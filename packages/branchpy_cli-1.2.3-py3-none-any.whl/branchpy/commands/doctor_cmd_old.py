from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from branchpy.config_store import ConfigStore
from branchpy.core.paths import BASE, CACHE, CONFIG, LOGS
from branchpy.patch_store import ensure_project_registered, get_project_patches_dir

# Optional dependencies
try:
    import psutil  # type: ignore[import]
except ImportError:
    psutil = None


def _ok(b):
    """Return OK or FAIL message with safe encoding."""
    if _can_display_unicode():
        return "✓ OK" if b else "✗ FAIL"
    else:
        return "[OK]" if b else "[FAIL]"


def _warn(b):
    """Return WARN or OK message with safe encoding."""
    if _can_display_unicode():
        return "⚠ WARN" if not b else "✓ OK"
    else:
        return "[WARN]" if not b else "[OK]"


def _can_display_unicode():
    """Check if the terminal can display Unicode/emoji safely."""
    try:
        # Check environment variables that indicate UTF-8 support
        if os.environ.get("PYTHONUTF8") == "1":
            return True
        if os.environ.get("LC_ALL", "").lower().endswith("utf-8"):
            return True
        if os.environ.get("LANG", "").lower().endswith("utf-8"):
            return True

        # Windows-specific checks
        if platform.system() == "Windows":
            try:
                # Try to encode/decode test emoji
                test_emoji = "🩺"
                test_emoji.encode(sys.stdout.encoding or "utf-8")
                return True
            except (UnicodeEncodeError, LookupError):
                return False

        # For non-Windows, default to True
        return True
    except Exception:
        return False


def _get_emoji_or_fallback(emoji, fallback):
    """Get emoji if Unicode is supported, otherwise return fallback."""
    return emoji if _can_display_unicode() else fallback


def _check_python_environment():
    """Check Python version and essential modules."""
    checks = []

    # Python version
    version_info = sys.version_info
    python_ok = (version_info.major, version_info.minor) >= (3, 11)
    checks.append(
        (
            "Python version",
            python_ok,
            f"{version_info.major}.{version_info.minor}.{version_info.micro}",
        )
    )

    # Essential modules
    essential_modules = ["json", "pathlib", "subprocess", "argparse"]
    for module in essential_modules:
        try:
            __import__(module)
            checks.append((f"Module {module}", True, "available"))
        except ImportError:
            checks.append((f"Module {module}", False, "missing"))

    # Optional but recommended
    optional_modules = ["appdirs"]
    for module in optional_modules:
        try:
            __import__(module)
            checks.append((f"Optional {module}", True, "available"))
        except ImportError:
            checks.append((f"Optional {module}", False, "missing (recommended)"))

    return checks


def _check_system_info():
    """Check system and platform info."""
    checks = []

    # Platform info
    checks.append(("Platform", True, f"{platform.system()} {platform.release()}"))
    checks.append(("Architecture", True, platform.machine()))

    # Disk space (where BranchPy stores data)
    try:
        if BASE.exists():
            stat = shutil.disk_usage(BASE)
            free_gb = stat.free / (1024**3)
            space_ok = free_gb > 1.0  # At least 1GB free
            checks.append(("Disk space", space_ok, f"{free_gb:.1f}GB free"))
        else:
            checks.append(("Disk space", False, "BranchPy data dir not accessible"))
    except Exception as e:
        checks.append(("Disk space", False, f"Error: {e}"))

    # Memory check (optional)
    try:
        if psutil is not None:
            mem = psutil.virtual_memory()
            mem_ok = mem.available / (1024**3) > 0.5  # At least 512MB available
            checks.append(
                ("Available memory", mem_ok, f"{mem.available / (1024**3):.1f}GB")
            )
        else:
            checks.append(("Available memory", True, "psutil not available (optional)"))
    except Exception as e:
        checks.append(("Available memory", False, f"Error: {e}"))

    return checks


def _check_branchpy_dirs():
    """Check BranchPy directory structure and permissions."""
    checks = []

    # Base directories
    dirs_to_check = [
        ("Config dir", CONFIG.parent),
        ("Cache dir", CACHE),
        ("Logs dir", LOGS),
        ("Base dir", BASE),
    ]

    for name, path in dirs_to_check:
        if path.exists():
            readable = os.access(path, os.R_OK)
            writable = os.access(path, os.W_OK)
            if readable and writable:
                checks.append((name, True, "exists, r/w OK"))
            else:
                perm_str = f"r={'OK' if readable else 'FAIL'}, w={'OK' if writable else 'FAIL'}"
                checks.append((name, False, f"exists, {perm_str}"))
        else:
            checks.append((name, False, "missing"))

    # Config file validity
    if CONFIG.exists():
        try:
            with open(CONFIG, "r", encoding="utf-8") as f:
                json.load(f)
            checks.append(("Config file", True, "valid JSON"))
        except Exception as e:
            checks.append(("Config file", False, f"invalid JSON: {e}"))
    else:
        checks.append(("Config file", True, "not present (will be created)"))

    # Recent crashes
    crashes = sorted(LOGS.glob("crash_*.log"), reverse=True)[:5]
    crash_count = len(crashes)
    if crash_count == 0:
        checks.append(("Recent crashes", True, "none found"))
    else:
        checks.append(("Recent crashes", False, f"{crash_count} found"))
        for crash in crashes[:3]:  # Show up to 3 most recent
            checks.append(
                ("", True, f"  {crash.name}")
            )  # Mark as True so it shows as info, not error

    return checks


def _check_config_integrity():
    """Check configuration store integrity."""
    checks = []

    try:
        cfg = ConfigStore()

        # Check if config loads
        checks.append(("Config store", True, "loads successfully"))

        # Check projects registry
        projects = cfg.cfg.projects
        if projects:
            valid_projects = 0
            for name, path in projects.items():
                if Path(path).exists():
                    valid_projects += 1
            if valid_projects == len(projects):
                checks.append(
                    ("Project registry", True, f"{len(projects)} projects, all valid")
                )
            else:
                checks.append(
                    (
                        "Project registry",
                        False,
                        f"{valid_projects}/{len(projects)} projects valid",
                    )
                )
        else:
            checks.append(
                ("Project registry", True, "empty (normal for new installation)")
            )

        # Check default project
        default = cfg.cfg.default_project
        if default:
            if default in projects and Path(projects[default]).exists():
                checks.append(("Default project", True, f"'{default}' exists"))
            else:
                checks.append(
                    ("Default project", False, f"'{default}' invalid/missing")
                )
        else:
            checks.append(("Default project", True, "none set"))

    except Exception as e:
        checks.append(("Config store", False, f"error: {e}"))

    return checks


def _check_renpy_sdk_config(project_root: str) -> bool:
    """Check project-specific Ren'Py SDK configuration."""
    has_warnings = False

    try:
        from branchpy.project_config import load_project_config
        from branchpy.renpy_sdk import RenpySdkManager

        # Load project config to check for Ren'Py settings
        config = load_project_config(project_root)
        manager = RenpySdkManager()

        # Check if project has Ren'Py pin
        if config.renpy_project_pin:
            sdk = manager.get_sdk(config.renpy_project_pin)
            if sdk and sdk.valid:
                print(
                    f"[{_ok(True)}] Project Ren'Py SDK: {config.renpy_project_pin} ({sdk.version or 'unknown'})"
                )
            else:
                print(
                    f"[{_warn(False)}] Project Ren'Py SDK: {config.renpy_project_pin} (invalid or missing)"
                )
                print(
                    f"    {_get_emoji_or_fallback('💡', 'Hint:')} Run 'branchpy renpy validate' to check SDK status"
                )
                has_warnings = True
        else:
            # Check if project appears to be a Ren'Py project
            renpy_files = [
                os.path.join(project_root, "options.rpy"),
                os.path.join(project_root, "script.rpy"),
                os.path.join(project_root, "game", "options.rpy"),
                os.path.join(project_root, "game", "script.rpy"),
            ]

            is_renpy_project = any(os.path.exists(f) for f in renpy_files)

            if is_renpy_project:
                # Check if there's a global default
                if config.renpy_default:
                    sdk = manager.get_sdk(config.renpy_default)
                    if sdk and sdk.valid:
                        print(
                            f"[{_ok(True)}] Ren'Py SDK: using global default {config.renpy_default} ({sdk.version or 'unknown'})"
                        )
                    else:
                        print(
                            f"[{_warn(False)}] Ren'Py SDK: global default {config.renpy_default} is invalid"
                        )
                        print(
                            f"    {_get_emoji_or_fallback('💡', 'Hint:')} Run 'branchpy renpy list' to see available SDKs"
                        )
                        has_warnings = True
                else:
                    print(f"[{_warn(False)}] Ren'Py project: no SDK configured")
                    print(
                        f"    {_get_emoji_or_fallback('💡', 'Hint:')} Set project SDK: 'branchpy renpy use <sdk-name>'"
                    )
                    print(
                        f"    {_get_emoji_or_fallback('💡', 'Hint:')} Or set global default: 'branchpy renpy default <sdk-name>'"
                    )
                    has_warnings = True
            else:
                print(f"[{_ok(True)}] Ren'Py SDK: not a Ren'Py project (no SDK needed)")

    except Exception as e:  # noqa: BLE001
        print(f"[{_warn(False)}] Ren'Py SDK check failed: {e}")
        has_warnings = True

    return has_warnings


def _check_global_renpy_sdks() -> bool:
    """Check global Ren'Py SDK registry."""
    has_warnings = False

    try:
        from branchpy.renpy_sdk import RenpySdkManager

        manager = RenpySdkManager()
        sdks = manager.list_sdks()

        if not sdks:
            print(f"[{_warn(False)}] Registry: no SDKs registered")
            print(
                f"    {_get_emoji_or_fallback('💡', 'Hint:')} Run 'branchpy renpy detect' to auto-detect SDKs"
            )
            print(
                f"    {_get_emoji_or_fallback('💡', 'Hint:')} Or manually add: 'branchpy renpy add <name> <path>'"
            )
            has_warnings = True
        else:
            valid_count = sum(1 for sdk in sdks.values() if sdk.valid)
            total_count = len(sdks)

            if valid_count == total_count:
                print(
                    f"[{_ok(True)}] Registry: {total_count} SDK(s) registered, all valid"
                )
            else:
                print(
                    f"[{_warn(False)}] Registry: {valid_count}/{total_count} SDKs valid"
                )
                print(
                    f"    {_get_emoji_or_fallback('💡', 'Hint:')} Run 'branchpy renpy validate' to check invalid SDKs"
                )
                has_warnings = True

            # List SDKs with status
            sdk_items = list(sdks.items())[:3]  # Show first 3 to avoid clutter
            for name, sdk in sdk_items:
                status = "valid" if sdk.valid else "invalid"
                version = sdk.version or "unknown"
                print(f"    • {name}: {version} ({status})")

            if len(sdks) > 3:
                print(
                    f"    ... and {len(sdks) - 3} more (run 'branchpy renpy list' for full list)"
                )

    except Exception as e:  # noqa: BLE001
        print(f"[{_warn(False)}] SDK registry check failed: {e}")
        has_warnings = True

    return has_warnings


def _git_info():
    git = shutil.which("git")
    if not git:
        return {"available": False, "version": None, "path": None}
    try:
        cp = subprocess.run(
            [git, "--version"], capture_output=True, text=True, check=True
        )
        return {"available": True, "version": cp.stdout.strip(), "path": git}
    except Exception:
        return {"available": True, "version": None, "path": git}


def cmd_doctor(args: argparse.Namespace) -> int:
    """Enhanced doctor command with comprehensive environment diagnostics."""
    has_errors = False
    has_warnings = False

    # Check if we can safely use Unicode/emoji
    can_use_unicode = _can_display_unicode()

    if can_use_unicode:
        print("🩺 BranchPy Doctor - Environment Diagnostics")
    else:
        print("BranchPy Doctor - Environment Diagnostics")
    print("=" * 50)

    # System Environment
    print(f"\n{_get_emoji_or_fallback('🖥️', 'System')}  System Environment")
    print("-" * 25)
    for name, status, detail in _check_system_info():
        if name:  # Skip empty names (used for indented details)
            print(f"[{_ok(status) if status else _warn(not status)}] {name}: {detail}")
            if not status:
                has_warnings = True
        else:
            print(f"    {detail}")

    # Python Environment
    print(f"\n{_get_emoji_or_fallback('🐍', 'Python')} Python Environment")
    print("-" * 25)
    for name, status, detail in _check_python_environment():
        print(f"[{_ok(status)}] {name}: {detail}")
        if not status:
            has_errors = True

    # BranchPy Directories and Files
    print(f"\n{_get_emoji_or_fallback('📁', 'BranchPy')} BranchPy Data")
    print("-" * 20)
    for name, status, detail in _check_branchpy_dirs():
        if name:  # Skip empty names (used for indented details)
            print(f"[{_ok(status) if status else _warn(not status)}] {name}: {detail}")
            if not status and "crashes" not in name.lower():
                has_warnings = True
        else:
            print(f"    {detail}")

    # Configuration Integrity
    print(f"\n{_get_emoji_or_fallback('⚙️', 'Config')}  Configuration")
    print("-" * 20)
    for name, status, detail in _check_config_integrity():
        print(f"[{_ok(status) if status else _warn(not status)}] {name}: {detail}")
        if not status:
            has_warnings = True

    # Git Integration
    print(f"\n{_get_emoji_or_fallback('🔧', 'Git')} Git Integration")
    print("-" * 20)
    gi = _git_info()
    if gi["available"]:
        print(f"[{_ok(True)}] Git: {gi['version'] or 'available'} ({gi['path']})")
        print(f"[{_ok(True)}] Features: undo/redo patches ENABLED")
    else:
        print(f"[{_warn(False)}] Git: NOT FOUND")
        print(f"[{_warn(False)}] Features: undo/redo patches DISABLED")
        print(
            f"    {_get_emoji_or_fallback('💡', 'Hint:')} Hint: Install Git (https://git-scm.com/downloads) and ensure 'git' is in PATH"
        )
        has_warnings = True

    # Current Project (if available)
    print(f"\n{_get_emoji_or_fallback('📋', 'Project')} Current Project")
    print("-" * 20)
    try:
        friendly, proj_root, _ = ensure_project_registered(
            getattr(args, "project", None)
        )
        pdir = get_project_patches_dir(friendly)

        print(f"[{_ok(True)}] Name: {friendly}")
        print(f"[{_ok(True)}] Root: {proj_root}")
        print(f"[{_ok(True)}] Patches: {pdir}")

        # Check patch dir exists and is writable
        patch_dir_ok = pdir.exists() and os.access(pdir, os.W_OK)
        print(
            f"[{_ok(patch_dir_ok)}] Patch directory: {'accessible' if patch_dir_ok else 'inaccessible'}"
        )
        if not patch_dir_ok:
            has_warnings = True

        # Check patch_state.json validity
        from branchpy.patch_state import _state_path

        state_path = _state_path(pdir)
        if state_path.exists():
            try:
                with open(state_path, "r", encoding="utf-8") as f:
                    json.load(f)
                print(f"[{_ok(True)}] Patch state: valid JSON")
            except Exception as e:
                print(f"[{_warn(False)}] Patch state: invalid JSON - {e}")
                has_warnings = True
        else:
            print(f"[{_ok(True)}] Patch state: not present (will be created as needed)")

        # Check git status if git is available
        if gi["available"]:
            try:
                cp = subprocess.run(
                    [gi["path"], "status", "--porcelain"],
                    cwd=str(proj_root),
                    capture_output=True,
                    text=True,
                )
                if cp.returncode == 0 and not cp.stdout.strip():
                    print(f"[{_ok(True)}] Git status: clean (safe for patches)")
                else:
                    print(
                        f"[{_warn(False)}] Git status: uncommitted changes (patches may be unsafe)"
                    )
                    has_warnings = True
            except Exception as e:
                print(f"[{_warn(False)}] Git status: could not check - {e}")
                has_warnings = True

        # Ren'Py SDK Configuration Check
        sdk_warnings = _check_renpy_sdk_config(str(proj_root))
        if sdk_warnings:
            has_warnings = True

    except SystemExit:
        print(f"[{_warn(False)}] No project resolved")
        print(
            f"    {_get_emoji_or_fallback('💡', 'Hint:')} Use --project <path|name> or set default via 'branchpy projects set-default'"
        )
        has_warnings = True
    except Exception as e:
        print(f"[{_warn(False)}] Project check failed: {e}")
        has_warnings = True

    # Global Ren'Py SDK Registry
    print(f"\n{_get_emoji_or_fallback('🎭', 'SDK')} Ren'Py SDK Registry")
    print("-" * 25)
    global_sdk_warnings = _check_global_renpy_sdks()
    if global_sdk_warnings:
        has_warnings = True

    # Summary
    print("\n" + "=" * 50)
    if has_errors:
        print(
            f"{_get_emoji_or_fallback('❌', 'ERROR:')} CRITICAL ISSUES FOUND - BranchPy may not function properly"
        )
        return 2  # Critical errors - fail
    elif has_warnings:
        print(
            f"{_get_emoji_or_fallback('⚠️', 'WARNING:')}  WARNINGS FOUND - Some features may be limited"
        )
        return 0  # Warnings are informational only (e.g., no SDKs on CI) - don't fail
    else:
        print(
            f"{_get_emoji_or_fallback('✅', 'SUCCESS:')} ALL CHECKS PASSED - BranchPy is ready to use!"
        )
        return 0  # All clear - success


def add_parser(subparsers):
    p = subparsers.add_parser(
        "doctor",
        help="Comprehensive environment and configuration diagnostics.",
        description="Perform comprehensive diagnostics of your BranchPy environment, including system info, Python environment, Git integration, configuration integrity, and current project status. Exit codes: 0=all OK, 1=warnings, 2=critical errors.",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Output results in JSON format for programmatic use",
    )
    p.set_defaults(handler=cmd_doctor)
