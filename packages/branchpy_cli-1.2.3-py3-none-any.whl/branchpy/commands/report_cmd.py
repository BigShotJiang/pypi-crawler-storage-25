# branchpy/commands/report_cmd.py
"""Report management command for saving and listing analyzer reports."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.commands.tests_cmd import run as run_tests
from branchpy.core.reports import get_report_summary, list_reports, save_report
from branchpy.project_resolver import resolve_project


def cmd_report(args: argparse.Namespace) -> int:
    """Handle report save/list operations."""

    # Resolve project path
    try:
        project_path = resolve_project(getattr(args, "project", "."))
        if not project_path:
            print("Error: Could not resolve project path")
            return 1
        project_path = Path(project_path)
    except Exception as e:
        print(f"Error resolving project: {e}")
        return 1

    if hasattr(args, "action") and args.action == "save":
        return _cmd_save_report(args, project_path)
    elif hasattr(args, "action") and args.action == "list":
        return _cmd_list_reports(args, project_path)
    elif hasattr(args, "save") and args.save:
        return _cmd_save_report(args, project_path)
    elif hasattr(args, "list") and args.list:
        return _cmd_list_reports(args, project_path)
    else:
        # Legacy report export mode - generate and display report
        return _cmd_export_report(args, project_path)


def _cmd_save_report(args: argparse.Namespace, project_path: Path) -> int:
    """Save a new report by running tests."""
    try:
        print(f"Running tests and saving report for project: {project_path}")

        # Run tests to get report data
        report_data = run_tests(str(project_path), as_json=True)

        if isinstance(report_data, str):
            report_data = json.loads(report_data)

        if not isinstance(report_data, dict):
            print("Error: Failed to generate valid report data")
            return 1

        # Save the report
        saved_path = save_report(report_data, project_path)

        if getattr(args, "json", False):
            result = {
                "success": True,
                "report_path": str(saved_path),
                "project_path": str(project_path),
            }
            print(json.dumps(result, indent=2))
        else:
            print(f"Report saved: {saved_path}")

        return 0

    except Exception as e:
        print(f"Error saving report: {e}")
        return 1


def _cmd_list_reports(args: argparse.Namespace, project_path: Path) -> int:
    """List saved reports for the project."""
    try:
        reports = list_reports(project_path)

        if getattr(args, "json", False):
            summary = get_report_summary(project_path)
            summary["reports"] = reports
            print(json.dumps(summary, indent=2))
        else:
            summary = get_report_summary(project_path)
            print(f"Project: {summary['project_key']}")
            print(f"Reports directory: {summary['reports_dir']}")
            print(f"Total reports: {summary['total_reports']}")

            if not reports:
                print("(no reports found)")
                return 0

            print("\nReports (newest first):")
            for i, report in enumerate(reports):
                # Format timestamp for display
                ts = report["timestamp"]
                formatted_ts = (
                    f"{ts[:4]}-{ts[4:6]}-{ts[6:8]} {ts[9:11]}:{ts[11:13]}:{ts[13:15]}"
                )

                size_kb = report["size"] / 1024
                prefix = "last" if i == 0 else f"last-{i}"

                print(
                    f"  {prefix:8} {formatted_ts}  {size_kb:6.1f}KB  {report['path']}"
                )

        return 0

    except Exception as e:
        print(f"Error listing reports: {e}")
        return 1


def _cmd_export_report(args: argparse.Namespace, project_path: Path) -> int:
    """Legacy report export functionality."""
    from branchpy.report import print_report
    from branchpy.report import save_report as legacy_save_report

    try:
        # Run tests to get results
        results = run_tests(str(project_path), as_json=True)
        if isinstance(results, str):
            results = json.loads(results)

        if not isinstance(results, dict):
            print("Failed to generate report: no results.")
            return 1

        # Output
        if hasattr(args, "out") and args.out:
            legacy_save_report(
                results, args.out, as_json=(getattr(args, "format", "text") == "json")
            )
            print(f"Report written to {args.out}")
        else:
            print_report(results, as_json=(getattr(args, "format", "text") == "json"))

        return 0

    except Exception as e:
        print(f"Failed to generate report: {e}")
        return 1


def add_parser(subparsers) -> None:
    """Register the report command with the CLI parser."""
    p = subparsers.add_parser(
        "report",
        help="Save, list, or export analyzer reports.",
        description=(
            "Save analyzer results as timestamped reports, list saved reports, "
            "or export reports in various formats. Reports are stored per-project "
            "in the user's data directory with automatic rotation."
        ),
        epilog=fmt_examples(
            "branchpy report --save",
            "branchpy report --list",
            "branchpy report --list --json",
            "branchpy --project mygame report --save",
            "branchpy --project C:\\proj report --list",
            "branchpy report --format json --out output.json",
        ),
        formatter_class=HelpFmt,
    )

    # Action group - save, list, or legacy export
    group = p.add_mutually_exclusive_group()
    group.add_argument(
        "--save", action="store_true", help="Run tests and save report with timestamp"
    )
    group.add_argument(
        "--list", action="store_true", help="List all saved reports for the project"
    )

    # Legacy export options (when neither --save nor --list)
    p.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format for legacy export mode",
    )
    p.add_argument(
        "--out", type=str, metavar="PATH", help="Output file for legacy export mode"
    )

    # Common options
    p.add_argument(
        "--json",
        action="store_true",
        help="Show output as JSON (for --save and --list)",
    )

    p.set_defaults(handler=cmd_report)
