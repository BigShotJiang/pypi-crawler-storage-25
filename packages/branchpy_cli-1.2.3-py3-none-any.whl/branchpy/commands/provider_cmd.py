"""Provider management CLI commands (Phase 2 RBAC integration).

Existing Subcommands:
    provider list                List available providers (requires image.validation.provider.read)
    provider enable <id>         Enable/authenticate provider (requires image.validation.provider.write)
    provider auth <id>           Authenticate provider (requires image.validation.provider.write)
    provider sync <project_id>   Sync assets (requires image.validation.provider.sync)
    provider status              Show connection status (requires image.validation.provider.read)

New Subcommands (introduced here):
    provider health --provider <id>            Run health check (requires image.validation.provider.health)
    provider rotate-credentials [--provider <id>]  Rotate encrypted credentials (requires image.validation.provider.credentials.rotate)
    provider reports list --provider <id>      List remote validation reports (requires image.validation.provider.report.list)
    provider reports push --provider <id> --file <report.json>  Push validation report (requires image.validation.provider.report.push)
    provider thumbnails rebuild --provider <id>  Rebuild / fetch thumbnails (requires image.validation.provider.thumbnail)

RBAC Enforcement:
    Loads `.branchpy/team.toml` if present; resolves user UUID from `.branchpy/identity.toml`.
    On capability violation: prints message and exits with code 65.

Governance Logging:
    Emits provider events using ImageValidationLogger (connect/list/fetch/push/health/credential rotation).
"""

import getpass
import json
import logging
import sys
import time
import tomllib
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy.analysis.image_validation.governance_logger import ImageValidationLogger
from branchpy.core.governance.standard_command_enforcement import standard_command
from branchpy.core.governance.team_manager import TeamManager
from branchpy.image_validation_v3.providers_v2 import (
    AuthenticationError,
    CredentialManager,
    ProviderError,
    ProviderRegistry,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# RBAC Helpers
# ---------------------------------------------------------------------------


def _load_identity_uuid() -> str:
    """Load user UUID from identity.toml; fallback to 'solo-user'."""
    identity_path = Path(".branchpy/identity.toml")
    if identity_path.exists():
        try:
            with open(identity_path, "rb") as f:
                data = tomllib.load(f)
            return data.get("user_uuid") or data.get("uuid") or "solo-user"
        except Exception:
            return "solo-user"
    return "solo-user"


def _require_capability(capability: str) -> None:
    """Enforce that current user has required capability with intelligent fallback suggestions; exit 65 if denied."""
    team_mgr = TeamManager(Path(".branchpy/team.toml"))
    user_uuid = _load_identity_uuid()
    role = team_mgr.get_role(user_uuid)
    if not team_mgr.has_capability(role, capability):
        # Emit RBAC_DENIED governance event with user_uuid for history tracking
        try:
            ImageValidationLogger(Path.cwd()).log_rbac_denied(
                capability=capability,
                user_role=role,
                command="provider_cli",
                reason="capability_missing",
                user_uuid=user_uuid,
            )
        except Exception:
            pass  # Non-critical if logging fails

        # Use intelligent fallback suggestions
        try:
            from branchpy.core.governance.denial_suggestions import (
                format_denial_message,
            )

            error_msg = format_denial_message(
                capability=capability,
                user_role=role,
                command="provider_cli",
                include_suggestion=True,
            )
            print(error_msg, file=sys.stderr)
        except ImportError:
            # Fallback if denial_suggestions not available
            print(
                f"Error: Permission denied (requires capability '{capability}', your role: {role})",
                file=sys.stderr,
            )

        sys.exit(65)


def _make_logger() -> ImageValidationLogger:
    return ImageValidationLogger(project_root=Path.cwd())


def cmd_provider_list(args):
    """List available providers (RBAC: image.validation.provider.read)."""
    _require_capability("image.validation.provider.read")
    registry = ProviderRegistry()
    providers = registry.list_providers(available_only=False)

    print("\n═══════════════════════════════════════════════════════════")
    print("  Available Storage Providers")
    print("═══════════════════════════════════════════════════════════\n")

    for provider_meta in providers:
        provider_id = provider_meta["id"]
        name = provider_meta["name"]
        auth_required = provider_meta["auth_required"]
        thumbnails = provider_meta["supports_thumbnails"]
        push_reports = provider_meta["supports_push_reports"]

        # Check if authenticated
        cred_manager = CredentialManager()
        has_creds = cred_manager.get_credentials(provider_id) is not None

        status = "✓ Connected" if has_creds else "○ Not Connected"

        print(f"  [{provider_id:12s}] {name}")
        print(f"    Status: {status}")
        print(f"    Auth Required: {auth_required}")
        print(f"    Thumbnails: {'Yes' if thumbnails else 'No'}")
        print(f"    Push Reports: {'Yes' if push_reports else 'No'}")
        print()

    print("═══════════════════════════════════════════════════════════\n")


def cmd_provider_enable(args):
    """Enable a provider (alias for auth). Requires provider.write capability."""
    if not args.provider_id:
        print("Error: Missing provider_id")
        print("Usage: branchpy provider enable <provider_id>")
        return 1

    # Delegate to auth command
    return cmd_provider_auth(args)


def cmd_provider_auth(args):
    """Authenticate with a provider (RBAC: image.validation.provider.write)."""
    if not args.provider_id:
        print("Error: Missing provider_id")
        print("Usage: branchpy provider auth <provider_id>")
        return 1

    provider_id = args.provider_id
    _require_capability("image.validation.provider.write")
    registry = ProviderRegistry()

    # Get provider metadata
    providers = registry.list_providers(available_only=False)
    provider_meta = next((p for p in providers if p["id"] == provider_id), None)

    if not provider_meta:
        print(f"Error: Unknown provider '{provider_id}'")
        print("Run 'branchpy provider list' to see available providers")
        return 1

    print("\n═══════════════════════════════════════════════════════════")
    print(f"  Authenticate with {provider_meta['name']}")
    print("═══════════════════════════════════════════════════════════\n")

    # Collect credentials based on provider
    credentials = _collect_credentials(provider_id)

    if not credentials:
        print("Authentication cancelled.")
        return 0

    # Test connection
    print("\nTesting connection...")

    t0 = time.perf_counter()
    try:
        provider = registry.get_provider(provider_id, {})
        logger_obj = _make_logger()
        logger_obj.log_provider_connect_start(provider_id, provider_meta["name"])
        if provider.connect(credentials):
            duration_ms = (time.perf_counter() - t0) * 1000
            logger_obj.log_provider_connect_ok(provider_id, duration_ms)
            # Save credentials
            cred_manager = CredentialManager()
            cred_manager.set_credentials(provider_id, credentials)

            print(f"✓ Successfully authenticated with {provider_meta['name']}")

            logger.info(
                json.dumps(
                    {
                        "event": "provider.authenticated",
                        "provider": provider_id,
                        "timestamp": datetime.utcnow().isoformat(),
                    }
                )
            )
            return 0
        else:
            print("✗ Authentication failed")
            return 1

    except (AuthenticationError, ProviderError) as e:
        duration_ms = (time.perf_counter() - t0) * 1000
        _make_logger().log_provider_connect_error(
            provider_id, type(e).__name__, str(e), duration_ms
        )
        print(f"✗ Authentication failed: {e}")
        return 1


def _collect_credentials(provider_id: str) -> Optional[Dict[str, Any]]:
    """Collect credentials interactively based on provider type."""

    if provider_id == "onedrive":
        print("OneDrive requires OAuth2 authentication.")
        print("You need to obtain an access token from Microsoft Graph API.\n")

        token = input("Access Token: ").strip()
        tenant_id = input("Tenant ID (optional, press Enter to skip): ").strip()

        creds = {"access_token": token}
        if tenant_id:
            creds["tenant_id"] = tenant_id

        return creds

    elif provider_id == "gdrive":
        print("Google Drive requires OAuth2 authentication.")
        print("You need to obtain an access token from Google Drive API.\n")

        token = input("Access Token: ").strip()
        return {"access_token": token}

    elif provider_id == "dropbox":
        print("Dropbox requires an access token from Dropbox API.\n")

        token = input("Access Token: ").strip()
        return {"access_token": token}

    elif provider_id == "mfiles":
        print("M-Files requires vault credentials.\n")

        vault_url = input("Vault URL (e.g., http://localhost:2266): ").strip()
        vault_id = input("Vault GUID: ").strip()
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ")

        return {
            "vault_url": vault_url,
            "vault_id": vault_id,
            "username": username,
            "password": password,
        }

    elif provider_id == "webdav":
        print("WebDAV requires endpoint and credentials.\n")

        endpoint = input(
            "WebDAV Endpoint (e.g., https://cloud.example.com/remote.php/webdav): "
        ).strip()
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ")

        auth_type = input("Auth Type (basic/digest) [basic]: ").strip().lower()
        if not auth_type:
            auth_type = "basic"

        return {
            "endpoint": endpoint,
            "username": username,
            "password": password,
            "auth_type": auth_type,
        }

    elif provider_id == "github":
        print("GitHub/GitLab requires a personal access token.\n")

        platform = input("Platform (github/gitlab) [github]: ").strip().lower()
        if not platform:
            platform = "github"

        token = input("Personal Access Token: ").strip()
        repo = input("Repository (owner/name): ").strip()

        creds = {"token": token, "platform": platform, "repo": repo}

        if platform == "gitlab":
            api_base = input(
                "GitLab API Base (optional, press Enter for gitlab.com): "
            ).strip()
            if api_base:
                creds["api_base"] = api_base

        return creds

    else:
        print(f"Unknown provider: {provider_id}")
        return None


@standard_command(
    name="provider.sync",
    capability="image.validation.provider.sync",
    export_audit=False,
)
def cmd_provider_sync(args):
    """Sync assets from a provider (RBAC: image.validation.provider.sync)."""
    if not args.project_id:
        print("Error: Missing project_id")
        print("Usage: branchpy provider sync <project_id> [options]")
        return 1

    project_id = args.project_id
    provider_id = args.provider
    recursive = args.recursive
    extensions = args.extensions

    if not provider_id:
        print("Error: Must specify --provider")
        return 1

    registry = ProviderRegistry()
    cred_manager = CredentialManager()

    # Get credentials
    credentials = cred_manager.get_credentials(provider_id)
    if not credentials:
        print(f"Error: Provider '{provider_id}' is not authenticated")
        print(f"Run 'branchpy provider auth {provider_id}' first")
        return 1

    print("\n═══════════════════════════════════════════════════════════")
    print(f"  Syncing Assets from {provider_id}")
    print("═══════════════════════════════════════════════════════════\n")
    print(f"Project: {project_id}")
    print(f"Recursive: {recursive}")
    if extensions:
        print(f"Extensions: {', '.join(extensions)}")
    print()

    try:
        # Connect
        provider = registry.get_provider(provider_id, {})
        logger_obj = _make_logger()
        t_conn = time.perf_counter()
        logger_obj.log_provider_connect_start(provider_id, provider_id)
        provider.connect(credentials)
        logger_obj.log_provider_connect_ok(
            provider_id, (time.perf_counter() - t_conn) * 1000
        )

        # List images
        print("Listing images...")
        t_list = time.perf_counter()
        assets = provider.list_images(
            project_id, extensions=extensions, recursive=recursive
        )
        logger_obj.log_provider_list_assets(
            provider_id=provider_id,
            asset_count=len(assets),
            folder=project_id,
            duration_ms=(time.perf_counter() - t_list) * 1000,
        )

        print(f"Found {len(assets)} images\n")

        # Download with progress
        download_dir = (
            Path(args.output_dir) if args.output_dir else Path.cwd() / "synced_assets"
        )
        download_dir.mkdir(parents=True, exist_ok=True)

        print(f"Downloading to: {download_dir}\n")

        success_count = 0
        error_count = 0

        for i, asset in enumerate(assets, 1):
            filename = Path(asset.path).name
            output_path = download_dir / filename

            # Progress indicator
            progress = f"[{i}/{len(assets)}]"
            print(f"{progress} {filename:50s} ", end="", flush=True)

            try:
                t_fetch = time.perf_counter()
                image_data = provider.fetch_image(asset)
                output_path.write_bytes(image_data)
                logger_obj.log_provider_fetch_asset(
                    provider_id=provider_id,
                    asset_id=asset.path,
                    size_bytes=len(image_data),
                    duration_ms=(time.perf_counter() - t_fetch) * 1000,
                )
                print("✓")
                success_count += 1
            except ProviderError as e:
                print(f"✗ {e}")
                error_count += 1

        print("\n═══════════════════════════════════════════════════════════")
        print("  Sync Complete")
        print("═══════════════════════════════════════════════════════════")
        print(f"  Success: {success_count}")
        print(f"  Errors:  {error_count}")
        print(f"  Total:   {len(assets)}")
        print("═══════════════════════════════════════════════════════════\n")

        logger.info(
            json.dumps(
                {
                    "event": "provider.sync_complete",
                    "provider": provider_id,
                    "project_id": project_id,
                    "success": success_count,
                    "errors": error_count,
                    "total": len(assets),
                }
            )
        )

        return 0

    except (AuthenticationError, ProviderError) as e:
        print(f"✗ Sync failed: {e}")
        return 1


def cmd_provider_status(args):
    """Show provider connection status (RBAC: image.validation.provider.read)."""
    _require_capability("image.validation.provider.read")
    registry = ProviderRegistry()
    cred_manager = CredentialManager()

    providers = registry.list_providers(available_only=False)

    print("\n═══════════════════════════════════════════════════════════")
    print("  Provider Connection Status")
    print("═══════════════════════════════════════════════════════════\n")

    for provider_meta in providers:
        provider_id = provider_meta["id"]
        name = provider_meta["name"]

        credentials = cred_manager.get_credentials(provider_id)

        if credentials:
            # Try to connect
            try:
                provider = registry.get_provider(provider_id, {})
                connected = provider.connect(credentials)

                if connected:
                    status = "✓ Connected"

                    # Check token expiry for OAuth providers
                    if provider_id in ["onedrive", "gdrive", "dropbox"]:
                        if cred_manager.is_token_expired(provider_id):
                            status = "⚠ Token Expired"
                else:
                    status = "✗ Connection Failed"

            except Exception as e:
                status = f"✗ Error: {e}"
        else:
            status = "○ Not Configured"

        print(f"  [{provider_id:12s}] {name:30s} {status}")


@standard_command(
    name="provider.health",
    capability="image.validation.provider.health",
    export_audit=True,
)
def cmd_provider_health(args):
    """Run provider health check (RBAC: image.validation.provider.health)."""
    if not args.provider:
        print("Error: --provider required")
        return 1
    provider_id = args.provider
    cred_manager = CredentialManager()
    credentials = cred_manager.get_credentials(provider_id)
    if not credentials:
        print(f"Error: Provider '{provider_id}' not authenticated")
        return 1
    registry = ProviderRegistry()
    provider = registry.get_provider(provider_id, {})
    logger_obj = _make_logger()
    t0 = time.perf_counter()
    try:
        provider.connect(credentials)
        latency_ms = (time.perf_counter() - t0) * 1000
        quota_used = None
        quota_total = None
        logger_obj.log_provider_health_check(
            provider_id=provider_id,
            status="OK",
            latency_ms=latency_ms,
            quota_used=quota_used,
            quota_total=quota_total,
        )
        print(f"Health Check: {provider_id} OK (latency={latency_ms:.1f}ms)")
        return 0
    except ProviderError as e:
        latency_ms = (time.perf_counter() - t0) * 1000
        logger_obj.log_provider_health_check(
            provider_id=provider_id,
            status="ERROR",
            latency_ms=latency_ms,
            quota_used=None,
            quota_total=None,
        )
        print(f"Health Check Failed: {e}")
        return 1


@standard_command(
    name="provider.rotate_credentials",
    capability="image.validation.provider.credentials.rotate",
    export_audit=True,
)
def cmd_provider_rotate_credentials(args):
    """Rotate provider credentials (RBAC: image.validation.provider.credentials.rotate)."""
    target_provider = args.provider  # Optional; if None rotate all
    cred_manager = CredentialManager()
    logger_obj = _make_logger()
    t0 = time.perf_counter()
    logger_obj.log_provider_credential_rotate_start(provider_id=target_provider)
    rotated = 0
    try:
        registry = ProviderRegistry()
        providers_meta = registry.list_providers(available_only=False)
    except Exception as e:
        logger_obj.log_provider_credential_rotate_error(
            str(e), (time.perf_counter() - t0) * 1000, provider_id=target_provider
        )
        print(f"Rotation failed (registry error): {e}")
        return 1
    for meta in providers_meta:
        pid = meta["id"]
        if target_provider and pid != target_provider:
            continue
        creds = cred_manager.get_credentials(pid)
        if not creds:
            continue
        cred_manager.set_credentials(pid, creds)
        rotated += 1
    duration_ms = (time.perf_counter() - t0) * 1000
    if rotated == 0:
        logger_obj.log_provider_credential_rotate_error(
            "No credentials to rotate", duration_ms, provider_id=target_provider
        )
        print("No credentials rotated (none found or filtered)")
        return 1
    logger_obj.log_provider_credential_rotate_complete(
        provider_count=rotated, duration_ms=duration_ms, provider_id=target_provider
    )
    scope = target_provider or "all"
    print(
        f"Rotated credentials for {rotated} provider(s) (scope={scope}, duration={duration_ms:.1f}ms)"
    )
    return 0


@standard_command(
    name="provider.reports.list",
    capability="image.validation.provider.report.list",
    export_audit=False,
)
def cmd_provider_reports_list(args):
    """List remote validation reports (RBAC: image.validation.provider.report.list)."""
    if not args.provider:
        print("Error: --provider required")
        return 1
    # Placeholder implementation until provider adapters expose report listing.
    print(f"(Stub) Remote reports for provider '{args.provider}': <not implemented>")
    return 0


@standard_command(
    name="provider.reports.push",
    capability="image.validation.provider.report.push",
    export_audit=True,
)
def cmd_provider_reports_push(args):
    """Push a validation report to remote (RBAC: image.validation.provider.report.push)."""
    if not args.provider:
        print("Error: --provider required")
        return 1
    if not args.file:
        print("Error: --file required (path to report JSON)")
        return 1
    report_path = Path(args.file)
    if not report_path.exists():
        print(f"Error: Report file not found: {report_path}")
        return 1
    cred_manager = CredentialManager()
    creds = cred_manager.get_credentials(args.provider)
    if not creds:
        print(f"Error: Provider '{args.provider}' not authenticated")
        return 1
    registry = ProviderRegistry()
    provider = registry.get_provider(args.provider, {})
    try:
        provider.connect(creds)
    except ProviderError as e:
        print(f"Error: Could not connect: {e}")
        return 1
    data = report_path.read_bytes()
    logger_obj = _make_logger()
    t0 = time.perf_counter()
    # Placeholder: provider.push_report(...) not yet defined; stub logging only.
    logger_obj.log_provider_push_report(
        provider_id=args.provider,
        remote_path=f"reports/{report_path.name}",
        size_bytes=len(data),
        duration_ms=(time.perf_counter() - t0) * 1000,
        report_id=report_path.stem,
    )
    print(f"(Stub) Uploaded report '{report_path.name}' to provider '{args.provider}'")
    return 0


@standard_command(
    name="provider.thumbnails.rebuild",
    capability="image.validation.provider.thumbnail",
    export_audit=False,
)
def cmd_provider_thumbnails_rebuild(args):
    """Rebuild thumbnails (RBAC: image.validation.provider.thumbnail)."""
    if not args.provider:
        print("Error: --provider required")
        return 1
    # Placeholder until thumbnail generation integrated.
    print(
        f"(Stub) Thumbnail rebuild initiated for provider '{args.provider}' — not yet implemented."
    )
    return 0


def register_provider_commands(subparsers):
    """Register provider CLI commands (with RBAC & Phase 2 extensions)."""

    # Main provider command
    provider_parser = subparsers.add_parser(
        "provider", help="Manage cloud storage providers"
    )

    provider_subparsers = provider_parser.add_subparsers(dest="provider_cmd")

    # list
    list_parser = provider_subparsers.add_parser(
        "list", help="List available providers"
    )
    list_parser.set_defaults(func=cmd_provider_list)

    # enable (alias for auth)
    enable_parser = provider_subparsers.add_parser("enable", help="Enable a provider")
    enable_parser.add_argument("provider_id", help="Provider ID")
    enable_parser.set_defaults(func=cmd_provider_enable)

    # auth
    auth_parser = provider_subparsers.add_parser(
        "auth", help="Authenticate with provider"
    )
    auth_parser.add_argument("provider_id", help="Provider ID")
    auth_parser.set_defaults(func=cmd_provider_auth)

    # sync
    sync_parser = provider_subparsers.add_parser(
        "sync", help="Sync assets from provider"
    )
    sync_parser.add_argument("project_id", help="Project/folder ID")
    sync_parser.add_argument("--provider", required=True, help="Provider ID")
    sync_parser.add_argument(
        "--recursive", action="store_true", default=True, help="Recursive search"
    )
    sync_parser.add_argument("--extensions", nargs="+", help="File extensions to sync")
    sync_parser.add_argument("--output-dir", help="Output directory")
    sync_parser.set_defaults(func=cmd_provider_sync)

    # status
    status_parser = provider_subparsers.add_parser(
        "status", help="Show provider status"
    )
    status_parser.set_defaults(func=cmd_provider_status)

    # health
    health_parser = provider_subparsers.add_parser(
        "health", help="Run provider health check"
    )
    health_parser.add_argument("--provider", required=True, help="Provider ID")
    health_parser.set_defaults(func=cmd_provider_health)

    # rotate credentials
    rotate_parser = provider_subparsers.add_parser(
        "rotate-credentials", help="Rotate provider credentials (all or one)"
    )
    rotate_parser.add_argument("--provider", help="Provider ID (omit to rotate all)")
    rotate_parser.set_defaults(func=cmd_provider_rotate_credentials)

    # reports (parent)
    reports_parser = provider_subparsers.add_parser(
        "reports", help="Manage remote validation reports"
    )
    reports_sub = reports_parser.add_subparsers(dest="reports_cmd")
    reports_list = reports_sub.add_parser("list", help="List remote reports")
    reports_list.add_argument("--provider", required=True, help="Provider ID")
    reports_list.set_defaults(func=cmd_provider_reports_list)
    reports_push = reports_sub.add_parser("push", help="Push a validation report")
    reports_push.add_argument("--provider", required=True, help="Provider ID")
    reports_push.add_argument("--file", required=True, help="Report JSON file path")
    reports_push.set_defaults(func=cmd_provider_reports_push)

    # thumbnails
    thumb_parser = provider_subparsers.add_parser(
        "thumbnails", help="Thumbnail operations"
    )
    thumb_sub = thumb_parser.add_subparsers(dest="thumb_cmd")
    thumb_rebuild = thumb_sub.add_parser(
        "rebuild", help="Rebuild thumbnails for provider"
    )
    thumb_rebuild.add_argument("--provider", required=True, help="Provider ID")
    thumb_rebuild.set_defaults(func=cmd_provider_thumbnails_rebuild)
