"""
branchpy test command — Entry point for running project tests with JSON summaries.

Usage:
    branchpy test [--format text|json] [--out PATH] [--coverage] [--threshold N]

Exit codes:
    0 - All tests passed
    1 - Tests failed
    2 - Coverage threshold not met
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from branchpy.attribution import maybe_show_attribution_notice
from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.obs import emit, end_operation, start_operation
from branchpy.project_resolver import resolve_project


def run_pytest(
    project_path: Path,
    coverage: bool = False,
    threshold: int | None = None,
    extra_args: list[str] | None = None,
) -> dict[str, Any]:
    """
    Run pytest in the project directory and capture results.

    Args:
        project_path: Path to the project root
        coverage: Whether to collect coverage data
        threshold: Minimum coverage percentage required (if coverage enabled)
        extra_args: Additional arguments to pass through to pytest (e.g., ["-m", "not advisory"])

    Returns:
        Dictionary with test results and metadata
    """
    cmd = [sys.executable, "-m", "pytest"]

    # Add JSON output
    cmd.extend(["--json-report", "--json-report-file=/tmp/pytest-report.json"])

    # Add coverage if requested
    if coverage:
        cmd.extend(["--cov=branchpy", "--cov-report=json"])
        if threshold:
            cmd.append(f"--cov-fail-under={threshold}")

    # Forward extra pytest arguments (e.g., -m "not advisory")
    if extra_args:
        cmd.extend(extra_args)

    # Change to project directory
    try:
        result = subprocess.run(
            cmd,
            cwd=project_path,
            capture_output=True,
            text=True,
            timeout=300,  # 5 minute timeout
        )
    except subprocess.TimeoutExpired:
        return {
            "status": "error",
            "error": "Test execution timed out after 5 minutes",
            "tests": {"total": 0, "passed": 0, "failed": 0, "skipped": 0},
            "coverage": None,
        }
    except FileNotFoundError:
        return {
            "status": "error",
            "error": "pytest not found - install with: pip install pytest pytest-json-report pytest-cov",
            "tests": {"total": 0, "passed": 0, "failed": 0, "skipped": 0},
            "coverage": None,
        }

    # Parse pytest output
    tests_data = {"total": 0, "passed": 0, "failed": 0, "skipped": 0, "duration": 0.0}

    # Simple regex parsing of pytest output (fallback if JSON report not available)
    import re

    # Look for pattern like "5 passed, 2 failed, 1 skipped in 1.23s"
    summary_match = re.search(
        r"(\d+)\s+passed|(\d+)\s+failed|(\d+)\s+skipped", result.stdout + result.stderr
    )

    if summary_match:
        for line in (result.stdout + result.stderr).split("\n"):
            if "passed" in line:
                passed = re.search(r"(\d+)\s+passed", line)
                if passed:
                    tests_data["passed"] = int(passed.group(1))
            if "failed" in line:
                failed = re.search(r"(\d+)\s+failed", line)
                if failed:
                    tests_data["failed"] = int(failed.group(1))
            if "skipped" in line:
                skipped = re.search(r"(\d+)\s+skipped", line)
                if skipped:
                    tests_data["skipped"] = int(skipped.group(1))

    tests_data["total"] = (
        tests_data["passed"] + tests_data["failed"] + tests_data["skipped"]
    )

    # Parse coverage if available
    coverage_data = None
    if coverage:
        coverage_file = project_path / "coverage.json"
        if coverage_file.exists():
            try:
                with coverage_file.open() as f:
                    cov = json.load(f)
                    coverage_data = {
                        "percent": cov.get("totals", {}).get("percent_covered", 0),
                        "lines_covered": cov.get("totals", {}).get("covered_lines", 0),
                        "lines_total": cov.get("totals", {}).get("num_statements", 0),
                    }
            except Exception:
                pass

    # Determine status - GOVERNANCE: test failures always take precedence over coverage gates
    status = "passed"
    if result.returncode != 0:
        failed_count = tests_data.get("failed", 0)

        # 1) Never mask real test failures
        if failed_count > 0:
            status = "failed"

        # 2) Only call it coverage_failed if tests did NOT fail
        elif (
            coverage
            and threshold is not None
            and coverage_data
            and coverage_data.get("percent") is not None
            and coverage_data["percent"] < threshold
        ):
            status = "coverage_failed"

        # 3) Otherwise it's some execution/collection/config error
        else:
            status = "error"

    # Emit stderr summary for CI diagnostics
    try:
        msg_parts = [f"branchpy test status={status}"]
        msg_parts.append(
            f"tests: passed={tests_data.get('passed', 0)} failed={tests_data.get('failed', 0)} "
            f"skipped={tests_data.get('skipped', 0)} total={tests_data.get('total', 0)}"
        )
        if coverage_data and coverage_data.get("percent") is not None:
            msg_parts.append(
                f"coverage={coverage_data['percent']:.1f}% threshold={threshold}"
            )
        print(" | ".join(msg_parts), file=sys.stderr)
    except Exception:
        # Never let logging break the command
        pass

    return {
        "status": status,
        "tests": tests_data,
        "coverage": coverage_data,
        "exit_code": result.returncode,
    }


def format_text_output(results: dict[str, Any]) -> str:
    """Format test results as human-readable text."""
    lines = []

    lines.append("=== BranchPy: Test Results ===")
    lines.append("")

    tests = results["tests"]
    lines.append(f"Tests: {tests['total']} total")
    lines.append(f"  ✓ Passed:  {tests['passed']}")

    if tests["failed"] > 0:
        lines.append(f"  ✗ Failed:  {tests['failed']}")

    if tests["skipped"] > 0:
        lines.append(f"  ○ Skipped: {tests['skipped']}")

    if tests.get("duration"):
        lines.append(f"  ⏱ Duration: {tests['duration']:.2f}s")

    # Coverage section
    if results.get("coverage"):
        cov = results["coverage"]
        lines.append("")
        lines.append("Coverage:")
        lines.append(
            f"  {cov['percent']:.1f}% ({cov['lines_covered']}/{cov['lines_total']} lines)"
        )

    # Status
    lines.append("")
    status = results["status"]
    if status == "passed":
        lines.append("Status: ✓ ALL TESTS PASSED")
    elif status == "failed":
        lines.append("Status: ✗ TESTS FAILED")
    elif status == "coverage_failed":
        lines.append("Status: ✗ COVERAGE THRESHOLD NOT MET")
    else:
        lines.append(f"Status: ERROR - {results.get('error', 'Unknown error')}")

    return "\n".join(lines)


def run(
    project: str | None = None,
    format_type: str = "text",
    out: str | None = None,
    coverage: bool = False,
    threshold: int | None = None,
    extra_args: list[str] | None = None,
) -> int:
    """
    Run project tests and output results.

    Args:
        project: Project path (defaults to current directory)
        format_type: "text" or "json"
        out: Optional output file path
        coverage: Whether to collect coverage data
        threshold: Minimum coverage percentage (0-100)
        extra_args: Additional arguments to pass through to pytest

    Returns:
        0: all tests passed
        1: tests failed
        2: coverage threshold not met
    """
    op_id = start_operation("test.run", {"project": project, "coverage": coverage})

    try:
        # Resolve project path
        project_path = resolve_project(project or ".")
        if not project_path:
            print(f"Error: Could not resolve project: {project}")
            end_operation(
                op_id,
                "test.run",
                status="error",
                meta={"error": "project resolution failed"},
            )
            return 1

        emit("test.start", {"project": str(project_path)})

        # Run tests
        results = run_pytest(
            project_path, coverage=coverage, threshold=threshold, extra_args=extra_args
        )

        # Output results
        if format_type == "json":
            output = json.dumps(results, indent=2, ensure_ascii=False)
        else:
            output = format_text_output(results)

        if out:
            Path(out).write_text(output, encoding="utf-8")
            print(f"Results written to: {out}")
        else:
            print(output)

        # Determine exit code
        status = results["status"]
        if status == "passed":
            exit_code = 0
        elif status == "coverage_failed":
            exit_code = 2
        else:
            exit_code = 1

        end_operation(
            op_id,
            "test.run",
            status=status,
            meta={"tests": results["tests"], "coverage": results.get("coverage")},
        )

        # Show attribution notice if Free tier and tests passed
        if exit_code == 0:
            maybe_show_attribution_notice("test")

        return exit_code

    except Exception as e:
        print(f"Test execution failed: {e}")
        end_operation(op_id, "test.run", status="error", meta={"error": str(e)})
        return 1


def cmd_test(args: argparse.Namespace) -> int:
    """Handle test command from CLI."""
    # Extract extra pytest arguments that weren't parsed by argparse
    # These come from the _pytest_extra_args attribute set in cli.py
    extra_args = getattr(args, "_pytest_extra_args", None)

    return run(
        project=getattr(args, "project", None),
        format_type=getattr(args, "format", "text"),
        out=getattr(args, "out", None),
        coverage=getattr(args, "coverage", False),
        threshold=getattr(args, "threshold", None),
        extra_args=extra_args,
    )


def build(parser: argparse.ArgumentParser) -> None:
    """Configure argparse for the test command."""
    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    parser.add_argument("--out", metavar="PATH", help="Write output to file")
    parser.add_argument(
        "--coverage", action="store_true", help="Collect test coverage data"
    )
    parser.add_argument(
        "--threshold",
        type=int,
        metavar="N",
        help="Minimum coverage percentage (0-100, requires --coverage)",
    )
    # Note: pytest args are passed through via parse_known_args in cmd_test()


def add_parser(subparsers) -> None:
    """Register the test command with the CLI parser."""
    p = subparsers.add_parser(
        "test",
        help="Run project tests with JSON summaries.",
        description=(
            "Execute project test suite using pytest and output structured results. "
            "Supports coverage collection with configurable thresholds."
        ),
        epilog=fmt_examples(
            "branchpy test",
            "branchpy test --format json",
            "branchpy test --coverage --threshold 80",
            "branchpy --project mygame test --out results.json",
            "branchpy test --coverage --format json --out coverage.json",
        ),
        formatter_class=HelpFmt,
    )

    build(p)
    p.set_defaults(handler=cmd_test)
