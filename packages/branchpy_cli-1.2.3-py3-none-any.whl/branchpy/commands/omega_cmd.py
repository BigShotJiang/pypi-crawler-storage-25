# BranchPyApp/branchpy/commands/omega_cmd.py

from __future__ import annotations

import json
import sys
from pathlib import Path

from branchpy.analysis.omega import OmegaLimits, run_omega

# License gating (v1.0.0)
from branchpy.license.gating import require_feature_cli


def add_parser(subparsers) -> None:
    p = subparsers.add_parser(
        "omega",
        help="OMEGA: derive bounds/co-occurrence signals from PILOT (stats2) output",
    )

    # Match your other commands' conventions as closely as possible.
    p.add_argument(
        "--project-root",
        dest="project_root",
        default=None,
        help="Project root (defaults to current working directory).",
    )

    p.add_argument(
        "--value-cap",
        dest="value_cap",
        type=int,
        default=50,
        help="Max distinct values tracked per variable (default: 50).",
    )

    p.add_argument(
        "--combo-cap",
        dest="combo_cap",
        type=int,
        default=2000,
        help="Max impossible-combo candidates evaluated (default: 2000).",
    )

    p.add_argument(
        "--open",
        dest="open_after",
        action="store_true",
        help="Open the OMEGA report after generation (if supported by caller).",
    )

    p.add_argument(
        "--html",
        action="store_true",
        help="Generate a standalone HTML report artifact (saved to .branchpy/reports/).",
    )

    p.add_argument(
        "--no-auto-recompute",
        dest="no_auto_recompute",
        action="store_true",
        help="Do not automatically re-run PILOT if its output is missing or stale.",
    )

    p.set_defaults(_branchpy_cmd="omega", omega_subcommand=None)

    # ── Subcommands (BPY-OMEGA-03) ───────────────────────────────────────────
    subs = p.add_subparsers(dest="omega_subcommand")

    # pf-report: validate cache then render PF metrics summary (promotion-only)
    p_pf = subs.add_parser(
        "pf-report",
        help=(
            "Validate Omega metrics cache and render PF summary "
            "(promotion-only — no recompute). Exits 0=valid, 1=schema warn, 2=invalid."
        ),
    )
    p_pf.add_argument(
        "--project-root",
        dest="project_root",
        default=None,
        help="Project root (defaults to current working directory).",
    )
    p_pf.set_defaults(_branchpy_cmd="omega", omega_subcommand="pf-report")

    # calibrate-batch: validate cache then run calibration batch (promotion-only)
    p_cal = subs.add_parser(
        "calibrate-batch",
        help=(
            "Validate Omega metrics cache and run calibration batch in "
            "promotion-only mode (consumes existing artifact — no recompute). "
            "Exits 0=valid, 1=schema warn, 2=invalid."
        ),
    )
    p_cal.add_argument(
        "--project-root",
        dest="project_root",
        default=None,
        help="Project root (defaults to current working directory).",
    )
    p_cal.set_defaults(_branchpy_cmd="omega", omega_subcommand="calibrate-batch")


def run(args) -> int:
    # ── Subcommand dispatch (BPY-OMEGA-03) ───────────────────────────────────
    subcommand = getattr(args, "omega_subcommand", None)
    if subcommand == "pf-report":
        return _run_pf_report(args)
    if subcommand == "calibrate-batch":
        return _run_calibrate_batch(args)

    # LIC-CLI-7: Omega requires Ren'Py Free+ tier
    project_root = (
        Path(args.project_root).resolve() if args.project_root else Path.cwd().resolve()
    )
    require_feature_cli("omega", "Omega State-Space Analysis", project_root)

    stats2_dir = project_root / ".branchpy" / "stats2"
    stats2_path = stats2_dir / "stats2.json"
    omega_path = stats2_dir / "omega.json"

    # Phase 5: Auto-recompute PILOT prerequisite if missing or stale
    from branchpy.artifact_freshness import (
        check_artifact_freshness,
        patch_artifact_metadata,
    )
    from branchpy.run_context import RunContext

    _run_ctx = getattr(args, "_run_ctx", None)
    no_auto_recompute = getattr(args, "no_auto_recompute", False)
    pilot_status = check_artifact_freshness(project_root, "pilot")

    if pilot_status.missing or pilot_status.stale:
        if no_auto_recompute:
            _reason = "missing" if pilot_status.missing else "stale"
            print(
                f"[bpy] Error: PILOT output is {_reason}. " "Run: branchpy stats2",
                file=__import__("sys").stderr,
            )
            return 1
        _reason_str = (
            "source files changed \u2013 recomputing\u2026"
            if pilot_status.stale
            else "first-time run\u2026"
        )
        print(f"  \u21bb  pilot     ({_reason_str})")
        import argparse as _argparse

        from branchpy.commands.stats2_cmd import run as _stats2_run

        _pilot_ns = _argparse.Namespace(
            project=str(project_root),
            max_paths=500,
            max_depth=100,
            output_dir="stats2",
            policy_mode="off",
            policy_json="",
            _run_ctx=_run_ctx,
        )
        _rc = _stats2_run(_pilot_ns)
        if _rc != 0:
            print("[bpy] Error: PILOT recompute failed.", file=__import__("sys").stderr)
            return 1
    else:
        print("  \u2713  pilot     (cached \u2013 project unchanged)")

    # OMEGA requires full per-path event data (Class C payload).
    # stats2.json is the thin public summary (Class B — no paths/events/aggregates).
    # Prefer .internal/stats2_full.json; checked AFTER any auto-recompute so the
    # file is guaranteed to exist when PILOT was just written for the first time.
    stats2_full_path = stats2_dir / ".internal" / "stats2_full.json"
    if stats2_full_path.exists():
        stats2_path = stats2_full_path

    limits = OmegaLimits(
        value_cap=int(getattr(args, "value_cap", 50)),
        combo_cap=int(getattr(args, "combo_cap", 2000)),
    )

    result = run_omega(stats2_path=stats2_path, omega_path=omega_path, limits=limits)

    # Write again defensively if run_omega returned dict but did not write (it should write).
    if isinstance(result, dict) and not omega_path.exists():
        omega_path.parent.mkdir(parents=True, exist_ok=True)
        omega_path.write_text(
            json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    # Phase 5: Embed source_revision + run identity for freshness model
    try:
        if _run_ctx is None:
            from branchpy.artifact_freshness import get_source_revision

            _run_ctx = RunContext.start(
                project_root, get_source_revision(project_root)
            ).complete()
        patch_artifact_metadata(omega_path, project_root, "omega", run_ctx=_run_ctx)
    except Exception:
        pass  # non-fatal; freshness metadata is best-effort

    # (M-09) Write timestamped history snapshot alongside the stable latest.
    # Snapshot name: omega-{YYYYMMDD_HHMMSS}.json in the same directory.
    # Consumers must use the latest pointer (omega.json) for current data;
    # snapshots are for history only.
    try:
        import time as _time

        _snap_ts = _time.strftime("%Y%m%d_%H%M%S")
        _snap_path = omega_path.parent / f"omega-{_snap_ts}.json"
        _snap_path.write_text(omega_path.read_text(encoding="utf-8"), encoding="utf-8")
    except Exception:
        pass  # non-fatal; latest file was already written successfully

    print(f"OMEGA wrote: {omega_path}")

    # Emit Ω-2 engine metrics (edit cardinality + state width) from stats2 data.
    # Uses a lightweight graph adapter built from the path/variable data in stats2.json.
    # (M-10) Writes .branchpy/omega/omega_metrics.json (moved from root in Wave 4).
    _emit_omega2_metrics(project_root, stats2_path)

    # --html / --open: generate standalone HTML report
    if getattr(args, "html", False) or getattr(args, "open_after", False):
        try:
            from branchpy.cli.html_report import (
                announce_html_report,
                generate_omega_html,
            )
            from branchpy.cli.html_report import open_in_browser as _open_browser
            from branchpy.cli.html_report import resolve_html_output_path

            omega_data = json.loads(omega_path.read_text(encoding="utf-8"))
            omega2_path = project_root / ".branchpy" / "omega" / "omega_metrics.json"
            # Legacy fallback: root-level path pre-M-10
            if not omega2_path.exists():
                omega2_path = project_root / ".branchpy" / "omega_metrics.json"
            omega2_data = None
            if omega2_path.exists():
                try:
                    omega2_data = json.loads(omega2_path.read_text(encoding="utf-8"))
                except Exception:
                    pass
            html_path = generate_omega_html(
                omega_data,
                project_root,
                resolve_html_output_path(project_root, "omega", None),
                omega2_data=omega2_data,
            )
            announce_html_report("omega", html_path)
            if getattr(args, "open_after", False):
                _open_browser(html_path)
        except Exception as _html_err:
            print(
                f"[bpy] Warning: HTML report generation failed: {_html_err}",
                file=sys.stderr,
            )

    return 0


def _emit_omega2_metrics(project_root: Path, stats2_path: Path) -> None:
    """
    Build a lightweight graph adapter from stats2 data and emit omega_metrics.json.

    Uses only the path sequences and per-label variable modification data present
    in the stats2 JSON — no full parse required. This is a conservative
    over-approximation suitable for cardinality and width metrics.

    Non-fatal: any exception is caught and logged to stderr.
    """
    try:
        from branchpy.omega import (
            compute_edit_cardinality,
            compute_state_width,
            export_omega_metrics,
        )
        from branchpy.omega.domains import (
            make_bool_meta,
            make_int_meta,
            make_unknown_meta,
        )

        stats2_data = json.loads(stats2_path.read_text(encoding="utf-8"))

        # ── Build graph adapter from stats2 paths ────────────────────────────
        _modifies: dict[str, set] = {}  # label -> set of var names modified there
        _preds: dict[str, list] = {}  # label -> list of predecessor labels
        _succs: dict[str, list] = {}  # label -> list of successor labels
        _all_labels: set = set()

        for path_obj in stats2_data.get("paths", []):
            path_seq = path_obj.get("path", [])
            for i, label in enumerate(path_seq):
                _all_labels.add(label)
                if label not in _preds:
                    _preds[label] = []
                if i > 0:
                    pred = path_seq[i - 1]
                    if pred not in _preds[label]:
                        _preds[label].append(pred)
                if i < len(path_seq) - 1:
                    succ = path_seq[i + 1]
                    if label not in _succs:
                        _succs[label] = []
                    if succ not in _succs[label]:
                        _succs[label].append(succ)
            for var_name, var_data in path_obj.get("variables", {}).items():
                for change in var_data.get("changes", []):
                    lbl = change.get("label", "")
                    if lbl:
                        _all_labels.add(lbl)
                        _modifies.setdefault(lbl, set()).add(var_name)

        if not _all_labels:
            # Nothing to analyze (no paths)
            return

        class _LabelNode:
            def __init__(self, mods, next_labels):
                self.modifies_variables = mods
                self.next_labels = next_labels

        class _GraphAdapter:
            def get_all_labels(self):
                return _all_labels

            def get_label(self, name):
                return _LabelNode(_modifies.get(name, set()), _succs.get(name, []))

            def get_predecessors(self, name):
                return _preds.get(name, [])

        graph = _GraphAdapter()

        # ── Build initial variable metadata from aggregates ──────────────────
        aggregates = stats2_data.get("aggregates", {})
        initial_meta: dict = {}
        for var_name, agg in aggregates.items():
            tc = agg.get("type_consistency", {})
            types = tc.get("types", [])
            primary_type = types[0] if types else "unknown"
            if primary_type == "boolean":
                initial_meta[var_name] = make_bool_meta(var_name)
            elif primary_type == "number":
                initial_meta[var_name] = make_int_meta(var_name)
            else:
                initial_meta[var_name] = make_unknown_meta(var_name)

        # ── Compute Ω-2 metrics ──────────────────────────────────────────────
        ec_result = compute_edit_cardinality(graph)
        sw_result = compute_state_width(graph, initial_meta)

        n_declared = (
            len(aggregates)
            if aggregates
            else len({v for mods in _modifies.values() for v in mods})
        )

        # ── Compute Ω-2.5 contextual PF signals ─────────────────────────────
        contextual_signals = None
        try:
            from branchpy.omega.pf_contextual import (
                PFContextualConfig,
                PFRawResult,
                pf_contextual,
            )

            pf_raw = PFRawResult(PF_RAW=0, PF_ALL=0, PF_CORE=0, W_player_core=0)
            ctx_result = pf_contextual(
                graph,
                ec_result.counts,
                pf_raw,
                PFContextualConfig(enable_pf_contextual=True),
            )
            contextual_signals = {
                "pf_entropy": ctx_result.pf_entropy,
                "pf_compression": ctx_result.pf_compression,
                "pf_density": ctx_result.pf_density,
                "rationale": ctx_result.rationale,
            }
        except Exception as _ctx_err:
            # Non-fatal: contextual signals are best-effort
            import sys as _sys

            print(
                f"[bpy] Warning: Ω-2.5 contextual signals failed: {_ctx_err}",
                file=_sys.stderr,
            )

        # (M-10) New canonical location: .branchpy/omega/omega_metrics.json
        # Auto-migrate: if the old root file exists and the new location does not,
        # move it so no ghost artifact is left behind.
        out_path = project_root / ".branchpy" / "omega" / "omega_metrics.json"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        old_omega_metrics = project_root / ".branchpy" / "omega_metrics.json"
        if old_omega_metrics.exists() and not out_path.exists():
            try:
                old_omega_metrics.rename(out_path)
            except Exception:
                # Cross-device or permission failure — copy then delete
                import shutil

                try:
                    shutil.copy2(old_omega_metrics, out_path)
                    old_omega_metrics.unlink()
                except Exception:
                    pass  # migration failed non-fatally; write below will still succeed
        export_omega_metrics(
            edit_cardinality=ec_result,
            state_width=sw_result,
            initial_meta_count=n_declared,
            engine="renpy",
            output_path=out_path,
            contextual_signals=contextual_signals,
            project_root=project_root,
        )
        print(f"OMEGA wrote: {out_path} (Ω-2 metrics)")

    except Exception as _err:
        print(f"[bpy] Warning: Ω-2 metrics emission failed: {_err}", file=sys.stderr)


# ============================================================================
# pf-report subcommand (BPY-OMEGA-03)
# ============================================================================


def _resolve_metrics_path(project_root: Path) -> Path:
    """Return the canonical omega_metrics.json path for *project_root*."""
    canonical = project_root / ".branchpy" / "omega" / "omega_metrics.json"
    if not canonical.exists():
        legacy = project_root / ".branchpy" / "omega_metrics.json"
        if legacy.exists():
            return legacy
    return canonical


def _run_pf_report(args) -> int:
    """
    branchpy omega pf-report

    Validate the Omega metrics cache and render a PF summary.
    Promotion-only: never recomputes — reads the existing artifact only.

    Exit codes:
      0  — cache valid, report rendered
      1  — cache schema mismatch (warn), report rendered
      2  — cache missing or corrupt, cannot render
    """
    from branchpy.omega.cache_validator import validate_omega_cache

    project_root = (
        Path(args.project_root).resolve()
        if getattr(args, "project_root", None)
        else Path.cwd().resolve()
    )
    metrics_path = _resolve_metrics_path(project_root)
    val = validate_omega_cache(metrics_path)

    if val.exit_code == 2:
        print(f"[bpy] Error: {val.message}", file=sys.stderr)
        return 2

    if val.exit_code == 1:
        print(f"[bpy] Warning: {val.message}", file=sys.stderr)

    # Render summary from the cached artifact
    try:
        data = json.loads(metrics_path.read_text(encoding="utf-8"))
        gs = data.get("graph_summary", {})
        ms = data.get("metadata_summary", {})
        cs = data.get("contextual_signals") or {}

        print("── Omega PF Report ─────────────────────────────────")
        print(f"  Schema:    {data.get('schema_version', 'unknown')}")
        print(
            f"  Generated: {data.get('generated_at', data.get('timestamp_utc', 'unknown'))}"
        )
        print(f"  Version:   {data.get('branchpy_version', 'unknown')}")
        print(f"  Engine:    {data.get('engine', 'unknown')}")
        print("  Graph")
        print(f"    Nodes:          {gs.get('nodes', '?')}")
        print(f"    Modified nodes: {gs.get('nodes_with_modifications', '?')}")
        print(f"    Cycles:         {gs.get('cycles_detected', False)}")
        print("  Metadata")
        print(f"    Variables:      {ms.get('variables_declared', '?')}")
        if cs:
            print("  Contextual PF (Ω-2.5)")
            for key in ("pf_entropy", "pf_compression", "pf_density"):
                val_map = cs.get(key, {})
                if isinstance(val_map, dict):
                    top = max(val_map.values(), default=None) if val_map else None
                    print(f"    {key}: max={top}")
        fp = data.get("project_fingerprint")
        if fp:
            print(f"  Fingerprint: {fp[:16]}…")
        print("─────────────────────────────────────────────────────")
    except Exception as exc:
        print(f"[bpy] Error reading metrics artifact: {exc}", file=sys.stderr)
        return 2

    return val.exit_code


# ============================================================================
# calibrate-batch subcommand (BPY-OMEGA-03)
# ============================================================================


def _run_calibrate_batch(args) -> int:
    """
    branchpy omega calibrate-batch

    Validate the Omega metrics cache then run calibration batch in
    promotion-only mode (consumes the existing artifact — no recompute).

    Exit codes:
      0  — cache valid, calibration batch ready
      1  — cache schema mismatch (warn), calibration may proceed with caution
      2  — cache missing or corrupt, calibration aborted
    """
    from branchpy.omega.cache_validator import validate_omega_cache

    project_root = (
        Path(args.project_root).resolve()
        if getattr(args, "project_root", None)
        else Path.cwd().resolve()
    )
    metrics_path = _resolve_metrics_path(project_root)
    val = validate_omega_cache(metrics_path)

    if val.exit_code == 2:
        print(f"[bpy] Error: {val.message}", file=sys.stderr)
        print(
            "[bpy] Calibration batch aborted: valid Omega metrics cache required.",
            file=sys.stderr,
        )
        return 2

    if val.exit_code == 1:
        print(f"[bpy] Warning: {val.message}", file=sys.stderr)

    print(
        f"[bpy] Omega cache validated ({val.status}). "
        "Calibration batch ready (promotion-only mode)."
    )
    return val.exit_code
