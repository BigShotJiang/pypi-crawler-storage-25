"""
CLI Command: bpy semantics

Full semantic analysis using SemanticsV2Engine.

This command runs the complete semantic analysis pipeline:
- Parse project scripts into AST
- Build per-label and global CFGs
- Extract and propagate effects
- Build semantic dependency graph
- Detect deep nesting anti-patterns
- Generate comprehensive report

Usage:
    bpy semantics <project_path> [options]

Examples:
    # Analyze project with default settings
    bpy semantics game/

    # Export to custom location with summary format
    bpy semantics game/ --output analysis.json --format summary

    # Adjust nesting threshold and disable transitive tracking
    bpy semantics game/ --nesting-threshold 5 --no-transitive

    # Minimal output for CI/CD
    bpy semantics game/ --format minimal --quiet
"""

import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


def add_parser(subparsers):
    """Add 'semantics' subcommand to CLI parser"""
    parser = subparsers.add_parser(
        "semantics",
        help="Run full semantic analysis on project",
        description="Complete semantic analysis pipeline with CFG, effects, and graph analysis",
    )

    # Positional arguments
    parser.add_argument(
        "project", type=str, help="Path to project root (containing game/ folder)"
    )

    # Output options
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=".branchpy/semantics_analysis.json",
        help="Output file path (default: .branchpy/semantics_analysis.json)",
    )

    parser.add_argument(
        "-f",
        "--format",
        type=str,
        choices=["full", "summary", "minimal"],
        default="full",
        help="Output format: full (all data), summary (high-level), minimal (metrics only)",
    )

    # Analysis options
    parser.add_argument(
        "--nesting-threshold",
        type=int,
        default=3,
        help="Deep nesting detection threshold (default: 3)",
    )

    parser.add_argument(
        "--no-deep-nesting", action="store_true", help="Disable deep nesting detection"
    )

    parser.add_argument(
        "--no-transitive",
        action="store_true",
        help="Disable transitive media reference tracking",
    )

    parser.add_argument(
        "--max-depth",
        type=int,
        default=20,
        help="Maximum call depth for effect propagation (default: 20)",
    )

    # Report content options
    parser.add_argument(
        "--include-ast",
        action="store_true",
        help="Include raw AST in output (increases file size)",
    )

    parser.add_argument(
        "--no-cfg", action="store_true", help="Exclude CFG details from output"
    )

    parser.add_argument(
        "--no-effects", action="store_true", help="Exclude effect details from output"
    )

    parser.add_argument(
        "--no-semantic-graph",
        action="store_true",
        help="Exclude semantic graph from output",
    )

    # Display options
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Suppress console output (except errors)",
    )

    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )

    # Governance
    parser.add_argument(
        "--governance-id", type=str, help="Custom governance ID for tracking"
    )

    parser.set_defaults(func=run)


def run(args) -> int:
    """Execute semantics command"""
    try:
        from branchpy.semantics_v2.engine import (
            OutputFormat,
            SemanticsV2Config,
            SemanticsV2Engine,
        )
    except ImportError as e:
        print(f"[ERROR] Failed to import SemanticsV2Engine: {e}", file=sys.stderr)
        print("[ERROR] Ensure BranchPy is properly installed", file=sys.stderr)
        return 1

    # Configure logging
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    elif args.quiet:
        logging.basicConfig(level=logging.ERROR)
    else:
        logging.basicConfig(level=logging.INFO)

    # Parse project path
    project_path = Path(args.project).resolve()

    if not project_path.exists():
        print(f"[ERROR] Project path does not exist: {project_path}", file=sys.stderr)
        return 1

    if not args.quiet:
        print(f"[bpy semantics] Analyzing project: {project_path}")

    # Build configuration
    output_format_map = {
        "full": OutputFormat.FULL,
        "summary": OutputFormat.SUMMARY,
        "minimal": OutputFormat.MINIMAL,
    }

    config = SemanticsV2Config(
        nesting_threshold=args.nesting_threshold,
        detect_deep_nesting=not args.no_deep_nesting,
        detect_transitive_media=not args.no_transitive,
        max_propagation_depth=args.max_depth,
        output_format=output_format_map[args.format],
        include_ast=args.include_ast,
        include_cfg=not args.no_cfg,
        include_effects=not args.no_effects,
        include_semantic_graph=not args.no_semantic_graph,
        governance_id=args.governance_id,
    )

    # Create engine and run analysis
    try:
        if not args.quiet:
            print("[bpy semantics] Initializing engine...")

        engine = SemanticsV2Engine(config=config)

        if not args.quiet:
            print("[bpy semantics] Running analysis pipeline...")

        result = engine.analyze(project_path)

        # Check for errors
        if result.errors:
            print(
                f"\n[WARNING] Analysis completed with {len(result.errors)} errors:",
                file=sys.stderr,
            )
            for error in result.errors[:5]:  # Show first 5
                print(f"  - {error}", file=sys.stderr)
            if len(result.errors) > 5:
                print(f"  ... and {len(result.errors) - 5} more", file=sys.stderr)

        # Display summary
        if not args.quiet:
            print("\n[bpy semantics] Analysis complete!")
            print(f"  Files analyzed:    {result.file_count}")
            print(f"  Labels found:      {result.label_count}")
            print(f"  Analysis time:     {result.analysis_time:.2f}s")

            if result.metrics:
                print("\n  Key Metrics:")
                print(
                    f"    Total CFG nodes:        {result.metrics.get('total_cfg_nodes', 0)}"
                )
                print(
                    f"    Total CFG edges:        {result.metrics.get('total_cfg_edges', 0)}"
                )
                print(
                    f"    Max call depth:         {result.metrics.get('max_call_depth', 0)}"
                )
                print(
                    f"    Cyclomatic complexity:  {result.metrics.get('cyclomatic_complexity', 0)}"
                )
                print(
                    f"    Total effects:          {result.metrics.get('total_effects', 0)}"
                )
                print(
                    f"    Deep nesting patterns:  {result.metrics.get('deep_nesting_patterns', 0)}"
                )
                print(
                    f"    Max nesting depth:      {result.metrics.get('max_nesting_depth', 0)}"
                )

        # Export to file
        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)

        result.to_json(output_path, format=config.output_format)

        if not args.quiet:
            print(f"\n[bpy semantics] Report exported to: {output_path}")
            print(f"  Format: {args.format}")
            print(f"  Size: {output_path.stat().st_size / 1024:.1f} KB")

        # Return non-zero if there were errors
        return 1 if result.errors else 0

    except FileNotFoundError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        return 1
    except Exception as e:
        logger.exception("Semantic analysis failed")
        print(f"[ERROR] Analysis failed: {e}", file=sys.stderr)
        return 1
