# branchpy/commands/watch_cmd.py
import os
import subprocess
import sys
from pathlib import Path

from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.emit import emit_watch_run
from branchpy.project_resolver import resolve_project
from branchpy.watcher import FileWatcher


def run(args):
    """
    Watch for file changes and automatically re-run BranchPy commands.
    """
    try:
        project_root = Path(resolve_project(args.project)).resolve()
    except Exception as e:
        print(f"Error resolving project: {e}")
        return 1

    print(f"[BranchPy Watch] Monitoring project: {project_root}")
    print(f"[BranchPy Watch] Command: {args.cmd}")
    print(f"[BranchPy Watch] Debounce: {args.debounce}ms")
    print("[BranchPy Watch] Press Ctrl+C to stop")
    print()

    # Set up file watcher
    patterns = ["**/*.rpy", ".branchpy.toml"]
    if args.cmd in ["media", "media-missing"]:
        patterns.extend(["assets/**", "game/**"])

    watcher = FileWatcher(project_root, patterns, args.debounce)
    watcher.start()

    try:
        while True:
            # Wait for file changes
            changed_file = watcher.get_next_change(timeout=1.0)
            if changed_file:
                relative_path = os.path.relpath(changed_file, project_root)
                print(f"[BranchPy Watch] File changed: {relative_path}")

                # Run the specified command
                exit_code = run_command(args.cmd, project_root)

                # Emit event if requested
                if args.emit_notify:
                    emit_watch_run(
                        args.cmd, exit_code, relative_path, str(project_root)
                    )

                print(f"[BranchPy Watch] Command completed with exit code: {exit_code}")
                print()

    except KeyboardInterrupt:
        print("\n[BranchPy Watch] Stopping...")
    finally:
        watcher.stop()

    return 0


def run_command(cmd: str, project_root: Path) -> int:
    """Run a BranchPy command and return its exit code."""
    try:
        # Build the command - --project must come BEFORE the subcommand
        command_args = [
            sys.executable,
            "-m",
            "branchpy",
            "--project",
            str(project_root),
            cmd,
        ]

        # Run the command
        result = subprocess.run(
            command_args,
            cwd=project_root,
            capture_output=False,  # Let output go to terminal
            timeout=300,  # 5 minute timeout
        )

        return result.returncode

    except subprocess.TimeoutExpired:
        print(f"[BranchPy Watch] Command '{cmd}' timed out after 5 minutes")
        return 124  # Timeout exit code
    except Exception as e:
        print(f"[BranchPy Watch] Error running command '{cmd}': {e}")
        return 1


def add_parser(subparsers):
    """Register the watch command with the CLI parser."""
    watch_p = subparsers.add_parser(
        "watch",
        help="Watch for file changes and auto-run commands",
        description="Monitor project files for changes and automatically re-run BranchPy commands.",
        epilog=fmt_examples(
            "branchpy watch --project .",
            "branchpy watch --cmd tests --debounce 500",
            "branchpy watch --cmd media-missing --emit-notify",
        ),
        formatter_class=HelpFmt,
    )
    watch_p.set_defaults(handler=run)
    watch_p.add_argument(
        "--project",
        default=".",
        help="Project directory to watch (default: current directory)",
    )
    watch_p.add_argument(
        "--debounce",
        type=int,
        default=300,
        help="Debounce delay in milliseconds (default: 300)",
    )
    watch_p.add_argument(
        "--cmd",
        default="checks",
        choices=["tests", "stats", "media-missing", "checks", "doctor"],
        help="Command to run when files change (default: checks)",
    )
    watch_p.add_argument(
        "--emit-notify", action="store_true", help="Emit events for VS Code integration"
    )
