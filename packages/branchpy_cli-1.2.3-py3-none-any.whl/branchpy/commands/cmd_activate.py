import argparse
import sys

# Import normalization (Axis5 v0.9.1)
from branchpy.license_manager import activate_offline


def build(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("key", help="License key (e.g., BRP-XXXX-XXXX-XXXX)")
    parser.add_argument("--email", help="Owner email (optional)", default=None)


def run(args: argparse.Namespace) -> int:
    try:
        info = activate_offline(args.key, args.email)
        print("✅ BranchPy license activated.")
        print(f"Tier: {info.tier}")
        if info.offline_until:
            from datetime import datetime

            print(
                "Offline grace until:",
                datetime.utcfromtimestamp(info.offline_until).isoformat() + "Z",
            )
        return 0
    except Exception as e:
        print(f"❌ Activation failed: {e}", file=sys.stderr)
        return 2
