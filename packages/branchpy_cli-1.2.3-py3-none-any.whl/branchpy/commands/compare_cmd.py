from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from branchpy.attribution import maybe_show_attribution_notice
from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.core.diffing import diff_reports
from branchpy.core.reports import load_report, load_report_with_path

# License gating (v1.0.0)
from branchpy.license.gating import require_feature_cli
from branchpy.obs import end_operation, start_operation
from branchpy.project_resolver import resolve_project


def format_text_output(diff: dict, source_a: str, source_b: str) -> str:
    """Format diff as human-readable text."""
    lines = []

    # Header
    lines.append(f"=== BranchPy: Compare ({source_a} vs {source_b}) ===")

    # Labels summary
    labels = diff["labels"]
    lines.append(
        f"Labels: +{len(labels['added'])}, -{len(labels['removed'])}, ~{len(labels['modified'])}"
    )

    if labels["added"]:
        for label in labels["added"]:
            lines.append(f"  + {label}")

    if labels["removed"]:
        for label in labels["removed"]:
            lines.append(f"  - {label}")

    # Jumps summary
    jumps = diff["jumps"]
    lines.append("")
    lines.append(
        f"Jumps: +{len(jumps['added'])}, -{len(jumps['removed'])}, ~{len(jumps['modified'])}"
    )

    for jump in jumps["added"]:
        lines.append(f"  + {jump.get('src', '?')} -> {jump.get('dst', '?')}")

    for jump in jumps["removed"]:
        lines.append(f"  - {jump.get('src', '?')} -> {jump.get('dst', '?')}")

    for jump in jumps["modified"]:
        lines.append(f"  ~ {jump.get('src', '?')} -> {jump.get('dst', '?')}")

    # Issues summary
    issues = diff["issues"]
    lines.append("")
    lines.append(
        f"Issues: +{len(issues['added'])}, -{len(issues['removed'])}, ~{len(issues['persisting'])}"
    )

    for issue in issues["added"]:
        file_path = issue.get("path", issue.get("file", "?"))
        line = issue.get("line", 0)
        kind = issue.get("kind", "?")
        value = issue.get("value", issue.get("label", ""))
        lines.append(f"  + {kind:15} {file_path}:{line} -> '{value}'")

    for issue in issues["removed"]:
        file_path = issue.get("path", issue.get("file", "?"))
        line = issue.get("line", 0)
        kind = issue.get("kind", "?")
        value = issue.get("value", issue.get("label", ""))
        lines.append(f"  - {kind:15} {file_path}:{line} -> '{value}'")

    # Summary
    lines.append("")
    if diff["summary"]["changed"]:
        lines.append("Summary: DIFFERENCES FOUND")
    else:
        lines.append("Summary: NO DIFFERENCES")

    return "\n".join(lines)


def run(
    a: str,
    b: str,
    project: str | None = None,
    format_type: str = "text",
    save: bool = False,
    out: str | None = None,
    bqf_compare: bool = False,
    policy_mode: str = "off",
    policy_config: str | None = None,
    engine: str | None = None,
    remote_debug: bool = False,
) -> int:
    """
    Compare two reports and output differences.

    Args:
        a: Source A (last/last-1/N/file path)
        b: Source B (last/last-1/N/file path)
        project: Project path for resolving last/last-N sources
        format_type: "text" or "json"
        save: Whether to save output to file
        out: Output file path (overrides save parameter)
        bqf_compare: Enable BQF policy enforcement for compare (WS-B1)
        policy_mode: BQF enforcement mode - "off", "warn", "strict", "ci"
        policy_config: Path to BQF policy configuration (YAML/TOML)
        engine: WS-C1 - Override detected engine ("renpy", "unity", "godot", "generic")
        remote_debug: WS-C1 - Display remote context and engine detection info

    Returns:
        0: identical reports (or policy passed in CI mode)
        1: error occurred
        2: differences found
        65: policy violation (BQF)
        66: remote error (BQF)
        67: partial analysis (BQF)
    """
    # WS-C1: Display remote/engine context if debug enabled
    if remote_debug:
        try:
            from branchpy.core.engine_resolver import EngineResolver
            from branchpy.core.remote_context import RemoteContext

            remote_ctx = RemoteContext.detect()
            print(f"[Remote Context] Type: {remote_ctx.type.value}", file=sys.stderr)
            print(
                f"[Remote Context] Is Remote: {remote_ctx.is_remote}", file=sys.stderr
            )
            print(f"[Remote Context] Is CI: {remote_ctx.is_ci}", file=sys.stderr)
            print(f"[Remote Context] Session: {remote_ctx.session_id}", file=sys.stderr)

            engine_ctx = EngineResolver().detect()
            print(
                f"[Engine Detection] Type: {engine_ctx.engine_type.value}",
                file=sys.stderr,
            )
            print(
                f"[Engine Detection] Confidence: {engine_ctx.confidence:.2f}",
                file=sys.stderr,
            )
            if engine_ctx.version:
                print(
                    f"[Engine Detection] Version: {engine_ctx.version}", file=sys.stderr
                )
            print(file=sys.stderr)
        except Exception as e:
            print(f"[WS-C1] Context detection error: {e}\n", file=sys.stderr)

    op_id = start_operation("compare.run", {"a": a, "b": b, "project": project})

    try:
        # Resolve project path if needed for relative sources
        resolved_project = None
        if project:
            resolved_project = resolve_project(project)
            if not resolved_project:
                print(f"Error: Could not resolve project: {project}", file=sys.stderr)
                end_operation(
                    op_id,
                    "compare.run",
                    status="error",
                    meta={"error": "project resolution failed"},
                )
                return 1

        # Load reports — capture resolved paths for source identity embedding (M-18)
        try:
            report_a, path_a = load_report_with_path(a, resolved_project)
        except Exception as e:
            print(f"Error loading report A '{a}': {e}", file=sys.stderr)
            end_operation(
                op_id,
                "compare.run",
                status="error",
                meta={"error": f"load A failed: {e}"},
            )
            return 1

        try:
            report_b, path_b = load_report_with_path(b, resolved_project)
        except Exception as e:
            print(f"Error loading report B '{b}': {e}", file=sys.stderr)
            end_operation(
                op_id,
                "compare.run",
                status="error",
                meta={"error": f"load B failed: {e}"},
            )
            return 1

        # Generate diff
        diff = diff_reports(report_a, report_b)

        # (M-18) Embed source identity so the panel can display meaningful labels.
        import os as _os

        diff["_source"] = {
            "a": {
                "ref": a,
                "path": path_a,
                "filename": _os.path.basename(path_a),
            },
            "b": {
                "ref": b,
                "path": path_b,
                "filename": _os.path.basename(path_b),
            },
        }

        # BQF Policy Enforcement (WS-B1)
        bqf_exit_code = None
        if bqf_compare and policy_mode != "off":
            try:
                from branchpy.bqf.policy_base import PolicyContext
                from branchpy.bqf.policy_enforcer import (
                    BQFPolicyEnforcer,
                    apply_policy_config,
                    load_policy_config,
                )
                from branchpy.bqf.registry import get_global_registry

                # Load policy configuration if provided
                registry = None
                if policy_config:
                    config = load_policy_config(Path(policy_config))
                    registry = apply_policy_config(config)

                # Create enforcer
                enforcer = BQFPolicyEnforcer(
                    mode=policy_mode if policy_mode != "off" else "warn",
                    registry=registry,
                )

                # Create policy context
                ctx = PolicyContext(
                    inputs={
                        "report_a": report_a,
                        "report_b": report_b,
                        "diff": diff,
                    },
                    governance_id=None,  # Optional: could extract from diff metadata
                )

                # Enforce policies
                result = enforcer.enforce(module="compare", ctx=ctx)
                bqf_exit_code = result.exit_code

                # Print BQF summary
                if result.exit_code != 0:
                    print(
                        f"\n[BQF] Policy Enforcement: {result.policies_failed} failed, {result.policies_warned} warned",
                        file=sys.stderr,
                    )
                    print(f"[BQF] Exit Code: {result.exit_code}", file=sys.stderr)

            except ImportError:
                print(
                    "[BQF] Warning: BQF policy enforcer not available", file=sys.stderr
                )
            except Exception as e:
                print(f"[BQF] Policy enforcement error: {e}", file=sys.stderr)

        # Determine output destination
        output_text = None
        if format_type == "json":
            output_text = json.dumps(diff, indent=2, ensure_ascii=False)
        else:
            output_text = format_text_output(diff, a, b)

        # Handle output (save to file or print to stdout)
        if out or save:
            # Determine output path
            output_path = out
            if output_path is None:
                # Default to .branchpy/compare/
                if resolved_project:
                    project_root = Path(resolved_project)
                else:
                    project_root = Path.cwd()

                compare_dir = project_root / ".branchpy" / "compare"
                compare_dir.mkdir(parents=True, exist_ok=True)
                timestamp = time.strftime("%Y%m%d-%H%M%S")
                ext = "json" if format_type == "json" else "txt"
                output_path = str(compare_dir / f"compare-{timestamp}.{ext}")
            # If output path is relative, put it in .branchpy/compare/
            elif not Path(output_path).is_absolute():
                if resolved_project:
                    project_root = Path(resolved_project)
                else:
                    project_root = Path.cwd()

                compare_dir = project_root / ".branchpy" / "compare"
                compare_dir.mkdir(parents=True, exist_ok=True)
                output_path = str(compare_dir / Path(output_path).name)

            # Write to file
            Path(output_path).write_text(output_text, encoding="utf-8")
            print(f"Comparison saved to: {output_path}", file=sys.stderr)
        else:
            # Print to stdout
            print(output_text)

        # Determine exit code
        # BQF exit code takes precedence if set
        if bqf_exit_code is not None and bqf_exit_code != 0:
            end_operation(
                op_id,
                "compare.run",
                status="bqf_violation",
                meta={"bqf_exit_code": bqf_exit_code},
            )
            maybe_show_attribution_notice("compare")
            return bqf_exit_code

        if diff["summary"]["changed"]:
            end_operation(
                op_id,
                "compare.run",
                status="diff",
                meta={
                    "added": diff["summary"]["added"],
                    "removed": diff["summary"]["removed"],
                    "modified": diff["summary"]["modified"],
                },
            )
            maybe_show_attribution_notice("compare")
            return 2
        else:
            end_operation(op_id, "compare.run", status="ok", meta={"identical": True})
            maybe_show_attribution_notice("compare")
            return 0

    except Exception as e:
        print(f"Compare failed: {e}", file=sys.stderr)
        end_operation(op_id, "compare.run", status="error", meta={"error": str(e)})
        return 1


def cmd_compare(args: argparse.Namespace) -> int:
    """Handle compare command from CLI."""
    # LIC-CLI-8: Compare requires Ren'Py Free+ tier
    project = getattr(args, "project", None)
    project_path = Path(project).resolve() if project else None
    require_feature_cli("compare", "Compare Report Analysis", project_path)

    return run(
        a=args.a,
        b=args.b,
        project=getattr(args, "project", None),
        format_type=getattr(args, "format", "text"),
        save=getattr(args, "save", False),
        out=getattr(args, "out", None),
        bqf_compare=getattr(args, "bqf_compare", False),
        policy_mode=getattr(args, "policy_mode", "off"),
        policy_config=getattr(args, "policy_config", None),
        engine=getattr(args, "engine", None),
        remote_debug=getattr(args, "remote_debug", False),
    )


def add_parser(subparsers) -> None:
    """Register the compare command with the CLI parser."""
    p = subparsers.add_parser(
        "compare",
        help="Compare two analyzer reports.",
        description=(
            "Diff two analyzer snapshots and print clear changes. "
            "Sources can be saved report references (last, last-1, N) or file paths."
        ),
        epilog=fmt_examples(
            "branchpy compare --a last --b last-1",
            "branchpy compare --a last --b last-1 --format json",
            "branchpy compare --a path/to/reportA.json --b path/to/reportB.json",
            "branchpy --project mygame compare --a last --b last-2",
            "branchpy compare --a 0 --b 1 --format json",
        ),
        formatter_class=HelpFmt,
    )

    p.add_argument(
        "--a",
        required=True,
        metavar="SOURCE",
        help="Source A: last/last-N/N or file path",
    )
    p.add_argument(
        "--b",
        required=True,
        metavar="SOURCE",
        help="Source B: last/last-N/N or file path",
    )
    p.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    p.add_argument(
        "--save", action="store_true", help="Save output to file in .branchpy/compare/"
    )
    p.add_argument("--out", metavar="PATH", help="Save output to specific file path")

    # BQF Policy Enforcement (WS-B1)
    p.add_argument(
        "--bqf-compare",
        action="store_true",
        help="Enable BQF policy enforcement for compare analysis",
    )
    p.add_argument(
        "--policy-mode",
        choices=["off", "warn", "strict", "ci"],
        default="off",
        help="BQF enforcement mode: off (disabled), warn (log only), strict (fail on any violation), ci (fail on errors only)",
    )
    p.add_argument(
        "--policy-config",
        type=str,
        metavar="PATH",
        help="Path to BQF policy configuration file (YAML/TOML)",
    )

    # WS-C1: Remote & Engine Context
    p.add_argument(
        "--engine",
        choices=["renpy", "unity", "godot", "generic"],
        default=None,
        help="Override detected game engine (WS-C1)",
    )
    p.add_argument(
        "--remote-debug",
        action="store_true",
        help="Display remote context and engine detection info (WS-C1)",
    )

    p.set_defaults(handler=cmd_compare)
