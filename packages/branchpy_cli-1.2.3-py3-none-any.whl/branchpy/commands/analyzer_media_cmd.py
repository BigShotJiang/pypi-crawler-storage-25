"""
Analyzer Media Command — Phase C v0.9.8

Ticket: WP-26
Module: branchpy.commands.analyzer_media_cmd
Version: v0.9.8

Modern media analysis command using Phase C adapter system.
Replaces old regex-based media.py with ScriptGraph + PFI integration.

Usage:
    branchpy analyzer media --referenced --json
    branchpy analyzer media --referenced --wrapper show_sprite:0:image --json
    branchpy analyzer media --missing
    branchpy analyzer media --engine renpy
"""

import json
import re
import sys
from pathlib import Path
from typing import List, Optional, Tuple

from branchpy.analyze.media_adapters import detect_engine, get_phase_c_adapter


def _parse_wrapper_spec(spec: str) -> Optional[Tuple[str, int, str]]:
    """
    Parse a wrapper spec string in the form ``function:arg_index:kind``.

    Returns:
        (function_name, arg_index, kind) on success, None on parse error.
    """
    parts = spec.split(":")
    if len(parts) != 3:
        print(
            f"Warning: --wrapper '{spec}' ignored (expected function:arg_index:kind)",
            file=sys.stderr,
        )
        return None
    fn_name, arg_index_str, kind = parts[0].strip(), parts[1].strip(), parts[2].strip()
    if not fn_name:
        print(f"Warning: --wrapper '{spec}' ignored (empty function name)", file=sys.stderr)
        return None
    try:
        arg_index = int(arg_index_str)
    except ValueError:
        print(
            f"Warning: --wrapper '{spec}' ignored (arg_index '{arg_index_str}' is not an integer)",
            file=sys.stderr,
        )
        return None
    if arg_index < 0:
        print(f"Warning: --wrapper '{spec}' ignored (arg_index must be >= 0)", file=sys.stderr)
        return None
    return (fn_name, arg_index, kind.lower() or "unknown")


def _scan_wrappers(
    project_path: Path,
    wrappers: List[Tuple[str, int, str]],
    existing_tags: set,
) -> Tuple[List[dict], List[str]]:
    """
    Scan ``.rpy`` files under *project_path* for calls to guidance-defined
    wrapper functions and extract string-literal arguments at the configured
    arg_index.

    Returns:
        (new_entries, warnings) — new_entries are Phase-C-style dicts ready
        to be appended to ``result['files']``.  Only string literals are
        extracted; variable references are skipped.  Tags already present in
        *existing_tags* are deduplicated.
    """
    rpy_files = list(project_path.rglob("*.rpy"))
    new_entries: List[dict] = []
    warnings: List[str] = []
    seen_tags: set = set(existing_tags)

    for fn_name, arg_index, kind in wrappers:
        # Match: fn_name(   ...args...   )
        # We capture the full argument list and split on commas (naïve, handles
        # simple cases; nested-call args are unusual in Ren'Py).
        call_pattern = re.compile(
            r'\b' + re.escape(fn_name) + r'\s*\(([^)]*)\)',
            re.MULTILINE,
        )
        found: List[dict] = []
        for rpy_file in rpy_files:
            try:
                text = rpy_file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for match in call_pattern.finditer(text):
                args_str = match.group(1)
                # Split on commas; trim whitespace
                raw_args = [a.strip() for a in args_str.split(",")]
                if arg_index >= len(raw_args):
                    continue
                raw_val = raw_args[arg_index]
                # Only accept string literals: "value" or 'value'
                str_match = re.fullmatch(r'["\']([^"\']*)["\']', raw_val)
                if not str_match:
                    continue
                tag = str_match.group(1)
                if not tag or tag in seen_tags:
                    continue
                seen_tags.add(tag)
                # Derive relative path for used_by
                try:
                    rel = rpy_file.relative_to(project_path).as_posix()
                except ValueError:
                    rel = rpy_file.name
                found.append({
                    "tag": tag,
                    "kind": kind,
                    "exists": None,
                    "resolved_files": [],
                    "used_by": [{"file": rel, "line": None, "context": f"{fn_name}(...)"}],
                    "extra": {
                        "source": "guidance_wrapper",
                        "function": fn_name,
                        "arg_index": arg_index,
                    },
                })
        if found:
            new_entries.extend(found)
        else:
            warnings.append(
                f"Guidance wrapper '{fn_name}' (arg_index={arg_index}, kind={kind}): "
                f"no string-literal calls found in {len(rpy_files)} .rpy file(s)."
            )

    return new_entries, warnings


def cmd_analyzer_media_referenced(
    project_root: str,
    engine: Optional[str] = None,
    as_json: bool = False,
    wrapper_specs: Optional[List[str]] = None,
) -> int:
    """
    Extract referenced media using Phase C adapters.

    Args:
        project_root: Path to project root
        engine: Engine name (auto-detected if None)
        as_json: Output JSON format
        wrapper_specs: List of ``function:arg_index:kind`` strings from
            ``--wrapper`` flags (project_guidance.json ``media_wrappers``).

    Returns:
        Exit code (0 = success)
    """
    project_path = Path(project_root).resolve()

    # Auto-detect engine if not specified
    if engine is None:
        engine = detect_engine(project_path) or "generic"

    # Get appropriate Phase C adapter — pass project_path as required by media_adapters v0.9.7+
    try:
        adapter = get_phase_c_adapter(engine, project_path)
    except Exception as e:
        print(
            f"Error: Failed to create extractor for engine '{engine}': {e}",
            file=sys.stderr,
        )
        return 1

    # Run Phase C collection
    try:
        phase_c_result = adapter.collect_phase_c(project_path)

        # ── Guidance wrapper scan (additive) ──────────────────────────────────
        parsed_wrappers: List[Tuple[str, int, str]] = []
        if wrapper_specs:
            for spec in wrapper_specs:
                parsed = _parse_wrapper_spec(spec)
                if parsed:
                    parsed_wrappers.append(parsed)

        if parsed_wrappers:
            result_dict = phase_c_result.to_json_dict()
            existing_tags = {f.get("tag", "") for f in result_dict.get("files", [])}
            wrapper_entries, wrapper_warnings = _scan_wrappers(
                project_path, parsed_wrappers, existing_tags
            )
            result_dict["files"].extend(wrapper_entries)
            result_dict["warnings"].extend(wrapper_warnings)
            if wrapper_entries:
                result_dict["warnings"].append(
                    f"Guidance wrappers: added {len(wrapper_entries)} tag(s) from "
                    f"{len(parsed_wrappers)} wrapper rule(s)."
                )
            if as_json:
                print(json.dumps(result_dict, indent=2, ensure_ascii=False))
            else:
                _print_human_readable(phase_c_result, wrapper_entries)
            return 0

        if as_json:
            print(
                json.dumps(phase_c_result.to_json_dict(), indent=2, ensure_ascii=False)
            )
        else:
            _print_human_readable(phase_c_result, [])

        return 0

    except Exception as e:
        print(f"Error: Media extraction failed: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


def _print_human_readable(phase_c_result, extra_entries: List[dict]) -> None:
    """Print Phase C results in human-readable form."""
    files = phase_c_result.files
    print(f"Referenced Media: {len(files) + len(extra_entries)} tags")
    for record in files:
        kind = (
            record.kind.value
            if hasattr(record.kind, "value")
            else str(record.kind)
        )
        exists = "✓" if record.exists else ("✗" if record.exists is False else "?")
        print(f"  {exists} [{kind:5}] {record.tag}")
    for entry in extra_entries:
        print(f"  ? [{entry['kind']:5}] {entry['tag']}  [guidance_wrapper: {entry['extra']['function']}]")
    for warning in phase_c_result.warnings:
        print(f"  WARNING: {warning}", file=sys.stderr)


def add_parser(subparsers):
    """
    Register analyzer media command with CLI.

    Args:
        subparsers: Argparse subparsers object
    """
    # Create 'analyzer' parent command
    analyzer_parser = subparsers.add_parser(
        "analyzer",
        help="Advanced analyzer commands (Phase C+)",
        description="Modern analyzer commands using ScriptGraph + PFI",
    )
    analyzer_subs = analyzer_parser.add_subparsers(
        dest="analyzer_command", required=True
    )

    # Add 'media' subcommand
    media_parser = analyzer_subs.add_parser(
        "media",
        help="Media analysis using Phase C adapters",
        description="Extract and validate media references using engine-specific adapters",
    )

    # Subcommand flags
    media_parser.add_argument(
        "--referenced", action="store_true", help="List all referenced media files"
    )
    media_parser.add_argument(
        "--missing",
        action="store_true",
        help="List missing media files (not yet implemented)",
    )

    # Options
    media_parser.add_argument(
        "--engine",
        choices=["renpy", "unity", "godot", "generic"],
        help="Override engine auto-detection",
    )
    media_parser.add_argument(
        "--json", action="store_true", help="Output in JSON format"
    )
    media_parser.add_argument(
        "--wrapper",
        action="append",
        dest="wrappers",
        metavar="FUNCTION:ARG_INDEX:KIND",
        default=[],
        help=(
            "Guidance-defined wrapper function to include in reference scan. "
            "Format: function_name:arg_index:kind  (e.g. show_sprite:0:image). "
            "Can be repeated for multiple wrappers."
        ),
    )

    # Handler
    def media_handler(args):
        if args.referenced:
            return cmd_analyzer_media_referenced(
                project_root=args.project,
                engine=args.engine,
                as_json=args.json,
                wrapper_specs=args.wrappers or [],
            )
        elif args.missing:
            print(
                "Error: --missing not yet implemented (use 'branchpy media --missing')",
                file=sys.stderr,
            )
            return 1
        else:
            print("Error: Specify --referenced or --missing", file=sys.stderr)
            return 1

    media_parser.set_defaults(handler=media_handler)


def run(args):
    """
    CLI entry point for analyzer command.

    Args:
        args: Parsed arguments

    Returns:
        Exit code
    """
    # The handler was already set by add_parser, just call it
    if hasattr(args, "handler"):
        return args.handler(args)
    else:
        print("Error: No handler found for analyzer command", file=sys.stderr)
        return 1


if __name__ == "__main__":
    # Standalone test
    import sys

    sys.exit(cmd_analyzer_media_referenced(".", as_json=True))
