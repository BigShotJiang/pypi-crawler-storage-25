"""
CLI Command: branchpy validate images

Advanced image validation using perceptual hashing and clustering
"""

from pathlib import Path

from branchpy.core.governance.standard_command_enforcement import standard_command

from ..analysis.image_validation import ImageValidator
from ..core.governance.guards import require_capability


def add_parser(subparsers):
    """Add 'validate' subcommand to CLI parser"""
    parser = subparsers.add_parser(
        "validate", help="Advanced validation tools (images, assets, etc.)"
    )

    validate_subparsers = parser.add_subparsers(
        dest="validate_command", help="Validation type"
    )

    # branchpy validate images
    images_parser = validate_subparsers.add_parser(
        "images", help="Validate images using perceptual hashing and clustering"
    )

    images_parser.add_argument(
        "--project-dir",
        type=str,
        default=".",
        help="Project directory (default: current directory)",
    )

    images_parser.add_argument(
        "--backend",
        type=str,
        choices=["phash", "clip"],
        default="phash",
        help="Hashing backend (default: phash)",
    )

    images_parser.add_argument(
        "--engine",
        type=str,
        choices=["renpy", "unity", "godot", "unreal", "generic"],
        default="renpy",
        help="Game engine type (default: renpy). Determines default image directories.",
    )

    images_parser.add_argument(
        "--images-dir",
        type=str,
        help="Custom images directory (overrides engine defaults). Can be relative or absolute path.",
    )

    images_parser.add_argument(
        "--fast", action="store_true", help="Use fast mode (lower quality, 5× faster)"
    )

    images_parser.add_argument(
        "--refresh-cache", action="store_true", help="Force re-scan (ignore cache)"
    )

    images_parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable feature caching (slower but uses less disk)",
    )

    images_parser.add_argument(
        "--auto-adopt",
        action="store_true",
        help="Automatically select canonical versions",
    )

    images_parser.add_argument(
        "--similarity-threshold",
        type=float,
        default=0.85,
        help="Similarity threshold for clustering (0-1, default: 0.85)",
    )

    images_parser.add_argument(
        "--output",
        type=str,
        help="Output report path (default: .branchpy/reports/image_validation.json)",
    )

    images_parser.add_argument(
        "--semantic",
        action="store_true",
        help="Enable semantic auto-tagging (characters, scenes, locations) - requires CLIP backend",
    )

    images_parser.add_argument(
        "--semantic-threshold",
        type=float,
        default=0.75,
        help="Semantic similarity threshold (0-1, default: 0.75)",
    )

    images_parser.add_argument(
        "--semantic-output",
        type=str,
        help="Semantic report path (default: .branchpy/reports/semantic_audit.html)",
    )


def run(args):
    """Execute validate command"""
    if args.validate_command == "images":
        return _run_images(args)
    else:
        print("Error: No validation type specified. Use 'branchpy validate images'")
        return 1


@standard_command(
    name="validation.images", capability="image.validation.run", export_audit=True
)
def _run_images(args):
    """Run image validation (wrapped by standard_command_enforcement)."""

    project_dir = Path(args.project_dir).resolve()

    if not project_dir.exists():
        print(f"❌ Error: Project directory not found: {project_dir}")
        return 1

    # Check cache capability if cache operations requested
    if not args.no_cache and args.refresh_cache:
        try:
            require_capability("image.validation.cache")
        except Exception:
            print(
                "\n⚠️  Warning: Cache management requires 'image.validation.cache' capability"
            )
            print("   Continuing without cache refresh...")
            args.refresh_cache = False

    # Check semantic capability if semantic analysis requested
    if args.semantic:
        try:
            require_capability("image.validation.semantic")
        except Exception:
            print(
                "\n⚠️  Warning: Semantic analysis requires 'image.validation.semantic' capability"
            )
            print("   Continuing without semantic tagging...")
            args.semantic = False

    # Default output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = project_dir / ".branchpy" / "reports" / "image_validation.json"

    try:
        # Resolve images_dir if provided
        images_dir = None
        if args.images_dir:
            images_dir = Path(args.images_dir)
            if not images_dir.is_absolute():
                images_dir = project_dir / images_dir

        # Create validator
        validator = ImageValidator(
            project_dir=project_dir,
            backend=args.backend,
            fast_mode=args.fast,
            similarity_threshold=args.similarity_threshold,
            use_cache=not args.no_cache,
            engine=args.engine,
            images_dir=images_dir,
        )

        # Run validation
        report = validator.validate(
            refresh_cache=args.refresh_cache, auto_adopt=args.auto_adopt
        )

        # Export report
        validator.export_report(output_path)

        # Clean up
        validator.close()

        # Print summary
        print("\n" + "=" * 60)
        print("IMAGE VALIDATION SUMMARY")
        print("=" * 60)
        print(f"Total images:        {report.total_images}")
        print(f"Indexed images:      {report.indexed_images}")
        print(f"Similarity clusters: {report.clusters_detected}")
        print(f"Exact duplicates:    {report.duplicates}")
        print("=" * 60)

        if report.clusters:
            print("\nTop clusters:")
            for idx, cluster in enumerate(report.clusters[:5], 1):
                canonical = cluster.canonical or cluster.members[0]
                print(
                    f"  {idx}. {len(cluster.members)} images (canonical: {canonical})"
                )
                print(f"     Similarity: {cluster.avg_similarity:.1%}")

        print(f"\n📄 Full report: {output_path}")

        return 0

    except Exception as e:
        print(f"\n❌ Validation failed: {e}")
        import traceback

        traceback.print_exc()
        return 1
