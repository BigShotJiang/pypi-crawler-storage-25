"""
branchpy/commands/flowchart_cmd.py

Generate a standalone flowchart HTML from the project story structure.

Reads the unified report produced by `branchpy analyze --format json`.
If no unified report exists, runs analyze automatically to produce one.

Usage:
    branchpy --project path/to/project flowchart --open
    branchpy --project path/to/project flowchart --html
    branchpy --project path/to/project flowchart --out report.html

The default output path is .branchpy/reports/flowchart-<timestamp>.html.
"""

from __future__ import annotations

import contextlib
import io
import json
import sys
from pathlib import Path

from branchpy.cli_help import HelpFmt, fmt_examples


def _load_unified_report(project_root: Path) -> dict | None:
    """Read the unified report written by analyze --format json."""
    unified_path = (
        project_root / ".branchpy" / "reports" / "unified" / "unified_report.json"
    )
    if not unified_path.exists():
        return None
    try:
        return json.loads(unified_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[bpy] Warning: Could not read unified report: {e}", file=sys.stderr)
        return None


def _run_analyze(project_root: Path) -> bool:
    """
    Run analyze with --format json to produce the unified report as a side effect.
    Suppresses JSON stdout output; progress messages on stderr are preserved.
    Returns True if the unified report exists after the run.
    """
    from branchpy.commands.analyze_cmd import main as analyze_main

    unified_path = (
        project_root / ".branchpy" / "reports" / "unified" / "unified_report.json"
    )

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            analyze_main([str(project_root), "--format=json", "--out=-"])
        except SystemExit:
            pass
        except Exception as e:
            print(f"[bpy] Analyze failed: {e}", file=sys.stderr)

    return unified_path.exists()


def run(args) -> int:
    """Entry point for `branchpy flowchart`."""
    from branchpy.cli.html_report import (
        announce_html_report,
        generate_flowchart_html,
        open_in_browser,
        resolve_html_output_path,
    )

    project_root = Path(args.project).resolve()
    no_auto_recompute = getattr(args, "no_auto_recompute", False)

    # Phase 5: Use content-revision freshness check, not mere existence check
    from branchpy.artifact_freshness import check_artifact_freshness

    analyze_status = check_artifact_freshness(project_root, "analyze")
    unified_data = None

    if analyze_status.exists and analyze_status.fresh:
        unified_data = _load_unified_report(project_root)
        if unified_data is not None:
            print("  \u2713  analyze   (cached \u2013 project unchanged)")

    if unified_data is None:
        if no_auto_recompute:
            _reason = "missing" if analyze_status.missing else "stale"
            print(
                f"[bpy] Error: Analysis data is {_reason}. "
                f"Run: branchpy analyze --format json",
                file=sys.stderr,
            )
            return 1
        _reason_str = (
            "source files changed \u2013 recomputing\u2026"
            if analyze_status.stale
            else "first-time run\u2026"
        )
        print(f"  \u21bb  analyze   ({_reason_str})")
        ok = _run_analyze(project_root)
        if not ok:
            print(
                f"[bpy] Error: Could not generate analysis data. "
                f"Run 'branchpy --project {project_root} analyze --format json' "
                "manually and check for errors.",
                file=sys.stderr,
            )
            return 1
        unified_data = _load_unified_report(project_root)
        if unified_data is None:
            print(
                "[bpy] Error: Analyze completed but unified report was not written.",
                file=sys.stderr,
            )
            return 1

    out_path = resolve_html_output_path(project_root, "flowchart", args.out)

    try:
        html_path = generate_flowchart_html(unified_data, project_root, out_path)
    except Exception as e:
        print(f"[bpy] Error generating flowchart HTML: {e}", file=sys.stderr)
        return 1

    announce_html_report("flowchart", html_path)

    if getattr(args, "open_browser", False):
        print("[bpy] Opening interactive graph in browser...", file=sys.stderr)
        open_in_browser(html_path)

    return 0


def add_parser(subparsers):
    """Register the flowchart command with the CLI parser."""
    p = subparsers.add_parser(
        "flowchart",
        help="Generate a standalone flowchart HTML from the project story structure.",
        description=(
            "Renders the project story flowchart as a self-contained HTML page "
            "with an interactive Cytoscape.js graph. Reads analysis data produced "
            "by the analyze command; runs analyze automatically if needed."
        ),
        epilog=fmt_examples(
            "branchpy --project /path/to/project flowchart --open",
            "branchpy --project /path/to/project flowchart --html",
            "branchpy --project /path/to/project flowchart --out flowchart.html --open",
        ),
        formatter_class=HelpFmt,
    )

    p.set_defaults(handler=run)

    p.add_argument(
        "--out",
        type=str,
        default="",
        metavar="PATH",
        help="Output path for the HTML file (default: .branchpy/reports/flowchart-<ts>.html)",
    )
    p.add_argument(
        "--html",
        action="store_true",
        help="Generate the HTML artifact (default when --open is not specified).",
    )
    p.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Generate and open the flowchart HTML in the default browser.",
    )
    p.add_argument(
        "--no-auto-recompute",
        dest="no_auto_recompute",
        action="store_true",
        help="Do not automatically re-run analyze if its output is missing or stale.",
    )
