def add_parser(subparsers):
    parser = subparsers.add_parser(
        "help", help="Show help and list all available commands."
    )
    parser.add_argument("topic", nargs="?", help="Command to get help for.")
    parser.set_defaults(handler=lambda args: run(getattr(args, "topic", None)))


import importlib

# branchpy/commands/help_cmd.py
from typing import List, Optional


# Lazy accessor to avoid CLI import cycle (cli imports help_cmd for registry)
def _get_command_names() -> List[str]:
    try:
        cli_mod = importlib.import_module("branchpy.cli")
        return getattr(cli_mod, "get_command_names", lambda: [])()
    except Exception:
        return []


# Command descriptions mapping
COMMAND_DESCRIPTIONS = {
    "activate": "Activate a commercial license",
    "analyze": "Run static analysis on a project",
    "compare": "On-demand diffs between two refs (scriptable, automation-friendly)",
    "config": "View and manage project configuration",
    "deactivate": "Deactivate license (seat transfer/cleanup)",
    "dev": "Developer tools and utilities",
    "doctor": "Diagnose project issues",
    "guard": "Project guard and validation checks",
    "help": "Show help and list available commands",
    "l10n": "Localization tools",
    "logs": "View and manage logs",
    "media": "Media asset management (missing/unused)",
    "migrate": "Migrate project data or configuration",
    "patches": "Patch state and history management",
    "pilot": "Visual timeline with checkpoints and test history (History Lanes)",
    "projects": "Manage multiple projects",
    "redo": "Redo changes (patch management)",
    "renpy": "Ren'Py SDK management",
    "report": "Generate and manage reports",
    "semantics": "Semantic analysis and validation",
    "serve": "Start the local dashboard server",
    "stats": "Variable consistency and flag validation",
    "stats2": "Legacy alias for pilot command",
    "status": "Show license status",
    "support": "Gather support information",
    "test": "Run tests (alias)",
    "tests": "Scan for structural issues (jumps, calls, orphans)",
    "undo": "Undo changes (patch management)",
    "watch": "Watch for file changes",
    "ws": "WebSocket daemon management",
}

# Detailed help templates for commands
COMPARE_HELP = """\
Usage: branchpy compare [OPTIONS]

On-demand diff tool for BranchPy projects.

Compare lets you run quick, scriptable diffs between two refs
(branches, commits, checkpoints) and optionally enrich them with
test results and media-awareness.

Examples:
  branchpy compare --from main --to feature/new-route
  branchpy compare --from main --to feature/new-assets --media
  branchpy compare --from main --to feature/new-tests --tests

Compare vs History Lanes:
  - Compare is a CLI command: think "git diff with superpowers".
  - History Lanes is a visual timeline in VS Code that shows
    curated lanes, checkpoints, tests, and media changes over time.
"""

PILOT_HELP = """\
Usage: branchpy pilot [OPTIONS]

History Lanes (formerly "Pilot Lanes") provide a visual timeline of
your project in the BranchPy VS Code extension.

Use History Lanes when you want to:
  - Navigate checkpoints and branches visually
  - See test status and media changes per lane
  - Jump from lanes into Compare to inspect diffs in detail

Use Compare when you want:
  - A one-off diff between two refs in the CLI
  - JSON output for tooling and CI pipelines
"""

# Command examples mapping
COMMAND_EXAMPLES = {
    "activate": "branchpy activate --key YOUR_LICENSE_KEY",
    "analyze": "branchpy analyze --deep",
    "compare": "branchpy compare --from main --to feature/new-route --media",
    "config": "branchpy config show",
    "deactivate": "branchpy deactivate",
    "dev": "branchpy dev --help",
    "doctor": "branchpy doctor",
    "guard": "branchpy guard run",
    "help": "branchpy help <command>",
    "l10n": "branchpy l10n --help",
    "logs": "branchpy logs --tail 50",
    "media": "branchpy media --missing",
    "migrate": "branchpy migrate --help",
    "patches": "branchpy patches --list",
    "pilot": "branchpy pilot (opens History Lanes in VS Code)",
    "projects": "branchpy projects list",
    "redo": "branchpy redo",
    "renpy": "branchpy renpy --help",
    "report": "branchpy report --format html",
    "semantics": "branchpy semantics --help",
    "serve": "branchpy serve",
    "stats": "branchpy stats --format json",
    "stats2": "branchpy stats2 (use pilot instead)",
    "status": "branchpy status",
    "support": "branchpy support",
    "test": "branchpy test",
    "tests": "branchpy tests --save-report",
    "undo": "branchpy undo",
    "watch": "branchpy watch",
    "ws": "branchpy ws --help",
}


def run(topic: Optional[str] = None) -> int:

    try:
        if topic:
            # Check for detailed help templates
            if topic == "compare":
                print(COMPARE_HELP)
                return 0
            elif topic == "pilot":
                print(PILOT_HELP)
                return 0
            else:
                print(
                    f"To get help for a specific command, run: branchpy {{command}} --help\nExample: branchpy {topic} --help"
                )
        else:
            print("BranchPy helper — available commands\n")
            print("Usage:")
            print("  branchpy <command> [options]\n")
            print(
                "To get help for a specific command, run: branchpy {command} --help\nExample: branchpy compare --help\n"
            )

            cmds = _get_command_names()
            print("Commands:")

            # Calculate max lengths for alignment
            max_cmd_len = max(len(c) for c in cmds) if cmds else 0
            max_desc_len = (
                max(len(COMMAND_DESCRIPTIONS.get(c, "")) for c in cmds) if cmds else 0
            )

            for c in cmds:
                desc = COMMAND_DESCRIPTIONS.get(c, "")
                example = COMMAND_EXAMPLES.get(c, "")
                print(f"  {c:<{max_cmd_len}}  {desc:<{max_desc_len}}  {example}")
        return 0
    except Exception as e:
        print(f"[BranchPy Help] Unexpected error: {e}")
        return 0
