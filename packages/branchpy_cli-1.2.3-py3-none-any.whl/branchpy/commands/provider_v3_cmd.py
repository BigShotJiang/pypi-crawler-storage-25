"""
Provider Management CLI Commands (Image Validation V3 - Phase 2)

Commands:
- provider list - List all registered providers
- provider health [--provider <id>] - Check provider health
- provider add <provider_id> - Add and configure provider credentials
- provider remove <provider_id> - Remove provider credentials
- provider rotate [--provider <id>] - Rotate encryption keys
- provider thumbnails rebuild --provider <id> - Rebuild thumbnails
"""

from __future__ import annotations

import getpass
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def add_parser(subparsers):
    """Add 'provider' subcommand to CLI parser"""
    parser = subparsers.add_parser(
        "provider-v3", help="Manage cloud providers (Image Validation V3)"
    )

    provider_subparsers = parser.add_subparsers(dest="provider_action")

    # list
    list_parser = provider_subparsers.add_parser(
        "list", help="List all registered providers"
    )
    list_parser.add_argument("--vault-path", type=str, help="Path to credential vault")

    # health
    health_parser = provider_subparsers.add_parser(
        "health", help="Check provider health and connectivity"
    )
    health_parser.add_argument(
        "--provider", type=str, help="Specific provider ID (check all if omitted)"
    )
    health_parser.add_argument(
        "--vault-path", type=str, help="Path to credential vault"
    )

    # add
    add_parser = provider_subparsers.add_parser("add", help="Add provider credentials")
    add_parser.add_argument(
        "provider_id",
        type=str,
        help="Provider ID (onedrive, gdrive, dropbox, webdav, github, mfiles)",
    )
    add_parser.add_argument("--vault-path", type=str, help="Path to credential vault")

    # remove
    remove_parser = provider_subparsers.add_parser(
        "remove", help="Remove provider credentials"
    )
    remove_parser.add_argument("provider_id", type=str, help="Provider ID")
    remove_parser.add_argument(
        "--vault-path", type=str, help="Path to credential vault"
    )

    # rotate
    rotate_parser = provider_subparsers.add_parser(
        "rotate", help="Rotate credential encryption keys"
    )
    rotate_parser.add_argument(
        "--provider", type=str, help="Specific provider ID (all if omitted)"
    )
    rotate_parser.add_argument(
        "--vault-path", type=str, help="Path to credential vault"
    )
    rotate_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate rotation without making changes",
    )

    # thumbnails
    thumbnails_parser = provider_subparsers.add_parser(
        "thumbnails", help="Manage remote thumbnails"
    )
    thumbnails_parser.add_argument(
        "action", choices=["rebuild"], help="Thumbnail action"
    )
    thumbnails_parser.add_argument(
        "--provider", type=str, required=True, help="Provider ID"
    )
    thumbnails_parser.add_argument(
        "--force", action="store_true", help="Force regeneration of all thumbnails"
    )
    thumbnails_parser.add_argument(
        "--vault-path", type=str, help="Path to credential vault"
    )


def run(args):
    """Execute provider command"""

    # Default vault path
    vault_path = (
        Path(args.vault_path)
        if args.vault_path
        else Path.home() / ".branchpy" / "vault.json"
    )

    action = args.provider_action

    if action == "list":
        return _cmd_list(args, vault_path)

    elif action == "health":
        return _cmd_health(args, vault_path)

    elif action == "add":
        return _cmd_add(args, vault_path)

    elif action == "remove":
        return _cmd_remove(args, vault_path)

    elif action == "rotate":
        return _cmd_rotate(args, vault_path)

    elif action == "thumbnails":
        return _cmd_thumbnails(args, vault_path)

    else:
        print("❌ Error: Unknown provider action")
        print("   Run: branchpy provider-v3 --help")
        return 1


def _cmd_list(args, vault_path: Path) -> int:
    """List all registered providers"""
    from ..analysis.image_validation.providers_v2 import (
        CredentialVault,
        ProviderRegistry,
    )

    print("\n" + "=" * 70)
    print(" IMAGE VALIDATION V3 - CLOUD PROVIDERS")
    print("=" * 70 + "\n")

    # List registered providers
    provider_ids = ProviderRegistry.list_provider_ids()

    if not provider_ids:
        print("No providers registered.")
        return 0

    # Load vault to check credential status
    try:
        vault = CredentialVault(vault_path, auto_create=False)
        vault_providers = vault.list_providers()
    except Exception:
        vault_providers = []

    for provider_id in sorted(provider_ids):
        info = ProviderRegistry.get_provider_info(provider_id)
        has_creds = provider_id in vault_providers

        status = "✓ Configured" if has_creds else "○ Not Configured"

        print(f"  [{provider_id:12s}] {info['display_name']}")
        print(f"    Status: {status}")
        print(f"    Delta Support: {'Yes' if info.get('supports_delta') else 'No'}")
        print()

    print("=" * 70)
    print(f"Total providers: {len(provider_ids)}")
    print(f"Configured: {len(vault_providers)}")
    print("=" * 70 + "\n")

    return 0


def _cmd_health(args, vault_path: Path) -> int:
    """Check provider health"""
    from ..analysis.image_validation.governance_logger import ImageValidationLogger
    from ..analysis.image_validation.providers_v2 import (
        CredentialVault,
        ProviderContext,
        get_provider,
    )

    print("\n" + "=" * 70)
    print(" PROVIDER HEALTH CHECK")
    print("=" * 70 + "\n")

    # Load vault
    try:
        vault = CredentialVault(vault_path, auto_create=False)
    except Exception as e:
        print(f"❌ Error: Cannot load vault: {e}")
        return 1

    # Determine which providers to check
    if args.provider:
        provider_ids = [args.provider]
    else:
        provider_ids = vault.list_providers()

    if not provider_ids:
        print("No providers configured.")
        return 0

    # Initialize governance logger
    gov_logger = ImageValidationLogger(Path.cwd())

    # Check each provider
    for provider_id in provider_ids:
        print(f"[{provider_id}] Checking...", end=" ", flush=True)

        start_time = time.time()

        try:
            # Get credentials
            credentials = vault.get_credentials(provider_id)
            if not credentials:
                print("❌ No credentials")
                continue

            # Create context
            context = ProviderContext(provider_id=provider_id, credentials=credentials)

            # Get provider and connect
            provider = get_provider(provider_id, context)

            # Health check
            health = provider.health_check()

            duration_ms = (time.time() - start_time) * 1000

            # Log health check
            gov_logger.log_provider_health_check(
                provider_id,
                health.status.value,
                health.latency_ms,
                health.quota_used,
                health.quota_total,
            )

            # Display result
            if health.is_healthy():
                print(f"✓ Healthy (latency: {health.latency_ms:.0f}ms)")

                if health.quota_used and health.quota_total:
                    quota_pct = health.quota_percentage()
                    print(f"    Quota: {quota_pct:.1f}% used")
            else:
                print(f"❌ {health.status.value}")
                if health.message:
                    print(f"    {health.message}")

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            print(f"❌ Error: {e}")

            gov_logger.log_provider_connect_error(
                provider_id, type(e).__name__, str(e), duration_ms
            )

    gov_logger.flush()

    print("\n" + "=" * 70 + "\n")

    return 0


def _cmd_add(args, vault_path: Path) -> int:
    """Add provider credentials"""
    from ..analysis.image_validation.providers_v2 import CredentialVault

    provider_id = args.provider_id

    print(f"\n{'='*70}")
    print(f" CONFIGURE PROVIDER: {provider_id}")
    print(f"{'='*70}\n")

    # Collect credentials interactively
    credentials = _collect_credentials(provider_id)

    if not credentials:
        print("\n❌ Credential collection cancelled.")
        return 1

    # Store in vault
    try:
        vault = CredentialVault(vault_path, auto_create=True)
        vault.store_credentials(provider_id, credentials)

        print(f"\n✓ Credentials stored successfully for {provider_id}")
        print(f"  Vault: {vault_path}")
        print(f"  Provider count: {len(vault.list_providers())}")
        print(f"\n{'='*70}\n")

        return 0

    except Exception as e:
        print(f"\n❌ Error: Failed to store credentials: {e}")
        return 1


def _cmd_remove(args, vault_path: Path) -> int:
    """Remove provider credentials"""
    from ..analysis.image_validation.providers_v2 import CredentialVault

    provider_id = args.provider_id

    try:
        vault = CredentialVault(vault_path, auto_create=False)

        if vault.remove_credentials(provider_id):
            print(f"✓ Removed credentials for {provider_id}")
            return 0
        else:
            print(f"❌ Provider '{provider_id}' not found in vault")
            return 1

    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def _cmd_rotate(args, vault_path: Path) -> int:
    """Rotate credential encryption keys"""
    from ..analysis.image_validation.governance_logger import ImageValidationLogger
    from ..analysis.image_validation.providers_v2 import CredentialVault

    # Handle dry-run mode
    if args.dry_run:
        print(f"\n{'='*70}")
        print(" CREDENTIAL KEY ROTATION - DRY RUN")
        print(f"{'='*70}\n")

        # Initialize governance logger
        gov_logger = ImageValidationLogger(Path.cwd())
        start_time = time.time()

        try:
            vault = CredentialVault(vault_path, auto_create=False)
            report = vault.rotate_key_dry_run()

            duration_ms = (time.time() - start_time) * 1000

            # Log dry-run governance event
            gov_logger.log_provider_credential_rotate_dry_run(
                provider_count=report["provider_count"],
                duration_ms=duration_ms,
                status=report["status"],
                errors=report.get("errors", []),
            )
            gov_logger.flush()

            # Display report
            print(f"Vault Path: {report['vault_path']}")
            print(f"Created: {report['created_at']}")
            print(f"Last Rotated: {report['last_rotated_at']}")
            print(f"Provider Count: {report['provider_count']}")
            print(f"\nStatus: {report['status'].upper()}")
            print(f"Recommendation: {report['recommendation']}")

            if report.get("estimated_duration_ms"):
                print(f"Estimated Duration: {report['estimated_duration_ms']:.0f}ms")

            print("\nProviders to be rotated:")
            for provider_info in report["providers"]:
                status_icon = "✓" if provider_info["can_decrypt"] else "✗"
                print(f"  {status_icon} {provider_info['provider_id']}")
                if provider_info.get("error"):
                    print(f"    Error: {provider_info['error']}")

            if report["errors"]:
                print(f"\n⚠ {len(report['errors'])} error(s) detected:")
                for error in report["errors"]:
                    print(f"  - {error['provider_id']}: {error['error']}")

            print("\nOperations that would be performed:")
            for operation in report["operations"]:
                print(f"  {operation}")

            print(f"\n{'='*70}\n")

            return 0 if report["status"] == "would_succeed" else 1

        except Exception as e:
            print(f"\n❌ Error during dry run: {e}")
            return 1

    # Normal rotation (interactive confirmation required)
    print(f"\n{'='*70}")
    print(" CREDENTIAL KEY ROTATION")
    print(f"{'='*70}\n")

    print("⚠ WARNING: This will re-encrypt all provider credentials.")
    print("  A backup will be created automatically.")
    print()

    confirm = input("Continue? (yes/no): ").strip().lower()

    if confirm != "yes":
        print("\n❌ Rotation cancelled.")
        return 0

    # Initialize governance logger
    gov_logger = ImageValidationLogger(Path.cwd())
    gov_logger.log_provider_credential_rotate_start(args.provider)

    start_time = time.time()

    try:
        vault = CredentialVault(vault_path, auto_create=False)

        # Optional: prompt for new password
        print("\nEnter new master password (or press Enter to auto-generate):")
        new_password = getpass.getpass("New password: ").strip()

        if not new_password:
            new_password = None  # Will auto-generate

        # Rotate
        vault.rotate_key(new_password)

        duration_ms = (time.time() - start_time) * 1000
        provider_count = len(vault.list_providers())

        gov_logger.log_provider_credential_rotate_complete(
            provider_count, duration_ms, args.provider
        )
        gov_logger.flush()

        print("\n✓ Key rotation complete")
        print(f"  Duration: {duration_ms:.0f}ms")
        print(f"  Providers re-encrypted: {provider_count}")
        print(f"\n{'='*70}\n")

        return 0

    except Exception as e:
        duration_ms = (time.time() - start_time) * 1000

        gov_logger.log_provider_credential_rotate_error(
            str(e), duration_ms, args.provider
        )
        gov_logger.flush()

        print(f"\n❌ Error: Key rotation failed: {e}")
        print("  Vault should be restored from backup.")
        return 1


def _cmd_thumbnails(args, vault_path: Path) -> int:
    """Manage thumbnails"""
    # TODO: Implement thumbnail rebuild
    print("❌ Error: Thumbnail management not yet implemented")
    return 1


def _collect_credentials(provider_id: str) -> Optional[dict]:
    """Collect credentials interactively"""

    if provider_id == "onedrive":
        print("Microsoft OneDrive requires OAuth2 credentials.\n")
        print("You need:")
        print("  1. client_id (from Azure App Registration)")
        print("  2. client_secret")
        print("  3. refresh_token (from OAuth2 flow)")
        print()

        client_id = input("Client ID: ").strip()
        client_secret = getpass.getpass("Client Secret: ").strip()
        refresh_token = input("Refresh Token: ").strip()
        tenant_id = input("Tenant ID [common]: ").strip() or "common"

        return {
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token,
            "tenant_id": tenant_id,
        }

    elif provider_id == "gdrive":
        print("Google Drive requires OAuth2 credentials.\n")

        client_id = input("Client ID: ").strip()
        client_secret = getpass.getpass("Client Secret: ").strip()
        refresh_token = input("Refresh Token: ").strip()

        return {
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token,
        }

    elif provider_id == "dropbox":
        print("Dropbox requires OAuth2 credentials.\n")

        access_token = getpass.getpass("Access Token: ").strip()
        refresh_token = input("Refresh Token (optional): ").strip()
        client_id = input("Client ID (for refresh): ").strip()
        client_secret = getpass.getpass("Client Secret (for refresh): ").strip()

        creds = {"access_token": access_token}

        if refresh_token and client_id and client_secret:
            creds.update(
                {
                    "refresh_token": refresh_token,
                    "client_id": client_id,
                    "client_secret": client_secret,
                }
            )

        return creds

    elif provider_id == "webdav":
        print("WebDAV configuration:\n")

        url = input("WebDAV URL: ").strip()
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ").strip()

        return {"url": url, "username": username, "password": password}

    elif provider_id == "github":
        print("GitHub configuration:\n")

        token = getpass.getpass("Personal Access Token: ").strip()
        repository = input("Repository (owner/repo): ").strip()
        branch = input("Branch [main]: ").strip() or "main"

        return {"token": token, "repository": repository, "branch": branch}

    elif provider_id == "mfiles":
        print("M-Files configuration:\n")
        print("⚠ Note: M-Files provider is not yet fully implemented.\n")

        url = input("M-Files Server URL: ").strip()
        vault_guid = input("Vault GUID: ").strip()
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ").strip()

        return {
            "url": url,
            "vault_guid": vault_guid,
            "username": username,
            "password": password,
        }

    else:
        print(f"❌ Error: Unknown provider '{provider_id}'")
        return None
