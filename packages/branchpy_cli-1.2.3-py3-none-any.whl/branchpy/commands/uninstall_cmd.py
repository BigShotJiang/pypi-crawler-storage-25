# branchpy/commands/uninstall_cmd.py
"""Remove BranchPy CLI, VS Code extension, and optional local data."""
import os
import shutil
import subprocess
import sys
from urllib.parse import urlencode

_EXTENSION_ID = "branchpy.branchpy"
_LOCAL_DATA_DIR = os.path.join(os.environ.get("APPDATA", ""), "BranchPy")
_FEEDBACK_BASE_URL = "https://branchpy.com/feedback"

_FEEDBACK_REASONS = [
    ("1", "Not useful for my current workflow"),
    ("2", "Too hard to set up"),
    ("3", "Too many bugs / instability"),
    ("4", "Missing features I need"),
    ("5", "Just trying it for now"),
    ("6", "Other"),
]

# Follow-up prompts shown after the user picks a specific reason.
# Only reasons where structured detail is useful.
_FOLLOW_UP_PROMPTS = {
    "2": "What part was hardest to set up?",
    "3": "What broke or felt unstable?",
    "4": "What feature did you expect to find?",
}


def _confirm(prompt: str) -> bool:
    """Prompt the user and return True if they confirm (Y/y or empty = yes)."""
    answer = input(prompt).strip()
    return answer == "" or answer.lower().startswith("y")


def _get_installed_version() -> str:
    """Read the installed branchpy version before pip removes it."""
    try:
        from importlib.metadata import version as _pkg_ver  # Python 3.8+

        return _pkg_ver("branchpy")
    except Exception:
        pass
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "show", "branchpy"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        for line in r.stdout.splitlines():
            if line.startswith("Version:"):
                return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return "unknown"


def _prompt_feedback(version: str) -> None:
    """Small, optional exit-prompt shown after removal is complete."""
    print()
    print("Optional: would you like to share why you uninstalled BranchPy?")
    print()
    for key, label in _FEEDBACK_REASONS:
        print(f"  [{key}] {label}")
    print("  [Enter] Skip (no feedback)")
    print()

    valid_keys = {r[0] for r in _FEEDBACK_REASONS}
    choice = input("  > ").strip()

    if not choice or choice not in valid_keys:
        # Skipped — end cleanly, still show the link
        print()
        print("Thanks for trying BranchPy.")
        print()
        print(f"  Share feedback: {_FEEDBACK_BASE_URL}")
        print()
        return

    # Conditional follow-up question
    follow_up_prompt = _FOLLOW_UP_PROMPTS.get(choice, "Anything else to add?")
    print()
    print(f"  {follow_up_prompt} (optional, press Enter to skip)")
    input("  > ")  # Detail is not stored locally — routed to website form

    # Build pre-filled URL so website form can pre-select the reason
    url = f"{_FEEDBACK_BASE_URL}?{urlencode({'source': 'uninstall', 'version': version, 'reason': choice})}"

    print()
    print("Thanks for the feedback.")
    print()
    print(f"  Share more here: {url}")
    print()


def run(args):
    """Interactively remove BranchPy from this machine."""
    print()
    print("BranchPy Uninstall")
    print("==================")
    print()
    print("The following will be removed:")
    print("  1. BranchPy Python package  (pip uninstall branchpy)")
    print(f"  2. VS Code extension        ({_EXTENSION_ID})")
    if os.path.isdir(_LOCAL_DATA_DIR):
        print(f"  3. Local app data           ({_LOCAL_DATA_DIR})  [optional]")
    print()
    print("  Note: Per-project .branchpy/ folders inside your game projects")
    print("        will NOT be touched — you can delete those manually if needed.")
    print()

    if not _confirm("Continue? [Y/n] "):
        print()
        print("Uninstall cancelled.")
        return 0

    # Capture version now — pip will remove it in the next step
    _version = _get_installed_version()

    print()
    exit_code = 0

    # --- 1. pip uninstall -----------------------------------------------------
    print("Removing Python package...")
    pip_ok = False
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "uninstall", "branchpy", "-y"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            print("  OK: branchpy package removed.")
            pip_ok = True
        else:
            stderr_text = result.stderr or ""
            # Windows self-lock: pip cannot move bpy.exe while it is the running process
            if sys.platform == "win32" and (
                "WinError 32" in stderr_text
                or "being used by another process" in stderr_text
            ):
                print("  Could not remove the Python package automatically.")
                print()
                print("  Windows cannot delete a program while it is running.")
                print("  Close this window, then run:")
                print()
                print("      python -m pip uninstall branchpy")
                print()
                print("  That removes the package from outside the locked launcher.")
            else:
                print(f"  Warning: pip exited {result.returncode}")
                if stderr_text:
                    print(f"  {stderr_text.strip()}")
            exit_code = 1
    except Exception as exc:
        print(f"  Error running pip: {exc}")
        exit_code = 1

    # --- 2. VS Code extension -------------------------------------------------
    print()
    print("Removing VS Code extension...")
    code_cmd = shutil.which("code") or shutil.which("code.cmd")
    if code_cmd:
        try:
            result = subprocess.run(
                [code_cmd, "--uninstall-extension", _EXTENSION_ID],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print(f"  OK: {_EXTENSION_ID} extension removed.")
                print("  Reload VS Code to apply the change.")
            else:
                print(f"  Warning: extension uninstall exited {result.returncode}")
                if result.stderr:
                    print(f"  {result.stderr.strip()}")
        except Exception as exc:
            print(f"  Error running VS Code CLI: {exc}")
    else:
        print("  VS Code CLI ('code') not found in PATH.")
        print(
            "  Uninstall the extension manually via VS Code → Extensions → BranchPy → Uninstall."
        )

    # --- 3. Optional local data -----------------------------------------------
    if os.path.isdir(_LOCAL_DATA_DIR):
        print()
        print(f"Local app data found: {_LOCAL_DATA_DIR}")
        if _confirm("Remove local data (logs, cache, settings)? [Y/n] "):
            try:
                shutil.rmtree(_LOCAL_DATA_DIR)
                print("  OK: local data removed.")
            except Exception as exc:
                print(f"  Error removing {_LOCAL_DATA_DIR}: {exc}")
                exit_code = 1
        else:
            print("  Kept.")

    # --- Done -----------------------------------------------------------------
    print()
    if exit_code == 0:
        print("BranchPy has been removed.")
        print("No data was left behind unless you chose to keep it.")
        # Feedback prompt — only shown on full success
        _prompt_feedback(_version)
    else:
        print("Partial uninstall — not everything was removed successfully.")
        if not pip_ok:
            print("  ✘ Python package:  NOT removed (see instructions above)")
        else:
            print("  ✓ Python package:  removed")
        print("  Refer to the messages above for details.")

    return exit_code


def add_parser(subparsers):
    """Register the uninstall command with the CLI parser."""
    p = subparsers.add_parser(
        "uninstall",
        help="Remove BranchPy CLI, VS Code extension, and optional local data",
        description=(
            "Interactively remove BranchPy from this machine.\n\n"
            "Removes the Python package, VS Code extension, and optionally\n"
            "the local app data folder. Per-project .branchpy/ folders are\n"
            "not touched."
        ),
    )
    p.set_defaults(handler=run)
