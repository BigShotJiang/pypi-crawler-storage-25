"""
Audit Log Commands for BranchPy v0.8.1

Provides:
- audit verify: Verify audit log integrity
- audit replay: Display audit history
- audit tail: Tail audit log

Part of v0.8.1 (BPY-812 - CLI Commands)
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


# Lazy import to avoid circular dependencies
def _get_audit_modules():
    """Lazy import audit modules"""
    from branchpy.core.audit import (
        AuditContext,
        Auditor,
        IdentityResolver,
        get_user_role,
        has_capability,
    )

    return Auditor, AuditContext, IdentityResolver, get_user_role, has_capability


def add_parser(subparsers):
    """Add audit command parser (BranchPy convention)"""
    parser = subparsers.add_parser(
        "audit",
        help="Manage and verify audit logs",
        description="Verify, replay, and manage team audit logs",
    )

    # Create subcommands
    audit_subparsers = parser.add_subparsers(
        dest="audit_command", help="Audit subcommands"
    )

    # audit verify
    verify_parser = audit_subparsers.add_parser(
        "verify",
        help="Verify audit log integrity",
        description="Verify hash chain and detect tampering (requires auditor/owner role)",
    )

    # audit replay
    replay_parser = audit_subparsers.add_parser(
        "replay",
        help="Replay audit history",
        description="Display audit log entries with optional filtering",
    )
    replay_parser.add_argument("--user", type=str, help="Filter by user UUID")
    replay_parser.add_argument("--action", type=str, help="Filter by action name")
    replay_parser.add_argument(
        "--limit", type=int, default=50, help="Maximum entries to display (default: 50)"
    )

    # audit tail
    tail_parser = audit_subparsers.add_parser(
        "tail", help="Tail audit log", description="Display recent audit log entries"
    )
    tail_parser.add_argument(
        "-n",
        "--lines",
        type=int,
        default=10,
        help="Number of entries to show (default: 10)",
    )

    # audit sink (subcommand group)
    sink_parser = audit_subparsers.add_parser(
        "sink",
        help="Manage audit sinks",
        description="Configure and test remote audit sinks (experimental)",
    )
    sink_subparsers = sink_parser.add_subparsers(
        dest="sink_command", help="Sink subcommands"
    )

    # audit sink list
    sink_list_parser = sink_subparsers.add_parser("list", help="List configured sinks")

    # audit sink test
    sink_test_parser = sink_subparsers.add_parser("test", help="Test sink connectivity")
    sink_test_parser.add_argument(
        "sink_name", type=str, help="Sink name to test (e.g., 'local', 'https', 'git')"
    )

    return parser


def run(args):
    """Run audit command (BranchPy convention)"""
    if not hasattr(args, "audit_command") or args.audit_command is None:
        print(
            "Error: No subcommand specified. Use 'audit verify', 'audit replay', or 'audit tail'"
        )
        return 1

    if args.audit_command == "verify":
        return audit_verify(args)
    elif args.audit_command == "replay":
        return audit_replay(args)
    elif args.audit_command == "tail":
        return audit_tail(args)
    elif args.audit_command == "sink":
        return audit_sink(args)
    else:
        print(f"Error: Unknown audit command: {args.audit_command}")
        return 1


def audit_verify(args):
    """Verify audit log integrity"""
    Auditor, AuditContext, IdentityResolver, get_user_role, has_capability = (
        _get_audit_modules()
    )

    try:
        project_root = Path.cwd()

        # Resolve identity
        resolver = IdentityResolver(project_root)
        identity = resolver.resolve()

        # Check RBAC if team.toml exists
        team_path = project_root / ".branchpy" / "team.toml"
        if team_path.exists():
            role = get_user_role(identity.user.user_uuid, team_path)
            if not has_capability(role, "audit:verify"):
                print(
                    "Error: Permission denied (requires audit:verify capability)",
                    file=sys.stderr,
                )
                print(f"Your role: {role or '(not in team.toml)'}", file=sys.stderr)
                print(
                    "Contact project owner to grant auditor or owner role",
                    file=sys.stderr,
                )
                return 65  # Permission denied exit code

        # Create auditor
        ctx = AuditContext(project_root=project_root, identity=identity)
        auditor = Auditor(ctx)

        # Verify
        report = auditor.verify()

        if report.ok:
            print(f"[OK] Audit log verified: {report.entries} entries, chain OK")
            return 0
        else:
            print("[FAILED] Audit verification FAILED", file=sys.stderr)
            print(f"  Broken at seq: {report.broken_at}", file=sys.stderr)
            print(f"  Reason: {report.reason}", file=sys.stderr)
            return 1

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def audit_replay(args):
    """Replay audit history"""
    Auditor, AuditContext, IdentityResolver, get_user_role, has_capability = (
        _get_audit_modules()
    )

    try:
        project_root = Path.cwd()

        # Resolve identity
        resolver = IdentityResolver(project_root)
        identity = resolver.resolve()

        # Check RBAC if team.toml exists
        team_path = project_root / ".branchpy" / "team.toml"
        if team_path.exists():
            role = get_user_role(identity.user.user_uuid, team_path)
            if not has_capability(role, "audit:replay"):
                print(
                    "Error: Permission denied (requires audit:replay capability)",
                    file=sys.stderr,
                )
                return 65

        # Create auditor
        ctx = AuditContext(project_root=project_root, identity=identity)
        auditor = Auditor(ctx)

        # Replay with filters
        entries = list(
            auditor.replay(
                user=getattr(args, "user", None), action=getattr(args, "action", None)
            )
        )

        # Limit results
        limit = getattr(args, "limit", 50)
        if len(entries) > limit:
            entries = entries[-limit:]

        # Display entries
        if not entries:
            print("No audit entries found")
            return 0

        for entry in entries:
            timestamp = (
                entry.timestamp
                if hasattr(entry, "timestamp")
                else datetime.now(timezone.utc).isoformat()
            )
            print(f"[{entry.seq}] {timestamp}")
            print(f"  User: {entry.user_uuid}")
            print(f"  Action: {entry.action}")
            if entry.args and not entry.args.get("_redacted"):
                print(f"  Args: {json.dumps(entry.args)}")
            print()

        print(f"Total: {len(entries)} entries")
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def audit_tail(args):
    """Tail audit log"""
    try:
        project_root = Path.cwd()
        audit_log = project_root / ".branchpy" / "audit" / "log.jsonl"

        if not audit_log.exists():
            print("No audit log found")
            return 0

        # Read last N lines
        lines_to_show = getattr(args, "lines", 10)

        with open(audit_log, "r", encoding="utf-8") as f:
            lines = f.readlines()

        # Show last N lines
        for line in lines[-lines_to_show:]:
            try:
                entry = json.loads(line)
                timestamp = entry.get("timestamp", "N/A")
                print(f"[{entry.get('seq', '?')}] {timestamp}")
                print(f"  Action: {entry.get('action', 'N/A')}")
                print(f"  User: {entry.get('user_uuid', 'N/A')}")
                print()
            except json.JSONDecodeError:
                continue

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def audit_sink(args):
    """Manage audit sinks"""
    if not hasattr(args, "sink_command") or args.sink_command is None:
        print(
            "Error: No sink subcommand specified. Use 'audit sink list' or 'audit sink test'"
        )
        return 1

    if args.sink_command == "list":
        return sink_list(args)
    elif args.sink_command == "test":
        return sink_test(args)
    else:
        print(f"Error: Unknown sink command: {args.sink_command}")
        return 1


def sink_list(args):
    """List configured sinks"""
    try:
        project_root = Path.cwd()
        sinks_path = project_root / ".branchpy" / "sinks.toml"

        # Always show local sink
        print("Configured sinks:")
        print("  • local (built-in)")

        # Check for remote sinks
        if sinks_path.exists():
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib

            with open(sinks_path, "rb") as f:
                sinks_config = tomllib.load(f)

            for sink_name, sink_config in sinks_config.get("sinks", {}).items():
                sink_type = sink_config.get("type", "unknown")
                enabled = sink_config.get("enabled", False)
                status = "[OK]" if enabled else "[X]"
                print(f"  {status} {sink_name} ({sink_type})")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def sink_test(args):
    """Test sink connectivity"""
    sink_name = args.sink_name

    if sink_name == "local":
        print(f"Testing sink: {sink_name}")
        print("  Type: LocalFileSink")
        print("  Status: [OK] (always available)")
        return 0
    else:
        print(f"Testing sink: {sink_name}")
        print("  Status: [X] Experimental (remote sinks not implemented in v0.8.1)")
        return 1


if __name__ == "__main__":
    # Standalone test
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers()
    add_parser(subparsers)
    args = parser.parse_args()
    sys.exit(run(args))
