"""
History Management CLI Command

Provides undo/redo/show subcommands for interactive history management.

Commands:
    bpy history undo [n]   - Undo last N operations
    bpy history redo [n]   - Redo last N operations
    bpy history show       - Display history stack

Example:
    $ bpy history undo 2
    Undone: AnalyzeProject (correlation_id=uuid-123)
    Undone: ReplaceAsset (correlation_id=uuid-124)

    $ bpy history show --json
    {
        "undo_available": 5,
        "redo_available": 2,
        ...
    }

Version: v0.8.8
"""

# Optional dependency: click
try:
    import click  # type: ignore
except ImportError:
    import sys

    print(
        "❌ CLI features require 'click'. Install with:\n"
        "  pip install 'click>=8.1'\n"
        "or:\n"
        "  pip install -e '.[cli]'",
        file=sys.stderr,
    )
    sys.exit(1)

import json
import logging
import sys
from pathlib import Path
from typing import Optional

from branchpy.core.history import HistoryPersistence

logger = logging.getLogger(__name__)


@click.group(name="history")
@click.option(
    "--project",
    type=click.Path(exists=True),
    default=".",
    help="Project directory (default: current directory)",
)
@click.pass_context
def history_cmd(ctx, project: str):
    """
    History management commands (undo, redo, show).

    Manage reversible operations with full governance tracking.
    """
    ctx.ensure_object(dict)
    ctx.obj["project_path"] = Path(project).resolve()
    ctx.obj["persistence"] = HistoryPersistence(str(ctx.obj["project_path"]))


@history_cmd.command(name="undo")
@click.argument("steps", type=int, default=1)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.option("--emit-notify", is_flag=True, help="Emit notifications for VS Code")
@click.pass_context
def undo_command(ctx, steps: int, json_output: bool, emit_notify: bool):
    """
    Undo the last N operations.

    STEPS: Number of operations to undo (default: 1)

    Example:
        bpy history undo 2
        bpy history undo --json
    """
    persistence = ctx.obj["persistence"]

    # Load history stack
    stack = persistence.load_stack()
    if stack is None or len(stack.undo_stack) == 0:
        if json_output:
            click.echo(json.dumps({"success": False, "error": "No operations to undo"}))
        else:
            click.echo("❌ No operations to undo", err=True)
        sys.exit(1)

    # Validate steps
    if steps < 1:
        if json_output:
            click.echo(json.dumps({"success": False, "error": "Steps must be >= 1"}))
        else:
            click.echo("❌ Steps must be >= 1", err=True)
        sys.exit(1)

    # Perform undo
    try:
        undone_actions = stack.undo(steps=steps)

        # Save updated stack
        persistence.save_stack(stack)

        # Output results
        if json_output:
            result = {
                "success": True,
                "undone_count": len(undone_actions),
                "actions": [a.to_dict() for a in undone_actions],
            }
            click.echo(json.dumps(result, indent=2))
        else:
            for action in undone_actions:
                click.echo(
                    f"⤺ Undone: {action.operation} "
                    f"(correlation_id={action.correlation_id})"
                )
            click.echo(f"\n✅ Successfully undone {len(undone_actions)} operation(s)")

        # Emit notification for VS Code
        if emit_notify:
            for action in undone_actions:
                notify = {
                    "event": "history_undone",
                    "operation": action.operation,
                    "correlation_id": action.correlation_id,
                }
                click.echo(json.dumps(notify), file=sys.stdout)

    except Exception as e:
        logger.error(f"Undo failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Undo failed: {e}", err=True)
        sys.exit(1)


@history_cmd.command(name="redo")
@click.argument("steps", type=int, default=1)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.option("--emit-notify", is_flag=True, help="Emit notifications for VS Code")
@click.pass_context
def redo_command(ctx, steps: int, json_output: bool, emit_notify: bool):
    """
    Redo the last N undone operations.

    STEPS: Number of operations to redo (default: 1)

    Example:
        bpy history redo 2
        bpy history redo --json
    """
    persistence = ctx.obj["persistence"]

    # Load history stack
    stack = persistence.load_stack()
    if stack is None or len(stack.redo_stack) == 0:
        if json_output:
            click.echo(json.dumps({"success": False, "error": "No operations to redo"}))
        else:
            click.echo("❌ No operations to redo", err=True)
        sys.exit(1)

    # Validate steps
    if steps < 1:
        if json_output:
            click.echo(json.dumps({"success": False, "error": "Steps must be >= 1"}))
        else:
            click.echo("❌ Steps must be >= 1", err=True)
        sys.exit(1)

    # Perform redo
    try:
        redone_actions = stack.redo(steps=steps)

        # Save updated stack
        persistence.save_stack(stack)

        # Output results
        if json_output:
            result = {
                "success": True,
                "redone_count": len(redone_actions),
                "actions": [a.to_dict() for a in redone_actions],
            }
            click.echo(json.dumps(result, indent=2))
        else:
            for action in redone_actions:
                click.echo(
                    f"⤼ Redone: {action.operation} "
                    f"(correlation_id={action.correlation_id})"
                )
            click.echo(f"\n✅ Successfully redone {len(redone_actions)} operation(s)")

        # Emit notification for VS Code
        if emit_notify:
            for action in redone_actions:
                notify = {
                    "event": "history_redone",
                    "operation": action.operation,
                    "correlation_id": action.correlation_id,
                }
                click.echo(json.dumps(notify), file=sys.stdout)

    except Exception as e:
        logger.error(f"Redo failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Redo failed: {e}", err=True)
        sys.exit(1)


@history_cmd.command(name="show")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.option("--limit", type=int, default=20, help="Limit number of entries shown")
@click.pass_context
def show_command(ctx, json_output: bool, limit: int):
    """
    Display current history stack state.

    Shows available undo/redo operations with metadata.

    Example:
        bpy history show
        bpy history show --json --limit 10
    """
    persistence = ctx.obj["persistence"]

    # Load history stack
    stack = persistence.load_stack()
    if stack is None:
        if json_output:
            click.echo(
                json.dumps(
                    {
                        "undo_available": 0,
                        "redo_available": 0,
                        "undo_stack": [],
                        "redo_stack": [],
                    }
                )
            )
        else:
            click.echo("📜 No history available")
        return

    # Get stack data
    stack_data = stack.show()

    if json_output:
        # Limit entries in JSON output
        limited_data = {
            "undo_available": stack_data["undo_available"],
            "redo_available": stack_data["redo_available"],
            "capacity": stack_data["capacity"],
            "undo_stack": stack_data["undo_stack"][-limit:],
            "redo_stack": stack_data["redo_stack"][-limit:],
        }
        click.echo(json.dumps(limited_data, indent=2))
    else:
        # Human-readable output
        click.echo("📜 History Stack Status")
        click.echo("=" * 60)
        click.echo(f"Undo available: {stack_data['undo_available']}")
        click.echo(f"Redo available: {stack_data['redo_available']}")
        click.echo(f"Capacity: {stack_data['capacity']}")
        click.echo()

        # Show undo stack (most recent first)
        if stack_data["undo_stack"]:
            click.echo("⤺ Undo Stack (most recent first):")
            for action in reversed(stack_data["undo_stack"][-limit:]):
                click.echo(
                    f"  • {action['operation']} "
                    f"({action['timestamp']}) "
                    f"[{action['correlation_id'][:8]}...]"
                )
            click.echo()

        # Show redo stack (most recent first)
        if stack_data["redo_stack"]:
            click.echo("⤼ Redo Stack (most recent first):")
            for action in reversed(stack_data["redo_stack"][-limit:]):
                click.echo(
                    f"  • {action['operation']} "
                    f"({action['timestamp']}) "
                    f"[{action['correlation_id'][:8]}...]"
                )
            click.echo()


@history_cmd.command(name="clear")
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def clear_command(ctx, force: bool):
    """
    Clear all history (irreversible!).

    Use with caution - this deletes all undo/redo history.

    Example:
        bpy history clear --force
    """
    persistence = ctx.obj["persistence"]

    if not force:
        click.confirm(
            "⚠️  This will delete ALL history. Continue?",
            abort=True,
        )

    try:
        persistence.clear()
        click.echo("✅ History cleared successfully")
    except Exception as e:
        logger.error(f"Clear failed: {e}", exc_info=True)
        click.echo(f"❌ Clear failed: {e}", err=True)
        sys.exit(1)


@history_cmd.command(name="restore")
@click.argument("snapshot_id", type=str)
@click.option("--no-backup", is_flag=True, help="Skip backup snapshot creation")
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def restore_command(
    ctx, snapshot_id: str, no_backup: bool, force: bool, json_output: bool
):
    """
    Restore project to a specific snapshot.

    SNAPSHOT_ID: Snapshot identifier (e.g., snap_20251105_152412_abc123)

    Example:
        bpy history restore snap_20251105_152412_abc123
        bpy history restore snap_001 --no-backup --force
    """
    from branchpy.core.history import Snapshot

    project_path = ctx.obj["project_path"]

    # Confirmation prompt
    if not force:
        click.confirm(
            f"⚠️  Restore project to {snapshot_id}?\n"
            f"Current state will be saved as backup.",
            abort=True,
        )

    try:
        Snapshot.restore(str(project_path), snapshot_id, create_backup=not no_backup)

        if json_output:
            result = {
                "success": True,
                "snapshot_id": snapshot_id,
                "backup_created": not no_backup,
            }
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"✅ Successfully restored to snapshot {snapshot_id}")
            if not no_backup:
                click.echo("💾 Backup snapshot created")

    except Exception as e:
        logger.error(f"Restore failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Restore failed: {e}", err=True)
        sys.exit(1)


@history_cmd.group(name="branch")
@click.pass_context
def branch_cmd(ctx):
    """
    Timeline branch management commands.

    Create experimental branches, switch between timelines,
    and isolate changes without affecting main history.
    """
    pass


@branch_cmd.command(name="create")
@click.argument("name", type=str)
@click.option(
    "--from", "from_snapshot", required=True, help="Snapshot ID to branch from"
)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def branch_create(ctx, name: str, from_snapshot: str, json_output: bool):
    """
    Create a new timeline branch.

    NAME: Branch name (e.g., "experiment_1", "feature_test")

    Example:
        bpy history branch create experiment_1 --from snap_001
    """
    from branchpy.core.history import Timeline

    project_path = ctx.obj["project_path"]

    try:
        timeline = Timeline(str(project_path))
        branch_id = timeline.create_branch(name, from_snapshot)

        if json_output:
            result = {
                "success": True,
                "branch_id": branch_id,
                "branch_name": name,
                "from_snapshot": from_snapshot,
            }
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"✅ Created branch '{name}' ({branch_id})")
            click.echo(f"   From snapshot: {from_snapshot}")

    except Exception as e:
        logger.error(f"Branch creation failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Branch creation failed: {e}", err=True)
        sys.exit(1)


@branch_cmd.command(name="switch")
@click.argument("branch", type=str)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def branch_switch(ctx, branch: str, json_output: bool):
    """
    Switch to a different branch.

    BRANCH: Branch ID or name

    Example:
        bpy history branch switch experiment_1
        bpy history branch switch main
    """
    from branchpy.core.history import Timeline

    project_path = ctx.obj["project_path"]

    try:
        timeline = Timeline(str(project_path))
        timeline.switch_branch(branch)

        if json_output:
            result = {"success": True, "branch": branch}
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"✅ Switched to branch '{branch}'")

    except Exception as e:
        logger.error(f"Branch switch failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Branch switch failed: {e}", err=True)
        sys.exit(1)


@branch_cmd.command(name="list")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def branch_list(ctx, json_output: bool):
    """
    List all timeline branches.

    Example:
        bpy history branch list
        bpy history branch list --json
    """
    from branchpy.core.history import Timeline

    project_path = ctx.obj["project_path"]

    try:
        timeline = Timeline(str(project_path))
        branches = timeline.list_branches()

        if json_output:
            click.echo(json.dumps({"branches": branches}, indent=2))
        else:
            if not branches:
                click.echo("No branches found")
            else:
                click.echo("Timeline Branches:")
                click.echo("=" * 80)
                for b in branches:
                    marker = "→" if b["is_current"] else " "
                    click.echo(
                        f"{marker} {b['name']} ({b['id'][:8]}...)\n"
                        f"   From: {b['from_snapshot']}\n"
                        f"   Created: {b['created_at']}"
                    )
                click.echo("=" * 80)

    except Exception as e:
        logger.error(f"Branch list failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Branch list failed: {e}", err=True)
        sys.exit(1)


@branch_cmd.command(name="delete")
@click.argument("branch", type=str)
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def branch_delete(ctx, branch: str, force: bool, json_output: bool):
    """
    Delete a timeline branch.

    BRANCH: Branch ID or name

    Example:
        bpy history branch delete experiment_1 --force
    """
    from branchpy.core.history import Timeline

    project_path = ctx.obj["project_path"]

    # Confirmation prompt
    if not force:
        click.confirm(
            f"⚠️  Delete branch '{branch}'? This cannot be undone.", abort=True
        )

    try:
        timeline = Timeline(str(project_path))
        timeline.delete_branch(branch, force=True)

        if json_output:
            result = {"success": True, "branch": branch}
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"✅ Deleted branch '{branch}'")

    except Exception as e:
        logger.error(f"Branch deletion failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Branch deletion failed: {e}", err=True)
        sys.exit(1)


@history_cmd.command(name="diff")
@click.argument("snapshot_id_1", type=str)
@click.argument("snapshot_id_2", type=str)
@click.option("--export-html", type=click.Path(), help="Export as HTML")
@click.option("--export-json", type=click.Path(), help="Export as JSON")
@click.option(
    "--json", "json_output", is_flag=True, help="Output diff as JSON to stdout"
)
@click.pass_context
def diff_command(
    ctx, snapshot_id_1: str, snapshot_id_2: str, export_html, export_json, json_output
):
    """
    Compare two snapshots.

    Example:
        bpy history diff snap_001 snap_002
        bpy history diff snap_001 snap_002 --export-html diff.html
        bpy history diff snap_001 snap_002 --export-json diff.json
    """
    from branchpy.core.history import DiffExporter, Snapshot

    project_path = ctx.obj["project_path"]

    try:
        # Compute diff
        diff = Snapshot.diff(str(project_path), snapshot_id_1, snapshot_id_2)

        # Export HTML
        if export_html:
            exporter = DiffExporter()
            exporter.export_html(diff, export_html)
            click.echo(f"✅ Exported HTML diff to {export_html}")

        # Export JSON
        if export_json:
            exporter = DiffExporter()
            exporter.export_json(diff, export_json)
            click.echo(f"✅ Exported JSON diff to {export_json}")

        # Print to stdout
        if json_output:
            click.echo(json.dumps(diff, indent=2))
        elif not export_html and not export_json:
            # Human-readable summary
            summary = diff.get("summary", {})
            click.echo(f"Snapshot Diff: {snapshot_id_1} → {snapshot_id_2}")
            click.echo("=" * 60)
            click.echo(f"Nodes Added:    {summary.get('nodes_added', 0)}")
            click.echo(f"Nodes Removed:  {summary.get('nodes_removed', 0)}")
            click.echo(f"Nodes Modified: {summary.get('nodes_modified', 0)}")
            click.echo(f"Variables Added:   {summary.get('variables_added', 0)}")
            click.echo(f"Variables Removed: {summary.get('variables_removed', 0)}")
            click.echo(f"Assets Changed:    {summary.get('assets_changed', 0)}")
            click.echo("=" * 60)

    except Exception as e:
        logger.error(f"Diff failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Diff failed: {e}", err=True)
        sys.exit(1)


# ============================================================================
# v0.8.8.2: Branch Merging Commands
# ============================================================================


@history_cmd.group(name="merge")
@click.pass_context
def merge_cmd(ctx):
    """
    Branch merging commands (v0.8.8.2).

    Merge experimental branches back into main with conflict detection
    and resolution strategies.
    """
    pass


@merge_cmd.command(name="start")
@click.argument("source_branch", type=str)
@click.option(
    "--into", "target_branch", default="main", help="Target branch (default: main)"
)
@click.option(
    "--strategy",
    type=click.Choice(["auto", "ours", "theirs", "interactive"]),
    default="auto",
    help="Merge strategy",
)
@click.option("--message", "-m", type=str, help="Custom merge commit message")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def merge_start(
    ctx,
    source_branch: str,
    target_branch: str,
    strategy: str,
    message: Optional[str],
    json_output: bool,
):
    """
    Start merging a source branch into target branch.

    SOURCE_BRANCH: Branch to merge from (e.g., "feature-menu")

    Example:
        bpy history merge start feature-menu --into main --strategy auto
        bpy history merge start experiment --strategy interactive
    """
    from branchpy.core.history import MergeEngine, MergeStrategy
    from branchpy.core.history.snapshot import SnapshotManager

    project_path = ctx.obj["project_path"]
    history_dir = project_path / ".branchpy" / "history"

    try:
        # Initialize merge engine
        snapshot_manager = SnapshotManager(str(history_dir))
        merge_engine = MergeEngine(history_dir, snapshot_manager)

        # Convert strategy string to enum
        strategy_map = {
            "auto": MergeStrategy.AUTO,
            "ours": MergeStrategy.OURS,
            "theirs": MergeStrategy.THEIRS,
            "interactive": MergeStrategy.INTERACTIVE,
        }
        merge_strategy = strategy_map[strategy]

        # Perform merge
        result = merge_engine.merge_branches(
            target_branch, source_branch, merge_strategy, message
        )

        if json_output:
            output = {
                "success": result.success,
                "target_branch": result.target_branch,
                "source_branch": result.source_branch,
                "merged_snapshot_id": result.merged_snapshot_id,
                "conflicts_count": len(result.conflicts),
                "message": result.message,
            }

            if result.has_conflicts:
                output["conflicts"] = [
                    {
                        "conflict_id": c.conflict_id,
                        "type": c.conflict_type.value,
                        "path": c.path,
                    }
                    for c in result.conflicts
                ]

            click.echo(json.dumps(output, indent=2))
        else:
            if result.success:
                click.echo(f"✅ {result.message}")
                click.echo(f"   Merge snapshot: {result.merged_snapshot_id}")
            else:
                click.echo(f"❌ {result.message}", err=True)
                click.echo(f"   Conflicts detected: {len(result.conflicts)}", err=True)
                click.echo("\n   Conflicts:")
                for conflict in result.conflicts[:10]:  # Show first 10
                    click.echo(f"   - {conflict.conflict_type.value}: {conflict.path}")
                if len(result.conflicts) > 10:
                    click.echo(f"   ... and {len(result.conflicts) - 10} more")
                click.echo("\n   Use 'bpy history merge resolve' to resolve conflicts")
                sys.exit(1)

    except Exception as e:
        logger.error(f"Merge failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Merge failed: {e}", err=True)
        sys.exit(1)


@merge_cmd.command(name="abort")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.pass_context
def merge_abort(ctx, json_output: bool):
    """
    Abort an in-progress merge and restore to pre-merge state.

    Example:
        bpy history merge abort
    """
    # In v0.8.8.2, merge is atomic (no intermediate state)
    # This command is a placeholder for future stateful merges
    if json_output:
        click.echo(json.dumps({"success": True, "message": "No merge in progress"}))
    else:
        click.echo("ℹ️  No merge in progress (merges are atomic in v0.8.8.2)")


# ============================================================================
# v0.8.8.2: Governance Cross-Diff Command
# ============================================================================


@history_cmd.command(name="governance-diff")
@click.argument("target_branch", type=str)
@click.argument("source_branch", type=str)
@click.option(
    "--event-type", multiple=True, help="Filter by event type (can specify multiple)"
)
@click.option("--actor", type=str, help="Filter by actor (regex pattern)")
@click.option("--export-html", type=click.Path(), help="Export as HTML report")
@click.option("--export-json", type=click.Path(), help="Export as JSON")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON to stdout")
@click.pass_context
def governance_diff_command(
    ctx,
    target_branch: str,
    source_branch: str,
    event_type: tuple,
    actor: Optional[str],
    export_html: Optional[str],
    export_json: Optional[str],
    json_output: bool,
):
    """
    Compare governance events between two branches.

    TARGET_BRANCH: Branch to compare to (e.g., "main")
    SOURCE_BRANCH: Branch to compare from (e.g., "feature-menu")

    Example:
        bpy history governance-diff main feature-menu
        bpy history governance-diff main feature --event-type POLICY_VIOLATED --export-html report.html
        bpy history governance-diff main dev --actor "user_.*" --json
    """
    from branchpy.core.history import GovernanceDiffEngine

    project_path = ctx.obj["project_path"]
    history_dir = project_path / ".branchpy" / "history"

    try:
        # Initialize governance diff engine
        diff_engine = GovernanceDiffEngine(history_dir)

        # Convert event_type tuple to list (if provided)
        event_type_filter = list(event_type) if event_type else None

        # Perform comparison
        result = diff_engine.compare_branches(
            target_branch,
            source_branch,
            event_type_filter=event_type_filter,
            actor_filter=actor,
        )

        # Export HTML
        if export_html:
            diff_engine.export_html(result, Path(export_html))
            click.echo(f"✅ Exported HTML governance diff to {export_html}")

        # Export JSON
        if export_json:
            diff_engine.export_json(result, Path(export_json))
            click.echo(f"✅ Exported JSON governance diff to {export_json}")

        # Print to stdout
        if json_output:
            output = {
                "target_branch": result.target_branch,
                "source_branch": result.source_branch,
                "total_target_events": result.total_target_events,
                "total_source_events": result.total_source_events,
                "only_target_count": result.only_target_count,
                "only_source_count": result.only_source_count,
                "modified_count": result.modified_count,
                "event_diffs": [
                    {
                        "event_id": diff.event_id,
                        "diff_type": diff.diff_type,
                        "event_type": diff.event_type,
                        "actor": diff.actor,
                        "timestamp": diff.timestamp.isoformat(),
                    }
                    for diff in result.event_diffs
                ],
            }
            click.echo(json.dumps(output, indent=2))
        elif not export_html and not export_json:
            # Human-readable summary
            click.echo(f"Governance Diff: {target_branch} ↔ {source_branch}")
            click.echo("=" * 60)
            click.echo(f"Target Events:      {result.total_target_events}")
            click.echo(f"Source Events:      {result.total_source_events}")
            click.echo(f"Only in Target:     {result.only_target_count}")
            click.echo(f"Only in Source:     {result.only_source_count}")
            click.echo(f"Modified:           {result.modified_count}")
            click.echo("=" * 60)

            if result.event_diffs:
                click.echo("\nRecent Differences:")
                for diff in result.event_diffs[:10]:  # Show first 10
                    diff_marker = {
                        "ONLY_TARGET": "→",
                        "ONLY_SOURCE": "←",
                        "MODIFIED": "⚠",
                    }.get(diff.diff_type, "?")
                    click.echo(
                        f"  {diff_marker} {diff.event_type} ({diff.actor}) - {diff.timestamp.strftime('%Y-%m-%d %H:%M')}"
                    )

                if len(result.event_diffs) > 10:
                    click.echo(
                        f"\n  ... and {len(result.event_diffs) - 10} more differences"
                    )

    except Exception as e:
        logger.error(f"Governance diff failed: {e}", exc_info=True)
        if json_output:
            click.echo(json.dumps({"success": False, "error": str(e)}))
        else:
            click.echo(f"❌ Governance diff failed: {e}", err=True)
        sys.exit(1)


# Register with main CLI
def register(cli):
    """Register history command with main CLI."""
    cli.add_command(history_cmd)
