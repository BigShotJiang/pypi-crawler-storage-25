"""
Phase 3A: Automatic Trace Generation CLI command

Provides `branchpy trace --install` to install automatic trace generation shim
into Ren'Py projects.
"""

import sys
from pathlib import Path

from branchpy import logs


def add_parser(subparsers):
    """Register trace command with CLI parser"""
    parser = subparsers.add_parser(
        "trace",
        help="Manage automatic trace generation and automated exploration for Ren'Py projects",
    )
    parser.add_argument(
        "action",
        nargs="?",
        choices=["install", "status", "run", "help"],
        default="help",
        help="Action to perform",
    )
    parser.add_argument(
        "project_path",
        nargs="?",
        default=None,
        help="Path to Ren'Py project (defaults to current directory)",
    )
    parser.add_argument(
        "--enable",
        action="store_true",
        help="Enable auto_trace in config when installing",
    )

    # Phase 3B.1: Automated runner flags
    parser.add_argument(
        "--mode",
        default="basic",
        choices=["basic"],
        help="Exploration mode (Phase 3B.1 MVP: only 'basic' supported)",
    )
    parser.add_argument(
        "--budget",
        default="600",
        help="Time budget for exploration (seconds or 5m/1h format)",
    )
    parser.add_argument(
        "--max-depth", type=int, default=50, help="Maximum exploration depth"
    )
    parser.add_argument(
        "--trace-timeout",
        type=int,
        default=30,
        help="Timeout in seconds for trace event polling",
    )
    parser.add_argument(
        "--no-install",
        action="store_true",
        help="Skip automatic shim installation check",
    )
    return parser


def run(args):
    """Handle trace command: install, status, run, or help"""

    # Handle parsed args from argparse
    if hasattr(args, "action"):
        action = args.action
        project_path = args.project_path
        enable = getattr(args, "enable", False)
    else:
        # Handle raw args list (for direct invocation)
        if not args or args[0] in ["--help", "-h", "help"]:
            print_help()
            return 0
        action = args[0]
        project_path = (
            args[1] if len(args) > 1 and not args[1].startswith("--") else None
        )
        enable = "--enable" in args

    if action == "install" or action == "--install":
        return install_trace_shim_cli(project_path, enable)
    elif action == "status" or action == "--status":
        return show_trace_status_cli(project_path)
    elif action == "run":
        return cmd_trace_run(args)
    else:
        print_help()
        return 0


def install_trace_shim_cli(project_path, enable):
    """Install automatic trace generation shim into project"""
    from branchpy.engines.renpy_engine import RenpyEngine
    from branchpy.license.detection import _is_renpy_project, detect_engine

    # Resolve project path
    if project_path:
        proj_path = Path(project_path).resolve()
    else:
        proj_path = Path.cwd()

    # Validate project type
    if not _is_renpy_project(proj_path):
        engine_type = detect_engine(proj_path)
        print(f"Error: Project at {proj_path} is not a Ren'Py project")
        print(f"Detected engine: {engine_type}")
        return 1

    # Install shim
    engine = RenpyEngine(config={})
    result = engine.install_trace_shim(str(proj_path))

    if result["success"]:
        print(f"✓ {result['message']}")
        print(f"  Path: {result['path']}")

        # Update config if --enable flag provided
        if enable:
            config_path = proj_path / ".branchpy" / "config.toml"
            if update_trace_config(config_path, enabled=True):
                print(f"✓ Enabled auto_trace in {config_path}")
            else:
                print(f"! Could not update config at {config_path}")
                print("  Manually set: [flowchart.observed]")
                print("                auto_trace = true")
        else:
            print("\nTo enable automatic trace generation:")
            print("  1. Set in .branchpy/config.toml:")
            print("     [flowchart.observed]")
            print("     auto_trace = true")
            print("  OR")
            print("  2. Re-run with: branchpy trace install --enable")

        return 0
    else:
        print(f"✗ Installation failed: {result['message']}")
        return 1


def show_trace_status_cli(project_path):
    """Show trace generation status for project"""
    from branchpy.engines.renpy_engine import RenpyEngine
    from branchpy.license.detection import _is_renpy_project, detect_engine

    # Resolve project path
    if project_path:
        proj_path = Path(project_path).resolve()
    else:
        proj_path = Path.cwd()

    # Validate project type
    if not _is_renpy_project(proj_path):
        engine_type = detect_engine(proj_path)
        print(f"Error: Project at {proj_path} is not a Ren'Py project")
        print(f"Detected engine: {engine_type}")
        return 1

    # Check installation status
    engine = RenpyEngine(config={})
    detection = engine.detect_trace_shim(str(proj_path))

    print(f"Trace Generation Status for: {proj_path}")
    print(f"  Installed: {detection['installed']}")
    if detection["installed"]:
        print(f"  Version: {detection['version']}")
        print(f"  Path: {detection['path']}")
    else:
        print(f"  Path (expected): {detection['path']}")
        print("\nTo install: branchpy trace install")

    # Check config
    config_path = proj_path / ".branchpy" / "config.toml"
    if config_path.exists():
        auto_trace_enabled = check_auto_trace_config(config_path)
        print(f"  Config auto_trace: {auto_trace_enabled}")
    else:
        print("  Config: No .branchpy/config.toml found")

    return 0


def update_trace_config(config_path: Path, enabled: bool) -> bool:
    """Update config.toml to enable/disable auto_trace"""
    try:
        import toml

        # Create config dir if needed
        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config or create new
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                config = toml.load(f)
        else:
            config = {}

        # Update flowchart.observed.auto_trace
        if "flowchart" not in config:
            config["flowchart"] = {}
        if "observed" not in config["flowchart"]:
            config["flowchart"]["observed"] = {}

        config["flowchart"]["observed"]["auto_trace"] = enabled

        # Write back
        with open(config_path, "w", encoding="utf-8") as f:
            toml.dump(config, f)

        return True
    except Exception as e:
        logs.warning("trace.config_update_failed", f"Failed to update config: {e}")
        return False


def cmd_trace_run(args):
    """
    Phase 3B.1: Automated exploration runner.

    Launches Ren'Py with autoplay shim and explores branches via BFS.
    """
    import json
    from datetime import datetime

    from branchpy.config import load_config
    from branchpy.engines.renpy_engine import RenpyEngine
    from branchpy.license.detection import _is_renpy_project, detect_engine

    # Resolve project path
    project_path = Path(args.project_path) if args.project_path else Path.cwd()
    project_path = project_path.resolve()

    # Validate project type
    if not _is_renpy_project(project_path):
        engine_type = detect_engine(project_path)
        print(f"✗ Error: Project at {project_path} is not a Ren'Py project")
        print(f"  Detected engine: {engine_type}")
        return 1

    # Ensure .branchpy/ directory structure exists (before any file writes)
    branchpy_dir = project_path / ".branchpy"
    branchpy_dir.mkdir(exist_ok=True)
    (branchpy_dir / "trace").mkdir(exist_ok=True)  # Trace event files
    (branchpy_dir / "runner").mkdir(exist_ok=True)  # Runner control + logs

    # Check for choice_points.json (required for runner)
    choice_points_path = branchpy_dir / "index" / "choice_points.json"
    if not choice_points_path.exists():
        print("✗ Error: Choice points index not found")
        print(f"  Expected: {choice_points_path}")
        print("")
        print("Phase 3B.1 requires indexed choice points before running.")
        print("Please run one of:")
        print("  • branchpy analyze --engine renpy")
        print("  • (or manually create .branchpy/index/choice_points.json)")
        return 1

    # Preflight checks before launching process
    # Gate 1: Verify SDK launcher exists
    try:
        config = load_config(project_path)
        engine = RenpyEngine(config=config)
        launcher = engine._resolve_renpy_launcher()
    except FileNotFoundError as e:
        print("✗ Preflight failed: SDK launcher not found")
        print("")
        print(str(e))
        return 1
    except Exception as e:
        print(f"✗ Preflight failed: {e}")
        return 1

    print(f"✓ Ren'Py launcher: {launcher}")

    # Gate 2: Verify .branchpy/trace/ is writable
    try:
        test_file = branchpy_dir / "trace" / ".write_test"
        test_file.touch()
        test_file.unlink()
    except Exception as e:
        print("✗ Preflight failed: Cannot write to .branchpy/trace/")
        print(f"  Error: {e}")
        return 1

    print("✓ Trace directory writable")

    # Generate session_id
    session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    logs.info("trace.run.session", f"Session ID: {session_id}")

    # Ensure runner_control.json written BEFORE launching Ren'Py
    runner_control_path = branchpy_dir / "runner_control.json"
    runner_control_data = {
        "enabled": True,
        "autoplay": True,
        "next_choice": None,
        "session_id": session_id,
        "nonce": 0,
    }

    with open(runner_control_path, "w", encoding="utf-8") as f:
        json.dump(runner_control_data, f, indent=2)

    logs.info(
        "trace.run.control", f"Written runner_control.json with session_id={session_id}"
    )

    # Ensure shims installed (unless --no-install)
    # Note: config and engine already loaded in preflight checks
    if not args.no_install:
        # Gate 3: Detect/install autoplay shim (Phase 3B variant)
        detection = engine.detect_trace_shim(str(project_path))

        if not detection["installed"]:
            print("Installing autoplay shim...")
            install_result = engine.install_trace_shim(str(project_path))
            if not install_result["success"]:
                print(f"✗ Failed to install shim: {install_result['message']}")
                return 1
            print(f"✓ Shim installed: {install_result['path']}")
        else:
            logs.info("trace.run.shim", f"Shim already installed: {detection['path']}")

    # Parse budget with validation (FIX #4: Validate budget)
    try:
        budget_sec = parse_budget(args.budget)
        if budget_sec <= 0:
            print(f"✗ Error: Budget must be positive (got {budget_sec}s)")
            return 2
    except ValueError as e:
        print(f"✗ Error: Invalid budget format '{args.budget}': {e}")
        print("  Supported formats: 600 (seconds), 5m (minutes), 1h (hours)")
        return 2

    # Delegate to engine orchestration
    print("")
    print("Phase 3B.1 Automated Runner")
    print(f"  Project: {project_path}")
    print(f"  Session: {session_id}")
    print(f"  Mode: {args.mode}")
    print(f"  Budget: {budget_sec}s")
    print(f"  Max Depth: {args.max_depth}")
    print(f"  Trace Timeout: {args.trace_timeout}s")
    print("")
    print("Starting exploration...")
    print("")

    try:
        # Reuse engine instance from preflight checks
        summary = engine.run_trace_exploration(
            project_path=str(project_path),
            session_id=session_id,
            mode=args.mode,
            budget_sec=budget_sec,
            max_depth=args.max_depth,
            trace_timeout=args.trace_timeout,
        )

        # Write run_summary.json
        summary_path = branchpy_dir / "runner" / f"run_summary_{session_id}.json"

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

        # FIX #5: Check summary success and propagate exit code
        if not summary.get("success", False):
            print("")
            print("✗ Exploration failed")
            print(f"  Error: {summary.get('error', 'Unknown error')}")
            print(f"  Summary: {summary_path.relative_to(project_path)}")
            return 1

        print("")
        print("✓ Exploration complete")
        print(f"  Choices seen: {summary.get('choices_seen', 0)}")
        print(f"  Branches enqueued: {summary.get('branches_enqueued', 0)}")
        print(f"  Branches executed: {summary.get('branches_executed', 0)}")
        print(f"  Unresolved: {summary.get('unresolved_count', 0)}")

        # Warn if session mismatches detected
        if summary.get("session_mismatches", 0) > 0:
            print(
                f"  ⚠ Session mismatches: {summary['session_mismatches']} (check trace file)"
            )

        print("")
        print(f"  Trace file: .branchpy/trace/session-{session_id}-001.jsonl")
        print(f"  Summary: {summary_path.relative_to(project_path)}")

        return 0

    except Exception as e:
        logs.error("trace.run.failed", f"Exploration failed: {e}")
        import traceback

        traceback.print_exc()
        return 1


def parse_budget(budget_str: str) -> int:
    """
    Parse budget string to seconds.

    Supports:
    - Plain integers: "600" → 600
    - Minutes: "5m" or "5M" → 300
    - Hours: "1h" or "1H" → 3600
    - Seconds (explicit): "30s" or "30S" → 30

    Raises:
        ValueError: If budget_str is invalid or empty
    """
    if not budget_str or not budget_str.strip():
        raise ValueError("Budget string is empty")

    budget_str = budget_str.strip().lower()

    try:
        if budget_str.endswith("h"):
            value = budget_str[:-1].strip()
            if not value:
                raise ValueError("Missing value before 'h'")
            return int(value) * 3600
        elif budget_str.endswith("m"):
            value = budget_str[:-1].strip()
            if not value:
                raise ValueError("Missing value before 'm'")
            return int(value) * 60
        elif budget_str.endswith("s"):
            value = budget_str[:-1].strip()
            if not value:
                raise ValueError("Missing value before 's'")
            return int(value)
        else:
            # Plain integer
            return int(budget_str)
    except ValueError as e:
        if "invalid literal" in str(e):
            raise ValueError(f"Invalid number in budget '{budget_str}'")
        raise


def check_auto_trace_config(config_path: Path) -> bool:
    """Check if auto_trace is enabled in config"""
    try:
        import toml

        with open(config_path, "r", encoding="utf-8") as f:
            config = toml.load(f)
        return config.get("flowchart", {}).get("observed", {}).get("auto_trace", False)
    except Exception:
        return False


def print_help():
    """Print help for trace command"""
    print(
        """
branchpy trace - Automatic trace generation management

USAGE:
    branchpy trace --install [PROJECT_PATH] [--enable]
    branchpy trace --status [PROJECT_PATH]
    branchpy trace --help

COMMANDS:
    --install    Install automatic trace generation shim into Ren'Py project
                 Copies branchpy_trace_autogen.rpy to game/ directory
                 Re-running will update shim to latest version (idempotent)
                 
                 Optional flags:
                   --enable    Also enable auto_trace in .branchpy/config.toml
    
    --status     Show trace generation installation and config status
    
    --help       Show this help message

EXAMPLES:
    # Install shim in current directory
    branchpy trace --install
    
    # Install and enable in specific project
    branchpy trace --install /path/to/renpy/project --enable
    
    # Check status
    branchpy trace --status

CONFIGURATION:
    After installing the shim, enable automatic trace generation in
    .branchpy/config.toml:
    
    [flowchart.observed]
    enabled = true        # Enable observed edge ingestion
    auto_trace = true     # Enable automatic trace generation
    
    Traces are written to: .branchpy/trace/session-*.jsonl

WORKFLOW:
    1. Install shim: branchpy trace --install --enable
    2. Run Ren'Py game and play through scenarios
    3. Traces are automatically captured to .branchpy/trace/
    4. Analyze project: branchpy analyze --engine renpy --out results.json
    5. Check obs_status.trace_files_found > 0 in results.json
    6. Observed edges are merged with CFG/PFI/SAE edges via ERP

For more information, see: docs/v1.1.0/flowchart/AUTO_TRACE_INSTALLATION.md
"""
    )


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
