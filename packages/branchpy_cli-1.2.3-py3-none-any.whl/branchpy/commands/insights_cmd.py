"""
branchpy/commands/insights_cmd.py

Show the InsightSummary for the current project.

Usage:
    branchpy insights
    branchpy --project /path/to/project insights
    branchpy insights --json
    branchpy insights --rebuild
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.license.gating import require_feature_cli


def _load_summary(project_root: Path) -> dict | None:
    # (M-11) New canonical path: .branchpy/insights/insight_summary.json
    # Legacy fallback: .branchpy/insight_summary.json (root — pre-Wave 4)
    path = project_root / ".branchpy" / "insights" / "insight_summary.json"
    if not path.exists():
        path = project_root / ".branchpy" / "insight_summary.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        print(
            f"[bpy] Warning: Could not read insight_summary.json: {e}", file=sys.stderr
        )
        return None


def _print_summary(summary: dict) -> None:
    """Print a compact human-readable summary to stdout."""
    from branchpy.insight_summary import SCHEMA_VERSION

    rm = summary.get("runtime_metadata") or {}
    sh = summary.get("story_health") or {}
    cx = summary.get("complexity") or {}
    vh = summary.get("variable_health") or {}
    ss = summary.get("state_space") or {}
    ast = summary.get("assets") or {}

    schema = summary.get("schema_version", "?")
    version = rm.get("branchpy_version", "?")
    run_id = rm.get("run_id", "?")[:8] + "…"
    started = rm.get("started_at", "?")

    print()
    print("  BranchPy Insights")
    print("  " + "─" * 50)
    print(f"  Schema:   {schema}   Run: {run_id}   Version: {version}")
    print(f"  Started:  {started}")
    print()

    # ── Top-level verdict ────────────────────────────────────────────────────
    _issues = []
    if (sh.get("error_count") or 0) > 0:
        n = sh["error_count"]
        _issues.append(f"{n} story error{'s' if n != 1 else ''}")
    if (sh.get("warning_count") or 0) > 0:
        n = sh["warning_count"]
        _issues.append(f"{n} story warning{'s' if n != 1 else ''}")
    if (sh.get("unreachable_label_count") or 0) > 0:
        n = sh["unreachable_label_count"]
        _issues.append(f"{n} unreachable label{'s' if n != 1 else ''}")
    if (sh.get("orphan_label_count") or 0) > 0:
        n = sh["orphan_label_count"]
        _issues.append(f"{n} orphan label{'s' if n != 1 else ''}")
    if (vh.get("high_variance_count") or 0) > 0:
        n = vh["high_variance_count"]
        _issues.append(f"{n} high-variance variable{'s' if n != 1 else ''}")
    if (vh.get("type_inconsistency_count") or 0) > 0:
        n = vh["type_inconsistency_count"]
        _issues.append(f"{n} type inconsistenc{'ies' if n != 1 else 'y'}")
    if (ss.get("impossible_combo_count") or 0) > 0:
        n = ss["impossible_combo_count"]
        _issues.append(f"{n} impossible state combo{'s' if n != 1 else ''}")
    if ss.get("capped"):
        _issues.append("state-space analysis capped (partial coverage)")
    if (ast.get("image_issues_count") or 0) > 0:
        n = ast["image_issues_count"]
        _issues.append(f"{n} missing image{'s' if n != 1 else ''}")

    if _issues:
        print("  Overall:  \u26a0  Needs attention")
        # One-sentence interpretation: pick the highest-priority meaning
        _has_story_errors = (sh.get("error_count") or 0) > 0
        _has_missing_imgs = (ast.get("image_issues_count") or 0) > 0
        _has_var_issues = (vh.get("high_variance_count") or 0) > 0 or (
            vh.get("type_inconsistency_count") or 0
        ) > 0
        _high_complexity = (cx.get("paths_enumerated") or 0) >= 500 or (
            cx.get("cfg_nodes") or 0
        ) > 50000
        _has_unreachable = (sh.get("unreachable_label_count") or 0) > 0
        if _has_story_errors:
            _meaning = "Story errors detected \u2014 the project may crash or behave incorrectly at runtime."
        elif _has_unreachable:
            _meaning = "Unreachable labels found \u2014 some story content may never be reached by players."
        elif _has_var_issues and _has_missing_imgs:
            _meaning = "Variable inconsistencies and missing assets both need attention before release."
        elif _has_var_issues:
            _meaning = "Variable usage inconsistencies may cause unexpected behavior during gameplay."
        elif _has_missing_imgs and _high_complexity:
            _meaning = "Project integrity impacted by missing assets; execution complexity is high."
        elif _has_missing_imgs:
            _meaning = "Missing assets will cause visual gaps at runtime \u2014 run image-validate for details."
        else:
            _meaning = "Minor issues detected \u2014 review the sections below."
        print(f"  \u2514\u2192 {_meaning}")
        print(f"  Issues:   {_issues[0]}")
        for _i in _issues[1:]:
            print(f"            {_i}")
    else:
        print("  Overall:  \u2713  All clear")

    # Project profile line
    _labels = sh.get("total_labels")
    _paths = cx.get("paths_enumerated")
    _vars = sh  # use story vars for now
    _profile = []
    if _labels is not None:
        if _labels > 500:
            _profile.append(f"large project ({_labels:,} labels)")
        elif _labels > 100:
            _profile.append(f"medium project ({_labels:,} labels)")
        else:
            _profile.append(f"small project ({_labels:,} labels)")
    if _paths is not None and _paths >= 500:
        _profile.append("500+ execution paths (at analysis cap)")
    if _profile:
        print(f"  Profile:  {',  '.join(_profile)}")
    print()

    def _flag(val, threshold=0, word="issue"):
        """Return ⚠ if val > threshold, ✓ if val == 0, else empty."""
        if val is None:
            return ""
        if val > threshold:
            return f"  ⚠  {val} {word}{'s' if val != 1 else ''}"
        return "  ✓"

    # Story health
    total_labels = sh.get("total_labels")
    errors = sh.get("error_count") or 0
    warnings = sh.get("warning_count") or 0
    unreachable = sh.get("unreachable_label_count") or 0
    orphans = sh.get("orphan_label_count") or 0
    files = sh.get("total_files")

    label_str = f"{total_labels:,}" if total_labels is not None else "—"
    file_str = f"  ({files} files)" if files is not None else ""
    print(f"  📖 Story Health{file_str}")
    print(f"     Labels:       {label_str}")
    if unreachable:
        print(f"     Unreachable:  {unreachable}  ⚠")
    if orphans:
        print(f"     Orphans:      {orphans}  ⚠")
    if errors or warnings:
        sev = f"{errors} error{'s' if errors != 1 else ''}, {warnings} warning{'s' if warnings != 1 else ''}  ⚠"
        print(f"     Issues:       {sev}")
    else:
        print("     Issues:       none  ✓")
    print()

    # Complexity (Pilot)
    paths = cx.get("paths_enumerated")
    cfg = cx.get("cfg_nodes")
    tvars = cx.get("total_variables")
    if paths is not None or tvars is not None:
        print("  🔀 Complexity  (Pilot)")
        if paths is not None:
            cap_note = "  (at analysis cap — true count higher)" if paths >= 500 else ""
            print(f"     Paths:        {paths:,}{cap_note}")
        if tvars is not None:
            print(f"     Variables:    {tvars:,}")
        if cfg is not None:
            complexity_note = "  (large project)" if cfg > 50000 else ""
            print(f"     CFG nodes:    {cfg:,}{complexity_note}")
        print()

    # Variable health (Pilot)
    hv = vh.get("high_variance_count")
    ti = vh.get("type_inconsistency_count")
    pu = vh.get("potentially_unused_count")
    if hv is not None or ti is not None:
        print("  📊 Variable Health  (Pilot)")
        hv_note = f"{hv}  ⚠" if hv else f"{hv}  ✓" if hv is not None else "—"
        ti_note = f"{ti}  ⚠" if ti else f"{ti}  ✓" if ti is not None else "—"
        pu_note = f"{pu}" if pu is not None else "—"
        print(f"     High variance:      {hv_note}")
        print(f"     Type inconsistency: {ti_note}")
        if pu is not None:
            print(f"     Potentially unused: {pu_note}")
        print()

    # State space (Omega)
    vs = ss.get("variables_seen")
    ic = ss.get("impossible_combo_count")
    if vs is not None:
        print("  🌐 State Space  (Omega)")
        print(f"     Variables seen:    {vs:,}")
        if ic is not None:
            ic_note = f"{ic}  ⚠" if ic else f"{ic}  ✓"
            print(f"     Impossible combos: {ic_note}")
        if ss.get("capped"):
            print(
                f"     ⚠  Analysis capped — {ss.get('capped_variable_count', '?')} variables at limit"
            )
        print()

    # Assets
    if ast.get("image_validation_present"):
        img_issues = ast.get("image_issues_count")
        if img_issues is None:
            img_str = "unknown (run: branchpy image-validate)"
        elif img_issues:
            img_str = f"{img_issues} missing  ⚠"
        else:
            img_str = "0  ✓"
        print("  🖼  Assets")
        print(f"     Missing images: {img_str}")
        print()

    print("  " + "─" * 50)


def run(args) -> int:
    project_root = Path(getattr(args, "project", ".")).resolve()
    output_json = getattr(args, "json", False)
    rebuild = getattr(args, "rebuild", False)
    no_auto_recompute = getattr(args, "no_auto_recompute", False)

    # License gate: Pro tier (+ renpy_free during pre-launch, beta_tester always)
    require_feature_cli("insights", "BranchPy Insights", project_root, "insights.run")

    if rebuild:
        print(
            "[bpy] Rebuilding InsightSummary from current artifacts…", file=sys.stderr
        )
        from branchpy.artifact_freshness import get_source_revision
        from branchpy.insight_summary import build_and_persist
        from branchpy.run_context import RunContext

        ctx = RunContext.start(
            project_root, get_source_revision(project_root)
        ).complete()
        summary, path = build_and_persist(ctx, project_root)
        print(f"[bpy] Written: {path}", file=sys.stderr)
    else:
        from branchpy.artifact_freshness import check_artifact_freshness

        # ── Analyze (hard dependency: always auto-run if missing or stale) ──
        analyze_status = check_artifact_freshness(project_root, "analyze")

        if analyze_status.missing or analyze_status.stale:
            if no_auto_recompute:
                _reason = "missing" if analyze_status.missing else "stale"
                print(
                    f"[bpy] Error: Analysis data is {_reason}. "
                    "Run: branchpy analyze --format json",
                    file=sys.stderr,
                )
                return 1
            _reason_str = (
                "source files changed \u2013 recomputing\u2026"
                if analyze_status.stale
                else "first-time run\u2026"
            )
            print(f"  \u21bb  analyze   ({_reason_str})")
            import contextlib
            import io as _io

            from branchpy.commands.analyze_cmd import main as _analyze_main

            buf = _io.StringIO()
            with contextlib.redirect_stdout(buf):
                _analyze_main([str(project_root), "--format=json", "--out=-"])
        else:
            if not output_json:
                print("  \u2713  analyze   (cached \u2013 project unchanged)")

        # ── Pilot (soft dependency: refresh if stale, skip if never run) ──
        pilot_status = check_artifact_freshness(project_root, "pilot")
        if pilot_status.stale and not no_auto_recompute:
            print("  \u21bb  pilot     (source files changed \u2013 recomputing\u2026)")
            import argparse as _argparse

            from branchpy.commands.stats2_cmd import run as _stats2_run

            _stats2_run(
                _argparse.Namespace(
                    project=str(project_root),
                    max_paths=500,
                    max_depth=100,
                    output_dir="stats2",
                    policy_mode="off",
                    policy_json="",
                    _run_ctx=None,
                )
            )
        elif pilot_status.fresh and not output_json:
            print("  \u2713  pilot     (cached \u2013 project unchanged)")

        # ── Omega (soft dependency: refresh if stale, skip if never run) ──
        omega_status = check_artifact_freshness(project_root, "omega")
        if omega_status.stale and not no_auto_recompute:
            print("  \u21bb  omega     (source files changed \u2013 recomputing\u2026)")
            import argparse as _argparse
            import contextlib as _cl
            import io as _io

            from branchpy.commands.omega_cmd import run as _omega_run

            # Suppress omega's internal pilot-status line (it prints its own "✓ pilot")
            _buf = _io.StringIO()
            with _cl.redirect_stdout(_buf):
                _omega_run(
                    _argparse.Namespace(
                        project_root=str(project_root),
                        value_cap=50,
                        combo_cap=2000,
                        open_after=False,
                        no_auto_recompute=True,
                        _run_ctx=None,
                    )
                )
            # Re-print only the OMEGA lines from omega's output (skip pilot lines)
            for _line in _buf.getvalue().splitlines():
                if "pilot" not in _line.lower():
                    print(_line)
        elif omega_status.fresh and not output_json:
            print("  \u2713  omega     (cached \u2013 project unchanged)")

        # ── Advisory: inform user which extra stages would enrich insights ──
        if not output_json:
            _missing = []
            if pilot_status.missing:
                _missing.append(
                    (
                        "pilot",
                        "branchpy --project . pilot",
                        "complexity & variable-health domains",
                    )
                )
            if omega_status.missing:
                _missing.append(
                    ("omega", "branchpy --project . omega", "state-space domain")
                )
            if _missing:
                print()
                print("  \u2139  This insight is built from Analyze data only.")
                print("     Run the following for richer coverage:")
                for _name, _cmd, _domains in _missing:
                    print(f"       {_cmd:<46}  \u2192  adds {_domains}")
                print()

        # ── Rebuild insight_summary from current on-disk artifacts ──
        # Always regenerate here so the summary reflects any stages just refreshed
        # (and covers the case where insight_summary.json was never created because
        #  analyze was run with an older version that didn't write it).
        from branchpy.artifact_freshness import get_source_revision
        from branchpy.insight_summary import build_and_persist
        from branchpy.run_context import RunContext

        _ctx = RunContext.start(
            project_root, get_source_revision(project_root)
        ).complete()
        try:
            _summary_dict, _ = build_and_persist(_ctx, project_root)
            summary = _summary_dict
        except Exception as _e:
            if not output_json:
                print(
                    f"[bpy] Warning: could not rebuild insight_summary: {_e}",
                    file=sys.stderr,
                )
            summary = _load_summary(project_root)

    if summary is None:
        print(
            "[bpy] No insight_summary.json found after analysis.\n"
            "      Try: branchpy --project . analyze --format json",
            file=sys.stderr,
        )
        return 1

    if output_json:
        if hasattr(sys.stdout, "buffer"):
            sys.stdout.buffer.write(
                json.dumps(summary, indent=2, ensure_ascii=False).encode("utf-8")
            )
            sys.stdout.buffer.write(b"\n")
            sys.stdout.buffer.flush()
        else:
            print(json.dumps(summary, indent=2, ensure_ascii=False))
    else:
        _print_summary(summary)

    return 0


def add_parser(subparsers) -> None:
    p = subparsers.add_parser(
        "insights",
        help="Show the InsightSummary for the current project.",
        description=(
            "Displays the normalized InsightSummary produced after the last analysis run. "
            "Use --rebuild to regenerate from current artifacts without re-running analysis."
        ),
        epilog=fmt_examples(
            "branchpy insights",
            "branchpy --project /path/to/project insights",
            "branchpy insights --json",
            "branchpy insights --rebuild",
        ),
        formatter_class=HelpFmt,
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Output the full InsightSummary as JSON.",
    )
    p.add_argument(
        "--rebuild",
        action="store_true",
        help="Re-derive the InsightSummary from existing artifacts on disk (no re-analysis).",
    )
    p.add_argument(
        "--no-auto-recompute",
        dest="no_auto_recompute",
        action="store_true",
        help="Do not automatically re-run analyze if its output is missing or stale.",
    )
    p.set_defaults(handler=run)
