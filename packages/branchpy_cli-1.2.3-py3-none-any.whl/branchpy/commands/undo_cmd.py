from __future__ import annotations

import argparse
import json
from pathlib import Path

from branchpy.patch_state import load_state, record_undo
from branchpy.patch_store import ensure_project_registered, get_project_patches_dir
from branchpy.utils import git_engine
from branchpy.utils.emit import emit_event, should_emit_from_args


def _latest_applied(pdir: Path) -> str | None:
    st = load_state(pdir)
    return st["applied"][-1] if st["applied"] else None


def cmd_undo(args: argparse.Namespace) -> int:
    if not git_engine.available():
        print("[BranchPy] Undo is disabled: Git not found in PATH.")
        print(
            "           Install Git (https://git-scm.com/downloads) or run 'branchpy doctor' for help."
        )
        return 2

    friendly, proj_path, _ = ensure_project_registered(getattr(args, "project", None))
    pdir = get_project_patches_dir(friendly)
    st = load_state(pdir)
    if not st["applied"]:
        print(f"[BranchPy] No applied patches to undo for project '{friendly}'.")
        return 0

    patch_name = st["applied"][-1]
    patch_file = pdir / patch_name

    ok, msg = git_engine.apply_patch(
        proj_path, patch_file, reverse=True, check=getattr(args, "preview", False)
    )
    if not ok:
        print(f"[BranchPy] FAILED to undo {patch_name}\n{msg}")
        return 1

    if getattr(args, "preview", False):
        print(f"Preview OK (no changes): {patch_name}")
        return 0

    record_undo(pdir, patch_name)
    st2 = load_state(pdir)

    # Emit notification event if requested
    if should_emit_from_args(args):
        emit_event(
            "patch_reverted",
            project=friendly,
            patch=patch_name,
        )

    if getattr(args, "json", False):
        print(
            json.dumps(
                {
                    "project": friendly,
                    "undone": patch_name,
                    "remaining_applied": len(st2["applied"]),
                    "reverted": len(st2["reverted"]),
                },
                indent=2,
            )
        )
    else:
        print(f"Reverted: {patch_name}")
        print(
            f"Remaining applied: {len(st2['applied'])} | Reverted: {len(st2['reverted'])}"
        )
    return 0


def add_parser(subparsers):
    p = subparsers.add_parser(
        "undo",
        help="Apply the latest revertible patch (undo). Requires Git. Run branchpy doctor to verify.",
        description="Undo the most recently applied patch in the selected project. Requires Git. Run 'branchpy doctor' to verify.",
    )
    p.add_argument(
        "--preview",
        action="store_true",
        help="Dry-run: use `git apply --check` (no changes).",
    )
    p.add_argument("--json", action="store_true", help="JSON output.")
    p.add_argument(
        "--emit-notify",
        action="store_true",
        help="Emit JSONL notifications on stdout for extension capture",
    )
    p.set_defaults(handler=cmd_undo)
