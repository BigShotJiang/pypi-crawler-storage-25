# branchpy/commands/dev_cmd.py
from __future__ import annotations

import argparse
import datetime
import os
import re
from difflib import unified_diff
from pathlib import Path

from branchpy.patch_state import record_apply
from branchpy.patch_store import ensure_project_registered, get_project_patches_dir

_SLUG_RE = re.compile(r"[^a-z0-9\-]+")


def _slugify(s: str) -> str:
    s = s.strip().lower().replace(" ", "-")
    s = _SLUG_RE.sub("-", s)
    return re.sub(r"-{2,}", "-", s).strip("-") or "change"


def _ts() -> str:
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


from branchpy.utils import git_engine


def _detect_eol(text: str) -> str:
    return "\r\n" if "\r\n" in text else "\n"


def _to_unix(p: Path) -> str:
    return str(p).replace("\\", "/")
    return str(p).replace("\\", "/")


def _write_patch(
    patch_dir: Path, rel_path: Path, before: list[str], after: list[str], desc: str
) -> str:
    # Standard unified diff with a/ and b/ prefixes
    a = f"a/{_to_unix(rel_path)}"
    b = f"b/{_to_unix(rel_path)}"
    diff = unified_diff(
        before, after, fromfile=a, tofile=b, lineterm=""  # no extra newlines
    )
    name = f"{_ts()}-{_slugify(desc)}.patch"
    out_path = patch_dir / name
    out_path.write_text("\n".join(diff) + "\n", encoding="utf-8")
    return name


def cmd_dev(args: argparse.Namespace) -> int:
    if args.action != "make-patch":
        print(
            'Use: branchpy dev make-patch --file <relative> --insert "..." [--at 1] [--desc "msg"]'
        )
        return 2

    # Resolve project & store
    friendly, project_root, auto_added = ensure_project_registered(
        getattr(args, "project", None)
    )
    patch_dir = get_project_patches_dir(friendly)

    rel_arg = Path(args.file)
    abs_path = (project_root / rel_arg).resolve()
    rel_path = abs_path.relative_to(project_root)
    abs_path.parent.mkdir(parents=True, exist_ok=True)

    # Read original text raw to detect EOL
    import io

    original = ""
    if abs_path.exists():
        with io.open(abs_path, "r", encoding="utf-8", newline="") as f:
            original = f.read()
    eol = _detect_eol(original) if original else os.linesep

    # Prepare before/after WITHOUT trailing newlines (difflib expects line chunks)
    before_lines = original.splitlines(keepends=False)

    # Support both literal newlines and escaped \n for multi-line input
    insert_arg = args.insert or ""
    if "\n" in insert_arg:
        # User passed --insert "line1\nline2" (PowerShell or Bash)
        new_lines = insert_arg.split("\n")
    else:
        # User passed a true multi-line string (here-string or file)
        new_lines = insert_arg.splitlines()
    if not new_lines:
        print("[BranchPy] Nothing to insert: --insert produced zero lines.")
        return 2

    at = max(1, args.at)
    idx = at - 1
    after_lines = before_lines.copy()
    for i, ln in enumerate(new_lines):
        after_lines.insert(idx + i, ln)

    # Write modified file with original EOLs
    new_text = eol.join(after_lines) + (eol if after_lines else "")
    abs_path.write_text(new_text, encoding="utf-8")

    # --- Robust unified diff for insert with context ---
    import re
    from datetime import datetime

    def _slugify(s: str) -> str:
        s = s.strip().lower().replace(" ", "-")
        return (
            re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9\-]+", "-", s)).strip("-")
            or "change"
        )

    def _to_unix(p: Path) -> str:
        return str(p).replace("\\", "/")

    def _build_insert_patch(
        rel_path: Path, before: list[str], added: list[str], idx: int
    ) -> str:
        """
        Build a minimal but robust unified diff for inserting `added` (no EOLs)
        at 0-based index `idx` into `before` (no EOLs).
        Emits:
          --- a/...
          +++ b/...
          @@ -<start_from>,<len_from> +<start_to>,<len_to> @@
          [context-before...]
          +added...
          [context-after...]
        Context: up to 3 lines before and 3 lines after the insertion point.
        """
        path = _to_unix(rel_path)
        out: list[str] = [f"--- a/{path}", f"+++ b/{path}"]

        m = len(added)
        if m == 0:
            raise ValueError("Nothing to insert")

        n = len(before)
        if n == 0:
            # New file content
            out.append(f"@@ -0,0 +1,{m} @@")
            out.extend("+" + ln for ln in added)
            return "\n".join(out) + "\n"

        # Determine context window sizes
        prev = min(3, idx)  # lines before idx
        foll = min(3, n - idx)  # lines starting at idx

        # 1-based starts
        start_from = (idx - prev) + 1
        start_to = start_from

        len_from = prev + foll
        len_to = prev + m + foll

        out.append(f"@@ -{start_from},{len_from} +{start_to},{len_to} @@")

        # context before
        for i in range(idx - prev, idx):
            out.append(" " + before[i])

        # additions
        out.extend("+" + ln for ln in added)

        # context after
        for i in range(idx, idx + foll):
            out.append(" " + before[i])

        return "\n".join(out) + "\n"

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    name = f"{ts}-{_slugify(args.desc or f'insert-{rel_path.name}')}.patch"
    patch_path = patch_dir / name

    patch_text = _build_insert_patch(rel_path, before_lines, list(new_lines), idx)

    # Write with exactly one trailing newline (no extras)
    patch_path.write_text(patch_text, encoding="utf-8")

    # Optional: validate reverse to ensure `undo --preview` success
    if git_engine.available():
        ok, msg = git_engine.apply_patch(
            project_root, patch_path, reverse=True, check=True
        )
        if not ok:
            print(
                f"[BranchPy] WARNING: reverse-apply validation failed; undo may fail.\n{msg}\nPatch: {patch_path}"
            )

    # Record as applied
    record_apply(patch_dir, name)

    # Output
    print(f"Project: {friendly}")
    if auto_added:
        print(f"[BranchPy] Registered project as '{friendly}' → {project_root}")
        print("[BranchPy] You can rename it anytime with:")
        print(f"    branchpy projects rename {friendly} <new_name>")
        print()

    print(f"File edited: {abs_path}")
    print(f"Patch dir:  {patch_dir}")
    print(f"Patch file: {name}")
    print("Done. You can now run:")
    print(f"  branchpy --project {friendly} patches --list")
    print(f"  branchpy --project {friendly} undo")
    return 0


def add_parser(subparsers):
    p = subparsers.add_parser(
        "dev",
        help="Developer utilities (temporary seeding/testing).",
        description="Dev helper commands for seeding patches and testing flows.",
    )
    sp = p.add_subparsers(dest="action", required=True)
    mk = sp.add_parser(
        "make-patch",
        help="Edit a file and create a unified diff patch in the project store.",
        description="Insert line(s) into a file, save the change, create a .patch, and mark it applied.",
    )
    mk.add_argument(
        "--file",
        required=True,
        help="Path RELATIVE to project root (e.g., game/script.rpy).",
    )
    mk.add_argument(
        "--insert",
        required=True,
        help=(
            "Text to insert. Multi-line is allowed; lines are inserted as a block.\n"
            "\n"
            "Multi-line Insert Examples (PowerShell & Bash/zsh):\n"
            "\n"
            "PowerShell:\n"
            "  Using backtick-newlines:\n"
            "    branchpy --project mygame dev make-patch --file game\\script.rpy --insert \"# L1`n# L2`n# L3\" --at 2 --desc 'add three lines'\n"
            "  Using a here-string (multi-line argument):\n"
            "    branchpy --project mygame dev make-patch --file game\\script.rpy --insert @\"\n# L1\n# L2\n# L3\n\"@ --at 2 --desc 'add three lines'\n"
            "\n"
            "Bash/zsh:\n"
            "  Using literal \\n inside double quotes:\n"
            "    branchpy --project mygame dev make-patch --file game/script.rpy --insert \"# L1\\n# L2\\n# L3\" --at 2 --desc 'add three lines'\n"
            "  Using a true multi-line argument:\n"
            "    branchpy --project mygame dev make-patch --file game/script.rpy --insert $'# L1\\n# L2\\n# L3' --at 2 --desc 'add three lines'\n"
        ),
    )
    mk.add_argument(
        "--at",
        type=int,
        default=1,
        help="1-based line number to insert the block at (default: 1).",
    )
    mk.add_argument(
        "--desc",
        default=None,
        help="Optional description to include in the patch filename.",
    )
    p.set_defaults(handler=cmd_dev)
