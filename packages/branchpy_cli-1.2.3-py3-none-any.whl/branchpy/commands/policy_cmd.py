"""Policy Evaluation CLI Command.

Usage:
    branchpy policy --rules <path> [--provider <id>] [--assets <path>] [--json]

Evaluate ProviderPolicyEngine rules against assets and emit governance events.
Reads asset metadata from JSON or scans directory.

Exit codes:
    0 = no violations or INFO only
    1 = WARN violations found
    2 = ERROR violations found or invalid arguments
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


def add_parser(subparsers) -> None:
    """Register policy command in CLI argument parser."""
    p = subparsers.add_parser(
        "policy",
        help="Evaluate provider policy rules",
        description=(
            "Evaluate policy rules (image size, naming patterns, tag requirements) "
            "against assets and emit governance events for violations."
        ),
    )
    p.set_defaults(handler=run)
    p.add_argument(
        "--rules",
        type=str,
        required=True,
        metavar="PATH",
        help="Path to JSON/YAML policy rules file",
    )
    p.add_argument(
        "--provider",
        type=str,
        default="local",
        metavar="ID",
        help="Provider ID for governance logging (default: local)",
    )
    p.add_argument(
        "--assets",
        type=str,
        metavar="PATH",
        help="Path to JSON asset metadata file or directory to scan",
    )
    p.add_argument("--json", action="store_true", help="Output violations as JSON")
    p.add_argument(
        "--correlation-id",
        type=str,
        metavar="ID",
        help="Optional correlation ID for governance events",
    )


def _load_rules(path: Path) -> List[Dict[str, Any]]:
    """Load policy rules from JSON or YAML file."""
    if not path.exists():
        raise FileNotFoundError(f"Rules file not found: {path}")

    content = path.read_text(encoding="utf-8")

    # Try JSON first
    try:
        data = json.loads(content)
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "rules" in data:
            return data["rules"]
        else:
            raise ValueError("Rules file must contain array or object with 'rules' key")
    except json.JSONDecodeError:
        pass

    # Try YAML if available
    try:
        import yaml  # type: ignore

        data = yaml.safe_load(content)
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "rules" in data:
            return data["rules"]
        else:
            raise ValueError("Rules file must contain array or object with 'rules' key")
    except ImportError:
        raise ValueError("Rules file is not valid JSON and PyYAML not installed")
    except Exception as e:
        raise ValueError(f"Failed to parse rules file: {e}")


def _load_assets(path: Optional[Path], project_root: Path) -> List[Dict[str, Any]]:
    """Load asset metadata from JSON file or scan directory."""
    if not path:
        # Default: scan project images directory
        images_dir = project_root / "game" / "images"
        if not images_dir.exists():
            return []
        return _scan_directory(images_dir)

    path = Path(path)
    if path.is_file():
        # Load from JSON
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "assets" in data:
            return data["assets"]
        else:
            raise ValueError(
                "Asset file must contain array or object with 'assets' key"
            )
    elif path.is_dir():
        return _scan_directory(path)
    else:
        raise FileNotFoundError(f"Assets path not found: {path}")


def _scan_directory(directory: Path) -> List[Dict[str, Any]]:
    """Scan directory for image files and extract basic metadata."""
    assets = []
    for ext in [".png", ".jpg", ".jpeg", ".webp"]:
        for img_path in directory.rglob(f"*{ext}"):
            try:
                # Try to get dimensions with PIL if available
                width, height = None, None
                try:
                    from PIL import Image  # type: ignore

                    with Image.open(img_path) as im:
                        width, height = im.size
                except ImportError:
                    pass
                except Exception:
                    pass

                assets.append(
                    {
                        "path": str(img_path.relative_to(directory)),
                        "width": width,
                        "height": height,
                        "tags": [],
                    }
                )
            except Exception:
                continue
    return assets


def run(args: argparse.Namespace) -> int:
    """Execute policy evaluation command."""
    project_root = Path(getattr(args, "project", ".")).resolve()

    # Load rules
    try:
        rules_path = Path(args.rules)
        rules = _load_rules(rules_path)
    except Exception as e:
        print(f"Error loading rules: {e}", file=sys.stderr)
        return 2

    # Load assets
    try:
        assets_path = Path(args.assets) if args.assets else None
        assets = _load_assets(assets_path, project_root)
    except Exception as e:
        print(f"Error loading assets: {e}", file=sys.stderr)
        return 2

    # Initialize governance logger
    from branchpy.analysis.image_validation.governance_logger import (
        ImageValidationLogger,
    )

    gov_logger = ImageValidationLogger(
        project_root=project_root, correlation_id=getattr(args, "correlation_id", None)
    )

    # Run policy engine
    from branchpy.analysis.image_validation.provider_policy import ProviderPolicyEngine

    engine = ProviderPolicyEngine(gov_logger)

    violations = engine.evaluate(provider_id=args.provider, assets=assets, rules=rules)

    # Flush governance events
    gov_logger.flush()

    # Output violations
    if args.json:
        print(
            json.dumps(
                [
                    {
                        "rule_id": v.rule_id,
                        "severity": v.severity,
                        "message": v.message,
                        "provider_id": v.provider_id,
                        "asset_path": v.asset_path,
                        "context": v.context,
                    }
                    for v in violations
                ],
                indent=2,
            )
        )
    else:
        if not violations:
            print(
                f"✅ No policy violations found ({len(rules)} rules, {len(assets)} assets)"
            )
            return 0

        # Group by severity
        by_severity = {"ERROR": [], "WARN": [], "INFO": []}
        for v in violations:
            by_severity.setdefault(v.severity, []).append(v)

        print(f"Policy Evaluation Results: {len(violations)} violations")
        print(f"  Rules:  {len(rules)}")
        print(f"  Assets: {len(assets)}")
        print()

        for severity in ["ERROR", "WARN", "INFO"]:
            viols = by_severity.get(severity, [])
            if not viols:
                continue

            icon = "❌" if severity == "ERROR" else "⚠️" if severity == "WARN" else "ℹ️"
            print(f"{icon} {severity}: {len(viols)} violations")
            for v in viols[:10]:  # Show first 10
                loc = f" ({v.asset_path})" if v.asset_path else ""
                print(f"  [{v.rule_id}] {v.message}{loc}")
            if len(viols) > 10:
                print(f"  ... and {len(viols) - 10} more")
            print()

    # Determine exit code based on highest severity
    has_error = any(v.severity == "ERROR" for v in violations)
    has_warn = any(v.severity == "WARN" for v in violations)

    if has_error:
        return 2
    elif has_warn:
        return 1
    else:
        return 0


__all__ = ["add_parser", "run"]
