"""
Compare Preview CLI Command (v0.8.8.3)
=======================================

CLI wrapper for multi-lane compare preview.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Optional

from branchpy.attribution import maybe_show_attribution_notice
from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.core.compare.preview_engine import compare_preview
from branchpy.core.compare.semantic_types import AliasMap, Filters, LaneSpec, Semantics
from branchpy.obs import end_operation, start_operation
from branchpy.project_resolver import resolve_project


def run_compare_preview(
    lanes: list[dict],
    filters: Optional[dict] = None,
    alias_map: Optional[dict] = None,
    semantics: Optional[dict] = None,
    project: Optional[str] = None,
    export_format: Optional[str] = None,
    export_path: Optional[str] = None,
) -> int:
    """
    Run compare preview and output results.

    Args:
        lanes: List of lane spec dicts
        filters: Filter options dict
        alias_map: Alias map dict
        semantics: Semantics config dict
        project: Project path
        export_format: "json" or "html"
        export_path: Output file path

    Returns:
        0: success
        1: error
    """
    op_id = start_operation(
        "compare.preview.run",
        {"lanes": len(lanes), "filters": bool(filters), "export": export_format},
    )

    try:
        # Resolve project path
        resolved_project = None
        if project:
            resolved_project = resolve_project(project)
            if not resolved_project:
                print(f"Error: Could not resolve project: {project}")
                end_operation(
                    op_id,
                    "compare.preview.run",
                    status="error",
                    meta={"error": "project resolution failed"},
                )
                return 1
        else:
            resolved_project = Path.cwd()

        # Parse lane specs
        lane_specs = []
        for lane_dict in lanes:
            try:
                lane_specs.append(
                    LaneSpec(
                        project_id=lane_dict["project"],
                        branch=lane_dict["branch"],
                        start=lane_dict["start"],
                        end=lane_dict["end"],
                        analysis_id=lane_dict.get("analysis_id"),
                    )
                )
            except Exception as e:
                print(f"Error parsing lane spec: {e}")
                print(f"Lane: {lane_dict}")
                end_operation(
                    op_id,
                    "compare.preview.run",
                    status="error",
                    meta={"error": f"lane parse failed: {e}"},
                )
                return 1

        # Parse filters
        filters_obj = None
        if filters:
            filters_obj = Filters(
                divergences_only=filters.get("divergencesOnly", False),
                stat_keys=filters.get("statKeys", []),
                include_guards=filters.get("includeGuards", True),
                include_choices=filters.get("includeChoices", True),
                max_rows=filters.get("maxRows", 5000),
            )

        # Parse alias map
        alias_map_obj = None
        if alias_map:
            alias_map_obj = AliasMap(
                lane_index=alias_map.get("laneIndex", 0),
                aliases=alias_map.get("aliases", {}),
            )

        # Parse semantics
        semantics_obj = None
        if semantics:
            semantics_obj = Semantics(
                weights=semantics.get("weights", {}),
                guard_compare_mode=semantics.get("guardCompareMode", "normalized"),
            )

        # Run compare preview
        result = compare_preview(
            lanes=lane_specs,
            filters=filters_obj,
            alias_map=alias_map_obj,
            semantics=semantics_obj,
            project_root=Path(resolved_project),
        )

        # Export or print results
        if export_format == "json":
            output = {
                "meta": result.meta,
                "anchors": [
                    {
                        "row": anchor.row,
                        "reason": anchor.reason,
                        "laneMatches": anchor.lane_matches,
                        "score": anchor.score,
                    }
                    for anchor in result.anchors
                ],
                "rows": [
                    {
                        "row": row.row,
                        "lanes": row.lanes,
                        "diffSummary": row.diff_summary,
                        "diverges": row.diverges,
                    }
                    for row in result.rows
                ],
                "summary": result.summary,
            }

            output_json = json.dumps(output, indent=2, ensure_ascii=False)

            if export_path:
                Path(export_path).write_text(output_json, encoding="utf-8")
                print(f"Exported JSON to: {export_path}")
            else:
                print(output_json)

        elif export_format == "html":
            # HTML export (will be implemented in exporter module)
            from branchpy.core.compare.exporter import export_html

            if not export_path:
                # Default path
                export_path = str(Path.cwd() / ".branchpy" / "compare" / "preview.html")

            export_html(result, lane_specs, Path(export_path))
            print(f"Exported HTML to: {export_path}")

        else:
            # Text summary output
            print(f"\n=== Compare Preview: {len(lane_specs)} lanes ===")
            print(f"Total rows: {result.meta['rowCount']}")
            print(f"Divergent rows: {result.summary['divergentRows']}")
            print(f"Anchors found: {len(result.anchors)}")

            if result.summary.get("statDeltas"):
                print("\nStat Deltas:")
                for stat_key, values in result.summary["statDeltas"].items():
                    print(f"  {stat_key}: {values}")

            print(f"\nGuards changed: {result.summary.get('guardsChanged', 0)}")

            # Show sample divergent rows
            divergent_rows = [r for r in result.rows if r.diverges]
            if divergent_rows:
                print("\nSample divergent rows (first 5):")
                for row in divergent_rows[:5]:
                    print(f"  Row {row.row}:")
                    for lane_idx, lane_data in enumerate(row.lanes):
                        if lane_data.get("gap"):
                            print(f"    Lane {lane_idx}: [GAP]")
                        else:
                            label = lane_data.get("label", "?")
                            stats = lane_data.get("statsDelta", {})
                            print(f"    Lane {lane_idx}: {label} {stats}")

        end_operation(
            op_id,
            "compare.preview.run",
            status="ok",
            meta={
                "rows": result.meta["rowCount"],
                "divergent": result.summary["divergentRows"],
            },
        )
        maybe_show_attribution_notice("compare_preview")
        return 0

    except Exception as e:
        print(f"Compare preview failed: {e}")
        import traceback

        traceback.print_exc()
        end_operation(
            op_id, "compare.preview.run", status="error", meta={"error": str(e)}
        )
        return 1


def cmd_compare_preview(args: argparse.Namespace) -> int:
    """Handle compare preview command from CLI."""

    # Build lanes list from command-line args
    lanes = []

    # Parse --lane arguments
    if hasattr(args, "lane") and args.lane:
        for lane_spec in args.lane:
            # Parse lane spec string: "project=X branch=Y start=label:Z end=label:W"
            # or use structured format
            lanes.append(lane_spec)

    # Parse filters
    filters = None
    if args.divergences_only or args.stat or args.max_rows != 5000:
        filters = {
            "divergencesOnly": args.divergences_only,
            "statKeys": args.stat or [],
            "includeGuards": not args.no_guards,
            "includeChoices": not args.no_choices,
            "maxRows": args.max_rows,
        }

    # Parse alias map
    alias_map = None
    if args.alias:
        # Parse alias arguments: "lane=0 label1=alias1,alias2"
        aliases = {}
        lane_index = 0
        for alias_spec in args.alias:
            parts = alias_spec.split("=", 1)
            if len(parts) == 2:
                key, value = parts
                if key == "lane":
                    lane_index = int(value)
                else:
                    # key is label, value is comma-separated aliases
                    aliases[key] = value.split(",")

        if aliases:
            alias_map = {"laneIndex": lane_index, "aliases": aliases}

    # Determine export format and path
    export_format = None
    export_path = None

    if args.export:
        # Parse export argument: "html" or "html out=path.html"
        parts = args.export.split()
        export_format = parts[0]

        for part in parts[1:]:
            if part.startswith("out="):
                export_path = part[4:]

    return run_compare_preview(
        lanes=lanes,
        filters=filters,
        alias_map=alias_map,
        semantics=None,  # Use defaults
        project=getattr(args, "project", None),
        export_format=export_format,
        export_path=export_path,
    )


def add_parser(subparsers) -> None:
    """Register the compare preview command with the CLI parser."""

    # Add 'preview' subcommand to 'compare' group
    # This assumes compare_cmd already has a subparser
    # We'll add this as a new command: 'branchpy compare preview'

    p = subparsers.add_parser(
        "compare-preview",
        help="Multi-lane semantic comparison (2-5 branches)",
        description=(
            "Compare 2-5 narrative branches side-by-side with intelligent semantic alignment. "
            "Uses weighted LCS with semantic action boosting for better matching."
        ),
        epilog=fmt_examples(
            "# Compare two branches for a chapter",
            "branchpy compare-preview \\",
            "  --lane project=MyGame branch=main start=label:chapter1 end=label:chapter2 \\",
            "  --lane project=MyGame branch=exp start=label:chapter1 end=label:chapter2",
            "",
            "# Show only divergences with specific stats",
            "branchpy compare-preview \\",
            "  --lane project=MyGame branch=main start=label:intro end=eof \\",
            "  --lane project=MyGame branch=dev start=label:intro end=eof \\",
            "  --divergences-only --stat claire_trust --stat p_name_boldness",
            "",
            "# Export to HTML with manual aliases",
            "branchpy compare-preview \\",
            "  --lane project=MyGame branch=main start=label:ch1 end=label:ch2 \\",
            "  --lane project=MyGame branch=refactor start=label:ch1 end=label:ch2 \\",
            "  --alias post_intro1=post_intro_01,pi1 \\",
            "  --export html out=compare_ch1.html",
        ),
        formatter_class=HelpFmt,
    )

    # Lane specifications
    p.add_argument(
        "--lane",
        action="append",
        type=_parse_lane_spec,
        required=True,
        help="Lane spec: project=ID branch=NAME start=TYPE:VALUE end=TYPE:VALUE [analysis_id=ID]",
    )

    # Filters
    p.add_argument(
        "--divergences-only",
        action="store_true",
        help="Show only rows where lanes diverge",
    )
    p.add_argument(
        "--stat",
        action="append",
        metavar="KEY",
        help="Filter to specific stat keys (can specify multiple times)",
    )
    p.add_argument("--no-guards", action="store_true", help="Exclude guard information")
    p.add_argument(
        "--no-choices", action="store_true", help="Exclude choice information"
    )
    p.add_argument(
        "--max-rows",
        type=int,
        default=5000,
        help="Maximum rows to return (default: 5000)",
    )

    # Aliases
    p.add_argument(
        "--alias",
        action="append",
        metavar="SPEC",
        help="Alias mapping: lane=N LABEL=ALIAS1,ALIAS2 or LABEL=ALIAS1,ALIAS2",
    )

    # Export
    p.add_argument(
        "--export",
        metavar="FORMAT",
        help="Export format: 'html out=path.html' or 'json out=path.json'",
    )

    p.set_defaults(handler=cmd_compare_preview)


def _parse_lane_spec(spec_str: str) -> dict:
    """
    Parse a lane specification string.

    Format: "project=ID branch=NAME start=TYPE:VALUE end=TYPE:VALUE [analysis_id=ID]"

    Examples:
        "project=MyGame branch=main start=label:intro end=label:chapter1"
        "project=MyGame branch=dev start=bof end=eof"
    """
    parts = spec_str.split()
    lane = {}

    for part in parts:
        if "=" not in part:
            continue

        key, value = part.split("=", 1)

        if key == "start" or key == "end":
            # Parse start/end: "label:intro" or "bof" or "eof"
            if ":" in value:
                type_part, value_part = value.split(":", 1)
                lane[key] = {"type": type_part, "value": value_part}
            else:
                lane[key] = {"type": value}
        else:
            lane[key] = value

    return lane
