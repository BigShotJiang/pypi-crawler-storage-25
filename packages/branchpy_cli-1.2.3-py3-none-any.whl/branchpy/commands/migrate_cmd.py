"""
BranchPy migrate command - Clean up project structure and move files to .branchpy/
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from branchpy.cli_help import HelpFmt


def migrate_project_files(project_path: Path) -> dict:
    """
    Migrate BranchPy files to proper .branchpy/ structure.

    Args:
        project_path: Path to project root

    Returns:
        dict with migration results
    """
    results = {"moved": [], "created_dirs": [], "errors": []}

    # Create .branchpy structure
    branchpy_dir = project_path / ".branchpy"
    subdirs = ["analyze", "stats", "compare", "cache", "temp", "templates", "logs"]

    for subdir in subdirs:
        dir_path = branchpy_dir / subdir
        if not dir_path.exists():
            dir_path.mkdir(parents=True, exist_ok=True)
            results["created_dirs"].append(str(dir_path.relative_to(project_path)))

    # Files to move (pattern: old_location -> new_location)
    migration_map = {
        "cfg_output.dot": ".branchpy/cache/cfg_output.dot",
        "cfg.dot": ".branchpy/cache/cfg.dot",
        "unified_report.json": ".branchpy/analyze/unified_report.json",
    }

    # Move files that exist in project root
    for old_name, new_path in migration_map.items():
        old_file = project_path / old_name
        if old_file.exists() and old_file.is_file():
            new_file = project_path / new_path
            try:
                # If destination exists, rename with timestamp
                if new_file.exists():
                    import time

                    timestamp = time.strftime("%Y%m%d-%H%M%S")
                    stem = new_file.stem
                    suffix = new_file.suffix
                    new_file = new_file.parent / f"{stem}-{timestamp}{suffix}"

                shutil.move(str(old_file), str(new_file))
                results["moved"].append(
                    f"{old_name} → {new_file.relative_to(project_path)}"
                )
            except Exception as e:
                results["errors"].append(f"Failed to move {old_name}: {e}")

    # Move any stray *.json reports to appropriate directories
    for json_file in project_path.glob("*.json"):
        name = json_file.name

        # Skip .branchpy.toml config
        if name == ".branchpy.toml":
            continue

        # Determine destination based on filename
        dest_dir = None
        if name.startswith("analyze-") or name == "unified_report.json":
            dest_dir = branchpy_dir / "analyze"
        elif name.startswith("stats-"):
            dest_dir = branchpy_dir / "stats"
        elif name.startswith("compare-"):
            dest_dir = branchpy_dir / "compare"

        if dest_dir:
            try:
                dest_file = dest_dir / name
                # If destination exists, skip (don't overwrite)
                if dest_file.exists():
                    continue

                shutil.move(str(json_file), str(dest_file))
                results["moved"].append(
                    f"{name} → {dest_file.relative_to(project_path)}"
                )
            except Exception as e:
                results["errors"].append(f"Failed to move {name}: {e}")

    # Create .gitignore if it doesn't exist
    gitignore_path = branchpy_dir / ".gitignore"
    if not gitignore_path.exists():
        gitignore_content = """# BranchPy Generated Files
# Never commit
cache/
temp/
logs/
*.pyc
__pycache__/

# Internal engine cache artifacts (Class C — not for public consumption)
**/.internal/

# Optional (team decision)
# analyze/
# stats/
# compare/
# out/

# Keep templates and baseline
!templates/
!reports/baseline.json
"""
        gitignore_path.write_text(gitignore_content, encoding="utf-8")
        results["created_dirs"].append(".branchpy/.gitignore")

    # Create README.md if it doesn't exist
    readme_path = branchpy_dir / "README.md"
    if not readme_path.exists():
        readme_content = """# .branchpy Directory

This directory contains all BranchPy-generated files.

## Structure

- `analyze/` - Analysis reports (unified_report.json)
- `stats/` - Statistics reports
- `compare/` - Comparison reports
- `cache/` - Cached data (CFG graphs, etc.)
- `temp/` - Temporary files
- `templates/` - Custom report templates
- `logs/` - Operation logs

## Configuration

The `.branchpy.toml` file in the project root (not here) contains project settings.

See https://branchpy.org/docs for more information.
"""
        readme_path.write_text(readme_content, encoding="utf-8")
        results["created_dirs"].append(".branchpy/README.md")

    return results


def run(project: str = ".") -> int:
    """
    Migrate BranchPy files to .branchpy/ structure.

    Args:
        project: Project path

    Returns:
        0 on success, 1 on error
    """
    project_path = Path(project).resolve()

    if not project_path.exists():
        print(f"Error: Project path does not exist: {project_path}")
        return 1

    print(f"Migrating BranchPy files in: {project_path}")
    print()

    results = migrate_project_files(project_path)

    # Print results
    if results["created_dirs"]:
        print("✅ Created directories/files:")
        for item in results["created_dirs"]:
            print(f"   {item}")
        print()

    if results["moved"]:
        print("✅ Moved files:")
        for item in results["moved"]:
            print(f"   {item}")
        print()

    if results["errors"]:
        print("⚠️  Errors:")
        for error in results["errors"]:
            print(f"   {error}")
        print()
        return 1

    if not results["moved"] and not results["created_dirs"]:
        print("✨ Project structure is already clean!")
        print()
    else:
        print("✨ Migration complete!")
        print()

    print(f"All BranchPy files are now in: {project_path / '.branchpy'}")
    return 0


def cmd_migrate(args: argparse.Namespace) -> int:
    """Handle migrate command from CLI."""
    return run(project=args.project)


def add_parser(subparsers) -> None:
    """Register the migrate command with the CLI parser."""
    p = subparsers.add_parser(
        "migrate",
        help="Clean up project structure and move BranchPy files to .branchpy/",
        description=(
            "Migrate BranchPy-generated files from project root to the .branchpy/ directory. "
            "This keeps your project clean and organized."
        ),
        epilog="Example: branchpy migrate --project mygame",
        formatter_class=HelpFmt,
    )

    p.add_argument(
        "--project",
        default=".",
        metavar="PATH",
        help="Project directory (default: current directory)",
    )

    p.set_defaults(handler=cmd_migrate)
