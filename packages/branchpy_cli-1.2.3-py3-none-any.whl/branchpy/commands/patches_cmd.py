from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

from branchpy.cli_help import HelpFmt, fmt_examples
from branchpy.patch_store import ensure_project_registered, get_project_patches_dir


def _list_patch_files(pdir: Path) -> list[str]:
    """List all .patch files in the given directory, sorted by mtime descending (newest first)."""
    if not pdir.exists():
        return []
    items = [p for p in pdir.iterdir() if p.is_file() and p.suffix.lower() == ".patch"]
    items.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return [str(p) for p in items]


def _push_external_patch(args) -> int:
    """Push (register) an external patch file into the project's patch directory."""
    try:
        friendly, proj_path, auto_added = ensure_project_registered(
            getattr(args, "project", None)
        )
        pdir = get_project_patches_dir(friendly)

        # Ensure patch directory exists
        pdir.mkdir(parents=True, exist_ok=True)

        source_file = Path(args.push)
        if not source_file.exists():
            print(f"Error: Patch file not found: {source_file}")
            return 1

        if not source_file.is_file():
            print(f"Error: Path is not a file: {source_file}")
            return 1

        # Validate it's a patch file (basic check)
        if not source_file.suffix.lower() == ".patch":
            print(f"Warning: File does not have .patch extension: {source_file}")

        # Generate timestamp-based name if needed
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = source_file.stem
        dest_name = f"{timestamp}_{base_name}.patch"
        dest_path = pdir / dest_name

        # Copy the file
        shutil.copy2(source_file, dest_path)

        # Update patch state to mark as "applied" (external patches are assumed to be applied)
        from branchpy.patch_state import load_state, save_state

        st = load_state(pdir)
        if "applied" not in st:
            st["applied"] = []
        if "reverted" not in st:
            st["reverted"] = []

        # Add to applied list if not already there
        if dest_name not in st["applied"]:
            st["applied"].append(dest_name)

        # Remove from reverted list if it was there
        if dest_name in st["reverted"]:
            st["reverted"].remove(dest_name)

        save_state(pdir, st)

        print("✓ Patch registered successfully:")
        print(f"  Source:      {source_file}")
        print(f"  Destination: {dest_path}")
        print(f"  Project:     {friendly}")
        print("  Status:      applied")

        if auto_added:
            print(
                f"  Note: Project was auto-registered. To rename: branchpy projects rename '{friendly}' <newname>"
            )

        return 0

    except Exception as e:
        print(f"Error pushing patch: {e}")
        return 1


def cmd_patches(args):
    """Project-scoped patches command that auto-registers project names if needed."""

    # Handle push operation
    if hasattr(args, "push") and args.push:
        return _push_external_patch(args)

    # Handle list operation (default)
    if not hasattr(args, "list") or not args.list:
        # If no action specified, default to list
        args.list = True

    friendly, proj_path, auto_added = ensure_project_registered(
        getattr(args, "project", None)
    )
    pdir = get_project_patches_dir(friendly)

    # Verbose scan output
    if getattr(args, "verbose", False):
        print(f"[scan] dir exists: {pdir.exists()} → {pdir}")
        try:
            for x in Path(pdir).iterdir():
                print(f"[scan] {x.name} ({'file' if x.is_file() else 'dir'})")
        except Exception as e:
            print(f"[scan] error reading dir: {e}")

    patches = _list_patch_files(pdir)

    # Load patch state and seed if missing
    from branchpy.patch_state import load_state, save_state

    st = load_state(pdir)
    if not st.get("applied") and patches:
        st["applied"] = [Path(p).name for p in patches]
        st["reverted"] = []
        save_state(pdir, st)
    applied = set(st.get("applied", []))
    reverted = set(st.get("reverted", []))

    if getattr(args, "json", False):
        out = {
            "project_friendly": friendly,
            "project_path": str(proj_path),
            "patch_dir": str(pdir),
            "count": len(patches),
            "patches": patches,
            "auto_registered": auto_added,
        }
        if auto_added:
            out["rename_hint"] = f"branchpy projects rename {friendly} <new_name>"
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    if auto_added:
        print(f"[BranchPy] Registered project as '{friendly}' → {proj_path}")
        print("[BranchPy] You can rename it anytime with:")
        print(f"    branchpy projects rename {friendly} <new_name>")
        print()
    print(f"Project: {friendly}")
    print(f"Root:    {proj_path}")
    print(f"Store:   {pdir}")
    if not patches:
        print("(no patches found)")
        return 0
    print("=== Patches ===")
    for p in patches:
        name = Path(p).name
        tag = (
            " (applied)"
            if name in applied
            else " (reverted)" if name in reverted else ""
        )
        print(f"- {name}{tag}")
    return 0


def add_parser(subparsers):
    """Register the patches command with the CLI parser."""
    p = subparsers.add_parser(
        "patches",
        help="List and manage undo/redo patch stacks.",
        description=(
            "List and manage the project's reversible patch stacks (applied/reverted). "
            "Use --push to register external patch files. "
            "Requires a project (global --project) or a default/auto-detected project."
        ),
        epilog=fmt_examples(
            "branchpy --project C:\\proj patches --list",
            "branchpy --project mygame patches --list --verbose",
            "branchpy --project mygame patches --push external.patch",
        ),
        formatter_class=HelpFmt,
    )

    # Create mutually exclusive group for main actions
    group = p.add_mutually_exclusive_group()
    group.add_argument("--list", action="store_true", help="List current patch stacks.")
    group.add_argument(
        "--push", type=str, metavar="FILE", help="Register an external patch file."
    )

    p.add_argument("--json", action="store_true", help="Show output as JSON.")
    p.add_argument("--verbose", action="store_true", help="Show scan details.")
    # If you keep a cross-project view later, you can add --all-projects here.
    p.set_defaults(handler=cmd_patches)
