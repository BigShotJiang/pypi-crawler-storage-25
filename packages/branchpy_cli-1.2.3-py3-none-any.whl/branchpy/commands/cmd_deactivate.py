import argparse
import os
import sys

# Import normalization (Axis5 v0.9.1)
from branchpy.license_manager import LICENSE_PATH, LicenseInfo, save_local


def build(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--keep-key",
        action="store_true",
        help="Keep key on disk but mark Free tier (for seat transfer prep)",
    )


def run(args: argparse.Namespace) -> int:
    try:
        if args.keep_key:
            # Downgrade to Free but preserve key metadata for potential reactivation
            save_local(LicenseInfo(tier="Free"))
            print("✅ BranchPy license downgraded to Free (Non-Commercial).")
            print("   Key metadata preserved. Use 'bpy activate' to reactivate.")
        else:
            # Complete removal
            try:
                os.remove(LICENSE_PATH)
                print("✅ BranchPy license deactivated. License file removed.")
            except FileNotFoundError:
                print(
                    "✅ BranchPy license already deactivated (no license file found)."
                )
            print("   Now on Free (Non-Commercial) tier.")
        return 0
    except Exception as e:
        print(f"❌ Deactivation failed: {e}", file=sys.stderr)
        return 2
