"""
L10n CLI Command

Provides `branchpy l10n` subcommand for translation analysis.

Uses lazy loading with help-aware inflation to avoid importing heavy modules until needed.
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
from pathlib import Path
from typing import Any, Dict, Tuple

# Map subcommand -> (module_path, build_parser_func, entry_func)
_LAZY_MAP: Dict[str, Tuple[str, str, str]] = {
    "audit": (
        "branchpy.cli.commands.l10n_audit_cmd",
        "build_arg_parser",
        "run_from_cli",
    ),
    "trend": (
        "branchpy.cli.commands.l10n_trend_cmd",
        "build_arg_parser",
        "run_trend_cmd",
    ),
    "export": (
        "branchpy.cli.commands.l10n_export_cmd",
        "build_arg_parser",
        "run_from_cli",
    ),
    "import": (
        "branchpy.cli.commands.l10n_import_cmd",
        "build_arg_parser",
        "run_from_cli",
    ),
}


def _base_parser() -> argparse.ArgumentParser:
    """Create base parser with lightweight subcommand placeholders."""
    p = argparse.ArgumentParser(
        prog="branchpy l10n",
        description=(
            "Extract translatable strings from Ren'Py scripts and compute translation "
            "coverage for each language. Reports missing, orphaned, and mismatched translations."
        ),
        add_help=True,
    )
    subs = p.add_subparsers(dest="subcmd", required=True, help="L10n subcommands")
    for name in _LAZY_MAP:
        subs.add_parser(name, add_help=True, help=f"{name.capitalize()} subcommand")
    return p


def _inflate_for_subcmd(subcmd: str) -> argparse.ArgumentParser:
    """
    Inflate full parser for specific subcommand (for help display).

    Imports the subcommand module and calls its build_arg_parser to get full flags.
    """
    mod_path, build_func_name, _ = _LAZY_MAP[subcmd]
    mod = importlib.import_module(mod_path)

    full = argparse.ArgumentParser(
        prog="branchpy l10n",
        description=(
            "Extract translatable strings from Ren'Py scripts and compute translation "
            "coverage for each language. Reports missing, orphaned, and mismatched translations."
        ),
        add_help=True,
    )
    subs = full.add_subparsers(dest="subcmd", required=True, help="L10n subcommands")

    # Call the subcommand's build_arg_parser to add its full parser
    build_func = getattr(mod, build_func_name)
    build_func(subs)

    return full


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    """Register `branchpy l10n` subcommand with lazy-loaded subcommands."""
    p = subparsers.add_parser(
        "l10n",
        help="Analyze translation coverage and generate L10n findings.",
        description=(
            "Extract translatable strings from Ren'Py scripts and compute translation "
            "coverage for each language. Reports missing, orphaned, and mismatched translations."
        ),
    )

    # Add subcommands - we DO need to import the modules to register their parsers
    # The win is avoiding imports of OTHER heavy command modules (compare_cmd, serve_cmd, etc.)
    l10n_subparsers = p.add_subparsers(dest="l10n_command", help="L10n subcommands")

    # Import and register each subcommand's parser
    for name, (mod_path, build_func_name, _) in _LAZY_MAP.items():
        mod = importlib.import_module(mod_path)
        build_func = getattr(mod, build_func_name)
        build_func(l10n_subparsers)

    p.set_defaults(handler=run)


def run(args: argparse.Namespace) -> int:
    """Execute L10n command via lazy dispatch."""
    subcmd = getattr(args, "l10n_command", None)

    if not subcmd:
        print(
            "❌ No l10n subcommand specified. Use 'branchpy l10n --help'",
            file=sys.stderr,
        )
        return 1

    if subcmd not in _LAZY_MAP:
        print(f"❌ Unknown l10n subcommand: {subcmd}", file=sys.stderr)
        return 1

    # Lazy import the requested subcommand module
    mod_path, build_func_name, entry_func_name = _LAZY_MAP[subcmd]
    mod = importlib.import_module(mod_path)

    # Get the entry function and dispatch
    entry = getattr(mod, entry_func_name)

    # export/import use run_from_cli(args) only;
    # audit/trend use run_from_cli(args, env) — check signature to dispatch correctly.
    import inspect

    sig = inspect.signature(entry)
    if len(sig.parameters) >= 2:
        env = _create_env(args)
        return int(entry(args, env) or 0)
    else:
        return int(entry(args) or 0)


def _create_env(args: argparse.Namespace):
    """Create a minimal environment object for trend command."""

    class DummyLogger:
        def info(self, msg):
            print(msg)

        def warn(self, msg):
            print(f"⚠ {msg}", file=sys.stderr)

        def error(self, msg):
            print(f"❌ {msg}", file=sys.stderr)

    class Env:
        project_root = str(Path(args.project).resolve())
        logger = DummyLogger()

    return Env()


def _format_text(index: Any, summaries: Dict[str, Any], findings: list) -> str:
    """Format coverage summary as human-readable text."""
    lines = ["=" * 60, "BranchPy L10n Coverage Report", "=" * 60, ""]

    # Summary table
    lines.append(f"Total source strings: {len(index.source)}")
    lines.append(f"Languages detected: {', '.join(sorted(index.languages))}")
    lines.append("")

    # Per-language coverage
    for lang, summary in sorted(summaries.items()):
        status = "✓" if summary.coverage_pct == 100.0 else "⚠"
        lines.append(
            f"{status} {lang.upper()}: {summary.coverage_pct:.1f}% ({summary.translated}/{summary.total_strings})"
        )

        if summary.missing:
            lines.append(f"   Missing: {len(summary.missing)} strings")
        if summary.orphaned:
            lines.append(f"   Orphaned: {len(summary.orphaned)} strings")
        if summary.length_mismatches:
            lines.append(
                f"   Length mismatches: {len(summary.length_mismatches)} strings"
            )

    lines.append("")
    lines.append(f"Total findings: {len(findings)}")

    # Group findings by severity
    errors = [f for f in findings if f.severity.value == "ERROR"]
    warnings = [f for f in findings if f.severity.value == "WARNING"]
    infos = [f for f in findings if f.severity.value == "INFO"]

    if errors:
        lines.append(f"  ❌ Errors: {len(errors)}")
    if warnings:
        lines.append(f"  ⚠ Warnings: {len(warnings)}")
    if infos:
        lines.append(f"  ℹ Info: {len(infos)}")

    return "\n".join(lines)


def _format_json(index: Any, summaries: Dict[str, Any], findings: list) -> str:
    """Format coverage summary as JSON."""
    output = {
        "totalSourceStrings": len(index.source),
        "languages": sorted(list(index.languages)),
        "coverage": {
            lang: {
                "language": summary.language,
                "totalStrings": summary.total_strings,
                "translated": summary.translated,
                "coveragePercent": summary.coverage_pct,
                "missing": len(summary.missing),
                "orphaned": len(summary.orphaned),
                "lengthMismatches": len(summary.length_mismatches),
            }
            for lang, summary in summaries.items()
        },
        "findings": [
            {
                "ruleId": f.rule_id,
                "severity": f.severity.value,
                "message": f.message,
                "category": f.category,
                "metadata": f.metadata,
            }
            for f in findings
        ],
    }
    return json.dumps(output, indent=2, ensure_ascii=False)
