"""
Image Validation — panel-ready JSON output for VS Code Image Validation panel.

Usage (VS Code panel — machine-readable):
    branchpy image-validate --project /path/to/project --json

Usage (human-readable summary):
    branchpy image-validate --project /path/to/project

Usage (write standalone HTML report):
    branchpy image-validate --project /path/to/project --html

Usage (write HTML report AND open in system browser):
    branchpy image-validate --project /path/to/project --open

What this command does
----------------------
1. Broad recursive scan of the entire project tree for image files (.png,
   .jpg, .jpeg, .webp).  No hard-coded folder list — custom folders such as
   game/cg/, game/mask/, game/phone/ are discovered automatically.
2. Classifies each file:
     user_asset    — game-authored assets in user directories
     renpy_gui     — files under game/gui/ (engine-managed)
     engine_like   — files under .branchpy/, __pycache__, build, etc.
     excluded      — .git, .venv, node_modules, temp, cache, etc.
   Only non-excluded files are included in panel output.
3. Groups by the direct subdirectory beneath the scan root
   (e.g. game/images/characters/ → "characters").
4. Per group:
   - Exact duplicates (MD5 match)
   - Resolution spread (>2 distinct sizes in one group)
   - Mixed naming convention (underscores vs hyphens both present)
5. Each image record carries both abs_path (for Open) and path
   (project-relative, for Copy Path).  No path reconstruction in the UI.
6. Outputs JSON matching the ClustersPayloadV2 contract.

All progress / debug output → stderr.  stdout → clean JSON when --json.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple

log = logging.getLogger("branchpy.image_validate")

# Image extensions we care about
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}

# Directories to skip entirely during the recursive walk
SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    ".env",
    "node_modules",
    ".npm",
    "__pycache__",
    ".branchpy",  # our own cache / report dir
    "build",
    "dist",
    "temp",
    "tmp",
    "cache",
    ".idea",
    ".vscode",
}

# Classify an asset based on its project-relative path
AssetCategory = Literal["user_asset", "renpy_gui", "dev_asset", "engine_like"]

# Path components (lowercased) that indicate dev / test assets.
_DEV_DIRS = {
    "dev",
    "test",
    "tests",
    "debug",
    "debug_assets",
    "testing",
    "sample",
    "samples",
}


def _classify(rel_path: str) -> AssetCategory:
    parts = Path(rel_path).parts
    # Ren’Py GUI folder (engine-managed assets)
    if len(parts) >= 2 and parts[1].lower() == "gui":
        return "renpy_gui"
    # Dev / test assets — anywhere in the path hierarchy
    for part in parts:
        if part.lower() in _DEV_DIRS:
            return "dev_asset"
    # Anything that looks engine/tool generated
    for part in parts:
        low = part.lower()
        if low in {"__pycache__", ".branchpy", "build", "dist", "cache", "temp", "tmp"}:
            return "engine_like"
    return "user_asset"


# ─── CLI registration ─────────────────────────────────────────────────────────


def add_parser(subparsers):
    parser = subparsers.add_parser(
        "image-validate",
        help="Validate project images and output panel-ready JSON",
        description=(
            "Recursively scans ALL project images (no hard-coded folder list), "
            "classifies them, groups by directory, and detects duplicates and "
            "resolution inconsistencies.  Outputs JSON for the VS Code Image "
            "Validation panel."
        ),
    )
    parser.add_argument(
        "--project",
        "-p",
        type=str,
        default=argparse.SUPPRESS,
        help="Project root directory (default: .)",
    )
    parser.add_argument(
        "--engine",
        type=str,
        default="renpy",
        choices=["renpy", "unity", "godot", "unreal", "generic"],
        help="Game engine — informs classification rules (default: renpy)",
    )
    parser.add_argument(
        "--include-gui",
        action="store_true",
        dest="include_gui",
        help="Include engine GUI assets (e.g. game/gui/) in output",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Output machine-readable JSON to stdout (required for VS Code panel)",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        dest="as_html",
        help="Write a standalone HTML report to .branchpy/reports/image-validation.html",
    )
    parser.add_argument(
        "--open",
        action="store_true",
        dest="open_browser",
        help="Open the HTML report in the system browser (implies --html)",
    )

    def handler(args):
        return run(
            project=args.project,
            engine=args.engine,
            include_gui=args.include_gui,
            as_json=args.as_json,
            as_html=args.as_html,
            open_browser=args.open_browser,
            args=args,
        )

    parser.set_defaults(handler=handler)
    return parser


# ─── Entry point ─────────────────────────────────────────────────────────────


def run(
    project: str = ".",
    engine: str = "renpy",
    include_gui: bool = False,
    as_json: bool = False,
    as_html: bool = False,
    open_browser: bool = False,
    args=None,
) -> int:
    project_dir = Path(project or ".").resolve()
    if not project_dir.exists():
        print(f"Error: project directory not found: {project_dir}", file=sys.stderr)
        return 1

    try:
        payload = _build_panel_payload(project_dir, engine, include_gui)

        if as_json:
            print(json.dumps(payload, indent=2, ensure_ascii=False))
        else:
            s = payload["summary"]
            print(f"\nImage Validation — {project_dir.name}")
            print(f"  {s['totalClusters']} groups | {s['totalImages']} images total")
            print(
                f"  \u2713 {s['healthyClusters']} healthy  "
                f"\u26a0 {s['warningClusters']} warning  "
                f"\u2717 {s['errorClusters']} error"
            )
            for g in payload["clusters"]:
                icon = {
                    "healthy": "\u2713",
                    "warning": "\u26a0",
                    "error": "\u2717",
                }.get(g["status"], "?")
                line = f"  {icon} {g['name']}: {g['imageCount']} images"
                if g["issueCount"]:
                    line += f", {g['issueCount']} issue(s)"
                print(line)

        if as_html or open_browser:
            html_path = _write_html_report(payload, project_dir)
            if not as_json:
                print(f"\nHTML report: {html_path}", file=sys.stderr)
            if open_browser:
                import webbrowser

                webbrowser.open(html_path.as_uri())

        return 0

    except Exception:
        log.exception("image-validate failed")
        return 1


# ─── Broad scanner ────────────────────────────────────────────────────────────


def _scan_images(project_dir: Path) -> List[Dict[str, Any]]:
    """
    Recursively walk the entire project tree and collect every image file.

    Returns a list of dicts with:
        abs_path       – absolute path (Path object)
        rel_path        – POSIX relative path from project_dir (str), e.g.
                         "game/images/characters/alice_normal.png"
        size_bytes      – file size in bytes
        width, height   – pixel dimensions (0 if Pillow unavailable)
        fmt             – format string, e.g. "PNG"
        md5             – MD5 hex digest
        category        – 'user_asset' | 'renpy_gui' | 'engine_like'
    """
    try:
        from PIL import Image as PILImage

        _pil = True
    except ImportError:
        _pil = False

    results: List[Dict[str, Any]] = []

    def _walk(directory: Path) -> None:
        try:
            entries = sorted(directory.iterdir())
        except PermissionError:
            return
        for entry in entries:
            if entry.name.startswith("."):
                continue
            if entry.is_dir():
                if entry.name in SKIP_DIRS:
                    continue
                _walk(entry)
            elif entry.is_file() and entry.suffix.lower() in IMAGE_EXTS:
                try:
                    rel = entry.relative_to(project_dir)
                    rel_str = rel.as_posix()
                    size = entry.stat().st_size
                    if _pil:
                        try:
                            with PILImage.open(entry) as im:
                                w, h = im.size
                                fmt = (
                                    getattr(im, "format", None)
                                    or entry.suffix[1:].upper()
                                )
                        except Exception:
                            w, h, fmt = 0, 0, entry.suffix[1:].upper()
                    else:
                        w, h, fmt = 0, 0, entry.suffix[1:].upper()
                    # MD5
                    md5 = hashlib.md5()
                    with open(entry, "rb") as f:
                        for chunk in iter(lambda: f.read(65536), b""):
                            md5.update(chunk)
                    results.append(
                        {
                            "abs_path": entry,
                            "rel_path": rel_str,
                            "size_bytes": size,
                            "width": w,
                            "height": h,
                            "fmt": fmt,
                            "md5": md5.hexdigest(),
                            "category": _classify(rel_str),
                        }
                    )
                except Exception as exc:
                    print(f"[image-validate] skip {entry.name}: {exc}", file=sys.stderr)

    _walk(project_dir)
    return results


# ─── Core pipeline ───────────────────────────────────────────────────────────


def _build_panel_payload(
    project_dir: Path, engine: str, include_gui: bool
) -> Dict[str, Any]:
    now_iso = datetime.now(timezone.utc).isoformat()
    t0 = time.monotonic()

    # ── 1. Broad recursive scan ───────────────────────────────────────────────
    all_images = _scan_images(project_dir)
    print(
        f"[image-validate] Discovered {len(all_images)} images in {project_dir.name}",
        file=sys.stderr,
    )

    # ── 2. Filter to displayable categories ──────────────────────────────────
    excluded_cats = {"engine_like"}
    if not include_gui:
        excluded_cats.add("renpy_gui")

    images = [img for img in all_images if img["category"] not in excluded_cats]
    gui_count = sum(1 for img in all_images if img["category"] == "renpy_gui")

    if gui_count and not include_gui:
        print(
            f"[image-validate] Excluded {gui_count} engine GUI images "
            f"(game/gui/*) — pass --include-gui to include them",
            file=sys.stderr,
        )

    print(
        f"[image-validate] Processing {len(images)} user assets",
        file=sys.stderr,
    )

    if not images:
        print("[image-validate] No user images found.", file=sys.stderr)
        return _empty_payload(project_dir, now_iso)

    # ── 3. Group by *scan root + first subdirectory* ──────────────────────────
    #
    # Strategy: for each image we find the deepest ancestor that is a direct
    # child of a known scan root (e.g. game/images/).  If the project doesn't
    # have a canonical root we group by the second path component.
    #
    # group_id  = stable slug, e.g. "characters"
    # group_key = stable identifier that includes the scan root for display,
    #             e.g. "game/images/characters"
    #
    def _derive_group(rel_path: str) -> Tuple[str, str]:
        """Return (group_id, friendly_name)."""
        parts = Path(rel_path).parts
        # RenPy: parts[0]='game', parts[1]='images'/'gui', parts[2]=subfolder
        # We want subfolders of known scan roots to become groups.
        if len(parts) >= 3 and parts[0].lower() == "game":
            folder = parts[2]
            parent = f"{parts[0]}/{parts[1]}"
            return (
                f"{parts[1]}-{folder}".lower().replace(" ", "-"),
                folder.replace("_", " ").replace("-", " ").title(),
            )
        # Generic: group by second path component, or first if shallow
        if len(parts) >= 2:
            folder = parts[1]
            return (
                folder.lower().replace(" ", "-"),
                folder.replace("_", " ").replace("-", " ").title(),
            )
        return "root", "Root"

    groups: Dict[str, List[Dict]] = {}
    group_names: Dict[str, str] = {}
    for img in images:
        gid, gname = _derive_group(img["rel_path"])
        groups.setdefault(gid, []).append(img)
        group_names[gid] = gname

    # ── 3b. Singleton merger — groups with <3 images fold into ‘Other’ ———————
    # This keeps the homepage clean: only meaningful, stable groups appear.
    # The raw images are preserved in full inside the merged group.
    SINGLETON_THRESHOLD = 3
    OTHER_ID = "other"
    OTHER_NAME = "Other"
    merged_into_other: List[Dict] = []
    tiny_ids = [gid for gid, imgs in groups.items() if len(imgs) < SINGLETON_THRESHOLD]
    for tid in tiny_ids:
        merged_into_other.extend(groups.pop(tid))
        del group_names[tid]
    if merged_into_other:
        existing = groups.get(OTHER_ID, [])
        groups[OTHER_ID] = existing + merged_into_other
        group_names[OTHER_ID] = OTHER_NAME
        print(
            f"[image-validate] Merged {len(tiny_ids)} tiny group(s) "
            f"({sum(1 for _ in merged_into_other)} images) into ‘Other’",
            file=sys.stderr,
        )

    # ── 4. Build per-group data ───────────────────────────────────────────────
    clusters: List[Dict] = []
    details: Dict[str, Any] = {}
    healthy = warning = error = 0

    for group_id in sorted(groups):
        group_images = groups[group_id]
        group_name = group_names[group_id]
        t_group = time.monotonic()

        # basePath: project-relative prefix shared by all images in the group
        # (longest common directory), used by UI for display only
        sample_rel = group_images[0]["rel_path"]
        base_path = str(Path(sample_rel).parent).replace("\\", "/") + "/"

        # ── Exact duplicates ──────────────────────────────────────────────────
        md5_map: Dict[str, List[Dict]] = {}
        for img in group_images:
            md5_map.setdefault(img["md5"], []).append(img)
        dup_groups_raw = [(md5, imgs) for md5, imgs in md5_map.items() if len(imgs) > 1]
        dup_md5_set = {md5 for md5, _ in dup_groups_raw}

        # ── Per-image entries ─────────────────────────────────────────────────
        all_images_data: List[Dict] = []
        for img in group_images:
            issues: List[Dict] = []
            if img["md5"] in dup_md5_set:
                peers = [p for p in md5_map[img["md5"]] if p is not img]
                if peers:
                    peer_name = Path(peers[0]["rel_path"]).name
                    issues.append(
                        {
                            "severity": "warning",
                            "tier": "minor",
                            "type": "duplicate",
                            "impact": "Wastes disk space and makes the asset pipeline harder to maintain.",
                            "message": f"Exact duplicate of {peer_name} (byte-for-byte identical)",
                            "suggestion": "Remove one of the identical copies.",
                            "relatedImage": peer_name,
                        }
                    )

            all_images_data.append(
                {
                    # path: project-relative (used by Copy Path in the UI)
                    "path": img["rel_path"],
                    # abs_path: absolute canonical path (used by Open in the UI)
                    "abs_path": str(img["abs_path"]).replace("\\", "/"),
                    "hash": img["md5"],
                    "goldset": False,
                    "status": "warning" if issues else "valid",
                    "width": img["width"],
                    "height": img["height"],
                    "format": img["fmt"],
                    "size_bytes": img["size_bytes"],
                    "category": img["category"],
                    "issues": issues,
                }
            )

        # ── Group-level issues ────────────────────────────────────────────────
        group_issues: List[Dict] = []

        dims = [
            (img["width"], img["height"]) for img in group_images if img["width"] > 0
        ]
        unique_dims = sorted(set(dims))
        if len(unique_dims) > 2:
            top5 = ", ".join(f"{w}\u00d7{h}" for w, h in unique_dims[:5])
            ellipsis_str = " \u2026" if len(unique_dims) > 5 else ""
            group_issues.append(
                {
                    "severity": "warning",
                    "tier": "warning",
                    "type": "resolution",
                    "impact": "Can cause visible quality drops or blurry assets during gameplay.",
                    "message": f"{len(unique_dims)} different resolutions: {top5}{ellipsis_str}",
                    "suggestion": f"Standardize all {group_name} to a single resolution.",
                }
            )

        if dup_groups_raw:
            total_dup_files = sum(len(imgs) for _, imgs in dup_groups_raw)
            plural = "s" if len(dup_groups_raw) > 1 else ""
            group_issues.append(
                {
                    "severity": "warning",
                    "tier": "minor",
                    "type": "duplicate",
                    "impact": "Wastes disk space and makes the asset pipeline harder to maintain.",
                    "message": (
                        f"{len(dup_groups_raw)} exact duplicate group{plural} "
                        f"({total_dup_files} affected files)"
                    ),
                    "suggestion": "Remove redundant copies — they are byte-for-byte identical.",
                }
            )

        stems = [Path(img["rel_path"]).stem for img in group_images]
        # Count exclusive buckets: a file that uses BOTH separators does not
        # belong to either "underscore-only" or "hyphen-only" camp, so it must
        # not be counted in both (which would produce misleading totals like
        # "5 use underscores, 5 use hyphens" when there are only 5 files).
        only_under = sum(1 for s in stems if "_" in s and "-" not in s)
        only_hyphen = sum(1 for s in stems if "-" in s and "_" not in s)
        if only_under >= 1 and only_hyphen >= 1:
            u_word = "file" if only_under == 1 else "files"
            h_word = "file" if only_hyphen == 1 else "files"
            group_issues.append(
                {
                    "severity": "warning",
                    "tier": "minor",
                    "type": "naming",
                    "impact": "Breaks automated tooling that relies on consistent file naming conventions.",
                    "message": (
                        f"Mixed naming conventions: {only_under} {u_word} use underscores, "
                        f"{only_hyphen} {h_word} use hyphens"
                    ),
                    "suggestion": "Adopt a single convention (underscores recommended).",
                }
            )

        has_error = any(i["severity"] == "error" for i in group_issues)
        if has_error:
            status = "error"
            error += 1
        elif group_issues:
            status = "warning"
            warning += 1
        else:
            status = "healthy"
            healthy += 1

        duration = round(time.monotonic() - t_group, 2)
        err_count = sum(1 for i in group_issues if i["severity"] == "error")
        warn_count = sum(1 for i in group_issues if i["severity"] == "warning")

        dup_detail: List[Dict] = [
            {
                "confidence": 100,
                "images": [img["rel_path"] for img in dup_imgs],
                "suggestion": "Remove one of the identical copies — they are byte-for-byte identical.",
                "deleteConfidence": "safe",
            }
            for _, dup_imgs in dup_groups_raw
        ]

        clusters.append(
            {
                "id": group_id,
                "name": group_name,
                "status": status,
                "imageCount": len(group_images),
                "goldsetCount": 0,
                "lastValidated": now_iso,
                "issueCount": len(group_issues),
                "issues": [
                    {
                        "severity": i["severity"],
                        "tier": i.get("tier", "minor"),
                        "type": i["type"],
                        "message": i["message"],
                    }
                    for i in group_issues
                ],
                "provider": "local",
                "basePath": base_path,
            }
        )

        details[group_id] = {
            "cluster": {
                "id": group_id,
                "name": group_name,
                "description": f"{group_name} assets",
                "provider": "local",
                "basePath": base_path,
            },
            "projectPath": str(project_dir).replace("\\", "/"),
            "totalImages": len(group_images),
            "isSample": False,
            "groupIssues": group_issues,
            "images": all_images_data,
            "validation": {
                "lastRun": now_iso,
                "duration": duration,
                "errors": err_count,
                "warnings": warn_count,
            },
            "duplicates": dup_detail,
        }

    # ── 4. Cross-group top issues ─────────────────────────────────────────────
    top_issues = _build_top_issues(clusters, details)

    elapsed = round(time.monotonic() - t0, 2)
    print(
        f"[image-validate] Done: {len(images)} images, {len(clusters)} groups in {elapsed}s",
        file=sys.stderr,
    )

    return {
        "source": "real",
        "project_root": str(project_dir).replace("\\", "/"),
        "generated_at": now_iso,
        "clusters": clusters,
        "summary": {
            "totalClusters": len(clusters),
            "totalImages": len(images),
            "totalGoldset": 0,
            "healthyClusters": healthy,
            "warningClusters": warning,
            "errorClusters": error,
        },
        "topIssues": top_issues,
        "details": details,
    }


# ─── Helpers ─────────────────────────────────────────────────────────────────


def _build_top_issues(clusters: List[Dict], details: Dict[str, Any]) -> List[Dict]:
    """Surface the 5 most impactful issues across all groups."""
    issues: List[Dict] = []
    rank = 1
    tier_order = {"critical": 0, "warning": 1, "minor": 2}

    for cluster in clusters:
        cid = cluster["id"]
        for gi in details.get(cid, {}).get("groupIssues", []):
            issues.append(
                {
                    "rank": rank,
                    "severity": gi["severity"],
                    "tier": gi.get("tier", "minor"),
                    "category": gi["type"].replace("-", " ").title(),
                    "description": gi["message"],
                    "impact": gi.get("impact", ""),
                    "affectedCount": cluster["imageCount"],
                    "clusterId": cid,
                    "clusterName": cluster["name"],
                    "actionLabel": "View Group",
                }
            )
            rank += 1

    issues.sort(
        key=lambda x: (
            0 if x["severity"] == "error" else 1,
            tier_order.get(x["tier"], 2),
            -x["affectedCount"],
        )
    )
    for i, issue in enumerate(issues[:5], 1):
        issue["rank"] = i

    return issues[:5]


def _write_html_report(payload: Dict[str, Any], project_dir: Path) -> Path:
    """Write a self-contained HTML report and return its path."""
    out_dir = project_dir / ".branchpy" / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "image-validation.html"

    s = payload["summary"]
    clusters = payload.get("clusters", [])
    top_issues = payload.get("topIssues", [])

    def _badge(status: str) -> str:
        colours = {"healthy": "#2ea043", "warning": "#d29922", "error": "#f85149"}
        return f'<span style="background:{colours.get(status,"#888")};color:#fff;padding:2px 7px;border-radius:3px;font-size:11px;font-weight:600;">{status.upper()}</span>'

    cluster_rows = []
    for grp in clusters:
        icon = {"healthy": "✓", "warning": "⚠", "error": "✗"}.get(grp["status"], "?")
        issue_html = ""
        for iss in grp.get("issues", []):
            issue_html += f'<li style="margin:3px 0;font-size:12px;color:#ccc;">{iss["message"]}</li>'
        cluster_rows.append(
            f"""
        <tr>
          <td style="padding:8px 12px;font-weight:600;">{icon} {grp['name']}</td>
          <td style="padding:8px 12px;">{_badge(grp['status'])}</td>
          <td style="padding:8px 12px;text-align:center;">{grp['imageCount']}</td>
          <td style="padding:8px 12px;"><ul style="margin:0;padding-left:16px;">{issue_html or '<li style="font-size:12px;color:#888;">None</li>'}</ul></td>
        </tr>"""
        )

    top_rows = ""
    for ti in top_issues:
        sev_col = "#d29922" if ti["severity"] == "warning" else "#f85149"
        top_rows += f"""
        <tr>
          <td style="padding:6px 10px;text-align:center;font-weight:700;color:{sev_col}">#{ti['rank']}</td>
          <td style="padding:6px 10px;">{ti.get('clusterName','—')}</td>
          <td style="padding:6px 10px;">{ti['category']}</td>
          <td style="padding:6px 10px;font-size:12px;">{ti['description']}</td>
          <td style="padding:6px 10px;text-align:center;">{ti['affectedCount']}</td>
        </tr>"""

    generated_at = payload.get("generated_at", "")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Image Validation — {project_dir.name}</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#1e1e1e;color:#d4d4d4;padding:28px;}}
  h1{{font-size:22px;font-weight:700;margin-bottom:4px;}}
  .meta{{font-size:12px;color:#888;margin-bottom:24px;}}
  .summary{{display:flex;gap:16px;margin-bottom:28px;flex-wrap:wrap;}}
  .card{{background:#252526;border:1px solid #3c3c3c;border-radius:6px;padding:16px 20px;min-width:130px;}}
  .card .val{{font-size:28px;font-weight:700;}}
  .card .lbl{{font-size:11px;color:#888;text-transform:uppercase;margin-top:4px;}}
  .card.healthy .val{{color:#2ea043;}}
  .card.warning .val{{color:#d29922;}}
  .card.error .val{{color:#f85149;}}
  h2{{font-size:15px;font-weight:600;margin-bottom:12px;border-bottom:1px solid #3c3c3c;padding-bottom:6px;}}
  table{{width:100%;border-collapse:collapse;font-size:13px;}}
  thead tr{{background:#252526;}}
  thead th{{padding:8px 12px;text-align:left;font-size:11px;text-transform:uppercase;color:#888;border-bottom:1px solid #3c3c3c;}}
  tbody tr{{border-bottom:1px solid #2d2d2d;}}
  tbody tr:hover{{background:#2a2a2a;}}
  section{{margin-bottom:32px;}}
</style>
</head>
<body>
<h1>Image Validation — {project_dir.name}</h1>
<p class="meta">Generated: {generated_at} &nbsp;|&nbsp; Project: {str(project_dir).replace(chr(92),'/')}</p>

<div class="summary">
  <div class="card"><div class="val">{s['totalClusters']}</div><div class="lbl">Groups</div></div>
  <div class="card"><div class="val">{s['totalImages']}</div><div class="lbl">Images</div></div>
  <div class="card healthy"><div class="val">{s['healthyClusters']}</div><div class="lbl">Healthy</div></div>
  <div class="card warning"><div class="val">{s['warningClusters']}</div><div class="lbl">Warning</div></div>
  <div class="card error"><div class="val">{s['errorClusters']}</div><div class="lbl">Error</div></div>
</div>

{"<section><h2>Top Issues</h2><table><thead><tr><th>#</th><th>Group</th><th>Type</th><th>Description</th><th>Images</th></tr></thead><tbody>" + top_rows + "</tbody></table></section>" if top_rows else ""}

<section>
<h2>Groups</h2>
<table>
  <thead><tr><th>Group</th><th>Status</th><th>Images</th><th>Issues</th></tr></thead>
  <tbody>{''.join(cluster_rows)}</tbody>
</table>
</section>

<script>
window.__IMAGE_VALIDATION_DATA__ = {json.dumps(payload, ensure_ascii=False)};
</script>
</body>
</html>"""

    out_path.write_text(html, encoding="utf-8")

    # (M-14) Write timestamped history snapshot alongside the stable latest pointer.
    # The extension reads image-validation.html (stable); snapshots are for audit trail only.
    try:
        import time as _time

        _snap_ts = _time.strftime("%Y%m%d_%H%M%S")
        _snap_path = out_dir / f"image-validation-{_snap_ts}.html"
        _snap_path.write_text(html, encoding="utf-8")
    except Exception:
        pass  # non-fatal; stable latest was already written

    return out_path


def _empty_payload(project_dir: Path, now_iso: str) -> Dict[str, Any]:
    return {
        "source": "real",
        "project_root": str(project_dir).replace("\\", "/"),
        "generated_at": now_iso,
        "clusters": [],
        "summary": {
            "totalClusters": 0,
            "totalImages": 0,
            "totalGoldset": 0,
            "healthyClusters": 0,
            "warningClusters": 0,
            "errorClusters": 0,
        },
        "topIssues": [],
        "details": {},
    }
