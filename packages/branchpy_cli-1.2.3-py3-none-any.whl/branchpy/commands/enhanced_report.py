#!/usr/bin/env python3
"""
Enhanced Report Formatter for BranchPy
Provides user-friendly, categorized error reporting with clear explanations.
"""

import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

# Rule ID explanations
RULE_EXPLANATIONS = {
    # Critical Code Errors
    "C02-001": "Quote Syntax Error - Mismatched or unclosed quotes in dialogue",
    "V01-001": "Undefined Variable - Variable used before being defined",
    "C01-001": "Undefined Character - Character used in dialogue but not defined",
    "C01-002": "Character Redefinition - Character defined multiple times",
    # Asset Errors
    "missing_image_file": "Missing Image Asset - Image referenced but file not found",
    "missing_audio_file": "Missing Audio Asset - Audio file referenced but not found",
    "asset_name_typo": "Asset Name Typo - Similar asset name exists (possible typo)",
    # Quality Warnings
    "C04-001": "Dialogue Quality - Long dialogue line (consider splitting)",
    "V01-002": "Unused Variable - Variable assigned but never used (dead code)",
    "V01-003": "Possible Typo - Variable name similar to another (Levenshtein distance)",
    "C02-002": "Unattributed Dialogue - Text not bound to a character",
    "V02-001": "Unsafe Persistent Write - Persistent variable modified without version guard",
    "V02-002": "Untracked Persistent - Persistent variable without save version tracking",
    "unused_label": "Unused Label - Label defined but never called or jumped to",
    "C01-003": "Unused Character - Character defined but never used in dialogue",
    "shadow_builtins": "Shadows Builtin - Variable name conflicts with Ren'Py/Python builtin",
    # Info
    "C04-003": "Dialogue Info - General dialogue information",
}


def categorize_errors(validation_items: List[Dict]) -> Dict[str, List[Dict]]:
    """Categorize validation items by type."""
    categories = {
        "critical_code": [],
        "missing_assets": [],
        "quality_warnings": [],
        "info": [],
    }

    for item in validation_items:
        rule_id = item.get("rule_id", "")
        severity = item.get("severity", "info")

        # Critical code errors
        if (
            rule_id in ["C02-001", "V01-001", "C01-001", "C01-002"]
            and severity == "error"
        ):
            categories["critical_code"].append(item)
        # Missing assets
        elif (
            rule_id in ["missing_image_file", "missing_audio_file", "asset_name_typo"]
            and severity == "error"
        ):
            categories["missing_assets"].append(item)
        # Quality warnings
        elif severity == "warning":
            categories["quality_warnings"].append(item)
        # Info
        else:
            categories["info"].append(item)

    return categories


def print_header(text: str, char: str = "═"):
    """Print a formatted header."""
    width = 100
    print("\n" + char * width)
    print(f"{text}")
    print(char * width)


def print_section(title: str, emoji: str, count: int):
    """Print section header with emoji and count."""
    print(f"\n{emoji} {title}: {count}")
    print("─" * 100)


def format_enhanced_report(report_path: str):
    """Generate enhanced, user-friendly report."""

    # Load report
    with open(report_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    validation_items = data.get("validation", [])
    summary = data.get("summary", {})

    # Categorize
    categories = categorize_errors(validation_items)

    # Count by severity
    error_count = sum(1 for item in validation_items if item.get("severity") == "error")
    warning_count = sum(
        1 for item in validation_items if item.get("severity") == "warning"
    )
    info_count = sum(1 for item in validation_items if item.get("severity") == "info")

    # Print header
    print_header("🎯 BRANCHPY ANALYSIS REPORT", "═")

    print(f"\n📊 Project: {data.get('project_root', '.')}")
    print(f"📅 Generated: {data.get('generated_at', 'N/A')}")
    print(f"⚙️  Version: {data.get('version', 'N/A')}")

    # Summary metrics
    dialogue_metrics = summary.get("dialogue_metrics", {})
    if dialogue_metrics:
        print(
            f"\n📖 Dialogue: {dialogue_metrics.get('dialogue_count', 0)} lines, "
            f"{dialogue_metrics.get('unique_characters', 0)} characters"
        )

    # ===== CRITICAL CODE ERRORS =====
    critical_code = categories["critical_code"]
    print_section("🔴 CRITICAL CODE ERRORS (Must Fix)", "🔴", len(critical_code))

    if critical_code:
        # Group by rule
        by_rule = defaultdict(list)
        for item in critical_code:
            by_rule[item.get("rule_id", "unknown")].append(item)

        for rule_id, items in sorted(by_rule.items(), key=lambda x: -len(x[1])):
            explanation = RULE_EXPLANATIONS.get(rule_id, "Unknown error type")
            print(f"\n  ✗ {rule_id}: {explanation}")
            print(f"    Count: {len(items)} errors")

            # Show first 3 examples
            for i, item in enumerate(items[:3], 1):
                file = item.get("file", "unknown")
                line = item.get("line", 0)
                msg = item.get("message", "")
                print(f"      {i}. {file}:{line} - {msg}")

            if len(items) > 3:
                print(f"      ... and {len(items) - 3} more")
    else:
        print("  ✅ No critical code errors found!")

    # ===== MISSING ASSETS =====
    missing_assets = categories["missing_assets"]
    print_section("📦 MISSING ASSETS (Add Files)", "📦", len(missing_assets))

    if missing_assets:
        # Group by rule
        by_rule = defaultdict(list)
        for item in missing_assets:
            by_rule[item.get("rule_id", "unknown")].append(item)

        for rule_id, items in sorted(by_rule.items(), key=lambda x: -len(x[1])):
            explanation = RULE_EXPLANATIONS.get(rule_id, "Unknown asset type")
            print(f"\n  ⚠ {rule_id}: {explanation}")
            print(f"    Count: {len(items)} missing")

            # Show first 5 examples
            for i, item in enumerate(items[:5], 1):
                file = item.get("file", "unknown")
                line = item.get("line", 0)
                msg = item.get("message", "")
                print(f"      {i}. {file}:{line} - {msg}")

            if len(items) > 5:
                print(f"      ... and {len(items) - 5} more")
    else:
        print("  ✅ All assets found!")

    # ===== QUALITY WARNINGS =====
    quality_warnings = categories["quality_warnings"]
    print_section(
        "⚠️  QUALITY WARNINGS (Review Recommended)", "⚠️", len(quality_warnings)
    )

    if quality_warnings:
        # Group by rule
        by_rule = defaultdict(list)
        for item in quality_warnings:
            by_rule[item.get("rule_id", "unknown")].append(item)

        # Show top 5 warning types
        top_warnings = sorted(by_rule.items(), key=lambda x: -len(x[1]))[:5]

        for rule_id, items in top_warnings:
            explanation = RULE_EXPLANATIONS.get(rule_id, "Quality issue")
            print(f"\n  • {rule_id}: {explanation}")
            print(f"    Count: {len(items)} warnings")

            # Special note for important ones
            if rule_id == "V01-003":
                print("    ⭐ IMPORTANT: Review these - they often catch real bugs!")
            elif rule_id in ["V02-001", "V02-002"]:
                print(
                    "    ⭐ IMPORTANT: Consider adding version guards for save compatibility"
                )

        if len(by_rule) > 5:
            remaining = sum(len(items) for rule_id, items in list(by_rule.items())[5:])
            print(
                f"\n  ... and {remaining} more warnings in {len(by_rule) - 5} other categories"
            )
    else:
        print("  ✅ No quality warnings!")

    # ===== SUMMARY =====
    print_header("📈 SUMMARY", "═")

    critical_count = len(critical_code)
    asset_count = len(missing_assets)

    print(f"\n🔴 Critical Code Errors: {critical_count}")
    print(f"📦 Missing Assets: {asset_count}")
    print(f"⚠️  Quality Warnings: {warning_count}")
    print(f"ℹ️  Info Items: {info_count}")
    print(f"\n{'─' * 100}")
    print(f"Total Issues: {len(validation_items)}")

    # Action items
    print(f"\n{'═' * 100}")
    print("🎯 NEXT ACTIONS")
    print(f"{'═' * 100}")

    if critical_count > 0:
        print(f"\n1. 🔴 Fix {critical_count} critical code errors first")

    if asset_count > 0:
        print(
            f"\n2. 📦 Add {asset_count} missing asset files (or use placeholders for WIP)"
        )

    if warning_count > 0:
        print(
            f"\n3. ⚠️  Review {warning_count} quality warnings (especially V01-003 typo warnings)"
        )

    if critical_count == 0 and asset_count == 0:
        print("\n✅ Great job! No critical errors or missing assets!")
        if warning_count > 0:
            print(
                f"   Consider addressing the {warning_count} quality warnings to improve code quality."
            )
        else:
            print("   Your code is clean!")

    print(f"\n{'═' * 100}\n")

    return 0 if critical_count == 0 else 1


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("Usage: python enhanced_report.py <path_to_unified_report.json>")
        return 1

    report_path = sys.argv[1]

    if not Path(report_path).exists():
        print(f"Error: Report file not found: {report_path}")
        return 1

    return format_enhanced_report(report_path)


if __name__ == "__main__":
    sys.exit(main())
