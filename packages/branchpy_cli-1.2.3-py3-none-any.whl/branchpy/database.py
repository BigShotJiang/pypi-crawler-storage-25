"""
Database connection helper for BranchPy backend.

Provides PostgreSQL connection management using environment variables.
"""

import os

import psycopg2


def get_db_connection():
    """
    Create a PostgreSQL database connection.

    Reads configuration from environment variables:
    - BRANCHPY_DB_HOST (default: localhost)
    - BRANCHPY_DB_PORT (default: 5432)
    - BRANCHPY_DB_NAME (default: branchpy)
    - BRANCHPY_DB_USER (default: branchpy)
    - BRANCHPY_DB_PASSWORD (required)

    Returns:
        psycopg2 connection object

    Raises:
        Exception: If connection fails
    """
    conn = psycopg2.connect(
        host=os.getenv("BRANCHPY_DB_HOST", "localhost"),
        port=int(os.getenv("BRANCHPY_DB_PORT", "5432")),
        database=os.getenv("BRANCHPY_DB_NAME", "branchpy"),
        user=os.getenv("BRANCHPY_DB_USER", "branchpy"),
        password=os.getenv("BRANCHPY_DB_PASSWORD"),
    )
    return conn


def test_connection() -> bool:
    """
    Test database connection.

    Returns:
        True if connection successful, False otherwise
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Database connection failed: {e}")
        return False
