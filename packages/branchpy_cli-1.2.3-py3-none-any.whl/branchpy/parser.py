import os
import re
from collections import defaultdict

# Top-level patterns
LABEL_DEF_RE = re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:\s*$", re.MULTILINE)
DEFINE_RE = re.compile(r"^\s*(default|define)\s+([A-Za-z_]\w*)\s*=", re.MULTILINE)

# In-block patterns (searched inside each label body)
JUMP_RE = re.compile(r"^\s*jump\s+([A-Za-z_]\w*)\s*$", re.MULTILINE)
CALL_RE = re.compile(r"^\s*call\s+([A-Za-z_]\w*)\s*$", re.MULTILINE)
RETURN_RE = re.compile(r"^\s*return\b", re.MULTILINE)
MENU_LINE_RE = re.compile(r"^\s*menu\s*:\s*$", re.MULTILINE)


def _read_text(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except UnicodeDecodeError:
        with open(path, encoding="latin-1") as f:
            return f.read()


def _iter_labels_with_bodies(text):
    """
    Yields (label_name, start_idx, end_idx) for each label and the slice of its body.
    The body spans from the line after 'label X:' to just before the next label (or EOF).
    """
    matches = list(LABEL_DEF_RE.finditer(text))
    for i, m in enumerate(matches):
        name = m.group(1)
        body_start = m.end()
        body_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        yield name, body_start, body_end


def scan_project(root_path: str):
    files_scanned = []
    # Global maps/sets
    labels_to_file = {}
    vars_defined = defaultdict(list)

    # Per-label details
    label_details = (
        {}
    )  # name -> dict(body_outgoing_jumps, body_outgoing_calls, has_return, has_menu, file)

    # Global tallies
    all_jumps = []
    all_calls = []

    for r, _, files in os.walk(root_path):
        for fn in files:
            if not fn.endswith(".rpy"):
                continue
            full = os.path.join(r, fn)
            files_scanned.append(full)
            text = _read_text(full)

            # Track label definitions first
            for name in LABEL_DEF_RE.findall(text):
                labels_to_file[name] = full

            # Variables
            for _, var in DEFINE_RE.findall(text):
                vars_defined[var].append(full)

            # Per-label body analysis
            for name, s, e in _iter_labels_with_bodies(text):
                body = text[s:e]
                jumps = JUMP_RE.findall(body)
                calls = CALL_RE.findall(body)
                has_return = bool(RETURN_RE.search(body))
                has_menu = bool(MENU_LINE_RE.search(body))

                label_details[name] = {
                    "file": full,
                    "body_outgoing_jumps": jumps,
                    "body_outgoing_calls": calls,
                    "has_return": has_return,
                    "has_menu": has_menu,
                }

                all_jumps.extend(jumps)
                all_calls.extend(calls)

    # Derived checks
    missing_jump_targets = sorted({t for t in all_jumps if t not in labels_to_file})
    missing_call_targets = sorted({t for t in all_calls if t not in labels_to_file})

    # Orphans: defined but never referenced by jump/call (start is allowed to have no inbound)
    orphan_labels = sorted(
        [
            lb
            for lb in labels_to_file
            if lb not in all_jumps and lb not in all_calls and lb != "start"
        ]
    )

    # Dead-ends: labels with no jump/call/return/menu in their body.
    dead_end_labels = sorted(
        [
            lb
            for lb, info in label_details.items()
            if not info["body_outgoing_jumps"]
            and not info["body_outgoing_calls"]
            and not info["has_return"]
            and not info["has_menu"]
        ]
    )

    # Called-without-return: labels that are called at least once but never contain a 'return'
    called_without_return = sorted(
        [
            lb
            for lb, info in label_details.items()
            if info["body_outgoing_calls"] or lb in set(all_calls)
            if not info["has_return"]
        ]
    )

    # Duplicate variable definitions
    duplicate_vars = {v: files for v, files in vars_defined.items() if len(files) > 1}

    # Menu edges (for each label, list the jump targets found within its body)
    menu_edges = {
        lb: info["body_outgoing_jumps"]
        for lb, info in label_details.items()
        if info["has_menu"] and info["body_outgoing_jumps"]
    }

    results = {
        "files_scanned": files_scanned,
        "labels": labels_to_file,  # label -> file
        "label_details": label_details,  # per-label metadata
        "jumps": all_jumps,
        "calls": all_calls,
        "menu_edges": menu_edges,  # label -> [targets]
        "missing_jump_targets": missing_jump_targets,
        "missing_call_targets": missing_call_targets,
        "orphan_labels": orphan_labels,
        "dead_end_labels": dead_end_labels,
        "called_without_return": called_without_return,
        "vars_defined": dict(vars_defined),
        "duplicate_vars": duplicate_vars,
        "summary": {
            "files": len(files_scanned),
            "labels": len(labels_to_file),
            "jumps": len(all_jumps),
            "calls": len(all_calls),
            "menus_with_targets": len(menu_edges),
            "missing_jump_targets": len(missing_jump_targets),
            "missing_call_targets": len(missing_call_targets),
            "orphan_labels": len(orphan_labels),
            "dead_end_labels": len(dead_end_labels),
            "called_without_return": len(called_without_return),
            "vars_defined": sum(len(v) for v in vars_defined.values()),
            "duplicate_vars": len(duplicate_vars),
        },
    }
    return results
