"""
BranchPy Media Intelligence - Core Data Structures and Extraction Framework
Version: v0.9.0

This module defines the canonical media reference schema and extraction framework
for the Media Intelligence feature. It provides:

- MediaRef dataclass: The authoritative media reference structure
- Enums for engine, kind, action, confidence
- Base extraction infrastructure
- Config support via .branchpy.toml [media] section

Phase A: Ren'Py MVP (images, audio, video, displayables)
Phase B: PFI inference (via_function tracking)
Phase C: Engine-agnostic (Unity, Godot, generic)
Phase D: Validation & UX enhancements

Data Contract:
This Python schema MUST stay in sync with TypeScript types/media.ts in vscode-addon.
Any changes to MediaRef structure require updates to both files.
"""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# ============================================================================
# ENUMS - Media Classification Types
# ============================================================================


class MediaEngine(str, Enum):
    """
    Engine type identifier
    Determines which analyzer/detector was used to extract the media reference
    """

    RENPY = "renpy"  # Ren'Py visual novel engine
    UNITY = "unity"  # Unity game engine (C#)
    GODOT = "godot"  # Godot game engine (GDScript)
    GENERIC = "generic"  # Fallback for unknown engines or file-based detection


class MediaKind(str, Enum):
    """
    Media kind/type classification
    Categories for different types of media assets
    """

    IMAGE = "image"  # Static images, sprites, backgrounds
    AUDIO = "audio"  # Sound effects, music, voice
    VIDEO = "video"  # Movie clips, cutscenes
    OTHER = "other"  # Other displayables (animations, composites, etc.)


class MediaAction(str, Enum):
    """
    Media action/operation
    What operation was performed with the media asset
    """

    DEFINE = "define"  # Definition/initialization (image statement, renpy.image, etc.)
    SHOW = "show"  # Display/show operation (scene, show, screen add)
    HIDE = "hide"  # Hide operation (hide statement, screen remove)
    PLAY = "play"  # Play audio/video
    STOP = "stop"  # Stop audio/video
    LOAD = "load"  # Load/preload operation
    ASSIGN = "assign"  # Variable assignment (e.g., sprite = load("path"))


class MediaConfidence(str, Enum):
    """
    Confidence level for media path resolution
    Indicates how certain we are about the media reference
    """

    EXACT = "exact"  # Literal string path, fully resolved
    DYNAMIC = "dynamic"  # Template/expression path (f-strings, .format(), etc.)
    INFERRED = "inferred"  # Inferred from call graph (PFI propagation)


# ============================================================================
# CORE DATA STRUCTURES
# ============================================================================


@dataclass
class MediaRef:
    """
    Media reference record - Core data structure for all media intelligence features

    This is the canonical schema - both Analyzer (Python) and Extension (TypeScript)
    must produce/consume this exact structure.

    All fields align 1:1 with the TypeScript MediaRef interface in types/media.ts.
    """

    # Identity
    id: str
    """
    Unique identifier for this media reference
    Format: hash(engine|source_file|source_line|kind|action|target|channel|path)
    Used for deduplication and cross-referencing
    """

    # Classification
    engine: MediaEngine
    """Engine that produced this media reference"""

    kind: MediaKind
    """Media type/category"""

    action: MediaAction
    """Operation performed with this media"""

    # Context
    channel: Optional[str] = None
    """
    Audio/video channel or None for images/other
    Examples: "music", "sound", "voice", "movie", "custom_sfx"
    """

    target: Optional[str] = None
    """
    Target layer, tag, screen, or component path
    Examples:
    - Ren'Py: "master" (layer), "eileen" (tag), "main_menu" (screen)
    - Unity: "GameObject/Canvas/Image" (component path)
    - Godot: "Node2D/Sprite2D" (node path)
    """

    # Source location
    source_file: str = ""
    """Source file where this media reference appears (relative path from project root)"""

    source_line: int = 0
    """Line number in source file (1-indexed)"""

    label: Optional[str] = None
    """Label/function where this media reference occurs (for flowchart integration)"""

    # Path resolution
    resolved_path: Optional[str] = None
    """
    Resolved absolute or relative path to media file
    None if path is dynamic/unresolved
    """

    template_path: Optional[str] = None
    """
    Template path for dynamic references
    Examples: "images/{character}.png", "audio/{bgm_name}.ogg"
    None for static paths
    """

    variables: List[str] = field(default_factory=list)
    """List of variable names used in template_path (empty for static paths)"""

    # PFI inference (Phase B)
    via_function: Optional[str] = None
    """
    Function name if media reference was inferred through call graph
    None for direct references
    """

    confidence: MediaConfidence = MediaConfidence.EXACT
    """Confidence level for this media reference"""

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary for JSON serialization
        Enum values are converted to their string representations
        """
        result = asdict(self)
        # Convert enums to strings
        result["engine"] = self.engine.value
        result["kind"] = self.kind.value
        result["action"] = self.action.value
        result["confidence"] = self.confidence.value
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MediaRef:
        """
        Create MediaRef from dictionary (for deserialization)
        String enum values are converted back to Enum instances
        """
        # Convert string values back to enums
        if isinstance(data.get("engine"), str):
            data["engine"] = MediaEngine(data["engine"])
        if isinstance(data.get("kind"), str):
            data["kind"] = MediaKind(data["kind"])
        if isinstance(data.get("action"), str):
            data["action"] = MediaAction(data["action"])
        if isinstance(data.get("confidence"), str):
            data["confidence"] = MediaConfidence(data["confidence"])

        return cls(**data)

    @staticmethod
    def generate_id(
        engine: MediaEngine,
        source_file: str,
        source_line: int,
        kind: MediaKind,
        action: MediaAction,
        target: Optional[str],
        channel: Optional[str],
        path: Optional[str],
    ) -> str:
        """
        Generate unique ID for a media reference
        Format: hash(engine|source_file|source_line|kind|action|target|channel|path)
        """
        components = [
            engine.value,
            source_file,
            str(source_line),
            kind.value,
            action.value,
            target or "",
            channel or "",
            path or "",
        ]
        hash_input = "|".join(components)
        return hashlib.md5(hash_input.encode("utf-8")).hexdigest()[:16]


@dataclass
class MediaSummary:
    """
    Media statistics/summary
    Aggregate counts for reporting and UI display
    """

    total: int = 0
    """Total media references found"""

    by_kind: Dict[str, int] = field(
        default_factory=lambda: {"image": 0, "audio": 0, "video": 0, "other": 0}
    )
    """Count by media kind"""

    by_action: Dict[str, int] = field(
        default_factory=lambda: {
            "define": 0,
            "show": 0,
            "hide": 0,
            "play": 0,
            "stop": 0,
            "load": 0,
            "assign": 0,
        }
    )
    """Count by action"""

    by_confidence: Dict[str, int] = field(
        default_factory=lambda: {"exact": 0, "dynamic": 0, "inferred": 0}
    )
    """Count by confidence"""

    unique_paths: int = 0
    """Unique resolved paths"""

    unique_templates: int = 0
    """Unique dynamic templates"""

    def add(self, media_ref: MediaRef) -> None:
        """Add a media reference to the summary statistics"""
        self.total += 1
        self.by_kind[media_ref.kind.value] += 1
        self.by_action[media_ref.action.value] += 1
        self.by_confidence[media_ref.confidence.value] += 1

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)


@dataclass
class MediaConfig:
    """
    Media configuration
    Settings for media extraction and analysis
    Loaded from .branchpy.toml [media] section
    """

    enabled: bool = True
    """Feature flag - enable media extraction"""

    screens_enabled: bool = True
    """Extract media from screen definitions"""

    pfi_inference_enabled: bool = False
    """Enable PFI inference for call graph propagation (Phase B)"""

    max_media_per_node: int = 200
    """Maximum media references per flowchart node"""

    extensions: Dict[str, List[str]] = field(
        default_factory=lambda: {
            "image": [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"],
            "audio": [".ogg", ".mp3", ".wav", ".opus", ".flac"],
            "video": [".webm", ".mp4", ".ogv", ".avi", ".mkv"],
        }
    )
    """File extensions to recognize as media"""

    channels: List[str] = field(
        default_factory=lambda: ["music", "sound", "voice", "movie"]
    )
    """Audio channels to track"""

    @classmethod
    def from_toml(cls, toml_dict: Dict[str, Any]) -> MediaConfig:
        """
        Create MediaConfig from TOML configuration

        Example .branchpy.toml:
        [media]
        enabled = true
        screens_enabled = true
        pfi_inference_enabled = false
        max_media_per_node = 200
        channels = ["music", "sound", "voice", "movie"]

        [media.extensions]
        image = [".png", ".jpg", ".jpeg", ".webp"]
        audio = [".ogg", ".mp3", ".wav"]
        video = [".webm", ".mp4"]
        """
        config = cls()

        if not toml_dict:
            return config

        # Simple fields
        config.enabled = toml_dict.get("enabled", config.enabled)
        config.screens_enabled = toml_dict.get(
            "screens_enabled", config.screens_enabled
        )
        config.pfi_inference_enabled = toml_dict.get(
            "pfi_inference_enabled", config.pfi_inference_enabled
        )
        config.max_media_per_node = toml_dict.get(
            "max_media_per_node", config.max_media_per_node
        )
        config.channels = toml_dict.get("channels", config.channels)

        # Extensions (nested dict)
        if "extensions" in toml_dict:
            ext_dict = toml_dict["extensions"]
            config.extensions["image"] = ext_dict.get(
                "image", config.extensions["image"]
            )
            config.extensions["audio"] = ext_dict.get(
                "audio", config.extensions["audio"]
            )
            config.extensions["video"] = ext_dict.get(
                "video", config.extensions["video"]
            )

        return config


# ============================================================================
# EXTRACTION FRAMEWORK - Base Classes
# ============================================================================


class MediaExtractor:
    """
    Base class for media extractors
    Subclasses implement engine-specific extraction logic

    Phase A: RenpyMediaExtractor (Ren'Py MVP)
    Phase C: UnityMediaExtractor, GodotMediaExtractor, GenericMediaExtractor
    """

    def __init__(self, config: MediaConfig):
        self.config = config
        self.media_refs: List[MediaRef] = []
        self.summary = MediaSummary()

    def extract(self, project_path: Path) -> List[MediaRef]:
        """
        Extract media references from project
        Must be implemented by subclasses

        Returns:
            List of MediaRef objects
        """
        raise NotImplementedError("Subclasses must implement extract()")

    def add_media_ref(self, media_ref: MediaRef) -> None:
        """Add a media reference to the collection"""
        self.media_refs.append(media_ref)
        self.summary.add(media_ref)

    def get_summary(self) -> MediaSummary:
        """Get aggregate statistics"""
        # Update unique counts
        unique_paths: Set[str] = set()
        unique_templates: Set[str] = set()

        for ref in self.media_refs:
            if ref.resolved_path:
                unique_paths.add(ref.resolved_path)
            if ref.template_path:
                unique_templates.add(ref.template_path)

        self.summary.unique_paths = len(unique_paths)
        self.summary.unique_templates = len(unique_templates)

        return self.summary


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================


def is_media_file(file_path: str, config: MediaConfig) -> Optional[MediaKind]:
    """
    Check if a file path refers to a media file

    Args:
        file_path: Path to check
        config: Media configuration with extension lists

    Returns:
        MediaKind if recognized, None otherwise
    """
    path_lower = file_path.lower()

    for ext in config.extensions["image"]:
        if path_lower.endswith(ext):
            return MediaKind.IMAGE

    for ext in config.extensions["audio"]:
        if path_lower.endswith(ext):
            return MediaKind.AUDIO

    for ext in config.extensions["video"]:
        if path_lower.endswith(ext):
            return MediaKind.VIDEO

    return None


def detect_dynamic_path(path_str: str) -> tuple[bool, Optional[str], List[str]]:
    """
    Detect if a path contains dynamic components (f-strings, .format(), % formatting)

    Args:
        path_str: Path string to analyze

    Returns:
        Tuple of (is_dynamic, template_path, variable_names)

    Examples:
        "images/bg.png" -> (False, None, [])
        f"images/{char}.png" -> (True, "images/{char}.png", ["char"])
        "images/{}.png".format(name) -> (True, "images/{}.png", ["name"])
        "images/%s.png" % var -> (True, "images/%s.png", ["var"])
    """
    import re

    # Check for placeholders: {}, {0}, {name}, %s, %d, etc.
    # Pattern 1: {} or {name} style (f-string or .format())
    bracket_pattern = re.compile(r"\{([A-Za-z_]\w*)?\}")
    bracket_matches = bracket_pattern.findall(path_str)

    if bracket_matches:
        # Found bracket-style placeholders
        template = path_str
        # Filter out empty strings (positional {})
        variables = [v for v in bracket_matches if v]
        return (True, template, variables)

    # Pattern 2: % formatting (%s, %d, %(name)s, etc.)
    percent_pattern = re.compile(r"%(?:\(([A-Za-z_]\w*)\)[sd]|[sd])")
    percent_matches = percent_pattern.findall(path_str)

    if percent_matches or "%s" in path_str or "%d" in path_str:
        # Found percent-style placeholders
        template = path_str
        # Extract named placeholders, or use empty list for positional %s/%d
        variables = [v for v in percent_matches if v]
        return (True, template, variables)

    # No dynamic components found
    return (False, None, [])


def merge_media_refs(refs: List[MediaRef], max_per_node: int = 200) -> List[MediaRef]:
    """
    Merge and deduplicate media references
    Limit to max_per_node to prevent memory issues

    Sorting order:
    1. action: define → show → play
    2. kind: image → audio → video → other
    3. source_line: ascending

    Args:
        refs: List of MediaRef objects (may contain duplicates)
        max_per_node: Maximum references to keep

    Returns:
        Deduplicated and sorted list of MediaRef objects
    """
    # Deduplicate by ID
    seen_ids: Set[str] = set()
    unique_refs: List[MediaRef] = []

    for ref in refs:
        if ref.id not in seen_ids:
            seen_ids.add(ref.id)
            unique_refs.append(ref)

    # Define sort order
    action_order = {
        MediaAction.DEFINE: 0,
        MediaAction.SHOW: 1,
        MediaAction.PLAY: 2,
        MediaAction.HIDE: 3,
        MediaAction.STOP: 4,
        MediaAction.LOAD: 5,
        MediaAction.ASSIGN: 6,
    }

    kind_order = {
        MediaKind.IMAGE: 0,
        MediaKind.AUDIO: 1,
        MediaKind.VIDEO: 2,
        MediaKind.OTHER: 3,
    }

    # Sort
    unique_refs.sort(
        key=lambda r: (
            action_order.get(r.action, 99),
            kind_order.get(r.kind, 99),
            r.source_line,
        )
    )

    # Limit to max_per_node
    return unique_refs[:max_per_node]
