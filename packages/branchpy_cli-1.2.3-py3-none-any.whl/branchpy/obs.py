# branchpy/obs.py
from __future__ import annotations

import json
import os
import platform
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


# ---------- portable state locations ----------
def _state_root() -> Path:
    # 1) explicit override
    override = os.getenv("BRANCHPY_STATE_DIR")
    if override:
        return Path(override)
    # 2) portable mode (env) or if repo-local .branchpy exists
    portable = os.getenv("BRANCHPY_PORTABLE") == "1"
    repo_dot = Path.cwd() / ".branchpy"
    if portable or repo_dot.exists():
        return repo_dot
    # 3) OS state dir
    if os.name == "nt":
        root = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return root / "BranchPy"
    xdg = os.getenv("XDG_STATE_HOME")
    if xdg:
        return Path(xdg) / "BranchPy"
    return Path.home() / ".local" / "state" / "BranchPy"


_STATE = _state_root()
_LOG_DIR = _STATE / "logs"
_LOG_FILE = _LOG_DIR / "action.log.jsonl"
_INSTALL_ID_FILE = _STATE / "install_id"


# ---------- basics ----------
def _ensure_dirs() -> None:
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    _STATE.mkdir(parents=True, exist_ok=True)


def _now_iso() -> str:
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def _read_install_id() -> str:
    _ensure_dirs()
    if not _INSTALL_ID_FILE.exists():
        _INSTALL_ID_FILE.write_text(str(uuid.uuid4()), encoding="utf-8")
    return _INSTALL_ID_FILE.read_text(encoding="utf-8").strip()


def _version() -> str:
    try:
        import branchpy  # type: ignore

        return getattr(
            branchpy, "__version__", getattr(branchpy, "VERSION", "0.0.0")
        )  # fallback
    except Exception:
        return "0.0.0"


def _redact_path(p: Optional[str]) -> Optional[str]:
    if not p:
        return p
    try:
        home = str(Path.home())
        cwd = os.getcwd()
        return p.replace(home, "${HOME}").replace(cwd, "${WORKSPACE}")
    except Exception:
        return p


# --------- simple size-based rotation (default ~5 MB) ----------
def _rotate_if_big(max_bytes: int = 5_000_000, keep_backups: int = 2) -> None:
    try:
        if not _LOG_FILE.exists() or _LOG_FILE.stat().st_size < max_bytes:
            return
        # rotate: action.log.jsonl -> action.log.1.jsonl -> action.log.2.jsonl
        for idx in range(keep_backups, 0, -1):
            older = _LOG_DIR / f"action.log.{idx}.jsonl"
            newer = _LOG_DIR / f"action.log.{idx-1}.jsonl" if idx > 1 else _LOG_FILE
            if older.exists():
                older.unlink(missing_ok=True)
            if newer.exists():
                newer.rename(older)
    except Exception:
        # never crash the caller on rotation
        pass


# ---------- public api ----------
@dataclass
class Event:
    ts: str
    event: str
    level: str
    install_id: str
    version: str
    platform: Dict[str, str]
    cwd: str
    operation_id: Optional[str] = None
    patch_id: Optional[str] = None
    exit_code: Optional[int] = None
    payload: Dict[str, Any] = field(default_factory=dict)


def emit(
    event_type: str,
    payload: Optional[Dict[str, Any]] = None,
    *,
    operation_id: Optional[str] = None,
    patch_id: Optional[str] = None,
    level: str = "info",
    exit_code: Optional[int] = None,
) -> None:
    """Write a single JSONL event to the local action log."""
    _ensure_dirs()
    _rotate_if_big()
    rec = Event(
        ts=_now_iso(),
        event=event_type,
        level=level,
        install_id=_read_install_id(),
        version=_version(),
        platform={"system": platform.system(), "release": platform.release()},
        cwd=_redact_path(os.getcwd()) or "",
        operation_id=operation_id,
        patch_id=patch_id,
        exit_code=exit_code,
        payload=payload or {},
    )
    # final redaction pass on any obvious path-like strings inside payload
    try:
        redacted = json.loads(json.dumps(asdict(rec), ensure_ascii=False, default=str))

        def _scrub(obj: Any) -> Any:
            if isinstance(obj, str) and ("/" in obj or "\\" in obj):
                return _redact_path(obj) or obj
            if isinstance(obj, dict):
                return {k: _scrub(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_scrub(v) for v in obj]
            return obj

        redacted = _scrub(redacted)
    except Exception:
        redacted = asdict(rec)

    with _LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(redacted, ensure_ascii=False) + "\n")


def start_operation(kind: str, meta: Optional[Dict[str, Any]] = None) -> str:
    op_id = str(uuid.uuid4())
    emit(f"{kind}.start", payload=meta or {}, operation_id=op_id)
    return op_id


def end_operation(
    op_id: str,
    kind: str,
    *,
    status: str = "ok",
    meta: Optional[Dict[str, Any]] = None,
    exit_code: Optional[int] = None,
) -> None:
    payload = {"status": status}
    if meta:
        payload.update(meta)
    emit(f"{kind}.end", payload=payload, operation_id=op_id, exit_code=exit_code)
