# branchpy/bootstrap.py
import sys
from pathlib import Path

from .update_manager import attempt_atomic_swap


def boot():
    # Must be called as early as possible in __main__.py
    try:
        attempt_atomic_swap()
    except Exception:
        # Log but don't crash startup; main CLI can still run on previous binary
        # (Your logger here)
        pass


def current_binary() -> Path:
    # Nuitka single-file or Python module run
    return Path(sys.argv[0]).resolve()
