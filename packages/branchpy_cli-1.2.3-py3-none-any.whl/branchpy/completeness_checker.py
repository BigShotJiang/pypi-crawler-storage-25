"""
Completeness Checker
Phase 5: Story Structure & Completeness Validation - R02 Rules

Implements:
- R02-001: Missing Endings
- R02-002: Unfinished Branches
- R02-003: Missing Transitions
- R02-004: Story Coverage (metric)
"""

import re
from typing import Any, Dict, List, Optional, Set, Tuple

from branchpy.story_graph import (
    CompletenessResult,
    ReachabilityResult,
    StoryArc,
    StoryGraph,
)


class CompletenessChecker:
    """
    Analyzes story graph for completeness issues.

    Verifies that all story arcs reach proper endings and that
    branches are properly resolved.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    def analyze(
        self, graph: StoryGraph, reachability: ReachabilityResult
    ) -> CompletenessResult:
        """
        Run complete story completeness analysis.

        Args:
            graph: Story graph to analyze
            reachability: Reachability analysis results

        Returns:
            Complete completeness analysis results
        """
        # Find all terminal/ending labels
        terminal_labels = self.find_terminal_labels(graph)

        # Check which endings are unreachable
        unreachable_terminals = terminal_labels - reachability.reachable_labels

        # Find unfinished branches
        unfinished_branches = self.find_unfinished_branches(
            graph, reachability.reachable_labels
        )

        # Detect missing transitions (chapter sequencing)
        missing_transitions = self.find_missing_transitions(graph)

        # Analyze story arcs (if configured)
        arcs = self.analyze_story_arcs(graph, reachability.reachable_labels)

        # Build result
        result = CompletenessResult(
            total_arcs=len(arcs),
            complete_arcs=sum(1 for arc in arcs if arc.is_complete),
            incomplete_arcs=[arc for arc in arcs if not arc.is_complete],
            missing_endings=list(unreachable_terminals),
            unfinished_branches=unfinished_branches,
            missing_transitions=missing_transitions,
            terminal_labels=terminal_labels,
            unreachable_terminals=unreachable_terminals,
        )

        return result

    def find_terminal_labels(self, graph: StoryGraph) -> Set[str]:
        """
        Identify all intended ending/terminal labels.

        Uses multiple heuristics:
        1. Labels with ending keywords in name
        2. Labels with return and no outgoing edges
        3. Explicitly configured endings

        Args:
            graph: Story graph

        Returns:
            Set of terminal label names
        """
        terminals = set()

        # Get explicitly configured endings
        expected_endings = self.config.get("expected_endings", [])
        terminals.update(expected_endings)

        # Heuristic 1: Keyword detection
        ending_keywords = [
            "end",
            "ending",
            "finale",
            "conclusion",
            "epilogue",
            "credits",
            "gameover",
            "game_over",
        ]

        for label_name in graph.get_all_labels():
            label_lower = label_name.lower()

            # Check for ending keywords
            if any(keyword in label_lower for keyword in ending_keywords):
                terminals.add(label_name)

        # Heuristic 2: Return with no outgoing edges
        # BUT: Exclude subroutines (labels with incoming RETURN edges)
        for label_name, node in graph.nodes.items():
            if node.has_return and len(graph.get_successors(label_name)) == 0:
                # Check if this label has incoming RETURN edges (i.e., it's called)
                from branchpy.story_graph import EdgeType

                incoming_edges = graph.get_incoming_edges(label_name)
                has_return_callers = any(
                    e.edge_type == EdgeType.RETURN for e in incoming_edges
                )

                # Only mark as terminal if it's NOT a subroutine
                if not has_return_callers:
                    terminals.add(label_name)

        return terminals

    def find_unfinished_branches(
        self, graph: StoryGraph, reachable: Set[str]
    ) -> List[str]:
        """
        Find story branches that end without proper resolution.

        A branch is unfinished if:
        - It's reachable
        - It's identified as a branch (by naming or context)
        - It has no outgoing edges
        - It's not a terminal/ending label

        Args:
            graph: Story graph
            reachable: Set of reachable labels

        Returns:
            List of unfinished branch label names
        """
        if not self.config.get("check_unfinished_branches", True):
            return []

        unfinished = []
        terminals = self.find_terminal_labels(graph)

        # Branch indicators in label names
        branch_keywords = ["path", "route", "branch", "choice", "option"]

        for label_name in reachable:
            # Skip terminal labels
            if label_name in terminals:
                continue

            node = graph.get_label(label_name)
            if not node:
                continue

            # Check if this looks like a branch label
            is_branch = any(
                keyword in label_name.lower() for keyword in branch_keywords
            )

            # Check if it has no resolution
            has_no_exit = (
                len(graph.get_successors(label_name)) == 0
                and not node.has_return
                and not node.has_jump
            )

            if is_branch and has_no_exit:
                unfinished.append(label_name)

        return unfinished

    def find_missing_transitions(self, graph: StoryGraph) -> List[Tuple[str, str]]:
        """
        Detect missing transitions between sequential chapters/labels.

        Looks for patterns like:
        - chapter1 → should transition to chapter2
        - scene_1 → should transition to scene_2

        Args:
            graph: Story graph

        Returns:
            List of (from_label, expected_to_label) tuples
        """
        missing = []

        # Pattern: chapter/scene numbering
        chapter_pattern = re.compile(r"(chapter|scene|part|act)_?(\d+)", re.IGNORECASE)

        for label_name in graph.get_all_labels():
            match = chapter_pattern.search(label_name)

            if match:
                prefix = match.group(1)
                number = int(match.group(2))

                # Construct expected next label
                expected_next = f"{prefix}_{number + 1}"

                # Check if next chapter exists but is not reachable from current
                if graph.has_label(expected_next):
                    successors = graph.get_successors(label_name)

                    if expected_next not in successors:
                        missing.append((label_name, expected_next))

        return missing

    def analyze_story_arcs(
        self, graph: StoryGraph, reachable: Set[str]
    ) -> List[StoryArc]:
        """
        Analyze completeness of defined story arcs.

        Story arcs are identified by naming patterns or configuration.

        Args:
            graph: Story graph
            reachable: Set of reachable labels

        Returns:
            List of analyzed story arcs
        """
        arcs = []

        # Detect common arc patterns
        arc_patterns = {
            "main": r"(main|story|chapter)",
            "romance": r"romance",
            "friendship": r"friend",
            "mystery": r"mystery",
            "combat": r"(fight|combat|battle)",
        }

        for arc_name, pattern in arc_patterns.items():
            arc_labels = self._find_arc_labels(graph, pattern)

            if arc_labels:
                # Find potential endings for this arc
                expected_endings = self._find_arc_endings(graph, arc_name)

                # Check which endings are reachable
                reachable_endings = set(expected_endings) & reachable

                # Find start label with safe null handling
                def get_label_line(label_name: str) -> int:
                    label_node = graph.get_label(label_name)
                    return label_node.location.line if label_node else 0

                arc = StoryArc(
                    arc_name=arc_name,
                    start_label=min(arc_labels, key=get_label_line),
                    expected_end_labels=expected_endings,
                    labels_in_arc=arc_labels,
                    is_complete=len(reachable_endings) > 0,
                    missing_endings=[e for e in expected_endings if e not in reachable],
                    reachable_endings=reachable_endings,
                )

                arcs.append(arc)

        return arcs

    def _find_arc_labels(self, graph: StoryGraph, pattern: str) -> Set[str]:
        """Find all labels matching an arc pattern"""
        arc_labels = set()
        regex = re.compile(pattern, re.IGNORECASE)

        for label_name in graph.get_all_labels():
            if regex.search(label_name):
                arc_labels.add(label_name)

        return arc_labels

    def _find_arc_endings(self, graph: StoryGraph, arc_name: str) -> List[str]:
        """Find expected ending labels for a story arc"""
        endings = []

        # Common ending naming patterns
        ending_patterns = [
            f"{arc_name}_ending",
            f"{arc_name}_end",
            f"ending_{arc_name}",
            f"end_{arc_name}",
            f"{arc_name}_good_ending",
            f"{arc_name}_bad_ending",
        ]

        for pattern in ending_patterns:
            if graph.has_label(pattern):
                endings.append(pattern)

        # Also check terminals that mention the arc name
        terminals = self.find_terminal_labels(graph)
        for terminal in terminals:
            if arc_name.lower() in terminal.lower():
                endings.append(terminal)

        return list(set(endings))  # Remove duplicates

    def verify_arc_completion(
        self, graph: StoryGraph, arc_labels: List[str], reachable: Set[str]
    ) -> Dict[str, bool]:
        """
        Verify if story arcs reach proper endings.

        Args:
            graph: Story graph
            arc_labels: Labels belonging to the arc
            reachable: Set of reachable labels from start

        Returns:
            Dictionary mapping arc label to completion status
        """
        results = {}
        terminals = self.find_terminal_labels(graph)

        for arc_label in arc_labels:
            if arc_label not in reachable:
                results[arc_label] = False
                continue

            # Check if any terminal is reachable from this arc label
            from branchpy.reachability_analyzer import ReachabilityAnalyzer

            analyzer = ReachabilityAnalyzer()

            arc_reachable = analyzer.compute_reachability(graph, start=arc_label)
            has_ending = bool(arc_reachable & terminals)

            results[arc_label] = has_ending

        return results


# Convenience function
def check_completeness(
    graph: StoryGraph,
    reachability: ReachabilityResult,
    config: Optional[Dict[str, Any]] = None,
) -> CompletenessResult:
    """Convenience function to run completeness analysis"""
    checker = CompletenessChecker(config)
    return checker.analyze(graph, reachability)
