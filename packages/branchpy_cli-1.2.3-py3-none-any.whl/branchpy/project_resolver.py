# branchpy/project_resolver.py
from __future__ import annotations

from pathlib import Path
from typing import Optional

from .config_store import ConfigStore


def _looks_like_renpy_root(p: Path) -> bool:
    if not p.exists():
        return False
    if (p / "game").is_dir():
        return True
    if any(p.glob("*.rpy")):
        return True
    if any((p / "game").glob("*.rpy")):
        return True
    return False


def _autodetect_from_cwd(start: Optional[Path] = None) -> Optional[Path]:
    cur = (start or Path.cwd()).resolve()
    for anc in [cur, *cur.parents]:
        if _looks_like_renpy_root(anc):
            return anc
    return None


def resolve_project(project_arg: Optional[str]) -> Path:
    """
    Resolution order:
    1) If project_arg is a path → use it (if exists).
    2) If project_arg is a friendly name → resolve from config.
    3) If default_project is set → use that.
    4) Try auto-detect from CWD.
    Otherwise → fail with guidance.
    """
    store = ConfigStore()
    # 1) explicit arg
    if project_arg:
        p = Path(project_arg).expanduser()
        if p.exists():
            return p.resolve()
        # friendly name?
        if project_arg in store.cfg.projects:
            return Path(store.cfg.projects[project_arg]).resolve()
        raise SystemExit(
            f"[BranchPy] Unknown project: {project_arg!r}. "
            f"Use a valid path or register a name via 'branchpy projects add <name> <path>'."
        )
    # 2) default
    d = store.cfg.default_project
    if d and d in store.cfg.projects:
        return Path(store.cfg.projects[d]).resolve()
    # 3) auto-detect
    guess = _autodetect_from_cwd()
    if guess:
        return guess
    # 4) fail
    raise SystemExit(
        "[BranchPy] Could not determine project root. "
        "Pass --project <path|name>, set a default with 'branchpy projects set-default', "
        "or run inside a Ren’Py project."
    )
