# branchpy/cli_help.py
from argparse import RawTextHelpFormatter


def fmt_examples(*lines: str) -> str:
    """
    Build a pretty 'Examples:' epilog for argparse.
    Each line should be a full example command (no leading spaces needed).
    """
    if not lines:
        return ""
    body = "\n".join(f"  {ln}" for ln in lines)
    return f"Examples:\n{body}"


HelpFmt = RawTextHelpFormatter  # alias so you can import both together
