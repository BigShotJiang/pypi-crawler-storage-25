"""
Pattern Mining Engine

Analyzes codebases to extract common patterns including:
- Variable naming conventions
- Statement sequences
- Code style preferences
- Indentation patterns
- Control flow patterns
- Anti-patterns

Provides foundation for automatic BQF policy generation.

Features:
- Multi-engine support (Ren'Py, Unity, Godot, Unreal)
- Configurable confidence thresholds
- Pattern frequency analysis
- Context-aware pattern extraction
- Performance optimized for large projects

Version: 0.9.6
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class PatternCategory(Enum):
    """Categories of detectable patterns."""

    VARIABLE_NAMING = "variable_naming"
    CONSTANT_NAMING = "constant_naming"
    LABEL_NAMING = "label_naming"
    FUNCTION_NAMING = "function_naming"
    INDENTATION = "indentation"
    QUOTE_STYLE = "quote_style"
    STATEMENT_SEQUENCE = "statement_sequence"
    CONTROL_FLOW = "control_flow"
    MAGIC_NUMBER = "magic_number"
    ANTI_PATTERN = "anti_pattern"
    BEST_PRACTICE = "best_practice"


@dataclass
class PatternInstance:
    """Single instance of a detected pattern.

    Attributes:
        category: Pattern category
        pattern: Pattern string (e.g., snake_case, 4 spaces)
        value: Actual value found (e.g., my_variable)
        file: Source file path
        line: Line number
        context: Surrounding code context
        confidence: Detection confidence (0.0-1.0)
        metadata: Additional pattern-specific data
    """

    category: PatternCategory
    pattern: str
    value: str
    file: str
    line: int
    context: str = ""
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "category": self.category.value,
            "pattern": self.pattern,
            "value": self.value,
            "file": self.file,
            "line": self.line,
            "context": self.context,
            "confidence": self.confidence,
            "metadata": self.metadata,
        }


@dataclass
class PatternSummary:
    """Summary of detected patterns.

    Attributes:
        category: Pattern category
        pattern: Pattern name
        count: Number of occurrences
        confidence: Overall confidence (0.0-1.0)
        examples: Sample instances
        coverage: Percentage of codebase covered (0.0-1.0)
        metadata: Additional summary data
    """

    category: PatternCategory
    pattern: str
    count: int
    confidence: float
    examples: List[PatternInstance] = field(default_factory=list)
    coverage: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "category": self.category.value,
            "pattern": self.pattern,
            "count": self.count,
            "confidence": self.confidence,
            "examples": [e.to_dict() for e in self.examples[:5]],  # Limit examples
            "coverage": self.coverage,
            "metadata": self.metadata,
        }


class PatternMiner:
    """Mines patterns from project codebase.

    Usage:
        miner = PatternMiner(project_root, engine_type="renpy")
        patterns = miner.mine_all_patterns()
        summaries = miner.get_pattern_summaries()
    """

    # Regex patterns for different engines
    RENPY_PATTERNS = {
        "label": re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:\s*$"),
        "variable_assign": re.compile(r"^\s*\$\s*([A-Za-z_]\w*)\s*[+\-*/]?="),
        "default_var": re.compile(r"^\s*default\s+([A-Za-z_]\w*)\s*="),
        "define_var": re.compile(r"^\s*define\s+([A-Za-z_]\w*)\s*="),
        "jump": re.compile(r"^\s*jump\s+([A-Za-z_]\w*)"),
        "call": re.compile(r"^\s*call\s+([A-Za-z_]\w*)"),
        "menu": re.compile(r"^\s*menu\s*:"),
        "if": re.compile(r"^\s*if\s+(.+):"),
        "numeric_literal": re.compile(r"\b(\d+(?:\.\d+)?)\b"),
    }

    PYTHON_PATTERNS = {
        "function_def": re.compile(r"^\s*def\s+([A-Za-z_]\w*)\s*\("),
        "class_def": re.compile(r"^\s*class\s+([A-Za-z]\w*)\s*[:(]"),
        "variable_assign": re.compile(r"^\s*([A-Za-z_]\w*)\s*="),
        "import": re.compile(r"^\s*(?:from\s+[\w.]+\s+)?import\s+"),
    }

    def __init__(
        self,
        project_root: Path | str,
        engine_type: str = "auto",
        file_patterns: Optional[List[str]] = None,
        min_confidence: float = 0.7,
        max_files: int = 10000,
    ):
        """Initialize pattern miner.

        Args:
            project_root: Project root directory
            engine_type: Engine type (auto, renpy, unity, godot, unreal, generic)
            file_patterns: File patterns to scan (e.g., ['*.rpy', '*.py'])
            min_confidence: Minimum confidence for pattern detection
            max_files: Maximum files to scan
        """
        self.project_root = Path(project_root)
        self.engine_type = (
            engine_type if engine_type != "auto" else self._detect_engine()
        )
        self.file_patterns = file_patterns or self._get_default_file_patterns()
        self.min_confidence = min_confidence
        self.max_files = max_files

        # Storage
        self.patterns: List[PatternInstance] = []
        self.file_count = 0
        self.line_count = 0

    def _detect_engine(self) -> str:
        """Auto-detect engine type from project structure."""
        if (self.project_root / "game").exists():
            return "renpy"
        elif (self.project_root / "project.godot").exists():
            return "godot"
        elif (self.project_root / "Assets").exists():
            return "unity"
        elif (self.project_root / "Content").exists():
            return "unreal"
        return "generic"

    def _get_default_file_patterns(self) -> List[str]:
        """Get default file patterns for engine type."""
        patterns_map = {
            "renpy": ["*.rpy", "*.py"],
            "godot": ["*.gd", "*.tscn"],
            "unity": ["*.cs", "*.shader"],
            "unreal": ["*.cpp", "*.h", "*.uasset"],
            "generic": ["*.py", "*.js", "*.ts", "*.json"],
        }
        return patterns_map.get(self.engine_type, patterns_map["generic"])

    def mine_all_patterns(self) -> List[PatternInstance]:
        """Mine all pattern categories.

        Returns:
            List of all detected pattern instances
        """
        self.patterns.clear()

        # Mine each category
        self.patterns.extend(self.mine_naming_patterns())
        self.patterns.extend(self.mine_style_patterns())
        self.patterns.extend(self.mine_statement_sequences())
        self.patterns.extend(self.mine_magic_numbers())
        self.patterns.extend(self.mine_anti_patterns())

        return self.patterns

    def mine_naming_patterns(self) -> List[PatternInstance]:
        """Mine variable and label naming conventions.

        Returns:
            List of naming pattern instances
        """
        patterns = []
        var_names: List[Tuple[str, str, int, str]] = []  # (name, file, line, context)
        label_names: List[Tuple[str, str, int, str]] = []
        const_names: List[Tuple[str, str, int, str]] = []
        func_names: List[Tuple[str, str, int, str]] = []

        for file_path in self._get_source_files():
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                lines = content.split("\n")
                self.line_count += len(lines)

                for line_no, line in enumerate(lines, 1):
                    # Variables
                    for pattern in [
                        self.RENPY_PATTERNS.get("variable_assign"),
                        self.RENPY_PATTERNS.get("default_var"),
                        self.RENPY_PATTERNS.get("define_var"),
                        self.PYTHON_PATTERNS.get("variable_assign"),
                    ]:
                        if pattern:
                            match = pattern.match(line)
                            if match:
                                var_name = match.group(1)
                                context = self._get_context(lines, line_no - 1, 2)

                                # Classify as constant or variable
                                if var_name.isupper() and len(var_name) > 1:
                                    const_names.append(
                                        (var_name, str(file_path), line_no, context)
                                    )
                                else:
                                    var_names.append(
                                        (var_name, str(file_path), line_no, context)
                                    )

                    # Labels (Ren'Py)
                    if self.engine_type == "renpy":
                        label_match = self.RENPY_PATTERNS["label"].match(line)
                        if label_match:
                            label_name = label_match.group(1)
                            context = self._get_context(lines, line_no - 1, 2)
                            label_names.append(
                                (label_name, str(file_path), line_no, context)
                            )

                    # Functions
                    func_match = self.PYTHON_PATTERNS["function_def"].match(line)
                    if func_match:
                        func_name = func_match.group(1)
                        context = self._get_context(lines, line_no - 1, 2)
                        func_names.append((func_name, str(file_path), line_no, context))

            except Exception:
                continue

        # Analyze naming patterns
        patterns.extend(
            self._analyze_naming_convention(var_names, PatternCategory.VARIABLE_NAMING)
        )
        patterns.extend(
            self._analyze_naming_convention(
                const_names, PatternCategory.CONSTANT_NAMING
            )
        )
        patterns.extend(
            self._analyze_naming_convention(label_names, PatternCategory.LABEL_NAMING)
        )
        patterns.extend(
            self._analyze_naming_convention(func_names, PatternCategory.FUNCTION_NAMING)
        )

        return patterns

    def _analyze_naming_convention(
        self, names: List[Tuple[str, str, int, str]], category: PatternCategory
    ) -> List[PatternInstance]:
        """Analyze naming convention patterns.

        Args:
            names: List of (name, file, line, context) tuples
            category: Pattern category

        Returns:
            List of detected pattern instances
        """
        if not names:
            return []

        patterns = []

        # Count convention types
        snake_case_count = 0
        camel_case_count = 0
        pascal_case_count = 0
        upper_case_count = 0

        for name, file, line, context in names:
            # Detect convention
            if re.match(r"^[a-z]+(_[a-z0-9]+)*$", name):
                snake_case_count += 1
                convention = "snake_case"
            elif re.match(r"^[a-z]+([A-Z][a-z0-9]+)*$", name):
                camel_case_count += 1
                convention = "camelCase"
            elif re.match(r"^[A-Z][a-z0-9]*([A-Z][a-z0-9]+)*$", name):
                pascal_case_count += 1
                convention = "PascalCase"
            elif re.match(r"^[A-Z_][A-Z0-9_]*$", name):
                upper_case_count += 1
                convention = "UPPER_CASE"
            else:
                continue  # Mixed or unclear

            patterns.append(
                PatternInstance(
                    category=category,
                    pattern=convention,
                    value=name,
                    file=file,
                    line=line,
                    context=context,
                    confidence=1.0,
                )
            )

        return patterns

    def mine_style_patterns(self) -> List[PatternInstance]:
        """Mine code style patterns (indentation, quotes, etc.).

        Returns:
            List of style pattern instances
        """
        patterns = []
        indent_counts: Dict[str, int] = Counter()
        quote_counts: Dict[str, int] = Counter()

        for file_path in self._get_source_files():
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                lines = content.split("\n")

                for line_no, line in enumerate(lines, 1):
                    # Indentation
                    if line and not line.isspace():
                        indent = len(line) - len(line.lstrip())
                        if indent > 0:
                            # Detect spaces vs tabs
                            if line.startswith("\t"):
                                indent_counts["tabs"] += 1
                            elif line.startswith(" "):
                                # Count spaces
                                spaces = indent
                                if spaces % 4 == 0:
                                    indent_counts["4_spaces"] += 1
                                elif spaces % 2 == 0:
                                    indent_counts["2_spaces"] += 1

                    # Quote style
                    single_quotes = len(re.findall(r"'[^']*'", line))
                    double_quotes = len(re.findall(r'"[^"]*"', line))

                    if single_quotes > 0:
                        quote_counts["single"] += single_quotes
                        patterns.append(
                            PatternInstance(
                                category=PatternCategory.QUOTE_STYLE,
                                pattern="single_quotes",
                                value=line.strip(),
                                file=str(file_path),
                                line=line_no,
                                context="",
                                confidence=0.9,
                            )
                        )
                    if double_quotes > 0:
                        quote_counts["double"] += double_quotes
                        patterns.append(
                            PatternInstance(
                                category=PatternCategory.QUOTE_STYLE,
                                pattern="double_quotes",
                                value=line.strip(),
                                file=str(file_path),
                                line=line_no,
                                context="",
                                confidence=0.9,
                            )
                        )

            except Exception:
                continue

        # Add indentation patterns
        for indent_type, count in indent_counts.items():
            if count > 10:  # Threshold
                patterns.append(
                    PatternInstance(
                        category=PatternCategory.INDENTATION,
                        pattern=indent_type,
                        value=indent_type,
                        file="<multiple>",
                        line=0,
                        confidence=min(1.0, count / 100.0),
                        metadata={"count": count},
                    )
                )

        return patterns

    def mine_statement_sequences(self) -> List[PatternInstance]:
        """Mine common statement sequences.

        Returns:
            List of statement sequence patterns
        """
        patterns = []
        sequences: Counter = Counter()

        for file_path in self._get_source_files():
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                lines = content.split("\n")

                # Extract statement types in sequence
                stmt_sequence = []
                for line in lines:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    # Classify statement
                    stmt_type = self._classify_statement(line)
                    if stmt_type:
                        stmt_sequence.append(stmt_type)

                        # Record 2-3 statement sequences
                        if len(stmt_sequence) >= 2:
                            seq2 = tuple(stmt_sequence[-2:])
                            sequences[seq2] += 1
                        if len(stmt_sequence) >= 3:
                            seq3 = tuple(stmt_sequence[-3:])
                            sequences[seq3] += 1

            except Exception:
                continue

        # Convert frequent sequences to patterns
        for sequence, count in sequences.most_common(50):
            if count >= 5:  # Threshold
                patterns.append(
                    PatternInstance(
                        category=PatternCategory.STATEMENT_SEQUENCE,
                        pattern=" -> ".join(sequence),
                        value=str(sequence),
                        file="<multiple>",
                        line=0,
                        confidence=min(1.0, count / 50.0),
                        metadata={"count": count},
                    )
                )

        return patterns

    def mine_magic_numbers(self) -> List[PatternInstance]:
        """Mine hardcoded numeric literals (magic numbers).

        Returns:
            List of magic number patterns
        """
        patterns = []
        numbers: Dict[float, List[Tuple[str, int, str]]] = defaultdict(list)

        # Common safe values to exclude
        SAFE_VALUES = {0, 1, -1, 2, 10, 100, 0.0, 1.0, -1.0}

        for file_path in self._get_source_files():
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                lines = content.split("\n")

                for line_no, line in enumerate(lines, 1):
                    # Find numeric literals
                    for match in self.RENPY_PATTERNS["numeric_literal"].finditer(line):
                        try:
                            value = float(match.group(1))
                            if value not in SAFE_VALUES:
                                context = self._get_context(lines, line_no - 1, 1)
                                numbers[value].append(
                                    (str(file_path), line_no, context)
                                )
                        except ValueError:
                            continue

            except Exception:
                continue

        # Convert to patterns (report numbers appearing 3+ times)
        for value, locations in numbers.items():
            if len(locations) >= 3:
                first_file, first_line, context = locations[0]
                patterns.append(
                    PatternInstance(
                        category=PatternCategory.MAGIC_NUMBER,
                        pattern=f"repeated_value_{value}",
                        value=str(value),
                        file=first_file,
                        line=first_line,
                        context=context,
                        confidence=min(1.0, len(locations) / 10.0),
                        metadata={
                            "occurrences": len(locations),
                            "locations": len(locations),
                        },
                    )
                )

        return patterns

    def mine_anti_patterns(self) -> List[PatternInstance]:
        """Mine common anti-patterns.

        Returns:
            List of anti-pattern instances
        """
        patterns = []

        for file_path in self._get_source_files():
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                lines = content.split("\n")

                for line_no, line in enumerate(lines, 1):
                    context = self._get_context(lines, line_no - 1, 2)

                    # Deep nesting (4+ indent levels)
                    indent = len(line) - len(line.lstrip())
                    if indent >= 16:  # 4 levels * 4 spaces
                        patterns.append(
                            PatternInstance(
                                category=PatternCategory.ANTI_PATTERN,
                                pattern="deep_nesting",
                                value=line.strip(),
                                file=str(file_path),
                                line=line_no,
                                context=context,
                                confidence=0.9,
                                metadata={"indent_level": indent // 4},
                            )
                        )

                    # Unused variables (assigned but never referenced again)
                    # This is simplified - full analysis needs dataflow
                    assign_match = re.match(r"^\s*\$?\s*([A-Za-z_]\w*)\s*=", line)
                    if assign_match:
                        var_name = assign_match.group(1)
                        # Check if variable is used in next 10 lines
                        used = False
                        for future_line in lines[line_no : line_no + 10]:
                            if (
                                var_name in future_line
                                and "=" not in future_line.split(var_name)[0]
                            ):
                                used = True
                                break

                        if not used:
                            patterns.append(
                                PatternInstance(
                                    category=PatternCategory.ANTI_PATTERN,
                                    pattern="potentially_unused_variable",
                                    value=var_name,
                                    file=str(file_path),
                                    line=line_no,
                                    context=context,
                                    confidence=0.6,  # Lower confidence
                                    metadata={"variable": var_name},
                                )
                            )

            except Exception:
                continue

        return patterns

    def get_pattern_summaries(
        self, min_count: int = 5, min_confidence: Optional[float] = None
    ) -> List[PatternSummary]:
        """Get aggregated pattern summaries.

        Args:
            min_count: Minimum occurrences to report
            min_confidence: Minimum confidence (uses instance min_confidence if None)

        Returns:
            List of pattern summaries sorted by count
        """
        if min_confidence is None:
            min_confidence = self.min_confidence

        # Group patterns by (category, pattern)
        grouped: Dict[Tuple[PatternCategory, str], List[PatternInstance]] = defaultdict(
            list
        )

        for pattern in self.patterns:
            if pattern.confidence >= min_confidence:
                key = (pattern.category, pattern.pattern)
                grouped[key].append(pattern)

        # Create summaries
        summaries = []
        for (category, pattern), instances in grouped.items():
            if len(instances) >= min_count:
                avg_confidence = sum(p.confidence for p in instances) / len(instances)
                coverage = (
                    len(instances) / max(1, self.line_count)
                    if self.line_count > 0
                    else 0.0
                )

                summaries.append(
                    PatternSummary(
                        category=category,
                        pattern=pattern,
                        count=len(instances),
                        confidence=avg_confidence,
                        examples=instances[:5],  # First 5 examples
                        coverage=coverage,
                        metadata={
                            "files_affected": len(set(p.file for p in instances))
                        },
                    )
                )

        # Sort by count descending
        summaries.sort(key=lambda s: s.count, reverse=True)
        return summaries

    def _get_source_files(self) -> List[Path]:
        """Get list of source files to scan.

        Returns:
            List of Path objects
        """
        files = []
        self.file_count = 0

        for pattern in self.file_patterns:
            for file_path in self.project_root.rglob(pattern):
                if file_path.is_file() and self.file_count < self.max_files:
                    # Skip common non-source directories
                    if any(
                        skip in file_path.parts
                        for skip in [".git", "__pycache__", "node_modules", ".venv"]
                    ):
                        continue
                    files.append(file_path)
                    self.file_count += 1

        return files

    def _get_context(self, lines: List[str], line_idx: int, context_lines: int) -> str:
        """Get surrounding context for a line.

        Args:
            lines: All lines in file
            line_idx: Target line index (0-based)
            context_lines: Number of lines before/after to include

        Returns:
            Context string
        """
        start = max(0, line_idx - context_lines)
        end = min(len(lines), line_idx + context_lines + 1)
        return "\n".join(lines[start:end])

    def _classify_statement(self, line: str) -> Optional[str]:
        """Classify a statement type.

        Args:
            line: Source line

        Returns:
            Statement type or None
        """
        if self.RENPY_PATTERNS["label"].match(line):
            return "label"
        elif self.RENPY_PATTERNS["jump"].match(line):
            return "jump"
        elif self.RENPY_PATTERNS["call"].match(line):
            return "call"
        elif self.RENPY_PATTERNS["menu"].match(line):
            return "menu"
        elif self.RENPY_PATTERNS["if"].match(line):
            return "if"
        elif self.RENPY_PATTERNS["variable_assign"].match(line):
            return "assign"
        elif self.PYTHON_PATTERNS["function_def"].match(line):
            return "function"
        elif line.startswith('"') or line.startswith("'"):
            return "dialogue"
        return None
