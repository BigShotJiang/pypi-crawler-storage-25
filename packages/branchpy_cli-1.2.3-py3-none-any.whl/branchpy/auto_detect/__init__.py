"""
BranchPy Auto-Detect → BQF Policy Conversion Module

Automatically detects codebase patterns and generates BQF policies for:
- Variable naming conventions
- Statement sequences
- Style conventions
- Anti-patterns
- Best practices

Features:
- Pattern mining from existing code
- Automatic rule inference with confidence scoring
- Policy recommendation engine
- Project-specific policy scaffolding
- Engine-agnostic pattern detection

Version: 0.9.6
Created: 2025-11-21
Module: auto_detect
"""

from .pattern_miner import PatternCategory, PatternInstance, PatternMiner
from .policy_scaffolder import PolicyScaffolder, ProjectType
from .recommendation_engine import PolicyRecommendation, RecommendationEngine
from .rule_inference import InferredRule, RuleInferenceEngine

__all__ = [
    "PatternMiner",
    "PatternCategory",
    "PatternInstance",
    "RuleInferenceEngine",
    "InferredRule",
    "PolicyScaffolder",
    "ProjectType",
    "RecommendationEngine",
    "PolicyRecommendation",
]

__version__ = "0.9.6"
