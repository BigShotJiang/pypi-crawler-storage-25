"""
Rule Inference Engine

Converts detected patterns into actionable BQF policies and regex rules.

Features:
- Automatic rule generation from pattern summaries
- Confidence-based filtering
- Rule deduplication and merging
- BQF policy conversion
- Customizable rule templates

Version: 0.9.6
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from branchpy.auto_detect.pattern_miner import PatternCategory, PatternSummary
from branchpy.semantics.propagation.bqf_policy_converter import (
    ActionType,
    BQFPolicy,
    PolicyAction,
    PolicyCondition,
    PolicyRule,
    PolicyScope,
    PolicySeverity,
    PolicyType,
)


class RuleType(Enum):
    """Types of inferred rules."""

    NAMING_CONVENTION = "naming_convention"
    STYLE_ENFORCEMENT = "style_enforcement"
    ANTI_PATTERN_DETECTION = "anti_pattern_detection"
    BEST_PRACTICE = "best_practice"
    MAGIC_NUMBER_DETECTION = "magic_number_detection"
    COMPLEXITY_LIMIT = "complexity_limit"


@dataclass
class InferredRule:
    """A rule inferred from codebase patterns.

    Attributes:
        rule_id: Unique identifier
        name: Human-readable name
        rule_type: Type of rule
        pattern: Regex pattern or description
        severity: Rule severity
        confidence: Inference confidence (0.0-1.0)
        message: Violation message
        fix_suggestion: Optional fix suggestion
        metadata: Additional rule data
    """

    rule_id: str
    name: str
    rule_type: RuleType
    pattern: str
    severity: str  # error, warning, info
    confidence: float
    message: str
    fix_suggestion: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "rule_id": self.rule_id,
            "name": self.name,
            "rule_type": self.rule_type.value,
            "pattern": self.pattern,
            "severity": self.severity,
            "confidence": self.confidence,
            "message": self.message,
            "fix_suggestion": self.fix_suggestion,
            "metadata": self.metadata,
        }

    def to_bqf_policy(self) -> BQFPolicy:
        """Convert to BQF policy."""
        # Map rule type to policy type
        policy_type_map = {
            RuleType.NAMING_CONVENTION: PolicyType.NAMING,
            RuleType.STYLE_ENFORCEMENT: PolicyType.STYLE,
            RuleType.ANTI_PATTERN_DETECTION: PolicyType.SEMANTIC,
            RuleType.BEST_PRACTICE: PolicyType.QUALITY,
            RuleType.MAGIC_NUMBER_DETECTION: PolicyType.QUALITY,
            RuleType.COMPLEXITY_LIMIT: PolicyType.QUALITY,
        }
        policy_type = policy_type_map.get(self.rule_type, PolicyType.CUSTOM)

        # Map severity
        severity_map = {
            "error": PolicySeverity.ERROR,
            "warning": PolicySeverity.WARNING,
            "info": PolicySeverity.INFO,
        }
        policy_severity = severity_map.get(self.severity, PolicySeverity.INFO)

        # Create policy condition
        condition = PolicyCondition(
            type="pattern",
            pattern=self.pattern,
            description=self.message,
            metadata={"confidence": self.confidence, "inferred": True, **self.metadata},
        )

        # Create policy action
        action = PolicyAction(
            action_type=(
                ActionType.ENFORCE
                if policy_severity == PolicySeverity.ERROR
                else ActionType.REPORT
            ),
            message=self.message,
            fix_suggestion=self.fix_suggestion,
            metadata={},
        )

        # Create policy rule
        policy_rule = PolicyRule(
            id=self.rule_id,
            name=self.name,
            condition=condition,
            action=action,
            enabled=True,
            metadata=self.metadata,
        )

        # Create BQF policy
        return BQFPolicy(
            id=f"AUTO_{self.rule_id}",
            name=f"Auto-detected: {self.name}",
            type=policy_type,
            severity=policy_severity,
            scope=PolicyScope.GLOBAL,
            rules=[policy_rule],
            version="1.0.0",
            description=f"Automatically inferred from codebase patterns (confidence: {self.confidence:.2f})",
            tags=["auto-detected", self.rule_type.value, "inferred"],
            metadata={
                "source": "rule_inference_engine",
                "confidence": self.confidence,
                "inferred": True,
            },
        )


class RuleInferenceEngine:
    """Infers rules from pattern summaries.

    Usage:
        engine = RuleInferenceEngine(min_confidence=0.8)
        rules = engine.infer_rules(pattern_summaries)
        policies = engine.convert_to_bqf_policies(rules)
    """

    def __init__(
        self,
        min_confidence: float = 0.7,
        min_pattern_count: int = 10,
        enable_aggressive_inference: bool = False,
    ):
        """Initialize inference engine.

        Args:
            min_confidence: Minimum confidence for rule inference
            min_pattern_count: Minimum pattern occurrences for rule
            enable_aggressive_inference: Enable lower-confidence rules
        """
        self.min_confidence = min_confidence
        self.min_pattern_count = min_pattern_count
        self.enable_aggressive_inference = enable_aggressive_inference

        self.inferred_rules: List[InferredRule] = []

    def infer_rules(
        self, pattern_summaries: List[PatternSummary]
    ) -> List[InferredRule]:
        """Infer rules from pattern summaries.

        Args:
            pattern_summaries: List of pattern summaries from PatternMiner

        Returns:
            List of inferred rules
        """
        self.inferred_rules.clear()

        for summary in pattern_summaries:
            # Skip low-confidence or low-count patterns
            if summary.confidence < self.min_confidence:
                continue
            if summary.count < self.min_pattern_count:
                continue

            # Infer rules based on category
            if summary.category == PatternCategory.VARIABLE_NAMING:
                rules = self._infer_naming_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.CONSTANT_NAMING:
                rules = self._infer_constant_naming_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.LABEL_NAMING:
                rules = self._infer_label_naming_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.FUNCTION_NAMING:
                rules = self._infer_function_naming_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.INDENTATION:
                rules = self._infer_indentation_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.QUOTE_STYLE:
                rules = self._infer_quote_style_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.MAGIC_NUMBER:
                rules = self._infer_magic_number_rules(summary)
                self.inferred_rules.extend(rules)

            elif summary.category == PatternCategory.ANTI_PATTERN:
                rules = self._infer_anti_pattern_rules(summary)
                self.inferred_rules.extend(rules)

        # Deduplicate rules
        self.inferred_rules = self._deduplicate_rules(self.inferred_rules)

        return self.inferred_rules

    def _infer_naming_rules(self, summary: PatternSummary) -> List[InferredRule]:
        """Infer variable naming convention rules."""
        rules = []

        convention = summary.pattern

        if convention == "snake_case":
            rules.append(
                InferredRule(
                    rule_id="VAR_SNAKE_CASE",
                    name="Variable Snake Case Convention",
                    rule_type=RuleType.NAMING_CONVENTION,
                    pattern=r"^[a-z]+(_[a-z0-9]+)*$",
                    severity="warning",
                    confidence=summary.confidence,
                    message=f"Variables should use snake_case (detected in {summary.count} instances)",
                    fix_suggestion="Convert to snake_case: lowercase with underscores",
                    metadata={
                        "convention": "snake_case",
                        "pattern_count": summary.count,
                        "coverage": summary.coverage,
                    },
                )
            )

        elif convention == "camelCase":
            rules.append(
                InferredRule(
                    rule_id="VAR_CAMEL_CASE",
                    name="Variable Camel Case Convention",
                    rule_type=RuleType.NAMING_CONVENTION,
                    pattern=r"^[a-z]+([A-Z][a-z0-9]+)*$",
                    severity="warning",
                    confidence=summary.confidence,
                    message=f"Variables should use camelCase (detected in {summary.count} instances)",
                    fix_suggestion="Convert to camelCase: first letter lowercase, capitalize subsequent words",
                    metadata={
                        "convention": "camelCase",
                        "pattern_count": summary.count,
                        "coverage": summary.coverage,
                    },
                )
            )

        elif convention == "PascalCase":
            rules.append(
                InferredRule(
                    rule_id="VAR_PASCAL_CASE",
                    name="Variable Pascal Case Convention",
                    rule_type=RuleType.NAMING_CONVENTION,
                    pattern=r"^[A-Z][a-z0-9]*([A-Z][a-z0-9]+)*$",
                    severity="warning",
                    confidence=summary.confidence,
                    message=f"Variables should use PascalCase (detected in {summary.count} instances)",
                    fix_suggestion="Convert to PascalCase: capitalize first letter and subsequent words",
                    metadata={
                        "convention": "PascalCase",
                        "pattern_count": summary.count,
                        "coverage": summary.coverage,
                    },
                )
            )

        return rules

    def _infer_constant_naming_rules(
        self, summary: PatternSummary
    ) -> List[InferredRule]:
        """Infer constant naming convention rules."""
        if summary.pattern == "UPPER_CASE":
            return [
                InferredRule(
                    rule_id="CONST_UPPER_CASE",
                    name="Constant Upper Case Convention",
                    rule_type=RuleType.NAMING_CONVENTION,
                    pattern=r"^[A-Z_][A-Z0-9_]*$",
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Constants should use UPPER_CASE (detected in {summary.count} instances)",
                    fix_suggestion="Convert to UPPER_CASE: all uppercase with underscores",
                    metadata={
                        "convention": "UPPER_CASE",
                        "pattern_count": summary.count,
                    },
                )
            ]
        return []

    def _infer_label_naming_rules(self, summary: PatternSummary) -> List[InferredRule]:
        """Infer label naming convention rules."""
        convention = summary.pattern

        if convention == "snake_case":
            return [
                InferredRule(
                    rule_id="LABEL_SNAKE_CASE",
                    name="Label Snake Case Convention",
                    rule_type=RuleType.NAMING_CONVENTION,
                    pattern=r"^[a-z]+(_[a-z0-9]+)*$",
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Labels should use snake_case (detected in {summary.count} instances)",
                    fix_suggestion="Convert to snake_case: lowercase with underscores",
                    metadata={
                        "convention": "snake_case",
                        "pattern_count": summary.count,
                    },
                )
            ]
        return []

    def _infer_function_naming_rules(
        self, summary: PatternSummary
    ) -> List[InferredRule]:
        """Infer function naming convention rules."""
        convention = summary.pattern

        if convention == "snake_case":
            return [
                InferredRule(
                    rule_id="FUNC_SNAKE_CASE",
                    name="Function Snake Case Convention",
                    rule_type=RuleType.NAMING_CONVENTION,
                    pattern=r"^[a-z]+(_[a-z0-9]+)*$",
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Functions should use snake_case (detected in {summary.count} instances)",
                    fix_suggestion="Convert to snake_case: lowercase with underscores",
                    metadata={
                        "convention": "snake_case",
                        "pattern_count": summary.count,
                    },
                )
            ]
        return []

    def _infer_indentation_rules(self, summary: PatternSummary) -> List[InferredRule]:
        """Infer indentation style rules."""
        rules = []

        if summary.pattern == "4_spaces":
            rules.append(
                InferredRule(
                    rule_id="INDENT_4_SPACES",
                    name="4-Space Indentation",
                    rule_type=RuleType.STYLE_ENFORCEMENT,
                    pattern=r"^(    )+\S",  # 4 spaces followed by non-whitespace
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Use 4-space indentation (detected in {summary.count} instances)",
                    fix_suggestion="Use 4 spaces for each indentation level",
                    metadata={"indent_size": 4, "pattern_count": summary.count},
                )
            )

        elif summary.pattern == "2_spaces":
            rules.append(
                InferredRule(
                    rule_id="INDENT_2_SPACES",
                    name="2-Space Indentation",
                    rule_type=RuleType.STYLE_ENFORCEMENT,
                    pattern=r"^(  )+\S",  # 2 spaces
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Use 2-space indentation (detected in {summary.count} instances)",
                    fix_suggestion="Use 2 spaces for each indentation level",
                    metadata={"indent_size": 2, "pattern_count": summary.count},
                )
            )

        elif summary.pattern == "tabs":
            rules.append(
                InferredRule(
                    rule_id="INDENT_TABS",
                    name="Tab Indentation",
                    rule_type=RuleType.STYLE_ENFORCEMENT,
                    pattern=r"^\t+\S",
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Use tab indentation (detected in {summary.count} instances)",
                    fix_suggestion="Use tabs for indentation",
                    metadata={"indent_type": "tabs", "pattern_count": summary.count},
                )
            )

        return rules

    def _infer_quote_style_rules(self, summary: PatternSummary) -> List[InferredRule]:
        """Infer quote style rules."""
        if summary.pattern == "double_quotes" and summary.confidence > 0.8:
            return [
                InferredRule(
                    rule_id="QUOTE_DOUBLE",
                    name="Double Quote Style",
                    rule_type=RuleType.STYLE_ENFORCEMENT,
                    pattern=r'"[^"]*"',
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Prefer double quotes for strings (detected in {summary.count} instances)",
                    fix_suggestion="Use double quotes: \"text\" instead of 'text'",
                    metadata={"quote_style": "double", "pattern_count": summary.count},
                )
            ]
        elif summary.pattern == "single_quotes" and summary.confidence > 0.8:
            return [
                InferredRule(
                    rule_id="QUOTE_SINGLE",
                    name="Single Quote Style",
                    rule_type=RuleType.STYLE_ENFORCEMENT,
                    pattern=r"'[^']*'",
                    severity="info",
                    confidence=summary.confidence,
                    message=f"Prefer single quotes for strings (detected in {summary.count} instances)",
                    fix_suggestion="Use single quotes: 'text' instead of \"text\"",
                    metadata={"quote_style": "single", "pattern_count": summary.count},
                )
            ]
        return []

    def _infer_magic_number_rules(self, summary: PatternSummary) -> List[InferredRule]:
        """Infer magic number detection rules."""
        value = summary.pattern.replace("repeated_value_", "")
        occurrences = summary.metadata.get("locations", 0)

        return [
            InferredRule(
                rule_id=f"MAGIC_NUMBER_{value.replace('.', '_')}",
                name=f"Repeated Magic Number: {value}",
                rule_type=RuleType.MAGIC_NUMBER_DETECTION,
                pattern=rf"\b{re.escape(value)}\b",
                severity="info",
                confidence=summary.confidence,
                message=f"Consider extracting repeated value {value} to a named constant (found {occurrences} times)",
                fix_suggestion=f"Define a constant: CONSTANT_NAME = {value}",
                metadata={"value": value, "occurrences": occurrences},
            )
        ]

    def _infer_anti_pattern_rules(self, summary: PatternSummary) -> List[InferredRule]:
        """Infer anti-pattern detection rules."""
        rules = []

        if summary.pattern == "deep_nesting":
            rules.append(
                InferredRule(
                    rule_id="ANTI_DEEP_NESTING",
                    name="Deep Nesting Anti-Pattern",
                    rule_type=RuleType.ANTI_PATTERN_DETECTION,
                    pattern=r"^[ \t]{16,}",  # 4+ levels
                    severity="warning",
                    confidence=summary.confidence,
                    message=f"Avoid deep nesting (4+ levels) - found {summary.count} instances",
                    fix_suggestion="Extract nested logic into separate labels or functions",
                    metadata={"pattern_count": summary.count, "threshold": 4},
                )
            )

        elif summary.pattern == "potentially_unused_variable":
            rules.append(
                InferredRule(
                    rule_id="ANTI_UNUSED_VARIABLE",
                    name="Potentially Unused Variable",
                    rule_type=RuleType.ANTI_PATTERN_DETECTION,
                    pattern=r"^\s*\$?\s*([A-Za-z_]\w*)\s*=.*(?!\1)",  # Simplified
                    severity="warning",
                    confidence=summary.confidence * 0.6,  # Lower confidence
                    message=f"Variables may be assigned but not used - found {summary.count} potential instances",
                    fix_suggestion="Remove unused variables or add usage",
                    metadata={
                        "pattern_count": summary.count,
                        "note": "Lower confidence - manual review recommended",
                    },
                )
            )

        return rules

    def _deduplicate_rules(self, rules: List[InferredRule]) -> List[InferredRule]:
        """Remove duplicate rules.

        Args:
            rules: List of rules to deduplicate

        Returns:
            Deduplicated list
        """
        seen: Dict[str, InferredRule] = {}

        for rule in rules:
            if rule.rule_id not in seen:
                seen[rule.rule_id] = rule
            else:
                # Keep rule with higher confidence
                if rule.confidence > seen[rule.rule_id].confidence:
                    seen[rule.rule_id] = rule

        return list(seen.values())

    def convert_to_bqf_policies(
        self, rules: Optional[List[InferredRule]] = None
    ) -> List[BQFPolicy]:
        """Convert inferred rules to BQF policies.

        Args:
            rules: List of rules to convert (uses self.inferred_rules if None)

        Returns:
            List of BQF policies
        """
        if rules is None:
            rules = self.inferred_rules

        policies = []
        for rule in rules:
            policy = rule.to_bqf_policy()
            policies.append(policy)

        return policies

    def export_rules_yaml(
        self, path: str, rules: Optional[List[InferredRule]] = None
    ) -> None:
        """Export rules to YAML file.

        Args:
            path: Output file path
            rules: Rules to export (uses self.inferred_rules if None)
        """
        import yaml

        if rules is None:
            rules = self.inferred_rules

        data = {
            "inferred_rules": [rule.to_dict() for rule in rules],
            "metadata": {
                "total_rules": len(rules),
                "min_confidence": self.min_confidence,
                "min_pattern_count": self.min_pattern_count,
            },
        }

        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def export_rules_json(
        self, path: str, rules: Optional[List[InferredRule]] = None
    ) -> None:
        """Export rules to JSON file.

        Args:
            path: Output file path
            rules: Rules to export (uses self.inferred_rules if None)
        """
        import json

        if rules is None:
            rules = self.inferred_rules

        data = {
            "inferred_rules": [rule.to_dict() for rule in rules],
            "metadata": {
                "total_rules": len(rules),
                "min_confidence": self.min_confidence,
                "min_pattern_count": self.min_pattern_count,
            },
        }

        with open(path, "w") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
