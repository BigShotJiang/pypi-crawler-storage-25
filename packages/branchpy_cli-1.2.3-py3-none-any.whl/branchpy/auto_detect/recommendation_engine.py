"""
Policy Recommendation Engine

Compares project patterns against best practices and recommends missing policies.

Features:
- Best practice library for different project types
- Gap analysis between current and recommended policies
- Prioritized recommendations
- Customizable recommendation scoring

Version: 0.9.6
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

from branchpy.auto_detect.pattern_miner import PatternCategory, PatternSummary
from branchpy.auto_detect.rule_inference import InferredRule, RuleType
from branchpy.semantics.propagation.bqf_policy_converter import BQFPolicy


class RecommendationPriority(Enum):
    """Priority levels for recommendations."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    OPTIONAL = "optional"


@dataclass
class PolicyRecommendation:
    """A recommended policy to add.

    Attributes:
        policy_id: Recommended policy ID
        name: Policy name
        description: Why this policy is recommended
        priority: Recommendation priority
        reason: Specific reason for recommendation
        impact: Expected impact
        existing_coverage: Current coverage (0.0-1.0)
        target_coverage: Target coverage (0.0-1.0)
        metadata: Additional recommendation data
    """

    policy_id: str
    name: str
    description: str
    priority: RecommendationPriority
    reason: str
    impact: str
    existing_coverage: float = 0.0
    target_coverage: float = 1.0
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "policy_id": self.policy_id,
            "name": self.name,
            "description": self.description,
            "priority": self.priority.value,
            "reason": self.reason,
            "impact": self.impact,
            "existing_coverage": self.existing_coverage,
            "target_coverage": self.target_coverage,
            "metadata": self.metadata,
        }


class RecommendationEngine:
    """Recommends policies based on best practices and gap analysis.

    Usage:
        engine = RecommendationEngine(project_type="visual_novel")
        recommendations = engine.analyze_gaps(
            existing_rules=inferred_rules,
            pattern_summaries=pattern_summaries
        )
    """

    # Best practice policies by project type
    BEST_PRACTICES = {
        "visual_novel": [
            {
                "policy_id": "BP_VN_LABEL_ORGANIZATION",
                "name": "Label Organization",
                "description": "Organize labels by chapter or scene",
                "category": RuleType.BEST_PRACTICE,
                "priority": RecommendationPriority.HIGH,
                "impact": "Improved code organization and maintainability",
            },
            {
                "policy_id": "BP_VN_VARIABLE_NAMING",
                "name": "Variable Naming Conventions",
                "description": "Use consistent naming for character states and flags",
                "category": RuleType.NAMING_CONVENTION,
                "priority": RecommendationPriority.HIGH,
                "impact": "Reduced naming conflicts and improved code readability",
            },
            {
                "policy_id": "BP_VN_MAGIC_NUMBER_ELIMINATION",
                "name": "Magic Number Elimination",
                "description": "Extract hardcoded values to named constants",
                "category": RuleType.MAGIC_NUMBER_DETECTION,
                "priority": RecommendationPriority.MEDIUM,
                "impact": "Easier configuration and value management",
            },
            {
                "policy_id": "BP_VN_DIALOGUE_STYLE",
                "name": "Dialogue Style Consistency",
                "description": "Consistent quote usage in dialogue",
                "category": RuleType.STYLE_ENFORCEMENT,
                "priority": RecommendationPriority.LOW,
                "impact": "Visual consistency in code",
            },
        ],
        "rpg": [
            {
                "policy_id": "BP_RPG_STAT_NAMING",
                "name": "Game Stat Naming",
                "description": "Consistent naming for character stats (hp, mp, strength, etc.)",
                "category": RuleType.NAMING_CONVENTION,
                "priority": RecommendationPriority.CRITICAL,
                "impact": "Prevents stat tracking bugs",
            },
            {
                "policy_id": "BP_RPG_BALANCE_CONSTANTS",
                "name": "Balance Constants",
                "description": "Extract game balance values to constants",
                "category": RuleType.MAGIC_NUMBER_DETECTION,
                "priority": RecommendationPriority.HIGH,
                "impact": "Easier game balancing and tuning",
            },
        ],
        "generic": [
            {
                "policy_id": "BP_GEN_NAMING",
                "name": "Naming Conventions",
                "description": "Consistent naming conventions across project",
                "category": RuleType.NAMING_CONVENTION,
                "priority": RecommendationPriority.HIGH,
                "impact": "Code readability and maintainability",
            },
            {
                "policy_id": "BP_GEN_INDENTATION",
                "name": "Indentation Style",
                "description": "Consistent indentation (spaces vs tabs)",
                "category": RuleType.STYLE_ENFORCEMENT,
                "priority": RecommendationPriority.MEDIUM,
                "impact": "Visual consistency",
            },
        ],
    }

    def __init__(self, project_type: str = "generic"):
        """Initialize recommendation engine.

        Args:
            project_type: Project type (visual_novel, rpg, puzzle, generic)
        """
        self.project_type = project_type
        self.recommendations: List[PolicyRecommendation] = []

    def analyze_gaps(
        self,
        existing_rules: List[InferredRule],
        pattern_summaries: List[PatternSummary],
        existing_policies: Optional[List[BQFPolicy]] = None,
    ) -> List[PolicyRecommendation]:
        """Analyze gaps between current state and best practices.

        Args:
            existing_rules: Currently inferred rules
            pattern_summaries: Pattern summaries from mining
            existing_policies: Existing BQF policies (if any)

        Returns:
            List of policy recommendations sorted by priority
        """
        self.recommendations.clear()

        # Get best practices for project type
        best_practices = self.BEST_PRACTICES.get(
            self.project_type, self.BEST_PRACTICES["generic"]
        )

        # Analyze coverage for each best practice
        existing_categories = {rule.rule_type for rule in existing_rules}

        for bp in best_practices:
            # Check if category is covered
            coverage = self._calculate_coverage(
                bp["category"], existing_rules, pattern_summaries
            )

            # Recommend if coverage is low
            if coverage < 0.7:  # Less than 70% coverage
                priority = bp["priority"]

                # Adjust priority based on coverage
                if coverage > 0.5:
                    priority = self._downgrade_priority(priority)

                self.recommendations.append(
                    PolicyRecommendation(
                        policy_id=bp["policy_id"],
                        name=bp["name"],
                        description=bp["description"],
                        priority=priority,
                        reason=f"Current coverage: {coverage*100:.0f}%, recommended: 70%+",
                        impact=bp["impact"],
                        existing_coverage=coverage,
                        target_coverage=0.7,
                        metadata={"category": bp["category"].value},
                    )
                )

        # Check for missing anti-pattern detection
        self._check_anti_patterns(existing_rules, pattern_summaries)

        # Sort by priority
        priority_order = {
            RecommendationPriority.CRITICAL: 0,
            RecommendationPriority.HIGH: 1,
            RecommendationPriority.MEDIUM: 2,
            RecommendationPriority.LOW: 3,
            RecommendationPriority.OPTIONAL: 4,
        }
        self.recommendations.sort(key=lambda r: priority_order[r.priority])

        return self.recommendations

    def _calculate_coverage(
        self,
        category: RuleType,
        existing_rules: List[InferredRule],
        pattern_summaries: List[PatternSummary],
    ) -> float:
        """Calculate coverage for a rule category.

        Args:
            category: Rule category
            existing_rules: Existing inferred rules
            pattern_summaries: Pattern summaries

        Returns:
            Coverage score (0.0-1.0)
        """
        # Check if rules exist for category
        matching_rules = [r for r in existing_rules if r.rule_type == category]

        if not matching_rules:
            return 0.0

        # Calculate based on confidence and count
        total_confidence = sum(r.confidence for r in matching_rules)
        avg_confidence = total_confidence / len(matching_rules)

        # Factor in pattern coverage
        relevant_patterns = [
            p
            for p in pattern_summaries
            if self._is_relevant_pattern(p.category, category)
        ]

        if relevant_patterns:
            avg_pattern_coverage = sum(p.coverage for p in relevant_patterns) / len(
                relevant_patterns
            )
            coverage = (avg_confidence + avg_pattern_coverage) / 2
        else:
            coverage = avg_confidence

        return min(1.0, coverage)

    def _is_relevant_pattern(
        self, pattern_category: PatternCategory, rule_type: RuleType
    ) -> bool:
        """Check if pattern category is relevant to rule type."""
        relevance_map = {
            RuleType.NAMING_CONVENTION: [
                PatternCategory.VARIABLE_NAMING,
                PatternCategory.CONSTANT_NAMING,
                PatternCategory.LABEL_NAMING,
                PatternCategory.FUNCTION_NAMING,
            ],
            RuleType.STYLE_ENFORCEMENT: [
                PatternCategory.INDENTATION,
                PatternCategory.QUOTE_STYLE,
            ],
            RuleType.MAGIC_NUMBER_DETECTION: [PatternCategory.MAGIC_NUMBER],
            RuleType.ANTI_PATTERN_DETECTION: [PatternCategory.ANTI_PATTERN],
        }

        relevant_categories = relevance_map.get(rule_type, [])
        return pattern_category in relevant_categories

    def _downgrade_priority(
        self, priority: RecommendationPriority
    ) -> RecommendationPriority:
        """Downgrade priority by one level."""
        downgrade_map = {
            RecommendationPriority.CRITICAL: RecommendationPriority.HIGH,
            RecommendationPriority.HIGH: RecommendationPriority.MEDIUM,
            RecommendationPriority.MEDIUM: RecommendationPriority.LOW,
            RecommendationPriority.LOW: RecommendationPriority.OPTIONAL,
            RecommendationPriority.OPTIONAL: RecommendationPriority.OPTIONAL,
        }
        return downgrade_map.get(priority, priority)

    def _check_anti_patterns(
        self,
        existing_rules: List[InferredRule],
        pattern_summaries: List[PatternSummary],
    ) -> None:
        """Check for missing anti-pattern detection rules."""
        anti_pattern_rules = [
            r for r in existing_rules if r.rule_type == RuleType.ANTI_PATTERN_DETECTION
        ]

        # Recommend deep nesting detection if not present
        has_deep_nesting = any("nesting" in r.name.lower() for r in anti_pattern_rules)
        if not has_deep_nesting:
            self.recommendations.append(
                PolicyRecommendation(
                    policy_id="BP_ANTI_DEEP_NESTING",
                    name="Deep Nesting Detection",
                    description="Detect and prevent excessive nesting depth",
                    priority=RecommendationPriority.MEDIUM,
                    reason="No deep nesting detection found",
                    impact="Improved code maintainability and readability",
                    existing_coverage=0.0,
                    target_coverage=1.0,
                    metadata={"category": "anti_pattern"},
                )
            )

        # Recommend unused variable detection if not present
        has_unused_var = any("unused" in r.name.lower() for r in anti_pattern_rules)
        if not has_unused_var:
            self.recommendations.append(
                PolicyRecommendation(
                    policy_id="BP_ANTI_UNUSED_VAR",
                    name="Unused Variable Detection",
                    description="Detect variables assigned but not used",
                    priority=RecommendationPriority.LOW,
                    reason="No unused variable detection found",
                    impact="Cleaner code and potential bug detection",
                    existing_coverage=0.0,
                    target_coverage=1.0,
                    metadata={"category": "anti_pattern"},
                )
            )

    def export_report(self, path: str) -> None:
        """Export recommendation report to file.

        Args:
            path: Output file path (supports .json, .yaml, .md)
        """
        path_obj = Path(path)

        if path_obj.suffix == ".json":
            self._export_json(path_obj)
        elif path_obj.suffix in [".yaml", ".yml"]:
            self._export_yaml(path_obj)
        elif path_obj.suffix == ".md":
            self._export_markdown(path_obj)
        else:
            raise ValueError(f"Unsupported format: {path_obj.suffix}")

    def _export_json(self, path: Path) -> None:
        """Export to JSON."""
        import json

        data = {
            "project_type": self.project_type,
            "recommendations": [r.to_dict() for r in self.recommendations],
            "summary": {
                "total": len(self.recommendations),
                "by_priority": self._get_priority_counts(),
            },
        }

        with open(path, "w") as f:
            json.dump(data, f, indent=2)
            f.write("\n")

    def _export_yaml(self, path: Path) -> None:
        """Export to YAML."""
        import yaml

        data = {
            "project_type": self.project_type,
            "recommendations": [r.to_dict() for r in self.recommendations],
            "summary": {
                "total": len(self.recommendations),
                "by_priority": self._get_priority_counts(),
            },
        }

        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def _export_markdown(self, path: Path) -> None:
        """Export to Markdown."""
        lines = [
            "# Policy Recommendations Report",
            "",
            f"**Project Type:** {self.project_type}",
            f"**Total Recommendations:** {len(self.recommendations)}",
            "",
            "## Summary by Priority",
            "",
        ]

        priority_counts = self._get_priority_counts()
        for priority, count in priority_counts.items():
            lines.append(f"- **{priority}:** {count}")

        lines.append("")
        lines.append("## Recommendations")
        lines.append("")

        for rec in self.recommendations:
            lines.extend(
                [
                    f"### {rec.name}",
                    "",
                    f"**Priority:** {rec.priority.value.upper()}",
                    f"**Policy ID:** `{rec.policy_id}`",
                    "",
                    f"**Description:** {rec.description}",
                    "",
                    f"**Reason:** {rec.reason}",
                    "",
                    f"**Expected Impact:** {rec.impact}",
                    "",
                    f"**Coverage:** {rec.existing_coverage*100:.1f}% → {rec.target_coverage*100:.1f}%",
                    "",
                    "---",
                    "",
                ]
            )

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _get_priority_counts(self) -> Dict[str, int]:
        """Get count of recommendations by priority."""
        counts = {}
        for rec in self.recommendations:
            priority = rec.priority.value
            counts[priority] = counts.get(priority, 0) + 1
        return counts
