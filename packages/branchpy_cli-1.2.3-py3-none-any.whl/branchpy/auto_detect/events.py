"""
Auto-Detect Telemetry Events

Structured event emission for auto-detect operations with governance integration.

Events:
- auto_detect.pattern_mining.start/complete/error
- auto_detect.rule_inference.start/complete/error
- auto_detect.recommendation.start/complete/error
- auto_detect.scaffolding.start/complete/error
- auto_detect.policy_export.start/complete/error

Version: 0.9.6
"""

import time
import uuid
from typing import Any, Dict, Optional

try:
    from branchpy import logs

    _HAS_LOGS = True
except ImportError:
    _HAS_LOGS = False

    class _LogShim:
        """Fallback logging shim."""

        def info(self, category: str, message: str, **kwargs):
            pass

        def warn(self, category: str, message: str, **kwargs):
            pass

        def error(self, category: str, message: str, **kwargs):
            pass

    logs = _LogShim()

try:
    from branchpy.telemetry.events import emit_event

    _HAS_TELEMETRY = True
except ImportError:
    _HAS_TELEMETRY = False

    def emit_event(
        event_type: str, data: Dict[str, Any], correlation_id: Optional[str] = None
    ) -> None:
        pass


class AutoDetectEvents:
    """Centralized event emission for auto-detect operations."""

    @staticmethod
    def emit_pattern_mining_start(
        project_root: str, engine_type: str, correlation_id: Optional[str] = None
    ) -> str:
        """Emit pattern mining start event.

        Returns:
            correlation_id for tracking
        """
        if correlation_id is None:
            correlation_id = f"auto_detect_{uuid.uuid4().hex[:12]}"

        logs.info(
            "auto_detect.pattern_mining.start",
            f"Starting pattern mining: {project_root}",
            project_root=project_root,
            engine_type=engine_type,
            correlation_id=correlation_id,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.pattern_mining.start",
                {
                    "project_root": project_root,
                    "engine_type": engine_type,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

        return correlation_id

    @staticmethod
    def emit_pattern_mining_complete(
        correlation_id: str,
        pattern_count: int,
        file_count: int,
        line_count: int,
        duration_ms: float,
    ) -> None:
        """Emit pattern mining complete event."""
        logs.info(
            "auto_detect.pattern_mining.complete",
            f"Pattern mining complete: {pattern_count} patterns from {file_count} files",
            correlation_id=correlation_id,
            pattern_count=pattern_count,
            file_count=file_count,
            line_count=line_count,
            duration_ms=duration_ms,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.pattern_mining.complete",
                {
                    "pattern_count": pattern_count,
                    "file_count": file_count,
                    "line_count": line_count,
                    "duration_ms": duration_ms,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_pattern_mining_error(
        correlation_id: str, error: str, error_type: str
    ) -> None:
        """Emit pattern mining error event."""
        logs.error(
            "auto_detect.pattern_mining.error",
            f"Pattern mining failed: {error}",
            correlation_id=correlation_id,
            error=error,
            error_type=error_type,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.pattern_mining.error",
                {"error": error, "error_type": error_type, "timestamp": time.time()},
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_rule_inference_start(
        correlation_id: str, pattern_count: int, min_confidence: float
    ) -> None:
        """Emit rule inference start event."""
        logs.info(
            "auto_detect.rule_inference.start",
            f"Starting rule inference from {pattern_count} patterns",
            correlation_id=correlation_id,
            pattern_count=pattern_count,
            min_confidence=min_confidence,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.rule_inference.start",
                {
                    "pattern_count": pattern_count,
                    "min_confidence": min_confidence,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_rule_inference_complete(
        correlation_id: str, rule_count: int, duration_ms: float
    ) -> None:
        """Emit rule inference complete event."""
        logs.info(
            "auto_detect.rule_inference.complete",
            f"Rule inference complete: {rule_count} rules generated",
            correlation_id=correlation_id,
            rule_count=rule_count,
            duration_ms=duration_ms,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.rule_inference.complete",
                {
                    "rule_count": rule_count,
                    "duration_ms": duration_ms,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_recommendation_start(
        correlation_id: str, project_type: str, rule_count: int
    ) -> None:
        """Emit recommendation start event."""
        logs.info(
            "auto_detect.recommendation.start",
            f"Starting recommendation analysis for {project_type}",
            correlation_id=correlation_id,
            project_type=project_type,
            rule_count=rule_count,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.recommendation.start",
                {
                    "project_type": project_type,
                    "rule_count": rule_count,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_recommendation_complete(
        correlation_id: str,
        recommendation_count: int,
        by_priority: Dict[str, int],
        duration_ms: float,
    ) -> None:
        """Emit recommendation complete event."""
        logs.info(
            "auto_detect.recommendation.complete",
            f"Recommendation analysis complete: {recommendation_count} recommendations",
            correlation_id=correlation_id,
            recommendation_count=recommendation_count,
            by_priority=by_priority,
            duration_ms=duration_ms,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.recommendation.complete",
                {
                    "recommendation_count": recommendation_count,
                    "by_priority": by_priority,
                    "duration_ms": duration_ms,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_scaffolding_start(
        correlation_id: str, project_type: str, mode: str
    ) -> None:
        """Emit scaffolding start event."""
        logs.info(
            "auto_detect.scaffolding.start",
            f"Starting policy scaffolding: {project_type} ({mode})",
            correlation_id=correlation_id,
            project_type=project_type,
            mode=mode,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.scaffolding.start",
                {"project_type": project_type, "mode": mode, "timestamp": time.time()},
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_scaffolding_complete(
        correlation_id: str, policy_count: int, duration_ms: float
    ) -> None:
        """Emit scaffolding complete event."""
        logs.info(
            "auto_detect.scaffolding.complete",
            f"Policy scaffolding complete: {policy_count} policies generated",
            correlation_id=correlation_id,
            policy_count=policy_count,
            duration_ms=duration_ms,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.scaffolding.complete",
                {
                    "policy_count": policy_count,
                    "duration_ms": duration_ms,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_policy_export(
        correlation_id: str, output_path: str, format: str, policy_count: int
    ) -> None:
        """Emit policy export event."""
        logs.info(
            "auto_detect.policy_export.complete",
            f"Policies exported: {output_path} ({format}, {policy_count} policies)",
            correlation_id=correlation_id,
            output_path=output_path,
            format=format,
            policy_count=policy_count,
        )

        if _HAS_TELEMETRY:
            emit_event(
                "auto_detect.policy_export.complete",
                {
                    "output_path": output_path,
                    "format": format,
                    "policy_count": policy_count,
                    "timestamp": time.time(),
                },
                correlation_id=correlation_id,
            )

    @staticmethod
    def emit_governance_event(
        governance_id: str, event_type: str, module: str, data: Dict[str, Any]
    ) -> None:
        """Emit governance event.

        Args:
            governance_id: Governance checkpoint ID
            event_type: Event type (START, COMPLETE, ERROR)
            module: Module name (auto_detect)
            data: Additional event data
        """
        logs.info(
            f"governance.{module}.{event_type.lower()}",
            f"Governance event: {event_type}",
            governance_id=governance_id,
            module=module,
            **data,
        )

        if _HAS_TELEMETRY:
            emit_event(
                f"governance.{module}.{event_type.lower()}",
                {
                    "governance_id": governance_id,
                    "module": module,
                    "event_type": event_type,
                    **data,
                    "timestamp": time.time(),
                },
                correlation_id=governance_id,
            )
