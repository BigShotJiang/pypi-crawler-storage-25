"""
Policy Scaffolding Engine

Generates starter BQF policy sets for new projects with customization
based on project type and detected patterns.

Features:
- Template-based policy generation
- Project type customization (visual novel, RPG, puzzle, generic)
- Confidence-based policy activation
- Incremental policy addition
- Export to multiple formats (YAML, JSON, Python)

Version: 0.9.6
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from branchpy.auto_detect.pattern_miner import PatternSummary
from branchpy.auto_detect.recommendation_engine import PolicyRecommendation
from branchpy.auto_detect.rule_inference import InferredRule
from branchpy.semantics.propagation.bqf_policy_converter import (
    ActionType,
    BQFPolicy,
    PolicyAction,
    PolicyCondition,
    PolicyRule,
    PolicyScope,
    PolicySet,
    PolicySeverity,
    PolicyType,
)


class ProjectType(Enum):
    """Supported project types for scaffolding."""

    VISUAL_NOVEL = "visual_novel"
    RPG = "rpg"
    PUZZLE = "puzzle"
    ADVENTURE = "adventure"
    SIMULATION = "simulation"
    GENERIC = "generic"


class ScaffoldingMode(Enum):
    """Scaffolding generation modes."""

    MINIMAL = "minimal"  # Only critical policies
    RECOMMENDED = "recommended"  # Recommended policies for project type
    COMPREHENSIVE = "comprehensive"  # All available policies
    CUSTOM = "custom"  # User-specified policies


@dataclass
class PolicyTemplate:
    """Template for generating a policy.

    Attributes:
        policy_id: Policy identifier
        name: Policy name
        description: Policy description
        type: Policy type
        severity: Policy severity
        scope: Policy scope
        enabled_by_default: Whether enabled by default
        project_types: Applicable project types
        confidence_threshold: Minimum confidence to include
        template_rules: Rule templates
    """

    policy_id: str
    name: str
    description: str
    type: PolicyType
    severity: PolicySeverity
    scope: PolicyScope
    enabled_by_default: bool = True
    project_types: List[ProjectType] = field(
        default_factory=lambda: [ProjectType.GENERIC]
    )
    confidence_threshold: float = 0.7
    template_rules: List[Dict[str, Any]] = field(default_factory=list)


class PolicyScaffolder:
    """Generates starter policy sets for projects.

    Usage:
        scaffolder = PolicyScaffolder(
            project_type=ProjectType.VISUAL_NOVEL,
            mode=ScaffoldingMode.RECOMMENDED
        )
        policy_set = scaffolder.generate_policy_set(
            inferred_rules=rules,
            recommendations=recommendations
        )
        scaffolder.export(policy_set, output_path)
    """

    # Built-in policy templates
    TEMPLATES = {
        "naming_snake_case": PolicyTemplate(
            policy_id="AUTO_NAMING_SNAKE_CASE",
            name="Snake Case Naming Convention",
            description="Enforce snake_case for variables and labels",
            type=PolicyType.NAMING,
            severity=PolicySeverity.WARNING,
            scope=PolicyScope.GLOBAL,
            enabled_by_default=True,
            project_types=[
                ProjectType.VISUAL_NOVEL,
                ProjectType.RPG,
                ProjectType.GENERIC,
            ],
            confidence_threshold=0.7,
            template_rules=[
                {
                    "pattern": r"^[a-z]+(_[a-z0-9]+)*$",
                    "message": "Use snake_case for variable names",
                    "fix_suggestion": "Convert to snake_case: lowercase with underscores",
                }
            ],
        ),
        "indentation_4_spaces": PolicyTemplate(
            policy_id="AUTO_STYLE_INDENT_4",
            name="4-Space Indentation",
            description="Enforce 4-space indentation",
            type=PolicyType.STYLE,
            severity=PolicySeverity.INFO,
            scope=PolicyScope.FILE,
            enabled_by_default=True,
            project_types=[ProjectType.GENERIC],
            confidence_threshold=0.6,
            template_rules=[
                {
                    "pattern": r"^(    )+\S",
                    "message": "Use 4 spaces for indentation",
                    "fix_suggestion": "Indent with 4 spaces per level",
                }
            ],
        ),
        "magic_number_detection": PolicyTemplate(
            policy_id="AUTO_QUALITY_MAGIC_NUMBERS",
            name="Magic Number Detection",
            description="Detect hardcoded numeric values",
            type=PolicyType.QUALITY,
            severity=PolicySeverity.INFO,
            scope=PolicyScope.GLOBAL,
            enabled_by_default=True,
            project_types=[
                ProjectType.RPG,
                ProjectType.SIMULATION,
                ProjectType.GENERIC,
            ],
            confidence_threshold=0.7,
            template_rules=[
                {
                    "pattern": r"\b\d+(?:\.\d+)?\b",
                    "message": "Consider extracting to named constant",
                    "fix_suggestion": "Define a constant: CONSTANT_NAME = value",
                }
            ],
        ),
        "deep_nesting": PolicyTemplate(
            policy_id="AUTO_ANTI_DEEP_NESTING",
            name="Deep Nesting Detection",
            description="Detect excessive nesting depth",
            type=PolicyType.SEMANTIC,
            severity=PolicySeverity.WARNING,
            scope=PolicyScope.LABEL,
            enabled_by_default=True,
            project_types=[ProjectType.GENERIC],
            confidence_threshold=0.8,
            template_rules=[
                {
                    "pattern": r"^[ \t]{16,}",
                    "message": "Avoid deep nesting (4+ levels)",
                    "fix_suggestion": "Extract nested logic to separate labels/functions",
                }
            ],
        ),
    }

    def __init__(
        self,
        project_type: ProjectType = ProjectType.GENERIC,
        mode: ScaffoldingMode = ScaffoldingMode.RECOMMENDED,
        min_confidence: float = 0.7,
    ):
        """Initialize policy scaffolder.

        Args:
            project_type: Type of project
            mode: Scaffolding mode
            min_confidence: Minimum confidence for policy inclusion
        """
        self.project_type = project_type
        self.mode = mode
        self.min_confidence = min_confidence

    def generate_policy_set(
        self,
        inferred_rules: Optional[List[InferredRule]] = None,
        recommendations: Optional[List[PolicyRecommendation]] = None,
        pattern_summaries: Optional[List[PatternSummary]] = None,
    ) -> PolicySet:
        """Generate a complete policy set.

        Args:
            inferred_rules: Inferred rules from pattern mining
            recommendations: Policy recommendations
            pattern_summaries: Pattern summaries for context

        Returns:
            Complete PolicySet ready for export
        """
        policies: List[BQFPolicy] = []

        # Add template-based policies
        if self.mode in [
            ScaffoldingMode.MINIMAL,
            ScaffoldingMode.RECOMMENDED,
            ScaffoldingMode.COMPREHENSIVE,
        ]:
            policies.extend(self._generate_from_templates())

        # Add inferred rule policies
        if inferred_rules:
            policies.extend(self._generate_from_rules(inferred_rules))

        # Add recommended policies
        if recommendations and self.mode in [
            ScaffoldingMode.RECOMMENDED,
            ScaffoldingMode.COMPREHENSIVE,
        ]:
            policies.extend(self._generate_from_recommendations(recommendations))

        # Remove duplicates
        policies = self._deduplicate_policies(policies)

        # Sort by type and severity
        policies.sort(key=lambda p: (p.type.value, p.severity.value))

        return PolicySet(
            name=f"{self.project_type.value.replace('_', ' ').title()} Policy Set",
            version="1.0.0",
            policies=policies,
            metadata={
                "project_type": self.project_type.value,
                "scaffolding_mode": self.mode.value,
                "min_confidence": self.min_confidence,
                "generated_by": "PolicyScaffolder",
                "total_policies": len(policies),
            },
        )

    def _generate_from_templates(self) -> List[BQFPolicy]:
        """Generate policies from built-in templates."""
        policies = []

        for template_key, template in self.TEMPLATES.items():
            # Check if template applies to project type
            if (
                self.project_type not in template.project_types
                and ProjectType.GENERIC not in template.project_types
            ):
                continue

            # Check mode
            if self.mode == ScaffoldingMode.MINIMAL and template.severity not in [
                PolicySeverity.BLOCKING,
                PolicySeverity.ERROR,
            ]:
                continue

            # Create policy from template
            policy = self._create_policy_from_template(template)
            policies.append(policy)

        return policies

    def _create_policy_from_template(self, template: PolicyTemplate) -> BQFPolicy:
        """Create BQF policy from template."""
        rules = []

        for idx, rule_template in enumerate(template.template_rules):
            condition = PolicyCondition(
                type="pattern",
                pattern=rule_template["pattern"],
                description=rule_template["message"],
                metadata={"template": True},
            )

            action = PolicyAction(
                action_type=(
                    ActionType.ENFORCE
                    if template.severity == PolicySeverity.ERROR
                    else ActionType.REPORT
                ),
                message=rule_template["message"],
                fix_suggestion=rule_template.get("fix_suggestion"),
                metadata={},
            )

            rule = PolicyRule(
                id=f"{template.policy_id}_RULE_{idx+1}",
                name=rule_template["message"],
                condition=condition,
                action=action,
                enabled=template.enabled_by_default,
                metadata={"template_source": True},
            )

            rules.append(rule)

        return BQFPolicy(
            id=template.policy_id,
            name=template.name,
            type=template.type,
            severity=template.severity,
            scope=template.scope,
            rules=rules,
            version="1.0.0",
            description=template.description,
            tags=["scaffolded", "template", self.project_type.value],
            metadata={
                "scaffolded": True,
                "project_type": self.project_type.value,
                "enabled_by_default": template.enabled_by_default,
            },
        )

    def _generate_from_rules(
        self, inferred_rules: List[InferredRule]
    ) -> List[BQFPolicy]:
        """Generate policies from inferred rules."""
        policies = []

        for rule in inferred_rules:
            if rule.confidence < self.min_confidence:
                continue

            policy = rule.to_bqf_policy()
            policy.tags.append("scaffolded")
            policy.tags.append(self.project_type.value)
            policy.metadata["scaffolded"] = True
            policy.metadata["project_type"] = self.project_type.value

            policies.append(policy)

        return policies

    def _generate_from_recommendations(
        self, recommendations: List[PolicyRecommendation]
    ) -> List[BQFPolicy]:
        """Generate policies from recommendations."""
        policies = []

        for rec in recommendations:
            # Skip low-priority recommendations in minimal mode
            if self.mode == ScaffoldingMode.MINIMAL and rec.priority.value not in [
                "critical",
                "high",
            ]:
                continue

            # Create placeholder policy
            policy = self._create_recommendation_policy(rec)
            policies.append(policy)

        return policies

    def _create_recommendation_policy(self, rec: PolicyRecommendation) -> BQFPolicy:
        """Create policy from recommendation."""
        # Map priority to severity
        severity_map = {
            "critical": PolicySeverity.ERROR,
            "high": PolicySeverity.WARNING,
            "medium": PolicySeverity.WARNING,
            "low": PolicySeverity.INFO,
            "optional": PolicySeverity.INFO,
        }
        severity = severity_map.get(rec.priority.value, PolicySeverity.INFO)

        # Create placeholder rule
        condition = PolicyCondition(
            type="custom",
            description=rec.description,
            metadata={"recommendation": True, "reason": rec.reason},
        )

        action = PolicyAction(
            action_type=ActionType.SUGGEST,
            message=rec.description,
            fix_suggestion=rec.impact,
            metadata={"priority": rec.priority.value},
        )

        rule = PolicyRule(
            id=f"{rec.policy_id}_RULE",
            name=rec.name,
            condition=condition,
            action=action,
            enabled=True,
            metadata={"recommended": True},
        )

        return BQFPolicy(
            id=rec.policy_id,
            name=rec.name,
            type=PolicyType.CUSTOM,
            severity=severity,
            scope=PolicyScope.GLOBAL,
            rules=[rule],
            version="1.0.0",
            description=rec.description,
            tags=["scaffolded", "recommended", self.project_type.value],
            metadata={
                "scaffolded": True,
                "recommended": True,
                "project_type": self.project_type.value,
                "priority": rec.priority.value,
                "reason": rec.reason,
                "impact": rec.impact,
            },
        )

    def _deduplicate_policies(self, policies: List[BQFPolicy]) -> List[BQFPolicy]:
        """Remove duplicate policies."""
        seen_ids = set()
        unique_policies = []

        for policy in policies:
            if policy.id not in seen_ids:
                seen_ids.add(policy.id)
                unique_policies.append(policy)

        return unique_policies

    def export(
        self, policy_set: PolicySet, output_path: Path | str, format: str = "auto"
    ) -> None:
        """Export policy set to file.

        Args:
            policy_set: PolicySet to export
            output_path: Output file path
            format: Export format (auto, yaml, json, python)
        """
        output_path = Path(output_path)

        # Auto-detect format from extension
        if format == "auto":
            suffix = output_path.suffix.lower()
            if suffix in [".yaml", ".yml"]:
                format = "yaml"
            elif suffix == ".json":
                format = "json"
            elif suffix == ".py":
                format = "python"
            else:
                format = "yaml"  # Default

        # Export
        if format == "yaml":
            self._export_yaml(policy_set, output_path)
        elif format == "json":
            self._export_json(policy_set, output_path)
        elif format == "python":
            self._export_python(policy_set, output_path)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _export_yaml(self, policy_set: PolicySet, path: Path) -> None:
        """Export to YAML."""
        with open(path, "w") as f:
            yaml.dump(
                policy_set.to_dict(), f, default_flow_style=False, sort_keys=False
            )

    def _export_json(self, policy_set: PolicySet, path: Path) -> None:
        """Export to JSON."""
        with open(path, "w") as f:
            json.dump(policy_set.to_dict(), f, indent=2)
            f.write("\n")

    def _export_python(self, policy_set: PolicySet, path: Path) -> None:
        """Export to Python module."""
        lines = [
            '"""',
            f"Auto-generated BQF Policy Set: {policy_set.name}",
            "",
            "Generated by: PolicyScaffolder",
            f"Project Type: {self.project_type.value}",
            f"Version: {policy_set.version}",
            '"""',
            "",
            "from branchpy.bqf.policy_base import Policy, PolicyConfig, PolicyContext, PolicyResult, PolicyStatus",
            "",
            "",
        ]

        # Generate policy classes
        for policy in policy_set.policies:
            class_name = self._policy_id_to_class_name(policy.id)

            lines.extend(
                [
                    f"class {class_name}(Policy):",
                    '    """',
                    f"    {policy.name}",
                    "    ",
                    f"    {policy.description}",
                    '    """',
                    "    ",
                    f'    POLICY_ID = "{policy.id}"',
                    '    MODULE = "auto_detect"',
                    "    ",
                    "    def get_default_config(self) -> PolicyConfig:",
                    "        return PolicyConfig(",
                    "            policy_id=self.POLICY_ID,",
                    f'            enabled={str(policy.metadata.get("enabled_by_default", True))},',
                    "            thresholds={},",
                    "            limits={}",
                    "        )",
                    "    ",
                    "    def evaluate(self, ctx: PolicyContext) -> PolicyResult:",
                    '        """Evaluate policy."""',
                    "        # TODO: Implement evaluation logic",
                    "        return PolicyResult(",
                    "            policy_id=self.POLICY_ID,",
                    "            status=PolicyStatus.PASS,",
                    '            message="Policy evaluation not yet implemented"',
                    "        )",
                    "",
                    "",
                ]
            )

        with open(path, "w") as f:
            f.write("\n".join(lines))

    def _policy_id_to_class_name(self, policy_id: str) -> str:
        """Convert policy ID to Python class name."""
        # Remove prefix, split by underscore, capitalize
        parts = policy_id.replace("AUTO_", "").split("_")
        return "".join(word.capitalize() for word in parts) + "Policy"

    def generate_readme(self, policy_set: PolicySet, output_path: Path | str) -> None:
        """Generate README for policy set.

        Args:
            policy_set: PolicySet
            output_path: Output path for README.md
        """
        lines = [
            f"# {policy_set.name}",
            "",
            f"**Version:** {policy_set.version}",
            f"**Project Type:** {self.project_type.value}",
            f"**Scaffolding Mode:** {self.mode.value}",
            "",
            "## Overview",
            "",
            f"This policy set contains {len(policy_set.policies)} auto-generated BQF policies",
            f'customized for {self.project_type.value.replace("_", " ")} projects.',
            "",
            "## Policies",
            "",
        ]

        # Group by type
        by_type: Dict[PolicyType, List[BQFPolicy]] = {}
        for policy in policy_set.policies:
            if policy.type not in by_type:
                by_type[policy.type] = []
            by_type[policy.type].append(policy)

        for policy_type, policies in sorted(by_type.items(), key=lambda x: x[0].value):
            lines.append(f"### {policy_type.value.title()} Policies ({len(policies)})")
            lines.append("")

            for policy in policies:
                lines.extend(
                    [
                        f"#### {policy.name}",
                        "",
                        f"**ID:** `{policy.id}`",
                        f"**Severity:** {policy.severity.value}",
                        f"**Scope:** {policy.scope.value}",
                        "",
                        f"{policy.description}",
                        "",
                        f"**Rules:** {len(policy.rules)}",
                        "",
                    ]
                )

        lines.extend(
            [
                "## Usage",
                "",
                "```python",
                "from branchpy.bqf import PolicyRegistry",
                "",
                "# Load policies",
                "registry = PolicyRegistry()",
                f'registry.load_from_file("{Path(output_path).stem}.yaml")',
                "",
                "# Run policies",
                "from branchpy.bqf import PolicyEnforcer",
                "enforcer = PolicyEnforcer(registry)",
                'report = enforcer.run_policies(module="auto_detect", context=...)',
                "```",
                "",
                "## Customization",
                "",
                "Edit the generated YAML/JSON file to:",
                "- Enable/disable specific policies",
                "- Adjust severity levels",
                "- Modify thresholds",
                "- Add custom rules",
                "",
            ]
        )

        with open(output_path, "w") as f:
            f.write("\n".join(lines))
