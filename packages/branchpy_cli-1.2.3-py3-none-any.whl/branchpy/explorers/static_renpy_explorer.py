"""
Static BFS Explorer for Ren'Py Projects (Phase 3B.1-A)

Builds a reachable flow graph from AST artifacts without executing Ren'Py.
Consumes output from branchpy.analysis.sae.indexer (labels, jumps, calls, choice_points).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from branchpy import logs


class EdgeCertainty(str, Enum):
    """Classification of edge reachability confidence."""

    CERTAIN = "certain"  # Direct jump/call to known label
    LIKELY = "likely"  # Menu option with no explicit condition
    UNKNOWN_CONDITION = "unknown_condition"  # Depends on variables (if/while)
    SCREEN_MENU = "screen_menu"  # Screen language choices
    DYNAMIC_JUMP = "dynamic"  # Computed target (jump expression)
    PYTHON_EFFECT = "python"  # Python block side effects


@dataclass(frozen=True)
class NodeRef:
    """Reference to a node in the flow graph."""

    label: str
    file: Optional[str] = None
    line: Optional[int] = None
    type: str = "label"  # "label" | "choice_point" | ...

    def __hash__(self):
        return hash((self.label, self.file, self.line, self.type))


@dataclass(frozen=True)
class Edge:
    """Directed edge in the flow graph."""

    from_: NodeRef
    to: NodeRef
    type: str  # "jump" | "call" | "return" | "menu_option" | "fallthrough"
    certainty: EdgeCertainty
    uncertainty_reason: Optional[str] = None

    def __hash__(self):
        return hash((self.from_, self.to, self.type, self.certainty))


@dataclass
class Uncertainty:
    """Location of uncertain control flow that may need runtime validation."""

    location: str  # File:line string (not NodeRef to keep it simple)
    reason: str  # Human-readable reason (not EdgeCertainty enum)
    detail: str


@dataclass
class StaticGraph:
    """Complete static flow graph with uncertainty annotations."""

    version: int
    timestamp: str
    nodes: List[NodeRef]
    edges: List[Edge]
    uncertainties: List[Uncertainty]
    menu_nesting: Optional[Any] = None  # MenuNestingAnalysis (optional)

    def to_json_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict."""
        result = {
            "version": self.version,
            "timestamp": self.timestamp,
            "nodes": [asdict(n) for n in self.nodes],
            "edges": [
                {
                    "from": asdict(e.from_),
                    "to": asdict(e.to),
                    "type": e.type,
                    "certainty": e.certainty.value,
                    **(
                        {"uncertainty_reason": e.uncertainty_reason}
                        if e.uncertainty_reason
                        else {}
                    ),
                }
                for e in self.edges
            ],
            "uncertainties": [
                {
                    "location": u.location,  # Already a string
                    "reason": u.reason,  # Already a string
                    "detail": u.detail,
                }
                for u in self.uncertainties
            ],
        }

        # Add menu nesting if available
        if self.menu_nesting:
            result["menu_nesting"] = self.menu_nesting.to_dict()

        return result

    def predecessors(self, label: str, hops: int = 1) -> Set[str]:
        """Get labels that reach this label within k hops (upstream)."""
        reached = set()
        frontier = {label}

        for _ in range(hops):
            next_frontier = set()
            for e in self.edges:
                if e.to.label in frontier and e.from_.label not in reached:
                    next_frontier.add(e.from_.label)
            reached.update(next_frontier)
            frontier = next_frontier
            if not frontier:
                break

        return reached

    def successors(self, label: str, hops: int = 1) -> Set[str]:
        """Get labels reachable from this label within k hops (downstream)."""
        reached = set()
        frontier = {label}

        for _ in range(hops):
            next_frontier = set()
            for e in self.edges:
                if e.from_.label in frontier and e.to.label not in reached:
                    next_frontier.add(e.to.label)
            reached.update(next_frontier)
            frontier = next_frontier
            if not frontier:
                break

        return reached


class StaticRenpyExplorer:
    """
    Builds a reachable flow graph from static artifacts.

    This does NOT execute Ren'Py; it uses the AST-derived indexes produced by
    branchpy.analysis.sae.indexer.

    Artifacts consumed:
    - labels: Dict[str, IndexEntry] - label definitions
    - jumps: List[IndexEntry] - jump statements
    - calls: List[IndexEntry] - call statements
    - choice_points: List[Dict] - menu AST with options/targets
    """

    def __init__(
        self,
        project_root: Path,
        label_index: Dict[str, Any],
        choice_points: List[Dict[str, Any]],
        jumps: List[Any],
        calls: List[Any],
    ):
        """
        Initialize explorer with AST artifacts.

        Args:
            project_root: Absolute path to project root
            label_index: ProjectIndex.labels (dict of label name → IndexEntry)
            choice_points: ProjectIndex.choice_points (list of menu AST dicts)
            jumps: ProjectIndex.jumps (list of jump IndexEntries)
            calls: ProjectIndex.calls (list of call IndexEntries)
        """
        self.project_root = Path(project_root)
        self.label_index = label_index
        self.choice_points = choice_points
        self.jumps = jumps
        self.calls = calls

        # Preindex for fast lookups during BFS
        self._jump_edges: Dict[str, List[Tuple[int, str, bool, Optional[str]]]] = (
            {}
        )  # from_label → [(line, to_label, conditional, condition_kind)]
        self._call_edges: Dict[str, List[Tuple[int, str]]] = (
            {}
        )  # from_label → [(line, to_label)]
        self._menu_edges: Dict[str, List[Tuple[int, str, str]]] = (
            {}
        )  # from_label → [(line, text, to_label)]

        self._build_edge_indexes()

    def _build_edge_indexes(self) -> None:
        """Preindex edges for fast BFS traversal."""

        # Jump edges: extract source label from IndexEntry.file + line
        for jump_entry in self.jumps:
            jump_target = (
                jump_entry.name
                if hasattr(jump_entry, "name")
                else jump_entry.get("name")
            )
            jump_file = (
                jump_entry.file
                if hasattr(jump_entry, "file")
                else jump_entry.get("file")
            )
            jump_line = (
                jump_entry.line
                if hasattr(jump_entry, "line")
                else jump_entry.get("line")
            )

            # Extract conditional metadata (Phase 3B.1-A)
            jump_extra = (
                jump_entry.extra
                if hasattr(jump_entry, "extra")
                else jump_entry.get("extra", {})
            )
            conditional = jump_extra.get("conditional", False) if jump_extra else False
            condition_kind = jump_extra.get("condition_kind") if jump_extra else None

            # Find which label contains this jump (by file + line)
            source_label = self._find_containing_label(jump_file, jump_line)
            if source_label:
                self._jump_edges.setdefault(source_label, []).append(
                    (jump_line, jump_target, conditional, condition_kind)
                )

        # Call edges: similar to jumps
        for call_entry in self.calls:
            call_target = (
                call_entry.name
                if hasattr(call_entry, "name")
                else call_entry.get("name")
            )
            call_file = (
                call_entry.file
                if hasattr(call_entry, "file")
                else call_entry.get("file")
            )
            call_line = (
                call_entry.line
                if hasattr(call_entry, "line")
                else call_entry.get("line")
            )

            source_label = self._find_containing_label(call_file, call_line)
            if source_label:
                self._call_edges.setdefault(source_label, []).append(
                    (call_line, call_target)
                )

        # Menu edges: from choice_points artifact
        for cp in self.choice_points:
            loc = cp.get("location", {})
            src_label = loc.get("label")
            src_line = loc.get("line")

            if not src_label:
                continue

            for opt in cp.get("options", []):
                opt_text = opt.get("text", "")
                targets = opt.get("targets", [])

                for target in targets:
                    self._menu_edges.setdefault(src_label, []).append(
                        (src_line, opt_text, target)
                    )

        logs.info(
            "explorer.edges_indexed",
            f"Indexed {len(self._jump_edges)} jump sources, "
            f"{len(self._call_edges)} call sources, "
            f"{len(self._menu_edges)} menu sources",
        )

    def _find_containing_label(self, file: str, line: int) -> Optional[str]:
        """Find which label contains the given file+line."""
        # Simple heuristic: find the label in the same file with line <= given line
        # and no other label between them

        candidates = []
        for label_name, label_info in self.label_index.items():
            label_file = (
                label_info.get("file")
                if isinstance(label_info, dict)
                else getattr(label_info, "file", None)
            )
            label_line = (
                label_info.get("line")
                if isinstance(label_info, dict)
                else getattr(label_info, "line", None)
            )

            if label_file == file and label_line is not None and label_line <= line:
                candidates.append((label_line, label_name))

        if not candidates:
            return None

        # Return the label with the highest line number <= target line
        candidates.sort(reverse=True)
        return candidates[0][1]

    def explore(
        self, start_label: str = "start", analyze_menus: bool = True
    ) -> StaticGraph:
        """
        BFS exploration from start_label.

        Follows:
        - Jump statements (CERTAIN)
        - Call statements (CERTAIN)
        - Menu options (LIKELY by default, UNKNOWN_CONDITION if condition_raw present)

        Args:
            start_label: Starting label for BFS
            analyze_menus: If True, perform nested menu analysis

        Returns:
            StaticGraph with nodes, edges, uncertainties, and optional menu nesting
        """
        visited: Set[str] = set()
        frontier: List[str] = [start_label]

        nodes: Dict[str, NodeRef] = {}
        edges: List[Edge] = []
        uncertainties: List[Uncertainty] = []

        def ensure_node(label: str) -> NodeRef:
            """Get or create node for label."""
            if label in nodes:
                return nodes[label]

            # Look up in label index
            label_info = self.label_index.get(label)
            if label_info:
                file = (
                    label_info.get("file")
                    if isinstance(label_info, dict)
                    else getattr(label_info, "file", None)
                )
                line = (
                    label_info.get("line")
                    if isinstance(label_info, dict)
                    else getattr(label_info, "line", None)
                )
                n = NodeRef(label=label, file=file, line=line, type="label")
            else:
                n = NodeRef(label=label, type="label")

            nodes[label] = n
            return n

        logs.info("explorer.start", f"Starting BFS from label: {start_label}")

        while frontier:
            current_label = frontier.pop(0)
            if current_label in visited:
                continue
            visited.add(current_label)

            src_node = ensure_node(current_label)

            # Process jump edges
            for line, target, conditional, condition_kind in self._jump_edges.get(
                current_label, []
            ):
                dst_node = ensure_node(target)

                # Check if jump is inside conditional block
                if conditional:
                    certainty = EdgeCertainty.UNKNOWN_CONDITION
                    reason = f"jump inside {condition_kind or 'conditional block'}"
                    uncertainties.append(
                        Uncertainty(
                            location=f"{src_node.file}:{line}",
                            reason=reason,
                            detail=f"jump to {target}",
                        )
                    )
                else:
                    certainty = EdgeCertainty.CERTAIN
                    reason = None

                edges.append(
                    Edge(
                        from_=NodeRef(
                            label=current_label,
                            file=src_node.file,
                            line=line,
                            type="statement",
                        ),
                        to=dst_node,
                        type="jump",
                        certainty=certainty,
                    )
                )
                if target not in visited:
                    frontier.append(target)

            # Process call edges
            for line, target in self._call_edges.get(current_label, []):
                dst_node = ensure_node(target)
                edges.append(
                    Edge(
                        from_=NodeRef(
                            label=current_label,
                            file=src_node.file,
                            line=line,
                            type="statement",
                        ),
                        to=dst_node,
                        type="call",
                        certainty=EdgeCertainty.CERTAIN,
                    )
                )
                if target not in visited:
                    frontier.append(target)

            # Process menu edges
            for line, text, target in self._menu_edges.get(current_label, []):
                dst_node = ensure_node(target)

                # Check if this menu option has a condition
                # (look up in choice_points to find condition_raw)
                has_condition = self._menu_has_condition(current_label, line, target)

                if has_condition:
                    certainty = EdgeCertainty.UNKNOWN_CONDITION
                    reason = f"menu option '{text}' depends on runtime condition"
                    uncertainties.append(
                        Uncertainty(
                            location=NodeRef(
                                label=current_label,
                                file=src_node.file,
                                line=line,
                                type="choice_point",
                            ),
                            reason=EdgeCertainty.UNKNOWN_CONDITION,
                            detail=reason,
                        )
                    )
                else:
                    certainty = EdgeCertainty.LIKELY
                    reason = None

                edges.append(
                    Edge(
                        from_=NodeRef(
                            label=current_label,
                            file=src_node.file,
                            line=line,
                            type="choice_point",
                        ),
                        to=dst_node,
                        type="menu_option",
                        certainty=certainty,
                        uncertainty_reason=reason,
                    )
                )

                if target not in visited:
                    frontier.append(target)

        logs.info(
            "explorer.complete",
            f"Explored {len(visited)} labels, {len(edges)} edges, {len(uncertainties)} uncertainties",
        )

        # Perform menu nesting analysis if requested
        menu_nesting_result = None
        if analyze_menus:
            try:
                from branchpy.explorers.menu_nesting import analyze_menu_nesting

                menu_nesting_result = analyze_menu_nesting(
                    self.choice_points, self.label_index
                )
                logs.info(
                    "explorer.menu_nesting",
                    f"Menu nesting: {menu_nesting_result.total_menus} total, "
                    f"{menu_nesting_result.nested_menus} nested, "
                    f"max depth {menu_nesting_result.max_depth}",
                )
            except Exception as e:
                logs.warning(
                    "explorer.menu_nesting_failed", f"Menu nesting analysis failed: {e}"
                )

        return StaticGraph(
            version=1,
            timestamp=datetime.utcnow().isoformat(timespec="seconds"),
            nodes=list(nodes.values()),
            edges=edges,
            uncertainties=uncertainties,
            menu_nesting=menu_nesting_result,
        )

    def _menu_has_condition(self, label: str, line: int, target: str) -> bool:
        """Check if a menu option has a runtime condition."""
        for cp in self.choice_points:
            loc = cp.get("location", {})
            if loc.get("label") == label and loc.get("line") == line:
                for opt in cp.get("options", []):
                    if target in opt.get("targets", []):
                        return opt.get("condition_raw") is not None
        return False
