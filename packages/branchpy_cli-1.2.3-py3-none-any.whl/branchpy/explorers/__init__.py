"""
Static flow graph exploration for BranchPy.

Phase 3B.1-A: Static analysis becomes the default, fast path for flow analysis.
Phase 3B.2: Nested menu detection and understanding.
"""

from .menu_nesting import (
    MenuChoice,
    MenuContainer,
    MenuNestingAnalysis,
    MenuNestingAnalyzer,
    MenuOutcomeType,
    analyze_menu_nesting,
)
from .static_renpy_explorer import EdgeCertainty, StaticGraph, StaticRenpyExplorer

__all__ = [
    "StaticRenpyExplorer",
    "StaticGraph",
    "EdgeCertainty",
    "MenuNestingAnalyzer",
    "MenuNestingAnalysis",
    "MenuContainer",
    "MenuChoice",
    "MenuOutcomeType",
    "analyze_menu_nesting",
]
