"""
Nested Menu Detection and Understanding (Phase 3B.2)

Analyzes menu structure for nesting patterns:
- Syntactic nesting (menu inside choice block)
- Graph nesting (menu reached by choice → jump/call)
- Conditional menus
- Depth computation and outcome analysis

Follows BranchPy SOP: structured logging, governance-ready, engine-agnostic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

from branchpy import logs


class MenuOutcomeType(str, Enum):
    """Classification of menu leaf outcomes."""

    JUMP = "jump"  # Choice leads to jump
    CALL = "call"  # Choice leads to call
    RETURN = "return"  # Choice leads to return
    END = "end"  # Choice has no terminal statement (fallthrough)
    LOOP = "loop"  # Choice leads back to same/parent menu
    NESTED_MENU = "nested_menu"  # Choice leads to another menu


@dataclass
class MenuChoice:
    """Represents a single menu choice with metadata."""

    index: int
    text: str
    text_raw: str  # Best-effort extraction (may be <expr> if dynamic)
    targets: List[str]  # Label targets (jump/call)
    condition_raw: Optional[str] = None
    outcome_type: MenuOutcomeType = MenuOutcomeType.END
    leads_to_menu: Optional[str] = None  # Choice point ID if leads to nested menu


@dataclass
class MenuContainer:
    """Container node for a menu with nested structure analysis."""

    choice_point_id: str
    label: str
    file: str
    line: int

    # Structure
    parent_menu_id: Optional[str] = None  # If this is nested inside another menu
    parent_choice_index: Optional[int] = None  # Which parent choice leads here
    depth: int = 0  # Nesting depth (0 = root menu)

    # Choices
    choices: List[MenuChoice] = field(default_factory=list)
    choice_count: int = 0
    conditional_choice_count: int = 0

    # Metadata
    is_syntactically_nested: bool = False  # Menu inside choice block
    is_graph_nested: bool = False  # Menu reached by jump/call from choice

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict."""
        return {
            "choice_point_id": self.choice_point_id,
            "label": self.label,
            "file": self.file,
            "line": self.line,
            "parent_menu_id": self.parent_menu_id,
            "parent_choice_index": self.parent_choice_index,
            "depth": self.depth,
            "choices": [
                {
                    "index": c.index,
                    "text": c.text,
                    "text_raw": c.text_raw,
                    "targets": c.targets,
                    "condition_raw": c.condition_raw,
                    "outcome_type": c.outcome_type.value,
                    "leads_to_menu": c.leads_to_menu,
                }
                for c in self.choices
            ],
            "choice_count": self.choice_count,
            "conditional_choice_count": self.conditional_choice_count,
            "is_syntactically_nested": self.is_syntactically_nested,
            "is_graph_nested": self.is_graph_nested,
        }


@dataclass
class MenuNestingAnalysis:
    """Complete nested menu analysis for a project."""

    version: int
    timestamp: str
    menus: List[MenuContainer]
    max_depth: int = 0
    total_menus: int = 0
    nested_menus: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict."""
        return {
            "version": self.version,
            "timestamp": self.timestamp,
            "menus": [m.to_dict() for m in self.menus],
            "max_depth": self.max_depth,
            "total_menus": self.total_menus,
            "nested_menus": self.nested_menus,
        }


class MenuNestingAnalyzer:
    """
    Analyzes menu nesting structure from static artifacts.

    Two-phase approach:
    1. Detection: build menu containers with choice metadata
    2. Understanding: compute nesting depth and outcome types
    """

    def __init__(
        self,
        choice_points: List[Dict[str, Any]],
        label_index: Dict[str, Any],
    ):
        """
        Initialize analyzer with AST artifacts.

        Args:
            choice_points: List of menu AST dicts from indexer
            label_index: Dict of label name → IndexEntry
        """
        self.choice_points = choice_points
        self.label_index = label_index

        # Build lookup maps
        self._menu_by_id: Dict[str, MenuContainer] = {}
        self._menu_by_label: Dict[str, List[str]] = {}  # label → [choice_point_ids]
        self._menu_by_location: Dict[Tuple[str, int], str] = (
            {}
        )  # (file, line) → choice_point_id

    def analyze(self) -> MenuNestingAnalysis:
        """
        Perform full nested menu analysis.

        Returns:
            MenuNestingAnalysis with structure and metadata
        """
        from datetime import datetime

        logs.info(
            "menu_nesting.start",
            f"Analyzing {len(self.choice_points)} menus for nesting",
        )

        # Phase 1: Build menu containers
        self._build_menu_containers()

        # Phase 0: Apply syntactic parent links (menu inside choice block)
        self._apply_syntactic_nesting()

        # Phase 2: Detect graph-level nesting relationships (menu A → jump → menu B)
        self._detect_nesting()

        # Phase 3: Compute depth and outcomes
        self._compute_depth()
        self._classify_outcomes()

        # Build analysis result
        menus = list(self._menu_by_id.values())
        max_depth = max((m.depth for m in menus), default=0)
        nested_count = sum(1 for m in menus if m.depth > 0)
        syntactic_count = sum(1 for m in menus if m.is_syntactically_nested)
        graph_count = sum(1 for m in menus if m.is_graph_nested)

        logs.info(
            "menu_nesting.complete",
            f"Found {len(menus)} menus: {syntactic_count} syntactic, {graph_count} graph-nested, max depth {max_depth}",
        )

        return MenuNestingAnalysis(
            version=1,
            timestamp=datetime.utcnow().isoformat(timespec="seconds"),
            menus=menus,
            max_depth=max_depth,
            total_menus=len(menus),
            nested_menus=nested_count,
        )

    def _build_menu_containers(self) -> None:
        """Phase 1: Convert choice_points to MenuContainer objects."""

        for cp in self.choice_points:
            cp_id = cp.get("choice_point_id")
            loc = cp.get("location", {})
            label = loc.get("label")
            file = loc.get("file")
            line = loc.get("line")

            if not cp_id or not label or not file or line is None:
                logs.warning(
                    "menu_nesting.invalid_choice_point",
                    f"Skipping choice point with missing metadata: {cp}",
                )
                continue

            # Build choices
            choices = []
            conditional_count = 0

            for opt in cp.get("options", []):
                idx = opt.get("index", 0)
                text = opt.get("text", "")
                targets = opt.get("targets", [])
                condition = opt.get("condition_raw")

                if condition:
                    conditional_count += 1

                choice = MenuChoice(
                    index=idx,
                    text=text,
                    text_raw=text,  # For now, assume text is static
                    targets=targets,
                    condition_raw=condition,
                )
                choices.append(choice)

            # Create container
            container = MenuContainer(
                choice_point_id=cp_id,
                label=label,
                file=file,
                line=line,
                choices=choices,
                choice_count=len(choices),
                conditional_choice_count=conditional_count,
            )

            # Index
            self._menu_by_id[cp_id] = container
            self._menu_by_label.setdefault(label, []).append(cp_id)
            self._menu_by_location[(file, line)] = cp_id

    def _apply_syntactic_nesting(self) -> None:
        """
        Phase 0: Apply syntactic parent links (menu inside choice block).

        Syntactic nesting takes precedence over graph-level nesting.
        When a menu is emitted with parent_choice_point_id, it is directly
        contained within a parent choice block.
        """

        for cp in self.choice_points:
            cp_id = cp.get("choice_point_id")
            parent_cp_id = cp.get("parent_choice_point_id")
            parent_choice_idx = cp.get("parent_choice_index")
            is_syntactic = cp.get("is_syntactically_nested", False)

            if not parent_cp_id or not is_syntactic:
                continue  # Not syntactically nested

            menu = self._menu_by_id.get(cp_id)
            parent_menu = self._menu_by_id.get(parent_cp_id)

            if not menu or not parent_menu:
                logs.warning(
                    "menu_nesting.missing_parent",
                    f"Menu {cp_id} has syntactic parent {parent_cp_id} but parent not found",
                )
                continue

            # Apply syntactic parent linkage
            menu.parent_menu_id = parent_cp_id
            menu.parent_choice_index = parent_choice_idx
            menu.is_syntactically_nested = True

            # Mark parent choice as leading to nested menu
            if 0 <= parent_choice_idx < len(parent_menu.choices):
                parent_choice = parent_menu.choices[parent_choice_idx]
                parent_choice.leads_to_menu = cp_id
                parent_choice.outcome_type = MenuOutcomeType.NESTED_MENU

            logs.debug(
                "menu_nesting.syntactic_parent",
                f"Menu {cp_id} is syntactically nested in {parent_cp_id} choice {parent_choice_idx}",
            )

    def _detect_nesting(self) -> None:
        """Phase 2: Detect graph-level parent-child relationships (menu A → jump → menu B)."""

        # Strategy: For each menu, check if any choice targets point to labels
        # that contain other menus (but skip if already syntactically nested)

        for cp_id, menu in self._menu_by_id.items():
            for choice in menu.choices:
                # Skip if this choice already leads to a syntactic nested menu
                if choice.leads_to_menu:
                    continue

                for target_label in choice.targets:
                    # Does this target label contain any menus?
                    child_menu_ids = self._menu_by_label.get(target_label, [])

                    for child_id in child_menu_ids:
                        child_menu = self._menu_by_id.get(child_id)
                        if child_menu and child_menu.choice_point_id != cp_id:
                            # Only apply graph nesting if not already syntactically nested
                            if not child_menu.is_syntactically_nested:
                                # Found a graph-level parent → child relationship
                                child_menu.parent_menu_id = cp_id
                                child_menu.parent_choice_index = choice.index
                                child_menu.is_graph_nested = True
                                choice.leads_to_menu = child_id
                                choice.outcome_type = MenuOutcomeType.NESTED_MENU

                                logs.debug(
                                    "menu_nesting.graph_parent_child",
                                    f"Menu {cp_id} choice {choice.index} → menu {child_id} (graph-level)",
                                )

    def _compute_depth(self) -> None:
        """Phase 3a: Compute nesting depth for each menu (0 = root)."""

        # Use BFS to compute depth, handling cycles gracefully
        visited: Set[str] = set()
        processed: Set[str] = set()

        # Find root menus (no parent or cycle)
        roots = [m for m in self._menu_by_id.values() if m.parent_menu_id is None]

        # If no roots but menus exist, there's a cycle at the top level
        # Mark all as root level
        if not roots and self._menu_by_id:
            for menu in self._menu_by_id.values():
                menu.depth = 0
            return

        for root in roots:
            root.depth = 0
            self._propagate_depth(root, visited, processed)

    def _propagate_depth(
        self, menu: MenuContainer, visited: Set[str], processed: Set[str]
    ) -> None:
        """Recursively propagate depth to children, handling cycles."""

        if menu.choice_point_id in processed:
            # Already fully processed
            return

        if menu.choice_point_id in visited:
            # Cycle detected - menu is already being processed
            logs.warning(
                "menu_nesting.cycle", f"Cycle detected at menu {menu.choice_point_id}"
            )
            return

        visited.add(menu.choice_point_id)

        # Find all children
        for choice in menu.choices:
            if choice.leads_to_menu:
                child = self._menu_by_id.get(choice.leads_to_menu)
                if child and child.choice_point_id not in processed:
                    # Only update depth if not already set or if we can go deeper
                    new_depth = menu.depth + 1
                    if child.depth == 0 or new_depth > child.depth:
                        child.depth = new_depth
                    self._propagate_depth(child, visited, processed)

        processed.add(menu.choice_point_id)

    def _classify_outcomes(self) -> None:
        """Phase 3b: Classify outcome types for each choice."""

        for menu in self._menu_by_id.values():
            for choice in menu.choices:
                # Already classified as NESTED_MENU?
                if choice.outcome_type == MenuOutcomeType.NESTED_MENU:
                    continue

                # Check targets
                if not choice.targets:
                    choice.outcome_type = MenuOutcomeType.END
                elif len(choice.targets) == 1:
                    target = choice.targets[0]

                    # Check if target is the same menu or parent (loop detection)
                    if target == menu.label:
                        choice.outcome_type = MenuOutcomeType.LOOP
                    elif menu.parent_menu_id:
                        parent = self._menu_by_id.get(menu.parent_menu_id)
                        if parent and target == parent.label:
                            choice.outcome_type = MenuOutcomeType.LOOP
                    else:
                        # Default: assume jump (call detection would require deeper analysis)
                        choice.outcome_type = MenuOutcomeType.JUMP
                else:
                    # Multiple targets: treat as jump
                    choice.outcome_type = MenuOutcomeType.JUMP


def analyze_menu_nesting(
    choice_points: List[Dict[str, Any]],
    label_index: Dict[str, Any],
) -> MenuNestingAnalysis:
    """
    Convenience function for menu nesting analysis.

    Args:
        choice_points: List of menu AST dicts from indexer
        label_index: Dict of label name → IndexEntry

    Returns:
        MenuNestingAnalysis with structure and metadata
    """
    analyzer = MenuNestingAnalyzer(choice_points, label_index)
    return analyzer.analyze()
