"""
Cache Manager for Static Explorer Artifacts (Phase 3B.1-A)

Manages persistence of:
- static_graph.json
- label_fingerprints.json
- impact_set.json

All artifacts stored in .branchpy/runner_cache/
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Set

from branchpy import logs


class CacheManager:
    """Manages .branchpy/runner_cache/ artifacts for incremental analysis."""

    def __init__(self, project_root: str | Path):
        """
        Initialize cache manager for a project.

        Args:
            project_root: Absolute path to project root
        """
        self.project_root = Path(project_root)
        self.cache_dir = self.project_root / ".branchpy" / "runner_cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        # Internal cache: engine artifacts not exposed to users (Class C outputs).
        # Hidden from public project trees via .gitignore.
        self._internal_dir = self.cache_dir / ".internal"
        self._internal_dir.mkdir(parents=True, exist_ok=True)

    # ===== Static Graph =====

    def write_static_graph(self, graph_dict: Dict[str, Any]) -> None:
        """
        Persist static graph to internal cache.

        Static graph is a Class C engine artifact — full nodes/edges/uncertainties.
        Written to .internal/ to prevent accidental exposure in public outputs.

        Args:
            graph_dict: Output of StaticGraph.to_json_dict()
        """
        path = self._internal_dir / "static_graph.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(graph_dict, f, indent=2, ensure_ascii=False)

        logs.info(
            "cache.static_graph_written",
            f"Static graph written to {path}",
            nodes=len(graph_dict.get("nodes", [])),
            edges=len(graph_dict.get("edges", [])),
            uncertainties=len(graph_dict.get("uncertainties", [])),
        )

    def read_static_graph(self) -> Optional[Dict[str, Any]]:
        """Read cached static graph, or None if not present."""
        path = self._internal_dir / "static_graph.json"
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    # ===== Label Fingerprints =====

    def write_label_fingerprints(self, fingerprints: Dict[str, Dict[str, Any]]) -> None:
        """
        Persist label fingerprints to cache.

        Args:
            fingerprints: Dict of label name → {file, span, hash}
        """
        path = self.cache_dir / "label_fingerprints.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"labels": fingerprints}, f, indent=2, ensure_ascii=False)

        logs.info(
            "cache.fingerprints_written",
            f"Label fingerprints written to {path}",
            count=len(fingerprints),
        )

    def read_label_fingerprints(self) -> Optional[Dict[str, Dict[str, Any]]]:
        """Read cached label fingerprints, or None if not present."""
        path = self.cache_dir / "label_fingerprints.json"
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("labels", {})

    def has_previous_fingerprints(self) -> bool:
        """Check if fingerprints from a previous run exist."""
        return (self.cache_dir / "label_fingerprints.json").exists()

    # ===== Impact Set =====

    def write_impact_set(
        self, changed_labels: Set[str], impact_set: Set[str], k_hops: int
    ) -> None:
        """
        Persist impact set from incremental analysis.

        Args:
            changed_labels: Labels whose content changed
            impact_set: Full k-hop neighborhood needing revalidation
            k_hops: Number of hops used
        """
        path = self.cache_dir / "impact_set.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "changed_labels": sorted(changed_labels),
                    "impact_set": sorted(impact_set),
                    "k_hops": k_hops,
                },
                f,
                indent=2,
            )

        logs.info(
            "cache.impact_set_written",
            f"Impact set written to {path}",
            changed=len(changed_labels),
            impacted=len(impact_set),
            k=k_hops,
        )

    def read_impact_set(self) -> Optional[Dict[str, Any]]:
        """Read cached impact set, or None if not present."""
        path = self.cache_dir / "impact_set.json"
        if not path.exists():
            return None

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    # ===== Utilities =====

    def clear_cache(self) -> None:
        """Remove all cached artifacts."""
        import shutil

        if self.cache_dir.exists():
            shutil.rmtree(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        logs.info("cache.cleared", f"Cache cleared: {self.cache_dir}")
