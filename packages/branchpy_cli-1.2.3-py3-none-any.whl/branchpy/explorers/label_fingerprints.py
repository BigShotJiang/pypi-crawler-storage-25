"""
Label Fingerprinting and Incremental Impact Detection (Phase 3B.1-A)

Computes content hashes for labels to detect edits and determine
which regions need revalidation.
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Dict, Optional, Set, Tuple

from branchpy import logs


class LabelFingerprinter:
    """Computes and compares label content hashes for incremental analysis."""

    def __init__(self, project_root: str | Path):
        """
        Initialize fingerprinter for a project.

        Args:
            project_root: Absolute path to project root
        """
        self.project_root = Path(project_root)

    def compute_fingerprints(
        self, label_index: Dict[str, Any]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Compute content hashes for all labels.

        Args:
            label_index: Dict of label name → label info (file, line)

        Returns:
            Dict of label name → {file, span, hash}
        """
        fingerprints = {}

        for label_name, label_info in label_index.items():
            file = (
                label_info.get("file")
                if isinstance(label_info, dict)
                else getattr(label_info, "file", None)
            )
            line = (
                label_info.get("line")
                if isinstance(label_info, dict)
                else getattr(label_info, "line", None)
            )

            if not file or line is None:
                continue

            # Extract label body span and compute hash
            span, content_hash = self._hash_label_body(file, line, label_name)

            if content_hash:
                fingerprints[label_name] = {
                    "file": str(file),
                    "span": span,
                    "hash": content_hash,
                }

        logs.info(
            "fingerprints.computed",
            f"Computed fingerprints for {len(fingerprints)} labels",
        )

        return fingerprints

    def _hash_label_body(
        self, file: str, start_line: int, label_name: str
    ) -> Tuple[Dict[str, int], Optional[str]]:
        """
        Extract and hash the content of a label body.

        Args:
            file: Path to .rpy file (relative or absolute)
            start_line: Line number where label starts (1-indexed)
            label_name: Label name for debugging

        Returns:
            (span_dict, hash_string) where span is {start, end}
        """
        # Resolve file path
        file_path = (
            self.project_root / file if not Path(file).is_absolute() else Path(file)
        )

        if not file_path.exists():
            logs.warning(
                "fingerprints.file_not_found",
                f"Cannot fingerprint label '{label_name}': file not found at {file_path}",
            )
            return {"start": start_line, "end": start_line}, None

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            # Convert to 0-indexed
            start_idx = start_line - 1

            # Find the actual "label X:" line (indexer might report line before due to regex matching newlines)
            label_decl_idx = None
            import re

            label_pattern = re.compile(
                r"^\s*label\s+" + re.escape(label_name) + r"\s*:"
            )
            for i in range(
                start_idx, min(start_idx + 5, len(lines))
            ):  # Check up to 5 lines ahead
                if label_pattern.match(lines[i]):
                    label_decl_idx = i
                    break

            if label_decl_idx is None:
                logs.warning(
                    "fingerprints.label_not_found",
                    f"Could not find 'label {label_name}:' near line {start_line} in {file}",
                )
                return {"start": start_line, "end": start_line}, None

            # Find label body end: next label or EOF
            end_idx = len(lines)
            for i in range(label_decl_idx + 1, len(lines)):
                # Simple heuristic: line starts with 'label ' = new label
                if lines[i].strip().startswith("label "):
                    end_idx = i
                    break

            # Extract body lines (from label declaration to end)
            body_lines = lines[label_decl_idx:end_idx]

            logs.debug(
                "fingerprints.label_span",
                f"Label {label_name}: reported_line={start_line}, actual_line={label_decl_idx+1}, "
                f"end_line={end_idx}, body_lines={len(body_lines)}",
            )

            # Normalize: strip comments and collapse whitespace
            normalized = self._normalize_code(body_lines)

            # Hash
            content_hash = hashlib.sha256(normalized.encode("utf-8")).hexdigest()

            # Return 1-indexed span (use actual label declaration line)
            return {
                "start": label_decl_idx + 1,
                "end": end_idx,
            }, f"sha256:{content_hash[:16]}"

        except Exception as e:
            logs.warning(
                "fingerprints.hash_error", f"Error hashing label '{label_name}': {e}"
            )
            return {"start": start_line, "end": start_line}, None

    def _normalize_code(self, lines: list[str]) -> str:
        """
        Normalize code for stable hashing.

        - Strip comments
        - Collapse whitespace
        - Remove blank lines
        """
        normalized_lines = []

        for line in lines:
            # Strip inline comments (naive: anything after '#')
            code = line.split("#")[0]

            # Collapse whitespace but preserve indentation structure
            code = re.sub(r"[ \t]+", " ", code).strip()

            if code:
                normalized_lines.append(code)

        return "\n".join(normalized_lines)

    def detect_changed_labels(
        self,
        current_fingerprints: Dict[str, Dict[str, Any]],
        previous_fingerprints: Dict[str, Dict[str, Any]],
    ) -> Set[str]:
        """
        Compare fingerprints to detect changed labels.

        Args:
            current_fingerprints: Current label hashes
            previous_fingerprints: Previous label hashes

        Returns:
            Set of label names whose content changed
        """
        changed = set()

        # Check existing labels for hash changes
        for label_name, current_fp in current_fingerprints.items():
            prev_fp = previous_fingerprints.get(label_name)

            if prev_fp is None:
                # New label
                changed.add(label_name)
                logs.info("fingerprints.new_label", f"New label detected: {label_name}")
            elif current_fp.get("hash") != prev_fp.get("hash"):
                # Modified label
                changed.add(label_name)
                logs.info(
                    "fingerprints.modified_label",
                    f"Modified label detected: {label_name}",
                )

        # Check for deleted labels
        for label_name in previous_fingerprints:
            if label_name not in current_fingerprints:
                changed.add(label_name)
                logs.info(
                    "fingerprints.deleted_label",
                    f"Deleted label detected: {label_name}",
                )

        logs.info(
            "fingerprints.changes_detected", f"Detected {len(changed)} changed labels"
        )

        return changed


def compute_impact_set(
    changed_labels: Set[str], static_graph: Any, k: int = 2  # StaticGraph instance
) -> Set[str]:
    """
    Compute k-hop neighborhood of changed labels.

    Args:
        changed_labels: Labels whose content changed
        static_graph: StaticGraph with predecessor/successor methods
        k: Number of hops (default 2)

    Returns:
        Set of labels needing revalidation
    """
    impact = set(changed_labels)

    for label in changed_labels:
        # Upstream: labels that reach this label
        impact.update(static_graph.predecessors(label, hops=k))

        # Downstream: labels reachable from this label
        impact.update(static_graph.successors(label, hops=k))

    logs.info(
        "impact_set.computed",
        f"Impact set: {len(changed_labels)} changed → {len(impact)} total impacted (k={k})",
    )

    return impact
