# BranchPy report helpers (safe printing + text export + DOT export)
from __future__ import annotations

import json
import sys
from typing import Any, Dict

__all__ = ("print_report", "save_report", "save_dot", "safe_print")


def _robust_write(stream, text: str = "") -> None:
    try:
        if not text.endswith("\n"):
            text += "\n"
        stream.write(text)
        stream.flush()
    except (BrokenPipeError, ValueError, OSError):
        # Ignore and do not close stdio; keep the process usable.
        pass


def safe_print(text: str = "") -> None:
    _robust_write(sys.stdout, text)


def safe_print_err(text: str = "") -> None:
    _robust_write(sys.stderr, text)


def _text(results: Dict[str, Any]) -> str:
    s = results.get("summary", {})
    lines = [
        "BranchPy 0.2 - CLI Report",
        f"Files scanned: {s.get('files', 0)}",
        f"Labels found: {s.get('labels', 0)}",
        f"Jumps found: {s.get('jumps', 0)}",
        f"Calls found: {s.get('calls', 0)}",
        f"Menus with targets: {s.get('menus_with_targets', 0)}",
        f"Missing jump targets: {s.get('missing_jump_targets', 0)}",
        f"Missing call targets: {s.get('missing_call_targets', 0)}",
        f"Orphan labels (no incoming jump/call): {s.get('orphan_labels', 0)}",
        f"Dead-end labels: {s.get('dead_end_labels', 0)}",
        f"Called-without-return: {s.get('called_without_return', 0)}",
        f"Duplicate variables: {s.get('duplicate_vars', 0)}",
    ]

    def add_list(title: str, items: Any) -> None:
        if items:
            # `items` may be a list[str] or a dict[str, list[str]] in the case of duplicate_vars
            if isinstance(items, dict):
                lines.append(f"  -> {title}:")
                for key, value in items.items():
                    lines.append(f"     - {key}: {', '.join(value)}")
            else:
                lines.append(f"  -> {title}: " + ", ".join(items))

    add_list("Missing jump targets", results.get("missing_jump_targets", []))
    add_list("Missing call targets", results.get("missing_call_targets", []))
    add_list("Orphans", results.get("orphan_labels", []))
    add_list("Dead-ends", results.get("dead_end_labels", []))
    add_list("Called-without-return", results.get("called_without_return", []))

    if results.get("duplicate_vars"):
        lines.append("  -> Duplicate variables:")
        for var, files in results["duplicate_vars"].items():
            lines.append(f"     - {var}: {', '.join(files)}")

    if results.get("menu_edges"):
        lines.append("  -> Menus:")
        for lb, targets in results["menu_edges"].items():
            lines.append(f"     - {lb} → {', '.join(targets)}")

    return "\n".join(lines)


def print_report(results: Dict[str, Any], as_json: bool = False) -> None:
    """Write the report to stdout, safely (no crash if stdout is closed)."""
    if as_json:
        payload = json.dumps(results, indent=2, ensure_ascii=False)
        safe_print(payload)
    else:
        safe_print(_text(results))


def save_report(results: Dict[str, Any], path: str, as_json: bool = False) -> None:
    if as_json or path.lower().endswith(".json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(_text(results) + "\n")


def save_dot(results: Dict[str, Any], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("digraph BranchPy {\n")
        f.write("  rankdir=LR;\n")  # left-to-right graph layout

        # Nodes
        for lb in results.get("labels", {}):
            f.write(f'  "{lb}" [shape=box];\n')

        # Jumps
        for lb, info in results.get("label_details", {}).items():
            for tgt in info.get("body_outgoing_jumps", []):
                f.write(f'  "{lb}" -> "{tgt}" [label="jump"];\n')

        # Calls
        for lb, info in results.get("label_details", {}).items():
            for tgt in info.get("body_outgoing_calls", []):
                f.write(f'  "{lb}" -> "{tgt}" [label="call", style=dashed];\n')

        # Menus
        for lb, targets in results.get("menu_edges", {}).items():
            for tgt in targets:
                f.write(f'  "{lb}" -> "{tgt}" [label="menu", color=blue];\n')

        f.write("}\n")
