"""
History API Routes — Daemon Endpoints for v0.8.8.1

REST API endpoints for history management:
- Snapshot restore
- Timeline branching
- Diff export
- Stack operations

SSE Events:
- history.stack.changed
- snapshot.created
- snapshot.restored
- branch.created
- branch.switched
- undo.executed
- redo.executed

Version: v0.8.8.1
"""

# Optional dependencies: fastapi, pydantic
try:
    from fastapi import Depends  # type: ignore
    from fastapi import APIRouter, BackgroundTasks, HTTPException
    from fastapi.responses import JSONResponse, StreamingResponse  # type: ignore
    from pydantic import BaseModel, Field  # type: ignore
except ImportError:
    # Will fail at runtime if web features are used, but won't break type checking
    pass

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.core.history import (
    DiffExporter,
    HistoryPersistence,
    IntegrityError,
    Snapshot,
    SnapshotMetadata,
    Timeline,
)
from branchpy.daemon.context import DaemonContext, get_daemon_context

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/history", tags=["history"])

# SSE clients registry
sse_clients: List[asyncio.Queue] = []


# ==================== Request/Response Models ====================


class RestoreRequest(BaseModel):
    """Request to restore a snapshot."""

    snapshot_id: str = Field(..., description="Snapshot ID to restore")
    create_backup: bool = Field(True, description="Create backup before restore")


class BranchCreateRequest(BaseModel):
    """Request to create a new branch."""

    name: str = Field(..., description="Branch name")
    from_snapshot: str = Field(..., description="Snapshot to branch from")
    parent_branch: Optional[str] = Field(None, description="Parent branch ID")


class BranchSwitchRequest(BaseModel):
    """Request to switch branches."""

    branch: str = Field(..., description="Branch ID or name")


class BranchDeleteRequest(BaseModel):
    """Request to delete a branch."""

    branch: str = Field(..., description="Branch ID or name")
    force: bool = Field(False, description="Skip confirmation")


class DiffRequest(BaseModel):
    """Request to compare snapshots."""

    snapshot_id_1: str = Field(..., description="First snapshot ID")
    snapshot_id_2: str = Field(..., description="Second snapshot ID")
    export_format: Optional[str] = Field(
        None, description="Export format: html or json"
    )
    output_path: Optional[str] = Field(None, description="Output file path")


class UndoRequest(BaseModel):
    """Request to undo operations."""

    steps: int = Field(1, ge=1, le=100, description="Number of steps to undo")


class RedoRequest(BaseModel):
    """Request to redo operations."""

    steps: int = Field(1, ge=1, le=100, description="Number of steps to redo")


# ==================== SSE Event Emission ====================


async def emit_sse_event(event_type: str, data: Dict[str, Any]):
    """
    Emit SSE event to all connected clients.

    Args:
        event_type: Event type (e.g., "snapshot.restored")
        data: Event payload
    """
    event_message = f"event: {event_type}\ndata: {json.dumps(data)}\n\n"

    # Send to all connected clients
    dead_clients = []
    for queue in sse_clients:
        try:
            await queue.put(event_message)
        except Exception as e:
            logger.warning(f"Failed to send SSE to client: {e}")
            dead_clients.append(queue)

    # Remove disconnected clients
    for dead in dead_clients:
        sse_clients.remove(dead)


# ==================== Snapshot Endpoints ====================


@router.post("/restore")
async def restore_snapshot(
    request: RestoreRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Restore project to a snapshot state.

    Creates backup snapshot before restoration (unless disabled).
    Emits SSE event: snapshot.restored

    Returns:
        {
            "success": true,
            "snapshot_id": "snap_001",
            "backup_created": true,
            "backup_id": "snap_002"
        }
    """
    try:
        # Get project path from daemon context
        project_path = str(ctx.project_root)

        # Create backup if requested
        backup_id = None
        if request.create_backup:
            backup_metadata = SnapshotMetadata(
                project_path=project_path,
                operation=f"BackupBeforeRestore_{request.snapshot_id}",
                actor="daemon",
                tags=["auto-backup", "pre-restore"],
            )
            backup_id = Snapshot.create(backup_metadata)
            logger.info(f"Created backup snapshot: {backup_id}")

        # Restore snapshot
        Snapshot.restore(
            project_path,
            request.snapshot_id,
            create_backup=False,  # Already created above
        )

        # Emit SSE event
        background_tasks.add_task(
            emit_sse_event,
            "snapshot.restored",
            {
                "snapshot_id": request.snapshot_id,
                "backup_created": request.create_backup,
                "backup_id": backup_id,
                "timestamp": SnapshotMetadata(project_path, "").timestamp,
            },
        )

        return JSONResponse(
            {
                "success": True,
                "snapshot_id": request.snapshot_id,
                "backup_created": request.create_backup,
                "backup_id": backup_id,
            }
        )

    except FileNotFoundError as e:
        logger.error(f"Snapshot not found: {e}")
        raise HTTPException(status_code=404, detail=str(e))

    except IntegrityError as e:
        logger.error(f"Snapshot integrity check failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        logger.error(f"Snapshot restoration failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/snapshots")
async def list_snapshots(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    List all available snapshots.

    Returns:
        {
            "snapshots": [
                {
                    "id": "snap_001",
                    "created_at": "2025-11-05T15:30:00Z",
                    "operation": "AnalyzeProject",
                    "tags": ["pre-refactor"]
                }
            ]
        }
    """
    try:
        project_path = str(ctx.project_root)
        snapshot_dir = Path(project_path) / Snapshot.SNAPSHOT_DIR

        if not snapshot_dir.exists():
            return JSONResponse({"snapshots": []})

        snapshots = []
        for snapshot_file in snapshot_dir.glob("*.json"):
            try:
                with open(snapshot_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    snapshots.append(
                        {
                            "id": data["snapshot_id"],
                            "created_at": data["metadata"]["timestamp"],
                            "operation": data["metadata"]["operation"],
                            "tags": data["metadata"].get("tags", []),
                            "snapshot_type": data.get("snapshot_type", "full"),
                        }
                    )
            except Exception as e:
                logger.warning(f"Failed to parse snapshot {snapshot_file}: {e}")

        # Sort by timestamp descending
        snapshots.sort(key=lambda x: x["created_at"], reverse=True)

        return JSONResponse({"snapshots": snapshots})

    except Exception as e:
        logger.error(f"Failed to list snapshots: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/snapshot/{snapshot_id}")
async def get_snapshot_details(
    snapshot_id: str, ctx: DaemonContext = Depends(get_daemon_context)
):
    """
    Get detailed snapshot information.

    Returns full snapshot data including CFG, stats, assets, governance.
    """
    try:
        project_path = str(ctx.project_root)
        snapshot = Snapshot.load(project_path, snapshot_id)

        return JSONResponse(snapshot)

    except FileNotFoundError as e:
        logger.error(f"Snapshot not found: {e}")
        raise HTTPException(status_code=404, detail=str(e))

    except Exception as e:
        logger.error(f"Failed to load snapshot: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Branch Endpoints ====================


@router.post("/branch/create")
async def create_branch(
    request: BranchCreateRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Create a new timeline branch.

    Emits SSE event: branch.created

    Returns:
        {
            "success": true,
            "branch_id": "uuid-123",
            "branch_name": "experiment_1",
            "from_snapshot": "snap_001"
        }
    """
    try:
        project_path = str(ctx.project_root)
        timeline = Timeline(project_path)

        branch_id = timeline.create_branch(
            request.name, request.from_snapshot, request.parent_branch
        )

        # Emit SSE event
        background_tasks.add_task(
            emit_sse_event,
            "branch.created",
            {
                "branch_id": branch_id,
                "branch_name": request.name,
                "from_snapshot": request.from_snapshot,
                "parent_branch": request.parent_branch,
            },
        )

        return JSONResponse(
            {
                "success": True,
                "branch_id": branch_id,
                "branch_name": request.name,
                "from_snapshot": request.from_snapshot,
            }
        )

    except Exception as e:
        logger.error(f"Branch creation failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/branch/switch")
async def switch_branch(
    request: BranchSwitchRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Switch to a different branch.

    Emits SSE event: branch.switched

    Returns:
        {
            "success": true,
            "branch": "experiment_1"
        }
    """
    try:
        project_path = str(ctx.project_root)
        timeline = Timeline(project_path)

        timeline.switch_branch(request.branch)

        # Emit SSE event
        background_tasks.add_task(
            emit_sse_event, "branch.switched", {"branch": request.branch}
        )

        return JSONResponse({"success": True, "branch": request.branch})

    except ValueError as e:
        logger.error(f"Branch not found: {e}")
        raise HTTPException(status_code=404, detail=str(e))

    except Exception as e:
        logger.error(f"Branch switch failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/branch/list")
async def list_branches(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    List all timeline branches.

    Returns:
        {
            "branches": [
                {
                    "id": "main",
                    "name": "main",
                    "from_snapshot": "",
                    "created_at": "2025-11-05T15:00:00Z",
                    "is_current": true
                }
            ]
        }
    """
    try:
        project_path = str(ctx.project_root)
        timeline = Timeline(project_path)

        branches = timeline.list_branches()

        return JSONResponse({"branches": branches})

    except Exception as e:
        logger.error(f"Failed to list branches: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/branch/delete")
async def delete_branch(
    request: BranchDeleteRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Delete a timeline branch.

    Emits SSE event: branch.deleted

    Returns:
        {
            "success": true,
            "branch": "experiment_1"
        }
    """
    try:
        project_path = str(ctx.project_root)
        timeline = Timeline(project_path)

        timeline.delete_branch(request.branch, force=request.force)

        # Emit SSE event
        background_tasks.add_task(
            emit_sse_event, "branch.deleted", {"branch": request.branch}
        )

        return JSONResponse({"success": True, "branch": request.branch})

    except ValueError as e:
        logger.error(f"Branch deletion failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        logger.error(f"Branch deletion failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Diff Endpoints ====================


@router.post("/diff")
async def compare_snapshots(
    request: DiffRequest, ctx: DaemonContext = Depends(get_daemon_context)
):
    """
    Compare two snapshots and optionally export.

    Query params:
        ?format=html|json - Export format

    Returns:
        Diff JSON if no export, or export confirmation
    """
    try:
        project_path = str(ctx.project_root)

        # Compute diff
        diff = Snapshot.diff(project_path, request.snapshot_id_1, request.snapshot_id_2)

        # Export if requested
        if request.export_format and request.output_path:
            exporter = DiffExporter()

            if request.export_format == "html":
                exporter.export_html(diff, request.output_path)
            elif request.export_format == "json":
                exporter.export_json(diff, request.output_path)
            else:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid export format: {request.export_format}",
                )

            return JSONResponse(
                {
                    "success": True,
                    "format": request.export_format,
                    "output_path": request.output_path,
                }
            )

        # Return diff JSON
        return JSONResponse(diff)

    except FileNotFoundError as e:
        logger.error(f"Snapshot not found: {e}")
        raise HTTPException(status_code=404, detail=str(e))

    except Exception as e:
        logger.error(f"Diff failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Stack Operations ====================


@router.post("/undo")
async def undo_operations(
    request: UndoRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Undo N operations.

    Emits SSE event: undo.executed

    Returns:
        {
            "success": true,
            "steps": 2,
            "actions": [...]
        }
    """
    try:
        project_path = str(ctx.project_root)
        persistence = HistoryPersistence(project_path)

        # Load stack
        stack = persistence.load_stack()
        if not stack:
            raise HTTPException(status_code=404, detail="No history available")

        # Undo
        actions = stack.undo(request.steps)

        # Save stack
        persistence.save_stack(stack)

        # Emit SSE event
        background_tasks.add_task(
            emit_sse_event,
            "undo.executed",
            {
                "steps": request.steps,
                "actions": [
                    {"operation": a.operation, "correlation_id": a.correlation_id}
                    for a in actions
                ],
            },
        )

        # Emit stack changed event
        background_tasks.add_task(emit_sse_event, "history.stack.changed", stack.show())

        return JSONResponse(
            {
                "success": True,
                "steps": len(actions),
                "actions": [
                    {
                        "operation": a.operation,
                        "snapshot_before": a.snapshot_before,
                        "snapshot_after": a.snapshot_after,
                        "correlation_id": a.correlation_id,
                    }
                    for a in actions
                ],
            }
        )

    except Exception as e:
        logger.error(f"Undo failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/redo")
async def redo_operations(
    request: RedoRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Redo N operations.

    Emits SSE event: redo.executed

    Returns:
        {
            "success": true,
            "steps": 2,
            "actions": [...]
        }
    """
    try:
        project_path = str(ctx.project_root)
        persistence = HistoryPersistence(project_path)

        # Load stack
        stack = persistence.load_stack()
        if not stack:
            raise HTTPException(status_code=404, detail="No history available")

        # Redo
        actions = stack.redo(request.steps)

        # Save stack
        persistence.save_stack(stack)

        # Emit SSE event
        background_tasks.add_task(
            emit_sse_event,
            "redo.executed",
            {
                "steps": request.steps,
                "actions": [
                    {"operation": a.operation, "correlation_id": a.correlation_id}
                    for a in actions
                ],
            },
        )

        # Emit stack changed event
        background_tasks.add_task(emit_sse_event, "history.stack.changed", stack.show())

        return JSONResponse(
            {
                "success": True,
                "steps": len(actions),
                "actions": [
                    {
                        "operation": a.operation,
                        "snapshot_before": a.snapshot_before,
                        "snapshot_after": a.snapshot_after,
                        "correlation_id": a.correlation_id,
                    }
                    for a in actions
                ],
            }
        )

    except Exception as e:
        logger.error(f"Redo failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/show")
async def show_history(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    Get current history stack state.

    Returns:
        {
            "undo_stack": [...],
            "redo_stack": [...],
            "undo_available": 5,
            "redo_available": 2
        }
    """
    try:
        project_path = str(ctx.project_root)
        persistence = HistoryPersistence(project_path)

        # Load stack
        stack = persistence.load_stack()
        if not stack:
            return JSONResponse(
                {
                    "undo_stack": [],
                    "redo_stack": [],
                    "undo_available": 0,
                    "redo_available": 0,
                }
            )

        return JSONResponse(stack.show())

    except Exception as e:
        logger.error(f"Show history failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== SSE Endpoint ====================


@router.get("/events")
async def history_events_stream():
    """
    Server-Sent Events stream for real-time history updates.

    Events:
        - history.stack.changed
        - snapshot.created
        - snapshot.restored
        - branch.created
        - branch.switched
        - branch.deleted
        - undo.executed
        - redo.executed

    Example:
        event: snapshot.restored
        data: {"snapshot_id": "snap_001", "backup_id": "snap_002"}
    """

    async def event_generator():
        """Generate SSE events for this client."""
        queue = asyncio.Queue()
        sse_clients.append(queue)

        try:
            while True:
                message = await queue.get()
                yield message
        except asyncio.CancelledError:
            sse_clients.remove(queue)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )


# ==================== v0.8.8.2: Branch Merging Endpoints ====================


class MergeStartRequest(BaseModel):
    """Request to start branch merge."""

    target_branch: str = Field(..., description="Branch to merge into")
    source_branch: str = Field(..., description="Branch to merge from")
    strategy: str = Field(
        "auto", description="Merge strategy: auto, ours, theirs, interactive"
    )
    message: Optional[str] = Field(None, description="Custom merge commit message")


class ConflictResolutionRequest(BaseModel):
    """Request to resolve merge conflicts."""

    conflict_id: str = Field(..., description="Conflict ID")
    resolution: str = Field(..., description="Resolution: use_ours, use_theirs, manual")
    resolved_value: Optional[Any] = Field(
        None, description="Custom resolved value (for manual)"
    )


class MergeResponse(BaseModel):
    """Response from merge operation."""

    success: bool
    target_branch: str
    source_branch: str
    merged_snapshot_id: Optional[str] = None
    conflicts_count: int = 0
    message: str
    conflicts: Optional[List[Dict[str, Any]]] = None


@router.post("/merge/start", response_model=MergeResponse)
async def merge_start(
    request: MergeStartRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Start merging source branch into target branch.

    Returns merge result with conflicts if any.
    Emits `branch.merged` SSE event on success.
    """
    try:
        from branchpy.core.history import MergeEngine, MergeStrategy
        from branchpy.core.history.snapshot import SnapshotManager

        # Get project path from daemon context
        # (In production, this would be injected via dependency)
        project_path = ctx.project_root
        history_dir = project_path / ".branchpy" / "history"

        # Initialize merge engine
        snapshot_manager = SnapshotManager(str(history_dir))
        merge_engine = MergeEngine(history_dir, snapshot_manager)

        # Convert strategy string to enum
        strategy_map = {
            "auto": MergeStrategy.AUTO,
            "ours": MergeStrategy.OURS,
            "theirs": MergeStrategy.THEIRS,
            "interactive": MergeStrategy.INTERACTIVE,
        }
        strategy = strategy_map.get(request.strategy, MergeStrategy.AUTO)

        # Perform merge
        result = merge_engine.merge_branches(
            request.target_branch, request.source_branch, strategy, request.message
        )

        # Emit SSE event on success
        if result.success:
            background_tasks.add_task(
                emit_sse_event,
                "branch.merged",
                {
                    "target_branch": result.target_branch,
                    "source_branch": result.source_branch,
                    "merged_snapshot_id": result.merged_snapshot_id,
                },
            )

        # Build response
        response = MergeResponse(
            success=result.success,
            target_branch=result.target_branch,
            source_branch=result.source_branch,
            merged_snapshot_id=result.merged_snapshot_id,
            conflicts_count=len(result.conflicts),
            message=result.message,
        )

        if result.has_conflicts:
            response.conflicts = [
                {
                    "conflict_id": c.conflict_id,
                    "type": c.conflict_type.value,
                    "path": c.path,
                    "base_value": c.base_value,
                    "ours_value": c.ours_value,
                    "theirs_value": c.theirs_value,
                }
                for c in result.conflicts
            ]

        return response

    except Exception as e:
        logger.error(f"Merge failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/merge/abort")
async def merge_abort():
    """
    Abort in-progress merge (placeholder for v0.8.8.2).

    Currently merges are atomic, so this always returns success.
    """
    return {"success": True, "message": "No merge in progress"}


# ==================== v0.8.8.2: Consolidation Daemon Endpoints ====================


class ConsolidationStatusResponse(BaseModel):
    """Response with consolidation daemon status."""

    running: bool
    enabled: bool
    last_run: Optional[str] = None
    consolidation_count: int
    config: Dict[str, Any]


class ConsolidationTriggerRequest(BaseModel):
    """Request to manually trigger consolidation."""

    immediate: bool = Field(True, description="Run immediately (bypass interval)")


@router.get("/consolidation/status", response_model=ConsolidationStatusResponse)
async def consolidation_status():
    """
    Get consolidation daemon status.

    Returns daemon state, configuration, and statistics.
    """
    try:

        # Get daemon instance from app state
        # (In production, this would be injected via dependency)
        # For now, return placeholder status
        return ConsolidationStatusResponse(
            running=False,  # Daemon not started yet
            enabled=True,
            last_run=None,
            consolidation_count=0,
            config={
                "enabled": True,
                "max_chain_depth": 10,
                "consolidation_interval": "6h",
                "preserve_old_deltas": True,
            },
        )

    except Exception as e:
        logger.error(f"Failed to get consolidation status: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/consolidation/trigger")
async def consolidation_trigger(
    request: ConsolidationTriggerRequest,
    background_tasks: BackgroundTasks,
    ctx: DaemonContext = Depends(get_daemon_context),
):
    """
    Manually trigger consolidation cycle.

    Useful for testing or forcing consolidation outside normal schedule.
    Emits `snapshot.consolidated` SSE event for each consolidation.
    """
    try:
        from branchpy.core.history import ConsolidationConfig, ConsolidationDaemon

        project_path = ctx.project_root
        history_dir = project_path / ".branchpy" / "history"

        # Initialize daemon (without starting background loop)
        from branchpy.core.history.snapshot import SnapshotManager

        snapshot_manager = SnapshotManager(str(history_dir))

        config = ConsolidationConfig()
        daemon = ConsolidationDaemon(history_dir, snapshot_manager, config)

        # Trigger consolidation
        count = daemon.trigger_consolidation()

        return {
            "success": True,
            "chains_consolidated": count,
            "message": f"Consolidated {count} delta chain(s)",
        }

    except Exception as e:
        logger.error(f"Consolidation trigger failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/consolidation/config")
async def consolidation_config():
    """Get consolidation daemon configuration."""
    from branchpy.core.history import ConsolidationConfig

    config = ConsolidationConfig()
    return config.to_dict()


@router.put("/consolidation/config")
async def consolidation_config_update(config_update: Dict[str, Any]):
    """Update consolidation daemon configuration (requires daemon restart)."""
    try:
        from branchpy.core.history import ConsolidationConfig

        # Validate config
        config = ConsolidationConfig.from_dict(config_update)

        # Save config (placeholder - would save to config file)
        return {
            "success": True,
            "config": config.to_dict(),
            "message": "Configuration updated (daemon restart required)",
        }

    except Exception as e:
        logger.error(f"Config update failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=str(e))


# ==================== v0.8.8.2: Governance Diff Endpoint ====================


class GovernanceDiffRequest(BaseModel):
    """Request to compare governance events between branches."""

    target_branch: str = Field(..., description="Branch to compare to")
    source_branch: str = Field(..., description="Branch to compare from")
    event_type_filter: Optional[List[str]] = Field(
        None, description="Filter by event types"
    )
    actor_filter: Optional[str] = Field(None, description="Filter by actor (regex)")
    export_format: Optional[str] = Field(
        None, description="Export format: html or json"
    )


class GovernanceDiffResponse(BaseModel):
    """Response with governance diff results."""

    target_branch: str
    source_branch: str
    total_target_events: int
    total_source_events: int
    only_target_count: int
    only_source_count: int
    modified_count: int
    event_diffs: List[Dict[str, Any]]


@router.post("/governance/diff", response_model=GovernanceDiffResponse)
async def governance_diff(
    request: GovernanceDiffRequest, ctx: DaemonContext = Depends(get_daemon_context)
):
    """
    Compare governance events between two branches.

    Returns side-by-side event comparison with filtering options.
    Can export to HTML/JSON for compliance reports.
    """
    try:
        from branchpy.core.history import GovernanceDiffEngine

        project_path = ctx.project_root
        history_dir = project_path / ".branchpy" / "history"

        # Initialize diff engine
        diff_engine = GovernanceDiffEngine(history_dir)

        # Perform comparison
        result = diff_engine.compare_branches(
            request.target_branch,
            request.source_branch,
            event_type_filter=request.event_type_filter,
            actor_filter=request.actor_filter,
        )

        # Export if requested
        if request.export_format == "html":
            export_path = (
                history_dir
                / "governance_diffs"
                / f"{request.target_branch}_vs_{request.source_branch}.html"
            )
            diff_engine.export_html(result, export_path)
        elif request.export_format == "json":
            export_path = (
                history_dir
                / "governance_diffs"
                / f"{request.target_branch}_vs_{request.source_branch}.json"
            )
            diff_engine.export_json(result, export_path)

        # Build response
        return GovernanceDiffResponse(
            target_branch=result.target_branch,
            source_branch=result.source_branch,
            total_target_events=result.total_target_events,
            total_source_events=result.total_source_events,
            only_target_count=result.only_target_count,
            only_source_count=result.only_source_count,
            modified_count=result.modified_count,
            event_diffs=[
                {
                    "event_id": diff.event_id,
                    "diff_type": diff.diff_type,
                    "event_type": diff.event_type,
                    "actor": diff.actor,
                    "timestamp": diff.timestamp.isoformat(),
                    "correlation_id": diff.correlation_id,
                }
                for diff in result.event_diffs
            ],
        )

    except Exception as e:
        logger.error(f"Governance diff failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Registration ====================


def register_routes(app):
    """Register history routes with FastAPI app."""
    app.include_router(router)
    logger.info("Registered history API routes")
