"""
Validation Policies API Routes — Wave 3 Backend

REST API endpoints for ValidationPolicy registry and evaluation telemetry:
- Policy registry snapshot
- Recent policy evaluations with filtering
- SSE integration via existing governance stream

Aligned with BQF-Core §1 (Validation Model) and §4 (Event Envelope)

SSE Events Consumed:
- validation.policy.registered
- validation.policy.applied
- validation.request.start
- validation.request.complete

Version: v0.9.2 Wave 3
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from branchpy.daemon.context import DaemonContext, get_daemon_context
from validation.registry import REGISTRY

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/v1/validation", tags=["validation"])


# ==================== Request/Response Models ====================


class PolicyResponse(BaseModel):
    """Registered ValidationPolicy metadata."""

    policyId: str = Field(..., description="Unique policy identifier")
    target: str = Field(
        ..., description="Validation target type (asset, variable, label, path)"
    )
    severity: str = Field(..., description="Policy severity (info, warn, error)")
    remediation: Optional[str] = Field(None, description="Remediation guidance")
    predicateCount: int = Field(..., description="Number of predicate functions")
    registeredAt: Optional[str] = Field(
        None, description="ISO 8601 registration timestamp"
    )


class AppliedEventResponse(BaseModel):
    """Recent policy application event."""

    policyId: str
    targetRef: str = Field(..., description="Target reference (e.g., 'game.start')")
    passed: bool
    severity: str
    ts: str = Field(..., description="ISO 8601 timestamp")
    correlationId: str
    message: Optional[str] = None


class RecentEventsRequest(BaseModel):
    """Filter criteria for recent policy evaluations."""

    policyId: Optional[str] = Field(None, description="Filter by specific policy")
    targetRef: Optional[str] = Field(None, description="Filter by target reference")
    passed: Optional[bool] = Field(None, description="Filter by pass/fail status")
    correlationId: Optional[str] = Field(None, description="Filter by correlation ID")
    limit: int = Field(50, ge=1, le=500, description="Maximum events to return")
    since: Optional[str] = Field(
        None, description="ISO 8601 timestamp for time-based filtering"
    )


class PolicyStatsResponse(BaseModel):
    """Aggregated statistics for a policy."""

    policyId: str
    totalEvaluations: int
    passed: int
    failed: int
    passRate: float = Field(..., description="Pass rate (0.0 to 1.0)")
    lastEvaluationTs: Optional[str] = None


# ==================== Policy Registry Endpoints ====================


@router.get("/policies", response_model=List[PolicyResponse])
async def get_policies(
    target: Optional[str] = Query(None, description="Filter by target type"),
    severity: Optional[str] = Query(None, description="Filter by severity"),
    ctx: DaemonContext = Depends(get_daemon_context),
) -> List[PolicyResponse]:
    """
    Get current ValidationPolicy registry snapshot.

    Returns all registered policies with metadata.
    Filters: target (asset|variable|label|path), severity (info|warn|error)

    Emits: governance.audit.export (per BQF-Core §4)
    """
    try:
        # Emit audit event for policy registry access
        if ctx.governance_logger:
            ctx.governance_logger.log_event(
                event_type="governance.audit.export",
                actor="api.validation.policies",
                metadata={
                    "endpoint": "/api/v1/validation/policies",
                    "filters": {"target": target, "severity": severity},
                    "timestamp": datetime.utcnow().isoformat(),
                },
            )

        # Get policies from registry
        policies = REGISTRY.get_all()

        # Apply filters
        filtered = policies
        if target:
            filtered = [p for p in filtered if p.target == target]
        if severity:
            filtered = [p for p in filtered if p.severity == severity]

        # Convert to response model
        response = [
            PolicyResponse(
                policyId=p.id,
                target=p.target,
                severity=p.severity,
                remediation=p.remediation,
                predicateCount=len(p.predicates),
                registeredAt=getattr(p, "registeredAt", None),
            )
            for p in filtered
        ]

        logger.info(
            f"Returned {len(response)} policies (filtered from {len(policies)})"
        )
        return response

    except Exception as e:
        logger.error(f"Failed to get policies: {e}", exc_info=True)
        raise HTTPException(
            status_code=500, detail=f"Failed to retrieve policies: {str(e)}"
        )


@router.get("/policies/{policy_id}", response_model=PolicyResponse)
async def get_policy(
    policy_id: str, ctx: DaemonContext = Depends(get_daemon_context)
) -> PolicyResponse:
    """
    Get specific policy by ID.

    Returns: Policy metadata
    Raises: 404 if policy not found
    """
    try:
        policy = REGISTRY.get(policy_id)
        if not policy:
            raise HTTPException(
                status_code=404, detail=f"Policy '{policy_id}' not found"
            )

        return PolicyResponse(
            policyId=policy.id,
            target=policy.target,
            severity=policy.severity,
            remediation=policy.remediation,
            predicateCount=len(policy.predicates),
            registeredAt=getattr(policy, "registeredAt", None),
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get policy {policy_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Recent Evaluations Endpoint ====================


@router.get("/recent", response_model=List[AppliedEventResponse])
async def get_recent_evaluations(
    policyId: Optional[str] = Query(None, description="Filter by policy ID"),
    targetRef: Optional[str] = Query(None, description="Filter by target reference"),
    passed: Optional[bool] = Query(None, description="Filter by pass/fail status"),
    correlationId: Optional[str] = Query(None, description="Filter by correlation ID"),
    limit: int = Query(50, ge=1, le=500, description="Max events to return"),
    since: Optional[str] = Query(
        None, description="ISO 8601 timestamp (e.g., 10 minutes ago)"
    ),
    ctx: DaemonContext = Depends(get_daemon_context),
) -> List[AppliedEventResponse]:
    """
    Get recent validation.policy.applied events from governance log.

    Filters: policyId, targetRef, passed, correlationId, since
    Returns: Recent evaluation events (newest last for SSE append compatibility)

    Emits: governance.audit.export
    """
    try:
        # Emit audit event
        if ctx.governance_logger:
            ctx.governance_logger.log_event(
                event_type="governance.audit.export",
                actor="api.validation.recent",
                metadata={
                    "endpoint": "/api/v1/validation/recent",
                    "filters": {
                        "policyId": policyId,
                        "targetRef": targetRef,
                        "passed": passed,
                        "correlationId": correlationId,
                        "limit": limit,
                        "since": since,
                    },
                },
            )

        # Parse since timestamp if provided
        since_dt = None
        if since:
            try:
                since_dt = datetime.fromisoformat(since.replace("Z", "+00:00"))
            except ValueError:
                raise HTTPException(
                    status_code=400, detail=f"Invalid 'since' timestamp: {since}"
                )

        # Query governance log for validation.policy.applied events
        # This would integrate with your existing governance log replay
        events = []

        # TODO: Integrate with actual governance log query
        # For now, return empty list with proper structure
        # In production, this would call:
        # events = ctx.governance_logger.query_events(
        #     event_type="validation.policy.applied",
        #     correlation_id=correlationId,
        #     since=since_dt,
        #     limit=limit
        # )

        # Apply filters and transform to response model
        filtered_events = []
        for evt in events:
            metadata = evt.get("metadata", {})

            # Apply filters
            if policyId and metadata.get("policyId") != policyId:
                continue
            if targetRef and metadata.get("target") != targetRef:
                continue
            if passed is not None and metadata.get("passed") != passed:
                continue
            if correlationId and evt.get("correlationId") != correlationId:
                continue

            filtered_events.append(
                AppliedEventResponse(
                    policyId=metadata.get("policyId", "unknown"),
                    targetRef=metadata.get("target", "unknown"),
                    passed=metadata.get("passed", False),
                    severity=evt.get("severity", "info"),
                    ts=evt.get("ts", datetime.utcnow().isoformat()),
                    correlationId=evt.get("correlationId", ""),
                    message=evt.get("message"),
                )
            )

        logger.info(f"Returned {len(filtered_events)} recent evaluations")
        return filtered_events[:limit]

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get recent evaluations: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Statistics Endpoint ====================


@router.get("/stats/{policy_id}", response_model=PolicyStatsResponse)
async def get_policy_stats(
    policy_id: str,
    since: Optional[str] = Query(None, description="ISO timestamp for time window"),
    ctx: DaemonContext = Depends(get_daemon_context),
) -> PolicyStatsResponse:
    """
    Get aggregated statistics for a specific policy.

    Computes pass/fail counts from governance log events.
    Time window: since parameter or last 24h by default.
    """
    try:
        # Verify policy exists
        policy = REGISTRY.get(policy_id)
        if not policy:
            raise HTTPException(
                status_code=404, detail=f"Policy '{policy_id}' not found"
            )

        # Query events for this policy
        # TODO: Integrate with governance log aggregation
        # For now, return placeholder stats

        return PolicyStatsResponse(
            policyId=policy_id,
            totalEvaluations=0,
            passed=0,
            failed=0,
            passRate=0.0,
            lastEvaluationTs=None,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get stats for {policy_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Health Check ====================


@router.get("/health")
async def validation_health() -> Dict[str, Any]:
    """
    Validation API health check.

    Returns: Registry status, policy count, API version
    """
    return {
        "status": "healthy",
        "registeredPolicies": len(REGISTRY.get_all()),
        "apiVersion": "v1",
        "wave": 3,
        "timestamp": datetime.utcnow().isoformat(),
    }
