"""
Daemon Context — Dependency Injection for FastAPI Routes

Provides project context and shared state to API route handlers.
Used to eliminate hardcoded project paths and enable multi-project support.

Version: v0.8.8.1+
"""

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional


class DaemonContext:
    """
    Daemon-wide context holding project information and configuration.

    Attributes:
        project_root: Absolute path to the current project root
        runtime_dir: Path to .branchpy runtime directory
        profile: Active configuration profile name
    """

    def __init__(
        self,
        project_root: Path,
        runtime_dir: Optional[Path] = None,
        profile: str = "default",
    ):
        self.project_root = project_root.resolve()
        self.runtime_dir = runtime_dir or (self.project_root / ".branchpy")
        self.profile = profile

    @property
    def history_dir(self) -> Path:
        """Get history storage directory."""
        return self.runtime_dir / "history"

    @property
    def snapshots_dir(self) -> Path:
        """Get snapshots storage directory."""
        return self.history_dir / "snapshots"

    @property
    def governance_log(self) -> Path:
        """Get governance log path."""
        return self.runtime_dir / "governance" / "audit.jsonl"

    def __repr__(self) -> str:
        return (
            f"DaemonContext(project_root={self.project_root}, profile={self.profile})"
        )


# Global context instance (set at daemon startup)
_context: Optional[DaemonContext] = None


def set_context(context: DaemonContext) -> None:
    """
    Set the global daemon context.

    Called once at daemon startup from run.py.

    Args:
        context: Initialized DaemonContext instance
    """
    global _context
    _context = context


def get_context() -> DaemonContext:
    """
    Get the current daemon context.

    Returns:
        Active DaemonContext instance

    Raises:
        RuntimeError: If context not initialized
    """
    if _context is None:
        raise RuntimeError(
            "Daemon context not initialized. " "Call set_context() at daemon startup."
        )
    return _context


# FastAPI dependency function
async def get_daemon_context() -> DaemonContext:
    """
    FastAPI dependency to inject daemon context into route handlers.

    Usage:
        @router.get("/endpoint")
        async def endpoint(ctx: DaemonContext = Depends(get_daemon_context)):
            project_path = ctx.project_root

    Returns:
        Current DaemonContext instance
    """
    return get_context()


@asynccontextmanager
async def lifespan_context(project_root: Path, runtime_dir: Optional[Path] = None):
    """
    Context manager for daemon lifespan with automatic cleanup.

    Usage:
        async with lifespan_context(project_root):
            # Daemon context is available
            await run_server()
        # Cleanup performed

    Args:
        project_root: Project root directory
        runtime_dir: Runtime directory (defaults to project_root/.branchpy)
    """
    context = DaemonContext(project_root, runtime_dir)
    set_context(context)
    try:
        yield context
    finally:
        # Cleanup code here (future: close connections, flush logs, etc.)
        pass
