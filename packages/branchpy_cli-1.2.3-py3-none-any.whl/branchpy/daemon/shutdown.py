"""Daemon shutdown helpers (Axis5 G4 governance flush wiring).

Provides graceful shutdown entrypoint that ensures governance events are durably
flushed with timeout + error handling semantics required for test hygiene.
"""

from __future__ import annotations

import asyncio
import logging

from branchpy.core.governance.logger import GovernanceLogger

_log = logging.getLogger(__name__)


async def _flush_governance_safely(timeout_s: float = 2.0) -> None:
    """Flush governance events with timeout and robust error handling.

    Timeout emits a warning; other exceptions emit full stack via exception().
    """
    try:
        await asyncio.wait_for(GovernanceLogger().flush_async(), timeout=timeout_s)
    except asyncio.TimeoutError:
        _log.warning("governance.flush: timeout after %.2fs", timeout_s)
    except Exception as e:  # pragma: no cover - defensive
        _log.exception("governance.flush: error: %s", e)


async def graceful_shutdown() -> None:
    """Placeholder graceful shutdown sequence.

    Real implementation would stop background tasks, close resources, etc.
    """
    try:
        # ... existing shutdown steps would go here ...
        pass
    finally:
        await _flush_governance_safely(2.0)


def shutdown_blocking() -> None:
    """Synchronous helper (tests may call) to run graceful shutdown."""
    asyncio.run(graceful_shutdown())


__all__ = ["graceful_shutdown", "shutdown_blocking", "_flush_governance_safely"]
