"""
Governance API Routes — Daemon Endpoints for v0.9.0

REST API endpoints for governance event monitoring:
- SSE event streaming
- Event replay with filtering
- Event querying and statistics

SSE Events:
- governance.event.logged
- governance.batch.flushed
- governance.replay.started
- governance.replay.completed

Version: v0.9.0
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional

# Dependencies: fastapi, pydantic (installed in venv)
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from branchpy.core.governance import GovernanceLogger
from branchpy.core.history.governance_bridge import get_sse_emitter, replay_events
from branchpy.daemon.context import DaemonContext, get_daemon_context

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/v1/governance", tags=["governance"])


# ==================== Request/Response Models ====================


class ReplayRequest(BaseModel):
    """Request to replay governance events."""

    from_timestamp: Optional[str] = Field(
        None, description="ISO timestamp to start replay from"
    )
    to_timestamp: Optional[str] = Field(
        None, description="ISO timestamp to end replay at"
    )
    event_type_filter: Optional[List[str]] = Field(
        None, description="Filter by event types"
    )
    actor_filter: Optional[str] = Field(None, description="Filter by actor")
    correlation_id_filter: Optional[str] = Field(
        None, description="Filter by correlation ID"
    )
    limit: int = Field(1000, ge=1, le=10000, description="Maximum events to return")


class QueryEventsRequest(BaseModel):
    """Request to query governance events."""

    event_type: Optional[str] = Field(None, description="Filter by event type")
    correlation_id: Optional[str] = Field(None, description="Filter by correlation ID")
    actor: Optional[str] = Field(None, description="Filter by actor")
    limit: int = Field(100, ge=1, le=1000, description="Maximum events to return")
    offset: int = Field(0, ge=0, description="Skip first N events")


class StatisticsResponse(BaseModel):
    """Response with governance statistics."""

    total_events: int
    event_types: Dict[str, int]
    unique_actors: int
    unique_correlations: int
    date_range: Optional[str]
    batching_enabled: bool


class IntegrityCheckResponse(BaseModel):
    """Response from integrity verification."""

    valid: bool
    errors: List[str]
    warnings: List[str]


# ==================== SSE Event Streaming ====================


@router.get("/events")
async def governance_events_stream(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    Server-Sent Events stream for real-time governance event monitoring.

    Events are emitted when:
    - New governance events are logged
    - Event batches are flushed to disk
    - Replay operations start/complete

    Event Format:
        event: governance.event.logged
        data: {"event_type": "ACTION_APPLIED", "correlation_id": "abc123", ...}

    Usage:
        const eventSource = new EventSource('/api/v1/governance/events');
        eventSource.addEventListener('governance.event.logged', (e) => {
            const event = JSON.parse(e.data);
            console.log('New governance event:', event);
        });
    """

    async def event_generator():
        """Generate SSE events for this client."""
        sse_emitter = get_sse_emitter()
        queue = await sse_emitter.subscribe()

        logger.info("New governance SSE client subscribed")

        try:
            # Send initial connection event
            yield f'event: connected\ndata: {{"timestamp": "{datetime.utcnow().isoformat()}Z"}}\n\n'

            while True:
                # Wait for events from emitter
                event = await queue.get()

                # Format as SSE
                if isinstance(event, dict):
                    event_type = event.get("event_type", "governance.event.logged")
                    event_data = json.dumps(event)
                    yield f"event: {event_type}\ndata: {event_data}\n\n"
                else:
                    # Already formatted SSE string
                    yield event

        except asyncio.CancelledError:
            logger.info("Governance SSE client disconnected")
            await sse_emitter.unsubscribe(queue)
            raise
        except Exception as e:
            logger.error(f"SSE stream error: {e}", exc_info=True)
            await sse_emitter.unsubscribe(queue)
            raise

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable nginx buffering
        },
    )


# ==================== Event Replay ====================


@router.post("/replay")
async def replay_governance_events(
    request: ReplayRequest, ctx: DaemonContext = Depends(get_daemon_context)
):
    """
    Replay governance events from log file with optional filtering.

    Useful for:
    - Reconstructing history state from audit trail
    - Exporting events for compliance reports
    - Debugging event sequences

    Query Parameters:
    - from_timestamp: Start replay from this ISO timestamp
    - to_timestamp: End replay at this ISO timestamp
    - event_type_filter: Only include specific event types
    - actor_filter: Filter by actor
    - correlation_id_filter: Filter by correlation ID
    - limit: Maximum events to return

    Returns:
        {
            "events": [...],
            "total_count": 150,
            "filtered_count": 25,
            "replay_started_at": "2025-11-06T12:00:00Z",
            "replay_completed_at": "2025-11-06T12:00:01Z"
        }
    """
    try:
        replay_started_at = datetime.utcnow().isoformat() + "Z"

        # Get log path
        log_path = ctx.project_root / ".branchpy" / "governance.jsonl"

        if not log_path.exists():
            return JSONResponse(
                {
                    "events": [],
                    "total_count": 0,
                    "filtered_count": 0,
                    "replay_started_at": replay_started_at,
                    "replay_completed_at": datetime.utcnow().isoformat() + "Z",
                }
            )

        # Replay events with timestamp filter
        events = []
        total_count = 0

        for event in replay_events(log_path, from_timestamp=request.from_timestamp):
            total_count += 1

            # Apply to_timestamp filter
            if request.to_timestamp:
                event_ts = datetime.fromisoformat(
                    event["timestamp"].replace("Z", "+00:00")
                )
                to_ts = datetime.fromisoformat(
                    request.to_timestamp.replace("Z", "+00:00")
                )
                if event_ts > to_ts:
                    break

            # Apply event type filter
            if request.event_type_filter:
                if event.get("event_type") not in request.event_type_filter:
                    continue

            # Apply actor filter
            if request.actor_filter:
                if event.get("actor") != request.actor_filter:
                    continue

            # Apply correlation ID filter
            if request.correlation_id_filter:
                if event.get("correlation_id") != request.correlation_id_filter:
                    continue

            events.append(event)

            # Respect limit
            if len(events) >= request.limit:
                break

        replay_completed_at = datetime.utcnow().isoformat() + "Z"

        # Emit SSE event for replay completion
        sse_emitter = get_sse_emitter()
        await sse_emitter.emit(
            {
                "event_type": "governance.replay.completed",
                "total_events": total_count,
                "filtered_events": len(events),
                "timestamp": replay_completed_at,
            }
        )

        return JSONResponse(
            {
                "events": events,
                "total_count": total_count,
                "filtered_count": len(events),
                "replay_started_at": replay_started_at,
                "replay_completed_at": replay_completed_at,
            }
        )

    except Exception as e:
        logger.error(f"Event replay failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Event Querying ====================


@router.post("/query")
async def query_governance_events(
    request: QueryEventsRequest, ctx: DaemonContext = Depends(get_daemon_context)
):
    """
    Query governance events with filters.

    Similar to replay but uses in-memory filtering for better performance
    on recent events.

    Returns:
        {
            "events": [...],
            "total_count": 150,
            "has_more": true
        }
    """
    try:
        # Initialize logger
        governance_logger = GovernanceLogger(ctx.project_root)

        # Query events
        events = governance_logger.query_events(
            event_type=request.event_type,
            correlation_id=request.correlation_id,
            actor=request.actor,
            limit=request.limit,
            offset=request.offset,
        )

        # Get total count (approximate)
        stats = governance_logger.get_statistics()
        total_count = stats.get("total_events", 0)

        return JSONResponse(
            {
                "events": events,
                "total_count": total_count,
                "has_more": len(events) == request.limit,
            }
        )

    except Exception as e:
        logger.error(f"Event query failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/timeline/{correlation_id}")
async def get_event_timeline(
    correlation_id: str, ctx: DaemonContext = Depends(get_daemon_context)
):
    """
    Get complete timeline of events for a correlation ID.

    Returns all events linked by the same correlation ID in chronological order.

    Returns:
        {
            "correlation_id": "abc123",
            "events": [...],
            "event_count": 5,
            "first_event_at": "2025-11-06T10:00:00Z",
            "last_event_at": "2025-11-06T10:05:00Z"
        }
    """
    try:
        governance_logger = GovernanceLogger(ctx.project_root)

        # Get event timeline
        events = governance_logger.get_event_timeline(correlation_id)

        if not events:
            raise HTTPException(
                status_code=404,
                detail=f"No events found for correlation ID: {correlation_id}",
            )

        return JSONResponse(
            {
                "correlation_id": correlation_id,
                "events": events,
                "event_count": len(events),
                "first_event_at": events[0].get("timestamp") if events else None,
                "last_event_at": events[-1].get("timestamp") if events else None,
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Timeline retrieval failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Statistics & Health ====================


@router.get("/statistics", response_model=StatisticsResponse)
async def get_governance_statistics(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    Get governance event statistics.

    Returns:
    - Total event count
    - Event counts by type
    - Unique actor count
    - Unique correlation ID count
    - Date range (earliest to latest event)
    - Batching enabled status
    """
    try:
        governance_logger = GovernanceLogger(ctx.project_root)

        stats = governance_logger.get_statistics()

        return StatisticsResponse(
            total_events=stats.get("total_events", 0),
            event_types=stats.get("event_types", {}),
            unique_actors=stats.get("unique_actors", 0),
            unique_correlations=stats.get("unique_correlations", 0),
            date_range=stats.get("date_range"),
            batching_enabled=governance_logger.use_batching,
        )

    except Exception as e:
        logger.error(f"Statistics retrieval failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/integrity", response_model=IntegrityCheckResponse)
async def verify_governance_integrity(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    Verify integrity of governance log.

    Checks:
    - Valid JSON for all entries
    - Required fields present
    - Chronological order

    Returns:
        {
            "valid": true,
            "errors": [],
            "warnings": ["Event out of chronological order at line 42"]
        }
    """
    try:
        governance_logger = GovernanceLogger(ctx.project_root)

        result = governance_logger.verify_integrity()

        return IntegrityCheckResponse(
            valid=result.get("valid", False),
            errors=result.get("errors", []),
            warnings=result.get("warnings", []),
        )

    except Exception as e:
        logger.error(f"Integrity check failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/flush")
async def flush_event_buffer(ctx: DaemonContext = Depends(get_daemon_context)):
    """
    Force flush buffered events to disk.

    Useful for:
    - Ensuring events are persisted before shutdown
    - Testing event batching behavior
    - Debugging event persistence

    Returns:
        {
            "success": true,
            "message": "Flushed buffered events"
        }
    """
    try:
        governance_logger = GovernanceLogger(ctx.project_root)
        governance_logger.flush()

        # Emit SSE event
        sse_emitter = get_sse_emitter()
        await sse_emitter.emit(
            {
                "event_type": "governance.batch.flushed",
                "timestamp": datetime.utcnow().isoformat() + "Z",
            }
        )

        return JSONResponse({"success": True, "message": "Flushed buffered events"})

    except Exception as e:
        logger.error(f"Flush failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Registration ====================


def register_routes(app):
    """Register governance routes with FastAPI app."""
    app.include_router(router)
    logger.info("Registered governance API routes")
