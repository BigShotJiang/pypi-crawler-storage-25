# branchpy/logging_setup.py
from __future__ import annotations

import json
import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

from .config_store import ConfigStore

LEVELS = {
    "errors": logging.ERROR,
    "system": logging.INFO,  # errors + system events
    "verbose": logging.DEBUG,  # errors + system + user actions
}


def init_logging(level: str = "system", cfg: Optional[ConfigStore] = None) -> str:
    cfg = cfg or ConfigStore()
    log_dir = cfg.logs_path
    log_path = os.path.join(log_dir, "branchpy.log")

    os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger("branchpy")
    logger.setLevel(LEVELS.get(level, logging.INFO))
    logger.handlers.clear()

    fh = RotatingFileHandler(
        log_path, maxBytes=512_000, backupCount=3, encoding="utf-8"
    )
    fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(fh)

    sh = logging.StreamHandler()
    sh.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    logger.addHandler(sh)

    logger.info("logging_initialized level=%s", level)
    return log_path


def compact_run_summary(logger: logging.Logger, **fields):
    # Single-line summary for easy grepping
    parts = [f"{k}={v}" for k, v in fields.items()]
    logger.info("run_summary %s", " ".join(parts))


# ---------- v0.6.3: Action Log (JSONL) ----------
_ACTION_MAX_BYTES = 5 * 1024 * 1024  # 5MB
_ACTION_KEEP = 5


def _sanitize_args(d: dict | None) -> dict:
    if not d:
        return {}
    S = ("token", "license", "key", "password", "passwd", "secret")
    out = {}
    for k, v in d.items():
        out[k] = "***" if any(s in k.lower() for s in S) else v
    return out


def _action_log_path(cfg: Optional[ConfigStore] = None) -> str:
    cfg = cfg or ConfigStore()
    os.makedirs(cfg.logs_path, exist_ok=True)
    return os.path.join(cfg.logs_path, "action.log")


def _rotate(path: Path):
    try:
        if not path.exists() or path.stat().st_size < _ACTION_MAX_BYTES:
            return
        # shift .(n-1) -> .n
        for i in range(_ACTION_KEEP, 0, -1):
            src = path.with_suffix(path.suffix + f".{i}")
            dst = path.with_suffix(path.suffix + f".{i+1}")
            if src.exists():
                if i == _ACTION_KEEP:
                    src.unlink(missing_ok=True)  # py3.11+
                else:
                    src.replace(dst)
        path.replace(path.with_suffix(path.suffix + ".1"))
    except Exception:
        # never fail the CLI because of logging
        pass


def log_action(record: dict, cfg: Optional[ConfigStore] = None) -> None:
    """
    Append one JSON object (single line) to action.log. Metadata only, no file contents.
    """
    try:
        p = Path(_action_log_path(cfg))
        _rotate(p)
        line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
        with p.open("a", encoding="utf-8", newline="\n") as f:
            f.write(line + "\n")
    except Exception:
        pass
