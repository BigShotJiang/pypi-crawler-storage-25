"""Discovery result caching for performance optimization"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from branchpy.discovery.base import (
    DiscoveryResult,
    DiscoveryStatus,
    EngineCandidate,
    Evidence,
    EvidenceType,
    MarkerCategory,
    ProbedPath,
)


@dataclass
class CacheKey:
    """Deterministic cache key for discovery results"""

    project_path: str
    threshold: float
    force_engine: Optional[str]
    force_engine_always: bool

    def to_hash(self) -> str:
        """Generate deterministic hash for cache lookup"""
        # Normalize project path (resolve symlinks, case)
        normalized = Path(self.project_path).resolve()

        # Build canonical key string
        key_parts = [
            f"path={normalized}",
            f"threshold={self.threshold:.2f}",
            f"force={self.force_engine or 'none'}",
            f"always={int(self.force_engine_always)}",
        ]
        key_string = "|".join(key_parts)

        # Hash to fixed-length identifier
        return hashlib.sha256(key_string.encode()).hexdigest()[:16]


@dataclass
class CacheEntry:
    """Cached discovery result with metadata"""

    cache_key: str
    cached_at: float  # Unix timestamp
    result: DiscoveryResult
    marker_mtimes: dict[str, float]  # {path: mtime} for invalidation

    def to_dict(self) -> dict:
        """Serialize for JSON storage"""
        return {
            "cache_key": self.cache_key,
            "cached_at": self.cached_at,
            "result": self.result.to_dict(),
            "marker_mtimes": self.marker_mtimes,
        }

    @classmethod
    def from_dict(cls, data: dict) -> CacheEntry:
        """Deserialize from JSON storage"""
        # Reconstruct DiscoveryResult (reverse of to_dict)
        result_data = data["result"]

        # Rebuild candidates
        candidates = []
        for c_data in result_data["candidates"]:
            evidence = []
            for e_data in c_data["evidence"]:
                evidence.append(
                    Evidence(
                        type=EvidenceType(e_data["type"]),
                        pattern=e_data["pattern"],
                        found=e_data["found"],
                        weight=e_data["weight"],
                        locations=e_data["locations"],
                        category=(
                            MarkerCategory(e_data["category"])
                            if "category" in e_data
                            else None
                        ),
                    )
                )
            candidates.append(
                EngineCandidate(
                    engine=c_data["engine"],
                    confidence=c_data["confidence"],
                    evidence=evidence,
                    root_hint=c_data["root_hint"],
                )
            )

        # Rebuild probed paths
        probed_paths = []
        for p_data in result_data["probed_paths"]:
            probed_paths.append(
                ProbedPath(
                    engine=p_data["engine"],
                    pattern=p_data["pattern"],
                    searched=p_data["searched"],
                )
            )

        # Rebuild DiscoveryResult
        result = DiscoveryResult(
            status=DiscoveryStatus(result_data["status"]),
            candidates=candidates,
            probed_paths=probed_paths,
            reason=result_data.get("reason"),
            matched_engine=result_data.get("matched_engine"),
            override=result_data.get("override", False),
            override_reason=result_data.get("override_reason"),
            original_status=(
                DiscoveryStatus(result_data["original_status"])
                if "original_status" in result_data
                else None
            ),
        )

        return cls(
            cache_key=data["cache_key"],
            cached_at=data["cached_at"],
            result=result,
            marker_mtimes=data["marker_mtimes"],
        )


class DiscoveryCache:
    """Manages discovery result caching"""

    def __init__(self, cache_dir: Path, ttl_seconds: float = 3600.0):
        """
        Initialize cache manager.

        Args:
            cache_dir: Directory for cache files (.branchpy/cache/)
            ttl_seconds: Time-to-live for cache entries (default: 1 hour)
        """
        self.cache_dir = cache_dir
        self.ttl_seconds = ttl_seconds
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _get_cache_path(self, cache_key: str) -> Path:
        """Get cache file path for given key"""
        return self.cache_dir / f"discovery_{cache_key}.json"

    def get(
        self,
        project_path: str | Path,
        threshold: float,
        force_engine: Optional[str],
        force_engine_always: bool,
    ) -> Optional[DiscoveryResult]:
        """
        Retrieve cached discovery result if valid.

        Args:
            project_path: Project root path
            threshold: Confidence threshold
            force_engine: Forced engine (or None)
            force_engine_always: Force override even on MATCHED

        Returns:
            Cached DiscoveryResult if valid, None otherwise
        """
        key = CacheKey(
            project_path=str(project_path),
            threshold=threshold,
            force_engine=force_engine,
            force_engine_always=force_engine_always,
        )
        cache_hash = key.to_hash()
        cache_path = self._get_cache_path(cache_hash)

        # Cache miss: file doesn't exist
        if not cache_path.exists():
            return None

        try:
            # Load cache entry
            with open(cache_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            entry = CacheEntry.from_dict(data)

            # Validate TTL
            age = time.time() - entry.cached_at
            if age > self.ttl_seconds:
                # Cache expired
                cache_path.unlink(missing_ok=True)
                return None

            # Validate marker mtimes (invalidate if files changed)
            project_root = Path(project_path).resolve()
            for rel_path, cached_mtime in entry.marker_mtimes.items():
                abs_path = project_root / rel_path
                if abs_path.exists():
                    current_mtime = abs_path.stat().st_mtime
                    if current_mtime > cached_mtime:
                        # File changed since cache
                        cache_path.unlink(missing_ok=True)
                        return None
                else:
                    # File was deleted
                    cache_path.unlink(missing_ok=True)
                    return None

            # Cache hit
            return entry.result

        except Exception:
            # Corrupted cache - delete and return miss
            cache_path.unlink(missing_ok=True)
            return None

    def put(
        self,
        project_path: str | Path,
        threshold: float,
        force_engine: Optional[str],
        force_engine_always: bool,
        result: DiscoveryResult,
        marker_paths: list[str],
    ) -> None:
        """
        Store discovery result in cache.

        Args:
            project_path: Project root path
            threshold: Confidence threshold
            force_engine: Forced engine (or None)
            force_engine_always: Force override even on MATCHED
            result: Discovery result to cache
            marker_paths: List of marker file paths for invalidation tracking
        """
        key = CacheKey(
            project_path=str(project_path),
            threshold=threshold,
            force_engine=force_engine,
            force_engine_always=force_engine_always,
        )
        cache_hash = key.to_hash()
        cache_path = self._get_cache_path(cache_hash)

        # Collect marker mtimes for invalidation
        project_root = Path(project_path).resolve()
        marker_mtimes = {}
        for marker_path in marker_paths:
            abs_path = project_root / marker_path
            if abs_path.exists():
                marker_mtimes[marker_path] = abs_path.stat().st_mtime

        # Build cache entry
        entry = CacheEntry(
            cache_key=cache_hash,
            cached_at=time.time(),
            result=result,
            marker_mtimes=marker_mtimes,
        )

        # Write to cache
        try:
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(entry.to_dict(), f, indent=2)
        except Exception:
            # Ignore cache write failures (non-fatal)
            pass

    def clear(self, project_path: Optional[str | Path] = None) -> int:
        """
        Clear cache entries.

        Args:
            project_path: If provided, clear only this project's cache.
                         If None, clear all discovery caches.

        Returns:
            Number of cache files deleted
        """
        if project_path is not None:
            # Clear specific project (all threshold/override combinations)
            # This requires scanning all cache files (no index)
            deleted = 0
            normalized = Path(project_path).resolve()

            for cache_file in self.cache_dir.glob("discovery_*.json"):
                try:
                    with open(cache_file, "r", encoding="utf-8") as f:
                        data = json.load(f)

                    # Check if this cache is for the target project
                    # (We'd need to parse result.candidates[0].root_hint or store project_path separately)
                    # For now, just check if any candidate root_hint matches
                    result_data = data.get("result", {})
                    candidates = result_data.get("candidates", [])

                    for candidate in candidates:
                        if Path(candidate.get("root_hint", "")).resolve() == normalized:
                            cache_file.unlink(missing_ok=True)
                            deleted += 1
                            break
                except Exception:
                    # Skip corrupted files
                    continue

            return deleted
        else:
            # Clear all discovery caches
            deleted = 0
            for cache_file in self.cache_dir.glob("discovery_*.json"):
                cache_file.unlink(missing_ok=True)
                deleted += 1
            return deleted
