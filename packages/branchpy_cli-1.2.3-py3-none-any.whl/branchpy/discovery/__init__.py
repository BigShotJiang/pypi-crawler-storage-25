"""
BranchPy Discovery Layer

Provides engine-agnostic project detection.
"""

from branchpy.discovery.base import (
    BaseEngineDetector,
    DiscoveryResult,
    DiscoveryStatus,
    EngineCandidate,
    Evidence,
    EvidenceType,
    Marker,
    MarkerCategory,
    ProbedPath,
)
from branchpy.discovery.orchestrator import ProjectDiscovery

__all__ = [
    "BaseEngineDetector",
    "DiscoveryResult",
    "DiscoveryStatus",
    "EngineCandidate",
    "Evidence",
    "EvidenceType",
    "Marker",
    "MarkerCategory",
    "ProbedPath",
    "ProjectDiscovery",
]
