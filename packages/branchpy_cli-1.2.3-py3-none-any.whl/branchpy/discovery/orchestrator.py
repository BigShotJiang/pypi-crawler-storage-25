"""Discovery orchestrator"""

from pathlib import Path
from typing import List, Optional

from branchpy.discovery.base import (
    BaseEngineDetector,
    DiscoveryResult,
    DiscoveryStatus,
    EngineCandidate,
    ProbedPath,
)
from branchpy.discovery.cache import DiscoveryCache
from branchpy.discovery.detectors.godot import GodotDetector
from branchpy.discovery.detectors.renpy import RenpyDetector
from branchpy.discovery.detectors.unity import UnityDetector
from branchpy.discovery.detectors.unreal import UnrealDetector


class ProjectDiscovery:
    """Orchestrates multi-engine project detection"""

    def __init__(
        self,
        detectors: Optional[List[BaseEngineDetector]] = None,
        cache: Optional[DiscoveryCache] = None,
    ):
        """
        Initialize discovery with detectors.

        Args:
            detectors: Custom detectors (defaults to all built-in)
            cache: Discovery cache (optional, for performance)
        """
        self.detectors = detectors or [
            RenpyDetector(),
            GodotDetector(),
            UnityDetector(),
            UnrealDetector(),
        ]
        self.cache = cache

    def discover(
        self,
        project_path: str | Path,
        threshold: float = 0.5,
        force_engine: Optional[str] = None,
        force_engine_always: bool = False,
        use_cache: bool = True,
    ) -> DiscoveryResult:
        """
        Detect project type at given path.

        Args:
            project_path: Path to search
            threshold: Minimum confidence to consider a match (default 0.5)
            force_engine: Override engine selection (None, "renpy", "godot", "unity", "unreal")
            force_engine_always: If True, apply override even on MATCHED status
            use_cache: If True and cache configured, use cached results (default: True)

        Returns:
            DiscoveryResult with status and candidates
        """
        project_path = Path(project_path).resolve()

        # Try cache hit
        if use_cache and self.cache is not None:
            cached_result = self.cache.get(
                project_path,
                threshold,
                force_engine,
                force_engine_always,
            )
            if cached_result is not None:
                # Cache hit - return cached result
                return cached_result

        # Cache miss - perform discovery
        candidates = []
        probed_paths = []
        marker_paths = []  # Track marker paths for cache invalidation

        # Run all detectors
        for detector in self.detectors:
            candidate = detector.detect(project_path)
            candidates.append(candidate)

            # Collect probed paths and marker paths
            for evidence in candidate.evidence:
                probed_paths.append(
                    ProbedPath(
                        engine=detector.engine_name,
                        pattern=evidence.pattern,
                        searched=True,
                    )
                )
                # Track found files for cache invalidation
                if evidence.found:
                    marker_paths.extend(evidence.locations)

        # Sort by confidence (highest first), then by engine name (lexicographic) for tiebreak
        candidates.sort(key=lambda c: (-c.confidence, c.engine))

        # Filter by threshold
        matches = [c for c in candidates if c.confidence >= threshold]

        # Determine status
        if len(matches) == 0:
            status = DiscoveryStatus.NO_MATCH
            reason = self._build_no_match_reason(project_path, candidates)
            matched_engine = None
        elif len(matches) == 1:
            status = DiscoveryStatus.MATCHED
            reason = None
            matched_engine = matches[0].engine
        else:
            status = DiscoveryStatus.AMBIGUOUS
            matched_engine = matches[0].engine  # Highest confidence
            reason = (
                f"Multiple engines matched (using {matched_engine} with "
                f"{matches[0].confidence:.0%} confidence): "
                f"{', '.join(m.engine for m in matches)}"
            )

        result = DiscoveryResult(
            status=status,
            candidates=candidates,
            probed_paths=probed_paths,
            reason=reason,
            matched_engine=matched_engine,
        )

        # Apply override policy (Phase 2)
        if force_engine is not None:
            result = self._apply_override(result, force_engine, force_engine_always)

        # Store in cache (Phase 3)
        if use_cache and self.cache is not None:
            self.cache.put(
                project_path,
                threshold,
                force_engine,
                force_engine_always,
                result,
                marker_paths,
            )

        return result

    def _apply_override(
        self,
        result: DiscoveryResult,
        force_engine: str,
        force_always: bool,
    ) -> DiscoveryResult:
        """
        Apply engine override policy.

        Override applies:
          - If force_always=True: ALWAYS override
          - If force_always=False: Only on NO_MATCH or AMBIGUOUS

        Args:
            result: Original discovery result
            force_engine: Engine to force
            force_always: Whether to override even on MATCHED

        Returns:
            DiscoveryResult with override metadata
        """
        # Validate engine exists
        valid_engines = {d.engine_name for d in self.detectors}
        if force_engine not in valid_engines:
            # Invalid engine - return original result with error reason
            result.reason = (
                f"Invalid force_engine '{force_engine}' (valid: {', '.join(sorted(valid_engines))}). "
                f"Using auto-detected: {result.matched_engine or 'NONE'}"
            )
            return result

        # Determine if override should apply
        should_override = force_always or result.status in (
            DiscoveryStatus.NO_MATCH,
            DiscoveryStatus.AMBIGUOUS,
        )

        if not should_override:
            # Override not applicable (MATCHED and not force_always)
            return result

        # Apply override
        original_status = result.status
        original_reason = result.reason

        result.override = True
        result.original_status = original_status
        result.status = DiscoveryStatus.MATCHED
        result.matched_engine = force_engine

        # Build override reason
        if force_always:
            result.override_reason = (
                f"Forced to '{force_engine}' (force_engine_always=true, "
                f"original: {original_status.value})"
            )
        elif original_status == DiscoveryStatus.NO_MATCH:
            result.override_reason = f"Forced to '{force_engine}' (no match detected)"
        else:  # AMBIGUOUS
            result.override_reason = (
                f"Forced to '{force_engine}' (ambiguous detection resolved)"
            )

        # Update reason field
        result.reason = result.override_reason
        if original_reason:
            result.reason += f" | Original: {original_reason}"

        return result

    def _build_no_match_reason(
        self, project_path: Path, candidates: List[EngineCandidate]
    ) -> str:
        """Build actionable error message when no engine matched"""
        lines = [
            "No supported project type detected.",
            f"Searched path: {project_path}",
            "",
            "Attempted engines:",
        ]

        for candidate in candidates:
            lines.append(
                f"  - {candidate.engine}: {candidate.confidence:.0%} confidence"
            )
            for evidence in candidate.evidence:
                if evidence.weight > 0:  # Only show non-stub markers
                    icon = "✓" if evidence.found else "✗"
                    lines.append(f"    {icon} {evidence.pattern}")

        lines.extend(
            [
                "",
                "Suggestions:",
                "  - Ensure you are in the correct project root directory",
                "  - For Ren'Py: folder must contain 'game/' with .rpy files",
                "  - For Godot: folder must contain 'project.godot' (not yet supported)",
                "  - For Unity: folder must contain 'Assets/' and 'ProjectSettings/' (not yet supported)",
                "  - For Unreal: folder must contain a .uproject file (not yet supported)",
            ]
        )

        return "\n".join(lines)
