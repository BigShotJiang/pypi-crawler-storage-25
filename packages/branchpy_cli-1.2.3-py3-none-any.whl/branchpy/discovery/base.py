"""Base classes and dataclasses for engine discovery"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional


class DiscoveryStatus(Enum):
    """Project discovery status"""

    MATCHED = "matched"  # Exactly one engine matched
    AMBIGUOUS = "ambiguous"  # Multiple engines matched (>= threshold)
    NO_MATCH = "no_match"  # No engine matched


class EvidenceType(Enum):
    """Type of detection evidence"""

    FILE = "file"  # Specific file exists
    DIRECTORY = "directory"  # Directory exists
    PATTERN = "pattern"  # Glob pattern matches


class MarkerCategory(Enum):
    """Category of detection marker for scoring"""

    CORE = "core"  # Core evidence (determines engine identity)
    SUPPORTING = "supporting"  # Supporting evidence (improves certainty)
    DIAGNOSTIC = "diagnostic"  # Diagnostic only (SDK/tooling detection)


@dataclass
class Marker:
    """Detection marker with pattern and weight"""

    pattern: str  # Glob pattern or file/dir name
    weight: float  # Contribution to confidence (0.0-1.0)
    type: EvidenceType  # What kind of marker
    category: MarkerCategory = MarkerCategory.SUPPORTING  # Scoring category


@dataclass
class Evidence:
    """Evidence of engine detection attempt"""

    type: EvidenceType
    pattern: str
    found: bool
    weight: float
    locations: List[str] = field(default_factory=list)
    category: Optional[MarkerCategory] = None  # For diagnostic UX

    def to_dict(self) -> dict:
        result = {
            "type": self.type.value,
            "pattern": self.pattern,
            "found": self.found,
            "weight": self.weight,
            "locations": self.locations,
        }
        if self.category is not None:
            result["category"] = self.category.value
        return result


@dataclass
class EngineCandidate:
    """Result of engine detection"""

    engine: str
    confidence: float  # 0.0 to 1.0
    evidence: List[Evidence]
    root_hint: str  # Suggested project root

    def to_dict(self) -> dict:
        return {
            "engine": self.engine,
            "confidence": self.confidence,
            "evidence": [e.to_dict() for e in self.evidence],
            "root_hint": self.root_hint,
        }


@dataclass
class ProbedPath:
    """Record of what was searched"""

    engine: str
    pattern: str
    searched: bool

    def to_dict(self) -> dict:
        return {
            "engine": self.engine,
            "pattern": self.pattern,
            "searched": self.searched,
        }


@dataclass
class DiscoveryResult:
    """Complete discovery result"""

    status: DiscoveryStatus
    candidates: List[EngineCandidate]
    probed_paths: List[ProbedPath]
    reason: Optional[str] = None
    matched_engine: Optional[str] = None  # Set when status == MATCHED
    override: bool = False  # True if engine was force-overridden
    override_reason: Optional[str] = None  # Explanation for override
    original_status: Optional[DiscoveryStatus] = None  # Pre-override status

    def to_dict(self) -> dict:
        result = {
            "status": self.status.value,
            "candidates": [c.to_dict() for c in self.candidates],
            "probed_paths": [p.to_dict() for p in self.probed_paths],
        }
        if self.reason:
            result["reason"] = self.reason
        if self.matched_engine:
            result["matched_engine"] = self.matched_engine
        if self.override:
            result["override"] = self.override
        if self.override_reason:
            result["override_reason"] = self.override_reason
        if self.original_status:
            result["original_status"] = self.original_status.value
        return result


class BaseEngineDetector(ABC):
    """Base class for engine-specific project detection"""

    @property
    @abstractmethod
    def engine_name(self) -> str:
        """Engine identifier (e.g., 'renpy', 'godot')"""
        pass

    @abstractmethod
    def get_markers(self) -> List[Marker]:
        """
        Get detection markers for this engine.

        Returns:
            List of Marker objects with patterns and weights
        """
        pass

    def detect(self, project_path: Path) -> EngineCandidate:
        """
        Detect if project_path contains this engine's project.

        Uses core/supporting evidence split:
        - Core markers determine engine identity (dominant signal)
        - Supporting markers improve certainty (additive bonus)
        - Diagnostic markers don't contribute to confidence

        Args:
            project_path: Path to search

        Returns:
            EngineCandidate with confidence 0.0-1.0 and evidence
        """
        evidence = []
        core_found = 0.0
        core_total = 0.0
        supporting_found = 0.0
        supporting_total = 0.0

        markers = self.get_markers()

        for marker in markers:
            found_locations = self._check_marker(project_path, marker)
            found = len(found_locations) > 0

            evidence.append(
                Evidence(
                    type=marker.type,
                    pattern=marker.pattern,
                    found=found,
                    weight=marker.weight,
                    locations=found_locations,
                    category=marker.category,
                )
            )

            # Categorize evidence
            if marker.category == MarkerCategory.CORE:
                core_total += marker.weight
                if found:
                    core_found += marker.weight
            elif marker.category == MarkerCategory.SUPPORTING:
                supporting_total += marker.weight
                if found:
                    supporting_found += marker.weight
            # DIAGNOSTIC markers don't contribute to confidence

        # Calculate confidence using core/supporting split
        # Core score dominates (0.85 weight), supporting adds certainty (0.15 weight)
        core_score = (core_found / core_total) if core_total > 0 else 0.0
        supporting_score = (
            (supporting_found / supporting_total) if supporting_total > 0 else 0.0
        )

        # Weighted combination: core is 85%, supporting is 15%
        confidence = min(core_score * 0.85 + supporting_score * 0.15, 1.0)

        return EngineCandidate(
            engine=self.engine_name,
            confidence=confidence,
            evidence=evidence,
            root_hint=str(project_path),
        )

    def _check_marker(self, project_path: Path, marker: Marker) -> List[str]:
        """
        Check if a marker matches in the project.

        Args:
            project_path: Root path to search
            marker: Marker to check

        Returns:
            List of matching paths (empty if no match)
        """
        if marker.type == EvidenceType.FILE:
            # Check for specific file
            file_path = project_path / marker.pattern
            if file_path.exists() and file_path.is_file():
                return [str(file_path.relative_to(project_path))]

        elif marker.type == EvidenceType.DIRECTORY:
            # Check for directory
            dir_path = project_path / marker.pattern
            if dir_path.exists() and dir_path.is_dir():
                return [str(dir_path.relative_to(project_path))]

        elif marker.type == EvidenceType.PATTERN:
            # Glob search
            try:
                matches = list(project_path.glob(marker.pattern))
                if matches:
                    return [
                        str(m.relative_to(project_path)) for m in matches[:5]
                    ]  # Limit to 5 examples
            except Exception:
                # Ignore glob errors (invalid patterns, permissions, etc.)
                pass

        return []
