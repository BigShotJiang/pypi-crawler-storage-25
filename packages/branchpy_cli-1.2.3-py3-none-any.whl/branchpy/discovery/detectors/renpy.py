"""Ren'Py project detector"""

from typing import List

from branchpy.discovery.base import (
    BaseEngineDetector,
    EvidenceType,
    Marker,
    MarkerCategory,
)


class RenpyDetector(BaseEngineDetector):
    """Detect Ren'Py projects"""

    @property
    def engine_name(self) -> str:
        return "renpy"

    def get_markers(self) -> List[Marker]:
        """
        Ren'Py detection markers using core/supporting evidence model.

        CORE evidence (determines Ren'Py identity):
        - game/**/*.rpy: Actual Ren'Py script files (required)

        SUPPORTING evidence (improves certainty):
        - game/options.rpy: Standard config file
        - game/screens.rpy: Standard UI file

        DIAGNOSTIC evidence (SDK detection, doesn't affect confidence):
        - renpy/: SDK directory

        Scoring model:
        - Core: 85% weight → minimal project (script.rpy only) = 85% confidence
        - Supporting: 15% weight → complete project (all supporting) = 100% confidence
        - Diagnostic: 0% weight → presence/absence doesn't affect score
        """
        return [
            # CORE: actual script files (defines Ren'Py identity)
            Marker(
                "game/**/*.rpy",
                weight=1.0,
                type=EvidenceType.PATTERN,
                category=MarkerCategory.CORE,
            ),
            # SUPPORTING: standard project files (improve certainty)
            Marker(
                "game/options.rpy",
                weight=1.0,
                type=EvidenceType.FILE,
                category=MarkerCategory.SUPPORTING,
            ),
            Marker(
                "game/screens.rpy",
                weight=1.0,
                type=EvidenceType.FILE,
                category=MarkerCategory.SUPPORTING,
            ),
            # DIAGNOSTIC: SDK marker (informational only)
            Marker(
                "renpy/",
                weight=1.0,
                type=EvidenceType.DIRECTORY,
                category=MarkerCategory.DIAGNOSTIC,
            ),
        ]
