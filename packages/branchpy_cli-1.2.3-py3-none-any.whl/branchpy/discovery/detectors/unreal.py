"""Unreal project detector (stub)"""

from typing import List

from branchpy.discovery.base import BaseEngineDetector, Marker


class UnrealDetector(BaseEngineDetector):
    """Detect Unreal projects (not yet implemented)"""

    @property
    def engine_name(self) -> str:
        return "unreal"

    def get_markers(self) -> List[Marker]:
        """Unreal markers (stub - returns empty list)"""
        # Future: Add *.uproject, Source/, Config/ detection
        return []
