"""Godot project detector (stub)"""

from typing import List

from branchpy.discovery.base import BaseEngineDetector, Marker


class GodotDetector(BaseEngineDetector):
    """Detect Godot projects (not yet implemented)"""

    @property
    def engine_name(self) -> str:
        return "godot"

    def get_markers(self) -> List[Marker]:
        """Godot markers (stub - returns empty list)"""
        # Future: Add project.godot, *.tscn, *.tres detection
        return []
