"""Unity project detector (stub)"""

from typing import List

from branchpy.discovery.base import BaseEngineDetector, Marker


class UnityDetector(BaseEngineDetector):
    """Detect Unity projects (not yet implemented)"""

    @property
    def engine_name(self) -> str:
        return "unity"

    def get_markers(self) -> List[Marker]:
        """Unity markers (stub - returns empty list)"""
        # Future: Add Assets/, ProjectSettings/, manifest.json detection
        return []
