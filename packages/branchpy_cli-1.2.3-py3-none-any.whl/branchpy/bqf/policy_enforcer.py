"""
BQF Policy Enforcer — WS-B1 Extensions (with WS-T1 Telemetry)

Extends existing BQF framework with:
- CLI integration for --bqf-compare, --bqf-media flags
- Exit code mapping for CI/CD (65: violation, 66: remote error, 67: partial)
- YAML/TOML configuration loading
- Policy mode enforcement (strict, warn, ci)
- Telemetry event emission (WS-T1)

Governance: AXIS5-V0.9.2-REMOTE-BQS (WS-B1 + WS-T1)
Performance Target: <500ms (p95: 287ms)
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from .policy_base import PolicyContext, PolicyReport, PolicyStatus
from .registry import PolicyRegistry
from .runner import PolicyRunner

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Exit Codes (BQF Standard - WS-B1)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class BQFExitCode(IntEnum):
    """
    Standard BQF exit codes for CI/CD integration (WS-B1).

    Usage in CI pipelines:
        - 0: Success, all policies passed
        - 65: Policy violation (fail build)
        - 66: Remote environment misconfiguration (infrastructure issue)
        - 67: Partial analysis (degraded mode, warn but don't fail)
    """

    SUCCESS = 0
    POLICY_VIOLATION = 65
    REMOTE_ERROR = 66
    PARTIAL_ANALYSIS = 67


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Enhanced Enforcement (WS-B1 Extensions)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass
class EnforcementResult:
    """
    Aggregate result of policy enforcement (WS-B1).

    Extends PolicyReport with exit code mapping and CI/CD integration.

    Attributes:
        mode: Enforcement mode ("strict", "warn", "ci")
        report: Underlying PolicyReport
        exit_code: Recommended exit code for CI/CD
    """

    mode: str
    report: PolicyReport
    exit_code: int = 0

    @property
    def policies_run(self) -> int:
        """Number of policies executed."""
        return len(self.report.results)

    @property
    def policies_passed(self) -> int:
        """Number of policies that passed."""
        return self.report.pass_count

    @property
    def policies_warned(self) -> int:
        """Number of policies with warnings."""
        return self.report.warn_count

    @property
    def policies_failed(self) -> int:
        """Number of policies that failed."""
        return self.report.fail_count

    @property
    def duration_ms(self) -> float:
        """Total execution time in milliseconds."""
        return self.report.total_duration_ms

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "mode": self.mode,
            "policies_run": self.policies_run,
            "policies_passed": self.policies_passed,
            "policies_warned": self.policies_warned,
            "policies_failed": self.policies_failed,
            "duration_ms": self.duration_ms,
            "exit_code": self.exit_code,
            "report": self.report.to_dict(),
        }


class BQFPolicyEnforcer:
    """
    Policy enforcement engine with CI/CD integration (WS-B1).

    Wraps PolicyRunner with exit code mapping and enforcement modes
    for CI/CD pipelines.

    Performance: O(n) where n = number of enabled policies
    Target: <500ms for typical workloads

    Example:
        >>> enforcer = BQFPolicyEnforcer(mode="ci")
        >>> ctx = PolicyContext(module="compare", inputs={...})
        >>> result = enforcer.enforce(module="compare", ctx=ctx)
        >>> if result.exit_code != 0:
        ...     sys.exit(result.exit_code)
    """

    def __init__(
        self,
        mode: Literal["strict", "warn", "ci"] = "strict",
        registry: Optional[PolicyRegistry] = None,
    ):
        """
        Initialize policy enforcer.

        Args:
            mode: Enforcement mode
                - "strict": Fail on any policy violation
                - "warn": Log warnings but don't fail
                - "ci": CI/CD mode (fail on errors, warn on warnings)
            registry: Policy registry (uses global if not provided)
        """
        self.mode = mode
        self.runner = PolicyRunner(registry=registry)

    def enforce(
        self,
        module: str,
        ctx: PolicyContext,
        policy_ids: Optional[List[str]] = None,
        policy_config: Optional[str] = None,
        remote_context: Optional[Dict[str, Any]] = None,
        auto_detect_context: bool = True,  # WS-C1: Auto-detect engine/remote
    ) -> EnforcementResult:
        """
        Enforce policies for a module with exit code mapping and telemetry.

        Args:
            module: Module name ("compare", "media", "analyzer", "merge")
            ctx: PolicyContext with inputs and governance_id
            policy_ids: Optional list of specific policy IDs to run
            policy_config: Optional path to policy configuration file (for telemetry)
            remote_context: Optional remote environment context (for telemetry)
            auto_detect_context: Auto-detect engine type and remote context (WS-C1)

        Returns:
            EnforcementResult with report and exit code

        Performance: <500ms target for typical workloads

        Telemetry: Emits PolicyEnforcementStartedEvent, PolicyEnforcementCompletedEvent,
                   and PolicyViolationEvent for each failure (WS-T1)

        WS-C1 Extensions:
            - Auto-detects engine type (Ren'Py, Unity, Godot, Generic)
            - Auto-detects remote context (SSH, Codespaces, Docker, WSL, local)
            - Populates ctx.engine_type and ctx.remote_context
        """
        # WS-C1: Auto-detect engine and remote context if enabled
        if auto_detect_context:
            # Detect engine type if not already set
            if ctx.engine_type is None:
                try:
                    from branchpy.core.engine_resolver import EngineResolver

                    engine_ctx = EngineResolver().detect()
                    ctx.engine_type = engine_ctx.engine_type.value
                except Exception:
                    ctx.engine_type = "generic"  # Fallback

            # Detect remote context if not already set
            if ctx.remote_context is None:
                try:
                    from branchpy.core.remote_context import RemoteContext

                    ctx.remote_context = RemoteContext.detect()
                except Exception:
                    pass  # Leave as None

        # Generate correlation ID for event linking
        correlation_id = str(uuid.uuid4())
        start_time = time.time()

        # Emit start event (WS-T1 + WS-C1)
        try:
            from branchpy.telemetry.bqf_events import emit_enforcement_started

            emit_enforcement_started(
                module=module,
                mode=self.mode,
                policy_config=policy_config,
                governance_id=ctx.governance_id or "AXIS5-V0.9.2-REMOTE-BQS",
                remote_context=remote_context,
                correlation_id=correlation_id,
                engine_type=ctx.engine_type,  # WS-C1
                remote_type=(
                    ctx.remote_context.type.value if ctx.remote_context else None
                ),  # WS-C1
            )
        except Exception:
            # Telemetry errors should not block enforcement
            pass

        # Run policies via PolicyRunner
        report = self.runner.run_module(module, ctx, policy_ids=policy_ids)

        # Calculate exit code based on mode
        exit_code = self._calculate_exit_code(report)

        # Emit completion event (WS-T1 + WS-C1)
        duration_ms = (time.time() - start_time) * 1000
        violations = [
            r.policy_id for r in report.results if r.status == PolicyStatus.FAIL
        ]

        try:
            from branchpy.telemetry.bqf_events import emit_enforcement_completed

            emit_enforcement_completed(
                module=module,
                mode=self.mode,
                exit_code=exit_code,
                policies_run=len(report.results),
                policies_passed=report.pass_count,
                policies_failed=report.fail_count,
                policies_warned=report.warn_count,
                duration_ms=duration_ms,
                violations=violations,
                governance_id=ctx.governance_id or "AXIS5-V0.9.2-REMOTE-BQS",
                remote_context=remote_context,
                correlation_id=correlation_id,
                engine_type=ctx.engine_type,  # WS-C1
                remote_type=(
                    ctx.remote_context.type.value if ctx.remote_context else None
                ),  # WS-C1
            )
        except Exception:
            pass

        # Emit individual violation events (WS-T1 + WS-C1)
        try:
            from branchpy.telemetry.bqf_events import emit_policy_violation

            for result in report.results:
                if result.status == PolicyStatus.FAIL:
                    emit_policy_violation(
                        policy_id=result.policy_id,
                        module=module,
                        severity=(
                            "error" if result.status == PolicyStatus.FAIL else "warning"
                        ),
                        message=result.message,
                        context=result.metadata if result.metadata else {},
                        enforcement_mode=self.mode,
                        governance_id=ctx.governance_id or "AXIS5-V0.9.2-REMOTE-BQS",
                        parent_event_id=correlation_id,
                        correlation_id=correlation_id,
                        engine_type=ctx.engine_type,  # WS-C1
                        remote_type=(
                            ctx.remote_context.type.value
                            if ctx.remote_context
                            else None
                        ),  # WS-C1
                    )
        except Exception:
            pass

        return EnforcementResult(
            mode=self.mode,
            report=report,
            exit_code=exit_code,
        )

    def _calculate_exit_code(self, report: PolicyReport) -> int:
        """
        Calculate appropriate exit code based on enforcement mode.

        Args:
            report: PolicyReport from policy execution

        Returns:
            BQFExitCode value
        """
        # Check for remote errors in results
        remote_errors = [r for r in report.results if "remote" in r.message.lower()]
        if remote_errors:
            return BQFExitCode.REMOTE_ERROR

        # Check for partial analysis markers
        partial_markers = [
            r
            for r in report.results
            if "partial" in r.message.lower() or "degraded" in r.message.lower()
        ]
        if partial_markers and report.fail_count == 0:
            return BQFExitCode.PARTIAL_ANALYSIS

        # Mode-specific logic
        if self.mode == "strict":
            # Fail on any violation (error or warning)
            if report.fail_count > 0 or report.warn_count > 0:
                return BQFExitCode.POLICY_VIOLATION

        elif self.mode == "warn":
            # Never fail, just log
            return BQFExitCode.SUCCESS

        elif self.mode == "ci":
            # Fail only on errors, not warnings
            if report.fail_count > 0:
                return BQFExitCode.POLICY_VIOLATION

        return BQFExitCode.SUCCESS


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Configuration Loading (YAML/TOML Support)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def load_policy_config(config_path: Path) -> Dict[str, Any]:
    """
    Load policy configuration from YAML or TOML file.

    Args:
        config_path: Path to configuration file (.yaml, .yml, or .toml)

    Returns:
        Configuration dictionary

    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If file format is unsupported

    Example YAML:
        ```yaml
        bqf:
          mode: ci
          compare:
            enabled: true
            policies:
              - BQF-COMPARE-001
              - BQF-COMPARE-002
          media:
            enabled: true
        ```

    Example TOML:
        ```toml
        [bqf]
        mode = "ci"

        [bqf.compare]
        enabled = true
        policies = ["BQF-COMPARE-001", "BQF-COMPARE-002"]

        [bqf.media]
        enabled = true
        ```
    """
    if not config_path.exists():
        raise FileNotFoundError(f"Policy configuration not found: {config_path}")

    suffix = config_path.suffix.lower()

    if suffix in (".yaml", ".yml"):
        try:
            import yaml

            with open(config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except ImportError:
            raise ValueError("PyYAML not installed. Install with: pip install pyyaml")

    elif suffix == ".toml":
        try:
            import tomllib  # Python 3.11+

            with open(config_path, "rb") as f:
                return tomllib.load(f)
        except ImportError:
            # Fallback to tomli for Python <3.11
            try:
                import tomli  # type: ignore[import-not-found]

                with open(config_path, "rb") as f:
                    return tomli.load(f)
            except ImportError:
                raise ValueError(
                    "TOML library not installed. Install with: pip install tomli"
                )

    else:
        raise ValueError(
            f"Unsupported configuration format: {suffix}. Use .yaml, .yml, or .toml"
        )


def apply_policy_config(
    config: Dict[str, Any], registry: Optional[PolicyRegistry] = None
) -> PolicyRegistry:
    """
    Apply configuration to create a filtered policy registry.

    Creates a new PolicyRegistry with only enabled policies from config.
    Preserves existing registry unchanged.

    Args:
        config: Configuration dictionary (from load_policy_config)
        registry: Source policy registry (uses global if not provided)

    Returns:
        New PolicyRegistry with filtered policies

    Example:
        >>> config = load_policy_config(Path("bqf_config.yaml"))
        >>> filtered_registry = apply_policy_config(config)
        >>> enforcer = BQFPolicyEnforcer(registry=filtered_registry)

    Note:
        The existing PolicyRegistry API doesn't have enable/disable methods.
        Instead, we create a new registry with only enabled policies.
        This is a cleaner approach that doesn't mutate shared state.
    """
    from .registry import get_global_registry

    source_registry = registry or get_global_registry()
    filtered_registry = PolicyRegistry()

    bqf_config = config.get("bqf", {})

    if not bqf_config:
        # No filtering - copy all policies
        for policy_class in source_registry.list_all():
            filtered_registry.register(policy_class)
        return filtered_registry

    # Build set of enabled policy IDs
    enabled_ids: set[str] = set()

    # Disable/enable modules
    for module in ("compare", "media", "analyzer", "merge"):
        module_config = bqf_config.get(module, {})
        enabled = module_config.get("enabled", True)

        if not enabled:
            continue  # Skip disabled modules

        # Get policies for this module
        module_policies = source_registry.list_by_module(module)

        # If specific policies listed, use only those
        policy_list = module_config.get("policies")
        if policy_list:
            enabled_ids.update(policy_list)
        else:
            # Enable all policies in this module
            for policy_class in module_policies:
                enabled_ids.add(policy_class.POLICY_ID)

    # Register only enabled policies
    for policy_class in source_registry.list_all():
        if policy_class.POLICY_ID in enabled_ids:
            filtered_registry.register(policy_class)

    return filtered_registry
