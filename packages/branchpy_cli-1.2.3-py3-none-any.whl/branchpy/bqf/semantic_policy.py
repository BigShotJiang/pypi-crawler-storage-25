"""
BQF Semantic Policy Integration (Step 10D)

Applies BQF policies to semantic warnings from CFG engines:
- Severity overrides (warning → error, etc.)
- Rule filtering (disable specific rules)
- Ruleset selection (default, strict, permissive)

This is the final layer of Semantics V2, enabling policy-driven
semantic analysis with governance and explainability.

Architecture:
    Engines → raw warnings → BQF policies → final warnings → output

Integration Point:
    cmd_scan() in semantics_v2_cmd.py
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

try:
    import tomllib  # Python 3.11+ stdlib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class SemanticPolicyConfig:
    """
    Configuration for semantic policy application.

    Attributes:
        ruleset_id: Policy identifier (default, strict, permissive, custom)
        severity_overrides: Map rule_id → new severity
        disabled_rules: Set of rule IDs to filter out
        enabled_rules: Optional whitelist (if set, only these rules pass)
        metadata: Additional policy metadata
    """

    ruleset_id: str = "default"
    severity_overrides: Dict[str, str] = field(default_factory=dict)
    disabled_rules: Set[str] = field(default_factory=set)
    enabled_rules: Optional[Set[str]] = None
    metadata: Dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "SemanticPolicyConfig":
        """Create config from dictionary (JSON/TOML load)."""
        return cls(
            ruleset_id=data.get("ruleset_id", "default"),
            severity_overrides=data.get("severity_overrides", {}),
            disabled_rules=set(data.get("disabled_rules", [])),
            enabled_rules=(
                set(data["enabled_rules"]) if "enabled_rules" in data else None
            ),
            metadata=data.get("metadata", {}),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "ruleset_id": self.ruleset_id,
            "severity_overrides": self.severity_overrides,
            "disabled_rules": list(self.disabled_rules),
            "enabled_rules": list(self.enabled_rules) if self.enabled_rules else None,
            "metadata": self.metadata,
        }


def load_semantic_policy(ruleset_id: Optional[str] = None) -> SemanticPolicyConfig:
    """
    Load semantic policy configuration.

    Args:
        ruleset_id: Policy identifier (default, strict, permissive, or custom path)

    Returns:
        SemanticPolicyConfig loaded from builtin or custom file

    Priority:
        1. If ruleset_id is a file path → load from file
        2. If ruleset_id matches builtin → use builtin config
        3. Otherwise → return default config
    """
    # If no ruleset specified, return default (no overrides)
    if not ruleset_id:
        return SemanticPolicyConfig(ruleset_id="default")

    # Check if ruleset_id is a file path
    if (
        "/" in ruleset_id
        or "\\" in ruleset_id
        or ruleset_id.endswith((".json", ".toml", ".yaml"))
    ):
        policy_path = Path(ruleset_id)
        if policy_path.exists():
            return _load_policy_from_file(policy_path)

    # Try builtin rulesets
    builtin = _get_builtin_policy(ruleset_id)
    if builtin:
        return builtin

    # Fallback to default
    return SemanticPolicyConfig(ruleset_id=ruleset_id or "default")


def _load_policy_from_file(path: Path) -> SemanticPolicyConfig:
    """Load policy from JSON or TOML file."""
    content = path.read_text(encoding="utf-8")

    if path.suffix == ".json":
        data = json.loads(content)
    elif path.suffix in (".toml", ".tml"):
        data = tomllib.loads(content)
    else:
        # Try JSON first, then TOML
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            data = tomllib.loads(content)

    return SemanticPolicyConfig.from_dict(data)


def _get_builtin_policy(ruleset_id: str) -> Optional[SemanticPolicyConfig]:
    """
    Get builtin policy configuration.

    Builtin policies:
        - default: No overrides, all rules enabled
        - strict: Treat warnings as errors
        - permissive: Treat errors as warnings
        - ci: Stricter rules for CI environments
    """
    if ruleset_id == "default":
        return SemanticPolicyConfig(
            ruleset_id="default",
            metadata={"description": "Default ruleset with no overrides"},
        )

    elif ruleset_id == "strict":
        # Treat all warnings and info as errors
        return SemanticPolicyConfig(
            ruleset_id="strict",
            severity_overrides={
                # Flow rules
                "SEM_FLOW_001": "error",  # Unreachable code
                "SEM_FLOW_002": "error",  # Contradictory condition
                "SEM_FLOW_003": "error",  # Unreachable label
                "SEM_FLOW_004": "error",  # Dead-end label
                "SEM_FLOW_005": "error",  # Unresolved dynamic jump
                "SEM_FLOW_006": "error",  # Single-choice menu
                "SEM_FLOW_007": "error",  # Excessive branching
                # Expression rules
                "SEM_EXPR_006": "error",  # Dead branch
                "SEM_EXPR_007": "error",  # Unused variable
                "SEM_EXPR_008": "error",  # Variable shadowing
            },
            metadata={"description": "Strict ruleset - treat warnings as errors"},
        )

    elif ruleset_id == "permissive":
        # Treat errors as warnings
        return SemanticPolicyConfig(
            ruleset_id="permissive",
            severity_overrides={
                "SEM_EXPR_001": "warning",  # Undefined variable
                "SEM_EXPR_002": "warning",  # Type mismatch
                "SEM_EXPR_003": "warning",  # Parse error
                "SEM_EXPR_004": "warning",  # Invalid operator
                "SEM_EXPR_005": "warning",  # Evaluation error
            },
            metadata={"description": "Permissive ruleset - treat errors as warnings"},
        )

    elif ruleset_id == "ci":
        # CI-focused: Disable low-priority rules, promote high-impact warnings
        return SemanticPolicyConfig(
            ruleset_id="ci",
            severity_overrides={
                "SEM_FLOW_001": "error",  # Unreachable code → blocking
                "SEM_EXPR_001": "error",  # Undefined variable → blocking
                "SEM_EXPR_002": "error",  # Type mismatch → blocking
            },
            disabled_rules={
                "SEM_EXPR_007",  # Unused variable (noisy in CI)
                "SEM_EXPR_008",  # Variable shadowing (noisy in CI)
            },
            metadata={
                "description": "CI ruleset - block critical issues, reduce noise"
            },
        )

    return None


def apply_policies_to_warnings(
    warnings: List,  # List[SemanticWarning]
    ruleset_id: Optional[str] = None,
    registry=None,  # Optional[RuleRegistry]
) -> List:
    """
    Apply BQF policies to semantic warnings.

    This is the Step 10D integration point that:
    1. Loads policy configuration (builtin or custom)
    2. Filters disabled rules
    3. Applies severity overrides
    4. Tags warnings with policy metadata for explainability

    Args:
        warnings: List of SemanticWarning objects from engines
        ruleset_id: Policy identifier or file path
        registry: Optional RuleRegistry for metadata lookup

    Returns:
        Filtered and transformed list of warnings

    Integration:
        Called from cmd_scan() between engine execution and output formatting
    """
    # Load policy
    policy = load_semantic_policy(ruleset_id)

    final_warnings = []

    for warning in warnings:
        # 1. Check enabled_rules whitelist (if configured)
        if policy.enabled_rules is not None:
            if warning.rule_id not in policy.enabled_rules:
                continue  # Skip - not in whitelist

        # 2. Check disabled_rules blacklist
        if warning.rule_id in policy.disabled_rules:
            continue  # Skip - explicitly disabled

        # 3. Apply severity override
        if warning.rule_id in policy.severity_overrides:
            # Preserve original for explainability
            if (
                not hasattr(warning, "severity_original")
                or warning.severity_original is None
            ):
                warning.severity_original = warning.severity

            # Apply override
            warning.severity = policy.severity_overrides[warning.rule_id]

        # 4. Tag with policy metadata
        if not hasattr(warning, "policy") or warning.policy is None:
            warning.policy = policy.ruleset_id

        final_warnings.append(warning)

    return final_warnings


def get_builtin_rulesets() -> List[str]:
    """
    Get list of builtin ruleset identifiers.

    Returns:
        List of builtin ruleset IDs (default, strict, permissive, ci)
    """
    return ["default", "strict", "permissive", "ci"]


def describe_ruleset(ruleset_id: str) -> str:
    """
    Get human-readable description of a ruleset.

    Args:
        ruleset_id: Ruleset identifier

    Returns:
        Description string or "Unknown ruleset"
    """
    policy = load_semantic_policy(ruleset_id)
    return policy.metadata.get("description", f"Ruleset: {ruleset_id}")


# Utility functions for policy introspection


def get_severity_override(ruleset_id: str, rule_id: str) -> Optional[str]:
    """
    Get severity override for a specific rule in a ruleset.

    Args:
        ruleset_id: Ruleset identifier
        rule_id: Rule identifier (e.g., SEM_FLOW_001)

    Returns:
        Overridden severity or None if no override
    """
    policy = load_semantic_policy(ruleset_id)
    return policy.severity_overrides.get(rule_id)


def is_rule_disabled(ruleset_id: str, rule_id: str) -> bool:
    """
    Check if a rule is disabled in a ruleset.

    Args:
        ruleset_id: Ruleset identifier
        rule_id: Rule identifier

    Returns:
        True if rule is disabled
    """
    policy = load_semantic_policy(ruleset_id)

    # Check blacklist
    if rule_id in policy.disabled_rules:
        return True

    # Check whitelist (if configured)
    if policy.enabled_rules is not None:
        return rule_id not in policy.enabled_rules

    return False
