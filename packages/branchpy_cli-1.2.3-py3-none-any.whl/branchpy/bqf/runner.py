"""
BQF Policy Runner

Executes policies against validation inputs and produces structured reports.

Features:
- Run all policies for a module (compare, media, etc.)
- Run specific policies by ID
- Aggregate pass/warn/fail counts
- Generate PolicyReport with timing and governance linking
"""

import time
from typing import Any, Dict, List, Optional

from branchpy.bqf.policy_base import PolicyContext, PolicyReport, PolicyResult
from branchpy.bqf.registry import PolicyRegistry, get_global_registry


class PolicyRunner:
    """
    Executes BQF policies and aggregates results.

    Usage:
        runner = PolicyRunner()
        ctx = PolicyContext(
            module="compare",
            inputs={"avg_similarity": 0.95, "sample_count": 100},
            governance_id="AXIS5-V0.9.1.2-20251113-H5"
        )
        report = runner.run_module("compare", ctx)

        if not report.is_success:
            print(f"Failures: {report.fail_count}")
    """

    def __init__(self, registry: Optional[PolicyRegistry] = None):
        """
        Initialize runner with policy registry.

        Args:
            registry: Optional PolicyRegistry; uses global if None
        """
        self.registry = registry or get_global_registry()

    def run_module(
        self, module: str, ctx: PolicyContext, policy_ids: Optional[List[str]] = None
    ) -> PolicyReport:
        """
        Run all policies for a module (or specific policies if provided).

        Args:
            module: Module name ("compare", "media", etc.)
            ctx: PolicyContext with inputs and governance_id
            policy_ids: Optional list of specific policy IDs to run

        Returns:
            PolicyReport with aggregated results
        """
        start = time.perf_counter()

        # Get policies to run
        if policy_ids:
            policies = []
            for pid in policy_ids:
                policy = self.registry.get(pid)
                if policy and policy.MODULE == module:
                    policies.append(policy)
        else:
            policy_classes = self.registry.list_by_module(module)
            policies = [cls() for cls in policy_classes]

        # Execute policies
        results: List[PolicyResult] = []
        for policy in policies:
            result = policy.run(ctx)
            results.append(result)

        total_duration = (time.perf_counter() - start) * 1000

        return PolicyReport(
            module=module,
            results=results,
            governance_id=ctx.governance_id,
            total_duration_ms=total_duration,
        )

    def run_policy(
        self,
        policy_id: str,
        ctx: PolicyContext,
        config: Optional[Dict[str, Any]] = None,
    ) -> PolicyResult:
        """
        Run a single policy by ID.

        Args:
            policy_id: Policy identifier
            ctx: PolicyContext with inputs
            config: Optional config overrides (merged into ctx.config_overrides)

        Returns:
            PolicyResult

        Raises:
            ValueError: If policy not found
        """
        if config:
            ctx.config_overrides.update(config)

        policy = self.registry.get(policy_id)
        if policy is None:
            raise ValueError(f"Policy '{policy_id}' not found in registry")

        return policy.run(ctx)

    def validate_inputs(
        self, module: str, inputs: Dict[str, Any]
    ) -> Dict[str, List[str]]:
        """
        Validate that inputs contain required fields for module policies.

        Args:
            module: Module name
            inputs: Input data dictionary

        Returns:
            Dictionary mapping policy_id -> list of missing required fields
        """
        policy_classes = self.registry.list_by_module(module)
        missing_fields: Dict[str, List[str]] = {}

        for policy_class in policy_classes:
            # Instantiate to access metadata (if policies define required_fields)
            policy = policy_class()
            if hasattr(policy, "REQUIRED_FIELDS"):
                required = policy.REQUIRED_FIELDS
                missing = [field for field in required if field not in inputs]
                if missing:
                    missing_fields[policy.POLICY_ID] = missing

        return missing_fields


# Convenience function for quick policy execution
def run(
    module: str,
    inputs: Dict[str, Any],
    governance_id: Optional[str] = None,
    config_overrides: Optional[Dict[str, Any]] = None,
    policy_ids: Optional[List[str]] = None,
) -> PolicyReport:
    """
    Quick policy execution using global registry.

    Args:
        module: Module name ("compare", "media")
        inputs: Input data for policies
        governance_id: Optional governance trace ID
        config_overrides: Optional config overrides
        policy_ids: Optional list of specific policy IDs to run

    Returns:
        PolicyReport with results

    Example:
        report = run(
            "compare",
            {"avg_similarity": 0.89, "sample_count": 50},
            governance_id="AXIS5-V0.9.1.2-20251113-H5"
        )
        print(f"Pass: {report.pass_count}, Fail: {report.fail_count}")
    """
    ctx = PolicyContext(
        module=module,
        inputs=inputs,
        governance_id=governance_id,
        config_overrides=config_overrides or {},
    )

    runner = PolicyRunner()
    return runner.run_module(module, ctx, policy_ids=policy_ids)
