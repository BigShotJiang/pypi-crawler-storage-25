"""
BQF Policy Registry

Central registry for BQF policies with dynamic loading and validation.

Features:
- Register policies programmatically or load from module directories
- Retrieve policies by ID or module
- Validate policy implementation (POLICY_ID, MODULE, methods)
- Thread-safe registry with get/list operations
"""

import importlib.util
import inspect
import threading
from pathlib import Path
from typing import Dict, List, Optional, Type

from branchpy.bqf.policy_base import Policy, PolicyConfig


class PolicyRegistry:
    """
    Thread-safe registry for BQF policies.

    Usage:
        registry = PolicyRegistry()
        registry.register(SimilarityFloorPolicy)
        registry.load_from_dir(Path("branchpy/bqf/policies"))

        policy = registry.get("compare.similarity_floor")
        policies = registry.list_by_module("compare")
    """

    def __init__(self):
        self._policies: Dict[str, Type[Policy]] = {}
        self._lock = threading.RLock()

    def register(self, policy_class: Type[Policy]) -> None:
        """
        Register a policy class.

        Args:
            policy_class: Policy subclass to register

        Raises:
            ValueError: If policy_class is invalid or duplicate ID
        """
        # Validate policy class
        if not inspect.isclass(policy_class) or not issubclass(policy_class, Policy):
            raise ValueError(f"{policy_class} is not a Policy subclass")

        if not hasattr(policy_class, "POLICY_ID") or not policy_class.POLICY_ID:
            raise ValueError(
                f"Policy class {policy_class.__name__} must define POLICY_ID"
            )

        if not hasattr(policy_class, "MODULE") or not policy_class.MODULE:
            raise ValueError(f"Policy class {policy_class.__name__} must define MODULE")

        # Check required methods
        if not hasattr(policy_class, "evaluate"):
            raise ValueError(
                f"Policy class {policy_class.__name__} must implement evaluate()"
            )

        if not hasattr(policy_class, "get_default_config"):
            raise ValueError(
                f"Policy class {policy_class.__name__} must implement get_default_config()"
            )

        policy_id = policy_class.POLICY_ID

        with self._lock:
            if policy_id in self._policies:
                existing = self._policies[policy_id]
                if existing is not policy_class:
                    raise ValueError(
                        f"Policy ID '{policy_id}' already registered by {existing.__name__}"
                    )
            self._policies[policy_id] = policy_class

    def get(
        self, policy_id: str, config: Optional[PolicyConfig] = None
    ) -> Optional[Policy]:
        """
        Retrieve and instantiate a policy by ID.

        Args:
            policy_id: Policy identifier (e.g., "compare.similarity_floor")
            config: Optional custom configuration; uses defaults if None

        Returns:
            Policy instance or None if not found
        """
        with self._lock:
            policy_class = self._policies.get(policy_id)
            if policy_class is None:
                return None
            return policy_class(config=config)

    def list_by_module(self, module: str) -> List[Type[Policy]]:
        """
        List all policy classes for a given module.

        Args:
            module: Module name ("compare", "media", etc.)

        Returns:
            List of Policy subclasses
        """
        with self._lock:
            return [cls for cls in self._policies.values() if cls.MODULE == module]

    def list_all(self) -> List[Type[Policy]]:
        """
        List all registered policy classes.

        Returns:
            List of all Policy subclasses
        """
        with self._lock:
            return list(self._policies.values())

    def load_from_dir(self, directory: Path) -> int:
        """
        Load all policies from a directory tree.

        Searches for Python files containing Policy subclasses and registers them.

        Args:
            directory: Root directory to scan (e.g., branchpy/bqf/policies)

        Returns:
            Number of policies loaded

        Raises:
            FileNotFoundError: If directory does not exist
        """
        if not directory.exists():
            raise FileNotFoundError(f"Policy directory not found: {directory}")

        loaded_count = 0

        # Recursively find all .py files
        for py_file in directory.rglob("*.py"):
            if py_file.name.startswith("_"):
                continue  # Skip __init__.py and private modules

            # Dynamically import module
            spec = importlib.util.spec_from_file_location(
                f"bqf.policies.{py_file.stem}", py_file
            )
            if spec is None or spec.loader is None:
                continue

            module = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(module)
            except Exception:
                # Skip modules that fail to load (missing dependencies, etc.)
                continue

            # Find Policy subclasses in module
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if (
                    issubclass(obj, Policy)
                    and obj is not Policy
                    and hasattr(obj, "POLICY_ID")
                    and obj.POLICY_ID  # Non-empty
                ):
                    try:
                        self.register(obj)
                        loaded_count += 1
                    except ValueError:
                        # Skip invalid policies
                        continue

        return loaded_count

    def clear(self) -> None:
        """Clear all registered policies (primarily for testing)."""
        with self._lock:
            self._policies.clear()


# Global singleton registry
_global_registry = PolicyRegistry()


def get_global_registry() -> PolicyRegistry:
    """
    Get the global PolicyRegistry singleton.

    Returns:
        Global PolicyRegistry instance
    """
    return _global_registry


def register_policy(policy_class: Type[Policy]) -> None:
    """
    Register a policy class in the global registry.

    Args:
        policy_class: Policy subclass to register
    """
    _global_registry.register(policy_class)


def get_policy(
    policy_id: str, config: Optional[PolicyConfig] = None
) -> Optional[Policy]:
    """
    Retrieve a policy from the global registry.

    Args:
        policy_id: Policy identifier
        config: Optional custom configuration

    Returns:
        Policy instance or None if not found
    """
    return _global_registry.get(policy_id, config)


def list_policies_by_module(module: str) -> List[Type[Policy]]:
    """
    List all policies for a module from the global registry.

    Args:
        module: Module name

    Returns:
        List of Policy subclasses
    """
    return _global_registry.list_by_module(module)
