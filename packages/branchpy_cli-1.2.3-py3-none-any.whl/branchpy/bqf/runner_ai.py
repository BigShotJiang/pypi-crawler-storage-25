"""BQF Wave 5: AI Usage Runner."""

import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict

from branchpy.bqf.models_ai import BQFAISummary
from branchpy.bqf.policies_ai import get_ai_policies
from branchpy.bqf.policy_base import PolicyContext, PolicyStatus
from branchpy.core.governance.logger import GovernanceLogger


def _parse_ai_events(log_path: Path, days: int = 1) -> Dict[str, Any]:
    """
    Parse governance log for AI events and aggregate statistics.

    Args:
        log_path: Path to governance.jsonl
        days: Number of days to look back

    Returns:
        Dict with aggregated AI statistics
    """
    if not log_path.exists():
        return {
            "total_calls": 0,
            "total_tokens": 0,
            "total_cost": 0.0,
            "error_count": 0,
            "provider_breakdown": {},
        }

    cutoff = datetime.now() - timedelta(days=days)
    stats = {
        "total_calls": 0,
        "total_tokens": 0,
        "total_cost": 0.0,
        "error_count": 0,
        "provider_breakdown": {},
    }

    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                event = json.loads(line)
                event_type = event.get("event_type", "")

                # Parse timestamp
                ts_str = event.get("timestamp", "")
                if ts_str:
                    try:
                        ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                        if ts < cutoff:
                            continue
                    except (ValueError, AttributeError):
                        pass

                # Track AI_CALL_END events for successful calls
                if event_type == "ai.call_end":
                    context = event.get("context", {})
                    provider = context.get("provider", "unknown")

                    # Initialize provider stats
                    if provider not in stats["provider_breakdown"]:
                        stats["provider_breakdown"][provider] = {
                            "calls": 0,
                            "tokens": 0,
                            "cost": 0.0,
                            "errors": 0,
                        }

                    stats["total_calls"] += 1
                    stats["provider_breakdown"][provider]["calls"] += 1

                    # Track tokens
                    total_tokens = 0
                    token_usage = context.get("token_usage", {})
                    if isinstance(token_usage, dict):
                        total_tokens = token_usage.get("total_tokens", 0)
                        stats["total_tokens"] += total_tokens
                        stats["provider_breakdown"][provider]["tokens"] += total_tokens

                    # Estimate cost (rough estimates: GPT-4: $0.03/1k, Claude: $0.015/1k)
                    # In real implementation, use actual pricing from provider configs
                    if "gpt-4" in provider.lower():
                        cost = total_tokens * 0.00003  # $0.03 per 1k tokens
                    elif "claude" in provider.lower():
                        cost = total_tokens * 0.000015  # $0.015 per 1k tokens
                    else:
                        cost = total_tokens * 0.00001  # Generic estimate

                    stats["total_cost"] += cost
                    stats["provider_breakdown"][provider]["cost"] += cost

                # Track AI_CALL_ERROR events
                elif event_type == "ai.call_error":
                    context = event.get("context", {})
                    provider = context.get("provider", "unknown")

                    stats["error_count"] += 1

                    if provider not in stats["provider_breakdown"]:
                        stats["provider_breakdown"][provider] = {
                            "calls": 0,
                            "tokens": 0,
                            "cost": 0.0,
                            "errors": 0,
                        }
                    stats["provider_breakdown"][provider]["errors"] += 1

            except (json.JSONDecodeError, KeyError):
                continue

    return stats


def run_bqf_ai(governance_logger: GovernanceLogger, days: int = 1) -> BQFAISummary:
    """
    Run BQF AI usage policies against governance log.

    Args:
        governance_logger: GovernanceLogger instance
        days: Number of days to analyze (default: 1)

    Returns:
        BQFAISummary with policy results and aggregated metrics
    """
    start_time = time.perf_counter()

    # Parse governance log for AI events
    log_path = Path(governance_logger.log_path)
    ai_stats = _parse_ai_events(log_path, days=days)

    # Create policy context
    ctx = PolicyContext(
        module="ai",
        inputs=ai_stats,
    )

    # Run policies
    policies = get_ai_policies()
    results = []

    for policy in policies:
        result = policy.run(ctx)
        results.append(result)

    # Aggregate results
    duration_ms = (time.perf_counter() - start_time) * 1000
    passed = sum(1 for r in results if r.status == PolicyStatus.PASS)
    warned = sum(1 for r in results if r.status == PolicyStatus.WARN)
    failed = sum(1 for r in results if r.status == PolicyStatus.FAIL)

    return BQFAISummary(
        policies_run=len(results),
        policies_passed=passed,
        policies_warned=warned,
        policies_failed=failed,
        duration_ms=duration_ms,
        total_calls=ai_stats["total_calls"],
        total_tokens=ai_stats["total_tokens"],
        total_cost=ai_stats["total_cost"],
        error_count=ai_stats["error_count"],
        provider_breakdown=ai_stats["provider_breakdown"],
    )
