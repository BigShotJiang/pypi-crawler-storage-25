"""
BQF Policy Base Classes

Defines the core abstractions for BranchPy Quality Framework (BQF) policies:
- Policy: Abstract base for evaluation logic
- PolicyResult: Structured pass/warn/fail outcome
- PolicyContext: Input data container for policy evaluation
- PolicyConfig: Configuration/thresholds for policies

Used by Compare and Media validation modules to enforce quality gates.
"""

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class PolicyStatus(str, Enum):
    """Policy evaluation outcome."""

    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"  # Policy not applicable to inputs


@dataclass
class PolicyResult:
    """
    Outcome of a single policy evaluation.

    Attributes:
        policy_id: Unique identifier (e.g., "compare.similarity_floor")
        status: Pass/warn/fail/skip
        message: Human-readable explanation
        metadata: Additional context (thresholds, actual values, counts)
        duration_ms: Evaluation time in milliseconds
    """

    policy_id: str
    status: PolicyStatus
    message: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dictionary."""
        return {
            "policy_id": self.policy_id,
            "status": self.status.value,
            "message": self.message,
            "metadata": self.metadata,
            "duration_ms": round(self.duration_ms, 3),
        }


@dataclass
class PolicyContext:
    """
    Input data for policy evaluation.

    Attributes:
        module: Module name ("compare", "media", "analyze", etc.)
        inputs: Policy-specific input data (metrics, counts, flags)
        governance_id: Optional governance trace identifier
        config_overrides: Runtime configuration overrides
        engine_type: Optional engine type (renpy, unity, godot, generic) - WS-C1
        remote_context: Optional remote environment context - WS-C1
    """

    module: str
    inputs: Dict[str, Any]
    governance_id: Optional[str] = None
    config_overrides: Dict[str, Any] = field(default_factory=dict)
    engine_type: Optional[str] = None  # WS-C1: "renpy" | "unity" | "godot" | "generic"
    remote_context: Optional[Any] = None  # WS-C1: RemoteContext instance

    def get(self, key: str, default: Any = None) -> Any:
        """Safely retrieve input value with default fallback."""
        return self.inputs.get(key, default)

    def require(self, key: str) -> Any:
        """
        Retrieve required input value.

        Raises:
            ValueError: If key is missing from inputs
        """
        if key not in self.inputs:
            raise ValueError(
                f"Required input '{key}' missing from PolicyContext for module '{self.module}'"
            )
        return self.inputs[key]

    @property
    def is_remote(self) -> bool:
        """Check if running in remote environment (WS-C1)."""
        if self.remote_context is None:
            return False
        return getattr(self.remote_context, "is_remote", False)

    @property
    def is_ci(self) -> bool:
        """Check if running in CI environment (WS-C1)."""
        if self.remote_context is None:
            return False
        return getattr(self.remote_context, "is_ci", False)


@dataclass
class PolicyConfig:
    """
    Configuration for a policy (thresholds, limits, feature flags).

    Attributes:
        policy_id: Unique policy identifier
        enabled: Whether policy is active
        thresholds: Numeric thresholds (e.g., min_similarity: 0.92)
        limits: Count-based limits (e.g., max_duplicates: 10)
        metadata: Additional config fields
    """

    policy_id: str
    enabled: bool = True
    thresholds: Dict[str, float] = field(default_factory=dict)
    limits: Dict[str, int] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_threshold(self, key: str, default: float) -> float:
        """Retrieve threshold with fallback to default."""
        return self.thresholds.get(key, default)

    def get_limit(self, key: str, default: int) -> int:
        """Retrieve limit with fallback to default."""
        return self.limits.get(key, default)


class Policy(ABC):
    """
    Abstract base class for BQF policies.

    Subclasses must implement:
    - evaluate(ctx): Core evaluation logic
    - get_default_config(): Default configuration

    Example:
        class SimilarityFloorPolicy(Policy):
            POLICY_ID = "compare.similarity_floor"

            def evaluate(self, ctx: PolicyContext) -> PolicyResult:
                min_score = self.config.get_threshold("min_score", 0.92)
                actual = ctx.require("avg_similarity")
                if actual >= min_score:
                    return PolicyResult(self.POLICY_ID, PolicyStatus.PASS, ...)
                return PolicyResult(self.POLICY_ID, PolicyStatus.FAIL, ...)
    """

    POLICY_ID: str = ""  # Override in subclasses
    MODULE: str = ""  # "compare", "media", etc.

    def __init__(self, config: Optional[PolicyConfig] = None):
        """
        Initialize policy with configuration.

        Args:
            config: Optional custom config; uses defaults if None
        """
        if not self.POLICY_ID:
            raise ValueError(
                f"Policy subclass {self.__class__.__name__} must define POLICY_ID"
            )
        if not self.MODULE:
            raise ValueError(
                f"Policy subclass {self.__class__.__name__} must define MODULE"
            )

        self.config = config or self.get_default_config()

    @abstractmethod
    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """
        Evaluate policy against context inputs.

        Args:
            ctx: PolicyContext with module, inputs, governance_id

        Returns:
            PolicyResult with status (pass/warn/fail/skip) and metadata
        """
        pass

    @abstractmethod
    def get_default_config(self) -> PolicyConfig:
        """
        Return default configuration for this policy.

        Returns:
            PolicyConfig with default thresholds/limits
        """
        pass

    def run(self, ctx: PolicyContext) -> PolicyResult:
        """
        Execute policy evaluation with timing.

        Args:
            ctx: PolicyContext

        Returns:
            PolicyResult with duration_ms populated
        """
        if not self.config.enabled:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.SKIP,
                message=f"Policy '{self.POLICY_ID}' is disabled",
                duration_ms=0.0,
            )

        # Apply config overrides from context
        if ctx.config_overrides:
            for key, value in ctx.config_overrides.items():
                if isinstance(value, float) and key in self.config.thresholds:
                    self.config.thresholds[key] = value
                elif isinstance(value, int) and key in self.config.limits:
                    self.config.limits[key] = value

        start = time.perf_counter()
        try:
            result = self.evaluate(ctx)
            result.duration_ms = (time.perf_counter() - start) * 1000
            return result
        except Exception as e:
            duration = (time.perf_counter() - start) * 1000
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"Policy evaluation error: {str(e)}",
                metadata={"error": str(e), "error_type": type(e).__name__},
                duration_ms=duration,
            )


@dataclass
class PolicyReport:
    """
    Aggregated results from running multiple policies.

    Attributes:
        module: Module name ("compare", "media")
        results: List of PolicyResult instances
        governance_id: Optional governance trace identifier
        total_duration_ms: Total evaluation time
    """

    module: str
    results: List[PolicyResult]
    governance_id: Optional[str] = None
    total_duration_ms: float = 0.0

    @property
    def pass_count(self) -> int:
        """Number of passed policies."""
        return sum(1 for r in self.results if r.status == PolicyStatus.PASS)

    @property
    def warn_count(self) -> int:
        """Number of warned policies."""
        return sum(1 for r in self.results if r.status == PolicyStatus.WARN)

    @property
    def fail_count(self) -> int:
        """Number of failed policies."""
        return sum(1 for r in self.results if r.status == PolicyStatus.FAIL)

    @property
    def skip_count(self) -> int:
        """Number of skipped policies."""
        return sum(1 for r in self.results if r.status == PolicyStatus.SKIP)

    @property
    def is_success(self) -> bool:
        """True if no failures (warns are acceptable)."""
        return self.fail_count == 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dictionary."""
        return {
            "module": self.module,
            "governance_id": self.governance_id,
            "total_duration_ms": round(self.total_duration_ms, 3),
            "summary": {
                "pass": self.pass_count,
                "warn": self.warn_count,
                "fail": self.fail_count,
                "skip": self.skip_count,
                "is_success": self.is_success,
            },
            "results": [r.to_dict() for r in self.results],
        }
