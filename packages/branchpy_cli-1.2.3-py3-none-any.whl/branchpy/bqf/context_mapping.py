"""
BQF Policy Context Mapping Utilities

Maps analyzer outputs (Compare, Media/Image Validation V3) to BQF policy inputs.
Provides typed summary dataclasses for each validation module.

Governance ID: AXIS5-V0.9.1.2-20251113-H5-G7
Checkpoint: H5 Day 2 — Policy-Aware Validation Integration
"""

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class CompareRunSummary:
    """
    Summary of Compare analyzer run outputs.

    Maps to BQF compare policy inputs (e.g., similarity_floor).

    Attributes:
        avg_similarity: Average similarity score across all comparisons (0.0-1.0)
        sample_count: Number of comparison samples analyzed
        min_similarity: Minimum similarity observed (optional)
        max_similarity: Maximum similarity observed (optional)
    """

    avg_similarity: float
    sample_count: int
    min_similarity: float = 0.0
    max_similarity: float = 1.0


@dataclass
class MediaRunSummary:
    """
    Summary of Media/Image Validation V3 run outputs.

    Maps to BQF media policy inputs (e.g., duplicate_cap, checksum_verified).

    Attributes:
        duplicate_count: Number of duplicate images detected
        total_count: Total number of images processed
        checksum_verified_pct: Percentage of images with verified checksums (0-100)
        cluster_count: Number of image clusters detected (optional)
    """

    duplicate_count: int
    total_count: int
    checksum_verified_pct: float
    cluster_count: int = 0


def to_bqf_inputs_for_compare(run_summary: CompareRunSummary) -> Dict[str, Any]:
    """
    Convert Compare analyzer summary to BQF policy inputs.

    Maps CompareRunSummary fields to policy input dictionary compatible
    with compare.similarity_floor and other compare policies.

    Args:
        run_summary: Compare analyzer run summary

    Returns:
        Dictionary with policy input fields:
            - avg_similarity: float (0.0-1.0)
            - sample_count: int
            - min_similarity: float (optional)
            - max_similarity: float (optional)

    Example:
        >>> summary = CompareRunSummary(avg_similarity=0.94, sample_count=25)
        >>> inputs = to_bqf_inputs_for_compare(summary)
        >>> assert inputs["avg_similarity"] == 0.94
    """
    return {
        "avg_similarity": run_summary.avg_similarity,
        "sample_count": run_summary.sample_count,
        "min_similarity": run_summary.min_similarity,
        "max_similarity": run_summary.max_similarity,
    }


def to_bqf_inputs_for_media(run_summary: MediaRunSummary) -> Dict[str, Any]:
    """
    Convert Media/Image Validation V3 summary to BQF policy inputs.

    Maps MediaRunSummary fields to policy input dictionary compatible
    with media.duplicate_cap, media.checksum_verified, and other media policies.

    Calculates derived metrics:
        - duplicate_pct: Percentage of duplicates relative to total (0-100)

    Args:
        run_summary: Media/Image Validation V3 run summary

    Returns:
        Dictionary with policy input fields:
            - duplicate_count: int
            - duplicate_pct: float (0-100)
            - total_count: int
            - checksum_verified_pct: float (0-100)
            - cluster_count: int (optional)

    Example:
        >>> summary = MediaRunSummary(
        ...     duplicate_count=3,
        ...     total_count=100,
        ...     checksum_verified_pct=98.5,
        ...     cluster_count=12
        ... )
        >>> inputs = to_bqf_inputs_for_media(summary)
        >>> assert inputs["duplicate_pct"] == 3.0
        >>> assert inputs["checksum_verified_pct"] == 98.5
    """
    # Calculate duplicate percentage (avoid division by zero)
    duplicate_pct = (
        run_summary.duplicate_count / max(1, run_summary.total_count)
    ) * 100.0

    return {
        "duplicate_count": run_summary.duplicate_count,
        "duplicate_pct": duplicate_pct,
        "total_count": run_summary.total_count,
        "checksum_verified_pct": run_summary.checksum_verified_pct,
        "cluster_count": run_summary.cluster_count,
    }
