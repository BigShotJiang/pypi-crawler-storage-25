"""
BQF Media Policies - Phase C Integration (v0.9.7)

Policy rules for media intelligence validation using Phase C adapters.
Enforces quality gates for missing assets, unused files, and media coverage.

Governance:
    - Module: branchpy.bqf.policies.media
    - Policy IDs: media.missing_assets, media.unused_assets, media.coverage
    - Contract: phaseC-v1

BQS Compliance:
    - Code Standards: Type-safe, documented
    - Performance: O(n) where n = number of media tags
    - Security: Read-only analysis
    - Cross-Platform: Uses pathlib
    - Engine Agnostic: Uses Phase C contract
    - Dependencies: stdlib only
"""

from __future__ import annotations

import time

from branchpy.bqf.policy_base import PolicyContext, PolicyResult, PolicyStatus


class MissingMediaAssetsPolicy:
    """
    Policy: Ensure no missing media assets in project.

    Checks that all media tags referenced in scripts have backing files.
    Uses Phase C exists flag and resolved_files for validation.

    Policy ID: media.missing_assets
    Module: media

    Inputs:
        - phase_c_result: MediaPhaseCResult from adapter
        OR
        - total_tags: int (total media tags)
        - missing_count: int (tags with exists=False)
        - missing_tags: list[str] (tag names of missing assets)

    Thresholds:
        - max_missing: int (default: 0) - Maximum allowed missing assets
        - warn_threshold: int (default: 1) - Warn if missing > this value

    Status Rules:
        - PASS: missing_count <= max_missing
        - WARN: missing_count <= warn_threshold
        - FAIL: missing_count > warn_threshold
    """

    policy_id = "media.missing_assets"

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """Evaluate missing media assets policy."""
        t0 = time.perf_counter()

        # Extract thresholds from config
        max_missing = ctx.config_overrides.get("max_missing", 0)
        warn_threshold = ctx.config_overrides.get("warn_threshold", 1)

        # Try to get Phase C result first
        phase_c_result = ctx.get("phase_c_result")

        if phase_c_result:
            # Extract from Phase C result
            total_tags = len(phase_c_result.files)
            missing_tags = [tag for tag in phase_c_result.files if tag.exists is False]
            missing_count = len(missing_tags)
            missing_names = [tag.tag for tag in missing_tags]
        else:
            # Fallback to explicit inputs
            total_tags = ctx.require("total_tags")
            missing_count = ctx.require("missing_count")
            missing_names = ctx.get("missing_tags", [])

        # Determine status
        if missing_count <= max_missing:
            status = PolicyStatus.PASS
            message = f"All {total_tags} media tag(s) have backing files"
        elif missing_count <= warn_threshold:
            status = PolicyStatus.WARN
            message = (
                f"{missing_count} missing asset(s) found (threshold: {warn_threshold})"
            )
        else:
            status = PolicyStatus.FAIL
            message = (
                f"{missing_count} missing asset(s) exceed threshold ({warn_threshold})"
            )

        duration_ms = (time.perf_counter() - t0) * 1000

        return PolicyResult(
            policy_id=self.policy_id,
            status=status,
            message=message,
            metadata={
                "total_tags": total_tags,
                "missing_count": missing_count,
                "missing_tags": missing_names[:10],  # Limit to first 10
                "max_missing": max_missing,
                "warn_threshold": warn_threshold,
            },
            duration_ms=duration_ms,
        )


class UnusedMediaAssetsPolicy:
    """
    Policy: Flag unused media assets on disk.

    Identifies files that exist on disk but are never referenced in scripts.
    Helps clean up orphaned assets and reduce project size.

    Policy ID: media.unused_assets
    Module: media

    Inputs:
        - phase_c_result: MediaPhaseCResult from adapter
        - disk_files: list[str] (files on disk)
        OR
        - total_files: int (total files on disk)
        - unused_count: int (files not referenced)
        - unused_files: list[str] (paths of unused files)

    Thresholds:
        - max_unused_percent: float (default: 20.0) - Max % of unused assets
        - warn_threshold: int (default: 10) - Warn if unused > this count

    Status Rules:
        - PASS: unused_count <= warn_threshold AND unused_pct <= max_unused_percent
        - WARN: unused_count > warn_threshold OR unused_pct > max_unused_percent
        - FAIL: Never fails (unused assets are warnings, not errors)
    """

    policy_id = "media.unused_assets"

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """Evaluate unused media assets policy."""
        t0 = time.perf_counter()

        # Extract thresholds from config
        max_unused_percent = ctx.config_overrides.get("max_unused_percent", 20.0)
        warn_threshold = ctx.config_overrides.get("warn_threshold", 10)

        # Try to get Phase C result first
        phase_c_result = ctx.get("phase_c_result")
        disk_files = ctx.get("disk_files", [])

        if phase_c_result and disk_files:
            # Extract resolved files from Phase C
            resolved_paths = set()
            for tag in phase_c_result.files:
                if tag.resolved_files:
                    resolved_paths.update(tag.resolved_files)

            # Find unused files
            unused_files = [f for f in disk_files if f not in resolved_paths]
            total_files = len(disk_files)
            unused_count = len(unused_files)
        else:
            # Fallback to explicit inputs
            total_files = ctx.require("total_files")
            unused_count = ctx.require("unused_count")
            unused_files = ctx.get("unused_files", [])

        # Calculate percentage
        unused_pct = (unused_count / total_files * 100) if total_files > 0 else 0.0

        # Determine status
        if unused_count == 0:
            status = PolicyStatus.PASS
            message = f"All {total_files} file(s) are referenced in scripts"
        elif unused_count <= warn_threshold and unused_pct <= max_unused_percent:
            status = PolicyStatus.PASS
            message = (
                f"{unused_count} unused file(s) ({unused_pct:.1f}%) within threshold"
            )
        else:
            status = PolicyStatus.WARN
            message = (
                f"{unused_count} unused file(s) ({unused_pct:.1f}%) exceed threshold"
            )

        duration_ms = (time.perf_counter() - t0) * 1000

        return PolicyResult(
            policy_id=self.policy_id,
            status=status,
            message=message,
            metadata={
                "total_files": total_files,
                "unused_count": unused_count,
                "unused_pct": round(unused_pct, 1),
                "unused_files": unused_files[:10],  # Limit to first 10
                "max_unused_percent": max_unused_percent,
                "warn_threshold": warn_threshold,
            },
            duration_ms=duration_ms,
        )


class MediaCoveragePolicy:
    """
    Policy: Ensure high media asset coverage (% of tags resolved).

    Checks that most media tags have resolved_files populated.
    High coverage indicates good tag-to-file mapping.

    Policy ID: media.coverage
    Module: media

    Inputs:
        - phase_c_result: MediaPhaseCResult from adapter
        OR
        - total_tags: int (total media tags)
        - resolved_count: int (tags with resolved_files)

    Thresholds:
        - min_coverage_percent: float (default: 90.0) - Minimum required coverage
        - warn_threshold: float (default: 80.0) - Warn if coverage < this

    Status Rules:
        - PASS: coverage >= min_coverage_percent
        - WARN: coverage >= warn_threshold
        - FAIL: coverage < warn_threshold
    """

    policy_id = "media.coverage"

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """Evaluate media coverage policy."""
        t0 = time.perf_counter()

        # Extract thresholds from config
        min_coverage_percent = ctx.config_overrides.get("min_coverage_percent", 90.0)
        warn_threshold = ctx.config_overrides.get("warn_threshold", 80.0)

        # Try to get Phase C result first
        phase_c_result = ctx.get("phase_c_result")

        if phase_c_result:
            # Extract from Phase C result
            total_tags = len(phase_c_result.files)
            resolved_count = sum(
                1 for tag in phase_c_result.files if tag.resolved_files and tag.exists
            )
        else:
            # Fallback to explicit inputs
            total_tags = ctx.require("total_tags")
            resolved_count = ctx.require("resolved_count")

        # Calculate coverage
        coverage_pct = (resolved_count / total_tags * 100) if total_tags > 0 else 100.0

        # Determine status
        if coverage_pct >= min_coverage_percent:
            status = PolicyStatus.PASS
            message = f"{coverage_pct:.1f}% coverage (excellent)"
        elif coverage_pct >= warn_threshold:
            status = PolicyStatus.WARN
            message = f"{coverage_pct:.1f}% coverage (acceptable)"
        else:
            status = PolicyStatus.FAIL
            message = f"{coverage_pct:.1f}% coverage (below threshold)"

        duration_ms = (time.perf_counter() - t0) * 1000

        return PolicyResult(
            policy_id=self.policy_id,
            status=status,
            message=message,
            metadata={
                "total_tags": total_tags,
                "resolved_count": resolved_count,
                "coverage_pct": round(coverage_pct, 1),
                "min_coverage_percent": min_coverage_percent,
                "warn_threshold": warn_threshold,
            },
            duration_ms=duration_ms,
        )


# Policy registry for auto-discovery
MEDIA_POLICIES = {
    "media.missing_assets": MissingMediaAssetsPolicy(),
    "media.unused_assets": UnusedMediaAssetsPolicy(),
    "media.coverage": MediaCoveragePolicy(),
}


def get_media_policy(policy_id: str):
    """Get media policy by ID."""
    return MEDIA_POLICIES.get(policy_id)


def evaluate_all_media_policies(ctx: PolicyContext) -> list[PolicyResult]:
    """Evaluate all media policies against given context."""
    results = []

    for policy_id, policy in MEDIA_POLICIES.items():
        try:
            result = policy.evaluate(ctx)
            results.append(result)
        except Exception as e:
            # Add skip result if policy evaluation fails
            results.append(
                PolicyResult(
                    policy_id=policy_id,
                    status=PolicyStatus.SKIP,
                    message=f"Policy evaluation failed: {e}",
                    metadata={"error": str(e)},
                )
            )

    return results
