"""
Compare Module - Similarity Floor Policy

Validates that average similarity scores meet minimum thresholds,
ensuring Compare analyzer produces statistically meaningful diffs.

Thresholds:
- min_score: Minimum average similarity (default: 0.92)
- min_sample_count: Minimum number of comparisons (default: 10)

Status Logic:
- PASS: avg_similarity >= min_score AND sample_count >= min_sample_count
- WARN: sample_count < min_sample_count (insufficient data)
- FAIL: avg_similarity < min_score
"""

from branchpy.bqf.policy_base import (
    Policy,
    PolicyConfig,
    PolicyContext,
    PolicyResult,
    PolicyStatus,
)


class SimilarityFloorPolicy(Policy):
    """
    Enforces minimum similarity threshold for Compare analyzer.

    Ensures that detected similarities are statistically meaningful
    and not random noise. Low scores indicate potential false positives
    or overly aggressive diff heuristics.

    Required Inputs:
        avg_similarity: float (0.0-1.0) — Mean similarity across comparisons
        sample_count: int — Number of comparisons in batch

    Optional Inputs:
        max_similarity: float — Helps detect overfitting (all 1.0)

    Example:
        ctx = PolicyContext(
            module="compare",
            inputs={"avg_similarity": 0.95, "sample_count": 50}
        )
        policy = SimilarityFloorPolicy()
        result = policy.run(ctx)
    """

    POLICY_ID = "compare.similarity_floor"
    MODULE = "compare"
    REQUIRED_FIELDS = ["avg_similarity", "sample_count"]

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """
        Evaluate similarity floor policy.

        Args:
            ctx: PolicyContext with avg_similarity and sample_count

        Returns:
            PolicyResult with pass/warn/fail status
        """
        # Extract inputs
        try:
            avg_similarity = ctx.require("avg_similarity")
            sample_count = ctx.require("sample_count")
        except ValueError as e:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=str(e),
                metadata={"error": "missing_required_field"},
            )

        # Get thresholds
        min_score = self.config.get_threshold("min_score", 0.92)
        min_sample = self.config.get_limit("min_sample_count", 10)

        # Validate types and ranges
        if not isinstance(avg_similarity, (int, float)):
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"avg_similarity must be numeric, got {type(avg_similarity).__name__}",
                metadata={"error": "invalid_type"},
            )

        if not (0.0 <= avg_similarity <= 1.0):
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"avg_similarity must be in [0.0, 1.0], got {avg_similarity}",
                metadata={"error": "out_of_range", "value": avg_similarity},
            )

        # Check sample size first (warn if insufficient)
        if sample_count < min_sample:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.WARN,
                message=f"Insufficient samples: {sample_count} < {min_sample} (threshold: {min_score})",
                metadata={
                    "sample_count": sample_count,
                    "min_sample_count": min_sample,
                    "avg_similarity": avg_similarity,
                    "min_score": min_score,
                    "reason": "insufficient_samples",
                },
            )

        # Check similarity threshold
        if avg_similarity < min_score:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"Similarity below threshold: {avg_similarity:.3f} < {min_score}",
                metadata={
                    "avg_similarity": avg_similarity,
                    "min_score": min_score,
                    "sample_count": sample_count,
                    "delta": round(min_score - avg_similarity, 3),
                },
            )

        # PASS: Good similarity with sufficient samples
        max_similarity = ctx.get("max_similarity", 1.0)
        metadata = {
            "avg_similarity": avg_similarity,
            "min_score": min_score,
            "sample_count": sample_count,
            "margin": round(avg_similarity - min_score, 3),
        }

        # Optional: detect suspicious uniformity (all scores identical)
        if max_similarity == avg_similarity and sample_count > 1:
            metadata["warning"] = "uniform_scores"

        return PolicyResult(
            policy_id=self.POLICY_ID,
            status=PolicyStatus.PASS,
            message=f"Similarity {avg_similarity:.3f} meets threshold {min_score} (n={sample_count})",
            metadata=metadata,
        )

    def get_default_config(self) -> PolicyConfig:
        """
        Return default configuration.

        Returns:
            PolicyConfig with default thresholds
        """
        return PolicyConfig(
            policy_id=self.POLICY_ID,
            enabled=True,
            thresholds={"min_score": 0.92},
            limits={"min_sample_count": 10},
            metadata={
                "description": "Enforce minimum similarity threshold for Compare analyzer",
                "version": "1.0.0",
            },
        )
