"""
Media Module - Checksum Verified Policy

Validates that image checksums are computed and verified,
ensuring cluster integrity and detecting corruption.

Thresholds:
- min_verified_pct: Minimum % of images with verified checksums (default: 0.95)
- require_all_verified: If true, fail on any unverified images (default: false)

Status Logic:
- PASS: verified_pct >= min_verified_pct
- WARN: verified_pct < min_verified_pct BUT > 0.80
- FAIL: verified_pct < 0.80 OR (require_all_verified AND verified_pct < 1.0)
"""

from branchpy.bqf.policy_base import (
    Policy,
    PolicyConfig,
    PolicyContext,
    PolicyResult,
    PolicyStatus,
)


class ChecksumVerifiedPolicy(Policy):
    """
    Enforces checksum verification for Media/Image Validation V3.

    Checksum verification ensures:
    - Image cluster integrity (no corrupted files)
    - Duplicate detection accuracy (hash-based)
    - Data consistency across cache refreshes

    Required Inputs:
        verified_count: int — Number of images with verified checksums
        total_images: int — Total images in batch

    Optional Inputs:
        checksum_algorithm: str — Algorithm used (SHA-256, etc.)
        failed_verifications: int — Images that failed verification

    Example:
        ctx = PolicyContext(
            module="media",
            inputs={"verified_count": 995, "total_images": 1000}
        )
        policy = ChecksumVerifiedPolicy()
        result = policy.run(ctx)
    """

    POLICY_ID = "media.checksum_verified"
    MODULE = "media"
    REQUIRED_FIELDS = ["verified_count", "total_images"]

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """
        Evaluate checksum verification policy.

        Args:
            ctx: PolicyContext with verified_count and total_images

        Returns:
            PolicyResult with pass/warn/fail status
        """
        # Extract inputs
        try:
            verified_count = ctx.require("verified_count")
            total_images = ctx.require("total_images")
        except ValueError as e:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=str(e),
                metadata={"error": "missing_required_field"},
            )

        # Get thresholds
        min_verified_pct = self.config.get_threshold("min_verified_pct", 0.95)
        require_all = self.config.metadata.get("require_all_verified", False)
        warn_floor = 0.80  # Hard-coded warn threshold

        # Validate inputs
        if not isinstance(verified_count, int) or verified_count < 0:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"verified_count must be non-negative integer, got {verified_count}",
                metadata={"error": "invalid_value"},
            )

        if not isinstance(total_images, int) or total_images <= 0:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"total_images must be positive integer, got {total_images}",
                metadata={"error": "invalid_value"},
            )

        if verified_count > total_images:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"verified_count ({verified_count}) exceeds total_images ({total_images})",
                metadata={"error": "invalid_state"},
            )

        # Calculate verification percentage
        verified_pct = verified_count / total_images if total_images > 0 else 0.0
        unverified_count = total_images - verified_count

        # Build metadata
        metadata = {
            "verified_count": verified_count,
            "unverified_count": unverified_count,
            "total_images": total_images,
            "verified_pct": round(verified_pct, 4),
            "min_verified_pct": min_verified_pct,
            "require_all_verified": require_all,
        }

        # Add optional fields
        if ctx.get("checksum_algorithm"):
            metadata["checksum_algorithm"] = ctx.get("checksum_algorithm")

        failed_verifications = ctx.get("failed_verifications", 0)
        if failed_verifications:
            metadata["failed_verifications"] = failed_verifications

        # Check strict mode (require 100%)
        if require_all and verified_pct < 1.0:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"Strict mode requires all images verified: {unverified_count} unverified",
                metadata={**metadata, "reason": "strict_mode_violation"},
            )

        # Check failure threshold (< 80%)
        if verified_pct < warn_floor:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"Verification rate too low: {verified_pct:.1%} < {warn_floor:.1%}",
                metadata={
                    **metadata,
                    "deficit": round((warn_floor - verified_pct) * total_images),
                },
            )

        # Check warn threshold (< min_verified_pct but >= 80%)
        if verified_pct < min_verified_pct:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.WARN,
                message=f"Verification rate below target: {verified_pct:.1%} < {min_verified_pct:.1%}",
                metadata={**metadata, "reason": "below_target"},
            )

        # PASS: Verification rate meets or exceeds target
        return PolicyResult(
            policy_id=self.POLICY_ID,
            status=PolicyStatus.PASS,
            message=f"Checksums verified: {verified_count}/{total_images} ({verified_pct:.1%})",
            metadata=metadata,
        )

    def get_default_config(self) -> PolicyConfig:
        """
        Return default configuration.

        Returns:
            PolicyConfig with default thresholds
        """
        return PolicyConfig(
            policy_id=self.POLICY_ID,
            enabled=True,
            thresholds={"min_verified_pct": 0.95},  # 95% minimum
            limits={},
            metadata={
                "description": "Enforce checksum verification for Media validation",
                "version": "1.0.0",
                "require_all_verified": False,  # Strict mode: require 100%
            },
        )
