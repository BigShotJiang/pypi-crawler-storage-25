"""
Media Module - Duplicate Cap Policy

Validates that duplicate image counts remain within acceptable limits,
preventing cluster quality degradation from excessive duplicates.

Thresholds:
- max_duplicates_per_batch: Maximum allowed duplicates (default: 10)
- warn_threshold_pct: Warn if duplicates exceed this % of total (default: 0.05)

Status Logic:
- PASS: duplicate_count <= max_duplicates AND duplicate_pct < warn_threshold
- WARN: duplicate_pct >= warn_threshold BUT duplicate_count <= max
- FAIL: duplicate_count > max_duplicates
"""

from branchpy.bqf.policy_base import (
    Policy,
    PolicyConfig,
    PolicyContext,
    PolicyResult,
    PolicyStatus,
)


class DuplicateCapPolicy(Policy):
    """
    Enforces maximum duplicate image count for Media/Image Validation V3.

    Excessive duplicates indicate:
    - Clustering failures (identical images not merged)
    - Duplicate asset imports
    - Hash collision issues

    Required Inputs:
        duplicate_count: int — Number of duplicate images detected
        total_images: int — Total images in batch

    Optional Inputs:
        cluster_count: int — Number of clusters (helps compute dupes per cluster)

    Example:
        ctx = PolicyContext(
            module="media",
            inputs={"duplicate_count": 3, "total_images": 1000}
        )
        policy = DuplicateCapPolicy()
        result = policy.run(ctx)
    """

    POLICY_ID = "media.duplicate_cap"
    MODULE = "media"
    REQUIRED_FIELDS = ["duplicate_count", "total_images"]

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """
        Evaluate duplicate cap policy.

        Args:
            ctx: PolicyContext with duplicate_count and total_images

        Returns:
            PolicyResult with pass/warn/fail status
        """
        # Extract inputs
        try:
            duplicate_count = ctx.require("duplicate_count")
            total_images = ctx.require("total_images")
        except ValueError as e:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=str(e),
                metadata={"error": "missing_required_field"},
            )

        # Get thresholds
        max_duplicates = self.config.get_limit("max_duplicates_per_batch", 10)
        warn_pct = self.config.get_threshold("warn_threshold_pct", 0.05)  # 5%

        # Validate inputs
        if not isinstance(duplicate_count, int) or duplicate_count < 0:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"duplicate_count must be non-negative integer, got {duplicate_count}",
                metadata={"error": "invalid_value"},
            )

        if not isinstance(total_images, int) or total_images <= 0:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"total_images must be positive integer, got {total_images}",
                metadata={"error": "invalid_value"},
            )

        # Calculate duplicate percentage
        duplicate_pct = duplicate_count / total_images if total_images > 0 else 0.0

        # Build metadata
        metadata = {
            "duplicate_count": duplicate_count,
            "total_images": total_images,
            "duplicate_pct": round(duplicate_pct, 4),
            "max_duplicates": max_duplicates,
            "warn_threshold_pct": warn_pct,
        }

        # Add cluster info if available
        cluster_count = ctx.get("cluster_count")
        if cluster_count and isinstance(cluster_count, int) and cluster_count > 0:
            metadata["cluster_count"] = cluster_count
            metadata["avg_duplicates_per_cluster"] = round(
                duplicate_count / cluster_count, 2
            )

        # Check failure threshold
        if duplicate_count > max_duplicates:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.FAIL,
                message=f"Duplicates exceed limit: {duplicate_count} > {max_duplicates} ({duplicate_pct:.1%})",
                metadata={**metadata, "overage": duplicate_count - max_duplicates},
            )

        # Check warn threshold
        if duplicate_pct >= warn_pct:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.WARN,
                message=f"Duplicate rate high: {duplicate_pct:.1%} >= {warn_pct:.1%} (count: {duplicate_count})",
                metadata={**metadata, "reason": "high_duplicate_rate"},
            )

        # PASS: Duplicates within acceptable limits
        return PolicyResult(
            policy_id=self.POLICY_ID,
            status=PolicyStatus.PASS,
            message=f"Duplicates within limits: {duplicate_count}/{total_images} ({duplicate_pct:.1%})",
            metadata=metadata,
        )

    def get_default_config(self) -> PolicyConfig:
        """
        Return default configuration.

        Returns:
            PolicyConfig with default limits and thresholds
        """
        return PolicyConfig(
            policy_id=self.POLICY_ID,
            enabled=True,
            thresholds={"warn_threshold_pct": 0.05},  # 5% duplicates triggers warning
            limits={"max_duplicates_per_batch": 10},
            metadata={
                "description": "Enforce maximum duplicate image count for Media validation",
                "version": "1.0.0",
            },
        )
