"""BQF Wave 5: AI Usage BQF Models."""

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class BQFAISummary:
    """BQF-AI policy execution summary with usage metrics."""

    policies_run: int
    policies_passed: int
    policies_warned: int
    policies_failed: int
    duration_ms: float

    # AI usage aggregates
    total_calls: int = 0
    total_tokens: int = 0
    total_cost: float = 0.0
    error_count: int = 0

    # Provider breakdown: {provider_name: {calls, tokens, cost, errors}}
    provider_breakdown: Dict[str, Dict[str, int | float]] = field(default_factory=dict)
