"""BQF Wave 5: AI Usage Policies."""

from branchpy.bqf.policy_base import (
    Policy,
    PolicyConfig,
    PolicyContext,
    PolicyResult,
    PolicyStatus,
)


class ExcessiveTokensPolicy(Policy):
    """Warn if total tokens exceed threshold in analysis period."""

    POLICY_ID = "BQF-AI-001"
    MODULE = "ai"

    def get_default_config(self) -> PolicyConfig:
        """Return default configuration."""
        return PolicyConfig(
            policy_id=self.POLICY_ID,
            enabled=True,
            thresholds={"max_tokens": 100_000.0},
        )

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """Check if token usage exceeds threshold."""
        total_tokens = ctx.get("total_tokens", 0)
        threshold = int(self.config.get_threshold("max_tokens", 100_000.0))

        if total_tokens > threshold:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.WARN,
                message=f"Token usage ({total_tokens:,}) exceeds threshold ({threshold:,})",
                metadata={"total_tokens": total_tokens, "threshold": threshold},
            )

        return PolicyResult(
            policy_id=self.POLICY_ID,
            status=PolicyStatus.PASS,
            message=f"Token usage ({total_tokens:,}) within acceptable limits",
            metadata={"total_tokens": total_tokens},
        )


class HighCostPolicy(Policy):
    """Warn if total AI cost exceeds threshold."""

    POLICY_ID = "BQF-AI-002"
    MODULE = "ai"

    def get_default_config(self) -> PolicyConfig:
        """Return default configuration."""
        return PolicyConfig(
            policy_id=self.POLICY_ID,
            enabled=True,
            thresholds={"max_cost": 10.0},
        )

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """Check if AI cost exceeds threshold."""
        total_cost = ctx.get("total_cost", 0.0)
        threshold = self.config.get_threshold("max_cost", 10.0)

        if total_cost > threshold:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.WARN,
                message=f"AI cost (${total_cost:.2f}) exceeds threshold (${threshold:.2f})",
                metadata={"total_cost": total_cost, "threshold": threshold},
            )

        return PolicyResult(
            policy_id=self.POLICY_ID,
            status=PolicyStatus.PASS,
            message=f"AI cost (${total_cost:.2f}) within budget",
            metadata={"total_cost": total_cost},
        )


class HighErrorRatePolicy(Policy):
    """Warn if AI error rate exceeds threshold."""

    POLICY_ID = "BQF-AI-003"
    MODULE = "ai"

    def get_default_config(self) -> PolicyConfig:
        """Return default configuration."""
        return PolicyConfig(
            policy_id=self.POLICY_ID,
            enabled=True,
            thresholds={"max_error_rate": 10.0},
        )

    def evaluate(self, ctx: PolicyContext) -> PolicyResult:
        """Check if AI error rate exceeds threshold."""
        total_calls = ctx.get("total_calls", 0)
        error_count = ctx.get("error_count", 0)

        if total_calls == 0:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.PASS,
                message="No AI calls in analysis period",
                metadata={"total_calls": 0, "error_count": 0},
            )

        error_rate = (error_count / total_calls) * 100
        threshold = self.config.get_threshold("max_error_rate", 10.0)

        if error_rate > threshold:
            return PolicyResult(
                policy_id=self.POLICY_ID,
                status=PolicyStatus.WARN,
                message=f"AI error rate ({error_rate:.1f}%) exceeds threshold ({threshold:.1f}%)",
                metadata={
                    "error_rate": error_rate,
                    "error_count": error_count,
                    "total_calls": total_calls,
                    "threshold": threshold,
                },
            )

        return PolicyResult(
            policy_id=self.POLICY_ID,
            status=PolicyStatus.PASS,
            message=f"AI error rate ({error_rate:.1f}%) within acceptable limits",
            metadata={
                "error_rate": error_rate,
                "error_count": error_count,
                "total_calls": total_calls,
            },
        )


# Policy registry - instantiate with default configs
def get_ai_policies():
    """Get list of AI policy instances."""
    return [
        ExcessiveTokensPolicy(),
        HighCostPolicy(),
        HighErrorRatePolicy(),
    ]
