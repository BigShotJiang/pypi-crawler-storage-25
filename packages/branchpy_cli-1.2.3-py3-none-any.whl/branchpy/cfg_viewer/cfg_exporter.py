"""
branchpy.cfg_viewer.cfg_exporter.py
BranchPy v0.9.4 — CFG Visualization

CFG export to JSON format for visualization
"""

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List


@dataclass
class CFGNode:
    """Control flow graph node"""

    id: str
    type: str  # 'start', 'end', 'statement', 'branch', 'loop'
    label: str
    location: Dict[str, int]  # {'line': X, 'col': Y}
    metadata: Dict[str, Any]


@dataclass
class CFGEdge:
    """Control flow graph edge"""

    source: str
    target: str
    label: str  # 'true', 'false', 'next', etc.
    metadata: Dict[str, Any]


class CFGExporter:
    """
    Exports control flow graph to JSON.

    Features:
    - Generate CFG from semantic detections
    - Export to JSON for visualization
    - Support for complex flow patterns
    """

    def __init__(self):
        self.nodes: List[CFGNode] = []
        self.edges: List[CFGEdge] = []
        self._node_counter = 0

    def _generate_node_id(self) -> str:
        """Generate unique node ID"""
        self._node_counter += 1
        return f"node_{self._node_counter}"

    def add_node(
        self,
        node_type: str,
        label: str,
        location: Dict[str, int],
        metadata: Dict[str, Any] = None,
    ) -> str:
        """
        Add a node to the CFG.

        Args:
            node_type: Type of node
            label: Node label
            location: Source location
            metadata: Additional metadata

        Returns:
            Node ID
        """
        node_id = self._generate_node_id()
        self.nodes.append(
            CFGNode(
                id=node_id,
                type=node_type,
                label=label,
                location=location,
                metadata=metadata or {},
            )
        )
        return node_id

    def add_edge(
        self,
        source: str,
        target: str,
        label: str = "next",
        metadata: Dict[str, Any] = None,
    ):
        """
        Add an edge to the CFG.

        Args:
            source: Source node ID
            target: Target node ID
            label: Edge label
            metadata: Additional metadata
        """
        self.edges.append(
            CFGEdge(source=source, target=target, label=label, metadata=metadata or {})
        )

    def build_from_detections(self, detections: List[Any]) -> Dict[str, Any]:
        """
        Build CFG from semantic detections.

        Args:
            detections: Semantic detections

        Returns:
            CFG as dict
        """
        self.nodes = []
        self.edges = []
        self._node_counter = 0

        # Add start node
        start_id = self.add_node("start", "Start", {"line": 0, "col": 0})
        current_id = start_id

        # Process detections
        for detection in detections:
            det_type = getattr(detection, "pattern_type", "unknown")
            location = getattr(detection, "location", {"line": 0, "col": 0})
            context = getattr(detection, "context", "")

            if det_type == "conditional":
                # Branch node
                branch_id = self.add_node("branch", context, location)
                self.add_edge(current_id, branch_id)

                # True and false paths (simplified)
                true_id = self.add_node("statement", "True path", location)
                false_id = self.add_node("statement", "False path", location)

                self.add_edge(branch_id, true_id, "true")
                self.add_edge(branch_id, false_id, "false")

                current_id = true_id

            elif det_type == "function_call":
                # Statement node
                node_id = self.add_node("statement", context, location)
                self.add_edge(current_id, node_id)
                current_id = node_id

            else:
                # Generic statement
                node_id = self.add_node("statement", context, location)
                self.add_edge(current_id, node_id)
                current_id = node_id

        # Add end node
        end_id = self.add_node("end", "End", {"line": 9999, "col": 0})
        self.add_edge(current_id, end_id)

        return self.to_dict()

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert CFG to dictionary.

        Returns:
            CFG as dict
        """
        return {
            "nodes": [asdict(node) for node in self.nodes],
            "edges": [asdict(edge) for edge in self.edges],
            "metadata": {"node_count": len(self.nodes), "edge_count": len(self.edges)},
        }

    def to_json(self, output_path: Path):
        """
        Export CFG to JSON file.

        Args:
            output_path: Output file path
        """
        try:
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(self.to_dict(), f, indent=2)
        except Exception as e:
            print(f"Failed to export CFG: {e}")

    def get_entry_nodes(self) -> List[CFGNode]:
        """Get all entry nodes (no incoming edges)"""
        has_incoming = {edge.target for edge in self.edges}
        return [node for node in self.nodes if node.id not in has_incoming]

    def get_exit_nodes(self) -> List[CFGNode]:
        """Get all exit nodes (no outgoing edges)"""
        has_outgoing = {edge.source for edge in self.edges}
        return [node for node in self.nodes if node.id not in has_outgoing]
