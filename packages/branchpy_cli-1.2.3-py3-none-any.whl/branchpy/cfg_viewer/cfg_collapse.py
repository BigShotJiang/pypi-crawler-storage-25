"""
branchpy.cfg_viewer.cfg_collapse.py
BranchPy v1.1.0 — Flowchart Utility Collapse

Collapses utility label chains into edge metadata to preserve flowchart connectivity
while reducing visual clutter from helper/transition functions.

Governance ID: FLOWCHART-COLLAPSE-P1
Phase: 1 - Backend Graph Collapsing
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .cfg_exporter import CFGEdge, CFGNode


@dataclass
class CollapsedEdge:
    """
    Edge that bypasses collapsed utility nodes.

    Represents a direct connection between story nodes that would otherwise
    pass through utility helper functions.
    """

    source: str  # Source node ID
    target: str  # Target node ID
    collapsed_utilities: List[str] = field(default_factory=list)  # Label names
    original_edge_types: List[str] = field(default_factory=list)  # Edge types
    metadata: Dict[str, object] = field(default_factory=dict)  # Additional data

    def to_dict(self) -> Dict[str, object]:
        """Convert to dictionary for JSON export."""
        return {
            "source": self.source,
            "target": self.target,
            "collapsed_utilities": self.collapsed_utilities,
            "original_edge_types": self.original_edge_types,
            "metadata": self.metadata,
        }

    def to_dot_attr(self) -> str:
        """
        Convert to DOT edge attribute format.

        Returns JSON string for embedding in DOT edge metadata.
        """
        return json.dumps(
            {
                "utilities": self.collapsed_utilities,
                "count": len(self.collapsed_utilities),
            }
        )


class CollapsedCFG:
    """
    Wrapper holding original CFG plus collapsed story view.

    Maintains both the full CFG (for debugging) and a collapsed view
    (for visualization) where utility chains are compressed into edges.
    """

    def __init__(
        self,
        original_nodes: List[CFGNode],
        original_edges: List[CFGEdge],
    ) -> None:
        self.original_nodes = original_nodes
        self.original_edges = original_edges
        self.story_nodes: Dict[str, CFGNode] = {}
        self.collapsed_edges: Dict[Tuple[str, str], CollapsedEdge] = {}
        self.collapsed_utility_labels: Set[str] = set()

    def add_story_node(self, node: CFGNode) -> None:
        """Add a node classified as story content."""
        self.story_nodes[node.id] = node

    def add_collapsed_edge(
        self,
        source_id: str,
        target_id: str,
        through: Iterable[CFGNode],
        edge_types: Iterable[str],
    ) -> None:
        """
        Add or update a collapsed edge.

        Args:
            source_id: Source story node ID
            target_id: Target story node ID
            through: Utility nodes being bypassed
            edge_types: Original edge types in the chain
        """
        key = (source_id, target_id)
        if key not in self.collapsed_edges:
            self.collapsed_edges[key] = CollapsedEdge(
                source=source_id,
                target=target_id,
            )
        edge = self.collapsed_edges[key]
        for node in through:
            # Use label from metadata if available, otherwise use id
            label_name = node.metadata.get("label_name", node.id)
            if label_name not in edge.collapsed_utilities:
                edge.collapsed_utilities.append(label_name)
                self.collapsed_utility_labels.add(label_name)
        for et in edge_types:
            if et not in edge.original_edge_types:
                edge.original_edge_types.append(et)

    def get_story_view_nodes(self) -> List[CFGNode]:
        """Get list of story nodes for visualization."""
        return list(self.story_nodes.values())

    def get_story_view_edges(self) -> List[CollapsedEdge]:
        """Get list of collapsed edges for visualization."""
        return list(self.collapsed_edges.values())

    def to_dict(self) -> Dict[str, object]:
        """Convert to dictionary for JSON export."""
        # CFGNode from cfg_exporter uses dataclass.asdict()
        import dataclasses

        return {
            "story_nodes": [
                dataclasses.asdict(node) for node in self.story_nodes.values()
            ],
            "collapsed_edges": [
                edge.to_dict() for edge in self.collapsed_edges.values()
            ],
            "collapsed_utility_count": len(self.collapsed_utility_labels),
            "original_node_count": len(self.original_nodes),
            "original_edge_count": len(self.original_edges),
        }


def is_utility_node(node: CFGNode) -> bool:
    """
    Classify node as utility based on naming and content patterns.

    Conservative classification - requires multiple indicators:
    - Utility naming pattern (starts with _, contains helper/transition/mas_reaction)
    - No story content (no dialogue, no menus)
    - Not marked as important in metadata

    Args:
        node: CFG node to classify

    Returns:
        True if node appears to be a utility helper
    """
    # Check metadata for explicit classification
    if node.metadata.get("is_story", False):
        return False
    if node.metadata.get("is_utility", False):
        return True

    # Extract label name
    label_name = node.metadata.get("label_name", node.label)
    if not label_name:
        return False

    # Utility naming patterns
    utility_patterns = [
        "_mas_reaction_",
        "_helper",
        "_transition",
        "_zoom",
        "_ribbon",
        "_emptydesk",
        "mas_transition_",
        "mas_zoom_",
        # Broader MAS utility patterns
        "_draw_",
        "_save",
        "_load",
        "_check",
        "_confirm",
        "_migration",
        "mas_chess_",  # Chess utilities
        "mas_dlg_",  # Dialogue helpers
    ]

    has_utility_pattern = any(
        pattern in label_name.lower() for pattern in utility_patterns
    )
    starts_with_underscore = label_name.startswith("_")

    # Content checks - utility nodes typically have minimal content
    # Use label field (CFGNode from cfg_exporter) or metadata content
    content_lower = ""
    if hasattr(node, "content"):
        content_lower = node.content.lower() if node.content else ""  # type: ignore[attr-defined]
    else:
        # Fallback to label or metadata
        check_text = node.label.lower() if node.label else ""
        if "content" in node.metadata:
            check_text += " " + str(node.metadata["content"]).lower()
        content_lower = check_text

    has_dialogue = any(
        marker in content_lower for marker in ["say ", '"', "menu:", "choice"]
    )
    has_story_keyword = any(
        kw in content_lower for kw in ["menu", "choice", "input", "nvl"]
    )

    # Classify as utility if:
    # 1. Has utility naming pattern AND no story content
    # 2. OR starts with underscore AND no story content AND not explicitly marked as story
    if has_utility_pattern and not has_dialogue:
        return True
    if starts_with_underscore and not has_dialogue and not has_story_keyword:
        return True

    return False


def validate_utility_classification(
    nodes: List[CFGNode],
    max_ratio: float = 0.8,
) -> None:
    """
    Safety guardrail: if >max_ratio nodes are utility, relax classification.

    Prevents pathological case where over-aggressive classification
    collapses entire graph to 1-2 nodes.

    Mutates node metadata in place to reclassify false positives.

    Args:
        nodes: List of CFG nodes to validate
        max_ratio: Maximum allowed utility ratio before relaxing (default 0.8 = 80%)
    """
    if not nodes:
        return

    # Count utilities
    utility_count = sum(1 for node in nodes if is_utility_node(node))
    total_count = len(nodes)
    ratio = utility_count / total_count if total_count > 0 else 0

    # If ratio exceeds threshold, relax classification
    if ratio > max_ratio:
        # Re-classify: only keep nodes with VERY strong utility patterns
        strict_patterns = ["_mas_reaction_ribbon", "_helper_internal"]
        for node in nodes:
            if is_utility_node(node):
                label_name = node.metadata.get("label_name", node.label)
                # Keep as utility only if matches strict patterns
                if not any(
                    pattern in label_name.lower() for pattern in strict_patterns
                ):
                    # Reclassify as story
                    node.metadata["is_story"] = True
                    node.metadata["reclassified_from_utility"] = True


def collapse_utility_chains(
    nodes: List[CFGNode],
    edges: List[CFGEdge],
) -> CollapsedCFG:
    """
    Collapse utility chains into edge metadata.

    Algorithm:
    1. Validate utility classification (apply safety guardrail)
    2. Identify story nodes
    3. For each utility node:
       - Find story predecessors
       - Find story successors
       - Create collapsed edges: predecessor -> successor (through utility)
    4. Return CollapsedCFG with story nodes and collapsed edges

    Complexity: O(U × P × S) where:
    - U = utility node count
    - P = average predecessors per utility
    - S = average successors per utility

    For MAS scale: ~1000 utilities × 2 preds × 2 succs = ~4000 ops (<100ms)

    Args:
        nodes: List of CFG nodes
        edges: List of CFG edges

    Returns:
        CollapsedCFG with story view
    """
    # Apply safety guardrail
    validate_utility_classification(nodes)

    # Build adjacency lists
    predecessors: Dict[str, List[str]] = {node.id: [] for node in nodes}
    successors: Dict[str, List[str]] = {node.id: [] for node in nodes}
    edge_types: Dict[Tuple[str, str], str] = {}

    for edge in edges:
        successors[edge.source].append(edge.target)
        predecessors[edge.target].append(edge.source)
        edge_types[(edge.source, edge.target)] = edge.label

    # Create collapsed CFG
    collapsed = CollapsedCFG(nodes, edges)

    # Classify nodes
    node_map = {node.id: node for node in nodes}
    utility_nodes: Set[str] = set()
    story_nodes: Set[str] = set()

    for node in nodes:
        if is_utility_node(node):
            utility_nodes.add(node.id)
        else:
            story_nodes.add(node.id)
            collapsed.add_story_node(node)

    # Collapse utility chains
    for util_id in utility_nodes:
        util_node = node_map[util_id]

        # Find story predecessors (walk back through utilities)
        # Create fresh visited set for each search
        story_preds = _find_story_predecessors(
            util_id,
            predecessors,
            story_nodes,
            utility_nodes,
            visited=set(),  # Fresh visited set
        )

        # Find story successors (walk forward through utilities)
        # Create fresh visited set for each search
        story_succs = _find_story_successors(
            util_id,
            successors,
            story_nodes,
            utility_nodes,
            visited=set(),  # Fresh visited set
        )

        # Create collapsed edges
        for pred_id in story_preds:
            for succ_id in story_succs:
                # Collect edge types along the path
                path_edge_types = []
                if (pred_id, util_id) in edge_types:
                    path_edge_types.append(edge_types[(pred_id, util_id)])
                if (util_id, succ_id) in edge_types:
                    path_edge_types.append(edge_types[(util_id, succ_id)])

                collapsed.add_collapsed_edge(
                    source_id=pred_id,
                    target_id=succ_id,
                    through=[util_node],
                    edge_types=path_edge_types,
                )

    return collapsed


def _find_story_predecessors(
    start_id: str,
    predecessors: Dict[str, List[str]],
    story_nodes: Set[str],
    utility_nodes: Set[str],
    visited: Optional[Set[str]] = None,
) -> Set[str]:
    """
    Walk backward through utility nodes to find story predecessors.

    Iterative implementation using explicit stack to avoid RecursionError
    on deep utility chains (e.g., 1000+ utilities).

    Args:
        start_id: Starting utility node ID
        predecessors: Adjacency list of predecessors
        story_nodes: Set of story node IDs
        utility_nodes: Set of utility node IDs
        visited: Set of visited nodes (for cycle detection)

    Returns:
        Set of story node IDs that precede this utility
    """
    if visited is None:
        visited = set()

    if start_id in visited:
        return set()  # Cycle detected

    result = set()
    stack = [start_id]

    while stack:
        node_id = stack.pop()

        if node_id in visited:
            continue  # Skip already visited nodes

        visited.add(node_id)

        for pred_id in predecessors.get(node_id, []):
            if pred_id in story_nodes:
                result.add(pred_id)
            elif pred_id in utility_nodes and pred_id not in visited:
                # Walk back through utility chain
                stack.append(pred_id)

    return result


def _find_story_successors(
    start_id: str,
    successors: Dict[str, List[str]],
    story_nodes: Set[str],
    utility_nodes: Set[str],
    visited: Optional[Set[str]] = None,
) -> Set[str]:
    """
    Walk forward through utility nodes to find story successors.

    Iterative implementation using explicit stack to avoid RecursionError
    on deep utility chains (e.g., 1000+ utilities).

    Args:
        start_id: Starting utility node ID
        successors: Adjacency list of successors
        story_nodes: Set of story node IDs
        utility_nodes: Set of utility node IDs
        visited: Set of visited nodes (for cycle detection)

    Returns:
        Set of story node IDs that follow this utility
    """
    if visited is None:
        visited = set()

    if start_id in visited:
        return set()  # Cycle detected

    result = set()
    stack = [start_id]

    while stack:
        node_id = stack.pop()

        if node_id in visited:
            continue  # Skip already visited nodes

        visited.add(node_id)

        for succ_id in successors.get(node_id, []):
            if succ_id in story_nodes:
                result.add(succ_id)
            elif succ_id in utility_nodes and succ_id not in visited:
                # Walk forward through utility chain
                stack.append(succ_id)

    return result
