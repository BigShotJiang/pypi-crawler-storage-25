"""
branchpy.cfg_viewer.cfg_to_graphviz.py
BranchPy v1.1.0 — CFG Visualization

Convert CFG to GraphViz DOT format for rendering

Supports:
- Full view: All nodes visible
- Story view: Utility chains collapsed into edges (v1.1.0)
"""

from pathlib import Path
from typing import Dict, List, Literal

from .cfg_collapse import CollapsedCFG, collapse_utility_chains
from .cfg_exporter import CFGEdge, CFGNode


class CFGToGraphviz:
    """
    Converts CFG to GraphViz DOT format.

    Features:
    - Generate DOT files from CFG
    - Customizable node/edge styling
    - Support for complex graphs
    """

    def __init__(self):
        self.node_styles = {
            "start": {"shape": "ellipse", "style": "filled", "fillcolor": "lightgreen"},
            "end": {"shape": "ellipse", "style": "filled", "fillcolor": "lightcoral"},
            "branch": {
                "shape": "diamond",
                "style": "filled",
                "fillcolor": "lightyellow",
            },
            "statement": {"shape": "box", "style": "filled", "fillcolor": "lightblue"},
            "loop": {
                "shape": "box",
                "style": "filled,rounded",
                "fillcolor": "lightgray",
            },
        }

        self.edge_styles = {
            "true": {"color": "green", "label": "true"},
            "false": {"color": "red", "label": "false"},
            "next": {"color": "black", "label": ""},
        }

    def convert(self, nodes: List[CFGNode], edges: List[CFGEdge]) -> str:
        """
        Convert CFG to DOT format.

        Args:
            nodes: List of CFG nodes
            edges: List of CFG edges

        Returns:
            DOT format string
        """
        dot_lines = ["digraph CFG {"]
        dot_lines.append("    rankdir=TB;")  # Top to bottom layout
        dot_lines.append('    node [fontname="Arial", fontsize=10];')
        dot_lines.append("")

        # Add nodes
        for node in nodes:
            style = self.node_styles.get(node.type, {})
            attrs = []

            # Node label (escape quotes)
            label = node.label.replace('"', '\\"')
            attrs.append(f'label="{label}"')

            # Apply style
            for key, value in style.items():
                attrs.append(f'{key}="{value}"')

            attrs_str = ", ".join(attrs)
            dot_lines.append(f"    {node.id} [{attrs_str}];")

        dot_lines.append("")

        # Add edges
        for edge in edges:
            style = self.edge_styles.get(edge.label, {})
            attrs = []

            for key, value in style.items():
                if value:  # Only add non-empty values
                    attrs.append(f'{key}="{value}"')

            if attrs:
                attrs_str = " [" + ", ".join(attrs) + "]"
            else:
                attrs_str = ""

            dot_lines.append(f"    {edge.source} -> {edge.target}{attrs_str};")

        dot_lines.append("}")

        return "\n".join(dot_lines)

    def export_dot(self, nodes: List[CFGNode], edges: List[CFGEdge], output_path: Path):
        """
        Export CFG to DOT file.

        Args:
            nodes: List of CFG nodes
            edges: List of CFG edges
            output_path: Output file path
        """
        dot_content = self.convert(nodes, edges)

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(dot_content)
        except Exception as e:
            print(f"Failed to export DOT file: {e}")

    def export_svg(self, nodes: List[CFGNode], edges: List[CFGEdge], output_path: Path):
        """
        Export CFG to SVG (requires graphviz installed).

        Args:
            nodes: List of CFG nodes
            edges: List of CFG edges
            output_path: Output SVG file path
        """
        try:
            import subprocess
            import tempfile

            # Create temporary DOT file
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".dot", delete=False
            ) as temp_dot:
                dot_content = self.convert(nodes, edges)
                temp_dot.write(dot_content)
                temp_dot_path = temp_dot.name

            # Run graphviz dot command
            subprocess.run(
                ["dot", "-Tsvg", temp_dot_path, "-o", str(output_path)], check=True
            )

            # Clean up temp file
            Path(temp_dot_path).unlink()

        except FileNotFoundError:
            print("Graphviz not installed. Please install graphviz to export SVG.")
        except Exception as e:
            print(f"Failed to export SVG: {e}")

    def set_node_style(self, node_type: str, style: Dict[str, str]):
        """
        Set custom node style.

        Args:
            node_type: Node type
            style: Style attributes dict
        """
        self.node_styles[node_type] = style

    def set_edge_style(self, edge_label: str, style: Dict[str, str]):
        """
        Set custom edge style.

        Args:
            edge_label: Edge label
            style: Style attributes dict
        """
        self.edge_styles[edge_label] = style

    def convert_with_collapse(
        self,
        nodes: List[CFGNode],
        edges: List[CFGEdge],
        view_mode: Literal["story", "full"] = "story",
    ) -> str:
        """
        Convert CFG to DOT format with optional utility collapse.

        Args:
            nodes: List of CFG nodes
            edges: List of CFG edges
            view_mode: "story" for collapsed view, "full" for all nodes

        Returns:
            DOT format string
        """
        if view_mode == "full":
            return self.convert(nodes, edges)

        # Story view: collapse utilities
        collapsed = collapse_utility_chains(nodes, edges)
        return self._convert_story_view(collapsed)

    def _convert_story_view(self, collapsed: CollapsedCFG) -> str:
        """
        Generate DOT for story view (collapsed utilities).

        Args:
            collapsed: Collapsed CFG with story nodes and collapsed edges

        Returns:
            DOT format string
        """
        dot_lines = ["digraph CFG {"]
        dot_lines.append("    rankdir=TB;")
        dot_lines.append('    node [fontname="Arial", fontsize=10];')
        dot_lines.append('    edge [fontname="Arial", fontsize=9];')
        dot_lines.append("")

        # Add story nodes
        for node in collapsed.get_story_view_nodes():
            style = self.node_styles.get(node.type, {})
            attrs = []

            # Node label (escape quotes)
            label = node.label.replace('"', '\\"')
            attrs.append(f'label="{label}"')

            # Apply style
            for key, value in style.items():
                attrs.append(f'{key}="{value}"')

            attrs_str = ", ".join(attrs)
            dot_lines.append(f"    {node.id} [{attrs_str}];")

        dot_lines.append("")

        # Add collapsed edges
        for edge in collapsed.get_story_view_edges():
            attrs = []

            # Dashed style for collapsed edges
            if edge.collapsed_utilities:
                attrs.append('style="dashed"')
                attrs.append('color="gray"')

                # Label with utility count
                count = len(edge.collapsed_utilities)
                if count == 1:
                    label = f"{count} utility"
                else:
                    label = f"{count} utilities"
                attrs.append(f'label="{label}"')

                # Embed collapsed data as tooltip
                utilities_str = ", ".join(edge.collapsed_utilities[:5])
                if len(edge.collapsed_utilities) > 5:
                    utilities_str += "..."
                tooltip = f"Through: {utilities_str}"
                attrs.append(f'tooltip="{tooltip}"')

                # Add metadata attribute for webview parsing
                attrs.append(f'metadata="{edge.to_dot_attr()}"')
            else:
                # Regular edge (direct connection between story nodes)
                attrs.append('color="black"')

            attrs_str = " [" + ", ".join(attrs) + "]" if attrs else ""
            dot_lines.append(f"    {edge.source} -> {edge.target}{attrs_str};")

        dot_lines.append("}")

        return "\n".join(dot_lines)

    def export_dot_with_collapse(
        self,
        nodes: List[CFGNode],
        edges: List[CFGEdge],
        output_path: Path,
        view_mode: Literal["story", "full"] = "story",
    ):
        """
        Export CFG to DOT file with optional utility collapse.

        Args:
            nodes: List of CFG nodes
            edges: List of CFG edges
            output_path: Output file path
            view_mode: "story" for collapsed view, "full" for all nodes
        """
        dot_content = self.convert_with_collapse(nodes, edges, view_mode)

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(dot_content)
        except Exception as e:
            print(f"Failed to export DOT file: {e}")
