# branchpy/emit.py
# Event emission bridge for VS Code integration
import json
import os
import sys
from datetime import datetime
from typing import Any, Dict, Optional


def emit_event(
    kind: str, payload: Dict[str, Any], project: Optional[str] = None
) -> None:
    """
    Emit an event for VS Code extension consumption.
    Events are printed to stdout in a structured format that the extension can parse.
    """
    event = {
        "timestamp": datetime.now().isoformat(),
        "kind": kind,
        "project": project or os.getcwd(),
        "payload": payload,
    }

    # Check if we should emit events (controlled by environment variable)
    if os.getenv("BRANCHPY_EMIT_EVENTS", "false").lower() == "true":
        # Print to stderr to avoid interfering with regular command output
        print(f"BRANCHPY_EVENT: {json.dumps(event)}", file=sys.stderr, flush=True)


def emit_command_start(command: str, project: Optional[str] = None) -> None:
    """Emit event when a command starts."""
    emit_event(
        "command_start",
        {"command": command, "args": sys.argv[1:] if len(sys.argv) > 1 else []},
        project,
    )


def emit_command_end(
    command: str, exit_code: int, project: Optional[str] = None
) -> None:
    """Emit event when a command ends."""
    emit_event("command_end", {"command": command, "exit_code": exit_code}, project)


def emit_watch_run(
    command: str, exit_code: int, changed_file: str, project: Optional[str] = None
) -> None:
    """Emit event when watch mode runs a command."""
    emit_event(
        "watch_run",
        {"command": command, "exit_code": exit_code, "changed_file": changed_file},
        project,
    )
