"""
Scene Coverage Analyzer with Telemetry Integration

Example implementation showing how to add Phase E telemetry
to the scene coverage analyzer without changing its core behavior.

This is a REFERENCE IMPLEMENTATION for Phase E, not production code.
Copy patterns into the real analyzer.

Governance: v0.9.8 Phase E — Scene Coverage Integration
"""

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from branchpy.telemetry.sdk_telemetry import get_sdk_emitter
from branchpy.telemetry.utils import compute_project_hash

logger = logging.getLogger(__name__)


class SceneCoverageAnalyzerWithTelemetry:
    """
    Scene coverage analyzer with Phase E telemetry integration.

    Usage:
        analyzer = SceneCoverageAnalyzerWithTelemetry(
            project_path="/path/to/project",
            config=config
        )

        result = analyzer.analyze()

        # result contains:
        # {
        #     "total_scenes": 145,
        #     "reachable_scenes": 128,
        #     "unreachable_scenes": 17,
        #     "coverage_percentage": 88.3,
        #     "unreachable_list": ["scene_x", "scene_y", ...],
        #     "correlation_id": "uuid"
        # }

    Telemetry:
        - Emits scene_coverage.analysis.started at beginning
        - Emits scene_coverage.analysis.completed on success
        - Emits scene_coverage.analysis.failed on exception
        - All telemetry errors are swallowed (non-blocking)
        - Telemetry respects opt-out configuration
    """

    def __init__(self, project_path: str, config: Dict[str, Any]):
        """
        Initialize scene coverage analyzer.

        Args:
            project_path: Path to Ren'Py project root
            config: Configuration dictionary (includes telemetry settings)
        """
        self.project_path = Path(project_path)
        self.config = config

        # Initialize telemetry emitter (singleton)
        # This respects user opt-out and privacy settings
        try:
            self.emitter = get_sdk_emitter(
                log_dir=config.get("telemetry.log_dir", ".branchpy/logs/telemetry")
            )
        except Exception as e:
            logger.warning(f"Telemetry initialization failed: {e}")
            self.emitter = None

        # Compute project hash once (used in all events)
        self.project_hash = compute_project_hash(project_path)

    def analyze(self) -> Dict[str, Any]:
        """
        Run scene coverage analysis with telemetry.

        Returns:
            Dictionary with coverage metrics and unreachable scenes

        Raises:
            Exception: If analysis fails critically

        Notes:
            - Telemetry errors are logged but don't block analysis
            - Correlation ID links started/completed/failed events
        """
        # Generate correlation ID for this analysis session
        correlation_id = str(uuid.uuid4())
        start_time = datetime.utcnow()

        # Emit telemetry: analysis started
        self._emit_started(correlation_id)

        try:
            # ============================================================
            # ACTUAL ANALYSIS LOGIC GOES HERE
            # (This is simplified for example purposes)
            # ============================================================

            # 1. Build scene graph
            logger.info(f"Building scene graph for {self.project_path}")
            graph = self._build_scene_graph()

            # 2. Calculate reachability
            logger.info("Calculating reachability...")
            reachable = self._calculate_reachability(graph)

            # 3. Compute metrics
            total = len(graph["scenes"])
            reachable_count = len(reachable)
            unreachable_count = total - reachable_count
            coverage_pct = (reachable_count / total * 100) if total > 0 else 0

            # 4. Get unreachable scene list
            unreachable_list = list(set(graph["scenes"].keys()) - reachable)

            # ============================================================
            # END ANALYSIS LOGIC
            # ============================================================

            # Calculate duration
            end_time = datetime.utcnow()
            duration_ms = int((end_time - start_time).total_seconds() * 1000)

            # Emit telemetry: analysis completed
            self._emit_completed(
                correlation_id=correlation_id,
                total_scenes=total,
                reachable_scenes=reachable_count,
                unreachable_scenes=unreachable_count,
                coverage_percentage=coverage_pct,
                duration_ms=duration_ms,
                unreachable_list=unreachable_list,
            )

            # Return results
            return {
                "total_scenes": total,
                "reachable_scenes": reachable_count,
                "unreachable_scenes": unreachable_count,
                "coverage_percentage": coverage_pct,
                "unreachable_list": unreachable_list,
                "correlation_id": correlation_id,
                "duration_ms": duration_ms,
            }

        except Exception as e:
            # Emit telemetry: analysis failed
            self._emit_failed(correlation_id=correlation_id, exception=e, fatal=True)

            # Re-raise exception (telemetry doesn't suppress errors)
            raise

    def _emit_started(self, correlation_id: str):
        """Emit scene_coverage.analysis.started event."""
        if not self.emitter:
            return

        try:
            self.emitter.emit_scene_coverage_started(
                project_path=str(self.project_path), correlation_id=correlation_id
            )
        except Exception as e:
            logger.warning(f"Telemetry emission failed (started): {e}")

    def _emit_completed(
        self,
        correlation_id: str,
        total_scenes: int,
        reachable_scenes: int,
        unreachable_scenes: int,
        coverage_percentage: float,
        duration_ms: int,
        unreachable_list: List[str],
    ):
        """Emit scene_coverage.analysis.completed event."""
        if not self.emitter:
            return

        try:
            self.emitter.emit_scene_coverage_completed(
                project_path=str(self.project_path),
                total_scenes=total_scenes,
                reachable_scenes=reachable_scenes,
                unreachable_scenes=unreachable_scenes,
                coverage_percentage=coverage_percentage,
                duration_ms=duration_ms,
                correlation_id=correlation_id,
                unreachable_list=unreachable_list,  # Will be truncated to 50 items / 1KB
            )
        except Exception as e:
            logger.warning(f"Telemetry emission failed (completed): {e}")

    def _emit_failed(self, correlation_id: str, exception: Exception, fatal: bool):
        """Emit scene_coverage.analysis.failed event."""
        if not self.emitter:
            return

        try:
            self.emitter.emit_scene_coverage_failed(
                project_path=str(self.project_path),
                exception_type=type(exception).__name__,
                message=str(exception),
                correlation_id=correlation_id,
                fatal=fatal,
            )
        except Exception as e:
            logger.warning(f"Telemetry emission failed (failed): {e}")

    # ====================================================================
    # PLACEHOLDER ANALYSIS METHODS
    # (Replace with real implementation)
    # ====================================================================

    def _build_scene_graph(self) -> Dict[str, Any]:
        """
        Build scene graph from Ren'Py script files.

        Returns:
            Dictionary with 'scenes' and 'edges'
        """
        # PLACEHOLDER: Replace with real graph building logic
        return {
            "scenes": {
                "start": {},
                "scene1": {},
                "scene2": {},
                "scene3": {},
                "unreachable_scene": {},
            },
            "edges": [("start", "scene1"), ("scene1", "scene2"), ("scene2", "scene3")],
        }

    def _calculate_reachability(self, graph: Dict[str, Any]) -> set:
        """
        Calculate reachable scenes via DFS/BFS.

        Args:
            graph: Scene graph from _build_scene_graph

        Returns:
            Set of reachable scene names
        """
        # PLACEHOLDER: Replace with real reachability algorithm
        reachable = {"start", "scene1", "scene2", "scene3"}
        return reachable


# ====================================================================
# USAGE EXAMPLE
# ====================================================================


def example_usage():
    """Example of using the analyzer with telemetry."""

    config = {
        "telemetry.log_dir": ".branchpy/logs/telemetry",
        "telemetry.enabled": True,  # User opt-in
        "telemetry.privacy_level": "minimal",
    }

    analyzer = SceneCoverageAnalyzerWithTelemetry(
        project_path="/path/to/my/renpy/project", config=config
    )

    try:
        result = analyzer.analyze()

        print(f"Coverage: {result['coverage_percentage']:.1f}%")
        print(f"Total Scenes: {result['total_scenes']}")
        print(f"Reachable: {result['reachable_scenes']}")
        print(f"Unreachable: {result['unreachable_scenes']}")

        if result["unreachable_list"]:
            print("\nUnreachable scenes:")
            for scene in result["unreachable_list"][:10]:
                print(f"  - {scene}")

            if len(result["unreachable_list"]) > 10:
                print(f"  ... and {len(result['unreachable_list']) - 10} more")

    except Exception as e:
        print(f"Analysis failed: {e}")


if __name__ == "__main__":
    example_usage()
