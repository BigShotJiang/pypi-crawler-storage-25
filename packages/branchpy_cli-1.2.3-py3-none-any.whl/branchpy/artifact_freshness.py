"""
branchpy/artifact_freshness.py

Content-revision freshness model for BranchPy CLI artifacts.

Mirrors the TypeScript implementation in
vscode-addon/src/services/artifactFreshness.ts.

Spec: docs/Current Version/Analysis/ARTIFACT_FRESHNESS_SPEC.md
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from branchpy.run_context import RunContext

# ── Types ──────────────────────────────────────────────────────────────────────

# Max mtime of .rpy files, milliseconds since epoch.
SourceRevision = int


@dataclass
class ArtifactStatus:
    exists: bool
    fresh: bool
    stale: bool
    missing: bool
    timestamp: Optional[int] = None  # artifact mtime, ms epoch
    source_revision: Optional[int] = None  # embedded source_revision field
    file_path: Optional[Path] = None


@dataclass
class ArtifactVersion:
    stage: str
    source_revision: int


# ─── Source revision ──────────────────────────────────────────────────────────


def get_source_revision(project_path: Path) -> SourceRevision:
    """Return the max mtime (ms epoch) of all .rpy files under project_path.

    Returns 0 if no .rpy files are found or on any I/O error.
    """
    try:
        max_mtime: float = 0.0
        for rpy_file in project_path.rglob("*.rpy"):
            try:
                mtime = rpy_file.stat().st_mtime
                if mtime > max_mtime:
                    max_mtime = mtime
            except OSError:
                continue
        return int(max_mtime * 1000)
    except Exception:
        return 0


# ── Artifact file lookup ───────────────────────────────────────────────────────


def find_artifact_file(project_path: Path, report_type: str) -> Optional[Path]:
    """Return the canonical Path for a given artifact type, or None if not found.

    report_type values: "analyze", "pilot", "omega"
    """
    branchpy_dir = project_path / ".branchpy"

    if report_type == "omega":
        p = branchpy_dir / "stats2" / "omega.json"
        return p if p.exists() else None

    if report_type in ("pilot", "stats2"):
        # Canonical path first, legacy fallback
        canonical = branchpy_dir / "pilot" / "pilot.json"
        if canonical.exists():
            return canonical
        legacy = branchpy_dir / "stats2" / "stats2.json"
        return legacy if legacy.exists() else None

    if report_type == "analyze":
        unified = branchpy_dir / "reports" / "unified" / "unified_report.json"
        if unified.exists():
            return unified
        # Fall back to newest timestamped report file
        reports_dir = branchpy_dir / "reports"
        if reports_dir.exists():
            candidates = sorted(
                reports_dir.glob("*.json"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if candidates:
                return candidates[0]
        return None

    return None


# ── Freshness check ────────────────────────────────────────────────────────────

_FRESHNESS_FALLBACK_TTL_MS: int = 24 * 60 * 60 * 1000  # 24 hours


def check_artifact_freshness(project_path: Path, report_type: str) -> ArtifactStatus:
    """Check whether an artifact is fresh relative to the current source revision.

    Primary method: compare current_revision <= artifact.source_revision.
    Fallback (when source_revision absent): 24-hour mtime window.
    """
    artifact_path = find_artifact_file(project_path, report_type)

    if artifact_path is None:
        return ArtifactStatus(exists=False, fresh=False, stale=False, missing=True)

    try:
        artifact_mtime_ms = int(artifact_path.stat().st_mtime * 1000)
    except OSError:
        return ArtifactStatus(exists=False, fresh=False, stale=False, missing=True)

    # Read source_revision embedded in the artifact JSON
    artifact_source_revision: Optional[int] = None
    try:
        data = json.loads(artifact_path.read_text(encoding="utf-8"))
        sr = data.get("source_revision")
        if isinstance(sr, (int, float)) and sr > 0:
            artifact_source_revision = int(sr)
    except Exception:
        pass

    current_revision = get_source_revision(project_path)

    if artifact_source_revision is not None:
        # Primary: content-revision comparison (spec §3.1)
        fresh = current_revision <= artifact_source_revision
    else:
        # Fallback: 24-hour mtime window (spec §3.1 legacy path)
        now_ms = int(time.time() * 1000)
        fresh = (now_ms - artifact_mtime_ms) < _FRESHNESS_FALLBACK_TTL_MS

    return ArtifactStatus(
        exists=True,
        fresh=fresh,
        stale=not fresh,
        missing=False,
        timestamp=artifact_mtime_ms,
        source_revision=artifact_source_revision,
        file_path=artifact_path,
    )


# ── Metadata patching ─────────────────────────────────────────────────────────


def patch_artifact_metadata(
    file_path: Path,
    project_path: Path,
    stage: str,
    run_ctx: "Optional[RunContext]" = None,
) -> Optional[ArtifactVersion]:
    """Non-destructively inject generated_at, source_revision, and run identity
    into an artifact JSON.

    If *run_ctx* is provided its :py:meth:`~RunContext.to_dict` is stored under
    the ``"_run"`` key so the artifact carries full snapshot identity.

    Returns ArtifactVersion on success, None on any error (non-fatal).
    """
    try:
        data = json.loads(file_path.read_text(encoding="utf-8"))
    except Exception:
        return None

    source_revision = get_source_revision(project_path)
    generated_at = int(time.time() * 1000)

    data["generated_at"] = generated_at
    data["source_revision"] = source_revision

    if run_ctx is not None:
        data["_run"] = run_ctx.to_dict()

    try:
        file_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        return None

    return ArtifactVersion(stage=stage, source_revision=source_revision)
