# branchpy/scan_context.py
import fnmatch
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Set

IMG_EXTS = {".png", ".webp", ".jpg", ".jpeg"}
SND_EXTS = {".ogg", ".mp3", ".wav", ".flac"}


def _is_ignored(root: Path, p: Path, patterns: List[str]) -> bool:
    """Match ignore globs relative to root (supports **)."""
    if not patterns:
        return False
    rel = p.relative_to(root).as_posix()
    for pat in patterns:
        # allow CSV passing to be split by caller already
        if fnmatch.fnmatch(rel, pat):
            return True
    return False


@dataclass
class ScanContext:
    project_root: Path
    assets_root: Path
    ignore: List[str] = field(default_factory=list)

    # Precomputed sets
    all_files: Set[Path] = field(default_factory=set)
    image_files: Set[Path] = field(default_factory=set)
    sound_files: Set[Path] = field(default_factory=set)
    rpy_files: Set[Path] = field(default_factory=set)

    # Optionally: indices for labels/jumps (light stub here)
    labels: Set[str] = field(default_factory=set)
    jump_targets: Set[str] = field(default_factory=set)

    @classmethod
    def build(
        cls,
        project_root: str | Path,
        assets_root: str | Path,
        ignore: Iterable[str] = (),
    ):
        root = Path(project_root).resolve()
        assets = Path(assets_root).resolve()
        patterns = [p.strip() for pat in ignore for p in pat.split(",") if p.strip()]

        ctx = cls(project_root=root, assets_root=assets, ignore=patterns)

        # Walk once
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            if _is_ignored(root, p, ctx.ignore):
                continue

            ctx.all_files.add(p)
            if p.suffix.lower() in {".rpy"}:
                ctx.rpy_files.add(p)

        # Assets on disk
        for p in assets.rglob("*"):
            if not p.is_file():
                continue
            if _is_ignored(assets, p, ctx.ignore):
                continue

            ext = p.suffix.lower()
            if ext in IMG_EXTS:
                ctx.image_files.add(p)
            elif ext in SND_EXTS:
                ctx.sound_files.add(p)

        # (Optional) populate labels/jumps here if you have parsers
        # ctx.labels = parse_labels(ctx.rpy_files)
        # ctx.jump_targets = parse_jumps(ctx.rpy_files)

        return ctx
