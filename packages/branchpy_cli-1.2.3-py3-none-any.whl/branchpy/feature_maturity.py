"""
Feature Maturity Registry — BranchPy v1.2.2+

SOP §3.13.3: Feature maturity tags must be declared in a config constant or
feature registry — not hardcoded per surface. The UI must filter by channel
using the maturity tag, not via named exceptions.

Channel rules (SOP §3.13.3):
  release-grade  → stable surfaces only
  pre-release    → stable + beta
  dev            → stable + beta + dev_internal

Usage:
    from branchpy.feature_maturity import surface_maturity, is_surface_visible

    if not is_surface_visible("semantics_v2"):
        print("Not available in this channel.", file=sys.stderr)
        return 1
"""

import os

# Maturity levels — ordered from most to least stable
STABLE = "stable"
BETA = "beta"
DEV_INTERNAL = "dev_internal"

# Surface registry: map surface name → maturity level
# This is the authoritative list for SOP §3.13.3 Gate 3.
# Closed in: docs/Current Version/GAP_ANALYSIS_v1.2.2_2026-04-19.md (GAP-DB, P3 stubs)
SURFACE_REGISTRY: dict[str, str] = {
    # ── Stable surfaces (release-grade in v1.2.2) ──────────────────────────
    "analyze": STABLE,
    "pilot": STABLE,
    "flowchart": STABLE,
    "media": STABLE,
    "l10n": STABLE,
    "doctor": STABLE,
    "compare": STABLE,
    "projects": STABLE,
    "license": STABLE,
    # ── Beta surfaces (hidden in stable channel) ────────────────────────────
    "omega": BETA,
    "flowchart_plus": BETA,
    # ── Dev-internal surfaces (hidden in stable and pre-release channels) ───
    "semantics_v2": DEV_INTERNAL,  # Full implementation pending; CLI stub in v1.2.2
    "hub": DEV_INTERNAL,  # Cloud hub not yet implemented
    "audit_sink": DEV_INTERNAL,  # Remote audit sink not yet implemented
    "cfg_builder": DEV_INTERNAL,  # Semantic CFG builder stub (v0.9.4 legacy)
}

# Channel from environment; defaults to 'stable' to be safe in production
_CHANNEL = os.environ.get("BRANCHPY_CHANNEL", STABLE).lower()

_CHANNEL_VISIBILITY: dict[str, set[str]] = {
    STABLE: {STABLE},
    "pre-release": {STABLE, BETA},
    "dev": {STABLE, BETA, DEV_INTERNAL},
}


def get_channel() -> str:
    """Return the current release channel."""
    return _CHANNEL


def surface_maturity(surface: str) -> str:
    """Return the maturity level for a surface, defaulting to stable if unknown."""
    return SURFACE_REGISTRY.get(surface, STABLE)


def is_surface_visible(surface: str) -> bool:
    """Return True if the surface is visible in the current channel."""
    maturity = surface_maturity(surface)
    visible_maturities = _CHANNEL_VISIBILITY.get(_CHANNEL, {STABLE})
    return maturity in visible_maturities
