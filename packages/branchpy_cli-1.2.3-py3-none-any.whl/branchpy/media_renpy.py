"""
BranchPy Media Intelligence - Ren'Py Media Extractor
Version: v0.9.0 - Phase A (MVP)

This module implements the Ren'Py-specific media extraction logic for the
Media Intelligence feature. It extracts media references from:

Phase A (MVP - Implemented):
- Script statements: scene, show, hide, with
- Audio: play/queue/stop on all channels (music, sound, voice, movie, custom)
- Screen definitions: add, imagebutton, imagemap
- Displayables: Movie(...), Animation(...), Image(...), etc.
- Python API: renpy.show/hide, renpy.music.*, renpy.movie_cutscene
- Image definitions: image, layeredimage, renpy.image()

Phase B (PFI Inference - Future):
- Call graph propagation for via_function tracking
- Confidence=inferred for media used in called functions

Dynamic path handling:
- f-strings: f"images/{character}.png"
- .format(): "images/{}.png".format(name)
- % formatting: "images/%s.png" % var
- Extracts template_path and variables list
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional

from branchpy import logs
from branchpy.media_analyzer import (
    MediaAction,
    MediaConfidence,
    MediaConfig,
    MediaEngine,
    MediaExtractor,
    MediaKind,
    MediaRef,
    detect_dynamic_path,
)

# ============================================================================
# REGEX PATTERNS - Ren'Py Statement Detection
# ============================================================================

# Label definitions
LABEL_RE = re.compile(
    r"^\s*label\s+([A-Za-z_]\w*)\s*(?:\(.*?\))?\s*:\s*$", re.MULTILINE
)

# Image operations
SCENE_RE = re.compile(r"^\s*scene\s+([^\s:]+)", re.MULTILINE)
SHOW_RE = re.compile(r"^\s*show\s+([^\s:]+)", re.MULTILINE)
HIDE_RE = re.compile(r"^\s*hide\s+([^\s]+)", re.MULTILINE)

# Audio operations - supports all channels
# Examples: "play music "song.ogg"", "play sound "sfx.wav" fadein 1.0"
PLAY_RE = re.compile(r'^\s*play\s+(\w+)\s+["\']([^"\']+)["\']', re.MULTILINE)
QUEUE_RE = re.compile(r'^\s*queue\s+(\w+)\s+["\']([^"\']+)["\']', re.MULTILINE)
STOP_RE = re.compile(r"^\s*stop\s+(\w+)", re.MULTILINE)

# Image definitions
IMAGE_DEF_RE = re.compile(
    r'^\s*image\s+([^\s=]+)\s*=\s*["\']?([^"\':\n]+)', re.MULTILINE
)
LAYERED_IMAGE_RE = re.compile(r"^\s*layeredimage\s+([^\s:]+)\s*:", re.MULTILINE)

# Screen elements
SCREEN_DEF_RE = re.compile(
    r"^\s*screen\s+([A-Za-z_]\w*)\s*(?:\(.*?\))?\s*:", re.MULTILINE
)
ADD_RE = re.compile(r'^\s*add\s+["\']([^"\']+)["\']', re.MULTILINE)
IMAGEBUTTON_RE = re.compile(
    r'^\s*imagebutton\s+.*?(?:idle|hover|selected_idle|selected_hover)\s+["\']([^"\']+)["\']',
    re.MULTILINE,
)

# Python API calls
RENPY_SHOW_RE = re.compile(r'renpy\.show\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE)
RENPY_HIDE_RE = re.compile(r'renpy\.hide\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE)
RENPY_MUSIC_PLAY_RE = re.compile(
    r'renpy\.music\.play\s*\(\s*["\']([^"\']+)["\'](?:\s*,\s*channel\s*=\s*["\']([^"\']+)["\'])?',
    re.MULTILINE,
)
RENPY_MUSIC_QUEUE_RE = re.compile(
    r'renpy\.music\.queue\s*\(\s*["\']([^"\']+)["\'](?:\s*,\s*channel\s*=\s*["\']([^"\']+)["\'])?',
    re.MULTILINE,
)
RENPY_MUSIC_STOP_RE = re.compile(
    r'renpy\.music\.stop\s*\(\s*(?:channel\s*=\s*)?["\']([^"\']+)["\']', re.MULTILINE
)
RENPY_MOVIE_RE = re.compile(
    r'renpy\.movie_cutscene\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE
)

# Displayable constructors
MOVIE_RE = re.compile(r'Movie\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE)
ANIMATION_RE = re.compile(r'Animation\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE)
IMAGE_CLASS_RE = re.compile(r'Image\s*\(\s*["\']([^"\']+)["\']', re.MULTILINE)

# Dynamic path patterns (f-strings, format, % formatting)
FSTRING_RE = re.compile(r'f["\']([^"\']*\{[^}]+\}[^"\']*)["\']')
FORMAT_RE = re.compile(r'["\']([^"\']*\{\}[^"\']*)["\']\.format\s*\(([^)]+)\)')
PERCENT_RE = re.compile(r'["\']([^"\']*%s[^"\']*)["\']\\s*%\s*(\w+)')


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def _read_text(path: Path) -> str:
    """Read text file with encoding fallback"""
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="latin-1", errors="ignore")


def _extract_variables_from_fstring(template: str) -> List[str]:
    """
    Extract variable names from f-string template
    Example: "images/{character}_{mood}.png" -> ["character", "mood"]
    """
    var_pattern = re.compile(r"\{([A-Za-z_]\w*)[^}]*\}")
    return var_pattern.findall(template)


def _normalize_image_path(image_tag: str, config: MediaConfig) -> str:
    """
    Normalize Ren'Py image tag to file path

    Ren'Py image tags use spaces: "eileen happy" -> "images/eileen happy.png"
    Also handles "bg forest" -> "images/bg/forest.png" convention

    Returns:
        Normalized path (may still need resolution against game directory)
    """
    # Replace spaces with underscores for file lookup
    normalized = image_tag.replace(" ", "_")

    # Check if it looks like a path already
    if "/" in normalized or "\\" in normalized:
        return normalized

    # Common conventions:
    # - bg_forest -> images/bg/forest.png
    # - eileen_happy -> images/eileen_happy.png
    if normalized.startswith("bg_"):
        parts = normalized[3:].split("_", 1)
        if len(parts) == 1:
            return f"images/bg/{parts[0]}.png"
        else:
            return f"images/bg/{parts[0]}_{parts[1]}.png"

    # Default: assume images/ directory
    return f"images/{normalized}.png"


def _get_current_label(text: str, line_num: int) -> Optional[str]:
    """
    Find the label that contains a given line number

    Args:
        text: Full file text
        line_num: Target line number (1-indexed)

    Returns:
        Label name or None if not inside a label
    """
    lines = text.splitlines()
    if line_num < 1 or line_num > len(lines):
        return None

    # Walk backwards from line_num to find the closest label definition
    for i in range(line_num - 1, -1, -1):
        match = LABEL_RE.match(lines[i])
        if match:
            return match.group(1)

    return None


# ============================================================================
# RENPY MEDIA EXTRACTOR
# ============================================================================


class RenpyMediaExtractor(MediaExtractor):
    """
    Ren'Py media extractor - Phase A MVP implementation

    Extracts media references from Ren'Py script files (.rpy) by:
    1. Scanning for script statements (scene/show/hide, play/queue/stop)
    2. Parsing image definitions (image, layeredimage)
    3. Detecting Python API calls (renpy.show, renpy.music.play, etc.)
    4. Analyzing screen definitions (add, imagebutton, imagemap)
    5. Recognizing displayable constructors (Movie, Animation, Image)
    6. Handling dynamic paths (f-strings, .format(), % formatting)
    """

    def __init__(self, config: MediaConfig):
        super().__init__(config)
        self.project_path: Optional[Path] = None
        self.file_to_labels: Dict[str, List[str]] = {}

    def extract(self, project_path: Path) -> List[MediaRef]:
        """
        Extract all media references from a Ren'Py project

        Args:
            project_path: Root directory of the Ren'Py project

        Returns:
            List of MediaRef objects
        """
        self.project_path = project_path
        self.media_refs = []
        self.summary.total = 0

        logs.info("media.extract", f"Starting Ren'Py media extraction: {project_path}")

        # Scan all .rpy files
        rpy_files = list(project_path.rglob("*.rpy"))
        logs.debug("media.extract", f"Found {len(rpy_files)} .rpy files")

        for rpy_file in rpy_files:
            try:
                self._process_file(rpy_file)
            except Exception as e:
                logs.error(
                    "media.extract", f"Failed to process {rpy_file}: {e}", exc_info=True
                )
                continue

        logs.info(
            "media.extract",
            f"Extraction complete: {len(self.media_refs)} media references found",
        )

        return self.media_refs

    def _process_file(self, file_path: Path) -> None:
        """Process a single .rpy file for media references"""
        try:
            text = _read_text(file_path)
        except Exception as e:
            logs.warning("media.extract", f"Could not read {file_path}: {e}")
            return

        if not self.project_path:
            logs.error("media.extract", "project_path is None")
            return

        rel_path = str(file_path.relative_to(self.project_path))

        # Build label map for this file
        labels = LABEL_RE.findall(text)
        self.file_to_labels[rel_path] = labels

        # Extract from different statement types
        self._extract_scene_statements(text, rel_path)
        self._extract_show_statements(text, rel_path)
        self._extract_hide_statements(text, rel_path)
        self._extract_audio_statements(text, rel_path)
        self._extract_image_definitions(text, rel_path)

        if self.config.screens_enabled:
            self._extract_screen_elements(text, rel_path)

        self._extract_python_api(text, rel_path)
        self._extract_displayables(text, rel_path)

    def _extract_scene_statements(self, text: str, file_path: str) -> None:
        """Extract scene statements: scene bg forest"""
        for match in SCENE_RE.finditer(text):
            image_tag = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            # Normalize image tag to path
            resolved_path = _normalize_image_path(image_tag, self.config)

            # Check if dynamic
            is_dynamic, template, vars_list = detect_dynamic_path(image_tag)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.SHOW,
                    None,
                    None,
                    resolved_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.SHOW,
                channel=None,
                target=image_tag,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=resolved_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

    def _extract_show_statements(self, text: str, file_path: str) -> None:
        """Extract show statements: show eileen happy"""
        for match in SHOW_RE.finditer(text):
            image_tag = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            resolved_path = _normalize_image_path(image_tag, self.config)
            is_dynamic, template, vars_list = detect_dynamic_path(image_tag)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.SHOW,
                    image_tag,
                    None,
                    resolved_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.SHOW,
                channel=None,
                target=image_tag,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=resolved_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

    def _extract_hide_statements(self, text: str, file_path: str) -> None:
        """Extract hide statements: hide eileen"""
        for match in HIDE_RE.finditer(text):
            image_tag = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.HIDE,
                    image_tag,
                    None,
                    None,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.HIDE,
                channel=None,
                target=image_tag,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=None,  # Hide doesn't need path resolution
                template_path=None,
                variables=[],
                via_function=None,
                confidence=MediaConfidence.EXACT,
            )

            self.add_media_ref(media_ref)

    def _extract_audio_statements(self, text: str, file_path: str) -> None:
        """
        Extract audio statements: play/queue/stop on all channels
        Supports: music, sound, voice, movie, and custom channels
        """
        # Play statements
        for match in PLAY_RE.finditer(text):
            channel = match.group(1)
            audio_path = match.group(2)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            # Determine media kind from channel
            if channel == "movie":
                kind = MediaKind.VIDEO
            else:
                kind = MediaKind.AUDIO

            is_dynamic, template, vars_list = detect_dynamic_path(audio_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    kind,
                    MediaAction.PLAY,
                    None,
                    channel,
                    audio_path,
                ),
                engine=MediaEngine.RENPY,
                kind=kind,
                action=MediaAction.PLAY,
                channel=channel,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=audio_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # Queue statements
        for match in QUEUE_RE.finditer(text):
            channel = match.group(1)
            audio_path = match.group(2)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            kind = MediaKind.VIDEO if channel == "movie" else MediaKind.AUDIO
            is_dynamic, template, vars_list = detect_dynamic_path(audio_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    kind,
                    MediaAction.PLAY,
                    None,
                    channel,
                    audio_path,
                ),
                engine=MediaEngine.RENPY,
                kind=kind,
                action=MediaAction.PLAY,  # Queue is a variant of play
                channel=channel,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=audio_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # Stop statements (no path, just channel)
        for match in STOP_RE.finditer(text):
            channel = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            kind = MediaKind.VIDEO if channel == "movie" else MediaKind.AUDIO

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    kind,
                    MediaAction.STOP,
                    None,
                    channel,
                    None,
                ),
                engine=MediaEngine.RENPY,
                kind=kind,
                action=MediaAction.STOP,
                channel=channel,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=None,
                template_path=None,
                variables=[],
                via_function=None,
                confidence=MediaConfidence.EXACT,
            )

            self.add_media_ref(media_ref)

    def _extract_image_definitions(self, text: str, file_path: str) -> None:
        """
        Extract image definitions: image eileen happy = "images/eileen_happy.png"
        """
        for match in IMAGE_DEF_RE.finditer(text):
            image_name = match.group(1)
            image_path = match.group(2)
            line_num = text[: match.start()].count("\n") + 1

            # Image definitions are typically at module level, not in labels
            label = _get_current_label(text, line_num)

            is_dynamic, template, vars_list = detect_dynamic_path(image_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.DEFINE,
                    image_name,
                    None,
                    image_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.DEFINE,
                channel=None,
                target=image_name,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=image_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # Layeredimage definitions (complex, but at least capture the tag)
        for match in LAYERED_IMAGE_RE.finditer(text):
            image_name = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            # Layeredimage doesn't have a simple path, mark as OTHER
            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.OTHER,
                    MediaAction.DEFINE,
                    image_name,
                    None,
                    None,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.OTHER,
                action=MediaAction.DEFINE,
                channel=None,
                target=image_name,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=None,
                template_path=None,
                variables=[],
                via_function=None,
                confidence=MediaConfidence.EXACT,
            )

            self.add_media_ref(media_ref)

    def _extract_screen_elements(self, text: str, file_path: str) -> None:
        """
        Extract media from screen definitions
        - add "image.png"
        - imagebutton idle "button_idle.png" hover "button_hover.png"
        """
        # Find screen definitions first
        screens = {}
        for match in SCREEN_DEF_RE.finditer(text):
            screen_name = match.group(1)
            screen_start = match.start()
            screens[screen_name] = screen_start

        # Extract 'add' statements
        for match in ADD_RE.finditer(text):
            image_path = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            # Find which screen this belongs to
            screen_name = None
            for sname, sstart in screens.items():
                if match.start() > sstart:
                    screen_name = sname

            is_dynamic, template, vars_list = detect_dynamic_path(image_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.SHOW,
                    screen_name,
                    None,
                    image_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.SHOW,
                channel=None,
                target=screen_name,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=image_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # Extract imagebutton states
        for match in IMAGEBUTTON_RE.finditer(text):
            image_path = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            screen_name = None
            for sname, sstart in screens.items():
                if match.start() > sstart:
                    screen_name = sname

            is_dynamic, template, vars_list = detect_dynamic_path(image_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.SHOW,
                    screen_name,
                    None,
                    image_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.SHOW,
                channel=None,
                target=screen_name,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=image_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

    def _extract_python_api(self, text: str, file_path: str) -> None:
        """
        Extract Python API calls:
        - renpy.show("eileen happy")
        - renpy.hide("eileen")
        - renpy.music.play("song.ogg", channel="music")
        - renpy.movie_cutscene("intro.webm")
        """
        # renpy.show
        for match in RENPY_SHOW_RE.finditer(text):
            image_tag = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            resolved_path = _normalize_image_path(image_tag, self.config)
            is_dynamic, template, vars_list = detect_dynamic_path(image_tag)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.SHOW,
                    image_tag,
                    None,
                    resolved_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.SHOW,
                channel=None,
                target=image_tag,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=resolved_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # renpy.hide
        for match in RENPY_HIDE_RE.finditer(text):
            image_tag = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.HIDE,
                    image_tag,
                    None,
                    None,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.HIDE,
                channel=None,
                target=image_tag,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=None,
                template_path=None,
                variables=[],
                via_function=None,
                confidence=MediaConfidence.EXACT,
            )

            self.add_media_ref(media_ref)

        # renpy.music.play
        for match in RENPY_MUSIC_PLAY_RE.finditer(text):
            audio_path = match.group(1)
            channel = match.group(2) if match.group(2) else "music"
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            is_dynamic, template, vars_list = detect_dynamic_path(audio_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.AUDIO,
                    MediaAction.PLAY,
                    None,
                    channel,
                    audio_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.AUDIO,
                action=MediaAction.PLAY,
                channel=channel,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=audio_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # renpy.movie_cutscene
        for match in RENPY_MOVIE_RE.finditer(text):
            video_path = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            is_dynamic, template, vars_list = detect_dynamic_path(video_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.VIDEO,
                    MediaAction.PLAY,
                    None,
                    "movie",
                    video_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.VIDEO,
                action=MediaAction.PLAY,
                channel="movie",
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=video_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

    def _extract_displayables(self, text: str, file_path: str) -> None:
        """
        Extract displayable constructors:
        - Movie("video.webm")
        - Animation("frame1.png", "frame2.png", ...)
        - Image("sprite.png")
        """
        # Movie()
        for match in MOVIE_RE.finditer(text):
            video_path = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            is_dynamic, template, vars_list = detect_dynamic_path(video_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.VIDEO,
                    MediaAction.DEFINE,
                    None,
                    None,
                    video_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.VIDEO,
                action=MediaAction.DEFINE,
                channel=None,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=video_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # Animation() - extract first frame
        for match in ANIMATION_RE.finditer(text):
            image_path = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            is_dynamic, template, vars_list = detect_dynamic_path(image_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.OTHER,
                    MediaAction.DEFINE,
                    None,
                    None,
                    image_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.OTHER,  # Animation is a composite
                action=MediaAction.DEFINE,
                channel=None,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=image_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)

        # Image()
        for match in IMAGE_CLASS_RE.finditer(text):
            image_path = match.group(1)
            line_num = text[: match.start()].count("\n") + 1
            label = _get_current_label(text, line_num)

            is_dynamic, template, vars_list = detect_dynamic_path(image_path)

            media_ref = MediaRef(
                id=MediaRef.generate_id(
                    MediaEngine.RENPY,
                    file_path,
                    line_num,
                    MediaKind.IMAGE,
                    MediaAction.DEFINE,
                    None,
                    None,
                    image_path,
                ),
                engine=MediaEngine.RENPY,
                kind=MediaKind.IMAGE,
                action=MediaAction.DEFINE,
                channel=None,
                target=None,
                source_file=file_path,
                source_line=line_num,
                label=label,
                resolved_path=image_path if not is_dynamic else None,
                template_path=template,
                variables=vars_list,
                via_function=None,
                confidence=(
                    MediaConfidence.DYNAMIC if is_dynamic else MediaConfidence.EXACT
                ),
            )

            self.add_media_ref(media_ref)
