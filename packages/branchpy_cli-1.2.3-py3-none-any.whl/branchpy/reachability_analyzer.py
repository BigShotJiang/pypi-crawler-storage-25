"""
Reachability Analyzer
Phase 5: Story Structure & Completeness Validation - R01 Rules

Implements:
- R01-001: Unreachable Labels
- R01-002: Dead-End Labels
- R01-003: Orphaned Content
- R01-004: Circular Loops
- R01-005: Unreachable Branches
"""

from collections import deque
from typing import Any, Dict, List, Optional, Set, Tuple

from branchpy.story_graph import ReachabilityResult, StoryGraph


class ReachabilityAnalyzer:
    """
    Analyzes story graph for reachability issues.

    Uses BFS traversal to identify unreachable labels, dead ends,
    and circular loops.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.start_label = "start"

    def analyze(self, graph: StoryGraph) -> ReachabilityResult:
        """
        Run complete reachability analysis.

        Args:
            graph: Story graph to analyze

        Returns:
            Complete reachability analysis results
        """
        # Compute reachable set from start
        reachable = self.compute_reachability(graph, self.start_label)

        # Find unreachable labels
        all_labels = graph.get_all_labels()
        unreachable = all_labels - reachable

        # Find dead-end labels (reachable but no exit)
        dead_ends = self.find_dead_ends(graph, reachable)

        # Detect circular loops
        circular_loops = self.detect_circular_loops(graph)

        # Calculate coverage
        coverage_percentage = (
            (len(reachable) / len(all_labels) * 100) if all_labels else 0.0
        )

        # Build result
        result = ReachabilityResult(
            reachable_labels=reachable,
            unreachable_labels=unreachable,
            dead_end_labels=dead_ends,
            coverage_percentage=coverage_percentage,
            total_labels=len(all_labels),
            circular_loops=circular_loops,
        )

        return result

    def compute_reachability(self, graph: StoryGraph, start: str = "start") -> Set[str]:
        """
        Compute all labels reachable from start using BFS.

        Algorithm:
        1. Initialize queue with start label
        2. For each label, explore all successors
        3. Mark visited to avoid cycles
        4. Continue until queue empty

        Time Complexity: O(V + E) where V=labels, E=transitions

        Args:
            graph: Story graph
            start: Starting label (default: "start")

        Returns:
            Set of reachable label names
        """
        if not graph.has_label(start):
            return set()

        visited = set()
        queue = deque([start])

        while queue:
            current = queue.popleft()

            if current in visited:
                continue

            visited.add(current)

            # Get all successor labels
            successors = graph.get_successors(current)

            for successor in successors:
                if successor not in visited and graph.has_label(successor):
                    queue.append(successor)

        return visited

    def find_dead_ends(self, graph: StoryGraph, reachable: Set[str]) -> Set[str]:
        """
        Find labels that are reachable but have no outgoing transitions.

        A dead-end is a label that:
        - Is reachable from start
        - Has no outgoing edges (jumps, calls, returns)
        - Is NOT a terminal/ending label (those are intentional)

        Args:
            graph: Story graph
            reachable: Set of reachable labels

        Returns:
            Set of dead-end label names
        """
        dead_ends = set()
        terminal_labels = graph.get_terminal_labels()

        for label in reachable:
            # Skip terminal labels (they're supposed to have no exit)
            if label in terminal_labels:
                continue

            # Check if label has any outgoing transitions
            successors = graph.get_successors(label)

            if len(successors) == 0:
                # No outgoing edges and not a terminal = dead end
                node = graph.get_label(label)
                if node and not node.has_return:
                    dead_ends.add(label)

        return dead_ends

    def detect_circular_loops(self, graph: StoryGraph) -> List[List[str]]:
        """
        Detect strongly connected components (circular loops) in the graph.

        Uses Tarjan's algorithm to find cycles without exit conditions.

        Args:
            graph: Story graph

        Returns:
            List of cycles, where each cycle is a list of label names
        """
        # Tarjan's SCC algorithm
        index_counter = [0]
        stack: List[str] = []
        lowlinks: Dict[str, int] = {}
        index: Dict[str, int] = {}
        on_stack: Dict[str, bool] = {}
        sccs: List[List[str]] = []

        def strongconnect(label: str) -> None:
            index[label] = index_counter[0]
            lowlinks[label] = index_counter[0]
            index_counter[0] += 1
            stack.append(label)
            on_stack[label] = True

            # Consider successors
            for successor in graph.get_successors(label):
                if successor not in index:
                    strongconnect(successor)
                    lowlinks[label] = min(lowlinks[label], lowlinks[successor])
                elif on_stack.get(successor, False):
                    lowlinks[label] = min(lowlinks[label], index[successor])

            # If label is a root node, pop the stack to get SCC
            if lowlinks[label] == index[label]:
                scc = []
                while True:
                    w = stack.pop()
                    on_stack[w] = False
                    scc.append(w)
                    if w == label:
                        break

                # Only report cycles with more than 1 node (actual loops)
                if len(scc) > 1:
                    sccs.append(scc)

        # Run algorithm on all labels
        for label in graph.get_all_labels():
            if label not in index:
                strongconnect(label)

        # Filter out cycles that have exit conditions
        # (for now, report all SCCs - exit condition detection is complex)
        return sccs

    def find_unreachable_branches(self, graph: StoryGraph) -> List[Tuple[str, str]]:
        """
        Find conditional branches that can never be true (R01-005).

        This requires integration with Phase 3 variable tracking.

        Args:
            graph: Story graph

        Returns:
            List of (label, condition) tuples for unreachable branches
        """
        unreachable_branches = []

        # For each conditional edge
        for edge in graph.edges:
            if edge.is_conditional and edge.condition:
                # TODO: Integrate with Phase 3 variable range analysis
                # For now, basic heuristic checks

                # Check for obviously impossible conditions
                if self._is_impossible_condition(edge.condition):
                    unreachable_branches.append((edge.from_label, edge.condition))

        return unreachable_branches

    def _is_impossible_condition(self, condition: str) -> bool:
        """
        Basic heuristic to detect impossible conditions.

        More sophisticated analysis requires Phase 3 integration.

        Args:
            condition: Condition expression

        Returns:
            True if condition is obviously impossible
        """
        # Simple heuristics
        impossible_patterns = [
            "False",
            "0 == 1",
            "1 == 2",
            "True and False",
        ]

        return any(pattern in condition for pattern in impossible_patterns)

    def find_potential_entry_points(
        self, graph: StoryGraph, unreachable_label: str
    ) -> List[str]:
        """
        Suggest labels that could potentially jump to an unreachable label.

        Uses heuristics:
        - Labels in same file
        - Labels close in line number
        - Labels with no outgoing edges

        Args:
            graph: Story graph
            unreachable_label: Label to find entry points for

        Returns:
            List of suggested entry point label names
        """
        label = graph.get_label(unreachable_label)
        if not label:
            return []

        suggestions = []

        # Look for labels in the same file
        for other_name, other_label in graph.nodes.items():
            if other_label.location.file == label.location.file:
                # Check if close in line number
                line_distance = abs(other_label.location.line - label.location.line)

                if line_distance < 50:
                    # Prefer labels with no outgoing edges (might need a jump)
                    if len(graph.get_successors(other_name)) == 0:
                        suggestions.append(other_name)

        return suggestions[:3]  # Top 3 suggestions


# Convenience function
def analyze_reachability(
    graph: StoryGraph, config: Optional[Dict[str, Any]] = None
) -> ReachabilityResult:
    """Convenience function to run reachability analysis"""
    analyzer = ReachabilityAnalyzer(config)
    return analyzer.analyze(graph)
