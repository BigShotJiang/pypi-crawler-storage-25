# branchpy/watcher.py
# File system watcher wrapper for BranchPy watch mode
import queue
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Set


class FileWatcher:
    """
    A simple polling-based file system watcher that monitors specific patterns.
    """

    def __init__(self, root_path: Path, patterns: List[str], debounce_ms: int = 300):
        self.root_path = Path(root_path).resolve()
        self.patterns = patterns
        self.debounce_ms = debounce_ms
        self.change_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._thread = None
        self._file_mtimes: Dict[str, float] = {}

    def start(self) -> None:
        """Start watching for file changes."""
        # Initialize file modification times
        self._scan_files()

        # Start polling thread
        self._thread = threading.Thread(target=self._poll_worker, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop watching for file changes."""
        self._stop_event.set()
        if self._thread:
            self._thread.join()

    def get_next_change(self, timeout: Optional[float] = None) -> Optional[str]:
        """
        Get the next debounced file change.
        Returns the path of the changed file, or None if timeout expires.
        """
        try:
            return self.change_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def _poll_worker(self) -> None:
        """Background worker that polls for file changes."""
        last_change_time = 0
        pending_changes: Set[str] = set()

        while not self._stop_event.is_set():
            try:
                # Check for file changes
                changed_files = self._check_for_changes()
                if changed_files:
                    pending_changes.update(changed_files)
                    last_change_time = time.time()

                # Check if debounce period has elapsed
                if (
                    pending_changes
                    and (time.time() - last_change_time) * 1000 >= self.debounce_ms
                ):
                    # Emit a single change event (just pick the first one)
                    change_path = next(iter(pending_changes))
                    self.change_queue.put(change_path)
                    pending_changes.clear()

                time.sleep(0.5)  # Poll every 500ms

            except Exception:
                # Ignore errors in poll worker
                continue

    def _scan_files(self) -> None:
        """Scan all files matching patterns and record their modification times."""
        self._file_mtimes.clear()

        for pattern in self.patterns:
            if pattern == "**/*.rpy":
                # Find all .rpy files
                for rpy_file in self.root_path.rglob("*.rpy"):
                    if rpy_file.is_file():
                        try:
                            self._file_mtimes[str(rpy_file)] = rpy_file.stat().st_mtime
                        except (OSError, FileNotFoundError):
                            pass
            elif pattern == "assets/**":
                # Find all files in assets directory
                assets_dir = self.root_path / "assets"
                if assets_dir.exists():
                    for asset_file in assets_dir.rglob("*"):
                        if asset_file.is_file():
                            try:
                                self._file_mtimes[str(asset_file)] = (
                                    asset_file.stat().st_mtime
                                )
                            except (OSError, FileNotFoundError):
                                pass
            elif pattern == "game/**":
                # Find all files in game directory
                game_dir = self.root_path / "game"
                if game_dir.exists():
                    for game_file in game_dir.rglob("*"):
                        if game_file.is_file():
                            try:
                                self._file_mtimes[str(game_file)] = (
                                    game_file.stat().st_mtime
                                )
                            except (OSError, FileNotFoundError):
                                pass
            elif pattern == ".branchpy.toml":
                # Check config file
                config_file = self.root_path / ".branchpy.toml"
                if config_file.exists():
                    try:
                        self._file_mtimes[str(config_file)] = (
                            config_file.stat().st_mtime
                        )
                    except (OSError, FileNotFoundError):
                        pass

    def _check_for_changes(self) -> List[str]:
        """Check for file changes since last scan."""
        changed_files = []
        current_mtimes = {}

        # Re-scan files and compare modification times
        for pattern in self.patterns:
            if pattern == "**/*.rpy":
                for rpy_file in self.root_path.rglob("*.rpy"):
                    if rpy_file.is_file():
                        try:
                            file_path = str(rpy_file)
                            current_mtime = rpy_file.stat().st_mtime
                            current_mtimes[file_path] = current_mtime

                            if (
                                file_path not in self._file_mtimes
                                or current_mtime != self._file_mtimes[file_path]
                            ):
                                changed_files.append(file_path)
                        except (OSError, FileNotFoundError):
                            pass
            elif pattern == ".branchpy.toml":
                config_file = self.root_path / ".branchpy.toml"
                if config_file.exists():
                    try:
                        file_path = str(config_file)
                        current_mtime = config_file.stat().st_mtime
                        current_mtimes[file_path] = current_mtime

                        if (
                            file_path not in self._file_mtimes
                            or current_mtime != self._file_mtimes[file_path]
                        ):
                            changed_files.append(file_path)
                    except (OSError, FileNotFoundError):
                        pass

        # Update stored modification times
        self._file_mtimes.update(current_mtimes)

        return changed_files
