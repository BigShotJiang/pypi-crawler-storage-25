"""
Diff Export — HTML & JSON Export for Snapshot Comparisons (Enhanced v0.8.8.2)

Export diff results as:
- HTML: Interactive side-by-side visual comparison with syntax highlighting
- JSON: Machine-readable diff data for automation

v0.8.8.2 Enhancements:
- Prism.js syntax highlighting for Ren'Py code blocks
- Collapsible sections for large diffs (hide/show node groups)
- Inline comment system with localStorage persistence
- Smart filtering (hide whitespace/formatting changes)
- Export comments as JSON

Classes:
    DiffExporter: Enhanced export engine for interactive diff results

Example:
    >>> exporter = DiffExporter()
    >>> exporter.export_html(diff, "comparison.html", interactive=True)
    >>> exporter.export_json(diff, "comparison.json")
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)


class DiffExporter:
    """
    Enhanced export engine for diff results (v0.8.8.2).

    Supports:
        - HTML: Interactive visual side-by-side comparison
        - JSON: Machine-readable structured data

    Features:
        - Color-coded additions/removals/modifications
        - Responsive layout for large diffs
        - Metadata embedding
        - Pretty-print JSON
        - (v0.8.8.2) Prism.js syntax highlighting
        - (v0.8.8.2) Collapsible sections
        - (v0.8.8.2) Inline comment system
        - (v0.8.8.2) Smart filtering
    """

    # Prism.js CDN URL (offline fallback available)
    PRISM_JS_URL = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"
    PRISM_CSS_URL = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css"
    PRISM_PYTHON_URL = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"

    def export_html(
        self,
        diff: Dict[str, Any],
        output_path: str,
        include_metadata: bool = True,
        interactive: bool = True,
        enable_syntax_highlight: bool = True,
        enable_comments: bool = True,
    ) -> None:
        """
        Export diff as HTML with optional interactive features.

        Args:
            diff: Diff dictionary from DiffEngine.compare()
            output_path: Output file path
            include_metadata: Include snapshot metadata in HTML
            interactive: Enable v0.8.8.2 interactive features (collapsible, filters)
            enable_syntax_highlight: Enable Prism.js syntax highlighting
            enable_comments: Enable inline comment system

        Example:
            >>> diff = DiffEngine.compare(snap1, snap2)
            >>> exporter = DiffExporter()
            >>> exporter.export_html(diff, "comparison.html", interactive=True)
        """
        summary = diff.get("summary", {})
        cfg_changes = diff.get("cfg_changes", {})
        stats_changes = diff.get("stats_changes", {})
        asset_changes = diff.get("asset_changes", {})

        # Generate interactive or static HTML
        if interactive:
            html = self._generate_interactive_html(
                diff,
                summary,
                cfg_changes,
                stats_changes,
                asset_changes,
                enable_syntax_highlight,
                enable_comments,
            )
        else:
            # Legacy static HTML (backward compatible)
            html = self._generate_static_html(
                diff, summary, cfg_changes, stats_changes, asset_changes
            )

        Path(output_path).write_text(html, encoding="utf-8")
        logger.info(
            f"Exported {'interactive' if interactive else 'static'} HTML diff to {output_path}"
        )

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_history_event(
                "DIFF_EXPORTED",
                None,
                {
                    "format": "html",
                    "output_path": output_path,
                    "snapshot_before": diff.get("snapshot_before"),
                    "snapshot_after": diff.get("snapshot_after"),
                    "interactive": interactive,
                },
            )
        except Exception as e:
            logger.warning(f"Failed to log diff export to governance: {e}")

    def _generate_interactive_html(
        self,
        diff: Dict[str, Any],
        summary: Dict[str, Any],
        cfg_changes: Dict[str, Any],
        stats_changes: Dict[str, Any],
        asset_changes: Dict[str, Any],
        enable_syntax_highlight: bool,
        enable_comments: bool,
    ) -> str:
        """Generate interactive HTML with v0.8.8.2 features."""
        # Prism.js includes (if enabled)
        prism_includes = ""
        if enable_syntax_highlight:
            prism_includes = f"""
    <link href="{self.PRISM_CSS_URL}" rel="stylesheet">
    <script src="{self.PRISM_JS_URL}"></script>
    <script src="{self.PRISM_PYTHON_URL}"></script>
    """

        # Comment system CSS/JS (if enabled)
        comment_system = ""
        if enable_comments:
            comment_system = self._get_comment_system_code()

        return f"""<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Snapshot Diff: {diff.get('snapshot_before', 'N/A')} → {diff.get('snapshot_after', 'N/A')}</title>
    {prism_includes}
    <style>
        * {{ box-sizing: border-box; }}
        body {{ 
            font-family: ui-monospace, 'Cascadia Code', 'SF Mono', monospace; 
            padding: 20px; 
            max-width: 1400px; 
            margin: 0 auto;
            background: #fafafa;
        }}
        h1 {{ color: #333; border-bottom: 3px solid #007acc; padding-bottom: 10px; }}
        h2 {{ color: #555; margin-top: 30px; }}
        h3 {{ 
            color: #666; 
            font-size: 1.1rem; 
            margin-top: 20px; 
            cursor: pointer;
            user-select: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        h3:hover {{ background: #f0f0f0; padding: 5px; border-radius: 4px; }}
        h3 .toggle-icon {{
            display: inline-block;
            transition: transform 0.2s;
            font-size: 0.9rem;
        }}
        h3.collapsed .toggle-icon {{
            transform: rotate(-90deg);
        }}
        .collapsible-content {{
            max-height: 2000px;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }}
        .collapsible-content.collapsed {{
            max-height: 0;
        }}
        .summary {{ 
            background: #fff; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        .summary p {{ margin: 8px 0; }}
        .summary ul {{ margin: 10px 0; padding-left: 20px; }}
        .summary li {{ margin: 5px 0; }}
        .diff-section {{ 
            background: #fff; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .filter-toolbar {{
            background: #f4f4f4;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            display: flex;
            gap: 15px;
            align-items: center;
        }}
        .filter-checkbox {{
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .filter-checkbox input {{
            cursor: pointer;
        }}
        .filter-checkbox label {{
            cursor: pointer;
            user-select: none;
            font-size: 0.9rem;
        }}
        .diff-table {{ 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px;
        }}
        .diff-table th {{ 
            background: #333; 
            color: white; 
            padding: 12px 10px; 
            text-align: left; 
            font-weight: 600;
        }}
        .diff-table td {{ 
            border: 1px solid #ddd; 
            padding: 8px 10px; 
            vertical-align: top;
            position: relative;
        }}
        .diff-table tbody tr:hover {{ background: #f5f5f5; }}
        .diff-table tbody tr.hidden {{ display: none; }}
        .added {{ background: #d4edda; border-left: 3px solid #28a745; }}
        .removed {{ background: #f8d7da; border-left: 3px solid #dc3545; }}
        .modified {{ background: #fff3cd; border-left: 3px solid #ffc107; }}
        .badge {{ 
            display: inline-block; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 0.85rem; 
            font-weight: 600;
        }}
        .badge-success {{ background: #28a745; color: white; }}
        .badge-danger {{ background: #dc3545; color: white; }}
        .badge-warning {{ background: #ffc107; color: #333; }}
        .empty-state {{ 
            text-align: center; 
            padding: 40px; 
            color: #999; 
            font-style: italic;
        }}
        code {{ 
            background: #f4f4f4; 
            padding: 2px 6px; 
            border-radius: 3px; 
            font-size: 0.9rem;
        }}
        /* Comment system styles */
        .comment-indicator {{
            position: absolute;
            right: 5px;
            top: 5px;
            cursor: pointer;
            font-size: 16px;
            opacity: 0.3;
            transition: opacity 0.2s;
        }}
        .comment-indicator:hover {{
            opacity: 1;
        }}
        .comment-indicator.has-comment {{
            opacity: 1;
            color: #007acc;
        }}
        .comment-popup {{
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            border: 2px solid #007acc;
            border-radius: 6px;
            padding: 10px;
            min-width: 300px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            display: none;
        }}
        .comment-popup.active {{
            display: block;
        }}
        .comment-textarea {{
            width: 100%;
            min-height: 60px;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 8px;
            font-family: inherit;
            font-size: 0.9rem;
        }}
        .comment-actions {{
            margin-top: 8px;
            display: flex;
            gap: 8px;
        }}
        .comment-btn {{
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.85rem;
        }}
        .comment-btn-save {{
            background: #007acc;
            color: white;
        }}
        .comment-btn-delete {{
            background: #dc3545;
            color: white;
        }}
        .comment-btn-cancel {{
            background: #e0e0e0;
            color: #333;
        }}
    </style>
</head>
<body>
    <h1>📊 Interactive Snapshot Comparison</h1>
    
    <div class="summary">
        <h2>Summary</h2>
        <p><strong>Before:</strong> <code>{diff.get('snapshot_before', 'N/A')}</code></p>
        <p><strong>After:</strong> <code>{diff.get('snapshot_after', 'N/A')}</code></p>
        <ul>
            <li><span class="badge badge-success">{summary.get('nodes_added', 0)}</span> Nodes Added</li>
            <li><span class="badge badge-danger">{summary.get('nodes_removed', 0)}</span> Nodes Removed</li>
            <li><span class="badge badge-warning">{summary.get('nodes_modified', 0)}</span> Nodes Modified</li>
            <li><span class="badge badge-success">{summary.get('variables_added', 0)}</span> Variables Added</li>
            <li><span class="badge badge-danger">{summary.get('variables_removed', 0)}</span> Variables Removed</li>
            <li><span class="badge badge-warning">{summary.get('assets_changed', 0)}</span> Assets Changed</li>
        </ul>
    </div>
    
    <div class="filter-toolbar">
        <strong>Filters:</strong>
        <div class="filter-checkbox">
            <input type="checkbox" id="hideWhitespace" onchange="toggleFilter('whitespace')">
            <label for="hideWhitespace">Hide whitespace changes</label>
        </div>
        <div class="filter-checkbox">
            <input type="checkbox" id="hideFormatting" onchange="toggleFilter('formatting')">
            <label for="hideFormatting">Hide formatting changes</label>
        </div>
        <div class="filter-checkbox">
            <input type="checkbox" id="showOnlyCommented" onchange="toggleFilter('commented')">
            <label for="showOnlyCommented">Show only commented</label>
        </div>
    </div>
    
    <div class="diff-section">
        <h2>CFG Changes</h2>
        
        <h3 onclick="toggleSection(this)" data-section="nodesAdded">
            <span class="toggle-icon">▼</span> Nodes Added ({len(cfg_changes.get('nodes_added', []))})
        </h3>
        <div id="nodesAdded" class="collapsible-content">
            {self._render_interactive_table(cfg_changes.get('nodes_added', []), ['id', 'label', 'kind'], 'added', 'node')}
        </div>
        
        <h3 onclick="toggleSection(this)" data-section="nodesRemoved">
            <span class="toggle-icon">▼</span> Nodes Removed ({len(cfg_changes.get('nodes_removed', []))})
        </h3>
        <div id="nodesRemoved" class="collapsible-content">
            {self._render_interactive_table(cfg_changes.get('nodes_removed', []), ['id', 'label', 'kind'], 'removed', 'node')}
        </div>
        
        <h3 onclick="toggleSection(this)" data-section="nodesModified">
            <span class="toggle-icon">▼</span> Nodes Modified ({len(cfg_changes.get('nodes_modified', []))})
        </h3>
        <div id="nodesModified" class="collapsible-content">
            {self._render_interactive_table(cfg_changes.get('nodes_modified', []), ['id', 'field', 'old_value', 'new_value'], 'modified', 'node')}
        </div>
        
        <h3 onclick="toggleSection(this)" data-section="edgesAdded">
            <span class="toggle-icon">▼</span> Edges Added ({len(cfg_changes.get('edges_added', []))})
        </h3>
        <div id="edgesAdded" class="collapsible-content">
            {self._render_interactive_table(cfg_changes.get('edges_added', []), ['source', 'target', 'kind'], 'added', 'edge')}
        </div>
        
        <h3 onclick="toggleSection(this)" data-section="edgesRemoved">
            <span class="toggle-icon">▼</span> Edges Removed ({len(cfg_changes.get('edges_removed', []))})
        </h3>
        <div id="edgesRemoved" class="collapsible-content">
            {self._render_interactive_table(cfg_changes.get('edges_removed', []), ['source', 'target', 'kind'], 'removed', 'edge')}
        </div>
    </div>
    
    <div class="diff-section">
        <h2>Stats Changes</h2>
        
        <h3 onclick="toggleSection(this)" data-section="varsAdded">
            <span class="toggle-icon">▼</span> Variables Added ({len(stats_changes.get('variables_added', []))})
        </h3>
        <div id="varsAdded" class="collapsible-content">
            {self._render_interactive_table(stats_changes.get('variables_added', []), ['name', 'count'], 'added', 'variable')}
        </div>
        
        <h3 onclick="toggleSection(this)" data-section="varsRemoved">
            <span class="toggle-icon">▼</span> Variables Removed ({len(stats_changes.get('variables_removed', []))})
        </h3>
        <div id="varsRemoved" class="collapsible-content">
            {self._render_interactive_table(stats_changes.get('variables_removed', []), ['name', 'count'], 'removed', 'variable')}
        </div>
        
        <h3 onclick="toggleSection(this)" data-section="varsModified">
            <span class="toggle-icon">▼</span> Variables Modified ({len(stats_changes.get('variables_modified', []))})
        </h3>
        <div id="varsModified" class="collapsible-content">
            {self._render_interactive_table(stats_changes.get('variables_modified', []), ['name', 'old_count', 'new_count'], 'modified', 'variable')}
        </div>
    </div>
    
    <div class="diff-section">
        <h2>Asset Validation Changes</h2>
        
        <h3 onclick="toggleSection(this)" data-section="assetsChanged">
            <span class="toggle-icon">▼</span> Assets Changed ({len(asset_changes.get('results_changed', []))})
        </h3>
        <div id="assetsChanged" class="collapsible-content">
            {self._render_interactive_table(asset_changes.get('results_changed', []), ['path', 'old_status', 'new_status'], 'modified', 'asset')}
        </div>
    </div>
    
    {comment_system}
    
    <footer style="margin-top: 40px; text-align: center; color: #999; font-size: 0.9rem;">
        Generated by BranchPy v0.8.8.2 — Enhanced Interactive History
    </footer>
    
    <script>
        // Collapsible sections
        function toggleSection(header) {{
            const sectionId = header.getAttribute('data-section');
            const content = document.getElementById(sectionId);
            const isCollapsed = content.classList.contains('collapsed');
            
            if (isCollapsed) {{
                content.classList.remove('collapsed');
                header.classList.remove('collapsed');
            }} else {{
                content.classList.add('collapsed');
                header.classList.add('collapsed');
            }}
        }}
        
        // Filtering
        let activeFilters = {{
            whitespace: false,
            formatting: false,
            commented: false
        }};
        
        function toggleFilter(filterType) {{
            activeFilters[filterType] = !activeFilters[filterType];
            applyFilters();
        }}
        
        function applyFilters() {{
            const rows = document.querySelectorAll('.diff-table tbody tr');
            
            rows.forEach(row => {{
                let hide = false;
                
                // Whitespace filter (heuristic: changes with only spacing differences)
                if (activeFilters.whitespace) {{
                    const cells = Array.from(row.cells);
                    const hasOnlyWhitespace = cells.some(cell => {{
                        const text = cell.textContent;
                        return text.match(/^\\s+$/) || text.includes('  ');
                    }});
                    if (hasOnlyWhitespace) hide = true;
                }}
                
                // Formatting filter (heuristic: changes to formatting fields)
                if (activeFilters.formatting) {{
                    const cells = Array.from(row.cells);
                    const hasFormattingChange = cells.some(cell => {{
                        const text = cell.textContent.toLowerCase();
                        return text.includes('indent') || text.includes('align') || text.includes('spacing');
                    }});
                    if (hasFormattingChange) hide = true;
                }}
                
                // Commented filter (show only rows with comments)
                if (activeFilters.commented) {{
                    const hasComment = row.querySelector('.comment-indicator.has-comment');
                    if (!hasComment) hide = true;
                }}
                
                row.classList.toggle('hidden', hide);
            }});
        }}
    </script>
</body>
</html>"""

    def _generate_static_html(
        self,
        diff: Dict[str, Any],
        summary: Dict[str, Any],
        cfg_changes: Dict[str, Any],
        stats_changes: Dict[str, Any],
        asset_changes: Dict[str, Any],
    ) -> str:
        """Generate legacy static HTML (v0.8.8.1 backward compatible)."""
        # Use parameters passed in (summary, cfg_changes, etc. already extracted)
        return f"""<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Snapshot Diff: {diff.get('snapshot_before', 'N/A')} → {diff.get('snapshot_after', 'N/A')}</title>
    <style>
        * {{ box-sizing: border-box; }}
        body {{ 
            font-family: ui-monospace, 'Cascadia Code', 'SF Mono', monospace; 
            padding: 20px; 
            max-width: 1400px; 
            margin: 0 auto;
            background: #fafafa;
        }}
        h1 {{ color: #333; border-bottom: 3px solid #007acc; padding-bottom: 10px; }}
        h2 {{ color: #555; margin-top: 30px; }}
        h3 {{ color: #666; font-size: 1.1rem; margin-top: 20px; }}
        .summary {{ 
            background: #fff; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        .summary p {{ margin: 8px 0; }}
        .summary ul {{ margin: 10px 0; padding-left: 20px; }}
        .summary li {{ margin: 5px 0; }}
        .diff-section {{ 
            background: #fff; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .diff-table {{ 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px;
        }}
        .diff-table th {{ 
            background: #333; 
            color: white; 
            padding: 12px 10px; 
            text-align: left; 
            font-weight: 600;
        }}
        .diff-table td {{ 
            border: 1px solid #ddd; 
            padding: 8px 10px; 
            vertical-align: top;
        }}
        .diff-table tbody tr:hover {{ background: #f5f5f5; }}
        .added {{ background: #d4edda; border-left: 3px solid #28a745; }}
        .removed {{ background: #f8d7da; border-left: 3px solid #dc3545; }}
        .modified {{ background: #fff3cd; border-left: 3px solid #ffc107; }}
        .badge {{ 
            display: inline-block; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 0.85rem; 
            font-weight: 600;
        }}
        .badge-success {{ background: #28a745; color: white; }}
        .badge-danger {{ background: #dc3545; color: white; }}
        .badge-warning {{ background: #ffc107; color: #333; }}
        .empty-state {{ 
            text-align: center; 
            padding: 40px; 
            color: #999; 
            font-style: italic;
        }}
        code {{ 
            background: #f4f4f4; 
            padding: 2px 6px; 
            border-radius: 3px; 
            font-size: 0.9rem;
        }}
    </style>
</head>
<body>
    <h1>📊 Snapshot Comparison</h1>
    
    <div class="summary">
        <h2>Summary</h2>
        <p><strong>Before:</strong> <code>{diff.get('snapshot_before', 'N/A')}</code></p>
        <p><strong>After:</strong> <code>{diff.get('snapshot_after', 'N/A')}</code></p>
        <ul>
            <li><span class="badge badge-success">{summary.get('nodes_added', 0)}</span> Nodes Added</li>
            <li><span class="badge badge-danger">{summary.get('nodes_removed', 0)}</span> Nodes Removed</li>
            <li><span class="badge badge-warning">{summary.get('nodes_modified', 0)}</span> Nodes Modified</li>
            <li><span class="badge badge-success">{summary.get('variables_added', 0)}</span> Variables Added</li>
            <li><span class="badge badge-danger">{summary.get('variables_removed', 0)}</span> Variables Removed</li>
            <li><span class="badge badge-warning">{summary.get('assets_changed', 0)}</span> Assets Changed</li>
        </ul>
    </div>
    
    <div class="diff-section">
        <h2>CFG Changes</h2>
        
        <h3>Nodes Added ({len(cfg_changes.get('nodes_added', []))})</h3>
        {self._render_table(cfg_changes.get('nodes_added', []), ['id', 'label', 'kind'], 'added')}
        
        <h3>Nodes Removed ({len(cfg_changes.get('nodes_removed', []))})</h3>
        {self._render_table(cfg_changes.get('nodes_removed', []), ['id', 'label', 'kind'], 'removed')}
        
        <h3>Nodes Modified ({len(cfg_changes.get('nodes_modified', []))})</h3>
        {self._render_table(cfg_changes.get('nodes_modified', []), ['id', 'field', 'old_value', 'new_value'], 'modified')}
        
        <h3>Edges Added ({len(cfg_changes.get('edges_added', []))})</h3>
        {self._render_table(cfg_changes.get('edges_added', []), ['source', 'target', 'kind'], 'added')}
        
        <h3>Edges Removed ({len(cfg_changes.get('edges_removed', []))})</h3>
        {self._render_table(cfg_changes.get('edges_removed', []), ['source', 'target', 'kind'], 'removed')}
    </div>
    
    <div class="diff-section">
        <h2>Stats Changes</h2>
        
        <h3>Variables Added ({len(stats_changes.get('variables_added', []))})</h3>
        {self._render_table(stats_changes.get('variables_added', []), ['name', 'count'], 'added')}
        
        <h3>Variables Removed ({len(stats_changes.get('variables_removed', []))})</h3>
        {self._render_table(stats_changes.get('variables_removed', []), ['name', 'count'], 'removed')}
        
        <h3>Variables Modified ({len(stats_changes.get('variables_modified', []))})</h3>
        {self._render_table(stats_changes.get('variables_modified', []), ['name', 'old_count', 'new_count'], 'modified')}
    </div>
    
    <div class="diff-section">
        <h2>Asset Validation Changes</h2>
        
        <h3>Assets Changed ({len(asset_changes.get('results_changed', []))})</h3>
        {self._render_table(asset_changes.get('results_changed', []), ['path', 'old_status', 'new_status'], 'modified')}
    </div>
    
    <footer style="margin-top: 40px; text-align: center; color: #999; font-size: 0.9rem;">
        Generated by BranchPy v0.8.8.1 — Enhanced History (Static Export)
    </footer>
</body>
</html>"""

    def export_json(
        self, diff: Dict[str, Any], output_path: str, pretty: bool = True
    ) -> None:
        """
        Export diff as JSON.

        Args:
            diff: Diff dictionary from DiffEngine.compare()
            output_path: Output file path
            pretty: Pretty-print JSON (default: True)

        Example:
            >>> diff = DiffEngine.compare(snap1, snap2)
            >>> exporter = DiffExporter()
            >>> exporter.export_json(diff, "comparison.json", pretty=True)
        """
        with open(output_path, "w", encoding="utf-8") as f:
            if pretty:
                json.dump(diff, f, indent=2, sort_keys=True)
            else:
                json.dump(diff, f)

        logger.info(f"Exported JSON diff to {output_path}")

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_history_event(
                "DIFF_EXPORTED",
                None,
                {
                    "format": "json",
                    "output_path": output_path,
                    "snapshot_before": diff.get("snapshot_before"),
                    "snapshot_after": diff.get("snapshot_after"),
                },
            )
        except Exception as e:
            logger.warning(f"Failed to log diff export to governance: {e}")

    def _render_table(self, items: list, columns: list, row_class: str = "") -> str:
        """
        Render HTML table for diff items.

        Args:
            items: List of item dictionaries
            columns: Column names to display
            row_class: CSS class for rows (added/removed/modified)

        Returns:
            HTML table string
        """
        if not items:
            return '<div class="empty-state">No changes</div>'

        # Build table header
        header = (
            "<tr>"
            + "".join(f"<th>{col.replace('_', ' ').title()}</th>" for col in columns)
            + "</tr>"
        )

        # Build table rows
        rows = []
        for item in items:
            row = f"<tr class='{row_class}'>"
            for col in columns:
                value = item.get(col, "N/A")
                # Truncate long values
                if isinstance(value, str) and len(value) > 100:
                    value = value[:97] + "..."
                row += f"<td><code>{value}</code></td>"
            row += "</tr>"
            rows.append(row)

        return f"""
        <table class="diff-table">
            <thead>{header}</thead>
            <tbody>{''.join(rows)}</tbody>
        </table>
        """

    def _render_interactive_table(
        self, items: list, columns: list, row_class: str = "", item_type: str = "item"
    ) -> str:
        """
        Render interactive HTML table with comment indicators (v0.8.8.2).

        Args:
            items: List of item dictionaries
            columns: Column names to display
            row_class: CSS class for rows (added/removed/modified)
            item_type: Type of item (node/edge/variable/asset)

        Returns:
            HTML table string with comment indicators
        """
        if not items:
            return '<div class="empty-state">No changes</div>'

        # Build table header
        header = (
            "<tr>"
            + "".join(f"<th>{col.replace('_', ' ').title()}</th>" for col in columns)
            + "</tr>"
        )

        # Build table rows with comment indicators
        rows = []
        for idx, item in enumerate(items):
            item_id = f"{item_type}_{idx}_{item.get('id', item.get('name', idx))}"
            row = f"<tr class='{row_class}' data-item-id='{item_id}'>"
            for col in columns:
                value = item.get(col, "N/A")
                # Truncate long values
                if isinstance(value, str) and len(value) > 100:
                    value = value[:97] + "..."
                row += f"<td><code>{value}</code></td>"
            # Add comment indicator in last column
            row += f"""<td style="position: relative;">
                <span class="comment-indicator" onclick="toggleComment('{item_id}')">💬</span>
                <div class="comment-popup" id="comment-{item_id}">
                    <textarea class="comment-textarea" id="textarea-{item_id}" placeholder="Add your review comment..."></textarea>
                    <div class="comment-actions">
                        <button class="comment-btn comment-btn-save" onclick="saveComment('{item_id}')">Save</button>
                        <button class="comment-btn comment-btn-delete" onclick="deleteComment('{item_id}')">Delete</button>
                        <button class="comment-btn comment-btn-cancel" onclick="cancelComment('{item_id}')">Cancel</button>
                    </div>
                </div>
            </td></tr>"""
            rows.append(row)

        return f"""
        <table class="diff-table">
            <thead>{header}<th style="width: 50px;">💬</th></thead>
            <tbody>{''.join(rows)}</tbody>
        </table>
        """

    def _get_comment_system_code(self) -> str:
        """Generate JavaScript code for comment system."""
        return """
    <script>
        // Comment system using localStorage
        const COMMENTS_KEY = 'branchpy_diff_comments';
        
        function loadComments() {
            try {
                const stored = localStorage.getItem(COMMENTS_KEY);
                return stored ? JSON.parse(stored) : {};
            } catch (e) {
                console.error('Failed to load comments:', e);
                return {};
            }
        }
        
        function saveComments(comments) {
            try {
                localStorage.setItem(COMMENTS_KEY, JSON.stringify(comments));
            } catch (e) {
                console.error('Failed to save comments:', e);
            }
        }
        
        function toggleComment(itemId) {
            const popup = document.getElementById(`comment-${itemId}`);
            const isActive = popup.classList.contains('active');
            
            // Close all popups
            document.querySelectorAll('.comment-popup').forEach(p => p.classList.remove('active'));
            
            if (!isActive) {
                popup.classList.add('active');
                
                // Load existing comment
                const comments = loadComments();
                const textarea = document.getElementById(`textarea-${itemId}`);
                textarea.value = comments[itemId] || '';
                textarea.focus();
            }
        }
        
        function saveComment(itemId) {
            const textarea = document.getElementById(`textarea-${itemId}`);
            const comment = textarea.value.trim();
            
            const comments = loadComments();
            if (comment) {
                comments[itemId] = comment;
                
                // Update indicator
                const indicator = document.querySelector(`tr[data-item-id="${itemId}"] .comment-indicator`);
                indicator.classList.add('has-comment');
            } else {
                delete comments[itemId];
                
                // Remove indicator
                const indicator = document.querySelector(`tr[data-item-id="${itemId}"] .comment-indicator`);
                indicator.classList.remove('has-comment');
            }
            
            saveComments(comments);
            toggleComment(itemId); // Close popup
        }
        
        function deleteComment(itemId) {
            const comments = loadComments();
            delete comments[itemId];
            saveComments(comments);
            
            // Clear textarea
            const textarea = document.getElementById(`textarea-${itemId}`);
            textarea.value = '';
            
            // Remove indicator
            const indicator = document.querySelector(`tr[data-item-id="${itemId}"] .comment-indicator`);
            indicator.classList.remove('has-comment');
            
            toggleComment(itemId); // Close popup
        }
        
        function cancelComment(itemId) {
            toggleComment(itemId); // Close popup without saving
        }
        
        function exportComments() {
            const comments = loadComments();
            const blob = new Blob([JSON.stringify(comments, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'diff_comments.json';
            a.click();
            URL.revokeObjectURL(url);
        }
        
        // Load and apply comments on page load
        window.addEventListener('DOMContentLoaded', () => {
            const comments = loadComments();
            Object.keys(comments).forEach(itemId => {
                const indicator = document.querySelector(`tr[data-item-id="${itemId}"] .comment-indicator`);
                if (indicator) {
                    indicator.classList.add('has-comment');
                }
            });
            
            // Add export button
            const exportBtn = document.createElement('button');
            exportBtn.textContent = '📥 Export Comments';
            exportBtn.style.cssText = 'position: fixed; top: 20px; right: 20px; padding: 10px 15px; background: #007acc; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);';
            exportBtn.onclick = exportComments;
            document.body.appendChild(exportBtn);
        });
    </script>
    """
