"""
Structural Diff Engine for Project Snapshots

Computes fine-grained differences between two snapshots:
- CFG changes (nodes, edges added/removed/modified)
- Stats changes (variable updates, metrics deltas)
- Asset changes (validation results)
- Reversible patches for undo/redo

Classes:
    DiffPatch: Reversible patch representation
    DiffEngine: Main diffing engine

Example:
    >>> diff = DiffEngine.compare(snap_old, snap_new)
    >>> patch = diff.to_patch()
    >>> reverse_patch = diff.to_patch(reverse=True)
    >>> DiffEngine.apply_patch(project_path, patch)

Version: v0.8.8
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


@dataclass
class DiffPatch:
    """
    Reversible patch for applying/reverting snapshot changes.

    Attributes:
        snapshot_before: Source snapshot ID
        snapshot_after: Target snapshot ID
        operations: List of patch operations (add/remove/modify)
        reverse: Whether this is a reverse patch (for undo)
    """

    snapshot_before: str
    snapshot_after: str
    operations: List[Dict[str, Any]] = field(default_factory=list)
    reverse: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Serialize patch to dictionary."""
        return {
            "snapshot_before": self.snapshot_before,
            "snapshot_after": self.snapshot_after,
            "operations": self.operations,
            "reverse": self.reverse,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DiffPatch":
        """Deserialize patch from dictionary."""
        return cls(**data)


class DiffEngine:
    """
    Structural diff engine for BranchPy snapshots.

    Supported entities:
        - CFG nodes (label, kind, conditions)
        - CFG edges (source, target, action)
        - Stats (variables, metrics)
        - Asset validation results
        - Governance log entries

    Example:
        >>> diff = DiffEngine.compare(old_snapshot, new_snapshot)
        >>> print(diff["summary"])
        {
            "nodes_added": 3,
            "nodes_removed": 1,
            "edges_modified": 5,
            "stats_changed": 12
        }
    """

    @classmethod
    def compare(
        cls, snapshot1: Dict[str, Any], snapshot2: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Compare two snapshots and generate diff.

        Args:
            snapshot1: Earlier snapshot (baseline)
            snapshot2: Later snapshot (target)

        Returns:
            Diff dictionary with detailed changes:
            {
                "summary": {...},
                "cfg_changes": {...},
                "stats_changes": {...},
                "asset_changes": {...}
            }
        """
        diff = {
            "snapshot_before": snapshot1.get("snapshot_id", "unknown"),
            "snapshot_after": snapshot2.get("snapshot_id", "unknown"),
            "summary": {},
            "cfg_changes": cls._diff_cfg(
                snapshot1.get("cfg", {}), snapshot2.get("cfg", {})
            ),
            "stats_changes": cls._diff_stats(
                snapshot1.get("stats", {}), snapshot2.get("stats", {})
            ),
            "asset_changes": cls._diff_assets(
                snapshot1.get("assets", {}), snapshot2.get("assets", {})
            ),
        }

        # Generate summary
        diff["summary"] = cls._generate_summary(diff)

        return diff

    @classmethod
    def to_patch(cls, diff: Dict[str, Any], reverse: bool = False) -> DiffPatch:
        """
        Convert diff to reversible patch.

        Args:
            diff: Diff dictionary from compare()
            reverse: If True, create reverse patch for undo

        Returns:
            DiffPatch instance
        """
        operations = []

        # CFG operations
        cfg = diff.get("cfg_changes", {})
        for node in cfg.get("nodes_added", []):
            op = {"type": "remove_node" if reverse else "add_node", "data": node}
            operations.append(op)

        for node in cfg.get("nodes_removed", []):
            op = {"type": "add_node" if reverse else "remove_node", "data": node}
            operations.append(op)

        for change in cfg.get("nodes_modified", []):
            if reverse:
                op = {
                    "type": "modify_node",
                    "id": change["id"],
                    "old": change["new"],
                    "new": change["old"],
                }
            else:
                op = {
                    "type": "modify_node",
                    "id": change["id"],
                    "old": change["old"],
                    "new": change["new"],
                }
            operations.append(op)

        # Stats operations
        stats = diff.get("stats_changes", {})
        for var in stats.get("variables_added", []):
            op = {"type": "remove_variable" if reverse else "add_variable", "data": var}
            operations.append(op)

        for var in stats.get("variables_removed", []):
            op = {"type": "add_variable" if reverse else "remove_variable", "data": var}
            operations.append(op)

        # Asset operations
        assets = diff.get("asset_changes", {})
        for change in assets.get("validation_changes", []):
            op = {
                "type": "update_asset_validation",
                "path": change["path"],
                "old": change["old"],
                "new": change["new"],
            }
            if reverse:
                op["old"], op["new"] = op["new"], op["old"]
            operations.append(op)

        return DiffPatch(
            snapshot_before=diff["snapshot_before"],
            snapshot_after=diff["snapshot_after"],
            operations=operations,
            reverse=reverse,
        )

    @classmethod
    def apply_delta(
        cls, base_snapshot: Dict[str, Any], delta: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Apply delta changes to base snapshot to reconstruct full state.

        Args:
            base_snapshot: Full snapshot to apply delta to
            delta: Delta changes (from incremental snapshot)

        Returns:
            Reconstructed full snapshot
        """
        # Start with copy of base
        reconstructed = json.loads(json.dumps(base_snapshot))  # Deep copy

        # Apply CFG changes
        cfg_changes = delta.get("cfg_changes", {})
        cfg = reconstructed.setdefault("cfg", {})

        # Apply node additions
        nodes = cfg.setdefault("nodes", [])
        node_ids = {n["id"] for n in nodes}
        for node in cfg_changes.get("nodes_added", []):
            if node["id"] not in node_ids:
                nodes.append(node)

        # Apply node removals
        removed_ids = {n["id"] for n in cfg_changes.get("nodes_removed", [])}
        cfg["nodes"] = [n for n in nodes if n["id"] not in removed_ids]

        # Apply node modifications
        node_map = {n["id"]: n for n in cfg["nodes"]}
        for change in cfg_changes.get("nodes_modified", []):
            if change["id"] in node_map:
                node_map[change["id"]].update(change["new"])

        # Apply edge changes similarly
        edges = cfg.setdefault("edges", [])
        edge_keys = {cls._edge_key(e) for e in edges}
        for edge in cfg_changes.get("edges_added", []):
            if cls._edge_key(edge) not in edge_keys:
                edges.append(edge)

        removed_edge_keys = {
            cls._edge_key(e) for e in cfg_changes.get("edges_removed", [])
        }
        cfg["edges"] = [e for e in edges if cls._edge_key(e) not in removed_edge_keys]

        # Apply stats changes
        stats_changes = delta.get("stats_changes", {})
        stats = reconstructed.setdefault("stats", {})
        variables = stats.setdefault("variables", {})

        for var in stats_changes.get("variables_added", []):
            variables[var["name"]] = var["value"]

        for var in stats_changes.get("variables_removed", []):
            variables.pop(var["name"], None)

        for var in stats_changes.get("variables_modified", []):
            variables[var["name"]] = var["new"]

        logger.info("Applied delta to reconstruct full snapshot")
        return reconstructed

    @classmethod
    def apply_patch(
        cls, project_path: str, patch: DiffPatch, create_backup: bool = True
    ) -> Dict[str, Any]:
        """
        Apply a patch to the project, modifying CFG, Stats, and Assets.

        This method applies reversible patch operations to the project's current state:
        1. Optionally create backup snapshot of current state
        2. Load current project files (cfg.json, stats_unified.json, asset_validation.json)
        3. Apply patch operations in order:
           - Node operations (add/remove/modify)
           - Edge operations (add/remove)
           - Variable operations (add/remove/modify)
           - Asset validation operations (update)
        4. Write modified data back to files
        5. Validate integrity of changes
        6. Emit governance event

        Args:
            project_path: Project root path
            patch: DiffPatch instance with operations to apply
            create_backup: Create backup snapshot before applying (default: True)

        Returns:
            Result dictionary with:
            {
                "success": bool,
                "backup_snapshot_id": str (if create_backup=True),
                "operations_applied": int,
                "files_modified": List[str],
                "message": str
            }

        Raises:
            FileNotFoundError: If project files don't exist
            ValueError: If patch operations are invalid
            IOError: If file writes fail

        Example:
            >>> diff = DiffEngine.compare(old_snapshot, new_snapshot)
            >>> patch = DiffEngine.to_patch(diff, reverse=False)
            >>> result = DiffEngine.apply_patch(project_path, patch)
            >>> print(result["message"])
        """
        from pathlib import Path

        project = Path(project_path)
        branchpy_dir = project / ".branchpy"

        # Validate project structure
        if not branchpy_dir.exists():
            raise FileNotFoundError(f"BranchPy directory not found: {branchpy_dir}")

        cfg_file = branchpy_dir / "cfg.json"
        stats_file = branchpy_dir / "stats_unified.json"
        assets_file = branchpy_dir / "asset_validation.json"

        # Backup snapshot creation removed (DT-002C cycle break: eliminate diff_engine -> snapshot import)
        backup_snapshot_id = None

        # Load current project state
        try:
            cfg = (
                json.loads(cfg_file.read_text(encoding="utf-8"))
                if cfg_file.exists()
                else {"nodes": [], "edges": []}
            )
            stats = (
                json.loads(stats_file.read_text(encoding="utf-8"))
                if stats_file.exists()
                else {"variables": {}}
            )
            assets = (
                json.loads(assets_file.read_text(encoding="utf-8"))
                if assets_file.exists()
                else {"results": []}
            )
        except Exception as e:
            raise IOError(f"Failed to load project files: {e}")

        # Track modifications
        files_modified = []
        operations_applied = 0

        # Apply patch operations
        for operation in patch.operations:
            op_type = operation["type"]

            try:
                # ========== CFG Node Operations ==========
                if op_type == "add_node":
                    node = operation["data"]
                    nodes = cfg.setdefault("nodes", [])
                    # Avoid duplicates
                    if not any(n["id"] == node["id"] for n in nodes):
                        nodes.append(node)
                        operations_applied += 1
                        if "cfg.json" not in files_modified:
                            files_modified.append("cfg.json")

                elif op_type == "remove_node":
                    node = operation["data"]
                    nodes = cfg.get("nodes", [])
                    cfg["nodes"] = [n for n in nodes if n["id"] != node["id"]]
                    operations_applied += 1
                    if "cfg.json" not in files_modified:
                        files_modified.append("cfg.json")

                elif op_type == "modify_node":
                    node_id = operation["id"]
                    new_data = operation["new"]
                    nodes = cfg.get("nodes", [])
                    for node in nodes:
                        if node["id"] == node_id:
                            node.update(new_data)
                            operations_applied += 1
                            if "cfg.json" not in files_modified:
                                files_modified.append("cfg.json")
                            break

                # ========== CFG Edge Operations ==========
                elif op_type == "add_edge":
                    edge = operation["data"]
                    edges = cfg.setdefault("edges", [])
                    edge_key = cls._edge_key(edge)
                    if not any(cls._edge_key(e) == edge_key for e in edges):
                        edges.append(edge)
                        operations_applied += 1
                        if "cfg.json" not in files_modified:
                            files_modified.append("cfg.json")

                elif op_type == "remove_edge":
                    edge = operation["data"]
                    edges = cfg.get("edges", [])
                    edge_key = cls._edge_key(edge)
                    cfg["edges"] = [e for e in edges if cls._edge_key(e) != edge_key]
                    operations_applied += 1
                    if "cfg.json" not in files_modified:
                        files_modified.append("cfg.json")

                # ========== Stats Variable Operations ==========
                elif op_type == "add_variable":
                    var = operation["data"]
                    variables = stats.setdefault("variables", {})
                    variables[var["name"]] = var["value"]
                    operations_applied += 1
                    if "stats_unified.json" not in files_modified:
                        files_modified.append("stats_unified.json")

                elif op_type == "remove_variable":
                    var = operation["data"]
                    variables = stats.get("variables", {})
                    variables.pop(var["name"], None)
                    operations_applied += 1
                    if "stats_unified.json" not in files_modified:
                        files_modified.append("stats_unified.json")

                elif op_type == "modify_variable":
                    var_name = operation["name"]
                    new_value = operation["new"]
                    variables = stats.setdefault("variables", {})
                    variables[var_name] = new_value
                    operations_applied += 1
                    if "stats_unified.json" not in files_modified:
                        files_modified.append("stats_unified.json")

                # ========== Asset Validation Operations ==========
                elif op_type == "update_asset_validation":
                    path = operation["path"]
                    new_val = operation["new"]
                    results = assets.setdefault("results", [])

                    # Find and update existing result
                    found = False
                    for result in results:
                        if result.get("path") == path:
                            result.update(new_val)
                            found = True
                            break

                    # Add new result if not found
                    if not found and new_val is not None:
                        results.append(new_val)

                    operations_applied += 1
                    if "asset_validation.json" not in files_modified:
                        files_modified.append("asset_validation.json")

                else:
                    logger.warning(f"Unknown operation type: {op_type}")

            except Exception as e:
                logger.error(f"Failed to apply operation {op_type}: {e}")
                raise ValueError(f"Invalid patch operation {op_type}: {e}")

        # Write modified files
        try:
            if "cfg.json" in files_modified:
                cfg_file.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

            if "stats_unified.json" in files_modified:
                stats_file.write_text(json.dumps(stats, indent=2), encoding="utf-8")

            if "asset_validation.json" in files_modified:
                assets_file.write_text(json.dumps(assets, indent=2), encoding="utf-8")

        except Exception as e:
            raise IOError(f"Failed to write modified files: {e}")

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge(project)
            bridge.log_history_event(
                "PATCH_APPLIED",
                None,
                {
                    "patch_id": f"{patch.snapshot_before}->{patch.snapshot_after}",
                    "operations_count": operations_applied,
                    "files_modified": files_modified,
                    "reverse": patch.reverse,
                    "backup_snapshot_id": backup_snapshot_id,
                },
            )
        except Exception as e:
            logger.warning(f"Failed to log patch application to governance: {e}")

        result = {
            "success": True,
            "backup_snapshot_id": backup_snapshot_id,
            "operations_applied": operations_applied,
            "files_modified": files_modified,
            "message": f"Successfully applied {operations_applied} operations to {len(files_modified)} files",
        }

        logger.info(
            f"Patch applied: {patch.snapshot_before} → {patch.snapshot_after} "
            f"({operations_applied} ops, {len(files_modified)} files)"
        )

        return result

    @classmethod
    def _diff_cfg(cls, cfg1: Dict[str, Any], cfg2: Dict[str, Any]) -> Dict[str, Any]:
        """Compute CFG differences (nodes, edges)."""
        nodes1 = {n["id"]: n for n in cfg1.get("nodes", [])}
        nodes2 = {n["id"]: n for n in cfg2.get("nodes", [])}

        nodes_added = [nodes2[nid] for nid in set(nodes2) - set(nodes1)]
        nodes_removed = [nodes1[nid] for nid in set(nodes1) - set(nodes2)]
        nodes_modified = []

        for nid in set(nodes1) & set(nodes2):
            if nodes1[nid] != nodes2[nid]:
                nodes_modified.append(
                    {
                        "id": nid,
                        "old": nodes1[nid],
                        "new": nodes2[nid],
                    }
                )

        edges1 = {cls._edge_key(e): e for e in cfg1.get("edges", [])}
        edges2 = {cls._edge_key(e): e for e in cfg2.get("edges", [])}

        edges_added = [edges2[ek] for ek in set(edges2) - set(edges1)]
        edges_removed = [edges1[ek] for ek in set(edges1) - set(edges2)]
        edges_modified = []

        for ek in set(edges1) & set(edges2):
            if edges1[ek] != edges2[ek]:
                edges_modified.append(
                    {
                        "key": ek,
                        "old": edges1[ek],
                        "new": edges2[ek],
                    }
                )

        return {
            "nodes_added": nodes_added,
            "nodes_removed": nodes_removed,
            "nodes_modified": nodes_modified,
            "edges_added": edges_added,
            "edges_removed": edges_removed,
            "edges_modified": edges_modified,
        }

    @classmethod
    def _diff_stats(
        cls, stats1: Dict[str, Any], stats2: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Compute Stats 2.x differences."""
        vars1 = stats1.get("variables", {})
        vars2 = stats2.get("variables", {})

        variables_added = [
            {"name": k, "value": v} for k, v in vars2.items() if k not in vars1
        ]
        variables_removed = [
            {"name": k, "value": v} for k, v in vars1.items() if k not in vars2
        ]
        variables_modified = []

        for var_name in set(vars1) & set(vars2):
            if vars1[var_name] != vars2[var_name]:
                variables_modified.append(
                    {
                        "name": var_name,
                        "old": vars1[var_name],
                        "new": vars2[var_name],
                    }
                )

        return {
            "variables_added": variables_added,
            "variables_removed": variables_removed,
            "variables_modified": variables_modified,
        }

    @classmethod
    def _diff_assets(
        cls, assets1: Dict[str, Any], assets2: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Compute asset validation differences."""
        results1 = {r["path"]: r for r in assets1.get("results", [])}
        results2 = {r["path"]: r for r in assets2.get("results", [])}

        validation_changes = []
        for path in set(results1) | set(results2):
            old_val = results1.get(path)
            new_val = results2.get(path)

            if old_val != new_val:
                validation_changes.append(
                    {
                        "path": path,
                        "old": old_val,
                        "new": new_val,
                    }
                )

        return {"validation_changes": validation_changes}

    @classmethod
    def _generate_summary(cls, diff: Dict[str, Any]) -> Dict[str, Any]:
        """Generate high-level summary of changes."""
        cfg = diff["cfg_changes"]
        stats = diff["stats_changes"]
        assets = diff["asset_changes"]

        return {
            "nodes_added": len(cfg["nodes_added"]),
            "nodes_removed": len(cfg["nodes_removed"]),
            "nodes_modified": len(cfg["nodes_modified"]),
            "edges_added": len(cfg["edges_added"]),
            "edges_removed": len(cfg["edges_removed"]),
            "edges_modified": len(cfg["edges_modified"]),
            "variables_added": len(stats["variables_added"]),
            "variables_removed": len(stats["variables_removed"]),
            "variables_modified": len(stats["variables_modified"]),
            "assets_changed": len(assets["validation_changes"]),
        }

    @staticmethod
    def _edge_key(edge: Dict[str, Any]) -> str:
        """Generate unique key for edge."""
        return f"{edge.get('source')}→{edge.get('target')}"


# TODO: Add semantic diff for Python code blocks in labels
# TODO: Add diff visualization (HTML report with side-by-side comparison)
# TODO: Add conflict detection for concurrent edits
