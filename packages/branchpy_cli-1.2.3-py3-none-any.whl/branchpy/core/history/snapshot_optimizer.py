"""
Snapshot Storage Optimization (v0.9.0 Phase 2.2)

Optimizes snapshot storage through:
- Compression of large snapshot files (gzip)
- Retention policies with automatic cleanup
- Storage analytics and recommendations
- Incremental snapshot validation

Classes:
    RetentionPolicy: Configurable snapshot retention strategy
    SnapshotOptimizer: Main optimization manager
    StorageStats: Storage usage statistics

Features:
    - Compress snapshots > 1MB threshold
    - Retention: Keep N recent + tagged snapshots
    - Auto-cleanup based on age/count
    - Storage reclamation analysis

Example:
    >>> optimizer = SnapshotOptimizer(project_path)
    >>> optimizer.compress_old_snapshots(age_days=7)
    >>> optimizer.cleanup_snapshots(keep_count=50)
    >>> stats = optimizer.get_storage_stats()
    >>> print(f"Potential savings: {stats.compression_savings_mb:.1f}MB")

Version: v0.9.0
Storage: .branchpy/history/snapshots/
"""

import gzip
import json
import logging
import shutil
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class RetentionStrategy(str, Enum):
    """Snapshot retention strategy."""

    KEEP_ALL = "keep_all"  # Never delete
    KEEP_RECENT = "keep_recent"  # Keep N most recent
    KEEP_TAGGED = "keep_tagged"  # Keep tagged + N recent
    TIME_BASED = "time_based"  # Keep snapshots within time window
    HYBRID = "hybrid"  # Combination of strategies


@dataclass
class RetentionPolicy:
    """
    Snapshot retention configuration.

    Attributes:
        strategy: Retention strategy to apply
        keep_count: Number of recent snapshots to retain
        keep_days: Number of days to retain snapshots
        keep_tagged: Whether to preserve tagged snapshots
        compress_age_days: Compress snapshots older than N days
        compress_threshold_mb: Compress snapshots larger than N MB
    """

    strategy: RetentionStrategy = RetentionStrategy.HYBRID
    keep_count: int = 50
    keep_days: int = 30
    keep_tagged: bool = True
    compress_age_days: int = 7
    compress_threshold_mb: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "strategy": self.strategy.value,
            "keep_count": self.keep_count,
            "keep_days": self.keep_days,
            "keep_tagged": self.keep_tagged,
            "compress_age_days": self.compress_age_days,
            "compress_threshold_mb": self.compress_threshold_mb,
        }


@dataclass
class StorageStats:
    """Snapshot storage statistics."""

    total_snapshots: int = 0
    compressed_snapshots: int = 0
    total_size_mb: float = 0.0
    compressed_size_mb: float = 0.0
    compression_savings_mb: float = 0.0
    oldest_snapshot: Optional[str] = None
    newest_snapshot: Optional[str] = None
    avg_snapshot_size_mb: float = 0.0
    tagged_count: int = 0
    incremental_count: int = 0
    full_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "total_snapshots": self.total_snapshots,
            "compressed_snapshots": self.compressed_snapshots,
            "total_size_mb": round(self.total_size_mb, 2),
            "compressed_size_mb": round(self.compressed_size_mb, 2),
            "compression_savings_mb": round(self.compression_savings_mb, 2),
            "oldest_snapshot": self.oldest_snapshot,
            "newest_snapshot": self.newest_snapshot,
            "avg_snapshot_size_mb": round(self.avg_snapshot_size_mb, 2),
            "tagged_count": self.tagged_count,
            "incremental_count": self.incremental_count,
            "full_count": self.full_count,
        }


class SnapshotOptimizer:
    """
    Manages snapshot storage optimization.

    Features:
        - Compress large/old snapshots
        - Apply retention policies
        - Provide storage analytics
        - Automatic cleanup

    Attributes:
        project_path: Project root directory
        snapshot_dir: Directory containing snapshots
        policy: Active retention policy
    """

    SNAPSHOT_DIR = ".branchpy/history/snapshots"
    COMPRESSED_EXT = ".gz"

    def __init__(self, project_path: str, policy: Optional[RetentionPolicy] = None):
        """
        Initialize snapshot optimizer.

        Args:
            project_path: Project root path
            policy: Retention policy (default: RetentionPolicy())
        """
        self.project_path = Path(project_path)
        self.snapshot_dir = self.project_path / self.SNAPSHOT_DIR
        self.policy = policy or RetentionPolicy()

        # Ensure snapshot directory exists
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)

    def compress_snapshot(
        self, snapshot_id: str, delete_original: bool = True
    ) -> Optional[Tuple[int, int]]:
        """
        Compress a snapshot file using gzip.

        Args:
            snapshot_id: Snapshot ID to compress
            delete_original: Whether to delete original after compression

        Returns:
            Tuple of (original_size, compressed_size) in bytes, or None if skipped

        Raises:
            FileNotFoundError: If snapshot doesn't exist
        """
        snapshot_file = self.snapshot_dir / f"{snapshot_id}.json"

        if not snapshot_file.exists():
            raise FileNotFoundError(f"Snapshot not found: {snapshot_file}")

        # Skip if already compressed
        compressed_file = self.snapshot_dir / f"{snapshot_id}.json.gz"
        if compressed_file.exists():
            logger.debug(f"Snapshot {snapshot_id} already compressed")
            return None

        # Get original size
        original_size = snapshot_file.stat().st_size

        # Compress with optimal settings
        try:
            with open(snapshot_file, "rb") as f_in:
                with gzip.open(compressed_file, "wb", compresslevel=6) as f_out:
                    shutil.copyfileobj(f_in, f_out)

            compressed_size = compressed_file.stat().st_size
            compression_ratio = (
                1 - (compressed_size / original_size) if original_size > 0 else 0
            )

            logger.info(
                f"Compressed {snapshot_id}: {original_size:,} → {compressed_size:,} bytes "
                f"({compression_ratio:.1%} reduction)"
            )

            # Delete original if requested
            if delete_original:
                snapshot_file.unlink()
                logger.debug(f"Deleted original snapshot: {snapshot_file.name}")

            return (original_size, compressed_size)

        except Exception as e:
            logger.error(f"Compression failed for {snapshot_id}: {e}")
            # Clean up partial compressed file
            if compressed_file.exists():
                compressed_file.unlink()
            raise

    def decompress_snapshot(self, snapshot_id: str) -> Path:
        """
        Decompress a compressed snapshot.

        Args:
            snapshot_id: Snapshot ID to decompress

        Returns:
            Path to decompressed file

        Raises:
            FileNotFoundError: If compressed snapshot doesn't exist
        """
        compressed_file = self.snapshot_dir / f"{snapshot_id}.json.gz"

        if not compressed_file.exists():
            raise FileNotFoundError(f"Compressed snapshot not found: {compressed_file}")

        output_file = self.snapshot_dir / f"{snapshot_id}.json"

        try:
            with gzip.open(compressed_file, "rb") as f_in:
                with open(output_file, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)

            logger.info(f"Decompressed {snapshot_id}")
            return output_file

        except Exception as e:
            logger.error(f"Decompression failed for {snapshot_id}: {e}")
            raise

    def compress_old_snapshots(
        self, age_days: Optional[int] = None, size_threshold_mb: Optional[float] = None
    ) -> int:
        """
        Compress snapshots older than specified age or larger than threshold.

        Args:
            age_days: Compress snapshots older than N days (default: from policy)
            size_threshold_mb: Compress snapshots larger than N MB (default: from policy)

        Returns:
            Number of snapshots compressed
        """
        age_days = age_days if age_days is not None else self.policy.compress_age_days
        size_threshold_mb = (
            size_threshold_mb
            if size_threshold_mb is not None
            else self.policy.compress_threshold_mb
        )

        threshold_date = datetime.utcnow() - timedelta(days=age_days)
        size_threshold_bytes = int(size_threshold_mb * 1024 * 1024)

        compressed_count = 0

        for snapshot_file in self.snapshot_dir.glob("snap_*.json"):
            # Skip if already compressed
            if (self.snapshot_dir / f"{snapshot_file.stem}.json.gz").exists():
                continue

            # Check age
            file_mtime = datetime.fromtimestamp(snapshot_file.stat().st_mtime)
            is_old = file_mtime < threshold_date

            # Check size
            file_size = snapshot_file.stat().st_size
            is_large = file_size >= size_threshold_bytes

            if is_old or is_large:
                try:
                    snapshot_id = snapshot_file.stem
                    self.compress_snapshot(snapshot_id, delete_original=True)
                    compressed_count += 1
                except Exception as e:
                    logger.warning(f"Failed to compress {snapshot_file.name}: {e}")

        if compressed_count > 0:
            logger.info(
                f"Compressed {compressed_count} snapshots (age>{age_days}d or size>{size_threshold_mb}MB)"
            )

        return compressed_count

    def cleanup_snapshots(
        self,
        keep_count: Optional[int] = None,
        keep_days: Optional[int] = None,
        dry_run: bool = False,
    ) -> List[str]:
        """
        Remove old snapshots according to retention policy.

        Args:
            keep_count: Number of recent snapshots to keep (default: from policy)
            keep_days: Number of days to keep snapshots (default: from policy)
            dry_run: If True, return list of snapshots that would be deleted without deleting

        Returns:
            List of deleted (or would-be-deleted) snapshot IDs
        """
        keep_count = keep_count if keep_count is not None else self.policy.keep_count
        keep_days = keep_days if keep_days is not None else self.policy.keep_days

        # Get all snapshots (both .json and .json.gz)
        all_snapshots = self._list_all_snapshots()

        if len(all_snapshots) <= keep_count:
            logger.info(
                f"Snapshot count ({len(all_snapshots)}) within retention limit ({keep_count})"
            )
            return []

        # Sort by modification time (newest first)
        all_snapshots.sort(key=lambda x: x["mtime"], reverse=True)

        # Determine which to delete
        to_delete = []
        cutoff_date = datetime.utcnow() - timedelta(days=keep_days)

        for i, snapshot in enumerate(all_snapshots):
            # Keep recent N snapshots
            if i < keep_count:
                continue

            # Keep snapshots within time window
            if snapshot["mtime"] >= cutoff_date:
                continue

            # Keep tagged snapshots if policy requires
            if self.policy.keep_tagged and snapshot.get("is_tagged", False):
                logger.debug(f"Preserving tagged snapshot: {snapshot['id']}")
                continue

            to_delete.append(snapshot["id"])

        if not to_delete:
            logger.info("No snapshots need cleanup")
            return []

        if dry_run:
            logger.info(f"[DRY RUN] Would delete {len(to_delete)} snapshots")
            return to_delete

        # Delete snapshots
        deleted = []
        for snapshot_id in to_delete:
            try:
                self._delete_snapshot(snapshot_id)
                deleted.append(snapshot_id)
            except Exception as e:
                logger.warning(f"Failed to delete {snapshot_id}: {e}")

        logger.info(
            f"Cleaned up {len(deleted)} snapshots (keep_count={keep_count}, keep_days={keep_days})"
        )
        return deleted

    def get_storage_stats(self) -> StorageStats:
        """
        Calculate storage statistics for snapshots.

        Returns:
            StorageStats with detailed storage information
        """
        stats = StorageStats()

        all_snapshots = self._list_all_snapshots()
        stats.total_snapshots = len(all_snapshots)

        if not all_snapshots:
            return stats

        total_size = 0
        compressed_size = 0

        for snapshot in all_snapshots:
            total_size += snapshot["size"]

            if snapshot["is_compressed"]:
                stats.compressed_snapshots += 1
                compressed_size += snapshot["size"]

            # Count snapshot types
            if snapshot.get("is_tagged"):
                stats.tagged_count += 1

            snapshot_type = snapshot.get("type", "full")
            if snapshot_type == "incremental":
                stats.incremental_count += 1
            else:
                stats.full_count += 1

        stats.total_size_mb = total_size / (1024 * 1024)
        stats.compressed_size_mb = compressed_size / (1024 * 1024)

        # Estimate potential savings (assume 80% compression for uncompressed files)
        uncompressed_size = total_size - compressed_size
        estimated_savings = uncompressed_size * 0.8
        stats.compression_savings_mb = estimated_savings / (1024 * 1024)

        # Average snapshot size
        stats.avg_snapshot_size_mb = (
            stats.total_size_mb / stats.total_snapshots
            if stats.total_snapshots > 0
            else 0
        )

        # Oldest/newest
        snapshots_by_time = sorted(all_snapshots, key=lambda x: x["mtime"])
        stats.oldest_snapshot = (
            snapshots_by_time[0]["id"] if snapshots_by_time else None
        )
        stats.newest_snapshot = (
            snapshots_by_time[-1]["id"] if snapshots_by_time else None
        )

        return stats

    def _list_all_snapshots(self) -> List[Dict[str, Any]]:
        """
        List all snapshots (both compressed and uncompressed).

        Returns:
            List of snapshot metadata dicts
        """
        snapshots = []

        # Find all snapshot files
        for snapshot_file in self.snapshot_dir.glob("snap_*"):
            if snapshot_file.suffix not in [".json", ".gz"]:
                continue

            is_compressed = snapshot_file.suffix == ".gz"
            snapshot_id = (
                snapshot_file.stem
                if not is_compressed
                else snapshot_file.stem.replace(".json", "")
            )

            # Skip if we already have this snapshot in the list
            if any(s["id"] == snapshot_id for s in snapshots):
                continue

            # Get file stats
            size = snapshot_file.stat().st_size
            mtime = datetime.fromtimestamp(snapshot_file.stat().st_mtime)

            # Try to load metadata to check if tagged
            is_tagged = False
            snapshot_type = "full"
            try:
                metadata = self._load_snapshot_metadata(snapshot_id, is_compressed)
                is_tagged = len(metadata.get("metadata", {}).get("tags", [])) > 0
                snapshot_type = metadata.get("snapshot_type", "full")
            except Exception:
                pass  # If we can't load metadata, assume defaults

            snapshots.append(
                {
                    "id": snapshot_id,
                    "size": size,
                    "mtime": mtime,
                    "is_compressed": is_compressed,
                    "is_tagged": is_tagged,
                    "type": snapshot_type,
                }
            )

        return snapshots

    def _load_snapshot_metadata(
        self, snapshot_id: str, is_compressed: bool
    ) -> Dict[str, Any]:
        """Load snapshot metadata without loading full content."""
        if is_compressed:
            snapshot_file = self.snapshot_dir / f"{snapshot_id}.json.gz"
            with gzip.open(snapshot_file, "rt", encoding="utf-8") as f:
                data = json.load(f)
        else:
            snapshot_file = self.snapshot_dir / f"{snapshot_id}.json"
            with open(snapshot_file, "r", encoding="utf-8") as f:
                data = json.load(f)

        return data

    def _delete_snapshot(self, snapshot_id: str) -> None:
        """Delete both compressed and uncompressed versions of a snapshot."""
        json_file = self.snapshot_dir / f"{snapshot_id}.json"
        gz_file = self.snapshot_dir / f"{snapshot_id}.json.gz"

        deleted = False
        if json_file.exists():
            json_file.unlink()
            deleted = True
        if gz_file.exists():
            gz_file.unlink()
            deleted = True

        if not deleted:
            raise FileNotFoundError(f"Snapshot {snapshot_id} not found")

        logger.debug(f"Deleted snapshot: {snapshot_id}")
