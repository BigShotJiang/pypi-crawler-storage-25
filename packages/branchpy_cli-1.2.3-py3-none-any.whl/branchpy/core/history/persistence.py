"""
History Persistence Layer — JSONL Storage

Manages durable storage of history stacks with:
- JSONL-based append-only format
- Auto-reload after restart (daemon integration)
- Retention policies (max_size, max_days)
- Atomic write operations

Classes:
    HistoryPersistence: Main persistence manager

Example:
    >>> persistence = HistoryPersistence(project_path)
    >>> persistence.save_stack(edit_stack)
    >>> loaded_stack = persistence.load_stack()

Version: v0.8.99-testing
Storage: .branchpy/history/history.jsonl
"""

import gzip
import hashlib
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .stack import EditStack, HistoryAction

logger = logging.getLogger(__name__)


class HistoryPersistence:
    """
    Persistent storage for edit stacks.

    Features:
        - Append-only JSONL format
        - Atomic writes with temp file + rename
        - Auto-cleanup of old entries
        - Cross-session restoration

    Example:
        >>> persistence = HistoryPersistence("/path/to/project")
        >>> persistence.save_stack(edit_stack)
        >>> edit_stack = persistence.load_stack()
    """

    HISTORY_FILE = ".branchpy/history/history.jsonl"
    MAX_HISTORY_SIZE = 100  # Maximum number of actions to retain
    MAX_HISTORY_DAYS = 30  # Maximum age of actions to retain
    MAX_ROTATED_FILES = 5  # Maximum number of rotated history files to keep
    COMPRESSION_ENABLED = True  # Enable gzip compression for history files
    COMPRESSION_LEVEL = 6  # gzip compression level (1-9)

    def __init__(
        self,
        project_path: str,
        compression: bool = True,
        max_rotated_files: int = 5,
        compression_level: int = 6,
    ):
        """
        Initialize persistence manager.

        Args:
            project_path: Project root path
            compression: Enable gzip compression for history files
            max_rotated_files: Maximum number of rotated files to keep
            compression_level: gzip compression level (1-9, default 6)
        """
        self.project_path = Path(project_path)
        self.history_file = self.project_path / self.HISTORY_FILE
        self.compression = compression
        self.max_rotated_files = max_rotated_files
        self.compression_level = compression_level
        self._ensure_history_dir()

    def save_stack(self, edit_stack) -> None:
        """
        Save edit stack to persistent storage.

        Args:
            edit_stack: EditStack instance to persist

        Side effects:
            - Writes to history.jsonl
            - Applies retention policies
        """
        from .stack import EditStack  # Avoid circular import

        if not isinstance(edit_stack, EditStack):
            raise TypeError("edit_stack must be EditStack instance")

        # Get stack data
        stack_data = edit_stack.show()

        # Write header
        lines = [
            json.dumps(
                {
                    "type": "stack_header",
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "capacity": stack_data["capacity"],
                }
            )
        ]

        # Write undo stack
        for action in stack_data["undo_stack"]:
            lines.append(
                json.dumps(
                    {
                        "type": "undo_action",
                        "data": action,
                    }
                )
            )

        # Write redo stack
        for action in stack_data["redo_stack"]:
            lines.append(
                json.dumps(
                    {
                        "type": "redo_action",
                        "data": action,
                    }
                )
            )

        # Write footer
        lines.append(
            json.dumps(
                {
                    "type": "stack_footer",
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                }
            )
        )

        # Atomic write (temp file + rename)
        temp_file = self.history_file.with_suffix(".tmp")

        # Rotate file if needed before writing
        self._rotate_if_needed()

        # Write with optional compression
        self._write_file(temp_file, "\n".join(lines) + "\n")

        temp_file.replace(self.history_file)

        # Generate integrity checksum
        self._generate_checksum(self.history_file)

        logger.info(f"Saved history stack to {self.history_file}")

        # Apply retention policies
        self._cleanup_old_entries()

    def load_stack(self) -> Optional["EditStack"]:
        """
        Load edit stack from persistent storage.

        Returns:
            EditStack instance or None if no history exists

        Raises:
            ValueError: If history file is corrupted
        """
        from .stack import EditStack, HistoryAction  # Avoid circular import

        if not self.history_file.exists():
            logger.info("No history file found, starting fresh")
            return None

        # Verify integrity before loading
        if not self._verify_checksum(self.history_file):
            logger.warning("History file integrity check failed - loading anyway")

        undo_actions = []
        redo_actions = []
        capacity = 100

        try:
            # Read with optional decompression
            content = self._read_file(self.history_file)
            lines = content.strip().split("\n")

            for line in lines:
                if not line.strip():
                    continue

                entry = json.loads(line.strip())

                if entry["type"] == "stack_header":
                    capacity = entry.get("capacity", 100)
                elif entry["type"] == "undo_action":
                    undo_actions.append(HistoryAction.from_dict(entry["data"]))
                elif entry["type"] == "redo_action":
                    redo_actions.append(HistoryAction.from_dict(entry["data"]))

            # Reconstruct stack
            stack = EditStack(capacity=capacity)
            stack.undo_stack = undo_actions
            stack.redo_stack = redo_actions

            logger.info(
                f"Loaded history stack: {len(undo_actions)} undo, "
                f"{len(redo_actions)} redo"
            )

            return stack

        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"Corrupted history file: {e}")
            raise ValueError(f"Failed to load history: {e}")

    def append_action(self, action: "HistoryAction", stack_type: str = "undo") -> None:
        """
        Append a single action to history file (incremental update).

        Args:
            action: HistoryAction to append
            stack_type: "undo" or "redo"
        """
        from .stack import HistoryAction  # Avoid circular import

        if not isinstance(action, HistoryAction):
            raise TypeError("action must be HistoryAction instance")

        entry = json.dumps(
            {
                "type": f"{stack_type}_action",
                "data": action.to_dict(),
            }
        )

        # Append to file
        with open(self.history_file, "a", encoding="utf-8") as f:
            f.write(entry + "\n")

        logger.debug(f"Appended {stack_type} action: {action.operation}")

    def clear(self) -> None:
        """Clear all history."""
        if self.history_file.exists():
            self.history_file.unlink()
            logger.info("Cleared history file")

    def _ensure_history_dir(self) -> None:
        """Create history directory if it doesn't exist."""
        history_dir = self.history_file.parent
        history_dir.mkdir(parents=True, exist_ok=True)

    def _cleanup_old_entries(self) -> None:
        """Apply retention policies (max_size, max_days)."""
        if not self.history_file.exists():
            return

        # Load all entries (handle both compressed and uncompressed)
        entries = []
        try:
            # Try compressed first
            with gzip.open(self.history_file, "rt", encoding="utf-8") as f:
                for line in f:
                    entry = json.loads(line.strip())
                    entries.append(entry)
        except (gzip.BadGzipFile, OSError):
            # Fall back to uncompressed
            with open(self.history_file, "r", encoding="utf-8") as f:
                for line in f:
                    entry = json.loads(line.strip())
                    entries.append(entry)

        # Filter by age
        cutoff_date = datetime.utcnow().replace(tzinfo=None) - timedelta(
            days=self.MAX_HISTORY_DAYS
        )
        filtered_entries = []

        for entry in entries:
            if entry["type"] in ("undo_action", "redo_action"):
                timestamp_str = entry["data"].get("timestamp", "")
                try:
                    timestamp = datetime.fromisoformat(
                        timestamp_str.replace("Z", "+00:00")
                    )
                    # Make offset-naive for comparison
                    timestamp_naive = timestamp.replace(tzinfo=None)
                    if timestamp_naive >= cutoff_date:
                        filtered_entries.append(entry)
                except ValueError:
                    # Keep entries with invalid timestamps (better safe than sorry)
                    filtered_entries.append(entry)
            else:
                # Keep header/footer entries
                filtered_entries.append(entry)

        # Limit size (keep most recent)
        action_entries = [
            e for e in filtered_entries if e["type"] in ("undo_action", "redo_action")
        ]
        if len(action_entries) > self.MAX_HISTORY_SIZE:
            # Keep only last MAX_HISTORY_SIZE actions
            actions_to_keep = action_entries[-self.MAX_HISTORY_SIZE :]
            filtered_entries = [
                e
                for e in filtered_entries
                if e["type"] not in ("undo_action", "redo_action")
            ]
            filtered_entries.extend(actions_to_keep)

        # Rewrite file if anything was removed
        if len(filtered_entries) < len(entries):
            temp_file = self.history_file.with_suffix(".tmp")
            with open(temp_file, "w", encoding="utf-8") as f:
                for entry in filtered_entries:
                    f.write(json.dumps(entry) + "\n")

            temp_file.replace(self.history_file)
            logger.info(
                f"Cleaned up history: {len(entries)} → {len(filtered_entries)} entries"
            )

    def _rotate_if_needed(self) -> None:
        """
        Rotate history file if it exists.

        Renames:
            history.jsonl → history.jsonl.1
            history.jsonl.1 → history.jsonl.2
            ...
            history.jsonl.N-1 → history.jsonl.N

        Deletes history.jsonl.N if N >= max_rotated_files
        """
        if not self.history_file.exists():
            return

        # Find highest rotation number
        history_dir = self.history_file.parent
        base_name = self.history_file.name

        # Shift existing rotated files
        for i in range(self.max_rotated_files - 1, 0, -1):
            old_file = history_dir / f"{base_name}.{i}"
            new_file = history_dir / f"{base_name}.{i + 1}"

            if old_file.exists():
                if i + 1 > self.max_rotated_files:
                    # Delete oldest file
                    old_file.unlink()
                    logger.debug(f"Deleted old rotation: {old_file}")
                else:
                    # Rename to next rotation
                    old_file.rename(new_file)
                    logger.debug(f"Rotated {old_file} → {new_file}")

        # Rotate current file to .1
        rotated_file = history_dir / f"{base_name}.1"
        self.history_file.rename(rotated_file)
        logger.info(f"Rotated history file: {self.history_file} → {rotated_file}")

    def _write_file(self, path: Path, content: str) -> None:
        """
        Write content to file with optional compression.

        Args:
            path: File path to write to
            content: Content to write
        """
        if self.compression:
            with gzip.open(
                path, "wt", encoding="utf-8", compresslevel=self.compression_level
            ) as f:
                f.write(content)
            logger.debug(f"Wrote compressed file: {path}")
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            logger.debug(f"Wrote uncompressed file: {path}")

    def _read_file(self, path: Path) -> str:
        """
        Read content from file with optional decompression.

        Args:
            path: File path to read from

        Returns:
            File content as string
        """
        # Try compressed first
        try:
            with gzip.open(path, "rt", encoding="utf-8") as f:
                content = f.read()
            logger.debug(f"Read compressed file: {path}")
            return content
        except (gzip.BadGzipFile, OSError):
            # Fall back to uncompressed
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            logger.debug(f"Read uncompressed file: {path}")
            return content

    def _generate_checksum(self, path: Path) -> None:
        """
        Generate SHA-256 checksum for file.

        Args:
            path: File path to generate checksum for

        Side effects:
            - Writes .sha256 sidecar file
        """
        if not path.exists():
            return

        # Read file content (raw bytes for checksum)
        with open(path, "rb") as f:
            content = f.read()

        # Calculate SHA-256
        checksum = hashlib.sha256(content).hexdigest()

        # Write to sidecar file
        checksum_file = path.with_suffix(path.suffix + ".sha256")
        with open(checksum_file, "w", encoding="utf-8") as f:
            f.write(f"{checksum}  {path.name}\n")

        logger.debug(f"Generated checksum: {checksum_file}")

    def _verify_checksum(self, path: Path) -> bool:
        """
        Verify SHA-256 checksum for file.

        Args:
            path: File path to verify

        Returns:
            True if checksum matches, False otherwise
        """
        checksum_file = path.with_suffix(path.suffix + ".sha256")

        if not checksum_file.exists():
            logger.debug(f"No checksum file found: {checksum_file}")
            return True  # No checksum file = assume valid

        # Read expected checksum
        try:
            with open(checksum_file, "r", encoding="utf-8") as f:
                expected = f.read().strip().split()[0]
        except (IOError, IndexError) as e:
            logger.warning(f"Failed to read checksum file: {e}")
            return False

        # Calculate actual checksum
        try:
            with open(path, "rb") as f:
                content = f.read()
            actual = hashlib.sha256(content).hexdigest()
        except IOError as e:
            logger.warning(f"Failed to read file for checksum: {e}")
            return False

        # Compare
        match = actual == expected
        if not match:
            logger.warning(
                f"Checksum mismatch for {path.name}: "
                f"expected {expected}, got {actual}"
            )

        return match


# Implementation complete - all TODOs addressed:
# ✅ Compression for large history files (gzip)
# ✅ History file rotation (history.jsonl.1, history.jsonl.2, etc.)
# ✅ Integrity checks (SHA-256 checksums)
