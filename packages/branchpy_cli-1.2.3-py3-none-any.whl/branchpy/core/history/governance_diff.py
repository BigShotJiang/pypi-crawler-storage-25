"""
Governance Event Cross-Diff Engine for Enhanced History (v0.8.8.2)

Compares governance event timelines between timeline branches for compliance auditing,
policy verification, and cross-branch change tracking. Supports event filtering by type,
actor, timestamp, and correlation ID.

Use Cases:
- Compliance audits: Compare experimental branch events vs main
- QA verification: Track policy violations across branches
- Security review: Identify actor-specific changes between branches
- Release notes: Generate change summaries from governance events

Architecture:
- Side-by-side event timeline comparison
- Event type/actor filtering with regex support
- HTML/JSON export with color-coded diff highlighting
- Integration with GovernanceBridge for event retrieval

Author: BranchPy Team
Date: November 2025
Version: 0.8.8.2-alpha
"""

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from .timeline import Timeline

# ============================================================================
# Enums
# ============================================================================


class EventFilterType(Enum):
    """Types of event filters for governance diff."""

    EVENT_TYPE = "event_type"  # Filter by event type (NODE_CREATED, etc.)
    ACTOR = "actor"  # Filter by actor (user ID)
    TIMESTAMP = "timestamp"  # Filter by timestamp range
    CORRELATION_ID = "correlation_id"  # Filter by correlation ID


# ============================================================================
# Data Classes
# ============================================================================


@dataclass
class EventDiff:
    """
    Represents a difference in governance events between branches.

    Attributes:
        event_id: Unique event ID
        diff_type: Type of difference (ONLY_TARGET, ONLY_SOURCE, MODIFIED)
        event_type: Type of governance event
        actor: Actor who triggered event
        timestamp: When event occurred
        target_details: Event details in target branch (None if not present)
        source_details: Event details in source branch (None if not present)
        correlation_id: Correlation ID for related events
    """

    event_id: str
    diff_type: str  # ONLY_TARGET, ONLY_SOURCE, MODIFIED
    event_type: str
    actor: str
    timestamp: datetime
    target_details: Optional[Dict[str, Any]] = None
    source_details: Optional[Dict[str, Any]] = None
    correlation_id: Optional[str] = None


@dataclass
class GovernanceDiffResult:
    """
    Result of governance diff comparison between branches.

    Attributes:
        target_branch: Branch being compared to
        source_branch: Branch being compared from
        event_diffs: List of event differences detected
        total_target_events: Total events in target branch
        total_source_events: Total events in source branch
        only_target_count: Events only in target branch
        only_source_count: Events only in source branch
        modified_count: Events modified between branches
        timestamp: When diff was generated
    """

    target_branch: str
    source_branch: str
    event_diffs: List[EventDiff] = field(default_factory=list)
    total_target_events: int = 0
    total_source_events: int = 0
    only_target_count: int = 0
    only_source_count: int = 0
    modified_count: int = 0
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def has_differences(self) -> bool:
        """Check if diff has any differences."""
        return len(self.event_diffs) > 0


# ============================================================================
# Governance Diff Engine
# ============================================================================


class GovernanceDiffEngine:
    """
    Engine for comparing governance event timelines between branches.

    Workflow:
        1. Load governance events for target and source branches
        2. Filter events by type, actor, timestamp, correlation ID
        3. Compare event timelines (detect ONLY_TARGET, ONLY_SOURCE, MODIFIED)
        4. Generate HTML/JSON reports with side-by-side comparison
        5. Highlight policy violations and compliance issues

    Usage:
        >>> engine = GovernanceDiffEngine(history_dir)
        >>> result = engine.compare_branches("main", "feature-menu")
        >>> print(f"Differences: {len(result.event_diffs)}")
        >>> engine.export_html(result, "governance_diff.html")
    """

    def __init__(self, history_dir: Path, governance_logger=None):
        """
        Initialize governance diff engine.

        Args:
            history_dir: Path to .branchpy/history directory
            governance_logger: Optional GovernanceLogger for event retrieval
        """
        self.history_dir = Path(history_dir)
        self.governance_logger = governance_logger
        self.timeline = Timeline(str(history_dir))

    def compare_branches(
        self,
        target_branch: str,
        source_branch: str,
        event_type_filter: Optional[List[str]] = None,
        actor_filter: Optional[str] = None,
        start_timestamp: Optional[datetime] = None,
        end_timestamp: Optional[datetime] = None,
    ) -> GovernanceDiffResult:
        """
        Compare governance events between target and source branches.

        Args:
            target_branch: Branch to compare to (e.g., "main")
            source_branch: Branch to compare from (e.g., "feature-menu")
            event_type_filter: Optional list of event types to include
            actor_filter: Optional actor ID regex pattern
            start_timestamp: Optional start of timestamp range
            end_timestamp: Optional end of timestamp range

        Returns:
            GovernanceDiffResult with detected differences

        Raises:
            ValueError: If branches don't exist
        """
        # Validate branches
        target = self.timeline.get_branch(target_branch)
        source = self.timeline.get_branch(source_branch)

        if not target or not source:
            raise ValueError(
                f"Branches not found: target={target_branch}, source={source_branch}"
            )

        # Load governance events for each branch
        target_events = self._load_branch_events(target_branch)
        source_events = self._load_branch_events(source_branch)

        # Filter events
        if event_type_filter or actor_filter or start_timestamp or end_timestamp:
            target_events = self._filter_events(
                target_events,
                event_type_filter,
                actor_filter,
                start_timestamp,
                end_timestamp,
            )
            source_events = self._filter_events(
                source_events,
                event_type_filter,
                actor_filter,
                start_timestamp,
                end_timestamp,
            )

        # Compare events
        event_diffs = self._compare_events(target_events, source_events)

        # Calculate statistics
        only_target = sum(1 for d in event_diffs if d.diff_type == "ONLY_TARGET")
        only_source = sum(1 for d in event_diffs if d.diff_type == "ONLY_SOURCE")
        modified = sum(1 for d in event_diffs if d.diff_type == "MODIFIED")

        return GovernanceDiffResult(
            target_branch=target_branch,
            source_branch=source_branch,
            event_diffs=event_diffs,
            total_target_events=len(target_events),
            total_source_events=len(source_events),
            only_target_count=only_target,
            only_source_count=only_source,
            modified_count=modified,
        )

    def _load_branch_events(self, branch_name: str) -> List[Dict[str, Any]]:
        """
        Load governance events for a specific branch.

        This would typically integrate with GovernanceBridge to retrieve events.
        For now, we'll load from a governance log file if it exists.

        Args:
            branch_name: Name of branch to load events for

        Returns:
            List of governance event dictionaries
        """
        governance_log_path = (
            self.history_dir / "governance" / f"{branch_name}_events.json"
        )

        if not governance_log_path.exists():
            return []

        try:
            with open(governance_log_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("events", [])
        except Exception as e:
            print(f"Error loading governance events for {branch_name}: {e}")
            return []

    def _filter_events(
        self,
        events: List[Dict[str, Any]],
        event_type_filter: Optional[List[str]],
        actor_filter: Optional[str],
        start_timestamp: Optional[datetime],
        end_timestamp: Optional[datetime],
    ) -> List[Dict[str, Any]]:
        """
        Filter events by type, actor, and timestamp.

        Args:
            events: List of event dictionaries
            event_type_filter: List of event types to include (None = all)
            actor_filter: Regex pattern for actor ID (None = all)
            start_timestamp: Start of timestamp range (None = no lower bound)
            end_timestamp: End of timestamp range (None = no upper bound)

        Returns:
            Filtered list of events
        """
        filtered = []

        for event in events:
            # Event type filter
            if event_type_filter and event.get("event_type") not in event_type_filter:
                continue

            # Actor filter (regex)
            if actor_filter:
                actor = event.get("actor", "")
                if not re.search(actor_filter, actor, re.IGNORECASE):
                    continue

            # Timestamp filter
            if start_timestamp or end_timestamp:
                timestamp_str = event.get("timestamp")
                if timestamp_str:
                    try:
                        event_ts = datetime.fromisoformat(
                            timestamp_str.replace("Z", "+00:00")
                        )

                        if start_timestamp and event_ts < start_timestamp:
                            continue

                        if end_timestamp and event_ts > end_timestamp:
                            continue
                    except ValueError:
                        continue  # Skip events with invalid timestamps

            filtered.append(event)

        return filtered

    def _compare_events(
        self, target_events: List[Dict[str, Any]], source_events: List[Dict[str, Any]]
    ) -> List[EventDiff]:
        """
        Compare two event lists and detect differences.

        Comparison logic:
            - Events matched by correlation_id + event_type
            - ONLY_TARGET: Event in target but not source
            - ONLY_SOURCE: Event in source but not target
            - MODIFIED: Event in both but with different details

        Args:
            target_events: Events from target branch
            source_events: Events from source branch

        Returns:
            List of EventDiff objects
        """
        diffs = []

        # Build event maps keyed by (correlation_id, event_type)
        target_map = self._build_event_map(target_events)
        source_map = self._build_event_map(source_events)

        # Find events only in target
        for key, target_event in target_map.items():
            if key not in source_map:
                diffs.append(
                    EventDiff(
                        event_id=target_event.get("event_id", ""),
                        diff_type="ONLY_TARGET",
                        event_type=target_event.get("event_type", ""),
                        actor=target_event.get("actor", ""),
                        timestamp=self._parse_timestamp(target_event.get("timestamp")),
                        target_details=target_event.get("details", {}),
                        source_details=None,
                        correlation_id=target_event.get("correlation_id"),
                    )
                )

        # Find events only in source
        for key, source_event in source_map.items():
            if key not in target_map:
                diffs.append(
                    EventDiff(
                        event_id=source_event.get("event_id", ""),
                        diff_type="ONLY_SOURCE",
                        event_type=source_event.get("event_type", ""),
                        actor=source_event.get("actor", ""),
                        timestamp=self._parse_timestamp(source_event.get("timestamp")),
                        target_details=None,
                        source_details=source_event.get("details", {}),
                        correlation_id=source_event.get("correlation_id"),
                    )
                )

        # Find modified events (same key but different details)
        for key in target_map.keys() & source_map.keys():
            target_event = target_map[key]
            source_event = source_map[key]

            target_details = target_event.get("details", {})
            source_details = source_event.get("details", {})

            if target_details != source_details:
                diffs.append(
                    EventDiff(
                        event_id=target_event.get("event_id", ""),
                        diff_type="MODIFIED",
                        event_type=target_event.get("event_type", ""),
                        actor=target_event.get("actor", ""),
                        timestamp=self._parse_timestamp(target_event.get("timestamp")),
                        target_details=target_details,
                        source_details=source_details,
                        correlation_id=target_event.get("correlation_id"),
                    )
                )

        # Sort diffs by timestamp
        diffs.sort(key=lambda d: d.timestamp)

        return diffs

    def _build_event_map(
        self, events: List[Dict[str, Any]]
    ) -> Dict[tuple, Dict[str, Any]]:
        """
        Build event map keyed by (correlation_id, event_type).

        Args:
            events: List of event dictionaries

        Returns:
            Dictionary mapping (correlation_id, event_type) -> event
        """
        event_map = {}

        for event in events:
            correlation_id = event.get("correlation_id", "")
            event_type = event.get("event_type", "")
            key = (correlation_id, event_type)

            # If duplicate key, keep the most recent event
            if key in event_map:
                existing_ts = self._parse_timestamp(event_map[key].get("timestamp"))
                new_ts = self._parse_timestamp(event.get("timestamp"))

                if new_ts > existing_ts:
                    event_map[key] = event
            else:
                event_map[key] = event

        return event_map

    def _parse_timestamp(self, timestamp_str: Optional[str]) -> datetime:
        """Parse ISO timestamp string to datetime (fallback to epoch if invalid)."""
        if not timestamp_str:
            return datetime.fromtimestamp(0)

        try:
            return datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        except ValueError:
            return datetime.fromtimestamp(0)

    def export_html(self, result: GovernanceDiffResult, output_path: Path) -> Path:
        """
        Export governance diff as HTML report with side-by-side comparison.

        Args:
            result: GovernanceDiffResult to export
            output_path: Path to output HTML file

        Returns:
            Path to created HTML file
        """
        html = self._generate_html_report(result)

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        return output_path

    def export_json(self, result: GovernanceDiffResult, output_path: Path) -> Path:
        """
        Export governance diff as JSON for CI/CD integration.

        Args:
            result: GovernanceDiffResult to export
            output_path: Path to output JSON file

        Returns:
            Path to created JSON file
        """
        json_data = {
            "target_branch": result.target_branch,
            "source_branch": result.source_branch,
            "timestamp": result.timestamp.isoformat(),
            "statistics": {
                "total_target_events": result.total_target_events,
                "total_source_events": result.total_source_events,
                "only_target_count": result.only_target_count,
                "only_source_count": result.only_source_count,
                "modified_count": result.modified_count,
            },
            "event_diffs": [
                {
                    "event_id": diff.event_id,
                    "diff_type": diff.diff_type,
                    "event_type": diff.event_type,
                    "actor": diff.actor,
                    "timestamp": diff.timestamp.isoformat(),
                    "target_details": diff.target_details,
                    "source_details": diff.source_details,
                    "correlation_id": diff.correlation_id,
                }
                for diff in result.event_diffs
            ],
        }

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(json_data, f, indent=2)

        return output_path

    def _generate_html_report(self, result: GovernanceDiffResult) -> str:
        """Generate HTML report with side-by-side event comparison."""
        # Build event rows
        rows_html = []
        for diff in result.event_diffs:
            diff_class = {
                "ONLY_TARGET": "only-target",
                "ONLY_SOURCE": "only-source",
                "MODIFIED": "modified",
            }.get(diff.diff_type, "")

            target_cell = (
                self._format_event_details(diff.target_details)
                if diff.target_details
                else "<em>Not present</em>"
            )
            source_cell = (
                self._format_event_details(diff.source_details)
                if diff.source_details
                else "<em>Not present</em>"
            )

            rows_html.append(
                f"""
                <tr class="{diff_class}">
                    <td>{diff.timestamp.strftime('%Y-%m-%d %H:%M:%S')}</td>
                    <td><code>{diff.event_type}</code></td>
                    <td>{diff.actor}</td>
                    <td>{target_cell}</td>
                    <td>{source_cell}</td>
                </tr>
            """
            )

        rows_content = (
            "\n".join(rows_html)
            if rows_html
            else "<tr><td colspan='5'><em>No differences detected</em></td></tr>"
        )

        return f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Governance Diff: {result.target_branch} vs {result.source_branch}</title>
            <style>
                body {{
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                    max-width: 1400px;
                    margin: 0 auto;
                    padding: 20px;
                    background: #f5f5f5;
                }}
                header {{
                    background: #2c3e50;
                    color: white;
                    padding: 20px;
                    border-radius: 8px;
                    margin-bottom: 20px;
                }}
                header h1 {{
                    margin: 0;
                    font-size: 24px;
                }}
                .stats {{
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 15px;
                    margin-bottom: 20px;
                }}
                .stat {{
                    background: white;
                    padding: 15px;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }}
                .stat-value {{
                    font-size: 32px;
                    font-weight: bold;
                    color: #2c3e50;
                }}
                .stat-label {{
                    color: #7f8c8d;
                    font-size: 14px;
                }}
                table {{
                    width: 100%;
                    background: white;
                    border-radius: 8px;
                    overflow: hidden;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }}
                th {{
                    background: #34495e;
                    color: white;
                    padding: 12px;
                    text-align: left;
                }}
                td {{
                    padding: 12px;
                    border-top: 1px solid #ecf0f1;
                }}
                .only-target {{
                    background: #e8f5e9;
                }}
                .only-source {{
                    background: #fff3e0;
                }}
                .modified {{
                    background: #fff9c4;
                }}
                code {{
                    background: #ecf0f1;
                    padding: 2px 6px;
                    border-radius: 3px;
                    font-family: 'Courier New', monospace;
                }}
            </style>
        </head>
        <body>
            <header>
                <h1>🔍 Governance Event Diff</h1>
                <p><strong>{result.target_branch}</strong> vs <strong>{result.source_branch}</strong></p>
                <p style="opacity: 0.8;">Generated: {result.timestamp.strftime('%Y-%m-%d %H:%M:%S')}</p>
            </header>
            
            <div class="stats">
                <div class="stat">
                    <div class="stat-value">{result.total_target_events}</div>
                    <div class="stat-label">Target Events</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{result.total_source_events}</div>
                    <div class="stat-label">Source Events</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{result.only_target_count}</div>
                    <div class="stat-label">Only Target</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{result.only_source_count}</div>
                    <div class="stat-label">Only Source</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{result.modified_count}</div>
                    <div class="stat-label">Modified</div>
                </div>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Event Type</th>
                        <th>Actor</th>
                        <th>{result.target_branch}</th>
                        <th>{result.source_branch}</th>
                    </tr>
                </thead>
                <tbody>
                    {rows_content}
                </tbody>
            </table>
        </body>
        </html>
        """

    def _format_event_details(self, details: Dict[str, Any]) -> str:
        """Format event details dictionary as HTML."""
        if not details:
            return "<em>No details</em>"

        items = []
        for key, value in details.items():
            items.append(f"<code>{key}</code>: {value}")

        return "<br>".join(items)
