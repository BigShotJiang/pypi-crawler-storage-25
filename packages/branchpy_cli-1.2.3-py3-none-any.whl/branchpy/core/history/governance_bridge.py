"""
Governance Integration Bridge — Audit Trail for History

Automatically logs every history operation to Governance Toolkit:
- ACTION_APPLIED: Operation executed
- ACTION_UNDONE: Operation reverted
- ACTION_RESTORED: Operation re-applied
- STATE_SNAPSHOT_CREATED: Snapshot persisted

Classes:
    HistoryEventType: Enum of history event types
    GovernanceBridge: Main governance integration

Example:
    >>> bridge = GovernanceBridge()
    >>> bridge.log_history_event("ACTION_APPLIED", history_action)

Version: v0.8.8
Dependencies: Governance Toolkit v0.8.6
"""

import asyncio
import json
import logging
import threading
import time
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Optional

if TYPE_CHECKING:
    from .snapshot import SnapshotMetadata
    from .stack import HistoryAction

logger = logging.getLogger(__name__)


class HistoryEventType(str, Enum):
    """
    History-related governance event types.

    Values:
        ACTION_APPLIED: User applies an operation (push to undo stack)
        ACTION_UNDONE: Operation reverted (undo)
        ACTION_RESTORED: Operation re-applied (redo)
        STATE_SNAPSHOT_CREATED: Project snapshot persisted
    """

    ACTION_APPLIED = "ACTION_APPLIED"
    ACTION_UNDONE = "ACTION_UNDONE"
    ACTION_RESTORED = "ACTION_RESTORED"
    STATE_SNAPSHOT_CREATED = "STATE_SNAPSHOT_CREATED"


class GovernanceBridge:
    """
    Bridge between History system and Governance Toolkit.

    Automatically logs every undoable operation as a governance event,
    creating a full audit trail for compliance and debugging.

    Example:
        >>> bridge = GovernanceBridge()
        >>> bridge.log_history_event(
        ...     HistoryEventType.ACTION_APPLIED,
        ...     history_action
        ... )
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize governance bridge.

        Args:
            project_root: Project root directory (defaults to current directory)
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self._governance_logger = None  # Lazy-loaded

    def log_history_event(
        self,
        event_type: str,
        action: Optional["HistoryAction"],
        additional_context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Log a history event to governance system.

        Args:
            event_type: HistoryEventType value
            action: HistoryAction being tracked (None for system events)
            additional_context: Optional extra metadata

        Side effects:
            - Appends to .branchpy/governance.jsonl
            - Emits daemon SSE event (if daemon running)
        """
        # Lazy-load governance logger
        if self._governance_logger is None:
            from branchpy.core.governance import GovernanceLogger

            self._governance_logger = GovernanceLogger(self.project_root)

        # Build event payload
        event_payload = {
            "event_type": event_type,
            "correlation_id": action.correlation_id if action else None,
            "actor": action.actor if action else "system",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "context": {
                "operation": action.operation if action else "unknown",
                "snapshot_before": action.snapshot_before if action else None,
                "snapshot_after": action.snapshot_after if action else None,
                "reversible": action.reversible if action else False,
                "compound_group": action.compound_group if action else None,
                "metadata": action.metadata if action else {},
            },
        }

        # Merge additional context
        if additional_context:
            event_payload["context"].update(additional_context)

        # Log to governance
        self._governance_logger.log_event(event_payload)

        logger.debug(
            f"Logged governance event: {event_type} "
            f"(correlation_id={action.correlation_id if action else 'N/A'})"
        )

    def log_snapshot_created(
        self,
        snapshot_id: str,
        metadata: "SnapshotMetadata",
    ) -> None:
        """
        Log snapshot creation event.

        Args:
            snapshot_id: Snapshot identifier
            metadata: SnapshotMetadata instance
        """
        event_payload = {
            "event_type": HistoryEventType.STATE_SNAPSHOT_CREATED,
            "correlation_id": metadata.correlation_id or snapshot_id,
            "actor": metadata.actor,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "context": {
                "snapshot_id": snapshot_id,
                "operation": metadata.operation,
                "project_path": metadata.project_path,
                "tags": metadata.tags,
            },
        }

        # Lazy-load governance logger
        if self._governance_logger is None:
            from branchpy.core.governance import GovernanceLogger

            self._governance_logger = GovernanceLogger(self.project_root)

        self._governance_logger.log_event(event_payload)

        logger.debug(f"Logged snapshot creation: {snapshot_id}")

    def query_history_events(
        self,
        correlation_id: Optional[str] = None,
        event_type: Optional[str] = None,
        limit: int = 100,
    ) -> list:
        """
        Query governance log for history events.

        Args:
            correlation_id: Filter by correlation ID
            event_type: Filter by HistoryEventType
            limit: Maximum number of events to return

        Returns:
            List of governance event dictionaries
        """
        if self._governance_logger is None:
            from branchpy.core.governance import GovernanceLogger

            self._governance_logger = GovernanceLogger(self.project_root)

        # Query governance log
        events = self._governance_logger.query_events(
            correlation_id=correlation_id, event_type=event_type, limit=limit
        )

        return events


# Example governance event schema:
EXAMPLE_EVENT = {
    "event_type": "ACTION_APPLIED",
    "correlation_id": "uuid-12345",
    "actor": "branchpy-cli",
    "timestamp": "2025-11-05T15:24:12Z",
    "context": {
        "operation": "AnalyzeProject",
        "snapshot_before": "snap_001",
        "snapshot_after": "snap_002",
        "reversible": True,
        "compound_group": None,
        "metadata": {
            "project": "HoS",
            "semantics": True,
            "stats_version": "2.0",
        },
    },
}


# ==================== Event Batching (v0.8.8.2+) ====================


class EventBatcher:
    """
    Batches governance events for improved write performance.

    Writes events in batches of BATCH_SIZE to reduce disk I/O.
    Automatically flushes on batch size or timeout.
    Integrates with compression for auto-rotation.
    """

    BATCH_SIZE = 10  # Write every 10 events
    FLUSH_TIMEOUT = 5.0  # Flush after 5 seconds of inactivity

    def __init__(self, log_path: Path, enable_compression: bool = True):
        self.log_path = log_path
        self.buffer: List[Dict[str, Any]] = []
        self.last_flush_time = time.time()
        self._lock = threading.Lock()
        self.enable_compression = enable_compression

        # Initialize compressor if enabled
        self.compressor = None
        if enable_compression:
            try:
                from .compression import HistoryFileCompressor

                # Get project path from log_path (.branchpy/history/governance.jsonl)
                project_path = log_path.parent.parent.parent
                self.compressor = HistoryFileCompressor(str(project_path))
            except Exception as e:
                logger.warning(f"Failed to initialize compressor: {e}")
                self.enable_compression = False

    def add_event(self, event: Dict[str, Any]) -> None:
        """
        Add event to batch buffer.

        Args:
            event: Governance event dictionary
        """
        with self._lock:
            self.buffer.append(event)

            # Flush if batch size reached
            if len(self.buffer) >= self.BATCH_SIZE:
                self._flush()

            # Flush if timeout reached
            elif time.time() - self.last_flush_time >= self.FLUSH_TIMEOUT:
                self._flush()

    def _flush(self) -> None:
        """Write buffered events to disk (internal, assumes lock held)."""
        if not self.buffer:
            return

        try:
            # Ensure parent directories exist
            self.log_path.parent.mkdir(parents=True, exist_ok=True)

            # Append all events to JSONL file
            with open(self.log_path, "a", encoding="utf-8") as f:
                for event in self.buffer:
                    f.write(json.dumps(event) + "\n")

            logger.debug(
                f"Flushed {len(self.buffer)} governance events to {self.log_path}"
            )
            self.buffer.clear()
            self.last_flush_time = time.time()

            # Auto-rotate file if compression enabled and threshold exceeded
            if self.compressor:
                try:
                    self.compressor.auto_rotate("governance.jsonl")
                except Exception as comp_err:
                    logger.warning(f"Auto-rotation failed: {comp_err}")

        except Exception as e:
            logger.error(f"Failed to flush governance events: {e}")
            # Keep events in buffer for retry

    def flush(self) -> None:
        """Force flush all buffered events (public API)."""
        with self._lock:
            self._flush()

    def __del__(self):
        """Ensure events are flushed on deletion."""
        try:
            self.flush()
        except Exception:
            pass  # Ignore errors during cleanup


# Global batcher instance (initialized on first use)
_batcher: Optional[EventBatcher] = None
_batcher_lock = threading.Lock()


def get_batcher(log_path: Path) -> EventBatcher:
    """
    Get or create global event batcher.

    Args:
        log_path: Path to governance log file

    Returns:
        EventBatcher instance
    """
    global _batcher

    with _batcher_lock:
        if _batcher is None or _batcher.log_path != log_path:
            # Flush old batcher if exists
            if _batcher is not None:
                _batcher.flush()

            _batcher = EventBatcher(log_path)

        return _batcher


# ==================== SSE Emission (v0.8.8.2+) ====================


class SSEEmitter:
    """
    Emits governance events to daemon subscribers via Server-Sent Events.

    Allows real-time monitoring of governance activities in dashboard/UI.
    """

    def __init__(self):
        self.subscribers: List[asyncio.Queue] = []
        self._lock = asyncio.Lock()

    async def subscribe(self) -> asyncio.Queue:
        """
        Subscribe to governance events.

        Returns:
            Queue that receives event dictionaries
        """
        queue = asyncio.Queue(maxsize=100)
        async with self._lock:
            self.subscribers.append(queue)
        return queue

    async def unsubscribe(self, queue: asyncio.Queue) -> None:
        """Remove subscriber queue."""
        async with self._lock:
            if queue in self.subscribers:
                self.subscribers.remove(queue)

    async def emit(self, event: Dict[str, Any]) -> None:
        """
        Emit event to all subscribers.

        Args:
            event: Governance event dictionary
        """
        async with self._lock:
            dead_queues = []

            for queue in self.subscribers:
                try:
                    # Non-blocking put (drop if queue full)
                    queue.put_nowait(event)
                except asyncio.QueueFull:
                    logger.warning("Subscriber queue full, marking as dead")
                    dead_queues.append(queue)
                except Exception as e:
                    logger.error(f"Failed to emit to subscriber: {e}")
                    dead_queues.append(queue)

            # Remove dead queues
            for dead in dead_queues:
                self.subscribers.remove(dead)


# Global SSE emitter (initialized lazily)
_sse_emitter: Optional[SSEEmitter] = None


def get_sse_emitter() -> SSEEmitter:
    """Get or create global SSE emitter."""
    global _sse_emitter
    if _sse_emitter is None:
        _sse_emitter = SSEEmitter()
    return _sse_emitter


def reset_sse_emitter() -> None:
    """Reset global SSE emitter (for testing)."""
    global _sse_emitter
    _sse_emitter = None


# ==================== Event Replay (v0.8.8.2+) ====================


def replay_events(
    log_path: Path, from_timestamp: Optional[str] = None
) -> Iterator[Dict[str, Any]]:
    """
    Replay governance events from log file.

    Allows reconstructing history state from audit trail.

    Args:
        log_path: Path to governance JSONL log
        from_timestamp: Optional ISO timestamp to start replay from

    Yields:
        Governance event dictionaries in chronological order

    Example:
        for event in replay_events(log_path, from_timestamp="2025-11-05T10:00:00Z"):
            if event["event_type"] == "snapshot.created":
                # Reconstruct snapshot history
                pass
    """
    if not log_path.exists():
        return

    from_dt = None
    if from_timestamp:
        from_dt = datetime.fromisoformat(from_timestamp.replace("Z", "+00:00"))

    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                event = json.loads(line.strip())

                # Filter by timestamp if requested
                if from_dt:
                    event_ts = datetime.fromisoformat(
                        event["timestamp"].replace("Z", "+00:00")
                    )
                    if event_ts < from_dt:
                        continue

                yield event

            except Exception as e:
                logger.warning(f"Skipping corrupt event in replay: {e}")
                continue


# TODO: Wire batching into GovernanceLogger.log_event()
# TODO: Wire SSE emission into daemon routes
# TODO: Add replay endpoint to daemon API
