"""
History File Compression (v0.9.0)

Implements gzip compression for governance.jsonl and history JSONL files
with automatic rotation when files exceed size threshold.

Features:
- Transparent gzip compression/decompression
- Auto-rotation at configurable threshold (default: 10MB)
- Maintains .jsonl.gz archive files
- Utilities for reading compressed and uncompressed files
- Compression stats and reporting

Classes:
    CompressionStats: Statistics about compression operations
    HistoryFileCompressor: Main compression manager

Example:
    >>> compressor = HistoryFileCompressor(project_path)
    >>> compressor.compress_file("governance.jsonl")
    >>> stats = compressor.get_stats("governance.jsonl")
    >>> print(f"Compression ratio: {stats.compression_ratio:.1%}")

Version: v0.9.0
Author: BranchPy Team
"""

import gzip
import json
import logging
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class CompressionStats:
    """Statistics about file compression."""

    original_size: int
    compressed_size: int
    compression_ratio: float
    file_path: str
    compressed_path: Path  # Path object for easier manipulation
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "original_size": self.original_size,
            "compressed_size": self.compressed_size,
            "compression_ratio": self.compression_ratio,
            "file_path": self.file_path,
            "compressed_path": str(self.compressed_path),  # Convert Path to str
            "timestamp": self.timestamp,
        }


class HistoryFileCompressor:
    """
    Manages compression of history and governance log files.

    Features:
        - Gzip compression with optimal settings
        - Auto-rotation at size threshold
        - Read compressed archives transparently
        - Compression statistics tracking

    Attributes:
        project_path: Project root directory
        history_dir: .branchpy/history directory
        size_threshold: File size threshold for auto-rotation (bytes)
    """

    DEFAULT_SIZE_THRESHOLD = 10 * 1024 * 1024  # 10MB

    def __init__(
        self,
        project_path: str,
        size_threshold: Optional[int] = None,
        size_threshold_mb: Optional[float] = None,
    ):
        """
        Initialize compressor.

        Args:
            project_path: Project root path
            size_threshold: Size threshold in bytes for auto-rotation
            size_threshold_mb: Size threshold in MB (alternative to size_threshold)
        """
        self.project_path = Path(project_path)
        self.history_dir = self.project_path / ".branchpy" / "history"
        self.archives_dir = self.history_dir / "archives"

        # Set threshold (MB takes precedence)
        if size_threshold_mb is not None:
            self.size_threshold = int(size_threshold_mb * 1024 * 1024)
        elif size_threshold is not None:
            self.size_threshold = size_threshold
        else:
            self.size_threshold = self.DEFAULT_SIZE_THRESHOLD

        # Ensure directories exist
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.archives_dir.mkdir(parents=True, exist_ok=True)

    def compress_file(
        self, filename: str, delete_original: bool = False
    ) -> CompressionStats:
        """
        Compress a JSONL file using gzip.

        Args:
            filename: Filename relative to history directory
            delete_original: Whether to delete original after compression (default False).
                            Note: auto_rotate() uses True to save disk space.

        Returns:
            CompressionStats with compression details

        Raises:
            FileNotFoundError: If file doesn't exist
            IOError: If compression fails

        Example:
            >>> # Manual compression (keeps original)
            >>> stats = compressor.compress_file("governance.jsonl")
            >>> # Auto-rotation (deletes original to save space)
            >>> stats = compressor.auto_rotate("governance.jsonl")
        """
        source_path = self.history_dir / filename

        if not source_path.exists():
            raise FileNotFoundError(f"File not found: {source_path}")

        # Generate archive filename with timestamp (including microseconds to avoid collisions)
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        archive_name = f"{filename}.{timestamp}.gz"
        archive_path = self.archives_dir / archive_name

        # Ensure archive directory exists
        archive_path.parent.mkdir(parents=True, exist_ok=True)

        # Get original size
        original_size = source_path.stat().st_size

        # Compress with optimal settings (level 6 is good balance)
        try:
            with open(source_path, "rb") as f_in:
                with gzip.open(archive_path, "wb", compresslevel=6) as f_out:
                    shutil.copyfileobj(f_in, f_out)

            compressed_size = archive_path.stat().st_size
            compression_ratio = (
                1 - (compressed_size / original_size) if original_size > 0 else 0
            )

            stats = CompressionStats(
                original_size=original_size,
                compressed_size=compressed_size,
                compression_ratio=compression_ratio,
                file_path=str(source_path),
                compressed_path=archive_path,  # Keep as Path object
                timestamp=datetime.utcnow().isoformat() + "Z",
            )

            logger.info(
                f"Compressed {filename}: {original_size:,} → {compressed_size:,} bytes "
                f"({compression_ratio:.1%} reduction)"
            )

            # Delete original if requested
            if delete_original:
                source_path.unlink()
                logger.debug(f"Deleted original file: {source_path}")

            return stats

        except Exception as e:
            logger.error(f"Compression failed for {filename}: {e}")
            # Clean up partial archive
            if archive_path.exists():
                archive_path.unlink()
            raise IOError(f"Compression failed: {e}")

    def decompress_file(
        self, archive_path: str, output_filename: Optional[str] = None
    ) -> Path:
        """
        Decompress a gzipped archive.

        Args:
            archive_path: Path to .gz file (relative to history/archives/)
            output_filename: Output filename (default: inferred from archive name)

        Returns:
            Path to decompressed file

        Example:
            >>> path = compressor.decompress_file("governance.jsonl.20251106_120000.gz")
            >>> print(f"Decompressed to: {path}")
        """
        archive = self.archives_dir / archive_path

        if not archive.exists():
            raise FileNotFoundError(f"Archive not found: {archive}")

        # Infer output filename if not provided
        if output_filename is None:
            # Remove .gz and timestamp: governance.jsonl.20251106_120000.gz → governance.jsonl
            name_parts = archive.stem.rsplit(".", 1)
            output_filename = name_parts[0] if len(name_parts) > 1 else archive.stem

        output_path = self.history_dir / output_filename

        try:
            with gzip.open(archive, "rb") as f_in:
                with open(output_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)

            logger.info(f"Decompressed {archive.name} → {output_filename}")
            return output_path

        except gzip.BadGzipFile:
            # Let gzip errors propagate for testing
            raise
        except Exception as e:
            logger.error(f"Decompression failed for {archive_path}: {e}")
            raise IOError(f"Decompression failed: {e}")

    def check_rotation_needed(self, filename: str) -> bool:
        """
        Check if file exceeds size threshold and needs rotation.

        Args:
            filename: Filename to check

        Returns:
            True if file should be rotated
        """
        file_path = self.history_dir / filename

        if not file_path.exists():
            return False

        size = file_path.stat().st_size
        return size >= self.size_threshold

    def auto_rotate(self, filename: str) -> Optional[CompressionStats]:
        """
        Automatically rotate file if it exceeds threshold.

        **Important**: This DELETES the original file after compression to save disk space.
        The compressed archive is stored in .branchpy/history/archives/

        Args:
            filename: Filename to check and rotate

        Returns:
            CompressionStats if rotation occurred, None if file below threshold

        Example:
            >>> stats = compressor.auto_rotate("governance.jsonl")
            >>> if stats:
            ...     print(f"Rotated! Saved {stats.compression_ratio:.1%}")
            ...     # Original file is now deleted, data in archive
        """
        if self.check_rotation_needed(filename):
            logger.info(
                f"Auto-rotating {filename} (exceeds {self.size_threshold:,} bytes)"
            )
            return self.compress_file(filename, delete_original=True)
        return None

    def read_jsonl(
        self, filename: str, include_archives: bool = True
    ) -> Iterator[Dict[str, Any]]:
        """
        Read JSONL file, including archived compressed files.
        Reads archives first (oldest to newest), then current file.

        Args:
            filename: Base filename (e.g., "governance.jsonl")
            include_archives: Whether to also read archived versions

        Yields:
            Parsed JSON objects from archived and current files

        Example:
            >>> for event in compressor.read_jsonl("governance.jsonl"):
            ...     print(event["event_type"])
        """
        # Read archived files first (oldest to newest)
        if include_archives:
            if self.archives_dir.exists():
                # Find all archives for this file (sorted by timestamp)
                pattern = f"{filename}.*.gz"
                archives = sorted(self.archives_dir.glob(pattern))

                for archive in archives:
                    try:
                        with gzip.open(archive, "rt", encoding="utf-8") as f:
                            for line in f:
                                line = line.strip()
                                if line:
                                    try:
                                        yield json.loads(line)
                                    except json.JSONDecodeError:
                                        logger.warning(
                                            f"Skipping malformed line in {archive.name}"
                                        )
                    except Exception as e:
                        logger.warning(f"Error reading archive {archive.name}: {e}")

        # Read current file last (most recent data)
        current_file = self.history_dir / filename
        if current_file.exists():
            try:
                with open(current_file, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                yield json.loads(line)
                            except json.JSONDecodeError:
                                logger.warning(f"Skipping malformed line in {filename}")
            except Exception as e:
                logger.warning(f"Error reading {filename}: {e}")

    def get_stats(self, filename: str) -> Dict[str, Any]:
        """
        Get statistics about current file and archives.

        Args:
            filename: Base filename

        Returns:
            Dictionary with file statistics (keys: current_file_size, total_archives,
            total_archived_size, compression_ratio, rotation_recommended)
        """
        # Current file stats
        current_file = self.history_dir / filename
        current_size = current_file.stat().st_size if current_file.exists() else 0

        # Archive stats
        archives = []
        total_archived_size = 0
        total_original_size = 0

        if self.archives_dir.exists():
            pattern = f"{filename}.*.gz"
            archive_files = sorted(self.archives_dir.glob(pattern))

            for archive in archive_files:
                archive_size = archive.stat().st_size
                archives.append(
                    {
                        "name": archive.name,
                        "path": str(archive),
                        "size": archive_size,
                        "timestamp": archive.stem.split(".")[-1],  # Extract timestamp
                    }
                )
                total_archived_size += archive_size

        # Calculate compression ratio if we have archives
        # We estimate original size from archives (gzip typically achieves 70-90% compression)
        compression_ratio = None
        if total_archived_size > 0:
            # Estimate: if compressed is X, original was roughly X / 0.2 (assuming 80% compression)
            estimated_original = total_archived_size / 0.2
            compression_ratio = 1 - (total_archived_size / estimated_original)

        return {
            "current_file_size": current_size,
            "total_archives": len(archives),
            "total_archived_size": total_archived_size,
            "compression_ratio": compression_ratio,
            "rotation_recommended": current_size >= self.size_threshold,
            "archives": archives,
        }

    def list_archives(self, filename: Optional[str] = None) -> List[Path]:
        """
        List compressed archives for a specific file or all archives.

        Args:
            filename: Base filename to filter archives (None = all archives)

        Returns:
            List of archive Path objects sorted by timestamp
        """
        if not self.archives_dir.exists():
            return []

        if filename:
            pattern = f"{filename}.*.gz"
        else:
            pattern = "*.gz"

        return sorted(self.archives_dir.glob(pattern))

    def cleanup_old_archives(self, filename: str, keep_count: int = 10) -> int:
        """
        Remove old archives, keeping only the most recent N files.

        Args:
            filename: Base filename pattern
            keep_count: Number of archives to keep

        Returns:
            Number of archives deleted
        """
        if not self.archives_dir.exists():
            return 0

        pattern = f"{filename}.*.gz"
        archives = sorted(self.archives_dir.glob(pattern), reverse=True)

        deleted = 0
        for archive in archives[keep_count:]:
            try:
                archive.unlink()
                deleted += 1
                logger.debug(f"Deleted old archive: {archive.name}")
            except Exception as e:
                logger.warning(f"Failed to delete {archive.name}: {e}")

        if deleted > 0:
            logger.info(f"Cleaned up {deleted} old archives for {filename}")

        return deleted
