"""
BranchPy v0.8.8.2 — Enhanced History System (Collaboration & Intelligence)

This package provides reversible edit tracking, project state snapshots,
timeline branching, incremental snapshots, branch merging, auto-consolidation,
and interactive diff export capabilities for both CLI and VS Code.

Core Components:
    - EditStack: In-memory undo/redo stack manager
    - Snapshot: Project state serialization, diffing, and restoration
    - DiffEngine: Structural diff engine for JSON-like models
    - Persistence: JSONL-based history storage
    - GovernanceBridge: Audit trail integration
    - Timeline: Branch management (v0.8.8.1)
    - DiffExporter: HTML/JSON export with interactivity (v0.8.8.2)
    - MergeEngine: Three-way branch merging (v0.8.8.2)
    - ConsolidationDaemon: Auto-consolidation background task (v0.8.8.2)
    - GovernanceDiffEngine: Cross-branch governance comparison (v0.8.8.2)
    - HistoryFileCompressor: JSONL compression with auto-rotation (v0.9.0)

Usage:
    >>> from branchpy.core.history import EditStack, Snapshot, Timeline, MergeEngine
    >>> stack = EditStack(capacity=100)
    >>> snapshot_id = Snapshot.create(metadata)
    >>> Snapshot.restore(project_path, snapshot_id, create_backup=True)
    >>> timeline = Timeline(project_path)
    >>> branch_id = timeline.create_branch("experiment_1", from_snapshot=snapshot_id)
    >>> # v0.8.8.2 features
    >>> merge_engine = MergeEngine(history_dir, snapshot_manager)
    >>> result = merge_engine.merge_branches("main", "feature-menu", MergeStrategy.AUTO)
    >>> # v0.9.0 compression
    >>> compressor = HistoryFileCompressor(project_path)
    >>> compressor.auto_rotate("governance.jsonl")

Version: v0.8.8.2
Dependencies:
    - Daemon Mode (v0.7.20)
    - Governance Toolkit (v0.8.6)
    - Image Validation V2 (v0.8.7.5)

See Also:
    - docs/v0.9.0/Core/History/enhanced_history_features.md
    - docs/v0.9.0/CLI/commands/history.md
    - docs/v0.9.0/releases/v0.8.8.2_RELEASE_SUMMARY.md
    - docs/v0.9.0/branch_merging_guide.md
    - docs/v0.9.0/interactive_diff_guide.md
"""

from .compression import CompressionStats, HistoryFileCompressor
from .consolidation_daemon import (
    ConsolidationConfig,
    ConsolidationDaemon,
    ConsolidationResult,
)
from .delta_reconstructor import (
    ChainValidationResult,
    DeltaChainError,
    DeltaReconstructor,
    ReconstructionCache,
)
from .diff_export import DiffExporter
from .governance_bridge import GovernanceBridge, HistoryEventType
from .governance_diff import (
    EventDiff,
    EventFilterType,
    GovernanceDiffEngine,
    GovernanceDiffResult,
)
from .merge_engine import (
    ConflictResolution,
    ConflictType,
    MergeConflict,
    MergeEngine,
    MergeResult,
    MergeStrategy,
)
from .persistence import HistoryPersistence
from .snapshot import (
    IntegrityError,
    Snapshot,
    SnapshotManager,
    SnapshotMetadata,
    SnapshotType,
)
from .snapshot_optimizer import (
    RetentionPolicy,
    RetentionStrategy,
    SnapshotOptimizer,
    StorageStats,
)
from .stack import EditStack, HistoryAction
from .timeline import Branch, Timeline

__all__ = [
    # Core stack operations
    "EditStack",
    "HistoryAction",
    # Snapshot management
    "Snapshot",
    "SnapshotMetadata",
    "SnapshotType",
    "IntegrityError",
    "SnapshotManager",
    # Diff computation
    # Persistence
    "HistoryPersistence",
    # Governance
    "GovernanceBridge",
    "HistoryEventType",
    # v0.8.8.1 additions
    "Timeline",
    "Branch",
    "DiffExporter",
    # v0.8.8.2 additions
    "MergeEngine",
    "MergeConflict",
    "MergeResult",
    "MergeStrategy",
    "ConflictResolution",
    "ConflictType",
    "ConsolidationDaemon",
    "ConsolidationConfig",
    "ConsolidationResult",
    "GovernanceDiffEngine",
    "GovernanceDiffResult",
    "EventDiff",
    "EventFilterType",
    # v0.9.0 additions
    "HistoryFileCompressor",
    "CompressionStats",
    "SnapshotOptimizer",
    "RetentionPolicy",
    "RetentionStrategy",
    "StorageStats",
    "DeltaReconstructor",
    "DeltaChainError",
    "ReconstructionCache",
    "ChainValidationResult",
]

__version__ = "0.8.8.2"


# Lazy attribute access to avoid eager import cycles (DT-002C)
def __getattr__(name: str):  # pragma: no cover - trivial
    if name in {"DiffEngine", "DiffPatch"}:
        from .diff_engine import DiffEngine, DiffPatch  # Local import breaks cycle

        return DiffEngine if name == "DiffEngine" else DiffPatch
    raise AttributeError(name)
