"""
Branch Merging Engine for Enhanced History (v0.8.8.2)

Implements three-way merge algorithm for BranchPy timeline branches with conflict
detection and resolution strategies. Supports structural merging of CFG, Stats, and Assets.

Architecture:
- Three-way merge: Base ← Ours ← Theirs
- Conflict types: NODE_MODIFIED, EDGE_MODIFIED, NODE_DELETED, ADD_ADD
- Resolution strategies: AUTO, OURS, THEIRS, INTERACTIVE
- Governance integration: BRANCH_MERGED, CONFLICT_RESOLVED events

Author: BranchPy Team
Date: November 2025
Version: 0.8.8.2-alpha
"""

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from .snapshot import SnapshotManager
from .timeline import Branch, Timeline

# ============================================================================
# Enums
# ============================================================================


class ConflictType(Enum):
    """Types of merge conflicts detected during branch merging."""

    NODE_MODIFIED = "node_modified"  # Same node modified in both branches
    EDGE_MODIFIED = "edge_modified"  # Same edge modified in both branches
    NODE_DELETED = "node_deleted"  # Node deleted in one branch, modified in other
    EDGE_DELETED = "edge_deleted"  # Edge deleted in one branch, modified in other
    ADD_ADD = "add_add"  # Same node/edge added with different content


class MergeStrategy(Enum):
    """Resolution strategies for merge conflicts."""

    AUTO = "auto"  # Attempt automatic resolution (fail if conflicts)
    OURS = "ours"  # Always use target branch changes
    THEIRS = "theirs"  # Always use source branch changes
    INTERACTIVE = "interactive"  # Require manual resolution via UI


class ConflictResolution(Enum):
    """User's resolution choice for individual conflicts."""

    USE_OURS = "use_ours"
    USE_THEIRS = "use_theirs"
    MANUAL = "manual"  # User provides custom merged content


# ============================================================================
# Data Classes
# ============================================================================


@dataclass
class MergeConflict:
    """
    Represents a single merge conflict detected during branch merging.

    Attributes:
        conflict_id: Unique identifier (SHA-256 of path + type)
        conflict_type: Type of conflict (NODE_MODIFIED, etc.)
        path: JSON path to conflicting element (e.g., "cfg.nodes.node_123")
        base_value: Value in common ancestor snapshot
        ours_value: Value in target branch (current)
        theirs_value: Value in source branch (merging from)
        resolution: User's chosen resolution (None if unresolved)
        resolved_value: Final merged value (None if unresolved)
    """

    conflict_id: str
    conflict_type: ConflictType
    path: str
    base_value: Optional[Any]
    ours_value: Optional[Any]
    theirs_value: Optional[Any]
    resolution: Optional[ConflictResolution] = None
    resolved_value: Optional[Any] = None

    @staticmethod
    def generate_id(path: str, conflict_type: ConflictType) -> str:
        """Generate deterministic conflict ID from path and type."""
        content = f"{path}:{conflict_type.value}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]


@dataclass
class MergeResult:
    """
    Result of a branch merge operation.

    Attributes:
        success: Whether merge completed without unresolved conflicts
        target_branch: Branch being merged into
        source_branch: Branch being merged from
        base_snapshot_id: Common ancestor snapshot ID
        conflicts: List of conflicts detected (empty if none)
        merged_snapshot_id: ID of created merge commit snapshot (None if failed)
        message: Human-readable result message
        timestamp: When merge was performed
        governance_event_id: ID of BRANCH_MERGED governance event
    """

    success: bool
    target_branch: str
    source_branch: str
    base_snapshot_id: str
    conflicts: List[MergeConflict] = field(default_factory=list)
    merged_snapshot_id: Optional[str] = None
    message: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    governance_event_id: Optional[str] = None

    @property
    def has_conflicts(self) -> bool:
        """Check if merge has unresolved conflicts."""
        return any(c.resolution is None for c in self.conflicts)


# ============================================================================
# Merge Engine
# ============================================================================


class MergeEngine:
    """
    Three-way merge engine for BranchPy timeline branches.

    Workflow:
        1. Find common ancestor snapshot (base)
        2. Load target (ours) and source (theirs) snapshots
        3. Detect conflicts across CFG/Stats/Assets
        4. Apply resolution strategy
        5. Create merge commit snapshot
        6. Emit governance events

    Usage:
        >>> engine = MergeEngine(history_dir, snapshot_manager)
        >>> result = engine.merge_branches("main", "feature-menu", MergeStrategy.AUTO)
        >>> if result.success:
        ...     print(f"Merged! Snapshot: {result.merged_snapshot_id}")
        ... else:
        ...     print(f"Conflicts: {len(result.conflicts)}")
    """

    def __init__(
        self,
        history_dir: Path,
        snapshot_manager: SnapshotManager,
        governance_logger=None,
    ):
        """
        Initialize merge engine.

        Args:
            history_dir: Path to .branchpy/history directory
            snapshot_manager: SnapshotManager instance for creating merge commits
            governance_logger: Optional GovernanceLogger for event emission
        """
        self.history_dir = Path(history_dir)
        self.snapshot_manager = snapshot_manager
        self.governance_logger = governance_logger
        # history_dir is .branchpy/history, so parent.parent gives project root
        self.timeline = Timeline(str(self.history_dir.parent.parent))

    def merge_branches(
        self,
        target_branch: str,
        source_branch: str,
        strategy: MergeStrategy = MergeStrategy.AUTO,
        message: Optional[str] = None,
        manual_resolutions: Optional[Dict[str, ConflictResolution]] = None,
    ) -> MergeResult:
        """
        Merge source branch into target branch using specified strategy.

        Args:
            target_branch: Branch to merge into (e.g., "main")
            source_branch: Branch to merge from (e.g., "feature-menu")
            strategy: Resolution strategy for conflicts
            message: Optional custom merge commit message
            manual_resolutions: Dict of conflict_id -> ConflictResolution for INTERACTIVE

        Returns:
            MergeResult with success status, conflicts, and merge commit ID

        Raises:
            ValueError: If branches don't exist or are same
            FileNotFoundError: If snapshots not found
        """
        # Validate branches
        target = self.timeline.get_branch(target_branch)
        source = self.timeline.get_branch(source_branch)

        if not target or not source:
            raise ValueError(
                f"Branches not found: target={target_branch}, source={source_branch}"
            )

        if target_branch == source_branch:
            raise ValueError("Cannot merge branch into itself")

        # Find common ancestor
        base_snapshot_id = self._find_common_ancestor(target, source)

        # Load snapshots
        base_data = self._load_snapshot(base_snapshot_id)
        ours_data = self._load_snapshot(target.current_snapshot_id)
        theirs_data = self._load_snapshot(source.current_snapshot_id)

        # Detect conflicts
        conflicts = self._detect_conflicts(base_data, ours_data, theirs_data)

        # Apply resolution strategy
        resolved_conflicts = self._resolve_conflicts(
            conflicts, strategy, manual_resolutions or {}
        )

        # Check for unresolved conflicts
        result = MergeResult(
            success=False,
            target_branch=target_branch,
            source_branch=source_branch,
            base_snapshot_id=base_snapshot_id,
            conflicts=resolved_conflicts,
        )

        if result.has_conflicts:
            result.message = (
                f"Merge failed: {len(result.conflicts)} unresolved conflicts"
            )
            return result

        # Apply merge
        merged_data = self._apply_merge(
            base_data, ours_data, theirs_data, resolved_conflicts
        )

        # Create merge commit snapshot
        merge_message = (
            message or f"Merge branch '{source_branch}' into '{target_branch}'"
        )
        snapshot_id = self._create_merge_commit(
            target_branch, merged_data, merge_message, source_branch
        )

        # Emit governance event
        governance_event_id = self._emit_merge_event(
            target_branch, source_branch, snapshot_id, resolved_conflicts
        )

        result.success = True
        result.merged_snapshot_id = snapshot_id
        result.message = f"Successfully merged '{source_branch}' into '{target_branch}'"
        result.governance_event_id = governance_event_id

        return result

    def _find_common_ancestor(self, branch1: Branch, branch2: Branch) -> str:
        """
        Find most recent common ancestor snapshot between two branches.

        Algorithm:
            1. Check if branches share the same created_from_snapshot (common case)
            2. Build ancestry chain for branch1 using branch parent relationships
            3. Walk branch2's ancestry until finding match
            4. Return the snapshot ID where they diverged

        Args:
            branch1: First branch
            branch2: Second branch

        Returns:
            Snapshot ID of common ancestor

        Raises:
            ValueError: If no common ancestor found (orphaned branches)
        """
        # Fast path: both branches forked from same snapshot
        if branch1.created_from_snapshot == branch2.created_from_snapshot:
            # Handle empty snapshot (main branch with no snapshot)
            if not branch1.created_from_snapshot:
                raise ValueError(
                    f"Cannot merge branches with no common ancestor snapshot. "
                    f"Branch '{branch1.name}' has no created_from_snapshot."
                )
            return branch1.created_from_snapshot

        # Build branch ancestry chain for branch1 (branch → parent branch → ...)
        ancestry1_branches = set()
        ancestry1_snapshots = set()
        current_branch_id = branch1.id

        visited = set()
        while current_branch_id:
            if current_branch_id in visited:
                break  # Circular reference (shouldn't happen)

            branch_info = self.timeline.get_branch(current_branch_id)
            if not branch_info:
                break

            ancestry1_branches.add(current_branch_id)
            # Only add non-empty snapshots to ancestry
            if branch_info.created_from_snapshot:
                ancestry1_snapshots.add(branch_info.created_from_snapshot)
            if branch_info.current_snapshot_id:
                ancestry1_snapshots.add(branch_info.current_snapshot_id)
            visited.add(current_branch_id)

            # Move to parent branch
            current_branch_id = branch_info.parent_branch

        # Walk branch2's ancestry until finding match
        current_branch_id = branch2.id
        visited2 = set()

        while current_branch_id:
            if current_branch_id in visited2:
                break

            branch_info = self.timeline.get_branch(current_branch_id)
            if not branch_info:
                break

            # Check if this branch's snapshots intersect with branch1's ancestry
            if branch_info.created_from_snapshot in ancestry1_snapshots:
                return branch_info.created_from_snapshot
            if branch_info.current_snapshot_id in ancestry1_snapshots:
                return branch_info.current_snapshot_id

            visited2.add(current_branch_id)
            current_branch_id = branch_info.parent_branch

        raise ValueError(
            f"no common ancestor found between branches "
            f"'{branch1.name}' and '{branch2.name}' (orphaned branches)"
        )

    def _get_parent_snapshot(self, snapshot_id: str) -> Optional[str]:
        """Get parent snapshot ID from snapshot metadata."""
        snapshot_path = self.history_dir / "snapshots" / f"{snapshot_id}.json"
        if not snapshot_path.exists():
            return None

        with open(snapshot_path, "r", encoding="utf-8") as f:
            metadata = json.load(f).get("metadata", {})
            return metadata.get("parent_snapshot_id")

    def _load_snapshot(self, snapshot_id: str) -> Dict[str, Any]:
        """Load snapshot data (CFG + Stats + Assets)."""
        # Try both .json and .json.gz formats
        snapshot_path_json = self.history_dir / "snapshots" / f"{snapshot_id}.json"
        snapshot_path_gz = self.history_dir / "snapshots" / f"{snapshot_id}.json.gz"

        if snapshot_path_gz.exists():
            import gzip

            with gzip.open(snapshot_path_gz, "rt", encoding="utf-8") as f:
                data = json.load(f)
        elif snapshot_path_json.exists():
            with open(snapshot_path_json, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            raise FileNotFoundError(f"Snapshot not found: {snapshot_id}")

        return {
            "cfg": data.get("cfg", {}),
            "stats": data.get("stats", {}),
            "assets": data.get("assets", []),
        }

    def _detect_conflicts(
        self, base: Dict[str, Any], ours: Dict[str, Any], theirs: Dict[str, Any]
    ) -> List[MergeConflict]:
        """
        Detect conflicts between ours and theirs relative to base.

        Three-way merge logic:
            - If ours == theirs: No conflict (same change or no change)
            - If ours == base and theirs != base: Accept theirs (only they changed)
            - If theirs == base and ours != base: Accept ours (only we changed)
            - If all three differ: Conflict (divergent changes)

        Args:
            base: Common ancestor snapshot data
            ours: Target branch snapshot data
            theirs: Source branch snapshot data

        Returns:
            List of detected conflicts
        """
        conflicts = []

        # Detect CFG node conflicts
        conflicts.extend(
            self._detect_node_conflicts(
                base.get("cfg", {}).get("nodes", {}),
                ours.get("cfg", {}).get("nodes", {}),
                theirs.get("cfg", {}).get("nodes", {}),
            )
        )

        # Detect CFG edge conflicts
        conflicts.extend(
            self._detect_edge_conflicts(
                base.get("cfg", {}).get("edges", []),
                ours.get("cfg", {}).get("edges", []),
                theirs.get("cfg", {}).get("edges", []),
            )
        )

        # Detect Stats conflicts
        conflicts.extend(
            self._detect_stats_conflicts(
                base.get("stats", {}), ours.get("stats", {}), theirs.get("stats", {})
            )
        )

        # Detect Assets conflicts (simpler - just check list equality)
        base_assets = set(base.get("assets", []))
        ours_assets = set(ours.get("assets", []))
        theirs_assets = set(theirs.get("assets", []))

        if ours_assets != theirs_assets:
            added_both = (ours_assets - base_assets) & (theirs_assets - base_assets)
            for asset in added_both:
                conflicts.append(
                    MergeConflict(
                        conflict_id=MergeConflict.generate_id(
                            f"assets.{asset}", ConflictType.ADD_ADD
                        ),
                        conflict_type=ConflictType.ADD_ADD,
                        path=f"assets.{asset}",
                        base_value=None,
                        ours_value=asset,
                        theirs_value=asset,
                    )
                )

        return conflicts

    def _detect_node_conflicts(
        self, base_nodes: Any, ours_nodes: Any, theirs_nodes: Any
    ) -> List[MergeConflict]:
        """
        Detect conflicts in CFG nodes.

        Handles both list-based (BranchPy format) and dict-based node structures.
        """
        conflicts = []

        # Convert list-based nodes to dict for easier comparison
        def normalize_nodes(nodes):
            if isinstance(nodes, list):
                return {node["id"]: node for node in nodes if "id" in node}
            elif isinstance(nodes, dict):
                return nodes
            else:
                return {}

        base_dict = normalize_nodes(base_nodes)
        ours_dict = normalize_nodes(ours_nodes)
        theirs_dict = normalize_nodes(theirs_nodes)

        all_node_ids = (
            set(base_dict.keys()) | set(ours_dict.keys()) | set(theirs_dict.keys())
        )

        for node_id in all_node_ids:
            base_node = base_dict.get(node_id)
            ours_node = ours_dict.get(node_id)
            theirs_node = theirs_dict.get(node_id)

            # Node deleted in one branch, modified in other
            if base_node and not ours_node and theirs_node != base_node:
                conflicts.append(
                    MergeConflict(
                        conflict_id=MergeConflict.generate_id(
                            f"cfg.nodes.{node_id}", ConflictType.NODE_DELETED
                        ),
                        conflict_type=ConflictType.NODE_DELETED,
                        path=f"cfg.nodes.{node_id}",
                        base_value=base_node,
                        ours_value=None,
                        theirs_value=theirs_node,
                    )
                )
            elif base_node and ours_node != base_node and not theirs_node:
                conflicts.append(
                    MergeConflict(
                        conflict_id=MergeConflict.generate_id(
                            f"cfg.nodes.{node_id}", ConflictType.NODE_DELETED
                        ),
                        conflict_type=ConflictType.NODE_DELETED,
                        path=f"cfg.nodes.{node_id}",
                        base_value=base_node,
                        ours_value=ours_node,
                        theirs_value=None,
                    )
                )
            # Both modified differently
            elif (
                ours_node != theirs_node
                and ours_node != base_node
                and theirs_node != base_node
            ):
                conflicts.append(
                    MergeConflict(
                        conflict_id=MergeConflict.generate_id(
                            f"cfg.nodes.{node_id}", ConflictType.NODE_MODIFIED
                        ),
                        conflict_type=ConflictType.NODE_MODIFIED,
                        path=f"cfg.nodes.{node_id}",
                        base_value=base_node,
                        ours_value=ours_node,
                        theirs_value=theirs_node,
                    )
                )

        return conflicts

    def _detect_edge_conflicts(
        self,
        base_edges: List[Dict[str, Any]],
        ours_edges: List[Dict[str, Any]],
        theirs_edges: List[Dict[str, Any]],
    ) -> List[MergeConflict]:
        """Detect conflicts in CFG edges (simplified - compare edge lists)."""
        conflicts = []

        # Convert to sets of tuples for comparison
        def edge_key(edge):
            return (edge.get("source"), edge.get("target"), edge.get("condition"))

        base_set = {edge_key(e) for e in base_edges}
        ours_set = {edge_key(e) for e in ours_edges}
        theirs_set = {edge_key(e) for e in theirs_edges}

        # Detect divergent edge changes (simple heuristic)
        if ours_set != theirs_set:
            ours_diff = ours_set - base_set
            theirs_diff = theirs_set - base_set
            conflict_edges = ours_diff & theirs_diff

            for edge_tuple in conflict_edges:
                conflicts.append(
                    MergeConflict(
                        conflict_id=MergeConflict.generate_id(
                            f"cfg.edges.{edge_tuple[0]}->{edge_tuple[1]}",
                            ConflictType.EDGE_MODIFIED,
                        ),
                        conflict_type=ConflictType.EDGE_MODIFIED,
                        path=f"cfg.edges.{edge_tuple[0]}->{edge_tuple[1]}",
                        base_value=None,
                        ours_value=edge_tuple,
                        theirs_value=edge_tuple,
                    )
                )

        return conflicts

    def _detect_stats_conflicts(
        self,
        base_stats: Dict[str, Any],
        ours_stats: Dict[str, Any],
        theirs_stats: Dict[str, Any],
    ) -> List[MergeConflict]:
        """Detect conflicts in Stats (total_nodes, etc.)."""
        conflicts = []
        all_keys = (
            set(base_stats.keys()) | set(ours_stats.keys()) | set(theirs_stats.keys())
        )

        for key in all_keys:
            base_val = base_stats.get(key)
            ours_val = ours_stats.get(key)
            theirs_val = theirs_stats.get(key)

            # Both modified differently
            if (
                ours_val != theirs_val
                and ours_val != base_val
                and theirs_val != base_val
            ):
                conflicts.append(
                    MergeConflict(
                        conflict_id=MergeConflict.generate_id(
                            f"stats.{key}", ConflictType.NODE_MODIFIED
                        ),
                        conflict_type=ConflictType.NODE_MODIFIED,
                        path=f"stats.{key}",
                        base_value=base_val,
                        ours_value=ours_val,
                        theirs_value=theirs_val,
                    )
                )

        return conflicts

    def _resolve_conflicts(
        self,
        conflicts: List[MergeConflict],
        strategy: MergeStrategy,
        manual_resolutions: Dict[str, ConflictResolution],
    ) -> List[MergeConflict]:
        """Apply resolution strategy to conflicts."""
        resolved = []

        for conflict in conflicts:
            if strategy == MergeStrategy.AUTO:
                # AUTO fails on any conflict
                resolved.append(conflict)
            elif strategy == MergeStrategy.OURS:
                conflict.resolution = ConflictResolution.USE_OURS
                conflict.resolved_value = conflict.ours_value
                resolved.append(conflict)
            elif strategy == MergeStrategy.THEIRS:
                conflict.resolution = ConflictResolution.USE_THEIRS
                conflict.resolved_value = conflict.theirs_value
                resolved.append(conflict)
            elif strategy == MergeStrategy.INTERACTIVE:
                # Check manual resolutions
                if conflict.conflict_id in manual_resolutions:
                    resolution = manual_resolutions[conflict.conflict_id]
                    conflict.resolution = resolution
                    if resolution == ConflictResolution.USE_OURS:
                        conflict.resolved_value = conflict.ours_value
                    elif resolution == ConflictResolution.USE_THEIRS:
                        conflict.resolved_value = conflict.theirs_value
                    # MANUAL resolution should have resolved_value set externally
                resolved.append(conflict)

        return resolved

    def _apply_merge(
        self,
        base: Dict[str, Any],
        ours: Dict[str, Any],
        theirs: Dict[str, Any],
        conflicts: List[MergeConflict],
    ) -> Dict[str, Any]:
        """
        Apply three-way merge with resolved conflicts.

        Logic:
            - Start with ours as base
            - Apply theirs changes where no conflict
            - Apply resolved conflict values
            - Preserve list-based node format (BranchPy standard)
        """

        # Helper to normalize nodes (list or dict)
        def get_nodes_as_dict(data):
            nodes = data.get("cfg", {}).get("nodes", [])
            if isinstance(nodes, list):
                return {node["id"]: node for node in nodes if "id" in node}
            return dict(nodes) if nodes else {}

        # Helper to convert nodes dict back to list
        def nodes_dict_to_list(nodes_dict):
            return list(nodes_dict.values())

        # Start with ours, convert nodes to dict for merging
        ours_nodes_dict = get_nodes_as_dict(ours)

        merged = {
            "cfg": {
                "nodes": dict(ours_nodes_dict),  # Will convert back to list at end
                "edges": list(ours.get("cfg", {}).get("edges", [])),
            },
            "stats": dict(ours.get("stats", {})),
            "assets": list(ours.get("assets", [])),
        }

        # Apply theirs changes (non-conflicting)
        theirs_nodes_dict = get_nodes_as_dict(theirs)
        base_nodes_dict = get_nodes_as_dict(base)

        for node_id, theirs_node in theirs_nodes_dict.items():
            base_node = base_nodes_dict.get(node_id)
            ours_node = merged["cfg"]["nodes"].get(node_id)

            # Theirs changed, ours didn't -> accept theirs
            if theirs_node != base_node and ours_node == base_node:
                merged["cfg"]["nodes"][node_id] = theirs_node

        # Apply resolved conflicts
        conflict_map = {c.path: c for c in conflicts}

        for path, conflict in conflict_map.items():
            if conflict.resolved_value is not None:
                # Apply resolved value to merged data
                if path.startswith("cfg.nodes."):
                    node_id = path.split(".")[-1]
                    if conflict.resolved_value is None:
                        merged["cfg"]["nodes"].pop(node_id, None)
                    else:
                        merged["cfg"]["nodes"][node_id] = conflict.resolved_value
                elif path.startswith("stats."):
                    key = path.split(".")[-1]
                    merged["stats"][key] = conflict.resolved_value

        # Convert nodes back to list format (BranchPy standard)
        merged["cfg"]["nodes"] = nodes_dict_to_list(merged["cfg"]["nodes"])

        return merged

    def _create_merge_commit(
        self,
        target_branch: str,
        merged_data: Dict[str, Any],
        message: str,
        source_branch: str,
    ) -> str:
        """
        Create merge commit snapshot and update target branch.

        Writes merged data to disk, then creates snapshot.
        """
        # Write merged data to project files
        project_path = Path(
            self.history_dir
        ).parent.parent  # .branchpy/history -> project root
        branchpy_dir = project_path / ".branchpy"

        # Write CFG
        cfg_file = branchpy_dir / "cfg.json"
        with open(cfg_file, "w", encoding="utf-8") as f:
            json.dump(merged_data.get("cfg", {}), f, indent=2)

        # Write stats
        stats_file = branchpy_dir / "stats_unified.json"
        with open(stats_file, "w", encoding="utf-8") as f:
            json.dump(merged_data.get("stats", {}), f, indent=2)

        # Write assets
        assets_file = branchpy_dir / "asset_validation.json"
        with open(assets_file, "w", encoding="utf-8") as f:
            json.dump(merged_data.get("assets", []), f, indent=2)

        # Create snapshot from current state

        from .snapshot import SnapshotMetadata

        metadata = SnapshotMetadata(
            project_path=str(project_path),
            operation="merge",
            actor="merge-engine",
            tags=[f"merge:{source_branch}→{target_branch}"],
        )

        snapshot_id = self.snapshot_manager.create(metadata)

        # Update target branch to point to merge commit
        self.timeline.update_branch_snapshot(target_branch, snapshot_id)

        return snapshot_id

    def _emit_merge_event(
        self,
        target_branch: str,
        source_branch: str,
        snapshot_id: str,
        conflicts: List[MergeConflict],
    ) -> Optional[str]:
        """Emit BRANCH_MERGED governance event."""
        if not self.governance_logger:
            return None

        return self.governance_logger.log_event(
            event_type="BRANCH_MERGED",
            details={
                "target_branch": target_branch,
                "source_branch": source_branch,
                "merge_snapshot_id": snapshot_id,
                "conflicts_count": len(conflicts),
                "conflicts_resolved": all(c.resolution is not None for c in conflicts),
            },
        )
