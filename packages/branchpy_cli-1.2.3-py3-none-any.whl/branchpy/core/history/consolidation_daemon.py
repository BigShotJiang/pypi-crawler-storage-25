"""
Snapshot Consolidation Daemon for Enhanced History (v0.8.8.2)

Automatic background task that detects and consolidates long delta chains to prevent
reconstruction performance degradation. Runs every 6 hours (configurable) and creates
full snapshots when delta chains exceed maximum depth (default: 10).

Performance Impact:
- Delta chains >10 depth: 850ms+ reconstruction time
- After consolidation: <500ms reconstruction time
- Auto-consolidation prevents user-visible slowdowns

Architecture:
- Async background loop with configurable interval
- Depth detection via parent_snapshot_id chain traversal
- Creates full snapshot from reconstructed delta state
- Updates subsequent deltas to reference new full snapshot
- Emits SNAPSHOT_CONSOLIDATED governance events

Author: BranchPy Team
Date: November 2025
Version: 0.8.8.2-alpha
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from .snapshot import SnapshotManager, SnapshotType

logger = logging.getLogger(__name__)


# ============================================================================
# Configuration
# ============================================================================


@dataclass
class ConsolidationConfig:
    """
    Configuration for snapshot consolidation daemon.

    Attributes:
        enabled: Whether consolidation daemon is active
        max_chain_depth: Maximum delta chain depth before consolidation (default: 10)
        consolidation_interval: Interval between consolidation runs (default: 6h)
        preserve_old_deltas: Keep original deltas after consolidation (audit trail)
        notify_user: Emit notifications when consolidation occurs
        min_disk_savings_threshold: Minimum disk savings % to trigger (default: 20%)
    """

    enabled: bool = True
    max_chain_depth: int = 10
    consolidation_interval: timedelta = field(
        default_factory=lambda: timedelta(hours=6)
    )
    preserve_old_deltas: bool = True
    notify_user: bool = True
    min_disk_savings_threshold: float = 0.20  # 20%

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConsolidationConfig":
        """Load configuration from dictionary."""
        interval_str = data.get("consolidation_interval", "6h")
        hours = int(interval_str.rstrip("h"))

        return cls(
            enabled=data.get("enabled", True),
            max_chain_depth=data.get("max_chain_depth", 10),
            consolidation_interval=timedelta(hours=hours),
            preserve_old_deltas=data.get("preserve_old_deltas", True),
            notify_user=data.get("notify_user", True),
            min_disk_savings_threshold=data.get("min_disk_savings_threshold", 0.20),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "enabled": self.enabled,
            "max_chain_depth": self.max_chain_depth,
            "consolidation_interval": f"{int(self.consolidation_interval.total_seconds() // 3600)}h",
            "preserve_old_deltas": self.preserve_old_deltas,
            "notify_user": self.notify_user,
            "min_disk_savings_threshold": self.min_disk_savings_threshold,
        }


@dataclass
class ConsolidationResult:
    """
    Result of a consolidation operation.

    Attributes:
        snapshot_id: ID of the delta snapshot that was consolidated
        new_snapshot_id: ID of the newly created full snapshot
        chain_depth: Depth of the delta chain before consolidation
        disk_savings_before: Disk savings percentage before consolidation
        disk_savings_after: Disk savings percentage after consolidation
        consolidation_time: Time taken to consolidate (seconds)
        timestamp: When consolidation occurred
    """

    snapshot_id: str
    new_snapshot_id: str
    chain_depth: int
    disk_savings_before: float
    disk_savings_after: float
    consolidation_time: float
    timestamp: datetime = field(default_factory=datetime.now)


# ============================================================================
# Consolidation Daemon
# ============================================================================


class ConsolidationDaemon:
    """
    Background daemon for automatic snapshot consolidation.

    Lifecycle:
        1. Start daemon: launch background asyncio task
        2. Periodic check: detect chains exceeding max_chain_depth
        3. Consolidate: create full snapshot from delta chain
        4. Update metadata: point subsequent deltas to new full snapshot
        5. Emit events: notify governance system & users
        6. Stop daemon: graceful shutdown

    Usage:
        >>> config = ConsolidationConfig(max_chain_depth=10, consolidation_interval=timedelta(hours=6))
        >>> daemon = ConsolidationDaemon(history_dir, snapshot_manager, config)
        >>> await daemon.start()
        >>> # ... daemon runs in background ...
        >>> await daemon.stop()
    """

    def __init__(
        self,
        history_dir: Path,
        snapshot_manager: SnapshotManager,
        config: Optional[ConsolidationConfig] = None,
        governance_logger=None,
    ):
        """
        Initialize consolidation daemon.

        Args:
            history_dir: Path to .branchpy/history directory
            snapshot_manager: SnapshotManager for creating full snapshots
            config: Consolidation configuration (default if None)
            governance_logger: Optional GovernanceLogger for event emission
        """
        self.history_dir = Path(history_dir)
        self.snapshot_manager = snapshot_manager
        self.config = config or ConsolidationConfig()
        self.governance_logger = governance_logger

        # Initialize delta reconstructor (v0.9.0)
        from .delta_reconstructor import DeltaReconstructor

        self.reconstructor = DeltaReconstructor(
            history_dir=self.history_dir, cache_size=50, enable_validation=True
        )

        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._consolidation_count = 0
        self._last_run: Optional[datetime] = None

    async def start(self):
        """Start consolidation daemon background task."""
        if self._running:
            logger.warning("Consolidation daemon already running")
            return

        if not self.config.enabled:
            logger.info("Consolidation daemon disabled in config")
            return

        self._running = True
        self._task = asyncio.create_task(self._consolidation_loop())
        logger.info(
            f"Consolidation daemon started (interval: {self.config.consolidation_interval}, "
            f"max_depth: {self.config.max_chain_depth})"
        )

    async def stop(self):
        """Stop consolidation daemon gracefully."""
        if not self._running:
            return

        self._running = False

        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

        logger.info(
            f"Consolidation daemon stopped (total consolidations: {self._consolidation_count})"
        )

    def is_running(self) -> bool:
        """Check if consolidation daemon is currently running."""
        return self._running

    async def _consolidation_loop(self):
        """Main consolidation loop (runs every consolidation_interval)."""
        while self._running:
            try:
                # Perform consolidation check
                await self._run_consolidation_cycle()

                # Update last run timestamp
                self._last_run = datetime.now()

                # Sleep until next cycle
                await asyncio.sleep(self.config.consolidation_interval.total_seconds())

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in consolidation loop: {e}", exc_info=True)
                # Continue running despite errors
                await asyncio.sleep(60)  # Wait 1 minute before retry

    async def _run_consolidation_cycle(self):
        """Run single consolidation cycle (detect chains and consolidate)."""
        logger.debug("Running consolidation cycle...")

        # Detect chains exceeding max depth
        chains_to_consolidate = self._detect_chains()

        if not chains_to_consolidate:
            logger.debug("No chains requiring consolidation")
            return

        logger.info(
            f"Found {len(chains_to_consolidate)} chains requiring consolidation"
        )

        # Consolidate each chain
        for snapshot_id, chain_depth in chains_to_consolidate:
            try:
                result = await self._consolidate(snapshot_id, chain_depth)
                self._consolidation_count += 1

                # Emit governance event
                self._emit_consolidation_event(result)

                # Notify user if enabled
                if self.config.notify_user:
                    self._notify_consolidation(result)

                logger.info(
                    f"Consolidated snapshot {snapshot_id} (depth: {chain_depth}) -> "
                    f"{result.new_snapshot_id} ({result.consolidation_time:.2f}s)"
                )

            except Exception as e:
                logger.error(
                    f"Failed to consolidate snapshot {snapshot_id}: {e}", exc_info=True
                )

    def _detect_chains(self) -> List[tuple[str, int]]:
        """
        Detect delta chains exceeding max_chain_depth.

        Returns:
            List of (snapshot_id, chain_depth) tuples requiring consolidation
        """
        snapshots_dir = self.history_dir / "snapshots"
        if not snapshots_dir.exists():
            return []

        chains_to_consolidate = []

        # Iterate through all snapshots (both .json and .json.gz)
        for snapshot_path in list(snapshots_dir.glob("*.json")) + list(
            snapshots_dir.glob("*.json.gz")
        ):
            try:
                # Handle both compressed and uncompressed snapshots
                if snapshot_path.suffix == ".gz":
                    import gzip

                    with gzip.open(snapshot_path, "rt", encoding="utf-8") as f:
                        snapshot_data = json.load(f)
                    # Remove .gz to get snapshot_id
                    snapshot_id = snapshot_path.stem.replace(".json", "")
                else:
                    with open(snapshot_path, "r", encoding="utf-8") as f:
                        snapshot_data = json.load(f)
                    snapshot_id = snapshot_path.stem

                # Check if incremental snapshot (accept both "incremental" and "delta")
                snapshot_type = snapshot_data.get("metadata", {}).get("snapshot_type")
                if snapshot_type not in ("incremental", "delta"):
                    continue

                # Calculate chain depth (snapshot_id already set above)
                chain_depth = self._calculate_chain_depth(snapshot_id)

                # Check if exceeds max depth
                if chain_depth > self.config.max_chain_depth:
                    chains_to_consolidate.append((snapshot_id, chain_depth))
                    logger.debug(
                        f"Snapshot {snapshot_id} has chain depth {chain_depth}"
                    )

            except Exception as e:
                logger.error(f"Error processing snapshot {snapshot_path.name}: {e}")

        return chains_to_consolidate

    def _calculate_chain_depth(self, snapshot_id: str) -> int:
        """
        Calculate delta chain depth for a snapshot.

        Traverses parent_snapshot_id chain until finding full snapshot or root.

        Args:
            snapshot_id: ID of snapshot to calculate depth for

        Returns:
            Chain depth (1 = direct child of full snapshot)
        """
        depth = 0
        current_id = snapshot_id
        visited = set()

        while current_id:
            # Prevent infinite loops
            if current_id in visited:
                logger.warning(
                    f"Circular reference detected in chain for {snapshot_id}"
                )
                break
            visited.add(current_id)

            # Check for both .json and .json.gz
            snapshot_path_json = self.history_dir / "snapshots" / f"{current_id}.json"
            snapshot_path_gz = self.history_dir / "snapshots" / f"{current_id}.json.gz"

            if snapshot_path_gz.exists():
                snapshot_path = snapshot_path_gz
            elif snapshot_path_json.exists():
                snapshot_path = snapshot_path_json
            else:
                break

            try:
                # Handle compressed/uncompressed
                if snapshot_path.suffix == ".gz":
                    import gzip

                    with gzip.open(snapshot_path, "rt", encoding="utf-8") as f:
                        snapshot_data = json.load(f)
                else:
                    with open(snapshot_path, "r", encoding="utf-8") as f:
                        snapshot_data = json.load(f)

                snapshot_type = snapshot_data.get("metadata", {}).get("snapshot_type")
                parent_id = snapshot_data.get("metadata", {}).get("parent_snapshot_id")

                if snapshot_type == "full" or not parent_id:
                    break  # Reached full snapshot or root

                depth += 1
                current_id = parent_id

            except Exception as e:
                logger.error(f"Error reading snapshot {current_id}: {e}")
                break

        return depth

    async def _consolidate(
        self, snapshot_id: str, chain_depth: int
    ) -> ConsolidationResult:
        """
        Consolidate a delta chain into a full snapshot.

        Process:
            1. Validate delta chain integrity (v0.9.0)
            2. Reconstruct full state from delta chain
            3. Create new full snapshot with reconstructed state
            4. Update metadata to mark old snapshot as consolidated
            5. Optionally preserve old deltas for audit trail

        Args:
            snapshot_id: ID of delta snapshot at end of chain
            chain_depth: Depth of the chain

        Returns:
            ConsolidationResult with before/after metrics

        Raises:
            DeltaChainError: If chain validation fails
        """
        start_time = datetime.now()

        # Validate chain integrity before consolidation (v0.9.0)
        validation = self.reconstructor.validate_chain(snapshot_id)
        if not validation.is_valid:
            error_msg = (
                f"Chain validation failed: {validation.error_message} "
                f"(corrupt snapshot: {validation.corrupt_snapshot_id})"
            )
            logger.error(error_msg)
            raise Exception(error_msg)

        logger.info(
            f"Chain validated successfully ({validation.chain_length} snapshots)"
        )

        # Load and reconstruct snapshot state
        snapshot_path = self.history_dir / "snapshots" / f"{snapshot_id}.json"
        with open(snapshot_path, "r", encoding="utf-8") as f:
            snapshot_data = json.load(f)

        # Reconstruct full state from delta chain (uses optimized reconstructor)
        reconstructed_state = self._reconstruct_state(snapshot_id)

        # Calculate disk savings before consolidation
        disk_savings_before = self._calculate_disk_savings(snapshot_id)

        # Create new full snapshot
        new_snapshot_id = self.snapshot_manager.create_snapshot(
            cfg_data=reconstructed_state.get("cfg"),
            stats=reconstructed_state.get("stats"),
            assets=reconstructed_state.get("assets"),
            snapshot_type=SnapshotType.FULL,
            message=f"Auto-consolidated from chain depth {chain_depth}",
            metadata={
                "consolidated_from": snapshot_id,
                "original_chain_depth": chain_depth,
                "consolidation_timestamp": datetime.now().isoformat(),
            },
        )

        # Update old snapshot metadata (mark as consolidated)
        snapshot_data["metadata"]["consolidated"] = True
        snapshot_data["metadata"]["consolidated_to"] = new_snapshot_id

        if self.config.preserve_old_deltas:
            # Keep old snapshot with consolidated flag
            with open(snapshot_path, "w", encoding="utf-8") as f:
                json.dump(snapshot_data, f, indent=2)
        else:
            # Delete old snapshot (free disk space)
            snapshot_path.unlink()

        # Calculate disk savings after consolidation
        disk_savings_after = self._calculate_disk_savings(new_snapshot_id)

        # Calculate consolidation time
        consolidation_time = (datetime.now() - start_time).total_seconds()

        return ConsolidationResult(
            snapshot_id=snapshot_id,
            new_snapshot_id=new_snapshot_id,
            chain_depth=chain_depth,
            disk_savings_before=disk_savings_before,
            disk_savings_after=disk_savings_after,
            consolidation_time=consolidation_time,
        )

    def _reconstruct_state(self, snapshot_id: str) -> Dict[str, Any]:
        """
        Reconstruct full state from delta chain using optimized reconstructor.

        Args:
            snapshot_id: Snapshot ID to reconstruct

        Returns:
            Fully reconstructed state dictionary

        Raises:
            DeltaChainError: If chain is corrupt or cannot be reconstructed
        """
        try:
            # Use optimized delta reconstructor (v0.9.0)
            state = self.reconstructor.reconstruct(
                snapshot_id,
                progress_callback=None,  # Could add progress logging here
                use_cache=True,
            )
            return state

        except Exception as e:
            logger.error(f"Delta reconstruction failed for {snapshot_id}: {e}")

            # Fallback: try simple load without delta application
            logger.warning(f"Falling back to simple snapshot load for {snapshot_id}")
            snapshot_path = self.history_dir / "snapshots" / f"{snapshot_id}.json"
            with open(snapshot_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {
                    "cfg": data.get("cfg", {}),
                    "stats": data.get("stats", {}),
                    "assets": data.get("assets", []),
                }

    def _calculate_disk_savings(self, snapshot_id: str) -> float:
        """
        Calculate disk savings percentage for a snapshot.

        Returns:
            Percentage of disk space saved (0.0-1.0)
        """
        snapshot_path = self.history_dir / "snapshots" / f"{snapshot_id}.json"
        if not snapshot_path.exists():
            return 0.0

        # Simple heuristic: compare file size to average full snapshot size
        snapshot_size = snapshot_path.stat().st_size

        # Get average full snapshot size
        snapshots_dir = self.history_dir / "snapshots"
        full_snapshots = [
            p.stat().st_size
            for p in snapshots_dir.glob("*.json")
            if self._is_full_snapshot(p)
        ]

        if not full_snapshots:
            return 0.0

        avg_full_size = sum(full_snapshots) / len(full_snapshots)

        if avg_full_size == 0:
            return 0.0

        savings = 1.0 - (snapshot_size / avg_full_size)
        return max(0.0, min(1.0, savings))  # Clamp to [0, 1]

    def _is_full_snapshot(self, snapshot_path: Path) -> bool:
        """Check if a snapshot is a full snapshot."""
        try:
            with open(snapshot_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("metadata", {}).get("snapshot_type") == "full"
        except Exception:
            return False

    def _emit_consolidation_event(self, result: ConsolidationResult):
        """Emit SNAPSHOT_CONSOLIDATED governance event."""
        if not self.governance_logger:
            return

        self.governance_logger.log_event(
            event_type="SNAPSHOT_CONSOLIDATED",
            details={
                "original_snapshot_id": result.snapshot_id,
                "new_snapshot_id": result.new_snapshot_id,
                "chain_depth": result.chain_depth,
                "disk_savings_before": f"{result.disk_savings_before:.2%}",
                "disk_savings_after": f"{result.disk_savings_after:.2%}",
                "consolidation_time": f"{result.consolidation_time:.2f}s",
            },
        )

    def _notify_consolidation(self, result: ConsolidationResult):
        """
        Notify user of consolidation (via SSE or logging).

        In production, this would emit an SSE event to connected clients.
        For now, just log at INFO level.
        """
        logger.info(
            f"[Consolidation] Snapshot {result.snapshot_id} consolidated "
            f"(depth: {result.chain_depth}) -> {result.new_snapshot_id} "
            f"(savings: {result.disk_savings_after:.1%})"
        )

    def get_status(self) -> Dict[str, Any]:
        """
        Get daemon status for monitoring/debugging.

        Returns:
            Dictionary with daemon state
        """
        return {
            "running": self._running,
            "enabled": self.config.enabled,
            "last_run": self._last_run.isoformat() if self._last_run else None,
            "consolidation_count": self._consolidation_count,
            "config": self.config.to_dict(),
        }

    def trigger_consolidation(self) -> int:
        """
        Manually trigger consolidation cycle (for testing/CLI).

        Returns:
            Number of chains consolidated
        """
        chains = self._detect_chains()

        for snapshot_id, chain_depth in chains:
            try:
                # Run consolidation synchronously
                import asyncio

                loop = asyncio.get_event_loop()
                result = loop.run_until_complete(
                    self._consolidate(snapshot_id, chain_depth)
                )

                self._emit_consolidation_event(result)
                if self.config.notify_user:
                    self._notify_consolidation(result)

                self._consolidation_count += 1

            except Exception as e:
                logger.error(f"Failed to consolidate {snapshot_id}: {e}")

        return len(chains)
