"""
Timeline Branching — Alternate History Management

Allows forking history at any point to create experimental branches.
Enables users to:
- Create branches from any snapshot
- Switch between branches without losing work
- Isolate changes to specific timelines
- Delete branches when experiments complete

Classes:
    Branch: Represents a history branch with metadata
    Timeline: Timeline manager with branch support

Storage:
    .branchpy/history/timelines.json

Example:
    >>> timeline = Timeline(project_path)
    >>> branch_id = timeline.create_branch(
    ...     name="experiment_1",
    ...     from_snapshot="snap_001"
    ... )
    >>> timeline.switch_branch(branch_id)
    >>> # Work in experimental branch
    >>> timeline.switch_branch("main")  # Return to main
"""

import json
import logging
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .snapshot import Snapshot
from .stack import EditStack

if TYPE_CHECKING:
    from .merge_engine import MergeResult

logger = logging.getLogger(__name__)


@dataclass
class Branch:
    """
    Represents a history branch.

    Attributes:
        id: Unique branch identifier (UUID)
        name: Human-readable branch name
        created_at: ISO 8601 timestamp
        created_from_snapshot: Snapshot this branch forked from
        parent_branch: Parent branch ID (None for main)
        stack_capacity: Maximum stack size for this branch
        current_snapshot_id: Current HEAD snapshot ID for this branch
    """

    id: str
    name: str
    created_at: str
    created_from_snapshot: str
    parent_branch: Optional[str]
    stack_capacity: int = 100
    current_snapshot_id: str = ""  # Tracks current HEAD snapshot


class Timeline:
    """
    Timeline manager with branching support.

    Features:
        - Create branches from any snapshot
        - Switch between branches
        - List all branches
        - Delete branches
        - Branch isolation (changes don't cross-contaminate)

    Storage:
        .branchpy/history/timelines.json

    Attributes:
        root: History storage directory
        file: Timelines JSON file path
        branches: Dictionary of branch ID -> branch data
        current: Current active branch ID
    """

    def __init__(self, project_path: str):
        """
        Initialize timeline manager.

        Args:
            project_path: Project root path
        """
        self.root = Path(project_path) / ".branchpy" / "history"
        self.root.mkdir(parents=True, exist_ok=True)
        self.file = self.root / "timelines.json"
        self.branches: Dict[str, Dict[str, Any]] = {}
        self.current: str = "main"
        self._load()

    def create_branch(
        self, name: str, from_snapshot: str, parent: Optional[str] = None
    ) -> str:
        """
        Create a new branch from a snapshot.

        Args:
            name: Branch name (e.g., "experiment_1", "feature_test")
            from_snapshot: Snapshot ID to branch from
            parent: Parent branch ID (default: current branch)

        Returns:
            Branch ID (UUID)

        Example:
            >>> timeline = Timeline(project_path)
            >>> branch_id = timeline.create_branch(
            ...     "experiment_1",
            ...     "snap_20251105_152000_abc"
            ... )
            >>> print(f"Created branch: {branch_id}")
        """
        branch_id = str(uuid.uuid4())

        branch = Branch(
            id=branch_id,
            name=name,
            created_at=datetime.utcnow().isoformat() + "Z",
            created_from_snapshot=from_snapshot,
            parent_branch=parent or self.current,
        )

        # Initialize with empty stack
        self.branches[branch_id] = {
            "meta": asdict(branch),
            "stack": EditStack(capacity=branch.stack_capacity).to_dict(),
        }

        self._save()

        logger.info(f"Created branch '{name}' ({branch_id}) from {from_snapshot}")

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_history_event(
                "BRANCH_CREATED",
                None,
                {
                    "branch_id": branch_id,
                    "branch_name": name,
                    "from_snapshot": from_snapshot,
                    "parent_branch": parent or self.current,
                },
            )
        except Exception as e:
            logger.warning(f"Failed to log branch creation to governance: {e}")

        return branch_id

    def switch_branch(self, branch_id_or_name: str) -> None:
        """
        Switch to a different branch.

        This will:
        1. Save current branch state
        2. Restore snapshot of target branch
        3. Update current branch pointer

        Args:
            branch_id_or_name: Branch ID or name

        Raises:
            ValueError: If branch not found

        Example:
            >>> timeline.switch_branch("experiment_1")
            >>> # Work in experiment_1 branch
            >>> timeline.switch_branch("main")  # Return to main
        """
        branch = self._get(branch_id_or_name)

        # Restore branch snapshot (if it has one)
        snapshot_id = branch["meta"]["created_from_snapshot"]
        if snapshot_id:  # Skip restore for main branch with no snapshot
            Snapshot.restore(
                str(self.root.parent.parent),  # Project path
                snapshot_id,
                create_backup=False,
            )

        # Update current branch
        self.current = branch["meta"]["id"]
        self._save()

        logger.info(
            f"Switched to branch '{branch['meta']['name']}' ({branch['meta']['id']})"
        )

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_history_event(
                "BRANCH_SWITCHED",
                None,
                {
                    "branch_id": branch["meta"]["id"],
                    "branch_name": branch["meta"]["name"],
                    "snapshot": branch["meta"]["created_from_snapshot"],
                },
            )
        except Exception as e:
            logger.warning(f"Failed to log branch switch to governance: {e}")

    def list_branches(self) -> List[Dict[str, Any]]:
        """
        List all branches.

        Returns:
            List of branch dictionaries with metadata

        Example:
            >>> branches = timeline.list_branches()
            >>> for b in branches:
            ...     print(f"{b['name']}: {b['from_snapshot']}")
        """
        return [
            {
                "id": b["meta"]["id"],
                "name": b["meta"]["name"],
                "from_snapshot": b["meta"]["created_from_snapshot"],
                "created_at": b["meta"]["created_at"],
                "parent_branch": b["meta"]["parent_branch"],
                "is_current": b["meta"]["id"] == self.current,
            }
            for b in self.branches.values()
        ]

    def get_branch(self, branch_id_or_name: str) -> Optional[Branch]:
        """
        Get branch by ID or name, returning Branch dataclass.

        Args:
            branch_id_or_name: Branch ID or name

        Returns:
            Branch dataclass instance or None if not found

        Example:
            >>> branch = timeline.get_branch("main")
            >>> if branch:
            ...     print(f"Current snapshot: {branch.current_snapshot_id}")
        """
        try:
            branch_data = self._get(branch_id_or_name)
            meta = branch_data["meta"]
            return Branch(
                id=meta["id"],
                name=meta["name"],
                created_at=meta["created_at"],
                created_from_snapshot=meta["created_from_snapshot"],
                parent_branch=meta.get("parent_branch"),
                stack_capacity=meta.get("stack_capacity", 100),
                current_snapshot_id=meta.get(
                    "current_snapshot_id", meta.get("created_from_snapshot", "")
                ),
            )
        except ValueError:
            return None

    def update_branch_snapshot(self, branch_id_or_name: str, snapshot_id: str) -> None:
        """
        Update the current snapshot ID for a branch.

        Args:
            branch_id_or_name: Branch ID or name
            snapshot_id: New snapshot ID to set as HEAD

        Example:
            >>> timeline.update_branch_snapshot("main", "snap-abc123")
        """
        branch_data = self._get(branch_id_or_name)
        branch_data["meta"]["current_snapshot_id"] = snapshot_id
        self._save()
        logger.info(f"Updated branch {branch_id_or_name} to snapshot {snapshot_id}")

    def delete_branch(self, branch_id_or_name: str, force: bool = False) -> None:
        """
        Delete a branch.

        Args:
            branch_id_or_name: Branch ID or name
            force: Skip confirmation (default: False)

        Raises:
            ValueError: If trying to delete current branch or main branch

        Example:
            >>> timeline.delete_branch("experiment_1", force=True)
        """
        branch = self._get(branch_id_or_name)
        branch_id = branch["meta"]["id"]

        # Prevent deleting main or current branch
        if branch_id == "main":
            raise ValueError("Cannot delete main branch")

        if branch_id == self.current:
            raise ValueError(
                "Cannot delete current branch. Switch to another branch first."
            )

        # Remove branch
        del self.branches[branch_id]
        self._save()

        logger.info(f"Deleted branch '{branch['meta']['name']}' ({branch_id})")

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_history_event(
                "BRANCH_DELETED",
                None,
                {"branch_id": branch_id, "branch_name": branch["meta"]["name"]},
            )
        except Exception as e:
            logger.warning(f"Failed to log branch deletion to governance: {e}")

    def merge_branch(
        self, source_branch: str, target_branch: str, strategy: str = "auto"
    ) -> "MergeResult":
        """
        Merge source branch into target branch using MergeEngine.

        This method delegates to MergeEngine for three-way merge algorithm,
        conflict detection, and resolution. Supports multiple strategies:
        - "auto": Automatic resolution (fail if conflicts detected)
        - "ours": Always use target branch changes
        - "theirs": Always use source branch changes
        - "interactive": Require manual resolution

        Args:
            source_branch: Branch to merge from (e.g., "feature-menu")
            target_branch: Branch to merge into (e.g., "main")
            strategy: Merge strategy ("auto", "ours", "theirs", "interactive")

        Returns:
            MergeResult with success status, conflicts, and merge commit ID

        Raises:
            ValueError: If branches don't exist or are same
            FileNotFoundError: If snapshots not found

        Example:
            >>> timeline = Timeline(project_path)
            >>> result = timeline.merge_branch("feature-menu", "main", "auto")
            >>> if result.success:
            ...     print(f"Merged! Snapshot: {result.merged_snapshot_id}")
            ... else:
            ...     print(f"Conflicts: {len(result.conflicts)}")
        """
        # Import MergeEngine and dependencies
        from .merge_engine import MergeEngine, MergeStrategy
        from .snapshot import SnapshotManager

        # Map string strategy to enum
        strategy_map = {
            "auto": MergeStrategy.AUTO,
            "ours": MergeStrategy.OURS,
            "theirs": MergeStrategy.THEIRS,
            "interactive": MergeStrategy.INTERACTIVE,
        }

        if strategy.lower() not in strategy_map:
            raise ValueError(
                f"Invalid merge strategy '{strategy}'. "
                f"Must be one of: {', '.join(strategy_map.keys())}"
            )

        merge_strategy = strategy_map[strategy.lower()]

        # Initialize MergeEngine with SnapshotManager
        snapshot_manager = SnapshotManager(str(self.root.parent))  # Project path
        merge_engine = MergeEngine(
            history_dir=self.root,
            snapshot_manager=snapshot_manager,
            governance_logger=None,  # Will be lazy-loaded by MergeEngine
        )

        # Perform merge
        result = merge_engine.merge_branches(
            target_branch=target_branch,
            source_branch=source_branch,
            strategy=merge_strategy,
        )

        # Reload timeline state to reflect changes made by MergeEngine
        self._load()

        logger.info(
            f"Merge completed: {source_branch} → {target_branch} "
            f"(success={result.success}, conflicts={len(result.conflicts)})"
        )

        return result

    def _get(self, id_or_name: str) -> Dict[str, Any]:
        """
        Get branch by ID or name.

        Args:
            id_or_name: Branch ID or name

        Returns:
            Branch data dictionary

        Raises:
            ValueError: If branch not found
        """
        # Try by ID first
        if id_or_name in self.branches:
            return self.branches[id_or_name]

        # Search by name
        for branch in self.branches.values():
            if branch["meta"]["name"] == id_or_name:
                return branch

        raise ValueError(f"Branch not found: {id_or_name}")

    def _load(self) -> None:
        """
        Load timelines from file.

        Initializes with main branch if file doesn't exist.
        """
        if self.file.exists():
            try:
                data = json.loads(self.file.read_text(encoding="utf-8"))
                self.current = data.get("_current", "main")
                # Filter out metadata keys
                self.branches = {
                    k: v for k, v in data.items() if k not in ["_current", "_version"]
                }
            except Exception as e:
                logger.error(f"Failed to load timelines: {e}")
                self._init_main_branch()
        else:
            self._init_main_branch()

    def _init_main_branch(self) -> None:
        """Initialize with main branch."""
        main = Branch(
            id="main",
            name="main",
            created_at=datetime.utcnow().isoformat() + "Z",
            created_from_snapshot="",
            parent_branch=None,
        )

        self.branches = {"main": {"meta": asdict(main), "stack": EditStack().to_dict()}}
        self.current = "main"
        self._save()

    def _save(self) -> None:
        """Save timelines to file."""
        data = {**self.branches, "_current": self.current, "_version": "0.8.8.1"}

        try:
            self.file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error(f"Failed to save timelines: {e}")
            raise
