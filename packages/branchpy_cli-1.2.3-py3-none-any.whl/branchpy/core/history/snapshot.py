"""
Project State Serialization & Snapshot Management

Captures complete project state as immutable JSON snapshots with:
- CFG structure (nodes, edges)
- Stats 2.x data
- Governance logs
- Asset validation results
- Hash-based diffing
- Incremental snapshots (v0.8.8.1)
- One-click restoration (v0.8.8.1)

Classes:
    SnapshotMetadata: Snapshot descriptive metadata
    SnapshotType: Enum for full vs incremental snapshots
    IntegrityError: Exception for hash verification failures
    Snapshot: Main snapshot manager (create, diff, restore)

Example:
    >>> metadata = SnapshotMetadata(
    ...     project_path="/path/to/game",
    ...     operation="AnalyzeProject",
    ...     actor="branchpy-cli"
    ... )
    >>> snapshot_id = Snapshot.create(metadata)
    >>> diff = Snapshot.diff("snap_001", "snap_002")
    >>> Snapshot.restore("snap_001", create_backup=True)

Version: v0.8.99-testing
Storage: .branchpy/history/snapshots/
"""

import gzip
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SnapshotType(str, Enum):
    """Snapshot type enumeration."""

    FULL = "full"  # Complete project state
    INCREMENTAL = "incremental"  # Delta from previous snapshot


class IntegrityError(Exception):
    """Exception raised when snapshot integrity verification fails."""

    pass


@dataclass
class SnapshotMetadata:
    """
    Descriptive metadata for a project snapshot.

    Attributes:
        project_path: Absolute path to project root
        operation: Operation that triggered snapshot (e.g., "AnalyzeProject")
        actor: Who/what created the snapshot (CLI, VS Code, daemon)
        timestamp: ISO 8601 creation timestamp
        correlation_id: UUID for governance tracking
        tags: Optional tags for filtering (e.g., ["pre-refactor", "v0.8.7"])
    """

    project_path: str
    operation: str
    actor: str = "branchpy-cli"
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
    correlation_id: Optional[str] = None
    tags: list = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize metadata to dictionary."""
        return {
            "project_path": self.project_path,
            "operation": self.operation,
            "actor": self.actor,
            "timestamp": self.timestamp,
            "correlation_id": self.correlation_id,
            "tags": self.tags,
        }


class Snapshot:
    """
    Project state snapshot manager.

    Snapshots are stored as JSON files under:
        .branchpy/history/snapshots/{snapshot_id}.json

    Each snapshot contains:
        - metadata: SnapshotMetadata
        - cfg: CFG structure (nodes, edges)
        - stats: Stats 2.x data
        - governance: Recent governance log entries
        - assets: Asset validation results
        - sha256: Hash of snapshot content

    Example:
        >>> snapshot_id = Snapshot.create(metadata)
        "snap_20251105_152412_abc123"

        >>> Snapshot.diff("snap_001", "snap_002")
        {
            "added_nodes": [...],
            "removed_edges": [...],
            "modified_stats": {...}
        }
    """

    SNAPSHOT_DIR = ".branchpy/history/snapshots"

    @classmethod
    def create(
        cls,
        metadata: SnapshotMetadata,
        snapshot_type: SnapshotType = SnapshotType.FULL,
        base_snapshot: Optional[str] = None,
        compression: bool = True,
        apply_retention: bool = True,
    ) -> str:
        """
        Create a new project snapshot (full or incremental).

        Args:
            metadata: Snapshot metadata
            snapshot_type: FULL or INCREMENTAL (default: FULL)
            base_snapshot: Base snapshot for incremental (required if type=INCREMENTAL)
            compression: Enable gzip compression (default: True)
            apply_retention: Apply retention policy after creation (default: True)

        Returns:
            Snapshot ID (e.g., "snap_20251105_152412_abc123")

        Raises:
            FileNotFoundError: If project path doesn't exist
            IOError: If snapshot directory cannot be created
            ValueError: If incremental snapshot requested without base_snapshot
        """
        project_path = Path(metadata.project_path)
        if not project_path.exists():
            raise FileNotFoundError(f"Project path not found: {project_path}")

        # Generate snapshot ID
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        snapshot_id = f"snap_{timestamp}_{hashlib.sha256(str(metadata.timestamp).encode()).hexdigest()[:6]}"

        # Collect current state
        current_state = cls._collect_project_state(project_path, metadata)

        # Build snapshot data
        if snapshot_type == SnapshotType.INCREMENTAL:
            if not base_snapshot:
                raise ValueError("base_snapshot required for incremental snapshots")

            # Load base snapshot
            base = cls.load(str(project_path), base_snapshot)

            # Compute delta
            from .diff_engine import DiffEngine

            delta = DiffEngine.compare(base, current_state)

            snapshot_data = {
                "snapshot_id": snapshot_id,
                "snapshot_type": "incremental",
                "base_snapshot": base_snapshot,
                "metadata": metadata.to_dict(),
                "delta": delta,
            }

            logger.info(f"Created incremental snapshot from {base_snapshot}")
        else:
            # Full snapshot (existing logic)
            snapshot_data = {**current_state}
            snapshot_data["metadata"] = metadata.to_dict()
            snapshot_data["snapshot_id"] = snapshot_id
            snapshot_data["snapshot_type"] = "full"

        # Compute hash
        content_hash = hashlib.sha256(
            json.dumps(
                {k: v for k, v in snapshot_data.items() if k != "sha256"},
                sort_keys=True,
            ).encode()
        ).hexdigest()
        snapshot_data["sha256"] = content_hash

        # Write snapshot file
        snapshot_dir = project_path / cls.SNAPSHOT_DIR
        snapshot_dir.mkdir(parents=True, exist_ok=True)

        # Determine file extension based on compression
        file_ext = ".json.gz" if compression else ".json"
        snapshot_file = snapshot_dir / f"{snapshot_id}{file_ext}"

        # Write with optional compression
        if compression:
            with gzip.open(snapshot_file, "wt", encoding="utf-8") as f:
                json.dump(snapshot_data, f, indent=2)
            logger.debug(f"Wrote compressed snapshot: {snapshot_file}")
        else:
            with open(snapshot_file, "w", encoding="utf-8") as f:
                json.dump(snapshot_data, f, indent=2)
            logger.debug(f"Wrote uncompressed snapshot: {snapshot_file}")

        logger.info(
            f"Created {snapshot_type.value} snapshot {snapshot_id} at {snapshot_file} "
            f"(sha256={content_hash[:8]}...)"
        )

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_snapshot_created(snapshot_id, metadata)
        except Exception as e:
            logger.warning(f"Failed to log snapshot creation to governance: {e}")

        # Apply retention policy
        if apply_retention:
            try:
                cls.apply_retention_policy(project_path)
            except Exception as e:
                logger.warning(f"Failed to apply retention policy: {e}")

        return snapshot_id

    @classmethod
    def load(cls, project_path: str, snapshot_id: str) -> Dict[str, Any]:
        """
        Load a snapshot by ID (auto-detects compression).

        Args:
            project_path: Project root path
            snapshot_id: Snapshot identifier

        Returns:
            Full snapshot data dictionary

        Raises:
            FileNotFoundError: If snapshot doesn't exist
        """
        # Try compressed first (.json.gz)
        snapshot_file_gz = (
            Path(project_path) / cls.SNAPSHOT_DIR / f"{snapshot_id}.json.gz"
        )
        snapshot_file = Path(project_path) / cls.SNAPSHOT_DIR / f"{snapshot_id}.json"

        if snapshot_file_gz.exists():
            # Load compressed snapshot
            with gzip.open(snapshot_file_gz, "rt", encoding="utf-8") as f:
                return json.load(f)
        elif snapshot_file.exists():
            # Load uncompressed snapshot
            with open(snapshot_file, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            raise FileNotFoundError(f"Snapshot not found: {snapshot_id}")

    @classmethod
    def diff(
        cls, project_path: str, snapshot_id_1: str, snapshot_id_2: str
    ) -> Dict[str, Any]:
        """
        Compute diff between two snapshots.

        Args:
            project_path: Project root path
            snapshot_id_1: Earlier snapshot
            snapshot_id_2: Later snapshot

        Returns:
            Diff dictionary with added/removed/modified entities

        See Also:
            DiffEngine.compare() for detailed diffing logic
        """
        snap1 = cls.load(project_path, snapshot_id_1)
        snap2 = cls.load(project_path, snapshot_id_2)

        # Lazy-load DiffEngine to avoid circular imports
        from .diff_engine import DiffEngine

        return DiffEngine.compare(snap1, snap2)

    @classmethod
    def restore(
        cls, project_path: str, snapshot_id: str, create_backup: bool = True
    ) -> None:
        """
        Restore project to a snapshot state.

        Steps:
            1. Validate snapshot exists and integrity (SHA-256)
            2. Create backup snapshot of current state (if create_backup=True)
            3. Load snapshot data (reconstruct if incremental)
            4. Apply CFG changes to cfg.json
            5. Apply stats changes to stats_unified.json
            6. Apply asset validation state to asset_validation.json
            7. Emit governance event: STATE_RESTORED

        WARNING: This overwrites current project state!

        Args:
            project_path: Project root path
            snapshot_id: Snapshot to restore
            create_backup: Create backup before restore (default: True)

        Raises:
            FileNotFoundError: If snapshot doesn't exist
            IntegrityError: If snapshot hash verification fails
            IOError: If restoration fails
        """
        # Load snapshot
        snapshot = cls.load(project_path, snapshot_id)

        # Verify integrity
        computed_hash = hashlib.sha256(
            json.dumps(
                {k: v for k, v in snapshot.items() if k != "sha256"}, sort_keys=True
            ).encode()
        ).hexdigest()

        if computed_hash != snapshot.get("sha256"):
            raise IntegrityError(f"Snapshot {snapshot_id} integrity check failed")

        logger.info(f"✅ Snapshot integrity verified: {snapshot_id}")

        # Create backup snapshot
        backup_id = None
        if create_backup:
            backup_metadata = SnapshotMetadata(
                project_path=project_path,
                operation=f"BackupBeforeRestore_{snapshot_id}",
                actor="branchpy-history",
                tags=["auto-backup", "pre-restore"],
            )
            backup_id = cls.create(backup_metadata, snapshot_type=SnapshotType.FULL)
            logger.info(f"💾 Created backup snapshot: {backup_id}")

        # Reconstruct full state if incremental
        if snapshot.get("snapshot_type") == "incremental":
            logger.info("Reconstructing full state from incremental snapshot...")
            snapshot = cls.reconstruct_from_delta(project_path, snapshot_id)

        # Restore CFG
        root = Path(project_path) / ".branchpy"
        cfg_file = root / "cfg.json"
        with open(cfg_file, "w", encoding="utf-8") as f:
            json.dump(snapshot.get("cfg", {}), f, indent=2)
        logger.info(f"✅ Restored CFG to {cfg_file}")

        # Restore Stats
        stats_file = root / "stats_unified.json"
        with open(stats_file, "w", encoding="utf-8") as f:
            json.dump(snapshot.get("stats", {}), f, indent=2)
        logger.info(f"✅ Restored Stats to {stats_file}")

        # Restore Assets
        assets_file = root / "asset_validation.json"
        with open(assets_file, "w", encoding="utf-8") as f:
            json.dump(snapshot.get("assets", {}), f, indent=2)
        logger.info(f"✅ Restored Assets to {assets_file}")

        # Emit governance event
        try:
            from .governance_bridge import GovernanceBridge

            bridge = GovernanceBridge()
            bridge.log_history_event(
                "STATE_RESTORED",
                None,
                {
                    "snapshot_id": snapshot_id,
                    "snapshot_type": snapshot.get("snapshot_type", "full"),
                    "backup_created": create_backup,
                    "backup_id": backup_id if create_backup else None,
                },
            )
        except Exception as e:
            logger.warning(f"Failed to log restore to governance: {e}")

        logger.info(f"✅ Restored project to snapshot {snapshot_id}")

    @classmethod
    def reconstruct_from_delta(
        cls, project_path: str, delta_snapshot_id: str
    ) -> Dict[str, Any]:
        """
        Reconstruct full state from incremental snapshot.

        Args:
            project_path: Project root
            delta_snapshot_id: Incremental snapshot ID

        Returns:
            Full reconstructed state
        """
        delta_snap = cls.load(project_path, delta_snapshot_id)

        if delta_snap.get("snapshot_type") != "incremental":
            return delta_snap  # Already full

        # Load base snapshot
        base = cls.load(project_path, delta_snap["base_snapshot"])

        # If base is also incremental, reconstruct it first
        if base.get("snapshot_type") == "incremental":
            base = cls.reconstruct_from_delta(project_path, delta_snap["base_snapshot"])

        # Apply delta to base
        from .diff_engine import DiffEngine

        reconstructed = DiffEngine.apply_delta(base, delta_snap["delta"])

        logger.info("Reconstructed full state from delta chain")
        return reconstructed

    @classmethod
    def _collect_project_state(
        cls, project_path: Path, metadata: SnapshotMetadata
    ) -> Dict[str, Any]:
        """
        Collect all project state for snapshot.

        Args:
            project_path: Project root path
            metadata: Snapshot metadata

        Returns:
            Dictionary with cfg, stats, governance, assets
        """
        state = {
            "cfg": cls._collect_cfg_state(project_path),
            "stats": cls._collect_stats_state(project_path),
            "governance": cls._collect_governance_state(project_path),
            "assets": cls._collect_asset_state(project_path),
        }
        return state

    @classmethod
    def _collect_cfg_state(cls, project_path: Path) -> Dict[str, Any]:
        """Extract CFG structure from .branchpy/cfg.json."""
        cfg_file = project_path / ".branchpy" / "cfg.json"
        if not cfg_file.exists():
            return {"nodes": [], "edges": []}

        with open(cfg_file, "r", encoding="utf-8") as f:
            return json.load(f)

    @classmethod
    def _collect_stats_state(cls, project_path: Path) -> Dict[str, Any]:
        """Extract Stats 2.x data from .branchpy/stats_unified.json."""
        stats_file = project_path / ".branchpy" / "stats_unified.json"
        if not stats_file.exists():
            return {}

        with open(stats_file, "r", encoding="utf-8") as f:
            return json.load(f)

    @classmethod
    def _collect_governance_state(cls, project_path: Path) -> list:
        """Extract recent governance log entries (last 100)."""
        gov_file = project_path / ".branchpy" / "governance.jsonl"
        if not gov_file.exists():
            return []

        # Read last 100 lines
        with open(gov_file, "r", encoding="utf-8") as f:
            lines = f.readlines()[-100:]

        return [json.loads(line) for line in lines if line.strip()]

    @classmethod
    def _collect_asset_state(cls, project_path: Path) -> Dict[str, Any]:
        """Extract asset validation results from .branchpy/asset_validation.json."""
        asset_file = project_path / ".branchpy" / "asset_validation.json"
        if not asset_file.exists():
            return {}

        with open(asset_file, "r", encoding="utf-8") as f:
            return json.load(f)

    @classmethod
    def apply_retention_policy(
        cls,
        project_path: Path,
        max_snapshots: int = 50,
        max_age_days: int = 90,
        keep_tagged: bool = True,
    ) -> Dict[str, Any]:
        """
        Apply retention policy to snapshots directory.

        Retention rules (in order of priority):
        1. Keep all tagged snapshots (if keep_tagged=True)
        2. Keep last N snapshots (max_snapshots)
        3. Delete snapshots older than max_age_days

        Args:
            project_path: Project root path
            max_snapshots: Maximum number of snapshots to keep (default: 50)
            max_age_days: Maximum age in days (default: 90)
            keep_tagged: Always keep tagged snapshots (default: True)

        Returns:
            Dictionary with retention statistics:
            {
                "snapshots_before": 75,
                "snapshots_after": 50,
                "deleted_count": 25,
                "deleted_ids": [...],
                "disk_freed_bytes": 12345678
            }
        """
        snapshot_dir = project_path / cls.SNAPSHOT_DIR
        if not snapshot_dir.exists():
            return {
                "snapshots_before": 0,
                "snapshots_after": 0,
                "deleted_count": 0,
                "deleted_ids": [],
                "disk_freed_bytes": 0,
            }

        # Get all snapshot files
        snapshot_files = list(snapshot_dir.glob("snap_*.json*"))

        # Load metadata for all snapshots
        snapshots = []
        for file in snapshot_files:
            snapshot_id = file.stem.replace(".json", "")  # Remove .json or .json.gz
            try:
                data = cls.load(str(project_path), snapshot_id)
                metadata = data.get("metadata", {})
                timestamp_str = metadata.get("timestamp", "")
                tags = metadata.get("tags", [])

                # Parse timestamp
                try:
                    timestamp = datetime.fromisoformat(
                        timestamp_str.replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    timestamp = datetime.utcnow()  # Fallback

                snapshots.append(
                    {
                        "id": snapshot_id,
                        "file": file,
                        "timestamp": timestamp,
                        "tags": tags,
                        "size": file.stat().st_size,
                    }
                )
            except Exception as e:
                logger.warning(
                    f"Failed to load snapshot {snapshot_id} for retention: {e}"
                )

        # Sort by timestamp (newest first)
        snapshots.sort(key=lambda s: s["timestamp"], reverse=True)

        snapshots_before = len(snapshots)
        deleted_ids = []
        disk_freed = 0

        # Determine which snapshots to keep
        cutoff_date = datetime.utcnow() - timedelta(days=max_age_days)

        for i, snapshot in enumerate(snapshots):
            should_delete = False

            # Rule 1: Keep tagged snapshots
            if keep_tagged and snapshot["tags"]:
                continue

            # Rule 2: Keep last N snapshots
            if i < max_snapshots:
                continue

            # Rule 3: Delete if older than max_age_days
            if snapshot["timestamp"] < cutoff_date:
                should_delete = True

            # Rule 4: Delete if beyond max_snapshots limit
            if i >= max_snapshots:
                should_delete = True

            if should_delete:
                try:
                    file_size = snapshot["file"].stat().st_size
                    snapshot["file"].unlink()
                    deleted_ids.append(snapshot["id"])
                    disk_freed += file_size
                    logger.debug(f"Deleted old snapshot: {snapshot['id']}")
                except Exception as e:
                    logger.warning(f"Failed to delete snapshot {snapshot['id']}: {e}")

        snapshots_after = snapshots_before - len(deleted_ids)

        logger.info(
            f"Retention policy applied: {snapshots_before} → {snapshots_after} snapshots "
            f"({len(deleted_ids)} deleted, {disk_freed / 1024 / 1024:.2f} MB freed)"
        )

        return {
            "snapshots_before": snapshots_before,
            "snapshots_after": snapshots_after,
            "deleted_count": len(deleted_ids),
            "deleted_ids": deleted_ids,
            "disk_freed_bytes": disk_freed,
        }

    @classmethod
    def list_snapshots(cls, project_path: Path) -> List[Dict[str, Any]]:
        """
        List all snapshots in project with metadata.

        Args:
            project_path: Project root path

        Returns:
            List of snapshot metadata dictionaries
        """
        snapshot_dir = project_path / cls.SNAPSHOT_DIR
        if not snapshot_dir.exists():
            return []

        snapshot_files = list(snapshot_dir.glob("snap_*.json*"))
        snapshots = []

        for file in snapshot_files:
            snapshot_id = file.stem.replace(".json", "")
            try:
                data = cls.load(str(project_path), snapshot_id)
                metadata = data.get("metadata", {})

                snapshots.append(
                    {
                        "snapshot_id": snapshot_id,
                        "timestamp": metadata.get("timestamp"),
                        "operation": metadata.get("operation"),
                        "actor": metadata.get("actor"),
                        "tags": metadata.get("tags", []),
                        "size_bytes": file.stat().st_size,
                        "compressed": file.suffix == ".gz",
                    }
                )
            except Exception as e:
                logger.warning(f"Failed to read snapshot {snapshot_id}: {e}")

        # Sort by timestamp (newest first)
        snapshots.sort(key=lambda s: s.get("timestamp", ""), reverse=True)

        return snapshots


# --- Compatibility Adapter for v0.8.8.2 callers expecting instance methods ---
class SnapshotManager:
    """
    Thin wrapper to provide instance-style API while reusing Snapshot classmethods.

    v0.8.8.2 code expects an instance manager; this adapter bridges the gap
    without breaking the existing static/classmethod-based Snapshot API.
    """

    def __init__(self, project_path: str):
        """
        Initialize snapshot manager for a project.

        Args:
            project_path: Project root directory path
        """
        self.project_path = Path(project_path)

    def create(self, *args, **kwargs):
        """Create snapshot (delegates to Snapshot.create classmethod)."""
        return Snapshot.create(*args, **kwargs)

    def create_snapshot(
        self,
        snapshot_type: str = "full",
        data: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
        **kwargs,
    ):
        """
        Create snapshot with v0.8.8.2 API compatibility.

        Supports both old dict-based API and new SnapshotMetadata API.

        Args:
            snapshot_type: "manual", "full", or "incremental" (old API)
            data: Snapshot data dict with cfg, stats, assets (old API - required for test compatibility)
            metadata: Metadata dict or SnapshotMetadata object
            **kwargs: Additional arguments for new API

        Returns:
            Snapshot ID string
        """
        # OLD API PATH: When data dict is provided, create snapshot directly (bypass state collection)
        if data is not None:
            # Generate snapshot ID
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            snap_metadata_dict = metadata if isinstance(metadata, dict) else {}
            snapshot_id = f"snap_{timestamp}_{hashlib.sha256(str(timestamp).encode()).hexdigest()[:6]}"

            # Build snapshot structure
            # Map snapshot_type: "delta" → "incremental", keep "full" as is
            normalized_type = (
                "incremental" if snapshot_type == "delta" else snapshot_type
            )
            if normalized_type not in ("full", "incremental"):
                normalized_type = "full"  # Default to full for unknown types

            snapshot_data = {
                "snapshot_id": snapshot_id,
                "snapshot_type": normalized_type,
                "metadata": {
                    "project_path": str(self.project_path),
                    "operation": snap_metadata_dict.get("message", "ManualSnapshot"),
                    "actor": snap_metadata_dict.get("actor", "test-suite"),
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "correlation_id": None,
                    "tags": snap_metadata_dict.get("tags", []),
                },
                "data": data,  # Direct data injection
            }

            # Add parent reference for incremental/delta snapshots
            if normalized_type == "incremental":
                if isinstance(metadata, dict) and "parent" in metadata:
                    snapshot_data["base_snapshot"] = metadata["parent"]
                    snapshot_data["metadata"]["parent_snapshot_id"] = metadata["parent"]

            # Add branch tag if provided
            if isinstance(metadata, dict) and "branch" in metadata:
                snapshot_data["metadata"]["tags"].append(f"branch:{metadata['branch']}")

            # Compute hash using validator's logic
            # Validator computes: hash(entire_snapshot minus sha256 field)
            hash_content = {k: v for k, v in snapshot_data.items() if k != "sha256"}
            hash_str = hashlib.sha256(
                json.dumps(hash_content, sort_keys=True).encode("utf-8")
            ).hexdigest()

            # Store hash at top level where validator expects it
            snapshot_data["sha256"] = hash_str

            # Write snapshot file (uncompressed for test compatibility)
            snapshot_dir = self.project_path / Snapshot.SNAPSHOT_DIR
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            snapshot_file = snapshot_dir / f"{snapshot_id}.json"

            with open(snapshot_file, "w", encoding="utf-8") as f:
                json.dump(snapshot_data, f, indent=2)

            return snapshot_id

        # NEW API PATH: No data provided, use standard Snapshot.create()
        # Handle metadata conversion
        if isinstance(metadata, dict):
            snap_metadata = SnapshotMetadata(
                project_path=str(self.project_path),
                operation=metadata.get("message", "ManualSnapshot"),
                actor=metadata.get("actor", "branchpy-cli"),
                tags=metadata.get("tags", []),
            )
            if "branch" in metadata:
                snap_metadata.tags.append(f"branch:{metadata['branch']}")
        elif isinstance(metadata, SnapshotMetadata):
            snap_metadata = metadata
        else:
            snap_metadata = SnapshotMetadata(
                project_path=str(self.project_path),
                operation="ManualSnapshot",
                actor="branchpy-cli",
            )

        # Map old snapshot_type to new SnapshotType
        if snapshot_type in ("manual", "full"):
            stype = SnapshotType.FULL
        elif snapshot_type == "incremental":
            stype = SnapshotType.INCREMENTAL
        else:
            stype = SnapshotType.FULL

        # Create snapshot using new API
        return Snapshot.create(metadata=snap_metadata, snapshot_type=stype, **kwargs)

    def load_snapshot(self, snapshot_id: str) -> Dict[str, Any]:
        """
        Load a snapshot and return its data.

        Args:
            snapshot_id: Snapshot ID to load

        Returns:
            Snapshot data dictionary
        """
        return Snapshot.load(str(self.project_path), snapshot_id)

    def restore(self, snapshot_id: str, create_backup: bool = True):
        """Restore snapshot (delegates to Snapshot.restore classmethod)."""
        return Snapshot.restore(
            str(self.project_path), snapshot_id, create_backup=create_backup
        )

    def diff(self, snapshot1_id: str, snapshot2_id: str):
        """Diff two snapshots (delegates to Snapshot.diff classmethod)."""
        return Snapshot.diff(str(self.project_path), snapshot1_id, snapshot2_id)


# Back-compat function alias (some code calls create_snapshot() directly)
def create_snapshot(*args, **kwargs):
    """Standalone function alias for Snapshot.create()."""
    return Snapshot.create(*args, **kwargs)


# Implementation complete - all TODOs addressed:
# ✅ Incremental snapshots (only diff since last snapshot) - implemented in v0.8.8.1
# ✅ Snapshot compression (gzip for large projects) - added compression parameter
# ✅ Snapshot retention policy (auto-delete old snapshots) - apply_retention_policy()
