from __future__ import annotations


# --- NEW: Canon helpers ---
def _strip_bom(s: str) -> str:
    return s.lstrip("\ufeff")


def _canon_text(s: str) -> str:
    # normalize EOLs and strip BOM once
    return _strip_bom(s.replace("\r\n", "\n").replace("\r", "\n"))


def _canon_line(s: str) -> str:
    # line-level canonical form (no trailing EOL)
    s = s.rstrip("\r\n")
    return _strip_bom(s)


def _lines_equal(a: str, b: str) -> bool:
    return _canon_line(a) == _canon_line(b)


def _find_forward(
    lines: list[str], start_idx: int, want: str, max_lookahead: int
) -> int | None:
    """Find the next index >= start_idx whose canonical line equals 'want' within a limited window."""
    want_c = _canon_line(want)
    end = min(len(lines), start_idx + max_lookahead)
    for i in range(start_idx, end):
        if _canon_line(lines[i]) == want_c:
            return i
    return None


import difflib

# branchpy/core/patches.py
import io
import re
from pathlib import Path
from typing import List, Tuple

from branchpy.core.fs import ensure_structure, load_state, save_state, timestamp_slug

# Very lightweight unified-diff applier with context matching.
# (Not a full git patch engine; safe for our simple generated diffs.)

HUNK_RE = re.compile(r"^@@ -(\d+),?(\d*) \+(\d+),?(\d*) @@")


class PatchError(Exception): ...


def read_patch_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def _apply_hunks_to_text(
    src: str, hunks, *, strict: bool = True, lookahead: int = 200
) -> str:
    """
    Unified-diff applier with optional fuzzy resync.
    - strict=True : fail fast on context mismatch (CI mode)
    - strict=False: try forward-resync within 'lookahead' lines
    """
    # Canonicalize file content to LF, strip BOM
    src = _canon_text(src)
    lines = [line + "\n" for line in src.split("\n")]
    out: list[str] = []
    idx = 0  # cursor in source lines

    for old_start, _old_len, _new_start, _new_len, hunk_lines in hunks:
        # Copy up to (old_start - 1) in 1-based coords
        target = max(0, old_start - 1)
        while idx < target and idx < len(lines):
            out.append(lines[idx])
            idx += 1

        for ln in hunk_lines:
            if not ln or ln == "\n":
                continue
            if ln.startswith("\\ No newline at end of file"):
                continue

            tag, body = ln[0], ln[1:]
            # We keep body as logical line (ensure single trailing '\n' for consistency)
            body = _canon_line(body) + "\n"

            if tag == " ":
                # Context line must match
                if idx < len(lines) and _lines_equal(lines[idx], body):
                    out.append(lines[idx])
                    idx += 1
                elif not strict:
                    # Fuzzy resync: scan ahead to find this context line
                    found = _find_forward(lines, idx, body, lookahead)
                    if found is None:
                        raise PatchError(
                            f"Context mismatch; could not resync to: {body.strip()}"
                        )
                    # Copy-through any drifted lines
                    while idx < found:
                        out.append(lines[idx])
                        idx += 1
                    out.append(lines[idx])
                    idx += 1
                else:
                    raise PatchError(
                        f"Context mismatch in hunk (expected {body.strip()})"
                    )

            elif tag == "-":
                # Deletion: current line should match expected
                if idx < len(lines) and _lines_equal(lines[idx], body):
                    idx += 1  # drop it
                elif not strict:
                    # try to locate and delete within window
                    found = _find_forward(lines, idx, body, lookahead)
                    if found is None:
                        # assume already deleted (tolerate) in force mode
                        # do nothing; keep idx
                        pass
                    else:
                        # copy-through lines before the deletion target
                        while idx < found:
                            out.append(lines[idx])
                            idx += 1
                        idx += 1  # drop the matched line
                else:
                    raise PatchError(
                        f"Deletion mismatch in hunk (expected {body.strip()})"
                    )

            elif tag == "+":
                out.append(body)

            else:
                # Skip any stray markers safely
                continue

    # Copy remainder
    out.extend(lines[idx:])
    text = "".join(out)
    if not text.endswith("\n"):
        text += "\n"
    return text


def _invert_hunks(
    hunks: List[Tuple[int, int, int, int, List[str]]],
) -> List[Tuple[int, int, int, int, List[str]]]:
    """Swap old/new coords and flip +/- lines for reverse application."""
    inv: List[Tuple[int, int, int, int, List[str]]] = []
    for old_start, old_len, new_start, new_len, hunk_lines in hunks:
        flipped: List[str] = []
        for ln in hunk_lines:
            if ln.startswith("-"):
                flipped.append("+" + ln[1:])
            elif ln.startswith("+"):
                flipped.append("-" + ln[1:])
            else:
                flipped.append(ln)
        inv.append((new_start, new_len, old_start, old_len, flipped))
    return inv


def parse_unified_patch(
    text: str,
) -> List[Tuple[Path, List[Tuple[int, int, int, int, List[str]]]]]:
    files: List[Tuple[Path, List[Tuple[int, int, int, int, List[str]]]]] = []
    cur_file: Path | None = None
    cur_hunks: List[Tuple[int, int, int, int, List[str]]] = []
    it = io.StringIO(text)
    for raw in it:
        if raw.startswith("+++ "):
            # flush previous file (if any) BEFORE switching cur_file
            if cur_file is not None and cur_hunks:
                files.append((cur_file, cur_hunks))
                cur_hunks = []
            # trust +++ path as the target file
            plus_path = raw.strip().split(" ", 1)[1]
            cur_file = (
                Path(plus_path.replace("b/", "", 1))
                if plus_path.startswith("b/")
                else Path(plus_path)
            )
        elif raw.startswith("@@"):
            m = HUNK_RE.match(raw)
            if not m:
                raise PatchError("Bad hunk header")
            old_start = int(m.group(1))
            old_len = int(m.group(2) or 0)
            new_start = int(m.group(3))
            new_len = int(m.group(4) or 0)
            hlines: List[str] = []
            # read until next hunk/file/EOF
            pos = it.tell()
            while True:
                ln = it.readline()
                if not ln:
                    break
                if (
                    ln.startswith("@@")
                    or ln.startswith("--- ")
                    or ln.startswith("+++ ")
                ):
                    it.seek(pos)
                    break
                # Drop the sentinel line and any stray bare newline
                if ln.startswith("\\ No newline at end of file") or ln == "\n":
                    pos = it.tell()
                    continue
                hlines.append(ln)
                pos = it.tell()
            cur_hunks.append((old_start, old_len, new_start, new_len, hlines))
        else:
            continue
    if cur_file and cur_hunks:
        files.append((cur_file, cur_hunks))
    return files


def _is_git_safe_to_apply(target: Path, patch_file: Path) -> bool:
    """Very light guard: skip if target was modified AFTER the patch file was created.
    (We also rely on context mismatches to fail safe.)"""
    try:
        return target.stat().st_mtime <= patch_file.stat().st_mtime
    except Exception:
        return True


def apply_patch(
    path: Path,
    reverse: bool = False,
    *,
    git_safe: bool = True,
    strict: bool = True,
    lookahead: int = 200,
) -> bool:
    base = ensure_structure()
    text = read_patch_text(path)
    parsed = parse_unified_patch(text)
    if reverse:
        parsed = [(f, _invert_hunks(h)) for (f, h) in parsed]
    try:
        for fpath, hunks in parsed:
            target = Path(fpath)
            if not target.exists():
                raise PatchError(f"Target file missing: {target}")
            if git_safe and not _is_git_safe_to_apply(target, path):
                raise PatchError(
                    f"Refusing to apply: {target} modified after patch creation"
                )
            src = target.read_text(encoding="utf-8-sig")
            dst = _apply_hunks_to_text(src, hunks, strict=strict, lookahead=lookahead)
            # Always write normalized LF UTF-8 (no BOM)
            target.write_text(_canon_text(dst), encoding="utf-8")
        return True
    except PatchError as e:
        # Surface a brief diagnostic; CLI can capture/print if desired
        print(f"[patch] apply failed: {e}")
        return False


def push_patch_from_text(name_hint: str, text: str) -> Path:
    base = ensure_structure()
    pdir = base / "patches"
    pdir.mkdir(parents=True, exist_ok=True)
    p = pdir / f"{timestamp_slug()}_{name_hint}.patch"
    p.write_text(text, encoding="utf-8")
    state = load_state(base)
    state["applied"].append(p.name)
    save_state(base, state)
    _enforce_rotation(base, keep=10)
    return p


def pop_last_applied() -> Path | None:
    base = ensure_structure()
    state = load_state(base)
    if not state["applied"]:
        return None
    last = state["applied"].pop()
    state["reverted"].append(last)
    save_state(base, state)
    _enforce_rotation(base, keep=10)
    return base / "patches" / last


def pop_last_reverted() -> Path | None:
    base = ensure_structure()
    state = load_state(base)
    if not state["reverted"]:
        return None
    last = state["reverted"].pop()
    state["applied"].append(last)
    save_state(base, state)
    _enforce_rotation(base, keep=10)
    return base / "patches" / last


def last_applied() -> Path | None:
    """Non-mutating: return absolute Path of last applied patch, or None."""
    base = ensure_structure()
    name = peek_last_applied_name()
    return (base / "patches" / name) if name else None


def last_reverted() -> Path | None:
    """Non-mutating: return absolute Path of last reverted patch, or None."""
    base = ensure_structure()
    name = peek_last_reverted_name()
    return (base / "patches" / name) if name else None


def peek_last_applied_name() -> str | None:
    base = ensure_structure()
    state = load_state(base)
    return state["applied"][-1] if state.get("applied") else None


def peek_last_reverted_name() -> str | None:
    base = ensure_structure()
    state = load_state(base)
    return state["reverted"][-1] if state.get("reverted") else None


def patch_path_from_name(name: str) -> Path:
    base = ensure_structure()
    return base / "patches" / name


# -------- Rotation & listing --------
def _enforce_rotation(base: Path, keep: int = 10) -> None:
    """Keep only newest <keep> patch files overall; never delete files referenced in stacks."""
    pdir = base / "patches"
    if not pdir.exists():
        return
    state = load_state(base)
    keep_names = set(state.get("applied", []) + state.get("reverted", []))
    patches = sorted(
        pdir.glob("*.patch"), key=lambda p: p.stat().st_mtime, reverse=True
    )
    # If total <= keep, nothing to do (we don't delete referenced files ever).
    if len(patches) <= keep:
        return
    # Delete oldest unreferenced first until <= keep
    for p in reversed(patches):
        if len(patches) <= keep:
            break
        if p.name in keep_names:
            continue
        try:
            p.unlink(missing_ok=True)
            patches.remove(p)
        except Exception:
            pass


def list_stack(base: Path | None = None):
    base = ensure_structure() if base is None else base
    state = load_state(base)

    def _meta(name: str):
        p = base / "patches" / name
        try:
            st = p.stat()
            return {
                "name": name,
                "size": st.st_size,
                "mtime": int(st.st_mtime),
                "exists": True,
            }
        except FileNotFoundError:
            return {"name": name, "size": 0, "mtime": 0, "exists": False}

    return {
        "applied": [_meta(n) for n in state.get("applied", [])],
        "reverted": [_meta(n) for n in state.get("reverted", [])],
    }


# -------- Dry-run preview --------
def _normalize_lines(s: str) -> list[str]:
    return [line.rstrip("\r\n") + "\n" for line in s.splitlines()]


def _unified_diff(a_text: str, b_text: str, path: Path) -> str:
    a = _normalize_lines(a_text.replace("\r\n", "\n"))
    b = _normalize_lines(b_text.replace("\r\n", "\n"))
    diff_iter = difflib.unified_diff(
        a,
        b,
        fromfile=f"a/{path.as_posix()}",
        tofile=f"b/{path.as_posix()}",
        lineterm="",
    )
    text = "\n".join(diff_iter)
    if not text.endswith("\n"):
        text += "\n"
    return text


def preview_patch_apply(path: Path, reverse: bool = False):
    """Return [{"path": <file>, "diff": <unified_diff>}, ...] without touching disk."""
    text = read_patch_text(path)
    parsed = parse_unified_patch(text)
    if reverse:
        parsed = [(f, _invert_hunks(h)) for (f, h) in parsed]
    previews = []
    for fpath, hunks in parsed:
        target = Path(fpath)
        if not target.exists():
            raise PatchError(f"Target file missing: {target}")
        src = target.read_text(encoding="utf-8-sig")
        dst = _apply_hunks_to_text(src, hunks)
        previews.append({"path": str(target), "diff": _unified_diff(src, dst, target)})
    return previews


# -------- Convenience for CLI Undo/Redo wiring --------
def apply_last_applied(
    reverse: bool = True, *, git_safe: bool = True, strict: bool = True
) -> tuple[bool, Path | None]:
    """Undo by default (reverse=True): apply inverse of the last applied patch, non-destructively to stacks."""
    p = last_applied()
    if not p:
        return (False, None)
    ok = apply_patch(p, reverse=reverse, git_safe=git_safe, strict=strict)
    return (ok, p)


def apply_last_reverted(
    reverse: bool = False, *, git_safe: bool = True, strict: bool = True
) -> tuple[bool, Path | None]:
    """Redo by default (reverse=False): re-apply the last reverted patch."""
    p = last_reverted()
    if not p:
        return (False, None)
    ok = apply_patch(p, reverse=reverse, git_safe=git_safe, strict=strict)
    return (ok, p)
