from __future__ import annotations

import os
import pathlib
import platform

APP = "BranchPy"
HOME = pathlib.Path.home()
if platform.system() == "Windows":
    BASE = pathlib.Path(os.environ.get("LOCALAPPDATA", HOME / "AppData/Local")) / APP
else:
    BASE = HOME / f".{APP.lower()}"
LOGS = BASE / "logs"
CACHE = BASE / "cache"
CONFIG = BASE / "config.json"

for p in (BASE, LOGS, CACHE):
    p.mkdir(parents=True, exist_ok=True)
