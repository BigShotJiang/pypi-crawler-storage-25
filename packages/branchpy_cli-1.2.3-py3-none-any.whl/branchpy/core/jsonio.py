from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_json(path: str | Path) -> Any:
    """
    Robust JSON reader:
    - Accepts UTF-8 with or without BOM (utf-8-sig).
    - Raises ValueError with a short, user-facing message on failure.
    """
    p = Path(path)
    try:
        # utf-8-sig strips BOM if present
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except FileNotFoundError as e:
        raise ValueError(f"File not found: {p}") from e
    except UnicodeDecodeError as e:
        raise ValueError(
            f"Invalid text encoding in {p}; expected UTF-8/UTF-8 BOM."
        ) from e
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Invalid JSON in {p}: {e.msg} (line {e.lineno}, col {e.colno})"
        ) from e


def dump_json(path: str | Path, obj: Any) -> None:
    """
    Consistent JSON writer:
    - Writes UTF-8 without BOM.
    - Stable formatting (indent=2), Unix newlines.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(obj, indent=2, ensure_ascii=False)
    # Write without BOM, with '\n' newlines
    p.write_text(text.replace("\r\n", "\n"), encoding="utf-8")
