from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Mapping, Sequence

if TYPE_CHECKING:
    from branchpy.analysis.sae.assets.models import AssetIndex


@dataclass(frozen=True)
class ProjectSnapshot:
    """Immutable snapshot of a project at analysis time."""

    files: Sequence[str]
    labels: Mapping[str, dict]  # name -> {file, line, ...}
    calls: Sequence[dict] | None  # optional future field
    menus: Sequence[dict] | None  # optional future field
    vars: Mapping[str, dict] | None
    assets: "AssetIndex | None" = None  # Phase 2: asset validation index
    cfg_nodes: Sequence[dict] = field(
        default_factory=list
    )  # Phase 9: CFG for test coverage
