"""
Semantic Tape Builder for Compare Lanes (v0.8.8.3)
===================================================

Converts CFG slices into semantic tapes for alignment.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.core.compare.semantic_types import (
    LaneSpec,
    SemanticAction,
    SemanticActionType,
    SemanticStep,
)


def build_semantic_tape(lane: LaneSpec, project_root: Path) -> List[SemanticStep]:
    """
    Build a semantic tape from a lane specification.

    Args:
        lane: Lane specification with project, branch, start/end points
        project_root: Root directory of the project

    Returns:
        List of semantic steps representing the CFG slice

    Process:
        1. Load CFG from analysis snapshot (or latest)
        2. Find start/end nodes
        3. Linearize CFG traversal between start and end
        4. Convert each CFG node to SemanticStep
        5. Attach stats deltas, guards, choice text, file:line
    """
    # Load CFG
    cfg = _load_cfg(lane, project_root)
    if not cfg:
        return []

    # Find start and end nodes
    start_node = _find_node(cfg, lane.start)
    end_node = _find_node(cfg, lane.end) if lane.end.get("type") != "eof" else None

    if not start_node:
        return []

    # Linearize CFG between start and end
    tape: List[SemanticStep] = []
    visited = set()
    _traverse_cfg(cfg, start_node, end_node, tape, visited, project_root)

    return tape


def _load_cfg(lane: LaneSpec, project_root: Path) -> Optional[Dict[str, Any]]:
    """Load CFG from analysis snapshot or latest.

    Lookup order:
    1. <project>/.branchpy/snapshots/<analysis_id>_cfg.json  (legacy Wave-3 format)
    2. <project>/.branchpy/cfg.json                          (legacy single-file format)
    3. Merge all <project>/.branchpy/internal/<hash>/collapsed_graph.json files
       and convert from array-based format to the dict-keyed format this module uses.
    """
    # Determine which analysis to load
    if lane.analysis_id:
        cfg_path = (
            project_root / ".branchpy" / "snapshots" / f"{lane.analysis_id}_cfg.json"
        )
    else:
        # Load latest from branch
        cfg_path = project_root / ".branchpy" / "cfg.json"

    if cfg_path.exists():
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass  # fall through to internal graph fallback

    # Fallback: build a compatible CFG by merging collapsed_graph.json files from
    # .branchpy/internal/<hash>/ — these are the per-file graphs the analyzer writes.
    return _load_cfg_from_internal(project_root)


def _load_cfg_from_internal(project_root: Path) -> Optional[Dict[str, Any]]:
    """
    Build a tape-builder-compatible CFG by merging all collapsed_graph.json files
    from .branchpy/internal/<hash>/collapsed_graph.json.

    The collapsed_graph format uses array-based nodes and edges with field names that
    differ from what _find_node / _traverse_cfg expect. This function normalises them:

    Node conversion:
      - Array of {id, label, type, file, line, entry_candidate, ...}
        → dict keyed by id
      - type "narrative" → "label"  (entry-point nodes)
      - type "exit"     → "return"
      - type "routing"  → "jump"    (merge / routing nodes)
      - adds "name" = node["label"]  (used by _find_node label lookup)

    Edge conversion:
      - {src, dst, edge_type, ...} → {src, dst, type} (tape builder uses "type")
    """
    internal_dir = project_root / ".branchpy" / "internal"
    if not internal_dir.exists():
        return None

    merged_nodes: Dict[str, Any] = {}
    merged_edges: list = []
    seen_edge_pairs: set = set()

    _type_map = {
        "narrative": "label",
        "exit": "return",
        "routing": "jump",
        "engine_root": "label",
    }

    for graph_file in internal_dir.rglob("collapsed_graph.json"):
        try:
            with open(graph_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            continue

        raw_nodes = data.get("nodes", [])
        raw_edges = data.get("edges", [])

        if not isinstance(raw_nodes, list):
            continue

        for node in raw_nodes:
            if not isinstance(node, dict):
                continue
            node_id = node.get("id")
            if not node_id or node_id in merged_nodes:
                continue
            raw_type = node.get("type", "unknown")
            normalised_type = _type_map.get(raw_type, raw_type)
            merged_nodes[node_id] = {
                **node,
                "type": normalised_type,
                # _find_node looks for node_data.get("name") when spec_type == "label"
                "name": node.get("label", node_id),
                # _find_node looks for is_entry; collapsed_graph uses entry_candidate
                "is_entry": node.get("entry_candidate", False),
            }

        if not isinstance(raw_edges, list):
            continue
        for edge in raw_edges:
            if not isinstance(edge, dict):
                continue
            src = edge.get("src")
            dst = edge.get("dst")
            if not src or not dst:
                continue
            pair = (src, dst)
            if pair in seen_edge_pairs:
                continue
            seen_edge_pairs.add(pair)
            merged_edges.append({
                "src": src,
                "dst": dst,
                # tape_builder sorts by e.get("type"); collapsed_graph uses "edge_type"
                "type": edge.get("edge_type", edge.get("kind", "seq")),
            })

    if not merged_nodes:
        return None

    return {"nodes": merged_nodes, "edges": merged_edges}


def _find_node(cfg: Dict[str, Any], spec: Dict[str, str]) -> Optional[str]:
    """
    Find a CFG node by specification.

    Args:
        cfg: CFG data structure
        spec: {"type": "label", "value": "intro"} or {"type": "bof"}

    Returns:
        Node ID or None
    """
    spec_type = spec.get("type")

    if spec_type == "bof":
        # Beginning of file - find first label or entry point
        nodes = cfg.get("nodes", {})
        for node_id, node_data in nodes.items():
            if node_data.get("type") == "label" and node_data.get("is_entry", False):
                return node_id
        # Fallback to first label
        for node_id, node_data in nodes.items():
            if node_data.get("type") == "label":
                return node_id
        return None

    elif spec_type == "label":
        label_name = spec.get("value")
        nodes = cfg.get("nodes", {})
        for node_id, node_data in nodes.items():
            if node_data.get("type") == "label" and node_data.get("name") == label_name:
                return node_id
        return None

    return None


def _traverse_cfg(
    cfg: Dict[str, Any],
    current_node_id: str,
    end_node_id: Optional[str],
    tape: List[SemanticStep],
    visited: set,
    project_root: Path,
    depth: int = 0,
) -> None:
    """
    Traverse CFG from current node to end node, building semantic tape.

    Uses DFS with cycle detection. Stops at end_node_id or when no more edges.
    """
    # Guard against infinite loops
    if depth > 1000:
        return

    # Stop if we've reached the end
    if end_node_id and current_node_id == end_node_id:
        return

    # Skip if already visited (cycle detection)
    if current_node_id in visited:
        return

    visited.add(current_node_id)

    nodes = cfg.get("nodes", {})
    node_data = nodes.get(current_node_id)

    if not node_data:
        return

    # Convert node to semantic step
    step = _node_to_semantic_step(cfg, current_node_id, node_data, project_root)
    if step:
        tape.append(step)

    # Follow edges (prefer control flow edges)
    edges = cfg.get("edges", [])
    outgoing = [e for e in edges if e.get("src") == current_node_id]

    # Sort edges by type priority: SEQ > CHOICE > COND > JUMP
    edge_priority = {"seq": 0, "choice": 1, "cond": 2, "jump": 3, "call": 4}
    outgoing.sort(key=lambda e: edge_priority.get(e.get("type", ""), 99))

    # Follow first edge (primary path)
    if outgoing:
        next_node_id = outgoing[0].get("dst")
        if next_node_id:
            _traverse_cfg(
                cfg, next_node_id, end_node_id, tape, visited, project_root, depth + 1
            )


def _node_to_semantic_step(
    cfg: Dict[str, Any], node_id: str, node_data: Dict[str, Any], project_root: Path
) -> Optional[SemanticStep]:
    """
    Convert a CFG node to a SemanticStep.

    Extracts:
        - Semantic action type (LABEL, JUMP, SET, etc.)
        - Target (label name, stat name, etc.)
        - Value (stat delta, choice text, etc.)
        - File/line location
        - Stat deltas
        - Guards
    """
    node_type = node_data.get("type", "unknown")

    # Determine semantic action type
    action_type_map = {
        "label": SemanticActionType.LABEL,
        "jump": SemanticActionType.JUMP,
        "call": SemanticActionType.CALL,
        "menu": SemanticActionType.MENU,
        "choice": SemanticActionType.CHOICE,
        "say": SemanticActionType.TEXT,
        "python": SemanticActionType.SET,  # Python blocks often contain stat modifications
        "if": SemanticActionType.GUARD,
        "elif": SemanticActionType.GUARD,
        "return": SemanticActionType.RETURN,
    }

    action_type = action_type_map.get(node_type, SemanticActionType.UNKNOWN)

    # Extract target and value
    target = None
    value = None

    if node_type == "label":
        target = node_data.get("name")
    elif node_type in ("jump", "call"):
        target = node_data.get("target")
    elif node_type == "python":
        # Try to extract stat modifications from Python code
        code = node_data.get("code", "")
        # Simple pattern: "var_name += value" or "var_name = value"
        # For v0.8.8.3, we'll use stats_delta if available from Stats2 pass
        pass
    elif node_type == "choice":
        value = node_data.get("text", "")

    # Create semantic action
    action = SemanticAction(
        action_type=action_type,
        target=target,
        value=value,
        metadata={"node_type": node_type},
    )

    # Extract file/line information
    file_path = node_data.get("file")
    line_number = node_data.get("line")

    # Extract stats delta (from Stats2 analysis if available)
    stats_delta = node_data.get("stats_delta", {})

    # Extract guards
    guards = []
    if node_type in ("if", "elif"):
        condition = node_data.get("condition", "")
        if condition:
            guards.append({"expr": condition, "type": node_type})

    # Extract choice text
    choice_text = None
    if node_type == "choice":
        choice_text = node_data.get("text")

    # Extract label at this step
    label = None
    if node_type == "label":
        label = node_data.get("name")

    return SemanticStep(
        action=action,
        node_id=node_id,
        label=label,
        file_path=file_path,
        line_number=line_number,
        stats_delta=stats_delta,
        guards=guards,
        choice_text=choice_text,
        path_id=None,  # Will be set during alignment
    )
