"""
Anchor Detection for Compare Lanes (v0.8.8.3)
==============================================

Finds high-confidence anchor points for alignment.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from branchpy.core.compare.semantic_types import (
    DEFAULT_SEMANTICS,
    AliasMap,
    Anchor,
    Semantics,
    SemanticStep,
)


def find_anchor_candidates(
    slices: List[List[SemanticStep]],
    alias_map: Optional[AliasMap],
    semantics: Semantics = DEFAULT_SEMANTICS,
) -> List[Anchor]:
    """
    Find anchor candidates for alignment.

    Anchors are high-confidence alignment points:
        - Hard anchors: Exact label matches or alias hits
        - Soft anchors: High-score semantic windows

    Args:
        slices: List of semantic tapes (one per lane)
        alias_map: Manual alias mappings
        semantics: Semantic weighting configuration

    Returns:
        List of anchor points with row indices and reasons
    """
    if not slices or len(slices) < 2:
        return []

    anchors: List[Anchor] = []

    # Find hard anchors (label matches)
    hard_anchors = _find_hard_anchors(slices, alias_map)
    anchors.extend(hard_anchors)

    # Find soft anchors (semantic windows)
    soft_anchors = _find_soft_anchors(slices, semantics, window_size=3)
    anchors.extend(soft_anchors)

    # Sort by row and deduplicate
    anchors.sort(key=lambda a: a.row)

    return anchors


def _find_hard_anchors(
    slices: List[List[SemanticStep]], alias_map: Optional[AliasMap]
) -> List[Anchor]:
    """Find hard anchors based on exact label matches or aliases."""
    anchors: List[Anchor] = []

    # Collect all labels from each lane with their positions
    lane_labels: List[Dict[str, List[int]]] = []
    for tape in slices:
        label_positions = {}
        for idx, step in enumerate(tape):
            if step.label:
                if step.label not in label_positions:
                    label_positions[step.label] = []
                label_positions[step.label].append(idx)
        lane_labels.append(label_positions)

    # Find common labels across all lanes
    if not lane_labels:
        return anchors

    ref_labels = set(lane_labels[0].keys())

    for label in ref_labels:
        # Check if this label exists in all lanes (exact match or alias)
        lane_matches = []
        found_in_all = True

        for lane_idx, labels_dict in enumerate(lane_labels):
            if label in labels_dict:
                # Exact match
                positions = labels_dict[label]
                lane_matches.append(
                    {"lane": lane_idx, "label": label, "positions": positions}
                )
            elif alias_map and alias_map.lane_index == 0:
                # Check aliases
                aliases = alias_map.get_aliases(label)
                found = False
                for alias in aliases:
                    if alias in labels_dict:
                        positions = labels_dict[alias]
                        lane_matches.append(
                            {"lane": lane_idx, "label": alias, "positions": positions}
                        )
                        found = True
                        break
                if not found:
                    found_in_all = False
                    break
            else:
                found_in_all = False
                break

        if found_in_all and len(lane_matches) == len(slices):
            # Create anchor (use first occurrence in each lane)
            row = lane_matches[0]["positions"][0]
            reason = (
                "LABEL_EQ"
                if all(m["label"] == label for m in lane_matches)
                else "ALIAS"
            )

            anchors.append(
                Anchor(
                    row=row,
                    reason=reason,
                    lane_matches=[
                        {"lane": m["lane"], "label": m["label"]} for m in lane_matches
                    ],
                    score=3.0 if reason == "LABEL_EQ" else 2.0,
                )
            )

    return anchors


def _find_soft_anchors(
    slices: List[List[SemanticStep]], semantics: Semantics, window_size: int = 3
) -> List[Anchor]:
    """
    Find soft anchors based on semantic action patterns.

    Looks for windows where the semantic action multiset matches
    across lanes (e.g., GUARD + SET + SET + JUMP pattern).
    """
    anchors: List[Anchor] = []

    if len(slices) < 2:
        return anchors

    # Build windows for each lane
    ref_tape = slices[0]

    for i in range(len(ref_tape) - window_size + 1):
        ref_window = ref_tape[i : i + window_size]
        ref_vector = _window_vector(ref_window, semantics)

        # Check if this window pattern appears in other lanes
        matches = [{"lane": 0, "position": i}]

        for lane_idx in range(1, len(slices)):
            tape = slices[lane_idx]
            best_match_pos = None
            best_score = 0.0

            for j in range(len(tape) - window_size + 1):
                window = tape[j : j + window_size]
                vector = _window_vector(window, semantics)
                score = _vector_similarity(ref_vector, vector)

                if score > best_score and score > 0.7:  # Threshold
                    best_score = score
                    best_match_pos = j

            if best_match_pos is not None:
                matches.append({"lane": lane_idx, "position": best_match_pos})

        # If window matches in all lanes, create anchor
        if len(matches) == len(slices):
            actions = [step.action.action_type.value for step in ref_window]
            reason = f"SEMANTIC({'+'.join(actions)})"

            anchors.append(
                Anchor(row=i, reason=reason, lane_matches=matches, score=1.5)
            )

    return anchors


def _window_vector(
    window: List[SemanticStep], semantics: Semantics
) -> Dict[str, float]:
    """
    Convert a window to a weighted multiset vector.

    Returns:
        Dict mapping action types to weighted counts
    """
    vector: Dict[str, float] = {}
    for step in window:
        action_type = step.action.action_type
        weight = semantics.get_weight(action_type)
        key = action_type.value
        vector[key] = vector.get(key, 0.0) + weight
    return vector


def _vector_similarity(v1: Dict[str, float], v2: Dict[str, float]) -> float:
    """
    Compute cosine similarity between two vectors.

    Returns:
        Similarity score in [0, 1]
    """
    # Get all keys
    all_keys = set(v1.keys()) | set(v2.keys())

    if not all_keys:
        return 0.0

    # Compute dot product and magnitudes
    dot_product = sum(v1.get(k, 0) * v2.get(k, 0) for k in all_keys)
    mag1 = sum(v**2 for v in v1.values()) ** 0.5
    mag2 = sum(v**2 for v in v2.values()) ** 0.5

    if mag1 == 0 or mag2 == 0:
        return 0.0

    return dot_product / (mag1 * mag2)
