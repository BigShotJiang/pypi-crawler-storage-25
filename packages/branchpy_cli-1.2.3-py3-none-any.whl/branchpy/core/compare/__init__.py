"""
BranchPy Compare Module (v0.8.8.3)
===================================

Multi-lane semantic comparison with weighted LCS alignment.
"""

from branchpy.core.compare.exporter import export_html, export_json
from branchpy.core.compare.preview_engine import compare_preview, invalidate_cache
from branchpy.core.compare.semantic_types import (
    DEFAULT_SEMANTICS,
    AliasMap,
    Anchor,
    ComparePreviewResult,
    Filters,
    LaneSpec,
    Row,
    SemanticAction,
    SemanticActionType,
    Semantics,
    SemanticStep,
)

__all__ = [
    # Types
    "SemanticActionType",
    "SemanticAction",
    "SemanticStep",
    "LaneSpec",
    "Filters",
    "AliasMap",
    "Semantics",
    "Anchor",
    "Row",
    "ComparePreviewResult",
    "DEFAULT_SEMANTICS",
    # Main functions
    "compare_preview",
    "invalidate_cache",
    "export_html",
    "export_json",
]
