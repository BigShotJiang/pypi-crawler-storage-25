"""
Semantic Types for Compare Lanes (v0.8.8.3)
============================================

Type definitions for semantic tape construction and alignment.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class SemanticActionType(Enum):
    """Types of semantic actions in a narrative flow."""

    LABEL = "LABEL"  # Label definition
    JUMP = "JUMP"  # Jump to label
    CALL = "CALL"  # Call to label (returns)
    SET = "SET"  # Stat assignment/modification
    GUARD = "GUARD"  # Conditional guard (if/elif)
    CHOICE = "CHOICE"  # Menu choice point
    TEXT = "TEXT"  # Dialogue/narration text
    MENU = "MENU"  # Menu container
    RETURN = "RETURN"  # Return from call
    UNKNOWN = "UNKNOWN"  # Unknown/unsupported action


@dataclass
class SemanticAction:
    """
    A single semantic action in the narrative flow.

    Examples:
        LABEL(intro)
        SET(claire_trust += 1)
        GUARD(claire_trust >= 5)
        JUMP(post_intro1)
        CHOICE("Talk to Claire")
    """

    action_type: SemanticActionType
    target: Optional[str] = None  # Label name, stat name, etc.
    value: Optional[Any] = None  # Stat value, choice text, etc.
    confidence: str = "high"  # high, medium, low
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        if self.target:
            if self.value is not None:
                return f"{self.action_type.value}({self.target}={self.value})"
            return f"{self.action_type.value}({self.target})"
        return f"{self.action_type.value}"

    def __repr__(self) -> str:
        return self.__str__()


@dataclass
class SemanticStep:
    """
    A step in the semantic tape with full context.

    Includes the semantic action plus file location, CFG node ID,
    stat deltas, guards, and choice information.
    """

    action: SemanticAction
    node_id: Optional[str] = None
    label: Optional[str] = None  # Label at this step
    file_path: Optional[str] = None
    line_number: Optional[int] = None

    # Stats tracking
    stats_delta: Dict[str, float] = field(default_factory=dict)

    # Guard information
    guards: List[Dict[str, Any]] = field(default_factory=list)

    # Choice information
    choice_text: Optional[str] = None

    # Metadata
    path_id: Optional[str] = None  # Path identifier

    def __str__(self) -> str:
        parts = [str(self.action)]
        if self.label:
            parts.append(f"@{self.label}")
        if self.stats_delta:
            delta_str = ", ".join(f"{k}:{v:+g}" for k, v in self.stats_delta.items())
            parts.append(f"[{delta_str}]")
        return " ".join(parts)


@dataclass
class LaneSpec:
    """
    Specification for a single lane (branch slice).
    """

    project_id: str
    branch: str
    start: Dict[str, str]  # {"type": "label", "value": "intro"} or {"type": "bof"}
    end: Dict[str, str]  # {"type": "label", "value": "end"} or {"type": "eof"}
    analysis_id: Optional[str] = None

    def __post_init__(self):
        # Validate start/end types
        valid_types = {"label", "bof", "eof"}
        if self.start.get("type") not in valid_types:
            raise ValueError(f"Invalid start type: {self.start.get('type')}")
        if self.end.get("type") not in valid_types:
            raise ValueError(f"Invalid end type: {self.end.get('type')}")


@dataclass
class Filters:
    """Filter options for compare preview."""

    divergences_only: bool = False
    stat_keys: List[str] = field(default_factory=list)
    include_guards: bool = True
    include_choices: bool = True
    max_rows: int = 5000


@dataclass
class AliasMap:
    """Manual alias mapping for label alignment."""

    lane_index: int
    aliases: Dict[str, List[str]] = field(default_factory=dict)

    def get_aliases(self, label: str) -> List[str]:
        """Get all aliases for a given label."""
        return self.aliases.get(label, [])

    def is_alias(self, label1: str, label2: str) -> bool:
        """Check if two labels are aliased."""
        aliases1 = self.get_aliases(label1)
        aliases2 = self.get_aliases(label2)
        return (
            label2 in aliases1
            or label1 in aliases2
            or bool(set(aliases1) & set(aliases2))
        )


@dataclass
class Semantics:
    """Semantic weighting configuration."""

    weights: Dict[str, float] = field(
        default_factory=lambda: {
            "LABEL": 3.0,
            "JUMP": 2.0,
            "CALL": 2.0,
            "SET": 1.5,
            "GUARD": 1.5,
            "CHOICE": 1.2,
            "TEXT": 0.8,
        }
    )
    guard_compare_mode: str = "normalized"  # or "raw"

    def get_weight(self, action_type: SemanticActionType) -> float:
        """Get weight for a semantic action type."""
        return self.weights.get(action_type.value, 1.0)


@dataclass
class Anchor:
    """An alignment anchor point."""

    row: int
    reason: str  # "LABEL_EQ", "SEMANTIC(...)", "ALIAS"
    lane_matches: List[Dict[str, Any]] = field(default_factory=list)
    score: float = 0.0


@dataclass
class Row:
    """A single row in the aligned comparison."""

    row: int
    lanes: List[Dict[str, Any]]
    diff_summary: Optional[Dict[str, Any]] = None
    diverges: bool = False


@dataclass
class ComparePreviewResult:
    """Result of compare preview operation."""

    meta: Dict[str, Any]
    anchors: List[Anchor]
    rows: List[Row]
    summary: Dict[str, Any]


# Default semantics instance
DEFAULT_SEMANTICS = Semantics()
