"""
Compare Preview Exporter (v0.8.8.3)
====================================

Export compare preview results to HTML or JSON formats.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import List

from branchpy.core.compare.semantic_types import ComparePreviewResult, LaneSpec


def export_html(
    result: ComparePreviewResult,
    lanes: List[LaneSpec],
    output_path: Path,
    interactive: bool = True,
) -> None:
    """
    Export compare preview to standalone HTML.

    Args:
        result: ComparePreviewResult object
        lanes: List of lane specifications
        output_path: Output file path
        interactive: If True, include interactive features (collapsible, filters)
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    html = _generate_html(result, lanes, interactive)

    output_path.write_text(html, encoding="utf-8")


def export_json(
    result: ComparePreviewResult,
    lanes: List[LaneSpec],
    output_path: Path,
    include_metadata: bool = True,
) -> None:
    """
    Export compare preview to JSON.

    Args:
        result: ComparePreviewResult object
        lanes: List of lane specifications
        output_path: Output file path
        include_metadata: If True, include export metadata
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    output = {
        "meta": result.meta,
        "anchors": [
            {
                "row": anchor.row,
                "reason": anchor.reason,
                "laneMatches": anchor.lane_matches,
                "score": anchor.score,
            }
            for anchor in result.anchors
        ],
        "rows": [
            {
                "row": row.row,
                "lanes": row.lanes,
                "diffSummary": row.diff_summary,
                "diverges": row.diverges,
            }
            for row in result.rows
        ],
        "summary": result.summary,
    }

    if include_metadata:
        output["exportMetadata"] = {
            "exportedAt": datetime.utcnow().isoformat() + "Z",
            "exportFormat": "json",
            "exportVersion": "1.0",
            "lanes": [
                {
                    "project_id": lane.project_id,
                    "branch": lane.branch,
                    "start": lane.start,
                    "end": lane.end,
                    "analysis_id": lane.analysis_id,
                }
                for lane in lanes
            ],
        }

    output_json = json.dumps(output, indent=2, ensure_ascii=False)
    output_path.write_text(output_json, encoding="utf-8")


def _generate_html(
    result: ComparePreviewResult, lanes: List[LaneSpec], interactive: bool
) -> str:
    """Generate HTML content for compare preview."""

    # Build lane headers
    lane_headers = []
    for idx, lane in enumerate(lanes):
        start_type = lane.start.get("type")
        start_val = lane.start.get("value", start_type)
        end_type = lane.end.get("type")
        end_val = lane.end.get("value", end_type)

        lane_headers.append(
            f"""
            <div class="lane-header">
                <div class="lane-title">Lane {idx + 1}: {lane.branch}</div>
                <div class="lane-range">{start_val} → {end_val}</div>
                <div class="lane-project">{lane.project_id}</div>
            </div>
        """
        )

    # Build rows
    rows_html = []
    for row in result.rows:
        diverge_class = "divergent" if row.diverges else ""

        lanes_html = []
        for lane_data in row.lanes:
            if lane_data.get("gap"):
                lanes_html.append('<div class="lane-cell gap">[GAP]</div>')
            else:
                label = lane_data.get("label", "")
                stats = lane_data.get("statsDelta", {})
                guards = lane_data.get("guards", [])
                choice = lane_data.get("choice")
                file_path = lane_data.get("file", "")
                line = lane_data.get("line", "")

                # Build badges
                badges = []

                # Stat badges
                for key, value in stats.items():
                    sign = "+" if value >= 0 else ""
                    badges.append(
                        f'<span class="badge stat">{sign}{value} {key}</span>'
                    )

                # Guard badges
                for guard in guards:
                    expr = guard.get("expr", "")
                    badges.append(f'<span class="badge guard" title="{expr}">🛡️</span>')

                # Choice badge
                if choice:
                    badges.append(
                        f'<span class="badge choice" title="{choice}">💬</span>'
                    )

                badges_html = "".join(badges)

                # File:line link
                file_line = ""
                if file_path and line:
                    file_line = f'<div class="file-line">{file_path}:{line}</div>'

                lanes_html.append(
                    f"""
                    <div class="lane-cell">
                        <div class="label">{label or "—"}</div>
                        {badges_html}
                        {file_line}
                    </div>
                """
                )

        rows_html.append(
            f"""
            <div class="row {diverge_class}" data-row="{row.row}">
                <div class="row-num">{row.row}</div>
                {''.join(lanes_html)}
            </div>
        """
        )

    # Build anchor indicators for mini-map
    anchor_ticks = []
    max_row = result.meta["rowCount"]
    for anchor in result.anchors:
        if max_row > 0:
            position_pct = (anchor.row / max_row) * 100
            anchor_ticks.append(
                f'<div class="anchor-tick" style="top: {position_pct}%" title="{anchor.reason}"></div>'
            )

    # Build summary stats
    summary_html = f"""
        <div class="summary">
            <div class="stat-item">
                <span class="stat-label">Total Rows:</span>
                <span class="stat-value">{result.meta["rowCount"]}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Divergent:</span>
                <span class="stat-value">{result.summary["divergentRows"]}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Anchors:</span>
                <span class="stat-value">{len(result.anchors)}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Guards Changed:</span>
                <span class="stat-value">{result.summary.get("guardsChanged", 0)}</span>
            </div>
        </div>
    """

    # Generate full HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BranchPy Compare Preview - {len(lanes)} Lanes</title>
    <style>
        :root {{
            --bg: #0f172a;
            --fg: #e2e8f0;
            --border: #334155;
            --header-bg: #1e293b;
            --divergent-bg: #7f1d1d;
            --gap-bg: #374151;
            --badge-stat: #059669;
            --badge-guard: #0284c7;
            --badge-choice: #7c3aed;
            --anchor-color: #10b981;
        }}
        
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg);
            color: var(--fg);
            padding: 16px;
            line-height: 1.5;
        }}
        
        .header {{
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }}
        
        .title {{
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 8px;
        }}
        
        .meta {{
            color: #94a3b8;
            font-size: 14px;
        }}
        
        .summary {{
            display: flex;
            gap: 24px;
            margin-bottom: 16px;
            padding: 12px;
            background: var(--header-bg);
            border-radius: 8px;
        }}
        
        .stat-item {{
            display: flex;
            flex-direction: column;
            gap: 4px;
        }}
        
        .stat-label {{
            font-size: 12px;
            color: #94a3b8;
        }}
        
        .stat-value {{
            font-size: 18px;
            font-weight: bold;
        }}
        
        .lanes-container {{
            display: flex;
            gap: 16px;
        }}
        
        .main-content {{
            flex: 1;
            min-width: 0;
        }}
        
        .mini-map {{
            width: 40px;
            height: 600px;
            background: var(--header-bg);
            border-radius: 4px;
            position: relative;
            flex-shrink: 0;
        }}
        
        .anchor-tick {{
            position: absolute;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--anchor-color);
        }}
        
        .lane-headers {{
            display: grid;
            grid-template-columns: 50px repeat({len(lanes)}, 1fr);
            gap: 8px;
            margin-bottom: 8px;
            padding: 12px;
            background: var(--header-bg);
            border-radius: 8px;
            position: sticky;
            top: 0;
            z-index: 10;
        }}
        
        .lane-header {{
            padding: 8px;
        }}
        
        .lane-title {{
            font-weight: bold;
            margin-bottom: 4px;
        }}
        
        .lane-range {{
            font-size: 12px;
            color: #94a3b8;
        }}
        
        .lane-project {{
            font-size: 11px;
            color: #64748b;
        }}
        
        .rows {{
            display: flex;
            flex-direction: column;
            gap: 1px;
        }}
        
        .row {{
            display: grid;
            grid-template-columns: 50px repeat({len(lanes)}, 1fr);
            gap: 8px;
            padding: 8px;
            background: var(--header-bg);
            border-radius: 4px;
        }}
        
        .row.divergent {{
            background: var(--divergent-bg);
        }}
        
        .row-num {{
            color: #64748b;
            font-size: 12px;
            text-align: right;
            padding: 8px 4px;
        }}
        
        .lane-cell {{
            padding: 8px;
            border-radius: 4px;
        }}
        
        .lane-cell.gap {{
            background: var(--gap-bg);
            color: #6b7280;
            text-align: center;
        }}
        
        .label {{
            font-weight: 600;
            margin-bottom: 4px;
            color: #a5b4fc;
        }}
        
        .badge {{
            display: inline-block;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 11px;
            margin-right: 4px;
            margin-top: 4px;
        }}
        
        .badge.stat {{
            background: var(--badge-stat);
            color: white;
        }}
        
        .badge.guard {{
            background: var(--badge-guard);
            color: white;
        }}
        
        .badge.choice {{
            background: var(--badge-choice);
            color: white;
        }}
        
        .file-line {{
            font-size: 11px;
            color: #64748b;
            margin-top: 4px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="title">BranchPy Compare Preview</div>
        <div class="meta">
            Generated: {result.meta["generatedAt"]} | 
            Lanes: {len(lanes)} | 
            Rows: {result.meta["rowCount"]}
        </div>
    </div>
    
    {summary_html}
    
    <div class="lanes-container">
        <div class="main-content">
            <div class="lane-headers">
                <div></div>
                {''.join(lane_headers)}
            </div>
            
            <div class="rows">
                {''.join(rows_html)}
            </div>
        </div>
        
        <div class="mini-map">
            {''.join(anchor_ticks)}
        </div>
    </div>
</body>
</html>
"""

    return html
