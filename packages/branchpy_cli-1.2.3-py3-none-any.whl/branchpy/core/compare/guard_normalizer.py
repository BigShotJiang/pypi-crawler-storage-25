"""
Guard Normalization for Compare Lanes (v0.8.8.3)
================================================

Normalizes guard expressions for consistent comparison across branches.
"""

from __future__ import annotations

import re


def normalize_guard(expr: str) -> str:
    """
    Normalize a guard expression for comparison.

    Normalization steps:
        1. Remove whitespace
        2. Sort boolean AND/OR clauses
        3. Canonical operator forms (>= vs >, == vs is, etc.)
        4. Sort identifiers in commutative operations
        5. Lowercase keywords

    Examples:
        "claire_trust >= 5 and p_name_boldness > 3"
        -> "claire_trust>=5 and p_name_boldness>3"

        "x == 5 and y >= 10"
        -> "x==5 and y>=10"

        "y >= 10 and x == 5"  (order normalized)
        -> "x==5 and y>=10"

    Args:
        expr: Raw guard expression string

    Returns:
        Normalized expression string
    """
    if not expr:
        return ""

    # Step 1: Basic cleanup
    expr = expr.strip()

    # Step 2: Remove extra whitespace
    expr = re.sub(r"\s+", " ", expr)

    # Step 3: Normalize whitespace around operators
    expr = re.sub(r"\s*([<>=!]+)\s*", r"\1", expr)
    expr = re.sub(r"\s*(and|or)\s*", r" \1 ", expr, flags=re.IGNORECASE)

    # Step 4: Lowercase boolean operators
    expr = re.sub(r"\band\b", "and", expr, flags=re.IGNORECASE)
    expr = re.sub(r"\bor\b", "or", expr, flags=re.IGNORECASE)
    expr = re.sub(r"\bnot\b", "not", expr, flags=re.IGNORECASE)

    # Step 5: Split into clauses and sort
    if " and " in expr:
        clauses = expr.split(" and ")
        clauses = [_normalize_clause(c.strip()) for c in clauses]
        clauses.sort()
        expr = " and ".join(clauses)
    elif " or " in expr:
        clauses = expr.split(" or ")
        clauses = [_normalize_clause(c.strip()) for c in clauses]
        clauses.sort()
        expr = " or ".join(clauses)
    else:
        expr = _normalize_clause(expr)

    return expr


def _normalize_clause(clause: str) -> str:
    """
    Normalize a single boolean clause.

    Examples:
        "5 == x" -> "x==5"
        "10 > y" -> "y<10"
    """
    clause = clause.strip()

    # Pattern: operand1 operator operand2
    match = re.match(r"^(.+?)(==|!=|<=|>=|<|>)(.+)$", clause)
    if not match:
        return clause

    left, op, right = match.groups()
    left = left.strip()
    right = right.strip()

    # Canonical form: variable on left, constant on right
    # If left is a number and right is an identifier, swap
    if _is_number(left) and not _is_number(right):
        left, right = right, left
        op = _flip_operator(op)

    return f"{left}{op}{right}"


def _is_number(s: str) -> bool:
    """Check if string represents a number."""
    try:
        float(s)
        return True
    except ValueError:
        return False


def _flip_operator(op: str) -> str:
    """Flip comparison operator (for swapping operands)."""
    flip_map = {">": "<", "<": ">", ">=": "<=", "<=": ">=", "==": "==", "!=": "!="}
    return flip_map.get(op, op)


def guards_equal(expr1: str, expr2: str) -> bool:
    """
    Check if two guard expressions are semantically equal.

    Args:
        expr1: First guard expression
        expr2: Second guard expression

    Returns:
        True if normalized forms are identical
    """
    return normalize_guard(expr1) == normalize_guard(expr2)


def guard_similarity(expr1: str, expr2: str) -> float:
    """
    Calculate similarity score between two guard expressions.

    Returns:
        1.0 if identical, 0.0 if completely different,
        values in between for partial matches
    """
    norm1 = normalize_guard(expr1)
    norm2 = normalize_guard(expr2)

    if norm1 == norm2:
        return 1.0

    # Extract identifiers from both expressions
    idents1 = set(re.findall(r"\b[a-zA-Z_]\w*\b", norm1))
    idents2 = set(re.findall(r"\b[a-zA-Z_]\w*\b", norm2))

    # Jaccard similarity of identifiers
    if not idents1 and not idents2:
        return 0.0

    intersection = len(idents1 & idents2)
    union = len(idents1 | idents2)

    return intersection / union if union > 0 else 0.0
