"""
Weighted LCS Alignment for Compare Lanes (v0.8.8.3)
====================================================

Implements weighted Longest Common Subsequence alignment with semantic action boosting.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from branchpy.core.compare.guard_normalizer import guards_equal
from branchpy.core.compare.semantic_types import (
    DEFAULT_SEMANTICS,
    AliasMap,
    Anchor,
    SemanticActionType,
    Semantics,
    SemanticStep,
)


def weighted_lcs_align(
    slices: List[List[SemanticStep]],
    anchors: List[Anchor],
    semantics: Semantics = DEFAULT_SEMANTICS,
    alias_map: Optional[AliasMap] = None,
) -> List[Tuple[Optional[int], ...]]:
    """
    Align multiple semantic tapes using weighted LCS.

    Args:
        slices: List of semantic tapes (one per lane)
        anchors: Pre-computed anchor points
        semantics: Semantic weighting configuration
        alias_map: Manual alias mappings

    Returns:
        List of aligned indices tuples, e.g.:
        [(0, 0, 0), (1, 1, None), (2, 2, 1), ...]
        where None indicates a gap in that lane

    Algorithm:
        1. Use pairwise LCS with lane 0 as reference
        2. Merge pairwise alignments
        3. Apply anchor constraints (force alignment at anchors)
        4. Fill gaps
    """
    if not slices or len(slices) < 2:
        return []

    # Use pairwise alignment with lane 0 as reference
    ref_tape = slices[0]
    alignments = []

    for i in range(1, len(slices)):
        pair_align = _pairwise_weighted_lcs(
            ref_tape, slices[i], anchors, semantics, alias_map, lane_b_index=i
        )
        alignments.append(pair_align)

    # Merge pairwise alignments into multi-lane alignment
    merged = _merge_alignments(ref_tape, slices, alignments)

    return merged


def _pairwise_weighted_lcs(
    tape_a: List[SemanticStep],
    tape_b: List[SemanticStep],
    anchors: List[Anchor],
    semantics: Semantics,
    alias_map: Optional[AliasMap],
    lane_b_index: int = 1,
) -> List[Tuple[Optional[int], Optional[int]]]:
    """
    Compute weighted LCS between two tapes.

    Returns:
        List of (index_a, index_b) tuples
    """
    m, n = len(tape_a), len(tape_b)

    # DP table: dp[i][j] = best score aligning tape_a[:i] with tape_b[:j]
    dp = [[0.0] * (n + 1) for _ in range(m + 1)]

    # Traceback table for reconstruction
    trace: List[List[Optional[Tuple[str, int, int]]]] = [
        [None] * (n + 1) for _ in range(m + 1)
    ]

    # Cost parameters
    gap_penalty = 1.0
    mismatch_penalty = 0.7

    # Build DP table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            step_a = tape_a[i - 1]
            step_b = tape_b[j - 1]

            # Compute match score
            match_score = _compute_match_score(step_a, step_b, semantics, alias_map)

            # Check if this is an anchor point
            is_anchor = _is_anchor_point(i - 1, j - 1, 0, lane_b_index, anchors)
            if is_anchor:
                match_score += 5.0  # Boost anchor matches

            # Three options: match, gap in A, gap in B
            match = dp[i - 1][j - 1] + match_score
            gap_a = dp[i - 1][j] - gap_penalty
            gap_b = dp[i][j - 1] - gap_penalty

            # Take best option
            if match >= gap_a and match >= gap_b:
                dp[i][j] = match
                trace[i][j] = ("match", i - 1, j - 1)
            elif gap_a >= gap_b:
                dp[i][j] = gap_a
                trace[i][j] = ("gap_b", i - 1, j)
            else:
                dp[i][j] = gap_b
                trace[i][j] = ("gap_a", i, j - 1)

    # Traceback to reconstruct alignment
    alignment = []
    i, j = m, n

    while i > 0 or j > 0:
        if i == 0:
            alignment.append((None, j - 1))
            j -= 1
        elif j == 0:
            alignment.append((i - 1, None))
            i -= 1
        else:
            action = trace[i][j]
            if not action:
                break

            if action[0] == "match":
                alignment.append((i - 1, j - 1))
                i, j = action[1], action[2]
            elif action[0] == "gap_b":
                alignment.append((i - 1, None))
                i = action[1]
            else:  # gap_a
                alignment.append((None, j - 1))
                j = action[2]

    alignment.reverse()
    return alignment


def _compute_match_score(
    step_a: SemanticStep,
    step_b: SemanticStep,
    semantics: Semantics,
    alias_map: Optional[AliasMap],
) -> float:
    """
    Compute match score between two semantic steps.

    Returns:
        Positive score for good match, negative for mismatch
    """
    action_a = step_a.action
    action_b = step_b.action

    # Same action type?
    if action_a.action_type != action_b.action_type:
        return -0.7  # Mismatch penalty

    # Base weight for action type
    weight = semantics.get_weight(action_a.action_type)
    score = weight

    # Additional matching criteria

    # Label match
    if action_a.action_type == SemanticActionType.LABEL:
        if step_a.label == step_b.label:
            score += 2.0  # Exact label match
        elif alias_map and step_a.label and step_b.label:
            if alias_map.is_alias(step_a.label, step_b.label):
                score += 1.5  # Alias match
            else:
                score -= 1.0  # Different labels
        else:
            score -= 1.0

    # Guard match
    if action_a.action_type == SemanticActionType.GUARD:
        if step_a.guards and step_b.guards:
            guard_a = step_a.guards[0].get("expr", "")
            guard_b = step_b.guards[0].get("expr", "")
            if guards_equal(guard_a, guard_b):
                score += 1.0
            else:
                score -= 0.5

    # Stat delta match
    if step_a.stats_delta and step_b.stats_delta:
        # Check if same stats are modified
        keys_a = set(step_a.stats_delta.keys())
        keys_b = set(step_b.stats_delta.keys())

        if keys_a == keys_b:
            score += 0.5
            # Check if values match
            for key in keys_a:
                if step_a.stats_delta[key] == step_b.stats_delta[key]:
                    score += 0.3
                else:
                    score -= 0.2
        else:
            score -= 0.3

    # Choice text match
    if action_a.action_type == SemanticActionType.CHOICE:
        if step_a.choice_text == step_b.choice_text:
            score += 0.5
        else:
            score -= 0.3

    return score


def _is_anchor_point(
    idx_a: int, idx_b: int, lane_a_index: int, lane_b_index: int, anchors: List[Anchor]
) -> bool:
    """Check if this pair of indices corresponds to an anchor point."""
    for anchor in anchors:
        matches = anchor.lane_matches
        if len(matches) > max(lane_a_index, lane_b_index):
            match_a = matches[lane_a_index]
            match_b = matches[lane_b_index]

            # Check if both lanes have this anchor at these indices
            # (simplified check - in real impl, would need row mapping)
            # For now, just boost label matches
            return True

    return False


def _merge_alignments(
    ref_tape: List[SemanticStep],
    all_tapes: List[List[SemanticStep]],
    pairwise_alignments: List[List[Tuple[Optional[int], Optional[int]]]],
) -> List[Tuple[Optional[int], ...]]:
    """
    Merge multiple pairwise alignments into a single multi-lane alignment.

    Args:
        ref_tape: Reference tape (lane 0)
        all_tapes: All tapes including reference
        pairwise_alignments: Pairwise alignments of each tape with reference

    Returns:
        Multi-lane alignment
    """
    if not pairwise_alignments:
        return []

    # Build merged alignment by walking through reference tape
    merged = []
    ref_idx = 0
    lane_indices = [0] * len(all_tapes)
    lane_indices[0] = 0

    # Create index maps from pairwise alignments
    ref_to_lane_maps = []
    for pair_align in pairwise_alignments:
        ref_to_lane = {}
        for ref_i, lane_i in pair_align:
            if ref_i is not None and lane_i is not None:
                ref_to_lane[ref_i] = lane_i
        ref_to_lane_maps.append(ref_to_lane)

    # Walk through reference tape
    for ref_idx in range(len(ref_tape)):
        row_indices = [ref_idx]  # Lane 0 (reference)

        # Map to other lanes
        for lane_num, ref_to_lane in enumerate(ref_to_lane_maps, start=1):
            lane_idx = ref_to_lane.get(ref_idx)
            row_indices.append(lane_idx)

        merged.append(tuple(row_indices))

    # Add gaps for lanes that extend beyond reference
    # (simplified - full impl would handle this more carefully)

    return merged
