"""
Row Emission for Compare Lanes (v0.8.8.3)
==========================================

Generates aligned rows with divergence detection.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from branchpy.core.compare.guard_normalizer import guards_equal
from branchpy.core.compare.semantic_types import Filters, Row, SemanticStep


def emit_rows(
    alignment: List[Tuple[Optional[int], ...]],
    slices: List[List[SemanticStep]],
    filters: Filters,
) -> List[Row]:
    """
    Generate aligned rows from alignment and semantic tapes.

    Args:
        alignment: Aligned indices (output of weighted_lcs_align)
        slices: Original semantic tapes
        filters: Filter configuration

    Returns:
        List of Row objects with divergence flags
    """
    rows: List[Row] = []

    for row_idx, indices in enumerate(alignment):
        if filters.max_rows and row_idx >= filters.max_rows:
            break

        # Build lane data for this row
        lanes_data = []
        for lane_idx, step_idx in enumerate(indices):
            if step_idx is None:
                # Gap in this lane
                lanes_data.append({"label": None, "gap": True, "diverges": True})
            else:
                step = slices[lane_idx][step_idx]
                lane_data = _step_to_lane_data(step)
                lanes_data.append(lane_data)

        # Detect divergence
        diverges = _detect_divergence(lanes_data, filters)

        # Apply filters
        if filters.divergences_only and not diverges:
            continue

        if filters.stat_keys:
            # Check if any lane has stats delta for filtered keys
            has_filtered_stat = any(
                lane.get("statsDelta")
                and any(key in lane["statsDelta"] for key in filters.stat_keys)
                for lane in lanes_data
                if not lane.get("gap")
            )
            if not has_filtered_stat:
                continue

        # Build diff summary
        diff_summary = _build_diff_summary(lanes_data) if diverges else None

        # Create row
        row = Row(
            row=row_idx, lanes=lanes_data, diff_summary=diff_summary, diverges=diverges
        )
        rows.append(row)

    return rows


def _step_to_lane_data(step: SemanticStep) -> Dict[str, Any]:
    """Convert a SemanticStep to lane data dict."""
    semantic_actions = [step.action.action_type.value]

    # Add target info to semantic actions
    if step.action.target:
        semantic_actions.append(
            f"{step.action.action_type.value}({step.action.target})"
        )

    # Add stat delta info
    for key, value in step.stats_delta.items():
        semantic_actions.append(f"SET({key}{value:+g})")

    # Add guard info
    for guard in step.guards:
        guard_expr = guard.get("expr", "")
        semantic_actions.append(f"GUARD({guard_expr})")

    return {
        "label": step.label,
        "pathId": step.path_id,
        "semantic": {"actions": semantic_actions},
        "statsDelta": dict(step.stats_delta) if step.stats_delta else {},
        "guards": [
            {"expr": g.get("expr", ""), "type": g.get("type", "if")}
            for g in step.guards
        ],
        "choice": step.choice_text,
        "file": step.file_path,
        "line": step.line_number,
        "diverges": False,  # Will be set later
    }


def _detect_divergence(lanes_data: List[Dict[str, Any]], filters: Filters) -> bool:
    """
    Detect if a row represents divergence across lanes.

    Divergence occurs if:
        - Any lane has a gap
        - Labels differ (excluding None/gaps)
        - Stat deltas differ
        - Guards differ
        - Choice text differs
    """
    # Check for gaps
    if any(lane.get("gap") for lane in lanes_data):
        return True

    # Collect non-gap lanes
    active_lanes = [lane for lane in lanes_data if not lane.get("gap")]

    if len(active_lanes) < 2:
        return False

    # Check label divergence
    labels = [lane.get("label") for lane in active_lanes]
    labels = [label for label in labels if label is not None]
    if len(set(labels)) > 1:
        return True

    # Check stat delta divergence
    if not filters.stat_keys:
        # Check all stats
        stat_deltas = [lane.get("statsDelta", {}) for lane in active_lanes]
        if len(stat_deltas) > 1:
            # Compare each stat key
            all_keys = set()
            for sd in stat_deltas:
                all_keys.update(sd.keys())

            for key in all_keys:
                values = [sd.get(key) for sd in stat_deltas]
                values = [v for v in values if v is not None]
                if len(set(values)) > 1:
                    return True
    else:
        # Check only filtered stat keys
        for key in filters.stat_keys:
            values = [lane.get("statsDelta", {}).get(key) for lane in active_lanes]
            values = [v for v in values if v is not None]
            if len(set(values)) > 1:
                return True

    # Check guard divergence
    if filters.include_guards:
        guards_lists = [lane.get("guards", []) for lane in active_lanes]
        if len(guards_lists) > 1:
            # Normalize and compare first guard in each lane
            if any(guards_lists):
                first_guards = [
                    guards[0].get("expr", "") if guards else ""
                    for guards in guards_lists
                ]
                first_guards = [g for g in first_guards if g]
                if len(first_guards) > 1:
                    # Check if all guards are equal
                    ref_guard = first_guards[0]
                    for guard in first_guards[1:]:
                        if not guards_equal(ref_guard, guard):
                            return True

    # Check choice text divergence
    if filters.include_choices:
        choices = [lane.get("choice") for lane in active_lanes]
        choices = [c for c in choices if c is not None]
        if len(set(choices)) > 1:
            return True

    return False


def _build_diff_summary(lanes_data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Build a summary of differences across lanes.

    Returns:
        Dict with keys like {"stat_name": [val1, val2, val3], ...}
    """
    summary = {}

    # Collect stat deltas
    all_stat_keys = set()
    for lane in lanes_data:
        if not lane.get("gap"):
            stats = lane.get("statsDelta", {})
            all_stat_keys.update(stats.keys())

    for key in all_stat_keys:
        values = []
        for lane in lanes_data:
            if lane.get("gap"):
                values.append(None)
            else:
                values.append(lane.get("statsDelta", {}).get(key))
        summary[key] = values

    return summary
