"""
PFI Integration for Compare System
===================================

Resolves dynamic jumps and function-based control flow using Project Function Index.
v0.8.9: Initial implementation
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


class DynamicJumpResolver:
    """
    Resolve dynamic jumps using PFI.

    Handles patterns like:
    - jump next_label()
    - call get_intro_path()
    - renpy.jump(variable_name)
    """

    def __init__(
        self, index_path_or_project: Path, pfi_index_path: Optional[Path] = None
    ):
        """
        Initialize resolver.

        Args:
            index_path_or_project: Path to PFI index JSON or project root directory
            pfi_index_path: Optional path to pre-generated PFI index (if first arg is project root)
        """
        index_path_or_project = Path(index_path_or_project)

        # Check if first arg is a JSON file (index) or directory (project)
        if index_path_or_project.is_file() and index_path_or_project.suffix == ".json":
            # Direct index path provided
            self.project_root = index_path_or_project.parent
            self.pfi_data: Optional[Dict] = None
            self.function_map: Dict[str, Any] = {}
            self._load_index(index_path_or_project)
        else:
            # Project root provided
            self.project_root = index_path_or_project
            self.pfi_data: Optional[Dict] = None
            self.function_map: Dict[str, Any] = {}

            # Try to load existing index
            if pfi_index_path and pfi_index_path.exists():
                self._load_index(pfi_index_path)
            else:
                # Try default location
                default_path = (
                    self.project_root / ".branchpy" / "reports" / "function_index.json"
                )
                if default_path.exists():
                    self._load_index(default_path)

    @property
    def functions(self) -> Dict[str, Any]:
        """Alias for function_map for backward compatibility"""
        return self.function_map

    def _load_index(self, index_path: Path):
        """Load PFI index from JSON file"""
        try:
            with open(index_path, "r", encoding="utf-8") as f:
                self.pfi_data = json.load(f)

            # Build function map for quick lookup
            if self.pfi_data and "functions" in self.pfi_data:
                for func in self.pfi_data["functions"]:
                    self.function_map[func["name"]] = func
        except Exception:
            pass  # Silently fail if index not available

    def is_dynamic_jump(self, target: str) -> bool:
        """
        Check if target appears to be a dynamic jump (function call).

        Args:
            target: Jump/call target string

        Returns:
            True if target looks like a function call
        """
        # Patterns indicating dynamic jump:
        # - Contains parentheses: next_label()
        # - Is a variable (no quotes): var_name
        # - Contains dot notation: helper.get_label()

        if "(" in target and ")" in target:
            return True

        if "." in target:
            return True

        # Check if it's a known function
        func_name = target.strip("()")
        if func_name in self.function_map:
            return True

        return False

    def resolve_dynamic_target(self, target: str) -> List[str]:
        """
        Resolve a dynamic jump to possible label targets.

        Args:
            target: Jump/call target (e.g., "next_label()", "get_path()")

        Returns:
            List of possible label targets, empty if cannot resolve
        """
        if not self.pfi_data:
            return []

        # Check if it's a function call pattern
        if not self.is_dynamic_jump(target):
            # Not a function call - treat as literal label
            return [target]

        # Extract function name
        func_name = target.strip("()").split("(")[0].split(".")[-1]

        if func_name not in self.function_map:
            return []

        func_data = self.function_map[func_name]

        # Get labels that this function returns or calls/jumps to
        labels = []

        # Prefer return values (these are direct targets)
        returns = func_data.get("returns_labels", [])
        if returns:
            labels.extend(returns)

        # Also include labels that are jumped/called to
        calls = func_data.get("calls_labels", [])
        if calls:
            labels.extend(calls)

        return labels

    def get_function_label_mapping(self) -> Dict[str, List[str]]:
        """
        Get mapping of all functions to labels they access.

        Returns:
            Dict mapping function name to list of labels
        """
        if not self.pfi_data:
            return {}

        mapping = {}
        for func in self.pfi_data.get("functions", []):
            labels = func.get("calls_labels", [])
            if labels:
                mapping[func["name"]] = labels

        return mapping

    def suggest_alias_for_function(
        self,
        func_name: str,
        branch_a_labels: Optional[Set[str]] = None,
        branch_b_labels: Optional[Set[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Suggest alias mapping when functions resolve to same labels.

        Can work in two modes:
        1. With branch labels: Find label aliases across branches
        2. Without branch labels: Find similar functions (same return values)

        Args:
            func_name: Function name
            branch_a_labels: Optional set of labels available in branch A
            branch_b_labels: Optional set of labels available in branch B

        Returns:
            List of alias suggestions as dicts with 'function', 'similarity', etc.
            Or tuple of (label_a, label_b) if branches provided and single match found
        """
        if not self.pfi_data:
            return []

        # If no branches provided, find similar functions
        if branch_a_labels is None and branch_b_labels is None:
            return self._suggest_similar_functions(func_name)

        # Original branch-based alias logic
        targets = self.resolve_dynamic_target(f"{func_name}()")

        if not targets:
            return []

        # Find which targets exist in each branch
        targets_a = [t for t in targets if t in branch_a_labels]
        targets_b = [t for t in targets if t in branch_b_labels]

        # If exactly one match in each branch but different labels, suggest alias
        if len(targets_a) == 1 and len(targets_b) == 1 and targets_a[0] != targets_b[0]:
            return [(targets_a[0], targets_b[0])]

        return []

    def _suggest_similar_functions(self, func_name: str) -> List[Dict[str, Any]]:
        """Find functions that return the same labels (potential aliases)"""
        if func_name not in self.function_map:
            return []

        target_func = self.function_map[func_name]
        target_returns = set(target_func.get("returns_labels", []))

        if not target_returns:
            return []

        # Find other functions with same return values
        similar = []
        for other_name, other_func in self.function_map.items():
            if other_name == func_name:
                continue

            other_returns = set(other_func.get("returns_labels", []))

            # Calculate similarity (Jaccard index)
            if other_returns:
                intersection = target_returns & other_returns
                union = target_returns | other_returns
                similarity = len(intersection) / len(union) if union else 0.0

                if similarity > 0:  # Any overlap
                    similar.append(
                        {
                            "function": other_name,
                            "similarity": similarity,
                            "shared_returns": list(intersection),
                            "file": other_func.get("file", ""),
                            "line": other_func.get("line", 0),
                        }
                    )

        # Sort by similarity (descending)
        similar.sort(key=lambda x: x["similarity"], reverse=True)

        return similar

    def expand_dynamic_path(self, path: List[str]) -> List[List[str]]:
        """
        Expand a path containing dynamic jumps into multiple concrete paths.

        Args:
            path: Label sequence potentially containing dynamic jumps

        Returns:
            List of concrete paths
        """
        if not self.pfi_data:
            return [path]

        # Find dynamic jumps in path
        # (This is a simplified implementation - would need CFG integration for full support)

        expanded_paths = [path]

        # For each label in path, check if it contains function calls
        for i, label in enumerate(path):
            if self.is_dynamic_jump(label):
                targets = self.resolve_dynamic_target(label)

                if targets:
                    # Replace this label with each possible target
                    new_paths = []
                    for expanded_path in expanded_paths:
                        for target in targets:
                            new_path = (
                                expanded_path[:i] + [target] + expanded_path[i + 1 :]
                            )
                            new_paths.append(new_path)
                    expanded_paths = new_paths

        return expanded_paths


def enhance_compare_with_pfi(
    lanes: Dict[str, List[str]], index_path: Path
) -> Dict[str, Any]:
    """
    Generate alias suggestions and dynamic resolutions for compare lanes using PFI.

    Args:
        lanes: Dict with 'branch_a' and 'branch_b' keys containing label sequences
        index_path: Path to PFI index JSON file

    Returns:
        Dict with 'alias_suggestions' and 'dynamic_resolutions' keys
    """
    resolver = DynamicJumpResolver(index_path)

    if not resolver.pfi_data:
        return {"alias_suggestions": {}, "dynamic_resolutions": {}}

    lane_a = lanes.get("branch_a", [])
    lane_b = lanes.get("branch_b", [])

    lane_a_labels = set(lane_a)
    lane_b_labels = set(lane_b)

    aliases = {}
    dynamic_resolutions = {}

    # Get all functions that access labels
    func_mapping = resolver.get_function_label_mapping()

    for func_name, labels in func_mapping.items():
        # Check if function appears in either lane
        func_call = f"{func_name}()"

        if func_call in lane_a or func_call in lane_b:
            # Resolve dynamic target
            targets = resolver.resolve_dynamic_target(func_call)
            dynamic_resolutions[func_call] = targets

            # Check for cross-branch aliases
            suggestion = resolver.suggest_alias_for_function(
                func_name, lane_a_labels, lane_b_labels
            )

            if suggestion and isinstance(suggestion, list) and len(suggestion) > 0:
                if isinstance(suggestion[0], tuple):
                    label_a, label_b = suggestion[0]
                    aliases[label_a] = label_b

    return {"alias_suggestions": aliases, "dynamic_resolutions": dynamic_resolutions}
