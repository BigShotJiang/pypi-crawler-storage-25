"""
Compare Preview Engine for Compare Lanes (v0.8.8.3)
====================================================

Main orchestration module for multi-lane comparison.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.core.compare.alignment import weighted_lcs_align
from branchpy.core.compare.anchors import find_anchor_candidates
from branchpy.core.compare.row_emitter import emit_rows
from branchpy.core.compare.semantic_types import (
    DEFAULT_SEMANTICS,
    AliasMap,
    ComparePreviewResult,
    Filters,
    LaneSpec,
    Semantics,
)
from branchpy.core.compare.tape_builder import build_semantic_tape

# Simple in-memory cache (in production, use Redis or similar)
_cache: Dict[str, ComparePreviewResult] = {}
_cache_ttl: Dict[str, float] = {}


def compare_preview(
    lanes: List[LaneSpec],
    filters: Optional[Filters] = None,
    alias_map: Optional[AliasMap] = None,
    semantics: Optional[Semantics] = None,
    project_root: Optional[Path] = None,
) -> ComparePreviewResult:
    """
    Generate multi-lane compare preview.

    Args:
        lanes: List of lane specifications (2-5 lanes)
        filters: Filter options
        alias_map: Manual alias mappings
        semantics: Semantic weighting configuration
        project_root: Project root directory

    Returns:
        ComparePreviewResult with meta, anchors, rows, summary

    Raises:
        ValueError: If lanes count is invalid or labels not found
    """
    # Validate inputs
    if not lanes or len(lanes) < 2 or len(lanes) > 5:
        raise ValueError("Must provide 2-5 lanes")

    if filters is None:
        filters = Filters()

    if semantics is None:
        semantics = DEFAULT_SEMANTICS

    if project_root is None:
        project_root = Path.cwd()

    # Check cache
    cache_key = _compute_cache_key(lanes, filters, alias_map, semantics)
    if cache_key in _cache:
        # Check TTL (5 minutes)
        import time

        if time.time() - _cache_ttl.get(cache_key, 0) < 300:
            return _cache[cache_key]

    # Step 1: Build semantic tapes for each lane
    slices = []
    for lane in lanes:
        tape = build_semantic_tape(lane, project_root)
        if not tape:
            raise ValueError(
                f"Could not build tape for lane: {lane.project_id}/{lane.branch}"
            )
        slices.append(tape)

    # Step 2: Find anchor candidates
    anchors = find_anchor_candidates(slices, alias_map, semantics)

    # Step 3: Weighted LCS alignment
    alignment = weighted_lcs_align(slices, anchors, semantics, alias_map)

    # Step 4: Emit rows with divergence detection
    rows = emit_rows(alignment, slices, filters)

    # Step 5: Build summary
    summary = _build_summary(rows, lanes)

    # Step 6: Build meta
    meta = {
        "lanes": len(lanes),
        "rowCount": len(rows),
        "generatedAt": datetime.utcnow().isoformat() + "Z",
        "analysisIds": [lane.analysis_id or "latest" for lane in lanes],
    }

    # Create result
    result = ComparePreviewResult(
        meta=meta, anchors=anchors, rows=rows, summary=summary
    )

    # Cache result
    import time

    _cache[cache_key] = result
    _cache_ttl[cache_key] = time.time()

    return result


def _compute_cache_key(
    lanes: List[LaneSpec],
    filters: Filters,
    alias_map: Optional[AliasMap],
    semantics: Semantics,
) -> str:
    """Compute cache key from parameters."""
    # Serialize parameters
    params = {
        "lanes": [
            {
                "project_id": lane.project_id,
                "branch": lane.branch,
                "start": lane.start,
                "end": lane.end,
                "analysis_id": lane.analysis_id,
            }
            for lane in lanes
        ],
        "filters": {
            "divergences_only": filters.divergences_only,
            "stat_keys": sorted(filters.stat_keys),
            "include_guards": filters.include_guards,
            "include_choices": filters.include_choices,
            "max_rows": filters.max_rows,
        },
        "alias_map": (
            {"lane_index": alias_map.lane_index, "aliases": alias_map.aliases}
            if alias_map
            else None
        ),
        "semantics": {
            "weights": semantics.weights,
            "guard_compare_mode": semantics.guard_compare_mode,
        },
    }

    params_json = json.dumps(params, sort_keys=True)
    return hashlib.sha256(params_json.encode()).hexdigest()[:16]


def _build_summary(rows: List, lanes: List[LaneSpec]) -> Dict[str, Any]:
    """Build summary statistics."""
    divergent_count = sum(1 for row in rows if row.diverges)

    # Count stat deltas per lane
    stat_deltas: Dict[str, List[float]] = {}
    for lane_idx in range(len(lanes)):
        for row in rows:
            if lane_idx < len(row.lanes):
                lane_data = row.lanes[lane_idx]
                if not lane_data.get("gap"):
                    for key, value in lane_data.get("statsDelta", {}).items():
                        if key not in stat_deltas:
                            stat_deltas[key] = [0.0] * len(lanes)
                        stat_deltas[key][lane_idx] += value

    # Count guards changed
    guards_changed = 0
    for row in rows:
        if row.diverges:
            # Check if divergence involves guards
            has_guard_diff = False
            guard_exprs = set()
            for lane_data in row.lanes:
                if not lane_data.get("gap"):
                    for guard in lane_data.get("guards", []):
                        guard_exprs.add(guard.get("expr", ""))
            if len(guard_exprs) > 1:
                has_guard_diff = True
                guards_changed += 1

    return {
        "divergentRows": divergent_count,
        "statDeltas": stat_deltas,
        "guardsChanged": guards_changed,
    }


def invalidate_cache(
    project_id: Optional[str] = None, analysis_id: Optional[str] = None
):
    """
    Invalidate cache entries and emit SSE event.

    Args:
        project_id: If provided, invalidate only entries for this project
        analysis_id: If provided, invalidate only entries for this analysis
    """
    if project_id is None and analysis_id is None:
        # Invalidate all
        _cache.clear()
        _cache_ttl.clear()
    else:
        # Selective invalidation (would need to parse cache keys)
        # For now, just clear all
        _cache.clear()
        _cache_ttl.clear()

    # Emit SSE event for cache invalidation
    try:
        from branchpy.server.events.helpers import emit_event

        emit_event(
            event_type="compare.preview.invalidated",
            data={
                "project_id": project_id,
                "analysis_id": analysis_id,
                "timestamp": datetime.now().isoformat(),
            },
        )
    except ImportError:
        # SSE module not available (non-server mode)
        pass
    except Exception as e:
        # Log but don't fail on SSE emission errors
        import logging

        logging.warning(f"Failed to emit compare.preview.invalidated event: {e}")
