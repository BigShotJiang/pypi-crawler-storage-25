"""
BranchPy Core Audit System

Provides tamper-evident audit logging with:
- Hash-chained JSONL entries (SHA-256)
- Pluggable sinks (local file, HTTPS, Git)
- Identity resolution (user + machine)
- Verification and replay capabilities

Part of v0.8.1 (Axis 4 — Collaboration & Governance)
"""

from __future__ import annotations

import hashlib
import json
import os
import socket
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Optional, Protocol

# =============================================================================
# Identity Model
# =============================================================================


@dataclass
class UserIdentity:
    """User identity (from .branchpy/identity.toml)"""

    name: str
    email: str
    user_uuid: str
    sso_provider: Optional[str] = None
    sso_subject: Optional[str] = None


@dataclass
class MachineIdentity:
    """Machine identity (hardware fingerprint)"""

    hostname: str
    machine_uuid: str


@dataclass
class Identity:
    """Combined user + machine identity"""

    user: UserIdentity
    machine: MachineIdentity


# =============================================================================
# Audit Entry Model
# =============================================================================


@dataclass
class RepoInfo:
    """Git repository context"""

    vcs: str = "git"
    branch: Optional[str] = None
    commit: Optional[str] = None
    dirty: Optional[bool] = None


@dataclass
class AuditEntryModel:
    """
    Single audit log entry (v1.0 schema)

    All fields except 'hash' are included in hash computation.
    'prev_hash' links to previous entry's hash (chain integrity).
    """

    # Envelope
    version: str = "1.0"
    seq: int = 0
    time_utc: str = ""
    tz_offset_min: int = 0

    # Identity
    user_uuid: str = ""
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    machine_uuid: str = ""
    hostname: Optional[str] = None

    # Context
    project_root: str = ""
    repo: Optional[RepoInfo] = None

    # Event
    action: str = ""
    args: Optional[dict[str, Any]] = None
    result: Optional[dict[str, Any]] = None

    # Integrity (hash chain)
    prev_hash: str = "0"
    hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for JSON serialization"""
        d = asdict(self)
        # Clean up None values for cleaner JSON
        return {k: v for k, v in d.items() if v is not None}


# =============================================================================
# Canonical JSON (Deterministic Serialization)
# =============================================================================


def canonical_json(obj: dict[str, Any], exclude: set[str] | None = None) -> str:
    """
    Serialize dict to canonical JSON for deterministic hashing.

    Rules:
    - Keys sorted lexicographically
    - No insignificant whitespace
    - Minimal escaping
    - Exclude specified keys (e.g., 'hash')

    Args:
        obj: Dictionary to serialize
        exclude: Keys to exclude from serialization

    Returns:
        Canonical JSON string (UTF-8)
    """
    if exclude:
        obj = {k: v for k, v in obj.items() if k not in exclude}

    return json.dumps(
        obj,
        sort_keys=True,  # Lexicographic key order
        separators=(",", ":"),  # No whitespace
        ensure_ascii=False,  # Keep Unicode as-is
    )


def compute_hash(entry: AuditEntryModel) -> str:
    """
    Compute SHA-256 hash of audit entry.

    Hash includes all fields except 'hash' itself.
    Uses canonical JSON for determinism.

    Args:
        entry: Audit entry to hash

    Returns:
        64-character hex SHA-256 hash
    """
    entry_dict = entry.to_dict()
    canonical = canonical_json(entry_dict, exclude={"hash"})
    hash_bytes = hashlib.sha256(canonical.encode("utf-8")).digest()
    return hash_bytes.hex()


# =============================================================================
# Audit Sink Protocol
# =============================================================================


class AuditSink(Protocol):
    """
    Protocol for audit log sinks.

    Sinks receive audit entries and deliver them to destinations
    (local file, HTTPS endpoint, Git repo, etc.).
    """

    def append(self, entry: AuditEntryModel) -> None:
        """Append audit entry (may buffer internally)"""
        ...

    def flush(self) -> None:
        """Force flush buffered entries"""
        ...

    def close(self) -> None:
        """Cleanup resources"""
        ...


# =============================================================================
# Local File Sink (Default)
# =============================================================================


class LocalFileSink:
    """
    Append-only JSONL file sink.

    Features:
    - Atomic append (temp file + rename)
    - Sequence tracking (seq.txt)
    - Conflict detection (concurrent writes)
    """

    def __init__(self, log_path: Path):
        self.log_path = log_path
        self.seq_path = log_path.parent / "seq.txt"
        self.conflicts_dir = log_path.parent / "conflicts"

        # Ensure directories exist
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.conflicts_dir.mkdir(exist_ok=True)

    def append(self, entry: AuditEntryModel) -> None:
        """Append entry with atomic write"""
        # 1. Read last sequence + hash
        last_seq, last_hash = self._read_last()

        # 2. Check for conflict (prev_hash mismatch)
        if entry.prev_hash != last_hash:
            self._handle_conflict(entry, expected_prev=last_hash)
            return

        # 3. Assign sequence
        entry.seq = last_seq + 1

        # 4. Compute hash
        entry.hash = compute_hash(entry)

        # 5. Atomic write (append mode)
        line = json.dumps(entry.to_dict(), ensure_ascii=False) + "\n"

        # Write atomically using temp file + rename on POSIX
        # (On Windows, just append directly as rename isn't atomic)
        if os.name == "posix":
            temp_path = self.log_path.with_suffix(".tmp")
            with open(temp_path, "w", encoding="utf-8") as f:
                f.write(line)

            # Append temp to log (cat-style)
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(temp_path.read_text(encoding="utf-8"))
            temp_path.unlink()
        else:
            # Windows: direct append
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(line)

        # 6. Update sequence counter
        self.seq_path.write_text(str(entry.seq), encoding="utf-8")

    def _read_last(self) -> tuple[int, str]:
        """Read last sequence number and hash from log"""
        if not self.log_path.exists():
            return 0, "0"  # Genesis

        # Read last line
        lines = self.log_path.read_text(encoding="utf-8").strip().split("\n")
        if not lines or not lines[-1]:
            return 0, "0"

        try:
            last_entry = json.loads(lines[-1])
            return last_entry["seq"], last_entry["hash"]
        except (json.JSONDecodeError, KeyError):
            return 0, "0"

    def _handle_conflict(self, entry: AuditEntryModel, expected_prev: str) -> None:
        """Handle concurrent write conflict"""
        # Ensure conflicts directory exists
        self.conflicts_dir.mkdir(parents=True, exist_ok=True)

        conflict_file = (
            self.conflicts_dir
            / f"{datetime.now(timezone.utc).isoformat().replace(':', '-')}.json"
        )
        conflict_data = {
            "conflict_detected_at": datetime.now(timezone.utc).isoformat(),
            "expected_prev_hash": expected_prev,
            "found_prev_hash": entry.prev_hash,
            "entry": entry.to_dict(),
        }
        conflict_file.write_text(json.dumps(conflict_data, indent=2), encoding="utf-8")

        raise RuntimeError(
            f"Audit log conflict detected. "
            f"Expected prev_hash={expected_prev}, found={entry.prev_hash}. "
            f"Conflict saved to {conflict_file}"
        )

    def flush(self) -> None:
        """No-op (always flushed)"""
        pass

    def close(self) -> None:
        """No-op"""
        pass


# =============================================================================
# Identity Resolution
# =============================================================================


class IdentityResolver:
    """
    Resolve user + machine identity from:
    1. Environment variables (BRANCHPY_USER, BRANCHPY_MACHINE)
    2. .branchpy/identity.toml
    3. Prompt (if missing)
    """

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.identity_path = project_root / ".branchpy" / "identity.toml"

    def resolve(
        self, *, user_override: str | None = None, machine_override: str | None = None
    ) -> Identity:
        """
        Resolve identity with priority:
        1. Overrides (CLI flags)
        2. Environment variables
        3. identity.toml
        4. Defaults (if not strict)
        """
        # Load from file (if exists)
        if self.identity_path.exists():
            identity = self._load_from_file()
        else:
            # Fallback: generate default
            identity = self._generate_default()

        # Apply overrides
        if user_override:
            identity.user.user_uuid = user_override
        elif os.getenv("BRANCHPY_USER"):
            identity.user.user_uuid = os.getenv("BRANCHPY_USER", "")
            identity.user.name = os.getenv("BRANCHPY_USER_NAME", "Unknown")
            identity.user.email = os.getenv("BRANCHPY_EMAIL", "")

        if machine_override:
            identity.machine.machine_uuid = machine_override
        elif os.getenv("BRANCHPY_MACHINE"):
            identity.machine.machine_uuid = os.getenv("BRANCHPY_MACHINE", "")

        return identity

    def _load_from_file(self) -> Identity:
        """Load identity from identity.toml"""
        try:
            import tomli
        except ImportError:
            import tomllib as tomli  # Python 3.11+

        with open(self.identity_path, "rb") as f:
            data = tomli.load(f)

        user = UserIdentity(
            name=data["user"]["name"],
            email=data["user"]["email"],
            user_uuid=data["user"]["user_uuid"],
            sso_provider=data["user"].get("sso_provider"),
            sso_subject=data["user"].get("sso_subject"),
        )

        machine = MachineIdentity(
            hostname=data["machine"]["hostname"],
            machine_uuid=data["machine"]["machine_uuid"],
        )

        return Identity(user=user, machine=machine)

    def _generate_default(self) -> Identity:
        """Generate default identity (for first-time use)"""
        user = UserIdentity(name="Unknown User", email="", user_uuid=str(uuid.uuid4()))

        machine = MachineIdentity(
            hostname=socket.gethostname(), machine_uuid=self._generate_machine_uuid()
        )

        return Identity(user=user, machine=machine)

    def _generate_machine_uuid(self) -> str:
        """Generate persistent machine UUID from hardware fingerprint"""
        # Simple version: hash hostname + platform info
        # TODO: In production, use CPU serial, disk serial, MAC address
        fingerprint = f"{socket.gethostname()}-{os.name}"
        hash_bytes = hashlib.sha256(fingerprint.encode("utf-8")).digest()
        return str(uuid.UUID(bytes=hash_bytes[:16]))

    def create_identity(
        self, name: str, email: str, *, sso_provider: str | None = None
    ) -> Identity:
        """
        Create new identity.toml file.

        Args:
            name: Full name
            email: Email address
            sso_provider: Optional SSO provider

        Returns:
            Created Identity
        """
        user = UserIdentity(
            name=name,
            email=email,
            user_uuid=str(uuid.uuid4()),
            sso_provider=sso_provider,
        )

        machine = MachineIdentity(
            hostname=socket.gethostname(), machine_uuid=self._generate_machine_uuid()
        )

        identity = Identity(user=user, machine=machine)

        # Write to identity.toml
        self.identity_path.parent.mkdir(parents=True, exist_ok=True)

        toml_content = f"""# BranchPy Identity (v0.8.1)
# Created: {datetime.now(timezone.utc).isoformat()}

[user]
name = "{user.name}"
email = "{user.email}"
user_uuid = "{user.user_uuid}"
sso_provider = "{sso_provider or ''}"
sso_subject = ""

[machine]
hostname = "{machine.hostname}"
machine_uuid = "{machine.machine_uuid}"
"""

        self.identity_path.write_text(toml_content, encoding="utf-8")

        return identity


# =============================================================================
# Audit Context
# =============================================================================


@dataclass
class AuditContext:
    """Context for audit operations"""

    project_root: Path
    identity: Identity
    repo: Optional[RepoInfo] = None


# =============================================================================
# Verification Report
# =============================================================================


@dataclass
class VerificationReport:
    """Result of audit chain verification"""

    ok: bool
    entries: int = 0
    invalid: int = 0
    broken_at: Optional[int] = None
    reason: Optional[str] = None
    elapsed_ms: float = 0.0


# =============================================================================
# Auditor (Main Facade)
# =============================================================================


class Auditor:
    """
    Main audit system facade.

    Responsibilities:
    - Emit audit entries
    - Verify hash chain integrity
    - Replay audit log
    - Manage sinks
    """

    def __init__(self, ctx: AuditContext, sinks: list[AuditSink] | None = None):
        self.ctx = ctx
        self.sinks = sinks or []

        # Add default local file sink if not present
        if not any(isinstance(s, LocalFileSink) for s in self.sinks):
            log_path = ctx.project_root / ".branchpy" / "audit" / "log.jsonl"
            self.sinks.append(LocalFileSink(log_path))

    def emit(
        self,
        action: str,
        *,
        args: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
        redact: bool = True,
    ) -> None:
        """
        Emit audit entry to all sinks.

        Args:
            action: Action name (e.g., "stats.run")
            args: Action arguments (redacted by default)
            result: Action result
            redact: Whether to redact args (privacy-safe default)
        """
        # Redact args if enabled
        if redact and args:
            args = {"_redacted": f"dict ({len(args)} keys)"}

        # Get last hash from primary sink (local file)
        local_sink = next((s for s in self.sinks if isinstance(s, LocalFileSink)), None)
        if local_sink:
            _, prev_hash = local_sink._read_last()
        else:
            prev_hash = "0"

        # Create entry
        now = datetime.now(timezone.utc)
        entry = AuditEntryModel(
            version="1.0",
            time_utc=now.isoformat(),
            tz_offset_min=int(-time.timezone / 60),
            user_uuid=self.ctx.identity.user.user_uuid,
            user_name=self.ctx.identity.user.name,
            user_email=self.ctx.identity.user.email,
            machine_uuid=self.ctx.identity.machine.machine_uuid,
            hostname=self.ctx.identity.machine.hostname,
            project_root=str(self.ctx.project_root),
            repo=self.ctx.repo,
            action=action,
            args=args,
            result=result,
            prev_hash=prev_hash,
        )

        # Emit to all sinks
        for sink in self.sinks:
            try:
                sink.append(entry)
            except Exception as e:
                # Log error but continue (best-effort)
                print(f"[AUDIT] Sink {sink} failed: {e}")

    def verify(self, log_path: Path | None = None) -> VerificationReport:
        """
        Verify audit chain integrity.

        Args:
            log_path: Path to log file (default: .branchpy/audit/log.jsonl)

        Returns:
            VerificationReport with results
        """
        if not log_path:
            log_path = self.ctx.project_root / ".branchpy" / "audit" / "log.jsonl"

        if not log_path.exists():
            return VerificationReport(ok=True, entries=0)

        start_time = time.time()
        prev_hash = "0"
        entries_count = 0

        for seq, line in enumerate(
            log_path.read_text(encoding="utf-8").strip().split("\n"), start=1
        ):
            if not line:
                continue

            entries_count += 1

            try:
                entry_dict = json.loads(line)

                # Check prev_hash linkage
                if entry_dict["prev_hash"] != prev_hash:
                    elapsed = (time.time() - start_time) * 1000
                    return VerificationReport(
                        ok=False,
                        entries=entries_count,
                        invalid=1,
                        broken_at=seq,
                        reason=f"prev_hash mismatch: expected {prev_hash}, found {entry_dict['prev_hash']}",
                        elapsed_ms=elapsed,
                    )

                # Recompute hash
                entry_without_hash = {
                    k: v for k, v in entry_dict.items() if k != "hash"
                }
                computed_hash = hashlib.sha256(
                    canonical_json(entry_without_hash).encode("utf-8")
                ).hexdigest()

                # Check stored hash
                if entry_dict["hash"] != computed_hash:
                    elapsed = (time.time() - start_time) * 1000
                    return VerificationReport(
                        ok=False,
                        entries=entries_count,
                        invalid=1,
                        broken_at=seq,
                        reason=f"hash mismatch: expected {computed_hash}, found {entry_dict['hash']}",
                        elapsed_ms=elapsed,
                    )

                # Advance chain
                prev_hash = entry_dict["hash"]

            except (json.JSONDecodeError, KeyError) as e:
                elapsed = (time.time() - start_time) * 1000
                return VerificationReport(
                    ok=False,
                    entries=entries_count,
                    invalid=1,
                    broken_at=seq,
                    reason=f"Invalid JSON or missing field: {e}",
                    elapsed_ms=elapsed,
                )

        elapsed = (time.time() - start_time) * 1000
        return VerificationReport(ok=True, entries=entries_count, elapsed_ms=elapsed)

    def replay(
        self,
        *,
        user: str | None = None,
        action: str | None = None,
        since: str | None = None,
        until: str | None = None,
        log_path: Path | None = None,
    ) -> Iterator[AuditEntryModel]:
        """
        Replay audit log with optional filters.

        Args:
            user: Filter by user UUID
            action: Filter by action name
            since: Filter by start time (ISO 8601)
            until: Filter by end time (ISO 8601)
            log_path: Path to log file

        Yields:
            Filtered audit entries
        """
        if not log_path:
            log_path = self.ctx.project_root / ".branchpy" / "audit" / "log.jsonl"

        if not log_path.exists():
            return

        for line in log_path.read_text(encoding="utf-8").strip().split("\n"):
            if not line:
                continue

            try:
                entry_dict = json.loads(line)

                # Apply filters
                if user and entry_dict.get("user_uuid") != user:
                    continue
                if action and entry_dict.get("action") != action:
                    continue
                if since and entry_dict.get("time_utc", "") < since:
                    continue
                if until and entry_dict.get("time_utc", "") > until:
                    continue

                # Convert to model (simplified)
                entry = AuditEntryModel(**entry_dict)
                yield entry

            except (json.JSONDecodeError, TypeError):
                continue

    def flush(self) -> None:
        """Flush all sinks"""
        for sink in self.sinks:
            sink.flush()

    def close(self) -> None:
        """Close all sinks"""
        for sink in self.sinks:
            sink.close()


# =============================================================================
# RBAC Helper Functions
# =============================================================================

# Role capability map
ROLE_CAPABILITIES = {
    "owner": [
        "stats:run",
        "compare:open",
        "serve:start",
        "render:html",
        "render:pdf",
        "audit:verify",
        "audit:replay",
        "audit:tail",
        "audit:push",
        "config:team:write",
        "config:sinks:write",
        "identity:init",
        "identity:whoami",
    ],
    "contributor": [
        "stats:run",
        "compare:open",
        "serve:start",
        "render:html",
        "render:pdf",
        "identity:init",
        "identity:whoami",
    ],
    "auditor": [
        "audit:verify",
        "audit:replay",
        "audit:tail",
        "identity:whoami",
    ],
}


def get_user_role(user_uuid: str, team_toml_path: Path) -> str | None:
    """
    Get user role from team.toml

    Args:
        user_uuid: User UUID to lookup
        team_toml_path: Path to team.toml

    Returns:
        Role string ("owner", "contributor", "auditor") or None if not found
    """
    if not team_toml_path.exists():
        return None

    try:
        # Use tomllib if Python 3.11+, else tomli
        try:
            import tomllib

            with open(team_toml_path, "rb") as f:
                team_config = tomllib.load(f)
        except ImportError:
            import tomli

            with open(team_toml_path, "rb") as f:
                team_config = tomli.load(f)

        # Find user in team config
        for user in team_config.get("users", []):
            if user.get("user_uuid") == user_uuid:
                return user.get("role", "contributor")

        return None
    except Exception:
        return None


def has_capability(role: str | None, capability: str) -> bool:
    """
    Check if role has capability

    Args:
        role: User role or None (None = no team.toml, implicitly owner)
        capability: Capability string (e.g., "audit:verify")

    Returns:
        True if role has capability, False otherwise
    """
    # If no role (no team.toml), allow everything (implicit owner)
    if role is None:
        return True

    # Check role capabilities
    return capability in ROLE_CAPABILITIES.get(role, [])
