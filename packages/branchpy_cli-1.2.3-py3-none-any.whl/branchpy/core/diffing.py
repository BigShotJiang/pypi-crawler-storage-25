# branchpy/core/diffing.py
"""Enhanced report diffing engine for v0.6.5 compare functionality."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class IssueKey:
    """Composite key for issue comparison."""

    kind: str
    file: str
    line: int
    label: Optional[str] = None
    src: Optional[str] = None
    dst: Optional[str] = None

    @classmethod
    def from_issue(cls, issue: Dict[str, Any]) -> "IssueKey":
        """Create an IssueKey from an issue dictionary."""
        return cls(
            kind=str(issue.get("kind", "")),
            file=str(issue.get("path", "") or issue.get("file", "")),
            line=int(issue.get("line", 0)),
            label=issue.get("label"),
            src=issue.get("src"),
            dst=issue.get("dst"),
        )


@dataclass(frozen=True)
class JumpKey:
    """Composite key for jump/call comparison."""

    src: str
    dst: str
    file: str
    line: int

    @classmethod
    def from_jump(cls, jump: Dict[str, Any]) -> "JumpKey":
        """Create a JumpKey from a jump dictionary."""
        return cls(
            src=str(jump.get("src", "")),
            dst=str(jump.get("dst", "")),
            file=str(jump.get("file", "") or jump.get("path", "")),
            line=int(jump.get("line", 0)),
        )


def normalize_report(report: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize report for stable comparison by sorting arrays and standardizing keys."""
    normalized = dict(report)

    # Sort labels alphabetically
    if "labels" in normalized and isinstance(normalized["labels"], list):
        normalized["labels"] = sorted(normalized["labels"])

    # Sort issues by key for stable comparison
    if "issues" in normalized and isinstance(normalized["issues"], list):
        normalized["issues"] = sorted(
            normalized["issues"],
            key=lambda x: (
                x.get("kind", ""),
                x.get("path", "") or x.get("file", ""),
                x.get("line", 0),
                x.get("value", "")
                or x.get("label", "")
                or x.get("src", "")
                or x.get("dst", ""),
            ),
        )

    # Sort jumps by key for stable comparison
    if "jumps" in normalized and isinstance(normalized["jumps"], list):
        normalized["jumps"] = sorted(
            normalized["jumps"],
            key=lambda x: (
                x.get("src", ""),
                x.get("dst", ""),
                x.get("file", "") or x.get("path", ""),
                x.get("line", 0),
            ),
        )

    return normalized


def diff_reports(old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate a comprehensive diff between two analyzer reports.

    Returns a structured diff with added/removed/modified sections for:
    - labels (keyed by name)
    - jumps (keyed by src/dst/file/line)
    - issues (keyed by kind/file/line/label/src/dst)
    """
    # Normalize both reports for stable comparison
    old_norm = normalize_report(old)
    new_norm = normalize_report(new)

    # Diff labels
    old_labels = set(old_norm.get("labels", []))
    new_labels = set(new_norm.get("labels", []))

    labels_diff = {
        "added": sorted(new_labels - old_labels),
        "removed": sorted(old_labels - new_labels),
        "modified": [],  # Labels are simple strings, no modification concept
    }

    # Diff jumps
    old_jumps = old_norm.get("jumps", [])
    new_jumps = new_norm.get("jumps", [])

    old_jump_map = {JumpKey.from_jump(j): j for j in old_jumps}
    new_jump_map = {JumpKey.from_jump(j): j for j in new_jumps}

    added_jump_keys = set(new_jump_map.keys()) - set(old_jump_map.keys())
    removed_jump_keys = set(old_jump_map.keys()) - set(new_jump_map.keys())
    common_jump_keys = set(old_jump_map.keys()) & set(new_jump_map.keys())

    # Check for modified jumps (same key but different content)
    modified_jumps = []
    for key in common_jump_keys:
        old_jump = old_jump_map[key]
        new_jump = new_jump_map[key]
        if old_jump != new_jump:
            modified_jumps.append(new_jump)

    jumps_diff = {
        "added": [
            new_jump_map[k]
            for k in sorted(
                added_jump_keys, key=lambda k: (k.src, k.dst, k.file, k.line)
            )
        ],
        "removed": [
            old_jump_map[k]
            for k in sorted(
                removed_jump_keys, key=lambda k: (k.src, k.dst, k.file, k.line)
            )
        ],
        "modified": modified_jumps,
    }

    # Diff issues
    old_issues = old_norm.get("issues", [])
    new_issues = new_norm.get("issues", [])

    old_issue_map = {IssueKey.from_issue(i): i for i in old_issues}
    new_issue_map = {IssueKey.from_issue(i): i for i in new_issues}

    added_issue_keys = set(new_issue_map.keys()) - set(old_issue_map.keys())
    removed_issue_keys = set(old_issue_map.keys()) - set(new_issue_map.keys())
    common_issue_keys = set(old_issue_map.keys()) & set(new_issue_map.keys())

    # Check for modified issues (same key but different content)
    modified_issues = []
    for key in common_issue_keys:
        old_issue = old_issue_map[key]
        new_issue = new_issue_map[key]
        if old_issue != new_issue:
            modified_issues.append(new_issue)

    # Persisting issues are those that appear in both reports unchanged
    persisting_issues = []
    for key in common_issue_keys:
        old_issue = old_issue_map[key]
        new_issue = new_issue_map[key]
        if old_issue == new_issue:
            persisting_issues.append(new_issue)

    def sort_issues(issues):
        return sorted(
            issues,
            key=lambda i: (
                i.get("kind", ""),
                i.get("path", "") or i.get("file", ""),
                i.get("line", 0),
            ),
        )

    issues_diff = {
        "added": sort_issues([new_issue_map[k] for k in added_issue_keys]),
        "removed": sort_issues([old_issue_map[k] for k in removed_issue_keys]),
        "modified": sort_issues(modified_issues),
        "persisting": sort_issues(persisting_issues),
    }

    # Calculate summary
    total_added = (
        len(labels_diff["added"]) + len(jumps_diff["added"]) + len(issues_diff["added"])
    )
    total_removed = (
        len(labels_diff["removed"])
        + len(jumps_diff["removed"])
        + len(issues_diff["removed"])
    )
    total_modified = len(jumps_diff["modified"]) + len(issues_diff["modified"])

    summary = {
        "changed": total_added > 0 or total_removed > 0 or total_modified > 0,
        "added": total_added,
        "removed": total_removed,
        "modified": total_modified,
    }

    return {
        "summary": summary,
        "labels": labels_diff,
        "jumps": jumps_diff,
        "issues": issues_diff,
        "meta": {
            "old_version": old.get("version"),
            "new_version": new.get("version"),
        },
    }
