from __future__ import annotations

import json
import platform
from datetime import datetime, timezone

from .config import load_config
from .paths import CACHE

TELEMETRY_FILE = CACHE / "telemetry.jsonl"


def _now_iso():
    return datetime.now(timezone.utc).isoformat()


def record(command: str, duration_ms: int, exit_code: int, extra: dict | None = None):
    cfg = load_config()
    if not cfg.get("telemetry_enabled", False):
        return
    payload = {
        "ts": _now_iso(),
        "command": command,
        "duration_ms": duration_ms,
        "exit_code": exit_code,
        "env": {
            "os": platform.platform(),
            "py": platform.python_version(),
            "branchpy": getattr(__import__("branchpy"), "__version__", "0.0.0"),
        },
    }
    if extra:
        payload["extra"] = extra
    with TELEMETRY_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")
