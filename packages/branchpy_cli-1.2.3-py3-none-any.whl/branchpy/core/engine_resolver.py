"""
Engine Detection & Resolution for BranchPy v0.9.2 (WS-C1).

This module provides automatic detection of game engine types:
- Ren'Py (visual novel engine)
- Unity (3D/2D game engine)
- Godot (open-source game engine)
- Generic (fallback for unknown engines)

Philosophy:
    "BranchPy understands your engine—policies adapt automatically."
    Engine detection enables intelligent rule filtering and context-aware analysis.

Governance:
    - Axis 5: Desktop vs Remote / Codespaces
    - WS-C1: Phase C Foundations (Engine Awareness)
    - BQF/BQS compliance: All detection is auditable
    - Extensibility: New engines can be added via registry

Author: BranchPy Team
Version: v0.9.2 (WS-C1)
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional


class EngineType(Enum):
    """Game engine types."""

    RENPY = "renpy"
    UNITY = "unity"
    GODOT = "godot"
    GENERIC = "generic"


@dataclass
class EngineContext:
    """
    Game engine detection result.

    Attributes:
        engine_type: Detected engine (renpy, unity, godot, generic)
        confidence: Detection confidence (0.0 - 1.0)
        version: Engine version if detectable (e.g., "8.1.0", "2022.3")
        indicators: Files/folders that triggered detection
        project_root: Project root directory

    Example:
        ctx = EngineResolver.detect(Path.cwd())
        if ctx.engine_type == EngineType.RENPY:
            print(f"Ren'Py {ctx.version} detected")
        print(f"Confidence: {ctx.confidence:.0%}")
    """

    engine_type: EngineType
    confidence: float
    version: Optional[str] = None
    indicators: list[str] = field(default_factory=list)
    project_root: Optional[Path] = None

    def to_dict(self) -> dict:
        """
        Convert to dictionary (for telemetry/serialization).

        Returns:
            Dict with engine_type, confidence, version, indicators

        Example:
            >>> ctx = EngineResolver.detect(Path.cwd())
            >>> ctx.to_dict()
            {
                'engine_type': 'renpy',
                'confidence': 0.95,
                'version': '8.1.0',
                'indicators': ['game/', 'script.rpy'],
                'project_root': '/path/to/project'
            }
        """
        return {
            "engine_type": self.engine_type.value,
            "confidence": self.confidence,
            "version": self.version,
            "indicators": self.indicators,
            "project_root": str(self.project_root) if self.project_root else None,
        }

    def __repr__(self) -> str:
        return (
            f"EngineContext(engine={self.engine_type.value}, "
            f"confidence={self.confidence:.2f}, "
            f"version={self.version or 'unknown'})"
        )


class EngineResolver:
    """
    Game engine detector with heuristic-based detection.

    Detection logic (in priority order):
    1. Godot: project.godot file (100% confidence)
    2. Unity: Assets/ + ProjectSettings/ folders (95% confidence)
    3. Ren'Py: game/ folder + *.rpy files (95% confidence)
    4. Generic: Fallback (50% confidence)

    Performance target: <0.5ms per detection

    Example:
        >>> resolver = EngineResolver()
        >>> ctx = resolver.detect(Path.cwd())
        >>> print(f"Detected {ctx.engine_type.value} with {ctx.confidence:.0%} confidence")
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize engine resolver.

        Args:
            project_root: Project root directory (defaults to current working directory)
        """
        self.project_root = project_root or Path.cwd()

    def detect(self, project_root: Optional[Path] = None) -> EngineContext:
        """
        Detect game engine from project structure.

        Args:
            project_root: Project root to analyze (overrides instance root)

        Returns:
            EngineContext with detected engine, confidence, version, indicators

        Example:
            >>> resolver = EngineResolver()
            >>> ctx = resolver.detect(Path("/path/to/renpy/game"))
            >>> ctx.engine_type
            EngineType.RENPY
            >>> ctx.confidence
            0.95
        """
        root = project_root or self.project_root

        # Try Godot first (highest confidence when project.godot exists)
        godot_ctx = self._detect_godot(root)
        if godot_ctx.confidence >= 0.9:
            return godot_ctx

        # Try Unity (Assets/ + ProjectSettings/)
        unity_ctx = self._detect_unity(root)
        if unity_ctx.confidence >= 0.9:
            return unity_ctx

        # Try Ren'Py (game/ + *.rpy)
        renpy_ctx = self._detect_renpy(root)
        if renpy_ctx.confidence >= 0.9:
            return renpy_ctx

        # Fallback to generic
        return self._detect_generic(root)

    def _detect_godot(self, root: Path) -> EngineContext:
        """
        Detect Godot engine.

        Indicators:
        - project.godot file (required, 100% confidence)
        - *.tscn files (scene files)
        - *.tres files (resource files)
        - *.gd files (GDScript files)

        Version extraction:
        - Read from project.godot [application] config_version
        """
        indicators = []
        confidence = 0.0
        version = None

        # Check for project.godot (primary indicator)
        project_godot = root / "project.godot"
        if project_godot.exists():
            indicators.append("project.godot")
            confidence = 1.0  # 100% confidence

            # Try to extract version
            try:
                content = project_godot.read_text(encoding="utf-8")
                for line in content.splitlines():
                    if "config_version=" in line:
                        # Format: config_version=5
                        version_str = line.split("=")[1].strip().strip('"')
                        version = f"Godot {version_str}.x"
                        break
            except Exception:
                pass  # Ignore read errors

        # Sentinel check: look for common scene/script directories (avoid full tree walk)
        if confidence == 0.0:
            # Check for typical Godot project structure
            for sentinel in ["scenes", "scripts", "assets", "addons"]:
                sentinel_path = root / sentinel
                if sentinel_path.exists() and sentinel_path.is_dir():
                    # Quick sample: check first few files in directory
                    try:
                        sample_files = list(sentinel_path.iterdir())[:10]
                        tscn_count = sum(1 for f in sample_files if f.suffix == ".tscn")
                        gd_count = sum(1 for f in sample_files if f.suffix == ".gd")
                        if tscn_count > 0:
                            indicators.append(f"{sentinel}/ (Godot scenes)")
                            confidence = max(confidence, 0.7)
                        if gd_count > 0:
                            indicators.append(f"{sentinel}/ (GDScript)")
                            confidence = max(confidence, 0.6)
                    except Exception:
                        pass

        return EngineContext(
            engine_type=EngineType.GODOT,
            confidence=confidence,
            version=version,
            indicators=indicators,
            project_root=root,
        )

    def _detect_unity(self, root: Path) -> EngineContext:
        """
        Detect Unity engine.

        Indicators:
        - Assets/ folder (required)
        - ProjectSettings/ folder (required, 95% confidence together)
        - *.unity files (scene files)
        - *.prefab files (prefab assets)

        Version extraction:
        - Read from ProjectSettings/ProjectVersion.txt
        """
        indicators = []
        confidence = 0.0
        version = None

        # Check for Assets/ folder
        assets_folder = root / "Assets"
        if assets_folder.exists() and assets_folder.is_dir():
            indicators.append("Assets/")
            confidence = 0.7  # Assets alone = moderate confidence

        # Check for ProjectSettings/ folder
        project_settings = root / "ProjectSettings"
        if project_settings.exists() and project_settings.is_dir():
            indicators.append("ProjectSettings/")
            if confidence >= 0.7:
                confidence = 0.95  # Assets + ProjectSettings = high confidence
            else:
                confidence = 0.6

            # Try to extract version
            version_file = project_settings / "ProjectVersion.txt"
            if version_file.exists():
                try:
                    content = version_file.read_text(encoding="utf-8")
                    for line in content.splitlines():
                        if line.startswith("m_EditorVersion:"):
                            version = line.split(":")[1].strip()
                            break
                except Exception:
                    pass

        # Sentinel check: look for typical Unity asset structure (avoid full tree walk)
        if confidence >= 0.95:
            scenes_folder = assets_folder / "Scenes"
            if scenes_folder.exists() and scenes_folder.is_dir():
                # Quick sample: check first few files
                try:
                    sample_files = list(scenes_folder.iterdir())[:10]
                    unity_count = sum(1 for f in sample_files if f.suffix == ".unity")
                    if unity_count > 0:
                        indicators.append(f"Assets/Scenes/ ({unity_count} scenes)")
                except Exception:
                    pass

        return EngineContext(
            engine_type=EngineType.UNITY,
            confidence=confidence,
            version=version,
            indicators=indicators,
            project_root=root,
        )

    def _detect_renpy(self, root: Path) -> EngineContext:
        """
        Detect Ren'Py engine.

        Indicators:
        - game/ folder (required)
        - *.rpy files in game/ (required, 95% confidence together)
        - script.rpy (common main script)
        - options.rpy (common config script)

        Version extraction:
        - Read from game/script.rpy header comments
        - Format: "## Ren'Py 8.1.0"
        """
        indicators = []
        confidence = 0.0
        version = None

        # Check for game/ folder
        game_folder = root / "game"
        if game_folder.exists() and game_folder.is_dir():
            indicators.append("game/")
            confidence = 0.6  # game/ alone = moderate confidence

            # Check for .rpy files in game/
            rpy_files = list(game_folder.glob("*.rpy"))
            if rpy_files:
                indicators.append(f"{len(rpy_files)} .rpy files")
                confidence = 0.95  # game/ + .rpy files = high confidence

                # Try to extract version from script.rpy
                script_rpy = game_folder / "script.rpy"
                if script_rpy.exists():
                    indicators.append("script.rpy")
                    try:
                        content = script_rpy.read_text(encoding="utf-8")
                        # Look for version in first 10 lines
                        for line in content.splitlines()[:10]:
                            if "Ren'Py" in line or "renpy" in line.lower():
                                # Try to extract version number
                                import re

                                match = re.search(r"(\d+\.\d+(?:\.\d+)?)", line)
                                if match:
                                    version = match.group(1)
                                    break
                    except Exception:
                        pass

                # Check for options.rpy (common config file)
                if (game_folder / "options.rpy").exists():
                    indicators.append("options.rpy")

        return EngineContext(
            engine_type=EngineType.RENPY,
            confidence=confidence,
            version=version,
            indicators=indicators,
            project_root=root,
        )

    def _detect_generic(self, root: Path) -> EngineContext:
        """
        Generic fallback when no specific engine is detected.

        Always returns confidence 0.5 (unknown engine).
        """
        return EngineContext(
            engine_type=EngineType.GENERIC,
            confidence=0.5,
            version=None,
            indicators=["no engine detected"],
            project_root=root,
        )

    @classmethod
    def detect_engine_type(cls, project_root: Optional[Path] = None) -> EngineType:
        """
        Quick engine type detection (convenience method).

        Args:
            project_root: Project root to analyze (defaults to cwd)

        Returns:
            EngineType enum value

        Example:
            >>> from branchpy.core.engine_resolver import EngineResolver
            >>> engine = EngineResolver.detect_engine_type()
            >>> print(engine.value)
            'renpy'
        """
        resolver = cls(project_root)
        ctx = resolver.detect()
        return ctx.engine_type


# Convenience function for quick detection
def detect_engine(project_root: Optional[Path] = None) -> EngineContext:
    """
    Detect game engine (convenience wrapper).

    Args:
        project_root: Project root to analyze (defaults to cwd)

    Returns:
        EngineContext with detected engine

    Example:
        >>> from branchpy.core.engine_resolver import detect_engine
        >>> ctx = detect_engine()
        >>> print(f"Engine: {ctx.engine_type.value}")
        >>> print(f"Confidence: {ctx.confidence:.0%}")
    """
    resolver = EngineResolver(project_root)
    return resolver.detect()
