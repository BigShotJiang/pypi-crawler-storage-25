from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Set


@dataclass(frozen=True)
class CFGNode:
    id: str  # typically a label name; special: "__ENTRY__"
    semantic_actions: Optional[List[Dict[str, Any]]] = (
        None  # v0.8.7: semantic actions at this node
    )


@dataclass(frozen=True)
class CFGEdge:
    src: str
    dst: str
    kind: str = "jump"  # or "entry"
    semantic: Optional[Dict[str, Any]] = None  # v0.8.7: semantic metadata for this edge


class CFGGraph:
    def __init__(self) -> None:
        self.nodes: Dict[str, CFGNode] = {}
        self.adj: Dict[str, Set[str]] = {}
        self.edges: List[CFGEdge] = []

    def add_node(
        self, node_id: str, semantic_actions: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        if node_id not in self.nodes:
            self.nodes[node_id] = CFGNode(node_id, semantic_actions)
            self.adj[node_id] = set()

    def add_edge(
        self,
        src: str,
        dst: str,
        kind: str = "jump",
        semantic: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.add_node(src)
        self.add_node(dst)
        self.adj[src].add(dst)
        self.edges.append(CFGEdge(src, dst, kind, semantic))

    def reachable_from(self, roots: Iterable[str]) -> Set[str]:
        seen: Set[str] = set()
        stack: List[str] = list(roots)
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            for nxt in self.adj.get(cur, ()):
                if nxt not in seen:
                    stack.append(nxt)
        return seen

    def to_dict(self) -> Dict:
        nodes_list = []
        for node in self.nodes.values():
            node_dict = {"id": node.id}
            if node.semantic_actions:
                node_dict["semantic_actions"] = node.semantic_actions
            nodes_list.append(node_dict)

        edges_list = []
        for e in self.edges:
            edge_dict = {"src": e.src, "dst": e.dst, "kind": e.kind}
            if e.semantic:
                edge_dict["semantic"] = e.semantic
            edges_list.append(edge_dict)

        return {
            "nodes": nodes_list,
            "edges": edges_list,
        }

    def to_dot(self) -> str:
        lines = ["digraph CFG {", "  rankdir=LR;"]
        for n in self.nodes.values():
            shape = "doublecircle" if n.id == "__ENTRY__" else "ellipse"
            lines.append(f'  "{n.id}" [shape={shape}];')
        for e in self.edges:
            label = f' [label="{e.kind}"]' if e.kind != "jump" else ""
            lines.append(f'  "{e.src}" -> "{e.dst}"{label};')
        lines.append("}")
        return "\n".join(lines)
