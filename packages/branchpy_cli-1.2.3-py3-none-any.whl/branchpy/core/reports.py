# branchpy/core/reports.py
"""Report storage and management infrastructure for v0.6.5"""
from __future__ import annotations

import hashlib
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .jsonio import dump_json, load_json
from .paths import BASE


def _sanitize_project_name(name: str) -> str:
    """Sanitize a project name for use as a directory name."""
    return re.sub(r"[^\w\-_]", "_", name)


def _project_key(project_path: Union[str, Path]) -> str:
    """Generate a project key from a path: sanitized folder name + short hash."""
    project_path = Path(project_path).resolve()
    folder_name = _sanitize_project_name(project_path.name)

    # Generate short hash from path
    path_hash = hashlib.sha256(str(project_path).encode("utf-8")).hexdigest()[:6]

    return f"{folder_name}-{path_hash}"


def get_reports_dir(project_path: Union[str, Path]) -> Path:
    """Get the reports directory for a specific project."""
    project_key = _project_key(project_path)
    reports_dir = BASE / "reports" / project_key
    reports_dir.mkdir(parents=True, exist_ok=True)
    return reports_dir


def save_report(report_data: Dict[str, Any], project_path: Union[str, Path]) -> Path:
    """Save a report to the project's reports directory with timestamp."""
    reports_dir = get_reports_dir(project_path)

    # Generate timestamp filename
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    report_path = reports_dir / f"{timestamp}.json"

    # Add metadata
    report_data = dict(report_data)  # Don't modify original
    report_data["_metadata"] = {
        "timestamp": timestamp,
        "project_path": str(Path(project_path).resolve()),
        "saved_at": time.time(),
    }

    dump_json(report_path, report_data)

    # Rotate old reports (keep last 50)
    _rotate_reports(reports_dir, max_reports=50)

    return report_path


def list_reports(project_path: Union[str, Path]) -> List[Dict[str, Any]]:
    """List all reports for a project, sorted by timestamp descending (newest first)."""
    reports_dir = get_reports_dir(project_path)

    reports = []
    for report_file in reports_dir.glob("*.json"):
        try:
            stat = report_file.stat()
            # Extract timestamp from filename
            match = re.match(r"(\d{8}_\d{6})\.json$", report_file.name)
            if match:
                timestamp_str = match.group(1)
                reports.append(
                    {
                        "timestamp": timestamp_str,
                        "path": str(report_file),
                        "size": stat.st_size,
                        "mtime": stat.st_mtime,
                    }
                )
        except Exception:
            continue

    # Sort by timestamp descending (newest first)
    reports.sort(key=lambda x: x["timestamp"], reverse=True)
    return reports


def load_report(
    source: str, project_path: Optional[Union[str, Path]] = None
) -> Dict[str, Any]:
    """Load a report. See load_report_with_path for the path-aware variant."""
    data, _ = load_report_with_path(source, project_path)
    return data


def load_report_with_path(
    source: str, project_path: Optional[Union[str, Path]] = None
) -> tuple[Dict[str, Any], str]:
    """
    Load a report from various sources, returning (data, resolved_path).

    Sources:
    - "last", "last-1", "last-2", etc. (requires project_path)
    - "N" where N is a number (Nth most recent, requires project_path)
    - Absolute/relative file path to JSON report
    - ":git-ref" (future enhancement)
    """
    if source.startswith(":"):
        # Git reference mode (future enhancement)
        raise NotImplementedError("Git reference mode not yet implemented")

    if source in ("last", "latest") or source.startswith("last-") or source.isdigit():
        if not project_path:
            raise ValueError(f"Source '{source}' requires project_path to be specified")

        # (M-05) Prefer project-local .branchpy/analyze/ snapshots written by the CLI.
        # Fall back to the global report store (populated by `branchpy report --save`).
        local_analyze_dir = Path(project_path).resolve() / ".branchpy" / "analyze"
        local_reports: list[dict] = []
        if local_analyze_dir.exists():
            for f in local_analyze_dir.iterdir():
                if (
                    f.is_file()
                    and f.name.startswith("analyze-")
                    and f.suffix == ".json"
                    and f.name != "analyze.json"
                ):
                    try:
                        local_reports.append(
                            {"path": str(f), "mtime": f.stat().st_mtime}
                        )
                    except Exception:
                        pass
            local_reports.sort(key=lambda x: x["mtime"], reverse=True)

        all_reports = local_reports if local_reports else list_reports(project_path)
        if not all_reports:
            raise FileNotFoundError(f"No reports found for project {project_path}")

        if source in ("last", "latest"):
            index = 0
        elif source.startswith("last-"):
            try:
                offset = int(source[5:])  # "last-1" -> 1
                index = offset
            except ValueError:
                raise ValueError(f"Invalid last offset: {source}")
        elif source.isdigit():
            index = int(source)
        else:
            raise ValueError(f"Invalid source: {source}")

        if index >= len(all_reports):
            raise FileNotFoundError(
                f"Report index {index} not found (only {len(all_reports)} reports available)"
            )

        resolved_path = all_reports[index]["path"]
        return load_json(resolved_path), str(resolved_path)

    # File path
    report_path = Path(source).resolve()
    if not report_path.exists():
        raise FileNotFoundError(f"Report file not found: {source}")

    return load_json(report_path), str(report_path)


def _rotate_reports(reports_dir: Path, max_reports: int = 50) -> None:
    """Remove old reports, keeping only the most recent max_reports."""
    report_files = []

    for report_file in reports_dir.glob("*.json"):
        try:
            stat = report_file.stat()
            report_files.append((report_file, stat.st_mtime))
        except Exception:
            continue

    # Sort by modification time, newest first
    report_files.sort(key=lambda x: x[1], reverse=True)

    # Remove excess files
    for report_file, _ in report_files[max_reports:]:
        try:
            report_file.unlink()
        except Exception:
            pass


def get_report_summary(project_path: Union[str, Path]) -> Dict[str, Any]:
    """Get a summary of reports for a project."""
    reports = list_reports(project_path)
    reports_dir = get_reports_dir(project_path)

    total_size = sum(report["size"] for report in reports)

    return {
        "project_path": str(Path(project_path).resolve()),
        "project_key": _project_key(project_path),
        "reports_dir": str(reports_dir),
        "total_reports": len(reports),
        "total_size_bytes": total_size,
        "latest_report": reports[0] if reports else None,
        "oldest_report": reports[-1] if reports else None,
    }
