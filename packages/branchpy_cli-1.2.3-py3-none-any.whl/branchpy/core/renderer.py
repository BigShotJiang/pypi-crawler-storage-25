"""
branchpy/core/renderer.py
Minimal Jinja2-based HTML renderer for BranchPy reports.
Part of v0.6.68 — HTML Renderer Foundation.
"""

from __future__ import annotations

import datetime
import json
from pathlib import Path
from typing import Any, Dict, Optional

# Jinja2 is a required dependency (see pyproject.toml)
from jinja2 import Environment, FileSystemLoader, select_autoescape

DEFAULT_TEMPLATES = Path(__file__).resolve().parent.parent.parent / "templates"


def _get_loader(project_root: Optional[Path]) -> FileSystemLoader:
    """Return a loader that prefers project-local templates if present."""
    search = []
    if project_root:
        proj_templates = project_root / "templates"
        if proj_templates.is_dir():
            search.append(str(proj_templates))
    search.append(str(DEFAULT_TEMPLATES))
    return FileSystemLoader(search)


def _default_context() -> Dict[str, Any]:
    """Base context used by all reports."""
    now = datetime.datetime.now().astimezone()
    return {
        "version": "0.6.68",
        "generated_at": now.isoformat(),
        "project": {"name": "Unnamed Project"},
        "engine": {"name": "renpy", "version": "8.x"},
        "report": {"type": "analyze", "hash": None, "mode": "full"},
        "flags": {"debug_cfg": False},
        "stats": {
            "files_total": 0,
            "labels_total": 0,
            "issues_total": 0,
            "warnings_total": 0,
            "errors_total": 0,
        },
        "issues": [],
        "actions": {},
        "extras": [],
        "links": {},
    }


def render_report(
    project_root: Optional[str] = None,
    report_type: str = "analyze",
    context: Optional[Dict[str, Any]] = None,
    outfile: Optional[Path] = None,
) -> str:
    """
    Render a report.html template with the given context.

    Parameters
    ----------
    project_root : str | None
        Project directory to look for templates in.
    report_type : str
        analyze | compare | stats
    context : dict | None
        Extra data to merge into default context.
    outfile : Path | None
        If provided, write the rendered HTML here.
    """
    base = _default_context()
    if context:
        # Merge recursively (simple shallow merge is enough for now)
        for k, v in context.items():
            if isinstance(v, dict) and k in base:
                base[k].update(v)
            else:
                base[k] = v
    base["report"]["type"] = report_type

    env = Environment(
        loader=_get_loader(Path(project_root) if project_root else None),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )

    tpl = env.get_template("report.html")
    html = tpl.render(**base)

    if outfile:
        outfile.parent.mkdir(parents=True, exist_ok=True)
        outfile.write_text(html, encoding="utf-8")
    return html


def render_to_json(context: Dict[str, Any], outfile: Path):
    """Helper to dump a JSON version of the report for export."""
    outfile.parent.mkdir(parents=True, exist_ok=True)
    outfile.write_text(
        json.dumps(context, indent=2, ensure_ascii=False), encoding="utf-8"
    )


# Legacy compatibility functions (preserve existing API)
def _ensure_reports_dir(project_root: Path) -> Path:
    """Legacy helper for backward compatibility."""
    reports_dir = project_root / ".branchpy" / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    return reports_dir


def render_html_report(
    *,
    project_root: str | Path,
    data: Any,
    title: str,
    kind: str = "report",
    version: str = "0.6.68",
) -> str:
    """
    Legacy HTML report renderer for backward compatibility.
    Wraps the new Jinja2-based renderer.
    """
    root = Path(project_root).resolve()
    out_dir = _ensure_reports_dir(root)

    # Convert legacy data format to new context
    context = {
        "project": {"name": root.name, "root": str(root)},
        "report": {"type": kind},
        "version": version,
    }

    # Handle different data types
    if isinstance(data, dict):
        context.update(data)
    elif data is not None:
        context["extras"] = [{"title": title, "html": str(data)}]

    # Generate filename and render
    import time

    fname = f"{kind}-{int(time.time())}.html"
    out_path = out_dir / fname

    render_report(
        project_root=str(root), report_type=kind, context=context, outfile=out_path
    )

    return str(out_path)


if __name__ == "__main__":
    # Manual test: render a demo report under ./reports/demo.html
    out = Path(__file__).resolve().parent.parent / "reports/demo.html"
    html = render_report(outfile=out)
    print(f"[BranchPy] Rendered demo report → {out}")
