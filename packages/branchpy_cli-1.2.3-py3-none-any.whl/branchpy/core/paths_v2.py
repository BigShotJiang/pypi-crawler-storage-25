"""
Cross-platform path resolution for BranchPy.

Follows OS-specific conventions:
- Windows: %LOCALAPPDATA%, %APPDATA%, %TEMP%
- macOS: ~/Library/Application Support, ~/Library/Caches, etc.
- Linux: XDG Base Directory specification

Key principle: NO temp/cache files inside user-synced folders.
"""

from __future__ import annotations

import os
import platform
import tempfile
from pathlib import Path
from typing import Optional

__all__ = [
    "BranchPyPaths",
    "get_base_dir",
    "get_cache_dir",
    "get_temp_dir",
    "get_logs_dir",
    "get_config_dir",
    "get_project_branchpy_dir",
    "get_project_reports_dir",
    "ensure_dir",
]


def ensure_dir(path: Path) -> Path:
    """
    Ensure directory exists, creating it if necessary.

    Args:
        path: Directory path to ensure

    Returns:
        Same path (for chaining)

    Example:
        >>> log_file = ensure_dir(get_logs_dir()) / "commands.jsonl"
    """
    path.mkdir(parents=True, exist_ok=True)
    return path


class BranchPyPaths:
    """
    Cross-platform path resolver for BranchPy.

    Usage:
        >>> paths = BranchPyPaths()
        >>> cache = paths.get_cache_dir()
        >>> temp = paths.get_temp_dir()
        >>> logs = paths.get_logs_dir()

    Environment Variables (optional overrides):
        BRANCHPY_BASE_DIR    - Base directory for all BranchPy data
        BRANCHPY_CACHE_DIR   - Cache directory
        BRANCHPY_TEMP_DIR    - Temporary files directory
        BRANCHPY_LOGS_DIR    - Logs directory
        BRANCHPY_CONFIG_DIR  - Configuration directory
    """

    # Environment variable names
    ENV_BASE = "BRANCHPY_BASE_DIR"
    ENV_CACHE = "BRANCHPY_CACHE_DIR"
    ENV_TEMP = "BRANCHPY_TEMP_DIR"
    ENV_CONFIG = "BRANCHPY_CONFIG_DIR"
    ENV_LOGS = "BRANCHPY_LOGS_DIR"

    # Per-session identifier for temp dirs
    _session_id: Optional[str] = None

    @staticmethod
    def get_base_dir() -> Path:
        """
        Get BranchPy base directory (outside sync folders).

        Returns:
            Windows: %LOCALAPPDATA%\\BranchPy
            macOS:   ~/Library/Application Support/BranchPy
            Linux:   ~/.local/share/BranchPy (or $XDG_DATA_HOME/BranchPy)

        Environment Override: BRANCHPY_BASE_DIR
        """
        override = os.getenv(BranchPyPaths.ENV_BASE)
        if override:
            return Path(override)

        system = platform.system()

        if system == "Windows":
            # %LOCALAPPDATA%\BranchPy (NOT in Documents/OneDrive)
            base = os.getenv("LOCALAPPDATA")
            if not base:
                base = Path.home() / "AppData" / "Local"
            return Path(base) / "BranchPy"

        elif system == "Darwin":  # macOS
            # ~/Library/Application Support/BranchPy
            return Path.home() / "Library" / "Application Support" / "BranchPy"

        else:  # Linux, BSD, etc.
            # Follow XDG Base Directory spec
            xdg_data = os.getenv("XDG_DATA_HOME")
            if xdg_data:
                return Path(xdg_data) / "BranchPy"
            return Path.home() / ".local" / "share" / "BranchPy"

    @staticmethod
    def get_cache_dir() -> Path:
        """
        Get cache directory (ephemeral, safe to delete).

        Returns:
            Windows: %LOCALAPPDATA%\\BranchPy\\cache
            macOS:   ~/Library/Caches/BranchPy
            Linux:   ~/.cache/BranchPy (or $XDG_CACHE_HOME/BranchPy)

        Environment Override: BRANCHPY_CACHE_DIR
        """
        override = os.getenv(BranchPyPaths.ENV_CACHE)
        if override:
            return Path(override)

        system = platform.system()

        if system == "Windows":
            return BranchPyPaths.get_base_dir() / "cache"

        elif system == "Darwin":
            return Path.home() / "Library" / "Caches" / "BranchPy"

        else:
            xdg_cache = os.getenv("XDG_CACHE_HOME")
            if xdg_cache:
                return Path(xdg_cache) / "BranchPy"
            return Path.home() / ".cache" / "BranchPy"

    @staticmethod
    def get_temp_dir() -> Path:
        """
        Get temporary directory (auto-cleanup on session end).

        Returns:
            System temp directory + BranchPy subfolder
            Windows: %TEMP%\\BranchPy
            macOS:   /tmp/BranchPy
            Linux:   /tmp/BranchPy

        Environment Override: BRANCHPY_TEMP_DIR

        Note:
            Files here may be deleted by OS cleanup routines.
            Use for truly temporary data only.
            For session-specific isolation, use get_session_temp_dir().
        """
        override = os.getenv(BranchPyPaths.ENV_TEMP)
        if override:
            return Path(override)

        # Use system temp (outside user folders, outside sync)
        system_temp = Path(tempfile.gettempdir())
        return system_temp / "BranchPy"

    @staticmethod
    def get_logs_dir() -> Path:
        """
        Get logs directory (persistent).

        Returns:
            Windows: %LOCALAPPDATA%\\BranchPy\\logs
            macOS:   ~/Library/Logs/BranchPy
            Linux:   ~/.local/state/BranchPy/logs (or $XDG_STATE_HOME/BranchPy/logs)

        Environment Override: BRANCHPY_LOGS_DIR
        """
        override = os.getenv(BranchPyPaths.ENV_LOGS)
        if override:
            return Path(override)

        system = platform.system()

        if system == "Windows":
            return BranchPyPaths.get_base_dir() / "logs"

        elif system == "Darwin":
            return Path.home() / "Library" / "Logs" / "BranchPy"

        else:
            xdg_state = os.getenv("XDG_STATE_HOME")
            if xdg_state:
                return Path(xdg_state) / "BranchPy" / "logs"
            return Path.home() / ".local" / "state" / "BranchPy" / "logs"

    @staticmethod
    def get_config_dir() -> Path:
        """
        Get config directory (persistent user settings).

        Returns:
            Windows: %APPDATA%\\BranchPy (separate from base_dir for roaming settings)
            macOS:   ~/Library/Application Support/BranchPy (same as base_dir)
            Linux:   ~/.config/BranchPy (separate from base_dir)

        Environment Override: BRANCHPY_CONFIG_DIR

        Note:
            On macOS, config_dir coincides with base_dir by OS convention.
            On Windows/Linux, they are separate to follow OS standards.
        """
        override = os.getenv(BranchPyPaths.ENV_CONFIG)
        if override:
            return Path(override)

        system = platform.system()

        if system == "Windows":
            # %APPDATA%\BranchPy (for roaming settings, separate from LOCALAPPDATA)
            appdata = os.getenv("APPDATA")
            if not appdata:
                appdata = Path.home() / "AppData" / "Roaming"
            return Path(appdata) / "BranchPy"

        elif system == "Darwin":
            # macOS: config and base_dir both use Application Support
            return Path.home() / "Library" / "Application Support" / "BranchPy"

        else:
            # Linux: separate config dir per XDG spec
            xdg_config = os.getenv("XDG_CONFIG_HOME")
            if xdg_config:
                return Path(xdg_config) / "BranchPy"
            return Path.home() / ".config" / "BranchPy"

    @staticmethod
    def get_project_branchpy_dir(project_root: Path | str) -> Path:
        """
        Get project-local .branchpy directory.

        Args:
            project_root: Path to project root directory

        Returns:
            {project_root}/.branchpy/

        Note:
            This is for reports and user content ONLY.
            NO temp or cache files should go here (use get_cache_dir() instead).
        """
        return Path(project_root) / ".branchpy"

    @staticmethod
    def get_project_reports_dir(project_root: Path | str, report_type: str) -> Path:
        """
        Get project-local reports directory for specific report type.

        Args:
            project_root: Path to project root directory
            report_type: Type of report (e.g., 'analyze', 'stats', 'compare')

        Returns:
            {project_root}/.branchpy/{report_type}/

        Example:
            >>> get_project_reports_dir("/path/to/project", "analyze")
            Path("/path/to/project/.branchpy/analyze")
        """
        return BranchPyPaths.get_project_branchpy_dir(project_root) / report_type

    @staticmethod
    def ensure_directories() -> dict[str, Path]:
        """
        Create all required BranchPy directories.

        Returns:
            Dictionary mapping directory names to their paths

        Example:
            >>> dirs = BranchPyPaths.ensure_directories()
            >>> print(dirs['cache'])
            WindowsPath('C:/Users/User/AppData/Local/BranchPy/cache')
        """
        dirs = {
            "base": BranchPyPaths.get_base_dir(),
            "cache": BranchPyPaths.get_cache_dir(),
            "temp": BranchPyPaths.get_temp_dir(),
            "logs": BranchPyPaths.get_logs_dir(),
            "config": BranchPyPaths.get_config_dir(),
        }

        for name, path in dirs.items():
            path.mkdir(parents=True, exist_ok=True)

        return dirs

    @staticmethod
    def get_session_temp_dir(session_id: Optional[str] = None) -> Path:
        """
        Get temporary directory for a specific session.

        Args:
            session_id: Optional session identifier (auto-generated if None)

        Returns:
            {temp_dir}/{session_id}/

        Example:
            >>> temp = BranchPyPaths.get_session_temp_dir("analysis-20251210-150430")
            >>> ensure_dir(temp)
            >>> scratch_file = temp / "cfg_temp.dot"

        Note:
            If no session_id provided, uses a per-process session ID that persists
            for the lifetime of the Python process.
        """
        if session_id is None:
            # Use per-process session ID
            if BranchPyPaths._session_id is None:
                import uuid

                BranchPyPaths._session_id = uuid.uuid4().hex[:12]
            session_id = BranchPyPaths._session_id

        return BranchPyPaths.get_temp_dir() / session_id


# Convenience functions (backward compatibility)


def get_base_dir() -> Path:
    """Get BranchPy base directory."""
    return BranchPyPaths.get_base_dir()


def get_cache_dir() -> Path:
    """Get cache directory."""
    return BranchPyPaths.get_cache_dir()


def get_temp_dir() -> Path:
    """Get temporary directory."""
    return BranchPyPaths.get_temp_dir()


def get_logs_dir() -> Path:
    """Get logs directory."""
    return BranchPyPaths.get_logs_dir()


def get_config_dir() -> Path:
    """Get config directory."""
    return BranchPyPaths.get_config_dir()


def get_project_branchpy_dir(project_root: Path | str) -> Path:
    """Get project-local .branchpy directory."""
    return BranchPyPaths.get_project_branchpy_dir(project_root)


def get_project_reports_dir(project_root: Path | str, report_type: str) -> Path:
    """Get project-local reports directory."""
    return BranchPyPaths.get_project_reports_dir(project_root, report_type)


# Auto-initialize on import
_dirs = BranchPyPaths.ensure_directories()
