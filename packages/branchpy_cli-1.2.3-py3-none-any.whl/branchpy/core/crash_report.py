from __future__ import annotations

import traceback
from datetime import datetime

from .paths import LOGS


def write_crash(exc: BaseException):
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    path = LOGS / f"crash_{stamp}.log"
    with path.open("w", encoding="utf-8") as f:
        f.write("BranchPy crash report\n\n")
        traceback.print_exc(file=f)
    return path
