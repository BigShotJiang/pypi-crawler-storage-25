"""Core Semantics Module - v0.9.9

Provides semantic layer above CFG/AST for BranchPy analysis.

This module defines canonical semantic actions (JUMP, CALL, SET, etc.) and provides
interfaces for mapping custom functions and language constructs to these actions.

New in v0.9.9: Unified Function Manager with split schema
- registry.py: Auto-discovered function catalog (registry-v1)
- definitions.py: User-defined semantic effects (semantics-v1)
- migration.py: OLD to NEW schema migration tool
"""

from .definitions import (
    OperationType,
    SemanticDefinition,
    SemanticDefinitions,
    SemanticEffect,
)
from .function_provider import (
    DefaultFunctionProvider,
    FunctionProvider,
    FunctionSemantics,
)
from .migration import SchemaMigration
from .registry import DiscoveredFunction, FunctionRegistry
from .semantic_action import SemanticAction, SemanticActionType
from .semantic_node import SemanticNode
from .trace_exporter import SemanticTraceExporter

__all__ = [
    "SemanticAction",
    "SemanticActionType",
    "SemanticNode",
    "FunctionProvider",
    "FunctionSemantics",
    "DefaultFunctionProvider",
    "SemanticTraceExporter",
    # New in v0.9.9
    "FunctionRegistry",
    "DiscoveredFunction",
    "SemanticDefinitions",
    "SemanticDefinition",
    "SemanticEffect",
    "OperationType",
    "SchemaMigration",
]

__version__ = "0.9.9"
