"""Semantic Trace Exporter - v0.8.7

Exports semantic analysis results to JSONL format for governance and stats engines.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, TextIO


class SemanticTraceExporter:
    """Exports semantic traces to JSONL format.

    Generates correlation-ID-linked trace files for downstream analysis
    by governance and statistics engines.
    """

    def __init__(self, output_dir: str | Path):
        """Initialize exporter with output directory.

        Args:
            output_dir: Directory to write trace files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.correlation_id = str(uuid.uuid4())
        self.timestamp = datetime.now().isoformat()

    def export_cfg_semantics(
        self,
        cfg_dict: Dict[str, Any],
        project_path: str,
        filename: str = "semantic_trace.jsonl",
    ) -> Path:
        """Export semantic actions from CFG to JSONL trace.

        Args:
            cfg_dict: CFG dictionary with semantic annotations
            project_path: Path to project root
            filename: Output filename

        Returns:
            Path to created trace file
        """
        output_path = self.output_dir / filename

        with open(output_path, "w", encoding="utf-8") as f:
            # Write header record
            self._write_header(f, project_path)

            # Process nodes
            for node in cfg_dict.get("nodes", []):
                node_id = node.get("id")
                actions = node.get("semantic_actions", [])

                for action in actions:
                    self._write_action_record(f, node_id, action, "node")

            # Process edges
            for edge in cfg_dict.get("edges", []):
                semantic = edge.get("semantic")
                if semantic:
                    edge_id = f"{edge['src']} -> {edge['dst']}"
                    self._write_action_record(f, edge_id, semantic, "edge")

            # Write footer
            self._write_footer(f)

        return output_path

    def export_node_trace(
        self,
        nodes: List[Dict[str, Any]],
        project_path: str,
        filename: str = "node_trace.jsonl",
    ) -> Path:
        """Export semantic node traces to JSONL.

        Args:
            nodes: List of semantic node dictionaries
            project_path: Path to project root
            filename: Output filename

        Returns:
            Path to created trace file
        """
        output_path = self.output_dir / filename

        with open(output_path, "w", encoding="utf-8") as f:
            self._write_header(f, project_path)

            for node in nodes:
                record = {
                    "type": "node",
                    "correlation_id": self.correlation_id,
                    "timestamp": self.timestamp,
                    "node_id": node.get("node_id"),
                    "file": node.get("file"),
                    "line": node.get("line"),
                    "kind": node.get("kind", "statement"),
                    "actions": node.get("actions", []),
                    "metadata": node.get("metadata", {}),
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

            self._write_footer(f)

        return output_path

    def _write_header(self, f: TextIO, project_path: str) -> None:
        """Write JSONL header record."""
        header = {
            "type": "header",
            "version": "0.8.7",
            "correlation_id": self.correlation_id,
            "timestamp": self.timestamp,
            "project": str(Path(project_path).resolve()),
            "exporter": "SemanticTraceExporter",
        }
        f.write(json.dumps(header, ensure_ascii=False) + "\n")

    def _write_action_record(
        self,
        f: TextIO,
        location_id: str,
        action: Dict[str, Any],
        location_type: str,
    ) -> None:
        """Write a semantic action record."""
        record = {
            "type": "semantic_action",
            "correlation_id": self.correlation_id,
            "timestamp": self.timestamp,
            "location_type": location_type,
            "location_id": location_id,
            "action_type": action.get("action_type"),
            "target": action.get("target"),
            "value": action.get("value"),
            "scope": action.get("scope", "local"),
            "confidence": action.get("confidence", "high"),
            "metadata": action.get("metadata", {}),
        }
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def _write_footer(self, f: TextIO) -> None:
        """Write JSONL footer record."""
        footer = {
            "type": "footer",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.now().isoformat(),
        }
        f.write(json.dumps(footer, ensure_ascii=False) + "\n")

    @staticmethod
    def read_trace(trace_file: str | Path) -> List[Dict[str, Any]]:
        """Read JSONL trace file.

        Args:
            trace_file: Path to trace file

        Returns:
            List of records from trace
        """
        records = []
        with open(trace_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))
        return records

    @staticmethod
    def filter_by_type(
        records: List[Dict[str, Any]],
        record_type: str,
    ) -> List[Dict[str, Any]]:
        """Filter records by type.

        Args:
            records: List of records
            record_type: Type to filter for

        Returns:
            Filtered list of records
        """
        return [r for r in records if r.get("type") == record_type]
