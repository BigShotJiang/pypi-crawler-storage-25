"""Semantic Definitions - User-defined function effects

This module provides the NEW schema for semantic definitions (with effects).
Semantic definitions teach BranchPy how custom functions affect control flow.

Schema: semantics-v1 (NEW format - with effects)
File: .branchpy/semantics.yaml
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from branchpy import logs


class OperationType(str, Enum):
    """Supported semantic operation types"""

    JUMP = "jump"
    CALL = "call"
    ASSIGN = "assign"
    TOGGLE = "toggle"


@dataclass
class SemanticEffect:
    """A single semantic effect (operation)"""

    op: OperationType
    args: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for YAML serialization"""
        return {"op": self.op.value, "args": self.args}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SemanticEffect:
        """Load from dictionary"""
        return cls(op=OperationType(data["op"]), args=data.get("args", {}))

    def validate_placeholders(self, allowed_args: List[str]) -> List[str]:
        """Validate that placeholders reference valid arguments

        Returns list of validation errors (empty if valid)
        """
        errors = []

        def check_value(value: Any, path: str = "") -> None:
            if isinstance(value, str):
                # Extract {placeholder} patterns
                import re

                placeholders = re.findall(r"\{(\w+)\}", value)
                for placeholder in placeholders:
                    if placeholder not in allowed_args:
                        errors.append(
                            f"Placeholder '{{{placeholder}}}' at {path} not in args {allowed_args}"
                        )
            elif isinstance(value, dict):
                for k, v in value.items():
                    check_value(v, f"{path}.{k}" if path else k)
            elif isinstance(value, list):
                for i, v in enumerate(value):
                    check_value(v, f"{path}[{i}]")

        check_value(self.args)
        return errors


@dataclass
class SemanticDefinition:
    """Semantic definition for a custom function"""

    name: str
    args: List[str] = field(default_factory=list)
    effects: List[SemanticEffect] = field(default_factory=list)

    # Optional metadata
    source: Optional[str] = None
    line: Optional[int] = None
    confidence: Optional[str] = None  # high, medium, low
    auto_detected: bool = False
    category: Optional[str] = None  # Navigation, State, Flags, etc.

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for YAML serialization"""
        result = {
            "name": self.name,
            "args": self.args,
            "effects": [effect.to_dict() for effect in self.effects],
        }

        # Add optional metadata if present
        if self.source:
            result["source"] = self.source
        if self.line is not None:
            result["line"] = self.line
        if self.confidence:
            result["confidence"] = self.confidence
        if self.auto_detected:
            result["auto_detected"] = self.auto_detected
        if self.category:
            result["category"] = self.category

        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SemanticDefinition:
        """Load from dictionary"""
        effects_data = data.get("effects", [])
        effects = [SemanticEffect.from_dict(e) for e in effects_data]

        return cls(
            name=data["name"],
            args=data.get("args", []),
            effects=effects,
            source=data.get("source"),
            line=data.get("line"),
            confidence=data.get("confidence"),
            auto_detected=data.get("auto_detected", False),
            category=data.get("category"),
        )

    def validate(self) -> List[str]:
        """Validate semantic definition

        Returns list of validation errors (empty if valid)
        """
        errors = []

        # Check required fields
        if not self.name:
            errors.append("Function name is required")

        if not self.effects:
            errors.append(f"{self.name}: No effects defined")

        # Validate each effect's placeholders
        for effect in self.effects:
            effect_errors = effect.validate_placeholders(self.args)
            errors.extend([f"{self.name}: {err}" for err in effect_errors])

        return errors


@dataclass
class SemanticDefinitions:
    """Collection of semantic definitions for a project"""

    schema_version: str = "semantics-v1"
    meta: Dict[str, Any] = field(default_factory=dict)
    functions: List[SemanticDefinition] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for YAML serialization"""
        return {
            "schema_version": self.schema_version,
            "meta": self.meta,
            "functions": [func.to_dict() for func in self.functions],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SemanticDefinitions:
        """Load from dictionary"""
        definitions = cls()
        definitions.schema_version = data.get("schema_version", "semantics-v1")
        definitions.meta = data.get("meta", {})

        functions_data = data.get("functions", [])
        definitions.functions = [
            SemanticDefinition.from_dict(f) for f in functions_data
        ]

        return definitions

    def save(self, path: Path) -> None:
        """Save definitions to YAML file"""
        path.parent.mkdir(parents=True, exist_ok=True)

        # Update metadata
        self.meta["last_updated"] = (
            datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        )
        if "created_with" not in self.meta:
            # Use placeholder version - can be updated by caller if needed
            self.meta["created_with"] = "branchpy 0.9.9"

        with open(path, "w", encoding="utf-8") as f:
            f.write("# Semantic definitions for custom functions\n")
            f.write("# Teaches BranchPy how custom functions affect control flow\n\n")
            yaml.safe_dump(self.to_dict(), f, default_flow_style=False, sort_keys=False)

        logs.info(
            "semantics.definitions.saved",
            f"Saved semantic definitions: {len(self.functions)} functions",
            path=str(path),
            function_count=len(self.functions),
        )

    @classmethod
    def load(cls, path: Path) -> SemanticDefinitions:
        """Load definitions from YAML file"""
        if not path.exists():
            logs.info(
                "semantics.definitions.not_found",
                "Semantic definitions file not found (creating new)",
                path=str(path),
            )
            return cls()

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not data:
                logs.warn(
                    "semantics.definitions.empty",
                    "Semantic definitions file is empty",
                    path=str(path),
                )
                return cls()

            definitions = cls.from_dict(data)

            logs.info(
                "semantics.definitions.loaded",
                f"Loaded semantic definitions: {len(definitions.functions)} functions",
                path=str(path),
                function_count=len(definitions.functions),
            )

            return definitions

        except yaml.YAMLError as e:
            logs.error(
                "semantics.definitions.yaml_error",
                f"Failed to parse definitions YAML: {e}",
                path=str(path),
                error=str(e),
            )
            return cls()
        except Exception as e:
            logs.error(
                "semantics.definitions.load_error",
                f"Failed to load definitions: {e}",
                path=str(path),
                error=str(e),
            )
            return cls()

    def validate_all(self) -> Dict[str, List[str]]:
        """Validate all semantic definitions

        Returns dict mapping function names to their validation errors
        """
        results = {}
        for func in self.functions:
            errors = func.validate()
            if errors:
                results[func.name] = errors

        return results

    def get_function(self, name: str) -> Optional[SemanticDefinition]:
        """Get semantic definition by function name"""
        for func in self.functions:
            if func.name == name:
                return func
        return None

    def upsert_function(self, definition: SemanticDefinition) -> None:
        """Insert or update a semantic definition"""
        # Remove existing definition with same name
        self.functions = [f for f in self.functions if f.name != definition.name]
        # Add new definition
        self.functions.append(definition)

        logs.info(
            "semantics.definitions.upserted",
            f"Upserted semantic definition: {definition.name}",
            function_name=definition.name,
            op_count=len(definition.effects),
        )

    def remove_function(self, name: str) -> bool:
        """Remove a semantic definition by name

        Returns True if removed, False if not found
        """
        original_count = len(self.functions)
        self.functions = [f for f in self.functions if f.name != name]
        removed = len(self.functions) < original_count

        if removed:
            logs.info(
                "semantics.definitions.removed",
                f"Removed semantic definition: {name}",
                function_name=name,
            )

        return removed

    def get_function_names(self) -> List[str]:
        """Get list of all defined function names"""
        return [f.name for f in self.functions]

    def find_orphaned(self, registry_functions: List[str]) -> List[str]:
        """Find semantic definitions for functions that no longer exist

        Args:
            registry_functions: List of function names from discovery registry

        Returns list of orphaned function names
        """
        registry_set = set(registry_functions)
        orphaned = []

        for func in self.functions:
            if func.name not in registry_set:
                orphaned.append(func.name)

        if orphaned:
            logs.warn(
                "semantics.definitions.orphaned",
                f"Found {len(orphaned)} orphaned definitions",
                orphaned_count=len(orphaned),
                orphaned=orphaned[:5],
            )

        return orphaned
