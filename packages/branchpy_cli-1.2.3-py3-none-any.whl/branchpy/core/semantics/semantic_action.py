"""Semantic Action Types - Core abstraction layer

Defines canonical semantic action types that represent high-level operations
independent of specific language syntax.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class SemanticActionType(Enum):
    """Canonical semantic action types for BranchPy analysis.

    These represent high-level operations that can be performed in
    branching narratives, independent of the specific engine syntax.
    """

    # Control flow actions
    JUMP = "jump"  # Unconditional jump to a label/scene
    CALL = "call"  # Call to a label/function with return
    RETURN = "return"  # Return from a call
    GUARD = "guard"  # Conditional check (if/while/menu condition)

    # State modification actions
    SET = "set"  # Variable assignment/mutation
    ASSIGN = "assign"  # Alias for SET (for clarity in some contexts)

    # Input/Output actions
    IO = "io"  # Display text, images, audio, user input

    # Future extensions (reserved)
    YIELD = "yield"  # Coroutine yield (future use)
    IMPORT = "import"  # Module/resource import (future use)
    DEFINE = "define"  # Symbol definition (future use)

    # Meta actions
    UNKNOWN = "unknown"  # Unknown or unclassified action


@dataclass
class SemanticAction:
    """Represents a single semantic action with metadata.

    This is the core unit of semantic analysis - each action represents
    a meaningful operation in the narrative that can be tracked through
    the control flow graph.
    """

    action_type: SemanticActionType
    """Type of semantic action"""

    target: Optional[str] = None
    """Target of the action (e.g., label name for JUMP, variable name for SET)"""

    value: Optional[Any] = None
    """Value associated with the action (e.g., assigned value, condition expression)"""

    scope: str = "local"
    """Scope of the action: 'local', 'global', 'persistent'"""

    confidence: str = "high"
    """Confidence level: 'high', 'medium', 'low'"""

    metadata: Dict[str, Any] = field(default_factory=dict)
    """Additional metadata about the action"""

    def __post_init__(self):
        """Validate and normalize action data."""
        if isinstance(self.action_type, str):
            self.action_type = SemanticActionType(self.action_type)

    def to_dict(self) -> Dict[str, Any]:
        """Export action as dictionary for serialization."""
        return {
            "action_type": self.action_type.value,
            "target": self.target,
            "value": self.value,
            "scope": self.scope,
            "confidence": self.confidence,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SemanticAction:
        """Create action from dictionary."""
        return cls(
            action_type=SemanticActionType(data["action_type"]),
            target=data.get("target"),
            value=data.get("value"),
            scope=data.get("scope", "local"),
            confidence=data.get("confidence", "high"),
            metadata=data.get("metadata", {}),
        )

    def is_control_flow(self) -> bool:
        """Check if this action affects control flow."""
        return self.action_type in {
            SemanticActionType.JUMP,
            SemanticActionType.CALL,
            SemanticActionType.RETURN,
            SemanticActionType.GUARD,
        }

    def is_state_change(self) -> bool:
        """Check if this action modifies state."""
        return self.action_type in {
            SemanticActionType.SET,
            SemanticActionType.ASSIGN,
        }

    def is_observable(self) -> bool:
        """Check if this action produces observable effects (I/O)."""
        return self.action_type == SemanticActionType.IO

    def __repr__(self) -> str:
        """String representation for debugging."""
        parts = [f"{self.action_type.value}"]
        if self.target:
            parts.append(f"target={self.target}")
        if self.value is not None:
            value_str = str(self.value)
            if len(value_str) > 30:
                value_str = value_str[:27] + "..."
            parts.append(f"value={value_str}")
        if self.confidence != "high":
            parts.append(f"confidence={self.confidence}")
        return f"SemanticAction({', '.join(parts)})"
