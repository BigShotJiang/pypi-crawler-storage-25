"""Schema Migration Tool - Convert OLD to NEW semantics format

This module handles migration from the OLD semantics.yaml format (mixed registry+definitions)
to the NEW split format:
- .branchpy/discovered/functions.yaml (registry - metadata only)
- .branchpy/semantics.yaml (definitions - with effects)

Migration Strategy:
1. Detect OLD format (no schema_version or old structure)
2. Create backup of OLD file
3. Extract registry data → discovered/functions.yaml
4. Convert semantic definitions → semantics.yaml
5. Log migration event for telemetry
"""

from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

import yaml

from branchpy import logs

from .definitions import (
    OperationType,
    SemanticDefinition,
    SemanticDefinitions,
    SemanticEffect,
)
from .registry import DiscoveredFunction, FunctionRegistry


class SchemaMigration:
    """Handles schema migration from OLD to NEW format"""

    @staticmethod
    def detect_old_format(semantics_path: Path) -> bool:
        """Check if file uses OLD schema format

        OLD format indicators:
        - Missing schema_version field
        - Has 'variables' section at top level
        - Has 'functions' as dict (not list)
        - Functions have 'is_jump_helper' field
        """
        if not semantics_path.exists():
            return False

        try:
            with open(semantics_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not data:
                return False

            # Check for NEW format indicators
            if "schema_version" in data:
                schema_version = data["schema_version"]
                if schema_version in ["semantics-v1", "registry-v1"]:
                    return False  # Already new format

            # Check for OLD format indicators
            if "variables" in data:
                return True  # OLD format has variables section

            if "functions" in data:
                functions = data["functions"]
                if isinstance(functions, dict):
                    # OLD format has functions as dict
                    return True
                if isinstance(functions, list) and len(functions) > 0:
                    # Check first function for OLD format fields
                    first_func = functions[0]
                    if "is_jump_helper" in first_func:
                        return True

            # Default to NEW format if uncertain
            return False

        except Exception as e:
            logs.error(
                "semantics.migration.detect_error",
                f"Failed to detect schema format: {e}",
                path=str(semantics_path),
                error=str(e),
            )
            return False

    @staticmethod
    def migrate_to_new_format(
        old_semantics_path: Path, project_root: Path, backup: bool = True
    ) -> Tuple[bool, str]:
        """Migrate OLD format to NEW split format

        Args:
            old_semantics_path: Path to OLD semantics.yaml
            project_root: Project root directory
            backup: Whether to create backup of OLD file

        Returns:
            Tuple of (success: bool, message: str)
        """
        if not old_semantics_path.exists():
            return False, "OLD semantics file not found"

        try:
            # Load OLD format
            with open(old_semantics_path, "r", encoding="utf-8") as f:
                old_data = yaml.safe_load(f)

            if not old_data:
                return False, "OLD semantics file is empty"

            # Create backup if requested
            if backup:
                backup_path = (
                    old_semantics_path.parent
                    / f"semantics.old.{datetime.now().strftime('%Y%m%d_%H%M%S')}.yaml"
                )
                shutil.copy2(old_semantics_path, backup_path)
                logs.info(
                    "semantics.migration.backup_created",
                    f"Created backup: {backup_path.name}",
                    backup_path=str(backup_path),
                )

            # Extract function data
            old_functions = old_data.get("functions", {})

            if not isinstance(old_functions, dict):
                return False, "OLD format has unexpected functions structure"

            # Create registry (discovered functions)
            registry = FunctionRegistry()
            registry.metadata = {
                "generated_at": datetime.now(timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
                "generated_by": "branchpy 0.9.9 (migration)",
                "file_count": old_data.get("metadata", {}).get("file_count", 0),
                "function_count": len(old_functions),
                "migrated_from": str(old_semantics_path.name),
            }

            # Create definitions (semantic effects)
            definitions = SemanticDefinitions()
            definitions.meta = {
                "created_with": "branchpy 0.9.9 (migration)",
                "last_updated": datetime.now(timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
                "migrated_from": str(old_semantics_path.name),
            }

            # Process each function
            migrated_count = 0
            skipped_count = 0

            for name, func_data in old_functions.items():
                if not isinstance(func_data, dict):
                    skipped_count += 1
                    continue

                # Extract metadata for registry
                params_str = func_data.get("params", "")
                params = (
                    [p.strip() for p in params_str.split(",") if p.strip()]
                    if params_str
                    else []
                )

                discovered_func = DiscoveredFunction(
                    name=name,
                    params=params,
                    source=func_data.get("source", ""),
                    line=0,  # Not available in OLD format
                    is_builtin=False,
                    call_count=0,  # Not available in OLD format
                    has_semantics=func_data.get("is_jump_helper", False),
                )
                registry.functions[name] = discovered_func

                # Check if function has semantic behavior in OLD format
                is_jump_helper = func_data.get("is_jump_helper", False)

                if is_jump_helper:
                    # Try to infer operation type from function name
                    op_type = SchemaMigration._infer_operation_type(name, params)

                    # Create semantic definition with best-effort conversion
                    effect = SemanticEffect(
                        op=op_type,
                        args=SchemaMigration._infer_effect_args(op_type, params),
                    )

                    definition = SemanticDefinition(
                        name=name,
                        args=params,
                        effects=[effect],
                        source=func_data.get("source"),
                        confidence="medium",  # Migration is best-effort
                        auto_detected=False,
                        category=SchemaMigration._infer_category(name),
                    )

                    definitions.functions.append(definition)
                    discovered_func.has_semantics = True
                    migrated_count += 1

            # Save to new locations
            registry_path = project_root / ".branchpy" / "discovered" / "functions.yaml"
            definitions_path = project_root / ".branchpy" / "semantics.yaml"

            registry.save(registry_path)
            definitions.save(definitions_path)

            # Log migration event
            logs.info(
                "semantics.migration.completed",
                f"Migration complete: {len(old_functions)} functions, {migrated_count} with semantics",
                total_functions=len(old_functions),
                migrated_semantics=migrated_count,
                skipped=skipped_count,
                registry_path=str(registry_path),
                definitions_path=str(definitions_path),
            )

            message = (
                f"✅ Migration successful!\n"
                f"• Migrated {len(old_functions)} functions\n"
                f"• {migrated_count} functions have semantic definitions\n"
                f"• Registry saved to: {registry_path.relative_to(project_root)}\n"
                f"• Definitions saved to: {definitions_path.relative_to(project_root)}"
            )

            return True, message

        except yaml.YAMLError as e:
            error_msg = f"YAML parse error: {e}"
            logs.error(
                "semantics.migration.yaml_error",
                error_msg,
                path=str(old_semantics_path),
                error=str(e),
            )
            return False, error_msg

        except Exception as e:
            error_msg = f"Migration failed: {e}"
            logs.error(
                "semantics.migration.failed",
                error_msg,
                path=str(old_semantics_path),
                error=str(e),
            )
            return False, error_msg

    @staticmethod
    def _infer_operation_type(func_name: str, params: List[str]) -> OperationType:
        """Infer operation type from function name patterns"""
        name_lower = func_name.lower()

        # Jump patterns
        if any(
            keyword in name_lower for keyword in ["jump", "goto", "navigate", "go_to"]
        ):
            return OperationType.JUMP

        # Call patterns
        if any(keyword in name_lower for keyword in ["call", "show", "display"]):
            return OperationType.CALL

        # Assignment patterns
        if any(
            keyword in name_lower for keyword in ["set", "assign", "update", "init"]
        ):
            return OperationType.ASSIGN

        # Toggle patterns
        if any(
            keyword in name_lower
            for keyword in ["toggle", "flip", "switch", "enable", "disable"]
        ):
            return OperationType.TOGGLE

        # Default to CALL (safest assumption)
        return OperationType.CALL

    @staticmethod
    def _infer_effect_args(op_type: OperationType, params: List[str]) -> Dict[str, str]:
        """Infer effect arguments from operation type and parameters"""
        if not params:
            return {}

        if op_type == OperationType.JUMP:
            # First param is likely the label/target
            return {"label": f"{{{params[0]}}}"}

        elif op_type == OperationType.CALL:
            # First param is likely the label/scene
            return {"label": f"{{{params[0]}}}"}

        elif op_type == OperationType.ASSIGN:
            # First param is likely variable, second is value
            if len(params) >= 2:
                return {"var": f"{{{params[0]}}}", "value": f"{{{params[1]}}}"}
            else:
                return {"var": f"{{{params[0]}}}"}

        elif op_type == OperationType.TOGGLE:
            # First param is likely the boolean variable
            return {"var": f"{{{params[0]}}}"}

        return {}

    @staticmethod
    def _infer_category(func_name: str) -> str:
        """Infer function category from name patterns"""
        name_lower = func_name.lower()

        patterns = {
            "Navigation": ["goto", "jump", "call", "navigate", "show_scene"],
            "State": ["set_", "get_", "update_", "init_", "store_"],
            "Flags": ["toggle", "enable", "disable", "flag_", "unlock_"],
            "UI": ["show_", "hide_", "display_", "render_"],
            "Character": ["say_", "speak_", "dialogue_"],
            "Utility": ["_helper", "_util", "_log", "debug_"],
            "Config": ["config_", "settings_", "option_"],
        }

        for category, keywords in patterns.items():
            if any(kw in name_lower for kw in keywords):
                return category

        return "Other"

    @staticmethod
    def check_migration_needed(project_root: Path) -> Tuple[bool, str]:
        """Check if migration is needed for a project

        Returns:
            Tuple of (migration_needed: bool, reason: str)
        """
        old_path = project_root / ".branchpy" / "semantics.yaml"
        new_registry_path = project_root / ".branchpy" / "discovered" / "functions.yaml"
        new_definitions_path = project_root / ".branchpy" / "semantics.yaml"

        if not old_path.exists():
            return False, "No semantics.yaml file found"

        # Check if NEW format files already exist
        if new_registry_path.exists() and new_definitions_path.exists():
            return False, "Already using NEW format (registry and definitions exist)"

        # Check if OLD format is detected
        if SchemaMigration.detect_old_format(old_path):
            return True, "OLD format detected - migration recommended"

        return False, "Already using NEW format"
