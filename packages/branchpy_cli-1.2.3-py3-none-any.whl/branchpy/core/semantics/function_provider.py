"""Function Provider - Maps custom functions to semantic actions

Provides interface for resolving helper functions and macros to their
underlying semantic meanings.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set

from .semantic_action import SemanticAction, SemanticActionType


@dataclass
class FunctionSemantics:
    """Semantic definition of a function's behavior.

    Maps a function name (and optional module) to its semantic action(s).
    """

    name: str
    """Function name"""

    module: str = "*"
    """Module name (* for any module)"""

    action_type: SemanticActionType = SemanticActionType.UNKNOWN
    """Primary semantic action type"""

    arg_index: int = 0
    """Which argument contains the target/value (0-based)"""

    transforms: Optional[List[Dict[str, Any]]] = None
    """Transformation rules for arguments"""

    confidence: str = "high"
    """Confidence level: 'high', 'medium', 'low'"""

    description: str = ""
    """Human-readable description of the function"""

    def matches(self, func_name: str, module_name: Optional[str] = None) -> bool:
        """Check if this semantic matches the given function call."""
        # Check name match
        if self.name != func_name:
            # Also check fully qualified name
            if module_name and f"{module_name}.{func_name}" != self.name:
                return False

        # Check module match
        if self.module != "*":
            if module_name != self.module:
                return False

        return True

    def to_action(
        self,
        args: List[Any],
        kwargs: Dict[str, Any],
        scope: str = "local",
    ) -> SemanticAction:
        """Convert function call to semantic action.

        Args:
            args: Positional arguments
            kwargs: Keyword arguments
            scope: Variable scope

        Returns:
            Semantic action representing the function call
        """
        # Extract target/value from arguments
        target = None
        value = None

        if len(args) > self.arg_index:
            target = args[self.arg_index]

        # Apply transforms if defined
        if self.transforms and target:
            target = self._apply_transforms(target, args, kwargs)

        return SemanticAction(
            action_type=self.action_type,
            target=target,
            value=value,
            scope=scope,
            confidence=self.confidence,
            metadata={
                "function": self.name,
                "module": self.module,
                "args": args,
                "kwargs": kwargs,
            },
        )

    def _apply_transforms(
        self,
        target: Any,
        args: List[Any],
        kwargs: Dict[str, Any],
    ) -> Any:
        """Apply transformation rules to target value."""
        result = target

        if not self.transforms:
            return result

        for transform in self.transforms:
            transform_type = transform.get("type", "passthrough")

            if transform_type == "passthrough":
                pass  # No transformation
            elif transform_type == "prefix":
                prefix = transform.get("value", "")
                result = f"{prefix}{result}"
            elif transform_type == "suffix":
                suffix = transform.get("value", "")
                result = f"{result}{suffix}"
            elif transform_type == "format":
                format_str = transform.get("template", "{}")
                result = format_str.format(result)
            elif transform_type == "concat":
                parts = transform.get("parts", [])
                resolved = []
                for part in parts:
                    if isinstance(part, str) and part.startswith("$arg"):
                        idx = int(part[4:]) if len(part) > 4 else 0
                        resolved.append(args[idx] if idx < len(args) else "")
                    else:
                        resolved.append(str(part))
                result = "".join(resolved)

        return result

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return {
            "name": self.name,
            "module": self.module,
            "action_type": self.action_type.value,
            "arg_index": self.arg_index,
            "transforms": self.transforms,
            "confidence": self.confidence,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> FunctionSemantics:
        """Create from dictionary."""
        return cls(
            name=data["name"],
            module=data.get("module", "*"),
            action_type=SemanticActionType(data["action_type"]),
            arg_index=data.get("arg_index", 0),
            transforms=data.get("transforms"),
            confidence=data.get("confidence", "high"),
            description=data.get("description", ""),
        )


class FunctionProvider(ABC):
    """Abstract base class for function semantic providers.

    Implementations provide mappings from function names to their
    semantic meanings for different contexts (built-ins, user-defined, etc.)
    """

    @abstractmethod
    def resolve(
        self,
        func_name: str,
        module_name: Optional[str] = None,
    ) -> Optional[FunctionSemantics]:
        """Resolve a function to its semantic definition.

        Args:
            func_name: Function name
            module_name: Optional module/namespace

        Returns:
            FunctionSemantics if found, None otherwise
        """
        pass

    @abstractmethod
    def register(self, semantics: FunctionSemantics) -> None:
        """Register a new function semantic definition.

        Args:
            semantics: Function semantic definition to register
        """
        pass

    @abstractmethod
    def list_functions(self) -> List[FunctionSemantics]:
        """List all registered function semantics.

        Returns:
            List of all registered function semantic definitions
        """
        pass


class DefaultFunctionProvider(FunctionProvider):
    """Default implementation of function provider with in-memory registry."""

    def __init__(self):
        """Initialize with empty registry."""
        self._registry: Dict[str, List[FunctionSemantics]] = {}
        self._load_builtins()

    def _load_builtins(self) -> None:
        """Load built-in Ren'Py function semantics."""
        builtins = [
            # Ren'Py built-in control flow
            FunctionSemantics(
                name="renpy.jump",
                module="renpy",
                action_type=SemanticActionType.JUMP,
                arg_index=0,
                confidence="high",
                description="Ren'Py jump to label",
            ),
            FunctionSemantics(
                name="renpy.call",
                module="renpy",
                action_type=SemanticActionType.CALL,
                arg_index=0,
                confidence="high",
                description="Ren'Py call label",
            ),
            FunctionSemantics(
                name="renpy.return_statement",
                module="renpy",
                action_type=SemanticActionType.RETURN,
                confidence="high",
                description="Ren'Py return from call",
            ),
            # Common helper patterns
            FunctionSemantics(
                name="go_to",
                module="*",
                action_type=SemanticActionType.JUMP,
                arg_index=0,
                confidence="medium",
                description="Common go_to helper pattern",
            ),
            FunctionSemantics(
                name="next_scene",
                module="*",
                action_type=SemanticActionType.JUMP,
                arg_index=0,
                confidence="medium",
                description="Common next_scene helper pattern",
            ),
        ]

        for builtin in builtins:
            self.register(builtin)

    def resolve(
        self,
        func_name: str,
        module_name: Optional[str] = None,
    ) -> Optional[FunctionSemantics]:
        """Resolve function to semantic definition."""
        # Try exact match first
        candidates = self._registry.get(func_name, [])

        # Filter by module if specified
        for candidate in candidates:
            if candidate.matches(func_name, module_name):
                return candidate

        return None

    def register(self, semantics: FunctionSemantics) -> None:
        """Register a function semantic definition."""
        if semantics.name not in self._registry:
            self._registry[semantics.name] = []
        self._registry[semantics.name].append(semantics)

    def list_functions(self) -> List[FunctionSemantics]:
        """List all registered function semantics."""
        result = []
        for func_list in self._registry.values():
            result.extend(func_list)
        return result

    def get_known_names(self) -> Set[str]:
        """Get set of all known function names."""
        return set(self._registry.keys())
