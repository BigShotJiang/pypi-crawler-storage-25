"""Semantic Node - Enhanced CFG node with semantic annotations

Extends CFG nodes with semantic action tracking for deeper analysis.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from .semantic_action import SemanticAction


@dataclass
class SemanticNode:
    """Enhanced CFG node with semantic action annotations.

    This class wraps or extends CFG nodes to track the semantic actions
    that occur at each point in the control flow graph.
    """

    node_id: str
    """Unique identifier for the node"""

    file_path: str
    """Source file path"""

    line_number: int
    """Line number in source file"""

    actions: List[SemanticAction] = field(default_factory=list)
    """Ordered list of semantic actions at this node"""

    kind: str = "statement"
    """Node kind: 'label', 'statement', 'menu', 'choice', 'return'"""

    metadata: Dict[str, Any] = field(default_factory=dict)
    """Additional metadata about the node"""

    def add_action(self, action: SemanticAction) -> None:
        """Add a semantic action to this node."""
        self.actions.append(action)

    def get_actions_by_type(self, action_type) -> List[SemanticAction]:
        """Get all actions of a specific type."""
        from .semantic_action import SemanticActionType

        if isinstance(action_type, str):
            action_type = SemanticActionType(action_type)
        return [a for a in self.actions if a.action_type == action_type]

    def has_control_flow(self) -> bool:
        """Check if this node has control flow actions."""
        return any(a.is_control_flow() for a in self.actions)

    def has_state_changes(self) -> bool:
        """Check if this node has state modification actions."""
        return any(a.is_state_change() for a in self.actions)

    def to_dict(self) -> Dict[str, Any]:
        """Export node as dictionary for serialization."""
        return {
            "node_id": self.node_id,
            "file": self.file_path,
            "line": self.line_number,
            "kind": self.kind,
            "actions": [a.to_dict() for a in self.actions],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SemanticNode:
        """Create node from dictionary."""
        return cls(
            node_id=data["node_id"],
            file_path=data["file"],
            line_number=data["line"],
            kind=data.get("kind", "statement"),
            actions=[SemanticAction.from_dict(a) for a in data.get("actions", [])],
            metadata=data.get("metadata", {}),
        )

    def __repr__(self) -> str:
        """String representation for debugging."""
        return f"SemanticNode(id={self.node_id}, actions={len(self.actions)}, kind={self.kind})"
