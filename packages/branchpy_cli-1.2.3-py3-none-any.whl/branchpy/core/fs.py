from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict

from .jsonio import dump_json, load_json

BP_DIR = ".branchpy"
PATCH_DIR = "patches"
REPORT_DIR = "reports"
STATE_FILE = "state.json"


def ensure_structure(root: str | Path = ".") -> Path:
    root = Path(root)
    base = root / BP_DIR
    (base / PATCH_DIR).mkdir(parents=True, exist_ok=True)
    (base / REPORT_DIR).mkdir(parents=True, exist_ok=True)
    (base / "logs").mkdir(parents=True, exist_ok=True)
    (base / "tmp").mkdir(parents=True, exist_ok=True)
    state = base / STATE_FILE
    if not state.exists():
        dump_json(state, {"applied": [], "reverted": []})
    return base


def load_state(base: Path) -> Dict[str, Any]:
    return load_json(base / STATE_FILE)


def save_state(base: Path, state: Dict[str, Any]) -> None:
    dump_json(base / STATE_FILE, state)


def timestamp_slug() -> str:
    return time.strftime("%Y%m%d-%H%M%S")


def iter_patch_paths(base: Path):
    pdir = base / PATCH_DIR
    for p in sorted(pdir.glob("*.patch")):
        yield p
