from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class EngineInterface(ABC):
    """
    Base interface for all BranchPy engines (Ren'Py, Twine, Ink, etc.).
    """

    @abstractmethod
    def build_index(self, project_path: str) -> Dict[str, Any]:
        """
        Parse a project at project_path and return a structured index
        (files, symbols, jumps/labels, basic graph stubs, etc.).
        """
        raise NotImplementedError

    @abstractmethod
    def analyze(
        self, index: Dict[str, Any], options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Run engine-specific static checks on the provided index.

        Args:
            index: Project index from build_index()
            options: Optional analysis options (e.g., enable_assets, export_cfg)

        Returns:
            Normalized analysis dict (issues, stats, metadata, optional assets)
        """
        raise NotImplementedError
