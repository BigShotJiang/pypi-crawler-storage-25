"""
BranchPy Plugin System (Minimal Stub for v0.8.3)

This is a minimal plugin loader to prepare for the full Plugin Adapter Layer (PAL)
in v1.7.8. Currently supports only internal (bundled) plugins.

Architecture:
- Internal plugins: Bundled with BranchPy, loaded at startup
- External plugins: Installed from marketplace (v1.7.8+)

Plugin Structure:
    branchpy/plugins/
    ├── git_safeguards/
    │   ├── manifest.toml      # Plugin metadata
    │   ├── __init__.py         # Entrypoint with setup() function
    │   ├── policy/             # Plugin modules
    │   ├── git/
    │   └── audit/

Migration Path:
    v0.8.3: Stub loader + manifest support
    v0.8.4: VS Code panel registration
    v1.7.8: Full PAL with marketplace support
    v1.8.0: License validation & feature gating

Usage:
    from branchpy.core.plugins import load_plugins

    plugin_manager = PluginManager()
    load_plugins(plugin_manager)
"""

import importlib.util
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib


class PluginManager:
    """
    Manages plugin lifecycle and command registration.

    This is a minimal implementation for v0.8.3. The full PAL will add:
    - External plugin discovery (marketplace)
    - License validation
    - Dependency resolution
    - Sandboxed execution
    - Version compatibility checks
    """

    def __init__(self):
        self.plugins: Dict[str, Dict[str, Any]] = {}
        self.commands: Dict[str, Callable] = {}
        self.config_schemas: Dict[str, Dict[str, str]] = {}
        self.panels: Dict[str, Any] = {}  # VS Code panels (future)

    def register_command(self, name: str, handler: Callable):
        """
        Register a CLI command handler.

        Args:
            name: Command name (e.g., "hooks", "policy")
            handler: Function that registers subparser (e.g., register_hooks)
        """
        self.commands[name] = handler

    def register_config_schema(self, plugin_id: str, schema: Dict[str, str]):
        """
        Register configuration schema for validation and UI generation.

        Args:
            plugin_id: Unique plugin identifier (e.g., "branchpy.git")
            schema: Dict of config keys and default values
        """
        self.config_schemas[plugin_id] = schema

    def register_panel(self, name: str, panel_class: Any):
        """
        Register a VS Code panel provider (future: v0.8.4).

        Args:
            name: Panel name (e.g., "policy_status")
            panel_class: Panel class or factory function
        """
        self.panels[name] = panel_class

    def get_plugin(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        """Get plugin metadata by ID."""
        return self.plugins.get(plugin_id)

    def list_plugins(self) -> List[str]:
        """List all loaded plugin IDs."""
        return list(self.plugins.keys())


def load_manifest(manifest_path: Path) -> Dict[str, Any]:
    """
    Load plugin manifest.toml file.

    Args:
        manifest_path: Path to manifest.toml

    Returns:
        Dict with plugin metadata

    Raises:
        FileNotFoundError: Manifest file not found
        ValueError: Invalid TOML syntax
    """
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    with open(manifest_path, "rb") as f:
        manifest = tomllib.load(f)

    # Validate required fields
    required = ["plugin.id", "plugin.version", "plugin.name", "plugin.type"]
    for field in required:
        keys = field.split(".")
        obj = manifest
        for key in keys:
            if key not in obj:
                raise ValueError(f"Missing required field: {field}")
            obj = obj[key]

    return manifest


def load_internal_plugin(plugin_dir: Path, plugin_manager: PluginManager):
    """
    Load an internal (bundled) plugin.

    Args:
        plugin_dir: Path to plugin directory
        plugin_manager: PluginManager instance

    Steps:
        1. Load manifest.toml
        2. Validate compatibility (requires version)
        3. Import plugin module
        4. Call setup(plugin_manager) entrypoint
    """
    manifest_path = plugin_dir / "manifest.toml"

    try:
        manifest = load_manifest(manifest_path)
    except Exception as e:
        print(f"[plugin] Failed to load manifest: {plugin_dir.name} ({e})")
        return

    plugin_id = manifest["plugin"]["id"]
    plugin_version = manifest["plugin"]["version"]
    plugin_name = manifest["plugin"].get("name", plugin_id)

    # Validate compatibility (simplified for v0.8.3)
    # Full version: semver parsing with >=, ~, ^ operators
    requires = manifest["plugin"].get("requires", "0.0.0")
    # TODO: Compare with branchpy.__version__

    # Import plugin module
    module_name = f"branchpy.plugins.{plugin_dir.name}"
    try:
        spec = importlib.util.spec_from_file_location(
            module_name, plugin_dir / "__init__.py"
        )
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
        else:
            print(f"[plugin] Failed to load module: {module_name}")
            return
    except Exception as e:
        print(f"[plugin] Import error: {module_name} ({e})")
        return

    # Call setup entrypoint
    if hasattr(module, "setup"):
        try:
            module.setup(plugin_manager)
        except Exception as e:
            print(f"[plugin] Setup failed: {plugin_name} ({e})")
            return
    else:
        print(f"[plugin] No setup() function: {module_name}")

    # Store plugin metadata
    plugin_manager.plugins[plugin_id] = {
        "id": plugin_id,
        "version": plugin_version,
        "name": plugin_name,
        "type": "internal",
        "manifest": manifest,
        "module": module,
    }


def load_plugins(plugin_manager: Optional[PluginManager] = None) -> PluginManager:
    """
    Load all internal plugins.

    Args:
        plugin_manager: Optional existing PluginManager instance

    Returns:
        PluginManager with loaded plugins

    Discovery:
        1. Scan branchpy/plugins/ for subdirectories
        2. Check for manifest.toml in each
        3. Load internal plugins only (type="internal")
        4. External plugins will be supported in v1.7.8
    """
    if plugin_manager is None:
        plugin_manager = PluginManager()

    # Find plugins directory
    branchpy_root = Path(__file__).parent.parent
    plugins_dir = branchpy_root / "plugins"

    if not plugins_dir.exists():
        # No plugins installed yet
        return plugin_manager

    # Scan for plugin directories
    for plugin_dir in plugins_dir.iterdir():
        if not plugin_dir.is_dir():
            continue

        manifest_path = plugin_dir / "manifest.toml"
        if not manifest_path.exists():
            # Not a plugin directory
            continue

        # Load manifest to check type
        try:
            manifest = load_manifest(manifest_path)
            plugin_type = manifest["plugin"].get("type", "external")

            if plugin_type == "internal":
                load_internal_plugin(plugin_dir, plugin_manager)
            else:
                # External plugins not supported yet
                pass
        except Exception as e:
            print(f"[plugin] Skipping {plugin_dir.name}: {e}")

    return plugin_manager


# Global plugin manager instance
_plugin_manager: Optional[PluginManager] = None


def get_plugin_manager() -> PluginManager:
    """
    Get or create the global plugin manager.

    Returns:
        PluginManager singleton instance
    """
    global _plugin_manager
    if _plugin_manager is None:
        _plugin_manager = load_plugins()
    return _plugin_manager


# Future: License validation (v1.8.0)
def check_license(plugin_id: str) -> Dict[str, Any]:
    """
    Check plugin license status (stub for v1.8.0).

    Args:
        plugin_id: Plugin ID (e.g., "branchpy.git")

    Returns:
        Dict with license info:
        {
            "valid": bool,
            "tier": "free" | "pro" | "enterprise",
            "expires": Optional[datetime],
            "features": List[str]
        }
    """
    # For v0.8.3, all internal plugins are free/unlimited
    return {
        "valid": True,
        "tier": "free",
        "expires": None,
        "features": ["*"],  # All features enabled
    }


__all__ = ["PluginManager", "load_plugins", "get_plugin_manager", "check_license"]
