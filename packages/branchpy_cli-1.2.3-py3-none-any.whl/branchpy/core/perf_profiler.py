"""
Performance Profiler for BranchPy Analyzer (SAE Phase 6)

Lightweight timing and memory tracking with minimal overhead (<3% wall time).
Captures stage-level metrics and exports to unified_report.json.

Author: BranchPy Core
Version: 0.7.6-dev1
"""

import os
import sys
from time import perf_counter
from typing import Any, Dict, Optional


class PerfProfiler:
    """
    Tracks timing and memory metrics during analysis.

    Usage:
        prof = PerfProfiler(enable_memory=True)
        prof.start_session()

        # ... do parse work ...
        prof.mark("parse")

        # ... do graph work ...
        prof.mark("story_graph")

        prof.finish_session()
        result = prof.export(derived={"total_labels": 85, "total_transitions": 274})
    """

    def __init__(self, enable_memory: bool = True):
        """
        Initialize profiler.

        Args:
            enable_memory: Enable memory sampling (default True).
                          Set to False for minimal overhead.
        """
        self.enable_memory = enable_memory
        self.marks: Dict[str, float] = {}  # mark_name -> timestamp
        self.timings: Dict[str, float] = {}  # stage_name_ms -> duration
        self.mem_peak_mb: float = 0.0
        self.session_start: float = 0.0

    def start_session(self):
        """Begin profiling session. Call at start of analysis."""
        self.session_start = perf_counter()
        self.marks["session_start"] = self.session_start

        if self.enable_memory:
            self._sample_memory()

    def mark(self, stage_name: str):
        """
        Mark end of a stage and record elapsed time.

        Args:
            stage_name: Name of stage (e.g., "parse", "story_graph", "rules", "assets")
        """
        now = perf_counter()
        elapsed_ms = (now - self.session_start) * 1000.0

        # Store raw timing
        self.timings[f"{stage_name}_time_ms"] = elapsed_ms
        self.marks[stage_name] = now

        if self.enable_memory:
            self._sample_memory()

    def finish_session(self):
        """End profiling session. Call at end of analysis."""
        now = perf_counter()
        total_ms = (now - self.session_start) * 1000.0

        self.timings["total_analysis_time_ms"] = total_ms
        self.marks["session_end"] = now

        if self.enable_memory:
            self._sample_memory()

    def export(self, derived: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Export performance metrics for unified_report.json.

        Args:
            derived: Optional dict with graph stats:
                     {total_labels, total_transitions, avg_edges_per_label}

        Returns:
            Dict with performance section data
        """
        # Base metrics
        result: Dict[str, Any] = {
            "total_analysis_time_ms": round(
                self.timings.get("total_analysis_time_ms", 0.0), 3
            ),
            "script_parse_time_ms": round(self._get_stage_duration("parse"), 3),
            "story_graph_time_ms": round(self._get_stage_duration("story_graph"), 3),
            "rules_eval_time_ms": round(self._get_stage_duration("rules"), 3),
            "asset_validation_time_ms": round(self._get_stage_duration("assets"), 3),
            "memory_peak_mb": round(self.mem_peak_mb, 3),
            "memory_end_mb": round(
                self._current_memory_mb() if self.enable_memory else 0.0, 3
            ),
        }

        # Add derived metrics
        if derived:
            result["total_labels"] = derived.get("total_labels", 0)
            result["total_transitions"] = derived.get("total_transitions", 0)
            result["avg_edges_per_label"] = round(
                derived.get("avg_edges_per_label", 0.0), 3
            )

            # Calculate labels/second
            total_time_sec = max(result["total_analysis_time_ms"] / 1000.0, 1e-6)
            labels = result["total_labels"]
            result["labels_per_second"] = (
                round(labels / total_time_sec, 3) if labels > 0 else 0.0
            )
        else:
            result["total_labels"] = 0
            result["total_transitions"] = 0
            result["avg_edges_per_label"] = 0.0
            result["labels_per_second"] = 0.0

        # Threshold evaluation
        result["thresholds_met"] = self._evaluate_thresholds(result)
        result["notes"] = self._generate_notes(result)

        return result

    def _get_stage_duration(self, stage_name: str) -> float:
        """Get duration of a specific stage in milliseconds."""
        # If we have cumulative timing, calculate delta
        key = f"{stage_name}_time_ms"
        if key in self.timings:
            return self.timings[key]
        return 0.0

    def _sample_memory(self):
        """Update peak memory if current usage is higher."""
        current_mb = self._current_memory_mb()
        if current_mb > self.mem_peak_mb:
            self.mem_peak_mb = current_mb

    def _current_memory_mb(self) -> float:
        """
        Get current process memory usage in MB.
        Uses platform-specific methods with graceful fallbacks.
        """
        # Try psutil first (most reliable, cross-platform)
        try:
            import psutil  # type: ignore

            process = psutil.Process(os.getpid())
            return process.memory_info().rss / (1024 * 1024)
        except ImportError:
            pass
        except Exception:
            pass

        # Try resource module (POSIX only)
        try:
            import resource  # type: ignore

            usage = resource.getrusage(resource.RUSAGE_SELF)  # type: ignore
            # ru_maxrss is in KB on Linux, bytes on macOS
            if sys.platform == "darwin":
                return usage.ru_maxrss / (1024 * 1024)
            else:
                return usage.ru_maxrss / 1024
        except ImportError:
            pass
        except Exception:
            pass

        # Fallback: return 0 (couldn't measure)
        return 0.0

    def _evaluate_thresholds(self, metrics: Dict) -> bool:
        """
        Evaluate if metrics meet performance thresholds.

        Thresholds (configurable in future):
        - Memory peak < 1024 MB
        - Total analysis time < 5000 ms
        - Labels/sec >= 50 (for projects with 50+ labels)
        """
        # Memory threshold
        if metrics.get("memory_peak_mb", 0) > 1024:
            return False

        # Time threshold
        if metrics.get("total_analysis_time_ms", 0) > 5000:
            return False

        # Throughput threshold (only for larger projects)
        total_labels = metrics.get("total_labels", 0)
        labels_per_sec = metrics.get("labels_per_second", 0)
        if total_labels >= 50 and labels_per_sec < 50:
            return False

        return True

    def _generate_notes(self, metrics: Dict) -> str:
        """Generate human-readable notes about performance."""
        notes = []

        # Check memory
        mem_peak = metrics.get("memory_peak_mb", 0)
        if mem_peak > 1024:
            notes.append(f"High memory usage: {mem_peak:.1f} MB (threshold: 1024 MB)")

        # Check time
        total_time = metrics.get("total_analysis_time_ms", 0)
        if total_time > 5000:
            notes.append(f"Slow analysis: {total_time:.1f} ms (threshold: 5000 ms)")

        # Check throughput
        total_labels = metrics.get("total_labels", 0)
        labels_per_sec = metrics.get("labels_per_second", 0)
        if total_labels >= 50 and labels_per_sec < 50:
            notes.append(
                f"Low throughput: {labels_per_sec:.1f} labels/sec (threshold: 50)"
            )

        # All good
        if not notes:
            return "All metrics within expected thresholds"

        return "; ".join(notes)


def create_profiler(
    enable: bool = True, enable_memory: bool = True
) -> Optional[PerfProfiler]:
    """
    Factory function to create profiler based on settings.

    Args:
        enable: Whether to enable profiling at all
        enable_memory: Whether to enable memory sampling

    Returns:
        PerfProfiler instance or None if disabled
    """
    if not enable:
        return None

    return PerfProfiler(enable_memory=enable_memory)
