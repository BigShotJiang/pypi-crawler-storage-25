"""
Governance Event Integrity Verification

Implements hash chain verification for governance event sequences to detect:
- Missing events (gaps in sequence)
- Tampered events (hash mismatch)
- Out-of-order events (timestamp violations)

Hash Chain Algorithm:
    chain_hash = SHA256(prev_hash + event_json)

    For first event: prev_hash = "0" * 64
    Each event includes its computed hash for next event verification

Usage:
    from branchpy.core.governance.integrity import verify_event_chain

    result = verify_event_chain(
        log_path=Path(".branchpy/governance.jsonl"),
        correlation_id="abc123"  # optional filter
    )

    if result.verified:
        print(f"Chain valid: {result.event_count} events")
    else:
        print(f"Violations: {result.missing_indices}")

Version: v0.9.2 (Phase 5 - Advanced Intelligence & Streaming)
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

_logger = logging.getLogger(__name__)


@dataclass
class IntegrityResult:
    """Result of hash chain verification."""

    verified: bool
    event_count: int
    chain_head_hash: str
    missing_indices: List[int]
    duration_ms: float
    violations: List[str]  # Human-readable violation messages


def _compute_event_hash(event: Dict[str, Any], prev_hash: str) -> str:
    """
    Compute SHA256 hash for event in chain.

    Args:
        event: Event dictionary (must be JSON serializable)
        prev_hash: Previous event's hash (or "0" * 64 for genesis)

    Returns:
        64-character hex digest SHA256 hash
    """
    # Serialize event deterministically (sorted keys)
    event_json = json.dumps(event, sort_keys=True, default=str)
    chain_input = f"{prev_hash}{event_json}"
    return hashlib.sha256(chain_input.encode("utf-8")).hexdigest()


def verify_event_chain(
    log_path: Path,
    correlation_id: Optional[str] = None,
    start_timestamp: Optional[str] = None,
    end_timestamp: Optional[str] = None,
) -> IntegrityResult:
    """
    Verify integrity of governance event chain.

    Args:
        log_path: Path to governance.jsonl file
        correlation_id: Optional filter for specific correlation group
        start_timestamp: Optional ISO 8601 start time filter
        end_timestamp: Optional ISO 8601 end time filter

    Returns:
        IntegrityResult with verification status and diagnostics

    Algorithm:
        1. Read events from JSONL (optionally filtered)
        2. Sort by timestamp (detect out-of-order)
        3. Compute chain hash for each event
        4. Detect missing indices if events have sequence numbers
        5. Return verification result with violations
    """
    start_time = datetime.utcnow()

    if not log_path.exists():
        return IntegrityResult(
            verified=False,
            event_count=0,
            chain_head_hash="",
            missing_indices=[],
            duration_ms=0.0,
            violations=["Log file does not exist"],
        )

    # Read and filter events
    events = []
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            for idx, line in enumerate(f):
                if not line.strip():
                    continue

                try:
                    event = json.loads(line)

                    # Apply filters
                    if correlation_id and event.get("correlation_id") != correlation_id:
                        continue

                    timestamp = event.get("timestamp", "")
                    if start_timestamp and timestamp < start_timestamp:
                        continue
                    if end_timestamp and timestamp > end_timestamp:
                        continue

                    # Add line index for missing event detection
                    event["_line_index"] = idx
                    events.append(event)

                except json.JSONDecodeError as e:
                    _logger.warning(f"Skipping malformed JSON at line {idx}: {e}")
                    continue
    except Exception as e:
        return IntegrityResult(
            verified=False,
            event_count=0,
            chain_head_hash="",
            missing_indices=[],
            duration_ms=0.0,
            violations=[f"Failed to read log file: {e}"],
        )

    if not events:
        return IntegrityResult(
            verified=True,  # Empty chain is valid
            event_count=0,
            chain_head_hash="0" * 64,  # Genesis hash
            missing_indices=[],
            duration_ms=(datetime.utcnow() - start_time).total_seconds() * 1000,
            violations=[],
        )

    # Sort by timestamp (detect out-of-order)
    events_sorted = sorted(events, key=lambda e: e.get("timestamp", ""))

    # Verify chain integrity
    violations = []
    prev_hash = "0" * 64  # Genesis hash
    prev_timestamp = None
    missing_indices = []

    for idx, event in enumerate(events_sorted):
        # Check timestamp ordering
        current_timestamp = event.get("timestamp")
        if prev_timestamp and current_timestamp and current_timestamp < prev_timestamp:
            violations.append(
                f"Event {idx} out of order: {current_timestamp} < {prev_timestamp}"
            )
        prev_timestamp = current_timestamp

        # Compute expected hash
        computed_hash = _compute_event_hash(event, prev_hash)

        # If event has stored hash, verify it matches
        stored_hash = event.get("_chain_hash")
        if stored_hash and stored_hash != computed_hash:
            violations.append(
                f"Event {idx} hash mismatch: expected {computed_hash[:16]}..., "
                f"got {stored_hash[:16]}..."
            )

        prev_hash = computed_hash

        # Detect missing indices if events have sequence numbers
        expected_line = idx if not missing_indices else idx + len(missing_indices)
        actual_line = event.get("_line_index", idx)
        if actual_line != expected_line:
            gap_indices = list(range(expected_line, actual_line))
            missing_indices.extend(gap_indices)
            violations.append(f"Missing events detected: indices {gap_indices}")

    # Compute final duration
    duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

    return IntegrityResult(
        verified=(len(violations) == 0),
        event_count=len(events_sorted),
        chain_head_hash=prev_hash,
        missing_indices=missing_indices,
        duration_ms=duration_ms,
        violations=violations,
    )


def verify_correlation_group(log_path: Path, correlation_id: str) -> IntegrityResult:
    """
    Convenience method to verify a specific correlation group.

    Args:
        log_path: Path to governance.jsonl
        correlation_id: Correlation ID to verify

    Returns:
        IntegrityResult for the correlation group
    """
    return verify_event_chain(log_path, correlation_id=correlation_id)
