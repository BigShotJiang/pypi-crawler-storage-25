"""
Team Manager — v0.8.6
Manage team members, roles, and capabilities from .branchpy/team.toml.

Usage:
    from branchpy.core.governance import TeamManager

    team = TeamManager(Path(".branchpy/team.toml"))
    role = team.get_role("user-uuid-123")
    has_perm = team.has_capability(role, "audit_write")
"""

from __future__ import annotations

import tomllib  # Python 3.11+
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class TeamMember:
    """Team member information."""

    user_uuid: str
    role: str
    name: Optional[str] = None
    email: Optional[str] = None


@dataclass
class RoleDefinition:
    """Role definition with capabilities."""

    name: str
    capabilities: Dict[str, bool]


class TeamManager:
    """
    Manage team configuration and RBAC.

    Loads .branchpy/team.toml and provides role/capability lookups.
    """

    def __init__(self, team_toml_path: Path):
        self.team_toml_path = team_toml_path
        self.config = self._load_config(team_toml_path)

    def _load_config(self, path: Path) -> Dict[str, Any]:
        """Load team.toml configuration."""
        if not path.exists():
            # No team config = single-user mode (all permissions)
            return {
                "team": {"team_id": "solo", "name": "Solo Project"},
                "roles": {
                    "owner": {
                        "admin": True,
                        "audit_write": True,
                        "audit_verify": True,
                        "replay": True,
                        "policy_manage": True,
                    }
                },
                "assignments": {},
            }

        with open(path, "rb") as f:
            return tomllib.load(f)

    def get_role(self, user_uuid: str) -> str:
        """
        Get user's role from team.toml.

        Returns:
            Role name (e.g., "owner", "contributor")
            If user not found and no assignments exist, returns "owner" (solo mode)
            If user not found but assignments exist, returns "none"
        """
        assignments = self.config.get("assignments", {})

        if not assignments:
            # No assignments = solo mode, everyone is owner
            return "owner"

        return assignments.get(user_uuid, "none")

    def has_capability(self, role: str, capability: str) -> bool:
        """
        Check if role has a specific capability.

        Args:
            role: Role name (e.g., "owner", "contributor")
            capability: Capability name (e.g., "audit_write")

        Returns:
            True if role has capability, False otherwise
        """
        if role == "none":
            return False

        roles = self.config.get("roles", {})

        if role not in roles:
            return False

        return roles[role].get(capability, False)

    def list_members(self) -> List[Dict[str, str]]:
        """
        List all team members with their roles.

        Returns:
            List of dicts with keys: uuid, role, name, email
        """
        assignments = self.config.get("assignments", {})
        members = []

        for user_uuid, role in assignments.items():
            members.append(
                {
                    "uuid": user_uuid,
                    "role": role,
                    "name": "",  # TODO: Load from identity.toml if available
                    "email": "",
                }
            )

        return members

    def get_team_info(self) -> Dict[str, str]:
        """Get team metadata."""
        team = self.config.get("team", {})
        return {
            "team_id": team.get("team_id", "unknown"),
            "name": team.get("name", "Unnamed Team"),
        }

    def get_role_capabilities(self, role: str) -> Dict[str, bool]:
        """Get all capabilities for a role."""
        roles = self.config.get("roles", {})
        return roles.get(role, {})

    def list_roles(self) -> List[RoleDefinition]:
        """List all defined roles."""
        roles = self.config.get("roles", {})
        return [
            RoleDefinition(name=name, capabilities=caps) for name, caps in roles.items()
        ]


class PermissionDenied(Exception):
    """Raised when user lacks required capability."""

    def __init__(
        self,
        capability: str,
        user_role: str,
        required_roles: Optional[List[str]] = None,
    ):
        self.capability = capability
        self.user_role = user_role
        self.required_roles = required_roles or []

        msg = f"Permission denied: '{capability}' capability required"
        if user_role:
            msg += f" (your role: {user_role})"
        if required_roles:
            msg += f" (required roles: {', '.join(required_roles)})"

        super().__init__(msg)
