"""Micro-benchmark for standard_command decorator overhead.

Measures P50/P95/P99 latency introduced by the decorator on minimal no-op commands.
Target: < 5ms P95 overhead (per Phase 2-4 implementation plan).

Usage:
    python -m branchpy.core.governance.benchmark_decorator_overhead
"""

from __future__ import annotations

import statistics
import time
from pathlib import Path

from branchpy.core.governance.standard_command_enforcement import standard_command


# Baseline: no decoration
def _baseline_noop() -> int:
    return 0


# Decorated: minimal overhead
@standard_command(name="benchmark.noop", capability=None, export_audit=False)
def _decorated_noop() -> int:
    return 0


# Decorated: with RBAC check (permissive)
@standard_command(
    name="benchmark.rbac", capability="test.capability", export_audit=False
)
def _decorated_rbac() -> int:
    return 0


# Decorated: with audit export
@standard_command(name="benchmark.audit", capability=None, export_audit=True)
def _decorated_audit() -> int:
    return 0


def benchmark(func, iterations: int = 1000) -> dict:
    """Run function N times and collect latency statistics."""
    latencies = []
    for _ in range(iterations):
        t0 = time.perf_counter()
        func()
        latencies.append((time.perf_counter() - t0) * 1000.0)  # ms

    return {
        "p50": statistics.median(latencies),
        "p95": statistics.quantiles(latencies, n=20)[18],  # 19th of 20 quantiles
        "p99": statistics.quantiles(latencies, n=100)[98],
        "mean": statistics.mean(latencies),
        "min": min(latencies),
        "max": max(latencies),
    }


def main():
    print("\n" + "=" * 70)
    print("Standard Command Decorator Overhead Benchmark")
    print("=" * 70)
    print("Iterations per test: 1000")
    print("Target: P95 < 5ms overhead\n")

    # Setup: ensure .branchpy exists for governance logger
    Path(".branchpy").mkdir(exist_ok=True)

    # Run benchmarks
    baseline_stats = benchmark(_baseline_noop)
    decorated_stats = benchmark(_decorated_noop)
    rbac_stats = benchmark(_decorated_rbac)
    audit_stats = benchmark(_decorated_audit)

    # Calculate overheads
    decorated_overhead = {
        k: decorated_stats[k] - baseline_stats[k] for k in ["p50", "p95", "p99", "mean"]
    }
    rbac_overhead = {
        k: rbac_stats[k] - baseline_stats[k] for k in ["p50", "p95", "p99", "mean"]
    }
    audit_overhead = {
        k: audit_stats[k] - baseline_stats[k] for k in ["p50", "p95", "p99", "mean"]
    }

    # Print results
    print(
        f"{'Scenario':<25} {'P50 (ms)':<12} {'P95 (ms)':<12} {'P99 (ms)':<12} {'Mean (ms)':<12}"
    )
    print("-" * 70)
    print(
        f"{'Baseline (no decorator)':<25} {baseline_stats['p50']:>10.3f}  {baseline_stats['p95']:>10.3f}  {baseline_stats['p99']:>10.3f}  {baseline_stats['mean']:>10.3f}"
    )
    print(
        f"{'Decorated (minimal)':<25} {decorated_stats['p50']:>10.3f}  {decorated_stats['p95']:>10.3f}  {decorated_stats['p99']:>10.3f}  {decorated_stats['mean']:>10.3f}"
    )
    print(
        f"{'Decorated (RBAC check)':<25} {rbac_stats['p50']:>10.3f}  {rbac_stats['p95']:>10.3f}  {rbac_stats['p99']:>10.3f}  {rbac_stats['mean']:>10.3f}"
    )
    print(
        f"{'Decorated (audit export)':<25} {audit_stats['p50']:>10.3f}  {audit_stats['p95']:>10.3f}  {audit_stats['p99']:>10.3f}  {audit_stats['mean']:>10.3f}"
    )
    print()
    print("=" * 70)
    print("Decorator Overhead (relative to baseline):")
    print("=" * 70)
    print(
        f"{'Scenario':<25} {'P50 (ms)':<12} {'P95 (ms)':<12} {'P99 (ms)':<12} {'Mean (ms)':<12}"
    )
    print("-" * 70)
    print(
        f"{'Minimal':<25} {decorated_overhead['p50']:>10.3f}  {decorated_overhead['p95']:>10.3f}  {decorated_overhead['p99']:>10.3f}  {decorated_overhead['mean']:>10.3f}"
    )
    print(
        f"{'RBAC check':<25} {rbac_overhead['p50']:>10.3f}  {rbac_overhead['p95']:>10.3f}  {rbac_overhead['p99']:>10.3f}  {rbac_overhead['mean']:>10.3f}"
    )
    print(
        f"{'Audit export':<25} {audit_overhead['p50']:>10.3f}  {audit_overhead['p95']:>10.3f}  {audit_overhead['p99']:>10.3f}  {audit_overhead['mean']:>10.3f}"
    )
    print()

    # Verdict
    target_p95 = 5.0  # ms
    pass_minimal = decorated_overhead["p95"] < target_p95
    pass_rbac = rbac_overhead["p95"] < target_p95
    pass_audit = audit_overhead["p95"] < target_p95

    print("=" * 70)
    print("Performance Verdict (P95 < 5ms target):")
    print("=" * 70)
    print(
        f"  Minimal:      {'✓ PASS' if pass_minimal else '✗ FAIL'} ({decorated_overhead['p95']:.3f} ms)"
    )
    print(
        f"  RBAC check:   {'✓ PASS' if pass_rbac else '✗ FAIL'} ({rbac_overhead['p95']:.3f} ms)"
    )
    print(
        f"  Audit export: {'✓ PASS' if pass_audit else '✗ FAIL'} ({audit_overhead['p95']:.3f} ms)"
    )
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
