"""
RBAC Denial Fallback Suggestions — Phase 4 Advanced UX

Provides intelligent fallback suggestions when users are denied access
to capabilities, helping them understand alternatives and next steps.

Usage:
    from branchpy.core.governance.denial_suggestions import get_fallback_suggestion

    suggestion = get_fallback_suggestion(
        capability="image.validation.run",
        user_role="viewer",
        command="validate images"
    )
    print(suggestion.message)  # User-friendly suggestion
    print(suggestion.action_type)  # REQUEST_ACCESS, USE_ALTERNATIVE, EXPORT_DATA, etc.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional


class FallbackActionType(Enum):
    """Types of fallback actions available to users"""

    REQUEST_ACCESS = "request_access"  # Ask admin for elevated role
    USE_ALTERNATIVE = "use_alternative"  # Use read-only or limited version
    EXPORT_DATA = "export_data"  # Export data for offline analysis
    VIEW_DOCUMENTATION = "view_documentation"  # Learn about feature
    CONTACT_ADMIN = "contact_admin"  # Contact administrator
    UPGRADE_ROLE = "upgrade_role"  # Upgrade user role
    WAIT_FOR_APPROVAL = "wait_for_approval"  # Pending approval workflow


@dataclass
class FallbackSuggestion:
    """
    Suggested fallback action when capability is denied.

    Attributes:
        action_type: Type of fallback action
        message: User-friendly message explaining the suggestion
        details: Additional details or steps to take
        links: Optional URLs to documentation or request forms
        alternative_command: Optional alternative CLI command to try
    """

    action_type: FallbackActionType
    message: str
    details: Optional[str] = None
    links: Optional[List[str]] = None
    alternative_command: Optional[str] = None


# Capability-specific fallback mappings
CAPABILITY_FALLBACKS: Dict[str, FallbackSuggestion] = {
    # Image Validation capabilities
    "image.validation.run": FallbackSuggestion(
        action_type=FallbackActionType.USE_ALTERNATIVE,
        message="You can view existing validation reports instead of running new validations.",
        details="Use 'branchpy provider reports list' to see recent validation reports.",
        alternative_command="branchpy provider reports list",
    ),
    "image.validation.cache.purge": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Cache purging requires admin privileges. Request access from your team administrator.",
        details="Cache operations can affect performance for all users.",
        links=["docs/v1.0.0/Governance/RBAC_REQUEST_ACCESS.md"],
    ),
    "image.validation.canonical.set": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Setting canonical images requires editor role. Request access to modify image selections.",
        details="You can view current canonical selections with viewer privileges.",
        alternative_command="branchpy validate images --report-only",
    ),
    "image.validation.semantic.retag": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Semantic tagging requires editor role. Request access to modify image tags.",
        details="You can view current semantic tags in read-only mode.",
    ),
    "image.validation.export": FallbackSuggestion(
        action_type=FallbackActionType.EXPORT_DATA,
        message="Export feature is available to all roles. This may be a configuration issue.",
        details="Contact your administrator to verify RBAC configuration.",
        links=["docs/v1.0.0/Governance/TROUBLESHOOTING.md"],
    ),
    # Provider capabilities
    "image.validation.provider.read": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Provider read access requires viewer role or higher.",
        details="Request access to view provider connections and reports.",
    ),
    "image.validation.provider.write": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Provider configuration requires editor role. Request access to modify provider settings.",
        details="You can view current provider status with viewer privileges.",
        alternative_command="branchpy provider list",
    ),
    "image.validation.provider.sync": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Provider sync requires editor role. Request access to synchronize providers.",
        details="Sync operations may create network traffic and modify remote data.",
    ),
    "image.validation.provider.health": FallbackSuggestion(
        action_type=FallbackActionType.USE_ALTERNATIVE,
        message="You can view provider health status in read-only mode.",
        details="Contact administrator if you need to modify health check settings.",
        alternative_command="branchpy provider list --status",
    ),
    "image.validation.provider.credentials": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Credential management requires admin role. This is a security-sensitive operation.",
        details="Only administrators can view or modify provider credentials.",
        links=["docs/v1.0.0/Security/CREDENTIAL_MANAGEMENT.md"],
    ),
    "image.validation.provider.credentials.rotate": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Credential rotation requires admin role due to security implications.",
        details="Contact your administrator to schedule credential rotation.",
    ),
    "image.validation.provider.report.list": FallbackSuggestion(
        action_type=FallbackActionType.USE_ALTERNATIVE,
        message="Report listing should be available to viewers. This may be a configuration issue.",
        details="Contact administrator to verify RBAC settings.",
    ),
    "image.validation.provider.report.push": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Report publishing requires editor role. Request access to push reports to providers.",
        details="You can view and export reports locally without push access.",
    ),
    "image.validation.provider.thumbnail": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Thumbnail rebuild requires editor role. Request access to regenerate thumbnails.",
        details="This operation can be resource-intensive and affect cached data.",
    ),
    # General governance capabilities
    "governance.policy.edit": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Policy editing requires admin role. Request elevated access from your administrator.",
        details="Policy changes affect all team members and require careful review.",
        links=["docs/v1.0.0/Governance/POLICY_MANAGEMENT.md"],
    ),
    "governance.audit.export": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Audit export requires admin role due to sensitive data access.",
        details="Contact administrator to request audit exports for compliance purposes.",
    ),
    "team.member.add": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Adding team members requires admin role. Request elevated access.",
        details="Team management operations require administrative privileges.",
    ),
    "team.member.remove": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Removing team members requires admin role. Contact your administrator.",
        details="This is a security-sensitive operation.",
    ),
    "team.role.assign": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Role assignment requires admin role. Request access to manage team roles.",
        details="Role changes affect user permissions and access levels.",
    ),
}


# Role-specific default fallbacks
ROLE_DEFAULTS: Dict[str, FallbackSuggestion] = {
    "viewer": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Your viewer role has read-only access. Request editor or admin role for write operations.",
        details="Contact your team administrator to upgrade your role if needed.",
        links=["docs/v1.0.0/Governance/ROLES.md"],
    ),
    "editor": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="This operation requires admin role. Request elevated access from your administrator.",
        details="Admin-only operations include policy editing, credential management, and team administration.",
    ),
    "guest": FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message="Guest accounts have very limited access. Request a permanent role from your administrator.",
        details="Guest access is typically temporary and read-only.",
    ),
}


def get_fallback_suggestion(
    capability: str,
    user_role: str,
    command: Optional[str] = None,
    context: Optional[Dict] = None,
) -> FallbackSuggestion:
    """
    Get intelligent fallback suggestion for denied capability.

    Args:
        capability: The capability that was denied (e.g., "image.validation.run")
        user_role: The user's current role (e.g., "viewer", "editor", "admin")
        command: Optional command that was attempted (e.g., "validate images")
        context: Optional additional context for better suggestions

    Returns:
        FallbackSuggestion with actionable next steps

    Example:
        >>> suggestion = get_fallback_suggestion(
        ...     capability="image.validation.run",
        ...     user_role="viewer",
        ...     command="validate images"
        ... )
        >>> print(suggestion.message)
        You can view existing validation reports instead of running new validations.
        >>> print(suggestion.alternative_command)
        branchpy provider reports list
    """
    # 1. Check for capability-specific fallback
    if capability in CAPABILITY_FALLBACKS:
        return CAPABILITY_FALLBACKS[capability]

    # 2. Check for role-specific default fallback
    if user_role in ROLE_DEFAULTS:
        return ROLE_DEFAULTS[user_role]

    # 3. Generic fallback based on capability pattern
    if "read" in capability or "list" in capability or "view" in capability:
        return FallbackSuggestion(
            action_type=FallbackActionType.CONTACT_ADMIN,
            message="Read operations should be available to most roles. This may be a configuration issue.",
            details="Contact your administrator to verify RBAC settings.",
        )
    elif "write" in capability or "edit" in capability or "set" in capability:
        return FallbackSuggestion(
            action_type=FallbackActionType.REQUEST_ACCESS,
            message=f"Write operations require elevated privileges. Request {capability} access.",
            details="Your current role may not have write permissions for this operation.",
        )
    elif "delete" in capability or "remove" in capability or "purge" in capability:
        return FallbackSuggestion(
            action_type=FallbackActionType.REQUEST_ACCESS,
            message="Destructive operations require admin role. Contact your administrator.",
            details="Deletion operations are restricted to prevent accidental data loss.",
        )

    # 4. Ultimate fallback
    return FallbackSuggestion(
        action_type=FallbackActionType.REQUEST_ACCESS,
        message=f"You don't have the '{capability}' capability. Request access from your administrator.",
        details=f"Your role ({user_role}) doesn't include this capability in the current policy.",
        links=["docs/v1.0.0/Governance/RBAC_REQUEST_ACCESS.md"],
    )


def format_denial_message(
    capability: str,
    user_role: str,
    command: Optional[str] = None,
    include_suggestion: bool = True,
) -> str:
    """
    Format a user-friendly denial message with optional fallback suggestion.

    Args:
        capability: The capability that was denied
        user_role: The user's current role
        command: Optional command that was attempted
        include_suggestion: Whether to include fallback suggestion

    Returns:
        Formatted message string for CLI/UI display

    Example:
        >>> msg = format_denial_message(
        ...     capability="image.validation.run",
        ...     user_role="viewer",
        ...     command="validate images",
        ...     include_suggestion=True
        ... )
        >>> print(msg)
        ❌ Permission denied: 'image.validation.run' capability required
           Your role: viewer
           Command: validate images

        💡 Suggestion: You can view existing validation reports instead of running new validations.
           Try: branchpy provider reports list
    """
    lines = [
        f"❌ Permission denied: '{capability}' capability required",
        f"   Your role: {user_role}",
    ]

    if command:
        lines.append(f"   Command: {command}")

    if include_suggestion:
        suggestion = get_fallback_suggestion(capability, user_role, command)
        lines.append("")  # Blank line
        lines.append(f"💡 Suggestion: {suggestion.message}")

        if suggestion.details:
            lines.append(f"   {suggestion.details}")

        if suggestion.alternative_command:
            lines.append(f"   Try: {suggestion.alternative_command}")

        if suggestion.links:
            lines.append(f"   Docs: {', '.join(suggestion.links)}")

    return "\n".join(lines)
