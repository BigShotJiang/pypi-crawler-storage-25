"""
Policy Enforcement Engine — v0.8.6
Loads, validates, and enforces .bpy-policy.json rules at runtime.

Usage:
    from branchpy.core.governance import PolicyEngine, ActionType

    engine = PolicyEngine(policy_path=Path(".branchpy/policy.json"))
    decision = engine.enforce(
        action=ActionType.CLI_COMMAND,
        context={"command": "run", "flags": ["--force"]},
        user_uuid="550e8400-...",
        role="contributor"
    )

    if decision.decision == EnforcementDecision.DENY:
        raise PermissionDenied(decision.reason)
"""

from __future__ import annotations

import fnmatch
import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


class ActionType(Enum):
    """Types of actions that can be policy-restricted."""

    CLI_COMMAND = "cli_command"  # e.g., branchpy run --force
    DAEMON_REQUEST = "daemon_request"  # WebSocket/HTTP API calls
    FILE_ACCESS = "file_access"  # Path-level restrictions
    GIT_OPERATION = "git_operation"  # Branch/commit restrictions
    PROVIDER_READ = "assets.provider_read"  # Read assets from cloud providers
    PROVIDER_WRITE = "assets.provider_write"  # Upload reports to providers
    PROVIDER_MANAGE = "assets.provider_manage"  # Add/remove provider connections


class EnforcementDecision(Enum):
    """Policy enforcement outcomes."""

    ALLOW = "allow"
    DENY = "deny"
    WARN = "warn"  # Allow but log warning


@dataclass
class PolicyViolation:
    """Record of a policy violation."""

    policy_id: str
    action: ActionType
    context: Dict[str, Any]
    decision: EnforcementDecision
    reason: str
    timestamp: str
    user_uuid: str
    role: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        data = asdict(self)
        data["action"] = self.action.value
        data["decision"] = self.decision.value
        return data


@dataclass
class PolicyRule:
    """Individual policy rule definition."""

    id: str
    description: str
    action_type: ActionType
    conditions: Dict[str, Any]
    enforcement: EnforcementDecision
    roles_affected: List[str]  # Empty = all roles

    def matches(self, action: ActionType, context: Dict[str, Any], role: str) -> bool:
        """Check if this rule applies to the given action + context + role."""
        # Check action type
        if action != self.action_type:
            return False

        # Check role filter
        if self.roles_affected and role not in self.roles_affected:
            return False

        # Evaluate conditions (pattern matching)
        for key, expected in self.conditions.items():
            if key not in context:
                continue  # Skip missing context keys (partial match OK)

            actual = context[key]

            # String pattern matching (wildcards)
            if isinstance(expected, str):
                if expected.startswith("*") or expected.endswith("*"):
                    if not fnmatch.fnmatch(str(actual), expected):
                        return False
                elif str(actual) != expected:
                    return False

            # List membership (e.g., flags contains "--force")
            elif isinstance(expected, list):
                if isinstance(actual, list):
                    # Check if any expected item is in actual list
                    if not any(item in actual for item in expected):
                        return False
                else:
                    if actual not in expected:
                        return False

            # Exact match for other types
            elif actual != expected:
                return False

        return True


@dataclass
class Policy:
    """Complete policy configuration."""

    version: str
    team_id: str
    rules: List[PolicyRule]
    default_enforcement: EnforcementDecision = EnforcementDecision.WARN
    metadata: Optional[Dict[str, str]] = None

    def find_matching_rules(
        self, action: ActionType, context: Dict[str, Any], role: str
    ) -> List[PolicyRule]:
        """Find all rules that match the given action + context + role."""
        return [r for r in self.rules if r.matches(action, context, role)]


class PolicyEngine:
    """
    Core policy enforcement engine.

    Loads .bpy-policy.json and enforces rules at runtime.
    Maintains violation history for audit reporting.
    """

    def __init__(self, policy_path: Path):
        self.policy_path = policy_path
        self.policy = self._load_policy(policy_path)
        self.violations: List[PolicyViolation] = []

    def _load_policy(self, path: Path) -> Policy:
        """Load and validate policy from .bpy-policy.json."""
        if not path.exists():
            # No policy = permissive mode (allow all, but still audit)
            return Policy(
                version="1.0",
                team_id="default",
                rules=[],
                default_enforcement=EnforcementDecision.ALLOW,
                metadata={"mode": "permissive", "reason": "no_policy_file"},
            )

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid policy JSON: {e}")

        # Validate required fields
        if "version" not in data:
            raise ValueError("Policy missing 'version' field")
        if "team_id" not in data:
            raise ValueError("Policy missing 'team_id' field")

        # Parse rules
        rules = []
        for r in data.get("rules", []):
            try:
                rules.append(
                    PolicyRule(
                        id=r["id"],
                        description=r["description"],
                        action_type=ActionType(r["action_type"]),
                        conditions=r["conditions"],
                        enforcement=EnforcementDecision(r["enforcement"]),
                        roles_affected=r.get("roles_affected", []),
                    )
                )
            except (KeyError, ValueError) as e:
                raise ValueError(f"Invalid rule '{r.get('id', '?')}': {e}")

        return Policy(
            version=data["version"],
            team_id=data["team_id"],
            rules=rules,
            default_enforcement=EnforcementDecision(
                data.get("default_enforcement", "warn")
            ),
            metadata=data.get("metadata", {}),
        )

    def enforce(
        self, action: ActionType, context: Dict[str, Any], user_uuid: str, role: str
    ) -> PolicyViolation:
        """
        Enforce policy for the given action.

        Returns:
            PolicyViolation with decision (ALLOW/DENY/WARN) and reason.
        """
        matching_rules = self.policy.find_matching_rules(action, context, role)

        if not matching_rules:
            # No rules matched → use default enforcement
            decision = self.policy.default_enforcement
            reason = f"No matching rules (default: {decision.value})"
        else:
            # Take strictest enforcement level (DENY > WARN > ALLOW)
            strictness_order = {
                EnforcementDecision.DENY: 3,
                EnforcementDecision.WARN: 2,
                EnforcementDecision.ALLOW: 1,
            }
            strictest = max(
                matching_rules, key=lambda r: strictness_order[r.enforcement]
            )
            decision = strictest.enforcement
            reason = f"Rule {strictest.id}: {strictest.description}"

        violation = PolicyViolation(
            policy_id=self.policy.team_id,
            action=action,
            context=context,
            decision=decision,
            reason=reason,
            timestamp=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            user_uuid=user_uuid,
            role=role,
        )

        # Log violation (even if ALLOW, for audit trail)
        self.violations.append(violation)

        return violation

    def export_violations(self, format: str = "json") -> str:
        """Export violations for audit logging."""
        if format == "json":
            return json.dumps([v.to_dict() for v in self.violations], indent=2)
        elif format == "csv":
            # CSV export (simplified)
            lines = ["timestamp,user,role,action,decision,reason"]
            for v in self.violations:
                lines.append(
                    f"{v.timestamp},{v.user_uuid},{v.role},"
                    f'{v.action.value},{v.decision.value},"{v.reason}"'
                )
            return "\n".join(lines)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def get_violation_summary(self) -> Dict[str, int]:
        """Get summary of violations by decision type."""
        summary = {"allow": 0, "deny": 0, "warn": 0, "total": len(self.violations)}

        for v in self.violations:
            summary[v.decision.value] += 1

        return summary


# Integration with audit system
def log_policy_decision(violation: PolicyViolation, auditor: Any):
    """
    Log policy decision to audit.jsonl.

    Args:
        violation: PolicyViolation to log
        auditor: AuditLog instance (from branchpy.core.audit)
    """
    auditor.emit(
        action="policy.enforce",
        args={
            "policy_id": violation.policy_id,
            "action_type": violation.action.value,
            "context": violation.context,
        },
        result={
            "decision": violation.decision.value,
            "reason": violation.reason,
            "role": violation.role,
        },
    )


class PolicyViolationError(Exception):
    """Raised when a policy violation blocks an action."""

    def __init__(self, violation: PolicyViolation):
        self.violation = violation
        super().__init__(f"Policy violation: {violation.reason}")
