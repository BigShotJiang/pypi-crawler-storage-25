"""
Policy Guards — v0.8.6
Decorator for wrapping commands with governance checks.

Usage:
    from branchpy.core.governance.guards import governed_action
    from branchpy.core.governance import ActionType

    @governed_action(ActionType.CLI_COMMAND, required_capability="stats:run")
    def stats_command(args):
        # Command implementation
        pass
"""

from __future__ import annotations

import sys
from functools import wraps
from pathlib import Path
from typing import Callable, Optional

from .policy_engine import (
    ActionType,
    EnforcementDecision,
    PolicyEngine,
    PolicyViolationError,
)
from .team_manager import PermissionDenied, TeamManager


def governed_action(
    action_type: ActionType,
    required_capability: Optional[str] = None,
    policy_path: Optional[Path] = None,
    team_path: Optional[Path] = None,
):
    """
    Decorator to enforce governance on CLI commands.

    Args:
        action_type: Type of action being governed
        required_capability: RBAC capability required (e.g., "stats:run")
        policy_path: Path to policy.json (default: .branchpy/policy.json)
        team_path: Path to team.toml (default: .branchpy/team.toml)

    Usage:
        @governed_action(ActionType.CLI_COMMAND, required_capability="stats:run")
        def stats_command(args):
            # Command implementation
            pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Resolve paths
            proj_root = Path(".").resolve()
            _policy_path = policy_path or proj_root / ".branchpy" / "policy.json"
            _team_path = team_path or proj_root / ".branchpy" / "team.toml"

            # Resolve identity + role
            try:
                from branchpy.core.identity import resolve_identity

                identity = resolve_identity()
            except Exception as e:
                # If identity resolution fails, use fallback
                print(f"⚠️  Warning: Could not resolve identity: {e}")
                print("   Proceeding with limited governance enforcement")
                return func(*args, **kwargs)

            team_mgr = TeamManager(_team_path)
            role = team_mgr.get_role(identity.user.user_uuid)

            # Check RBAC capability if specified
            if required_capability:
                if not team_mgr.has_capability(role, required_capability):
                    # Log RBAC denial to governance
                    try:
                        from .logger import GovernanceLogger

                        gov_logger = GovernanceLogger()
                        gov_logger.log_rbac_denied(
                            capability=required_capability,
                            user_role=role,
                            command=func.__name__,
                            reason=f"Capability '{required_capability}' not granted to role '{role}'",
                            user_uuid=identity.user.user_uuid,
                        )
                    except Exception as e:
                        gov_logger.warning(f"Failed to log RBAC denial: {e}")

                    # Import fallback suggestion system
                    try:
                        from .denial_suggestions import format_denial_message

                        error_msg = format_denial_message(
                            capability=required_capability,
                            user_role=role,
                            command=func.__name__,
                            include_suggestion=True,
                        )
                    except ImportError:
                        # Fallback if denial_suggestions not available
                        error_msg = (
                            f"\n❌ Permission denied: '{required_capability}' capability required\n"
                            f"   Your role: {role}\n"
                            f"   Required capabilities: {required_capability}\n"
                        )
                    print(error_msg, file=sys.stderr)
                    sys.exit(65)  # RBAC violation exit code

            # Check policy
            policy_engine = PolicyEngine(_policy_path)
            decision = policy_engine.enforce(
                action=action_type,
                context={
                    "function": func.__name__,
                    "args": str(args),
                    "kwargs": str(kwargs),
                },
                user_uuid=identity.user.user_uuid,
                role=role,
            )

            # Log governance event (if structured logging available)
            try:
                from branchpy.core.logs.structured_log import (
                    PolicyContext,
                    emit_governance_event,
                )

                emit_governance_event(
                    event_type="governance.enforced",
                    action=func.__name__,
                    context=PolicyContext(
                        role=role,
                        enforcement_decision=decision.decision.value,
                        policy_id=decision.policy_id,
                    ),
                )
            except ImportError:
                pass  # Structured logging not available

            # Enforce decision
            if decision.decision == EnforcementDecision.DENY:
                error_msg = (
                    f"\n❌ Policy violation: {decision.reason}\n"
                    f"   Your role: {role}\n"
                    f"   Policy: {decision.policy_id}\n"
                )
                print(error_msg, file=sys.stderr)
                sys.exit(66)  # Policy violation exit code

            elif decision.decision == EnforcementDecision.WARN:
                print(f"⚠️  Policy warning: {decision.reason}")

            # Execute command
            return func(*args, **kwargs)

        return wrapper

    return decorator


def require_capability(capability: str):
    """
    Simple decorator to check RBAC capability with intelligent fallback suggestions.

    Usage:
        @require_capability("audit_verify")
        def verify_command(args):
            pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            proj_root = Path(".").resolve()
            team_path = proj_root / ".branchpy" / "team.toml"

            try:
                from branchpy.core.identity import resolve_identity

                identity = resolve_identity()
            except Exception as e:
                print(f"⚠️  Warning: Could not resolve identity: {e}")
                return func(*args, **kwargs)

            team_mgr = TeamManager(team_path)
            role = team_mgr.get_role(identity.user.user_uuid)

            if not team_mgr.has_capability(role, capability):
                # Log RBAC denial to governance
                try:
                    from .logger import GovernanceLogger

                    gov_logger = GovernanceLogger()
                    gov_logger.log_rbac_denied(
                        capability=capability,
                        user_role=role,
                        command=func.__name__,
                        reason=f"Capability '{capability}' not granted to role '{role}'",
                        user_uuid=identity.user.user_uuid,
                    )
                except Exception as e:
                    import logging

                    logging.getLogger(__name__).warning(
                        f"Failed to log RBAC denial: {e}"
                    )

                # Import fallback suggestion system
                try:
                    from .denial_suggestions import format_denial_message

                    error_msg = format_denial_message(
                        capability=capability,
                        user_role=role,
                        command=func.__name__,
                        include_suggestion=True,
                    )
                except ImportError:
                    # Fallback if denial_suggestions not available
                    error_msg = (
                        f"\n❌ Permission denied: '{capability}' capability required\n"
                        f"   Your role: {role}\n"
                    )

                print(error_msg, file=sys.stderr)
                sys.exit(65)

            return func(*args, **kwargs)

        return wrapper

    return decorator


class GovernanceContext:
    """
    Context manager for governance-aware operations.

    Usage:
        with GovernanceContext(action_type=ActionType.FILE_ACCESS) as gov:
            gov.check_policy(context={"path": "sensitive.txt", "operation": "read"})
            # Perform operation
    """

    def __init__(
        self,
        action_type: ActionType,
        policy_path: Optional[Path] = None,
        team_path: Optional[Path] = None,
    ):
        self.action_type = action_type
        proj_root = Path(".").resolve()
        self.policy_path = policy_path or proj_root / ".branchpy" / "policy.json"
        self.team_path = team_path or proj_root / ".branchpy" / "team.toml"

        self.policy_engine = None
        self.team_mgr = None
        self.identity = None
        self.role = None

    def __enter__(self):
        """Initialize governance context."""
        try:
            from branchpy.core.identity import resolve_identity

            self.identity = resolve_identity()
        except Exception:
            self.identity = None

        self.policy_engine = PolicyEngine(self.policy_path)
        self.team_mgr = TeamManager(self.team_path)

        if self.identity:
            self.role = self.team_mgr.get_role(self.identity.user.user_uuid)
        else:
            self.role = "owner"  # Fallback for solo mode

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Clean up governance context."""
        pass

    def check_policy(self, context: dict) -> bool:
        """
        Check policy for current action.

        Returns:
            True if allowed, False if denied

        Raises:
            PolicyViolationError if policy denies action
        """
        if not self.identity or not self.policy_engine:
            return True  # Permissive fallback

        decision = self.policy_engine.enforce(
            action=self.action_type,
            context=context,
            user_uuid=self.identity.user.user_uuid,
            role=self.role,
        )

        if decision.decision == EnforcementDecision.DENY:
            raise PolicyViolationError(decision)
        elif decision.decision == EnforcementDecision.WARN:
            print(f"⚠️  Policy warning: {decision.reason}")

        return True

    def check_capability(self, capability: str) -> bool:
        """
        Check if user has required capability.

        Returns:
            True if user has capability

        Raises:
            PermissionDenied if user lacks capability
        """
        if not self.team_mgr or not self.role:
            return True  # Permissive fallback

        if not self.team_mgr.has_capability(self.role, capability):
            raise PermissionDenied(capability, self.role)

        return True
