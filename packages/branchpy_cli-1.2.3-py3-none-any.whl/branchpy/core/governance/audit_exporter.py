"""
Audit Log Exporter — v0.8.6
Export audit logs to JSON/CSV/PDF for compliance reporting.

Usage:
    from branchpy.core.governance import AuditExporter
    from branchpy.core.audit import AuditLog

    audit_log = AuditLog(Path(".branchpy/audit.jsonl"))
    entries = list(audit_log.read_entries())

    exporter = AuditExporter(entries)
    exporter.export_json(Path("audit-export.json"))
    exporter.export_csv(Path("audit-export.csv"))
    exporter.export_pdf(Path("audit-report.pdf"))
"""

from __future__ import annotations

import csv
import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


class AuditExporter:
    """Export audit logs to various formats."""

    def __init__(self, audit_entries: List[Any]):
        """
        Initialize exporter with audit entries.

        Args:
            audit_entries: List of AuditEntryModel instances
        """
        self.entries = audit_entries

    def export_json(self, output_path: Path, pretty: bool = True):
        """
        Export to JSON format.

        Args:
            output_path: Path to output file
            pretty: Pretty-print with indentation
        """
        data = []
        for e in self.entries:
            # Convert dataclass to dict
            entry_dict = asdict(e) if hasattr(e, "__dataclass_fields__") else e.__dict__
            data.append(entry_dict)

        with open(output_path, "w", encoding="utf-8") as f:
            if pretty:
                json.dump(data, f, indent=2, default=str)
            else:
                json.dump(data, f, default=str)

        print(f"✅ Exported {len(self.entries)} entries to {output_path}")

    def export_csv(self, output_path: Path):
        """
        Export to CSV format.

        Args:
            output_path: Path to output file
        """
        if not self.entries:
            print("⚠️  No entries to export")
            return

        # Flatten nested structures for CSV
        rows = []
        for entry in self.entries:
            # Handle both dataclass and regular objects
            if hasattr(entry, "__dataclass_fields__"):
                e = asdict(entry)
            else:
                e = entry.__dict__

            row = {
                "seq": e.get("seq", ""),
                "timestamp": e.get("time_utc", ""),
                "user_uuid": e.get("user_uuid", ""),
                "user_name": e.get("user_name") or "",
                "user_email": e.get("user_email") or "",
                "hostname": e.get("hostname") or "",
                "action": e.get("action", ""),
                "args": json.dumps(e.get("args")) if e.get("args") else "",
                "result": json.dumps(e.get("result")) if e.get("result") else "",
                "hash": e.get("hash", ""),
                "prev_hash": e.get("prev_hash", ""),
            }
            rows.append(row)

        with open(output_path, "w", encoding="utf-8", newline="") as f:
            fieldnames = rows[0].keys()
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        print(f"✅ Exported {len(rows)} entries to {output_path}")

    def export_pdf(
        self,
        output_path: Path,
        metadata: Optional[Dict[str, str]] = None,
        max_entries: int = 100,
    ):
        """
        Export to PDF format (formatted governance report).

        Requires: reportlab (optional dependency)

        Args:
            output_path: Path to output file
            metadata: Optional report metadata (team_name, date_range, etc.)
            max_entries: Maximum entries to include in PDF (default 100)
        """
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import inch
            from reportlab.platypus import (
                PageBreak,
                Paragraph,
                SimpleDocTemplate,
                Spacer,
                Table,
                TableStyle,
            )
        except ImportError:
            print("❌ PDF export requires 'reportlab' package")
            print("   Install with: pip install reportlab")
            return

        doc = SimpleDocTemplate(str(output_path), pagesize=letter)
        story = []
        styles = getSampleStyleSheet()

        # Title
        title = Paragraph("<b>BranchPy Audit Report</b>", styles["Title"])
        story.append(title)
        story.append(Spacer(1, 0.2 * inch))

        # Metadata section
        if metadata:
            meta_text = f"""
            <b>Team:</b> {metadata.get('team_name', 'N/A')}<br/>
            <b>Period:</b> {metadata.get('date_range', 'All time')}<br/>
            <b>Generated:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}<br/>
            <b>Total Entries:</b> {len(self.entries)}<br/>
            <b>Included in Report:</b> {min(len(self.entries), max_entries)}
            """
            meta = Paragraph(meta_text, styles["Normal"])
            story.append(meta)
            story.append(Spacer(1, 0.3 * inch))

        # Summary statistics
        summary = self._generate_summary()
        summary_text = f"""
        <b>Summary Statistics:</b><br/>
        • Unique Users: {summary['unique_users']}<br/>
        • Unique Actions: {summary['unique_actions']}<br/>
        • Date Range: {summary['date_range']}<br/>
        • Success Rate: {summary['success_rate']:.1%}
        """
        story.append(Paragraph(summary_text, styles["Normal"]))
        story.append(Spacer(1, 0.3 * inch))

        # Audit entries table
        table_data = [["Seq", "Timestamp", "User", "Action", "Status"]]

        for entry in self.entries[:max_entries]:
            # Handle both dataclass and regular objects
            if hasattr(entry, "__dataclass_fields__"):
                e = asdict(entry)
            else:
                e = entry.__dict__

            # Determine status icon
            result = e.get("result", {})
            if isinstance(result, dict):
                success = result.get("success", True)
            else:
                success = True
            status_icon = "✅" if success else "⚠️"

            table_data.append(
                [
                    str(e.get("seq", "")),
                    e.get("time_utc", "")[:19],  # Truncate timestamp
                    (e.get("user_name") or e.get("user_uuid", "")[:8])[:20],
                    e.get("action", "")[:30],
                    status_icon,
                ]
            )

        table = Table(
            table_data,
            colWidths=[0.5 * inch, 1.5 * inch, 2 * inch, 2.5 * inch, 0.5 * inch],
        )
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                ]
            )
        )

        story.append(table)

        # Note if truncated
        if len(self.entries) > max_entries:
            story.append(Spacer(1, 0.2 * inch))
            note = Paragraph(
                f"<i>Note: Report limited to first {max_entries} entries. "
                f"Full export contains {len(self.entries)} entries.</i>",
                styles["Normal"],
            )
            story.append(note)

        # Build PDF
        doc.build(story)
        print(f"✅ Exported {len(self.entries)} entries to {output_path}")
        print(f"   (PDF limited to first {max_entries} entries)")

    def _generate_summary(self) -> Dict[str, Any]:
        """Generate summary statistics from audit entries."""
        if not self.entries:
            return {
                "unique_users": 0,
                "unique_actions": 0,
                "date_range": "N/A",
                "success_rate": 0.0,
            }

        users = set()
        actions = set()
        timestamps = []
        successes = 0
        total = 0

        for entry in self.entries:
            # Handle both dataclass and regular objects
            if hasattr(entry, "__dataclass_fields__"):
                e = asdict(entry)
            else:
                e = entry.__dict__

            users.add(e.get("user_uuid", ""))
            actions.add(e.get("action", ""))
            timestamps.append(e.get("time_utc", ""))

            result = e.get("result", {})
            if isinstance(result, dict) and result.get("success", True):
                successes += 1
            total += 1

        # Date range
        timestamps = [t for t in timestamps if t]
        if timestamps:
            date_range = f"{min(timestamps)[:10]} to {max(timestamps)[:10]}"
        else:
            date_range = "N/A"

        return {
            "unique_users": len(users),
            "unique_actions": len(actions),
            "date_range": date_range,
            "success_rate": successes / total if total > 0 else 0.0,
        }


def export_audit_command(args):
    """
    CLI handler for 'branchpy audit export' command.

    This would be registered in branchpy/cli/audit_cmd.py
    """
    from pathlib import Path

    # Import audit system
    try:
        from branchpy.core.audit import AuditLog
    except ImportError:
        print("❌ Audit system not available")
        return

    proj_root = Path(".").resolve()
    audit_log_path = proj_root / ".branchpy" / "audit.jsonl"

    if not audit_log_path.exists():
        print(f"⚠️  No audit log found at {audit_log_path}")
        return

    # Read entries
    audit_log = AuditLog(audit_log_path)
    entries = list(audit_log.read_entries())

    if not entries:
        print("⚠️  No audit entries found")
        return

    # Export
    exporter = AuditExporter(entries)
    output_path = Path(args.output)

    if args.format == "json":
        exporter.export_json(output_path, pretty=not getattr(args, "compact", False))
    elif args.format == "csv":
        exporter.export_csv(output_path)
    elif args.format == "pdf":
        # Load team metadata if available
        metadata = {}
        team_toml = proj_root / ".branchpy" / "team.toml"
        if team_toml.exists():
            try:
                from branchpy.core.governance.team_manager import TeamManager

                team = TeamManager(team_toml)
                info = team.get_team_info()
                metadata["team_name"] = info.get("name", "Unknown")
            except Exception:
                pass

        metadata["date_range"] = "All time"
        exporter.export_pdf(output_path, metadata)
    else:
        print(f"❌ Unsupported format: {args.format}")
