"""
BranchPy Governance Toolkit — v0.8.6

Core governance infrastructure:
- Policy enforcement engine
- Session certificates
- Team management
- Audit export
- History event logging

Part of Axis 4: Collaboration & Governance
"""

from .audit_exporter import AuditExporter
from .certificates import CertificateManager, SessionCertificate
from .logger import GovernanceLogger
from .policy_engine import (
    ActionType,
    EnforcementDecision,
    Policy,
    PolicyEngine,
    PolicyRule,
    PolicyViolation,
)
from .team_manager import TeamManager

__all__ = [
    # Policy Engine
    "PolicyEngine",
    "Policy",
    "PolicyRule",
    "PolicyViolation",
    "ActionType",
    "EnforcementDecision",
    # Certificates
    "SessionCertificate",
    "CertificateManager",
    # Team Management
    "TeamManager",
    # Audit Export
    "AuditExporter",
    # History Logging
    "GovernanceLogger",
]

__version__ = "0.8.6"
