"""
RBAC Denial History Storage — Phase 4 Advanced UX

Persistent storage for RBAC denial events, allowing users to review
past access denials and track patterns over time.

Storage:
    - Location: `.branchpy/denial_history.jsonl`
    - Format: JSON Lines (one event per line)
    - Retention: Last 1000 denial events (configurable)
    - Persistence: Across VS Code sessions

Usage:
    from branchpy.core.governance.denial_history import DenialHistoryStore

    store = DenialHistoryStore()
    store.add_denial(
        capability="image.validation.run",
        user_role="viewer",
        command="validate images",
        reason="capability_missing"
    )

    recent_denials = store.get_recent_denials(limit=50)
    for denial in recent_denials:
        print(f"{denial.timestamp}: {denial.capability} denied for {denial.user_role}")
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import portalocker

logger = logging.getLogger(__name__)


class DenialActionTaken(Enum):
    """Actions user took after denial"""

    ABORTED = "aborted"  # User cancelled operation
    REQUESTED_ACCESS = "requested_access"  # User requested elevated access
    USED_ALTERNATIVE = "used_alternative"  # User tried alternative command
    EXPORTED_DATA = "exported_data"  # User exported data instead
    CONTACTED_ADMIN = "contacted_admin"  # User contacted administrator
    IGNORED = "ignored"  # User took no action
    UNKNOWN = "unknown"  # Action not tracked


@dataclass
class DenialEvent:
    """
    Single RBAC denial event.

    Attributes:
        timestamp: ISO 8601 timestamp when denial occurred
        capability: Capability that was denied (e.g., "image.validation.run")
        user_role: User's role at time of denial (e.g., "viewer")
        user_uuid: User's UUID for tracking
        command: Command or operation that was attempted
        reason: Reason for denial (e.g., "capability_missing", "policy_violation")
        correlation_id: Optional correlation ID linking related events
        action_taken: Action user took after denial
        context: Additional context (project path, file, etc.)
    """

    timestamp: str
    capability: str
    user_role: str
    user_uuid: str
    command: Optional[str] = None
    reason: Optional[str] = None
    correlation_id: Optional[str] = None
    action_taken: DenialActionTaken = DenialActionTaken.UNKNOWN
    context: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        data = asdict(self)
        data["action_taken"] = self.action_taken.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> DenialEvent:
        """Create from dictionary (JSON deserialization)."""
        # Convert action_taken string to enum
        if "action_taken" in data and isinstance(data["action_taken"], str):
            data["action_taken"] = DenialActionTaken(data["action_taken"])
        return cls(**data)


class DenialHistoryStore:
    """
    Persistent storage for RBAC denial events.

    Thread-safe file-based storage using JSON Lines format.
    Automatically prunes old events to maintain size limits.
    """

    DEFAULT_PATH = Path(".branchpy") / "denial_history.jsonl"
    MAX_EVENTS = 1000  # Keep last 1000 denial events

    def __init__(
        self, storage_path: Optional[Path] = None, max_events: int = MAX_EVENTS
    ):
        """
        Initialize denial history store.

        Args:
            storage_path: Path to JSONL file (default: .branchpy/denial_history.jsonl)
            max_events: Maximum events to retain (default: 1000)
        """
        self.storage_path = storage_path or self.DEFAULT_PATH
        self.max_events = max_events

        # Ensure directory exists
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

        # Create empty file if doesn't exist
        if not self.storage_path.exists():
            self.storage_path.touch()

    def add_denial(
        self,
        capability: str,
        user_role: str,
        user_uuid: str,
        command: Optional[str] = None,
        reason: Optional[str] = None,
        correlation_id: Optional[str] = None,
        action_taken: DenialActionTaken = DenialActionTaken.UNKNOWN,
        context: Optional[Dict[str, Any]] = None,
    ) -> DenialEvent:
        """
        Add new denial event to history with automatic retry.

        Will retry lock acquisition with exponential backoff for up to
        30 seconds. Raises LockException only if unable to acquire lock
        within the maximum wait time.

        Args:
            capability: Capability that was denied
            user_role: User's role at time of denial
            user_uuid: User's UUID
            command: Command or operation that was attempted
            reason: Reason for denial
            correlation_id: Optional correlation ID
            action_taken: Action user took after denial
            context: Additional context

        Returns:
            DenialEvent that was added

        Raises:
            portalocker.LockException: If unable to acquire lock within 30 seconds
        """
        event = DenialEvent(
            timestamp=datetime.utcnow().isoformat() + "Z",
            capability=capability,
            user_role=user_role,
            user_uuid=user_uuid,
            command=command,
            reason=reason,
            correlation_id=correlation_id,
            action_taken=action_taken,
            context=context,
        )

        # Retry with exponential backoff for up to 30 seconds
        self._write_with_retry(
            lambda f: f.write(json.dumps(event.to_dict()) + "\n"),
            mode="a",
            max_wait_time=30,
        )

        # Prune if over limit
        self._prune_if_needed()

        return event

    def _write_with_retry(
        self,
        write_fn,
        mode: str = "a",
        max_wait_time: int = 30,
        lock_timeout: int = 2,
    ) -> None:
        """
        Write to file with retry logic and exponential backoff.

        Args:
            write_fn: Callable that takes file handle and performs write
            mode: File open mode ('a' for append, 'w' for write)
            max_wait_time: Maximum total time to retry (seconds)
            lock_timeout: Timeout per lock acquisition attempt (seconds)

        Raises:
            portalocker.LockException: If unable to acquire lock within max_wait_time
        """
        start_time = time.time()
        attempt = 0

        while True:
            try:
                with open(self.storage_path, mode) as f:
                    portalocker.lock(f, portalocker.LOCK_EX | portalocker.LOCK_NB)
                    try:
                        write_fn(f)
                        return  # Success!
                    finally:
                        portalocker.unlock(f)

            except portalocker.LockException:
                attempt += 1
                elapsed = time.time() - start_time

                # Check if we've exceeded maximum wait time
                if elapsed >= max_wait_time:
                    logger.error(
                        f"Failed to acquire lock on {self.storage_path} after {max_wait_time}s "
                        f"({attempt} attempts)"
                    )
                    raise  # Give up - something is seriously wrong

                # Exponential backoff: 0.1s, 0.2s, 0.4s, 0.8s, 1.6s...
                # But cap at 2 seconds between attempts
                backoff = min(0.1 * (2**attempt), 2.0)

                # Don't sleep longer than remaining time
                remaining = max_wait_time - elapsed
                sleep_time = min(backoff, remaining)

                if sleep_time > 0:
                    logger.debug(
                        f"Lock acquisition failed (attempt {attempt}), "
                        f"retrying in {sleep_time:.2f}s"
                    )
                    time.sleep(sleep_time)

    def get_recent_denials(
        self,
        limit: int = 50,
        capability_filter: Optional[str] = None,
        role_filter: Optional[str] = None,
        user_filter: Optional[str] = None,
    ) -> List[DenialEvent]:
        """
        Get recent denial events, optionally filtered.

        Args:
            limit: Maximum number of events to return
            capability_filter: Filter by capability (e.g., "image.validation.run")
            role_filter: Filter by role (e.g., "viewer")
            user_filter: Filter by user UUID

        Returns:
            List of DenialEvent objects, newest first
        """
        events = self._read_all_events()

        # Apply filters
        if capability_filter:
            events = [e for e in events if e.capability == capability_filter]
        if role_filter:
            events = [e for e in events if e.user_role == role_filter]
        if user_filter:
            events = [e for e in events if e.user_uuid == user_filter]

        # Return newest first, limited
        events.reverse()  # Reverse to get newest first (file is oldest→newest)
        return events[:limit]

    def get_denial_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about denial history.

        Returns:
            Dictionary with statistics:
                - total_denials: Total number of denials
                - denials_by_capability: Count by capability
                - denials_by_role: Count by role
                - denials_by_reason: Count by reason
                - most_common_capability: Most frequently denied capability
                - most_common_role: Role with most denials
        """
        events = self._read_all_events()

        if not events:
            return {
                "total_denials": 0,
                "denials_by_capability": {},
                "denials_by_role": {},
                "denials_by_reason": {},
                "most_common_capability": None,
                "most_common_role": None,
            }

        # Count by capability
        by_capability: Dict[str, int] = {}
        for event in events:
            by_capability[event.capability] = by_capability.get(event.capability, 0) + 1

        # Count by role
        by_role: Dict[str, int] = {}
        for event in events:
            by_role[event.user_role] = by_role.get(event.user_role, 0) + 1

        # Count by reason
        by_reason: Dict[str, int] = {}
        for event in events:
            reason = event.reason or "unknown"
            by_reason[reason] = by_reason.get(reason, 0) + 1

        # Find most common
        most_common_capability = (
            max(by_capability.items(), key=lambda x: x[1])[0] if by_capability else None
        )
        most_common_role = (
            max(by_role.items(), key=lambda x: x[1])[0] if by_role else None
        )

        return {
            "total_denials": len(events),
            "denials_by_capability": by_capability,
            "denials_by_role": by_role,
            "denials_by_reason": by_reason,
            "most_common_capability": most_common_capability,
            "most_common_role": most_common_role,
        }

    def update_action_taken(
        self, event_index: int, action_taken: DenialActionTaken
    ) -> bool:
        """
        Update action_taken field for a specific denial event.

        Args:
            event_index: Index of event to update (0 = most recent)
            action_taken: New action_taken value

        Returns:
            True if updated successfully, False if index out of range
        """
        events = self._read_all_events()

        # Reverse to get newest first, apply index
        events.reverse()

        if event_index >= len(events):
            return False

        events[event_index].action_taken = action_taken

        # Reverse back to oldest→newest for writing
        events.reverse()

        # Write all events back with retry
        self._write_with_retry(
            lambda f: f.writelines(json.dumps(e.to_dict()) + "\n" for e in events),
            mode="w",
            max_wait_time=30,
        )

        return True

    def clear_history(self) -> int:
        """
        Clear all denial history.

        Returns:
            Number of events cleared
        """
        events = self._read_all_events()
        count = len(events)

        # Truncate file with retry
        self._write_with_retry(
            lambda f: None,  # Write nothing (clear file)
            mode="w",
            max_wait_time=30,
        )

        return count

    def _read_all_events(self) -> List[DenialEvent]:
        """Read all events from storage file with retry."""
        events = []

        if not self.storage_path.exists():
            return events

        # Retry read with exponential backoff
        start_time = time.time()
        attempt = 0
        max_wait_time = 30
        lock_timeout = 2

        while True:
            try:
                with open(self.storage_path, "r") as f:
                    portalocker.lock(f, portalocker.LOCK_SH, timeout=lock_timeout)
                    try:
                        for line in f:
                            line = line.strip()
                            if line:
                                try:
                                    data = json.loads(line)
                                    events.append(DenialEvent.from_dict(data))
                                except (json.JSONDecodeError, TypeError, ValueError):
                                    # Skip malformed lines
                                    continue
                        return events  # Success!
                    finally:
                        portalocker.unlock(f)

            except portalocker.LockException:
                attempt += 1
                elapsed = time.time() - start_time

                if elapsed >= max_wait_time:
                    logger.error(
                        f"Failed to acquire read lock on {self.storage_path} after {max_wait_time}s"
                    )
                    raise

                backoff = min(0.1 * (2**attempt), 2.0)
                remaining = max_wait_time - elapsed
                sleep_time = min(backoff, remaining)

                if sleep_time > 0:
                    logger.debug(
                        f"Read lock acquisition failed (attempt {attempt}), "
                        f"retrying in {sleep_time:.2f}s"
                    )
                    time.sleep(sleep_time)

    def _prune_if_needed(self) -> None:
        """Prune old events if over max_events limit."""
        events = self._read_all_events()

        if len(events) <= self.max_events:
            return  # No pruning needed

        # Keep only most recent max_events
        events_to_keep = events[len(events) - self.max_events :]

        # Write pruned events back with retry
        self._write_with_retry(
            lambda f: f.writelines(
                json.dumps(e.to_dict()) + "\n" for e in events_to_keep
            ),
            mode="w",
            max_wait_time=30,
        )
