"""
Session Certificates — v0.8.6
Generate and validate short-lived signed tokens for authenticated operations.

Usage:
    from branchpy.core.governance import CertificateManager

    cert_mgr = CertificateManager(Path(".branchpy/session"), secret_key)
    cert = cert_mgr.issue("user-123", "contributor", scope="cli")

    is_valid, reason, loaded_cert = cert_mgr.validate(cert.session_id)
    if not is_valid:
        raise AuthenticationError(reason)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Tuple


@dataclass
class SessionCertificate:
    """Short-lived authentication token."""

    user_id: str
    role: str
    scope: str  # e.g., "cli" | "daemon" | "api"
    issued_at: str  # ISO 8601 UTC
    expires_at: str
    session_id: str
    signature: str  # HMAC-SHA256 signature

    def is_valid(self, secret_key: bytes) -> Tuple[bool, str]:
        """
        Validate certificate signature and expiration.

        Returns:
            (is_valid, reason) tuple
        """
        # Check expiration
        try:
            expires = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
            if datetime.now(timezone.utc) > expires:
                return False, "Certificate expired"
        except ValueError:
            return False, "Invalid expiration timestamp"

        # Verify signature
        payload = self._get_payload()
        expected_sig = self._compute_signature(payload, secret_key)

        if not hmac.compare_digest(self.signature, expected_sig):
            return False, "Invalid signature"

        return True, "Valid"

    def _get_payload(self) -> bytes:
        """Get canonical payload for signing."""
        data = {
            "user_id": self.user_id,
            "role": self.role,
            "scope": self.scope,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "session_id": self.session_id,
        }
        return json.dumps(data, sort_keys=True).encode("utf-8")

    def _compute_signature(self, payload: bytes, secret_key: bytes) -> str:
        """Compute HMAC-SHA256 signature."""
        return hmac.new(secret_key, payload, hashlib.sha256).hexdigest()

    @classmethod
    def issue(
        cls,
        user_id: str,
        role: str,
        scope: str,
        secret_key: bytes,
        ttl_minutes: int = 60,
    ) -> SessionCertificate:
        """Issue a new session certificate."""
        now = datetime.now(timezone.utc)
        issued_at = now.isoformat().replace("+00:00", "Z")
        expires_at = (
            (now + timedelta(minutes=ttl_minutes)).isoformat().replace("+00:00", "Z")
        )
        session_id = secrets.token_urlsafe(16)

        cert = cls(
            user_id=user_id,
            role=role,
            scope=scope,
            issued_at=issued_at,
            expires_at=expires_at,
            session_id=session_id,
            signature="",  # Placeholder
        )

        # Compute signature
        payload = cert._get_payload()
        cert.signature = cert._compute_signature(payload, secret_key)

        return cert

    def to_file(self, path: Path):
        """Save certificate to .bpy-cert file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def from_file(cls, path: Path) -> SessionCertificate:
        """Load certificate from .bpy-cert file."""
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(**data)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return asdict(self)


class CertificateManager:
    """Manage session certificates for team operations."""

    def __init__(self, cert_dir: Path, secret_key: bytes):
        self.cert_dir = cert_dir
        self.secret_key = secret_key
        self.cert_dir.mkdir(parents=True, exist_ok=True)

    def issue(
        self, user_id: str, role: str, scope: str = "cli", ttl_minutes: int = 60
    ) -> SessionCertificate:
        """Issue a new certificate and save to disk."""
        cert = SessionCertificate.issue(
            user_id, role, scope, self.secret_key, ttl_minutes=ttl_minutes
        )
        cert_path = self.cert_dir / f"{cert.session_id}.bpy-cert"
        cert.to_file(cert_path)
        return cert

    def validate(
        self, session_id: str
    ) -> Tuple[bool, str, Optional[SessionCertificate]]:
        """
        Validate a certificate by session ID.

        Returns:
            (is_valid, reason, certificate) tuple
        """
        cert_path = self.cert_dir / f"{session_id}.bpy-cert"

        if not cert_path.exists():
            return False, "Certificate not found", None

        try:
            cert = SessionCertificate.from_file(cert_path)
        except (json.JSONDecodeError, TypeError) as e:
            return False, f"Corrupted certificate: {e}", None

        is_valid, reason = cert.is_valid(self.secret_key)

        if not is_valid:
            return False, reason, cert

        return True, "Valid", cert

    def revoke(self, session_id: str) -> bool:
        """Revoke a certificate by deleting it."""
        cert_path = self.cert_dir / f"{session_id}.bpy-cert"
        if cert_path.exists():
            cert_path.unlink()
            return True
        return False

    def cleanup_expired(self) -> int:
        """Remove expired certificates. Returns count of deleted certs."""
        count = 0
        for cert_file in self.cert_dir.glob("*.bpy-cert"):
            try:
                cert = SessionCertificate.from_file(cert_file)
                is_valid, _ = cert.is_valid(self.secret_key)
                if not is_valid:
                    cert_file.unlink()
                    count += 1
            except Exception:
                pass  # Skip corrupted files
        return count

    def list_active(self) -> list[SessionCertificate]:
        """List all active (non-expired) certificates."""
        active = []
        for cert_file in self.cert_dir.glob("*.bpy-cert"):
            try:
                cert = SessionCertificate.from_file(cert_file)
                is_valid, _ = cert.is_valid(self.secret_key)
                if is_valid:
                    active.append(cert)
            except Exception:
                pass  # Skip corrupted files
        return active


def load_or_create_secret_key(key_file: Path) -> bytes:
    """
    Load secret key from file, or generate new one if missing.

    Args:
        key_file: Path to .cert_secret file

    Returns:
        32-byte secret key
    """
    if key_file.exists():
        return key_file.read_bytes()
    else:
        # Generate new 32-byte (256-bit) secret
        secret = secrets.token_bytes(32)

        # Ensure parent directory exists
        key_file.parent.mkdir(parents=True, exist_ok=True)

        # Write with restricted permissions
        key_file.write_bytes(secret)

        # Set permissions to 0600 (owner read/write only)
        try:
            import os

            os.chmod(key_file, 0o600)
        except Exception:
            pass  # Windows may not support chmod

        return secret
