"""
Governance Event Schemas — v0.8.6
Standard governance event schemas for structured logging.

These schemas define the events emitted by the governance system
for cross-system integration and audit trail consistency.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional


@dataclass
class PolicyContext:
    """Governance context for structured logs."""

    role: Optional[str] = None
    session_id: Optional[str] = None
    enforcement_decision: Optional[str] = None  # allow/deny/warn
    policy_id: Optional[str] = None
    correlation_id: Optional[str] = None  # Link to audit entry

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class GovernanceEvent:
    """Base governance event."""

    event_type: str  # governance.enforced | policy.violation | audit.recorded
    action: str
    user_uuid: str
    role: str
    timestamp: str

    # Policy context
    policy_id: Optional[str] = None
    enforcement_decision: Optional[str] = None  # allow/deny/warn

    # Audit linkage
    correlation_id: Optional[str] = None  # Links to audit.jsonl entry
    audit_seq: Optional[int] = None

    # Additional metadata
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


# Standard event types
EVENT_GOVERNANCE_ENFORCED = "governance.enforced"  # Policy check completed
EVENT_POLICY_VIOLATION = "policy.violation"  # Rule violated (deny/warn)
EVENT_AUDIT_RECORDED = "audit.recorded"  # Action logged to audit.jsonl
EVENT_RBAC_CHECK = "rbac.capability_check"  # Role capability verified
EVENT_CERT_ISSUED = "cert.issued"  # Session certificate created
EVENT_CERT_REVOKED = "cert.revoked"  # Session certificate revoked

# Module-specific event types
EVENT_STATS_COMPUTED = "stats.computed"  # Stats analysis completed
EVENT_SAE_ANALYZED = "sae.analyzed"  # SAE analysis completed
EVENT_MEDIA_VALIDATED = "media.validated"  # Image validation completed
EVENT_MEDIA_REPLACED = "media.replaced"  # Image replacement performed
EVENT_L10N_COVERAGE_CHECK = "l10n.coverage_check"  # L10n coverage audit
EVENT_L10N_VIOLATION = "l10n.violation"  # L10n policy violation
EVENT_PATCH_APPLIED = "patch.applied"  # Patch applied to codebase
EVENT_AUDIT_REVERT = "audit.revert"  # Audit entry reverted (undo)
EVENT_GIT_SAFEGUARD_CHECK = "git.safeguard_check"  # Pre-commit/push check
EVENT_POLICY_GIT_ENFORCE = "policy.git_enforce"  # Git policy enforcement
EVENT_DAEMON_SESSION_START = "daemon.session_start"  # Daemon session started
EVENT_API_POLICY_CHECK = "api.policy_check"  # API request policy check
EVENT_TEST_EXECUTED = "test.executed"  # Test execution
EVENT_TEST_RESULT = "test.result"  # Test result recorded
EVENT_RENDER_GENERATED = "render.generated"  # Render output generated

# AI-specific event types (v0.9.5)
EVENT_AI_CALL_START = "ai.call_start"  # AI provider call initiated
EVENT_AI_CALL_END = "ai.call_end"  # AI provider call completed
EVENT_AI_CALL_ERROR = "ai.call_error"  # AI provider call failed


# Structured logging integration (if available)
def emit_governance_event(
    event_type: str,
    action: str,
    context: PolicyContext,
    metadata: Optional[Dict[str, Any]] = None,
):
    """
    Emit governance-specific structured log event.

    This function attempts to use the structured logging system if available,
    otherwise falls back to simple print.

    Args:
        event_type: Type of governance event
        action: Action being performed
        context: Policy context (role, decision, etc.)
        metadata: Additional event metadata
    """
    try:
        from branchpy.core.logs import structured_log

        structured_log.log_event(
            level="INFO" if context.enforcement_decision == "allow" else "WARN",
            event_type=event_type,
            action=action,
            policy_context=context.to_dict(),
            metadata=metadata or {},
        )
    except ImportError:
        # Fallback to simple logging
        print(
            f"[{event_type}] {action} (role={context.role}, decision={context.enforcement_decision})"
        )


def create_governance_event(
    event_type: str,
    action: str,
    user_uuid: str,
    role: str,
    timestamp: str,
    policy_id: Optional[str] = None,
    enforcement_decision: Optional[str] = None,
    correlation_id: Optional[str] = None,
    audit_seq: Optional[int] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> GovernanceEvent:
    """
    Factory function to create standardized governance events.

    Args:
        event_type: Type of event (use EVENT_* constants)
        action: Action being performed
        user_uuid: User UUID
        role: User role
        timestamp: ISO 8601 timestamp
        policy_id: Policy ID (optional)
        enforcement_decision: Enforcement decision (optional)
        correlation_id: Audit correlation ID (optional)
        audit_seq: Audit sequence number (optional)
        metadata: Additional metadata (optional)

    Returns:
        GovernanceEvent instance
    """
    return GovernanceEvent(
        event_type=event_type,
        action=action,
        user_uuid=user_uuid,
        role=role,
        timestamp=timestamp,
        policy_id=policy_id,
        enforcement_decision=enforcement_decision,
        correlation_id=correlation_id,
        audit_seq=audit_seq,
        metadata=metadata,
    )


# Integration helper for legacy systems
def wrap_with_governance(
    action: str, action_type: str, user_uuid: str, role: str, func, *args, **kwargs
):
    """
    Wrap a legacy function with governance event emission.

    Usage:
        result = wrap_with_governance(
            action="stats.computed",
            action_type="stats:run",
            user_uuid=identity.user_uuid,
            role=role,
            func=compute_stats,
            project_path=path
        )
    """
    from datetime import datetime, timezone

    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    # Emit pre-execution event
    emit_governance_event(
        event_type=EVENT_GOVERNANCE_ENFORCED,
        action=action,
        context=PolicyContext(role=role, enforcement_decision="allow"),
    )

    # Execute function
    try:
        result = func(*args, **kwargs)

        # Emit success event
        emit_governance_event(
            event_type=action,
            action=action,
            context=PolicyContext(role=role, enforcement_decision="allow"),
            metadata={"success": True},
        )

        return result

    except Exception as e:
        # Emit failure event
        emit_governance_event(
            event_type=action,
            action=action,
            context=PolicyContext(role=role, enforcement_decision="deny"),
            metadata={"success": False, "error": str(e)},
        )
        raise
