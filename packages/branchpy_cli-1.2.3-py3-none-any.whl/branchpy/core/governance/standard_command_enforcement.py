"""Standard Command Enforcement

Provides a lightweight, opt-in decorator and helper API to standardise:
  * Structured governance logging lifecycle for any CLI/daemon command
  * RBAC capability gating (graceful denial + JSONL audit trail)
  * Certificate presence hinting (identity / session cert files)
  * Optional audit export of the command's correlated event slice

Design Goals:
  * Zero coupling: Does not modify existing command implementations; wrap them.
  * Low‑risk: Pure additive; if anything fails we fall back to original behaviour.
  * Deterministic: Single correlation_id groups all emitted events.

Events Emitted (category = governance.standard_command):
  - STANDARD_COMMAND_START
  - STANDARD_COMMAND_DENIED        (RBAC gating failed)
  - STANDARD_COMMAND_ERROR         (Unhandled exception)
  - STANDARD_COMMAND_COMPLETE      (Successful completion)
  - STANDARD_COMMAND_AUDIT_EXPORT  (Optional audit slice export performed)

Each event context includes: command_name, correlation_id, duration_ms (where applicable),
capability (if provided), certificate_present (bool), exit_code (on COMPLETE / ERROR / DENIED).

Usage:
    from branchpy.core.governance.standard_command_enforcement import standard_command

    @standard_command(name="provider.health", capability="image.validation.provider.health", export_audit=True)
    def run_provider_health(args) -> int:
        ...
        return 0  # exit code

    if __name__ == "__main__":
        raise SystemExit(run_provider_health(sys.argv[1:]))

Future TODOs (tracked in STUB_FUNCTIONS_AND_TODOS.md):
  * Add certificate chain validation (currently only presence check)
  * Pluggable denial reason providers (e.g. feature flags, maintenance windows)
  * Structured audit export schema versioning
  * VS Code panel integration for real‑time standard command telemetry
"""

from __future__ import annotations

import time
import traceback
import uuid
from dataclasses import dataclass
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Optional

from branchpy.core.governance.logger import GovernanceLogger

EVENT_CATEGORY = "governance.standard_command"
GOVERNANCE_LOG_PATH = Path(".branchpy/governance.jsonl")
AUDIT_EXPORT_DIR = Path(".branchpy/audit/exports")


def _ensure_dirs() -> None:
    try:
        AUDIT_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass  # non-critical


def _load_team_file() -> str:
    """Return raw team.toml contents (or empty string)."""
    path = Path(".branchpy/team.toml")
    if path.exists():
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return ""
    return ""


def _has_capability(capability: Optional[str]) -> bool:
    if not capability:
        return True  # no gating requested
    raw = _load_team_file()
    if not raw:
        # No team file -> permissive (aligns with existing behaviour before RBAC bootstrap)
        return True
    # naive scan – sufficient for decorator usage (avoid dependency on TeamManager internals)
    return capability in raw


def _certificate_present() -> bool:
    # Presence heuristic: any *.cert or identity file in .branchpy
    base = Path(".branchpy")
    if not base.exists():
        return False
    for p in base.glob("*.cert"):  # session certs
        return True
    if (base / "identity.toml").exists():
        return True
    if (base / "cert_secret").exists():
        return True
    return False


@dataclass
class StandardCommandContext:
    name: str
    capability: Optional[str]
    export_audit: bool
    correlation_id: str
    started_at: float
    logger: GovernanceLogger

    def log(self, event_type: str, **context: Any) -> None:
        payload = {
            "event_type": event_type,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "correlation_id": self.correlation_id,
            "category": EVENT_CATEGORY,
            "actor": "system",
            "context": {
                "command_name": self.name,
                "capability": self.capability,
                "certificate_present": _certificate_present(),
                **context,
            },
        }
        try:
            self.logger.log_event(payload)
        except Exception:
            # Never raise – governance failures must not break command semantics
            pass


def standard_command(
    name: str, capability: Optional[str] = None, export_audit: bool = False
) -> Callable:
    """Decorator to wrap a CLI/daemon command with standard enforcement lifecycle.

    The wrapped function must return an int exit code (0 == success by convention).
    Any raised exception will be caught and converted to STANDARD_COMMAND_ERROR.

    Args:
        name: Stable command identifier (e.g. 'provider.health')
        capability: Optional RBAC capability string to enforce
        export_audit: If True, create audit slice export on successful completion
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> int:
            correlation_id = str(uuid.uuid4())
            logger_instance = GovernanceLogger(Path.cwd(), use_batching=True)
            ctx = StandardCommandContext(
                name=name,
                capability=capability,
                export_audit=export_audit,
                correlation_id=correlation_id,
                started_at=time.time(),
                logger=logger_instance,
            )
            ctx.log("STANDARD_COMMAND_START")

            # RBAC gating
            if not _has_capability(capability):
                duration_ms = (time.time() - ctx.started_at) * 1000.0
                # Try to resolve user info for unified schema
                user_role = "unknown"
                user_uuid = "unknown"
                try:
                    from branchpy.core.identity import resolve_identity

                    identity = resolve_identity()
                    user_uuid = getattr(identity.user, "user_uuid", "unknown")
                    from branchpy.core.governance.team_manager import TeamManager

                    team_mgr = TeamManager(Path(".branchpy/team.toml"))
                    user_role = team_mgr.get_role(user_uuid)
                except Exception:
                    pass
                ctx.log(
                    "STANDARD_COMMAND_DENIED",
                    exit_code=65,
                    duration_ms=duration_ms,
                    denial_reason="capability_missing",
                    user_role=user_role,
                    user_uuid=user_uuid,
                    command=name,
                    reason="capability_missing",
                )
                # Also emit RBAC_DENIED event for unified governance event taxonomy
                try:
                    ctx.logger.log_rbac_denied(
                        capability=capability or "none",
                        user_role=user_role,
                        command=name,
                        reason="capability_missing",
                        user_uuid=user_uuid,
                        correlation_id=ctx.correlation_id,
                    )
                except Exception:
                    pass  # Non-critical if RBAC event emission fails
                return 65

            try:
                exit_code = int(func(*args, **kwargs))
            except (
                Exception
            ) as e:  # noqa: BLE001 broad but intentional for enforcement wrapper
                tb = traceback.format_exc(limit=8)
                duration_ms = (time.time() - ctx.started_at) * 1000.0
                ctx.log(
                    "STANDARD_COMMAND_ERROR",
                    exit_code=1,
                    duration_ms=duration_ms,
                    error_type=e.__class__.__name__,
                    error_message=str(e),
                    traceback=tb,
                )
                return 1

            duration_ms = (time.time() - ctx.started_at) * 1000.0
            ctx.log(
                "STANDARD_COMMAND_COMPLETE",
                exit_code=exit_code,
                duration_ms=duration_ms,
            )

            if exit_code == 0 and ctx.export_audit:
                _ensure_dirs()
                try:
                    export_path = (
                        AUDIT_EXPORT_DIR
                        / f"standard_command_{name.replace('.', '_')}_{correlation_id}.jsonl"
                    )
                    _export_audit_slice(
                        GOVERNANCE_LOG_PATH, export_path, correlation_id
                    )
                    ctx.log(
                        "STANDARD_COMMAND_AUDIT_EXPORT",
                        exit_code=exit_code,
                        duration_ms=duration_ms,
                        export_path=str(export_path),
                    )
                except Exception as e:  # silently record failure as error event
                    ctx.log(
                        "STANDARD_COMMAND_AUDIT_EXPORT",
                        exit_code=exit_code,
                        duration_ms=duration_ms,
                        export_path=None,
                        audit_export_error=str(e),
                    )
            return exit_code

        return wrapper

    return decorator


def _export_audit_slice(
    events_file: Path, export_path: Path, correlation_id: str
) -> None:
    """Export only events matching correlation_id to export_path.
    Format: JSON Lines (raw governance events subset).
    """
    if not events_file.exists():
        raise FileNotFoundError("governance events file not found; nothing to export")
    lines: list[str] = []
    with open(events_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            # Cheap correlation match (string contains) to avoid JSON parse cost for large files
            if correlation_id in line:
                lines.append(line.rstrip("\n"))
    with open(export_path, "w", encoding="utf-8") as out:
        for ln in lines:
            out.write(ln + "\n")


__all__ = ["standard_command", "StandardCommandContext"]
