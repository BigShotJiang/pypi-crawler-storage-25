"""
Governance Logger — History Event Tracking

Integrates history operations with BranchPy audit system:
- Logs all history events to audit trail
- Provides queryable event history
- Maintains chain integrity with existing audit logs

Usage:
    from branchpy.core.governance import GovernanceLogger

    logger = GovernanceLogger(project_root)
    logger.log_event({
        "event_type": "ACTION_APPLIED",
        "correlation_id": "abc123",
        "actor": "user@example.com",
        "context": {...}
    })

    events = logger.query_events(
        event_type="ACTION_APPLIED",
        correlation_id="abc123"
    )

Version: v0.8.8
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

_logger = logging.getLogger(__name__)


class GovernanceLogger:
    """
    Logger for history governance events.

    Integrates with BranchPy audit system to provide:
    - Tamper-evident event logging
    - Event querying and filtering
    - Correlation tracking across operations
    - Batched writes for improved performance (v0.9.0)
    """

    def __init__(self, project_root: Optional[Path] = None, use_batching: bool = True):
        """
        Initialize governance logger.

        Args:
            project_root: Project root directory (defaults to current directory)
            use_batching: Enable event batching for improved performance (default: True)
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        # Unified env override (Axis5 G4): prefer BRANCHPY_GOV_LOG_PATH, fall back to legacy BRANCHPY_GOVERNANCE_LOG
        override = os.environ.get("BRANCHPY_GOV_LOG_PATH") or os.environ.get(
            "BRANCHPY_GOVERNANCE_LOG"
        )
        if override:
            self.log_path = Path(override)
        else:
            self.log_path = self.project_root / ".branchpy" / "governance.jsonl"
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.use_batching = use_batching

        # Initialize event batcher if enabled (v0.9.0)
        self._batcher = None
        if use_batching:
            try:
                from branchpy.core.history.governance_bridge import get_batcher

                self._batcher = get_batcher(self.log_path)
                _logger.debug("Event batching enabled (5-10x performance improvement)")
            except ImportError:
                _logger.warning(
                    "EventBatcher not available, falling back to direct writes"
                )
                self.use_batching = False

        # Try to use core audit system if available (legacy, may not exist)
        self._audit_log = None
        try:
            from branchpy.core.audit import AuditLog  # type: ignore[attr-defined]

            audit_path = self.project_root / ".branchpy" / "audit.jsonl"
            self._audit_log = AuditLog(audit_path)
        except ImportError:
            _logger.debug("Core audit system not available, using direct JSONL")

    def log_event(self, event: Dict[str, Any]) -> None:
        """
        Log a governance event.

        Args:
            event: Event dictionary with:
                - event_type: Type of event (ACTION_APPLIED, etc.)
                - correlation_id: Unique ID linking related events
                - actor: User/system performing action
                - timestamp: ISO 8601 timestamp
                - context: Event-specific metadata

        Side effects:
            - Appends to .branchpy/governance.jsonl (batched if enabled)
            - If audit system available, also logs to audit.jsonl

        Performance:
            - With batching: 10-50μs per event (buffered writes)
            - Without batching: 100-500μs per event (immediate writes)
        """
        # Ensure required fields
        if "timestamp" not in event:
            event["timestamp"] = datetime.utcnow().isoformat() + "Z"

        # Log to audit system if available
        if self._audit_log:
            try:
                self._audit_log.log(
                    action=f"history.{event.get('event_type', 'UNKNOWN')}",
                    args={
                        "correlation_id": event.get("correlation_id"),
                        "context": event.get("context", {}),
                    },
                    result={"success": True},
                )
            except Exception as e:
                _logger.warning(f"Failed to log to audit system: {e}")

        # Log to governance.jsonl (batched or direct)
        try:
            if self._batcher:
                # Use batched writes (v0.9.0) - 5-10x faster
                self._batcher.add_event(event)
            else:
                # Fall back to direct writes
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event, default=str) + "\n")

            _logger.debug(
                f"Logged governance event: {event.get('event_type')} "
                f"(correlation_id={event.get('correlation_id')}, "
                f"batched={self.use_batching})"
            )
        except Exception as e:
            _logger.error(f"Failed to write governance event: {e}")

    def log_rbac_denied(
        self,
        capability: str,
        user_role: str,
        command: str,
        reason: str,
        user_uuid: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Log an RBAC denial event with exit code 65 context.

        Args:
            capability: Required capability that was denied (e.g., "image.validation.run")
            user_role: User's current role (e.g., "developer", "viewer")
            command: Command that was denied (e.g., "branchpy validate images")
            reason: Human-readable denial reason
            user_uuid: Optional user UUID for audit trail
            correlation_id: Optional correlation ID for linking related events

        Side effects:
            - Emits RBAC_DENIED governance event
            - Includes exit_code=65 in context for traceability

        Example:
            logger.log_rbac_denied(
                capability="image.validation.run",
                user_role="developer",
                command="branchpy validate images",
                reason="Capability not granted to role 'developer'"
            )
        """
        import uuid

        event = {
            "event_type": "RBAC_DENIED",
            "category": "governance.rbac",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "correlation_id": correlation_id or str(uuid.uuid4()),
            "context": {
                "capability": capability,
                "user_role": user_role,
                "command": command,
                "reason": reason,
                "exit_code": 65,
            },
        }

        # Add optional fields
        if user_uuid:
            event["context"]["user_uuid"] = user_uuid

        self.log_event(event)

        _logger.info(
            f"RBAC denial logged: capability={capability}, "
            f"role={user_role}, command={command}"
        )

    def query_events(
        self,
        event_type: Optional[str] = None,
        correlation_id: Optional[str] = None,
        actor: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Query governance events with filters.

        Args:
            event_type: Filter by event type (ACTION_APPLIED, etc.)
            correlation_id: Filter by correlation ID
            actor: Filter by actor (user/system)
            limit: Maximum events to return
            offset: Skip first N events

        Returns:
            List of matching event dictionaries
        """
        if not self.log_path.exists():
            return []

        events = []
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue

                    try:
                        event = json.loads(line)

                        # Apply filters
                        if event_type and event.get("event_type") != event_type:
                            continue
                        if (
                            correlation_id
                            and event.get("correlation_id") != correlation_id
                        ):
                            continue
                        if actor and event.get("actor") != actor:
                            continue

                        events.append(event)
                    except json.JSONDecodeError:
                        _logger.warning(f"Skipping malformed JSON line: {line[:100]}")
                        continue
        except Exception as e:
            _logger.error(f"Failed to read governance log: {e}")
            return []

        # Apply pagination
        return events[offset : offset + limit]

    def get_event_timeline(self, correlation_id: str) -> List[Dict[str, Any]]:
        """
        Get complete timeline of events for a correlation ID.

        Args:
            correlation_id: Correlation ID to retrieve

        Returns:
            List of events in chronological order
        """
        events = self.query_events(correlation_id=correlation_id, limit=1000)

        # Sort by timestamp
        events.sort(key=lambda e: e.get("timestamp", ""))

        return events

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about governance events.

        Returns:
            Dictionary with:
            - total_events: Total event count
            - event_types: Count by event type
            - unique_actors: Number of unique actors
            - unique_correlations: Number of unique correlation IDs
            - date_range: Earliest to latest event
        """
        if not self.log_path.exists():
            return {
                "total_events": 0,
                "event_types": {},
                "unique_actors": 0,
                "unique_correlations": 0,
                "date_range": None,
            }

        event_types = {}
        actors = set()
        correlations = set()
        timestamps = []
        total = 0

        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue

                    try:
                        event = json.loads(line)
                        total += 1

                        # Count event types
                        event_type = event.get("event_type", "UNKNOWN")
                        event_types[event_type] = event_types.get(event_type, 0) + 1

                        # Track actors and correlations
                        if "actor" in event:
                            actors.add(event["actor"])
                        if "correlation_id" in event:
                            correlations.add(event["correlation_id"])
                        if "timestamp" in event:
                            timestamps.append(event["timestamp"])

                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            _logger.error(f"Failed to read governance log: {e}")

        # Determine date range
        date_range = None
        if timestamps:
            timestamps.sort()
            date_range = f"{timestamps[0]} to {timestamps[-1]}"

        return {
            "total_events": total,
            "event_types": event_types,
            "unique_actors": len(actors),
            "unique_correlations": len(correlations),
            "date_range": date_range,
        }

    def verify_integrity(self) -> Dict[str, Any]:
        """
        Verify integrity of governance log.

        Checks:
        - Valid JSON for all entries
        - Required fields present
        - Chronological order

        Returns:
            Dictionary with:
            - valid: True if all checks pass
            - errors: List of error messages
            - warnings: List of warning messages
        """
        # Flush any buffered events before verification
        self.flush()

        errors = []
        warnings = []

        if not self.log_path.exists():
            return {
                "valid": True,
                "errors": [],
                "warnings": ["No governance log exists yet"],
            }

        required_fields = ["event_type", "timestamp"]
        prev_timestamp = None
        line_num = 0

        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    line_num += 1
                    if not line.strip():
                        continue

                    # Check valid JSON
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError as e:
                        errors.append(f"Line {line_num}: Invalid JSON - {e}")
                        continue

                    # Check required fields
                    for field in required_fields:
                        if field not in event:
                            errors.append(
                                f"Line {line_num}: Missing required field '{field}'"
                            )

                    # Check chronological order
                    if "timestamp" in event:
                        timestamp = event["timestamp"]
                        if prev_timestamp and timestamp < prev_timestamp:
                            warnings.append(
                                f"Line {line_num}: Event out of chronological order "
                                f"({timestamp} < {prev_timestamp})"
                            )
                        prev_timestamp = timestamp

        except Exception as e:
            errors.append(f"Failed to read log: {e}")

        return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings}

    def flush(self) -> None:
        """
        Force flush all buffered events to disk.

        Call this before shutdown or when immediate persistence is required.
        With batching enabled, events are normally flushed every 10 events or 5 seconds.
        """
        if self._batcher:
            try:
                self._batcher.flush()
                _logger.debug("Flushed buffered governance events")
            except Exception as e:
                _logger.error(f"Failed to flush events: {e}")

    async def flush_async(self) -> None:
        """Awaitable version of flush for async shutdown paths."""
        # Synchronous flush is lightweight; run in default loop executor if batching present
        if self._batcher:
            await asyncio.to_thread(self.flush)
        else:
            # No batching: nothing buffered beyond direct writes
            return

    def __del__(self):
        """Ensure events are flushed on cleanup."""
        try:
            self.flush()
        except Exception:
            pass  # Ignore errors during cleanup


# Example usage
if __name__ == "__main__":
    # Example: Log a history event
    logger = GovernanceLogger()

    logger.log_event(
        {
            "event_type": "ACTION_APPLIED",
            "correlation_id": "test-123",
            "actor": "user@example.com",
            "context": {"operation": "FILE_EDIT", "files": ["test.py"]},
        }
    )

    # Query events
    events = logger.query_events(correlation_id="test-123")
    print(f"Found {len(events)} events")

    # Get statistics
    stats = logger.get_statistics()
    print(f"Statistics: {json.dumps(stats, indent=2)}")
