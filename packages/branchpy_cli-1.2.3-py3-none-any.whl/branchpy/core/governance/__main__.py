#!/usr/bin/env python
"""
CLI Entry Point for Governance Integrity Verification

Provides command-line interface to verify_event_chain function for VS Code integration.

Usage:
    python -m branchpy.core.governance.integrity verify --correlation-id abc123 --format json
    python -m branchpy.core.governance.integrity verify --all --format text

Returns:
    - Exit code 0: Chain verified
    - Exit code 1: Chain verification failed
    - Exit code 2: Error during verification

Output Formats:
    - json: Single-line JSON with IntegrityResult fields
    - text: Human-readable summary

Version: v0.9.2
"""

import argparse
import json
import sys
from pathlib import Path

from branchpy.core.governance.integrity import IntegrityResult, verify_event_chain


def main():
    parser = argparse.ArgumentParser(
        description="Verify governance event chain integrity"
    )
    parser.add_argument(
        "action",
        choices=["verify"],
        help="Action to perform (currently only 'verify' supported)",
    )
    parser.add_argument(
        "--correlation-id", type=str, help="Correlation ID to filter events (optional)"
    )
    parser.add_argument(
        "--start-timestamp", type=str, help="ISO 8601 start timestamp filter (optional)"
    )
    parser.add_argument(
        "--end-timestamp", type=str, help="ISO 8601 end timestamp filter (optional)"
    )
    parser.add_argument(
        "--log-path",
        type=str,
        help="Path to governance.jsonl file (defaults to .branchpy/governance.jsonl)",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format (json or text)",
    )
    parser.add_argument(
        "--all", action="store_true", help="Verify entire log (no correlation filter)"
    )

    args = parser.parse_args()

    # Determine log path
    if args.log_path:
        log_path = Path(args.log_path)
    else:
        log_path = Path.cwd() / ".branchpy" / "governance.jsonl"

    # Verify log exists
    if not log_path.exists():
        if args.format == "json":
            print(
                json.dumps(
                    {
                        "verified": False,
                        "event_count": 0,
                        "chain_head_hash": "",
                        "missing_indices": [],
                        "duration_ms": 0.0,
                        "violations": [f"Log file not found: {log_path}"],
                    }
                )
            )
        else:
            print(f"ERROR: Log file not found: {log_path}", file=sys.stderr)
        sys.exit(2)

    # Execute verification
    try:
        correlation_id = None if args.all else args.correlation_id

        result: IntegrityResult = verify_event_chain(
            log_path=log_path,
            correlation_id=correlation_id,
            start_timestamp=args.start_timestamp,
            end_timestamp=args.end_timestamp,
        )

        # Output result
        if args.format == "json":
            # Single-line JSON for easy parsing in VS Code
            print(
                json.dumps(
                    {
                        "verified": result.verified,
                        "event_count": result.event_count,
                        "chain_head_hash": result.chain_head_hash,
                        "missing_indices": result.missing_indices,
                        "duration_ms": result.duration_ms,
                        "violations": result.violations,
                    }
                )
            )
        else:
            # Human-readable text
            status = "✓ VERIFIED" if result.verified else "✗ FAILED"
            print(f"\nIntegrity Check: {status}")
            print(f"  Events Verified: {result.event_count}")
            print(f"  Chain Head Hash: {result.chain_head_hash[:16]}...")
            print(f"  Duration: {result.duration_ms:.1f}ms")

            if result.missing_indices:
                print(f"  Missing Indices: {result.missing_indices}")

            if result.violations:
                print("\n  Violations:")
                for violation in result.violations:
                    print(f"    - {violation}")

        # Exit code
        sys.exit(0 if result.verified else 1)

    except Exception as e:
        if args.format == "json":
            print(
                json.dumps(
                    {
                        "verified": False,
                        "event_count": 0,
                        "chain_head_hash": "",
                        "missing_indices": [],
                        "duration_ms": 0.0,
                        "violations": [f"Verification error: {str(e)}"],
                    }
                )
            )
        else:
            print(f"ERROR: Verification failed: {e}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
