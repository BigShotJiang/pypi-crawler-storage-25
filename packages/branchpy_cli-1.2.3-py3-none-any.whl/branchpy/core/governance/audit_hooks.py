"""
Governance Audit Hooks — Wave 3

Automatic audit event emission for policy API access and UI operations.
Ensures compliance with BQF-Core §4 (Observability) and §9 (Security).

Audit Events:
- governance.audit.export (REST API access)
- governance.audit.panel_opened (UI panel activation)
- governance.audit.policy_inspected (Policy detail view)

Version: v0.9.2 Wave 3
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AuditHooks:
    """
    Centralized audit event emission for governance compliance.

    Hooks into API access, UI operations, and policy inspections.
    All events include cryptographic hash for integrity verification (§9).
    """

    def __init__(self, governance_logger=None):
        self.governance_logger = governance_logger

    def audit_api_access(
        self,
        endpoint: str,
        actor: str,
        filters: Optional[dict[str, Any]] = None,
        result_count: Optional[int] = None,
    ) -> None:
        """
        Audit REST API access.

        Args:
            endpoint: API endpoint (e.g., "/api/v1/validation/policies")
            actor: Actor identifier (e.g., "user:alice", "api.client")
            filters: Applied filters/parameters
            result_count: Number of items returned
        """
        if not self.governance_logger:
            logger.warning(f"No governance logger for audit: {endpoint}")
            return

        metadata = {
            "endpoint": endpoint,
            "filters": filters or {},
            "result_count": result_count,
            "timestamp": datetime.utcnow().isoformat(),
        }

        # Compute integrity hash
        payload = json.dumps(metadata, sort_keys=True).encode("utf-8")
        integrity_hash = hashlib.sha256(payload).hexdigest()
        metadata["integrity_hash"] = integrity_hash

        self.governance_logger.log_event(
            event_type="governance.audit.export",
            actor=actor,
            metadata=metadata,
            severity="info",
        )

        logger.info(
            f"Audit: {actor} accessed {endpoint} (hash: {integrity_hash[:8]}...)"
        )

    def audit_panel_opened(
        self, panel_name: str, user_id: str, load_time_ms: Optional[float] = None
    ) -> None:
        """
        Audit UI panel activation.

        Args:
            panel_name: Panel identifier (e.g., "PoliciesPanel")
            user_id: User identifier
            load_time_ms: Panel load time in milliseconds
        """
        if not self.governance_logger:
            return

        metadata = {
            "panel": panel_name,
            "user": user_id,
            "load_time_ms": load_time_ms,
            "timestamp": datetime.utcnow().isoformat(),
        }

        # Compute integrity hash
        payload = json.dumps(metadata, sort_keys=True).encode("utf-8")
        metadata["integrity_hash"] = hashlib.sha256(payload).hexdigest()

        self.governance_logger.log_event(
            event_type="governance.audit.panel_opened",
            actor=f"ui.{panel_name}",
            metadata=metadata,
            severity="info",
        )

        logger.debug(f"Audit: Panel {panel_name} opened by {user_id}")

    def audit_policy_inspected(
        self, policy_id: str, user_id: str, evaluations_viewed: int = 0
    ) -> None:
        """
        Audit policy detail inspection.

        Args:
            policy_id: Policy identifier
            user_id: User identifier
            evaluations_viewed: Number of evaluations shown in detail view
        """
        if not self.governance_logger:
            return

        metadata = {
            "policy_id": policy_id,
            "user": user_id,
            "evaluations_viewed": evaluations_viewed,
            "timestamp": datetime.utcnow().isoformat(),
        }

        # Compute integrity hash
        payload = json.dumps(metadata, sort_keys=True).encode("utf-8")
        metadata["integrity_hash"] = hashlib.sha256(payload).hexdigest()

        self.governance_logger.log_event(
            event_type="governance.audit.policy_inspected",
            actor="ui.PolicyDetail",
            metadata=metadata,
            severity="info",
        )

        logger.debug(f"Audit: Policy {policy_id} inspected by {user_id}")

    def audit_export(
        self, export_type: str, actor: str, record_count: int, format: str = "json"
    ) -> None:
        """
        Audit data export operations.

        Args:
            export_type: Type of export (e.g., "policies", "evaluations")
            actor: Actor identifier
            record_count: Number of records exported
            format: Export format (json, csv, etc.)
        """
        if not self.governance_logger:
            return

        metadata = {
            "export_type": export_type,
            "record_count": record_count,
            "format": format,
            "timestamp": datetime.utcnow().isoformat(),
        }

        # Compute integrity hash
        payload = json.dumps(metadata, sort_keys=True).encode("utf-8")
        metadata["integrity_hash"] = hashlib.sha256(payload).hexdigest()

        self.governance_logger.log_event(
            event_type="governance.audit.export",
            actor=actor,
            metadata=metadata,
            severity="info",
        )

        logger.info(f"Audit: {actor} exported {record_count} {export_type} as {format}")


# Singleton instance
_audit_hooks: Optional[AuditHooks] = None


def get_audit_hooks(governance_logger=None) -> AuditHooks:
    """Get or create AuditHooks singleton."""
    global _audit_hooks
    if _audit_hooks is None:
        _audit_hooks = AuditHooks(governance_logger)
    elif governance_logger and not _audit_hooks.governance_logger:
        _audit_hooks.governance_logger = governance_logger
    return _audit_hooks


def audit_api_access(endpoint: str, actor: str, **kwargs) -> None:
    """Convenience function to audit API access."""
    get_audit_hooks().audit_api_access(endpoint, actor, **kwargs)


def audit_panel_opened(panel_name: str, user_id: str, **kwargs) -> None:
    """Convenience function to audit panel opening."""
    get_audit_hooks().audit_panel_opened(panel_name, user_id, **kwargs)


def audit_policy_inspected(policy_id: str, user_id: str, **kwargs) -> None:
    """Convenience function to audit policy inspection."""
    get_audit_hooks().audit_policy_inspected(policy_id, user_id, **kwargs)
