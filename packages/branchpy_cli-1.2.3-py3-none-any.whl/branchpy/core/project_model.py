from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from .engine_interface import EngineInterface
from .snapshot import ProjectSnapshot


@dataclass
class ProjectModel:
    name: str
    path: str
    engine: EngineInterface
    index: Dict[str, Any] = field(default_factory=dict)
    analysis: Dict[str, Any] = field(default_factory=dict)
    snapshot: ProjectSnapshot | None = None

    def load(self) -> "ProjectModel":
        self.index = self.engine.build_index(self.path)
        # Extract snapshot data from index
        files = list(self.index.get("files", {}).keys())
        labels = self.index.get("labels", {})
        calls = None  # Future field
        menus = None  # Future field
        vars_data = None  # Future field

        self.snapshot = ProjectSnapshot(
            files=files, labels=labels, calls=calls, menus=menus, vars=vars_data
        )
        return self

    def run_analysis(self, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Run analysis on the project.

        Args:
            options: Optional dict with analysis options:
                - enable_assets (bool): Enable asset validation
                - export_cfg (bool): Include CFG debug output

        Returns:
            Analysis results dictionary
        """
        if not self.index:
            self.load()
        self.analysis = self.engine.analyze(self.index, options or {})
        return self.analysis
