"""
Remote Context Detection for BranchPy v0.9.2 (WS-C1).

This module provides automatic detection of remote development environments:
- SSH remote sessions
- GitHub Codespaces
- Docker/Podman containers
- WSL (Windows Subsystem for Linux)
- VS Code Remote extensions
- Local desktop (fallback)

Philosophy:
    "BranchPy adapts to your environment—not the other way around."
    Remote detection is transparent, non-invasive, and privacy-safe.

Governance:
    - Axis 5: Desktop vs Remote / Codespaces
    - WS-C1: Phase C Foundations
    - BQF/BQS compliance: All detection is auditable
    - Privacy: Session IDs are hashed (SHA256)

Author: BranchPy Team
Version: v0.9.2 (WS-C1)
"""

import hashlib
import os
import platform
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional


class RemoteType(Enum):
    """Remote environment types."""

    LOCAL = "local"
    SSH = "ssh"
    CODESPACES = "codespaces"
    CONTAINER = "container"
    WSL = "wsl"
    VSCODE_REMOTE = "vscode_remote"
    UNKNOWN = "unknown"


class PathStyle(Enum):
    """Path separator style."""

    POSIX = "posix"  # Unix-style (/)
    WINDOWS = "windows"  # Windows-style (\)


@dataclass
class RemoteContext:
    """
    Remote environment context.

    Attributes:
        type: Remote environment type (ssh, codespaces, container, wsl, local)
        path_style: Path separator style (posix or windows)
        session_id: Anonymized session identifier (SHA256 hash)
        metadata: Additional context (varies by remote type)
        is_remote: True if not local desktop
        is_ci: True if detected as CI environment

    Example:
        ctx = RemoteContext.detect()
        if ctx.is_remote:
            print(f"Running in {ctx.type.value} environment")
        if ctx.is_ci:
            print("CI environment detected")
    """

    type: RemoteType
    path_style: PathStyle
    session_id: str
    metadata: dict = field(default_factory=dict)
    is_remote: bool = False
    is_ci: bool = False

    @classmethod
    def detect(cls) -> "RemoteContext":
        """
        Detect remote environment context.

        Detection logic (in priority order):
        1. GitHub Codespaces (CODESPACES=true env var)
        2. Docker/Podman container (/.dockerenv or /proc/1/cgroup)
        3. WSL (Linux with /proc/version containing "Microsoft" or "WSL")
        4. SSH (SSH_CONNECTION, SSH_CLIENT env vars)
        5. VS Code Remote (VSCODE_REMOTE_* env vars)
        6. Local desktop (fallback)

        Performance target: <200µs

        Returns:
            RemoteContext with detected environment

        Example:
            >>> ctx = RemoteContext.detect()
            >>> ctx.type
            RemoteType.CODESPACES
            >>> ctx.is_remote
            True
            >>> ctx.session_id
            'session-9d2e1f0a'
        """
        # Detect CI environment first (affects metadata)
        is_ci = cls._detect_ci()

        # Detection sequence
        codespaces_ctx = cls._detect_codespaces()
        if codespaces_ctx:
            codespaces_ctx.is_ci = is_ci
            return codespaces_ctx

        container_ctx = cls._detect_container()
        if container_ctx:
            container_ctx.is_ci = is_ci
            return container_ctx

        wsl_ctx = cls._detect_wsl()
        if wsl_ctx:
            wsl_ctx.is_ci = is_ci
            return wsl_ctx

        ssh_ctx = cls._detect_ssh()
        if ssh_ctx:
            ssh_ctx.is_ci = is_ci
            return ssh_ctx

        vscode_ctx = cls._detect_vscode_remote()
        if vscode_ctx:
            vscode_ctx.is_ci = is_ci
            return vscode_ctx

        # Fallback: local desktop
        return cls._detect_local(is_ci)

    @classmethod
    def _detect_ci(cls) -> bool:
        """Detect if running in CI environment."""
        ci_indicators = [
            "CI",
            "CONTINUOUS_INTEGRATION",
            "GITHUB_ACTIONS",
            "GITLAB_CI",
            "JENKINS_URL",
            "TRAVIS",
            "CIRCLECI",
            "BUILDKITE",
        ]
        return any(os.getenv(var) for var in ci_indicators)

    @classmethod
    def _detect_codespaces(cls) -> Optional["RemoteContext"]:
        """Detect GitHub Codespaces."""
        if os.getenv("CODESPACES") == "true":
            codespace_name = os.getenv("CODESPACE_NAME", "unknown")
            session_id = cls._hash_session(f"codespaces:{codespace_name}")

            return RemoteContext(
                type=RemoteType.CODESPACES,
                path_style=PathStyle.POSIX,
                session_id=session_id,
                metadata={
                    "codespace_name": "<redacted>",  # Privacy: don't expose name
                    "vscode_remote": os.getenv("VSCODE_REMOTE_CONTAINERS_IPC")
                    is not None,
                },
                is_remote=True,
            )
        return None

    @classmethod
    def _detect_container(cls) -> Optional["RemoteContext"]:
        """Detect Docker/Podman container."""
        # Check for /.dockerenv file
        if Path("/.dockerenv").exists():
            container_id = cls._get_container_id()
            session_id = cls._hash_session(f"container:{container_id}")

            return RemoteContext(
                type=RemoteType.CONTAINER,
                path_style=PathStyle.POSIX,
                session_id=session_id,
                metadata={
                    "container_id": "<redacted>",  # Privacy: hash container ID
                    "runtime": "docker",
                },
                is_remote=True,
            )

        # Check /proc/1/cgroup for container indicators
        cgroup_path = Path("/proc/1/cgroup")
        if cgroup_path.exists():
            try:
                cgroup_content = cgroup_path.read_text()
                if "docker" in cgroup_content or "kubepods" in cgroup_content:
                    container_id = cls._get_container_id()
                    session_id = cls._hash_session(f"container:{container_id}")

                    runtime = "docker" if "docker" in cgroup_content else "kubernetes"

                    return RemoteContext(
                        type=RemoteType.CONTAINER,
                        path_style=PathStyle.POSIX,
                        session_id=session_id,
                        metadata={
                            "container_id": "<redacted>",
                            "runtime": runtime,
                        },
                        is_remote=True,
                    )
            except Exception:
                pass  # Ignore read errors

        return None

    @classmethod
    def _detect_wsl(cls) -> Optional["RemoteContext"]:
        """Detect Windows Subsystem for Linux."""
        if platform.system() != "Linux":
            return None

        proc_version = Path("/proc/version")
        if proc_version.exists():
            try:
                version_content = proc_version.read_text().lower()
                if "microsoft" in version_content or "wsl" in version_content:
                    wsl_distro = os.getenv("WSL_DISTRO_NAME", "unknown")
                    session_id = cls._hash_session(f"wsl:{wsl_distro}")

                    return RemoteContext(
                        type=RemoteType.WSL,
                        path_style=PathStyle.POSIX,
                        session_id=session_id,
                        metadata={
                            "distro": "<redacted>",  # Privacy: don't expose distro
                            "wsl_version": "2" if "wsl2" in version_content else "1",
                        },
                        is_remote=True,
                    )
            except Exception:
                pass

        return None

    @classmethod
    def _detect_ssh(cls) -> Optional["RemoteContext"]:
        """Detect SSH remote session."""
        ssh_connection = os.getenv("SSH_CONNECTION")
        ssh_client = os.getenv("SSH_CLIENT")

        if ssh_connection or ssh_client:
            # SSH_CONNECTION format: "client_ip client_port server_ip server_port"
            connection_str = ssh_connection or ssh_client or "unknown"
            session_id = cls._hash_session(f"ssh:{connection_str}")

            return RemoteContext(
                type=RemoteType.SSH,
                path_style=(
                    PathStyle.POSIX
                    if platform.system() != "Windows"
                    else PathStyle.WINDOWS
                ),
                session_id=session_id,
                metadata={
                    "ssh_tty": os.getenv("SSH_TTY", "<none>"),
                    "term": os.getenv("TERM", "unknown"),
                },
                is_remote=True,
            )

        return None

    @classmethod
    def _detect_vscode_remote(cls) -> Optional["RemoteContext"]:
        """Detect VS Code Remote extension."""
        # VS Code Remote sets specific env vars
        vscode_remote_vars = [
            "VSCODE_REMOTE_CONTAINERS_IPC",
            "VSCODE_REMOTE_SSH_IPC",
            "VSCODE_REMOTE_WSL_IPC",
        ]

        for var in vscode_remote_vars:
            if os.getenv(var):
                session_id = cls._hash_session(f"vscode_remote:{var}")

                return RemoteContext(
                    type=RemoteType.VSCODE_REMOTE,
                    path_style=PathStyle.POSIX,
                    session_id=session_id,
                    metadata={
                        "remote_type": var.replace("VSCODE_REMOTE_", "")
                        .replace("_IPC", "")
                        .lower(),
                    },
                    is_remote=True,
                )

        return None

    @classmethod
    def _detect_local(cls, is_ci: bool = False) -> "RemoteContext":
        """Fallback: local desktop environment."""
        system = platform.system()
        path_style = PathStyle.WINDOWS if system == "Windows" else PathStyle.POSIX

        # Use hostname as session identifier (hashed for privacy)
        hostname = platform.node()
        session_id = cls._hash_session(f"local:{hostname}")

        return RemoteContext(
            type=RemoteType.LOCAL,
            path_style=path_style,
            session_id=session_id,
            metadata={
                "platform": system,
                "hostname": "<redacted>",  # Privacy: don't expose hostname
            },
            is_remote=False,
            is_ci=is_ci,
        )

    @staticmethod
    def _hash_session(session_str: str) -> str:
        """
        Hash session identifier for privacy.

        Args:
            session_str: Raw session string (hostname, container ID, etc.)

        Returns:
            Anonymized session ID (format: "session-<hash[:8]>")

        Example:
            >>> RemoteContext._hash_session("codespaces:abc123")
            'session-9d2e1f0a'
        """
        hash_hex = hashlib.sha256(session_str.encode()).hexdigest()
        return f"session-{hash_hex[:8]}"

    @staticmethod
    def _get_container_id() -> str:
        """
        Get container ID from /proc/self/cgroup or hostname.

        Returns:
            Container ID (first 12 chars of full ID) or "unknown"
        """
        # Try reading from cgroup
        cgroup_path = Path("/proc/self/cgroup")
        if cgroup_path.exists():
            try:
                cgroup_content = cgroup_path.read_text()
                # Look for container ID in cgroup paths
                for line in cgroup_content.splitlines():
                    if "docker" in line or "kubepods" in line:
                        parts = line.split("/")
                        if parts:
                            container_id = parts[-1].strip()
                            if len(container_id) >= 12:
                                return container_id[:12]
            except Exception:
                pass

        # Fallback: use hostname (often container ID in Docker)
        hostname = platform.node()
        if len(hostname) >= 12:
            return hostname[:12]

        return "unknown"

    def to_dict(self) -> dict:
        """
        Convert to dictionary (for telemetry/serialization).

        Returns:
            Dict with type, path_style, session_id, metadata, is_remote, is_ci

        Example:
            >>> ctx = RemoteContext.detect()
            >>> ctx.to_dict()
            {
                'type': 'codespaces',
                'path_style': 'posix',
                'session_id': 'session-9d2e1f0a',
                'metadata': {...},
                'is_remote': True,
                'is_ci': False
            }
        """
        return {
            "type": self.type.value,
            "path_style": self.path_style.value,
            "session_id": self.session_id,
            "metadata": self.metadata,
            "is_remote": self.is_remote,
            "is_ci": self.is_ci,
        }

    def __repr__(self) -> str:
        return (
            f"RemoteContext(type={self.type.value}, "
            f"is_remote={self.is_remote}, "
            f"is_ci={self.is_ci}, "
            f"session_id={self.session_id})"
        )


# Convenience function for quick detection
def detect_remote_context() -> RemoteContext:
    """
    Detect remote environment context (convenience wrapper).

    Returns:
        RemoteContext with detected environment

    Example:
        >>> from branchpy.core.remote_context import detect_remote_context
        >>> ctx = detect_remote_context()
        >>> if ctx.is_remote:
        ...     print(f"Running in {ctx.type.value}")
    """
    return RemoteContext.detect()
