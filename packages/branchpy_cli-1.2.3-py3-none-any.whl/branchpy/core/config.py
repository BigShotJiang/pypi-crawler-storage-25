from __future__ import annotations

import json

from .paths import CONFIG

DEFAULTS = {"telemetry_enabled": False}


def load_config():
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        return {**DEFAULTS, **data}
    except Exception:
        return dict(DEFAULTS)


def save_config(cfg: dict):
    CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
