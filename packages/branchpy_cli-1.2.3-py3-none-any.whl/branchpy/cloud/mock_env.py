# branchpy/cloud/mock_env.py
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CLOUD_ROOT_ENV = "BRANCHPY_CLOUD_ROOT"  # optional override


def _cloud_root() -> Path:
    root = os.getenv(CLOUD_ROOT_ENV)
    if not root:
        root = os.path.join(os.path.expanduser("~"), ".branchpy_cloud")
    path = Path(root)
    path.mkdir(parents=True, exist_ok=True)
    return path


@dataclass
class CloudAccount:
    account_id: str
    display_name: str

    @classmethod
    def load_or_init(cls) -> "CloudAccount":
        root = _cloud_root()
        account_path = root / "account.json"
        if account_path.exists():
            data = json.loads(account_path.read_text(encoding="utf-8"))
            return cls(
                account_id=data["account_id"],
                display_name=data.get("display_name", "Local Cloud Account"),
            )
        acct = cls(account_id=str(uuid.uuid4()), display_name="Local Cloud Account")
        account_path.write_text(json.dumps(acct.__dict__, indent=2), encoding="utf-8")
        return acct


@dataclass
class CloudProject:
    project_id: str
    name: str
    local_path: str

    @property
    def project_root(self) -> Path:
        return _cloud_root() / "projects" / self.project_id

    @classmethod
    def from_local_path(cls, local_path: Path) -> "CloudProject":
        # For v0.9.5 we can just derive project_id from a stable hash of the path
        project_id = uuid.uuid5(uuid.NAMESPACE_URL, str(local_path)).hex
        name = local_path.name or "Unnamed Project"
        proj = cls(project_id=project_id, name=name, local_path=str(local_path))
        return proj

    def ensure_dirs(self) -> None:
        (self.project_root).mkdir(parents=True, exist_ok=True)
        (self.project_root / "snapshots").mkdir(parents=True, exist_ok=True)
        (self.project_root / "artifacts" / "reports").mkdir(parents=True, exist_ok=True)
        (self.project_root / "artifacts" / "logs").mkdir(parents=True, exist_ok=True)
        (self.project_root / "state").mkdir(parents=True, exist_ok=True)

    def manifest_path(self) -> Path:
        return self.project_root / "manifest.json"

    def save_manifest(self) -> None:
        data = {
            "project_id": self.project_id,
            "name": self.name,
            "local_path": self.local_path,
            "last_updated": time.time(),
        }
        self.manifest_path().write_text(json.dumps(data, indent=2), encoding="utf-8")


def snapshot_project_config(project: CloudProject, branchpy_toml_path: Path) -> Path:
    project.ensure_dirs()
    ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    snap_path = project.project_root / "snapshots" / f"{ts}.json"

    config = {}
    if branchpy_toml_path.exists():
        config_text = branchpy_toml_path.read_text(encoding="utf-8")
        config["branchpy_toml"] = config_text

    payload = {
        "project_id": project.project_id,
        "name": project.name,
        "local_path": project.local_path,
        "timestamp": ts,
        "config": config,
    }
    snap_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    project.save_manifest()
    return snap_path


def reserve_project(project: CloudProject, actor: str) -> None:
    project.ensure_dirs()
    lock_path = project.project_root / "state" / "rem_lock.json"
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    lock_payload = {
        "project_id": project.project_id,
        "actor": actor,
        "reserved_at": ts,
    }
    lock_path.write_text(json.dumps(lock_payload, indent=2), encoding="utf-8")


def release_project(project: CloudProject) -> None:
    lock_path = project.project_root / "state" / "rem_lock.json"
    if lock_path.exists():
        lock_path.unlink()


def list_projects() -> list[CloudProject]:
    """
    List all projects in the cloud mock.

    Returns:
        List of CloudProject instances found in ~/.branchpy_cloud/projects/
    """
    root = _cloud_root()
    projects_dir = root / "projects"

    if not projects_dir.exists():
        return []

    projects = []
    for project_dir in projects_dir.iterdir():
        if not project_dir.is_dir():
            continue

        manifest_path = project_dir / "manifest.json"
        if not manifest_path.exists():
            continue

        try:
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            project = CloudProject(
                project_id=data["project_id"],
                name=data["name"],
                local_path=data["local_path"],
            )
            projects.append(project)
        except (json.JSONDecodeError, KeyError):
            # Skip malformed manifests
            continue

    # Sort by last_updated (most recent first)
    projects.sort(
        key=lambda p: (
            p.manifest_path().stat().st_mtime if p.manifest_path().exists() else 0
        ),
        reverse=True,
    )
    return projects


def get_project_rem_status(project: CloudProject) -> dict[str, Any]:
    """
    Get REM status for a project.

    Returns:
        Dict with 'status' ('free' or 'reserved'), 'actor', and 'reserved_at'
    """
    lock_path = project.project_root / "state" / "rem_lock.json"

    if not lock_path.exists():
        return {"status": "free"}

    try:
        lock_data = json.loads(lock_path.read_text(encoding="utf-8"))
        return {
            "status": "reserved",
            "actor": lock_data.get("actor", "unknown"),
            "reserved_at": lock_data.get("reserved_at", ""),
        }
    except (json.JSONDecodeError, KeyError):
        return {"status": "free"}
