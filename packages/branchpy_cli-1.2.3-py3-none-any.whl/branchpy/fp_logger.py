# branchpy/fp_logger.py
"""
False Positive Logger

Tracks user-suppressed findings for FP/FN analysis.
Writes to CSV for easy import into audit tools.
"""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


class FPLogger:
    """
    Logger for false positive tracking.

    Writes suppressed findings to CSV with format:
    timestamp,ruleId,file,line,message,comment
    """

    def __init__(self, log_path: str | Path):
        """
        Initialize FP logger.

        Args:
            log_path: Path to CSV log file
        """
        self.log_path = Path(log_path)
        self._ensure_header()

    def _ensure_header(self) -> None:
        """Create log file with header if it doesn't exist."""
        if not self.log_path.exists():
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.log_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(
                    ["timestamp", "ruleId", "file", "line", "message", "comment"]
                )

    def log_suppression(
        self, rule_id: str, file_path: str, line: int, message: str, comment: str = ""
    ) -> None:
        """
        Log a suppressed finding.

        Args:
            rule_id: Rule that triggered the finding
            file_path: File path where finding occurred
            line: Line number
            message: Finding message
            comment: Optional comment explaining suppression
        """
        timestamp = datetime.now(timezone.utc).isoformat()

        with open(self.log_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([timestamp, rule_id, file_path, line, message, comment])

    def log_findings(
        self, findings: List[Dict[str, Any]], suppressed: bool = True
    ) -> int:
        """
        Log multiple findings at once.

        Args:
            findings: List of finding dicts with keys: rule_id, file, line, message, comment
            suppressed: Whether these are suppressed (default: True)

        Returns:
            Number of findings logged
        """
        count = 0
        for finding in findings:
            self.log_suppression(
                rule_id=finding.get("rule_id", "unknown"),
                file_path=finding.get("file", "<unknown>"),
                line=finding.get("line", 0),
                message=finding.get("message", ""),
                comment=finding.get("comment", ""),
            )
            count += 1
        return count


def create_fp_logger(log_path: Optional[str]) -> Optional[FPLogger]:
    """
    Create FP logger if log path is provided.

    Args:
        log_path: Path to log file, or None to skip logging

    Returns:
        FPLogger instance or None
    """
    if not log_path:
        return None

    try:
        return FPLogger(log_path)
    except Exception as e:
        # Graceful degradation - log to stderr but don't fail
        import sys

        print(f"Warning: Failed to create FP logger: {e}", file=sys.stderr)
        return None
