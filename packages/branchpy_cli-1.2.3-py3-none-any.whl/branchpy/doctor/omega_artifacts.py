"""
Omega Artifacts Reader for Doctor Command

Provides read-only, promotion-only access to Omega artifacts for doctor diagnostics.
No computation, no artifact generation - pure validation and metadata extraction.

Part of Track 2: Doctor ↔ Omega Coupling (v1.1.2+)
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


def find_omega_cache(project_root: Path) -> Optional[Path]:
    """
    Find Omega cache file in project.

    Args:
        project_root: Project root directory

    Returns:
        Path to omega.json if found, None otherwise
    """
    cache_path = project_root / ".branchpy" / "stats2" / "omega.json"
    return cache_path if cache_path.exists() else None


def find_pf_triads(project_root: Path) -> Optional[Path]:
    """
    Find PF triads artifact in project (checks multiple locations).

    Args:
        project_root: Project root directory

    Returns:
        Path to pf_triads.json if found, None otherwise
    """
    # Check canonical locations in order of preference
    candidate_paths = [
        project_root / ".branchpy" / "pf_triads.json",
        project_root / ".branchpy" / "pf_triads" / "pf_triads.json",
    ]

    for path in candidate_paths:
        if path.exists():
            return path

    return None


def read_json(path: Path) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Read and parse JSON file safely.

    Args:
        path: Path to JSON file

    Returns:
        Tuple of (parsed_data, error_message)
        - If successful: (dict, None)
        - If failed: (None, error_string)
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return (data, None)
    except json.JSONDecodeError as e:
        return (None, f"Invalid JSON: {e}")
    except Exception as e:
        return (None, f"Read error: {e}")


def validate_omega_cache_minimal(
    data: Dict[str, Any]
) -> Tuple[bool, Dict[str, Any], Optional[str]]:
    """
    Minimal validation of Omega cache structure.

    Does NOT enforce strict schema versions - just checks for expected keys
    and extracts metadata for diagnostic purposes.

    Args:
        data: Parsed JSON data

    Returns:
        Tuple of (is_valid, info_dict, error_message)
        - info_dict contains: schema_version, generated_at, branchpy_version
    """
    info = {
        "schema_version": None,
        "generated_at": None,
        "branchpy_version": None,
    }

    # Check for basic structure
    if not isinstance(data, dict):
        return (False, info, "Not a JSON object")

    # Extract metadata (optional fields - don't fail if missing)
    info["schema_version"] = data.get(
        "schema_version", data.get("omega_version", "unknown")
    )
    info["generated_at"] = data.get("generated_at", data.get("timestamp_utc", None))
    info["branchpy_version"] = data.get("branchpy_version", None)

    # Basic sanity check - should have some recognizable Omega keys
    omega_keys = ["nodes", "graph_summary", "metadata_summary", "pf_triads"]
    has_omega_structure = any(key in data for key in omega_keys)

    if not has_omega_structure:
        return (False, info, "Missing expected Omega keys (nodes, graph_summary, etc.)")

    return (True, info, None)


def validate_pf_triads_minimal(
    data: Dict[str, Any]
) -> Tuple[bool, Dict[str, Any], Optional[str]]:
    """
    Minimal validation of PF triads artifact structure.

    Args:
        data: Parsed JSON data

    Returns:
        Tuple of (is_valid, info_dict, error_message)
        - info_dict contains: schema_version, generated_at, pf_all, pf_core, pf_ui
    """
    info = {
        "schema_version": None,
        "generated_at": None,
        "pf_all": None,
        "pf_core": None,
        "pf_ui": None,
    }

    if not isinstance(data, dict):
        return (False, info, "Not a JSON object")

    # Extract metadata
    info["schema_version"] = data.get("schema_version", "unknown")
    info["generated_at"] = data.get("generated_at", None)

    # Check for PF triads (required for this artifact type)
    pf_triads = data.get("pf_triads", {})
    if not isinstance(pf_triads, dict):
        return (False, info, "Missing or invalid 'pf_triads' section")

    # Extract counts
    info["pf_all"] = pf_triads.get("pf_all", 0)
    info["pf_core"] = pf_triads.get("pf_core", 0)
    info["pf_ui"] = pf_triads.get("pf_ui", 0)

    return (True, info, None)
