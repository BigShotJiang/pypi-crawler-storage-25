"""
branchpy.ai.providers.ollama_provider — Ollama/OpenAI-Compatible Provider

Implementation for OpenAI-compatible API servers:
- Ollama (http://localhost:11434)
- LM Studio (http://localhost:1234)
- llama.cpp server
- vLLM
- Any other OpenAI-compatible endpoint

These servers implement the OpenAI Chat Completions API but run locally.

Governance ID: V1.0.0-AI-LOCAL
Privacy: 100% local, no data leaves machine
"""

from __future__ import annotations

from typing import List, Optional

# Third-party libraries
try:
    import openai
except ImportError:
    openai = None

from branchpy import logs

from ..models import (
    AIRequestBase,
    AIResponse,
    CodeReviewRequest,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from ..protocol import (
    ChatRequest,
    ChatResponse,
    ProviderConfigError,
    ProviderError,
    TokenUsage,
)
from ..provider_base import AIProvider

# Import safety layer for P2 integration
try:
    from branchpy.ai.safety import AISafetyLayer, get_safety_layer

    SAFETY_AVAILABLE = True
except ImportError:
    SAFETY_AVAILABLE = False
    from typing import TYPE_CHECKING

    if TYPE_CHECKING:
        from branchpy.ai.safety import AISafetyLayer
    else:
        AISafetyLayer = type(None)


class OllamaProvider(AIProvider):
    """
    AIProvider implementation for OpenAI-compatible local servers.

    Supports:
    - Ollama (default: http://localhost:11434)
    - LM Studio (default: http://localhost:1234)
    - llama.cpp server
    - vLLM
    - Any OpenAI-compatible API

    Privacy: Runs locally, no cloud communication
    Models: Llama 3.1, Mistral, Mixtral, etc.
    """

    def __init__(
        self,
        provider_id: str,
        api_key: Optional[str],
        config: dict,
        safety_layer: Optional[AISafetyLayer] = None,
    ):
        """
        Initialize the Ollama/OpenAI-compatible provider.

        Args:
            provider_id: The unique ID for this provider instance (e.g., 'local_llama')
            api_key: API key (optional for local servers)
            config: Provider configuration from ai_providers.toml
            safety_layer: Optional safety layer for redaction, consent, governance (P2)
        """
        if openai is None:
            raise ImportError(
                "Ollama provider requires 'openai' library. "
                "Please run 'pip install openai'"
            )

        self.id: str = provider_id
        self.name: str = config.get("name", "Ollama (Local)")
        self.type: str = "openai_compatible"
        self.config = config

        # Base URL (required for local servers)
        self.base_url = config.get("base_url", "http://localhost:11434/v1")

        # API key setup (optional for Ollama, some servers require it)
        api_key = api_key or "ollama"  # Dummy key for OpenAI client
        self._client = openai.OpenAI(api_key=api_key, base_url=self.base_url)
        self._configured = True

        # Model mappings
        self.models = config.get(
            "models",
            {
                "chat": "llama3.1:8b",  # Default Ollama model
                "code": "codellama:13b",
            },
        )

        # Capabilities
        capability_names = config.get(
            "capabilities",
            [
                "CODE_REVIEW",
                "DOC_GEN",
                "EXPLAIN_WARNING",
                "REFACTOR",
                "TRANSLATE",
            ],
        )
        self.capabilities: List[ProviderCapability] = [
            ProviderCapability(c) for c in capability_names
        ]

        # Data policy (fully local)
        self.data_policy = {
            "is_local": True,
            "stores_data": False,
            "shares_data": False,
            "safe_mode_allowed": True,
        }

        # Initialize safety layer (P2 integration)
        if SAFETY_AVAILABLE and safety_layer is None:
            self.safety = get_safety_layer()
        else:
            self.safety = safety_layer

        logs.info(
            "ai.ollama.init",
            f"Ollama provider '{self.id}' initialized",
            base_url=self.base_url,
            default_model=self.models.get("chat", "unknown"),
            safety_enabled=self.safety is not None,
        )

    def chat(self, request: ChatRequest) -> ChatResponse:
        """
        Execute chat request through safety layer.

        P2 Integration: All requests go through safety middleware for:
        - Redaction (P0)
        - Safe mode validation (P0)
        - Policy enforcement (P1)
        - Consent (P2) - local providers skip this
        - Governance logging (P1)

        Args:
            request: ChatRequest with messages
            project: Project name for governance logging

        Returns:
            ChatResponse from Ollama
        """
        if self.safety:
            # Route through safety layer
            return self.safety.process_request(
                request=request,
                provider=self,
                operation="chat",
                project="unknown",  # project parameter not in function signature
            )
        else:
            # Fallback: direct call (no safety layer)
            return self._raw_chat(request)

    def _raw_chat(self, request: ChatRequest) -> ChatResponse:
        """
        Raw chat implementation without safety layer.

        Called by safety middleware after redaction/consent/policy checks.

        Args:
            request: ChatRequest (may be redacted by safety layer)

        Returns:
            ChatResponse from Ollama
        """
        self._ensure_configured()

        model = request.model or self.models.get("chat", "llama3.1:8b")

        # Convert our Message format to OpenAI format
        messages = [
            {"role": msg.role, "content": msg.content} for msg in request.messages
        ]

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
            )

            content = response.choices[0].message.content or ""

            usage = None
            if response.usage:
                usage = TokenUsage(
                    prompt_tokens=response.usage.prompt_tokens,
                    completion_tokens=response.usage.completion_tokens,
                    total_tokens=response.usage.total_tokens,
                )

            return ChatResponse(
                content=content,
                model=model,
                finish_reason=response.choices[0].finish_reason or "stop",
                usage=usage,
                provider_id=self.id,
            )

        except Exception as e:
            logs.error(
                "ai.ollama.chat.error", f"Ollama chat failed: {str(e)}", model=model
            )
            raise ProviderError(f"Ollama chat failed: {str(e)}") from e

    def invoke(self, request: AIRequestBase) -> AIResponse:
        """Generic invocation method"""
        if request.capability == ProviderCapability.CODE_REVIEW:
            if not isinstance(request, CodeReviewRequest):
                raise TypeError(
                    f"Expected CodeReviewRequest for capability '{request.capability}', "
                    f"got {type(request).__name__}"
                )
            return self.review_code(request)
        elif request.capability == ProviderCapability.DOC_GEN:
            if not isinstance(request, DocGenRequest):
                raise TypeError(
                    f"Expected DocGenRequest for capability '{request.capability}', "
                    f"got {type(request).__name__}"
                )
            return self.generate_docs(request)
        elif request.capability == ProviderCapability.EXPLAIN_WARNING:
            if not isinstance(request, ExplainWarningRequest):
                raise TypeError(
                    f"Expected ExplainWarningRequest for capability '{request.capability}', "
                    f"got {type(request).__name__}"
                )
            return self.explain_warning(request)
        else:
            raise NotImplementedError(
                f"Capability '{request.capability}' not implemented by {self.id}"
            )

    def review_code(self, request: CodeReviewRequest) -> AIResponse:
        """
        Review code using local Llama model.

        Same interface as OpenAI but runs locally.
        """
        self._ensure_configured()

        # Select model
        model = self.models.get("code") or self.models.get("chat", "llama3.1:8b")

        # Build prompt
        system_prompt = (
            "You are a code reviewer for a Ren'Py visual novel project. "
            "Provide constructive feedback on code quality, style, and potential issues."
        )

        user_prompt = f"Review this Ren'Py code:\n\n```renpy\n{request.code}\n```"

        try:
            # Call local model
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,  # Lower for code review
                max_tokens=1000,
            )

            content = response.choices[0].message.content

            logs.info(
                "ai.ollama.review_code",
                "Code review completed (local)",
                model=model,
                tokens=response.usage.total_tokens if response.usage else 0,
            )

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=content,
                token_usage=(
                    {"total": response.usage.total_tokens} if response.usage else {}
                ),
                raw={"local": True, "base_url": self.base_url},
            )

        except Exception as e:
            logs.error(
                "ai.ollama.review_code.error",
                f"Ollama code review failed: {str(e)}",
                model=model,
            )
            raise

    def generate_docs(self, request: DocGenRequest) -> AIResponse:
        """Generate documentation using local model"""
        self._ensure_configured()

        model = self.models.get("chat", "llama3.1:8b")

        system_prompt = (
            "You are a technical documentation writer for Ren'Py projects. "
            "Generate clear, concise documentation from code."
        )

        user_prompt = (
            f"Generate documentation for this Ren'Py code:\n\n"
            f"```renpy\n{request.code}\n```\n\n"
            f"Format: {request.format}"
        )

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.5,
                max_tokens=1500,
            )

            content = response.choices[0].message.content

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=content,
                token_usage=(
                    {"total": response.usage.total_tokens} if response.usage else {}
                ),
                raw={"local": True},
            )

        except Exception as e:
            logs.error("ai.ollama.generate_docs.error", str(e))
            raise

    def explain_warning(self, request: ExplainWarningRequest) -> AIResponse:
        """Explain warning using local model"""
        self._ensure_configured()

        model = self.models.get("chat", "llama3.1:8b")

        system_prompt = (
            "You are a helpful assistant explaining Ren'Py warnings and errors. "
            "Provide clear explanations and actionable solutions."
        )

        user_prompt = (
            f"Explain this warning:\n\n"
            f"Warning: {request.warning_text}\n"
            f"Context: {request.context or 'None'}"
        )

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.4,
                max_tokens=800,
            )

            content = response.choices[0].message.content

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=content,
                token_usage=(
                    {"total": response.usage.total_tokens} if response.usage else {}
                ),
                raw={"local": True},
            )

        except Exception as e:
            logs.error("ai.ollama.explain_warning.error", str(e))
            raise

    def get_default_model_for(self, capability: ProviderCapability) -> str | None:
        """Get default model for capability"""
        if capability == ProviderCapability.CODE_REVIEW:
            return self.models.get("code") or self.models.get("chat")
        return self.models.get("chat")

    def check_health(self) -> bool:
        """
        Check if Ollama server is running and reachable.

        Returns:
            True if server responds, False otherwise
        """
        try:
            # Try to list models (lightweight check)
            models = self._client.models.list()
            logs.info(
                "ai.ollama.health_check",
                "Ollama server reachable",
                base_url=self.base_url,
            )
            return True
        except Exception as e:
            logs.warning(
                "ai.ollama.health_check.failed",
                f"Ollama server not reachable: {str(e)}",
                base_url=self.base_url,
            )
            return False

    def _ensure_configured(self) -> None:
        """Raise an error if the provider is not configured"""
        if not self._configured or self._client is None:
            raise ProviderConfigError(
                f"Ollama provider '{self.id}' is not configured. "
                f"Ensure Ollama is running at {self.base_url}"
            )
