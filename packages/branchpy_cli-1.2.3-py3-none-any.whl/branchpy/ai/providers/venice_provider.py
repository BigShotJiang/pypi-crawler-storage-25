"""
branchpy.ai.providers.venice_provider.py
BranchPy v1.0.0 — Venice.ai Provider

Venice.ai provider for privacy-focused cloud AI.
OpenAI-compatible API with uncensored models.

Privacy Notice:
- Venice.ai claims not to store or train on user data
- Still a cloud provider (data sent over network)
- Not allowed in safe mode (cloud provider)
- Read Venice.ai privacy policy before use

Features:
- OpenAI-compatible API (chat completions)
- Uncensored models
- Web search capabilities (optional)
- No data retention (per Venice policy)
- Competitive pricing

BQS Compliance:
- Input validation on all requests
- Privacy warnings for cloud usage
- Governance event logging
- Rate limit handling
"""

import os
from datetime import datetime
from typing import Any, Dict, List, Optional

try:
    from openai import OpenAI
    from openai.types.chat import ChatCompletion

    _OPENAI_AVAILABLE = True
except ImportError:
    OpenAI = None  # type: ignore[assignment,misc]
    ChatCompletion = None  # type: ignore[assignment,misc]
    _OPENAI_AVAILABLE = False

from ..protocol import (
    ChatRequest,
    ChatResponse,
    ProviderConfigError,
    ProviderError,
    TokenUsage,
)

# Import safety layer for P2 integration
try:
    from branchpy.ai.safety import AISafetyLayer, get_safety_layer

    SAFETY_AVAILABLE = True
except ImportError:
    SAFETY_AVAILABLE = False
    AISafetyLayer = None


class VeniceProvider:
    """
    AIProvider implementation for Venice.ai.

    Venice.ai is a privacy-focused cloud AI provider with OpenAI-compatible API.

    Key Features:
    - OpenAI-compatible API (easy migration)
    - Uncensored models (no content restrictions)
    - No data retention (per Venice.ai policy)
    - Optional web search integration
    - Competitive pricing

    Privacy Considerations:
    - Cloud provider (data sent to Venice.ai servers)
    - Venice claims no data storage or training
    - Read privacy policy: https://venice.ai/privacy
    - Not allowed in safe mode

    Configuration Example:
        [ai.providers.venice]
        type = "venice"
        api_key_env = "VENICE_API_KEY"
        base_url = "https://api.venice.ai/api/v1"
        default_model = "llama-3.3-70b"
        is_local = false
        safe_mode_allowed = false

    Models:
    - llama-3.3-70b (Meta's Llama 3.3, 70B params)
    - llama-3.1-405b (Meta's Llama 3.1, 405B params)
    - qwen3-235b (Alibaba's Qwen 3, 235B params)
    - venice-uncensored (Venice's uncensored model)

    Usage:
        provider = VeniceProvider(
            provider_id="venice",
            api_key="your-venice-api-key",
            base_url="https://api.venice.ai/api/v1",
            default_model="llama-3.3-70b"
        )

        request = ChatRequest(
            messages=[Message(role="user", content="Review this code...")],
            model="llama-3.3-70b"
        )

        response = provider.chat(request)
    """

    def __init__(
        self,
        provider_id: str,
        api_key: Optional[str] = None,
        base_url: str = "https://api.venice.ai/api/v1",
        default_model: str = "llama-3.3-70b",
        timeout: int = 60,
        enable_web_search: bool = False,
        safety_layer: AISafetyLayer = None,
    ):
        """
        Initialize Venice.ai provider.

        Args:
            provider_id: Unique identifier for this provider instance
            api_key: Venice.ai API key (or set VENICE_API_KEY env var)
            base_url: Venice API base URL
            default_model: Default model to use
            timeout: Request timeout in seconds
            enable_web_search: Enable web search for all requests
            safety_layer: Optional safety layer for redaction, consent, governance (P2)

        Raises:
            ProviderConfigurationError: If API key is missing
        """
        if not _OPENAI_AVAILABLE:
            raise ProviderConfigError(
                "VeniceProvider requires the openai library. "
                'Install AI support with: pip install "branchpy[ai]"'
            )

        self.provider_id = provider_id
        self.base_url = base_url
        self.default_model = default_model
        self.timeout = timeout
        self.enable_web_search = enable_web_search

        # Get API key from parameter or environment
        self._api_key = api_key or os.environ.get("VENICE_API_KEY")
        if not self._api_key:
            raise ProviderConfigError(
                "Venice.ai API key not found. Set VENICE_API_KEY environment variable "
                "or pass api_key parameter."
            )

        # Initialize OpenAI client (Venice is OpenAI-compatible)
        try:
            self.client = OpenAI(
                api_key=self._api_key,
                base_url=self.base_url,
                timeout=self.timeout,
            )
        except Exception as e:
            raise ProviderConfigError(f"Failed to initialize Venice client: {e}")

        # Supported models and capabilities
        self.models = {
            "llama-3.3-70b": {"context": 128000, "tier": "standard"},
            "llama-3.1-405b": {"context": 128000, "tier": "premium"},
            "qwen3-235b": {"context": 32768, "tier": "standard"},
            "venice-uncensored": {"context": 8192, "tier": "standard"},
        }

        self.capabilities = [
            "CODE_REVIEW",
            "DOC_GEN",
            "EXPLAIN_WARNING",
            "REFACTOR",
            "TRANSLATE",
        ]

        # Initialize safety layer (P2 integration)
        if SAFETY_AVAILABLE and safety_layer is None:
            self.safety = get_safety_layer()
        else:
            self.safety = safety_layer

    @property
    def is_local(self) -> bool:
        """Venice.ai is a cloud provider."""
        return False

    def chat(self, request: ChatRequest, project: str = None) -> ChatResponse:
        """
        Execute chat request through safety layer.

        P2 Integration: All requests go through safety middleware for:
        - Redaction (P0) - sensitive data removed
        - Safe mode validation (P0) - blocks if safe mode ON
        - Policy enforcement (P1) - payload limits, provider whitelist
        - Consent (P2) - user consent required (external provider)
        - Governance logging (P1) - audit trail

        Args:
            request: ChatRequest with messages and parameters
            project: Project name for governance logging

        Returns:
            ChatResponse with generated content

        Raises:
            SafeModeViolation: If safe mode is ON (external provider blocked)
            PolicyViolation: If policy violated (payload too large, no consent, etc.)
            ProviderError: If API request fails
        """
        if self.safety:
            # Route through safety layer (P2)
            return self.safety.process_request(
                request=request,
                provider=self,
                operation="chat",
                project=project or "unknown",
            )
        else:
            # Fallback: direct call with basic safety check
            if request.safe_mode:
                raise ProviderError(
                    "Venice.ai is a cloud provider and cannot be used in safe mode. "
                    "Use a local provider (Ollama, LM Studio) for safe mode."
                )
            return self._raw_chat(request)

    def _raw_chat(self, request: ChatRequest) -> ChatResponse:
        """
        Raw chat implementation without safety layer.

        Called by safety middleware after redaction/consent/policy checks.

        Args:
            request: ChatRequest (may be redacted by safety layer)

        Returns:
            ChatResponse from Venice.ai
        """

        # Model selection
        model = request.model or self.default_model

        # Convert our Message format to OpenAI format
        messages = [
            {"role": msg.role, "content": msg.content} for msg in request.messages
        ]

        # Build request parameters
        params: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": request.temperature,
        }

        # Add Venice-specific parameters if needed
        venice_params: Dict[str, Any] = {}

        if self.enable_web_search:
            venice_params["enable_web_search"] = "auto"

        # Disable Venice's default system prompt for code tasks
        # (we want clean, technical responses)
        venice_params["include_venice_system_prompt"] = False

        if venice_params:
            params["venice_parameters"] = venice_params

        try:
            # Make API call
            completion: ChatCompletion = self.client.chat.completions.create(**params)

            # Extract response
            choice = completion.choices[0]
            content = choice.message.content or ""

            # Extract token usage
            usage = None
            if completion.usage:
                usage = TokenUsage(
                    prompt_tokens=completion.usage.prompt_tokens,
                    completion_tokens=completion.usage.completion_tokens,
                    total_tokens=completion.usage.total_tokens,
                )

            return ChatResponse(
                content=content,
                model=completion.model,
                usage=usage,
                provider_id=self.provider_id,
                finish_reason=choice.finish_reason,
                created_at=datetime.now(),
            )

        except Exception as e:
            error_msg = f"Venice.ai API error: {str(e)}"
            raise ProviderError(error_msg) from e

    def validate_config(self) -> bool:
        """
        Validate Venice.ai configuration.

        Returns:
            True if config is valid

        Raises:
            ProviderConfigError: If config is invalid
        """
        if not self._api_key:
            raise ProviderConfigError("Venice.ai API key is required")

        if not self.base_url:
            raise ProviderConfigError("Venice.ai base URL is required")

        if not self.default_model:
            raise ProviderConfigError("Default model is required")

        return True

    def estimate_cost(self, request: ChatRequest) -> float:
        """
        Estimate cost of request (approximate).

        Venice.ai pricing (as of 2024):
        - llama-3.3-70b: ~$0.50-1.00 per 1M tokens
        - llama-3.1-405b: ~$3.00-5.00 per 1M tokens
        - qwen3-235b: ~$1.00-2.00 per 1M tokens

        Args:
            request: ChatRequest to estimate

        Returns:
            Estimated cost in USD (approximate)
        """
        # Rough token estimation (4 chars per token)
        total_chars = sum(len(msg.content) for msg in request.messages)
        estimated_tokens = total_chars // 4

        # Estimate completion tokens (roughly same as prompt)
        estimated_total_tokens = estimated_tokens * 2

        # Model-specific pricing (per 1M tokens)
        model = request.model or self.default_model
        if "405b" in model:
            cost_per_1m = 4.0  # Premium model
        elif "235b" in model:
            cost_per_1m = 1.5  # Mid-tier
        else:
            cost_per_1m = 0.75  # Standard models

        estimated_cost = (estimated_total_tokens / 1_000_000) * cost_per_1m
        return estimated_cost

    def check_health(self) -> bool:
        """
        Check if Venice.ai API is reachable.

        Returns:
            True if API is healthy, False otherwise
        """
        try:
            # Make a minimal request to check connectivity
            response = self.client.chat.completions.create(
                model=self.default_model,
                messages=[{"role": "user", "content": "Hi"}],
                max_tokens=5,
            )
            return bool(response.choices)
        except Exception:
            return False

    def data_policy(self) -> Dict[str, Any]:
        """
        Get Venice.ai's data policy information.

        Returns:
            Dictionary with privacy policy details
        """
        return {
            "provider_name": "Venice.ai",
            "provider_type": "cloud",
            "is_local": False,
            "stores_data": False,  # Per Venice.ai claims
            "trains_on_data": False,  # Per Venice.ai claims
            "shares_data_third_party": False,  # Per Venice.ai claims
            "privacy_level": "high",  # Venice.ai is privacy-focused
            "privacy_policy_url": "https://venice.ai/privacy",
            "data_retention": "none",  # Per Venice.ai claims
            "encryption_in_transit": True,
            "encryption_at_rest": "not_applicable",  # No storage
            "compliance": ["GDPR", "CCPA"],  # Typical for privacy-focused services
            "warning": (
                "Venice.ai is a cloud provider. While they claim not to store "
                "or train on your data, your code will be sent to their servers. "
                "Review their privacy policy before use. "
                "For 100% privacy, use a local provider (Ollama, LM Studio)."
            ),
        }

    def available_models(self) -> List[str]:
        """
        Get list of available Venice.ai models.

        Returns:
            List of model IDs
        """
        return list(self.models.keys())

    def model_info(self, model_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific model.

        Args:
            model_id: Model identifier

        Returns:
            Model information dict or None if not found
        """
        return self.models.get(model_id)
