"""
branchpy.ai.providers.openai_provider — OpenAI Provider

Implementation of the AIProvider protocol for OpenAI's API (GPT models).

Governance ID: V0.9.5-AI-BYOAI
"""

from __future__ import annotations

import json
from typing import Set

# Third-party libraries
try:
    import openai
except ImportError:
    openai = None

from branchpy import logs

from ..models import (
    AIRequestBase,
    AIResponse,
    CodeReviewRequest,
    DataClassification,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from ..provider_base import AIProvider, ProviderConfigurationError


class OpenAIProvider(AIProvider):
    """
    AIProvider implementation for OpenAI's API.

    Connects to GPT-3.5, GPT-4, and other OpenAI models.
    """

    def __init__(self, provider_id: str, api_key: str | None, config: dict):
        """
        Initialize the OpenAI provider.

        Args:
            provider_id: The unique ID for this provider instance.
            api_key: The OpenAI API key.
            config: Provider configuration dictionary from ai_providers.toml.
        """
        if openai is None:
            # This check is for developer experience; if the lib is missing, fail early.
            raise ImportError(
                "OpenAI provider requires 'openai' library. Please run 'pip install openai'."
            )

        self.id: str = provider_id
        self.name: str = config.get("name", "OpenAI")
        self.type: str = "openai"
        self.config = config

        # API key setup
        self._configured = bool(api_key)
        if not self._configured:
            logs.warning(
                "ai.openai.no_key",
                f"OpenAI provider '{self.id}' initialized without API key. Calls will fail.",
            )
            self._client = None
        else:
            self._client = openai.OpenAI(
                api_key=api_key, base_url=config.get("base_url")
            )

        # Model mappings
        self.models = config.get("models", {})

        # Capabilities
        capability_names = config.get("capabilities", [])
        self.capabilities: Set[ProviderCapability] = {
            ProviderCapability(c) for c in capability_names
        }

        # Data policy
        self.data_policy = config.get("data_policy", {})

    def invoke(self, request: AIRequestBase) -> AIResponse:
        if request.capability == ProviderCapability.CODE_REVIEW:
            if not isinstance(request, CodeReviewRequest):
                raise TypeError(
                    f"Expected CodeReviewRequest for capability '{request.capability}', got {type(request).__name__}"
                )
            return self.review_code(request)
        elif request.capability == ProviderCapability.DOC_GEN:
            if not isinstance(request, DocGenRequest):
                raise TypeError(
                    f"Expected DocGenRequest for capability '{request.capability}', got {type(request).__name__}"
                )
            return self.generate_docs(request)
        elif request.capability == ProviderCapability.EXPLAIN_WARNING:
            if not isinstance(request, ExplainWarningRequest):
                raise TypeError(
                    f"Expected ExplainWarningRequest for capability '{request.capability}', got {type(request).__name__}"
                )
            return self.explain_warning(request)
        else:
            # A real implementation would either have a generic chat handler
            # or raise an error for unsupported capabilities.
            raise NotImplementedError(
                f"Capability '{request.capability}' not implemented by {self.id}"
            )

    def _ensure_configured(self) -> None:
        """Raise an error if the provider is used without being configured."""
        if not self._configured or self._client is None:
            raise ProviderConfigurationError(
                f"OpenAI provider '{self.id}' is not configured (missing API key)."
            )

    def get_default_model_for(self, capability: ProviderCapability) -> str | None:
        """Get the configured default model for a capability."""
        return self.models.get(capability.value)

    def _check_policy(self, data_class: DataClassification):
        """Check if the data policy allows this request."""
        self._ensure_configured()
        allowed_classes = self.data_policy.get(
            "data_class_allowed", ["public", "internal", "sensitive", "restricted"]
        )
        if data_class.value not in allowed_classes:
            raise ValueError(
                f"Provider '{self.id}' policy forbids data of class '{data_class.value}'"
            )

    def review_code(self, request: CodeReviewRequest) -> AIResponse:
        """Perform code review using an OpenAI model."""
        self._ensure_configured()
        self._check_policy(request.data_class)

        prompt = f"""Review the following {request.language} code from file '{request.file_path or "unknown"}'.
Identify potential bugs, style issues, and areas for improvement.

Code:
```{request.language}
{request.code}
```

Provide your response as a JSON object with two keys:
1. "findings": An array of objects, each with "severity" (error, warning, info), "message", "line", and "suggestion".
2. "summary": A brief, one-paragraph summary of the code's quality.
"""

        model = (
            self.get_default_model_for(ProviderCapability.CODE_REVIEW)
            or "gpt-4-turbo-preview"
        )

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert code review assistant.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
                response_format={"type": "json_object"},
                max_tokens=self.data_policy.get("max_tokens_per_request", 4096),
            )

            result = json.loads(response.choices[0].message.content)

            # Adapt to the new AIResponse model
            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=result.get("summary", "No summary provided."),
                suggestions=[f["message"] for f in result.get("findings", [])],
                token_usage={
                    "prompt": response.usage.prompt_tokens,
                    "completion": response.usage.completion_tokens,
                    "total": response.usage.total_tokens,
                },
                latency_ms=response.response_ms,
                raw=response.model_dump(),
            )
        except Exception as e:
            logs.error("ai.openai.review_error", f"OpenAI code review failed: {e}")
            raise RuntimeError(f"OpenAI API error: {e}") from e

    def generate_docs(self, request: DocGenRequest) -> AIResponse:
        """Generate documentation using an OpenAI model."""
        self._ensure_configured()
        self._check_policy(request.data_class)

        prompt = f"""Generate a docstring for the following {request.language} code.
Follow standard conventions for {request.language} documentation.

Code:
```{request.language}
{request.code}
```
"""
        model = (
            self.get_default_model_for(ProviderCapability.DOC_GEN)
            or "gpt-4-turbo-preview"
        )

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a technical writer specializing in software documentation.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.5,
            )

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=response.choices[0].message.content,
                token_usage={
                    "prompt": response.usage.prompt_tokens,
                    "completion": response.usage.completion_tokens,
                    "total": response.usage.total_tokens,
                },
                latency_ms=response.response_ms,
                raw=response.model_dump(),
            )
        except Exception as e:
            logs.error("ai.openai.docgen_error", f"OpenAI doc generation failed: {e}")
            raise RuntimeError(f"OpenAI API error: {e}") from e

    def explain_warning(self, request: ExplainWarningRequest) -> AIResponse:
        """Explain a warning or error using an OpenAI model."""
        self._ensure_configured()
        self._check_policy(request.data_class)

        prompt = f"""Explain the following warning/error message:

Message: "{request.warning_message}"

Context:
- Source File: {request.file_path or 'N/A'}
- Code Snippet:
```
{request.code or 'No code context provided.'}
```

Provide a clear explanation of the root cause and a step-by-step guide on how to fix it.
"""
        model = (
            self.get_default_model_for(ProviderCapability.EXPLAIN_WARNING)
            or "gpt-4-turbo-preview"
        )

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a helpful debugging assistant for software developers.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
            )

            content = response.choices[0].message.content
            # A more robust implementation would parse the response into explanation/suggestion
            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=content,
                token_usage={
                    "prompt": response.usage.prompt_tokens,
                    "completion": response.usage.completion_tokens,
                    "total": response.usage.total_tokens,
                },
                latency_ms=response.response_ms,
                raw=response.model_dump(),
            )
        except Exception as e:
            logs.error("ai.openai.explain_error", f"OpenAI explain warning failed: {e}")
            raise RuntimeError(f"OpenAI API error: {e}") from e

    def generic_chat(self, prompt: str, data_class: DataClassification) -> str:
        """Handle a generic chat prompt."""
        self._ensure_configured()
        self._check_policy(data_class)
        model = (
            self.get_default_model_for(ProviderCapability.CHAT_HELP)
            or "gpt-4-turbo-preview"
        )

        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.6,
            )
            return response.choices[0].message.content
        except Exception as e:
            logs.error("ai.openai.chat_error", f"OpenAI chat failed: {e}")
            raise RuntimeError(f"OpenAI API error: {e}") from e

    def health_check(self) -> bool:
        """Check if the OpenAI API is accessible."""
        if not self._configured:
            return False
        try:
            self._ensure_configured()
            self._client.models.list(limit=1)
            return True
        except Exception as e:
            logs.warning(
                "ai.openai.health_check_failed", f"OpenAI health check failed: {e}"
            )
            return False
