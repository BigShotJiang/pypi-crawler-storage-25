"""
branchpy.ai.providers.anthropic_provider — Anthropic Provider

Implementation of the AIProvider protocol for Anthropic's API (Claude models).

Governance ID: V0.9.5-AI-BYOAI
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict
from typing import Set

# Third-party libraries
try:
    import anthropic
except ImportError:
    anthropic = None

from branchpy import logs

from ..models import (
    AIRequestBase,
    AIResponse,
    CodeReviewRequest,
    DataClassification,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from ..provider_base import AIProvider, ProviderConfigurationError


class AnthropicProvider(AIProvider):
    """
    AIProvider implementation for Anthropic's API.

    Connects to Claude 3, Claude 3.5, and other Anthropic models.
    """

    def __init__(self, provider_id: str, api_key: str | None, config: dict):
        """
        Initialize the Anthropic provider.

        Args:
            provider_id: The unique ID for this provider instance.
            api_key: The Anthropic API key.
            config: Provider configuration dictionary from ai_providers.toml.

        Raises:
            ImportError: If the 'anthropic' library is not installed.
            ProviderConfigurationError: If API key is not found.
        """
        if anthropic is None:
            raise ImportError(
                "Anthropic provider requires 'anthropic' library. Please run 'pip install anthropic'."
            )

        self.id: str = provider_id
        self.name: str = config.get("name", "Anthropic")

        # API Key
        if not api_key:
            raise ProviderConfigurationError(
                f"API key not found for provider '{self.id}'."
            )

        self.client = anthropic.Anthropic(api_key=api_key)

        # Model mappings
        self.models = config.get("models", {})

        # Capabilities
        capability_names = config.get("capabilities", [])
        self.capabilities: Set[ProviderCapability] = {
            ProviderCapability(c) for c in capability_names
        }

        # Data policy
        self.data_policy = config.get("data_policy", {})

    def invoke(self, request: AIRequestBase) -> AIResponse:
        if request.capability == ProviderCapability.CODE_REVIEW:
            if not isinstance(request, CodeReviewRequest):
                raise TypeError(
                    f"Expected CodeReviewRequest, got {type(request).__name__}"
                )
            return self.review_code(request)
        elif request.capability == ProviderCapability.DOC_GEN:
            if not isinstance(request, DocGenRequest):
                raise TypeError(f"Expected DocGenRequest, got {type(request).__name__}")
            return self.generate_docs(request)
        elif request.capability == ProviderCapability.EXPLAIN_WARNING:
            if not isinstance(request, ExplainWarningRequest):
                raise TypeError(
                    f"Expected ExplainWarningRequest, got {type(request).__name__}"
                )
            return self.explain_warning(request)
        else:
            raise NotImplementedError(
                f"Capability '{request.capability}' not implemented by {self.id}"
            )

    def get_default_model_for(self, capability: ProviderCapability) -> str | None:
        """Get the configured default model for a capability."""
        return self.models.get(capability.value)

    def _check_policy(self, data_class: DataClassification):
        """Check if the data policy allows this request."""
        allowed_classes = self.data_policy.get(
            "data_class_allowed", ["public", "internal", "sensitive"]
        )
        if data_class.value not in allowed_classes:
            raise ValueError(
                f"Provider '{self.id}' policy forbids data of class '{data_class.value}'"
            )

    def review_code(self, request: CodeReviewRequest) -> AIResponse:
        """Perform code review using a Claude model."""
        self._check_policy(request.data_class)

        prompt = f"""You are an expert code review assistant. Review the following {request.language} code from file '{request.file_path or "unknown"}'.
Identify potential bugs, style issues, and areas for improvement.

Code:
```{request.language}
{request.code}
```

Provide your response as a valid JSON object with two keys:
1. "findings": An array of objects, each with "severity" (error, warning, info), "message", "line", and "suggestion".
2. "summary": A brief, one-paragraph summary of the code's quality.
"""

        model = (
            self.get_default_model_for(ProviderCapability.CODE_REVIEW)
            or "claude-3-5-sonnet-20240620"
        )

        try:
            response = self.client.messages.create(
                model=model,
                max_tokens=self.data_policy.get("max_tokens_per_request", 4096),
                temperature=0.2,
                system="You are an expert code review assistant that provides output in JSON format.",
                messages=[{"role": "user", "content": prompt}],
            )

            # Claude may wrap JSON in ```json ... ```, so we need to extract it.
            raw_content = response.content[0].text
            json_content = self._extract_json(raw_content)
            result = json.loads(json_content)

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=result.get("summary", "No summary provided."),
                suggestions=[f.get("message", "") for f in result.get("findings", [])],
                token_usage={
                    "prompt": response.usage.input_tokens,
                    "completion": response.usage.output_tokens,
                    "total": response.usage.input_tokens + response.usage.output_tokens,
                },
                latency_ms=response.response_ms,
                raw={"model": model, "usage": asdict(response.usage)},
            )
        except Exception as e:
            logs.error(
                "ai.anthropic.review_error", f"Anthropic code review failed: {e}"
            )
            raise RuntimeError(f"Anthropic API error: {e}") from e

    def generate_docs(self, request: DocGenRequest) -> AIResponse:
        """Generate documentation using a Claude model."""
        self._check_policy(request.data_class)

        prompt = f"""Generate a docstring for the following {request.language} code.
Follow standard conventions for {request.language} documentation.

Code:
```{request.language}
{request.code}
```
"""
        model = (
            self.get_default_model_for(ProviderCapability.DOC_GEN)
            or "claude-3-5-sonnet-20240620"
        )

        try:
            response = self.client.messages.create(
                model=model,
                max_tokens=self.data_policy.get("max_tokens_per_request", 4096),
                temperature=0.5,
                system="You are a technical writer specializing in software documentation.",
                messages=[{"role": "user", "content": prompt}],
            )

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=response.content[0].text,
                token_usage={
                    "prompt": response.usage.input_tokens,
                    "completion": response.usage.output_tokens,
                    "total": response.usage.input_tokens + response.usage.output_tokens,
                },
                latency_ms=response.response_ms,
                raw={"model": model, "usage": asdict(response.usage)},
            )
        except Exception as e:
            logs.error(
                "ai.anthropic.docgen_error", f"Anthropic doc generation failed: {e}"
            )
            raise RuntimeError(f"Anthropic API error: {e}") from e

    def explain_warning(self, request: ExplainWarningRequest) -> AIResponse:
        """Explain a warning or error using a Claude model."""
        self._check_policy(request.data_class)

        prompt = f"""Explain the following warning/error message:

Message: "{request.warning_message}"

Context:
- Source File: {request.file_path or 'N/A'}
- Code Snippet:
```
{request.code or 'No code context provided.'}
```

Provide a clear explanation of the root cause and a step-by-step guide on how to fix it.
"""
        model = (
            self.get_default_model_for(ProviderCapability.EXPLAIN_WARNING)
            or "claude-3-5-sonnet-20240620"
        )

        try:
            response = self.client.messages.create(
                model=model,
                max_tokens=self.data_policy.get("max_tokens_per_request", 4096),
                temperature=0.3,
                system="You are a helpful debugging assistant for software developers.",
                messages=[{"role": "user", "content": prompt}],
            )

            return AIResponse(
                request_id=request.id,
                provider_id=self.id,
                capability=request.capability,
                content=response.content[0].text,
                token_usage={
                    "prompt": response.usage.input_tokens,
                    "completion": response.usage.output_tokens,
                    "total": response.usage.input_tokens + response.usage.output_tokens,
                },
                latency_ms=response.response_ms,
                raw={"model": model, "usage": asdict(response.usage)},
            )
        except Exception as e:
            logs.error(
                "ai.anthropic.explain_error", f"Anthropic explain warning failed: {e}"
            )
            raise RuntimeError(f"Anthropic API error: {e}") from e

    def generic_chat(self, prompt: str, data_class: DataClassification) -> str:
        """Handle a generic chat prompt."""
        self._check_policy(data_class)
        model = (
            self.get_default_model_for(ProviderCapability.CHAT_HELP)
            or "claude-3-5-sonnet-20240620"
        )

        try:
            response = self.client.messages.create(
                model=model,
                max_tokens=self.data_policy.get("max_tokens_per_request", 4096),
                temperature=0.6,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        except Exception as e:
            logs.error("ai.anthropic.chat_error", f"Anthropic chat failed: {e}")
            raise RuntimeError(f"Anthropic API error: {e}") from e

    def health_check(self) -> bool:
        """Check if the Anthropic API is accessible."""
        try:
            # Anthropic client doesn't have a simple health check, so we do a lightweight operation.
            self.client.count_tokens("health check")
            return True
        except Exception as e:
            logs.warning(
                "ai.anthropic.health_check_failed",
                f"Anthropic health check failed: {e}",
            )
            return False

    def _extract_json(self, text: str) -> str:
        """Extracts a JSON object from a string that might contain markdown code fences."""
        match = re.search(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
        if match:
            return match.group(1)
        return text
