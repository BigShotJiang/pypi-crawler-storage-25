# c:\Users\terru\OneDrive\Documents\BranchPy\BranchPyApp\branchpy\ai\providers\http_provider.py

from typing import Any, Dict, Optional

import requests

from ..models import (
    AIRequestBase,
    AIResponse,
    CodeReviewRequest,
    DataClassification,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from ..provider_base import AIProvider, ProviderConfigurationError


class HTTPProvider(AIProvider):
    """
    A generic AI provider that interacts with any HTTP endpoint.
    The endpoint is expected to conform to a specific request/response format.
    """

    type: str = "http"

    def __init__(
        self, provider_id: str, config: Dict[str, Any], api_key: Optional[str] = None
    ):
        self.id = provider_id
        self.name = config.get("name", "Generic HTTP Provider")
        self.url = config.get("url")
        self.api_key = api_key
        self.config = config

        if not self.url:
            raise ProviderConfigurationError(
                "HTTPProvider requires a 'url' in its configuration."
            )

        # The provider reports which capabilities it supports.
        # For a generic wrapper, we can make this configurable.
        supported_caps = self.config.get(
            "capabilities", ["code_review", "doc_gen", "explain_warning", "chat_help"]
        )
        self.capabilities = [ProviderCapability(c) for c in supported_caps]

    def invoke(self, request: AIRequestBase) -> AIResponse:
        if request.capability == ProviderCapability.CODE_REVIEW:
            if not isinstance(request, CodeReviewRequest):
                raise TypeError(
                    f"Expected CodeReviewRequest, got {type(request).__name__}"
                )
            return self.review_code(request)
        elif request.capability == ProviderCapability.DOC_GEN:
            if not isinstance(request, DocGenRequest):
                raise TypeError(f"Expected DocGenRequest, got {type(request).__name__}")
            return self.generate_docs(request)
        elif request.capability == ProviderCapability.EXPLAIN_WARNING:
            if not isinstance(request, ExplainWarningRequest):
                raise TypeError(
                    f"Expected ExplainWarningRequest, got {type(request).__name__}"
                )
            return self.explain_warning(request)
        else:
            raise NotImplementedError(
                f"Capability '{request.capability}' not implemented by {self.id}"
            )

    def _make_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Makes a POST request to the configured endpoint.

        Raises:
            ProviderConfigurationError: If URL is not configured
            requests.exceptions.RequestException: If HTTP request fails
        """
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        if not self.url:
            raise ProviderConfigurationError("HTTPProvider url is not configured.")

        try:
            response = requests.post(
                self.url, json=payload, timeout=30, headers=headers
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.Timeout as e:
            raise requests.exceptions.RequestException(
                f"Timeout calling {self.url}: {e}"
            ) from e
        except requests.exceptions.HTTPError as e:
            raise requests.exceptions.RequestException(
                f"HTTP error from {self.url}: {e}"
            ) from e
        except requests.exceptions.RequestException as e:
            raise requests.exceptions.RequestException(
                f"Request failed to {self.url}: {e}"
            ) from e

    def get_default_model_for(self, capability: ProviderCapability) -> str | None:
        """For a generic HTTP provider, the model is defined by the endpoint."""
        return self.config.get("models", {}).get(capability.value, "default")

    def review_code(self, request: CodeReviewRequest) -> AIResponse:
        """
        Performs a code review via the HTTP endpoint.
        """
        payload = {
            "task": "code_review",
            "request": {
                "code": request.code,
                "language": request.language,
                "file_path": request.file_path,
                "context_before": request.context_before,
                "context_after": request.context_after,
                "data_class": request.data_class.value,
            },
        }
        response_data = self._make_request(payload)

        # Reconstruct the dataclass object from the JSON response
        return AIResponse(
            request_id=request.id,
            provider_id=self.id,
            capability=request.capability,
            content=response_data.get("summary", "No summary provided."),
            suggestions=[
                f.get("message", "") for f in response_data.get("findings", [])
            ],
            is_error="error" in response_data,
            raw=response_data.get("metadata", {}),
        )

    def generate_docs(self, request: DocGenRequest) -> AIResponse:
        """
        Generates documentation via the HTTP endpoint.
        """
        payload = {
            "task": "docgen",
            "request": {
                "code": request.code,
                "language": request.language,
                "symbol_name": request.symbol_name,
                "data_class": request.data_class.value,
            },
        }
        response_data = self._make_request(payload)
        return AIResponse(
            request_id=request.id,
            provider_id=self.id,
            capability=request.capability,
            content=response_data.get("content", "[SKELETON] Error from HTTPProvider."),
            is_error="error" in response_data,
            raw=response_data.get("metadata", {}),
        )

    def explain_warning(self, request: ExplainWarningRequest) -> AIResponse:
        """
        Explains a warning via the HTTP endpoint.
        """
        payload = {
            "task": "explain_warning",
            "request": {
                "warning_message": request.warning_message,
                "code": request.code,
                "file_path": request.file_path,
                "data_class": request.data_class.value,
            },
        }
        response_data = self._make_request(payload)
        return AIResponse(
            request_id=request.id,
            provider_id=self.id,
            capability=request.capability,
            content=response_data.get(
                "explanation", "[SKELETON] Error from HTTPProvider."
            ),
            suggestions=[str(s)] if (s := response_data.get("suggestion")) else [],
            is_error="error" in response_data,
            raw=response_data.get("metadata", {}),
        )

    def generic_chat(self, prompt: str, data_class: DataClassification) -> str:
        """
        Sends a generic chat prompt to the HTTP endpoint.
        """
        payload = {
            "task": "generic_chat",
            "request": {
                "prompt": prompt,
                "data_class": data_class.value,
            },
        }
        response_data = self._make_request(payload)
        return response_data.get("response_text", "[SKELETON] Error from HTTPProvider.")

    def check_health(self) -> bool:
        """
        Checks the health of the endpoint via a GET request.

        Returns:
            True if endpoint responds with 200, False otherwise
        """
        if not self.url:
            return False
        try:
            response = requests.get(self.url, timeout=5)
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False
