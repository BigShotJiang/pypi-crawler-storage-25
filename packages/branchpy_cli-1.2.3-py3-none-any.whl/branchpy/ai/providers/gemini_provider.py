# c:\Users\terru\OneDrive\Documents\BranchPy\BranchPyApp\branchpy\ai\providers\gemini_provider.py
# c:\Users\terru\OneDrive\Documents\BranchPy\BranchPyApp\branchpy\ai\providers\gemini_provider.py

from __future__ import annotations

from typing import Any, Dict

try:
    import google.generativeai as genai
except ImportError:
    genai = None  # type: ignore[assignment]

from ..models import (
    AIRequestBase,
    AIResponse,
    CodeReviewRequest,
    DataClassification,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from ..provider_base import AIProvider, ProviderConfigurationError


class GeminiProvider(AIProvider):
    """
    AI Provider for Google's Gemini models.
    """

    def __init__(self, provider_id: str, api_key: str | None, config: Dict[str, Any]):
        self.id = provider_id
        self.name = config.get("name", "Google Gemini")

        if genai is None:
            raise ProviderConfigurationError(
                "GeminiProvider requires google-generativeai. "
                'Install AI support with: pip install "branchpy[ai]"'
            )

        if not api_key:
            raise ProviderConfigurationError("GeminiProvider requires an API key.")

        genai.configure(api_key=api_key)

        self.config = config
        self.capabilities = {
            ProviderCapability.CODE_REVIEW,
            ProviderCapability.DOC_GEN,
            ProviderCapability.EXPLAIN_WARNING,
            ProviderCapability.CHAT_HELP,
        }
        # This is a simplification. A real implementation would check model availability.
        self.models = {
            ProviderCapability.CODE_REVIEW: "gemini-pro",
            ProviderCapability.DOC_GEN: "gemini-pro",
            ProviderCapability.EXPLAIN_WARNING: "gemini-pro",
            ProviderCapability.CHAT_HELP: "gemini-pro",
        }

    def invoke(self, request: AIRequestBase) -> AIResponse:
        if request.capability == ProviderCapability.CODE_REVIEW:
            if not isinstance(request, CodeReviewRequest):
                raise TypeError(
                    f"Expected CodeReviewRequest, got {type(request).__name__}"
                )
            return self.review_code(request)
        elif request.capability == ProviderCapability.DOC_GEN:
            if not isinstance(request, DocGenRequest):
                raise TypeError(f"Expected DocGenRequest, got {type(request).__name__}")
            return self.generate_docs(request)
        elif request.capability == ProviderCapability.EXPLAIN_WARNING:
            if not isinstance(request, ExplainWarningRequest):
                raise TypeError(
                    f"Expected ExplainWarningRequest, got {type(request).__name__}"
                )
            return self.explain_warning(request)
        else:
            raise NotImplementedError(
                f"Capability '{request.capability}' not implemented by {self.id}"
            )

    def get_default_model_for(self, capability: ProviderCapability) -> str | None:
        return self.models.get(capability)

    def _get_model(self, capability: ProviderCapability) -> genai.GenerativeModel:
        model_name = self.get_default_model_for(capability)
        if not model_name:
            raise ProviderConfigurationError(
                f"No default model configured for capability: {capability.value}"
            )
        return genai.GenerativeModel(model_name)

    def review_code(self, request: CodeReviewRequest) -> AIResponse:
        """
        Performs a code review using Gemini.
        SKELETON IMPLEMENTATION
        """
        # This is a placeholder. A real implementation would construct a detailed prompt.
        prompt = (
            f"Review the following {request.language} code:\n\n```\n{request.code}\n```"
        )

        model = self._get_model(ProviderCapability.CODE_REVIEW)
        response = model.generate_content(prompt)

        # This is a placeholder. A real implementation would parse the response.
        return AIResponse(
            request_id=request.id,
            provider_id=self.id,
            capability=request.capability,
            content="[SKELETON] Gemini code review summary.",
            suggestions=["[SKELETON] Gemini code review placeholder."],
            token_usage={"total": response.usage_metadata.total_token_count},
            raw={"model": model.model_name, "usage": response.usage_metadata},
        )

    def generate_docs(self, request: DocGenRequest) -> AIResponse:
        """
        Generates documentation using Gemini.
        SKELETON IMPLEMENTATION
        """
        prompt = f"Generate a docstring for the following {request.language} code:\n\n```\n{request.code}\n```"

        model = self._get_model(ProviderCapability.DOC_GEN)
        response = model.generate_content(prompt)

        return AIResponse(
            request_id=request.id,
            provider_id=self.id,
            capability=request.capability,
            content=response.text,
            token_usage={"total": response.usage_metadata.total_token_count},
            raw={"model": model.model_name, "usage": response.usage_metadata},
        )

    def explain_warning(self, request: ExplainWarningRequest) -> AIResponse:
        """
        Explains a warning using Gemini.
        SKELETON IMPLEMENTATION
        """
        prompt = f"Explain this warning: '{request.warning_message}'.\nContext: {request.code}"

        model = self._get_model(ProviderCapability.EXPLAIN_WARNING)
        response = model.generate_content(prompt)

        return AIResponse(
            request_id=request.id,
            provider_id=self.id,
            capability=request.capability,
            content=response.text,
            suggestions=["[SKELETON] Suggestion from Gemini."],
            token_usage={"total": response.usage_metadata.total_token_count},
            raw={"model": model.model_name, "usage": response.usage_metadata},
        )

    def generic_chat(self, prompt: str, data_class: DataClassification) -> str:
        """
        Generic chat/query interface using Gemini.
        """
        if data_class == DataClassification.RESTRICTED:
            return "Error: Cannot send RESTRICTED data to Gemini."

        model = self._get_model(ProviderCapability.CHAT_HELP)
        response = model.generate_content(prompt)
        return response.text

    def health_check(self) -> bool:
        """
        Checks if the Gemini API is available by listing models.
        """
        try:
            # A simple way to check health is to list available models.
            # This makes an actual API call.
            list(genai.list_models())
            return True
        except Exception:
            return False
