"""
branchpy.ai.provider_base — AI Provider Protocol and Request/Response Models

Defines the vendor-neutral interface that all AI providers must implement.

Governance ID: V0.9.5-AI-BYOAI
"""

from __future__ import annotations

from typing import List, Protocol, runtime_checkable

from .models import AIRequestBase, AIResponse, ProviderCapability


class ProviderConfigurationError(Exception):
    """Custom exception for provider configuration errors."""

    pass


@runtime_checkable
class AIProvider(Protocol):
    """
    Protocol for AI providers.

    All providers must implement this interface to be usable in BranchPy.
    Providers can support a subset of capabilities.

    The `type` attribute indicates the kind of service the provider offers,
    such as 'LLM' for Large Language Model service (e.g., OpenAI, Anthropic, Google Gemini).
    """

    id: str
    name: str
    type: str
    capabilities: List[ProviderCapability]

    def __init__(self, provider_id: str, api_key: str | None, config: dict): ...

    def invoke(self, request: "AIRequestBase") -> "AIResponse":
        """
        Generic invocation method for any AI request.
        The provider is responsible for dispatching to the correct handler
        based on the request's capability.
        """
        ...

    def get_default_model_for(self, capability: ProviderCapability) -> str | None:
        """
        Returns the default model for a given capability, if configured.
        """
        ...

    def check_health(self) -> bool:
        """
        Performs a simple check to see if the provider is configured and reachable.
        """
        ...
