"""
branchpy.ai.telemetry — AI Governance and Telemetry

Logs AI requests and responses for auditing, cost tracking, and compliance.

Governance ID: V0.9.5-AI-BYOAI
"""

from __future__ import annotations

import sys
import uuid

from branchpy import logs
from branchpy.core.governance.schemas import PolicyContext, emit_governance_event


def log_ai_call(
    *,
    provider_id: str,
    model_name: str | None,
    capability: str,
    command: str,
    project_id: str | None,
    workspace_root: str | None,
    data_class: str,  # "public" | "sensitive" | "restricted"
    redaction_applied: bool,
    success: bool,
    duration_ms: float,
    error_code: str | None = None,
    error_message: str | None = None,
    token_used_prompt: int | None = None,
    token_used_completion: int | None = None,
    correlation_id: str | None = None,
) -> None:
    """
    Emits a structured governance event for an AI provider call.

    This function is designed to be non-fatal. If logging fails, it will
    print a warning to stderr but will not raise an exception, ensuring
    that the primary AI command can still complete.
    """
    try:
        # Ensure a correlation ID exists
        final_correlation_id = correlation_id or f"ai-{uuid.uuid4()}"

        context = PolicyContext(
            correlation_id=final_correlation_id,
            enforcement_decision="allow" if success else "deny",
        )

        metadata = {
            "provider_id": provider_id,
            "model_name": model_name,
            "capability": capability,
            "command": command,
            "project_id": project_id,
            "workspace_root": workspace_root,
            "data_class": data_class,
            "redaction_applied": redaction_applied,
            "success": success,
            "duration_ms": round(duration_ms, 2),
            "error_code": error_code,
            "error_message": error_message,
            "token_used_prompt": token_used_prompt,
            "token_used_completion": token_used_completion,
            # The timestamp is added by emit_governance_event
        }

        # Filter out None values to keep the log clean
        final_metadata = {k: v for k, v in metadata.items() if v is not None}

        emit_governance_event(
            event_type="ai_call",
            action=f"ai.{capability}",
            context=context,
            metadata=final_metadata,
        )
    except Exception as e:
        # Non-fatal logging: print a warning and continue.
        logs.warn(f"Failed to emit AI governance event: {e}", file=sys.stderr)
