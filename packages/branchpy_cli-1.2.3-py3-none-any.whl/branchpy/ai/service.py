# branchpy/ai/service.py
from __future__ import annotations

import time
from typing import Optional

from branchpy.core.governance.logger import GovernanceLogger
from branchpy.core.governance.schemas import (
    EVENT_AI_CALL_END,
    EVENT_AI_CALL_ERROR,
    EVENT_AI_CALL_START,
)
from branchpy.telemetry import collector

from .data_guard import DataGuard
from .models import (
    AIRequestBase,
    AIResponse,
    CodeReviewRequest,
    DocGenRequest,
    ExplainWarningRequest,
)
from .provider_registry import ProviderRegistry


class AIService:
    """
    High-level orchestrator for AI calls.

    Responsibilities:
    - Run requests through Data Guard.
    - Select a provider based on config / CLI args.
    - Invoke the provider.
    - Emit governance-friendly metadata.
    """

    def __init__(
        self,
        registry: ProviderRegistry,
        data_guard: Optional[DataGuard] = None,
        default_provider_id: Optional[str] = None,
    ) -> None:
        self.registry = registry
        self.data_guard = data_guard or DataGuard()
        self.default_provider_id = default_provider_id
        self.governance_logger = GovernanceLogger()

    # --- Public API used by CLI / VSCode ---

    def review_code(
        self, request: CodeReviewRequest, provider_id: Optional[str] = None
    ) -> AIResponse:
        return self._execute(request, provider_id)

    def generate_docs(
        self, request: DocGenRequest, provider_id: Optional[str] = None
    ) -> AIResponse:
        return self._execute(request, provider_id)

    def explain_warning(
        self, request: ExplainWarningRequest, provider_id: Optional[str] = None
    ) -> AIResponse:
        return self._execute(request, provider_id)

    # --- Internal helpers ---

    def _execute(
        self, request: AIRequestBase, provider_id: Optional[str]
    ) -> AIResponse:
        # 1) Sanitize request
        sanitized = self.data_guard.sanitize_request(request)

        # 2) Select provider
        provider = self._select_provider(provider_id)

        # 3) Governance hook – before
        self._log_ai_call_start(sanitized, provider.id)
        start_time = time.perf_counter()

        try:
            # 4) Invoke provider (AIProvider protocol assumed: invoke(AIRequestBase) -> AIResponse)
            response = provider.invoke(sanitized)

            # Add latency from our perspective
            response.latency_ms = int((time.perf_counter() - start_time) * 1000)

            # 5) Governance hook – after success
            self._log_ai_call_end(sanitized, response)

            # 6) User telemetry hook (privacy-safe AI summary)
            self._emit_telemetry_success(sanitized, response, provider.id)

            return response

        except Exception as e:
            # Log error event
            latency_ms = int((time.perf_counter() - start_time) * 1000)
            self._log_ai_call_error(sanitized, provider.id, str(e), latency_ms)

            # User telemetry hook (error outcome)
            self._emit_telemetry_error(sanitized, provider.id, latency_ms)

            raise

    def _select_provider(self, explicit_id: Optional[str]):
        # For now: explicit > default > first available
        if explicit_id:
            return self.registry.providers[explicit_id]

        if (
            self.default_provider_id
            and self.default_provider_id in self.registry.providers
        ):
            return self.registry.providers[self.default_provider_id]

        if not self.registry.providers:
            raise RuntimeError(
                "No AI providers are configured. Check ai_providers.toml."
            )

        # deterministic: first key sorted
        provider_id = sorted(self.registry.providers.keys())[0]
        return self.registry.providers[provider_id]

    # --- Governance logging ---

    def _log_ai_call_start(self, request: AIRequestBase, provider_id: str) -> None:
        """Logs the start of an AI call for governance and audit."""
        dataguard_meta = request.metadata.get("data_guard", {})
        self.governance_logger.log_event(
            {
                "event_type": EVENT_AI_CALL_START,
                "correlation_id": request.id,
                "actor": "AIService",
                "context": {
                    "provider_id": provider_id,
                    "capability": request.capability.value,
                    "data_class": request.data_class.value,
                    "redaction_applied": request.redaction_applied,
                    "emails_redacted": dataguard_meta.get("emails_redacted", 0),
                    "paths_redacted": dataguard_meta.get("paths_redacted", 0),
                    "secrets_redacted": dataguard_meta.get("secrets_redacted", 0),
                    # Guarantee stable schema: include keys expected by tests
                    "token_usage": {},  # Empty for start events
                    "correlation_id": request.id,  # Also in context for test compatibility
                },
            }
        )

    def _log_ai_call_end(self, request: AIRequestBase, response: AIResponse) -> None:
        """Logs the end of an AI call for governance and audit."""
        self.governance_logger.log_event(
            {
                "event_type": EVENT_AI_CALL_END,
                "correlation_id": request.id,
                "actor": "AIService",
                "context": {
                    "provider_id": response.provider_id,
                    "capability": response.capability.value,
                    "token_usage": response.token_usage
                    or {},  # Guarantee dict, not None
                    "latency_ms": response.latency_ms,
                    "is_fallback": response.is_fallback,
                    "is_error": response.is_error,
                    # Guarantee stable schema: include keys expected by tests
                    "redaction_applied": request.redaction_applied,
                    "correlation_id": request.id,  # Also in context for test compatibility
                },
            }
        )

    def _log_ai_call_error(
        self, request: AIRequestBase, provider_id: str, error: str, latency_ms: int
    ) -> None:
        """Logs an AI call error for governance and audit."""
        self.governance_logger.log_event(
            {
                "event_type": EVENT_AI_CALL_ERROR,
                "correlation_id": request.id,
                "actor": "AIService",
                "context": {
                    "provider_id": provider_id,
                    "capability": request.capability.value,
                    "error": error,
                    "latency_ms": latency_ms,
                    # Guarantee stable schema: include keys expected by tests
                    "token_usage": {},  # Empty for error events
                    "redaction_applied": request.redaction_applied,
                    "correlation_id": request.id,  # Also in context for test compatibility
                },
            }
        )

    # --- User Telemetry Hooks ---

    def _emit_telemetry_success(
        self, request: AIRequestBase, response: AIResponse, provider_id: str
    ) -> None:
        """
        Emit privacy-safe user telemetry for successful AI calls.

        NO prompts/responses are sent, only aggregate metrics:
        - provider, duration, token counts, redaction status
        """
        prompt_tokens = (
            response.token_usage.get("prompt_tokens", 0) if response.token_usage else 0
        )
        completion_tokens = (
            response.token_usage.get("completion_tokens", 0)
            if response.token_usage
            else 0
        )

        collector.emit_ai_summary(
            provider=provider_id,
            duration_ms=response.latency_ms or 0,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            outcome="success",
            redaction_applied=request.redaction_applied,
        )

    def _emit_telemetry_error(
        self, request: AIRequestBase, provider_id: str, latency_ms: int
    ) -> None:
        """
        Emit privacy-safe user telemetry for failed AI calls.

        Only metadata, no error messages or stack traces.
        """
        collector.emit_ai_summary(
            provider=provider_id,
            duration_ms=latency_ms,
            prompt_tokens=0,
            completion_tokens=0,
            outcome="error",
            redaction_applied=request.redaction_applied,
        )
