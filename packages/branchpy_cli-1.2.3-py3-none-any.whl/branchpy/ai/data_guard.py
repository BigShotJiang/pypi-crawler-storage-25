# branchpy/ai/data_guard.py
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, fields
from typing import Any, Dict, Optional, Type, TypeVar

from .models import AIRequestBase, DataClassification

TRequest = TypeVar("TRequest", bound=AIRequestBase)


# Very simple heuristic patterns; this can be expanded over time.
EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
FILE_PATH_PATTERN = re.compile(
    r"""(?:
        [A-Za-z]:\\[^\s'"]+   |   # Windows paths: C:\foo\bar
        /[^\s'"]+                # Unix paths: /home/user/file
    )""",
    re.VERBOSE,
)
SECRET_PATTERN = re.compile(
    r"""(?i)  # case-insensitive
    (api[_-]?key|token|secret|password|passwd)
    \s*[:=]\s*
    ['"]?([^'"\s]{8,})['"]?
    """,
    re.VERBOSE,
)


@dataclass
class RedactionConfig:
    """Configuration for Data Guard behavior."""

    enabled: bool = True
    redact_emails: bool = True
    redact_paths: bool = True
    redact_secrets: bool = True
    max_text_length: Optional[int] = 8000  # soft guard; None = no limit


class DataGuard:
    """
    Data Guard for AI requests.

    - Applies regex-based redaction to string fields.
    - Upgrades DataClassification when sensitive markers are found.
    - Records basic stats in request.metadata["data_guard"].
    """

    def __init__(self, config: Optional[RedactionConfig] = None) -> None:
        self.config = config or RedactionConfig()

    def sanitize_request(self, request: TRequest) -> TRequest:
        """
        Return a sanitized copy of the given request.

        - Does NOT mutate the original.
        - Preserves the concrete subclass (CodeReviewRequest, DocGenRequest, etc.).
        """
        if not self.config.enabled:
            return request

        original_dict = asdict(request)
        redacted_dict = dict(original_dict)  # shallow copy for modifications

        email_count = 0
        path_count = 0
        secret_count = 0

        # Walk all dataclass fields; only touch str fields.
        for f in fields(request):
            value = redacted_dict.get(f.name)
            if not isinstance(value, str) or not value:
                continue

            text = value
            if (
                self.config.max_text_length is not None
                and len(text) > self.config.max_text_length
            ):
                # We don't truncate by default; this is just a soft check.
                # You could later choose to cut or summarize oversized payloads.
                pass

            if self.config.redact_emails:
                new_text, n = EMAIL_PATTERN.subn("[REDACTED_EMAIL]", text)
                if n:
                    email_count += n
                    text = new_text

            if self.config.redact_paths:
                new_text, n = FILE_PATH_PATTERN.subn("[REDACTED_PATH]", text)
                if n:
                    path_count += n
                    text = new_text

            if self.config.redact_secrets:

                def _secret_repl(match: re.Match[str]) -> str:
                    key_name = match.group(1)
                    return f"{key_name}: [REDACTED_SECRET]"

                new_text, n = SECRET_PATTERN.subn(_secret_repl, text)
                if n:
                    secret_count += n
                    text = new_text

            redacted_dict[f.name] = text

        # Determine if we actually changed anything.
        redaction_applied = email_count > 0 or path_count > 0 or secret_count > 0

        # Upgrade data_class if we detected secret-like patterns.
        data_class = DataClassification(
            redacted_dict.get("data_class", request.data_class)
        )
        if secret_count > 0 and data_class != DataClassification.RESTRICTED:
            data_class = DataClassification.RESTRICTED
        elif (
            email_count > 0 or path_count > 0
        ) and data_class == DataClassification.INTERNAL:
            data_class = DataClassification.SENSITIVE

        redacted_dict["data_class"] = data_class
        redacted_dict["redaction_applied"] = redaction_applied

        # Update metadata with guard stats.
        metadata: Dict[str, Any] = dict(redacted_dict.get("metadata") or {})
        metadata_guard = dict(metadata.get("data_guard") or {})
        metadata_guard.update(
            {
                "emails_redacted": email_count,
                "paths_redacted": path_count,
                "secrets_redacted": secret_count,
                "enabled": self.config.enabled,
            }
        )
        metadata["data_guard"] = metadata_guard
        redacted_dict["metadata"] = metadata

        # Reconstruct same concrete type as original.
        request_type: Type[TRequest] = type(request)  # type: ignore[assignment]
        sanitized: TRequest = request_type(**redacted_dict)  # type: ignore[arg-type]

        return sanitized
