"""
branchpy.ai.ai_models.py
BranchPy v0.9.4 — AI Integration Strategy

AI models and task definitions
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional


class AIModel(Enum):
    """Supported AI models"""

    GPT4 = "gpt-4"
    GPT4_TURBO = "gpt-4-turbo"
    GPT5 = "gpt-5"  # Future
    CLAUDE_35_SONNET = "claude-3-5-sonnet-20241022"
    CLAUDE_45 = "claude-4-5"  # Future


class AITask(Enum):
    """AI task types"""

    CODE_REVIEW = "code_review"
    DOCGEN = "documentation_generation"
    SEMANTIC_ASSIST = "semantic_assistance"
    ASSET_GUESS = "asset_guessing"
    EXPLAIN_WARNING = "explain_warning"
    HELP = "help_support"


@dataclass
class AIRequest:
    """AI request data structure"""

    task: AITask
    provider: str
    model: str
    input_data: Dict[str, Any]
    context: Optional[Dict[str, Any]] = None


@dataclass
class AIResponse:
    """AI response data structure"""

    task: AITask
    provider: str
    model: str
    output: Any
    metadata: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


@dataclass
class AIConfig:
    """AI configuration"""

    provider: str
    api_key: str
    model: Optional[str] = None
    temperature: float = 0.5
    max_tokens: int = 4096
