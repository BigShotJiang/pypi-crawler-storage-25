"""
branchpy.ai.request_models — AI Request/Response Dataclasses

This file is now deprecated. All models have been moved to `provider_base.py`
to avoid circular dependencies and centralize the core protocol definitions.

This file is kept for backward compatibility during the v0.9.5 transition
and will be removed in v0.9.6.

Governance ID: V0.9.5-AI-BYOAI
"""

from .provider_base import (
    CodeReviewRequest,
    CodeReviewResponse,
    DocGenRequest,
    DocGenResponse,
    ExplainWarningRequest,
    ExplainWarningResponse,
)

__all__ = [
    "CodeReviewRequest",
    "CodeReviewResponse",
    "DocGenRequest",
    "DocGenResponse",
    "ExplainWarningRequest",
    "ExplainWarningResponse",
]

import warnings

warnings.warn(
    "`branchpy.ai.request_models` is deprecated and will be removed in v0.9.6. "
    "Import from `branchpy.ai.provider_base` instead.",
    DeprecationWarning,
    stacklevel=2,
)
