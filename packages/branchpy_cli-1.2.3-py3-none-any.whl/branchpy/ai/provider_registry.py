"""
branchpy.ai.provider_registry — AI Provider Registry and Router

Loads provider configurations and routes AI requests to the appropriate provider.

Governance ID: V0.9.5-AI-BYOAI
"""

from __future__ import annotations

import os
from typing import Any, Dict, Mapping

from .provider_base import AIProvider, ProviderConfigurationError
from .providers.anthropic_provider import AnthropicProvider
from .providers.gemini_provider import GeminiProvider
from .providers.http_provider import HTTPProvider
from .providers.openai_provider import OpenAIProvider


class ProviderRegistry:
    def __init__(self) -> None:
        # Keys MUST be the TOML section names:
        # e.g. "openai-default", "anthropic-default", "http-local", "gemini-experimental"
        self.providers: Dict[str, AIProvider] = {}

    def load_from_dict(self, config: Mapping[str, Any]) -> None:
        """
        Load providers from a dict produced by tomllib/toml.

        Expected TOML shape:

            [providers.openai-default]
            name = "OpenAI GPT-4"
            type = "openai"
            api_key_env = "OPENAI_API_KEY"
            capabilities = ["code_review", "doc_gen"]

        """
        self.providers.clear()

        providers_section = config.get("providers") or {}
        if not isinstance(providers_section, dict):
            raise ProviderConfigurationError(
                "ai_providers.toml must contain a [providers] table with nested [providers.<id>] entries."
            )

        for provider_id, cfg in providers_section.items():
            if not isinstance(cfg, dict):
                continue

            enabled = cfg.get("enabled", True)
            if not enabled:
                continue

            provider_type = cfg.get("type")
            if not provider_type:
                # no type = skip, but don't crash
                continue

            api_key_env = cfg.get("api_key_env")
            api_key = None
            if api_key_env:
                api_key = os.getenv(api_key_env)
                # STRICT BEHAVIOR: if env var required but missing, skip provider
                if api_key is None:
                    continue
            else:
                api_key = cfg.get("api_key")

            provider = self._create_provider(
                provider_id=provider_id,
                provider_type=str(provider_type),
                cfg=cfg,
                api_key=api_key,
            )
            self.providers[provider_id] = provider

    def _create_provider(
        self,
        provider_id: str,
        provider_type: str,
        cfg: Mapping[str, Any],
        api_key: str | None,
    ) -> AIProvider:
        if provider_type == "openai":
            if not api_key:
                raise ProviderConfigurationError(
                    f"API key not found for provider '{provider_id}'."
                )
            return OpenAIProvider(provider_id=provider_id, api_key=api_key, config=cfg)

        if provider_type == "anthropic":
            if not api_key:
                raise ProviderConfigurationError(
                    f"API key not found for provider '{provider_id}'."
                )
            return AnthropicProvider(
                provider_id=provider_id, api_key=api_key, config=cfg
            )

        if provider_type == "gemini":
            if not api_key:
                raise ProviderConfigurationError(
                    f"API key not found for provider '{provider_id}'."
                )
            return GeminiProvider(provider_id=provider_id, api_key=api_key, config=cfg)

        if provider_type == "http":
            return HTTPProvider(provider_id=provider_id, config=cfg, api_key=api_key)

        raise ProviderConfigurationError(
            f"Unknown provider type '{provider_type}' for '{provider_id}'."
        )

    def list_providers(self) -> list[str]:
        return sorted(self.providers.keys())
