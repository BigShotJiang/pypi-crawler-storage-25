"""
Redaction Configuration

Defines configuration schema for the redaction engine.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class RedactionConfig:
    """
    Configuration for redaction engine.

    Attributes:
        enabled: Whether redaction is enabled
        categories: List of redaction categories to apply
        custom_patterns: User-defined regex patterns
        custom_keywords: User-defined keywords to redact
        preserve_structure: Keep whitespace and formatting
        max_preview_length: Maximum length for previews
        case_sensitive: Case-sensitive keyword matching
        redact_filenames: Redact filenames in paths
        redact_extensions: Redact file extensions
    """

    enabled: bool = True
    categories: List[str] = field(
        default_factory=lambda: ["all"]  # Enable all redaction categories by default
    )
    custom_patterns: Dict[str, str] = field(default_factory=dict)
    custom_keywords: List[str] = field(default_factory=list)
    preserve_structure: bool = True
    max_preview_length: int = 500
    case_sensitive: bool = False
    redact_filenames: bool = True
    redact_extensions: bool = False

    @classmethod
    def from_dict(cls, config: Dict) -> "RedactionConfig":
        """Create RedactionConfig from dictionary (TOML)"""
        return cls(
            enabled=config.get("enabled", True),
            categories=config.get(
                "categories", cls.__dataclass_fields__["categories"].default_factory()
            ),
            custom_patterns=config.get("custom_patterns", {}),
            custom_keywords=config.get("custom_keywords", []),
            preserve_structure=config.get("preserve_structure", True),
            max_preview_length=config.get("max_preview_length", 500),
            case_sensitive=config.get("case_sensitive", False),
            redact_filenames=config.get("redact_filenames", True),
            redact_extensions=config.get("redact_extensions", False),
        )

    @classmethod
    def from_toml_file(cls, path: Path) -> Optional["RedactionConfig"]:
        """Load config from TOML file"""
        if not path.exists():
            return None

        try:
            import tomli
        except ImportError:
            try:
                import tomllib as tomli
            except ImportError:
                return None

        with open(path, "rb") as f:
            data = tomli.load(f)

        # Navigate to ai.safety.redaction section
        if (
            "ai" in data
            and "safety" in data["ai"]
            and "redaction" in data["ai"]["safety"]
        ):
            return cls.from_dict(data["ai"]["safety"]["redaction"])

        return None

    @classmethod
    def load_from_workspace(
        cls, workspace_path: Optional[Path] = None
    ) -> "RedactionConfig":
        """
        Load redaction config with fallback chain:
        1. Workspace .branchpy/branchpy.toml
        2. User ~/.branchpy/config.toml
        3. User ~/branchpy.toml
        4. Defaults
        """
        # Try workspace config
        if workspace_path:
            workspace_config = workspace_path / ".branchpy" / "branchpy.toml"
            if workspace_config.exists():
                config = cls.from_toml_file(workspace_config)
                if config:
                    return config

        # Try user config locations
        home = Path.home()
        user_configs = [
            home / ".branchpy" / "config.toml",
            home / "branchpy.toml",
        ]

        for config_path in user_configs:
            if config_path.exists():
                config = cls.from_toml_file(config_path)
                if config:
                    return config

        # Return defaults
        return cls()

    def to_dict(self) -> Dict:
        """Serialize to dictionary"""
        return {
            "enabled": self.enabled,
            "categories": self.categories,
            "custom_patterns": self.custom_patterns,
            "custom_keywords": self.custom_keywords,
            "preserve_structure": self.preserve_structure,
            "max_preview_length": self.max_preview_length,
            "case_sensitive": self.case_sensitive,
            "redact_filenames": self.redact_filenames,
            "redact_extensions": self.redact_extensions,
        }


# Example TOML configuration
EXAMPLE_CONFIG = """
[ai.safety.redaction]
enabled = true
categories = ["personal_data", "paths", "secrets", "project", "metadata"]
preserve_structure = true
max_preview_length = 500
case_sensitive = false
redact_filenames = true
redact_extensions = false

# Custom keywords to redact (case-insensitive by default)
custom_keywords = [
    "MY_GAME_TITLE",
    "SecretCharacterName",
    "StudioCodenameX"
]

# Custom regex patterns
[ai.safety.redaction.custom_patterns]
studio_name = "MyStudioName"
internal_code = "INTERNAL-[A-Z0-9]+"
"""
