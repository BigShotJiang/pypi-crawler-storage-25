"""
AI Governance Logging

Records all AI operations to tamper-resistant JSONL audit log.
Compliant with GDPR, CCPA, and Quebec Law 25.
"""

import hashlib
import json
import threading
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class AIGovernanceEvent:
    """
    AI operation governance event.

    Logged for every AI request (translation, refactoring, etc.)
    """

    event: str = "ai_request"
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    user_id: str = "<local-user>"
    project: str = ""
    provider: str = ""
    model: str = ""
    safe_mode: bool = True
    bytes_sent: int = 0
    bytes_received: int = 0
    operation: str = ""
    preview_redacted: str = ""
    success: bool = True
    duration_ms: float = 0.0
    error: Optional[str] = None

    # Additional metadata
    redaction_applied: bool = False
    consent_granted: bool = False
    policy_version: str = "1.0"

    def to_jsonl(self) -> str:
        """
        Serialize to JSONL format (single line JSON).

        Returns:
            JSONL string (no trailing newline)
        """
        data = asdict(self)
        # Remove None values
        data = {k: v for k, v in data.items() if v is not None}
        return json.dumps(data, ensure_ascii=False)

    @classmethod
    def from_jsonl(cls, line: str) -> "AIGovernanceEvent":
        """Parse AIGovernanceEvent from JSONL line"""
        data = json.loads(line)
        return cls(**data)

    def compute_integrity_hash(self, secret: Optional[str] = None) -> str:
        """
        Compute HMAC-SHA256 integrity hash for tamper detection.

        Args:
            secret: Optional secret key for HMAC (uses timestamp if None)

        Returns:
            Hex digest of hash
        """
        data = self.to_jsonl()
        key = secret or self.timestamp
        return hashlib.sha256(f"{key}:{data}".encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary"""
        return asdict(self)


class AIGovernanceLogger:
    """
    Thread-safe JSONL logger for AI governance events.

    Features:
    - Atomic writes (append-only)
    - Crash-safe
    - Query support
    - Rotation support
    - Integrity hashing
    """

    def __init__(
        self,
        log_path: Optional[Path] = None,
        enable_integrity: bool = False,
        integrity_secret: Optional[str] = None,
        max_preview_length: int = 500,
    ):
        """
        Initialize governance logger.

        Args:
            log_path: Path to JSONL log file (auto-created)
            enable_integrity: Enable integrity hashing
            integrity_secret: Secret for HMAC (uses timestamp if None)
            max_preview_length: Max length for redacted preview
        """
        self.log_path = log_path or self._default_log_path()
        self.enable_integrity = enable_integrity
        self.integrity_secret = integrity_secret
        self.max_preview_length = max_preview_length
        self._lock = threading.Lock()
        self._ensure_log_dir()

    def _default_log_path(self) -> Path:
        """Get default log path"""
        # Try workspace first, fall back to user directory
        workspace = Path.cwd() / ".branchpy" / "governance"
        if workspace.parent.exists():
            return workspace / "ai_operations.jsonl"

        # User home directory
        home = Path.home() / ".branchpy" / "governance"
        return home / "ai_operations.jsonl"

    def _ensure_log_dir(self) -> None:
        """Ensure log directory exists"""
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def log_event(self, event: AIGovernanceEvent) -> None:
        """
        Log AI governance event (thread-safe, atomic).

        Args:
            event: AIGovernanceEvent to log
        """
        # Ensure log directory exists
        self._ensure_log_dir()

        # Truncate preview if needed
        if len(event.preview_redacted) > self.max_preview_length:
            event.preview_redacted = (
                event.preview_redacted[: self.max_preview_length]
                + "\n[...truncated...]"
            )

        # Add integrity hash if enabled
        jsonl_line = event.to_jsonl()
        if self.enable_integrity:
            integrity = event.compute_integrity_hash(self.integrity_secret)
            # Append integrity hash to line
            data = json.loads(jsonl_line)
            data["_integrity"] = integrity
            jsonl_line = json.dumps(data, ensure_ascii=False)

        # Atomic write (append mode)
        with self._lock:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(jsonl_line + "\n")
                f.flush()  # Ensure written to disk

    def log_request_start(
        self,
        operation: str,
        provider: str,
        model: str,
        safe_mode: bool,
        bytes_sent: int,
        preview_redacted: str,
        project: str = "",
        user_id: str = "<local-user>",
    ) -> AIGovernanceEvent:
        """
        Log the start of an AI request.

        Returns:
            AIGovernanceEvent (not yet logged, call log_event separately)
        """
        return AIGovernanceEvent(
            event="ai_request",
            user_id=user_id,
            project=project,
            provider=provider,
            model=model,
            safe_mode=safe_mode,
            bytes_sent=bytes_sent,
            operation=operation,
            preview_redacted=preview_redacted,
            success=True,  # Optimistic, update on error
            duration_ms=0.0,
        )

    def log_request_complete(
        self,
        event: AIGovernanceEvent,
        bytes_received: int,
        duration_ms: float,
        success: bool = True,
        error: Optional[str] = None,
    ) -> None:
        """
        Complete and log an AI request event.

        Args:
            event: Event from log_request_start
            bytes_received: Response size
            duration_ms: Request duration
            success: Whether request succeeded
            error: Error message if failed
        """
        event.bytes_received = bytes_received
        event.duration_ms = duration_ms
        event.success = success
        event.error = error

        self.log_event(event)

    @contextmanager
    def track_request(
        self,
        operation: str,
        provider: str,
        model: str,
        safe_mode: bool,
        bytes_sent: int,
        preview_redacted: str,
        project: str = "",
    ):
        """
        Context manager for tracking AI requests.

        Usage:
            with logger.track_request(...) as event:
                response = provider.chat(request)
                event.bytes_received = len(response.content)
        """
        start_time = time.perf_counter()
        event = self.log_request_start(
            operation=operation,
            provider=provider,
            model=model,
            safe_mode=safe_mode,
            bytes_sent=bytes_sent,
            preview_redacted=preview_redacted,
            project=project,
        )

        try:
            yield event
            duration_ms = (time.perf_counter() - start_time) * 1000
            event.duration_ms = duration_ms
            event.success = True
            self.log_event(event)
        except Exception as e:
            duration_ms = (time.perf_counter() - start_time) * 1000
            event.duration_ms = duration_ms
            event.success = False
            event.error = str(e)
            self.log_event(event)
            raise

    def query_events(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        provider: Optional[str] = None,
        operation: Optional[str] = None,
        success_only: bool = False,
        limit: Optional[int] = None,
    ) -> List[AIGovernanceEvent]:
        """
        Query logged events with filters.

        Args:
            start_date: Filter by start date (inclusive)
            end_date: Filter by end date (inclusive)
            provider: Filter by provider ID
            operation: Filter by operation type
            success_only: Only return successful operations
            limit: Maximum number of events to return

        Returns:
            List of AIGovernanceEvent matching filters
        """
        if not self.log_path.exists():
            return []

        events: List[AIGovernanceEvent] = []

        with open(self.log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                try:
                    event = AIGovernanceEvent.from_jsonl(line)

                    # Apply filters
                    if (
                        start_date
                        and datetime.fromisoformat(event.timestamp) < start_date
                    ):
                        continue
                    if end_date and datetime.fromisoformat(event.timestamp) > end_date:
                        continue
                    if provider and event.provider != provider:
                        continue
                    if operation and event.operation != operation:
                        continue
                    if success_only and not event.success:
                        continue

                    events.append(event)

                    if limit and len(events) >= limit:
                        break

                except (json.JSONDecodeError, TypeError):
                    # Skip malformed lines
                    continue

        return events

    def get_statistics(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """
        Get statistics about logged events.

        Returns:
            Dictionary with statistics
        """
        events = self.query_events(start_date=start_date, end_date=end_date)

        if not events:
            return {
                "total_events": 0,
                "success_count": 0,
                "error_count": 0,
                "providers": {},
                "operations": {},
                "safe_mode_count": 0,
            }

        # Calculate statistics
        success_count = sum(1 for e in events if e.success)
        error_count = len(events) - success_count
        safe_mode_count = sum(1 for e in events if e.safe_mode)

        # Count by provider
        providers: Dict[str, int] = {}
        for event in events:
            providers[event.provider] = providers.get(event.provider, 0) + 1

        # Count by operation
        operations: Dict[str, int] = {}
        for event in events:
            operations[event.operation] = operations.get(event.operation, 0) + 1

        # Calculate totals
        total_bytes_sent = sum(e.bytes_sent for e in events)
        total_bytes_received = sum(e.bytes_received for e in events)
        avg_duration = sum(e.duration_ms for e in events) / len(events)

        return {
            "total_events": len(events),
            "success_count": success_count,
            "error_count": error_count,
            "success_rate": success_count / len(events) if events else 0,
            "providers": providers,
            "operations": operations,
            "safe_mode_count": safe_mode_count,
            "safe_mode_ratio": safe_mode_count / len(events) if events else 0,
            "total_bytes_sent": total_bytes_sent,
            "total_bytes_received": total_bytes_received,
            "avg_duration_ms": avg_duration,
        }

    def export_csv(self, output_path: Path) -> int:
        """
        Export events to CSV format.

        Args:
            output_path: Path to CSV file

        Returns:
            Number of events exported
        """
        import csv

        events = self.query_events()
        if not events:
            return 0

        # Get all field names
        fieldnames = list(asdict(events[0]).keys())

        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for event in events:
                writer.writerow(asdict(event))

        return len(events)

    def rotate_log(self, keep_days: int = 90) -> None:
        """
        Rotate log file (archive old events).

        Args:
            keep_days: Number of days to keep in active log
        """
        if not self.log_path.exists():
            return

        cutoff_date = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(
            days=keep_days
        )

        # Read all events
        events = self.query_events()

        # Split into keep and archive
        keep_events = []
        archive_events = []

        for event in events:
            event_date = datetime.fromisoformat(event.timestamp).replace(tzinfo=None)
            if event_date >= cutoff_date:
                keep_events.append(event)
            else:
                archive_events.append(event)

        if not archive_events:
            return

        # Archive old events
        archive_path = (
            self.log_path.parent
            / f'ai_operations.{datetime.now().strftime("%Y%m%d")}.archive.jsonl'
        )
        with open(archive_path, "w", encoding="utf-8") as f:
            for event in archive_events:
                f.write(event.to_jsonl() + "\n")

        # Rewrite active log with kept events
        with open(self.log_path, "w", encoding="utf-8") as f:
            for event in keep_events:
                f.write(event.to_jsonl() + "\n")


# Global logger instance (lazy initialized)
_global_logger: Optional[AIGovernanceLogger] = None
_logger_lock = threading.Lock()


def get_governance_logger(
    log_path: Optional[Path] = None,
    enable_integrity: bool = False,
) -> AIGovernanceLogger:
    """
    Get global governance logger instance (singleton).

    Args:
        log_path: Custom log path (uses default if None)
        enable_integrity: Enable integrity hashing

    Returns:
        AIGovernanceLogger instance
    """
    global _global_logger

    with _logger_lock:
        if _global_logger is None:
            _global_logger = AIGovernanceLogger(
                log_path=log_path,
                enable_integrity=enable_integrity,
            )
        return _global_logger


def set_governance_logger(logger: AIGovernanceLogger) -> None:
    """Set global governance logger instance"""
    global _global_logger
    with _logger_lock:
        _global_logger = logger


# Import timedelta for rotate_log
from datetime import timedelta
