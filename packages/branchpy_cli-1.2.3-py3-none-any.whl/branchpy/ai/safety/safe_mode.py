"""
Safe Mode Controller

Enforces safe mode restrictions for AI providers.
"""

import os
from pathlib import Path
from typing import Optional

from ..protocol import AIProvider
from .safe_mode_config import SafeMode, SafeModeConfig


class SafeModeViolation(Exception):
    """Raised when safe mode restrictions are violated"""

    def __init__(self, message: str, provider_id: str):
        self.message = message
        self.provider_id = provider_id
        super().__init__(message)


class SafeModeController:
    """
    Controls safe mode enforcement for AI operations.

    Resolution order (highest to lowest priority):
    1. CLI flag (--safe-ai / --no-safe-ai)
    2. Environment variable (BRANCHPY_SAFE_MODE)
    3. VS Code workspace setting
    4. Project config (.branchpy/branchpy.toml)
    5. User config (~/.branchpy/config.toml)
    6. Default (SAFE MODE ON)
    """

    def __init__(
        self,
        config: Optional[SafeModeConfig] = None,
        workspace_path: Optional[Path] = None,
        cli_override: Optional[bool] = None,
    ):
        """
        Initialize safe mode controller.

        Args:
            config: Safe mode configuration
            workspace_path: Workspace path for config loading
            cli_override: CLI flag override (True=ON, False=OFF, None=no override)
        """
        self.config = config or SafeModeConfig.load_from_workspace(workspace_path)
        self.workspace_path = workspace_path
        self.cli_override = cli_override
        self._resolved_mode: Optional[SafeMode] = None

    def get_safe_mode(self) -> SafeMode:
        """
        Get current safe mode state with resolution chain.

        Returns:
            SafeMode.ON or SafeMode.OFF
        """
        if self._resolved_mode is not None:
            return self._resolved_mode

        # 1. CLI override (highest priority)
        if self.cli_override is not None and self.config.allow_cli_override:
            self._resolved_mode = SafeMode.ON if self.cli_override else SafeMode.OFF
            return self._resolved_mode

        # 2. Environment variable
        env_mode = os.environ.get("BRANCHPY_SAFE_MODE")
        if env_mode:
            try:
                self._resolved_mode = SafeMode.from_string(env_mode)
                return self._resolved_mode
            except ValueError:
                pass  # Invalid value, continue to next source

        # 3. VS Code workspace setting (if available)
        # TODO: Add VS Code settings integration when available

        # 4. Config file (already loaded in self.config)
        self._resolved_mode = self.config.default_mode
        return self._resolved_mode

    def is_safe_mode(self) -> bool:
        """Check if safe mode is currently ON"""
        return self.get_safe_mode() == SafeMode.ON

    def is_provider_allowed(self, provider: AIProvider) -> bool:
        """
        Check if provider is allowed in current safe mode.

        Args:
            provider: AI provider to check

        Returns:
            True if provider is allowed, False otherwise
        """
        mode = self.get_safe_mode()

        # If safe mode is OFF, all providers allowed (with consent)
        if mode == SafeMode.OFF:
            return True

        # Safe mode ON: only local providers allowed
        if provider.is_local:
            return True

        # Check whitelist for external providers
        if provider.provider_id in self.config.allowed_external_providers:
            return True

        return False

    def enforce_provider(self, provider: AIProvider) -> None:
        """
        Enforce safe mode restrictions on provider.

        Args:
            provider: AI provider to validate

        Raises:
            SafeModeViolation: If provider not allowed in current mode
        """
        if not self.is_provider_allowed(provider):
            raise SafeModeViolation(
                f"Provider '{provider.provider_id}' is not allowed in safe mode. "
                f"Use a local provider (Ollama, LM Studio) or disable safe mode.",
                provider_id=provider.provider_id,
            )

    def enforce_payload_size(self, payload: str, is_local: bool) -> None:
        """
        Enforce payload size limits.

        Args:
            payload: Request payload text
            is_local: Whether provider is local

        Raises:
            SafeModeViolation: If payload exceeds size limit
        """
        payload_size = len(payload.encode("utf-8"))
        max_size = (
            self.config.max_payload_size_local
            if is_local
            else self.config.max_payload_size_external
        )

        if payload_size > max_size:
            provider_type = "local" if is_local else "external"
            raise SafeModeViolation(
                f"Payload size ({payload_size:,} bytes) exceeds {provider_type} limit ({max_size:,} bytes). "
                f"Reduce context or increase limit in config.",
                provider_id="payload_check",
            )

    def get_max_payload_size(self, is_local: bool) -> int:
        """Get maximum payload size for provider type"""
        return (
            self.config.max_payload_size_local
            if is_local
            else self.config.max_payload_size_external
        )

    def set_cli_override(self, safe_mode: SafeMode) -> None:
        """
        Set CLI override for safe mode.

        Args:
            safe_mode: SafeMode.ON or SafeMode.OFF
        """
        if self.config.allow_cli_override:
            self.cli_override = safe_mode == SafeMode.ON
            self._resolved_mode = None  # Clear cached resolution

    def clear_cli_override(self) -> None:
        """Clear CLI override"""
        self.cli_override = None
        self._resolved_mode = None

    def get_mode_info(self) -> dict:
        """
        Get detailed information about current safe mode state.

        Returns:
            Dictionary with mode info
        """
        mode = self.get_safe_mode()
        source = "default"

        if self.cli_override is not None and self.config.allow_cli_override:
            source = "cli_flag"
        elif os.environ.get("BRANCHPY_SAFE_MODE"):
            source = "environment"
        elif (
            self.workspace_path
            and (self.workspace_path / ".branchpy" / "branchpy.toml").exists()
        ):
            source = "workspace_config"
        elif (Path.home() / ".branchpy" / "config.toml").exists():
            source = "user_config"

        return {
            "mode": mode.value,
            "is_safe": mode == SafeMode.ON,
            "source": source,
            "cli_override_enabled": self.config.allow_cli_override,
            "workspace_override_enabled": self.config.allow_workspace_override,
            "max_payload_local": self.config.max_payload_size_local,
            "max_payload_external": self.config.max_payload_size_external,
            "allowed_external_providers": self.config.allowed_external_providers,
        }
