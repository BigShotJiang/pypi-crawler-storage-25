"""
Provider Validator

Validates AI providers against safe mode restrictions.
"""

from dataclasses import dataclass
from typing import Optional

from ..protocol import AIProvider
from .safe_mode_config import SafeMode


@dataclass
class ValidationResult:
    """Result of provider validation"""

    is_valid: bool
    provider_id: str
    is_local: bool
    safe_mode: SafeMode
    reason: Optional[str] = None
    warnings: list = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []

    def to_dict(self) -> dict:
        """Serialize to dictionary"""
        return {
            "is_valid": self.is_valid,
            "provider_id": self.provider_id,
            "is_local": self.is_local,
            "safe_mode": self.safe_mode.value,
            "reason": self.reason,
            "warnings": self.warnings,
        }


def validate_provider_for_safe_mode(
    provider: AIProvider, safe_mode: SafeMode, allowed_external_providers: list = None
) -> ValidationResult:
    """
    Validate provider against safe mode restrictions.

    Safe mode ON rules:
    - Only local providers allowed
    - No API keys required
    - No network calls

    Safe mode OFF rules:
    - All providers allowed
    - Consent required for cloud providers
    - Redaction applied

    Args:
        provider: AI provider to validate
        safe_mode: Current safe mode state
        allowed_external_providers: Whitelist of external providers (optional)

    Returns:
        ValidationResult with validation status
    """
    allowed_external = allowed_external_providers or []
    warnings = []

    # Safe mode OFF: all providers allowed (with warnings)
    if safe_mode == SafeMode.OFF:
        if not provider.is_local:
            warnings.append(
                f"Provider '{provider.provider_id}' is external (cloud). "
                "Data will be sent outside your machine. Consent required."
            )

        return ValidationResult(
            is_valid=True,
            provider_id=provider.provider_id,
            is_local=provider.is_local,
            safe_mode=safe_mode,
            warnings=warnings,
        )

    # Safe mode ON: strict validation
    if provider.is_local:
        # Local provider: always allowed
        return ValidationResult(
            is_valid=True,
            provider_id=provider.provider_id,
            is_local=True,
            safe_mode=safe_mode,
            reason="Local provider allowed in safe mode",
        )

    # External provider in safe mode: check whitelist
    if provider.provider_id in allowed_external:
        warnings.append(
            f"Provider '{provider.provider_id}' is whitelisted but external. "
            "Consider using local provider for maximum privacy."
        )
        return ValidationResult(
            is_valid=True,
            provider_id=provider.provider_id,
            is_local=False,
            safe_mode=safe_mode,
            reason="External provider whitelisted",
            warnings=warnings,
        )

    # External provider not allowed
    return ValidationResult(
        is_valid=False,
        provider_id=provider.provider_id,
        is_local=False,
        safe_mode=safe_mode,
        reason=(
            f"Provider '{provider.provider_id}' is external and not allowed in safe mode. "
            "Use local provider (Ollama, LM Studio) or disable safe mode."
        ),
    )


def check_api_key_security(
    provider: AIProvider, require_encryption: bool = False
) -> ValidationResult:
    """
    Check API key security for provider.

    Args:
        provider: AI provider to check
        require_encryption: Whether to require encrypted API keys

    Returns:
        ValidationResult with security check status
    """
    warnings = []

    # Local providers don't need API keys
    if provider.is_local:
        return ValidationResult(
            is_valid=True,
            provider_id=provider.provider_id,
            is_local=True,
            safe_mode=SafeMode.ON,  # N/A for this check
            reason="Local provider does not require API keys",
        )

    # Check if provider has API key configured
    # This is a simplified check - real implementation would verify encryption
    if require_encryption:
        warnings.append(
            f"API key encryption is required but not verified for '{provider.provider_id}'. "
            "Ensure API keys are stored securely."
        )

    return ValidationResult(
        is_valid=True,
        provider_id=provider.provider_id,
        is_local=False,
        safe_mode=SafeMode.OFF,
        warnings=warnings,
    )
