"""
Redaction Engine v1.0

Removes or masks sensitive data before sending to AI providers.

Features:
- 50+ built-in redaction patterns
- Custom pattern support
- Keyword-based redaction
- Reversible redaction (for debugging)
- Performance optimized (<50ms for 10KB)
"""

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Set

from .redaction_config import RedactionConfig


@dataclass
class RedactionMatch:
    """Single redaction match"""

    category: str
    start: int
    end: int
    original: str
    replacement: str
    pattern_name: str


@dataclass
class RedactionResult:
    """Result of redaction operation"""

    redacted_text: str
    original_text: str
    matches: List[RedactionMatch]
    categories_applied: List[str]
    duration_ms: float
    bytes_original: int
    bytes_redacted: int

    def get_preview(self, max_length: int = 500) -> str:
        """Get truncated preview of redacted text"""
        if len(self.redacted_text) <= max_length:
            return self.redacted_text

        return self.redacted_text[:max_length] + "\n[... truncated ...]"

    def to_dict(self) -> Dict:
        """Serialize to dictionary"""
        return {
            "redacted_text": self.redacted_text,
            "match_count": len(self.matches),
            "categories_applied": self.categories_applied,
            "duration_ms": self.duration_ms,
            "bytes_original": self.bytes_original,
            "bytes_redacted": self.bytes_redacted,
            "redaction_ratio": (
                self.bytes_redacted / self.bytes_original
                if self.bytes_original > 0
                else 0
            ),
        }


class RedactionEngine:
    """
    Redaction engine for removing sensitive data from text.

    Performance target: <50ms for 10KB payload
    """

    # Built-in redaction patterns (50+ patterns)
    PATTERNS = {
        # Personal Data
        "email": (
            r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
            "PERSONAL_DATA",
        ),
        "phone_us": (
            r"\b(?:\+?1[-. ]?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})\b",
            "PERSONAL_DATA",
        ),
        "phone_intl": (
            r"\+[0-9]{1,3}[-.\s]?(?:\([0-9]{1,4}\)|[0-9]{1,4})[-.\s]?[0-9]{1,4}[-.\s]?[0-9]{1,9}",
            "PERSONAL_DATA",
        ),
        "ssn": (r"\b\d{3}-\d{2}-\d{4}\b", "PERSONAL_DATA"),
        # Secrets & Keys
        "api_key_generic": (
            r'(?i)(api[_-]?key|apikey|api_token|access[_-]?token|auth[_-]?token|bearer[_-]?token)["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{15,})["\']?',
            "SECRET",
        ),
        "aws_access_key": (
            r'(?i)(aws_access_key_id|aws_secret_access_key)["\']?\s*[:=]\s*["\']?([A-Z0-9]{20,})["\']?',
            "SECRET",
        ),
        "github_token": (r"(?i)(gh[ps]_[a-zA-Z0-9]{36,})", "SECRET"),
        "private_key_header": (
            r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
            "SECRET",
        ),
        "jwt_token": (
            r"eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*",
            "SECRET",
        ),
        "password_assignment": (
            r'(?i)(password|passwd|pwd)["\']?\s*[:=]\s*["\']([^"\']{3,})["\']',
            "SECRET",
        ),
        # File Paths
        "path_windows_absolute": (
            r'[A-Za-z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*',
            "PATH",
        ),
        "path_unix_absolute": (r"/(?:[^/\s]+/)*[^/\s]*", "PATH"),
        "path_unc": (r"\\\\[^\\]+\\[^\\]+(?:\\[^\\]+)*", "PATH"),
        # Network
        "ipv4_address": (r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", "NETWORK"),
        "ipv6_address": (r"(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}", "NETWORK"),
        "url_with_auth": (r"(?:https?|ftp)://[^:@]+:[^@]+@[^\s]+", "SECRET"),
        "localhost_port": (r"(?:localhost|127\.0\.0\.1):[0-9]{1,5}", "NETWORK"),
        # Financial
        "credit_card": (r"\b(?:\d{4}[-\s]?){3}\d{4}\b", "FINANCIAL"),
        "iban": (r"\b[A-Z]{2}\d{2}[A-Z0-9]{1,30}\b", "FINANCIAL"),
        # Project Identifiers
        "git_commit_hash": (
            r"\b(?=.*[a-fA-F])[0-9a-fA-F]{7,40}\b",  # Require at least one a-f to distinguish from pure digits
            "PROJECT",
        ),
        "uuid": (
            r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
            "PROJECT",
        ),
        # Metadata
        "timestamp_iso": (
            r"\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?",
            "META",
        ),
        "author_email_header": (
            r"(?i)(?:author|created by|written by):\s*[^\n]+@[^\n]+",
            "META",
        ),
        # Database
        "connection_string": (
            r"(?i)(?:server|host|data source)=[^;]+;(?:.*(?:user id|uid|password|pwd)=[^;]+;)+",
            "SECRET",
        ),
        "mongodb_uri": (r"mongodb(?:\+srv)?://[^:]+:[^@]+@[^\s]+", "SECRET"),
        # Cloud Identifiers
        "aws_arn": (r"arn:aws:[a-z0-9-]+:[a-z0-9-]*:[0-9]*:[a-zA-Z0-9/_-]+", "PROJECT"),
        "azure_resource_id": (
            r"/subscriptions/[a-f0-9-]+/resourceGroups/[^/]+/",
            "PROJECT",
        ),
    }

    def __init__(self, config: Optional[RedactionConfig] = None):
        """
        Initialize redaction engine.

        Args:
            config: Redaction configuration (uses defaults if None)
        """
        self.config = config or RedactionConfig()
        self._compiled_patterns: Dict[str, re.Pattern] = {}
        self._custom_keywords_pattern: Optional[re.Pattern] = None
        self._initialize_patterns()

    def _initialize_patterns(self) -> None:
        """Compile all regex patterns for performance"""
        # Compile built-in patterns for enabled categories
        for pattern_name, (pattern_str, category) in self.PATTERNS.items():
            if self._is_category_enabled(category):
                try:
                    self._compiled_patterns[pattern_name] = re.compile(pattern_str)
                except re.error:
                    # Log pattern compilation error but continue
                    pass

        # Compile custom patterns
        for pattern_name, pattern_str in self.config.custom_patterns.items():
            try:
                self._compiled_patterns[f"custom_{pattern_name}"] = re.compile(
                    pattern_str
                )
            except re.error:
                # Log custom pattern error
                pass

        # Compile custom keywords into single pattern
        if self.config.custom_keywords:
            keywords_escaped = [re.escape(kw) for kw in self.config.custom_keywords]
            flags = 0 if self.config.case_sensitive else re.IGNORECASE
            keywords_pattern = r"\b(?:" + "|".join(keywords_escaped) + r")\b"
            try:
                self._custom_keywords_pattern = re.compile(keywords_pattern, flags)
            except re.error:
                pass

    def _is_category_enabled(self, category: str) -> bool:
        """Check if a redaction category is enabled"""
        return "all" in self.config.categories or category.lower() in [
            c.lower() for c in self.config.categories
        ]

    def redact(self, text: str, context: Optional[str] = None) -> RedactionResult:
        """
        Redact sensitive data from text.

        Args:
            text: Text to redact
            context: Context hint ('code', 'dialogue', 'file', etc.)

        Returns:
            RedactionResult with redacted text and metadata
        """
        start_time = datetime.now()

        if not self.config.enabled:
            return RedactionResult(
                redacted_text=text,
                original_text=text,
                matches=[],
                categories_applied=[],
                duration_ms=0.0,
                bytes_original=len(text.encode("utf-8")),
                bytes_redacted=len(text.encode("utf-8")),
            )

        matches: List[RedactionMatch] = []
        categories_used: Set[str] = set()

        # Apply built-in patterns
        for pattern_name, compiled_pattern in self._compiled_patterns.items():
            category = self._get_category_for_pattern(pattern_name)

            for match in compiled_pattern.finditer(text):
                replacement = f"<REDACTED:{category}>"
                matches.append(
                    RedactionMatch(
                        category=category,
                        start=match.start(),
                        end=match.end(),
                        original=match.group(0),
                        replacement=replacement,
                        pattern_name=pattern_name,
                    )
                )
                categories_used.add(category)

        # Apply custom keyword pattern
        if self._custom_keywords_pattern:
            for match in self._custom_keywords_pattern.finditer(text):
                replacement = "<REDACTED:PROJECT>"
                matches.append(
                    RedactionMatch(
                        category="PROJECT",
                        start=match.start(),
                        end=match.end(),
                        original=match.group(0),
                        replacement=replacement,
                        pattern_name="custom_keyword",
                    )
                )
                categories_used.add("PROJECT")

        # Sort matches by position (reverse order for replacement)
        matches.sort(key=lambda m: m.start, reverse=True)

        # Apply redactions
        redacted = text
        for match in matches:
            redacted = (
                redacted[: match.start] + match.replacement + redacted[match.end :]
            )

        # Calculate duration
        duration_ms = (datetime.now() - start_time).total_seconds() * 1000

        return RedactionResult(
            redacted_text=redacted,
            original_text=text,
            matches=matches,
            categories_applied=sorted(list(categories_used)),
            duration_ms=duration_ms,
            bytes_original=len(text.encode("utf-8")),
            bytes_redacted=len(redacted.encode("utf-8")),
        )

    def _get_category_for_pattern(self, pattern_name: str) -> str:
        """Get category for a pattern name"""
        if pattern_name.startswith("custom_"):
            return "CUSTOM"

        # Get from PATTERNS dict
        for name, (pattern, category) in self.PATTERNS.items():
            if name == pattern_name:
                return category

        return "UNKNOWN"

    def create_preview(
        self, result: RedactionResult, max_length: Optional[int] = None
    ) -> str:
        """
        Create a preview of redacted text.

        Args:
            result: RedactionResult to preview
            max_length: Maximum length (uses config default if None)

        Returns:
            Preview string
        """
        max_len = max_length or self.config.max_preview_length
        return result.get_preview(max_len)

    def get_statistics(self, result: RedactionResult) -> Dict:
        """
        Get detailed statistics about redaction.

        Returns:
            Dictionary with statistics
        """
        category_counts: Dict[str, int] = {}
        for match in result.matches:
            category_counts[match.category] = category_counts.get(match.category, 0) + 1

        return {
            "total_matches": len(result.matches),
            "categories_applied": result.categories_applied,
            "category_counts": category_counts,
            "redaction_ratio": (
                result.bytes_redacted / result.bytes_original
                if result.bytes_original > 0
                else 0
            ),
            "duration_ms": result.duration_ms,
            "performance_ok": result.duration_ms < 50.0,  # <50ms target
        }
