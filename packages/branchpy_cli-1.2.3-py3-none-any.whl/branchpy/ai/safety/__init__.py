"""
branchpy.ai.safety
AI Safety Layer v1.0

Provides privacy, redaction, governance, and safe-mode controls for AI operations.

Components:
- Redaction Engine: Remove sensitive data before AI processing
- Safe Mode: Enforce local-only AI providers
- Policy Enforcer: AI operation policy validation
- Governance: Log all AI operations for audit trail
- Consent System: User consent for external providers
- Safety Middleware: Central integration layer

Usage:
    from branchpy.ai.safety import get_safety_layer

    safety = get_safety_layer()
    response = safety.process_request(request, provider, operation="translate")
"""

from .consent import (
    ConsentManager,
    ConsentRequest,
    ConsentResponse,
    create_auto_consent_callback,
    create_cli_consent_callback,
    get_consent_manager,
)
from .governance import AIGovernanceEvent, AIGovernanceLogger, get_governance_logger
from .middleware import AISafetyLayer, get_safety_layer
from .policy import AIPolicy, PolicyEnforcer, PolicyViolation
from .provider_validator import ValidationResult, validate_provider_for_safe_mode
from .redaction import RedactionEngine, RedactionResult
from .redaction_config import RedactionConfig
from .safe_mode import SafeModeController, SafeModeViolation
from .safe_mode_config import SafeMode, SafeModeConfig

__all__ = [
    # Redaction
    "RedactionEngine",
    "RedactionConfig",
    "RedactionResult",
    # Safe Mode
    "SafeModeController",
    "SafeModeConfig",
    "SafeMode",
    "SafeModeViolation",
    "validate_provider_for_safe_mode",
    "ValidationResult",
    # Governance
    "AIGovernanceEvent",
    "AIGovernanceLogger",
    "get_governance_logger",
    # Policy
    "AIPolicy",
    "PolicyEnforcer",
    "PolicyViolation",
    # Consent
    "ConsentRequest",
    "ConsentResponse",
    "ConsentManager",
    "get_consent_manager",
    "create_cli_consent_callback",
    "create_auto_consent_callback",
    # Middleware
    "AISafetyLayer",
    "get_safety_layer",
]

__version__ = "1.0.0"
