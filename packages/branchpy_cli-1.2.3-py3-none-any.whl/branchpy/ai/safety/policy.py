"""
AI Policy Enforcement

Defines and enforces policies for AI operations.
BQF-compliant policy engine.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..protocol import AIProvider, ChatRequest


class PolicyViolation(Exception):
    """Raised when AI policy is violated"""

    def __init__(self, message: str, code: str, provider_id: Optional[str] = None):
        self.message = message
        self.code = code
        self.provider_id = provider_id
        super().__init__(message)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary"""
        return {
            "error": "AI_POLICY_VIOLATION",
            "code": self.code,
            "message": self.message,
            "provider_id": self.provider_id,
        }


@dataclass
class AIPolicy:
    """
    AI operation policy configuration.

    Enforces:
    - Payload size limits
    - Provider whitelist/blacklist
    - Redaction requirements
    - Consent requirements
    - Safe mode defaults
    """

    # Payload limits
    max_payload_size_external: int = 200_000  # 200 KB
    max_payload_size_local: int = 32_768  # 32 KB

    # Provider restrictions
    allowed_providers: List[str] = field(
        default_factory=list
    )  # Empty = all allowed (with consent)
    blocked_providers: List[str] = field(default_factory=list)

    # Safety requirements
    redaction_required: bool = True
    consent_required_external: bool = True
    safe_mode_default: bool = True

    # Rate limiting (future)
    max_requests_per_minute: int = 30
    max_requests_per_hour: int = 500

    # Cost limits (future)
    max_cost_per_request: float = 1.0  # USD
    max_cost_per_day: float = 10.0  # USD

    # Governance
    require_governance_logging: bool = True
    policy_version: str = "1.0"

    @classmethod
    def from_dict(cls, config: Dict) -> "AIPolicy":
        """Create AIPolicy from dictionary"""
        return cls(
            max_payload_size_external=config.get("max_payload_size_external", 200_000),
            max_payload_size_local=config.get("max_payload_size_local", 32_768),
            allowed_providers=config.get("allowed_providers", []),
            blocked_providers=config.get("blocked_providers", []),
            redaction_required=config.get("redaction_required", True),
            consent_required_external=config.get("consent_required_external", True),
            safe_mode_default=config.get("safe_mode_default", True),
            max_requests_per_minute=config.get("max_requests_per_minute", 30),
            max_requests_per_hour=config.get("max_requests_per_hour", 500),
            max_cost_per_request=config.get("max_cost_per_request", 1.0),
            max_cost_per_day=config.get("max_cost_per_day", 10.0),
            require_governance_logging=config.get("require_governance_logging", True),
            policy_version=config.get("policy_version", "1.0"),
        )

    @classmethod
    def from_toml_file(cls, path: Path) -> Optional["AIPolicy"]:
        """Load policy from TOML file"""
        if not path.exists():
            return None

        try:
            import tomli
        except ImportError:
            try:
                import tomllib as tomli
            except ImportError:
                return None

        with open(path, "rb") as f:
            data = tomli.load(f)

        # Navigate to ai.safety.policy section
        if "ai" in data and "safety" in data["ai"] and "policy" in data["ai"]["safety"]:
            return cls.from_dict(data["ai"]["safety"]["policy"])

        return None

    @classmethod
    def load_from_workspace(cls, workspace_path: Optional[Path] = None) -> "AIPolicy":
        """
        Load policy with fallback chain:
        1. Workspace .branchpy/branchpy.toml
        2. User ~/.branchpy/config.toml
        3. Defaults
        """
        # Try workspace config
        if workspace_path:
            workspace_config = workspace_path / ".branchpy" / "branchpy.toml"
            if workspace_config.exists():
                policy = cls.from_toml_file(workspace_config)
                if policy:
                    return policy

        # Try user config
        home = Path.home()
        user_configs = [
            home / ".branchpy" / "config.toml",
            home / "branchpy.toml",
        ]

        for config_path in user_configs:
            if config_path.exists():
                policy = cls.from_toml_file(config_path)
                if policy:
                    return policy

        # Return defaults
        return cls()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary"""
        return {
            "max_payload_size_external": self.max_payload_size_external,
            "max_payload_size_local": self.max_payload_size_local,
            "allowed_providers": self.allowed_providers,
            "blocked_providers": self.blocked_providers,
            "redaction_required": self.redaction_required,
            "consent_required_external": self.consent_required_external,
            "safe_mode_default": self.safe_mode_default,
            "max_requests_per_minute": self.max_requests_per_minute,
            "max_requests_per_hour": self.max_requests_per_hour,
            "max_cost_per_request": self.max_cost_per_request,
            "max_cost_per_day": self.max_cost_per_day,
            "require_governance_logging": self.require_governance_logging,
            "policy_version": self.policy_version,
        }


class PolicyEnforcer:
    """
    Enforces AI policies on requests.

    Validates:
    - Provider allowed
    - Payload size
    - Redaction applied
    - Consent obtained
    """

    def __init__(self, policy: Optional[AIPolicy] = None):
        """
        Initialize policy enforcer.

        Args:
            policy: AI policy (uses defaults if None)
        """
        self.policy = policy or AIPolicy()

    def enforce_provider(self, provider: AIProvider) -> None:
        """
        Enforce provider restrictions.

        Args:
            provider: AI provider to validate

        Raises:
            PolicyViolation: If provider not allowed
        """
        # Check blocked list
        if provider.provider_id in self.policy.blocked_providers:
            raise PolicyViolation(
                f"Provider '{provider.provider_id}' is blocked by policy",
                code="PROVIDER_BLOCKED",
                provider_id=provider.provider_id,
            )

        # Check allowed list (if specified)
        if self.policy.allowed_providers:
            if provider.provider_id not in self.policy.allowed_providers:
                raise PolicyViolation(
                    f"Provider '{provider.provider_id}' not in allowed providers list: "
                    f"{', '.join(self.policy.allowed_providers)}",
                    code="PROVIDER_NOT_ALLOWED",
                    provider_id=provider.provider_id,
                )

    def enforce_payload_size(self, payload: str, provider: AIProvider) -> None:
        """
        Enforce payload size limits.

        Args:
            payload: Request payload text
            provider: AI provider

        Raises:
            PolicyViolation: If payload exceeds limit
        """
        payload_size = len(payload.encode("utf-8"))
        max_size = (
            self.policy.max_payload_size_local
            if provider.is_local
            else self.policy.max_payload_size_external
        )

        if payload_size > max_size:
            provider_type = "local" if provider.is_local else "external"
            raise PolicyViolation(
                f"Payload size ({payload_size:,} bytes) exceeds {provider_type} limit "
                f"({max_size:,} bytes). Reduce context or increase policy limit.",
                code="PAYLOAD_TOO_LARGE",
                provider_id=provider.provider_id,
            )

    def enforce_redaction(self, request: ChatRequest, redaction_applied: bool) -> None:
        """
        Enforce redaction requirement.

        Args:
            request: Chat request
            redaction_applied: Whether redaction was applied

        Raises:
            PolicyViolation: If redaction required but not applied
        """
        if self.policy.redaction_required and not redaction_applied:
            raise PolicyViolation(
                "Policy requires redaction but it was not applied",
                code="REDACTION_REQUIRED",
            )

    def enforce_consent(self, provider: AIProvider, consent_granted: bool) -> None:
        """
        Enforce consent requirement for external providers.

        Args:
            provider: AI provider
            consent_granted: Whether user consent was granted

        Raises:
            PolicyViolation: If consent required but not granted
        """
        if not provider.is_local and self.policy.consent_required_external:
            if not consent_granted:
                raise PolicyViolation(
                    f"Policy requires consent for external provider '{provider.provider_id}' "
                    f"but consent was not granted",
                    code="CONSENT_REQUIRED",
                    provider_id=provider.provider_id,
                )

    def enforce_governance_logging(self, logging_enabled: bool) -> None:
        """
        Enforce governance logging requirement.

        Args:
            logging_enabled: Whether governance logging is enabled

        Raises:
            PolicyViolation: If logging required but disabled
        """
        if self.policy.require_governance_logging and not logging_enabled:
            raise PolicyViolation(
                "Policy requires governance logging but it is disabled",
                code="GOVERNANCE_LOGGING_REQUIRED",
            )

    def enforce_request(
        self,
        request: ChatRequest,
        provider: AIProvider,
        payload: str,
        redaction_applied: bool = False,
        consent_granted: bool = False,
        logging_enabled: bool = True,
    ) -> None:
        """
        Enforce all policies on a request (convenience method).

        Args:
            request: Chat request
            provider: AI provider
            payload: Request payload text
            redaction_applied: Whether redaction was applied
            consent_granted: Whether consent was granted
            logging_enabled: Whether governance logging enabled

        Raises:
            PolicyViolation: If any policy violated
        """
        self.enforce_provider(provider)
        self.enforce_payload_size(payload, provider)
        self.enforce_redaction(request, redaction_applied)
        self.enforce_consent(provider, consent_granted)
        self.enforce_governance_logging(logging_enabled)

    def check_request(
        self,
        request: ChatRequest,
        provider: AIProvider,
        payload: str,
        redaction_applied: bool = False,
        consent_granted: bool = False,
    ) -> Dict[str, Any]:
        """
        Check request against policies without raising exceptions.

        Returns:
            Dictionary with check results
        """
        violations = []
        warnings = []

        # Check provider
        try:
            self.enforce_provider(provider)
        except PolicyViolation as e:
            violations.append(e.to_dict())

        # Check payload size
        try:
            self.enforce_payload_size(payload, provider)
        except PolicyViolation as e:
            violations.append(e.to_dict())

        # Check redaction
        if self.policy.redaction_required and not redaction_applied:
            warnings.append(
                {
                    "code": "REDACTION_NOT_APPLIED",
                    "message": "Redaction is recommended by policy",
                }
            )

        # Check consent
        if (
            not provider.is_local
            and self.policy.consent_required_external
            and not consent_granted
        ):
            violations.append(
                {
                    "code": "CONSENT_REQUIRED",
                    "message": f"Consent required for external provider '{provider.provider_id}'",
                }
            )

        return {
            "is_compliant": len(violations) == 0,
            "violations": violations,
            "warnings": warnings,
            "policy_version": self.policy.policy_version,
        }


# Example TOML configuration
EXAMPLE_CONFIG = """
[ai.safety.policy]
# Payload size limits (bytes)
max_payload_size_external = 200000  # 200 KB for cloud providers
max_payload_size_local = 32768      # 32 KB for local providers

# Provider restrictions
allowed_providers = []  # Empty = all allowed (with consent)
blocked_providers = []  # Explicitly blocked providers

# Safety requirements
redaction_required = true
consent_required_external = true
safe_mode_default = true

# Rate limiting
max_requests_per_minute = 30
max_requests_per_hour = 500

# Cost limits (USD)
max_cost_per_request = 1.0
max_cost_per_day = 10.0

# Governance
require_governance_logging = true
policy_version = "1.0"
"""
