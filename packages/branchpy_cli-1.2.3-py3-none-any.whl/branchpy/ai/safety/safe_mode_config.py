"""
Safe Mode Configuration

Defines configuration schema for safe mode enforcement.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional


class SafeMode(Enum):
    """Safe mode state"""

    ON = "on"  # Only local providers allowed
    OFF = "off"  # External providers allowed with consent

    @classmethod
    def from_string(cls, value: str) -> "SafeMode":
        """Parse safe mode from string"""
        value_lower = value.lower()
        if value_lower in ("on", "true", "1", "yes", "enabled"):
            return cls.ON
        elif value_lower in ("off", "false", "0", "no", "disabled"):
            return cls.OFF
        else:
            raise ValueError(f"Invalid safe mode value: {value}")


@dataclass
class SafeModeConfig:
    """
    Configuration for safe mode enforcement.

    Attributes:
        default_mode: Default safe mode state
        allow_cli_override: Allow CLI flag to override
        allow_workspace_override: Allow workspace config to override
        max_payload_size_local: Max payload for local providers (bytes)
        max_payload_size_external: Max payload for external providers (bytes)
        allowed_external_providers: Whitelist of external providers (empty = all blocked)
        require_api_key_encryption: Require API keys to be encrypted
    """

    default_mode: SafeMode = SafeMode.ON
    allow_cli_override: bool = True
    allow_workspace_override: bool = True
    max_payload_size_local: int = 32_768  # 32 KB default
    max_payload_size_external: int = 200_000  # 200 KB default
    allowed_external_providers: List[str] = field(default_factory=list)
    require_api_key_encryption: bool = False

    @classmethod
    def from_dict(cls, config: dict) -> "SafeModeConfig":
        """Create SafeModeConfig from dictionary"""
        default_mode_str = config.get("default_mode", "on")
        default_mode = SafeMode.from_string(default_mode_str)

        return cls(
            default_mode=default_mode,
            allow_cli_override=config.get("allow_cli_override", True),
            allow_workspace_override=config.get("allow_workspace_override", True),
            max_payload_size_local=config.get("max_payload_size_local", 32_768),
            max_payload_size_external=config.get("max_payload_size_external", 200_000),
            allowed_external_providers=config.get("allowed_external_providers", []),
            require_api_key_encryption=config.get("require_api_key_encryption", False),
        )

    @classmethod
    def from_toml_file(cls, path: Path) -> Optional["SafeModeConfig"]:
        """Load config from TOML file"""
        if not path.exists():
            return None

        try:
            import tomli
        except ImportError:
            try:
                import tomllib as tomli
            except ImportError:
                return None

        with open(path, "rb") as f:
            data = tomli.load(f)

        # Navigate to ai.safety.safe_mode section
        if (
            "ai" in data
            and "safety" in data["ai"]
            and "safe_mode" in data["ai"]["safety"]
        ):
            return cls.from_dict(data["ai"]["safety"]["safe_mode"])

        return None

    @classmethod
    def load_from_workspace(
        cls, workspace_path: Optional[Path] = None
    ) -> "SafeModeConfig":
        """
        Load safe mode config with fallback chain:
        1. Workspace .branchpy/branchpy.toml
        2. User ~/.branchpy/config.toml
        3. User ~/branchpy.toml
        4. Defaults (safe mode ON)
        """
        # Try workspace config
        if workspace_path:
            workspace_config = workspace_path / ".branchpy" / "branchpy.toml"
            if workspace_config.exists():
                config = cls.from_toml_file(workspace_config)
                if config:
                    return config

        # Try user config locations
        home = Path.home()
        user_configs = [
            home / ".branchpy" / "config.toml",
            home / "branchpy.toml",
        ]

        for config_path in user_configs:
            if config_path.exists():
                config = cls.from_toml_file(config_path)
                if config:
                    return config

        # Return defaults (safe mode ON)
        return cls()

    def to_dict(self) -> dict:
        """Serialize to dictionary"""
        return {
            "default_mode": self.default_mode.value,
            "allow_cli_override": self.allow_cli_override,
            "allow_workspace_override": self.allow_workspace_override,
            "max_payload_size_local": self.max_payload_size_local,
            "max_payload_size_external": self.max_payload_size_external,
            "allowed_external_providers": self.allowed_external_providers,
            "require_api_key_encryption": self.require_api_key_encryption,
        }


# Example TOML configuration
EXAMPLE_CONFIG = """
[ai.safety.safe_mode]
default_mode = "on"  # "on" or "off"
allow_cli_override = true
allow_workspace_override = true
max_payload_size_local = 32768      # 32 KB for local providers
max_payload_size_external = 200000  # 200 KB for external providers
require_api_key_encryption = false

# Whitelist of allowed external providers (empty = all blocked in safe mode)
allowed_external_providers = []

# Example: Allow specific providers
# allowed_external_providers = ["openai", "venice"]
"""
