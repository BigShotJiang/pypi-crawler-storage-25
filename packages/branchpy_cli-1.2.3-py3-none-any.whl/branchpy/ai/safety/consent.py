"""
AI Consent System

Manages user consent for external AI provider requests.
Required for GDPR, CCPA, and Quebec Law 25 compliance.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, Optional

from ..protocol import AIProvider


@dataclass
class ConsentRequest:
    """
    Request for user consent to use external AI provider.

    Contains all information needed for informed consent.
    """

    provider_id: str
    model: str
    operation: str
    preview_redacted: str
    payload_size: int
    project: str = ""
    is_local: bool = False
    safe_mode: bool = True
    redaction_applied: bool = False
    timestamp: datetime = field(default_factory=datetime.now)

    def get_display_text(self, max_preview: int = 500) -> str:
        """
        Generate user-friendly display text for consent prompt.

        Args:
            max_preview: Maximum preview length

        Returns:
            Formatted consent prompt text
        """
        lines = []

        # Header
        lines.append("╔════════════════════════════════════════════════════════════╗")
        lines.append("║          🔒 EXTERNAL AI REQUEST - CONSENT REQUIRED         ║")
        lines.append("╚════════════════════════════════════════════════════════════╝")
        lines.append("")

        # Provider info
        lines.append(f"Provider:     {self.provider_id}")
        lines.append(f"Model:        {self.model}")
        lines.append(f"Operation:    {self.operation}")
        lines.append(f"Payload Size: {self.payload_size:,} bytes")
        if self.project:
            lines.append(f"Project:      {self.project}")
        lines.append("")

        # Privacy info
        lines.append("Privacy Information:")
        if self.redaction_applied:
            lines.append("  ✓ Sensitive data has been redacted")
        else:
            lines.append("  ⚠ WARNING: Redaction not applied")

        if self.safe_mode:
            lines.append("  ⚠ Safe mode is ON - external providers normally blocked")
        else:
            lines.append("  ℹ Safe mode is OFF - external providers allowed")
        lines.append("")

        # Preview
        preview = self.preview_redacted
        if len(preview) > max_preview:
            preview = preview[:max_preview] + "\n[... truncated ...]"

        lines.append("Preview (redacted):")
        lines.append("─" * 60)
        lines.append(preview)
        lines.append("─" * 60)
        lines.append("")

        # Legal notice
        lines.append("⚖ Legal Notice:")
        lines.append("  This request will send data to an external AI service.")
        lines.append("  Data may be processed outside your jurisdiction.")
        lines.append("  Review the provider's privacy policy before consenting.")
        lines.append("")

        return "\n".join(lines)

    def to_dict(self) -> Dict:
        """Serialize to dictionary"""
        return {
            "provider_id": self.provider_id,
            "model": self.model,
            "operation": self.operation,
            "payload_size": self.payload_size,
            "project": self.project,
            "is_local": self.is_local,
            "safe_mode": self.safe_mode,
            "redaction_applied": self.redaction_applied,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class ConsentResponse:
    """
    User's response to consent request.
    """

    granted: bool
    remember_for_session: bool = False
    declined_reason: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict:
        """Serialize to dictionary"""
        return {
            "granted": self.granted,
            "remember_for_session": self.remember_for_session,
            "declined_reason": self.declined_reason,
            "timestamp": self.timestamp.isoformat(),
        }


class ConsentManager:
    """
    Manages user consent for external AI operations.

    Features:
    - Session-based consent cache
    - Per-provider, per-operation tracking
    - "Remember for session" support
    - Consent prompt integration
    """

    def __init__(
        self,
        consent_callback: Optional[Callable[[ConsentRequest], ConsentResponse]] = None,
        enable_cache: bool = True,
    ):
        """
        Initialize consent manager.

        Args:
            consent_callback: Function to prompt user for consent
            enable_cache: Enable session-based consent caching
        """
        self.consent_callback = consent_callback
        self.enable_cache = enable_cache
        self._cache: Dict[str, ConsentResponse] = {}

    def _get_cache_key(self, provider_id: str, operation: str) -> str:
        """Generate cache key for provider + operation"""
        return f"{provider_id}:{operation}"

    def request_consent(
        self,
        provider: AIProvider,
        operation: str,
        preview_redacted: str,
        payload_size: int,
        project: str = "",
        safe_mode: bool = True,
        redaction_applied: bool = False,
    ) -> ConsentResponse:
        """
        Request user consent for external AI operation.

        Args:
            provider: AI provider
            operation: Operation type (translate, refactor, etc.)
            preview_redacted: Redacted preview of request
            payload_size: Request size in bytes
            project: Project name
            safe_mode: Whether safe mode is enabled
            redaction_applied: Whether redaction was applied

        Returns:
            ConsentResponse with user's decision
        """
        # Check cache first
        if self.enable_cache:
            cache_key = self._get_cache_key(provider.provider_id, operation)
            if cache_key in self._cache:
                cached = self._cache[cache_key]
                if cached.remember_for_session:
                    return cached

        # Create consent request
        request = ConsentRequest(
            provider_id=provider.provider_id,
            model=getattr(provider, "default_model", "unknown"),
            operation=operation,
            preview_redacted=preview_redacted,
            payload_size=payload_size,
            project=project,
            is_local=provider.is_local,
            safe_mode=safe_mode,
            redaction_applied=redaction_applied,
        )

        # Get consent from user
        if self.consent_callback:
            response = self.consent_callback(request)
        else:
            # Default: deny if no callback (safety-first)
            response = ConsentResponse(
                granted=False,
                declined_reason="No consent callback configured",
            )

        # Cache if requested
        if self.enable_cache and response.remember_for_session:
            cache_key = self._get_cache_key(provider.provider_id, operation)
            self._cache[cache_key] = response

        return response

    def is_consent_required(self, provider: AIProvider) -> bool:
        """
        Check if consent is required for provider.

        Local providers don't require consent.

        Args:
            provider: AI provider

        Returns:
            True if consent required
        """
        return not provider.is_local

    def check_cached_consent(
        self,
        provider_id: str,
        operation: str,
    ) -> Optional[ConsentResponse]:
        """
        Check for cached consent decision.

        Args:
            provider_id: Provider identifier
            operation: Operation type

        Returns:
            Cached ConsentResponse or None
        """
        if not self.enable_cache:
            return None

        cache_key = self._get_cache_key(provider_id, operation)
        cached = self._cache.get(cache_key)

        if cached and cached.remember_for_session:
            return cached

        return None

    def clear_cache(self) -> None:
        """Clear all cached consent decisions"""
        self._cache.clear()

    def clear_provider_cache(self, provider_id: str) -> None:
        """
        Clear cached consent for specific provider.

        Args:
            provider_id: Provider identifier
        """
        keys_to_remove = [
            key for key in self._cache.keys() if key.startswith(f"{provider_id}:")
        ]
        for key in keys_to_remove:
            del self._cache[key]

    def get_cache_status(self) -> Dict:
        """
        Get current cache status.

        Returns:
            Dictionary with cache information
        """
        return {
            "enabled": self.enable_cache,
            "cached_decisions": len(self._cache),
            "providers": list(set(key.split(":")[0] for key in self._cache.keys())),
        }

    def export_consent_log(self, output_path: Path) -> int:
        """
        Export cached consent decisions to JSON.

        Args:
            output_path: Output file path

        Returns:
            Number of decisions exported
        """
        decisions = []

        for key, response in self._cache.items():
            provider_id, operation = key.split(":", 1)
            decisions.append(
                {
                    "provider_id": provider_id,
                    "operation": operation,
                    "granted": response.granted,
                    "remember_for_session": response.remember_for_session,
                    "timestamp": response.timestamp.isoformat(),
                }
            )

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(decisions, f, indent=2)

        return len(decisions)


def create_cli_consent_callback() -> Callable[[ConsentRequest], ConsentResponse]:
    """
    Create CLI-based consent callback using input().

    Returns:
        Consent callback function
    """

    def cli_prompt(request: ConsentRequest) -> ConsentResponse:
        # Display consent request
        print("\n" + request.get_display_text())

        # Prompt for decision
        while True:
            print("Do you consent to this request?")
            print("  [Y] Yes")
            print("  [N] No")
            print("  [R] Remember my choice for this session")
            print()
            choice = input("Your choice (Y/N/R): ").strip().upper()

            if choice == "Y":
                return ConsentResponse(granted=True, remember_for_session=False)
            elif choice == "N":
                reason = input("Reason (optional): ").strip()
                return ConsentResponse(
                    granted=False,
                    remember_for_session=False,
                    declined_reason=reason or "User declined",
                )
            elif choice == "R":
                print("Remember choice for session. Do you consent?")
                sub_choice = input("Your choice (Y/N): ").strip().upper()
                if sub_choice == "Y":
                    return ConsentResponse(granted=True, remember_for_session=True)
                elif sub_choice == "N":
                    reason = input("Reason (optional): ").strip()
                    return ConsentResponse(
                        granted=False,
                        remember_for_session=True,
                        declined_reason=reason or "User declined",
                    )

            print("Invalid choice. Please enter Y, N, or R.\n")

    return cli_prompt


def create_auto_consent_callback(
    always_grant: bool = True,
) -> Callable[[ConsentRequest], ConsentResponse]:
    """
    Create automatic consent callback (for testing/automation).

    Args:
        always_grant: Always grant consent (True) or always deny (False)

    Returns:
        Consent callback function
    """

    def auto_prompt(request: ConsentRequest) -> ConsentResponse:
        return ConsentResponse(
            granted=always_grant,
            remember_for_session=False,
            declined_reason=None if always_grant else "Auto-denied",
        )

    return auto_prompt


# Global consent manager instance (lazy initialized)
_global_consent_manager: Optional[ConsentManager] = None


def get_consent_manager(
    consent_callback: Optional[Callable[[ConsentRequest], ConsentResponse]] = None,
) -> ConsentManager:
    """
    Get global consent manager instance (singleton).

    Args:
        consent_callback: Consent callback function (uses CLI if None)

    Returns:
        ConsentManager instance
    """
    global _global_consent_manager

    if _global_consent_manager is None:
        callback = consent_callback or create_cli_consent_callback()
        _global_consent_manager = ConsentManager(consent_callback=callback)

    return _global_consent_manager


def set_consent_manager(manager: ConsentManager) -> None:
    """Set global consent manager instance"""
    global _global_consent_manager
    _global_consent_manager = manager
