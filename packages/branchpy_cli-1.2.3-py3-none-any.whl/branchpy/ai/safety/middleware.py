"""
AI Safety Middleware

Central integration point for all AI operations.
Ties together redaction, safe mode, policy enforcement, consent, and governance.
"""

import time
from pathlib import Path
from typing import Any, Dict, Optional

from ..protocol import AIProvider, ChatRequest, ChatResponse
from .consent import ConsentManager
from .governance import AIGovernanceEvent, AIGovernanceLogger, get_governance_logger
from .policy import AIPolicy, PolicyEnforcer, PolicyViolation
from .redaction import RedactionConfig, RedactionEngine
from .safe_mode import SafeMode, SafeModeConfig, SafeModeController


class AISafetyLayer:
    """
    Main safety middleware for AI operations.

    Process flow:
    1. Check safe mode
    2. Validate provider
    3. Enforce policy
    4. Apply redaction
    5. Request consent (if needed)
    6. Call AI provider
    7. Log governance event
    8. Return response
    """

    def __init__(
        self,
        redaction_config: Optional[RedactionConfig] = None,
        safe_mode_config: Optional[SafeModeConfig] = None,
        policy: Optional[AIPolicy] = None,
        governance_logger: Optional[AIGovernanceLogger] = None,
        consent_manager: Optional[ConsentManager] = None,
    ):
        """
        Initialize AI safety layer.

        Args:
            redaction_config: Redaction configuration
            safe_mode_config: Safe mode configuration
            policy: AI policy
            governance_logger: Governance logger
            consent_manager: Consent manager for user prompts
        """
        # Load configurations
        workspace = Path.cwd()

        self.redaction_config = redaction_config or RedactionConfig.load_from_workspace(
            workspace
        )
        self.safe_mode_config = safe_mode_config or SafeModeConfig.load_from_workspace(
            workspace
        )
        self.policy = policy or AIPolicy.load_from_workspace(workspace)

        # Initialize components
        self.redaction_engine = RedactionEngine(self.redaction_config)
        self.safe_mode_controller = SafeModeController(config=self.safe_mode_config)
        self.policy_enforcer = PolicyEnforcer(self.policy)
        self.governance_logger = governance_logger or get_governance_logger()
        self.consent_manager = consent_manager or ConsentManager()

    def process_request(
        self,
        request: ChatRequest,
        provider: AIProvider,
        operation: str = "chat",
        project: str = "",
        user_id: str = "<local-user>",
        skip_consent: bool = False,
    ) -> ChatResponse:
        """
        Process AI request through safety layer.

        Args:
            request: Chat request
            provider: AI provider
            operation: Operation type (chat, translate, refactor, etc.)
            project: Project name
            user_id: User identifier
            skip_consent: Skip consent check (for testing)

        Returns:
            ChatResponse from provider

        Raises:
            SafeModeViolation: If safe mode blocks provider
            PolicyViolation: If policy violated
        """
        start_time = time.perf_counter()

        # Build full request text for analysis
        request_text = self._build_request_text(request)
        original_size = len(request_text.encode("utf-8"))

        # STEP 1: Check safe mode
        safe_mode = self.safe_mode_controller.get_safe_mode()

        # STEP 2: Validate provider against safe mode
        self.safe_mode_controller.enforce_provider(provider)

        # STEP 3: Enforce policy
        # (Redaction and consent status will be updated after those steps)
        redaction_applied = False
        consent_granted = (
            skip_consent or provider.is_local
        )  # Local doesn't need consent

        # Check policy first (will raise if violations)
        self.policy_enforcer.enforce_provider(provider)
        self.policy_enforcer.enforce_payload_size(request_text, provider)

        # STEP 4: Apply redaction (if enabled)
        redacted_preview = ""
        if self.redaction_config.enabled:
            redaction_result = self.redaction_engine.redact(
                request_text, context=operation
            )
            redacted_text = redaction_result.redacted_text
            redacted_preview = redaction_result.get_preview(max_length=500)
            redaction_applied = True

            # Update request with redacted text (in future, this would modify the actual request)
            # For now, we just track that redaction was applied
        else:
            redacted_text = request_text
            redacted_preview = request_text[:500] + (
                "..." if len(request_text) > 500 else ""
            )

        # STEP 5: Request consent (if external provider and not skipped)
        if not provider.is_local and not skip_consent:
            # Check if consent manager configured
            if self.consent_manager.consent_callback:
                consent_response = self.consent_manager.request_consent(
                    provider=provider,
                    operation=operation,
                    preview_redacted=redacted_preview,
                    payload_size=original_size,
                    project=project,
                    safe_mode=(safe_mode == SafeMode.ON),
                    redaction_applied=redaction_applied,
                )

                consent_granted = consent_response.granted

                if not consent_granted:
                    # User declined consent
                    error_msg = f"User declined consent for external provider '{provider.provider_id}'"
                    if consent_response.declined_reason:
                        error_msg += f": {consent_response.declined_reason}"

                    # Log governance event (failure)
                    event = AIGovernanceEvent(
                        user_id=user_id,
                        project=project,
                        provider=provider.provider_id,
                        model=request.model or "unknown",
                        safe_mode=(safe_mode == SafeMode.ON),
                        bytes_sent=original_size,
                        operation=operation,
                        preview_redacted=redacted_preview,
                        success=False,
                        error="USER_DECLINED_CONSENT",
                        redaction_applied=redaction_applied,
                        consent_granted=False,
                    )
                    self.governance_logger.log_event(event)

                    raise PolicyViolation(
                        error_msg,
                        code="USER_DECLINED_CONSENT",
                        provider_id=provider.provider_id,
                    )
            else:
                # No consent manager configured, assume consent granted
                # (In production, this should raise an error or use default behavior)
                consent_granted = True
        else:
            # Local provider or consent skipped
            consent_granted = skip_consent or provider.is_local

        # STEP 6: Final policy enforcement
        self.policy_enforcer.enforce_redaction(request, redaction_applied)
        self.policy_enforcer.enforce_consent(provider, consent_granted)
        self.policy_enforcer.enforce_governance_logging(True)  # Always enabled

        # STEP 7: Call AI provider's raw implementation (bypass safety layer to avoid recursion)
        try:
            response = provider._raw_chat(request)
            response_size = len(response.content.encode("utf-8"))
            duration_ms = (time.perf_counter() - start_time) * 1000

            # STEP 8: Log governance event (success)
            event = AIGovernanceEvent(
                user_id=user_id,
                project=project,
                provider=provider.provider_id,
                model=request.model or "unknown",
                safe_mode=(safe_mode == SafeMode.ON),
                bytes_sent=original_size,
                bytes_received=response_size,
                operation=operation,
                preview_redacted=redacted_preview,
                success=True,
                duration_ms=duration_ms,
                redaction_applied=redaction_applied,
                consent_granted=consent_granted,
            )
            self.governance_logger.log_event(event)

            return response

        except Exception as e:
            # Log governance event (failure)
            duration_ms = (time.perf_counter() - start_time) * 1000
            event = AIGovernanceEvent(
                user_id=user_id,
                project=project,
                provider=provider.provider_id,
                model=request.model or "unknown",
                safe_mode=(safe_mode == SafeMode.ON),
                bytes_sent=original_size,
                bytes_received=0,
                operation=operation,
                preview_redacted=redacted_preview,
                success=False,
                duration_ms=duration_ms,
                error=str(e),
                redaction_applied=redaction_applied,
                consent_granted=consent_granted,
            )
            self.governance_logger.log_event(event)

            # Re-raise original exception
            raise

    def _build_request_text(self, request: ChatRequest) -> str:
        """Build full request text for analysis"""
        parts = []

        for message in request.messages:
            # Handle both dict and Message dataclass
            if isinstance(message, dict):
                role = message.get("role", "user")
                content = message.get("content", "")
            else:
                role = message.role
                content = message.content
            parts.append(f"{role}: {content}")

        return "\n".join(parts)

    def check_request_compliance(
        self,
        request: ChatRequest,
        provider: AIProvider,
    ) -> Dict[str, Any]:
        """
        Check request compliance without executing.

        Useful for dry-run mode.

        Returns:
            Dictionary with compliance check results
        """
        request_text = self._build_request_text(request)

        # Check safe mode
        safe_mode = self.safe_mode_controller.get_safe_mode()
        is_provider_allowed = self.safe_mode_controller.is_provider_allowed(provider)

        # Check policy
        policy_check = self.policy_enforcer.check_request(
            request=request,
            provider=provider,
            payload=request_text,
            redaction_applied=self.redaction_config.enabled,
            consent_granted=provider.is_local,  # Local doesn't need consent
        )

        # Check redaction
        redaction_result = None
        if self.redaction_config.enabled:
            redaction_result = self.redaction_engine.redact(request_text)

        return {
            "safe_mode": safe_mode.value,
            "provider_allowed": is_provider_allowed,
            "policy_compliant": policy_check["is_compliant"],
            "policy_violations": policy_check["violations"],
            "policy_warnings": policy_check["warnings"],
            "redaction_enabled": self.redaction_config.enabled,
            "redaction_matches": (
                len(redaction_result.matches) if redaction_result else 0
            ),
            "redaction_categories": (
                redaction_result.categories_applied if redaction_result else []
            ),
            "payload_size": len(request_text.encode("utf-8")),
            "max_payload_size": (
                self.policy.max_payload_size_local
                if provider.is_local
                else self.policy.max_payload_size_external
            ),
        }

    def get_configuration_summary(self) -> Dict[str, Any]:
        """
        Get summary of current safety configuration.

        Returns:
            Dictionary with configuration details
        """
        safe_mode_info = self.safe_mode_controller.get_mode_info()

        return {
            "safe_mode": safe_mode_info,
            "redaction": {
                "enabled": self.redaction_config.enabled,
                "categories": self.redaction_config.categories,
                "custom_keywords_count": len(self.redaction_config.custom_keywords),
                "custom_patterns_count": len(self.redaction_config.custom_patterns),
            },
            "policy": self.policy.to_dict(),
            "governance": {
                "log_path": str(self.governance_logger.log_path),
                "integrity_enabled": self.governance_logger.enable_integrity,
            },
        }

    def set_safe_mode(self, mode: SafeMode) -> None:
        """
        Set safe mode (CLI override).

        Args:
            mode: SafeMode.ON or SafeMode.OFF
        """
        self.safe_mode_controller.set_cli_override(mode)

    def clear_safe_mode_override(self) -> None:
        """Clear CLI safe mode override"""
        self.safe_mode_controller.clear_cli_override()


# Global safety layer instance (lazy initialized)
_global_safety_layer: Optional[AISafetyLayer] = None


def get_safety_layer(
    redaction_config: Optional[RedactionConfig] = None,
    safe_mode_config: Optional[SafeModeConfig] = None,
    policy: Optional[AIPolicy] = None,
) -> AISafetyLayer:
    """
    Get global safety layer instance (singleton).

    Args:
        redaction_config: Redaction configuration
        safe_mode_config: Safe mode configuration
        policy: AI policy

    Returns:
        AISafetyLayer instance
    """
    global _global_safety_layer

    if _global_safety_layer is None:
        _global_safety_layer = AISafetyLayer(
            redaction_config=redaction_config,
            safe_mode_config=safe_mode_config,
            policy=policy,
        )

    return _global_safety_layer


def set_safety_layer(layer: AISafetyLayer) -> None:
    """Set global safety layer instance"""
    global _global_safety_layer
    _global_safety_layer = layer
