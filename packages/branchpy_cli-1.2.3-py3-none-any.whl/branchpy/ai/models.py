# branchpy/ai/models.py
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional


class ProviderCapability(str, Enum):
    """High-level AI capability type, used for routing & governance."""

    CODE_REVIEW = "code_review"
    DOC_GEN = "doc_gen"
    EXPLAIN_WARNING = "explain_warning"
    CHAT_HELP = "chat_help"
    CODE_PATCH = "code_patch"


class DataClassification(str, Enum):
    """Data sensitivity level for AI calls, used by Data Guard + governance."""

    PUBLIC = "public"
    INTERNAL = "internal"
    SENSITIVE = "sensitive"
    RESTRICTED = "restricted"


@dataclass
class AIRequestBase:
    """
    Base fields for all AI requests.

    These fields are shared across capabilities and are important for:
    - governance logging
    - Data Guard behavior
    - provider routing
    """

    id: str  # correlation ID, ideally from existing governance/telemetry
    capability: ProviderCapability

    # Contextual info for routing + display
    project: Optional[str] = None
    file_path: Optional[str] = None

    # Governance / Data Guard metadata
    data_class: DataClassification = DataClassification.INTERNAL
    redaction_applied: bool = False  # Data Guard will flip this to True when used

    # Free-form extra metadata (e.g., editor position, branch name, etc.)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """JSON-serializable view suitable for logging and providers."""
        return asdict(self)


@dataclass
class CodeReviewRequest(AIRequestBase):
    """
    Request to review a block of code.

    The 'code' field should contain exactly what will be sent to the provider
    *after* Data Guard has run.
    """

    code: str = ""
    language: Optional[str] = None  # e.g., "python", "csharp"
    cursor_line: Optional[int] = None
    selection_start: Optional[int] = None
    selection_end: Optional[int] = None

    # Optional extra context (e.g., neighboring code, function name)
    context_before: Optional[str] = None
    context_after: Optional[str] = None


@dataclass
class DocGenRequest(AIRequestBase):
    """
    Request to generate or improve documentation for a symbol or file.
    """

    symbol_name: Optional[str] = None  # function/class name, etc.
    symbol_kind: Optional[str] = None  # "function", "class", "module", etc.
    code: str = ""  # relevant code block
    existing_doc: Optional[str] = None  # current docstring/comment, if any
    language: Optional[str] = None  # "python", "csharp", etc.


@dataclass
class ExplainWarningRequest(AIRequestBase):
    """
    Request to explain or suggest fixes for a specific analyzer warning.
    """

    warning_id: str = ""  # internal BranchPy warning ID
    warning_message: str = ""  # human-readable message
    code: str = ""  # affected code snippet
    code_path: Optional[str] = None  # path to the file containing the code
    message: Optional[str] = None  # optional message override
    language: Optional[str] = None
    rule_name: Optional[str] = None  # e.g. "unused-variable", "dead-code"
    analyzer: Optional[str] = (
        None  # source of the warning ("flow_delta", "stats2", etc.)
    )


@dataclass
class PatchRequest(AIRequestBase):
    """
    Request to generate code patch from warning or issue.

    Used for AI Patch feature (AI-CLI-1).
    """

    code: str = ""  # Full code or context around issue
    warning_id: Optional[str] = None  # Warning ID to fix (e.g., "W001")
    target_line: Optional[int] = None  # Line number with issue
    context_lines: int = 20  # Lines of context around target
    language: Optional[str] = None  # "python", "renpy", etc.
    issue_description: Optional[str] = None  # Human description of problem


@dataclass
class PatchResult:
    """
    Result of AI patch generation.

    Contains both the patch and metadata for governance/display.
    """

    # Core patch data
    patch_content: str  # Unified diff format
    patched_content: str  # Full patched file content
    explanation: str  # AI explanation of changes

    # Provider metadata
    provider: str  # Provider ID used
    model: str  # Model name used

    # Usage metrics
    tokens_prompt: int = 0  # Tokens in prompt
    tokens_completion: int = 0  # Tokens in completion
    tokens_total: int = 0  # Total tokens
    cost_usd: float = 0.0  # Estimated cost in USD
    duration_ms: float = 0.0  # Generation time

    # Status
    success: bool = True  # Whether generation succeeded
    error: Optional[str] = None  # Error message if failed

    def to_dict(self) -> Dict[str, Any]:
        """JSON-serializable view for logging and CLI output."""
        return {
            "patch_content": self.patch_content,
            "patched_content": self.patched_content,
            "explanation": self.explanation,
            "provider": self.provider,
            "model": self.model,
            "tokens_prompt": self.tokens_prompt,
            "tokens_completion": self.tokens_completion,
            "tokens_total": self.tokens_total,
            "cost_usd": self.cost_usd,
            "duration_ms": self.duration_ms,
            "success": self.success,
            "error": self.error,
        }


@dataclass
class AIResponse:
    """
    Standardized AI response object.

    This insulates the rest of BranchPy from provider-specific response shapes.
    """

    request_id: str
    provider_id: str
    capability: ProviderCapability

    # Main content returned to the user (markdown-safe string)
    content: str

    # Optional: additional structured info
    suggestions: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    # Token usage and performance metrics (optional, but great for governance)
    token_usage: Dict[str, int] = field(
        default_factory=dict
    )  # {"prompt": 123, "completion": 456, "total": 579}
    latency_ms: Optional[int] = None

    # Raw provider payload for debugging / advanced logging (optional)
    raw: Optional[Mapping[str, Any]] = None

    # Status flags
    is_error: bool = False
    is_fallback: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """JSON-serializable view suitable for logging and for the VS Code panel."""
        return asdict(self)
