"""AI-powered code review using AST context.

Provides intelligent code review by analyzing Python AST structure
and using AI to detect bugs, style issues, and complexity problems.
"""

import asyncio
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..models import AIRequest, AIResponse
from ..provider_manager import get_provider_manager
from .ast_context import AIContext, ASTContextBuilder


@dataclass
class CodeReview:
    """AI code review result."""

    severity: str
    """Severity level: 'info', 'warning', 'error'."""

    category: str
    """Category: 'bug', 'style', 'complexity', 'security', 'performance'."""

    message: str
    """Short description of the issue."""

    suggestion: Optional[str] = None
    """Suggested fix or improvement."""

    line_start: int = 0
    """Starting line number."""

    line_end: int = 0
    """Ending line number."""

    confidence: float = 0.0
    """Confidence score (0.0 - 1.0)."""

    rationale: str = ""
    """AI explanation of why this is an issue."""

    code_snippet: str = ""
    """Code snippet showing the issue."""


@dataclass
class ReviewCache:
    """Cache for code review results."""

    _cache: Dict[str, List[CodeReview]] = field(default_factory=dict)

    def get(self, cache_key: str) -> Optional[List[CodeReview]]:
        """Get cached review result."""
        return self._cache.get(cache_key)

    def set(self, cache_key: str, reviews: List[CodeReview]) -> None:
        """Cache review result."""
        self._cache[cache_key] = reviews

    def clear(self) -> None:
        """Clear all cache."""
        self._cache.clear()

    @staticmethod
    def make_key(code: str, options: Dict[str, Any]) -> str:
        """Generate cache key from code and options."""
        data = f"{code}:{json.dumps(options, sort_keys=True)}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]


CODE_REVIEW_PROMPT = """You are a Python code review expert. Analyze the following code for issues:

**Code to review:**
```python
{code}
```

**Context:**
- File: {file_path}
- Function: {function_name}
- Lines: {line_start}-{line_end}
- Complexity: {complexity}

**Imports:**
{imports}

**Called functions:**
{dependencies}

**Review criteria:**
1. **Bugs**: Logical errors, edge cases, exception handling, potential crashes
2. **Style**: PEP 8 compliance, naming conventions, readability
3. **Complexity**: Functions that are too long or complex (>10 cyclomatic complexity)
4. **Security**: Input validation, sensitive data handling, injection vulnerabilities
5. **Performance**: Inefficient algorithms, unnecessary computations

**Instructions:**
- Provide specific, actionable feedback
- Focus on correctness first, then style
- Rate confidence (0.0-1.0) for each issue
- Explain rationale clearly
- Suggest concrete fixes when possible
- Ignore minor style issues if code is otherwise good

**Output JSON format:**
```json
{{
  "issues": [
    {{
      "severity": "warning",
      "category": "complexity",
      "message": "Function has high cyclomatic complexity",
      "suggestion": "Consider breaking into smaller functions",
      "line_start": 42,
      "line_end": 67,
      "confidence": 0.85,
      "rationale": "Function has 8 nested conditionals making it hard to test and maintain",
      "code_snippet": "if condition1:\\n    if condition2:..."
    }}
  ]
}}
```

Return ONLY the JSON, no other text.
"""


class AICodeReviewer:
    """AI-powered code review using AST context."""

    def __init__(self, provider: str = "local_llama"):
        """Initialize code reviewer.

        Args:
            provider: AI provider name (default: local_llama for privacy)
        """
        self.provider_manager = get_provider_manager()
        self.provider = provider
        self.cache = ReviewCache()
        self.context_builder = ASTContextBuilder()

    async def review_function(
        self,
        source_code: str,
        function_name: str,
        file_path: str = "unknown.py",
        use_cache: bool = True,
    ) -> List[CodeReview]:
        """Review a single function.

        Args:
            source_code: Full Python source code
            function_name: Name of function to review
            file_path: Path to file (for context)
            use_cache: Whether to use cached results

        Returns:
            List of CodeReview objects
        """
        # Build AST context
        context = self.context_builder.build_function_context(
            source_code, function_name, max_tokens=8000
        )

        if "error" in context.metadata:
            return [
                CodeReview(
                    severity="error",
                    category="syntax",
                    message=context.metadata["error"],
                    line_start=context.metadata.get("line", 0),
                    confidence=1.0,
                    rationale="Syntax error prevents analysis",
                )
            ]

        # Check cache
        if use_cache:
            cache_key = ReviewCache.make_key(
                context.primary_code, {"provider": self.provider, "type": "function"}
            )
            cached = self.cache.get(cache_key)
            if cached:
                return cached

        # Build prompt
        prompt = self._build_review_prompt(context, file_path)

        # Call AI provider
        try:
            response = await self._call_ai_provider(prompt)
            reviews = self._parse_ai_response(response, context)
        except Exception as e:
            return [
                CodeReview(
                    severity="error",
                    category="review",
                    message=f"AI review failed: {str(e)}",
                    confidence=1.0,
                    rationale="Unable to complete AI analysis",
                )
            ]

        # Cache result
        if use_cache:
            self.cache.set(cache_key, reviews)

        return reviews

    async def review_file(
        self, file_path: str, max_functions: int = 10
    ) -> Dict[str, List[CodeReview]]:
        """Review all functions in a file.

        Args:
            file_path: Path to Python file
            max_functions: Maximum number of functions to review

        Returns:
            Dict mapping function names to review results
        """
        path = Path(file_path)
        if not path.exists():
            return {}

        source_code = path.read_text(encoding="utf-8")

        # Build file context to get function list
        file_context = self.context_builder.build_file_context(file_path)

        if "error" in file_context.metadata:
            return {
                "_file_error": [
                    CodeReview(
                        severity="error",
                        category="syntax",
                        message=file_context.metadata["error"],
                        confidence=1.0,
                    )
                ]
            }

        functions = file_context.metadata.get("functions", [])[:max_functions]

        # Review each function
        results = {}
        for func_name in functions:
            reviews = await self.review_function(source_code, func_name, str(path))
            if reviews:  # Only include if issues found
                results[func_name] = reviews

        return results

    async def batch_review(
        self, file_paths: List[str], max_functions_per_file: int = 5
    ) -> Dict[str, Dict[str, List[CodeReview]]]:
        """Batch review multiple files.

        Args:
            file_paths: List of Python file paths
            max_functions_per_file: Max functions to review per file

        Returns:
            Dict mapping file paths to function review results
        """
        tasks = [self.review_file(path, max_functions_per_file) for path in file_paths]

        results_list = await asyncio.gather(*tasks, return_exceptions=True)

        # Build result dict
        results = {}
        for path, file_results in zip(file_paths, results_list):
            if isinstance(file_results, Exception):
                results[path] = {
                    "_error": [
                        CodeReview(
                            severity="error",
                            category="review",
                            message=str(file_results),
                            confidence=1.0,
                        )
                    ]
                }
            else:
                results[path] = file_results

        return results

    def _build_review_prompt(self, context: AIContext, file_path: str) -> str:
        """Build prompt for AI provider."""
        imports_str = "\n".join(context.imports) if context.imports else "None"
        deps_str = (
            ", ".join(context.dependencies[:10]) if context.dependencies else "None"
        )

        return CODE_REVIEW_PROMPT.format(
            code=context.primary_code,
            file_path=file_path,
            function_name=context.metadata.get("function_name", "unknown"),
            line_start=context.metadata.get("line_start", 0),
            line_end=context.metadata.get("line_end", 0),
            complexity=context.metadata.get("complexity", 0),
            imports=imports_str,
            dependencies=deps_str,
        )

    async def _call_ai_provider(self, prompt: str) -> str:
        """Call AI provider with prompt."""
        request = AIRequest(
            prompt=prompt,
            max_tokens=2000,
            temperature=0.3,  # Lower temperature for consistent reviews
            system_prompt="You are a Python code review expert. Provide thorough, actionable feedback.",
        )

        response: AIResponse = await self.provider_manager.generate(
            self.provider, request
        )

        return response.content

    def _parse_ai_response(self, response: str, context: AIContext) -> List[CodeReview]:
        """Parse AI response into CodeReview objects."""
        try:
            # Extract JSON from response (may have markdown code blocks)
            json_str = response
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]

            data = json.loads(json_str.strip())
            issues = data.get("issues", [])

            reviews = []
            for issue in issues:
                review = CodeReview(
                    severity=issue.get("severity", "info"),
                    category=issue.get("category", "general"),
                    message=issue.get("message", ""),
                    suggestion=issue.get("suggestion"),
                    line_start=issue.get("line_start", 0),
                    line_end=issue.get("line_end", 0),
                    confidence=float(issue.get("confidence", 0.5)),
                    rationale=issue.get("rationale", ""),
                    code_snippet=issue.get("code_snippet", ""),
                )
                reviews.append(review)

            return reviews

        except (json.JSONDecodeError, KeyError, ValueError) as e:
            # Fallback: create generic review from text response
            return [
                CodeReview(
                    severity="info",
                    category="general",
                    message="AI review completed (parse error)",
                    suggestion=response[:200],
                    confidence=0.3,
                    rationale=f"Unable to parse structured output: {str(e)}",
                )
            ]
