"""
AI Refactor Suggester for BranchPy

Suggests code refactorings using AI analysis of Python AST,
helping developers improve code quality, readability, and maintainability.

Author: BranchPy Team
Date: 2025-11-26
Version: v1.0.0-rc
"""

import ast
import hashlib
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .ast_context import ASTContextBuilder

logger = logging.getLogger(__name__)


@dataclass
class RefactoringSuggestion:
    """
    A suggested code refactoring.

    Attributes:
        title: Short title describing the refactoring
        description: Detailed explanation of the suggestion
        rationale: Why this refactoring would improve the code
        priority: Priority level (critical/high/medium/low)
        category: Refactoring category (extract_method, rename, simplify, etc.)
        location: File location (line numbers)
        original_code: Code snippet before refactoring
        refactored_code: Suggested code after refactoring
        confidence: AI confidence in suggestion (0.0-1.0)
        estimated_effort: Estimated effort (trivial/easy/medium/hard)
        benefits: List of benefits from applying this refactoring
    """

    title: str
    description: str
    rationale: str
    priority: str
    category: str
    location: Dict[str, int]  # {line_start, line_end}
    original_code: str
    refactored_code: str
    confidence: float
    estimated_effort: str
    benefits: List[str]


# Refactoring suggestion prompt template
REFACTOR_SUGGESTION_PROMPT = """You are a Python code refactoring expert helping game developers improve their code.

Code Context:
```python
{code_context}
```

Function/Class: {target_name}
Type: {target_type}
Complexity: {complexity}
Lines of Code: {loc}

Analyze this code and suggest refactorings to improve:
1. **Readability** - Make code easier to understand
2. **Maintainability** - Reduce future maintenance burden
3. **Performance** - Improve execution efficiency
4. **Best Practices** - Follow Python conventions (PEP 8, etc.)

Return a JSON array of refactoring suggestions:
[
  {{
    "title": "Short descriptive title",
    "description": "Detailed explanation of what to change",
    "rationale": "Why this improves the code",
    "priority": "critical|high|medium|low",
    "category": "extract_method|rename|simplify|decompose|eliminate_duplication|improve_names|add_docs|optimize",
    "location": {{"line_start": 10, "line_end": 25}},
    "original_code": "Code snippet before refactoring",
    "refactored_code": "Suggested code after refactoring",
    "confidence": 0.95,
    "estimated_effort": "trivial|easy|medium|hard",
    "benefits": ["Benefit 1", "Benefit 2"]
  }}
]

Focus on actionable suggestions that provide clear value.
For game development code, consider:
- Function names should reflect game concepts
- Complex conditionals can be extracted
- Long functions can be decomposed
- Magic numbers should be named constants
"""


class RefactoringCache:
    """Cache for refactoring suggestions to avoid redundant AI calls."""

    def __init__(self, max_size: int = 128):
        self._cache: Dict[str, List[RefactoringSuggestion]] = {}
        self._max_size = max_size
        self._hits = 0
        self._misses = 0

    def _make_key(self, code: str, target_name: str) -> str:
        """Generate cache key from code signature."""
        code_hash = hashlib.sha256(code.encode()).hexdigest()[:16]
        key_string = f"{target_name}:{code_hash}"
        return hashlib.sha256(key_string.encode()).hexdigest()[:32]

    def get(self, code: str, target_name: str) -> Optional[List[RefactoringSuggestion]]:
        """Get cached suggestions if available."""
        key = self._make_key(code, target_name)
        if key in self._cache:
            self._hits += 1
            logger.debug(f"Refactoring cache hit: {key}")
            return self._cache[key]

        self._misses += 1
        logger.debug(f"Refactoring cache miss: {key}")
        return None

    def set(
        self, code: str, target_name: str, suggestions: List[RefactoringSuggestion]
    ) -> None:
        """Cache refactoring suggestions."""
        key = self._make_key(code, target_name)

        # Simple FIFO eviction
        if len(self._cache) >= self._max_size:
            first_key = next(iter(self._cache))
            del self._cache[first_key]
            logger.debug(f"Cache evicted: {first_key}")

        self._cache[key] = suggestions
        logger.debug(f"Cached suggestions: {key}")

    def clear(self) -> None:
        """Clear all cached suggestions."""
        self._cache.clear()
        self._hits = 0
        self._misses = 0
        logger.info("Refactoring cache cleared")

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0.0

        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "size": len(self._cache),
            "max_size": self._max_size,
        }


class AIRefactorSuggester:
    """
    Suggests code refactorings using AI analysis.

    Analyzes Python code using AST and provides actionable
    refactoring suggestions to improve quality.
    """

    def __init__(self, provider_manager=None, max_tokens: int = 8000):
        """
        Initialize refactor suggester.

        Args:
            provider_manager: AI provider manager instance (optional)
            max_tokens: Maximum tokens for context window
        """
        self.provider_manager = provider_manager
        self.max_tokens = max_tokens
        self.context_builder = ASTContextBuilder(max_tokens=max_tokens)
        self.cache = RefactoringCache()

        # Load provider manager lazily if not provided
        if self.provider_manager is None:
            try:
                from branchpy.ai.provider_manager import get_provider_manager

                self.provider_manager = get_provider_manager()
            except ImportError:
                logger.warning("AI provider manager not available")

    async def suggest_refactorings(
        self,
        file_path: str,
        function_name: Optional[str] = None,
        use_cache: bool = True,
    ) -> List[RefactoringSuggestion]:
        """
        Suggest refactorings for a file or specific function.

        Args:
            file_path: Path to Python file
            function_name: Optional specific function to analyze
            use_cache: Whether to use cached suggestions

        Returns:
            List of RefactoringSuggestion objects

        Raises:
            ValueError: If file cannot be parsed
            RuntimeError: If AI provider fails
        """
        # Read file
        try:
            source_code = Path(file_path).read_text(encoding="utf-8")
        except Exception as e:
            logger.error(f"Failed to read {file_path}: {e}")
            raise ValueError(f"Cannot read file: {e}")

        # If specific function requested, analyze just that
        if function_name:
            return await self._suggest_for_function(
                source_code, function_name, file_path, use_cache
            )

        # Otherwise, analyze entire file
        return await self._suggest_for_file(source_code, file_path, use_cache)

    async def _suggest_for_function(
        self, source_code: str, function_name: str, file_path: str, use_cache: bool
    ) -> List[RefactoringSuggestion]:
        """Suggest refactorings for a specific function."""
        # Check cache
        if use_cache:
            cached = self.cache.get(source_code, function_name)
            if cached:
                return cached

        # Build context
        try:
            context = self.context_builder.build_function_context(
                source_code, function_name
            )
        except Exception as e:
            logger.error(f"Failed to build context for {function_name}: {e}")
            return []

        # Prepare prompt
        complexity = context.metadata.get("complexity", 0)
        loc = len(context.primary_code.splitlines())

        prompt = self._format_prompt(
            context.primary_code, function_name, "function", complexity, loc
        )

        # Call AI provider
        try:
            response = await self._call_ai_provider(prompt)
            suggestions = self._parse_response(response, file_path)

            # Cache results
            if use_cache:
                self.cache.set(source_code, function_name, suggestions)

            return suggestions

        except Exception as e:
            logger.error(f"AI provider call failed: {e}")
            return []

    async def _suggest_for_file(
        self, source_code: str, file_path: str, use_cache: bool
    ) -> List[RefactoringSuggestion]:
        """Suggest refactorings for entire file."""
        # Parse AST to find all functions
        try:
            tree = ast.parse(source_code)
        except SyntaxError as e:
            logger.error(f"Syntax error in {file_path}: {e}")
            return []

        # Find all function definitions
        functions = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                functions.append(node.name)

        # Get suggestions for each function
        all_suggestions = []
        for func_name in functions:
            suggestions = await self._suggest_for_function(
                source_code, func_name, file_path, use_cache
            )
            all_suggestions.extend(suggestions)

        # Sort by priority
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        all_suggestions.sort(key=lambda s: priority_order.get(s.priority, 99))

        return all_suggestions

    async def suggest_quick_wins(self, file_path: str) -> List[RefactoringSuggestion]:
        """
        Get only quick win refactorings (trivial/easy effort).

        Args:
            file_path: Path to Python file

        Returns:
            List of easy refactoring suggestions
        """
        all_suggestions = await self.suggest_refactorings(file_path)

        return [s for s in all_suggestions if s.estimated_effort in ("trivial", "easy")]

    def _format_prompt(
        self, code: str, target_name: str, target_type: str, complexity: int, loc: int
    ) -> str:
        """Format the refactoring prompt."""
        return REFACTOR_SUGGESTION_PROMPT.format(
            code_context=code,
            target_name=target_name,
            target_type=target_type,
            complexity=complexity,
            loc=loc,
        )

    async def _call_ai_provider(self, prompt: str) -> str:
        """Call AI provider with prompt."""
        if not self.provider_manager:
            raise RuntimeError("AI provider manager not available")

        response = await self.provider_manager.complete_async(
            prompt=prompt,
            max_tokens=self.max_tokens,
            temperature=0.4,  # Slightly higher for creative suggestions
        )

        return response

    def _parse_response(
        self, response: str, file_path: str
    ) -> List[RefactoringSuggestion]:
        """Parse AI response into RefactoringSuggestion objects."""
        import json
        import re

        # Try to extract JSON array from response
        json_match = re.search(r"```json\s*(\[.*?\])\s*```", response, re.DOTALL)
        if json_match:
            json_str = json_match.group(1)
        else:
            # Try to find raw JSON array
            json_match = re.search(r"\[.*\]", response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
            else:
                logger.warning("No JSON found in response")
                return []

        try:
            data = json.loads(json_str)

            suggestions = []
            for item in data:
                suggestion = RefactoringSuggestion(
                    title=item.get("title", "Untitled refactoring"),
                    description=item.get("description", ""),
                    rationale=item.get("rationale", ""),
                    priority=item.get("priority", "medium"),
                    category=item.get("category", "unknown"),
                    location=item.get("location", {"line_start": 0, "line_end": 0}),
                    original_code=item.get("original_code", ""),
                    refactored_code=item.get("refactored_code", ""),
                    confidence=float(item.get("confidence", 0.5)),
                    estimated_effort=item.get("estimated_effort", "medium"),
                    benefits=item.get("benefits", []),
                )
                suggestions.append(suggestion)

            return suggestions

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return []

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return self.cache.get_stats()


# Global singleton instance
_suggester_instance: Optional[AIRefactorSuggester] = None


def get_refactor_suggester(provider_manager=None) -> AIRefactorSuggester:
    """
    Get the global refactor suggester instance.

    Args:
        provider_manager: Optional AI provider manager

    Returns:
        AIRefactorSuggester singleton instance
    """
    global _suggester_instance

    if _suggester_instance is None:
        _suggester_instance = AIRefactorSuggester(provider_manager)

    return _suggester_instance
