"""
AI Warning Explainer for BranchPy Static Analysis Engine

This module provides natural language explanations for BranchPy warnings,
helping game developers understand and fix issues without deep Python expertise.

Author: BranchPy Team
Date: 2025-11-26
Version: v1.0.0-rc
"""

import asyncio
import hashlib
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .ast_context import ASTContextBuilder

logger = logging.getLogger(__name__)


@dataclass
class WarningExplanation:
    """
    Natural language explanation of a BranchPy warning.

    Attributes:
        explanation: Plain English description of the warning
        cause: What caused the warning to be triggered
        impact: Why this matters and potential consequences
        suggested_fix: Optional code fix with explanation
        learn_more: Links to documentation or resources
        confidence: AI confidence in explanation (0.0-1.0)
        code_snippet: Relevant code that triggered warning
        fixed_code: Optional corrected code example
    """

    explanation: str
    cause: str
    impact: str
    suggested_fix: Optional[str]
    learn_more: List[str]
    confidence: float
    code_snippet: str
    fixed_code: Optional[str] = None


# Warning explanation prompt template
EXPLAIN_WARNING_PROMPT = """You are a BranchPy expert helping game developers understand static analysis warnings.

Warning Details:
- Type: {warning_type}
- Message: {warning_message}
- Severity: {severity}
- Line: {line_number}
- File: {file_path}

Code Context:
```python
{code_context}
```

Additional Context:
{additional_context}

Please provide a clear explanation suitable for a Ren'Py game developer who may not be a Python expert.

Return a JSON response with this structure:
{{
    "explanation": "Plain English explanation of what this warning means",
    "cause": "What in the code triggered this warning",
    "impact": "Why this matters - potential bugs or issues if not fixed",
    "suggested_fix": "How to fix it, with code example if applicable",
    "learn_more": ["URL1", "URL2"],
    "confidence": 0.95,
    "fixed_code": "Optional corrected code example"
}}

Focus on:
1. Clear, jargon-free language
2. Specific to Ren'Py game development context when applicable
3. Actionable advice with examples
4. Severity-appropriate tone (errors are serious, info is helpful)
"""


class ExplanationCache:
    """
    Cache for warning explanations to avoid redundant AI calls.

    Uses warning signature (type + message + code hash) as cache key.
    """

    def __init__(self, max_size: int = 256):
        self._cache: Dict[str, WarningExplanation] = {}
        self._max_size = max_size
        self._hits = 0
        self._misses = 0

    def _make_key(self, warning: Dict[str, Any], code: str) -> str:
        """Generate cache key from warning signature."""
        warning_type = warning.get("type", "unknown")
        message = warning.get("message", "")
        code_hash = hashlib.sha256(code.encode()).hexdigest()[:16]

        key_string = f"{warning_type}:{message}:{code_hash}"
        return hashlib.sha256(key_string.encode()).hexdigest()[:32]

    def get(self, warning: Dict[str, Any], code: str) -> Optional[WarningExplanation]:
        """Get cached explanation if available."""
        key = self._make_key(warning, code)
        if key in self._cache:
            self._hits += 1
            logger.debug(f"Explanation cache hit: {key}")
            return self._cache[key]

        self._misses += 1
        logger.debug(f"Explanation cache miss: {key}")
        return None

    def set(
        self, warning: Dict[str, Any], code: str, explanation: WarningExplanation
    ) -> None:
        """Cache an explanation."""
        key = self._make_key(warning, code)

        # Simple FIFO eviction if cache is full
        if len(self._cache) >= self._max_size:
            first_key = next(iter(self._cache))
            del self._cache[first_key]
            logger.debug(f"Cache evicted: {first_key}")

        self._cache[key] = explanation
        logger.debug(f"Cached explanation: {key}")

    def clear(self) -> None:
        """Clear all cached explanations."""
        self._cache.clear()
        self._hits = 0
        self._misses = 0
        logger.info("Explanation cache cleared")

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0.0

        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "size": len(self._cache),
            "max_size": self._max_size,
        }


class AIWarningExplainer:
    """
    Explains BranchPy static analysis warnings using AI.

    Converts technical warning messages into plain English explanations
    with actionable advice for fixing issues.
    """

    def __init__(self, provider_manager=None, max_tokens: int = 4000):
        """
        Initialize the warning explainer.

        Args:
            provider_manager: AI provider manager instance (optional)
            max_tokens: Maximum tokens for context window
        """
        self.provider_manager = provider_manager
        self.max_tokens = max_tokens
        self.context_builder = ASTContextBuilder()
        self.cache = ExplanationCache()

        # Load provider manager lazily if not provided
        if self.provider_manager is None:
            try:
                from branchpy.ai.provider_manager import (  # type: ignore
                    get_provider_manager,
                )

                self.provider_manager = get_provider_manager()
            except (ImportError, AttributeError):
                logger.warning("AI provider manager not available")

    async def explain_warning(
        self, warning: Dict[str, Any], file_path: str, use_cache: bool = True
    ) -> WarningExplanation:
        """
        Explain a warning using AI.

        Args:
            warning: Warning dictionary with type, message, line, etc.
            file_path: Path to file containing the warning
            use_cache: Whether to use cached explanations

        Returns:
            WarningExplanation with plain English explanation

        Raises:
            ValueError: If warning format is invalid
            RuntimeError: If AI provider fails
        """
        # Validate warning structure
        if "type" not in warning or "message" not in warning:
            raise ValueError("Warning must contain 'type' and 'message' fields")

        # Extract code context
        try:
            code_snippet = self._extract_code_snippet(file_path, warning)
        except Exception as e:
            logger.error(f"Failed to extract code snippet: {e}")
            code_snippet = "# Code snippet unavailable"

        # Check cache first
        if use_cache:
            cached = self.cache.get(warning, code_snippet)
            if cached:
                return cached

        # Build full context
        context = self._build_warning_context(warning, file_path, code_snippet)

        # Format prompt
        prompt = self._format_prompt(warning, context, code_snippet)

        # Call AI provider
        try:
            response = await self._call_ai_provider(prompt)
            explanation = self._parse_response(response, warning, code_snippet)

            # Cache the result
            if use_cache:
                self.cache.set(warning, code_snippet, explanation)

            return explanation

        except Exception as e:
            logger.error(f"AI provider call failed: {e}")
            # Return fallback explanation
            return self._create_fallback_explanation(warning, code_snippet)

    async def suggest_fix(
        self, warning: Dict[str, Any], file_path: str
    ) -> Optional[str]:
        """
        Suggest a fix for a warning.

        Args:
            warning: Warning dictionary
            file_path: Path to file containing the warning

        Returns:
            Suggested fix code or None if no fix available
        """
        explanation = await self.explain_warning(warning, file_path)
        return explanation.fixed_code

    async def batch_explain(
        self, warnings: List[Dict[str, Any]], file_path: str
    ) -> List[WarningExplanation]:
        """
        Explain multiple warnings from the same file.

        Args:
            warnings: List of warning dictionaries
            file_path: Path to file containing warnings

        Returns:
            List of WarningExplanation objects
        """
        tasks = [self.explain_warning(warning, file_path) for warning in warnings]

        results = await asyncio.gather(*tasks, return_exceptions=True)
        # Filter out exceptions and return only successful explanations
        return [r for r in results if isinstance(r, WarningExplanation)]

    def _extract_code_snippet(
        self, file_path: str, warning: Dict[str, Any], context_lines: int = 5
    ) -> str:
        """Extract code snippet around warning location."""
        line_number = warning.get("line", 1)

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            start = max(0, line_number - context_lines - 1)
            end = min(len(lines), line_number + context_lines)

            snippet_lines = []
            for i in range(start, end):
                marker = ">>> " if i == line_number - 1 else "    "
                snippet_lines.append(f"{marker}{i+1:4d}: {lines[i].rstrip()}")

            return "\n".join(snippet_lines)

        except Exception as e:
            logger.error(f"Failed to read file {file_path}: {e}")
            return f"# Error reading file: {e}"

    def _build_warning_context(
        self, warning: Dict[str, Any], file_path: str, code_snippet: str
    ) -> str:
        """Build additional context about the warning."""
        context_parts = []

        # Add function/class context if available
        if "function" in warning:
            context_parts.append(f"Function: {warning['function']}")

        if "class" in warning:
            context_parts.append(f"Class: {warning['class']}")

        # Add related warnings if available
        if "related" in warning:
            context_parts.append(f"Related warnings: {len(warning['related'])}")

        return "\n".join(context_parts) if context_parts else "No additional context"

    def _format_prompt(
        self, warning: Dict[str, Any], context: str, code_snippet: str
    ) -> str:
        """Format the explanation prompt."""
        return EXPLAIN_WARNING_PROMPT.format(
            warning_type=warning.get("type", "unknown"),
            warning_message=warning.get("message", ""),
            severity=warning.get("severity", "warning"),
            line_number=warning.get("line", "unknown"),
            file_path=warning.get("file", "unknown"),
            code_context=code_snippet,
            additional_context=context,
        )

    async def _call_ai_provider(self, prompt: str) -> str:
        """Call AI provider with prompt."""
        if not self.provider_manager:
            raise RuntimeError("AI provider manager not available")

        # Call provider (implementation depends on provider manager API)
        response = await self.provider_manager.complete_async(
            prompt=prompt,
            max_tokens=self.max_tokens,
            temperature=0.3,  # Lower temperature for more consistent explanations
        )

        return response

    def _parse_response(
        self, response: str, warning: Dict[str, Any], code_snippet: str
    ) -> WarningExplanation:
        """Parse AI response into WarningExplanation."""
        import json
        import re

        # Try to extract JSON from response
        json_match = re.search(r"```json\s*(\{.*?\})\s*```", response, re.DOTALL)
        if json_match:
            json_str = json_match.group(1)
        else:
            # Try to find raw JSON
            json_match = re.search(r"\{.*\}", response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
            else:
                raise ValueError("No JSON found in response")

        try:
            data = json.loads(json_str)

            return WarningExplanation(
                explanation=data.get("explanation", "No explanation provided"),
                cause=data.get("cause", "Unknown cause"),
                impact=data.get("impact", "Unknown impact"),
                suggested_fix=data.get("suggested_fix"),
                learn_more=data.get("learn_more", []),
                confidence=float(data.get("confidence", 0.5)),
                code_snippet=code_snippet,
                fixed_code=data.get("fixed_code"),
            )

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return self._create_fallback_explanation(warning, code_snippet)

    def _create_fallback_explanation(
        self, warning: Dict[str, Any], code_snippet: str
    ) -> WarningExplanation:
        """Create a fallback explanation when AI fails."""
        warning_type = warning.get("type", "unknown")
        message = warning.get("message", "No message")

        return WarningExplanation(
            explanation=f"BranchPy detected a {warning_type} issue in your code.",
            cause=message,
            impact="This may cause issues in your game. Please review the code carefully.",
            suggested_fix="Review the highlighted code and consult the documentation.",
            learn_more=["https://branchpy.com/docs/warnings"],
            confidence=0.5,
            code_snippet=code_snippet,
            fixed_code=None,
        )


# Global singleton instance
_explainer_instance: Optional[AIWarningExplainer] = None


def get_warning_explainer(provider_manager=None) -> AIWarningExplainer:
    """
    Get the global warning explainer instance.

    Args:
        provider_manager: Optional AI provider manager

    Returns:
        AIWarningExplainer singleton instance
    """
    global _explainer_instance

    if _explainer_instance is None:
        _explainer_instance = AIWarningExplainer(provider_manager)

    return _explainer_instance
