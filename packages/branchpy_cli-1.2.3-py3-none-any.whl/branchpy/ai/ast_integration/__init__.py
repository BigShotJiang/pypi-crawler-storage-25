"""AI integration with Python AST analysis.

This module provides AI-powered code analysis using rich context
extracted from Python AST nodes.

Components:
- ast_context: Extract rich context from AST for AI operations
- code_review: AI-powered code review
- explain_warning: AI explanations of BranchPy warnings
- refactor: AI-powered refactoring suggestions
"""

from .ast_context import AIContext, ASTContextBuilder
from .code_review import AICodeReviewer, CodeReview
from .explain_warning import AIWarningExplainer, WarningExplanation
from .refactor import AIRefactorSuggester, RefactoringPatch, RefactorSuggestion

__all__ = [
    "ASTContextBuilder",
    "AIContext",
    "AICodeReviewer",
    "CodeReview",
    "AIWarningExplainer",
    "WarningExplanation",
    "AIRefactorSuggester",
    "RefactorSuggestion",
    "RefactoringPatch",
]
