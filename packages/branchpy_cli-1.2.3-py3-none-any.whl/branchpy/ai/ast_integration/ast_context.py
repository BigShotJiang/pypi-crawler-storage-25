"""AST Context Builder for AI operations.

Extracts rich context from Python AST nodes to provide AI models
with comprehensive information for code analysis, review, and refactoring.
"""

import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

# Approximate tokens per character (GPT-4 uses ~4 chars/token)
CHARS_PER_TOKEN = 4


@dataclass
class AIContext:
    """Rich context for AI operations."""

    primary_code: str
    """Main code to analyze."""

    surrounding_context: str = ""
    """Context around main code (before/after)."""

    imports: List[str] = field(default_factory=list)
    """Import statements in the file."""

    dependencies: List[str] = field(default_factory=list)
    """Referenced functions/classes."""

    type_hints: Dict[str, str] = field(default_factory=dict)
    """Variable types extracted from annotations."""

    docstrings: List[str] = field(default_factory=list)
    """Existing documentation."""

    metadata: Dict[str, Any] = field(default_factory=dict)
    """AST metadata (line numbers, complexity, etc.)."""

    token_count: int = 0
    """Approximate token count."""

    def __post_init__(self):
        """Calculate token count after initialization."""
        if self.token_count == 0:
            total_chars = (
                len(self.primary_code)
                + len(self.surrounding_context)
                + sum(len(imp) for imp in self.imports)
                + sum(len(dep) for dep in self.dependencies)
            )
            self.token_count = total_chars // CHARS_PER_TOKEN


class ASTContextBuilder:
    """Build rich context from Python AST for AI operations."""

    def __init__(self):
        self._ast_cache: Dict[str, ast.Module] = {}

    def build_function_context(
        self, source_code: str, function_name: str, max_tokens: int = 8000
    ) -> AIContext:
        """Build context for a specific function.

        Args:
            source_code: Full Python source code
            function_name: Name of function to analyze
            max_tokens: Maximum context tokens

        Returns:
            AIContext with function details
        """
        try:
            tree = ast.parse(source_code)
        except SyntaxError as e:
            return AIContext(
                primary_code=source_code[:500],
                metadata={"error": str(e), "line": e.lineno},
            )

        # Find target function
        target_func = None
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == function_name:
                target_func = node
                break

        if not target_func:
            return AIContext(
                primary_code="",
                metadata={"error": f"Function '{function_name}' not found"},
            )

        # Extract function code
        lines = source_code.splitlines()
        func_start = target_func.lineno - 1
        func_end = target_func.end_lineno
        func_code = "\n".join(lines[func_start:func_end])

        # Extract context
        context_lines = 5
        before_start = max(0, func_start - context_lines)
        after_end = min(len(lines), func_end + context_lines)
        surrounding = "\n".join(
            lines[before_start:func_start] + lines[func_end:after_end]
        )

        # Extract imports
        imports = self._extract_imports(tree)

        # Extract dependencies (called functions)
        dependencies = self._extract_function_calls(target_func)

        # Extract type hints
        type_hints = self._extract_type_hints(target_func)

        # Extract docstring
        docstrings = []
        if ast.get_docstring(target_func):
            docstrings.append(ast.get_docstring(target_func))

        # Calculate complexity
        complexity = self._calculate_complexity(target_func)

        # Build metadata
        metadata = {
            "function_name": function_name,
            "line_start": target_func.lineno,
            "line_end": target_func.end_lineno,
            "num_lines": target_func.end_lineno - target_func.lineno + 1,
            "num_args": len(target_func.args.args),
            "complexity": complexity,
            "has_decorators": len(target_func.decorator_list) > 0,
            "is_async": isinstance(target_func, ast.AsyncFunctionDef),
        }

        context = AIContext(
            primary_code=func_code,
            surrounding_context=surrounding[:500],  # Limit context
            imports=imports[:10],  # Top 10 imports
            dependencies=dependencies[:20],  # Top 20 dependencies
            type_hints=type_hints,
            docstrings=docstrings,
            metadata=metadata,
        )

        # Truncate if exceeds max_tokens
        if context.token_count > max_tokens:
            context = self._truncate_context(context, max_tokens)

        return context

    def build_class_context(
        self, source_code: str, class_name: str, max_tokens: int = 8000
    ) -> AIContext:
        """Build context for a specific class.

        Args:
            source_code: Full Python source code
            class_name: Name of class to analyze
            max_tokens: Maximum context tokens

        Returns:
            AIContext with class details
        """
        try:
            tree = ast.parse(source_code)
        except SyntaxError as e:
            return AIContext(
                primary_code=source_code[:500],
                metadata={"error": str(e), "line": e.lineno},
            )

        # Find target class
        target_class = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                target_class = node
                break

        if not target_class:
            return AIContext(
                primary_code="", metadata={"error": f"Class '{class_name}' not found"}
            )

        # Extract class code
        lines = source_code.splitlines()
        class_start = target_class.lineno - 1
        class_end = target_class.end_lineno
        class_code = "\n".join(lines[class_start:class_end])

        # Extract methods
        methods = [
            node.name
            for node in ast.walk(target_class)
            if isinstance(node, ast.FunctionDef)
        ]

        # Extract base classes
        bases = [self._get_node_name(base) for base in target_class.bases]

        # Extract imports
        imports = self._extract_imports(tree)

        # Extract docstring
        docstrings = []
        if ast.get_docstring(target_class):
            docstrings.append(ast.get_docstring(target_class))

        metadata = {
            "class_name": class_name,
            "line_start": target_class.lineno,
            "line_end": target_class.end_lineno,
            "num_lines": target_class.end_lineno - target_class.lineno + 1,
            "num_methods": len(methods),
            "methods": methods,
            "base_classes": bases,
            "has_decorators": len(target_class.decorator_list) > 0,
        }

        context = AIContext(
            primary_code=class_code,
            imports=imports[:10],
            docstrings=docstrings,
            metadata=metadata,
        )

        if context.token_count > max_tokens:
            context = self._truncate_context(context, max_tokens)

        return context

    def build_file_context(self, file_path: str, max_tokens: int = 16000) -> AIContext:
        """Build full file context.

        Args:
            file_path: Path to Python file
            max_tokens: Maximum context tokens

        Returns:
            AIContext with file-level details
        """
        path = Path(file_path)
        if not path.exists():
            return AIContext(
                primary_code="", metadata={"error": f"File not found: {file_path}"}
            )

        source_code = path.read_text(encoding="utf-8")

        try:
            tree = ast.parse(source_code)
        except SyntaxError as e:
            return AIContext(
                primary_code=source_code[:500],
                metadata={"error": str(e), "line": e.lineno},
            )

        # Extract all top-level definitions
        functions = []
        classes = []
        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                functions.append(node.name)
            elif isinstance(node, ast.ClassDef):
                classes.append(node.name)

        # Extract imports
        imports = self._extract_imports(tree)

        # Extract module docstring
        docstrings = []
        module_doc = ast.get_docstring(tree)
        if module_doc:
            docstrings.append(module_doc)

        # Calculate file statistics
        lines = source_code.splitlines()
        code_lines = [
            line for line in lines if line.strip() and not line.strip().startswith("#")
        ]

        metadata = {
            "file_path": str(path),
            "total_lines": len(lines),
            "code_lines": len(code_lines),
            "num_functions": len(functions),
            "num_classes": len(classes),
            "functions": functions,
            "classes": classes,
        }

        context = AIContext(
            primary_code=source_code,
            imports=imports,
            docstrings=docstrings,
            metadata=metadata,
        )

        if context.token_count > max_tokens:
            # For files, provide summary instead of full content
            summary = self._build_file_summary(tree, source_code)
            context.primary_code = summary
            context.token_count = len(summary) // CHARS_PER_TOKEN

        return context

    def _extract_imports(self, tree: ast.Module) -> List[str]:
        """Extract import statements from AST."""
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(f"import {alias.name}")
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    imports.append(f"from {module} import {alias.name}")
        return imports

    def _extract_function_calls(self, node: ast.AST) -> List[str]:
        """Extract function calls from AST node."""
        calls = []
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                func_name = self._get_node_name(child.func)
                if func_name:
                    calls.append(func_name)
        return list(set(calls))  # Deduplicate

    def _extract_type_hints(self, node: ast.FunctionDef) -> Dict[str, str]:
        """Extract type hints from function definition."""
        hints = {}

        # Argument types
        for arg in node.args.args:
            if arg.annotation:
                hints[arg.arg] = ast.unparse(arg.annotation)

        # Return type
        if node.returns:
            hints["return"] = ast.unparse(node.returns)

        return hints

    def _calculate_complexity(self, node: ast.AST) -> int:
        """Calculate cyclomatic complexity of AST node."""
        complexity = 1  # Base complexity

        for child in ast.walk(node):
            # Add 1 for each branching point
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1

        return complexity

    def _get_node_name(self, node: ast.AST) -> Optional[str]:
        """Get name from AST node."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            value = self._get_node_name(node.value)
            return f"{value}.{node.attr}" if value else node.attr
        elif isinstance(node, ast.Call):
            return self._get_node_name(node.func)
        return None

    def _truncate_context(self, context: AIContext, max_tokens: int) -> AIContext:
        """Truncate context to fit within token limit."""
        # Calculate current token usage
        primary_tokens = len(context.primary_code) // CHARS_PER_TOKEN

        if primary_tokens > max_tokens * 0.8:
            # Truncate primary code to 80% of max_tokens
            max_chars = int(max_tokens * 0.8 * CHARS_PER_TOKEN)
            context.primary_code = (
                context.primary_code[:max_chars] + "\n... (truncated)"
            )

        # Clear surrounding context to save tokens
        context.surrounding_context = ""

        # Limit lists
        context.imports = context.imports[:5]
        context.dependencies = context.dependencies[:10]

        # Recalculate token count
        context.token_count = (
            len(context.primary_code) // CHARS_PER_TOKEN
            + sum(len(imp) for imp in context.imports) // CHARS_PER_TOKEN
        )

        return context

    def _build_file_summary(self, tree: ast.Module, source_code: str) -> str:
        """Build a summary of file for token-limited context."""
        lines = []

        # Add module docstring
        doc = ast.get_docstring(tree)
        if doc:
            lines.append(f'"""{doc}"""')
            lines.append("")

        # Add imports (first 10)
        imports = self._extract_imports(tree)
        for imp in imports[:10]:
            lines.append(imp)

        if len(imports) > 10:
            lines.append(f"... ({len(imports) - 10} more imports)")

        lines.append("")

        # Add function/class signatures
        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                # Function signature with docstring
                sig = self._get_function_signature(node)
                lines.append(sig)
                doc = ast.get_docstring(node)
                if doc:
                    lines.append(
                        f'    """{doc[:100]}{"..." if len(doc) > 100 else ""}"""'
                    )
                lines.append("    ...")
                lines.append("")
            elif isinstance(node, ast.ClassDef):
                # Class signature with methods
                lines.append(f"class {node.name}:")
                doc = ast.get_docstring(node)
                if doc:
                    lines.append(
                        f'    """{doc[:100]}{"..." if len(doc) > 100 else ""}"""'
                    )

                # List methods
                for child in node.body:
                    if isinstance(child, ast.FunctionDef):
                        sig = self._get_function_signature(child, indent=4)
                        lines.append(sig)
                        lines.append("        ...")

                lines.append("")

        return "\n".join(lines)

    def _get_function_signature(self, node: ast.FunctionDef, indent: int = 0) -> str:
        """Get function signature as string."""
        indent_str = " " * indent

        # Build args
        args = []
        for arg in node.args.args:
            arg_str = arg.arg
            if arg.annotation:
                arg_str += f": {ast.unparse(arg.annotation)}"
            args.append(arg_str)

        args_str = ", ".join(args)

        # Return type
        returns_str = ""
        if node.returns:
            returns_str = f" -> {ast.unparse(node.returns)}"

        return f"{indent_str}def {node.name}({args_str}){returns_str}:"
