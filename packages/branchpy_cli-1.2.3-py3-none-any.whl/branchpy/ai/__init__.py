"""
branchpy.ai.__init__.py
BranchPy v1.0.0 — AI Integration Strategy

AI-as-a-Service module for BranchPy.
Supports multiple providers (OpenAI, Anthropic, Ollama, Venice.ai) with local API keys.

Governance:
- All AI operations emit governance events
- Privacy-preserving: no data sent to BranchPy servers
- User-controlled API keys

Local AI Support:
- Ollama provider for local Llama models (100% private)
- LM Studio support (OpenAI-compatible)
- Safe mode restricts to local-only providers

BQS Compliance:
- Input validation on all API calls
- Rate limiting and error handling
- Cross-platform compatibility
"""

from .ai_models import AIModel, AITask
from .ai_routing import AIRouter
from .config import AIConfig, ProviderConfig, load_ai_config
from .protocol import AIProvider, ChatRequest, ChatResponse, Message, TokenUsage
from .provider_manager import ProviderManager
from .providers.ollama_provider import OllamaProvider
from .providers.venice_provider import VeniceProvider

__all__ = [
    "ProviderManager",
    "AIModel",
    "AITask",
    "AIRouter",
    "AIProvider",
    "ChatRequest",
    "ChatResponse",
    "Message",
    "TokenUsage",
    "ProviderConfig",
    "AIConfig",
    "load_ai_config",
    "OllamaProvider",
    "VeniceProvider",
]

__version__ = "1.0.0"
