"""
AI Configuration Management

Loads provider configs from branchpy.toml or environment.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Literal, Optional

try:
    import tomllib  # Python 3.11+ stdlib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class ProviderConfig:
    """Configuration for a single AI provider"""

    type: Literal["openai", "openai_compatible", "custom_http"]

    # Common settings
    api_key_env: Optional[str] = None  # Environment variable name
    api_key: Optional[str] = None  # Direct key (not recommended)
    default_model: str = "gpt-3.5-turbo"
    base_url: Optional[str] = None  # For custom endpoints

    # Timeouts & limits
    timeout: int = 60  # seconds
    max_retries: int = 3
    max_tokens_default: Optional[int] = None

    # Safety
    is_local: bool = False  # True for Ollama, LM Studio, etc.
    safe_mode_allowed: bool = True  # Can be used in safe mode

    # Provider-specific extras
    extra: Dict[str, any] = field(default_factory=dict)

    def get_api_key(self) -> Optional[str]:
        """Get API key from env or direct config"""
        if self.api_key:
            return self.api_key
        if self.api_key_env:
            return os.getenv(self.api_key_env)
        return None


@dataclass
class AIConfig:
    """Complete AI configuration"""

    providers: Dict[str, ProviderConfig]
    default_provider: str = "openai"

    # Global safety settings
    safe_mode_default: bool = False
    redact_sensitive_data: bool = True
    max_context_tokens: int = 16000

    # Governance
    enable_governance: bool = True
    log_all_requests: bool = True


def load_ai_config(project_root: Optional[Path] = None) -> AIConfig:
    """
    Load AI configuration from branchpy.toml

    Search order:
    1. {project_root}/.branchpy/branchpy.toml
    2. {project_root}/branchpy.toml
    3. ~/.branchpy/branchpy.toml
    4. Default config (OpenAI only)

    Args:
        project_root: Project root directory (optional)

    Returns:
        AIConfig with provider settings
    """
    config_paths = []

    if project_root:
        config_paths.extend(
            [
                project_root / ".branchpy" / "branchpy.toml",
                project_root / "branchpy.toml",
            ]
        )

    # User config
    home = Path.home()
    config_paths.append(home / ".branchpy" / "branchpy.toml")

    # Try each path
    for path in config_paths:
        if path.exists():
            return _parse_ai_config(path)

    # Default config
    return _default_config()


def _parse_ai_config(path: Path) -> AIConfig:
    """Parse TOML config file"""
    with open(path, "rb") as f:
        data = tomllib.load(f)

    ai_section = data.get("ai", {})
    providers_data = ai_section.get("providers", {})

    # Parse providers
    providers = {}
    for name, provider_data in providers_data.items():
        providers[name] = ProviderConfig(
            type=provider_data.get("type", "openai"),
            api_key_env=provider_data.get("api_key_env"),
            api_key=provider_data.get("api_key"),
            default_model=provider_data.get("default_model", "gpt-3.5-turbo"),
            base_url=provider_data.get("base_url"),
            timeout=provider_data.get("timeout", 60),
            max_retries=provider_data.get("max_retries", 3),
            max_tokens_default=provider_data.get("max_tokens_default"),
            is_local=provider_data.get("is_local", False),
            safe_mode_allowed=provider_data.get("safe_mode_allowed", True),
            extra=provider_data.get("extra", {}),
        )

    return AIConfig(
        providers=providers,
        default_provider=ai_section.get("default_provider", "openai"),
        safe_mode_default=ai_section.get("safe_mode_default", False),
        redact_sensitive_data=ai_section.get("redact_sensitive_data", True),
        max_context_tokens=ai_section.get("max_context_tokens", 16000),
        enable_governance=ai_section.get("enable_governance", True),
        log_all_requests=ai_section.get("log_all_requests", True),
    )


def _default_config() -> AIConfig:
    """Default configuration (OpenAI only)"""
    return AIConfig(
        providers={
            "openai": ProviderConfig(
                type="openai",
                api_key_env="OPENAI_API_KEY",
                default_model="gpt-3.5-turbo",
                is_local=False,
                safe_mode_allowed=False,
            ),
            "local_llama": ProviderConfig(
                type="openai_compatible",
                base_url="http://localhost:11434/v1",
                default_model="llama3.1:8b",
                is_local=True,
                safe_mode_allowed=True,
            ),
        },
        default_provider="openai",
    )


# Example branchpy.toml content
EXAMPLE_CONFIG = """
[ai]
default_provider = "local_llama"  # or "openai", "venice", etc.
safe_mode_default = true
redact_sensitive_data = true
max_context_tokens = 16000

[ai.providers.openai]
type = "openai"
api_key_env = "OPENAI_API_KEY"
default_model = "gpt-4o-mini"
is_local = false
safe_mode_allowed = false  # Cloud provider

[ai.providers.local_llama]
type = "openai_compatible"
base_url = "http://localhost:11434/v1"  # Ollama default
default_model = "llama3.1:8b"
timeout = 120  # Local models can be slow
is_local = true
safe_mode_allowed = true  # Fully private

[ai.providers.venice]
type = "custom_http"
base_url = "https://api.venice.ai/v1"
api_key_env = "VENICE_API_KEY"
default_model = "venice-model-id"
is_local = false
safe_mode_allowed = false  # Cloud provider (privacy-focused but not local)

[ai.providers.lm_studio]
type = "openai_compatible"
base_url = "http://localhost:1234/v1"  # LM Studio default
default_model = "local-model"
is_local = true
safe_mode_allowed = true
"""
