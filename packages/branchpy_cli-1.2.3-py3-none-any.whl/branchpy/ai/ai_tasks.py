"""
branchpy.ai.ai_tasks.py
BranchPy v0.9.4 — AI Integration Strategy

High-level AI task implementations
Convenience functions for common AI operations
"""

from typing import Any, Dict, List, Optional

from .ai_models import AIRequest, AITask
from .ai_routing import AIRouter
from .provider_manager import ProviderManager


def code_review(
    file_path: str, code: Optional[str] = None, language: str = "python"
) -> Dict[str, Any]:
    """
    Run AI code review on a file.

    Args:
        file_path: Path to file
        code: Optional code string (if not provided, read from file)
        language: Programming language

    Returns:
        Review results
    """
    try:
        if code is None:
            with open(file_path, "r", encoding="utf-8") as f:
                code = f.read()
    except FileNotFoundError:
        return {"error": f"File not found: {file_path}", "findings": []}
    except Exception as e:
        return {"error": f"Failed to read file: {str(e)}", "findings": []}

    pm = ProviderManager()
    provider = pm.get_active_provider()

    if provider is None:
        return {"error": "No AI provider configured", "findings": []}

    model = pm.get_model(provider) or "default"

    request = AIRequest(
        task=AITask.CODE_REVIEW,
        provider=provider.value,
        model=model,
        input_data={"code": code, "language": language},
    )

    router = AIRouter()
    response = router.execute(request)

    if response.error:
        return {"error": response.error, "findings": []}

    return response.output


def generate_docs(code: str, doc_type: str = "readme") -> str:
    """
    Generate documentation for code.

    Args:
        code: Source code
        doc_type: Documentation type

    Returns:
        Generated documentation
    """
    pm = ProviderManager()
    provider = pm.get_active_provider()

    if provider is None:
        return "Error: No AI provider configured"

    model = pm.get_model(provider) or "default"

    request = AIRequest(
        task=AITask.DOCGEN,
        provider=provider.value,
        model=model,
        input_data={"code": code, "doc_type": doc_type},
    )

    router = AIRouter()
    response = router.execute(request)

    if response.error:
        return f"Error: {response.error}"

    return response.output


def explain_warning(warning_text: str, context: Optional[str] = None) -> str:
    """
    Get AI explanation for a warning.

    Args:
        warning_text: Warning message
        context: Optional context

    Returns:
        Explanation
    """
    pm = ProviderManager()
    provider = pm.get_active_provider()

    if provider is None:
        return "Error: No AI provider configured"

    model = pm.get_model(provider) or "default"

    request = AIRequest(
        task=AITask.EXPLAIN_WARNING,
        provider=provider.value,
        model=model,
        input_data={"warning": warning_text, "context": context},
    )

    router = AIRouter()
    response = router.execute(request)

    if response.error:
        return f"Error: {response.error}"

    return response.output


def guess_missing_asset(context: str, available_assets: List[str]) -> List[str]:
    """
    Guess missing asset based on context.

    Args:
        context: Asset context
        available_assets: Available asset filenames

    Returns:
        List of suggestions
    """
    pm = ProviderManager()
    provider = pm.get_active_provider()

    if provider is None:
        return []

    model = pm.get_model(provider) or "default"

    request = AIRequest(
        task=AITask.ASSET_GUESS,
        provider=provider.value,
        model=model,
        input_data={"context": context, "available_assets": available_assets},
    )

    router = AIRouter()
    response = router.execute(request)

    if response.error:
        return []

    return response.output if isinstance(response.output, list) else []
