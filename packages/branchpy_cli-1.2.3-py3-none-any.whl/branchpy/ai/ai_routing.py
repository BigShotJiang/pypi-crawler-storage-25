"""
branchpy.ai.ai_routing.py
BranchPy v0.9.4 — AI Integration Strategy

AI task routing and execution
Routes tasks to appropriate providers based on configuration and task type
"""

from typing import Any, Dict, Optional

from .ai_models import AIRequest, AIResponse, AITask
from .provider_manager import AIProvider, ProviderManager
from .providers.anthropic_provider import AnthropicProvider
from .providers.openai_provider import OpenAIProvider


class AIRouter:
    """
    Routes AI tasks to appropriate providers.

    Handles:
    - Provider selection
    - Task routing
    - Error handling
    - Governance event emission
    """

    def __init__(self):
        self.provider_manager = ProviderManager()
        self._providers: Dict[str, Any] = {}

    def _get_provider_instance(self, provider: AIProvider):
        """Get or create provider instance"""
        if provider.value in self._providers:
            return self._providers[provider.value]

        api_key = self.provider_manager.get_api_key(provider)
        if not api_key:
            raise ValueError(f"No API key configured for {provider.value}")

        model = self.provider_manager.get_model(provider)

        if provider == AIProvider.OPENAI:
            instance = OpenAIProvider(api_key, model or "gpt-4")
        elif provider == AIProvider.ANTHROPIC:
            instance = AnthropicProvider(api_key, model or "claude-3-5-sonnet-20241022")
        else:
            raise ValueError(f"Unsupported provider: {provider}")

        self._providers[provider.value] = instance
        return instance

    def execute(self, request: AIRequest) -> AIResponse:
        """
        Execute an AI task.

        Args:
            request: AI request

        Returns:
            AI response
        """
        try:
            # Get provider
            provider = AIProvider(request.provider)
            instance = self._get_provider_instance(provider)

            # Route task
            if request.task == AITask.CODE_REVIEW:
                output = instance.code_review(
                    code=request.input_data["code"],
                    language=request.input_data.get("language", "python"),
                )
            elif request.task == AITask.DOCGEN:
                output = instance.generate_documentation(
                    code=request.input_data["code"],
                    doc_type=request.input_data.get("doc_type", "readme"),
                )
            elif request.task == AITask.EXPLAIN_WARNING:
                output = instance.explain_warning(
                    warning_text=request.input_data["warning"],
                    context=request.input_data.get("context"),
                )
            elif request.task == AITask.ASSET_GUESS:
                if provider == AIProvider.ANTHROPIC:
                    output = instance.guess_asset(
                        asset_context=request.input_data["context"],
                        available_assets=request.input_data["available_assets"],
                    )
                else:
                    output = {"error": "Asset guessing only supported on Anthropic"}
            else:
                output = {"error": f"Unsupported task: {request.task}"}

            return AIResponse(
                task=request.task,
                provider=request.provider,
                model=request.model,
                output=output,
            )

        except Exception as e:
            return AIResponse(
                task=request.task,
                provider=request.provider,
                model=request.model,
                output=None,
                error=str(e),
            )

    def is_available(self, provider: Optional[AIProvider] = None) -> bool:
        """Check if AI is available"""
        if provider is None:
            provider = self.provider_manager.get_active_provider()

        if provider is None:
            return False

        return self.provider_manager.is_configured(provider)
