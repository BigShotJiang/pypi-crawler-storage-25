"""
AI Provider Protocol

Generic interface that all AI providers must implement.
Keeps BranchPy features provider-agnostic.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Protocol


@dataclass
class Message:
    """Normalized message format across all providers"""

    role: Literal["system", "user", "assistant"]
    content: str
    name: Optional[str] = None  # For multi-agent scenarios


@dataclass
class TokenUsage:
    """Token usage statistics (normalized)"""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class ChatRequest:
    """
    Generic chat request format.

    Providers adapt this to their specific API format.
    """

    messages: List[Message]
    model: Optional[str] = None  # If None, use provider default
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    stop: Optional[List[str]] = None

    # BranchPy-specific metadata
    feature: Optional[str] = None  # "translate", "refactor", "patch", etc.
    safe_mode: bool = False  # True = restrict context, local-only
    redacted: bool = False  # True if safety layer redacted content

    # Provider-specific extras (passed through as-is)
    extra: Optional[Dict[str, Any]] = None


@dataclass
class ChatResponse:
    """
    Generic chat response format.

    Providers adapt their response to this format.
    """

    content: str
    model: str
    finish_reason: Literal["stop", "length", "content_filter", "error"]
    provider_id: str
    usage: Optional[TokenUsage] = None
    provider_response_raw: Optional[Dict[str, Any]] = None  # For debugging
    created_at: Optional[datetime] = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.utcnow()


class AIProvider(Protocol):
    """
    Protocol that all AI providers must implement.

    This is the contract that BranchPy features depend on.
    Providers can be OpenAI, Llama, Venice.ai, or custom.
    """

    @property
    def provider_id(self) -> str:
        """Unique provider identifier (e.g., 'openai', 'local_llama', 'venice')"""
        ...

    @property
    def default_model(self) -> str:
        """Default model to use when request.model is None"""
        ...

    @property
    def is_local(self) -> bool:
        """True if provider runs locally (no data leaves machine)"""
        ...

    def chat(self, request: ChatRequest) -> ChatResponse:
        """
        Send chat request and get response.

        Providers must:
        1. Convert ChatRequest to their API format
        2. Make HTTP call (or local inference)
        3. Parse response into ChatResponse
        4. Handle errors gracefully (raise ProviderError)

        Args:
            request: Generic chat request

        Returns:
            ChatResponse with normalized data

        Raises:
            ProviderError: On API errors, timeouts, etc.
            ProviderConfigError: On configuration issues
        """
        ...

    def validate_config(self) -> None:
        """
        Validate provider configuration.

        Called on initialization. Should check:
        - API keys exist (if required)
        - Base URLs are valid
        - Required dependencies installed

        Raises:
            ProviderConfigError: If config invalid
        """
        ...

    def estimate_cost(self, request: ChatRequest) -> Optional[float]:
        """
        Estimate cost in USD for this request.

        Returns None if cost unknown (local providers).
        """
        ...


class ProviderError(Exception):
    """Base exception for provider errors"""

    pass


class ProviderConfigError(ProviderError):
    """Configuration error (missing keys, invalid URLs, etc.)"""

    pass


class ProviderTimeoutError(ProviderError):
    """Request timed out"""

    pass


class ProviderRateLimitError(ProviderError):
    """Rate limit exceeded"""

    pass


class ProviderAuthError(ProviderError):
    """Authentication failed (invalid API key)"""

    pass
