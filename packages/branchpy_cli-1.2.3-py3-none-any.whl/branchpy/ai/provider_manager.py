"""
branchpy.ai.provider_manager.py
BranchPy v0.9.4 — AI Integration Strategy

Manages AI providers: OpenAI, Anthropic
Handles API key storage, provider selection, and routing

Governance Events:
- ai.provider.select
- ai.provider.configure
"""

import json
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional


class AIProvider(Enum):
    """Supported AI providers"""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"


class ProviderManager:
    """
    Manages AI provider configuration and API keys.

    API keys are stored locally in ~/.branchpy/ai_config.json
    Never transmitted to BranchPy servers.
    """

    def __init__(self):
        self.config_path = Path.home() / ".branchpy" / "ai_config.json"
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        self._config: Dict[str, Any] = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load AI configuration from disk"""
        if not self.config_path.exists():
            return {"provider": None, "api_keys": {}, "models": {}}

        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Failed to load AI config: {e}")
            return {"provider": None, "api_keys": {}, "models": {}}

    def _save_config(self):
        """Save AI configuration to disk"""
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self._config, f, indent=2)
        except Exception as e:
            print(f"Failed to save AI config: {e}")

    def set_api_key(self, provider: AIProvider, api_key: str):
        """
        Store API key for a provider.

        Args:
            provider: AI provider
            api_key: API key string
        """
        self._config["api_keys"][provider.value] = api_key
        self._save_config()

    def get_api_key(self, provider: AIProvider) -> Optional[str]:
        """Get API key for a provider"""
        return self._config["api_keys"].get(provider.value)

    def set_active_provider(self, provider: AIProvider):
        """Set the active AI provider"""
        self._config["provider"] = provider.value
        self._save_config()

    def get_active_provider(self) -> Optional[AIProvider]:
        """Get the currently active provider"""
        provider_str = self._config.get("provider")
        if provider_str:
            try:
                return AIProvider(provider_str)
            except ValueError:
                return None
        return None

    def set_model(self, provider: AIProvider, model: str):
        """Set model for a provider"""
        self._config["models"][provider.value] = model
        self._save_config()

    def get_model(self, provider: AIProvider) -> Optional[str]:
        """Get model for a provider"""
        return self._config["models"].get(provider.value)

    def is_configured(self, provider: AIProvider) -> bool:
        """Check if a provider is fully configured"""
        return self.get_api_key(provider) is not None

    def clear_config(self):
        """Clear all AI configuration"""
        self._config = {"provider": None, "api_keys": {}, "models": {}}
        self._save_config()
