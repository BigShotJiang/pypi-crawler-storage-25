"""
Compare Media Integration - v0.9.1.4 Compare UX & Media-Aware Diffs

Orchestrates media diff computation for branchpy compare --media.
Integrates media indexer with diff engine.

BQS Compliance:
- Engine-agnostic design
- Telemetry integration
- Type-safe with mypy compliance
- Cross-platform path handling
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from ..analyzer.media_indexer import MediaIndex, RenpyMediaIndexer
from .media_diff_engine import MediaDiffEngine


def compute_media_diffs_for_compare(
    *,
    project_root: Path,
    from_ref: str,
    to_ref: str,
    engine_type: str = "renpy",
) -> Dict[str, Any]:
    """
    Compute media diffs for compare command.

    High-level orchestration that:
    1. Selects appropriate media indexer
    2. Builds indexes for both refs
    3. Runs MediaDiffEngine
    4. Emits telemetry
    5. Returns media_diffs fragment

    Args:
        project_root: Project root directory
        from_ref: Source ref (branch, commit, checkpoint)
        to_ref: Target ref
        engine_type: Game engine type ("renpy", "godot", "unity")

    Returns:
        Dictionary with media_diffs structure ready for merge

    Example:
        result = compute_media_diffs_for_compare(
            project_root=Path("~/mygame"),
            from_ref="main",
            to_ref="feature/new-art",
        )
        compare_output.update(result)

    Note:
        v0.9.1.4 implementation uses current working state for both refs.
        Future versions will integrate with history engine / worktree manager
        to check out refs to temp directories for accurate comparison.
    """
    # Select indexer based on engine type
    if engine_type == "renpy":
        indexer = RenpyMediaIndexer()
    else:
        # Future: GodotMediaIndexer, UnityMediaIndexer
        raise ValueError(f"Unsupported engine type: {engine_type}")

    engine = MediaDiffEngine(project_root)

    # TODO (v0.9.1.5+): Integrate with history engine for proper ref checkout
    # For now, build indexes from current project state (simplified)
    #
    # Ideal implementation:
    #   with worktree_manager.checkout(from_ref) as from_dir:
    #       from_index = indexer.index_media(from_dir)
    #   with worktree_manager.checkout(to_ref) as to_dir:
    #       to_index = indexer.index_media(to_dir)
    #
    # Current stub (assumes project is at to_ref state):
    from_index: MediaIndex = {}  # Placeholder - would use history
    to_index: MediaIndex = indexer.index_media(project_root)

    # Compute diff using original stub signature
    diff_result = engine.compute_diff(
        ref_from=from_ref,
        ref_to=to_ref,
        engine=engine_type,
    )

    # Convert MediaDiffOutput to dict
    if hasattr(diff_result, "to_dict"):
        diff_dict: Dict[str, Any] = {"media_diffs": diff_result.to_dict()}
    else:
        diff_dict = diff_result  # type: ignore[assignment]

    # Emit telemetry
    _emit_media_diff_telemetry(
        project_root=project_root,
        diff_result=diff_dict,
    )

    return diff_dict


def _emit_media_diff_telemetry(
    project_root: Path,
    diff_result: Dict[str, Any],
) -> None:
    """
    Emit telemetry for media diff generation.

    Args:
        project_root: Project root path
        diff_result: MediaDiffOutput from engine

    Note:
        Imports telemetry module lazily to avoid circular dependencies.
    """
    try:
        from ..telemetry.events_compare import (
            MediaDiffSummary,
            emit_media_diff_generated,
        )

        groups = diff_result.get("media_diffs", {})
        summary = MediaDiffSummary(
            added=len(groups.get("added", [])),
            removed=len(groups.get("removed", [])),
            moved=len(groups.get("moved", [])),
            renamed=len(groups.get("renamed", [])),
            changed_call_context=len(groups.get("changed_call_context", [])),
        )

        emit_media_diff_generated(
            governance_id="AXIS4-V0.9.1.4-MEDIA",
            project_id=str(project_root),
            summary=summary,
            correlation_id="compare-media-v0914",  # TODO: Use proper correlation ID
        )
    except ImportError:
        # Telemetry module not available (graceful degradation)
        pass
