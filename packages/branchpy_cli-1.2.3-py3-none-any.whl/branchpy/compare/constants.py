"""
BranchPy Compare Constants and Enums

Defines terminology and constants for Compare UX (v0.9.1.4)
- History Lanes: Visual path + test history UI
- Compare: CLI diff tool
"""

from enum import Enum
from typing import Literal


class PanelType(str, Enum):
    """VS Code panel types for BranchPy features."""

    HISTORY_LANES = "history_lanes"
    COMPARE = "compare"
    MEDIA = "media"
    PILOT = "pilot"  # Legacy alias for HISTORY_LANES


# Type aliases for clarity
HistoryLanesView = Literal["history_lanes"]
CompareView = Literal["compare"]


# Panel display names (for UI)
PANEL_DISPLAY_NAMES = {
    PanelType.HISTORY_LANES: "BranchPy: History Lanes",
    PanelType.COMPARE: "BranchPy: Compare",
    PanelType.MEDIA: "BranchPy: Media",
    PanelType.PILOT: "BranchPy: Pilot (Legacy)",  # Deprecated
}


# Command descriptions (for CLI help)
COMMAND_DESCRIPTIONS = {
    "compare": "On-demand diffs between two refs (scriptable, automation-friendly)",
    "pilot": "Visual path + test history (History Lanes UI) - see also 'history-lanes'",
    "history-lanes": "Visual path + branches with test-aware history",
}


# Feature flags
FEATURES = {
    "HISTORY_LANES_ENABLED": True,
    "COMPARE_MEDIA_DIFFS": True,
    "COMPARE_TEST_MAPPING": True,
    "PILOT_LEGACY_COMPAT": True,  # Support old "pilot" terminology
}


def get_panel_name(panel_type: PanelType) -> str:
    """Get display name for a panel type."""
    return PANEL_DISPLAY_NAMES.get(panel_type, str(panel_type))


def is_history_lanes_panel(panel_id: str) -> bool:
    """Check if panel ID refers to History Lanes (including legacy 'pilot')."""
    return panel_id.lower() in ("history_lanes", "pilot")


def normalize_panel_type(panel_id: str) -> PanelType:
    """Normalize panel ID to canonical type (pilot → history_lanes)."""
    if panel_id.lower() == "pilot":
        return PanelType.HISTORY_LANES
    try:
        return PanelType(panel_id.lower())
    except ValueError:
        raise ValueError(f"Unknown panel type: {panel_id}")
