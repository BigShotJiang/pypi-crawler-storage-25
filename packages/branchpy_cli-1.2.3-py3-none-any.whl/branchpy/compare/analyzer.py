"""
Compare Analyzer — Policy-Aware Integration (H5 Day 2 G7)

Wraps Compare analysis with BQF policy evaluation and telemetry emission.
Integrates compare.similarity_floor policy with validation telemetry.

Governance ID: AXIS5-V0.9.1.2-20251113-H5-G7
Checkpoint: H5 Day 2 — Policy-Aware Validation Integration
"""

from time import perf_counter
from typing import Any, Dict, Optional

# Lazy imports to avoid circular dependencies
_bqf_available = None
_telemetry_available = None


def _check_bqf_available():
    """Check if BQF module is available."""
    global _bqf_available
    if _bqf_available is None:
        try:
            from branchpy.bqf.context_mapping import (
                CompareRunSummary,
                to_bqf_inputs_for_compare,
            )
            from branchpy.bqf.runner import PolicyRunner

            _bqf_available = True
        except ImportError:
            _bqf_available = False
    return _bqf_available


def _check_telemetry_available():
    """Check if telemetry module is available."""
    global _telemetry_available
    if _telemetry_available is None:
        try:
            from branchpy.telemetry.validation_events import ValidationTelemetryContext

            _telemetry_available = True
        except ImportError:
            _telemetry_available = False
    return _telemetry_available


async def run_compare_analysis(
    files: list[str],
    *,
    governance_id: Optional[str] = None,
    target_path: Optional[str] = None,
    enable_policies: bool = True,
) -> Dict[str, Any]:
    """
    Run Compare analysis with BQF policy evaluation and telemetry.

    Orchestrates:
        1. Compare similarity analysis (existing logic)
        2. BQF policy evaluation (similarity_floor)
        3. Telemetry emission (validation.start/complete with policy_results)

    Args:
        files: List of file paths to compare
        governance_id: Optional governance ID for telemetry linking
        target_path: Optional target path for telemetry (defaults to "compare:batch")
        enable_policies: Enable BQF policy evaluation (default: True)

    Returns:
        Analysis report with:
            - avg_similarity: Average similarity score
            - sample_count: Number of comparisons
            - policy: PolicyReport dict (if policies enabled)
            - duration_ms: Analysis duration
            - issues_found: Total warn+fail policy count

    Example:
        >>> result = await run_compare_analysis(
        ...     ["a.rpy", "b.rpy", "c.rpy"],
        ...     governance_id="AXIS5-V0.9.1.2-20251113-H5-G7"
        ... )
        >>> assert "avg_similarity" in result
        >>> assert "policy" in result
    """
    t0 = perf_counter()

    # Default target path
    if target_path is None:
        target_path = "compare:batch"

    # --- Existing Compare Analysis Logic (placeholder) ---
    # TODO: Replace with actual Compare analyzer implementation
    # For now, mock with simple metrics
    avg_similarity = await _compute_avg_similarity(files)
    sample_count = len(files)

    # --- BQF Policy Evaluation ---
    policy_report = None
    if enable_policies and _check_bqf_available():
        try:
            from branchpy.bqf.context_mapping import (
                CompareRunSummary,
                to_bqf_inputs_for_compare,
            )
            from branchpy.bqf.policy_base import PolicyContext
            from branchpy.bqf.runner import PolicyRunner

            # Create policy inputs
            inputs = to_bqf_inputs_for_compare(
                CompareRunSummary(
                    avg_similarity=avg_similarity, sample_count=sample_count
                )
            )

            # Create policy context
            ctx = PolicyContext(
                module="compare", inputs=inputs, governance_id=governance_id
            )

            # Run policies
            runner = PolicyRunner()
            policy_report = runner.run_module("compare", ctx)

        except Exception:
            # Non-blocking: policy failure doesn't break analysis
            pass

    # Calculate duration
    duration_ms = (perf_counter() - t0) * 1000.0

    # --- Telemetry Emission ---
    if _check_telemetry_available():
        try:
            from branchpy.telemetry.validation_events import emit_validation_event

            # Build policy_results field
            policy_results = None
            if policy_report:
                policy_results = {
                    "pass": policy_report.pass_count,
                    "warn": policy_report.warn_count,
                    "fail": policy_report.fail_count,
                }

            # Calculate issues_found
            issues_found = 0
            if policy_report:
                issues_found = policy_report.warn_count + policy_report.fail_count

            # Emit validation.complete event
            await emit_validation_event(
                event_type="validation.complete",
                module="compare",
                target_path=target_path,
                issues_found=issues_found,
                duration_ms=duration_ms,
                governance_id=governance_id,
                metadata={
                    "avg_similarity": avg_similarity,
                    "sample_count": sample_count,
                },
                policy_results=policy_results,
            )
        except Exception:
            # Non-blocking: telemetry failure doesn't break analysis
            pass

    # --- Build Result ---
    result = {
        "avg_similarity": avg_similarity,
        "sample_count": sample_count,
        "duration_ms": duration_ms,
        "issues_found": 0,
    }

    if policy_report:
        result["policy"] = policy_report.to_dict()
        result["issues_found"] = policy_report.warn_count + policy_report.fail_count

    return result


async def _compute_avg_similarity(files: list[str]) -> float:
    """
    Compute average similarity score across files.

    PLACEHOLDER: Replace with actual Compare analyzer logic.
    For now, returns mock similarity based on file count.

    Args:
        files: List of file paths

    Returns:
        Average similarity score (0.0-1.0)
    """
    # Mock implementation - replace with actual logic
    if len(files) < 2:
        return 1.0

    # Simple mock: higher similarity for more files
    return min(0.95, 0.80 + (len(files) * 0.02))
