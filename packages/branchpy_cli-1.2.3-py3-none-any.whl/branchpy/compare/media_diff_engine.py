"""
Media Diff Engine Implementation (v0.9.1.4)

Computes media diffs by comparing media indexes between two refs.
"""

from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

from branchpy.analyzer.media_indexer import RenpyMediaIndexer
from branchpy.compare.media_diff_types import CallSite, MediaDiffOutput, MediaDiffResult

log = logging.getLogger(__name__)


class MediaDiffEngine:
    """
    Engine for computing media-aware diffs between refs.

    Integrates with existing media indexer to detect:
    - Added/removed media files
    - Moved/renamed media files
    - Changed call contexts (different usage patterns)
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize the media diff engine.

        Args:
            project_root: Absolute path to project root (defaults to CWD)
        """
        self.project_root = project_root or Path.cwd()
        self.indexer = RenpyMediaIndexer()

    def compute_diff(
        self,
        ref_from: str,
        ref_to: str,
        engine: Optional[str] = None,
    ) -> MediaDiffOutput:
        """
        Compute media differences between two refs.

        Args:
            ref_from: Source ref (branch name, commit hash, or checkpoint ID)
            ref_to: Target ref to compare against
            engine: Engine type (renpy/godot/unity) or None for auto-detect

        Returns:
            MediaDiffOutput containing all media changes

        Raises:
            ValueError: If refs are invalid or not found
            MediaIndexError: If media index is unavailable
        """
        log.info(f"Computing media diff: {ref_from} → {ref_to}")

        # Get media indexes for both refs
        index_from = self._get_media_index(ref_from, engine)
        index_to = self._get_media_index(ref_to, engine)

        # Compute differences
        output = MediaDiffOutput()

        media_ids_from = set(index_from.keys())
        media_ids_to = set(index_to.keys())

        # Detect added media
        for media_id in media_ids_to - media_ids_from:
            entry = index_to[media_id]
            call_sites = [
                CallSite(
                    file=cs["file"],
                    line=cs["line"],
                    function=cs["function"],
                    context=cs.get("context"),
                )
                for cs in entry["call_sites"]
            ]
            output.added.append(
                MediaDiffResult(
                    media_id=media_id,
                    path=entry["path"],
                    status="added",
                    call_sites={"to": call_sites},
                )
            )

        # Detect removed media
        for media_id in media_ids_from - media_ids_to:
            entry = index_from[media_id]
            call_sites = [
                CallSite(
                    file=cs["file"],
                    line=cs["line"],
                    function=cs["function"],
                    context=cs.get("context"),
                )
                for cs in entry["call_sites"]
            ]
            output.removed.append(
                MediaDiffResult(
                    media_id=media_id,
                    path=entry["path"],
                    status="removed",
                    call_sites={"from": call_sites},
                )
            )

        # Detect changed call contexts
        for media_id in media_ids_from & media_ids_to:
            entry_from = index_from[media_id]
            entry_to = index_to[media_id]

            # Compare call sites
            call_sites_from = [
                CallSite(
                    file=cs["file"],
                    line=cs["line"],
                    function=cs["function"],
                    context=cs.get("context"),
                )
                for cs in entry_from["call_sites"]
            ]
            call_sites_to = [
                CallSite(
                    file=cs["file"],
                    line=cs["line"],
                    function=cs["function"],
                    context=cs.get("context"),
                )
                for cs in entry_to["call_sites"]
            ]

            # Check if call sites changed
            if self._call_sites_differ(call_sites_from, call_sites_to):
                output.changed_call_context.append(
                    MediaDiffResult(
                        media_id=media_id,
                        path=entry_to["path"],
                        status="changed_call_context",
                        call_sites={
                            "from": call_sites_from,
                            "to": call_sites_to,
                        },
                    )
                )

        return output

    def _call_sites_differ(
        self,
        sites_from: List[CallSite],
        sites_to: List[CallSite],
    ) -> bool:
        """
        Check if call sites differ between refs.

        Args:
            sites_from: Call sites in 'from' ref
            sites_to: Call sites in 'to' ref

        Returns:
            True if call sites differ (different locations/contexts)
        """
        # Simple comparison: different count or different locations
        if len(sites_from) != len(sites_to):
            return True

        # Compare normalized locations
        locs_from = {(cs.file, cs.function) for cs in sites_from}
        locs_to = {(cs.file, cs.function) for cs in sites_to}

        return locs_from != locs_to

    def _get_media_index(self, ref: str, engine: Optional[str]) -> Dict[str, Dict]:
        """
        Get media index for a specific ref.

        Args:
            ref: Git ref or checkpoint ID
            engine: Engine type

        Returns:
            Dict mapping media_id to MediaIndexEntry dict
        """
        # Special case: If ref is HEAD or HEAD~N, we can work directly in the repo
        if ref == "HEAD" or ref.startswith("HEAD~"):
            # Index current state (for HEAD)
            if ref == "HEAD":
                return self.indexer.index_media(self.project_root)

        # For other refs, checkout in temp directory
        # Use a temporary directory to avoid modifying working tree
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir) / "checkout"
            tmp_path.mkdir()

            # Use git worktree for clean checkout
            worktree_created = False
            try:
                # Create a temporary worktree at the specific ref
                subprocess.run(
                    ["git", "worktree", "add", "--detach", str(tmp_path), ref],
                    cwd=self.project_root,
                    check=True,
                    capture_output=True,
                    text=True,
                )
                worktree_created = True

                # Index media at this ref
                index = self.indexer.index_media(tmp_path)

                return index

            except subprocess.CalledProcessError as e:
                log.error(f"Failed to checkout ref {ref}: {e.stderr}")
                return {}

            finally:
                # Always clean up worktree if it was created
                if worktree_created:
                    try:
                        subprocess.run(
                            ["git", "worktree", "remove", "--force", str(tmp_path)],
                            cwd=self.project_root,
                            check=False,
                            capture_output=True,
                        )
                    except Exception as cleanup_err:
                        log.warning(
                            f"Failed to clean up worktree {tmp_path}: {cleanup_err}"
                        )

    def _compute_added(
        self,
        index_from: Dict[str, List[CallSite]],
        index_to: Dict[str, List[CallSite]],
    ) -> List[MediaDiffResult]:
        """Find media files added in ref_to."""
        added = []
        for media_id, call_sites in index_to.items():
            if media_id not in index_from:
                added.append(
                    MediaDiffResult(
                        media_id=media_id,
                        path=media_id,  # TODO: Resolve actual path
                        status="added",
                        call_sites={"to": call_sites},
                    )
                )
        return added

    def _compute_removed(
        self,
        index_from: Dict[str, List[CallSite]],
        index_to: Dict[str, List[CallSite]],
    ) -> List[MediaDiffResult]:
        """Find media files removed in ref_to."""
        removed = []
        for media_id, call_sites in index_from.items():
            if media_id not in index_to:
                removed.append(
                    MediaDiffResult(
                        media_id=media_id,
                        path=media_id,
                        status="removed",
                        call_sites={"from": call_sites},
                    )
                )
        return removed

    def _compute_changed_context(
        self,
        index_from: Dict[str, List[CallSite]],
        index_to: Dict[str, List[CallSite]],
    ) -> List[MediaDiffResult]:
        """Find media files with changed call contexts."""
        changed = []
        common_media = set(index_from.keys()) & set(index_to.keys())

        for media_id in common_media:
            sites_from = index_from[media_id]
            sites_to = index_to[media_id]

            # Compare call sites (file, line, function)
            if not self._call_sites_equal(sites_from, sites_to):
                changed.append(
                    MediaDiffResult(
                        media_id=media_id,
                        path=media_id,
                        status="changed_call_context",
                        call_sites={
                            "from": sites_from,
                            "to": sites_to,
                        },
                    )
                )

        return changed

    def _call_sites_equal(
        self,
        sites1: List[CallSite],
        sites2: List[CallSite],
    ) -> bool:
        """Check if two lists of call sites are equivalent."""
        if len(sites1) != len(sites2):
            return False

        # Convert to set of tuples for comparison (ignore context)
        def to_tuple(cs: CallSite) -> tuple:
            return (cs.file, cs.line, cs.function)

        set1 = {to_tuple(cs) for cs in sites1}
        set2 = {to_tuple(cs) for cs in sites2}

        return set1 == set2


class MediaIndexError(Exception):
    """Raised when media index is unavailable or corrupted."""

    pass
