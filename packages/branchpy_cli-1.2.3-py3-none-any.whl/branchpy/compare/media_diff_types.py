"""
Media Diff Engine for BranchPy (v0.9.1.4)

Computes diffs between two refs (branches, commits, checkpoints)
with awareness of media assets and their usage contexts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional

# Media diff statuses
MediaStatus = Literal["added", "removed", "moved", "renamed", "changed_call_context"]


@dataclass
class CallSite:
    """
    Represents a location where media is referenced in code.

    Attributes:
        file: Relative path to source file
        line: Line number where media is referenced
        function: Function/label name containing the reference
        context: Optional surrounding code snippet
    """

    file: str
    line: int
    function: str
    context: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "file": self.file,
            "line": self.line,
            "function": self.function,
            "context": self.context,
        }


@dataclass
class MediaDiffResult:
    """
    Result of comparing media usage between two refs.

    Attributes:
        media_id: Unique identifier for the media asset
        path: Relative path to media file
        status: Type of change (added/removed/moved/etc.)
        call_sites: Call sites per ref ("from" or "to")
    """

    media_id: str
    path: str
    status: MediaStatus
    call_sites: Dict[str, List[CallSite]] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "media_id": self.media_id,
            "path": self.path,
            "status": self.status,
            "call_sites": {
                ref: [cs.to_dict() for cs in sites]
                for ref, sites in self.call_sites.items()
            },
        }


@dataclass
class MediaDiffOutput:
    """
    Complete media diff output for a compare operation.

    Attributes:
        added: Media files added in 'to' ref
        removed: Media files removed in 'to' ref
        moved: Media files moved to different path
        renamed: Media files renamed
        changed_call_context: Media with different usage patterns
    """

    added: List[MediaDiffResult] = field(default_factory=list)
    removed: List[MediaDiffResult] = field(default_factory=list)
    moved: List[MediaDiffResult] = field(default_factory=list)
    renamed: List[MediaDiffResult] = field(default_factory=list)
    changed_call_context: List[MediaDiffResult] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "added": [item.to_dict() for item in self.added],
            "removed": [item.to_dict() for item in self.removed],
            "moved": [item.to_dict() for item in self.moved],
            "renamed": [item.to_dict() for item in self.renamed],
            "changed_call_context": [
                item.to_dict() for item in self.changed_call_context
            ],
        }

    @property
    def total_changes(self) -> int:
        """Total number of media changes across all categories."""
        return (
            len(self.added)
            + len(self.removed)
            + len(self.moved)
            + len(self.renamed)
            + len(self.changed_call_context)
        )

    def is_empty(self) -> bool:
        """Check if there are no media changes."""
        return self.total_changes == 0
