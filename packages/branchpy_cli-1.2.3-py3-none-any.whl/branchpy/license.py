# branchpy/license.py
import hashlib
import json
import time
from pathlib import Path

from appdirs import user_config_dir

from branchpy.contract import Exit

APP_DIR = Path(user_config_dir("BranchPy", "BranchPy"))
APP_DIR.mkdir(parents=True, exist_ok=True)
TOKEN_FILE = APP_DIR / "license_token.json"

GRACE_SECONDS = 7 * 24 * 3600


def _machine_id() -> str:
    # privacy-friendly stable hash (OS+user+host)
    import getpass
    import platform
    import socket

    raw = f"{platform.system()}::{getpass.getuser()}::{socket.gethostname()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _save_token(token: dict):
    TOKEN_FILE.write_text(json.dumps(token, indent=2), encoding="utf-8")


def _load_token() -> dict | None:
    if not TOKEN_FILE.exists():
        return None
    try:
        return json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def validate_license(
    key: str | None, now: float | None = None
) -> tuple[bool, dict, int | None]:
    """
    Returns (valid, license_dict, exit_code_if_error_or_None)
    For alpha: accept FREE-* keys locally. Add simple offline 'grace' behavior.
    """
    now = now or time.time()
    token = _load_token()
    if token and token.get("exp", 0) > now:
        token["grace_left"] = max(0, int(token["exp"] - now))
        # cached token in use; signal possible offline (network not checked here)
        return True, token, Exit.LIC_NETWORK

    # Alpha acceptance rule: FREE- keys always valid; others invalid for now.
    if key and key.upper().startswith("FREE-"):
        token = {
            "plan": "free",
            "valid": True,
            "exp": now + GRACE_SECONDS,  # refresh weekly in alpha
            "machine_id": _machine_id(),
        }
        _save_token(token)
        token["grace_left"] = GRACE_SECONDS
        return True, token, None

    # If we had a previously valid token, allow a short grace when offline
    if token:
        if token.get("exp", 0) + GRACE_SECONDS > now:
            token["valid"] = True
            token["grace_left"] = int(token["exp"] + GRACE_SECONDS - now)
            # grace after expiration; signal offline
            return True, token, Exit.LIC_NETWORK

    return False, {"plan": "free", "valid": False}, 2  # LIC_INVALID for alpha
