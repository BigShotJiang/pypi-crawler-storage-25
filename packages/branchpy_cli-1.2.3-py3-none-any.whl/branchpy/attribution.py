"""
branchpy/attribution.py — Attribution notice for Free tier users

Provides a lightweight, non-blocking attribution notice that appears after
major commands (analyze, test, benchmark) when using the Free tier.

Respects user preferences in config: show_attribution_reminder (default: true)
"""

from __future__ import annotations

import sys
from typing import Optional

from branchpy.config_store import ConfigStore
from branchpy.license_manager import load_local


def should_show_attribution() -> bool:
    """
    Determine if attribution notice should be shown.

    Returns True if:
    - User is on Free tier (no license or Free license)
    - Config option show_attribution_reminder is True (default)

    Returns:
        True if notice should be shown, False otherwise
    """
    # Check license tier
    try:
        license_info = load_local()
        if license_info and license_info.tier != "Free":
            # Commercial tier - no attribution needed
            return False
    except Exception:
        # No license or error loading - treat as Free tier
        pass

    # Check config preference
    try:
        config = ConfigStore()
        show_reminder = config.cfg.get("show_attribution_reminder", True)
        if not show_reminder:
            return False
    except Exception:
        # Default to showing if config unavailable
        pass

    return True


def maybe_show_attribution_notice(command: Optional[str] = None) -> None:
    """
    Display attribution notice if appropriate.

    This is called after major commands complete successfully. It's non-blocking
    and outputs a single-line notice to stderr.

    Args:
        command: Name of the command that was executed (e.g., "analyze", "test")
    """
    if not should_show_attribution():
        return

    # Simple, non-intrusive notice
    notice = "💡 BranchPy Free • Consider upgrading for priority support → https://branchpy.com/pricing"

    if command:
        notice = f"[{command}] {notice}"

    # Print to stderr so it doesn't interfere with JSON output or pipelines
    print(notice, file=sys.stderr)


def disable_attribution_notices() -> None:
    """
    Disable attribution notices by updating config.

    This can be called programmatically or via CLI command:
    $ branchpy config set show_attribution_reminder false
    """
    config = ConfigStore()
    config.cfg["show_attribution_reminder"] = False
    config.save()
    print(
        "Attribution notices disabled. Re-enable with: branchpy config set show_attribution_reminder true"
    )


def enable_attribution_notices() -> None:
    """
    Enable attribution notices by updating config.
    """
    config = ConfigStore()
    config.cfg["show_attribution_reminder"] = True
    config.save()
    print("Attribution notices enabled.")


# Convenience function for CLI integration
def add_attribution_to_command(func):
    """
    Decorator to add attribution notice after command execution.

    Usage:
        @add_attribution_to_command
        def my_command(args):
            # ... command logic ...
            return 0
    """

    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)

        # Only show attribution if command succeeded (exit code 0)
        if result == 0:
            command_name = func.__name__.replace("cmd_", "").replace("_", " ")
            maybe_show_attribution_notice(command_name)

        return result

    return wrapper
