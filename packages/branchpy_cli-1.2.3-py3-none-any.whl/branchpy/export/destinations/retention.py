"""
Retention policy for telemetry exports.

Implements TTL-based and count-based pruning with dry-run support.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.5)
"""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from .base import BaseDestination


class RetentionPolicy:
    """
    Retention policy for telemetry exports.

    Features:
    - TTL-based pruning (delete exports older than N days)
    - Count-based pruning (keep only N most recent exports)
    - Dry-run mode for testing
    - Respects idempotent keys and manifest files

    Example:
        policy = RetentionPolicy(ttl_days=90, max_artifacts=100)
        deleted = policy.apply(destination, dry_run=True)
    """

    def __init__(
        self, ttl_days: Optional[int] = None, max_artifacts: Optional[int] = None
    ):
        """
        Initialize retention policy.

        Args:
            ttl_days: Delete exports older than this many days (None = no TTL)
            max_artifacts: Keep only N most recent exports (None = no limit)
        """
        if ttl_days is None and max_artifacts is None:
            raise ValueError(
                "At least one of ttl_days or max_artifacts must be specified"
            )

        self.ttl_days = ttl_days
        self.max_artifacts = max_artifacts

    def apply(
        self,
        destination: BaseDestination,
        dry_run: bool = False,
        date_prefix: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Apply retention policy to destination.

        Args:
            destination: Destination to apply policy to
            dry_run: If True, log actions without deleting
            date_prefix: Optional date prefix to scope retention (YYYY/MM/DD)

        Returns:
            Dictionary with pruning statistics:
            - total_scanned: Number of exports scanned
            - ttl_pruned: Number pruned by TTL
            - max_n_pruned: Number pruned by count limit
            - total_deleted: Total exports deleted
            - bytes_freed: Approximate bytes freed
        """
        # List all exports
        exports = destination.list(date_prefix=date_prefix)

        stats = {
            "total_scanned": len(exports),
            "ttl_pruned": 0,
            "max_n_pruned": 0,
            "total_deleted": 0,
            "bytes_freed": 0,
        }

        if not exports:
            if not dry_run:
                print("No exports found for retention policy")
            return stats

        to_delete = []

        # Apply TTL-based pruning
        if self.ttl_days is not None:
            cutoff = datetime.now(timezone.utc) - timedelta(days=self.ttl_days)

            for export in exports:
                # Parse ISO timestamp, handle both 'Z' suffix and +00:00
                ts_str = export["last_modified"].replace("Z", "+00:00")
                last_modified = datetime.fromisoformat(ts_str)

                # Ensure timezone-aware comparison
                if last_modified.tzinfo is None:
                    last_modified = last_modified.replace(tzinfo=timezone.utc)

                if last_modified < cutoff:
                    to_delete.append(export)
                    stats["ttl_pruned"] += 1
                    stats["bytes_freed"] += export.get("size", 0)

        # Apply count-based pruning (keep N most recent)
        if self.max_artifacts is not None and len(exports) > self.max_artifacts:
            # Exports already sorted by last_modified descending
            # Keep first max_artifacts, delete the rest
            excess = exports[self.max_artifacts :]

            for export in excess:
                if export not in to_delete:
                    to_delete.append(export)
                    stats["max_n_pruned"] += 1
                    stats["bytes_freed"] += export.get("size", 0)

        stats["total_deleted"] = len(to_delete)

        # Delete exports
        if to_delete:
            if dry_run:
                print(
                    f"\n[DRY-RUN] Retention policy would delete {len(to_delete)} exports:"
                )
                for export in to_delete[:10]:  # Show first 10
                    print(f"  - {export['key']} ({export.get('size', 0):,} bytes)")
                if len(to_delete) > 10:
                    print(f"  ... and {len(to_delete) - 10} more")
            else:
                print(
                    f"\nApplying retention policy: deleting {len(to_delete)} exports..."
                )
                deleted_count = 0

                for export in to_delete:
                    if destination.delete(export["key"], dry_run=False):
                        deleted_count += 1

                print(
                    f"✅ Deleted {deleted_count} exports ({stats['bytes_freed']:,} bytes freed)"
                )
        else:
            if not dry_run:
                print("No exports meet retention criteria for deletion")

        return stats

    def __repr__(self) -> str:
        """String representation of retention policy."""
        parts = []
        if self.ttl_days is not None:
            parts.append(f"ttl={self.ttl_days}d")
        if self.max_artifacts is not None:
            parts.append(f"max_n={self.max_artifacts}")
        return f"RetentionPolicy({', '.join(parts)})"
