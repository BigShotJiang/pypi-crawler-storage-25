"""
Base destination interface for telemetry exports.

Defines abstract interface for export destinations (local, GitHub Actions, S3, GCS, Azure)
with manifest generation, idempotent keys, and checksum validation.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.1)
"""

import hashlib
import json
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ExportManifest:
    """
    Export manifest metadata for governance audit trail.

    Attributes:
        schema_version: Manifest schema version (e.g., "1.0.0")
        export_timestamp: ISO 8601 timestamp of export
        time_window_start: Start of export time window (ISO 8601)
        time_window_end: End of export time window (ISO 8601)
        governance_id: Optional governance ID filter
        event_count: Number of events exported
        format: Export format (json/csv/parquet)
        compressed: Whether export is gzipped
        file_size_bytes: Size of exported file in bytes
        file_checksum_sha256: SHA256 checksum of exported file
        summary_file: Optional summary file path
        summary_checksum_sha256: Optional SHA256 checksum of summary file
        filters: Applied filters (module, event_type, policy_only)
    """

    schema_version: str
    export_timestamp: str
    time_window_start: Optional[str]
    time_window_end: Optional[str]
    governance_id: Optional[str]
    event_count: int
    format: str
    compressed: bool
    file_size_bytes: int
    file_checksum_sha256: str
    summary_file: Optional[str] = None
    summary_checksum_sha256: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert manifest to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}

    def to_json(self, indent: int = 2) -> str:
        """Serialize manifest to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)


class BaseDestination(ABC):
    """
    Abstract base class for export destinations.

    All destinations (local, GitHub, S3, GCS, Azure) must implement
    upload, list, and delete methods with idempotent key support.
    """

    def __init__(self, prefix: str = "telemetry-exports"):
        """
        Initialize destination with optional prefix.

        Args:
            prefix: Base path prefix for all exports
        """
        self.prefix = prefix

    @abstractmethod
    def upload(
        self, file_path: Path, manifest: ExportManifest, dry_run: bool = False
    ) -> str:
        """
        Upload file to destination with manifest and idempotent key.

        Args:
            file_path: Local file path to upload
            manifest: Export manifest metadata
            dry_run: If True, log actions without uploading

        Returns:
            Destination key/URL for uploaded file

        Raises:
            IOError: If upload fails
        """
        pass

    @abstractmethod
    def list(
        self, date_prefix: Optional[str] = None, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        List exports at destination.

        Args:
            date_prefix: Optional date prefix filter (YYYY/MM/DD)
            limit: Maximum number of results to return

        Returns:
            List of export metadata dictionaries with keys:
            - key: Destination key/path
            - size: File size in bytes
            - last_modified: ISO 8601 timestamp
            - checksum: Optional SHA256 checksum
        """
        pass

    @abstractmethod
    def delete(self, key: str, dry_run: bool = False) -> bool:
        """
        Delete export from destination.

        Args:
            key: Destination key/path to delete
            dry_run: If True, log actions without deleting

        Returns:
            True if deleted (or would be deleted in dry-run), False otherwise
        """
        pass

    def generate_idempotent_key(
        self,
        timestamp: datetime,
        governance_id: Optional[str],
        format: str,
        compressed: bool,
    ) -> str:
        """
        Generate idempotent key for export deduplication.

        Pattern: prefix/YYYY/MM/DD/<hash>.<ext>[.gz]
        Hash: SHA256(timestamp + governance_id + format)[:8]

        Args:
            timestamp: Export timestamp
            governance_id: Optional governance ID
            format: Export format (json/csv/parquet)
            compressed: Whether export is compressed

        Returns:
            Idempotent key string

        Example:
            telemetry-exports/2025/11/14/a1b2c3d4.json.gz
        """
        # Generate hash from identifying attributes
        hash_input = f"{timestamp.isoformat()}{governance_id or ''}{format}"
        hash_digest = hashlib.sha256(hash_input.encode()).hexdigest()[:8]

        # Date-based partitioning
        date_path = timestamp.strftime("%Y/%m/%d")

        # Extension with optional compression
        ext = f".{format}"
        if compressed:
            ext += ".gz"

        return f"{self.prefix}/{date_path}/{hash_digest}{ext}"

    @staticmethod
    def compute_checksum(file_path: Path) -> str:
        """
        Compute SHA256 checksum of file.

        Args:
            file_path: Path to file

        Returns:
            Hexadecimal SHA256 checksum string
        """
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    def write_manifest(
        self, manifest: ExportManifest, manifest_path: Path, write_sidecar: bool = True
    ) -> Path:
        """
        Write manifest JSON and optional SHA256 sidecar.

        Args:
            manifest: Export manifest to write
            manifest_path: Target path for manifest.json
            write_sidecar: If True, also write .sha256 sidecar file

        Returns:
            Path to written manifest file
        """
        # Write manifest JSON
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        with open(manifest_path, "w", encoding="utf-8") as f:
            f.write(manifest.to_json())

        # Write SHA256 sidecar if requested
        # Sidecar contains the export file's checksum from the manifest
        if write_sidecar and manifest.file_checksum_sha256:
            sidecar_path = manifest_path.with_suffix(".json.sha256")
            # Use the export file's checksum stored in the manifest
            with open(sidecar_path, "w", encoding="utf-8") as f:
                # Format: <checksum>  <manifest_filename>\n
                f.write(f"{manifest.file_checksum_sha256}  {manifest_path.name}\n")

        return manifest_path
