"""
AWS S3 destination for telemetry exports.

Uploads exports to S3 with idempotent keys and manifest metadata.
Falls back to local storage if boto3 not installed.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.4)
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import BaseDestination, ExportManifest
from .local import LocalDestination

try:
    import boto3
    from botocore.exceptions import ClientError

    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False


class S3Destination(BaseDestination):
    """
    AWS S3 destination for telemetry exports.

    Features:
    - Idempotent key-based storage (bucket/prefix/YYYY/MM/DD/<hash>.<ext>)
    - Manifest + SHA256 checksum as S3 metadata
    - Server-side encryption (SSE-S3)
    - Graceful fallback to local if boto3 unavailable

    Requires:
        boto3: pip install boto3
    """

    def __init__(
        self,
        bucket: str,
        prefix: str = "telemetry-exports",
        region: Optional[str] = None,
        fallback_dir: Optional[Path] = None,
    ):
        """
        Initialize S3 destination.

        Args:
            bucket: S3 bucket name
            prefix: Prefix for export paths
            region: AWS region (default: use boto3 default)
            fallback_dir: Local fallback if boto3 unavailable
        """
        super().__init__(prefix=prefix)
        self.bucket = bucket
        self.region = region

        if not BOTO3_AVAILABLE:
            print("⚠️  boto3 not installed. Falling back to local storage.")
            print("   Install with: pip install boto3")
            fallback_path = fallback_dir or Path.cwd() / "telemetry-artifacts"
            self.s3_client = None
            self.fallback = LocalDestination(base_dir=fallback_path, prefix=prefix)
        else:
            self.s3_client = boto3.client("s3", region_name=region)
            self.fallback = None

    def upload(
        self, file_path: Path, manifest: ExportManifest, dry_run: bool = False
    ) -> str:
        """
        Upload file to S3 with manifest metadata.

        Args:
            file_path: Local file path to upload
            manifest: Export manifest metadata
            dry_run: If True, log actions without uploading

        Returns:
            S3 key (s3://bucket/key format)
        """
        # Fallback to local if boto3 unavailable
        if not BOTO3_AVAILABLE or self.fallback:
            return self.fallback.upload(file_path, manifest, dry_run=dry_run)

        # Generate idempotent key
        timestamp = datetime.fromisoformat(
            manifest.export_timestamp.replace("Z", "+00:00")
        )
        key = self.generate_idempotent_key(
            timestamp=timestamp,
            governance_id=manifest.governance_id,
            format=manifest.format,
            compressed=manifest.compressed,
        )

        s3_uri = f"s3://{self.bucket}/{key}"

        if dry_run:
            print(f"[DRY-RUN] Would upload {file_path} → {s3_uri}")
            return s3_uri

        # Upload file with metadata
        extra_args = {
            "ServerSideEncryption": "AES256",
            "Metadata": {
                "governance-id": manifest.governance_id or "none",
                "event-count": str(manifest.event_count),
                "checksum-sha256": manifest.file_checksum_sha256,
                "export-timestamp": manifest.export_timestamp,
            },
        }

        self.s3_client.upload_file(
            str(file_path), self.bucket, key, ExtraArgs=extra_args
        )

        # Upload manifest as separate object
        manifest_key = key.replace(f".{manifest.format}", "_manifest.json")
        self.s3_client.put_object(
            Bucket=self.bucket,
            Key=manifest_key,
            Body=manifest.to_json().encode("utf-8"),
            ServerSideEncryption="AES256",
            ContentType="application/json",
        )

        print(f"✅ Uploaded to S3: {s3_uri}")
        return s3_uri

    def list(
        self, date_prefix: Optional[str] = None, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """List exports in S3."""
        if not BOTO3_AVAILABLE or self.fallback:
            return self.fallback.list(date_prefix=date_prefix, limit=limit)

        prefix = f"{self.prefix}/"
        if date_prefix:
            prefix += f"{date_prefix}/"

        results = []
        paginator = self.s3_client.get_paginator("list_objects_v2")

        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                # Skip manifests
                if "_manifest" in obj["Key"]:
                    continue

                results.append(
                    {
                        "key": f"s3://{self.bucket}/{obj['Key']}",
                        "size": obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                        "checksum": obj.get("ETag", "").strip('"'),
                    }
                )

        results.sort(key=lambda x: x["last_modified"], reverse=True)

        if limit:
            results = results[:limit]

        return results

    def delete(self, key: str, dry_run: bool = False) -> bool:
        """Delete export from S3."""
        if not BOTO3_AVAILABLE or self.fallback:
            return self.fallback.delete(key, dry_run=dry_run)

        # Extract key from s3:// URI if present
        s3_key = key.replace(f"s3://{self.bucket}/", "")

        if dry_run:
            print(f"[DRY-RUN] Would delete s3://{self.bucket}/{s3_key}")
            return True

        try:
            self.s3_client.delete_object(Bucket=self.bucket, Key=s3_key)

            # Also delete manifest
            manifest_key = (
                s3_key.replace(".json", "_manifest.json")
                .replace(".csv", "_manifest.json")
                .replace(".parquet", "_manifest.json")
            )
            self.s3_client.delete_object(Bucket=self.bucket, Key=manifest_key)

            return True
        except ClientError:
            return False
