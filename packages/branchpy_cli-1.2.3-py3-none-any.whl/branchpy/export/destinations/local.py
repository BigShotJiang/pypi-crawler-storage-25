"""
Local filesystem destination for telemetry exports.

Implements idempotent key-based storage with manifest generation and SHA256 sidecars.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.2)
"""

import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import BaseDestination, ExportManifest


class LocalDestination(BaseDestination):
    """
    Local filesystem destination for telemetry exports.

    Features:
    - Idempotent key-based storage (prefix/YYYY/MM/DD/<hash>.<ext>[.gz])
    - Manifest JSON + SHA256 sidecar per export
    - List exports by date prefix
    - Dry-run support for testing

    Storage layout:
        <base_dir>/<prefix>/YYYY/MM/DD/
            <hash>.json.gz          # Compressed events
            <hash>_manifest.json    # Export manifest
            <hash>_manifest.json.sha256  # Manifest checksum
    """

    def __init__(self, base_dir: Path, prefix: str = "telemetry-exports"):
        """
        Initialize local destination.

        Args:
            base_dir: Base directory for local storage
            prefix: Prefix for export paths (default: "telemetry-exports")
        """
        super().__init__(prefix=prefix)
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def upload(
        self, file_path: Path, manifest: ExportManifest, dry_run: bool = False
    ) -> str:
        """
        Upload file to local destination with manifest.

        Copies file to idempotent key location, writes manifest + SHA256 sidecar.

        Args:
            file_path: Local file path to upload
            manifest: Export manifest metadata
            dry_run: If True, log actions without copying

        Returns:
            Destination key (relative path from base_dir)

        Raises:
            IOError: If file copy fails
        """
        # Generate idempotent key
        timestamp = datetime.fromisoformat(
            manifest.export_timestamp.replace("Z", "+00:00")
        )
        key = self.generate_idempotent_key(
            timestamp=timestamp,
            governance_id=manifest.governance_id,
            format=manifest.format,
            compressed=manifest.compressed,
        )

        # Compute destination paths
        dest_file = self.base_dir / key
        dest_dir = dest_file.parent

        # Extract hash from key for manifest naming
        hash_part = dest_file.stem.split(".")[0]  # Remove extensions to get hash
        manifest_file = dest_dir / f"{hash_part}_manifest.json"

        if dry_run:
            print(f"[DRY-RUN] Would upload {file_path} → {key}")
            print(f"[DRY-RUN] Would write manifest → {manifest_file}")
            return key

        # Create destination directory
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Copy export file to destination (idempotent - overwrites if exists)
        shutil.copy2(file_path, dest_file)

        # Write manifest with SHA256 sidecar
        self.write_manifest(manifest, manifest_file, write_sidecar=True)

        return key

    def list(
        self, date_prefix: Optional[str] = None, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        List exports in local destination.

        Args:
            date_prefix: Optional date prefix filter (YYYY/MM/DD)
            limit: Maximum number of results to return

        Returns:
            List of export metadata dictionaries sorted by last_modified descending
        """
        search_path = self.base_dir / self.prefix

        if date_prefix:
            # Filter by date prefix (e.g., "2025/11/14")
            search_path = search_path / date_prefix

        if not search_path.exists():
            return []

        # Find all export files (exclude manifests and checksums)
        results = []
        for file_path in search_path.rglob("*"):
            # Skip manifests, checksums, and directories
            if (
                file_path.is_dir()
                or "_manifest" in file_path.name
                or file_path.suffix == ".sha256"
            ):
                continue

            # Compute relative key from base_dir
            key = str(file_path.relative_to(self.base_dir)).replace("\\", "/")

            # Get file stats
            stat = file_path.stat()

            results.append(
                {
                    "key": key,
                    "size": stat.st_size,
                    "last_modified": datetime.fromtimestamp(
                        stat.st_mtime, tz=timezone.utc
                    ).isoformat(),
                    "checksum": (
                        self.compute_checksum(file_path)
                        if file_path.stat().st_size < 100_000_000
                        else None
                    ),  # Skip checksum for large files
                }
            )

        # Sort by last_modified descending
        results.sort(key=lambda x: x["last_modified"], reverse=True)

        # Apply limit if specified
        if limit:
            results = results[:limit]

        return results

    def delete(self, key: str, dry_run: bool = False) -> bool:
        """
        Delete export from local destination.

        Deletes export file, manifest, and SHA256 sidecar.

        Args:
            key: Destination key to delete
            dry_run: If True, log actions without deleting

        Returns:
            True if deleted (or would be deleted in dry-run), False if not found
        """
        file_path = self.base_dir / key

        if not file_path.exists():
            return False

        # Compute manifest and sidecar paths
        dest_dir = file_path.parent
        hash_part = file_path.stem.split(".")[0]
        manifest_file = dest_dir / f"{hash_part}_manifest.json"
        sidecar_file = dest_dir / f"{hash_part}_manifest.json.sha256"

        if dry_run:
            print(f"[DRY-RUN] Would delete {key}")
            if manifest_file.exists():
                print(
                    f"[DRY-RUN] Would delete {manifest_file.relative_to(self.base_dir)}"
                )
            if sidecar_file.exists():
                print(
                    f"[DRY-RUN] Would delete {sidecar_file.relative_to(self.base_dir)}"
                )
            return True

        # Delete files
        file_path.unlink()
        if manifest_file.exists():
            manifest_file.unlink()
        if sidecar_file.exists():
            sidecar_file.unlink()

        # Clean up empty directories
        try:
            dest_dir.rmdir()  # Only removes if empty
        except OSError:
            pass  # Directory not empty, leave it

        return True

    def get_manifest(self, key: str) -> Optional[ExportManifest]:
        """
        Retrieve manifest for export key.

        Args:
            key: Export key

        Returns:
            ExportManifest if found, None otherwise
        """
        file_path = self.base_dir / key
        if not file_path.exists():
            return None

        # Compute manifest path
        dest_dir = file_path.parent
        hash_part = file_path.stem.split(".")[0]
        manifest_file = dest_dir / f"{hash_part}_manifest.json"

        if not manifest_file.exists():
            return None

        # Load and parse manifest
        import json

        with open(manifest_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        return ExportManifest(**data)
