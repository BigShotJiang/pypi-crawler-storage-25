"""
Export destinations module for telemetry exports.

Provides pluggable destination backends for local, GitHub Actions, and cloud storage
with idempotent keys, manifest generation, and retention policies.

Supported Destinations:
- local: Local filesystem storage
- github: GitHub Actions artifacts (with local fallback)
- s3: AWS S3 (requires boto3)
- gcs: Google Cloud Storage (requires google-cloud-storage)
- azure: Azure Blob Storage (requires azure-storage-blob)

Usage:
    from branchpy.export.destinations import get_destination, RetentionPolicy

    # Get destination
    dest = get_destination('local', base_dir=Path('/tmp/exports'))

    # Upload export
    manifest = ExportManifest(...)
    dest.upload(file_path, manifest)

    # Apply retention
    policy = RetentionPolicy(ttl_days=90, max_artifacts=100)
    policy.apply(dest, dry_run=True)

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4)
"""

from pathlib import Path
from typing import Optional, Union

from .azure import AzureDestination
from .base import BaseDestination, ExportManifest
from .gcs import GCSDestination
from .github import GitHubDestination
from .local import LocalDestination
from .retention import RetentionPolicy
from .s3 import S3Destination

__all__ = [
    "BaseDestination",
    "ExportManifest",
    "LocalDestination",
    "GitHubDestination",
    "S3Destination",
    "GCSDestination",
    "AzureDestination",
    "RetentionPolicy",
    "get_destination",
]


def get_destination(dest_type: str, **kwargs) -> BaseDestination:
    """
    Factory function to get destination instance.

    Args:
        dest_type: Destination type ('local', 'github', 's3', 'gcs', 'azure')
        **kwargs: Destination-specific parameters

    Local destination kwargs:
        base_dir: Base directory for storage (Path)
        prefix: Path prefix (str, default: "telemetry-exports")

    GitHub destination kwargs:
        prefix: Path prefix (str, default: "telemetry-exports")
        retention_days: Artifact retention (int, default: 90)
        fallback_dir: Local fallback directory (Optional[Path])

    S3 destination kwargs:
        bucket: S3 bucket name (str, required)
        prefix: Path prefix (str, default: "telemetry-exports")
        region: AWS region (Optional[str])
        fallback_dir: Local fallback if boto3 unavailable (Optional[Path])

    GCS destination kwargs:
        bucket: GCS bucket name (str, required)
        prefix: Path prefix (str, default: "telemetry-exports")
        project: GCP project ID (Optional[str])
        fallback_dir: Local fallback if SDK unavailable (Optional[Path])

    Azure destination kwargs:
        container: Azure container name (str, required)
        connection_string: Azure connection string (Optional[str])
        account_url: Azure account URL (Optional[str])
        prefix: Path prefix (str, default: "telemetry-exports")
        fallback_dir: Local fallback if SDK unavailable (Optional[Path])

    Returns:
        Destination instance

    Raises:
        ValueError: If dest_type is not supported

    Examples:
        >>> # Local destination
        >>> dest = get_destination('local', base_dir=Path('/tmp/exports'))

        >>> # S3 destination with fallback
        >>> dest = get_destination('s3', bucket='my-bucket', region='us-east-1')

        >>> # GitHub Actions destination
        >>> dest = get_destination('github', retention_days=90)
    """
    dest_type = dest_type.lower()

    destinations = {
        "local": LocalDestination,
        "github": GitHubDestination,
        "s3": S3Destination,
        "gcs": GCSDestination,
        "azure": AzureDestination,
    }

    if dest_type not in destinations:
        raise ValueError(
            f"Unsupported destination type: {dest_type}. "
            f"Supported types: {', '.join(destinations.keys())}"
        )

    destination_class = destinations[dest_type]

    # Handle different constructor signatures
    if dest_type == "local":
        base_dir = kwargs.get("base_dir")
        if not base_dir:
            base_dir = Path.cwd() / "telemetry-artifacts"
        return destination_class(
            base_dir=Path(base_dir), prefix=kwargs.get("prefix", "telemetry-exports")
        )

    elif dest_type == "github":
        return destination_class(
            prefix=kwargs.get("prefix", "telemetry-exports"),
            retention_days=kwargs.get("retention_days", 90),
            fallback_dir=kwargs.get("fallback_dir"),
        )

    elif dest_type == "s3":
        bucket = kwargs.get("bucket")
        if not bucket:
            raise ValueError("S3 destination requires 'bucket' parameter")

        return destination_class(
            bucket=bucket,
            prefix=kwargs.get("prefix", "telemetry-exports"),
            region=kwargs.get("region"),
            fallback_dir=kwargs.get("fallback_dir"),
        )

    elif dest_type == "gcs":
        bucket = kwargs.get("bucket")
        if not bucket:
            raise ValueError("GCS destination requires 'bucket' parameter")

        return destination_class(
            bucket=bucket,
            prefix=kwargs.get("prefix", "telemetry-exports"),
            project=kwargs.get("project"),
            fallback_dir=kwargs.get("fallback_dir"),
        )

    elif dest_type == "azure":
        container = kwargs.get("container")
        if not container:
            raise ValueError("Azure destination requires 'container' parameter")

        return destination_class(
            container=container,
            connection_string=kwargs.get("connection_string"),
            account_url=kwargs.get("account_url"),
            prefix=kwargs.get("prefix", "telemetry-exports"),
            fallback_dir=kwargs.get("fallback_dir"),
        )

    # Should never reach here
    raise ValueError(f"Unknown destination type: {dest_type}")
