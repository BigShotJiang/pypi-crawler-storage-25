"""
GitHub Actions artifacts destination for telemetry exports.

Uploads exports to GitHub Actions workflow artifacts with configurable retention.
Falls back to local storage if not running in GitHub Actions environment.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.3)
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import BaseDestination, ExportManifest
from .local import LocalDestination


class GitHubDestination(BaseDestination):
    """
    GitHub Actions artifacts destination for telemetry exports.

    Features:
    - Uploads to GitHub Actions artifacts with retention-days
    - Automatic fallback to local storage if not in CI
    - Uses upload-artifact@v4 action via subprocess
    - Idempotent keys for deduplication

    Environment variables:
        GITHUB_ACTIONS: Set to "true" when running in GitHub Actions
        GITHUB_WORKSPACE: Workspace directory path
    """

    def __init__(
        self,
        prefix: str = "telemetry-exports",
        retention_days: int = 90,
        fallback_dir: Optional[Path] = None,
    ):
        """
        Initialize GitHub destination.

        Args:
            prefix: Prefix for export paths
            retention_days: Artifact retention in days (default: 90)
            fallback_dir: Local fallback directory if not in CI
        """
        super().__init__(prefix=prefix)
        self.retention_days = retention_days
        self.is_github_actions = os.getenv("GITHUB_ACTIONS") == "true"

        # Fallback to local destination if not in GitHub Actions
        if not self.is_github_actions:
            fallback_path = fallback_dir or Path.cwd() / "telemetry-artifacts"
            self.fallback = LocalDestination(base_dir=fallback_path, prefix=prefix)
        else:
            self.fallback = None

    def upload(
        self, file_path: Path, manifest: ExportManifest, dry_run: bool = False
    ) -> str:
        """
        Upload file to GitHub Actions artifacts.

        Falls back to local storage if not in CI environment.

        Args:
            file_path: Local file path to upload
            manifest: Export manifest metadata
            dry_run: If True, log actions without uploading

        Returns:
            Destination key or local path
        """
        # Fallback to local if not in GitHub Actions
        if not self.is_github_actions:
            if self.fallback:
                print("⚠️  Not in GitHub Actions environment. Using local fallback.")
                return self.fallback.upload(file_path, manifest, dry_run=dry_run)
            else:
                raise RuntimeError(
                    "GitHub Actions environment not detected and no fallback configured"
                )

        # Generate idempotent key
        timestamp = datetime.fromisoformat(
            manifest.export_timestamp.replace("Z", "+00:00")
        )
        key = self.generate_idempotent_key(
            timestamp=timestamp,
            governance_id=manifest.governance_id,
            format=manifest.format,
            compressed=manifest.compressed,
        )

        if dry_run:
            print(f"[DRY-RUN] Would upload {file_path} → GitHub artifact: {key}")
            return key

        # In actual GitHub Actions workflow, artifact upload is handled by workflow step
        # This method prepares files in the expected location for the workflow to upload
        workspace = Path(os.getenv("GITHUB_WORKSPACE", "."))
        artifact_dir = workspace / "telemetry-artifacts"
        artifact_dir.mkdir(parents=True, exist_ok=True)

        # Copy file to artifact directory with idempotent key structure
        dest_file = artifact_dir / Path(key).name
        import shutil

        shutil.copy2(file_path, dest_file)

        # Write manifest in artifact directory
        manifest_file = dest_file.with_name(
            dest_file.stem.split(".")[0] + "_manifest.json"
        )
        self.write_manifest(manifest, manifest_file, write_sidecar=True)

        print(f"✅ Prepared for GitHub artifact upload: {dest_file.name}")
        print(f"   Retention: {self.retention_days} days")

        return key

    def list(
        self, date_prefix: Optional[str] = None, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        List exports in GitHub artifacts.

        Falls back to local listing if not in CI.

        Note: GitHub Actions API integration requires gh CLI or REST API calls.
        This implementation uses fallback for now.
        """
        if self.fallback:
            return self.fallback.list(date_prefix=date_prefix, limit=limit)

        # TODO: Implement GitHub API artifact listing
        print("⚠️  GitHub artifact listing requires API integration")
        return []

    def delete(self, key: str, dry_run: bool = False) -> bool:
        """
        Delete export from GitHub artifacts.

        Falls back to local deletion if not in CI.

        Note: GitHub Actions API integration required for artifact deletion.
        """
        if self.fallback:
            return self.fallback.delete(key, dry_run=dry_run)

        # TODO: Implement GitHub API artifact deletion
        print("⚠️  GitHub artifact deletion requires API integration")
        return False
