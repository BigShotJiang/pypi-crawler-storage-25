"""
Google Cloud Storage destination for telemetry exports.

Uploads exports to GCS with idempotent keys and manifest metadata.
Falls back to local storage if google-cloud-storage not installed.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.4)
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import BaseDestination, ExportManifest
from .local import LocalDestination

try:
    from google.api_core import exceptions
    from google.cloud import storage

    GCS_AVAILABLE = True
except ImportError:
    GCS_AVAILABLE = False


class GCSDestination(BaseDestination):
    """
    Google Cloud Storage destination for telemetry exports.

    Features:
    - Idempotent key-based storage
    - Manifest + SHA256 as object metadata
    - Graceful fallback to local if google-cloud-storage unavailable

    Requires:
        google-cloud-storage: pip install google-cloud-storage
    """

    def __init__(
        self,
        bucket: str,
        prefix: str = "telemetry-exports",
        project: Optional[str] = None,
        fallback_dir: Optional[Path] = None,
    ):
        """
        Initialize GCS destination.

        Args:
            bucket: GCS bucket name
            prefix: Prefix for export paths
            project: GCP project ID (optional)
            fallback_dir: Local fallback if SDK unavailable
        """
        super().__init__(prefix=prefix)
        self.bucket_name = bucket
        self.project = project

        if not GCS_AVAILABLE:
            print(
                "⚠️  google-cloud-storage not installed. Falling back to local storage."
            )
            print("   Install with: pip install google-cloud-storage")
            fallback_path = fallback_dir or Path.cwd() / "telemetry-artifacts"
            self.gcs_client = None
            self.bucket = None
            self.fallback = LocalDestination(base_dir=fallback_path, prefix=prefix)
        else:
            self.gcs_client = storage.Client(project=project)
            self.bucket = self.gcs_client.bucket(bucket)
            self.fallback = None

    def upload(
        self, file_path: Path, manifest: ExportManifest, dry_run: bool = False
    ) -> str:
        """Upload file to GCS with manifest metadata."""
        if not GCS_AVAILABLE or self.fallback:
            return self.fallback.upload(file_path, manifest, dry_run=dry_run)

        timestamp = datetime.fromisoformat(
            manifest.export_timestamp.replace("Z", "+00:00")
        )
        key = self.generate_idempotent_key(
            timestamp=timestamp,
            governance_id=manifest.governance_id,
            format=manifest.format,
            compressed=manifest.compressed,
        )

        gcs_uri = f"gs://{self.bucket_name}/{key}"

        if dry_run:
            print(f"[DRY-RUN] Would upload {file_path} → {gcs_uri}")
            return gcs_uri

        # Upload file
        blob = self.bucket.blob(key)
        blob.metadata = {
            "governance-id": manifest.governance_id or "none",
            "event-count": str(manifest.event_count),
            "checksum-sha256": manifest.file_checksum_sha256,
            "export-timestamp": manifest.export_timestamp,
        }
        blob.upload_from_filename(str(file_path))

        # Upload manifest
        manifest_key = key.replace(f".{manifest.format}", "_manifest.json")
        manifest_blob = self.bucket.blob(manifest_key)
        manifest_blob.upload_from_string(
            manifest.to_json(), content_type="application/json"
        )

        print(f"✅ Uploaded to GCS: {gcs_uri}")
        return gcs_uri

    def list(
        self, date_prefix: Optional[str] = None, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """List exports in GCS."""
        if not GCS_AVAILABLE or self.fallback:
            return self.fallback.list(date_prefix=date_prefix, limit=limit)

        prefix = f"{self.prefix}/"
        if date_prefix:
            prefix += f"{date_prefix}/"

        results = []
        for blob in self.bucket.list_blobs(prefix=prefix):
            if "_manifest" in blob.name:
                continue

            results.append(
                {
                    "key": f"gs://{self.bucket_name}/{blob.name}",
                    "size": blob.size,
                    "last_modified": blob.updated.isoformat(),
                    "checksum": blob.md5_hash,
                }
            )

        results.sort(key=lambda x: x["last_modified"], reverse=True)

        if limit:
            results = results[:limit]

        return results

    def delete(self, key: str, dry_run: bool = False) -> bool:
        """Delete export from GCS."""
        if not GCS_AVAILABLE or self.fallback:
            return self.fallback.delete(key, dry_run=dry_run)

        gcs_key = key.replace(f"gs://{self.bucket_name}/", "")

        if dry_run:
            print(f"[DRY-RUN] Would delete gs://{self.bucket_name}/{gcs_key}")
            return True

        try:
            blob = self.bucket.blob(gcs_key)
            blob.delete()

            # Delete manifest
            manifest_key = (
                gcs_key.replace(".json", "_manifest.json")
                .replace(".csv", "_manifest.json")
                .replace(".parquet", "_manifest.json")
            )
            self.bucket.blob(manifest_key).delete()

            return True
        except exceptions.NotFound:
            return False
