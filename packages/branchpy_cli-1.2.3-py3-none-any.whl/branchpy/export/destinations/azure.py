"""
Azure Blob Storage destination for telemetry exports.

Uploads exports to Azure Blob Storage with idempotent keys and manifest metadata.
Falls back to local storage if azure-storage-blob not installed.

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Task 4.4)
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import BaseDestination, ExportManifest
from .local import LocalDestination

try:
    from azure.core.exceptions import ResourceNotFoundError
    from azure.storage.blob import BlobServiceClient

    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False


class AzureDestination(BaseDestination):
    """
    Azure Blob Storage destination for telemetry exports.

    Features:
    - Idempotent key-based storage
    - Manifest + SHA256 as blob metadata
    - Graceful fallback to local if azure-storage-blob unavailable

    Requires:
        azure-storage-blob: pip install azure-storage-blob
    """

    def __init__(
        self,
        container: str,
        connection_string: Optional[str] = None,
        account_url: Optional[str] = None,
        prefix: str = "telemetry-exports",
        fallback_dir: Optional[Path] = None,
    ):
        """
        Initialize Azure destination.

        Args:
            container: Azure blob container name
            connection_string: Azure storage connection string
            account_url: Azure storage account URL (alternative to connection_string)
            prefix: Prefix for export paths
            fallback_dir: Local fallback if SDK unavailable
        """
        super().__init__(prefix=prefix)
        self.container_name = container

        if not AZURE_AVAILABLE:
            print("⚠️  azure-storage-blob not installed. Falling back to local storage.")
            print("   Install with: pip install azure-storage-blob")
            fallback_path = fallback_dir or Path.cwd() / "telemetry-artifacts"
            self.blob_service_client = None
            self.container_client = None
            self.fallback = LocalDestination(base_dir=fallback_path, prefix=prefix)
        else:
            if connection_string:
                self.blob_service_client = BlobServiceClient.from_connection_string(
                    connection_string
                )
            elif account_url:
                self.blob_service_client = BlobServiceClient(account_url=account_url)
            else:
                raise ValueError(
                    "Either connection_string or account_url must be provided"
                )

            self.container_client = self.blob_service_client.get_container_client(
                container
            )
            self.fallback = None

    def upload(
        self, file_path: Path, manifest: ExportManifest, dry_run: bool = False
    ) -> str:
        """Upload file to Azure Blob Storage with manifest metadata."""
        if not AZURE_AVAILABLE or self.fallback:
            return self.fallback.upload(file_path, manifest, dry_run=dry_run)

        timestamp = datetime.fromisoformat(
            manifest.export_timestamp.replace("Z", "+00:00")
        )
        key = self.generate_idempotent_key(
            timestamp=timestamp,
            governance_id=manifest.governance_id,
            format=manifest.format,
            compressed=manifest.compressed,
        )

        azure_uri = (
            f"https://<account>.blob.core.windows.net/{self.container_name}/{key}"
        )

        if dry_run:
            print(f"[DRY-RUN] Would upload {file_path} → {azure_uri}")
            return azure_uri

        # Upload file with metadata
        blob_client = self.container_client.get_blob_client(key)
        with open(file_path, "rb") as f:
            blob_client.upload_blob(
                f,
                metadata={
                    "governance_id": manifest.governance_id or "none",
                    "event_count": str(manifest.event_count),
                    "checksum_sha256": manifest.file_checksum_sha256,
                    "export_timestamp": manifest.export_timestamp,
                },
                overwrite=True,
            )

        # Upload manifest
        manifest_key = key.replace(f".{manifest.format}", "_manifest.json")
        manifest_blob = self.container_client.get_blob_client(manifest_key)
        manifest_blob.upload_blob(
            manifest.to_json(),
            content_settings={"content_type": "application/json"},
            overwrite=True,
        )

        print(f"✅ Uploaded to Azure: {azure_uri}")
        return azure_uri

    def list(
        self, date_prefix: Optional[str] = None, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """List exports in Azure Blob Storage."""
        if not AZURE_AVAILABLE or self.fallback:
            return self.fallback.list(date_prefix=date_prefix, limit=limit)

        name_starts_with = f"{self.prefix}/"
        if date_prefix:
            name_starts_with += f"{date_prefix}/"

        results = []
        for blob in self.container_client.list_blobs(name_starts_with=name_starts_with):
            if "_manifest" in blob.name:
                continue

            results.append(
                {
                    "key": f"azure://{self.container_name}/{blob.name}",
                    "size": blob.size,
                    "last_modified": blob.last_modified.isoformat(),
                    "checksum": blob.etag,
                }
            )

        results.sort(key=lambda x: x["last_modified"], reverse=True)

        if limit:
            results = results[:limit]

        return results

    def delete(self, key: str, dry_run: bool = False) -> bool:
        """Delete export from Azure Blob Storage."""
        if not AZURE_AVAILABLE or self.fallback:
            return self.fallback.delete(key, dry_run=dry_run)

        azure_key = key.replace(f"azure://{self.container_name}/", "")

        if dry_run:
            print(f"[DRY-RUN] Would delete azure://{self.container_name}/{azure_key}")
            return True

        try:
            blob_client = self.container_client.get_blob_client(azure_key)
            blob_client.delete_blob()

            # Delete manifest
            manifest_key = (
                azure_key.replace(".json", "_manifest.json")
                .replace(".csv", "_manifest.json")
                .replace(".parquet", "_manifest.json")
            )
            self.container_client.get_blob_client(manifest_key).delete_blob()

            return True
        except ResourceNotFoundError:
            return False
