# branchpy/update_manager.py
from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

# If you use pynacl: Ed25519 verification
try:
    from nacl.exceptions import BadSignatureError  # type: ignore
    from nacl.signing import VerifyKey  # type: ignore
except Exception:  # no NaCl installed in dev? fine while paused
    VerifyKey = None  # type: ignore
    BadSignatureError = Exception  # type: ignore

RELEASE_ROOT = os.getenv(
    "BRANCHPY_RELEASE_ROOT",
    "https://raw.githubusercontent.com/BranchPy/branchpy-releases/main",
)
UPDATES_DIR = Path.home() / ".branchpy" / "updates"  # per-user
STATE_FILE = UPDATES_DIR / "pending_update.json"

# embed multiple pubkeys for rotation
PUBKEYS_B64 = {
    "2025-01": "BASE64_PUBLIC_KEY_A",
    "2026-01": "BASE64_PUBLIC_KEY_B",
}


def utcnow_iso() -> str:
    """Return current UTC time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


def err(code: str, meta: dict | None = None):
    """Create an exception with error code and metadata."""
    msg = f"{code}: {meta}" if meta else code
    return Exception(msg)


def exe_suffix() -> str:
    return ".exe" if os.name == "nt" else ""


def _http_get_json(url: str) -> dict:
    # minimal stdlib client to avoid deps; replace with requests if you already depend on it
    import json as _json
    import urllib.request

    try:
        with urllib.request.urlopen(url, timeout=20) as r:
            return _json.loads(r.read().decode("utf-8"))
    except Exception as e:
        raise err("E_NET_FAIL", meta={"URL": url, "DETAIL": str(e)})


def _http_download(url: str, dest: Path) -> Path:
    import urllib.request

    try:
        with urllib.request.urlopen(url, timeout=60) as r, open(dest, "wb") as f:
            shutil.copyfileobj(r, f)
        return dest
    except Exception as e:
        raise err("E_NET_FAIL", meta={"URL": url, "DETAIL": str(e)})


def should_check(cfg, now_iso: str | None = None) -> bool:
    # Updater paused by default unless explicitly enabled
    if os.getenv("BRANCHPY_UPDATE_DISABLE") != "1":
        return False
    last = cfg.update_cfg.get("last_check")
    if not last:
        return True
    from datetime import datetime, timezone

    last_dt = datetime.fromisoformat(last.replace("Z", "")).replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - last_dt).days >= int(
        cfg.update_cfg["check_interval_days"]
    )


def fetch_manifest(channel: str) -> dict:
    return _http_get_json(f"{RELEASE_ROOT}/releases/{channel}/releases.json")


def needs_update(local_ver: str, remote_ver: str) -> bool:
    from packaging.version import Version

    return Version(remote_ver) > Version(local_ver)


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_binary(file_path: Path, sha256_expected: str, sig_b64: str) -> None:
    # Paused/dev mode: skip verification entirely if NaCl is not available
    if VerifyKey is None:
        return

    if sha256_file(file_path) != sha256_expected.lower():
        raise err("E_SIG_FAIL", meta={"REASON": "Checksum mismatch"})

    sig = base64.b64decode(sig_b64)
    payload = file_path.read_bytes()
    for kid, key_b64 in PUBKEYS_B64.items():
        try:
            VerifyKey(base64.b64decode(key_b64)).verify(payload, sig)
            return
        except BadSignatureError:
            continue
    raise err("E_SIG_FAIL", meta={"REASON": "Detached signature invalid"})


def stage_update(tmp_bin: Path, version: str, current_bin: Path) -> Path:
    target_dir = UPDATES_DIR / version
    target_dir.mkdir(parents=True, exist_ok=True)
    staged = target_dir / f"branchpy{exe_suffix()}"
    shutil.copy2(tmp_bin, staged)
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(
        json.dumps(
            {
                "from": str(current_bin),
                "to": str(staged),
                "backup": f"{current_bin}.old",
                "version": version,
                "created_at": utcnow_iso(),
            },
            indent=2,
        )
    )
    return staged


def attempt_atomic_swap() -> bool:
    if not STATE_FILE.exists():
        return False
    s = json.loads(STATE_FILE.read_text())
    src, dst, bak = Path(s["from"]), Path(s["to"]), Path(s["backup"])
    try:
        # do swap before Python imports lock the file (call from bootstrap)
        if bak.exists():
            bak.unlink(missing_ok=True)
        src.rename(bak)  # may fail on Windows if in-use (call early!)
        dst.replace(src)  # atomic on same FS
        STATE_FILE.unlink(missing_ok=True)
        # keep .old until new binary runs successfully (choose where to clean later)
        return True
    except OSError as e:
        # rollback
        try:
            if bak.exists() and not src.exists():
                bak.rename(src)
        finally:
            raise err("E_PERM_DENIED", meta={"DETAIL": str(e)})


# ---------------------------------------------------------------------------
# PyPI update nudge  ([3/11] CLI update nudge)
# ---------------------------------------------------------------------------
_PYPI_NUDGE_CACHE = UPDATES_DIR / "pypi_nudge_cache.json"
_PYPI_URL = "https://pypi.org/pypi/branchpy-cli/json"
_PYPI_TIMEOUT_S = 3
_PYPI_CACHE_TTL_S = 24 * 60 * 60  # 24 hours


def pypi_nudge(local_version: str) -> None:
    """
    Non-blocking PyPI version check with a 24-hour cache.

    Behaviour:
    - If the cache is fresh and records a newer version: prints a one-line
      nudge to stderr and returns.
    - If the cache is stale or missing: spawns a daemon thread to refresh it
      (result available on the *next* run) and returns immediately — no nudge
      this run.
    - Silent on every error (network, parse, filesystem, version comparison).

    Never raises. Always completes in sub-millisecond time for the caller
    (either a cache-file read or a fire-and-forget thread spawn).
    """
    try:
        import json as _json
        import sys
        import threading
        from datetime import datetime, timezone
        from packaging.version import Version

        now = datetime.now(timezone.utc)

        # ── Step 1: read cache ────────────────────────────────────────────
        latest_version: str | None = None
        if _PYPI_NUDGE_CACHE.exists():
            try:
                cache = _json.loads(_PYPI_NUDGE_CACHE.read_text(encoding="utf-8"))
                checked_at = datetime.fromisoformat(cache["checked_at"])
                if (now - checked_at).total_seconds() < _PYPI_CACHE_TTL_S:
                    latest_version = cache.get("latest_version")
            except Exception:
                pass

        # ── Step 2: stale / missing → background refresh, no nudge now ───
        if latest_version is None:
            def _refresh() -> None:
                try:
                    import json as _j
                    import urllib.request
                    from datetime import datetime, timezone

                    with urllib.request.urlopen(_PYPI_URL, timeout=_PYPI_TIMEOUT_S) as r:
                        data = _j.loads(r.read().decode("utf-8"))
                    ver: str = data["info"]["version"]
                    _PYPI_NUDGE_CACHE.parent.mkdir(parents=True, exist_ok=True)
                    _PYPI_NUDGE_CACHE.write_text(
                        _j.dumps({
                            "checked_at": datetime.now(timezone.utc).isoformat(),
                            "latest_version": ver,
                        }),
                        encoding="utf-8",
                    )
                except Exception:
                    pass

            threading.Thread(target=_refresh, daemon=True).start()
            return  # no nudge this run

        # ── Step 3: compare and nudge if newer ───────────────────────────
        if Version(latest_version) > Version(local_version):
            print(
                f"\n💡 BranchPy {latest_version} is available (you have {local_version})."
                f"\n   Run: python -m pip install --upgrade branchpy-cli\n",
                file=sys.stderr,
            )
    except Exception:
        pass  # never block the CLI


def check_and_stage_if_needed(
    local_version: str, current_bin: Path, verify=True
) -> dict:
    from .config_store import ConfigStore

    cfg_store = ConfigStore()
    cfg_store.load()
    cfg = cfg_store.cfg

    if not should_check(cfg):
        return {"checked": False}
    m = fetch_manifest(cfg.update_cfg.channel)
    remote = m["latest"]["version"]
    if not needs_update(local_version, remote):
        # Update last_check timestamp
        update_cfg = cfg.update_cfg
        update_cfg.last_check = utcnow_iso()
        cfg_store.cfg.update_cfg = update_cfg
        cfg_store.save()
        return {"checked": True, "update_available": False}
    # download → verify → stage
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td) / f"branchpy{exe_suffix()}"
        _http_download(m["latest"]["url"], tmp)
        if verify:
            verify_binary(tmp, m["latest"]["sha256"], m["latest"]["sig"])
        staged = stage_update(tmp, remote, current_bin)
    # Update last_check timestamp
    update_cfg = cfg.update_cfg
    update_cfg.last_check = utcnow_iso()
    cfg_store.cfg.update_cfg = update_cfg
    cfg_store.save()
    return {
        "checked": True,
        "update_available": True,
        "staged": str(staged),
        "version": remote,
    }
