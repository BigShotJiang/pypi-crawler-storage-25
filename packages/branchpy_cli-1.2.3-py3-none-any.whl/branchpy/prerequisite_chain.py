"""
branchpy/prerequisite_chain.py

Prerequisite chain resolution and execution for BranchPy CLI commands.

Mirrors the TypeScript implementation in
vscode-addon/src/services/prerequisiteChain.ts.

Spec: docs/Current Version/Analysis/ARTIFACT_FRESHNESS_SPEC.md §8
"""

from __future__ import annotations

import argparse
import contextlib
import io
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Literal, Optional

from branchpy.artifact_freshness import ArtifactStatus, check_artifact_freshness
from branchpy.run_context import RunContext

# ── Types ──────────────────────────────────────────────────────────────────────

Stage = Literal["analyze", "pilot", "omega"]

CHAIN_BASE: List[Stage] = ["analyze"]
CHAIN_PLUS: List[Stage] = ["analyze", "pilot", "omega"]


@dataclass
class StageStatus:
    stage: Stage
    status: ArtifactStatus
    needs_run: bool


@dataclass
class PrerequisiteResolution:
    chain: List[StageStatus]
    stages_needed: List[Stage]
    overall_state: Literal["all_fresh", "some_stale", "missing"]


class PrerequisiteError(Exception):
    """Raised when a prerequisite stage fails to run."""

    def __init__(self, stage: Stage, cause: Exception) -> None:
        super().__init__(f"[{stage}] {cause}")
        self.stage = stage
        self.cause = cause


# ── Status messages (spec §7.2) ────────────────────────────────────────────────


def get_status_message(overall_state: str) -> str:
    if overall_state == "some_stale":
        return "Project changed — refreshing analysis…"
    if overall_state == "missing":
        return "Running first-time analysis…"
    return "Using cached results"


# ── Resolution ─────────────────────────────────────────────────────────────────


def resolve_prerequisites(
    mode: Literal["base", "plus"],
    project_path: Path,
) -> PrerequisiteResolution:
    """Pure, read-only prerequisite resolution (no side effects).

    mode="base"  → chain = ["analyze"]        (flowchart base)
    mode="plus"  → chain = ["analyze", "pilot", "omega"]  (flowchart-plus)
    """
    chain_stages: List[Stage] = CHAIN_BASE if mode == "base" else CHAIN_PLUS

    chain: List[StageStatus] = []
    stages_needed: List[Stage] = []

    for stage in chain_stages:
        status = check_artifact_freshness(project_path, stage)
        needs_run = status.missing or status.stale
        chain.append(StageStatus(stage=stage, status=status, needs_run=needs_run))
        if needs_run:
            stages_needed.append(stage)

    if any(s.status.missing for s in chain):
        overall_state: Literal["all_fresh", "some_stale", "missing"] = "missing"
    elif stages_needed:
        overall_state = "some_stale"
    else:
        overall_state = "all_fresh"

    return PrerequisiteResolution(
        chain=chain,
        stages_needed=stages_needed,
        overall_state=overall_state,
    )


# ── CLI output helpers ─────────────────────────────────────────────────────────

_STAGE_WIDTH = 8  # column width for stage name


def _print_stage_line(stage: Stage, cached: bool, reason: str = "") -> None:
    label = stage.ljust(_STAGE_WIDTH)
    if cached:
        print(f"  \u2713  {label}  (cached \u2013 project unchanged)")
    else:
        print(f"  \u21bb  {label}  ({reason})")


# ── Execution ─────────────────────────────────────────────────────────────────


def run_prerequisite_chain(
    resolution: PrerequisiteResolution,
    project_path: Path,
    *,
    no_auto_recompute: bool = False,
    run_ctx: Optional[RunContext] = None,
) -> RunContext:
    """Execute the prerequisite chain, running only stages that need it.

    Creates a chain-level :class:`RunContext` (or uses the one supplied) so every
    stage in this chain shares the same ``run_id``.  The context is stamped with
    ``completed_at`` and returned to the caller for further bookkeeping.

    Raises PrerequisiteError if a stage execution fails.
    Raises SystemExit(1) if no_auto_recompute is True and stages are needed.
    """
    from branchpy.artifact_freshness import get_source_revision

    if run_ctx is None:
        run_ctx = RunContext.start(
            project_path,
            source_revision=get_source_revision(project_path),
        )

    if no_auto_recompute and resolution.stages_needed:
        missing_str = ", ".join(resolution.stages_needed)
        print(
            f"[bpy] Error: Prerequisites not met ({missing_str}). "
            "Run them manually or omit --no-auto-recompute.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    for stage_status in resolution.chain:
        stage = stage_status.stage

        if not stage_status.needs_run:
            _print_stage_line(stage, cached=True)
            continue

        reason = (
            "source files changed \u2013 recomputing\u2026"
            if stage_status.status.stale
            else "first-time run\u2026"
        )
        _print_stage_line(stage, cached=False, reason=reason)

        # Revision-drift guard: re-check freshness before running
        current_status = check_artifact_freshness(project_path, stage)
        if current_status.fresh:
            print(
                f"  \u21b3  {stage}: became fresh while waiting, skipping",
                file=sys.stderr,
            )
            continue

        _run_stage(stage, project_path, run_ctx=run_ctx)

    run_ctx.complete()

    # Build and persist InsightSummary after all stages complete (non-fatal)
    try:
        from branchpy.insight_summary import build_and_persist

        _summary, _path = build_and_persist(run_ctx, project_path)
        print(f"  \u2139  insight summary written to: {_path}")
    except Exception:
        pass  # non-fatal; InsightSummary is best-effort

    return run_ctx


def _run_stage(
    stage: Stage,
    project_path: Path,
    *,
    run_ctx: Optional[RunContext] = None,
) -> None:
    """Dispatch a single stage by calling its command's entry point."""
    try:
        if stage == "analyze":
            from branchpy.commands.analyze_cmd import main as _analyze_main

            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                _analyze_main(
                    [str(project_path), "--format=json", "--out=-"],
                    run_ctx=run_ctx,
                )

        elif stage == "pilot":
            from branchpy.commands.stats2_cmd import run as _stats2_run

            ns = argparse.Namespace(
                project=str(project_path),
                max_paths=500,
                max_depth=100,
                output_dir="stats2",
                policy_mode="off",
                policy_json="",
                _run_ctx=run_ctx,
            )
            rc = _stats2_run(ns)
            if rc != 0:
                raise RuntimeError(f"pilot exited with code {rc}")

        elif stage == "omega":
            from branchpy.commands.omega_cmd import run as _omega_run

            ns = argparse.Namespace(
                project_root=str(project_path),
                value_cap=50,
                combo_cap=2000,
                open_after=False,
                no_auto_recompute=True,  # prevent recursion; chain owns prereqs
                _run_ctx=run_ctx,
            )
            rc = _omega_run(ns)
            if rc != 0:
                raise RuntimeError(f"omega exited with code {rc}")

    except SystemExit as exc:
        if exc.code not in (None, 0):
            raise PrerequisiteError(
                stage, RuntimeError(f"Exited with code {exc.code}")
            ) from exc
    except PrerequisiteError:
        raise
    except Exception as exc:
        raise PrerequisiteError(stage, exc) from exc
