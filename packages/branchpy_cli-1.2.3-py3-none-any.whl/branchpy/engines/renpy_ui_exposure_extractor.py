"""
Ren'Py UI Exposure Extractor (Engine Layer)
Extracts player-facing variables from screens.rpy metadata

Detects variables exposed in UI through:
- Stat metadata dictionaries (STAT_BOUNDS, RANGE_HINTS, etc.)
- Function calls with variable name literals (percent_for("x", ...))

Scope:
- Tier 1: Dictionary literals (STAT_BOUNDS = {...})
- Tier 1.5: Subscript assignments (STAT_BOUNDS["x"] = ...) [Ω-2.2 Phase 4]
- Tier 1.5: dict.update() calls (STAT_BOUNDS.update({...})) [Ω-2.2 Phase 4]
- Conservative: Only string keys matching identifier pattern

Design:
- Engine layer (Ren'Py specific)
- Zero new dependencies (stdlib only)
- Deterministic output
- Safe fallback on parse errors
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Set, Tuple

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Result Type
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass(frozen=True)
class UIExposure:
    """
    Result of UI exposure analysis from screens.rpy.

    Attributes:
        ui_vars: Set of variable names exposed in UI (player-facing)
        stat_bounds: Optional dict mapping var names to (min, max) bounds
        labels: Optional dict mapping var names to display labels
    """

    ui_vars: Set[str] = field(default_factory=set)
    stat_bounds: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    labels: Dict[str, str] = field(default_factory=dict)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Regex Patterns
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Match dictionary assignment for known stat metadata dicts
# Examples:
#   STAT_BOUNDS = { "trust": (0, 10), ... }
#   RANGE_HINTS = { "arousal": 100, ... }
DICT_ASSIGN_RE = re.compile(
    r"^\s*(STAT_BOUNDS|RANGE_HINTS|STAT_LABEL_OVERRIDES)\s*=\s*(\{.+?\})",
    re.MULTILINE | re.DOTALL,
)

# Match function calls with string literal variable names
# Examples:
#   percent_for("claire_trust", value)
#   stat_percent("arousal", x, (0, 10))
FUNC_CALL_RE = re.compile(
    r'\b(?:percent_for|stat_percent|get_stat|_prettify_label)\s*\(\s*"([A-Za-z_]\w*)"\s*[,)]'
)

# Valid Python identifier pattern (for safety checks)
IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Extractor
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def extract_ui_exposure(project_path: Path) -> UIExposure:
    """
    Extract UI-exposed variables from Ren'Py screens.rpy file.

    Strategy:
    1. Find screens.rpy in project_path/game/
    2. Extract stat metadata dictionaries (STAT_BOUNDS, RANGE_HINTS, etc.)
    3. Extract function calls with variable name string literals
    4. Return consolidated set of player-facing variables

    Args:
        project_path: Root path of Ren'Py project

    Returns:
        UIExposure with discovered player-facing variables and metadata

    Example:
        >>> ui = extract_ui_exposure(Path("HoS"))
        >>> "claire_trust" in ui.ui_vars
        True
        >>> ui.stat_bounds.get("claire_trust")
        (0.0, 10.0)
    """
    ui_vars: Set[str] = set()
    stat_bounds: Dict[str, Tuple[float, float]] = {}
    labels: Dict[str, str] = {}

    # Locate screens.rpy (standard location: game/screens.rpy)
    screens_file = project_path / "game" / "screens.rpy"
    if not screens_file.exists():
        # Try alternate location
        screens_file = project_path / "screens.rpy"
        if not screens_file.exists():
            return UIExposure()

    # Read file content
    try:
        content = screens_file.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return UIExposure()

    # ═══════════════════════════════════════════════════════════════
    # Extract dictionary assignments
    # ═══════════════════════════════════════════════════════════════

    for match in DICT_ASSIGN_RE.finditer(content):
        dict_name = match.group(1)
        dict_literal = match.group(2)

        # Parse dictionary using ast.literal_eval (safe, deterministic)
        try:
            parsed = ast.literal_eval(dict_literal)
            if not isinstance(parsed, dict):
                continue

            # Extract keys (only string keys matching identifier pattern)
            for key, value in parsed.items():
                if not isinstance(key, str):
                    continue
                if not IDENTIFIER_RE.match(key):
                    continue

                # Add to ui_vars
                ui_vars.add(key)

                # Process specific dict types
                if dict_name == "STAT_BOUNDS":
                    # Value should be (min, max) tuple
                    if isinstance(value, (tuple, list)) and len(value) == 2:
                        try:
                            min_val = float(value[0])
                            max_val = float(value[1])
                            stat_bounds[key] = (min_val, max_val)
                        except (ValueError, TypeError):
                            pass

                elif dict_name == "STAT_LABEL_OVERRIDES":
                    # Value should be display string
                    if isinstance(value, str):
                        labels[key] = value

                elif dict_name == "RANGE_HINTS":
                    # Value might be max value or (min, max)
                    if isinstance(value, (int, float)):
                        # Assume 0 as min
                        stat_bounds[key] = (0.0, float(value))
                    elif isinstance(value, (tuple, list)) and len(value) == 2:
                        try:
                            min_val = float(value[0])
                            max_val = float(value[1])
                            stat_bounds[key] = (min_val, max_val)
                        except (ValueError, TypeError):
                            pass

        except (SyntaxError, ValueError):
            # Not a literal dict → skip safely
            continue

    # ═══════════════════════════════════════════════════════════════
    # Tier 1.5: Extract subscript assignments + dict.update() [Ω-2.2 Phase 4]
    # ═══════════════════════════════════════════════════════════════

    # Extract Python snippets from inline $ and python: blocks
    python_snippets = _extract_python_snippets(content)

    for snippet in python_snippets:
        try:
            tree = ast.parse(snippet, mode="exec")

            for node in ast.walk(tree):
                # Pattern 1: STAT_BOUNDS["x"] = (0, 10)
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Subscript):
                            # Get dictionary name
                            dict_name = _get_dict_name(target.value)
                            # Get literal key (ast.Subscript uses .slice for the index)
                            key = _get_literal_key(target.slice)

                            if dict_name and key and IDENTIFIER_RE.match(key):
                                if dict_name in (
                                    "STAT_BOUNDS",
                                    "RANGE_HINTS",
                                    "STAT_LABEL_OVERRIDES",
                                ):
                                    ui_vars.add(key)

                                    # Extract value if it's a literal
                                    if dict_name in ("STAT_BOUNDS", "RANGE_HINTS"):
                                        bounds = _extract_bounds_literal(node.value)
                                        if bounds:
                                            stat_bounds[key] = bounds

                                    elif dict_name == "STAT_LABEL_OVERRIDES":
                                        label = _extract_string_literal(node.value)
                                        if label:
                                            labels[key] = label

                # Pattern 2: STAT_BOUNDS.update({...})
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Attribute):
                        dict_name = _get_dict_name(node.func.value)
                        method = node.func.attr

                        if method == "update" and dict_name in (
                            "STAT_BOUNDS",
                            "RANGE_HINTS",
                            "STAT_LABEL_OVERRIDES",
                        ):
                            if node.args and isinstance(node.args[0], ast.Dict):
                                dict_node = node.args[0]

                                # Extract key-value pairs from Dict node
                                for key_node, val_node in zip(
                                    dict_node.keys, dict_node.values
                                ):
                                    if isinstance(
                                        key_node, ast.Constant
                                    ) and isinstance(key_node.value, str):
                                        key = key_node.value

                                        if IDENTIFIER_RE.match(key):
                                            ui_vars.add(key)

                                            if dict_name in (
                                                "STAT_BOUNDS",
                                                "RANGE_HINTS",
                                            ):
                                                bounds = _extract_bounds_literal(
                                                    val_node
                                                )
                                                if bounds:
                                                    stat_bounds[key] = bounds

                                            elif dict_name == "STAT_LABEL_OVERRIDES":
                                                label = _extract_string_literal(
                                                    val_node
                                                )
                                                if label:
                                                    labels[key] = label

        except (SyntaxError, ValueError):
            # Invalid Python snippet → skip safely
            continue

    # ═══════════════════════════════════════════════════════════════
    # Extract function calls with string literal variable names
    # ═══════════════════════════════════════════════════════════════

    for match in FUNC_CALL_RE.finditer(content):
        var_name = match.group(1)
        if IDENTIFIER_RE.match(var_name):
            ui_vars.add(var_name)

    return UIExposure(ui_vars=ui_vars, stat_bounds=stat_bounds, labels=labels)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Helper Functions (Tier 1.5)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def _extract_python_snippets(content: str) -> list:
    """
    Extract Python code snippets from Ren'Py screens.rpy.

    Extracts:
    - Inline Python: $ code
    - Python blocks: python: ... (indented)
    - init python blocks: init python: ... (indented)

    Returns:
        List of Python code strings
    """
    snippets = []

    # Pattern 1: Inline Python ($ ...)
    inline_pattern = re.compile(r"^\s*\$\s+(.+)$", re.MULTILINE)
    for match in inline_pattern.finditer(content):
        snippets.append(match.group(1))

    # Pattern 2: Python blocks (python: or init python:)
    lines = content.split("\n")
    in_python_block = False
    python_block_lines = []
    base_indent = 0

    for line in lines:
        # Start of python block
        if re.match(r"^\s*(?:init\s+)?python:", line):
            in_python_block = True
            python_block_lines = []
            base_indent = len(line) - len(line.lstrip())
            continue

        if in_python_block:
            stripped = line.lstrip()

            # Empty lines continue the block
            if not stripped:
                python_block_lines.append("")
                continue

            current_indent = len(line) - len(stripped)

            # End block on dedent
            if current_indent <= base_indent:
                if python_block_lines:
                    snippets.append("\n".join(python_block_lines))
                in_python_block = False
                python_block_lines = []
            else:
                # Remove base indentation
                dedented = (
                    line[base_indent + 4 :] if len(line) > base_indent + 4 else stripped
                )
                python_block_lines.append(dedented)

    # Handle trailing python block
    if in_python_block and python_block_lines:
        snippets.append("\n".join(python_block_lines))

    return snippets


def _get_dict_name(node: ast.AST) -> Optional[str]:
    """Extract dictionary name from AST node (e.g., STAT_BOUNDS from target.value)."""
    if isinstance(node, ast.Name):
        return node.id
    return None


def _get_literal_key(node: ast.AST) -> Optional[str]:
    """Extract string literal key from subscript index node."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    # Python 3.7 compatibility
    if isinstance(node, ast.Str):
        return node.s
    return None


def _extract_bounds_literal(node: ast.AST) -> Optional[Tuple[float, float]]:
    """
    Extract (min, max) bounds from AST node.

    Handles:
    - Tuple/List: (0, 10) or [0, 10]
    - Single number: 100 → (0.0, 100.0)
    """
    # Tuple or List literal
    if isinstance(node, (ast.Tuple, ast.List)):
        if len(node.elts) == 2:
            try:
                min_node = node.elts[0]
                max_node = node.elts[1]

                min_val = _extract_number(min_node)
                max_val = _extract_number(max_node)

                if min_val is not None and max_val is not None:
                    return (float(min_val), float(max_val))
            except (ValueError, TypeError):
                pass

    # Single number → assume min=0
    num = _extract_number(node)
    if num is not None:
        return (0.0, float(num))

    return None


def _extract_number(node: ast.AST) -> Optional[float]:
    """Extract numeric value from AST node."""
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    # Python 3.7 compatibility
    if isinstance(node, ast.Num):
        return node.n
    # Unary minus: -5
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        val = _extract_number(node.operand)
        return -val if val is not None else None
    return None


def _extract_string_literal(node: ast.AST) -> Optional[str]:
    """Extract string literal from AST node."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    # Python 3.7 compatibility
    if isinstance(node, ast.Str):
        return node.s
    return None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Exports
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

__all__ = [
    "UIExposure",
    "extract_ui_exposure",
]
