"""
BranchPy engines package.

This package contains engine implementations for different interactive fiction frameworks.
"""
