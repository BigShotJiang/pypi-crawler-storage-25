"""
Ren'Py Script-Language Condition Reads Extractor (Ω-2.2 Phase 3)
Engine layer: Ren'Py-specific syntax parsing

Extracts variable reads from Ren'Py script-language control structures:
- if/elif <condition>:
- while <condition>:
- menu item gating: "Choice text" if <condition>:

Why this matters:
- Python AST extraction only sees `$ python code` blocks
- Ren'Py script conditions are THE primary player-facing reads (branching predicates)
- Missing these reads causes massive under-counting (reads_any = 16 vs actual 80-150)

Conservative tokenization approach:
- Extract identifiers with regex (no full AST needed)
- Filter out Python keywords
- Filter out function calls (NAME followed by '(')
- Normalize store.x → x
- No heuristics, deterministic
"""

import re
from typing import Set, Tuple

# Python keywords to exclude from condition tokenization
PYTHON_KEYWORDS = {
    "and",
    "or",
    "not",
    "in",
    "is",
    "True",
    "False",
    "None",
    "if",
    "elif",
    "else",
    "for",
    "while",
    "def",
    "class",
    "return",
    "lambda",
    "with",
    "as",
    "from",
    "import",
    "pass",
    "break",
    "continue",
    "try",
    "except",
    "finally",
    "raise",
    "assert",
    "del",
    "global",
    "nonlocal",
    "yield",
    "async",
    "await",
}

# Common Ren'Py screen keywords (if they appear in conditions, likely internal)
# For now, we'll be liberal and let visibility classifier handle these
RENPY_SCREEN_KEYWORDS = {"renpy", "config", "preferences", "persistent"}


def extract_script_condition_reads_ctx(label_body: str) -> Tuple[Set[str], Set[str]]:
    """
    Ω-2.4: Extract script-language reads with conditional context separation.

    Returns:
        (reads_all, reads_conditional)

        - reads_all: All variables read in conditions (same as Ω-2.2/2.3 behavior)
        - reads_conditional: Same set (since current implementation only extracts from conditionals)

    Note: In this Ren'Py extractor, ALL reads come from control-flow conditions
    (if/elif/while/menu), so reads_all == reads_conditional. This is correct:
    script-language conditions ARE the primary branch-driving reads.
    """
    reads_conditional = set()

    # Pattern 1: if/elif conditions
    for match in re.finditer(r"^\s*(?:if|elif)\s+(.+?):\s*$", label_body, re.MULTILINE):
        condition = match.group(1)
        reads_conditional.update(_tokenize_condition(condition))

    # Pattern 2: menu item conditions
    for match in re.finditer(
        r'^\s*"[^"]*"\s+if\s+(.+?):\s*$', label_body, re.MULTILINE
    ):
        condition = match.group(1)
        reads_conditional.update(_tokenize_condition(condition))

    # Pattern 3: while loops
    for match in re.finditer(r"^\s*while\s+(.+?):\s*$", label_body, re.MULTILINE):
        condition = match.group(1)
        reads_conditional.update(_tokenize_condition(condition))

    # For Ren'Py script language: reads_all == reads_conditional
    # (All extracted reads come from control-flow conditions)
    reads_all = reads_conditional.copy()

    return reads_all, reads_conditional


def extract_script_condition_reads(label_body: str) -> Set[str]:
    """
    Extract variable reads from Ren'Py script-language conditions.

    Backward-compatible wrapper for Ω-2.2/2.3: returns reads_all.

    Handles:
    - if/elif <condition>:
    - while <condition>:
    - menu item conditions: "Choice text" if <condition>:

    Args:
        label_body: Raw Ren'Py script text for a label

    Returns:
        Set of variable names read in conditions

    Example:
        >>> body = '''
        ... if claire_trust > 5:
        ...     "She trusts you"
        ... elif michael_dom < 3:
        ...     "He resists"
        ... menu:
        ...     "Go with Claire" if claire_path:
        ...         jump claire_route
        ... '''
        >>> reads = extract_script_condition_reads(body)
        >>> reads
        {'claire_trust', 'michael_dom', 'claire_path'}
    """
    reads_all, _reads_conditional = extract_script_condition_reads_ctx(label_body)
    return reads_all


def _tokenize_condition(condition: str) -> Set[str]:
    """
    Extract variable identifiers from a condition string.

    Conservative approach:
    - Extract all identifiers matching [A-Za-z_]\\w*
    - Filter out Python keywords
    - Filter out function calls (identifier followed by '(')
    - Normalize store.x → x

    Args:
        condition: Condition expression string (e.g., "claire_trust > 5 and met_sophie")

    Returns:
        Set of variable names appearing in condition

    Example:
        >>> _tokenize_condition("claire_trust > 5 and has_flag('x')")
        {'claire_trust'}  # 'has_flag' filtered as function call
    """
    reads = set()

    # Extract all identifier tokens (including dotted forms)
    # Pattern: captures identifiers and dotted names like store.x
    tokens = re.findall(r"\b[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\b", condition)

    # Identify function calls: identifiers immediately followed by '('
    # We'll exclude these from reads (they're function names, not variables)
    func_call_pattern = r"\b([A-Za-z_]\w*)\s*\("
    func_names = set(re.findall(func_call_pattern, condition))

    for token in tokens:
        # Handle dotted names (e.g., store.x, persistent.y)
        parts = token.split(".")

        # If it's a dotted name like 'store.x', extract 'x'
        if len(parts) == 2 and parts[0] == "store":
            var_name = parts[1]
        # If it's persistent.x or config.x, treat as internal (skip for now)
        # User can adjust this policy via visibility classifier
        elif len(parts) == 2 and parts[0] in ("persistent", "config"):
            continue  # Skip persistent/config for now
        # Otherwise, use the token as-is (could be single identifier)
        else:
            var_name = parts[0]  # Take first part of any dotted name

        # Filter out keywords
        if var_name in PYTHON_KEYWORDS:
            continue

        # Filter out function calls
        if var_name in func_names:
            continue

        # Filter out numeric literals (though regex shouldn't catch these)
        if var_name.isdigit():
            continue

        reads.add(var_name)

    return reads


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Exports
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

__all__ = [
    "extract_script_condition_reads",
    "extract_script_condition_reads_ctx",  # Ω-2.4
]
