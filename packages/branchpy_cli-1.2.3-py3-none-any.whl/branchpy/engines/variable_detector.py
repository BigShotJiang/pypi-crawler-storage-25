"""
Variable Detector - Engine-agnostic variable extraction layer

Provides detection of variable reads/writes in narrative scripts.
Currently implements Ren'Py detector; extensible to other engines.

Part of v1.1.2 Omega Intelligence Engine enhancements.
"""

import re
from abc import ABC, abstractmethod
from typing import Set


class ModifierDetector(ABC):
    """Abstract base class for variable modification detection"""

    @abstractmethod
    def detect(self, text: str) -> Set[str]:
        """
        Detect variables that are written/modified in the given text.

        Args:
            text: Script text to analyze

        Returns:
            Set of variable names that are modified
        """
        pass

    @abstractmethod
    def detect_reads(self, text: str) -> Set[str]:
        """
        Detect variables that are read in the given text.

        Args:
            text: Script text to analyze

        Returns:
            Set of variable names that are read
        """
        pass


class RenpyModifierDetector(ModifierDetector):
    """Ren'Py-specific variable modification detector"""

    def __init__(self):
        # Patterns for detecting variable modifications
        # Match: $ var = value, $ var += 1, $ var -= 1, etc.
        self.inline_assign_re = re.compile(
            r"^\s*\$\s+([A-Za-z_]\w*)\s*(?:\+|-|\*|/|//|%|&|\||\^)?=", re.MULTILINE
        )

        # Match: default var = value (variable definition)
        self.default_re = re.compile(r"^\s*default\s+([A-Za-z_]\w*)\s*=", re.MULTILINE)

        # Match: python block assignments (simplified - matches var = anywhere in python block)
        # This is a heuristic; full Python parsing would be needed for 100% accuracy
        self.python_block_assign_re = re.compile(
            r"^\s*python\s*:.*?^\s*([A-Za-z_]\w*)\s*(?:\+|-|\*|/|//|%|&|\||\^)?=",
            re.MULTILINE | re.DOTALL,
        )

        # Patterns for detecting variable reads
        # Match: if var > 3:, "{var}", [var], etc.
        self.if_condition_re = re.compile(
            r"^\s*(?:if|elif)\s+.*?\b([A-Za-z_]\w*)\b", re.MULTILINE
        )

        # Match: "{variable_name}" or "[variable_name]" (interpolation)
        self.interpolation_re = re.compile(r"[\{\[]([A-Za-z_]\w*)[\}\]]")

        # Match: menu conditions like "Option text" if var > 3:
        self.menu_condition_re = re.compile(
            r'^\s*"[^"]*"\s+if\s+.*?\b([A-Za-z_]\w*)\b', re.MULTILINE
        )

    def detect(self, text: str) -> Set[str]:
        """Detect variables that are modified in Ren'Py script text"""
        modified = set()

        # Inline assignments: $ var = value
        for match in self.inline_assign_re.finditer(text):
            modified.add(match.group(1))

        # Default variable definitions
        for match in self.default_re.finditer(text):
            modified.add(match.group(1))

        # Python block assignments (simplified detection)
        for match in self.python_block_assign_re.finditer(text):
            modified.add(match.group(1))

        return modified

    def detect_reads(self, text: str) -> Set[str]:
        """Detect variables that are read in Ren'Py script text"""
        reads = set()

        # Conditional expressions
        for match in self.if_condition_re.finditer(text):
            reads.add(match.group(1))

        # String/text interpolation
        for match in self.interpolation_re.finditer(text):
            reads.add(match.group(1))

        # Menu conditions
        for match in self.menu_condition_re.finditer(text):
            reads.add(match.group(1))

        return reads


def create_detector(engine: str = "renpy") -> ModifierDetector:
    """
    Factory function to create appropriate detector for the given engine.

    Args:
        engine: Engine name ("renpy" is currently the only supported value)

    Returns:
        ModifierDetector instance for the specified engine

    Raises:
        ValueError: If engine is not supported
    """
    if engine.lower() == "renpy":
        return RenpyModifierDetector()
    else:
        raise ValueError(
            f"Unsupported engine: {engine}. Only 'renpy' is currently supported."
        )
