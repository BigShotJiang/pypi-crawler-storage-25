"""
Ren'Py Metadata Extractor (Engine Layer)
Extracts Variable Metadata from Ren'Py default/define Declarations

Parses .rpy script files to build initial variable domain model
for Omega State Width computation.

Scope (Phase Ω-2):
- Only `default` and `define` statements
- Only literal RHS values (via ast.literal_eval)
- Canonical symbol naming (store.x → x)

Not included (Phase Ω-2.1):
- `init python:` blocks (requires partial Python semantics)
- Complex RHS expressions (function calls, computations)
- Dotted attribute chains beyond store.x

Design Principles:
- Engine layer (lives in branchpy/engines/)
- Zero new dependencies (stdlib only)
- Deterministic output (same input → same result)
- Conservative fallback (unknown → UnknownDomain)
"""

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Dict, List, Optional

from branchpy.omega.domains import (
    Confidence,
    DiscreteDomain,
    IntervalDomain,
    UnknownDomain,
    VariableMeta,
    VarKind,
)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Regex Patterns
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Matches: default <name> = <value>  or  define <name> = <value>
# Captures: (keyword, name, rhs)
# Examples:
#   default affection = 0
#   define MAX_LEVEL = 10
#   default store.player_hp = 100
DEFAULT_RE = re.compile(
    r"^\s*(default|define)\s+([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)\s*=\s*(.+?)\s*$"
)

# Matches comments to strip them before parsing
COMMENT_RE = re.compile(r"#.*$")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Symbol Normalization
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def _canonical_name(name: str) -> str:
    """
    Normalize Ren'Py symbol to canonical form.

    Policy (Option A locked):
    - store.x → x
    - x → x

    Future: May need to handle persistent., config., etc.
    For Ω-2, we only track store variables.
    """
    if name.startswith("store."):
        return name.split(".", 1)[1]
    return name


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Extractor Class
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class RenpyMetadataExtractor:
    """
    Extracts variable metadata from Ren'Py script files.

    Parses `default` and `define` statements to build initial
    variable domain model for Omega State Width computation.

    Usage:
        extractor = RenpyMetadataExtractor()
        metadata = extractor.extract_metadata(script_files)

        # metadata: Dict[str, VariableMeta]
        # e.g., {"affection": VariableMeta(...), "hp": VariableMeta(...)}
    """

    def extract_metadata(self, script_files: List[Path]) -> Dict[str, VariableMeta]:
        """
        Extract variable metadata from Ren'Py script files.

        Args:
            script_files: List of .rpy file paths to parse

        Returns:
            Dict mapping canonical symbol names to VariableMeta

        Example:
            Given files containing:
                default affection = 0
                define MAX_HP = 100
                default mood = "happy"

            Returns:
                {
                    "affection": VariableMeta(INT, [0,0]),
                    "MAX_HP": VariableMeta(INT, [100,100]),
                    "mood": VariableMeta(STRING, Unknown)
                }
        """
        out: Dict[str, VariableMeta] = {}

        for p in script_files:
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                # File read error → skip silently (consistent with graph builder)
                continue

            for line in text.splitlines():
                # Strip comments first
                line = COMMENT_RE.sub("", line).strip()
                if not line:
                    continue

                # Match default/define pattern
                m = DEFAULT_RE.match(line)
                if not m:
                    continue

                keyword, raw_name, rhs = m.group(1), m.group(2), m.group(3)
                name = _canonical_name(raw_name)

                # Parse RHS literal → VariableMeta (with source provenance) [Ω-2.3]
                source = keyword  # "default" or "define"
                meta = self._meta_from_literal(name, rhs, source)
                if meta is None:
                    continue

                # Merge if duplicate declaration (conservative union)
                if name in out:
                    out[name] = out[name].merge(meta)
                else:
                    out[name] = meta

        return out

    def _meta_from_literal(
        self, name: str, rhs: str, source: str = "unknown"
    ) -> Optional[VariableMeta]:
        """
        Parse RHS literal into VariableMeta.

        Uses ast.literal_eval() for safe deterministic parsing.

        Supported types:
        - bool → BOOL, {False, True}
        - int → INT, [value, value]
        - float → FLOAT, [value, value]
        - list/tuple of scalars → ENUM, {values}
        - str → STRING, Unknown (conservative)
        - other → UNKNOWN

        Args:
            name: Canonical variable name
            rhs: Right-hand side expression string
            source: Declaration type ("default" for state, "define" for binding) [Ω-2.3]

        Returns:
            VariableMeta or None if unparseable
        """
        try:
            value = ast.literal_eval(rhs)
        except Exception:
            # Not a literal → mark as unknown declaration
            # Still EXPLICIT_DECLARATION because we found `default`/`define`
            return VariableMeta(
                name=name,
                kind=VarKind.UNKNOWN,
                domain=UnknownDomain(),
                confidence=Confidence.EXPLICIT_DECLARATION,
                source=source,  # [Ω-2.3]
            )

        # ════════════════════════════════════════════════════════════════
        # Boolean (check first — bool is subclass of int in Python)
        # ════════════════════════════════════════════════════════════════
        # Ω-2.0 Fix: Initial domain = singleton {value}, not type range
        if isinstance(value, bool):
            return VariableMeta(
                name=name,
                kind=VarKind.BOOL,
                domain=DiscreteDomain(frozenset({value})),
                confidence=Confidence.EXPLICIT_DECLARATION,
                source=source,
            )

        # ════════════════════════════════════════════════════════════════
        # Integer
        # ════════════════════════════════════════════════════════════════
        if isinstance(value, int):
            return VariableMeta(
                name=name,
                kind=VarKind.INT,
                domain=IntervalDomain(value, value),
                confidence=Confidence.EXPLICIT_DECLARATION,
                source=source,
            )

        # ════════════════════════════════════════════════════════════════
        # Float
        # ════════════════════════════════════════════════════════════════
        if isinstance(value, float):
            return VariableMeta(
                name=name,
                kind=VarKind.FLOAT,
                domain=IntervalDomain(value, value),
                confidence=Confidence.EXPLICIT_DECLARATION,
                source=source,
            )

        # ════════════════════════════════════════════════════════════════
        # List/Tuple → COMPOSITE + UnknownDomain
        # ════════════════════════════════════════════════════════════════
        # Ω-2.0 Fix: Lists are values (containers), not enum declarations.
        # default inventory = ["sword", "shield"] means "a list with 2 items",
        # not "inventory can only be 'sword' or 'shield'".
        # For explicit enum domains, use a convention like:
        #   define __domain_mood = ["happy", "sad", "angry"]
        if isinstance(value, (list, tuple)):
            return VariableMeta(
                name=name,
                kind=VarKind.COMPOSITE,
                domain=UnknownDomain(),
                confidence=Confidence.EXPLICIT_DECLARATION,
                source=source,
            )

        # ════════════════════════════════════════════════════════════════
        # String → Singleton Discrete Domain
        # ════════════════════════════════════════════════════════════════
        # Ω-2.0 Fix: Initial domain = singleton {value}, not UnknownDomain
        # Rationale: default mood = "happy" means domain = {"happy"} at entry,
        # not "all possible strings". Modified strings → Unknown via propagation.
        if isinstance(value, str):
            return VariableMeta(
                name=name,
                kind=VarKind.STRING,
                domain=DiscreteDomain(frozenset({value})),
                confidence=Confidence.EXPLICIT_DECLARATION,
                source=source,
            )

        # ════════════════════════════════════════════════════════════════
        # Fallback: Unknown type
        # ════════════════════════════════════════════════════════════════
        # Covers: dict, set, None, custom objects, etc.
        return VariableMeta(
            name=name,
            kind=VarKind.UNKNOWN,
            domain=UnknownDomain(),
            confidence=Confidence.EXPLICIT_DECLARATION,
            source=source,
        )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Convenience Function
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def extract_metadata(script_files: List[Path]) -> Dict[str, VariableMeta]:
    """
    Extract variable metadata from Ren'Py scripts (convenience wrapper).

    Args:
        script_files: List of .rpy file paths

    Returns:
        Dict[str, VariableMeta]: Canonical symbol → metadata mapping

    Example:
        >>> from pathlib import Path
        >>> script_files = [Path("game/script.rpy"), Path("game/chars.rpy")]
        >>> metadata = extract_metadata(script_files)
        >>> print(metadata["affection"].kind)
        VarKind.INT
    """
    extractor = RenpyMetadataExtractor()
    return extractor.extract_metadata(script_files)
