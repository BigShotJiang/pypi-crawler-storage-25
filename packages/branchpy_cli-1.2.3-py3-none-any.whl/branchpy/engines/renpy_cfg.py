from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from branchpy.core.cfg import CFGGraph

LABEL_RX = re.compile(r"^\s*label\s+([A-Za-z0-9_]+)\s*:\s*$")
JUMP_RX = re.compile(r"^\s*(jump|call)\s+([A-Za-z0-9_]+)\s*$")


def split_into_label_blocks(file_path: Path) -> List[Tuple[str, List[str]]]:
    """
    Returns [(label_name, lines_in_block), ...] for a .rpy file.
    """
    blocks: List[Tuple[str, List[str]]] = []
    current_label: str | None = None
    current_lines: List[str] = []
    try:
        for line in file_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            m = LABEL_RX.match(line)
            if m:
                # flush previous
                if current_label is not None:
                    blocks.append((current_label, current_lines))
                current_label = m.group(1)
                current_lines = []
            else:
                if current_label is not None:
                    current_lines.append(line)
        if current_label is not None:
            blocks.append((current_label, current_lines))
    except Exception:
        pass
    return blocks


def _classify_terminals(
    g: CFGGraph,
    labels: Dict[str, Dict[str, Any]],
    reachable: Set[str],
    unreachable: List[str],
) -> List[Dict[str, Any]]:
    """
    Classify terminal labels (endings) in the CFG.

    Terminal = label with out-degree 0 (no outgoing edges).

    Returns list of terminal metadata dicts.
    """
    terminals = []
    unreachable_set = set(unreachable)

    for label_name in labels.keys():
        # Skip special entry node
        if label_name == "__ENTRY__":
            continue

        # Check if terminal (no outgoing edges)
        out_degree = len(g.adj.get(label_name, set()))

        if out_degree == 0:
            label_info = labels.get(label_name, {})
            terminals.append(
                {
                    "name": label_name,
                    "type": "implicit",  # No outgoing edges
                    "reachable": label_name in reachable
                    and label_name not in unreachable_set,
                    "file": label_info.get("file", ""),
                    "line": label_info.get("line", 0),
                    "out_degree": 0,
                }
            )

    return terminals


def _tarjan_scc(adj: Dict[str, Set[str]], nodes: Set[str]) -> List[List[str]]:
    """
    Tarjan's algorithm for finding strongly connected components.

    Returns list of SCCs (each SCC is a list of node IDs).
    """
    index_counter = [0]
    stack: List[str] = []
    lowlinks: Dict[str, int] = {}
    index: Dict[str, int] = {}
    on_stack: Dict[str, bool] = {}
    sccs: List[List[str]] = []

    def strongconnect(node: str) -> None:
        index[node] = index_counter[0]
        lowlinks[node] = index_counter[0]
        index_counter[0] += 1
        on_stack[node] = True
        stack.append(node)

        for successor in adj.get(node, set()):
            if successor not in index:
                strongconnect(successor)
                lowlinks[node] = min(lowlinks[node], lowlinks[successor])
            elif on_stack.get(successor, False):
                lowlinks[node] = min(lowlinks[node], index[successor])

        if lowlinks[node] == index[node]:
            component: List[str] = []
            while True:
                w = stack.pop()
                on_stack[w] = False
                component.append(w)
                if w == node:
                    break
            sccs.append(component)

    for node in nodes:
        if node not in index:
            strongconnect(node)

    return sccs


def _compute_route_variants(
    g: CFGGraph,
    entry: Optional[str],
    terminals: List[Dict[str, Any]],
    reachable: Set[str],
    cap: int = 10000,
) -> Dict[str, Any]:
    """
    Compute bounded route variants using SCC condensation.

    Routes = distinct structural paths in SCC-condensed DAG (loops collapsed).
    Does NOT enumerate variable permutations.

    Returns dict with route counts per terminal (capped at max).
    """
    if not entry or not terminals:
        return {
            "cap": cap,
            "entry": entry or "start",
            "by_terminal": {},
            "notes": {
                "definition": "Structural routes in SCC-condensed DAG (loops collapsed); excludes variable permutations.",
                "algorithm": "Tarjan SCC + DP on condensed DAG",
            },
        }

    # Work only with reachable subgraph (exclude __ENTRY__)
    reachable_labels = {n for n in reachable if n != "__ENTRY__"}

    # Build adjacency for reachable subgraph only
    adj_reachable: Dict[str, Set[str]] = {}
    for src in reachable_labels:
        adj_reachable[src] = {
            dst for dst in g.adj.get(src, set()) if dst in reachable_labels
        }

    # Step 1: Compute SCCs on reachable subgraph
    sccs = _tarjan_scc(adj_reachable, reachable_labels)

    # Build component mapping
    comp_id: Dict[str, int] = {}
    for idx, scc in enumerate(sccs):
        for node in scc:
            comp_id[node] = idx

    # Step 2: Build condensed DAG
    dag_adj: Dict[int, Set[int]] = {i: set() for i in range(len(sccs))}

    for src in reachable_labels:
        src_comp = comp_id[src]
        for dst in adj_reachable.get(src, set()):
            dst_comp = comp_id[dst]
            if src_comp != dst_comp:
                dag_adj[src_comp].add(dst_comp)

    # Step 3: Topological sort of condensed DAG
    in_degree = {i: 0 for i in range(len(sccs))}
    for comp in dag_adj:
        for neighbor in dag_adj[comp]:
            in_degree[neighbor] += 1

    topo_order: List[int] = []
    queue = [comp for comp in range(len(sccs)) if in_degree[comp] == 0]

    while queue:
        current = queue.pop(0)
        topo_order.append(current)
        for neighbor in dag_adj[current]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    # Step 4: DP route counting with cap
    entry_comp = comp_id.get(entry, -1)
    if entry_comp == -1:
        # Entry not in reachable set (shouldn't happen but guard)
        return {
            "cap": cap,
            "entry": entry,
            "by_terminal": {},
            "notes": {
                "definition": "Structural routes in SCC-condensed DAG (loops collapsed); excludes variable permutations.",
                "error": f"Entry label '{entry}' not found in reachable components",
            },
        }

    routes: Dict[int, int] = {entry_comp: 1}
    capped_comps: Set[int] = set()

    for comp in topo_order:
        if comp not in routes:
            routes[comp] = 0

        current_routes = routes[comp]

        for neighbor in dag_adj[comp]:
            if neighbor not in routes:
                routes[neighbor] = 0

            # Add routes with cap
            new_count = routes[neighbor] + current_routes
            if new_count > cap:
                routes[neighbor] = cap
                capped_comps.add(neighbor)
            else:
                routes[neighbor] = new_count

    # Step 5: Map terminal counts
    by_terminal: Dict[str, Dict[str, Any]] = {}

    for terminal in terminals:
        if not terminal["reachable"]:
            by_terminal[terminal["name"]] = {
                "count": 0,
                "capped": False,
                "reason": "unreachable",
            }
        else:
            term_comp = comp_id.get(terminal["name"], -1)
            if term_comp == -1:
                by_terminal[terminal["name"]] = {
                    "count": 0,
                    "capped": False,
                    "reason": "not_in_reachable_set",
                }
            else:
                count = routes.get(term_comp, 0)
                by_terminal[terminal["name"]] = {
                    "count": count,
                    "capped": term_comp in capped_comps,
                }

    return {
        "cap": cap,
        "entry": entry,
        "by_terminal": by_terminal,
        "notes": {
            "definition": "Structural routes in SCC-condensed DAG (loops collapsed); excludes variable permutations.",
            "algorithm": "Tarjan SCC + DP on condensed DAG with cap enforcement",
        },
    }


def build_cfg(index: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build a CFG from the index structure produced by RenpyEngine.build_index.
    Output: {"graph": CFGGraph.to_dict(), "undefined_targets": [...], "unreachable": [...]}
    """
    g = CFGGraph()
    # Handle both old and new index structures
    labels: Dict[str, Dict[str, Any]] = index.get("symbols", {}).get(
        "labels", {}
    ) or index.get("labels", {})
    files = [Path(p) for p in index.get("files", [])]

    # nodes for every label
    for lbl in labels.keys():
        g.add_node(lbl)

    # entry: prefer 'start' if present; else any label deterministically (sorted)
    entry = (
        "start" if "start" in labels else (sorted(labels.keys())[0] if labels else None)
    )
    if entry:
        g.add_node("__ENTRY__")
        g.add_edge("__ENTRY__", entry, kind="entry")

    # edges from jump/call statements
    defined = set(labels.keys())
    referenced: set[str] = set()
    for f in files:
        for lbl, lines in split_into_label_blocks(f):
            for ln in lines:
                jm = JUMP_RX.match(ln)
                if jm:
                    tgt = jm.group(2)
                    referenced.add(tgt)
                    g.add_edge(lbl, tgt, kind="jump")

    undefined_targets = sorted(referenced - defined)
    reachable = g.reachable_from(["__ENTRY__"] if entry else [])
    unreachable = sorted([n for n in defined if n not in reachable]) if entry else []

    # Phase B: Terminal classification
    terminals = _classify_terminals(g, labels, reachable, unreachable)

    # Phase B: Route variants (SCC-condensed, bounded)
    route_variants = _compute_route_variants(g, entry, terminals, reachable, cap=10000)

    return {
        "graph": g.to_dict(),
        "dot": g.to_dot(),
        "undefined_targets": undefined_targets,
        "unreachable": unreachable,
        "terminals": terminals,  # Phase B: Studio-tier branch metrics
        "route_variants": route_variants,  # Phase B: Bounded route counts
    }
