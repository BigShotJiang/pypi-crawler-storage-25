"""
Source provider abstraction for analyzer file access.

Provides unified interface for reading Python source files in local and
remote environments, with implementations for each supported remote mode.

Governance: AXIS5-V0.9.2-REMOTE-BQS
"""

from pathlib import Path
from typing import Iterable, Optional, Protocol

from branchpy.analyzer.remote_paths import normalize_path_for_remote
from branchpy.remote.context import RemoteContext


class SourceProvider(Protocol):
    """
    Protocol for reading source files in various environments.

    Implementations provide environment-specific file access while maintaining
    a consistent interface for the analyzer.
    """

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        """
        Read text content from a file.

        Args:
            path: File path (relative or absolute)
            encoding: Text encoding (default: utf-8)

        Returns:
            File content as string

        Raises:
            FileNotFoundError: If file doesn't exist
            UnicodeDecodeError: If encoding fails
        """
        ...

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        """
        List all Python files under a root directory.

        Args:
            root: Root directory path
            pattern: File pattern to match (e.g., "*.py", "*.rpy")

        Returns:
            Iterator of Python file paths (.py and .rpy files)
        """
        ...

    def exists(self, path: str) -> bool:
        """
        Check if a file exists.

        Args:
            path: File path to check

        Returns:
            True if file exists, False otherwise
        """
        ...

    def get_name(self) -> str:
        """
        Get provider name for debugging/telemetry.

        Returns:
            Provider identifier (e.g., "local", "wsl", "ssh")
        """
        ...


class LocalSourceProvider:
    """
    Source provider for local filesystem access.

    Uses standard Python pathlib for file operations.
    """

    def get_name(self) -> str:
        """Return provider name."""
        return "local"

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        """Read text from local filesystem."""
        return Path(path).read_text(encoding=encoding)

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        """List Python files recursively."""
        root_path = Path(root)

        # Use the provided pattern
        for matched_file in root_path.rglob(pattern):
            if matched_file.is_file():
                yield str(matched_file.resolve().as_posix())

    def exists(self, path: str) -> bool:
        """Check if file exists."""
        return Path(path).exists()


class WslSourceProvider:
    """
    Source provider for WSL environments.

    Handles /mnt/c/... → C:/... path conversions and normalizes
    all returned paths to canonical format.

    In WS-A1.3, still filesystem-based (future: VS Code API integration).
    """

    def __init__(self, ctx: RemoteContext):
        """Initialize WSL source provider."""
        self.ctx = ctx

    def get_name(self) -> str:
        return "wsl"

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        return Path(path).read_text(encoding=encoding)

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        root_path = Path(root)
        for matched_file in root_path.rglob(pattern):
            if matched_file.is_file():
                canonical = normalize_path_for_remote(self.ctx, str(matched_file))
                yield canonical

    def exists(self, path: str) -> bool:
        return Path(path).exists()


class SshSourceProvider:
    """
    Source provider for SSH remote environments.

    Normalizes POSIX paths (removes .., ., //, trailing /).
    In WS-A1.3, still filesystem-based (future: SSH command execution).
    """

    def __init__(self, ctx: RemoteContext):
        self.ctx = ctx

    def get_name(self) -> str:
        return "ssh"

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        return Path(path).read_text(encoding=encoding)

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        root_path = Path(root)
        for matched_file in root_path.rglob(pattern):
            if matched_file.is_file():
                canonical = normalize_path_for_remote(self.ctx, str(matched_file))
                yield canonical

    def exists(self, path: str) -> bool:
        return Path(path).exists()


class ContainerSourceProvider:
    """
    Source provider for container environments (Docker, dev containers).

    Handles workspace mount paths and normalizes to canonical POSIX format.
    In WS-A1.3, still filesystem-based (future: Docker API integration).
    """

    def __init__(self, ctx: RemoteContext):
        self.ctx = ctx

    def get_name(self) -> str:
        return "container"

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        return Path(path).read_text(encoding=encoding)

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        root_path = Path(root)
        for matched_file in root_path.rglob(pattern):
            if matched_file.is_file():
                canonical = normalize_path_for_remote(self.ctx, str(matched_file))
                yield canonical

    def exists(self, path: str) -> bool:
        return Path(path).exists()


class CodespacesSourceProvider:
    """
    Source provider for GitHub Codespaces.

    Handles /workspaces/... paths and normalizes to canonical POSIX format.
    In WS-A1.3, still filesystem-based (future: VS Code API integration).
    """

    def __init__(self, ctx: RemoteContext):
        self.ctx = ctx

    def get_name(self) -> str:
        return "codespaces"

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        return Path(path).read_text(encoding=encoding)

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        root_path = Path(root)
        for matched_file in root_path.rglob(pattern):
            if matched_file.is_file():
                canonical = normalize_path_for_remote(self.ctx, str(matched_file))
                yield canonical

    def exists(self, path: str) -> bool:
        return Path(path).exists()


class CiSourceProvider:
    """
    Source provider for CI environments (GitHub Actions, GitLab CI).

    Handles CI workspace paths and normalizes to canonical POSIX format.
    In WS-A1.3, still filesystem-based (future: CI-specific optimizations).
    """

    def __init__(self, ctx: RemoteContext):
        self.ctx = ctx

    def get_name(self) -> str:
        return "ci"

    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        return Path(path).read_text(encoding=encoding)

    def list_python_files(self, root: str, pattern: str = "*.py") -> Iterable[str]:
        root_path = Path(root)
        for matched_file in root_path.rglob(pattern):
            if matched_file.is_file():
                canonical = normalize_path_for_remote(self.ctx, str(matched_file))
                yield canonical

    def exists(self, path: str) -> bool:
        return Path(path).exists()


def create_source_provider(ctx: Optional[RemoteContext] = None) -> SourceProvider:
    """
    Create appropriate source provider for a remote context.

    Factory function that selects the correct provider implementation
    based on the remote environment mode.

    Args:
        ctx: Remote context (None = local mode)

    Returns:
        SourceProvider instance appropriate for the environment

    Examples:
        >>> from branchpy.remote import detect_environment
        >>> ctx = detect_environment()
        >>> provider = create_source_provider(ctx)
        >>> files = list(provider.list_python_files("/workspace"))
    """
    if ctx is None or ctx.mode == "local":
        return LocalSourceProvider()

    mode = ctx.mode

    if mode == "wsl":
        return WslSourceProvider(ctx)

    if mode == "ssh":
        return SshSourceProvider(ctx)

    if mode == "container":
        return ContainerSourceProvider(ctx)

    if mode == "codespaces":
        return CodespacesSourceProvider(ctx)

    if mode == "ci":
        return CiSourceProvider(ctx)

    # Safe fallback for unknown modes
    return LocalSourceProvider()
