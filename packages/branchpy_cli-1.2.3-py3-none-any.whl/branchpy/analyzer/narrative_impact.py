"""
Narrative Impact Scoring — WS-M2

Quantifies narrative significance of merge conflicts by analyzing:
- Entry point modifications
- High-traffic label changes
- Label additions/deletions
- Downstream flow impact

Part of v0.9.2 Merge Analyzer enhancements.

Governance: AXIS5-V0.9.2-REMOTE-BQS (WS-M2)
Performance Target: <100ms p95 for typical file (10-50 labels)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from .script_graph import ScriptGraph

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Data Structures
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass
class NarrativeImpactScore:
    """
    Quantifies narrative significance of a merge conflict.

    Score ranges from 0.0 (trivial/no impact) to 1.0 (critical/high impact).

    Scoring weights:
    - Entry point modification: 0.4
    - High-traffic label (>5 callers): 0.3
    - Label deletion: 0.2
    - New label creation: 0.1

    Attributes:
        file_path: Path to modified file
        score: Narrative impact score (0.0 to 1.0)
        factors: Breakdown of score contributions
        affected_labels: Labels in the modified file
        downstream_labels: Labels reachable from affected labels
        is_high_impact: True if score >= 0.7
        is_medium_impact: True if 0.4 <= score < 0.7
        reason: Human-readable explanation

    Examples:
        >>> score = NarrativeImpactScore(
        ...     file_path=Path("game/script.rpy"),
        ...     score=0.85,
        ...     factors={"entry_point": 0.4, "high_traffic": 0.3, "label_deleted": 0.2},
        ...     affected_labels=["start", "chapter1"],
        ...     downstream_labels=["start", "chapter1", "chapter2", "ending"],
        ...     is_high_impact=True,
        ...     is_medium_impact=False,
        ...     reason="Entry point 'start' modified, high-traffic label with 8 callers, 1 label deleted",
        ... )
        >>> score.score
        0.85
        >>> score.is_high_impact
        True
    """

    file_path: Path
    score: float  # 0.0 to 1.0
    factors: Dict[str, float] = field(default_factory=dict)
    affected_labels: List[str] = field(default_factory=list)
    downstream_labels: List[str] = field(default_factory=list)
    is_high_impact: bool = False
    is_medium_impact: bool = False
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            "file_path": self.file_path.as_posix(),
            "score": self.score,
            "factors": self.factors,
            "affected_labels": self.affected_labels,
            "downstream_labels": self.downstream_labels,
            "is_high_impact": self.is_high_impact,
            "is_medium_impact": self.is_medium_impact,
            "reason": self.reason,
        }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Core Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def compute_narrative_impact(
    file_path: Path,
    script_graph: ScriptGraph,
    old_content: Optional[str] = None,
    new_content: Optional[str] = None,
    depth: int = 3,
) -> NarrativeImpactScore:
    """
    Compute narrative impact score for a modified file.

    Analyzes the semantic significance of changes to a script file by examining:
    1. Entry point modifications (highest weight: 0.4)
    2. High-traffic labels (>5 callers, weight: 0.3)
    3. Label deletions (weight: 0.2)
    4. New label additions (weight: 0.1)

    Performance: O(n) where n = labels in file, typically <100ms

    Args:
        file_path: Path to modified script file
        script_graph: Project script graph
        old_content: Original file content (for deletion detection)
        new_content: New file content (for addition detection)
        depth: Flow walking depth for downstream analysis (default: 3)

    Returns:
        NarrativeImpactScore with score, factors, and metadata

    Examples:
        >>> graph = build_script_graph(project_root)
        >>> score = compute_narrative_impact(
        ...     Path("game/script.rpy"),
        ...     graph,
        ...     old_content=old_text,
        ...     new_content=new_text,
        ... )
        >>> if score.is_high_impact:
        ...     print(f"High impact change: {score.reason}")
    """
    score = 0.0
    factors: Dict[str, float] = {}
    affected_labels: List[str] = []
    downstream_labels: List[str] = []

    # 1. Extract labels from file
    labels_in_file = script_graph.get_labels_in_file(file_path)
    affected_labels = [node.name for node in labels_in_file]

    if not affected_labels:
        # No labels in file, return zero impact
        return NarrativeImpactScore(
            file_path=file_path,
            score=0.0,
            factors={},
            affected_labels=[],
            downstream_labels=[],
            is_high_impact=False,
            is_medium_impact=False,
            reason="No labels in modified file",
        )

    # 2. Check for entry point modifications (0.4 weight)
    entry_point_names = {
        node.name
        for node_id in script_graph.entry_points
        if (node := script_graph.nodes.get(node_id)) is not None
    }

    modified_entry_points = [
        label for label in affected_labels if label in entry_point_names
    ]

    if modified_entry_points:
        factors["entry_point"] = 0.4
        score += 0.4

    # 3. Check for high-traffic labels (0.3 weight)
    # A label is "high-traffic" if it has >5 incoming edges
    high_traffic_labels = []
    for label in affected_labels:
        # Find all edges pointing to this label
        node_id = f"{file_path.as_posix()}:{label}"
        incoming_edges = [
            edge
            for edge in script_graph.edges
            if edge.to_node == node_id or edge.to_node == label
        ]

        if len(incoming_edges) > 5:
            high_traffic_labels.append(label)

    if high_traffic_labels:
        factors["high_traffic"] = 0.3
        score += 0.3

    # 4. Check for label deletions (0.2 weight)
    deleted_labels = _detect_deleted_labels(old_content, new_content, affected_labels)
    if deleted_labels:
        factors["label_deleted"] = 0.2
        score += 0.2

    # 5. Check for new label additions (0.1 weight)
    added_labels = _detect_added_labels(old_content, new_content)
    if added_labels:
        factors["new_labels"] = 0.1
        score += 0.1

    # 6. Compute downstream labels (for context, not scoring)
    downstream_set: Set[str] = set()
    for label in affected_labels:
        node_id = f"{file_path.as_posix()}:{label}"
        if node_id in script_graph.nodes:
            # Walk flow from this label
            reachable = _walk_reachable(script_graph, node_id, depth)
            downstream_set.update(reachable)

    downstream_labels = sorted(downstream_set)

    # 7. Clamp score to [0.0, 1.0]
    score = min(score, 1.0)

    # 8. Classify impact level
    is_high_impact = score >= 0.7
    is_medium_impact = 0.4 <= score < 0.7

    # 9. Generate human-readable reason
    reason = _generate_reason(
        factors,
        modified_entry_points,
        high_traffic_labels,
        deleted_labels,
        added_labels,
        len(downstream_labels),
    )

    return NarrativeImpactScore(
        file_path=file_path,
        score=score,
        factors=factors,
        affected_labels=affected_labels,
        downstream_labels=downstream_labels,
        is_high_impact=is_high_impact,
        is_medium_impact=is_medium_impact,
        reason=reason,
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Helper Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def _detect_deleted_labels(
    old_content: Optional[str],
    new_content: Optional[str],
    current_labels: List[str],
) -> List[str]:
    """
    Detect labels that were deleted in the new version.

    Args:
        old_content: Original file content
        new_content: New file content
        current_labels: Labels currently in the graph

    Returns:
        List of deleted label names
    """
    if not old_content or not new_content:
        return []

    # Extract label definitions from old content
    import re

    old_labels = set(re.findall(r"^\s*label\s+(\w+)", old_content, re.MULTILINE))
    new_labels = set(re.findall(r"^\s*label\s+(\w+)", new_content, re.MULTILINE))

    # Labels that existed before but not now
    deleted = old_labels - new_labels

    return sorted(deleted)


def _detect_added_labels(
    old_content: Optional[str],
    new_content: Optional[str],
) -> List[str]:
    """
    Detect labels that were added in the new version.

    Args:
        old_content: Original file content
        new_content: New file content

    Returns:
        List of added label names
    """
    if not old_content or not new_content:
        return []

    # Extract label definitions
    import re

    old_labels = set(re.findall(r"^\s*label\s+(\w+)", old_content, re.MULTILINE))
    new_labels = set(re.findall(r"^\s*label\s+(\w+)", new_content, re.MULTILINE))

    # Labels that exist now but didn't before
    added = new_labels - old_labels

    return sorted(added)


def _walk_reachable(
    graph: ScriptGraph,
    start_node: str,
    depth: int,
) -> Set[str]:
    """
    Walk the graph from a starting node to find reachable labels.

    Uses breadth-first search with depth limiting.

    Args:
        graph: Script graph
        start_node: Starting node ID (file:label format)
        depth: Maximum depth to walk

    Returns:
        Set of reachable node names (label names only, not full node IDs)
    """
    from collections import deque

    visited: Set[str] = set()
    queue: deque = deque([(start_node, 0)])
    reachable_names: Set[str] = set()

    while queue:
        node_id, current_depth = queue.popleft()

        if node_id in visited or current_depth > depth:
            continue

        visited.add(node_id)

        # Extract label name from node_id (format: "path:label")
        if ":" in node_id:
            label_name = node_id.split(":", 1)[1]
            reachable_names.add(label_name)

        # Get outgoing edges
        edges = graph.get_outgoing_edges(node_id)
        for edge in edges:
            if edge.to_node not in visited:
                queue.append((edge.to_node, current_depth + 1))

    return reachable_names


def _generate_reason(
    factors: Dict[str, float],
    entry_points: List[str],
    high_traffic: List[str],
    deleted: List[str],
    added: List[str],
    downstream_count: int,
) -> str:
    """
    Generate human-readable explanation of narrative impact.

    Args:
        factors: Score factor breakdown
        entry_points: Modified entry point labels
        high_traffic: High-traffic labels
        deleted: Deleted labels
        added: Added labels
        downstream_count: Number of downstream labels

    Returns:
        Human-readable reason string
    """
    parts = []

    if "entry_point" in factors:
        if len(entry_points) == 1:
            parts.append(f"Entry point '{entry_points[0]}' modified")
        else:
            parts.append(f"{len(entry_points)} entry points modified")

    if "high_traffic" in factors:
        if len(high_traffic) == 1:
            parts.append(f"High-traffic label '{high_traffic[0]}'")
        else:
            parts.append(f"{len(high_traffic)} high-traffic labels")

    if "label_deleted" in factors:
        if len(deleted) == 1:
            parts.append(f"Label '{deleted[0]}' deleted")
        else:
            parts.append(f"{len(deleted)} labels deleted")

    if "new_labels" in factors:
        if len(added) == 1:
            parts.append(f"New label '{added[0]}' added")
        else:
            parts.append(f"{len(added)} new labels added")

    if downstream_count > 0:
        parts.append(f"{downstream_count} downstream labels affected")

    if not parts:
        return "Low impact change"

    return ", ".join(parts)
