"""
Flow Delta Analysis — WS-M3

Compares ScriptGraphs between merge base and target to detect:
- Label/edge additions and removals
- Reachability changes
- Flow impact propagation
- Breaking changes (entry point removal)

Part of v0.9.2 Merge Analyzer enhancements.

Governance: AXIS5-V0.9.2-REMOTE-BQS (WS-M3)
Performance Target: <200ms p95 for typical project (100-500 labels)
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Set, Tuple

from .script_graph import ScriptGraph

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Data Structures
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass
class FlowDelta:
    """
    Represents flow graph differences between two branches.

    Compares two ScriptGraphs (e.g., merge base vs target) and identifies
    structural changes that affect story flow.

    Attributes:
        base_branch: Name of base branch (e.g., "main")
        target_branch: Name of target branch (e.g., "feature/story")
        labels_added: Labels present in target but not base
        labels_removed: Labels present in base but not target
        labels_modified: Labels present in both but with different content
        edges_added: Flow edges added in target
        edges_removed: Flow edges removed from base
        newly_reachable: Labels that became reachable in target
        newly_unreachable: Labels that became unreachable in target
        total_labels_affected: Total count of changed labels
        max_depth_affected: Maximum propagation depth of changes
        entry_points_affected: Entry point labels affected by changes
        is_breaking_change: True if entry points removed/unreachable
        propagation_score: 0.0-1.0 score of how far changes propagate

    Examples:
        >>> delta = FlowDelta(
        ...     base_branch="main",
        ...     target_branch="feature/story",
        ...     labels_added=["new_chapter"],
        ...     labels_removed=["old_ending"],
        ...     labels_modified=["chapter1", "chapter2"],
        ...     edges_added=[("start", "new_chapter")],
        ...     edges_removed=[("chapter2", "old_ending")],
        ...     newly_reachable=["new_chapter"],
        ...     newly_unreachable=["old_ending"],
        ...     total_labels_affected=4,
        ...     max_depth_affected=2,
        ...     entry_points_affected=[],
        ...     is_breaking_change=False,
        ...     propagation_score=0.67,
        ... )
    """

    base_branch: str
    target_branch: str

    # Label changes
    labels_added: List[str] = field(default_factory=list)
    labels_removed: List[str] = field(default_factory=list)
    labels_modified: List[str] = field(default_factory=list)

    # Edge changes
    edges_added: List[Tuple[str, str]] = field(default_factory=list)
    edges_removed: List[Tuple[str, str]] = field(default_factory=list)

    # Reachability changes
    newly_reachable: List[str] = field(default_factory=list)
    newly_unreachable: List[str] = field(default_factory=list)

    # Impact metrics
    total_labels_affected: int = 0
    max_depth_affected: int = 0
    entry_points_affected: List[str] = field(default_factory=list)

    # Classification
    is_breaking_change: bool = False
    propagation_score: float = 0.0  # 0.0 to 1.0

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            "base_branch": self.base_branch,
            "target_branch": self.target_branch,
            "labels_added": self.labels_added,
            "labels_removed": self.labels_removed,
            "labels_modified": self.labels_modified,
            "edges_added": [(str(a), str(b)) for a, b in self.edges_added],
            "edges_removed": [(str(a), str(b)) for a, b in self.edges_removed],
            "newly_reachable": self.newly_reachable,
            "newly_unreachable": self.newly_unreachable,
            "total_labels_affected": self.total_labels_affected,
            "max_depth_affected": self.max_depth_affected,
            "entry_points_affected": self.entry_points_affected,
            "is_breaking_change": self.is_breaking_change,
            "propagation_score": self.propagation_score,
        }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Core Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def compute_flow_delta(
    base_graph: ScriptGraph,
    target_graph: ScriptGraph,
    base_branch: str = "base",
    target_branch: str = "target",
    depth: int = 3,
) -> FlowDelta:
    """
    Compare two ScriptGraphs and compute flow delta.

    Analyzes structural differences between two versions of a story graph:
    1. Identifies added/removed/modified labels
    2. Detects edge changes (flow connections)
    3. Computes reachability changes via BFS
    4. Calculates propagation metrics
    5. Detects breaking changes

    Performance: O(V + E) where V = vertices (labels), E = edges
    Typical: <200ms for projects with 100-500 labels

    Args:
        base_graph: Script graph from base branch
        target_graph: Script graph from target branch
        base_branch: Name of base branch (for metadata)
        target_branch: Name of target branch (for metadata)
        depth: Maximum depth for reachability analysis (default: 3)

    Returns:
        FlowDelta with comprehensive change analysis

    Examples:
        >>> base_graph = build_script_graph(project_root, branch="main")
        >>> target_graph = build_script_graph(project_root, branch="feature")
        >>> delta = compute_flow_delta(base_graph, target_graph, "main", "feature")
        >>> if delta.is_breaking_change:
        ...     print(f"Breaking: {len(delta.entry_points_affected)} entry points affected")
    """
    # 1. Diff labels (node-level changes)
    base_labels = set(base_graph.nodes.keys())
    target_labels = set(target_graph.nodes.keys())

    labels_added = sorted(target_labels - base_labels)
    labels_removed = sorted(base_labels - target_labels)

    # Find modified labels (same node_id, but different metadata)
    # For simplicity, we consider labels "modified" if they exist in both
    # but have different line numbers (indicating content change)
    common_labels = base_labels & target_labels
    labels_modified = []

    for node_id in common_labels:
        base_node = base_graph.nodes[node_id]
        target_node = target_graph.nodes[node_id]

        # Simple heuristic: different line number = modified
        # (In production, could use content hash or AST comparison)
        if base_node.line_number != target_node.line_number:
            labels_modified.append(node_id)

    labels_modified = sorted(labels_modified)

    # 2. Diff edges (flow-level changes)
    base_edges = {(e.from_node, e.to_node) for e in base_graph.edges}
    target_edges = {(e.from_node, e.to_node) for e in target_graph.edges}

    edges_added = sorted(target_edges - base_edges)
    edges_removed = sorted(base_edges - target_edges)

    # 3. Compute reachability changes
    # Get entry points (prefer target graph for current state)
    entry_point_ids = target_graph.entry_points
    if not entry_point_ids:
        # Fallback to base graph entry points
        entry_point_ids = base_graph.entry_points

    newly_reachable = []
    newly_unreachable = []

    # Check reachability for all labels in union
    all_labels = base_labels | target_labels

    for label_id in all_labels:
        # Check if reachable in base
        base_reachable = label_id in base_labels and _is_reachable_from_any(
            base_graph, entry_point_ids, label_id, depth
        )

        # Check if reachable in target
        target_reachable = label_id in target_labels and _is_reachable_from_any(
            target_graph, entry_point_ids, label_id, depth
        )

        if target_reachable and not base_reachable:
            newly_reachable.append(label_id)
        elif not target_reachable and base_reachable:
            newly_unreachable.append(label_id)

    newly_reachable = sorted(newly_reachable)
    newly_unreachable = sorted(newly_unreachable)

    # 4. Calculate impact metrics
    total_labels_affected = (
        len(labels_added) + len(labels_removed) + len(labels_modified)
    )

    # Calculate max propagation depth
    max_depth = _calculate_max_depth(
        target_graph,
        labels_added + labels_modified,
        depth,
    )

    # Check which entry points are affected
    entry_point_names = {
        node_id.split(":", 1)[1] if ":" in node_id else node_id
        for node_id in entry_point_ids
    }

    entry_points_affected = []
    for node_id in labels_removed + labels_modified:
        label_name = node_id.split(":", 1)[1] if ":" in node_id else node_id
        if label_name in entry_point_names:
            entry_points_affected.append(label_name)

    entry_points_affected = sorted(set(entry_points_affected))

    # 5. Determine if breaking change
    is_breaking = len(entry_points_affected) > 0 or len(newly_unreachable) > 0

    # 6. Calculate propagation score (0.0 to 1.0)
    # Score increases with depth and number of affected labels
    if depth > 0 and total_labels_affected > 0:
        depth_factor = max_depth / depth
        volume_factor = min(total_labels_affected / 10.0, 1.0)
        propagation_score = min((depth_factor + volume_factor) / 2.0, 1.0)
    else:
        propagation_score = 0.0

    return FlowDelta(
        base_branch=base_branch,
        target_branch=target_branch,
        labels_added=labels_added,
        labels_removed=labels_removed,
        labels_modified=labels_modified,
        edges_added=edges_added,
        edges_removed=edges_removed,
        newly_reachable=newly_reachable,
        newly_unreachable=newly_unreachable,
        total_labels_affected=total_labels_affected,
        max_depth_affected=max_depth,
        entry_points_affected=entry_points_affected,
        is_breaking_change=is_breaking,
        propagation_score=propagation_score,
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Helper Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def _is_reachable_from_any(
    graph: ScriptGraph,
    start_nodes: Set[str],
    target_node: str,
    max_depth: int,
) -> bool:
    """
    Check if target_node is reachable from any start node.

    Uses breadth-first search with depth limiting.

    Args:
        graph: Script graph to search
        start_nodes: Set of starting node IDs
        target_node: Target node ID to find
        max_depth: Maximum search depth

    Returns:
        True if target is reachable from any start node
    """
    if target_node in start_nodes:
        return True

    visited: Set[str] = set()
    queue: deque = deque()

    # Initialize queue with all start nodes
    for start in start_nodes:
        if start in graph.nodes:
            queue.append((start, 0))

    while queue:
        node_id, current_depth = queue.popleft()

        if node_id in visited or current_depth > max_depth:
            continue

        if node_id == target_node:
            return True

        visited.add(node_id)

        # Get outgoing edges
        edges = graph.get_outgoing_edges(node_id)
        for edge in edges:
            if edge.to_node not in visited:
                queue.append((edge.to_node, current_depth + 1))

    return False


def _calculate_max_depth(
    graph: ScriptGraph,
    changed_labels: List[str],
    max_depth: int,
) -> int:
    """
    Calculate maximum propagation depth from changed labels.

    Measures how far changes propagate through the flow graph.

    Args:
        graph: Script graph
        changed_labels: List of changed label node IDs
        max_depth: Maximum depth to search

    Returns:
        Maximum depth reached from any changed label
    """
    if not changed_labels:
        return 0

    max_reached = 0

    for label_id in changed_labels:
        if label_id not in graph.nodes:
            continue

        # BFS from this label
        visited: Set[str] = set()
        queue: deque = deque([(label_id, 0)])

        while queue:
            node_id, current_depth = queue.popleft()

            if node_id in visited or current_depth > max_depth:
                continue

            visited.add(node_id)
            max_reached = max(max_reached, current_depth)

            # Get outgoing edges
            edges = graph.get_outgoing_edges(node_id)
            for edge in edges:
                if edge.to_node not in visited:
                    queue.append((edge.to_node, current_depth + 1))

    return max_reached
