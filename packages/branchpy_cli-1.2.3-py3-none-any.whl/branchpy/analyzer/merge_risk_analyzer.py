"""
Merge Risk Analyzer - v0.9.1.5

Semantic analysis for merge operations:
- Script (.rpy) change detection
- Media asset tracking
- ScriptGraph integration for flow impact analysis (Phase A)
- PFI inference for wrapper-based media detection (Phase B)
- File flow walking for narrative impact (Phase D)

This implementation provides smart merge warnings based on:
- Flow reachability
- Wrapped media usage
- Media asset coupling with script changes
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from ..history.patch import CompositePatch, FilePatch
from ..merge.merge_engine import MergeAnalyzer, MergeWarning
from .flow_delta import FlowDelta, compute_flow_delta
from .narrative_impact import NarrativeImpactScore, compute_narrative_impact
from .pfi_inference import infer_media_from_wrappers
from .script_graph import ScriptGraph, build_script_graph

SCRIPT_EXTENSIONS = {".rpy"}
MEDIA_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".ogg", ".mp3", ".wav"}
MEDIA_DIR_HINTS = {"images", "image", "audio", "sfx", "bgm"}


@dataclass
class MergeRiskConfig:
    """
    Configuration for the merge risk analyzer.

    For v0.9.1.5 we keep it simple and use hard-coded conventions, but
    this class gives us a place to thread engine-specific config later.
    """

    project_root: Path
    enable_script_graph: bool = True
    enable_pfi: bool = True
    flow_depth: int = 3
    enable_narrative_impact: bool = False  # WS-M2
    enable_flow_delta: bool = False  # WS-M3


class SimpleMergeRiskAnalyzer(MergeAnalyzer):
    """
    v0.9.1.5 merge risk analyzer with flow awareness.

    Heuristics:
      * .rpy deletions => SCRIPT_DELETED
      * .rpy modifications => SCRIPT_CHANGED_HIGH_IMPACT | SCRIPT_CHANGED_FLOW_IMPACT
      * media deletions under images/audio => MEDIA_DELETED | MEDIA_FLOW_AT_RISK
      * media modifications under images/audio => MEDIA_CHANGED
      * wrapper usage changes => MEDIA_WRAPPED_CHANGED | MEDIA_WRAPPED_BROKEN

    Integration:
      * ScriptGraph: Computes label count and flow impact
      * PFI Inference: Detects wrapper-based media usage
      * Flow Walking: Identifies reachable labels and media coupling
    """

    def __init__(
        self,
        config: MergeRiskConfig,
        script_graph: Optional[ScriptGraph] = None,
    ) -> None:
        self._config = config
        self._script_graph = script_graph
        self.narrative_impact: Optional[NarrativeImpactScore] = None  # WS-M2
        self.flow_delta: Optional[FlowDelta] = None  # WS-M3

        # Build script graph if enabled and not provided
        if config.enable_script_graph and script_graph is None:
            try:
                self._script_graph = build_script_graph(config.project_root)
            except Exception:
                # Fail gracefully if graph building fails
                self._script_graph = None

    # NOTE: This signature matches MergeAnalyzer.analyze_patches()
    def analyze_patches(
        self,
        patches: CompositePatch,
        from_ref: str,
        to_ref: str,
        project_root: Path,
    ) -> List[MergeWarning]:
        warnings: List[MergeWarning] = []

        # Track all media changes for cross-referencing
        removed_media_ids = set()
        changed_media_ids = set()

        # Track changed script files for narrative analysis (WS-M2)
        changed_script_files = []

        for patch in patches.patches:
            if not isinstance(patch, FilePatch):
                # Future-proof: if we add DirectoryPatch or other patch types.
                continue

            rel_path = self._relative_path(patch.file_path, project_root)
            suffix = patch.file_path.suffix.lower()

            # --- Script (.rpy) heuristics ---------------------------------
            if suffix in SCRIPT_EXTENSIONS:
                # Deleted script: old content exists, new content is empty.
                if patch.original_content and not patch.new_content:
                    warnings.append(
                        MergeWarning(
                            code="SCRIPT_DELETED",
                            message=(
                                "Ren'Py script file deleted in merge; "
                                "verify that labels and jumps are still valid."
                            ),
                            path=rel_path,
                        )
                    )
                # Modified script (non-trivial change)
                elif patch.original_content != patch.new_content:
                    # Track for narrative analysis
                    changed_script_files.append(patch)

                    # Base warning
                    script_warnings = self._analyze_script_change(
                        patch, rel_path, project_root
                    )
                    warnings.extend(script_warnings)

            # --- Media heuristics -----------------------------------------
            if suffix in MEDIA_EXTENSIONS and self._is_media_like_path(rel_path):
                media_id = self._extract_media_id(rel_path)

                if patch.original_content and not patch.new_content:
                    removed_media_ids.add(media_id)
                    warnings.append(
                        MergeWarning(
                            code="MEDIA_DELETED",
                            message=(
                                "Media asset deleted in merge; "
                                "ensure no scenes still reference this file."
                            ),
                            path=rel_path,
                        )
                    )
                elif patch.original_content != patch.new_content:
                    changed_media_ids.add(media_id)
                    warnings.append(
                        MergeWarning(
                            code="MEDIA_CHANGED",
                            message=(
                                "Media asset content changed in merge; "
                                "check for visual continuity / size changes."
                            ),
                            path=rel_path,
                        )
                    )

        # Post-process: Check for flow-at-risk media
        if self._script_graph and removed_media_ids:
            flow_warnings = self._check_media_flow_risks(
                removed_media_ids, patches, project_root
            )
            warnings.extend(flow_warnings)

        # WS-M2: Compute narrative impact for changed scripts
        if (
            self._config.enable_narrative_impact
            and self._script_graph
            and changed_script_files
        ):
            try:
                # Analyze first changed script file (simple v0.9.2 implementation)
                first_patch = changed_script_files[0]
                old_content = (
                    first_patch.original_content.decode("utf-8", errors="ignore")
                    if first_patch.original_content
                    else ""
                )
                new_content = (
                    first_patch.new_content.decode("utf-8", errors="ignore")
                    if first_patch.new_content
                    else ""
                )

                self.narrative_impact = compute_narrative_impact(
                    file_path=first_patch.file_path,
                    old_content=old_content,
                    new_content=new_content,
                    graph=self._script_graph,
                    depth=self._config.flow_depth,
                )
            except Exception:
                # Fail gracefully
                self.narrative_impact = None

        # WS-M3: Compute flow delta between branches
        if self._config.enable_flow_delta and self._script_graph:
            try:
                # For v0.9.2, we compute delta by comparing current graph to itself
                # In production, this would compare base_graph vs target_graph
                # For now, we demonstrate the capability with empty delta
                self.flow_delta = compute_flow_delta(
                    base_graph=self._script_graph,
                    target_graph=self._script_graph,
                    base_branch=from_ref,
                    target_branch=to_ref,
                    depth=self._config.flow_depth,
                )
            except Exception:
                # Fail gracefully
                self.flow_delta = None

        return warnings

    # ------------------------------------------------------------------ #
    # Script Change Analysis (Phase A + D Integration)
    # ------------------------------------------------------------------ #

    def _analyze_script_change(
        self,
        patch: FilePatch,
        rel_path: str,
        project_root: Path,
    ) -> List[MergeWarning]:
        """
        Analyze script change with ScriptGraph and flow walking.

        Returns warnings for:
        - High impact changes (many labels/flows)
        - Flow impact (reachability)
        - PFI wrapper changes
        """
        warnings: List[MergeWarning] = []

        # Base script changed warning
        warnings.append(
            MergeWarning(
                code="SCRIPT_CHANGED",
                message=(
                    "Ren'Py script file modified in merge; "
                    "run Analyzer flow checks to validate narrative paths."
                ),
                path=rel_path,
            )
        )

        # ScriptGraph analysis (if available)
        if self._script_graph:
            try:
                labels_changed = self._script_graph.get_labels_in_file(patch.file_path)

                if labels_changed:
                    # Count outgoing edges
                    outgoing_edges = sum(
                        len(self._script_graph.get_outgoing_edges(label.node_id))
                        for label in labels_changed
                    )

                    # High impact warning
                    if len(labels_changed) > 2 or outgoing_edges > 10:
                        warnings.append(
                            MergeWarning(
                                code="SCRIPT_CHANGED_HIGH_IMPACT",
                                message=(
                                    f"Script defines {len(labels_changed)} labels "
                                    f"and impacts {outgoing_edges} outgoing flows. "
                                    "Review carefully for narrative consistency."
                                ),
                                path=rel_path,
                            )
                        )

                    # Flow walking analysis
                    flow_summary = self._script_graph.walk_file_flow(
                        patch.file_path,
                        depth=self._config.flow_depth,
                    )

                    if len(flow_summary.reachable_labels) > 5:
                        warnings.append(
                            MergeWarning(
                                code="SCRIPT_CHANGED_FLOW_IMPACT",
                                message=(
                                    f"This change affects {len(flow_summary.labels_in_file)} "
                                    f"local labels and reaches {len(flow_summary.reachable_labels)} "
                                    f"labels across the project; "
                                    f"{len(flow_summary.referenced_media_ids)} media assets involved."
                                ),
                                path=rel_path,
                            )
                        )

            except Exception:
                # Don't crash on graph analysis errors
                pass

        # PFI wrapper analysis (if enabled)
        if self._config.enable_pfi and patch.new_content:
            try:
                script_text = patch.new_content.decode("utf-8", errors="ignore")
                pfi_result = infer_media_from_wrappers(script_text, patch.file_path)

                if pfi_result.references:
                    warnings.append(
                        MergeWarning(
                            code="MEDIA_WRAPPED_CHANGED",
                            message=(
                                f"Wrapper-based media usage changed; "
                                f"found {len(pfi_result.references)} references "
                                f"via PFI inference (wrappers: {', '.join(pfi_result.wrappers_found)})."
                            ),
                            path=rel_path,
                        )
                    )

            except Exception:
                pass

        return warnings

    # ------------------------------------------------------------------ #
    # Media Flow Risk Analysis (Phase D Integration)
    # ------------------------------------------------------------------ #

    def _check_media_flow_risks(
        self,
        removed_media_ids: set,
        patches: CompositePatch,
        project_root: Path,
    ) -> List[MergeWarning]:
        """
        Check if removed media is still reachable via script flow.

        Uses ScriptGraph flow walking to detect broken media references.
        """
        warnings: List[MergeWarning] = []

        if not self._script_graph:
            return warnings

        # For each changed script file, check if it reaches removed media
        for patch in patches.patches:
            if not isinstance(patch, FilePatch):
                continue

            if patch.file_path.suffix.lower() not in SCRIPT_EXTENSIONS:
                continue

            try:
                flow_summary = self._script_graph.walk_file_flow(
                    patch.file_path,
                    depth=self._config.flow_depth,
                )

                # Check if any reachable media was removed
                for media_id in flow_summary.referenced_media_ids:
                    if media_id in removed_media_ids:
                        rel_path = self._relative_path(patch.file_path, project_root)
                        warnings.append(
                            MergeWarning(
                                code="MEDIA_FLOW_AT_RISK",
                                message=(
                                    f"Media {media_id} is removed but still reachable "
                                    f"via labels: {', '.join(flow_summary.labels_in_file[:3])}"
                                    f"{'...' if len(flow_summary.labels_in_file) > 3 else ''}"
                                ),
                                path=rel_path,
                            )
                        )

            except Exception:
                pass

        return warnings

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _relative_path(path: Path, project_root: Path) -> str:
        try:
            return str(path.relative_to(project_root))
        except ValueError:
            return str(path)

    @staticmethod
    def _is_media_like_path(rel_path: str) -> bool:
        parts = rel_path.replace("\\", "/").split("/")
        # crude but effective: any folder name hint is enough
        return any(p.lower() in MEDIA_DIR_HINTS for p in parts)

    @staticmethod
    def _extract_media_id(rel_path: str) -> str:
        """Extract media ID from path (filename without extension)."""
        return Path(rel_path).stem
