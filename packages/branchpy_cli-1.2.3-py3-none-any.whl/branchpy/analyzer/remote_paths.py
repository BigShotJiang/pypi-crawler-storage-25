"""
Remote path normalization utilities.

Handles path conversions and normalization across different remote environments:
- WSL: /mnt/c/... <-> C:/...
- SSH: POSIX path normalization
- Containers: workspace mount path handling
- Codespaces: workspace root semantics
- CI: platform-specific normalization

Governance: AXIS5-V0.9.2-REMOTE-BQS
"""

import re
from pathlib import Path, PureWindowsPath
from typing import Optional

from branchpy.remote.context import RemoteContext

# WSL mount path pattern: /mnt/<drive>/...
_WSL_MNT_RE = re.compile(r"^/mnt/([a-zA-Z])/(.*)$")


def normalize_path_for_remote(
    ctx: Optional[RemoteContext],
    raw_path: str,
) -> str:
    """
    Normalize a file path for the given remote context.

    Converts paths to a canonical internal representation based on the
    remote environment type. This ensures consistent path handling across
    local, WSL, SSH, containers, and CI environments.

    Internal canonical format: POSIX-style forward slashes (e.g., C:/Users/...)
    even on Windows, for cross-platform consistency.

    Args:
        ctx: Remote context (None = local mode)
        raw_path: Raw path string to normalize

    Returns:
        Normalized path string in canonical POSIX-like format

    Examples:
        >>> from branchpy.remote.context import RemoteContext
        >>>
        >>> # Local mode (resolve + POSIX)
        >>> normalize_path_for_remote(None, "C:\\Users\\dev\\project")
        'C:/Users/dev/project'
        >>>
        >>> # WSL mode: /mnt/c/... → C:/...
        >>> wsl_ctx = RemoteContext(mode="wsl", ...)
        >>> normalize_path_for_remote(wsl_ctx, "/mnt/c/Users/dev/project")
        'C:/Users/dev/project'
        >>>
        >>> # SSH/container mode (POSIX normalization)
        >>> ssh_ctx = RemoteContext(mode="ssh", ...)
        >>> normalize_path_for_remote(ssh_ctx, "/home/dev//project/")
        '/home/dev/project'
    """
    # 1) No context or local mode: resolve and use POSIX format
    if ctx is None or ctx.mode == "local":
        # Check if it's already a Linux-style absolute path
        if raw_path.startswith("/") and ":" not in raw_path:
            # Use POSIX normalization to avoid Windows drive resolution
            return normalize_posix_path(raw_path)

        # Check if it's a Windows path (e.g., C:\... or C:/...)
        # Use PureWindowsPath to detect drive even on Linux
        try:
            win_path = PureWindowsPath(raw_path)
            if win_path.drive:
                # It's a Windows path - convert to canonical POSIX format
                return str(win_path).replace("\\", "/")
        except Exception:
            pass

        try:
            return Path(raw_path).resolve(strict=False).as_posix()
        except Exception:
            # Fallback if resolve fails
            return Path(raw_path).as_posix()

    mode = ctx.mode

    # 2) WSL: /mnt/c/... → C:/...
    if mode == "wsl":
        win_path = wsl_path_to_windows(raw_path)
        if win_path is not None:
            # Already normalized by wsl_path_to_windows(), don't call normalize_posix_path
            # because that would treat it as relative on Linux and prepend CWD
            return win_path
        # Not a mount path, normalize as POSIX
        return normalize_posix_path(raw_path)

    # 3) SSH, CI (Linux remote, already POSIX)
    if mode in ("ssh", "ci"):
        return normalize_posix_path(raw_path)

    # 4) Container / Codespaces (POSIX, workspace-root mapping in future)
    if mode in ("container", "codespaces"):
        return normalize_posix_path(raw_path)

    # 5) Fallback for unknown modes
    return normalize_posix_path(raw_path)


def wsl_path_to_windows(wsl_path: str) -> Optional[str]:
    """
    Convert WSL path to Windows path.

    Converts /mnt/c/... → C:/... using POSIX-style forward slashes
    for internal consistency.

    Args:
        wsl_path: WSL-style path (e.g., "/mnt/c/Users/...")

    Returns:
        Windows-style path (e.g., "C:/Users/...") or None if not a WSL mount

    Examples:
        >>> wsl_path_to_windows("/mnt/c/Users/dev/project")
        'C:/Users/dev/project'
        >>> wsl_path_to_windows("/mnt/d/Data/file.txt")
        'D:/Data/file.txt'
        >>> wsl_path_to_windows("/home/user/file.txt")
        None
    """
    match = _WSL_MNT_RE.match(wsl_path)
    if not match:
        return None

    drive = match.group(1).upper()
    rest = match.group(2)

    # Use forward slash for internal canonical format
    return f"{drive}:/{rest}".replace("\\", "/")


def windows_path_to_wsl(windows_path: str) -> Optional[str]:
    """
    Convert Windows path to WSL path.

    Converts C:/Users/... or C:\\Users\\... to /mnt/c/...

    Args:
        windows_path: Windows-style path (e.g., "C:\\Users\\...")

    Returns:
        WSL-style path (e.g., "/mnt/c/Users/...") or None if not a drive path

    Examples:
        >>> windows_path_to_wsl("C:\\Users\\dev\\project")
        '/mnt/c/Users/dev/project'
        >>> windows_path_to_wsl("D:/Data/file.txt")
        '/mnt/d/Data/file.txt'
        >>> windows_path_to_wsl("/home/user/file.txt")
        None
    """
    # Use PureWindowsPath for cross-platform compatibility (works on Linux)
    p = PureWindowsPath(windows_path)
    drive = p.drive.rstrip(":\\/")

    if not drive:
        return None

    # Extract path parts excluding drive
    # Use anchor to properly split drive from path
    path_without_drive = str(p).replace(p.drive, "", 1).lstrip("\\/")

    if not path_without_drive:
        return f"/mnt/{drive.lower()}/"

    # Normalize separators to forward slash
    path_posix = path_without_drive.replace("\\", "/")

    return f"/mnt/{drive.lower()}/{path_posix}"


def normalize_posix_path(posix_path: str) -> str:
    """
    Normalize a POSIX path (remove double slashes, trailing slash, etc.).

    Uses PurePosixPath for pure POSIX normalization without Windows
    drive resolution, then manually resolves .. and . components.

    Args:
        posix_path: POSIX-style path

    Returns:
        Normalized POSIX path

    Examples:
        >>> normalize_posix_path("/home/dev//project/")
        '/home/dev/project'
        >>> normalize_posix_path("//workspace///file.py")
        '/workspace/file.py'
        >>> normalize_posix_path("/home/./user/../dev/project")
        '/home/dev/project'
    """

    # For Linux-style absolute paths, use PurePosixPath to avoid Windows resolution
    if posix_path.startswith("/") and ":" not in posix_path:
        # Split into parts and manually resolve .., .
        parts = []
        for part in posix_path.split("/"):
            if not part or part == ".":
                # Skip empty parts (from //) and current directory
                continue
            elif part == "..":
                # Parent directory: pop if possible
                if parts:
                    parts.pop()
            else:
                parts.append(part)

        if not parts:
            return "/"
        return "/" + "/".join(parts)

    # Windows path or relative path: use Path() resolution
    p = Path(posix_path)
    try:
        return p.resolve(strict=False).as_posix()
    except Exception:
        return p.as_posix()

    # Windows path or relative path: use standard Path() resolution
    p = Path(posix_path)
    try:
        # resolve(strict=False) handles .., ., double slashes without requiring file existence
        return p.resolve(strict=False).as_posix()
    except Exception:
        # Fallback if resolve fails (e.g., invalid characters)
        return p.as_posix()


def get_display_path(ctx: Optional[RemoteContext], internal_path: str) -> str:
    """
    Convert internal canonical path to user-facing display format.

    Translates internal POSIX-like paths back to environment-specific
    display format for user messages, logs, and telemetry.

    Args:
        ctx: Remote context
        internal_path: Internal canonical path (POSIX-like)

    Returns:
        User-friendly display path appropriate for the environment

    Examples:
        >>> # Local mode: unchanged (already canonical)
        >>> get_display_path(None, "C:/Users/dev/project/file.py")
        'C:/Users/dev/project/file.py'
        >>>
        >>> # WSL mode: convert back to /mnt/c/...
        >>> wsl_ctx = RemoteContext(mode="wsl", host_platform="linux", ...)
        >>> get_display_path(wsl_ctx, "C:/Users/dev/project/file.py")
        '/mnt/c/Users/dev/project/file.py'
        >>>
        >>> # SSH/CI/container: POSIX paths unchanged
        >>> ssh_ctx = RemoteContext(mode="ssh", host_platform="linux", ...)
        >>> get_display_path(ssh_ctx, "/home/dev/project/file.py")
        '/home/dev/project/file.py'
    """
    if ctx is None or ctx.mode == "local":
        # Local mode: return canonical format as-is
        return internal_path

    if ctx.mode == "wsl":
        # Convert back to WSL /mnt/c/... format for terminal display
        wsl_path = windows_path_to_wsl(internal_path)
        return wsl_path if wsl_path else internal_path

    # SSH, CI, container, codespaces: POSIX paths are already user-friendly
    return internal_path
