"""
Media Indexer - v0.9.1.4 Compare UX & Media-Aware Diffs

Abstracts media indexing for different game engines.
Provides Protocol-based interface for extensibility.

BQS Compliance:
- Engine-agnostic Protocol design
- Type-safe with mypy compliance
- Cross-platform path handling
- Extensible for future engines (Godot, Unity, etc.)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Protocol

# Type aliases for clarity
MediaIndexEntry = Dict[str, Any]
MediaIndex = Dict[str, MediaIndexEntry]


class MediaIndexer(Protocol):
    """
    Protocol for media indexing implementations.

    Allows engine-specific indexers to provide unified interface
    for media diff computation.
    """

    def index_media(self, project_root: Path) -> MediaIndex:
        """
        Build media index for project.

        Args:
            project_root: Path to project root directory

        Returns:
            MediaIndex mapping media_id to entry with:
            - media_id: str
            - path: str (relative to project root)
            - call_sites: List[Dict] with file/line/function/context
        """
        ...


class RenpyMediaIndexer:
    """
    Ren'Py-specific media indexer.

    Walks Ren'Py project structure and builds media index by:
    1. Scanning /images, /audio directories for assets
    2. Parsing .rpy files for show/scene/play statements
    3. Mapping call sites to media references

    Future Enhancement:
        Hook into existing Analyzer/Media Phase A pipeline
        for full semantic analysis.
    """

    def index_media(self, project_root: Path) -> MediaIndex:
        """
        Build media index for Ren'Py project.

        Args:
            project_root: Path to Ren'Py game directory

        Returns:
            MediaIndex with detected assets and call sites

        Note:
            v0.9.1.4 implementation is a simplified stub.
            Full integration with Analyzer/Media pipeline pending.
        """
        index: MediaIndex = {}

        # Phase 1: Scan for media files
        media_dirs = ["images", "audio", "video", "gui"]
        for dir_name in media_dirs:
            media_path = project_root / dir_name
            if not media_path.exists():
                continue

            for asset_file in media_path.rglob("*"):
                if not asset_file.is_file():
                    continue

                # Skip non-media extensions
                if asset_file.suffix.lower() not in {
                    ".png",
                    ".jpg",
                    ".jpeg",
                    ".webp",  # Images
                    ".mp3",
                    ".ogg",
                    ".wav",
                    ".opus",  # Audio
                    ".webm",
                    ".ogv",
                    ".mp4",  # Video
                }:
                    continue

                # Derive media_id from filename (Ren'Py convention: basename without extension)
                # e.g., images/bg_cafe.png -> media_id = "bg_cafe"
                media_id = asset_file.stem
                rel_path = asset_file.relative_to(project_root)

                index[media_id] = {
                    "media_id": media_id,
                    "path": str(rel_path).replace("\\", "/"),
                    "call_sites": self._find_call_sites(
                        project_root,
                        media_id,
                    ),
                }

        return index

    def _find_call_sites(
        self,
        project_root: Path,
        media_id: str,
    ) -> List[Dict[str, Any]]:
        """
        Find call sites for media asset in .rpy files.

        Args:
            project_root: Project root path
            media_id: Media identifier to search for

        Returns:
            List of call site dicts with file/line/function/context

        Note:
            Simplified implementation. Full version would use:
            - AST parsing for accurate line numbers
            - Semantic analysis for label/function context
            - Renpy lexer for proper statement detection
        """
        call_sites: List[Dict[str, Any]] = []

        # Search .rpy files for references
        # Try both game/ subdirectory and project root
        search_dirs = []
        game_dir = project_root / "game"
        if game_dir.exists():
            search_dirs.append(game_dir)
        else:
            # No game/ dir, search project root directly
            search_dirs.append(project_root)

        # Extract just the media name (without directory path)
        # e.g., "images/bg_cafe" -> "bg_cafe"
        media_name = Path(media_id).name

        for search_dir in search_dirs:
            for rpy_file in search_dir.rglob("*.rpy"):
                try:
                    content = rpy_file.read_text(encoding="utf-8", errors="ignore")
                    lines = content.splitlines()

                    for line_num, line in enumerate(lines, start=1):
                        # Simple regex-free detection (v0.9.1.4 stub)
                        # Look for media name in lines with show/scene/play keywords
                        if media_name in line and any(
                            keyword in line
                            for keyword in ["show", "scene", "play", "image"]
                        ):
                            call_sites.append(
                                {
                                    "file": str(
                                        rpy_file.relative_to(project_root)
                                    ).replace("\\", "/"),
                                    "line": line_num,
                                    "function": self._extract_label_context(
                                        lines, line_num
                                    ),
                                    "context": line.strip(),
                                }
                            )

                except (OSError, UnicodeDecodeError):
                    continue

        return call_sites

    @staticmethod
    def _extract_label_context(lines: List[str], target_line: int) -> str:
        """
        Find nearest label/function context for line.

        Args:
            lines: File content as list of lines
            target_line: Line number to find context for (1-indexed)

        Returns:
            Label name or "unknown"
        """
        # Search backwards for label statement
        for i in range(target_line - 1, -1, -1):
            line = lines[i].strip()
            if line.startswith("label "):
                # Extract label name
                label_name = line[6:].split("(")[0].split(":")[0].strip()
                return f"label {label_name}"

        return "unknown"


class GodotMediaIndexer:
    """
    Godot-specific media indexer (future implementation).

    Placeholder for Phase 5+ when multi-engine support is added.
    """

    def index_media(self, project_root: Path) -> MediaIndex:
        """Stub for future Godot support."""
        # TODO: Implement Godot scene/resource parsing
        return {}


class UnityMediaIndexer:
    """
    Unity-specific media indexer (future implementation).

    Placeholder for Phase 5+ when multi-engine support is added.
    """

    def index_media(self, project_root: Path) -> MediaIndex:
        """Stub for future Unity support."""
        # TODO: Implement Unity asset database parsing
        return {}
