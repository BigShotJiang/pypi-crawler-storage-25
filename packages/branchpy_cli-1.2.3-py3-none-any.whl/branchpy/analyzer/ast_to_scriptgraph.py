"""
AST to ScriptGraph Adapter — v0.9.6 Milestone 1

Converts AST nodes to ScriptGraph format for flow analysis.
This is a bridge between the new AST parser and the existing ScriptGraph analyzer.

Status: Day 6 Phase 3 implementation (basic adapter)
Future: Replace regex-based ScriptGraph parsing entirely with AST parsing
"""

from pathlib import Path
from typing import List, Tuple

from branchpy.analyzer.script_graph import ScriptEdge, ScriptNode
from branchpy.semantics.ast import (
    AudioNode,
    CallNode,
    DefineNode,
    ImageNode,
    InitNode,
    JumpNode,
    LabelNode,
    Node,
    ReturnNode,
)


def ast_to_script_nodes_and_edges(
    ast_nodes: List[Node],
    file_path: Path,
) -> Tuple[List[ScriptNode], List[ScriptEdge]]:
    """
    Convert AST nodes to ScriptGraph format.

    Args:
        ast_nodes: List of AST nodes from parser
        file_path: Path to source file (for node IDs)

    Returns:
        Tuple of (nodes, edges) compatible with ScriptGraph

    Mapping:
        - LabelNode → ScriptNode (type="label")
        - JumpNode → ScriptEdge (type="jump")
        - CallNode → ScriptEdge (type="call")
        - ReturnNode → No edge (tracked but not as explicit edge for now)
        - InitNode → Metadata (could be separate init region)
        - DefineNode → Metadata (variable declarations)
        - ImageNode/AudioNode → media_refs in parent label

    Limitations (Day 6):
        - Returns not tracked as explicit edges (future: add "return" edge type)
        - Init blocks not separated into regions (future: add init_region)
        - Defines not stored as declarations (future: add variable tracking)
        - Media refs not collected per label (future: walk AST tree)
    """
    nodes: List[ScriptNode] = []
    edges: List[ScriptEdge] = []

    current_label: str | None = None
    media_refs: List[str] = []

    def process_node(node: Node) -> None:
        nonlocal current_label, media_refs

        if isinstance(node, LabelNode):
            # Save previous label's media refs
            if current_label:
                for sn in nodes:
                    if sn.name == current_label:
                        sn.media_refs.extend(media_refs)
                        break

            # Start new label
            current_label = node.name
            media_refs = []

            nodes.append(
                ScriptNode(
                    file_path=file_path,
                    node_type="label",
                    name=node.name,
                    line_number=node.line_number,
                    media_refs=[],
                )
            )

        elif isinstance(node, JumpNode):
            if current_label:
                edges.append(
                    ScriptEdge(
                        from_node=f"{file_path.as_posix()}:{current_label}",
                        to_node=f"{file_path.as_posix()}:{node.target}",
                        edge_type="jump",
                        line_number=node.line_number,
                    )
                )

        elif isinstance(node, CallNode):
            if current_label:
                edges.append(
                    ScriptEdge(
                        from_node=f"{file_path.as_posix()}:{current_label}",
                        to_node=f"{file_path.as_posix()}:{node.target}",
                        edge_type="call",
                        line_number=node.line_number,
                    )
                )

        elif isinstance(node, ReturnNode):
            # Future: Track as "return" edge type
            # For now, just note that returns exist in this label
            pass

        elif isinstance(node, InitNode):
            # Future: Could create separate init_region nodes
            # For now, treat as metadata
            pass

        elif isinstance(node, DefineNode):
            # Future: Store as variable declaration metadata
            # For now, just track that defines exist
            pass

        elif isinstance(node, ImageNode):
            # Collect media references
            if node.action in ("show", "scene", "hide"):
                media_refs.append(f"image:{node.image_name}")

        elif isinstance(node, AudioNode):
            # Collect media references
            if node.action in ("play", "queue") and node.file_path:
                media_refs.append(f"audio:{node.file_path}")

        # Recursively process children
        if hasattr(node, "children") and node.children:
            for child in node.children:
                process_node(child)

    # Process all top-level nodes
    for node in ast_nodes:
        process_node(node)

    # Save last label's media refs
    if current_label:
        for sn in nodes:
            if sn.name == current_label:
                sn.media_refs.extend(media_refs)
                break

    return nodes, edges
