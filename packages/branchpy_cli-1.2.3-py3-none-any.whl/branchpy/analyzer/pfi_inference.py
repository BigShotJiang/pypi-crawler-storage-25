"""
PFI (Python Function Invocation) Inference — v0.9.2 WS-A2 Analyzer Phase B

Wrapper-based media detection for Ren'Py (and future engines).
Detects media references through helper functions/wrappers.

v0.9.2 WS-A2 Enhancements:
- Multi-line wrapper call detection
- Simple variable flow tracking
- Remote context integration (WS-A1)

Example:
    show_bg("bg_cafe")  →  infers image reference "bg_cafe"
    play_music("theme_day")  →  infers audio reference "theme_day"
    show_bg(\n  "cafe"\n)  →  multi-line detection (WS-A2)
    bg = "cafe"; show_bg(bg)  →  variable tracking (WS-A2)

BQS Compliance:
- Engine-agnostic pattern matching
- Type-safe with full annotations
- Extensible registry design
- Performance: O(n) linear scan (regex) + O(n) AST walk (v2)

Governance: AXIS5-V0.9.2-REMOTE-BQS
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


# Simple telemetry shim
def _emit_telemetry(event_type: str, properties: Dict[str, Any]) -> None:
    """Emit telemetry event (no-op if unavailable)."""
    try:
        from pathlib import Path as TelPath

        from ..telemetry import LocalTelemetryWriter, TelemetryEvent, create_trace_id

        telemetry_dir = TelPath.home() / ".branchpy" / "telemetry"
        telemetry_dir.mkdir(parents=True, exist_ok=True)

        writer = LocalTelemetryWriter(telemetry_dir)
        event = TelemetryEvent(
            ts=writer.iso_now(),
            session_id=writer.session_id,
            trace_id=create_trace_id(),
            category="analyzer",
            name=event_type,
            attrs=properties,
        )
        writer.write_event(event)
    except Exception:
        pass


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Configuration
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


# PFI Wrapper Registry
# Maps wrapper function names to their media kind and argument position
PFI_WRAPPERS: Dict[str, Dict[str, Any]] = {
    # Image wrappers
    "show_bg": {"kind": "image", "arg_index": 0},
    "show_char": {"kind": "image", "arg_index": 0},
    "show_character": {"kind": "image", "arg_index": 0},
    "show_sprite": {"kind": "image", "arg_index": 0},
    "show_cg": {"kind": "image", "arg_index": 0},
    "display_image": {"kind": "image", "arg_index": 0},
    # Audio wrappers
    "play_music": {"kind": "audio", "arg_index": 0},
    "play_sound": {"kind": "audio", "arg_index": 0},
    "play_audio": {"kind": "audio", "arg_index": 0},
    "play_voice": {"kind": "audio", "arg_index": 0},
    "queue_music": {"kind": "audio", "arg_index": 0},
    # Video wrappers
    "play_movie": {"kind": "video", "arg_index": 0},
    "show_video": {"kind": "video", "arg_index": 0},
}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Data Structures
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass
class CallInfo:
    """
    Information about a wrapper function call (WS-A2).

    Attributes:
        wrapper_name: Function name (e.g., "show_bg")
        args: Positional arguments (resolved or raw)
        kwargs: Keyword arguments
        lineno: Starting line number
        end_lineno: Ending line number (for multi-line calls)

    Governance: AXIS5-V0.9.2-REMOTE-BQS
    """

    wrapper_name: str
    args: List[Optional[str]]
    kwargs: Dict[str, Any]
    lineno: int
    end_lineno: Optional[int] = None


@dataclass
class MediaReference:
    """
    Media reference detected in code.

    Attributes:
        media_id: Media asset identifier (e.g., "bg_cafe")
        media_kind: Type of media ("image" | "audio" | "video")
        source: Detection method ("pfi" | "pfi_multiline" | "pfi_variable")
        file_path: Source file path
        line_number: Line where reference found
        end_line_number: Ending line (for multi-line calls) [WS-A2]
        wrapper_name: Wrapper function name (if source="pfi*")
        variable_name: Variable name (if resolved from variable) [WS-A2]
        confidence: Confidence score 0.0-1.0
    """

    media_id: str
    media_kind: str
    source: str
    file_path: Path
    line_number: int
    end_line_number: Optional[int] = None  # WS-A2: multi-line support
    wrapper_name: Optional[str] = None
    variable_name: Optional[str] = None  # WS-A2: variable tracking
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry/export."""
        return {
            "media_id": self.media_id,
            "media_kind": self.media_kind,
            "source": self.source,
            "file_path": str(self.file_path),
            "line_number": self.line_number,
            "end_line_number": self.end_line_number,
            "wrapper_name": self.wrapper_name,
            "variable_name": self.variable_name,
            "confidence": self.confidence,
        }


@dataclass
class PFIAnalysisResult:
    """
    Result of PFI inference analysis.

    Attributes:
        file_path: File analyzed
        references: List of detected media references
        wrappers_found: Set of wrapper names encountered
        lines_scanned: Number of lines processed
    """

    file_path: Path
    references: List[MediaReference] = field(default_factory=list)
    wrappers_found: Set[str] = field(default_factory=set)
    lines_scanned: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry/export."""
        return {
            "file_path": str(self.file_path),
            "reference_count": len(self.references),
            "wrappers_found": list(self.wrappers_found),
            "lines_scanned": self.lines_scanned,
        }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# WS-A2: AST-Based Multi-line Detection & Variable Tracking
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def extract_variable_assignments(ast_tree: ast.Module) -> Dict[str, str]:
    """
    Extract simple variable assignments from AST (WS-A2).

    Tracks only direct string literal assignments:
        x = "value"      → {"x": "value"}
        y = x            → {"y": "value"} (if x already tracked)
        z = f"val{x}"    → NOT TRACKED (expressions excluded)

    Args:
        ast_tree: Parsed AST module

    Returns:
        Dictionary mapping variable names to string values

    Performance:
        O(n) single-pass AST walk

    Governance:
        AXIS5-V0.9.2-REMOTE-BQS
    """
    var_map: Dict[str, str] = {}

    for node in ast.walk(ast_tree):
        if isinstance(node, ast.Assign):
            # Only handle single target: x = "value"
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                var_name = node.targets[0].id

                # Case 1: Direct string literal
                if isinstance(node.value, ast.Constant) and isinstance(
                    node.value.value, str
                ):
                    var_map[var_name] = node.value.value

                # Case 2: Variable reference (transitive)
                elif isinstance(node.value, ast.Name):
                    ref_name = node.value.id
                    if ref_name in var_map:
                        var_map[var_name] = var_map[ref_name]

    return var_map


def find_wrapper_calls_in_ast(
    ast_tree: ast.Module,
    wrappers: Dict[str, Dict[str, Any]],
) -> List[CallInfo]:
    """
    Find all wrapper function calls in AST (WS-A2 multi-line detection).

    Detects:
        - Single-line: show_bg("cafe")
        - Multi-line: show_bg(\n  "cafe"\n)
        - With kwargs: play_music("theme", loop=True)

    Args:
        ast_tree: Parsed AST module
        wrappers: Wrapper registry (PFI_WRAPPERS)

    Returns:
        List of CallInfo objects with call details

    Performance:
        O(n) single-pass AST walk

    Governance:
        AXIS5-V0.9.2-REMOTE-BQS
    """
    calls: List[CallInfo] = []

    for node in ast.walk(ast_tree):
        if isinstance(node, ast.Call):
            # Check if it's a wrapper function
            if isinstance(node.func, ast.Name) and node.func.id in wrappers:
                wrapper_name = node.func.id

                # Extract positional args
                args: List[Optional[str]] = []
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        args.append(arg.value)
                    elif isinstance(arg, ast.Name):
                        args.append(arg.id)  # Variable name (will resolve later)
                    else:
                        args.append(None)  # Expression (skip)

                # Extract keyword args
                kwargs: Dict[str, Any] = {}
                for keyword in node.keywords:
                    if isinstance(keyword.value, ast.Constant):
                        kwargs[keyword.arg] = keyword.value.value

                calls.append(
                    CallInfo(
                        wrapper_name=wrapper_name,
                        args=args,
                        kwargs=kwargs,
                        lineno=node.lineno,
                        end_lineno=(
                            node.end_lineno
                            if hasattr(node, "end_lineno")
                            else node.lineno
                        ),
                    )
                )

    return calls


def resolve_media_references(
    calls: List[CallInfo],
    var_map: Dict[str, str],
    wrappers: Dict[str, Dict[str, Any]],
    file_path: Path,
) -> List[MediaReference]:
    """
    Resolve wrapper calls to media references using variable tracking (WS-A2).

    Args:
        calls: List of detected wrapper calls
        var_map: Variable name → value mapping
        wrappers: Wrapper registry
        file_path: Source file path

    Returns:
        List of resolved MediaReference objects

    Governance:
        AXIS5-V0.9.2-REMOTE-BQS
    """
    references: List[MediaReference] = []

    for call in calls:
        config = wrappers[call.wrapper_name]
        arg_index = config.get("arg_index", 0)

        if arg_index >= len(call.args):
            continue

        arg_value = call.args[arg_index]
        if arg_value is None:
            continue

        # Determine source type and resolve value
        if arg_value in var_map:
            # Variable reference
            media_id = var_map[arg_value]
            source = "pfi_variable"
            variable_name = arg_value
            confidence = 0.9
        else:
            # Direct string literal or unresolved variable
            media_id = arg_value
            source = "pfi_multiline" if call.end_lineno != call.lineno else "pfi"
            variable_name = None
            confidence = 1.0

        references.append(
            MediaReference(
                media_id=media_id,
                media_kind=config["kind"],
                source=source,
                file_path=file_path,
                line_number=call.lineno,
                end_line_number=call.end_lineno,
                wrapper_name=call.wrapper_name,
                variable_name=variable_name,
                confidence=confidence,
            )
        )

    return references


def infer_media_from_wrappers_v2(
    script_text: str,
    file_path: Path,
    wrappers: Optional[Dict[str, Dict[str, Any]]] = None,
    remote_ctx: Optional[Any] = None,  # RemoteAnalyzerContext from WS-A1
) -> PFIAnalysisResult:
    """
    Analyze script for PFI wrappers with multi-line and variable tracking (WS-A2).

    This is the WS-A2 enhanced version that uses AST parsing for:
    - Multi-line wrapper detection
    - Simple variable flow tracking
    - Remote context integration (WS-A1)

    Args:
        script_text: Source code to analyze
        file_path: Path to source file
        wrappers: Wrapper registry (defaults to PFI_WRAPPERS)
        remote_ctx: Optional remote analyzer context (WS-A1)

    Returns:
        PFIAnalysisResult with detected references

    Performance:
        Target: <100ms per 1000 lines
        AST parsing: ~2ms overhead (from WS-A1)
        Variable tracking: O(n) single pass
        Call detection: O(n) single pass

    Fallback:
        On parse errors, falls back to v0.9.1.5 regex-based detection

    Governance:
        AXIS5-V0.9.2-REMOTE-BQS
    """
    if wrappers is None:
        wrappers = PFI_WRAPPERS

    result = PFIAnalysisResult(file_path=file_path)
    result.lines_scanned = len(script_text.splitlines())

    try:
        # Use WS-A1 AST parsing with remote context
        from branchpy.analyzer.parser import ParseContext, parse_python_source

        parse_ctx = ParseContext(
            path=str(file_path),
            remote_ctx=remote_ctx,
        )

        ast_tree = parse_python_source(script_text, parse_ctx)

        # Phase 1: Extract variable assignments
        var_map = extract_variable_assignments(ast_tree)

        # Phase 2: Find wrapper calls
        calls = find_wrapper_calls_in_ast(ast_tree, wrappers)

        # Phase 3: Resolve to media references
        references = resolve_media_references(calls, var_map, wrappers, file_path)

        result.references = references
        result.wrappers_found = {call.wrapper_name for call in calls}

        # Emit telemetry
        _emit_telemetry(
            "pfi_inference.multi_line",
            {
                "file": str(file_path),
                "refs_found": len(references),
                "multiline_refs": sum(
                    1 for r in references if r.source == "pfi_multiline"
                ),
                "variable_refs": sum(
                    1 for r in references if r.source == "pfi_variable"
                ),
                "variables_tracked": len(var_map),
                "remote_mode": (
                    remote_ctx.remote.mode
                    if remote_ctx and hasattr(remote_ctx, "remote")
                    else "local"
                ),
            },
        )

    except Exception as e:
        # Fallback to v0.9.1.5 regex-based detection
        _emit_telemetry(
            "pfi_inference.fallback",
            {
                "file": str(file_path),
                "error": str(e),
                "fallback": "regex",
            },
        )

        # Call original v0.9.1.5 function
        return infer_media_from_wrappers(script_text, file_path, wrappers)

    return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PFI Inference Engine (v0.9.1.5 Regex-Based)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def infer_media_from_wrappers(
    script_text: str,
    file_path: Path,
    wrappers: Optional[Dict[str, Dict[str, Any]]] = None,
) -> PFIAnalysisResult:
    """
    Scan script for wrapper patterns and infer media references.

    Uses simple regex matching to detect wrapper function calls:
        wrapper_name("media_id")
        wrapper_name('media_id')
        wrapper_name(variable)  # ignored in v0

    Args:
        script_text: Source code to analyze
        file_path: Path to source file
        wrappers: Wrapper registry (defaults to PFI_WRAPPERS)

    Returns:
        PFIAnalysisResult with detected references

    Performance:
        O(n*w) where n = lines, w = wrapper count
        Typical: ~1ms per 1000 lines

    Limitations (v0):
        - String literals only (no variable resolution)
        - Single-line patterns only
        - No expression evaluation
        - No context awareness (may miss conditionals)
    """
    if wrappers is None:
        wrappers = PFI_WRAPPERS

    result = PFIAnalysisResult(file_path=file_path)
    lines = script_text.splitlines()
    result.lines_scanned = len(lines)

    for line_num, line in enumerate(lines, start=1):
        # Strip comments
        if "#" in line:
            line = line[: line.index("#")]

        # Check each registered wrapper
        for wrapper_name, config in wrappers.items():
            # Pattern: wrapper_name("media_id") or wrapper_name('media_id')
            # Using raw string for clarity
            pattern = rf'{re.escape(wrapper_name)}\s*\(\s*["\']([^"\']+)["\']'

            matches = re.finditer(pattern, line)

            for match in matches:
                media_id = match.group(1)

                # Filter out obvious non-media (variables, expressions)
                if any(char in media_id for char in ["{", "}", "[", "]", "."]):
                    continue

                result.references.append(
                    MediaReference(
                        media_id=media_id,
                        media_kind=config["kind"],
                        source="pfi",
                        file_path=file_path,
                        line_number=line_num,
                        wrapper_name=wrapper_name,
                    )
                )
                result.wrappers_found.add(wrapper_name)

    return result


def analyze_file_for_pfi(file_path: Path) -> PFIAnalysisResult:
    """
    Analyze a file for PFI wrapper usage.

    Convenience wrapper around infer_media_from_wrappers().

    Args:
        file_path: Path to file to analyze

    Returns:
        PFIAnalysisResult

    Raises:
        FileNotFoundError: If file doesn't exist
        UnicodeDecodeError: If file encoding is incompatible
    """
    try:
        content = file_path.read_text(encoding="utf-8", errors="ignore")
        result = infer_media_from_wrappers(content, file_path)

        # Emit telemetry
        if result.references:
            _emit_telemetry(
                "pfi_inference_run",
                {
                    "file": str(file_path),
                    "refs_found": len(result.references),
                    "wrappers": list(result.wrappers_found),
                },
            )

        return result

    except Exception as e:
        _emit_telemetry(
            "pfi_inference_error",
            {
                "file": str(file_path),
                "error": str(e),
            },
        )
        # Return empty result rather than crash
        return PFIAnalysisResult(file_path=file_path)


def analyze_files_for_pfi(
    file_paths: List[Path],
    wrappers: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[PFIAnalysisResult]:
    """
    Analyze a pre-built list of files for PFI wrapper usage.

    Preferred entry point when the caller already holds a file list (e.g.,
    media_cmd.py Pass 1 result). Avoids a redundant filesystem walk.

    Args:
        file_paths: Explicit list of file paths to analyze.
        wrappers: Wrapper registry. Callers should pass an isolated copy built
                  via _build_scan_wrappers(), not the global PFI_WRAPPERS.
                  Defaults to a fresh copy of PFI_WRAPPERS if not supplied.

    Returns:
        List[PFIAnalysisResult] for files that produced at least one reference.

    Performance:
        O(n) over file_paths — no filesystem traversal.

    Governance:
        MEDIA-PHASE-B-WP-B0
    """
    if wrappers is None:
        wrappers = {k: v.copy() for k, v in PFI_WRAPPERS.items()}

    results: List[PFIAnalysisResult] = []
    for file_path in file_paths:
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            result = infer_media_from_wrappers(content, file_path, wrappers)
            if result.references:
                results.append(result)
        except Exception as e:
            _emit_telemetry(
                "pfi_inference_error",
                {"file": str(file_path), "error": str(e)},
            )
    return results


def analyze_project_for_pfi(
    project_root: Path,
    file_patterns: Optional[List[str]] = None,
) -> List[PFIAnalysisResult]:
    """
    Analyze entire project for PFI wrapper usage.

    Args:
        project_root: Project root directory
        file_patterns: File patterns to analyze (default: ["*.rpy"])

    Returns:
        List of PFIAnalysisResult for each file

    Performance:
        Typical project (100 files): ~100ms
        Large project (500 files): ~500ms
    """
    if file_patterns is None:
        file_patterns = ["*.rpy"]

    # Find files
    game_dir = project_root / "game"
    search_dirs = [game_dir] if game_dir.exists() else [project_root]

    files: List[Path] = []
    for search_dir in search_dirs:
        for pattern in file_patterns:
            files.extend(search_dir.rglob(pattern))

    return analyze_files_for_pfi(files)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Registry Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def register_wrapper(
    wrapper_name: str,
    media_kind: str,
    arg_index: int = 0,
) -> None:
    """
    Register a custom PFI wrapper.

    Allows user-defined wrappers to be tracked.

    Args:
        wrapper_name: Function name to track
        media_kind: Type of media ("image" | "audio" | "video")
        arg_index: Position of media_id argument (default: 0)

    Example:
        register_wrapper("my_show_bg", "image", 0)
    """
    PFI_WRAPPERS[wrapper_name] = {
        "kind": media_kind,
        "arg_index": arg_index,
    }


def unregister_wrapper(wrapper_name: str) -> None:
    """
    Remove a wrapper from the registry.

    Args:
        wrapper_name: Function name to remove
    """
    if wrapper_name in PFI_WRAPPERS:
        del PFI_WRAPPERS[wrapper_name]


def get_registered_wrappers() -> Dict[str, Dict[str, Any]]:
    """
    Get current wrapper registry.

    Returns:
        Copy of PFI_WRAPPERS
    """
    return dict(PFI_WRAPPERS)


def reset_wrapper_registry() -> None:
    """
    Reset wrapper registry to default state.

    Useful for testing or configuration reloads.
    """
    global PFI_WRAPPERS
    PFI_WRAPPERS = {
        "show_bg": {"kind": "image", "arg_index": 0},
        "show_char": {"kind": "image", "arg_index": 0},
        "show_character": {"kind": "image", "arg_index": 0},
        "show_sprite": {"kind": "image", "arg_index": 0},
        "show_cg": {"kind": "image", "arg_index": 0},
        "display_image": {"kind": "image", "arg_index": 0},
        "play_music": {"kind": "audio", "arg_index": 0},
        "play_sound": {"kind": "audio", "arg_index": 0},
        "play_audio": {"kind": "audio", "arg_index": 0},
        "play_voice": {"kind": "audio", "arg_index": 0},
        "queue_music": {"kind": "audio", "arg_index": 0},
        "play_movie": {"kind": "video", "arg_index": 0},
        "show_video": {"kind": "video", "arg_index": 0},
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


__all__ = [
    # Data structures
    "CallInfo",
    "MediaReference",
    "PFIAnalysisResult",
    # Configuration
    "PFI_WRAPPERS",
    # Core functions (v0.9.1.5)
    "infer_media_from_wrappers",
    "analyze_file_for_pfi",
    "analyze_files_for_pfi",
    "analyze_project_for_pfi",
    # WS-A2: Multi-line & variable tracking
    "extract_variable_assignments",
    "find_wrapper_calls_in_ast",
    "resolve_media_references",
    "infer_media_from_wrappers_v2",
    # Registry management
    "register_wrapper",
    "unregister_wrapper",
    "get_registered_wrappers",
    "reset_wrapper_registry",
]
