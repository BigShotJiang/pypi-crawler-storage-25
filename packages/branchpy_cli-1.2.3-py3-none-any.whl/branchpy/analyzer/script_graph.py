"""
Script Graph — v0.9.1.5 Analyzer Phase A

Project-level script flow graph for Ren'Py (and future engines).
Provides:
- Label/screen node tracking
- Jump/call edge tracking
- Media reference mapping
- File-level flow walking

BQS Compliance:
- Engine-agnostic design (Ren'Py v0, extensible for Godot/Unity/Unreal)
- Type-safe with full annotations
- Cross-platform path handling
- Performance: O(n) parsing, cached graph, depth-limited BFS
"""

from __future__ import annotations

import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from branchpy.analyzer.providers import SourceProvider, create_source_provider
from branchpy.analyzer.remote_context import (
    RemoteAnalyzerContext,
    extract_remote_telemetry_fields,
)
from branchpy.analyzer.remote_paths import normalize_path_for_remote

# Semantics V2 — Expression parser integration
try:
    from branchpy.semantics.expressions import (
        ExpressionNode,
        ValidationResult,
        parse_expression,
        validate,
    )

    _EXPRESSIONS_AVAILABLE = True
except ImportError:
    _EXPRESSIONS_AVAILABLE = False


# Simple telemetry shim
def _emit_telemetry(event_type: str, properties: Dict[str, Any]) -> None:
    """Emit telemetry event (no-op if unavailable)."""
    try:
        from pathlib import Path

        from ..telemetry import LocalTelemetryWriter, TelemetryEvent, create_trace_id

        telemetry_dir = Path.home() / ".branchpy" / "telemetry"
        telemetry_dir.mkdir(parents=True, exist_ok=True)

        writer = LocalTelemetryWriter(telemetry_dir)
        event = TelemetryEvent(
            ts=writer.iso_now(),
            session_id=writer.session_id,
            trace_id=create_trace_id(),
            category="analyzer",
            name=event_type,
            attrs=properties,
        )
        writer.write_event(event)
    except Exception:
        pass


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Data Structures
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass
class ScriptNode:
    """
    Represents a label or screen in a script.

    Attributes:
        file_path: Path to source file (relative to project)
                   NOTE: Identifier/display path only - do not use for filesystem IO.
                   Use source_provider for all file operations.
        node_type: "label" | "screen"
        name: Label/screen name
        line_number: Line where defined
        media_refs: List of media IDs referenced within this node's scope
    """

    file_path: Path
    node_type: str
    name: str
    line_number: int
    media_refs: List[str] = field(default_factory=list)

    @property
    def node_id(self) -> str:
        """Unique identifier: file_path:name"""
        return f"{self.file_path.as_posix()}:{self.name}"


@dataclass
class ScriptEdge:
    """
    Represents a flow connection between nodes.

    Attributes:
        from_node: Source node ID (file:label format)
        to_node: Target node ID
        edge_type: "jump" | "call" | "screen_usage" | "menu" | "conditional"
        line_number: Line where edge originates
        condition_text: Optional condition expression (e.g., "score > 50")
        condition_ast: Parsed expression AST (Semantics V2)
        validation_result: Semantic validation result
        variables_used: Set of variable names used in condition
    """

    from_node: str
    to_node: str
    edge_type: str
    line_number: int
    condition_text: Optional[str] = None
    condition_ast: Optional[Any] = None  # ExpressionNode if expressions available
    validation_result: Optional[Any] = None  # ValidationResult if expressions available
    variables_used: Set[str] = field(default_factory=set)

    def parse_condition(self, context: Optional[Dict[str, Any]] = None) -> bool:
        """
        Parse and validate the condition expression.

        Args:
            context: Optional runtime context for validation

        Returns:
            True if parsing/validation succeeded
        """
        if not self.condition_text or not _EXPRESSIONS_AVAILABLE:
            return False

        try:
            # Parse expression
            self.condition_ast = parse_expression(
                self.condition_text, line=self.line_number
            )

            if self.condition_ast is None:
                return False

            # Extract variables
            var_nodes = self.condition_ast.get_variables()
            self.variables_used = {v.name for v in var_nodes}

            # Validate (optional context for type checking)
            self.validation_result = validate(self.condition_text, context or {})

            return True
        except Exception:
            return False

    def evaluate_condition(self, context: Dict[str, Any]) -> Optional[bool]:
        """
        Evaluate condition with runtime context.

        Args:
            context: Variable values for evaluation

        Returns:
            True/False if evaluation succeeds, None if failed or no condition
        """
        if self.condition_ast is None:
            return None

        try:
            result = self.condition_ast.evaluate(context)
            return bool(result) if result is not None else None
        except Exception:
            return None

    def is_static_true(self) -> bool:
        """Check if condition is statically always true."""
        if self.condition_ast is None:
            return False
        try:
            result = self.condition_ast.evaluate({})
            return result is True
        except Exception:
            return False

    def is_static_false(self) -> bool:
        """Check if condition is statically always false (dead branch)."""
        if self.condition_ast is None:
            return False
        try:
            result = self.condition_ast.evaluate({})
            return result is False
        except Exception:
            return False


@dataclass
class FlowSummary:
    """
    Summary of reachable flow from a file.

    Result of walk_file_flow() analysis.
    """

    labels_in_file: List[str]
    reachable_labels: List[str]
    referenced_media_ids: List[str]
    depth_reached: int
    total_edges: int


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ScriptGraph
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class ScriptGraph:
    """
    Project-level script flow graph.

    Tracks:
    - Labels/screens defined across files
    - Jump/call relationships
    - Media references per label
    - Entry points (start, main_menu, etc.)

    Performance:
    - Build: O(n) where n = total lines across .rpy files
    - Query: O(1) for node lookup, O(edges) for traversal
    - Memory: ~100 bytes per node, ~50 bytes per edge
    """

    def __init__(self) -> None:
        self.nodes: Dict[str, ScriptNode] = {}
        self.edges: List[ScriptEdge] = []
        self.entry_points: Set[str] = set()

        # Index for fast lookups
        self._nodes_by_file: Dict[Path, List[ScriptNode]] = defaultdict(list)
        self._edges_by_source: Dict[str, List[ScriptEdge]] = defaultdict(list)

    def add_node(self, node: ScriptNode) -> None:
        """
        Add a node to the graph.

        Args:
            node: ScriptNode to add
        """
        node_id = node.node_id
        self.nodes[node_id] = node
        self._nodes_by_file[node.file_path].append(node)

        # Track entry points
        if node.name in {"start", "main_menu", "splashscreen", "after_load"}:
            self.entry_points.add(node_id)

    def add_edge(self, edge: ScriptEdge) -> None:
        """
        Add an edge to the graph.

        Args:
            edge: ScriptEdge to add
        """
        self.edges.append(edge)
        self._edges_by_source[edge.from_node].append(edge)

    def parse_all_conditions(
        self, context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Parse and validate all conditional edges in the graph.

        Args:
            context: Optional runtime context for validation

        Returns:
            Dictionary with parsing statistics
        """
        stats = {
            "total_edges": len(self.edges),
            "conditional_edges": 0,
            "parsed_successfully": 0,
            "parse_failures": 0,
            "static_true": 0,
            "static_false": 0,
            "undefined_variables": 0,
            "type_mismatches": 0,
        }

        for edge in self.edges:
            if edge.condition_text:
                stats["conditional_edges"] += 1

                if edge.parse_condition(context):
                    stats["parsed_successfully"] += 1

                    # Check static evaluation
                    if edge.is_static_true():
                        stats["static_true"] += 1
                    elif edge.is_static_false():
                        stats["static_false"] += 1

                    # Count validation errors
                    if edge.validation_result and not edge.validation_result.is_valid:
                        for error in edge.validation_result.errors:
                            error_type = type(error).__name__
                            if "UndefinedVariable" in error_type:
                                stats["undefined_variables"] += 1
                            elif "TypeMismatch" in error_type:
                                stats["type_mismatches"] += 1
                else:
                    stats["parse_failures"] += 1

        return stats

    def get_conditional_edges(self) -> List[ScriptEdge]:
        """Get all edges with conditions."""
        return [e for e in self.edges if e.condition_text is not None]

    def get_dead_branches(self) -> List[ScriptEdge]:
        """Get all edges with statically false conditions (unreachable)."""
        return [e for e in self.edges if e.is_static_false()]

    def get_variables_used(self) -> Set[str]:
        """Get all variable names used in conditional edges."""
        variables = set()
        for edge in self.edges:
            if edge.variables_used:
                variables.update(edge.variables_used)
        return variables

    def get_labels_in_file(self, file_path: Path) -> List[ScriptNode]:
        """
        Get all nodes defined in a file.

        Args:
            file_path: Path to file (relative or absolute)

        Returns:
            List of ScriptNode instances
        """
        # Normalize path for lookup
        normalized = Path(file_path.as_posix())
        return self._nodes_by_file.get(normalized, [])

    def get_outgoing_edges(self, node_id: str) -> List[ScriptEdge]:
        """
        Get all edges originating from a node.

        Args:
            node_id: Node identifier (file:label format)

        Returns:
            List of ScriptEdge instances
        """
        return self._edges_by_source.get(node_id, [])

    def walk_file_flow(
        self,
        file_path: Path,
        depth: int = 3,
    ) -> FlowSummary:
        """
        Walk outgoing edges from all labels in file up to N steps.

        Uses breadth-first search to find reachable labels and
        collect media references.

        Args:
            file_path: File to analyze
            depth: Maximum steps to traverse (default: 3)

        Returns:
            FlowSummary with reachability and media analysis

        Performance:
            O(V + E) where V = reachable nodes, E = edges traversed
            Depth limit ensures bounded execution time
        """
        labels_in_file = self.get_labels_in_file(file_path)

        if not labels_in_file:
            return FlowSummary(
                labels_in_file=[],
                reachable_labels=[],
                referenced_media_ids=[],
                depth_reached=0,
                total_edges=0,
            )

        reachable: Set[str] = set()
        media_ids: Set[str] = set()
        visited: Set[str] = set()
        edges_traversed = 0

        # BFS from each label in file
        queue: deque = deque()
        for label in labels_in_file:
            queue.append((label.node_id, 0))

        while queue:
            node_id, current_depth = queue.popleft()

            if node_id in visited or current_depth > depth:
                continue

            visited.add(node_id)
            reachable.add(node_id)

            # Collect media refs from this node
            if node_id in self.nodes:
                media_ids.update(self.nodes[node_id].media_refs)

            # Add outgoing edges to queue
            if current_depth < depth:
                for edge in self.get_outgoing_edges(node_id):
                    edges_traversed += 1
                    if edge.to_node not in visited:
                        queue.append((edge.to_node, current_depth + 1))

        return FlowSummary(
            labels_in_file=[label.name for label in labels_in_file],
            reachable_labels=list(reachable),
            referenced_media_ids=list(media_ids),
            depth_reached=depth,
            total_edges=edges_traversed,
        )

    def get_stats(self) -> Dict[str, int]:
        """
        Get graph statistics.

        Returns:
            Dict with node_count, edge_count, entry_point_count, file_count
        """
        return {
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "entry_point_count": len(self.entry_points),
            "file_count": len(self._nodes_by_file),
        }

    def analyze_flow(self, use_cache: bool = True, enable_timing: bool = False):
        """
        Perform semantic flow analysis on this ScriptGraph.

        Converts ScriptGraph to AST nodes and runs M3 propagation engine.

        Args:
            use_cache: Whether to use cached flow analysis results (default: True)
            enable_timing: Enable timing telemetry (default: False)

        Returns:
            FlowAnalysisBundle with complete flow analysis results

        Example:
            >>> graph = build_script_graph(project_root)
            >>> flow = graph.analyze_flow()
            >>> print(f"Cyclomatic complexity: {flow.global_metrics.cyclomatic_complexity}")
            >>> print(f"Unreachable labels: {flow.get_unreachable_labels()}")

            >>> # Disable caching for fresh analysis
            >>> flow = graph.analyze_flow(use_cache=False)

            >>> # Enable timing telemetry
            >>> flow = graph.analyze_flow(enable_timing=True)

        Note:
            This is a convenience method that delegates to the M3 propagation engine.
            For direct access to propagation APIs, use:
            `from branchpy.semantics.propagation import analyze_flow`

        Performance:
            - First call: Full propagation analysis
            - Cached calls: <1ms lookup time (>90% hit rate)
            - ScriptGraph-level memoization enabled by default
        """
        from branchpy.semantics.propagation import analyze_flow

        # Convert ScriptGraph to AST nodes
        # For now, we'll use the scriptgraph parameter (future: full conversion)
        return analyze_flow(
            scriptgraph=self, use_cache=use_cache, enable_timing=enable_timing
        )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Ren'Py Parser (v0 — Simple Regex-Based)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


# Regex patterns for Ren'Py syntax
LABEL_PATTERN = re.compile(r"^\s*label\s+(\w+)\s*[:\(]")
SCREEN_PATTERN = re.compile(r"^\s*screen\s+(\w+)\s*[:\(]")
JUMP_PATTERN = re.compile(r"^\s*jump\s+(\w+)")
CALL_PATTERN = re.compile(r"^\s*call\s+(\w+)")
MENU_PATTERN = re.compile(r"^\s*\".*\":\s*$")  # Menu choice (simplified)
SHOW_PATTERN = re.compile(r"^\s*show\s+(\w+)")
SCENE_PATTERN = re.compile(r"^\s*scene\s+(\w+)")
PLAY_PATTERN = re.compile(r"^\s*play\s+\w+\s+[\"']([^\"']+)[\"']")


def parse_rpy_file(
    file_path: Path,
    project_root: Path,
    source_provider: Optional[SourceProvider] = None,
) -> tuple[List[ScriptNode], List[ScriptEdge]]:
    """
    Extract labels, screens, and flow from .rpy file.

    Args:
        file_path: Path to .rpy file (relative to project_root)
        project_root: Path to project root directory
        source_provider: Optional source provider (defaults to local filesystem)

    Returns:
        Tuple of (nodes, edges) extracted from file

    Performance:
        O(n) where n = lines in file
        Typical file (500 lines): ~5ms

    Note:
        This is a v0 implementation using simple regex.
        Future versions will use proper AST parsing for accuracy.

    Limitations:
        - No indentation awareness (may miss nested labels)
        - No expression evaluation (dynamic jumps not tracked)
        - No Python block parsing
        - No ATL parsing
    """
    nodes: List[ScriptNode] = []
    edges: List[ScriptEdge] = []

    # Use source provider if available, else fall back to local filesystem
    if source_provider is None:
        from branchpy.analyzer.providers import LocalSourceProvider

        source_provider = LocalSourceProvider()

    try:
        # Ensure file_path is Path object (may be string from list_python_files)
        file_path = Path(file_path)

        # Calculate relative path for node IDs
        try:
            rel_path = file_path.relative_to(project_root)
        except ValueError:
            # File outside project root, use name only
            rel_path = Path(file_path.name)

        # Normalize path for remote context (POSIX-style forward slashes)
        # This ensures consistent path format across local/WSL/SSH/container modes
        remote_ctx = getattr(source_provider, "ctx", None)  # RemoteContext | None
        if remote_ctx is not None:
            # Lazy import to avoid CLI startup overhead
            from pathlib import PurePosixPath

            # Use PurePosixPath to preserve forward slashes on Windows
            rel_path_str = normalize_path_for_remote(remote_ctx, str(rel_path))
            rel_path = PurePosixPath(rel_path_str)

        # Read file content via provider
        abs_path = (
            project_root / file_path if not file_path.is_absolute() else file_path
        )
        content = source_provider.read_text(abs_path)
        lines = content.splitlines()

        current_label: Optional[str] = None
        current_media_refs: List[str] = []

        for line_num, line in enumerate(lines, start=1):
            # Strip comments
            if "#" in line:
                line = line[: line.index("#")]

            # Label definition
            match = LABEL_PATTERN.match(line)
            if match:
                # Save previous label's media refs
                if current_label:
                    # Find the node and update its media refs
                    for node in nodes:
                        if node.name == current_label:
                            node.media_refs.extend(current_media_refs)
                            break

                label_name = match.group(1)
                current_label = label_name
                current_media_refs = []

                nodes.append(
                    ScriptNode(
                        file_path=rel_path,
                        node_type="label",
                        name=label_name,
                        line_number=line_num,
                    )
                )
                continue

            # Screen definition
            match = SCREEN_PATTERN.match(line)
            if match:
                screen_name = match.group(1)
                nodes.append(
                    ScriptNode(
                        file_path=rel_path,
                        node_type="screen",
                        name=screen_name,
                        line_number=line_num,
                    )
                )
                continue

            # Jump statement
            match = JUMP_PATTERN.match(line)
            if match and current_label:
                target_label = match.group(1)
                edges.append(
                    ScriptEdge(
                        from_node=f"{rel_path.as_posix()}:{current_label}",
                        to_node=f"{rel_path.as_posix()}:{target_label}",  # Assume same file
                        edge_type="jump",
                        line_number=line_num,
                    )
                )
                continue

            # Call statement
            match = CALL_PATTERN.match(line)
            if match and current_label:
                target_label = match.group(1)
                edges.append(
                    ScriptEdge(
                        from_node=f"{rel_path.as_posix()}:{current_label}",
                        to_node=f"{rel_path.as_posix()}:{target_label}",  # Assume same file
                        edge_type="call",
                        line_number=line_num,
                    )
                )
                continue

            # Media references
            # Show statement
            match = SHOW_PATTERN.match(line)
            if match:
                media_id = match.group(1)
                current_media_refs.append(media_id)
                continue

            # Scene statement
            match = SCENE_PATTERN.match(line)
            if match:
                media_id = match.group(1)
                current_media_refs.append(media_id)
                continue

            # Play statement
            match = PLAY_PATTERN.match(line)
            if match:
                media_id = match.group(1)
                current_media_refs.append(media_id)
                continue

        # Save last label's media refs
        if current_label:
            for node in nodes:
                if node.name == current_label:
                    node.media_refs.extend(current_media_refs)
                    break

    except Exception as e:
        # Log but don't crash — partial data is better than none
        _emit_telemetry(
            "script_graph_parse_error",
            {
                "file": str(file_path),
                "error": str(e),
            },
        )

    return nodes, edges


def build_script_graph(
    project_root: Path,
    remote_ctx: Optional[RemoteAnalyzerContext] = None,
) -> ScriptGraph:
    """
    Build project-wide script graph.

    Process:
    1. Find all .rpy files in project
    2. Parse each file for nodes and edges
    3. Build unified graph
    4. Identify entry points

    Args:
        project_root: Path to project root directory
        remote_ctx: Optional remote analyzer context for remote environments

    Returns:
        ScriptGraph instance

    Performance:
        Typical project (100 .rpy files, 50k total lines): ~200ms
        Large project (500 .rpy files, 250k total lines): ~1s

    Telemetry:
        Emits 'script_graph_built' event with stats
    """
    import time

    start_time = time.time()

    graph = ScriptGraph()

    # Create source provider based on context
    source_provider = create_source_provider(remote_ctx.remote if remote_ctx else None)

    # Find .rpy files via source provider
    # Try game/ subdirectory first (standard Ren'Py structure)
    game_dir = project_root / "game"
    search_dirs = [game_dir] if game_dir.exists() else [project_root]

    rpy_files = []
    for search_dir in search_dirs:
        rpy_files.extend(source_provider.list_python_files(search_dir, pattern="*.rpy"))

    # Parse files
    for rpy_file in rpy_files:
        nodes, edges = parse_rpy_file(rpy_file, project_root, source_provider)

        for node in nodes:
            graph.add_node(node)

        for edge in edges:
            graph.add_edge(edge)

    # Emit telemetry
    duration_ms = int((time.time() - start_time) * 1000)
    stats = graph.get_stats()

    telemetry_props = {
        "project_root": str(project_root),
        "files_parsed": len(rpy_files),
        "duration_ms": duration_ms,
        **stats,
        **extract_remote_telemetry_fields(remote_ctx),
    }

    _emit_telemetry("script_graph_built", telemetry_props)

    return graph


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


__all__ = [
    "ScriptNode",
    "ScriptEdge",
    "FlowSummary",
    "ScriptGraph",
    "parse_rpy_file",
    "build_script_graph",
]
