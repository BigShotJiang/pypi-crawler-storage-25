"""
PFI Expression Integration — v0.9.6 M2 Phase 2

Integrates expression parser with PFI (Project Function Index) for:
- Menu choice condition parsing
- Label gate validation
- Variable tracking in conditions

Part of Milestone 2 (Semantics V2: Expressions, Variables, and Validation).

Governance: M2-DAY10-PHASE2-PFI-INTEGRATION
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set

from ..semantics.expressions import parse_expression, validate
from ..semantics.expressions.errors import ParseError
from ..semantics.expressions.nodes import ExpressionNode, LiteralNode
from ..semantics.expressions.validator import ValidationResult

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Data Structures
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@dataclass
class ConditionAnalysis:
    """
    Analysis result for a single condition expression.

    Attributes:
        condition_text: Original condition string
        condition_ast: Parsed expression AST (None if parse failed)
        validation_result: Semantic validation result
        variables_used: Set of variable names referenced
        is_static_true: True if condition is always true (e.g., "True")
        is_static_false: True if condition is always false (e.g., "False")
        parse_error: Parse error if parsing failed
        line_number: Source line number
        context: Context where condition appears ("menu_choice", "label_gate", "if_condition")
    """

    condition_text: str
    condition_ast: Optional[ExpressionNode]
    validation_result: ValidationResult
    variables_used: Set[str]
    is_static_true: bool
    is_static_false: bool
    parse_error: Optional[ParseError]
    line_number: int
    context: str


@dataclass
class MenuConditionAnalysis:
    """
    Analysis result for menu choice conditions.

    Attributes:
        menu_name: Menu identifier (if any)
        choices: List of condition analyses for each choice
        dead_choices: Indices of choices that are always false
        total_choices: Total number of choices in menu
        has_errors: True if any choice has parse errors
        has_warnings: True if any choice has semantic warnings
    """

    menu_name: Optional[str]
    choices: List[ConditionAnalysis]
    dead_choices: List[int]
    total_choices: int
    has_errors: bool
    has_warnings: bool


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Core Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def parse_condition(
    condition_text: str,
    line_number: int,
    context: str = "condition",
    runtime_vars: Optional[Dict[str, Any]] = None,
) -> ConditionAnalysis:
    """
    Parse and validate a single condition expression.

    Args:
        condition_text: Condition string (e.g., "flag and score > 10")
        line_number: Source line number
        context: Context identifier ("menu_choice", "label_gate", "if_condition")
        runtime_vars: Known runtime variables for validation

    Returns:
        ConditionAnalysis with parsed AST and validation results

    Example:
        >>> analysis = parse_condition("has_key", 42, "menu_choice")
        >>> print(analysis.variables_used)
        {'has_key'}

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    condition_ast: Optional[ExpressionNode] = None
    parse_error: Optional[ParseError] = None
    validation_result: ValidationResult = ValidationResult(
        is_valid=True,
        errors=[],
        warnings=[],
    )
    variables_used: Set[str] = set()
    is_static_true = False
    is_static_false = False

    # Step 1: Parse expression
    try:
        condition_ast = parse_expression(condition_text)

        # Extract variables (convert list of VariableRefNode to set of strings)
        if condition_ast is not None:
            var_nodes = condition_ast.get_variables()
            variables_used = {v.name for v in var_nodes}

            # Check for static constants
            if isinstance(condition_ast, LiteralNode):
                if condition_ast.value is True:
                    is_static_true = True
                elif condition_ast.value is False:
                    is_static_false = True

    except ParseError as e:
        parse_error = e

    # Step 2: Semantic validation (even if parse succeeded)
    if condition_ast is not None:
        try:
            validation_result = validate(condition_text, context=runtime_vars or {})
        except Exception:
            # Validation errors captured in result
            pass

    return ConditionAnalysis(
        condition_text=condition_text,
        condition_ast=condition_ast,
        validation_result=validation_result,
        variables_used=variables_used,
        is_static_true=is_static_true,
        is_static_false=is_static_false,
        parse_error=parse_error,
        line_number=line_number,
        context=context,
    )


def parse_menu_conditions(
    choice_nodes: List[Any],
    menu_name: Optional[str] = None,
    runtime_vars: Optional[Dict[str, Any]] = None,
) -> MenuConditionAnalysis:
    """
    Parse and analyze all choice conditions in a menu.

    Args:
        choice_nodes: List of ChoiceNode objects from AST
        menu_name: Menu identifier (if any)
        runtime_vars: Known runtime variables for validation

    Returns:
        MenuConditionAnalysis with per-choice analysis and dead choice detection

    Example:
        >>> from branchpy.semantics.ast.nodes import ChoiceNode
        >>> choices = [
        ...     ChoiceNode(text="Option A", condition="flag", line=10),
        ...     ChoiceNode(text="Option B", condition="False", line=11),
        ... ]
        >>> analysis = parse_menu_conditions(choices)
        >>> print(analysis.dead_choices)
        [1]

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    analyses: List[ConditionAnalysis] = []
    dead_choices: List[int] = []
    has_errors = False
    has_warnings = False

    for i, choice in enumerate(choice_nodes):
        # Skip choices without conditions
        if not hasattr(choice, "condition") or not choice.condition:
            continue

        # Parse condition
        analysis = parse_condition(
            choice.condition,
            choice.line_number if hasattr(choice, "line_number") else 0,
            context="menu_choice",
            runtime_vars=runtime_vars,
        )

        analyses.append(analysis)

        # Track dead choices (always false)
        if analysis.is_static_false:
            dead_choices.append(i)

        # Track errors and warnings
        if analysis.parse_error or not analysis.validation_result.is_valid:
            has_errors = True
        if analysis.validation_result.warnings:
            has_warnings = True

    return MenuConditionAnalysis(
        menu_name=menu_name,
        choices=analyses,
        dead_choices=dead_choices,
        total_choices=len(choice_nodes),
        has_errors=has_errors,
        has_warnings=has_warnings,
    )


def parse_label_gate(
    gate_condition: str,
    label_name: str,
    line_number: int,
    runtime_vars: Optional[Dict[str, Any]] = None,
) -> ConditionAnalysis:
    """
    Parse and validate a label gate condition.

    Label gates control access to labels (less common in Ren'Py but supported).

    Args:
        gate_condition: Gate expression (e.g., "chapter >= 2")
        label_name: Label being gated
        line_number: Source line number
        runtime_vars: Known runtime variables for validation

    Returns:
        ConditionAnalysis for the gate condition

    Example:
        >>> analysis = parse_label_gate("chapter >= 2", "secret_ending", 100)
        >>> print(analysis.variables_used)
        {'chapter'}

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    return parse_condition(
        gate_condition,
        line_number,
        context=f"label_gate:{label_name}",
        runtime_vars=runtime_vars,
    )


def parse_if_conditions(
    if_node: Any,
    runtime_vars: Optional[Dict[str, Any]] = None,
) -> List[ConditionAnalysis]:
    """
    Parse and validate all conditions in an if/elif/else chain.

    Args:
        if_node: IfNode from AST (may have elif_nodes and else_node)
        runtime_vars: Known runtime variables for validation

    Returns:
        List of ConditionAnalysis for if and each elif

    Example:
        >>> from branchpy.semantics.ast.nodes import IfNode, ElifNode
        >>> if_node = IfNode(condition="score > 100", line=50)
        >>> analyses = parse_if_conditions(if_node)
        >>> print(analyses[0].variables_used)
        {'score'}

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    analyses: List[ConditionAnalysis] = []

    # Parse main if condition
    if hasattr(if_node, "condition") and if_node.condition:
        analysis = parse_condition(
            if_node.condition,
            if_node.line_number if hasattr(if_node, "line") else 0,
            context="if_condition",
            runtime_vars=runtime_vars,
        )
        analyses.append(analysis)

    # Parse elif conditions
    if hasattr(if_node, "elif_nodes"):
        for elif_node in if_node.elif_nodes:
            if hasattr(elif_node, "condition") and elif_node.condition:
                analysis = parse_condition(
                    elif_node.condition,
                    elif_node.line_number if hasattr(elif_node, "line") else 0,
                    context="elif_condition",
                    runtime_vars=runtime_vars,
                )
                analyses.append(analysis)

    return analyses


def extract_all_conditions_from_ast(
    ast_root: Any,
    runtime_vars: Optional[Dict[str, Any]] = None,
) -> Dict[str, List[ConditionAnalysis]]:
    """
    Extract and analyze all conditions from an AST tree.

    Walks the entire AST and finds:
    - Menu choice conditions
    - If/elif conditions
    - While loop conditions
    - Label gates (if present)

    Args:
        ast_root: Root AST node (typically Module or Label)
        runtime_vars: Known runtime variables for validation

    Returns:
        Dictionary mapping condition types to lists of analyses:
        - "menu_choices": Menu choice conditions
        - "if_conditions": If/elif conditions
        - "while_conditions": While loop conditions
        - "label_gates": Label gate conditions

    Example:
        >>> conditions = extract_all_conditions_from_ast(ast_tree)
        >>> print(len(conditions["menu_choices"]))
        5

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    results: Dict[str, List[ConditionAnalysis]] = {
        "menu_choices": [],
        "if_conditions": [],
        "while_conditions": [],
        "label_gates": [],
    }

    def walk(node: Any) -> None:
        """Recursively walk AST nodes."""
        node_type = getattr(node, "node_type", lambda: None)()

        # Menu nodes contain choice nodes
        if node_type == "menu":
            if hasattr(node, "children"):
                for child in node.children:
                    if getattr(child, "node_type", lambda: None)() == "choice":
                        if hasattr(child, "condition") and child.condition:
                            analysis = parse_condition(
                                child.condition,
                                getattr(child, "line", 0),
                                context="menu_choice",
                                runtime_vars=runtime_vars,
                            )
                            results["menu_choices"].append(analysis)

        # If/elif conditions
        elif node_type == "if":
            if hasattr(node, "condition") and node.condition:
                analysis = parse_condition(
                    node.condition,
                    getattr(node, "line", 0),
                    context="if_condition",
                    runtime_vars=runtime_vars,
                )
                results["if_conditions"].append(analysis)

        elif node_type == "elif":
            if hasattr(node, "condition") and node.condition:
                analysis = parse_condition(
                    node.condition,
                    getattr(node, "line", 0),
                    context="elif_condition",
                    runtime_vars=runtime_vars,
                )
                results["if_conditions"].append(analysis)

        # While loop conditions
        elif node_type == "while":
            if hasattr(node, "condition") and node.condition:
                analysis = parse_condition(
                    node.condition,
                    getattr(node, "line", 0),
                    context="while_condition",
                    runtime_vars=runtime_vars,
                )
                results["while_conditions"].append(analysis)

        # Recurse into children
        if hasattr(node, "children"):
            for child in node.children:
                walk(child)

        # Recurse into body (if/elif/else/while)
        if hasattr(node, "body"):
            for child in node.body:
                walk(child)

    walk(ast_root)
    return results


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Reporting
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def format_condition_warnings(analysis: ConditionAnalysis) -> List[str]:
    """
    Format warnings for a condition analysis into human-readable strings.

    Args:
        analysis: ConditionAnalysis with validation results

    Returns:
        List of formatted warning strings

    Example:
        >>> warnings = format_condition_warnings(analysis)
        >>> for w in warnings:
        ...     print(w)
        Line 42: Undefined variable 'has_key' in menu_choice
        Line 42: Type mismatch: expected bool, got int

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    warnings: List[str] = []

    # Parse errors
    if analysis.parse_error:
        warnings.append(
            f"Line {analysis.line_number}: Parse error in {analysis.context}: {analysis.parse_error.message}"
        )

    # Validation warnings
    for warning in analysis.validation_result.warnings:
        warnings.append(
            f"Line {analysis.line_number}: {warning.message} in {analysis.context}"
        )

    # Static false warnings (dead code)
    if analysis.is_static_false:
        warnings.append(
            f"Line {analysis.line_number}: Condition is always false in {analysis.context} (dead code)"
        )

    return warnings


def summarize_menu_analysis(analysis: MenuConditionAnalysis) -> str:
    """
    Create a summary report for menu condition analysis.

    Args:
        analysis: MenuConditionAnalysis for a menu

    Returns:
        Formatted summary string

    Example:
        >>> summary = summarize_menu_analysis(analysis)
        >>> print(summary)
        Menu 'main_menu': 3 choices, 1 dead, 0 errors, 2 warnings

    Governance:
        M2-DAY10-PHASE2-PFI-INTEGRATION
    """
    menu_id = analysis.menu_name or "unnamed"

    status = []
    if analysis.has_errors:
        status.append("ERRORS")
    if analysis.has_warnings:
        status.append("WARNINGS")
    if analysis.dead_choices:
        status.append(f"{len(analysis.dead_choices)} DEAD")

    status_str = " | ".join(status) if status else "OK"

    return (
        f"Menu '{menu_id}': {analysis.total_choices} choices, "
        f"{len(analysis.dead_choices)} dead, "
        f"{len([c for c in analysis.choices if c.parse_error])} errors, "
        f"{sum(len(c.validation_result.warnings) for c in analysis.choices)} warnings [{status_str}]"
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


__all__ = [
    # Data structures
    "ConditionAnalysis",
    "MenuConditionAnalysis",
    # Core functions
    "parse_condition",
    "parse_menu_conditions",
    "parse_label_gate",
    "parse_if_conditions",
    "extract_all_conditions_from_ast",
    # Reporting
    "format_condition_warnings",
    "summarize_menu_analysis",
]
