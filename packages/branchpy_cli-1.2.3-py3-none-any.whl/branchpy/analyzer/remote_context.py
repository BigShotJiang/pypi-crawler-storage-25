"""
Remote analyzer context and integration.

Provides remote-awareness for the Flow Analyzer, enabling correct behavior
in WSL, SSH, containers, Codespaces, and CI environments.

Governance: AXIS5-V0.9.2-REMOTE-BQS
"""

from dataclasses import dataclass
from typing import Optional

from branchpy.remote.bootstrap.models import BootstrapResult
from branchpy.remote.context import RemoteContext


@dataclass
class RemoteAnalyzerContext:
    """
    Remote context for analyzer operations.

    Bundles RemoteContext (from WS-R1) and optional BootstrapResult (from WS-R2)
    to provide analyzer with all remote environment metadata.

    Attributes:
        remote: Detected remote environment context
        bootstrap: Optional bootstrap health check result

    Examples:
        >>> from branchpy.remote import detect_environment
        >>> from branchpy.remote.bootstrap import ensure_remote_ready
        >>> from branchpy.analyzer.remote_context import RemoteAnalyzerContext
        >>>
        >>> ctx = detect_environment()
        >>> bootstrap = ensure_remote_ready(ctx)
        >>> analyzer_ctx = RemoteAnalyzerContext(remote=ctx, bootstrap=bootstrap)
        >>>
        >>> # Pass to analyzer
        >>> analyze_project(root="/workspace/project", remote_ctx=analyzer_ctx)
    """

    remote: RemoteContext
    bootstrap: Optional[BootstrapResult] = None

    @property
    def is_remote(self) -> bool:
        """Check if running in remote environment."""
        return self.remote.is_remote

    @property
    def mode(self) -> str:
        """Get remote mode (local/wsl/ssh/container/codespaces/ci)."""
        return self.remote.mode

    @property
    def host_platform(self) -> str:
        """Get host platform (windows/linux/darwin)."""
        return self.remote.host_platform

    @property
    def is_healthy(self) -> bool:
        """
        Check if bootstrap is healthy (if available).

        Returns True if no bootstrap result, or if bootstrap succeeded.
        """
        if self.bootstrap is None:
            return True  # No bootstrap check = assume healthy
        return self.bootstrap.is_success

    def to_dict(self) -> dict:
        """Convert to dictionary for telemetry/logging."""
        result = {
            "remote_mode": self.remote.mode,
            "is_remote": self.remote.is_remote,
            "host_platform": self.remote.host_platform,
            "detection_confidence": self.remote.detection_confidence,
        }

        if self.bootstrap:
            result["bootstrap_status"] = self.bootstrap.status
            result["bootstrap_strategy"] = self.bootstrap.strategy_name

        return result


def extract_remote_telemetry_fields(
    ctx: Optional[RemoteAnalyzerContext],
) -> dict:
    """
    Extract remote telemetry fields from analyzer context.

    Returns standard set of remote fields for telemetry events.
    Used to enrich analyzer events with remote environment metadata.

    Args:
        ctx: Optional remote analyzer context

    Returns:
        Dictionary with remote_mode, host_platform, bootstrap_status, bootstrap_strategy.
        All values are None if ctx is None or ctx.remote is None.

    Examples:
        >>> # Local mode
        >>> fields = extract_remote_telemetry_fields(None)
        >>> assert fields["remote_mode"] is None
        >>>
        >>> # Remote mode
        >>> remote_ctx = RemoteAnalyzerContext(remote=RemoteContext(mode="ssh"))
        >>> fields = extract_remote_telemetry_fields(remote_ctx)
        >>> assert fields["remote_mode"] == "ssh"
        >>>
        >>> # Usage in telemetry
        >>> event_data = {
        ...     "project_root": "/workspace/proj",
        ...     "duration_ms": 150.5,
        ...     **extract_remote_telemetry_fields(remote_ctx),
        ... }
    """
    if ctx is None or ctx.remote is None:
        return {
            "remote_mode": None,
            "host_platform": None,
            "bootstrap_status": None,
            "bootstrap_strategy": None,
        }

    remote = ctx.remote
    bootstrap = ctx.bootstrap

    return {
        "remote_mode": remote.mode,
        "host_platform": remote.host_platform,
        "bootstrap_status": bootstrap.status if bootstrap else None,
        "bootstrap_strategy": bootstrap.strategy_name if bootstrap else None,
    }
