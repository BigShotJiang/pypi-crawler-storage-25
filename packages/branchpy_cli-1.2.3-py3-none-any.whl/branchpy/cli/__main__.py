"""
CLI entrypoint for python -m branchpy.cli execution.
Ensures the package can be invoked as a module.
"""


def main():
    """Main entrypoint for CLI execution."""
    # The actual CLI is in branchpy/cli.py (sibling module file)
    # The branchpy.cli package __init__.py proxies to it
    try:
        # Import from the parent module which proxies to cli.py
        from branchpy import cli

        # Try to get the Typer app
        if hasattr(cli, "app"):
            import sys

            sys.exit(cli.app())
        elif hasattr(cli, "main"):
            import sys

            sys.exit(cli.main())
        else:
            # Fallback: just import and hope it auto-runs
            import sys

            print("Error: Could not find CLI entrypoint (app or main)", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        import sys

        print(f"Error running CLI: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
