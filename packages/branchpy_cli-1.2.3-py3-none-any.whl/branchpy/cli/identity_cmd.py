"""
BranchPy CLI — Identity Management Commands

Commands:
- branchpy init-user: Create identity.toml
- branchpy whoami: Display current identity and role
"""

from pathlib import Path

import click

from branchpy.core.audit import IdentityResolver


@click.group("identity")
def identity():
    """Identity management commands"""
    pass


@identity.command("init-user")
@click.option("--name", prompt="Full Name", help="Your full name")
@click.option("--email", prompt="Email", help="Your email address")
@click.option("--sso", default="", help="SSO provider (e.g., okta, azuread)")
@click.pass_context
def init_user(ctx, name: str, email: str, sso: str):
    """
    Initialize user identity.

    Creates .branchpy/identity.toml with user/machine UUIDs.
    """
    project_root = Path.cwd()
    resolver = IdentityResolver(project_root)

    # Check if identity already exists
    if resolver.identity_path.exists():
        click.confirm(
            f"Identity already exists at {resolver.identity_path}. Overwrite?",
            abort=True,
        )

    # Create identity
    identity = resolver.create_identity(
        name=name, email=email, sso_provider=sso if sso else None
    )

    click.echo("\n✅ Identity created:")
    click.echo(f"   User UUID: {identity.user.user_uuid}")
    click.echo(f"   Machine UUID: {identity.machine.machine_uuid}")
    click.echo(f"   File: {resolver.identity_path}")
    click.echo("\nRun 'branchpy whoami' to verify.")


@identity.command("whoami")
@click.pass_context
def whoami(ctx):
    """
    Display current user identity and role.

    Shows:
    - User name, email, UUID
    - Machine hostname, UUID
    - Team role (if team.toml exists)
    - Audit status
    """
    project_root = Path.cwd()
    resolver = IdentityResolver(project_root)

    try:
        identity = resolver.resolve()
    except Exception as e:
        click.echo(f"❌ Error resolving identity: {e}", err=True)
        click.echo("\nRun 'branchpy init-user' to create identity.", err=True)
        ctx.exit(1)

    # Display user identity
    click.echo(f"User: {identity.user.name} <{identity.user.email}>")
    click.echo(f"UUID: {identity.user.user_uuid}")

    # Display machine identity
    click.echo(
        f"Machine: {identity.machine.hostname} ({identity.machine.machine_uuid})"
    )

    # Check for team role (if team.toml exists)
    team_path = project_root / ".branchpy" / "team.toml"
    if team_path.exists():
        role = _get_user_role(team_path, identity.user.user_uuid)
        if role:
            click.echo(f"Role: {role} (from team.toml)")
        else:
            click.echo("Role: (not assigned in team.toml)")
    else:
        click.echo("Team: (no team.toml)")

    # Check audit status
    audit_log = project_root / ".branchpy" / "audit" / "log.jsonl"
    if audit_log.exists():
        lines = len(audit_log.read_text(encoding="utf-8").strip().split("\n"))
        click.echo(f"Audit: ON (local sink, {lines} entries)")
    else:
        click.echo("Audit: OFF (no audit log)")


def _get_user_role(team_path: Path, user_uuid: str) -> str | None:
    """Get user role from team.toml"""
    try:
        import tomli
    except ImportError:
        import tomllib as tomli

    with open(team_path, "rb") as f:
        team_config = tomli.load(f)

    assignments = team_config.get("assignments", {})
    return assignments.get(user_uuid)
