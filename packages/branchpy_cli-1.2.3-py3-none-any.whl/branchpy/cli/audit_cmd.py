"""
BranchPy CLI — Audit Commands

Commands:
- branchpy audit verify: Verify hash chain integrity
- branchpy audit replay: Replay audit log with filters
- branchpy audit tail: Show recent/live audit entries
- branchpy audit sink list/test: Manage sinks
- branchpy audit push: Force flush to remote sinks
"""

import json
import time
from pathlib import Path

import click

from branchpy.core.audit import AuditContext, Auditor, IdentityResolver


@click.group("audit")
def audit_group():
    """Audit log operations (verify, replay, tail, sinks)"""
    pass


@audit_group.command("verify")
@click.option("--verbose", is_flag=True, help="Show details for each entry")
@click.pass_context
def audit_verify(ctx, verbose: bool):
    """
    Verify audit chain integrity.

    Checks:
    - Hash chain linkage (prev_hash → hash)
    - Hash recomputation (detect tampering)
    - JSON validity

    Exit codes:
    - 0: Chain verified
    - 1: Chain broken
    - 65: Permission denied (RBAC)
    """
    project_root = Path.cwd()

    # Check RBAC (requires 'audit_verify' capability)
    if not _check_capability(project_root, "audit_verify"):
        click.echo("❌ Permission denied: audit_verify capability required", err=True)
        ctx.exit(65)

    # Resolve identity
    resolver = IdentityResolver(project_root)
    identity = resolver.resolve()

    # Create auditor
    audit_ctx = AuditContext(project_root=project_root, identity=identity)
    auditor = Auditor(audit_ctx)

    # Verify
    click.echo("Verifying audit chain...")
    report = auditor.verify()

    if report.ok:
        click.echo("✅ Audit chain verified")
        click.echo(f"Entries: {report.entries:,}")
        click.echo(f"Elapsed: {report.elapsed_ms:.1f}ms")
    else:
        click.echo(f"⚠️ Audit chain broken at entry {report.broken_at}", err=True)
        click.echo(f"Reason: {report.reason}", err=True)
        click.echo("\nPossible causes:", err=True)
        click.echo("  • Entry was modified", err=True)
        click.echo("  • Entry was deleted", err=True)
        click.echo("  • Log file was manually edited", err=True)
        click.echo("\nAction: Restore from backup or Git history", err=True)
        ctx.exit(1)


@audit_group.command("replay")
@click.option("--user", help="Filter by user UUID")
@click.option("--action", help="Filter by action name")
@click.option("--since", help="Filter by start time (ISO 8601)")
@click.option("--until", help="Filter by end time (ISO 8601)")
@click.option(
    "--format",
    type=click.Choice(["json", "pretty"]),
    default="pretty",
    help="Output format",
)
@click.pass_context
def audit_replay(ctx, user: str, action: str, since: str, until: str, format: str):
    """
    Replay audit log with filters.

    Examples:
      branchpy audit replay --user 550e8400-...
      branchpy audit replay --action stats.run
      branchpy audit replay --since 2025-11-01
    """
    project_root = Path.cwd()

    # Check RBAC (requires 'replay' capability)
    if not _check_capability(project_root, "replay"):
        click.echo("❌ Permission denied: replay capability required", err=True)
        ctx.exit(65)

    # Resolve identity
    resolver = IdentityResolver(project_root)
    identity = resolver.resolve()

    # Create auditor
    audit_ctx = AuditContext(project_root=project_root, identity=identity)
    auditor = Auditor(audit_ctx)

    # Replay
    entries = list(auditor.replay(user=user, action=action, since=since, until=until))

    if not entries:
        click.echo("No entries found matching filters.")
        return

    click.echo(f"Found {len(entries)} entries:\n")

    for entry in entries:
        if format == "json":
            click.echo(json.dumps(entry.to_dict(), indent=2))
        else:
            # Pretty format
            click.echo(f"[{entry.seq}] {entry.time_utc}")
            click.echo(f"  User: {entry.user_name} ({entry.user_uuid})")
            click.echo(f"  Action: {entry.action}")
            if entry.args:
                click.echo(f"  Args: {entry.args}")
            if entry.result:
                click.echo(f"  Result: {entry.result}")
            click.echo()


@audit_group.command("tail")
@click.option("-n", "--lines", default=10, help="Number of lines to show")
@click.option("--follow", "-f", is_flag=True, help="Follow mode (live tail)")
@click.pass_context
def audit_tail(ctx, lines: int, follow: bool):
    """
    Show recent audit entries (like tail -f).

    Examples:
      branchpy audit tail -n 20
      branchpy audit tail --follow
    """
    project_root = Path.cwd()
    log_path = project_root / ".branchpy" / "audit" / "log.jsonl"

    if not log_path.exists():
        click.echo("No audit log found.", err=True)
        ctx.exit(1)

    if follow:
        click.echo(f"Following {log_path} (Ctrl+C to stop)...\n")
        _tail_follow(log_path)
    else:
        # Show last N lines
        all_lines = log_path.read_text(encoding="utf-8").strip().split("\n")
        recent = all_lines[-lines:] if len(all_lines) > lines else all_lines

        for line in recent:
            if not line:
                continue
            try:
                entry = json.loads(line)
                click.echo(f"[{entry['seq']}] {entry['time_utc']} - {entry['action']}")
                click.echo(f"  User: {entry.get('user_name', 'Unknown')}")
                if entry.get("result"):
                    click.echo(f"  Result: {entry['result']}")
                click.echo()
            except json.JSONDecodeError:
                continue


def _tail_follow(log_path: Path):
    """Tail -f implementation"""
    # Read initial size
    with open(log_path, "r", encoding="utf-8") as f:
        f.seek(0, 2)  # Seek to end

        while True:
            line = f.readline()
            if line:
                try:
                    entry = json.loads(line)
                    click.echo(
                        f"[{entry['seq']}] {entry['time_utc']} - {entry['action']}"
                    )
                    click.echo(f"  User: {entry.get('user_name', 'Unknown')}")
                except json.JSONDecodeError:
                    pass
            else:
                time.sleep(0.1)


@audit_group.group("sink")
def sink_group():
    """Audit sink management (list, test)"""
    pass


@sink_group.command("list")
@click.pass_context
def sink_list(ctx):
    """List configured audit sinks"""
    project_root = Path.cwd()
    log_path = project_root / ".branchpy" / "audit" / "log.jsonl"

    click.echo("Configured sinks:")
    click.echo("  ✅ local_file (always active)")
    click.echo(f"     Path: {log_path}")

    if log_path.exists():
        lines = len(log_path.read_text(encoding="utf-8").strip().split("\n"))
        click.echo(f"     Entries: {lines:,}")
    else:
        click.echo("     Entries: 0")

    # Check for team.toml (HTTPS/Git sinks)
    team_path = project_root / ".branchpy" / "team.toml"
    if team_path.exists():
        try:
            import tomli
        except ImportError:
            import tomllib as tomli

        with open(team_path, "rb") as f:
            team_config = tomli.load(f)

        if "sinks" in team_config:
            if "https" in team_config["sinks"]:
                click.echo("\n  🔶 https (experimental)")
                click.echo(
                    f"     URL: {team_config['sinks']['https'].get('url', 'N/A')}"
                )
                click.echo("     Status: Not implemented (v0.8.1)")

            if "git" in team_config["sinks"]:
                click.echo("\n  🔶 git (experimental)")
                click.echo(
                    f"     Repo: {team_config['sinks']['git'].get('repo_path', 'N/A')}"
                )
                click.echo("     Status: Not implemented (v0.8.1)")


@sink_group.command("test")
@click.argument("sink_name")
@click.pass_context
def sink_test(ctx, sink_name: str):
    """Test sink connectivity"""
    click.echo(f"Testing {sink_name} sink...")
    click.echo("⚠️ Not implemented in v0.8.1 (BPY-813)")
    click.echo("HTTPS and Git sinks are planned for future releases.")


@audit_group.command("push")
@click.pass_context
def audit_push(ctx):
    """Force flush to all remote sinks"""
    click.echo("Flushing all sinks...")
    click.echo("  ✅ local_file: Already flushed (no buffering)")
    click.echo("  ⚠️ Remote sinks: Not implemented in v0.8.1 (BPY-813)")


# =============================================================================
# RBAC Helper
# =============================================================================


def _check_capability(project_root: Path, capability: str) -> bool:
    """
    Check if current user has required capability.

    Returns True if:
    - No team.toml (single-user mode)
    - User has required capability in team.toml

    Returns False if:
    - team.toml exists but user lacks capability
    """
    team_path = project_root / ".branchpy" / "team.toml"
    if not team_path.exists():
        return True  # No RBAC in single-user mode

    # Load identity
    resolver = IdentityResolver(project_root)
    try:
        identity = resolver.resolve()
    except Exception:
        return False  # Can't resolve identity

    # Load team config
    try:
        import tomli
    except ImportError:
        import tomllib as tomli

    with open(team_path, "rb") as f:
        team_config = tomli.load(f)

    # Get user role
    assignments = team_config.get("assignments", {})
    role = assignments.get(identity.user.user_uuid)

    if not role:
        return False  # No role assigned

    # Check capability
    roles = team_config.get("roles", {})
    role_caps = roles.get(role, {})

    return role_caps.get(capability, False)
