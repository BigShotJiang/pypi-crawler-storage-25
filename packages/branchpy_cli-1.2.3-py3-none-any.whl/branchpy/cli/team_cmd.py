"""
Team Management CLI — v0.8.6
Commands: branchpy team [list|policy|audit|cert]

Provides governance and team management functionality.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from branchpy.core.governance.certificates import (
    CertificateManager,
    load_or_create_secret_key,
)
from branchpy.core.governance.policy_engine import PolicyEngine
from branchpy.core.governance.team_manager import TeamManager


def register_team(sub):
    """Register 'branchpy team' command group."""
    p = sub.add_parser("team", help="Team and governance management")

    team_sub = p.add_subparsers(dest="team_command", required=True)

    # branchpy team list
    list_p = team_sub.add_parser("list", help="Show team members and roles")
    list_p.add_argument("--format", choices=["table", "json"], default="table")

    # branchpy team policy
    policy_p = team_sub.add_parser("policy", help="Show current policy status")
    policy_p.add_argument(
        "--violations", action="store_true", help="Show recent policy violations"
    )
    policy_p.add_argument(
        "--summary", action="store_true", help="Show violation summary"
    )

    # branchpy team audit
    audit_p = team_sub.add_parser("audit", help="Quick audit summary")
    audit_p.add_argument(
        "--last", type=int, default=10, help="Number of recent events to show"
    )

    # branchpy team cert
    cert_sub = team_sub.add_parser("cert", help="Manage session certificates")
    cert_cmd = cert_sub.add_subparsers(dest="cert_action", required=True)

    # branchpy team cert issue
    issue_p = cert_cmd.add_parser("issue", help="Issue new certificate")
    issue_p.add_argument("--scope", default="cli", choices=["cli", "daemon", "api"])
    issue_p.add_argument("--ttl", type=int, default=60, help="TTL in minutes")

    # branchpy team cert list
    cert_cmd.add_parser("list", help="List active certificates")

    # branchpy team cert revoke
    revoke_p = cert_cmd.add_parser("revoke", help="Revoke certificate")
    revoke_p.add_argument("session_id", help="Certificate session ID")

    # branchpy team cert cleanup
    cert_cmd.add_parser("cleanup", help="Remove expired certificates")


def main_team(args):
    """Main entry point for team commands."""
    proj_root = Path(".").resolve()

    if args.team_command == "list":
        _handle_team_list(proj_root, args)
    elif args.team_command == "policy":
        _handle_team_policy(proj_root, args)
    elif args.team_command == "audit":
        _handle_team_audit(proj_root, args)
    elif args.team_command == "cert":
        _handle_team_cert(proj_root, args)


def _handle_team_list(proj_root: Path, args):
    """Handle 'branchpy team list'."""
    team_toml = proj_root / ".branchpy" / "team.toml"

    if not team_toml.exists():
        print("⚠️  No team configuration found (.branchpy/team.toml)")
        print("   Run: branchpy migrate --governance")
        return

    team_mgr = TeamManager(team_toml)
    members = team_mgr.list_members()
    team_info = team_mgr.get_team_info()

    print(f"Team: {team_info['name']} (ID: {team_info['team_id']})\n")

    if args.format == "json":
        output = {"team": team_info, "members": members}
        print(json.dumps(output, indent=2))
    else:
        # Table format
        if not members:
            print("No team members assigned")
            return

        print(f"{'User UUID':<40} {'Role':<15}")
        print("=" * 60)
        for m in members:
            print(f"{m['uuid']:<40} {m['role']:<15}")

        print(f"\nTotal members: {len(members)}")


def _handle_team_policy(proj_root: Path, args):
    """Handle 'branchpy team policy'."""
    policy_path = proj_root / ".branchpy" / "policy.json"

    if not policy_path.exists():
        print("⚠️  No policy configuration found (.branchpy/policy.json)")
        print("   Running in permissive mode (all actions allowed)")
        return

    policy_engine = PolicyEngine(policy_path)

    print(f"Policy Version: {policy_engine.policy.version}")
    print(f"Team ID: {policy_engine.policy.team_id}")
    print(f"Default Enforcement: {policy_engine.policy.default_enforcement.value}")
    print(f"\nActive Rules: {len(policy_engine.policy.rules)}")

    if policy_engine.policy.rules:
        print("\nRules:")
        for rule in policy_engine.policy.rules:
            print(f"\n  [{rule.id}] {rule.description}")
            print(f"    Action Type: {rule.action_type.value}")
            print(f"    Enforcement: {rule.enforcement.value}")
            if rule.roles_affected:
                print(f"    Roles Affected: {', '.join(rule.roles_affected)}")
            if rule.conditions:
                print(f"    Conditions: {rule.conditions}")

    if args.summary:
        summary = policy_engine.get_violation_summary()
        print("\n\nViolation Summary:")
        print(f"  Total: {summary['total']}")
        print(f"  Allowed: {summary['allow']}")
        print(f"  Warnings: {summary['warn']}")
        print(f"  Denied: {summary['deny']}")

    if args.violations and policy_engine.violations:
        print(f"\n\nRecent Violations ({len(policy_engine.violations)}):")
        for v in policy_engine.violations[-10:]:
            print(f"  {v.timestamp} | {v.decision.value.upper():6} | {v.reason}")


def _handle_team_audit(proj_root: Path, args):
    """Handle 'branchpy team audit'."""
    audit_path = proj_root / ".branchpy" / "audit.jsonl"

    if not audit_path.exists():
        print("⚠️  No audit log found (.branchpy/audit.jsonl)")
        print("   Audit logging may not be enabled")
        return

    try:
        from branchpy.core.audit import AuditLog

        audit_log = AuditLog(audit_path)
        entries = list(audit_log.read_entries(limit=args.last))
    except ImportError:
        print("❌ Audit system not available")
        return
    except Exception as e:
        print(f"❌ Error reading audit log: {e}")
        return

    if not entries:
        print("No audit entries found")
        return

    print(f"Last {min(args.last, len(entries))} Audit Events:\n")

    for entry in entries:
        print(f"[{entry.seq:04d}] {entry.time_utc}")
        print(f"  Action: {entry.action}")
        print(f"  User: {entry.user_name or 'N/A'} ({entry.user_uuid[:8]}...)")

        if entry.result:
            # Show result summary
            if isinstance(entry.result, dict):
                success = entry.result.get("success", True)
                status = "✅" if success else "❌"
                print(f"  Status: {status}")

        print()


def _handle_team_cert(proj_root: Path, args):
    """Handle 'branchpy team cert' subcommands."""
    cert_dir = proj_root / ".branchpy" / "session"
    secret_key_path = proj_root / ".branchpy" / ".cert_secret"

    # Load or create secret key
    secret_key = load_or_create_secret_key(secret_key_path)
    cert_mgr = CertificateManager(cert_dir, secret_key)

    if args.cert_action == "issue":
        _cert_issue(proj_root, cert_mgr, args)
    elif args.cert_action == "list":
        _cert_list(cert_mgr)
    elif args.cert_action == "revoke":
        _cert_revoke(cert_mgr, args.session_id)
    elif args.cert_action == "cleanup":
        _cert_cleanup(cert_mgr)


def _cert_issue(proj_root: Path, cert_mgr: CertificateManager, args):
    """Issue a new session certificate."""
    # Resolve identity
    try:
        from branchpy.core.identity import resolve_identity

        identity = resolve_identity()
    except Exception as e:
        print(f"❌ Failed to resolve identity: {e}")
        print("   Ensure .branchpy/identity.toml exists")
        sys.exit(1)

    # Get user role
    team_toml = proj_root / ".branchpy" / "team.toml"
    team_mgr = TeamManager(team_toml)
    role = team_mgr.get_role(identity.user.user_uuid)

    # Issue certificate
    cert = cert_mgr.issue(
        user_id=identity.user.user_uuid,
        role=role,
        scope=args.scope,
        ttl_minutes=args.ttl,
    )

    print("✅ Certificate issued successfully")
    print(f"   Session ID: {cert.session_id}")
    print(f"   User: {identity.user.name} ({identity.user.user_uuid[:8]}...)")
    print(f"   Role: {cert.role}")
    print(f"   Scope: {cert.scope}")
    print(f"   Issued: {cert.issued_at}")
    print(f"   Expires: {cert.expires_at}")
    print(
        f"\n   Certificate saved to: {cert_mgr.cert_dir / f'{cert.session_id}.bpy-cert'}"
    )


def _cert_list(cert_mgr: CertificateManager):
    """List active certificates."""
    active = cert_mgr.list_active()

    if not active:
        print("No active certificates")
        return

    print(f"Active Certificates ({len(active)}):\n")
    print(f"{'Session ID':<20} {'User ID':<15} {'Role':<12} {'Scope':<8} {'Expires'}")
    print("=" * 85)

    for cert in active:
        print(
            f"{cert.session_id:<20} {cert.user_id[:13]:<15} {cert.role:<12} {cert.scope:<8} {cert.expires_at[:19]}"
        )


def _cert_revoke(cert_mgr: CertificateManager, session_id: str):
    """Revoke a certificate."""
    if cert_mgr.revoke(session_id):
        print(f"✅ Certificate {session_id} revoked")
    else:
        print(f"❌ Certificate {session_id} not found")
        sys.exit(1)


def _cert_cleanup(cert_mgr: CertificateManager):
    """Clean up expired certificates."""
    count = cert_mgr.cleanup_expired()
    print(f"✅ Removed {count} expired certificate(s)")
