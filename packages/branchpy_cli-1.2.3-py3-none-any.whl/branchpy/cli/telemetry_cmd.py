"""
BranchPy CLI — Telemetry Commands

Commands:
- branchpy telemetry export: Export aggregated metrics (JSON/CSV/Parquet) with policy filtering
- branchpy telemetry stats: Show current telemetry statistics
- branchpy telemetry config: Display telemetry configuration

Governance: AXIS5-V0.9.1.2-20251114-H5-G9 (Tasks 2, 3, 4: CLI + Exporters + Destinations)
BQS: Code Standards, Cross-Platform Readiness, CLI UX
"""

import argparse
import asyncio
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

import click

from branchpy.export.destinations import (
    ExportManifest,
    RetentionPolicy,
    get_destination,
)
from branchpy.telemetry.exporters import get_exporter


@click.group("telemetry")
def telemetry_group():
    """Telemetry export and statistics commands"""
    pass


@telemetry_group.command("export")
@click.option(
    "--governance-id",
    "-g",
    help="Filter by governance ID (mutually exclusive with --start/--end)",
)
@click.option("--start", help="Start ISO8601 (inclusive), e.g. 2025-11-13T00:00:00Z")
@click.option("--end", help="End ISO8601 (exclusive), e.g. 2025-11-14T00:00:00Z")
@click.option(
    "--module",
    type=click.Choice(["compare", "image", "media", "bqf"], case_sensitive=False),
    help="Filter by module",
)
@click.option("--event-type", help="Filter by event_type (e.g., validation.complete)")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["json", "csv", "parquet"], case_sensitive=False),
    default="json",
    help="Export format (default: json)",
)
@click.option("--out", "-o", type=click.Path(), required=True, help="Output file path")
@click.option(
    "--policy-only",
    is_flag=True,
    help="Only include events carrying policy_results field",
)
@click.option(
    "--summary",
    is_flag=True,
    help="Also emit *_summary.json with aggregated policy counts",
)
@click.option("--compress", is_flag=True, help="Write gzip-compressed output (.gz)")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed export information")
@click.option(
    "--dest",
    type=click.Choice(["local", "github", "s3", "gcs", "azure"], case_sensitive=False),
    default="local",
    help="Destination for exports (default: local)",
)
@click.option("--bucket", help="S3/GCS bucket name (required for s3/gcs destinations)")
@click.option(
    "--container", help="Azure container name (required for azure destination)"
)
@click.option(
    "--prefix",
    default="telemetry-exports",
    help="Path prefix for exports (default: telemetry-exports)",
)
@click.option(
    "--ttl-days", type=int, help="Delete exports older than N days (retention policy)"
)
@click.option(
    "--max-artifacts",
    type=int,
    help="Keep only N most recent exports (retention policy)",
)
@click.option(
    "--dry-run-dest",
    is_flag=True,
    help="Log destination actions without uploading/deleting",
)
@click.option(
    "--no-retention",
    is_flag=True,
    help="Skip retention policy even if ttl-days/max-artifacts provided",
)
@click.pass_context
def export_cmd(
    ctx,
    governance_id: Optional[str],
    start: Optional[str],
    end: Optional[str],
    module: Optional[str],
    event_type: Optional[str],
    fmt: str,
    out: str,
    policy_only: bool,
    summary: bool,
    compress: bool,
    verbose: bool,
    dest: str,
    bucket: Optional[str],
    container: Optional[str],
    prefix: str,
    ttl_days: Optional[int],
    max_artifacts: Optional[int],
    dry_run_dest: bool,
    no_retention: bool,
):
    """
    Export telemetry events with multi-destination support and retention policies.
    
    Modes:
    1. Governance-scoped: --governance-id to export events for specific governance ID
    2. Date-range: --start and --end to export events within time window
    
    Formats:
    - json: Grafana/Metabase (default)
    - csv: Power BI/Excel (flattens policy_results)
    - parquet: Snowflake/BigQuery (requires pyarrow)
    
    Destinations:
    - local: Local filesystem (default)
    - github: GitHub Actions artifacts (auto-fallback to local if not in CI)
    - s3: AWS S3 (requires boto3, --bucket)
    - gcs: Google Cloud Storage (requires google-cloud-storage, --bucket)
    - azure: Azure Blob Storage (requires azure-storage-blob, --container)
    
    Retention:
    - --ttl-days: Delete exports older than N days
    - --max-artifacts: Keep only N most recent exports
    - --dry-run-dest: Preview destination actions without uploading/deleting
    - --no-retention: Skip retention even if ttl-days/max-artifacts set
    
    Examples:
        # Local with compression
        branchpy telemetry export -g AXIS5-V0.9.1.2-20251113-H5-G8 \\
          -f json -o exports/g8.json --compress --dest local
        
        # S3 with retention
        branchpy telemetry export --start 2025-11-13T00:00:00Z --end 2025-11-14T00:00:00Z \\
          -f parquet -o daily.parquet --dest s3 --bucket my-telemetry \\
          --prefix prod/exports --ttl-days 30 --max-artifacts 200
        
        # Dry-run with retention preview
        branchpy telemetry export -g AXIS5-V0.9.1.2-20251113-H5-G8 \\
          -f csv -o g8.csv --dest gcs --bucket telemetry-bkt \\
          --ttl-days 14 --dry-run-dest
    
    Exit codes:
        0: Export successful with ≥1 event
        1: Unexpected error
        2: No events matched filters (informational)
        65: RBAC/policy denied
    """
    try:
        # Validate destination-specific requirements
        dest_lower = dest.lower()

        if dest_lower in ("s3", "gcs") and not bucket:
            raise click.UsageError(f"{dest} destination requires --bucket parameter")

        if dest_lower == "azure" and not container:
            raise click.UsageError("azure destination requires --container parameter")

        # Validate mode arguments
        if governance_id and (start or end):
            raise click.UsageError(
                "Use either --governance-id OR --start/--end (not both)."
            )
        if not governance_id and not (start and end):
            raise click.UsageError("Provide --governance-id OR both --start and --end.")

        from branchpy.telemetry.collectors import EventCollector, EventFilter

        if verbose:
            click.echo("Initializing EventCollector...")

        ec = EventCollector()

        # Collect events based on mode
        if governance_id:
            if verbose:
                click.echo(f"Collecting events for governance_id: {governance_id}")

            # Use governance_id mode
            if module or event_type:
                # Apply additional filters
                flt = EventFilter(
                    governance_id=governance_id,
                    module=module,
                    event_type=event_type,
                    require_policy_results=policy_only,
                )
                events = ec.collect_with_filter(flt)
            else:
                events = ec.collect_by_governance_id(
                    governance_id, include_policy_results=policy_only
                )
        else:
            if verbose:
                click.echo(f"Collecting events from {start} to {end}")

            # Ensure start/end are not None
            if start is None or end is None:
                click.echo(
                    "❌ --start and --end are required when not using --governance-id",
                    err=True,
                )
                raise click.Abort()

            # Use date range mode
            events = ec.collect_by_date_range(
                start_iso=start,
                end_iso=end,
                event_type=event_type,
                module=module,
                include_policy_results=policy_only,
            )

        if verbose:
            click.echo(f"Collected {len(events)} events")

        # Export to specified format using exporters module
        out_path = Path(out)
        exporter = get_exporter(fmt)

        if verbose:
            click.echo(f"Writing {fmt.upper()} to {out_path}")

        # Export with optional compression
        if compress:
            if verbose:
                click.echo("Applying gzip compression...")

            written, reduction = exporter.export_compressed(
                events, out_path, delete_original=True
            )

            if verbose:
                click.echo(f"  Compression: {reduction:.1f}% reduction")
        else:
            exporter.export(events, out_path)
            written = out_path

        # Optional: Generate policy summary
        summary_path = None
        if summary:
            if verbose:
                click.echo("Generating policy summary...")

            s = ec.collect_policy_summary(events, include_details=True)
            summary_path = out_path.with_name(out_path.stem + "_summary.json")

            # Export summary as JSON
            summary_exporter = get_exporter("json")
            if compress:
                summary_path, summary_reduction = summary_exporter.export_compressed(
                    [s],  # Wrap in list for consistent interface
                    summary_path,
                    delete_original=True,
                )
                if verbose:
                    click.echo(
                        f"  Summary compression: {summary_reduction:.1f}% reduction"
                    )
            else:
                # Write summary object directly (not wrapped in list)
                with open(summary_path, "w", encoding="utf-8") as f:
                    json.dump(s, f, indent=2, default=str)
                summary_path = summary_path

            if verbose:
                click.echo(f"Summary written to {summary_path}")
                click.echo(f"  Total executions: {s['events_count']}")
                click.echo(
                    f"  Pass: {s['totals']['pass']}, Warn: {s['totals']['warn']}, Fail: {s['totals']['fail']}, Skip: {s['totals']['skip']}"
                )

        # Check for empty result set
        if len(events) == 0:
            click.echo("⚠️  No events matched filters", err=True)
            sys.exit(2)

        # Destination upload with manifest
        if verbose:
            click.echo(f"\nUploading to {dest_lower} destination...")

        # Build destination kwargs
        dest_kwargs: Dict[str, Any] = {"prefix": prefix}

        if dest_lower == "s3":
            if bucket is None:
                click.echo("❌ --bucket is required for S3 destination", err=True)
                sys.exit(1)
            dest_kwargs["bucket"] = bucket
        elif dest_lower == "gcs":
            if bucket is None:
                click.echo("❌ --bucket is required for GCS destination", err=True)
                sys.exit(1)
            dest_kwargs["bucket"] = bucket
        elif dest_lower == "azure":
            if container is None:
                click.echo("❌ --container is required for Azure destination", err=True)
                sys.exit(1)
            dest_kwargs["container"] = container
        elif dest_lower == "local":
            # Use out file's parent directory as base_dir
            base_path = (
                written.parent
                if written.parent != Path(".")
                else Path.cwd() / "telemetry-artifacts"
            )
            dest_kwargs["base_dir"] = str(base_path)

        try:
            destination = get_destination(dest_lower, **dest_kwargs)
        except Exception as e:
            click.echo(
                f"❌ Failed to initialize {dest_lower} destination: {e}", err=True
            )
            sys.exit(1)

        # Build manifest
        export_timestamp = datetime.now(timezone.utc)

        # Compute checksums
        file_checksum = destination.compute_checksum(written)
        summary_checksum = (
            destination.compute_checksum(summary_path) if summary_path else None
        )

        # Build filters dict for manifest
        filters_dict = {}
        if module:
            filters_dict["module"] = module
        if event_type:
            filters_dict["event_type"] = event_type
        if policy_only:
            filters_dict["policy_only"] = True

        manifest = ExportManifest(
            schema_version="1.0.0",
            export_timestamp=export_timestamp.isoformat(),
            time_window_start=start if start else None,
            time_window_end=end if end else None,
            governance_id=governance_id,
            event_count=len(events),
            format=fmt,
            compressed=compress,
            file_size_bytes=written.stat().st_size,
            file_checksum_sha256=file_checksum,
            summary_file=summary_path.name if summary_path else None,
            summary_checksum_sha256=summary_checksum,
            filters=filters_dict if filters_dict else None,
        )

        # Upload export + manifest
        try:
            upload_key = destination.upload(written, manifest, dry_run=dry_run_dest)

            if verbose:
                click.echo(f"  Uploaded: {upload_key}")
                click.echo(f"  Checksum: {file_checksum[:16]}...")

            if not dry_run_dest:
                click.echo(f"✅ Uploaded to {dest_lower}: {upload_key}")
        except Exception as e:
            click.echo(f"❌ Upload failed: {e}", err=True)
            if verbose:
                import traceback

                traceback.print_exc()
            sys.exit(1)

        # Apply retention policy if configured
        if not no_retention and (ttl_days or max_artifacts):
            if verbose:
                click.echo("\nApplying retention policy...")

            try:
                policy = RetentionPolicy(ttl_days=ttl_days, max_artifacts=max_artifacts)

                if verbose:
                    click.echo(f"  Policy: {policy}")

                stats = policy.apply(destination, dry_run=dry_run_dest)

                if verbose or dry_run_dest:
                    click.echo(f"  Scanned: {stats['total_scanned']} exports")
                    click.echo(f"  TTL pruned: {stats['ttl_pruned']}")
                    click.echo(f"  Max-N pruned: {stats['max_n_pruned']}")
                    click.echo(f"  Bytes freed: {stats['bytes_freed']:,}")

                if not dry_run_dest and stats["total_deleted"] > 0:
                    click.echo(
                        f"✅ Retention: Deleted {stats['total_deleted']} old exports ({stats['bytes_freed']:,} bytes)"
                    )
            except Exception as e:
                click.echo(f"⚠️  Retention policy failed: {e}", err=True)
                # Don't fail the export on retention errors
                stats = None  # Ensure stats is defined even on error
        else:
            stats = None  # No retention policy applied

        # Note: Phase3TelemetryHandler.emit_event() is not available in current implementation
        # Skip telemetry event emission to avoid errors

        # Success
        click.echo(f"\n✅ Export complete: {len(events)} events")
        sys.exit(0)

    except click.UsageError as ue:
        click.echo(f"❌ Usage error: {ue}", err=True)
        sys.exit(2)

    except ImportError as e:
        if "pyarrow" in str(e) and fmt.lower() == "parquet":
            click.echo("❌ Parquet export requires pyarrow", err=True)
            click.echo("   Install with: pip install pyarrow", err=True)
            sys.exit(1)
        else:
            click.echo(f"❌ Import error: {e}", err=True)
            if verbose:
                import traceback

                traceback.print_exc()
            sys.exit(2)

    except Exception as e:
        click.echo(f"❌ Export failed: {e}", err=True)
        if verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)


@telemetry_group.command("stats")
@click.option("--json-output", is_flag=True, help="Output statistics as JSON")
@click.option(
    "--recent",
    default=5,
    show_default=True,
    help="Number of recent events to display",
)
@click.pass_context
def stats_cmd(ctx, json_output: bool, recent: int):
    """
    Show telemetry statistics from local storage.

    Reads from the two local telemetry stores:
    - Core store: command metadata (duration, exit code) written by the CLI
    - Session store: structured events written by the telemetry pipeline

    Examples:
        branchpy telemetry stats
        branchpy telemetry stats --recent 10
        branchpy telemetry stats --json-output > stats.json
    """
    from branchpy.core.paths import CACHE
    from branchpy.telemetry.paths import get_all_telemetry_dirs

    # --- Core telemetry file (command metadata) ---
    core_file = CACHE / "telemetry.jsonl"
    core_records: list[dict] = []
    core_error: str | None = None
    if core_file.exists():
        try:
            with core_file.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        try:
                            core_records.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        except OSError as e:
            core_error = str(e)

    # --- Session JSONL files (LocalTelemetryWriter structured events) ---
    session_records: list[dict] = []
    session_files: list[str] = []
    session_error: str | None = None
    try:
        for telemetry_dir in get_all_telemetry_dirs():
            for f in sorted(telemetry_dir.glob("telemetry_*.jsonl")):
                session_files.append(str(f))
                try:
                    with f.open("r", encoding="utf-8") as fh:
                        for line in fh:
                            line = line.strip()
                            if line:
                                try:
                                    session_records.append(json.loads(line))
                                except json.JSONDecodeError:
                                    pass
                except OSError:
                    pass
    except Exception as e:
        session_error = str(e)

    result = {
        "core": {
            "path": str(core_file),
            "count": len(core_records),
            "error": core_error,
            "recent": core_records[-recent:] if core_records else [],
        },
        "sessions": {
            "files": len(session_files),
            "count": len(session_records),
            "error": session_error,
            "recent": session_records[-recent:] if session_records else [],
        },
    }

    if json_output:
        click.echo(json.dumps(result, indent=2, default=str))
        return

    click.echo("=== Telemetry Storage Statistics ===\n")

    # Core store
    click.echo("[Core — command metadata]")
    click.echo(f"  Path:    {core_file}")
    if core_error:
        click.echo(f"  Error:   {core_error}")
    else:
        click.echo(f"  Records: {len(core_records):,}")
        if core_records:
            last = core_records[-1]
            click.echo(
                f"  Last:    {last.get('ts', 'unknown')} — "
                f"{last.get('command', '?')} "
                f"(exit {last.get('exit_code', '?')})"
            )
        else:
            click.echo("  No records found. (Telemetry may be disabled in config.)")

    click.echo()

    # Session store
    click.echo("[Sessions — structured events]")
    click.echo(f"  Files:   {len(session_files)}")
    if session_error:
        click.echo(f"  Error:   {session_error}")
    else:
        click.echo(f"  Records: {len(session_records):,}")
        if session_records:
            last = session_records[-1]
            click.echo(
                f"  Last:    "
                f"{last.get('ts', last.get('timestamp', 'unknown'))} — "
                f"{last.get('event_type', last.get('type', '?'))}"
            )
            if recent > 0:
                click.echo(f"\n  Recent {min(recent, len(session_records))} event(s):")
                for rec in session_records[-recent:]:
                    ts = rec.get("ts", rec.get("timestamp", "?"))
                    etype = rec.get("event_type", rec.get("type", "?"))
                    click.echo(f"    {ts}  {etype}")
        else:
            click.echo("  No session events found.")


@telemetry_group.command("inspect")
@click.option(
    "--last",
    "n",
    default=10,
    show_default=True,
    help="Number of most recent events to show",
)
@click.option(
    "--store",
    type=click.Choice(["core", "sessions", "all"], case_sensitive=False),
    default="all",
    show_default=True,
    help="Which store to read from",
)
@click.option("--event-type", help="Filter by event_type substring (case-insensitive)")
@click.option("--json-output", is_flag=True, help="Output raw records as JSON array")
def inspect_cmd(n: int, store: str, event_type: str | None, json_output: bool):
    """
    Inspect raw telemetry events from local storage.

    Shows the most recent N events, with optional filtering by store and event
    type. Useful for verifying telemetry is being captured correctly.

    Data never leaves the machine — this reads only from local JSONL files.

    Examples:
        branchpy telemetry inspect
        branchpy telemetry inspect --last 20 --store sessions
        branchpy telemetry inspect --event-type command --json-output
    """
    from branchpy.core.paths import CACHE
    from branchpy.telemetry.paths import get_all_telemetry_dirs

    records: list[dict] = []

    # --- Core store ---
    if store in ("core", "all"):
        core_file = CACHE / "telemetry.jsonl"
        if core_file.exists():
            try:
                with core_file.open("r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if line:
                            try:
                                rec = json.loads(line)
                                rec.setdefault("_store", "core")
                                records.append(rec)
                            except json.JSONDecodeError:
                                pass
            except OSError:
                pass

    # --- Session store ---
    if store in ("sessions", "all"):
        try:
            for telemetry_dir in get_all_telemetry_dirs():
                for f in sorted(telemetry_dir.glob("telemetry_*.jsonl")):
                    try:
                        with f.open("r", encoding="utf-8") as fh:
                            for line in fh:
                                line = line.strip()
                                if line:
                                    try:
                                        rec = json.loads(line)
                                        rec.setdefault("_store", "session")
                                        records.append(rec)
                                    except json.JSONDecodeError:
                                        pass
                    except OSError:
                        pass
        except Exception:
            pass

    # Sort by timestamp field (ts or timestamp), fall back to append order
    def _ts(r: dict) -> str:
        return r.get("ts", r.get("timestamp", ""))

    records.sort(key=_ts)

    # Filter by event type
    if event_type:
        needle = event_type.lower()
        records = [
            r
            for r in records
            if needle
            in (r.get("event_type", r.get("type", r.get("command", ""))).lower())
        ]

    # Take last N
    records = records[-n:]

    if not records:
        click.echo("No telemetry events found.")
        if event_type:
            click.echo(f"(filter: event_type contains '{event_type}')")
        return

    if json_output:
        # Strip internal _store tag from output
        out = [{k: v for k, v in r.items() if k != "_store"} for r in records]
        click.echo(json.dumps(out, indent=2, default=str))
        return

    click.echo(f"=== Last {len(records)} telemetry event(s) ===\n")
    for rec in records:
        ts = rec.get("ts", rec.get("timestamp", "—"))
        etype = rec.get("event_type", rec.get("type", rec.get("command", "—")))
        src = rec.get("_store", "?")
        extra_parts = []
        if "exit_code" in rec:
            extra_parts.append(f"exit={rec['exit_code']}")
        if "duration_ms" in rec:
            extra_parts.append(f"{rec['duration_ms']}ms")
        if "module" in rec:
            extra_parts.append(f"module={rec['module']}")
        extra = f"  [{', '.join(extra_parts)}]" if extra_parts else ""
        click.echo(f"  [{src:7s}] {ts}  {etype}{extra}")


@telemetry_group.command("config")
@click.option("--json-output", is_flag=True, help="Output configuration as JSON")
def config_cmd(json_output: bool):
    """
    Display current telemetry configuration.

    Shows:
    - Backend type (memory, sqlite, postgresql)
    - Feature flags (cache, provider, validation telemetry)
    - Sampling rates
    - Export paths and schedules

    Examples:
        branchpy telemetry config
        branchpy telemetry config --json-output
    """
    try:
        from branchpy.telemetry.config import load_config

        config = load_config()

        if json_output:
            # Convert config to dict
            config_dict = {
                "telemetry_enabled": config.telemetry_enabled,
                "backend": config.backend,
                "cache_telemetry_enabled": config.cache_telemetry_enabled,
                "provider_telemetry_enabled": config.provider_telemetry_enabled,
                "validation_telemetry_enabled": config.validation_telemetry_enabled,
                "cache_sampling_rate": config.cache_sampling_rate,
                "provider_sampling_rate": config.provider_sampling_rate,
                "validation_sampling_rate": config.validation_sampling_rate,
                "export_path": config.export_path,
                "aggregation_window_seconds": config.aggregation_window_seconds,
                "max_event_queue_depth": config.max_event_queue_depth,
                "event_buffer_size": config.event_buffer_size,
            }
            click.echo(json.dumps(config_dict, indent=2))
        else:
            click.echo("=== Telemetry Configuration ===\n")
            click.echo(f"Telemetry enabled:     {config.telemetry_enabled}")
            click.echo(f"Backend:               {config.backend}")

            click.echo("\n--- Feature Flags ---")
            click.echo(f"Cache telemetry:       {config.cache_telemetry_enabled}")
            click.echo(f"Provider telemetry:    {config.provider_telemetry_enabled}")
            click.echo(f"Validation telemetry:  {config.validation_telemetry_enabled}")

            click.echo("\n--- Sampling Rates ---")
            click.echo(f"Cache:                 {config.cache_sampling_rate:.1%}")
            click.echo(f"Provider:              {config.provider_sampling_rate:.1%}")
            click.echo(f"Validation:            {config.validation_sampling_rate:.1%}")

            click.echo("\n--- Export Settings ---")
            click.echo(f"Export path:           {config.export_path}")
            click.echo(f"Aggregation window:    {config.aggregation_window_seconds}s")

            click.echo("\n--- Performance ---")
            click.echo(f"Max queue depth:       {config.max_event_queue_depth:,}")
            click.echo(f"Buffer size:           {config.event_buffer_size:,}")

    except Exception as e:
        click.echo(f"❌ Failed to load config: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("policy")
@click.option("--project", help="Filter by project ID")
@click.option(
    "--module",
    type=click.Choice(["compare", "media", "analyze"], case_sensitive=False),
    help="Filter by module",
)
@click.option(
    "--mode",
    type=click.Choice(["strict", "warn", "ci"], case_sensitive=False),
    help="Filter by enforcement mode",
)
@click.option("--exit-code", type=int, help="Filter by exit code (0, 65, 66, 67)")
@click.option("--days", type=int, default=30, help="Look back N days (default: 30)")
@click.option("--summary", is_flag=True, help="Show summary statistics only")
@click.option("--json-output", is_flag=True, help="Output as JSON")
def policy_cmd(
    project: Optional[str],
    module: Optional[str],
    mode: Optional[str],
    exit_code: Optional[int],
    days: int,
    summary: bool,
    json_output: bool,
):
    """
    View BQF policy enforcement telemetry (WS-T1).

    Shows policy runs, exit codes, violations, and compliance trends.

    Examples:
        # Show all policy runs in last 30 days
        branchpy telemetry policy

        # CI mode runs only
        branchpy telemetry policy --mode ci --days 7

        # Policy violations (exit code 65)
        branchpy telemetry policy --exit-code 65 --summary

        # Export to JSON
        branchpy telemetry policy --module compare --json-output > policy.json

    Exit codes:
        0: Success, all policies passed
        65: Policy violation (fail build)
        66: Remote environment error
        67: Partial analysis (degraded mode)
    """
    try:
        from branchpy.telemetry.query import PolicyTelemetryQuery

        query = PolicyTelemetryQuery()

        if summary or json_output:
            # Get summary statistics
            summary_data = query.get_summary(module=module, mode=mode, days=days)

            if json_output:
                output = {
                    "total_runs": summary_data.total_runs,
                    "strict_runs": summary_data.strict_runs,
                    "warn_runs": summary_data.warn_runs,
                    "ci_runs": summary_data.ci_runs,
                    "exit_code_counts": summary_data.exit_code_counts,
                    "violation_counts": summary_data.violation_counts,
                    "success_rate": round(summary_data.success_rate, 2),
                    "avg_duration_ms": round(summary_data.avg_duration_ms, 2),
                    "top_violations": summary_data.top_violations(10),
                }
                click.echo(json.dumps(output, indent=2))
            else:
                # Print formatted summary
                click.echo(f"Policy Enforcement Summary (Last {days} days)")
                click.echo("━" * 60)
                click.echo(f"Total Runs: {summary_data.total_runs}")

                if summary_data.total_runs > 0:
                    click.echo(
                        f"  - Strict Mode: {summary_data.strict_runs} ({summary_data.strict_runs / summary_data.total_runs * 100:.1f}%)"
                    )
                    click.echo(
                        f"  - CI Mode: {summary_data.ci_runs} ({summary_data.ci_runs / summary_data.total_runs * 100:.1f}%)"
                    )
                    click.echo(
                        f"  - Warn Mode: {summary_data.warn_runs} ({summary_data.warn_runs / summary_data.total_runs * 100:.1f}%)"
                    )

                    click.echo("\nExit Codes:")
                    click.echo(summary_data.format_exit_codes())

                    click.echo(f"\nSuccess Rate: {summary_data.success_rate:.1f}%")
                    click.echo(f"Avg Duration: {summary_data.avg_duration_ms:.1f}ms")

                    top_violations = summary_data.top_violations(5)
                    if top_violations:
                        click.echo("\nTop Violations:")
                        for policy_id, count in top_violations:
                            click.echo(f"  {count:3d}  {policy_id}")
                else:
                    click.echo("\n⚠️  No policy runs found in this time period")

        else:
            # Get detailed runs
            runs = query.get_policy_runs(
                project=project,
                module=module,
                mode=mode,
                exit_code=exit_code,
                days=days,
            )

            if not runs:
                click.echo("⚠️  No policy runs found matching filters")
                return

            click.echo(f"Found {len(runs)} policy runs (Last {days} days)")
            click.echo("━" * 60)

            for run in runs[:20]:  # Limit to 20 most recent
                timestamp = run.get("timestamp", "")
                module_name = run.get("module", "unknown")
                mode_name = run.get("mode", "unknown")
                exit_code_val = run.get("exit_code", 0)
                violations = run.get("violations", [])

                status = "✅" if exit_code_val == 0 else "❌"
                click.echo(
                    f"{status} {timestamp[:19]} | {module_name:8s} | {mode_name:6s} | exit={exit_code_val}"
                )

                if violations:
                    for v in violations[:3]:  # Show first 3 violations
                        click.echo(f"     └─ {v}")

    except Exception as e:
        click.echo(f"❌ Failed to query policy telemetry: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("opt-out")
@click.option("--confirm", is_flag=True, help="Confirm opt-out action")
def opt_out_cmd(confirm: bool):
    """
    Opt-out of telemetry at project level (WS-T1).

    Creates/updates .branchpy.toml to disable telemetry.

    Examples:
        branchpy telemetry opt-out --confirm
    """
    if not confirm:
        click.echo("⚠️  This will disable telemetry for this project.")
        click.echo("   Run with --confirm to proceed.")
        return

    try:
        config_path = Path.cwd() / ".branchpy.toml"

        if config_path.exists():
            # Update existing config
            click.echo(f"Updating {config_path}...")

            try:
                import tomli

                with open(config_path, "rb") as f:
                    data = tomli.load(f)
            except ImportError:
                import tomllib

                with open(config_path, "rb") as f:
                    data = tomllib.load(f)

            # Set telemetry.enabled = false
            if "telemetry" not in data:
                data["telemetry"] = {}
            data["telemetry"]["enabled"] = False

            # Write back (requires tomli_w or manual TOML writing)
            # For now, append to file
            with open(config_path, "a", encoding="utf-8") as f:
                f.write("\n[telemetry]\n")
                f.write("enabled = false\n")

            click.echo(f"✅ Telemetry disabled in {config_path}")

        else:
            # Create new config
            click.echo(f"Creating {config_path}...")

            with open(config_path, "w", encoding="utf-8") as f:
                f.write("[telemetry]\n")
                f.write("enabled = false\n")

            click.echo(f"✅ Created {config_path} with telemetry disabled")

    except Exception as e:
        click.echo(f"❌ Failed to opt-out: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("history")
@click.option("--days", type=int, default=7, help="Show last N days (default: 7)")
@click.option(
    "--event-type", help="Filter by event type (e.g., bqf.enforcement.completed)"
)
def history_cmd(days: int, event_type: Optional[str]):
    """
    Show telemetry events sent in last N days (WS-T1).

    Provides transparency into what data has been emitted.

    Examples:
        branchpy telemetry history --days 7
        branchpy telemetry history --event-type bqf.enforcement.completed
    """
    try:
        from datetime import datetime, timedelta, timezone

        from branchpy.telemetry.collectors import EventCollector, EventFilter

        # Calculate time window
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=days)

        ec = EventCollector()

        # Collect events
        if event_type:
            flt = EventFilter(event_type=event_type, start=start_time, end=end_time)
            events = ec.collect_with_filter(flt)
        else:
            events = ec.collect_by_date_range(
                start_iso=start_time.isoformat(), end_iso=end_time.isoformat()
            )

        if not events:
            click.echo(f"⚠️  No events found in last {days} days")
            return

        click.echo(f"Telemetry History (Last {days} days)")
        click.echo("━" * 60)
        click.echo(f"Total Events: {len(events)}")

        # Group by event type
        by_type = {}
        for event in events:
            evt_type = event.get("event_type", "unknown")
            if evt_type not in by_type:
                by_type[evt_type] = []
            by_type[evt_type].append(event)

        click.echo("\nBy Event Type:")
        for evt_type, evt_list in sorted(
            by_type.items(), key=lambda x: len(x[1]), reverse=True
        ):
            click.echo(f"  {len(evt_list):4d}  {evt_type}")

        # Show sample events
        click.echo("\nRecent Events (last 5):")
        for event in events[-5:]:
            timestamp = event.get("timestamp", "")
            evt_type = event.get("event_type", "unknown")
            click.echo(f"  {timestamp[:19]} | {evt_type}")

    except Exception as e:
        click.echo(f"❌ Failed to load history: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("scene-coverage")
@click.option("--project-hash", help="Filter by project hash")
@click.option(
    "--days",
    "-d",
    type=int,
    default=30,
    help="Show scene coverage data from last N days (default: 30)",
)
@click.option(
    "--format",
    "-f",
    type=click.Choice(["table", "json"], case_sensitive=False),
    default="table",
    help="Output format (default: table)",
)
def scene_coverage_cmd(project_hash: Optional[str], days: int, format: str):
    """
    Show scene coverage analysis telemetry.

    Displays scene reachability metrics from recent analyses.
    """
    try:
        from datetime import datetime, timedelta, timezone

        from branchpy.telemetry.collectors import EventCollector

        ec = EventCollector()

        # Date range filter
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=days)

        # Collect events by date range
        events = ec.collect_by_date_range(
            start_iso=start_time.isoformat(), end_iso=end_time.isoformat()
        )

        # Filter by event type prefix and project hash
        events = [
            e for e in events if e.get("event_type", "").startswith("scene_coverage.")
        ]

        # Project filter if provided
        if project_hash:
            events = [e for e in events if e.get("project_hash") == project_hash]

        if not events:
            click.echo(f"⚠️  No scene coverage data found in last {days} days")
            return

        if format == "json":
            click.echo(json.dumps(events, indent=2))
            return

        # Table format
        click.echo(f"Scene Coverage Analysis (Last {days} days)")
        click.echo("━" * 80)
        click.echo(
            f"Total Analyses: {len([e for e in events if 'completed' in e.get('event_type', '')])}"
        )
        click.echo("")

        # Show completed analyses
        completed = [
            e
            for e in events
            if e.get("event_type") == "scene_coverage.analysis.completed"
        ]

        if completed:
            click.echo(
                f"{'Timestamp':<20} {'Project':<16} {'Total':>6} {'Reach':>6} {'Unreach':>6} {'Coverage':>9} {'Duration':>10}"
            )
            click.echo("─" * 80)

            for event in sorted(
                completed, key=lambda x: x.get("timestamp", ""), reverse=True
            ):
                timestamp = event.get("timestamp", "")[:19]
                proj_hash = event.get("project_hash", "")[:14]
                total = event.get("total_scenes", 0)
                reachable = event.get("reachable_scenes", 0)
                unreachable = event.get("unreachable_scenes", 0)
                coverage = event.get("coverage_percentage", 0.0)
                duration = event.get("duration_ms", 0)

                click.echo(
                    f"{timestamp:<20} {proj_hash:<16} {total:>6} {reachable:>6} {unreachable:>6} {coverage:>8.2f}% {duration:>9}ms"
                )

            # Summary statistics
            click.echo("")
            click.echo("Summary:")
            avg_coverage = sum(
                e.get("coverage_percentage", 0.0) for e in completed
            ) / len(completed)
            avg_duration = sum(e.get("duration_ms", 0) for e in completed) / len(
                completed
            )
            click.echo(f"  Average Coverage: {avg_coverage:.2f}%")
            click.echo(f"  Average Duration: {avg_duration:.0f}ms")

    except Exception as e:
        click.echo(f"❌ Failed to load scene coverage data: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("quickfix")
@click.option(
    "--days",
    "-d",
    type=int,
    default=7,
    help="Show QuickFix data from last N days (default: 7)",
)
@click.option("--action-id", help="Filter by action ID (e.g., 'create-file')")
def quickfix_cmd(days: int, action_id: Optional[str]):
    """
    Show QuickFix action telemetry.

    Displays QuickFix usage metrics and success rates.
    """
    try:
        from datetime import datetime, timedelta, timezone

        from branchpy.telemetry.collectors import EventCollector

        ec = EventCollector()

        # Date range filter
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=days)

        # Collect events by date range
        events = ec.collect_by_date_range(
            start_iso=start_time.isoformat(), end_iso=end_time.isoformat()
        )

        # Filter by event type prefix
        events = [e for e in events if e.get("event_type", "").startswith("quickfix.")]

        # Action ID filter
        if action_id:
            events = [e for e in events if e.get("action_id") == action_id]

        if not events:
            click.echo(f"⚠️  No QuickFix data found in last {days} days")
            return

        click.echo(f"QuickFix Actions (Last {days} days)")
        click.echo("━" * 70)

        # Aggregate by action_id
        actions = {}
        for event in events:
            aid = event.get("action_id", "unknown")
            if aid not in actions:
                actions[aid] = {
                    "invoked": 0,
                    "completed": 0,
                    "success": 0,
                    "failure": 0,
                    "cancelled": 0,
                }

            evt_type = event.get("event_type", "")
            if "invoked" in evt_type:
                actions[aid]["invoked"] += 1
            elif "completed" in evt_type:
                actions[aid]["completed"] += 1
                result = event.get("result", "")
                if result:
                    actions[aid][result] += 1

        # Display table
        click.echo(
            f"{'Action ID':<25} {'Invoked':>8} {'Completed':>10} {'Success':>8} {'Failure':>8} {'Success Rate':>13}"
        )
        click.echo("─" * 70)

        for aid, stats in sorted(
            actions.items(), key=lambda x: x[1]["invoked"], reverse=True
        ):
            invoked = stats["invoked"]
            completed = stats["completed"]
            success = stats["success"]
            failure = stats["failure"]
            success_rate = (success / completed * 100) if completed > 0 else 0.0

            click.echo(
                f"{aid:<25} {invoked:>8} {completed:>10} {success:>8} {failure:>8} {success_rate:>12.1f}%"
            )

        # Overall summary
        total_invoked = sum(s["invoked"] for s in actions.values())
        total_completed = sum(s["completed"] for s in actions.values())
        total_success = sum(s["success"] for s in actions.values())
        overall_rate = (
            (total_success / total_completed * 100) if total_completed > 0 else 0.0
        )

        click.echo("")
        click.echo(
            f"Total: {total_invoked} invoked, {total_completed} completed, {overall_rate:.1f}% success rate"
        )

    except Exception as e:
        click.echo(f"❌ Failed to load QuickFix data: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("sessions")
@click.option(
    "--days",
    "-d",
    type=int,
    default=30,
    help="Show session data from last N days (default: 30)",
)
@click.option(
    "--source",
    type=click.Choice(["cli", "vscode", "sdk", "analyzer"], case_sensitive=False),
    help="Filter by source",
)
def sessions_cmd(days: int, source: Optional[str]):
    """
    Show session telemetry.

    Displays session count, duration, and platform statistics.
    """
    try:
        from datetime import datetime, timedelta, timezone

        from branchpy.telemetry.collectors import EventCollector

        ec = EventCollector()

        # Date range filter
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=days)

        # Collect events by date range
        events = ec.collect_by_date_range(
            start_iso=start_time.isoformat(), end_iso=end_time.isoformat()
        )

        # Filter by event type prefix
        events = [
            e
            for e in events
            if e.get("event_type", "").startswith("telemetry.session.")
        ]

        # Source filter
        if source:
            events = [e for e in events if e.get("source") == source]

        if not events:
            click.echo(f"⚠️  No session data found in last {days} days")
            return

        click.echo(f"Session Telemetry (Last {days} days)")
        click.echo("━" * 60)

        # Separate start and end events
        starts = [e for e in events if e.get("event_type") == "telemetry.session.start"]
        ends = [e for e in events if e.get("event_type") == "telemetry.session.end"]

        click.echo(f"Total Sessions Started: {len(starts)}")
        click.echo(f"Total Sessions Ended: {len(ends)}")
        click.echo("")

        # By source
        by_source = {}
        for event in starts:
            src = event.get("source", "unknown")
            by_source[src] = by_source.get(src, 0) + 1

        click.echo("By Source:")
        for src, count in sorted(by_source.items(), key=lambda x: x[1], reverse=True):
            click.echo(f"  {src:<12} {count:>4} sessions")

        # By platform
        by_platform = {}
        for event in starts:
            plat = event.get("platform", "unknown")
            by_platform[plat] = by_platform.get(plat, 0) + 1

        if by_platform:
            click.echo("")
            click.echo("By Platform:")
            for plat, count in sorted(
                by_platform.items(), key=lambda x: x[1], reverse=True
            ):
                click.echo(f"  {plat:<12} {count:>4} sessions")

        # Average duration
        durations = [e.get("duration_ms", 0) for e in ends if e.get("duration_ms")]
        if durations:
            avg_duration = sum(durations) / len(durations)
            click.echo("")
            click.echo(
                f"Average Session Duration: {avg_duration/1000:.1f}s ({avg_duration:.0f}ms)"
            )

    except Exception as e:
        click.echo(f"❌ Failed to load session data: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("errors")
@click.option(
    "--days",
    "-d",
    type=int,
    default=7,
    help="Show error data from last N days (default: 7)",
)
@click.option("--exception-type", help="Filter by exception type (e.g., 'ValueError')")
def errors_cmd(days: int, exception_type: Optional[str]):
    """
    Show error and crash telemetry.

    Displays exception types, modules, and SLO violations.
    """
    try:
        from datetime import datetime, timedelta, timezone

        from branchpy.telemetry.collectors import EventCollector

        ec = EventCollector()

        # Date range filter
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=days)

        # Collect events by date range
        events = ec.collect_by_date_range(
            start_iso=start_time.isoformat(), end_iso=end_time.isoformat()
        )

        # Filter by event type prefix
        events = [e for e in events if e.get("event_type", "").startswith("error.")]

        # Exception type filter
        if exception_type:
            events = [e for e in events if e.get("exception_type") == exception_type]

        if not events:
            click.echo(f"⚠️  No error data found in last {days} days")
            return

        click.echo(f"Error & Crash Telemetry (Last {days} days)")
        click.echo("━" * 60)

        # Separate by event type
        exceptions = [e for e in events if "exception" in e.get("event_type", "")]
        slo_violations = [e for e in events if "slo" in e.get("event_type", "")]

        click.echo(f"Total Unhandled Exceptions: {len(exceptions)}")
        click.echo(f"Total SLO Violations: {len(slo_violations)}")
        click.echo("")

        # Exception types
        if exceptions:
            exc_types = {}
            for event in exceptions:
                exc_type = event.get("exception_type", "unknown")
                module = event.get("module", "unknown")
                key = f"{exc_type} ({module})"
                exc_types[key] = exc_types.get(key, 0) + 1

            click.echo("By Exception Type:")
            for key, count in sorted(
                exc_types.items(), key=lambda x: x[1], reverse=True
            ):
                click.echo(f"  {count:>3}  {key}")

        # SLO violations
        if slo_violations:
            click.echo("")
            click.echo("SLO Violations:")
            for event in sorted(
                slo_violations, key=lambda x: x.get("actual_ms", 0), reverse=True
            )[:10]:
                operation = event.get("operation", "unknown")
                expected = event.get("expected_ms", 0)
                actual = event.get("actual_ms", 0)
                overage = actual - expected
                click.echo(
                    f"  {operation:<30} Expected: {expected:>5}ms  Actual: {actual:>5}ms  (+{overage}ms)"
                )

    except Exception as e:
        click.echo(f"❌ Failed to load error data: {e}", err=True)
        raise click.Abort()


@telemetry_group.command("coverage")
@click.option("--project", help="Filter by project hash (e.g., abc123...)")
@click.option(
    "--days",
    "-d",
    type=int,
    default=30,
    help="Show analyses from last N days (default: 30)",
)
@click.option(
    "--limit", "-n", type=int, default=20, help="Maximum analyses to show (default: 20)"
)
@click.option(
    "--format",
    "-f",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format (default: table)",
)
def coverage_cmd(project: Optional[str], days: int, limit: int, format: str):
    """
    Display scene coverage metrics from recent analyses.

    Shows total scenes, reachable scenes, unreachable scenes, and coverage
    percentage for each analysis run.

    Examples:

        branchpy telemetry coverage
        branchpy telemetry coverage --project abc123
        branchpy telemetry coverage --days 7 --format json
    """
    try:
        # Import storage (lazy to avoid startup penalty)
        from datetime import datetime, timedelta, timezone

        from branchpy.telemetry.storage import EventFilter
        from branchpy.telemetry.storage_sqlite import LocalSQLiteSink

        # Initialize storage
        storage = LocalSQLiteSink(db_path=".branchpy/telemetry/events.db")

        # Build filter
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=days)

        event_filter = EventFilter(
            category="scene_coverage",
            event_type="scene_coverage.analysis.completed",
            project_hash=project if project else None,
            start=start,
            end=end,
            limit=limit,
        )

        # Query events
        events = storage.read_events(event_filter)

        if not events:
            if project:
                click.echo(
                    f"⚠️  No coverage data found for project {project} in last {days} days"
                )
            else:
                click.echo(f"⚠️  No coverage data found in last {days} days")
            click.echo("\nRun scene coverage analysis to generate data:")
            click.echo("  branchpy analyze --coverage <project_path>")
            return

        # JSON output
        if format == "json":
            output = []
            for event in events:
                output.append(
                    {
                        "timestamp": event.get("occurred_at"),
                        "project_hash": event.get("project_hash"),
                        "total_scenes": event.get("total_scenes"),
                        "reachable_scenes": event.get("reachable_scenes"),
                        "unreachable_scenes": event.get("unreachable_scenes"),
                        "coverage_percentage": event.get("coverage_percentage"),
                        "duration_ms": event.get("duration_ms"),
                    }
                )
            click.echo(json.dumps(output, indent=2))
            return

        # Table output
        try:
            from tabulate import tabulate
        except ImportError:
            click.echo("❌ Missing dependency: tabulate", err=True)
            click.echo("Install: pip install tabulate", err=True)
            raise click.Abort()

        # Calculate summary stats
        total_analyses = len(events)
        avg_coverage = (
            sum(e.get("coverage_percentage", 0) for e in events) / total_analyses
            if total_analyses > 0
            else 0
        )
        avg_total_scenes = (
            sum(e.get("total_scenes", 0) for e in events) / total_analyses
            if total_analyses > 0
            else 0
        )
        avg_reachable = (
            sum(e.get("reachable_scenes", 0) for e in events) / total_analyses
            if total_analyses > 0
            else 0
        )

        # Display summary header
        click.echo("\n" + "=" * 70)
        click.echo("  SCENE COVERAGE SUMMARY")
        click.echo("=" * 70)
        click.echo(f"  Period:             Last {days} days")
        click.echo(f"  Total Analyses:     {total_analyses}")
        click.echo(f"  Avg Coverage:       {avg_coverage:.1f}%")
        click.echo(f"  Avg Total Scenes:   {int(avg_total_scenes)}")
        click.echo(f"  Avg Reachable:      {int(avg_reachable)}")
        if project:
            click.echo(f"  Project Filter:     {project}")
        click.echo("=" * 70 + "\n")

        # Build table rows
        table = []
        for event in events:
            # Format timestamp
            timestamp = event.get("occurred_at", "")
            if isinstance(timestamp, str):
                timestamp = timestamp[:19]  # Trim to YYYY-MM-DD HH:MM:SS

            # Format project hash (first 8 chars)
            proj_hash = event.get("project_hash", "unknown")
            if len(proj_hash) > 8:
                proj_hash = proj_hash[:8]

            # Get metrics
            total = event.get("total_scenes", 0)
            reachable = event.get("reachable_scenes", 0)
            unreachable = event.get("unreachable_scenes", 0)
            coverage = event.get("coverage_percentage", 0)
            duration = event.get("duration_ms", 0)

            # Color-code coverage
            if coverage >= 90:
                coverage_str = click.style(f"{coverage:.1f}%", fg="green")
            elif coverage >= 70:
                coverage_str = click.style(f"{coverage:.1f}%", fg="yellow")
            else:
                coverage_str = click.style(f"{coverage:.1f}%", fg="red")

            table.append(
                [
                    timestamp,
                    proj_hash,
                    total,
                    reachable,
                    unreachable,
                    coverage_str,
                    f"{duration:,}ms" if duration else "-",
                ]
            )

        # Display table
        headers = [
            "Timestamp",
            "Project",
            "Total",
            "Reachable",
            "Unreach.",
            "Coverage",
            "Duration",
        ]
        click.echo(tabulate(table, headers=headers, tablefmt="simple"))

        click.echo(f"\nShowing {len(events)} of {total_analyses} analyses")

        if len(events) < total_analyses:
            click.echo(f"Use --limit {total_analyses} to see all")

    except ImportError as e:
        click.echo(f"❌ Missing dependency: {e}", err=True)
        raise click.Abort()
    except Exception as e:
        click.echo(f"❌ Failed to load coverage data: {e}", err=True)
        raise click.Abort()


# Legacy function name for backward compatibility
def _legacy_add_parser(subparsers):
    """
    Legacy argparse-style parser registration for CLI compatibility.

    For v1.1.0 telemetry standardization commands (mode, preview, upload),
    users should call Click directly:
        python -m branchpy.cli.telemetry_cmd mode --show
        python -m branchpy.cli.telemetry_cmd preview --from 2h
        python -m branchpy.cli.telemetry_cmd upload --auto

    Legacy export/stats/config commands still work via argparse:
        branchpy telemetry export --format json
        branchpy telemetry stats
    """
    parser = subparsers.add_parser(
        "telemetry",
        help="Telemetry management and export commands (legacy: export, stats, config)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""
Telemetry Commands:
  
  Legacy commands (via argparse):
    branchpy telemetry export   - Export aggregated metrics
    branchpy telemetry stats    - Show telemetry statistics  
    branchpy telemetry config   - Display configuration
  
  v1.1.0 commands (use Click directly):
    python -m branchpy.cli.telemetry_cmd mode [off|manual|auto]
    python -m branchpy.cli.telemetry_cmd preview [--from TIME] [--to TIME]
    python -m branchpy.cli.telemetry_cmd upload [--auto] [--file FILE]
""",
    )

    return parser


def _legacy_run(args):
    """
    Legacy run function - shows help for new Click commands.
    """
    print("ℹ️  For v1.1.0 telemetry mode/preview/upload commands, use:")
    print("    python -m branchpy.cli.telemetry_cmd mode --show")
    print("    python -m branchpy.cli.telemetry_cmd preview --from 2h")
    print("    python -m branchpy.cli.telemetry_cmd upload --auto")
    print()
    print("Or call telemetry_group directly from Python")
    return 0


@telemetry_group.command("mode")
@click.argument(
    "mode",
    type=click.Choice(["off", "manual", "auto"], case_sensitive=False),
    required=False,
)
@click.option("--show", is_flag=True, help="Show current telemetry mode")
def mode_cmd(mode: Optional[str], show: bool):
    """
    Get or set telemetry mode.

    Modes:
    - off:    No telemetry collection or upload
    - manual: Collect locally, manual export/upload only
    - auto:   Automatic upload on schedule

    Examples:
        branchpy telemetry mode --show
        branchpy telemetry mode manual
        branchpy telemetry mode off
    """
    try:
        from pathlib import Path

        from branchpy.config import load_config

        # Load current config
        project_root = Path.cwd()
        config = load_config(project_root)

        current_mode = config.get("telemetry", {}).get("mode", "manual")

        if show or not mode:
            # Show current mode
            click.echo(f"Current telemetry mode: {current_mode}")

            mode_descriptions = {
                "off": "No telemetry collected or sent",
                "manual": "Collect locally, manual export/upload only",
                "auto": "Automatic upload on schedule",
            }
            click.echo(f"  {mode_descriptions.get(current_mode, 'Unknown mode')}")
            sys.exit(0)

        # Set new mode
        if mode.lower() == current_mode:
            click.echo(f"✅ Telemetry mode already set to: {mode}")
            sys.exit(0)

        # Update config via config set command
        result = subprocess.run(
            [
                "python",
                "-m",
                "branchpy",
                "config",
                "set",
                "telemetry.mode",
                mode.lower(),
            ],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            click.echo(f"✅ Telemetry mode set to: {mode}")

            # Show helpful message
            if mode.lower() == "off":
                click.echo("   Telemetry collection and upload disabled")
            elif mode.lower() == "manual":
                click.echo("   Telemetry will be collected locally")
                click.echo(
                    "   Use 'branchpy telemetry export' to create an export file"
                )
            elif mode.lower() == "auto":
                click.echo("   Telemetry will be uploaded automatically")
                click.echo(
                    "   Use 'branchpy telemetry preview' to see what will be sent"
                )
        else:
            click.echo(f"❌ Failed to set telemetry mode: {result.stderr}", err=True)
            sys.exit(1)

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@telemetry_group.command("preview")
@click.option(
    "--from",
    "from_time",
    help="Start time (ISO8601 or relative like '2h')",
    default="2h",
)
@click.option("--to", "to_time", help="End time (ISO8601)", default="now")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.option("--full", is_flag=True, help="Show full package content (verbose)")
def preview_cmd(from_time: str, to_time: str, json_output: bool, full: bool):
    """
    Preview telemetry data that would be exported/uploaded.

    Shows:
    - Event count
    - Time range
    - Approximate size
    - Sample events (if --full)

    Examples:
        branchpy telemetry preview
        branchpy telemetry preview --from 24h
        branchpy telemetry preview --full --json
    """
    try:
        import json
        from datetime import datetime, timedelta

        from branchpy.telemetry import retention
        from branchpy.telemetry.package_builder import build_telemetry_package
        from branchpy.telemetry.package_schema import validate_package

        # Enforce retention before preview (deterministic cleanup)
        retention.opportunistic_cleanup()

        # Parse time range
        end_dt = datetime.utcnow()

        if from_time.endswith("h"):
            hours = int(from_time[:-1])
            start_dt = end_dt - timedelta(hours=hours)
        elif from_time.endswith("d"):
            days = int(from_time[:-1])
            start_dt = end_dt - timedelta(days=days)
        elif from_time.endswith("m"):
            minutes = int(from_time[:-1])
            start_dt = end_dt - timedelta(minutes=minutes)
        else:
            # Assume ISO8601
            start_dt = datetime.fromisoformat(from_time.replace("Z", "+00:00"))

        # Use isoformat() directly for TZ-aware datetimes (already includes +00:00);
        # only append Z for naive datetimes produced by datetime.utcnow().
        start_iso = (
            start_dt.isoformat()
            if start_dt.tzinfo is not None
            else start_dt.isoformat() + "Z"
        )
        end_iso = (
            end_dt.isoformat()
            if end_dt.tzinfo is not None
            else end_dt.isoformat() + "Z"
        )

        # Build preview package
        click.echo("Building telemetry preview...")
        package = build_telemetry_package(start_iso, end_iso)

        # Validate privacy
        validation_errors = validate_package(package)
        if validation_errors:
            click.echo("⚠️  Privacy validation warnings:", err=True)
            for error in validation_errors:
                click.echo(f"  - {error}", err=True)

        if json_output:
            # Output as JSON
            from dataclasses import asdict

            output = asdict(package)
            if not full:
                # Truncate events for non-full preview
                if len(output["events"]) > 10:
                    output["events"] = output["events"][:10]
                    output["_truncated"] = True
            click.echo(json.dumps(output, indent=2, default=str))
        else:
            # Human-readable summary
            click.echo("\n" + "=" * 70)
            click.echo("  TELEMETRY PREVIEW")
            click.echo("=" * 70)
            click.echo(f"  Schema Version:     {package.schema_version}")
            click.echo(
                f"  Time Range:         {package.time_range_start[:19]} to {package.time_range_end[:19]}"
            )
            click.echo(f"  Total Events:       {len(package.events)}")
            click.echo(f"  Error Count:        {len(package.errors)}")

            if package.client:
                click.echo(f"  BranchPy Version:   {package.client.branchpy_version}")
                click.echo(f"  Python Version:     {package.client.python_version}")
                click.echo(f"  OS:                 {package.client.os}")

            if package.usage:
                total_commands = sum(package.usage.commands_run.values())
                click.echo(f"  Commands Run:       {total_commands}")

            # Estimate size
            import json
            from dataclasses import asdict

            size_bytes = len(json.dumps(asdict(package), default=str))
            click.echo(
                f"  Estimated Size:     {size_bytes:,} bytes ({size_bytes/1024:.1f} KB)"
            )

            click.echo("=" * 70)

            if full and package.events:
                click.echo("\nSample Events (first 10):")
                for i, event in enumerate(package.events[:10], 1):
                    click.echo(f"\n  {i}. {event.event_type}")
                    click.echo(f"     Time: {event.timestamp}")
                    click.echo(
                        f"     Duration: {event.duration_ms}ms"
                        if event.duration_ms
                        else ""
                    )
                    click.echo(f"     Success: {event.success}")

            click.echo(
                "\n✅ Privacy check passed"
                if not validation_errors
                else "\n⚠️  Privacy warnings detected"
            )

        sys.exit(0)

    except Exception as e:
        click.echo(f"❌ Preview failed: {e}", err=True)
        if "--verbose" in sys.argv:
            import traceback

            traceback.print_exc()
        sys.exit(1)


@telemetry_group.command("where")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed file listing")
def where_cmd(verbose: bool):
    """
    Show telemetry storage location and disk usage.

    Displays:
    - Current telemetry mode
    - Telemetry directory path
    - File count and disk usage
    - Optional: detailed file listing

    Examples:
        branchpy telemetry where
        branchpy telemetry where --verbose
    """
    try:
        from pathlib import Path

        from branchpy.config import load_config
        from branchpy.telemetry import paths as telemetry_paths

        click.echo("\n" + "=" * 70)
        click.echo("  TELEMETRY STORAGE LOCATION")
        click.echo("=" * 70)

        # Show mode
        try:
            project_root = Path.cwd()
            config = load_config(project_root)
            mode = config.get("telemetry", {}).get("mode", "manual")
            click.echo(f"  Mode:               {mode}")
        except Exception:
            click.echo("  Mode:               manual (default)")

        # Show telemetry directory
        telemetry_dir = telemetry_paths.get_telemetry_dir()
        click.echo(f"  Directory:          {telemetry_dir}")
        click.echo(
            f"  Exists:             {'✓ Yes' if telemetry_dir.exists() else '✗ No'}"
        )

        if telemetry_dir.exists():
            # Show disk usage
            total_bytes, file_count = telemetry_paths.get_disk_usage(telemetry_dir)
            total_mb = total_bytes / (1024 * 1024)

            click.echo(f"  File Count:         {file_count}")
            click.echo(
                f"  Disk Usage:         {total_mb:.2f} MB ({total_bytes:,} bytes)"
            )

            # Detailed file listing (if --verbose)
            if verbose and file_count > 0:
                click.echo("\n  Files:")
                files = sorted(
                    telemetry_dir.glob("telemetry-*.jsonl"),
                    key=lambda f: f.stat().st_mtime,
                )

                for file in files:
                    stat = file.stat()
                    size_kb = stat.st_size / 1024
                    mtime = datetime.fromtimestamp(stat.st_mtime).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )

                    # Count lines (events)
                    try:
                        with open(file, "r", encoding="utf-8") as f:
                            line_count = sum(1 for line in f if line.strip())
                    except Exception:
                        line_count = 0

                    click.echo(f"    • {file.name}")
                    click.echo(
                        f"      Size: {size_kb:.1f} KB | Events: {line_count} | Modified: {mtime}"
                    )

        click.echo("=" * 70 + "\n")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        import traceback

        traceback.print_exc()
        sys.exit(1)


@telemetry_group.command("upload")
@click.option(
    "--file", "-f", type=click.Path(exists=True), help="Telemetry file to upload"
)
@click.option("--auto", is_flag=True, help="Auto-generate and upload current telemetry")
@click.option(
    "--from",
    "from_time",
    help="Start time for auto-generate (ISO8601 or relative)",
    default="2h",
)
@click.option(
    "--to", "to_time", help="End time for auto-generate (ISO8601)", default="now"
)
@click.option("--endpoint", help="Upload endpoint URL", default=None)
@click.option(
    "--dry-run", is_flag=True, help="Show what would be uploaded without sending"
)
def upload_cmd(
    file: Optional[str],
    auto: bool,
    from_time: str,
    to_time: str,
    endpoint: Optional[str],
    dry_run: bool,
):
    """
    Upload telemetry data to BranchPy servers.

    Modes:
    - Manual: Upload from pre-exported file (--file)
    - Auto: Generate and upload current telemetry (--auto)

    Examples:
        branchpy telemetry upload --file telemetry.json
        branchpy telemetry upload --auto --from 24h
        branchpy telemetry upload --auto --dry-run
    """
    try:
        import json
        from pathlib import Path

        import requests

        # Determine upload endpoint
        if not endpoint:
            # Use default production endpoint
            endpoint = "https://api.branchpy.com/api/telemetry/upload"

        # Get telemetry data
        if file:
            # Load from file
            file_path = Path(file)
            click.echo(f"Loading telemetry from: {file_path}")

            with open(file_path, "r", encoding="utf-8") as f:
                telemetry_data = json.load(f)

        elif auto:
            # Auto-generate from current telemetry
            from datetime import datetime, timedelta

            from branchpy.telemetry import retention
            from branchpy.telemetry.package_builder import build_telemetry_package

            # Enforce retention before packaging (prevent stale data upload)
            retention.opportunistic_cleanup()

            click.echo("Generating telemetry package...")

            # Parse time range (same logic as preview)
            end_dt = datetime.utcnow()

            if from_time.endswith("h"):
                hours = int(from_time[:-1])
                start_dt = end_dt - timedelta(hours=hours)
            elif from_time.endswith("d"):
                days = int(from_time[:-1])
                start_dt = end_dt - timedelta(days=days)
            elif from_time.endswith("m"):
                minutes = int(from_time[:-1])
                start_dt = end_dt - timedelta(minutes=minutes)
            else:
                start_dt = datetime.fromisoformat(from_time.replace("Z", "+00:00"))

            # Use isoformat() directly for TZ-aware datetimes (already includes +00:00);
            # only append Z for naive datetimes produced by datetime.utcnow().
            start_iso = (
                start_dt.isoformat()
                if start_dt.tzinfo is not None
                else start_dt.isoformat() + "Z"
            )
            end_iso = (
                end_dt.isoformat()
                if end_dt.tzinfo is not None
                else end_dt.isoformat() + "Z"
            )

            package = build_telemetry_package(start_iso, end_iso)

            # Convert to dict
            from dataclasses import asdict

            telemetry_data = asdict(package)
        else:
            click.echo("❌ Must specify either --file or --auto", err=True)
            sys.exit(1)

        # Validate data
        event_count = telemetry_data.get("events", [])
        if isinstance(event_count, list):
            event_count = len(event_count)

        data_size = len(json.dumps(telemetry_data))

        click.echo(f"  Events: {event_count}")
        click.echo(f"  Size: {data_size:,} bytes ({data_size/1024:.1f} KB)")

        if dry_run:
            click.echo("\n🔍 DRY RUN - Would upload to:")
            click.echo(f"  Endpoint: {endpoint}")
            click.echo("  Payload preview:")
            click.echo(
                f"    {json.dumps(telemetry_data, indent=2, default=str)[:500]}..."
            )
            click.echo("\n✅ Dry run complete (no data sent)")
            sys.exit(0)

        # Perform upload
        click.echo(f"\nUploading to: {endpoint}")

        # Get authentication token if configured
        from branchpy.config import load_config

        config = load_config(Path.cwd())
        auth_token = config.get("telemetry", {}).get("auth_token")

        # Fall back to telemetry_token provisioned in auth.json by the VS Code extension
        if not auth_token:
            try:
                auth_json_path = Path.home() / ".branchpy" / "auth.json"
                if auth_json_path.exists():
                    stored = json.loads(auth_json_path.read_text(encoding="utf-8-sig"))
                    auth_token = stored.get("telemetry_token") or None
            except Exception as e:
                click.echo(
                    f"[telemetry] Warning: could not read auth.json ({e})", err=True
                )

        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"BranchPy/{telemetry_data.get('client', {}).get('branchpy_version', 'unknown')}",
        }

        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        response = requests.post(
            endpoint, json=telemetry_data, headers=headers, timeout=30
        )

        if response.status_code in (200, 201, 202):
            result = response.json()
            click.echo("\n✅ Upload successful!")
            click.echo(f"   Upload ID: {result.get('upload_id', 'N/A')}")
            click.echo(f"   Events received: {result.get('events_received', 0)}")
            click.echo(f"   Events processed: {result.get('events_processed', 0)}")
            click.echo(f"   Deduped: {result.get('deduped', 0)}")
            # Record timestamp for `bpy telemetry status`
            try:
                from branchpy.telemetry.paths import get_branchpy_home

                upload_marker = get_branchpy_home() / "last_upload.txt"
                upload_marker.write_text(
                    datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
                    encoding="utf-8",
                )
            except Exception:
                pass
            sys.exit(0)
        elif response.status_code == 401:
            click.echo("\n❌ Authentication failed", err=True)
            click.echo(
                "   Set auth token: branchpy config set telemetry.auth_token <token>",
                err=True,
            )
            sys.exit(1)
        else:
            click.echo(f"\n❌ Upload failed: HTTP {response.status_code}", err=True)
            click.echo(f"   {response.text}", err=True)
            sys.exit(1)

    except ImportError:
        click.echo("❌ Missing dependency: requests", err=True)
        click.echo("   Install with: pip install requests", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Upload failed: {e}", err=True)
        if "--verbose" in sys.argv:
            import traceback

            traceback.print_exc()
        sys.exit(1)


@telemetry_group.command("status")
def status_cmd():
    """
    Show telemetry status at a glance.

    Reports:
    - Telemetry mode (off / manual / auto)
    - Upload token presence and linkage
    - Account identity from auth.json
    - Last local event timestamp
    - Last upload timestamp

    Examples:
        branchpy telemetry status
    """
    import json as _json
    from pathlib import Path as _Path

    auth_json_path = _Path.home() / ".branchpy" / "auth.json"

    # ── Auth / account ─────────────────────────────────────────────────────
    account_email: str = "(not logged in)"
    token_status: str = "absent"
    auth_data: dict = {}

    if auth_json_path.exists():
        try:
            auth_data = _json.loads(auth_json_path.read_text(encoding="utf-8-sig"))
            raw_email = auth_data.get("email") or ""
            # Email may be embedded in the JWT access_token payload
            if not raw_email:
                try:
                    import base64

                    payload_b64 = (auth_data.get("access_token") or "").split(".")[1]
                    payload = _json.loads(base64.b64decode(payload_b64 + "=="))
                    raw_email = payload.get("email") or ""
                except Exception:
                    pass
            account_email = raw_email or "(unknown)"
            token_status = (
                "present (linked)" if auth_data.get("telemetry_token") else "absent"
            )
        except Exception:
            account_email = "(auth.json unreadable)"

    # ── Telemetry mode ──────────────────────────────────────────────────────
    telemetry_mode: str = "unknown"
    try:
        from branchpy.config import load_config as _load_cfg

        cfg = _load_cfg(_Path.cwd())
        telemetry_mode = cfg.get("telemetry", {}).get("mode", "off")
    except Exception:
        pass

    # ── Last local event ────────────────────────────────────────────────────
    last_event: str = "never"
    try:
        from branchpy.telemetry.paths import get_telemetry_dir

        tel_dir = get_telemetry_dir()
        jsonl_files = sorted(
            tel_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True
        )
        if jsonl_files:
            import datetime as _dt

            mtime = jsonl_files[0].stat().st_mtime
            last_event = _dt.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        pass

    # ── Last upload ─────────────────────────────────────────────────────────
    last_upload: str = "never"
    try:
        from branchpy.telemetry.paths import get_branchpy_home

        upload_marker = get_branchpy_home() / "last_upload.txt"
        if upload_marker.exists():
            last_upload = upload_marker.read_text(encoding="utf-8").strip() or "never"
    except Exception:
        pass

    # ── Output ──────────────────────────────────────────────────────────────
    click.echo("")
    click.echo("Telemetry status")
    click.echo("════════════════════════════════════")
    click.echo(f"  Mode        : {telemetry_mode}")
    click.echo(f"  Token       : {token_status}")
    click.echo(f"  Account     : {account_email}")
    click.echo(f"  Last event  : {last_event}")
    click.echo(f"  Last upload : {last_upload}")
    click.echo("")


# Click app entrypoint
if __name__ == "__main__":
    telemetry_group()


# ============================================================================
# Argparse bridge (for CLI registry compatibility)
# ============================================================================
def add_parser(subparsers):
    """
    Register telemetry command with argparse (CLI registry interface).
    Bridges Click-based telemetry_group to argparse framework.
    """
    parser = subparsers.add_parser(
        "telemetry",
        help="Telemetry export, upload, and statistics",
        description="Telemetry management commands (export, stats, config, upload, etc.)",
    )

    # Add all telemetry subcommands via argparse
    telemetry_sub = parser.add_subparsers(dest="telemetry_command", required=False)

    # --- export subcommand ---
    export_parser = telemetry_sub.add_parser("export", help="Export telemetry data")
    export_parser.add_argument("--governance-id", "-g", help="Filter by governance ID")
    export_parser.add_argument("--start", help="Start ISO8601")
    export_parser.add_argument("--end", help="End ISO8601")
    export_parser.add_argument("--module", choices=["compare", "image", "media", "bqf"])
    export_parser.add_argument("--event-type", help="Filter by event_type")
    export_parser.add_argument(
        "-f", "--format", choices=["json", "csv", "parquet"], default="json"
    )
    export_parser.add_argument("-o", "--out", required=True, help="Output file path")
    export_parser.add_argument("--policy-only", action="store_true")
    export_parser.add_argument("--summary", action="store_true")
    export_parser.add_argument("--compress", action="store_true")
    export_parser.add_argument("-v", "--verbose", action="store_true")
    export_parser.add_argument(
        "--dest", choices=["local", "github", "s3", "gcs", "azure"], default="local"
    )
    export_parser.add_argument("--bucket", help="S3/GCS bucket name")

    # --- stats subcommand ---
    stats_parser = telemetry_sub.add_parser("stats", help="Show telemetry statistics")
    stats_parser.add_argument("--json", action="store_true")

    # --- config subcommand ---
    config_parser = telemetry_sub.add_parser(
        "config", help="Display telemetry configuration"
    )

    # --- status subcommand ---
    telemetry_sub.add_parser("status", help="Show telemetry status at a glance")

    # --- upload subcommand (the one we need for the fix) ---
    upload_parser = telemetry_sub.add_parser("upload", help="Upload telemetry data")
    upload_parser.add_argument("--file", "-f", help="Telemetry file to upload")
    upload_parser.add_argument(
        "--auto", action="store_true", help="Auto-generate and upload"
    )
    upload_parser.add_argument(
        "--from",
        dest="from_time",
        help="Start time (ISO8601 or relative)",
        default="2h",
    )
    upload_parser.add_argument(
        "--to", dest="to_time", help="End time (ISO8601)", default="now"
    )
    upload_parser.add_argument("--endpoint", help="Upload endpoint URL")
    upload_parser.add_argument("--dry-run", action="store_true", help="Dry run mode")

    parser.set_defaults(func=run)
    return parser


def run(args):
    """
    Entrypoint for argparse-based CLI invocation.
    Routes to appropriate Click handler based on telemetry_command.
    """
    import sys

    # Reconstruct sys.argv for Click to parse
    original_argv = sys.argv
    try:
        # Get the telemetry subcommand (export, stats, config, upload, etc.)
        subcmd = getattr(args, "telemetry_command", None)

        if not subcmd:
            # No subcommand provided, show telemetry help
            telemetry_group(["--help"], standalone_mode=False)
            return 0

        # Build new argv for Click to parse
        # Click expects: [script_name, subcommand, ...options]
        new_argv = [sys.argv[0], subcmd]

        # Mapping from argparse dest name to Click option name
        # This handles cases where --from → from_time, etc.
        option_mapping = {
            "from_time": "--from",
            "to_time": "--to",
            "dry_run": "--dry-run",
            "policy_only": "--policy-only",
            "event_type": "--event-type",
            "governance_id": "--governance-id",
        }

        # Add all the arguments from argparse back into sys.argv
        for action in args.__dict__:
            value = getattr(args, action, None)

            # Skip the telemetry_command and func fields
            if action in ("telemetry_command", "func", "project", "command"):
                continue

            if value is None or value is False:
                continue

            # Use mapping if available, otherwise convert underscores to dashes
            if action in option_mapping:
                flag_name = option_mapping[action]
            else:
                flag_name = "--" + action.replace("_", "-")

            if isinstance(value, bool):
                if value:
                    new_argv.append(flag_name)
            elif isinstance(value, (list, tuple)):
                for v in value:
                    new_argv.append(flag_name)
                    new_argv.append(str(v))
            else:
                new_argv.append(flag_name)
                new_argv.append(str(value))

        sys.argv = new_argv
        # Call telemetry_group, which is a Click group, with the constructed argv
        telemetry_group(standalone_mode=False)
        return 0
    except SystemExit as e:
        return int(e.code) if e.code else 0
    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        import traceback

        traceback.print_exc()
        return 1
    finally:
        sys.argv = original_argv
