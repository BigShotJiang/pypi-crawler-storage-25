"""
BranchPy Server CLI Commands
=============================

Manage the BranchPy background server daemon.

Commands:
  branchpy server start   - Start server in background
  branchpy server stop    - Stop server gracefully
  branchpy server status  - Check server status
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional


def _get_project_root(project_arg: Optional[str] = None) -> Path:
    """Get project root from argument or environment."""
    import os

    if project_arg:
        return Path(project_arg).resolve()

    # Check environment variable
    env_project = os.environ.get("BRANCHPY_PROJECT")
    if env_project:
        return Path(env_project).resolve()

    # Default to current directory
    return Path.cwd().resolve()


def cmd_start(args: argparse.Namespace) -> int:
    """Start the BranchPy server daemon."""
    # Get project from args or use default
    project_arg = getattr(args, "project", None)
    project_root = _get_project_root(project_arg)

    # Import the daemon starter
    # (Using absolute import to avoid path issues)
    try:
        # Add BranchPyApp root to path if needed
        app_root = Path(__file__).parent.parent.parent
        if str(app_root) not in sys.path:
            sys.path.insert(0, str(app_root))

        from start_server_daemon import start_server_daemon

        result = start_server_daemon(project_root)

        if result["ok"]:
            return 0
        else:
            print(
                f"[Error] Failed to start server: {result.get('reason', 'unknown')}",
                file=sys.stderr,
            )
            return 1

    except ImportError as e:
        print(f"[Error] Could not import daemon starter: {e}", file=sys.stderr)
        print(
            "[Error] Make sure you're running from BranchPyApp directory",
            file=sys.stderr,
        )
        return 1

    except Exception as e:
        print(f"[Error] Unexpected error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


def cmd_stop(args: argparse.Namespace) -> int:
    """Stop the BranchPy server daemon."""
    project_arg = getattr(args, "project", None)
    project_root = _get_project_root(project_arg)

    try:
        # Add BranchPyApp root to path if needed
        app_root = Path(__file__).parent.parent.parent
        if str(app_root) not in sys.path:
            sys.path.insert(0, str(app_root))

        from stop_server_daemon import stop_server_daemon

        result = stop_server_daemon(project_root)

        if result["ok"]:
            return 0
        else:
            # Not running is not an error if force flag is set
            if args.force and result.get("reason") in ("not_running", "stale_pid"):
                print("[Server] No running server to stop")
                return 0

            print(
                f"[Error] Failed to stop server: {result.get('reason', 'unknown')}",
                file=sys.stderr,
            )
            return 1

    except ImportError as e:
        print(f"[Error] Could not import daemon stopper: {e}", file=sys.stderr)
        return 1

    except Exception as e:
        print(f"[Error] Unexpected error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


def cmd_status(args: argparse.Namespace) -> int:
    """Check the BranchPy server daemon status."""
    project_arg = getattr(args, "project", None)
    project_root = _get_project_root(project_arg)

    runtime_dir = project_root / ".branchpy" / "runtime"
    pid_file = runtime_dir / "server.pid"
    port_file = runtime_dir / "server.port"

    if not pid_file.exists():
        print("Status: Not running (no PID file)")
        return 1

    try:
        import psutil

        pid = int(pid_file.read_text().strip())

        if not psutil.pid_exists(pid):
            print(f"Status: Not running (PID {pid} doesn't exist)")
            print(
                "Hint: Stale PID file found. Use 'branchpy server stop --force' to clean up"
            )
            return 1

        proc = psutil.Process(pid)

        # Read port
        port = None
        if port_file.exists():
            try:
                port = int(port_file.read_text().strip())
            except Exception:
                pass

        # Check if port is listening
        port_status = "unknown"
        if port:
            import socket

            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            try:
                result = sock.connect_ex(("127.0.0.1", port))
                sock.close()
                port_status = "listening" if result == 0 else "not responding"
            except Exception:
                port_status = "error"

        # Get process info
        try:
            cpu_percent = proc.cpu_percent(interval=0.1)
            mem_info = proc.memory_info()
            mem_mb = mem_info.rss / 1024 / 1024

            # Calculate uptime
            import time

            create_time = proc.create_time()
            uptime_seconds = int(time.time() - create_time)
            uptime_str = f"{uptime_seconds // 3600}h {(uptime_seconds % 3600) // 60}m {uptime_seconds % 60}s"

            print("Status: Running ✓")
            print(f"  PID:     {pid}")
            if port:
                print(f"  Port:    {port} ({port_status})")
                print(f"  URL:     http://127.0.0.1:{port}")
            print(f"  Uptime:  {uptime_str}")
            print(f"  CPU:     {cpu_percent:.1f}%")
            print(f"  Memory:  {mem_mb:.1f} MB")
            print(f"  Project: {project_root}")

            return 0

        except Exception as e:
            print(f"Status: Running (PID: {pid}) but could not get details: {e}")
            return 0

    except ImportError:
        print("Error: psutil not installed. Install with: pip install psutil")
        return 1

    except Exception as e:
        print(f"Error checking status: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_restart(args: argparse.Namespace) -> int:
    """Restart the BranchPy server daemon."""
    print("[Server] Restarting server...")

    # Stop first
    print("[Server] Stopping existing server...")
    args.force = True  # Force stop even if not running
    stop_result = cmd_stop(args)

    # Wait a moment
    import time

    time.sleep(1)

    # Start
    print("[Server] Starting new server...")
    return cmd_start(args)


def main(argv=None) -> int:
    """Main entry point for server commands."""
    parser = argparse.ArgumentParser(
        prog="branchpy server", description="Manage BranchPy background server daemon"
    )

    subparsers = parser.add_subparsers(dest="command", help="Server command")

    # start command
    start_parser = subparsers.add_parser("start", help="Start server in background")
    start_parser.add_argument(
        "--project",
        type=str,
        default=None,
        help="Project root directory (default: current directory)",
    )

    # stop command
    stop_parser = subparsers.add_parser("stop", help="Stop server gracefully")
    stop_parser.add_argument(
        "--project",
        type=str,
        default=None,
        help="Project root directory (default: current directory)",
    )
    stop_parser.add_argument(
        "--force", action="store_true", help="Force cleanup even if server not running"
    )

    # status command
    status_parser = subparsers.add_parser("status", help="Check server status")
    status_parser.add_argument(
        "--project",
        type=str,
        default=None,
        help="Project root directory (default: current directory)",
    )

    # restart command
    restart_parser = subparsers.add_parser("restart", help="Restart server")
    restart_parser.add_argument(
        "--project",
        type=str,
        default=None,
        help="Project root directory (default: current directory)",
    )

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 1

    # Dispatch to command handler
    if args.command == "start":
        return cmd_start(args)
    elif args.command == "stop":
        return cmd_stop(args)
    elif args.command == "status":
        return cmd_status(args)
    elif args.command == "restart":
        return cmd_restart(args)
    else:
        print(f"Unknown command: {args.command}", file=sys.stderr)
        return 1


def add_parser(subparsers):
    """Add server parser to main CLI (compatibility with BranchPy CLI pattern)."""
    server_parser = subparsers.add_parser(
        "server",
        help="Manage background server daemon (start/stop/status)",
        description="Control the BranchPy background server daemon",
    )

    # Create subparsers for server subcommands
    server_subparsers = server_parser.add_subparsers(
        dest="server_command", help="Server action"
    )

    # start
    start_p = server_subparsers.add_parser("start", help="Start server in background")
    start_p.add_argument(
        "--project", type=str, default=".", help="Project root directory"
    )
    start_p.set_defaults(server_handler=cmd_start)

    # stop
    stop_p = server_subparsers.add_parser("stop", help="Stop server gracefully")
    stop_p.add_argument(
        "--project", type=str, default=".", help="Project root directory"
    )
    stop_p.add_argument("--force", action="store_true", help="Force cleanup")
    stop_p.set_defaults(server_handler=cmd_stop)

    # status
    status_p = server_subparsers.add_parser("status", help="Check server status")
    status_p.add_argument(
        "--project", type=str, default=".", help="Project root directory"
    )
    status_p.set_defaults(server_handler=cmd_status)

    # restart
    restart_p = server_subparsers.add_parser("restart", help="Restart server")
    restart_p.add_argument(
        "--project", type=str, default=".", help="Project root directory"
    )
    restart_p.set_defaults(server_handler=cmd_restart)

    # Set main handler
    def run_server_command(args):
        if hasattr(args, "server_handler"):
            return args.server_handler(args)
        else:
            server_parser.print_help()
            return 1

    server_parser.set_defaults(handler=run_server_command)
    return server_parser


if __name__ == "__main__":
    sys.exit(main())
