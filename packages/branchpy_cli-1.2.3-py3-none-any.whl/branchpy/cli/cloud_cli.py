from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from branchpy.cloud.mock_env import (
    CloudAccount,
    CloudProject,
    get_project_rem_status,
    list_projects,
    release_project,
    reserve_project,
    snapshot_project_config,
)
from branchpy.core.governance.logger import GovernanceLogger


def add_cloud_subparser(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    cloud_parser = subparsers.add_parser(
        "cloud",
        help="BranchPy Cloud (local mock environment).",
    )
    cloud_sub = cloud_parser.add_subparsers(dest="cloud_cmd", required=True)

    cloud_sub.add_parser("status", help="Show Cloud mock status for this project.")

    list_cmd = cloud_sub.add_parser("list", help="List all cloud-synced projects.")
    list_cmd.add_argument("--json", action="store_true", help="Output JSON format.")

    sync = cloud_sub.add_parser(
        "sync", help="Sync project metadata to local Cloud mock."
    )
    sync.add_argument(
        "--path", default=".", help="Project root (defaults to current directory)."
    )
    sync.add_argument(
        "--config", default=".branchpy.toml", help="Path to .branchpy.toml."
    )

    rem_reserve = cloud_sub.add_parser(
        "rem-reserve", help="Reserve project for editing (REM)."
    )
    rem_reserve.add_argument("--path", default=".", help="Project root.")
    rem_reserve.add_argument(
        "--actor", default=None, help="Actor name to record in lock."
    )

    rem_release = cloud_sub.add_parser(
        "rem-release", help="Release project edit reservation."
    )
    rem_release.add_argument("--path", default=".", help="Project root.")

    cloud_parser.set_defaults(func=handle_cloud_command)


def handle_cloud_command(args: argparse.Namespace) -> int:
    acct = CloudAccount.load_or_init()
    root = Path(getattr(args, "path", ".")).resolve()
    project = CloudProject.from_local_path(root)

    # Corrected logger instantiation
    logger = GovernanceLogger()

    if args.cloud_cmd == "status":
        return _handle_status(acct, project)
    if args.cloud_cmd == "list":
        return _handle_list(acct, args)
    if args.cloud_cmd == "sync":
        return _handle_sync(acct, project, args, logger)
    if args.cloud_cmd == "rem-reserve":
        return _handle_rem_reserve(acct, project, args, logger)
    if args.cloud_cmd == "rem-release":
        return _handle_rem_release(acct, project, logger)

    print("Unknown cloud command", file=sys.stderr)
    return 1


def _handle_status(acct: CloudAccount, project: CloudProject) -> int:
    project.ensure_dirs()
    print("BranchPy Cloud (Local Mock)")
    print(f"  Account: {acct.display_name} ({acct.account_id})")
    print(f"  Project: {project.name} ({project.project_id})")
    print(f"  Local path: {project.local_path}")
    # Optionally show REM status
    lock_path = project.project_root / "state" / "rem_lock.json"
    if lock_path.exists():
        data = json.loads(lock_path.read_text(encoding="utf-8"))
        print(
            f"  REM: RESERVED by {data.get('actor', 'unknown')} at {data.get('reserved_at')}"
        )
    else:
        print("  REM: free")
    return 0


def _handle_list(acct: CloudAccount, args: argparse.Namespace) -> int:
    projects = list_projects()

    if args.json:
        # JSON output for machine consumption
        output = {
            "account_id": acct.account_id,
            "display_name": acct.display_name,
            "projects": [],
        }

        for proj in projects:
            rem_status = get_project_rem_status(proj)
            output["projects"].append(
                {
                    "project_id": proj.project_id,
                    "name": proj.name,
                    "local_path": proj.local_path,
                    "rem_status": rem_status["status"],
                    "rem_actor": rem_status.get("actor"),
                    "rem_reserved_at": rem_status.get("reserved_at"),
                }
            )

        print(json.dumps(output, indent=2))
    else:
        # Human-readable output
        print("BranchPy Cloud (Local Mock)")
        print(f"Account: {acct.display_name} ({acct.account_id})")
        print()

        if not projects:
            print("No projects found. Use 'branchpy cloud sync' to add a project.")
            return 0

        print(f"Projects ({len(projects)}):")
        print()

        for proj in projects:
            rem_status = get_project_rem_status(proj)
            rem_indicator = ""
            if rem_status["status"] == "reserved":
                rem_indicator = f" [RESERVED by {rem_status.get('actor', 'unknown')}]"

            print(f"  • {proj.name}{rem_indicator}")
            print(f"    ID: {proj.project_id}")
            print(f"    Path: {proj.local_path}")
            print()

    return 0


def _handle_sync(
    acct: CloudAccount,
    project: CloudProject,
    args: argparse.Namespace,
    logger: GovernanceLogger,
) -> int:
    config_path = Path(args.config).resolve()
    logger.log_event(
        {
            "event_type": "CLOUD_SYNC_START",
            "context": {
                "project_id": project.project_id,
                "local_path": project.local_path,
                "config_path": str(config_path),
            },
        }
    )
    snap_path = snapshot_project_config(project, config_path)
    logger.log_event(
        {
            "event_type": "CLOUD_SYNC_END",
            "context": {
                "project_id": project.project_id,
                "snapshot_path": str(snap_path),
            },
        }
    )
    print(f"Synced project to local Cloud mock at {project.project_root}")
    return 0


def _handle_rem_reserve(
    acct: CloudAccount,
    project: CloudProject,
    args: argparse.Namespace,
    logger: GovernanceLogger,
) -> int:
    actor = args.actor or acct.display_name
    logger.log_event(
        {
            "event_type": "REM_RESERVE",
            "context": {
                "project_id": project.project_id,
                "local_path": project.local_path,
                "actor": actor,
            },
        }
    )
    reserve_project(project, actor=actor)
    print(f"Reserved project for {actor}.")
    return 0


def _handle_rem_release(
    acct: CloudAccount, project: CloudProject, logger: GovernanceLogger
) -> int:
    logger.log_event(
        {
            "event_type": "REM_RELEASE",
            "context": {
                "project_id": project.project_id,
                "local_path": project.local_path,
            },
        }
    )
    release_project(project)
    print("Released project reservation.")
    return 0
