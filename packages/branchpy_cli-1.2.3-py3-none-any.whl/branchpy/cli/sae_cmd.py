import argparse
import json
import sys
from pathlib import Path

import yaml


def register_sae(sub: argparse._SubParsersAction):
    p = sub.add_parser("sae", help="Symbolic Analysis Engine")
    sp = p.add_subparsers(dest="sae_cmd")
    runp = sp.add_parser("run", help="Run symbolic pass")
    runp.add_argument("-p", "--project", default=".")
    runp.add_argument("--mode", choices=["numeric", "symbolic", "both"], default="both")
    exp = sp.add_parser("export", help="Export unified report")
    exp.add_argument("-p", "--project", default=".")
    exp.add_argument("-o", "--out", default=".branchpy/reports/unified_semantics.json")
    exp.add_argument(
        "--stats2", default=".branchpy/stats2/latest.json", help="Path to Stats2 JSON"
    )
    exp.add_argument(
        "--internal",
        action="store_true",
        # SOP §3.3 — unified SAE+Stats2 export is Class C. Not in public help.
        help=argparse.SUPPRESS,
    )


def load_semantics(project_root: Path) -> dict:
    """Load and parse semantics.yaml."""
    sem_file = project_root / ".branchpy" / "semantics.yaml"
    if not sem_file.exists():
        return {}

    data = yaml.safe_load(sem_file.read_text(encoding="utf-8"))
    # Convert to index: {function_name: entry_dict}
    entries = data.get("entries", [])
    return {e["name"]: e for e in entries}


def main_sae(args):
    """
    Entry point for SAE subcommands.

    Commands:
      - run: Execute symbolic analysis (mode: numeric/symbolic/both)
      - export: Merge Stats2 + SAE → unified JSON report
    """
    project_root = Path(args.project).resolve()

    if args.sae_cmd == "run":
        try:
            from branchpy.pilot.adapters import (
                DualEvaluator,
                NumericEvaluator,
                SymbolicEvaluator,
            )

            print(f"[SAE] Running analysis on: {project_root}")
            print(f"[SAE] Mode: {args.mode}")

            # Load semantics
            semantics_index = load_semantics(project_root)
            print(f"[SAE] Loaded {len(semantics_index)} semantics entries")

            # Select evaluator
            if args.mode == "numeric":
                evaluator = NumericEvaluator()
            elif args.mode == "symbolic":
                evaluator = SymbolicEvaluator(semantics_index)
            else:  # both
                evaluator = DualEvaluator(semantics_index)

            # NOTE: Actual CFG traversal requires pilot graph integration
            # This stub demonstrates the evaluator selection pattern
            print(f"[SAE] Evaluator ready: {type(evaluator).__name__}")
            print("[SAE] Integration checkpoint:")
            print("  -> Wire to pilot CFG traversal (traverse_cfg(cfg, evaluator))")
            print("  -> Call run_symbolic() for fixpoint computation")

            result = evaluator.result()
            print(
                f"[SAE] Run complete. Labels analyzed: {len(getattr(result, 'labels', []))}"
            )
        except Exception as e:
            # Avoid Unicode in error messages on Windows cp1252
            msg = str(e).encode("ascii", "replace").decode("ascii")
            print(f"[SAE] Error: {msg}")
            raise

    elif args.sae_cmd == "export":
        # SOP §3.3 — unified SAE+Stats2 report is a Class C engine artifact.
        if not getattr(args, "internal", False):
            print(
                "[SAE] ERROR: `sae export` produces a Class C engine artifact (full unified SAE report).\n"
                "  Add --internal to confirm this is an internal / development use.",
                file=sys.stderr,
            )
            return
        try:
            from branchpy.sae.report import export_unified

            print(f"[SAE] Exporting unified report to: {args.out}")

            # Load Stats2
            stats2_path = Path(args.stats2)
            if not stats2_path.exists():
                print(f"[SAE] Error: Stats2 file not found: {stats2_path}")
                print("[SAE] Run pilot rebuild first to generate Stats2 data")
                return

            stats2_json = json.loads(stats2_path.read_text(encoding="utf-8"))
            print(f"[SAE] Loaded Stats2: {len(stats2_json.get('labels', []))} labels")

            # Load semantics
            semantics_index = load_semantics(project_root)
            print(f"[SAE] Loaded semantics: {len(semantics_index)} entries")

            # NOTE: Requires CFG from pilot
            # For stub: create minimal SymResult
            from branchpy.sae.interpreter import SymResult

            sym = SymResult()
            print("[SAE] Symbolic analysis placeholder (awaiting CFG integration)")

            # Export
            export_unified(
                project=project_root.name,
                stats2_json=stats2_json,
                sym=sym,
                out_path=Path(args.out),
            )
            print(f"[SAE] Unified report written: {args.out}")
        except Exception as e:
            # Avoid Unicode in error messages on Windows cp1252
            msg = str(e).encode("ascii", "replace").decode("ascii")
            print(f"[SAE] Error: {msg}")
            raise

    else:
        print("[SAE] Unknown command. Use: run | export")
