"""CLI commands for semantic rule versioning management.

Commands:
- list-versions: Show all rule versions
- show-deprecated: List deprecated rules
- check-compatibility: Check version compatibility
- validate: Validate rule set for conflicts
- migrate: Show migration path between versions
- export-yaml: Export registry to YAML

Part of Semantics V2 Phase 5 Step 6
"""

import sys
from datetime import date, timedelta
from pathlib import Path
from typing import Optional

import click  # type: ignore
from tabulate import tabulate  # type: ignore

from branchpy.semantics.propagation.rule_versioning import load_registry


@click.group(name="rule-versions")  # type: ignore
def rule_versions_cli():
    """Manage semantic rule versions and migrations."""
    pass


@rule_versions_cli.command(name="list-versions")  # type: ignore
@click.option("--registry", "-r", type=click.Path(exists=True), help="Path to registry YAML file")  # type: ignore
@click.option("--rule-id", help="Filter by specific rule ID")  # type: ignore
@click.option("--include-deprecated", is_flag=True, help="Include deprecated versions")  # type: ignore
def list_versions(
    registry: Optional[str], rule_id: Optional[str], include_deprecated: bool
):
    """List all rule versions with status.

    Examples:
        branchpy semantics2 rule-versions list-versions
        branchpy semantics2 rule-versions list-versions --rule-id N001
        branchpy semantics2 rule-versions list-versions --include-deprecated
    """
    # Load registry
    if registry:
        reg = load_registry(Path(registry))
    else:
        # Try to find default registry
        default_path = Path("branchpy/semantics/propagation/rule_registry.yaml")
        if default_path.exists():
            reg = load_registry(default_path)
        else:
            click.echo("No registry found. Use --registry to specify path.", err=True)
            sys.exit(1)

    # Filter by rule_id if specified
    if rule_id:
        versions = reg.get_all_versions(rule_id)
        if not versions:
            click.echo(f"No versions found for rule {rule_id}", err=True)
            sys.exit(1)
        rules_to_show = {rule_id: versions}
    else:
        rules_to_show = reg.versions

    # Build table
    table_data = []
    for rid, versions in rules_to_show.items():
        for version in versions:
            if not include_deprecated and version.is_deprecated():
                continue

            # Determine status
            if version.is_sunset():
                status = click.style("SUNSET", fg="red", bold=True)
            elif version.is_deprecated():
                status = click.style("DEPRECATED", fg="yellow")
            else:
                status = click.style("ACTIVE", fg="green")

            # Format dates
            effective = version.effective_date
            deprecated = version.deprecated_date or "-"
            sunset = version.sunset_date or "-"

            table_data.append(
                [rid, version.version, status, effective, deprecated, sunset]
            )

    if not table_data:
        click.echo("No versions found matching criteria.")
        return

    # Print table
    headers = ["Rule ID", "Version", "Status", "Effective Date", "Deprecated", "Sunset"]
    click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    click.echo(f"\nTotal: {len(table_data)} version(s)")


@rule_versions_cli.command(name="show-deprecated")
@click.option(
    "--registry", "-r", type=click.Path(exists=True), help="Path to registry YAML file"
)
@click.option(
    "--warn-days",
    type=int,
    default=30,
    help="Warn about rules sunsetting within N days",
)
def show_deprecated(registry: Optional[str], warn_days: int):
    """Show all deprecated rules with sunset warnings.

    Examples:
        branchpy semantics2 rule-versions show-deprecated
        branchpy semantics2 rule-versions show-deprecated --warn-days 60
    """
    # Load registry
    if registry:
        reg = load_registry(Path(registry))
    else:
        default_path = Path("branchpy/semantics/propagation/rule_registry.yaml")
        if default_path.exists():
            reg = load_registry(default_path)
        else:
            click.echo("No registry found. Use --registry to specify path.", err=True)
            sys.exit(1)

    # Get deprecated rules
    deprecated = reg.list_deprecated_rules()

    if not deprecated:
        click.echo(click.style("✓ No deprecated rules found.", fg="green"))
        return

    # Build table with warnings
    table_data = []
    today = date.today()
    warn_threshold = today + timedelta(days=warn_days)

    for rule_id, version in deprecated:
        # Check sunset status
        warning = ""
        if version.sunset_date:
            sunset_date = date.fromisoformat(version.sunset_date)
            days_until = (sunset_date - today).days

            if days_until < 0:
                warning = click.style("⚠ SUNSET PASSED", fg="red", bold=True)
            elif days_until <= warn_days:
                warning = click.style(
                    f"⚠ {days_until} days until sunset", fg="yellow", bold=True
                )

        deprecated_date = version.deprecated_date or "-"
        sunset_date = version.sunset_date or "-"

        table_data.append(
            [rule_id, version.version, deprecated_date, sunset_date, warning]
        )

    # Print table
    headers = ["Rule ID", "Version", "Deprecated Date", "Sunset Date", "Warning"]
    click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    click.echo(
        f"\n{click.style('⚠', fg='yellow')} Total deprecated rules: {len(deprecated)}"
    )

    # Show migration guide if available
    for rule_id, version in deprecated:
        if version.migration_guide:
            click.echo(f"\nMigration guide for {rule_id}: {version.migration_guide}")


@rule_versions_cli.command(name="check-compatibility")
@click.option(
    "--registry", "-r", type=click.Path(exists=True), help="Path to registry YAML file"
)
@click.option("--from-version", required=True, help="Source version")
@click.option("--to-version", required=True, help="Target version")
@click.option("--rule-id", required=True, help="Rule ID to check")
def check_compatibility(
    registry: Optional[str], from_version: str, to_version: str, rule_id: str
):
    """Check if migration path exists between versions.

    Examples:
        branchpy semantics2 rule-versions check-compatibility --rule-id N001 --from-version 1.0.0 --to-version 2.0.0
    """
    # Load registry
    if registry:
        reg = load_registry(Path(registry))
    else:
        default_path = Path("branchpy/semantics/propagation/rule_registry.yaml")
        if default_path.exists():
            reg = load_registry(default_path)
        else:
            click.echo("No registry found. Use --registry to specify path.", err=True)
            sys.exit(1)

    # Check if versions exist
    from_ver = reg.get_version(rule_id, from_version)
    to_ver = reg.get_version(rule_id, to_version)

    if not from_ver:
        click.echo(f"Version {from_version} not found for rule {rule_id}", err=True)
        sys.exit(1)
    if not to_ver:
        click.echo(f"Version {to_version} not found for rule {rule_id}", err=True)
        sys.exit(1)

    # Find migration path
    chain = reg.find_migration_chain(rule_id, from_version, to_version)

    if not chain:
        click.echo(click.style("✗ No migration path available", fg="red"))
        click.echo(f"Cannot migrate {rule_id} from {from_version} to {to_version}")
        sys.exit(1)

    click.echo(click.style("✓ Migration path found", fg="green"))
    click.echo(f"\nMigration steps for {rule_id}: {from_version} → {to_version}\n")

    # Show migration chain
    for i, migration in enumerate(chain, 1):
        click.echo(f"Step {i}: {migration.from_version} → {migration.to_version}")
        click.echo(f"  Strategy: {migration.strategy.value}")
        click.echo(f"  Automated: {migration.automated}")

        if migration.steps:
            click.echo("  Steps:")
            for step in migration.steps:
                click.echo(f"    - {step}")
        click.echo()

    # Check if fully automated
    all_automated = all(m.automated for m in chain)
    if all_automated:
        click.echo(click.style("✓ Migration can be fully automated", fg="green"))
    else:
        click.echo(click.style("⚠ Manual intervention required", fg="yellow"))


@rule_versions_cli.command(name="validate")
@click.option(
    "--registry", "-r", type=click.Path(exists=True), help="Path to registry YAML file"
)
@click.argument("rule_file", type=click.Path(exists=True))
def validate_rules(registry: Optional[str], rule_file: str):
    """Validate rule set for conflicts and deprecations.

    Examples:
        branchpy semantics2 rule-versions validate rules.yaml
        branchpy semantics2 rule-versions validate --registry custom.yaml rules.yaml
    """
    # Load registry
    if registry:
        reg = load_registry(Path(registry))
    else:
        default_path = Path("branchpy/semantics/propagation/rule_registry.yaml")
        if default_path.exists():
            reg = load_registry(default_path)
        else:
            click.echo("No registry found. Use --registry to specify path.", err=True)
            sys.exit(1)

    # Load rules from file
    import yaml

    with open(rule_file, "r") as f:
        rules_data = yaml.safe_load(f)

    # Convert to rule objects (simplified - in production would use actual Rule classes)
    from dataclasses import dataclass

    @dataclass
    class SimpleRule:
        id: str
        name: str
        enabled: bool = True

    rules = [
        SimpleRule(id=r.get("id", "unknown"), name=r.get("name", "unknown"))
        for r in rules_data.get("rules", [])
    ]

    if not rules:
        click.echo("No rules found in file", err=True)
        sys.exit(1)

    # Validate
    click.echo(f"Validating {len(rules)} rule(s)...\n")
    result = reg.validate_with_conflict_detection(rules)

    # Show results
    if result.is_valid:
        click.echo(click.style("✓ Validation passed", fg="green"))
    else:
        click.echo(click.style("✗ Validation failed", fg="red"))

    # Show conflicts
    if hasattr(result, "conflicts") and result.conflicts:
        click.echo(f"\n{click.style('Conflicts:', fg='red', bold=True)}")
        for conflict in result.conflicts:
            severity_color = (
                "red" if str(conflict.severity.value) == "blocking" else "yellow"
            )
            click.echo(
                f"  [{click.style(conflict.severity.value.upper(), fg=severity_color)}] "
                f"{conflict.rule1_id} ↔ {conflict.rule2_id}: {conflict.conflict_type.value}"
            )
            click.echo(f"    {conflict.description}")
            if conflict.resolution_suggestion:
                click.echo(f"    → {conflict.resolution_suggestion}")

    # Show warnings
    if result.warnings:
        click.echo(f"\n{click.style('Warnings:', fg='yellow', bold=True)}")
        for warning in result.warnings:
            click.echo(f"  ⚠ {warning}")

    # Exit with appropriate code
    sys.exit(0 if result.is_valid else 1)


@rule_versions_cli.command(name="migrate")
@click.option(
    "--registry", "-r", type=click.Path(exists=True), help="Path to registry YAML file"
)
@click.option("--rule-id", required=True, help="Rule ID to migrate")
@click.option("--from-version", required=True, help="Current version")
@click.option("--to-version", required=True, help="Target version")
@click.option("--show-steps", is_flag=True, help="Show detailed migration steps")
def migrate(
    registry: Optional[str],
    rule_id: str,
    from_version: str,
    to_version: str,
    show_steps: bool,
):
    """Show migration path and steps between versions.

    Examples:
        branchpy semantics2 rule-versions migrate --rule-id N001 --from-version 1.0.0 --to-version 3.0.0
        branchpy semantics2 rule-versions migrate --rule-id N001 --from-version 1.0.0 --to-version 3.0.0 --show-steps
    """
    # Load registry
    if registry:
        reg = load_registry(Path(registry))
    else:
        default_path = Path("branchpy/semantics/propagation/rule_registry.yaml")
        if default_path.exists():
            reg = load_registry(default_path)
        else:
            click.echo("No registry found. Use --registry to specify path.", err=True)
            sys.exit(1)

    # Find migration chain
    chain = reg.find_migration_chain(rule_id, from_version, to_version)

    if not chain:
        click.echo(click.style("✗ No migration path found", fg="red"))
        sys.exit(1)

    # Show migration path
    click.echo(click.style(f"Migration path for {rule_id}:", fg="cyan", bold=True))
    click.echo(f"{from_version} → {to_version}\n")

    # Show each step
    for i, migration in enumerate(chain, 1):
        click.echo(
            f"{click.style(f'Step {i}:', fg='cyan')} {migration.from_version} → {migration.to_version}"
        )
        click.echo(f"  Strategy: {click.style(migration.strategy.value, fg='yellow')}")
        click.echo(
            f"  Automated: {click.style('Yes' if migration.automated else 'No', fg='green' if migration.automated else 'red')}"
        )

        if show_steps and migration.steps:
            click.echo(f"  {click.style('Steps:', fg='cyan')}")
            for step in migration.steps:
                click.echo(f"    • {step}")

        if migration.validation_rules:
            click.echo(f"  Validation: {', '.join(migration.validation_rules)}")

        click.echo()

    # Summary
    total_steps = len(chain)
    automated_steps = sum(1 for m in chain if m.automated)

    click.echo("Summary:")
    click.echo(f"  Total migration steps: {total_steps}")
    click.echo(f"  Automated steps: {automated_steps}/{total_steps}")

    if automated_steps == total_steps:
        click.echo(click.style("  ✓ Fully automated migration available", fg="green"))
    elif automated_steps > 0:
        click.echo(
            click.style(
                f"  ⚠ Partial automation ({automated_steps}/{total_steps} steps)",
                fg="yellow",
            )
        )
    else:
        click.echo(click.style("  ⚠ Manual migration required", fg="red"))


@rule_versions_cli.command(name="export-yaml")
@click.option(
    "--registry", "-r", type=click.Path(exists=True), help="Path to registry YAML file"
)
@click.argument("output", type=click.Path())
def export_yaml(registry: Optional[str], output: str):
    """Export registry to YAML file.

    Examples:
        branchpy semantics2 rule-versions export-yaml output.yaml
    """
    # Load registry
    if registry:
        reg = load_registry(Path(registry))
    else:
        default_path = Path("branchpy/semantics/propagation/rule_registry.yaml")
        if default_path.exists():
            reg = load_registry(default_path)
        else:
            click.echo("No registry found. Use --registry to specify path.", err=True)
            sys.exit(1)

    # Export
    output_path = Path(output)
    reg.save_to_yaml(output_path)

    click.echo(click.style(f"✓ Registry exported to {output}", fg="green"))

    # Show stats
    total_versions = sum(len(versions) for versions in reg.versions.values())
    total_migrations = len(reg.migration_paths)
    click.echo(f"  Rules: {len(reg.versions)}")
    click.echo(f"  Versions: {total_versions}")
    click.echo(f"  Migration paths: {total_migrations}")


if __name__ == "__main__":
    rule_versions_cli()
