"""
BranchPy Merge Command (v0.9.1.5)

Safe branch merging with reversible patches, journal integration, and timeline events.

Usage:
    branchpy merge --from main --to feature [--dry-run] [--force] [--verbose]
    branchpy merge --from v0.9.1.4 --to feature/new-feature --apply
"""

import sys
from pathlib import Path
from typing import Any, Dict, Optional

import click

from ...analyzer.merge_risk_analyzer import MergeRiskConfig, SimpleMergeRiskAnalyzer
from ...merge.merge_engine import MergeResult, SafeMergeEngine

try:
    from ...telemetry.event_emitter import emit_event as _emit_event

    def emit_event(event_type: str, properties: Dict[str, Any]) -> None:
        """Wrapper to match merge_cmd signature"""
        _emit_event({**properties, "event_type": event_type})

except ImportError:
    # Fallback if telemetry not available
    def emit_event(event_type: str, properties: Dict[str, Any]) -> None:
        pass


@click.command("merge")
@click.option(
    "--from",
    "from_ref",
    required=True,
    help="Source ref (branch, tag, or commit) to merge from",
)
@click.option(
    "--to",
    "to_ref",
    required=True,
    help="Target ref (branch, tag, or commit) to merge to",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview merge without applying changes",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Force merge even with uncommitted changes (dangerous)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show detailed merge information",
)
@click.option(
    "--project",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project root directory (defaults to current directory)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Output machine-readable JSON (for automation/VS Code)",
)
@click.option(
    "--merge-narrative",
    is_flag=True,
    default=False,
    help="Analyze narrative impact of script changes (WS-M2)",
)
@click.option(
    "--merge-flow",
    is_flag=True,
    default=False,
    help="Compute flow delta between branches (WS-M3)",
)
@click.option(
    "--merge-depth",
    type=int,
    default=3,
    help="Maximum depth for flow analysis (default: 3)",
)
def merge(
    from_ref: str,
    to_ref: str,
    dry_run: bool,
    force: bool,
    verbose: bool,
    project: Optional[Path],
    as_json: bool,
    merge_narrative: bool,
    merge_flow: bool,
    merge_depth: int,
) -> None:
    """
    Safely merge changes between git refs with reversible patches.

    This command:
    - Validates refs and repository state
    - Computes reversible patches between from_ref and to_ref
    - Applies patches and records in journal (unless --dry-run)
    - Emits timeline/telemetry events
    - Provides structured JSON output for automation

    Examples:
        # Preview merge from main to current branch
        branchpy merge --from main --to HEAD --dry-run

        # Apply merge and record in journal
        branchpy merge --from main --to feature/v0.9.1.5 --apply

        # Force merge even with uncommitted changes
        branchpy merge --from main --to feature --force
    """
    project_root = project or Path.cwd()

    # Initialize analyzer
    analyzer = SimpleMergeRiskAnalyzer(
        config=MergeRiskConfig(
            project_root=project_root,
            flow_depth=merge_depth,
            enable_narrative_impact=merge_narrative,
            enable_flow_delta=merge_flow,
        )
    )

    # Initialize engine with telemetry callback
    def telemetry_callback(event: dict) -> None:
        """Wrapper to emit telemetry events"""
        try:
            emit_event(
                event_type=event["event_type"],
                properties=event,
            )
        except Exception as exc:
            if verbose:
                click.echo(f"Warning: Failed to emit telemetry: {exc}", err=True)

    engine = SafeMergeEngine(
        project_root=project_root,
        analyzer=analyzer,
        emit_event=telemetry_callback,
    )

    # Execute merge
    try:
        result: MergeResult = engine.merge(
            from_ref=from_ref,
            to_ref=to_ref,
            dry_run=dry_run,
            force=force,
        )
    except RuntimeError as exc:
        click.echo(f"❌ Merge failed: {exc}", err=True)
        emit_event(
            event_type="merge.operation.failed",
            properties={
                "from_ref": from_ref,
                "to_ref": to_ref,
                "project_root": str(project_root),
                "error": str(exc),
            },
        )
        sys.exit(1)

    # Display results
    if as_json:
        click.echo(result.to_json())
    elif verbose:
        click.echo(result.to_json())
    else:
        _print_summary(result)

    # Exit with appropriate status
    if result.conflicts:
        sys.exit(1)
    elif result.warnings:
        sys.exit(0)  # Warnings don't fail the command
    else:
        sys.exit(0)


def _print_summary(result: MergeResult) -> None:
    """Print a human-readable summary of the merge result"""
    click.echo(f"\n🔀 Merge: {result.from_ref} → {result.to_ref}")
    click.echo(f"   Project: {result.project_root}")

    if result.dry_run:
        click.echo("\n   Mode: DRY RUN (no changes applied)")

    # Patch summary
    if result.composite_patch and result.composite_patch.patches:
        patch_count = len(result.composite_patch.patches)
        click.echo(f"\n   📦 Patches: {patch_count}")
        if patch_count <= 5:
            for patch in result.composite_patch.patches:
                click.echo(f"      • {patch.describe()}")
        else:
            # Show first 3 and last 2
            for patch in result.composite_patch.patches[:3]:
                click.echo(f"      • {patch.describe()}")
            click.echo(f"      ... ({patch_count - 5} more patches) ...")
            for patch in result.composite_patch.patches[-2:]:
                click.echo(f"      • {patch.describe()}")
    else:
        click.echo("\n   📦 Patches: 0 (no changes)")

    # Conflicts
    if result.conflicts:
        click.echo(f"\n   ❌ Conflicts: {len(result.conflicts)}")
        for conflict in result.conflicts:
            click.echo(f"      • {conflict.path}: {conflict.reason}")

    # Warnings
    if result.warnings:
        click.echo(f"\n   ⚠️  Warnings: {len(result.warnings)}")
        for warning in result.warnings:
            path_info = f" ({warning.path})" if warning.path else ""
            click.echo(f"      • [{warning.code}] {warning.message}{path_info}")

    # Narrative Impact (WS-M2)
    if hasattr(result, "narrative_impact") and result.narrative_impact:
        impact = result.narrative_impact
        click.echo(f"\n   📖 Narrative Impact: {impact.score:.2f}")
        if impact.is_high_impact:
            click.echo("      🔴 HIGH IMPACT - Review carefully")
        elif impact.is_medium_impact:
            click.echo("      🟡 MEDIUM IMPACT - Moderate changes")
        if impact.reason:
            click.echo(f"      {impact.reason}")

    # Flow Delta (WS-M3)
    if hasattr(result, "flow_delta") and result.flow_delta:
        delta = result.flow_delta
        click.echo("\n   🔀 Flow Delta:")
        click.echo(
            f"      Labels: +{len(delta.labels_added)} -{len(delta.labels_removed)} ~{len(delta.labels_modified)}"
        )
        click.echo(
            f"      Edges: +{len(delta.edges_added)} -{len(delta.edges_removed)}"
        )
        click.echo(f"      Propagation: {delta.propagation_score:.2f}")
        if delta.is_breaking_change:
            click.echo("      ⚠️  BREAKING CHANGE DETECTED")
        if delta.newly_unreachable:
            click.echo(f"      Unreachable: {', '.join(delta.newly_unreachable[:3])}")

    # Status
    if result.applied:
        click.echo("\n   ✅ Status: Applied and recorded in journal")
        if result.timeline_node_id:
            click.echo(f"   📍 Timeline node: {result.timeline_node_id}")
    elif result.conflicts:
        click.echo("\n   ❌ Status: Not applied (conflicts detected)")
    elif result.dry_run:
        click.echo("\n   👁️  Status: Preview only (use without --dry-run to apply)")
    else:
        click.echo("\n   ℹ️  Status: No changes to apply")

    click.echo()
