"""
BranchPy AI Patch Command

Generates AI-powered code fixes from warnings or analysis results.
"""

import argparse
import json
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy.ai.models import ProviderCapability
from branchpy.ai.provider_registry import ProviderRegistry
from branchpy.ai.safety.governance import AIGovernanceEvent, AIGovernanceLogger
from branchpy.ai.service import AIService
from branchpy.config import load_ai_providers_config
from branchpy.license.gating import require_feature_cli


def add_parser(ai_subparsers: argparse._SubParsersAction) -> None:
    """Register ai patch subcommand."""
    patch = ai_subparsers.add_parser(
        "patch", help="Generate AI-powered code patch from warnings."
    )
    patch.add_argument("file", help="Path to file with issues")
    patch.add_argument("--warning-id", help="Specific warning ID to fix (e.g., W001)")
    patch.add_argument("--line", type=int, help="Target specific line number")
    patch.add_argument("--provider", help="Override default AI provider")
    patch.add_argument(
        "--context", type=int, default=20, help="Lines of context (default: 20)"
    )
    patch.add_argument(
        "--dry-run", action="store_true", help="Preview without applying"
    )
    patch.add_argument(
        "--auto-apply", action="store_true", help="Apply without confirmation"
    )
    patch.add_argument("--json", action="store_true", help="Output JSON")
    patch.set_defaults(func=handle_ai_patch)


def handle_ai_patch(args: argparse.Namespace) -> int:
    """Handle ai patch command."""
    # LIC-CLI-4: AI patch requires Pro+ or Ren'Py (reuses ai_review feature key)
    file_path = Path(args.file)
    project_path = file_path.parent if file_path.exists() else None
    require_feature_cli("ai_review", "AI Patch", project_path)

    if not file_path.exists():
        print(f"✗ File not found: {args.file}", file=sys.stderr)
        return 1

    # Load AI service
    config = load_ai_providers_config()
    registry = ProviderRegistry()
    registry.load_from_dict(config)
    service = AIService(registry=registry)

    # Initialize governance logger
    gov_logger = AIGovernanceLogger()

    # Read file content
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            code = f.read()
    except Exception as e:
        print(f"✗ Error reading file: {e}", file=sys.stderr)
        return 1

    # Generate patch
    correlation_id = str(uuid.uuid4())

    try:
        patch_result = _generate_patch(
            service=service,
            file_path=file_path,
            code=code,
            warning_id=args.warning_id,
            target_line=args.line,
            context_lines=args.context,
            provider_id=args.provider,
            correlation_id=correlation_id,
            project_path=project_path,
        )

        # Log governance event
        gov_event = AIGovernanceEvent(
            event="ai_patch_generated",
            timestamp=datetime.utcnow().isoformat() + "Z",
            user_id=_get_user_id(),
            project=str(project_path) if project_path else "",
            provider=patch_result["provider"],
            model=patch_result["model"],
            operation="code_patch",
            bytes_sent=len(code.encode()),
            bytes_received=len(patch_result["patch_content"].encode()),
            preview_redacted=_redact_preview(patch_result["explanation"]),
            success=True,
            duration_ms=patch_result["duration_ms"],
            consent_granted=True,
            policy_version="1.0",
        )
        gov_logger.log_event(gov_event)

        # Display patch
        if args.json:
            output = {
                "success": True,
                "file": str(file_path),
                "patch": patch_result["patch_content"],
                "explanation": patch_result["explanation"],
                "provider": patch_result["provider"],
                "model": patch_result["model"],
                "duration_ms": patch_result["duration_ms"],
                "correlation_id": correlation_id,
            }
            print(json.dumps(output, indent=2))
            return 0
        else:
            _display_patch_human(patch_result, file_path)

        # Apply patch (unless dry-run or --json)
        if not args.dry_run:
            if args.auto_apply or _confirm_patch():
                _apply_patch(
                    file_path,
                    patch_result["patched_content"],
                    gov_logger,
                    correlation_id,
                )
                return 0
            else:
                print("\n✗ Patch declined by user")
                _log_patch_declined(gov_logger, correlation_id)
                return 3
        else:
            print("\n✗ Dry run mode — patch not applied")
            print(f"\nTo apply: branchpy ai patch {file_path}")

        return 0

    except Exception as e:
        print(f"\n✗ Error generating patch: {e}", file=sys.stderr)

        # Log error event
        gov_event = AIGovernanceEvent(
            event="ai_patch_error",
            timestamp=datetime.utcnow().isoformat() + "Z",
            user_id=_get_user_id(),
            project=str(project_path) if project_path else "",
            success=False,
            error=str(e),
        )
        gov_logger.log_event(gov_event)

        return 1


def _generate_patch(
    service: AIService,
    file_path: Path,
    code: str,
    warning_id: Optional[str],
    target_line: Optional[int],
    context_lines: int,
    provider_id: Optional[str],
    correlation_id: str,
    project_path: Optional[Path],
) -> Dict[str, Any]:
    """Generate patch using AI service."""
    import time

    # Extract context around target line
    lines = code.split("\n")
    if target_line:
        start = max(0, target_line - context_lines - 1)  # Convert to 0-based
        end = min(len(lines), target_line + context_lines)
        context = "\n".join(lines[start:end])
        context_info = f"around line {target_line}"
    else:
        context = code
        context_info = "entire file"

    # Build prompt
    prompt = _build_patch_prompt(
        file_path=str(file_path),
        code=context,
        warning_id=warning_id,
        target_line=target_line,
        context_info=context_info,
    )

    # Call AI provider
    start_time = time.time()
    provider = service._select_provider(provider_id)

    # Create a simple request (we'll use the provider's completion method directly)
    from branchpy.ai.models import AIRequestBase

    request = AIRequestBase(
        id=correlation_id,
        capability=ProviderCapability.CODE_REVIEW,
        project=str(project_path) if project_path else "",
        file_path=str(file_path),
    )

    # Simplified completion call (assumes provider has complete method)
    response_text = _call_provider_completion(provider, prompt)

    duration_ms = (time.time() - start_time) * 1000

    # Parse patch from response
    patch_content = _extract_patch(response_text)
    explanation = _extract_explanation(response_text)
    patched_content = _apply_patch_to_code(code, patch_content, target_line)

    return {
        "patch_content": patch_content,
        "patched_content": patched_content,
        "explanation": explanation,
        "provider": getattr(provider, "name", provider_id or "default"),
        "model": getattr(provider, "default_model", "unknown"),
        "duration_ms": duration_ms,
    }


def _build_patch_prompt(
    file_path: str,
    code: str,
    warning_id: Optional[str],
    target_line: Optional[int],
    context_info: str,
) -> str:
    """Build AI prompt for patch generation."""
    prompt_parts = [
        "You are an expert code assistant. Generate a precise code patch to fix the issue described below.",
        "",
        f"File: {file_path}",
        f"Context: {context_info}",
        "",
    ]

    if warning_id:
        prompt_parts.append(f"Warning ID: {warning_id}")

    if target_line:
        prompt_parts.append(f"Problem at line: {target_line}")

    prompt_parts.extend(
        [
            "",
            "Code:",
            "```",
            code,
            "```",
            "",
            "Please provide:",
            "1. A unified diff patch showing the changes",
            "2. A brief explanation of what was fixed and why",
            "",
            "Format your response as:",
            "PATCH:",
            "```diff",
            "[unified diff here]",
            "```",
            "",
            "EXPLANATION:",
            "[explanation here]",
        ]
    )

    return "\n".join(prompt_parts)


def _call_provider_completion(provider, prompt: str) -> str:
    """Call provider completion (simplified)."""
    # This is a simplified version - in production, use provider's actual API
    # For now, return a mock response or call the provider's completion method
    if hasattr(provider, "complete"):
        response = provider.complete(prompt=prompt, max_tokens=1500, temperature=0.2)
        return response.content if hasattr(response, "content") else str(response)
    else:
        raise NotImplementedError(f"Provider {provider} does not support completion")


def _extract_patch(response_text: str) -> str:
    """Extract patch content from AI response."""
    # Look for PATCH: section
    if "PATCH:" in response_text:
        patch_start = response_text.find("PATCH:")
        patch_content = response_text[patch_start + 6 :].strip()

        # Extract content between ```diff markers
        if "```diff" in patch_content:
            diff_start = patch_content.find("```diff") + 7
            diff_end = patch_content.find("```", diff_start)
            if diff_end > diff_start:
                return patch_content[diff_start:diff_end].strip()
        elif "```" in patch_content:
            code_start = patch_content.find("```") + 3
            code_end = patch_content.find("```", code_start)
            if code_end > code_start:
                return patch_content[code_start:code_end].strip()

    # Fallback: look for diff markers
    if "@@" in response_text:
        lines = response_text.split("\n")
        patch_lines = []
        in_patch = False
        for line in lines:
            if line.startswith("@@"):
                in_patch = True
            if in_patch:
                patch_lines.append(line)
        if patch_lines:
            return "\n".join(patch_lines)

    # Last resort: return entire response
    return response_text


def _extract_explanation(response_text: str) -> str:
    """Extract explanation from AI response."""
    if "EXPLANATION:" in response_text:
        expl_start = response_text.find("EXPLANATION:") + 12
        explanation = response_text[expl_start:].strip()

        # Remove trailing code blocks
        if "```" in explanation:
            explanation = explanation[: explanation.find("```")].strip()

        return explanation

    # Fallback: look for explanation after patch
    if "PATCH:" in response_text:
        after_patch = response_text.split("PATCH:")[-1]
        if "```" in after_patch:
            parts = after_patch.split("```")
            if len(parts) >= 3:
                return parts[2].strip()

    return "AI-generated patch"


def _apply_patch_to_code(
    original_code: str, patch_content: str, target_line: Optional[int]
) -> str:
    """Apply patch to original code (simple implementation)."""
    # For MVP, just try to apply unified diff
    # In production, use proper patch library

    lines = original_code.split("\n")
    patch_lines = patch_content.split("\n")

    # Simple heuristic: if patch has + and - lines, apply them
    result_lines = lines.copy()

    # Look for additions (lines starting with +)
    additions = [
        line[1:]
        for line in patch_lines
        if line.startswith("+") and not line.startswith("+++")
    ]
    removals = [
        line[1:]
        for line in patch_lines
        if line.startswith("-") and not line.startswith("---")
    ]

    if target_line and additions:
        # Insert additions at target line
        insert_pos = target_line - 1  # Convert to 0-based
        for i, addition in enumerate(additions):
            result_lines.insert(insert_pos + i, addition)

    return "\n".join(result_lines)


def _display_patch_human(patch_result: Dict[str, Any], file_path: Path) -> None:
    """Display patch in human-readable format."""
    print(f"\n🔧 Patch generated for {file_path}")
    print(f"Provider: {patch_result['provider']} ({patch_result['model']})")
    print(f"Duration: {patch_result['duration_ms']:.0f}ms\n")

    print("Proposed Changes:")
    print("━" * 60)
    print(f" {file_path}")
    print("━" * 60)
    print(patch_result["patch_content"])
    print("━" * 60)
    print()

    if patch_result["explanation"]:
        print("Explanation:")
        print(patch_result["explanation"])
        print()


def _confirm_patch() -> bool:
    """Prompt user to confirm patch application."""
    while True:
        response = input("Apply this patch? [y/N]: ").strip().lower()
        if response in ("y", "yes"):
            return True
        elif response in ("n", "no", ""):
            return False
        print("Please enter 'y' or 'n'")


def _apply_patch(
    file_path: Path,
    patched_content: str,
    gov_logger: AIGovernanceLogger,
    correlation_id: str,
) -> None:
    """Apply patch to file with backup."""
    # Create simple backup
    backup_dir = file_path.parent / ".branchpy" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"{file_path.name}.{timestamp}.bak"

    # Backup original
    with open(file_path, "r", encoding="utf-8") as f:
        original_content = f.read()

    with open(backup_path, "w", encoding="utf-8") as f:
        f.write(original_content)

    # Write patched content
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(patched_content)

    print("\n✓ Patch applied successfully")
    print(f"  Backup: {backup_path}")
    print(f"\nRestore: cp {backup_path} {file_path}")

    # Log applied event
    gov_event = AIGovernanceEvent(
        event="ai_patch_applied",
        timestamp=datetime.utcnow().isoformat() + "Z",
        user_id=_get_user_id(),
        success=True,
    )
    gov_logger.log_event(gov_event)


def _log_patch_declined(gov_logger: AIGovernanceLogger, correlation_id: str) -> None:
    """Log patch declined event."""
    gov_event = AIGovernanceEvent(
        event="ai_patch_declined",
        timestamp=datetime.utcnow().isoformat() + "Z",
        user_id=_get_user_id(),
    )
    gov_logger.log_event(gov_event)


def _get_user_id() -> str:
    """Get user ID from auth.json."""
    try:
        from branchpy.license.auth import load_auth_data

        auth_data = load_auth_data()
        return auth_data.get("email", "<local-user>") if auth_data else "<local-user>"
    except Exception:
        return "<local-user>"


def _redact_preview(text: str, max_length: int = 200) -> str:
    """Redact preview text for governance logs."""
    if not text:
        return ""
    if len(text) <= max_length:
        return text
    return text[:max_length] + "\n[...truncated...]"
