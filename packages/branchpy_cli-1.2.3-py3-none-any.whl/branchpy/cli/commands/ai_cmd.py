"""
BranchPy AI Commands
"""

import argparse
import json
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List

from branchpy.ai.models import (
    CodeReviewRequest,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from branchpy.ai.provider_registry import ProviderRegistry
from branchpy.ai.service import AIService
from branchpy.config import load_ai_providers_config

# License gating (v1.0.0 - LIC-CLI-4)
from branchpy.license.gating import require_feature_cli

_AI_DEPS = ["openai", "anthropic", "google.generativeai"]


def _check_ai_deps() -> bool:
    """Return True if all AI provider packages are installed."""
    import importlib

    for mod in _AI_DEPS:
        try:
            importlib.import_module(mod)
        except ImportError:
            return False
    return True


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    """Register AI subcommand and sub-subcommands."""
    ai_parser = subparsers.add_parser(
        "ai",
        help="AI-powered helpers: review code, generate docs, explain warnings.",
    )
    ai_sub = ai_parser.add_subparsers(dest="ai_command", required=True)

    # --- existing subcommands (review/docgen/explain-warning) ---

    review = ai_sub.add_parser("review", help="Review code in a file.")
    review.add_argument("path", help="Path to the source file.")
    review.add_argument(
        "--line", type=int, default=None, help="Cursor line (for context)."
    )
    review.add_argument(
        "--provider", default=None, help="Provider ID defined in ai_providers.toml."
    )

    docgen = ai_sub.add_parser("docgen", help="Generate or improve documentation.")
    docgen.add_argument("path", help="Path to the source file.")
    docgen.add_argument("--symbol", required=False, help="Symbol name to document.")
    docgen.add_argument(
        "--provider", default=None, help="Provider ID defined in ai_providers.toml."
    )

    explain = ai_sub.add_parser("explain-warning", help="Explain an analyzer warning.")
    explain.add_argument("warning_id", help="BranchPy warning ID (e.g., W001).")
    explain.add_argument(
        "--message", required=False, help="Optional warning message override."
    )
    explain.add_argument(
        "--code-path", required=False, help="Path to the affected file."
    )
    explain.add_argument(
        "--provider", default=None, help="Provider ID defined in ai_providers.toml."
    )

    # --- NEW: providers subcommand ---

    providers = ai_sub.add_parser("providers", help="List configured AI providers.")
    providers.add_argument(
        "--json",
        action="store_true",
        help="Output machine-readable JSON for the VS Code extension.",
    )

    # --- NEW: report subcommand ---

    report = ai_sub.add_parser(
        "report", help="Generate AI usage report from governance logs."
    )
    report.add_argument(
        "--days", type=int, default=7, help="Number of days to look back (default: 7)."
    )
    report.add_argument(
        "--provider",
        default=None,
        help="Filter by provider ID (e.g., openai, anthropic).",
    )
    report.add_argument(
        "--capability",
        default=None,
        help="Filter by capability (e.g., code_review, doc_gen).",
    )
    report.add_argument(
        "--json", action="store_true", help="Output JSON instead of formatted text."
    )

    # --- NEW: patch subcommand (AI-CLI-1) ---

    patch = ai_sub.add_parser(
        "patch", help="Generate AI-powered code patch from warnings."
    )
    patch.add_argument("file", help="Path to file with issues.")
    patch.add_argument("--warning-id", help="Specific warning ID to fix (e.g., W001).")
    patch.add_argument("--line", type=int, help="Target specific line number.")
    patch.add_argument("--provider", help="Override default AI provider.")
    patch.add_argument(
        "--context", type=int, default=20, help="Lines of context (default: 20)."
    )
    patch.add_argument(
        "--dry-run", action="store_true", help="Preview without applying."
    )
    patch.add_argument(
        "--auto-apply", action="store_true", help="Apply without confirmation."
    )
    patch.add_argument("--json", action="store_true", help="Output JSON.")

    # --- NEW: bqf subcommand (Wave 5) ---

    bqf = ai_sub.add_parser(
        "bqf", help="Run BQF AI usage policies against governance logs."
    )
    bqf.add_argument(
        "--days", type=int, default=1, help="Number of days to analyze (default: 1)."
    )
    bqf.add_argument(
        "--json", action="store_true", help="Output JSON instead of formatted text."
    )

    ai_parser.set_defaults(func=handle_ai_command)


def _load_registry() -> ProviderRegistry:
    config = load_ai_providers_config()
    registry = ProviderRegistry()
    registry.load_from_dict(config)
    return registry


def handle_ai_command(args: argparse.Namespace) -> int:
    if args.ai_command == "providers":
        return _handle_providers(args)

    if args.ai_command == "report":
        return _handle_report(args)

    if args.ai_command == "patch":
        return _handle_patch(args)

    if args.ai_command == "bqf":
        return _handle_bqf(args)

    registry = _load_registry()
    service = AIService(registry=registry)

    if args.ai_command == "review":
        return _handle_review(args, service)
    if args.ai_command == "docgen":
        return _handle_docgen(args, service)
    if args.ai_command == "explain-warning":
        return _handle_explain_warning(args, service)

    print("Unknown ai command", file=sys.stderr)
    return 1


def _handle_providers(args: argparse.Namespace) -> int:
    registry = _load_registry()

    providers_info: List[Dict[str, Any]] = []

    for provider_id, provider in registry.providers.items():
        name = getattr(provider, "name", provider_id)
        provider_type = getattr(
            provider, "provider_type", provider.__class__.__name__.lower()
        )
        capabilities = getattr(provider, "capabilities", [])
        experimental = getattr(provider, "experimental", False)

        providers_info.append(
            {
                "id": provider_id,
                "name": name,
                "type": provider_type,
                "capabilities": [c.value for c in capabilities],
                "experimental": experimental,
            }
        )

    if getattr(args, "json", False):
        print(json.dumps({"providers": providers_info}, indent=2))
    else:
        if not providers_info:
            print("No AI providers configured. Check ai_providers.toml.")
        else:
            print("Configured AI providers:")
            for p in providers_info:
                label = f"{p['id']} – {p['name']} ({p['type']})"
                if p.get("experimental"):
                    label += " [experimental]"
                caps = ", ".join(p["capabilities"]) if p["capabilities"] else "none"
                print(f"  {label}")
                print(f"      capabilities: {caps}")

    return 0


def _handle_review(args: argparse.Namespace, service: AIService) -> int:
    # LIC-CLI-4: AI review requires Pro+ or Ren'Py
    file_path = Path(args.path)
    project_path = file_path.parent if file_path.exists() else None
    require_feature_cli("ai_review", "AI-Powered Review", project_path)

    if not file_path.exists():
        print(f"File not found: {args.path}", file=sys.stderr)
        return 1

    with open(file_path, "r", encoding="utf-8") as f:
        code = f.read()

    request = CodeReviewRequest(
        id=str(uuid.uuid4()),
        capability=ProviderCapability.CODE_REVIEW,
        file_path=args.path,
        code=code,
        cursor_line=args.line,
    )
    response = service.review_code(request, provider_id=args.provider)
    print(response.content)
    return 0


def _handle_docgen(args: argparse.Namespace, service: AIService) -> int:
    # LIC-CLI-4: AI docgen requires Pro+ or Ren'Py
    file_path = Path(args.path)
    project_path = file_path.parent if file_path.exists() else None
    require_feature_cli("ai_docgen", "AI Documentation Generator", project_path)

    if not file_path.exists():
        print(f"File not found: {args.path}", file=sys.stderr)
        return 1

    with open(file_path, "r", encoding="utf-8") as f:
        code = f.read()

    request = DocGenRequest(
        id=str(uuid.uuid4()),
        capability=ProviderCapability.DOC_GEN,
        file_path=args.path,
        code=code,
        symbol_name=args.symbol,
    )
    response = service.generate_docs(request, provider_id=args.provider)
    print(response.content)
    return 0


def _handle_explain_warning(args: argparse.Namespace, service: AIService) -> int:
    # LIC-CLI-4: AI explain requires Pro+ or Ren'Py
    code_path = Path(args.code_path) if args.code_path else None
    project_path = code_path.parent if code_path and code_path.exists() else None
    require_feature_cli("ai_explain", "AI Explanation", project_path)

    request = ExplainWarningRequest(
        id=str(uuid.uuid4()),
        capability=ProviderCapability.EXPLAIN_WARNING,
        warning_id=args.warning_id,
        code_path=args.code_path,
        message=args.message,
    )
    response = service.explain_warning(request, provider_id=args.provider)
    print(response.content)
    return 0


def _handle_report(args: argparse.Namespace) -> int:
    """Handle AI usage report generation."""
    from branchpy.cli.commands.ai_report_cmd import ai_report_command

    return ai_report_command(
        days=args.days,
        provider=args.provider,
        capability=args.capability,
        json_output=getattr(args, "json", False),
        project_path=Path(getattr(args, "project", ".")),
    )


def _handle_patch(args: argparse.Namespace) -> int:
    """Handle AI patch generation."""
    from branchpy.cli.commands.ai_patch_cmd import handle_ai_patch

    return handle_ai_patch(args)


def _handle_bqf(args: argparse.Namespace) -> int:
    """Handle BQF AI usage policy checks."""
    import json

    from branchpy.bqf.runner_ai import run_bqf_ai
    from branchpy.core.governance.logger import GovernanceLogger

    # Get governance logger
    logger = GovernanceLogger()

    # Run BQF AI policies
    summary = run_bqf_ai(logger, days=args.days)

    if args.json:
        # JSON output for machine consumption
        output = {
            "policies_run": summary.policies_run,
            "policies_passed": summary.policies_passed,
            "policies_warned": summary.policies_warned,
            "policies_failed": summary.policies_failed,
            "duration_ms": summary.duration_ms,
            "total_calls": summary.total_calls,
            "total_tokens": summary.total_tokens,
            "total_cost": summary.total_cost,
            "error_count": summary.error_count,
            "provider_breakdown": summary.provider_breakdown,
        }
        print(json.dumps(output, indent=2))
    else:
        # Human-readable output
        print("\n" + "=" * 60)
        print("  BQF AI Usage Summary")
        print("=" * 60)
        print(f"Analysis Period: Last {args.days} day(s)")
        print()
        print("Policy Results:")
        print(f"  Policies run:    {summary.policies_run}")
        print(f"  Passed:          {summary.policies_passed}")
        print(f"  Warned:          {summary.policies_warned}")
        print(f"  Failed:          {summary.policies_failed}")
        print(f"  Duration:        {summary.duration_ms:.2f} ms")
        print()
        print("AI Usage Metrics:")
        print(f"  Total calls:     {summary.total_calls}")
        print(f"  Total tokens:    {summary.total_tokens:,}")
        print(f"  Total cost:      ${summary.total_cost:.2f}")
        print(f"  Error count:     {summary.error_count}")

        if summary.provider_breakdown:
            print()
            print("Provider Breakdown:")
            for provider, stats in summary.provider_breakdown.items():
                print(f"  {provider}:")
                print(f"    Calls:   {stats['calls']}")
                print(f"    Tokens:  {stats['tokens']:,}")
                print(f"    Cost:    ${stats['cost']:.2f}")
                print(f"    Errors:  {stats['errors']}")

        print("=" * 60 + "\n")

    # Return non-zero if policies failed
    return 1 if summary.policies_failed > 0 else 0


# The original `run` function is being replaced by `handle_ai_command`
# and the sub-command handlers.
# The `add_parser` function will set `handle_ai_command` as the default
# function for the `ai` command.
def run(args: argparse.Namespace) -> int:
    if not _check_ai_deps():
        print(
            "AI features require optional dependencies that are not installed.\n"
            "\n"
            "  Install them with:\n"
            '    pip install "branchpy[ai]"\n'
            "\n"
            "Core BranchPy analysis (analyze, stats, pilot, omega, flowchart)\n"
            "works without AI dependencies.",
            file=sys.stderr,
        )
        return 1
    return handle_ai_command(args)
