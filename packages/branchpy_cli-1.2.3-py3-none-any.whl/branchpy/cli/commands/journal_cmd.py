"""
Journal command - show operation history.
"""

import click

from branchpy.history.journal import get_journal
from branchpy.telemetry import emit_event


@click.command("journal")
@click.option(
    "--limit", "-n", type=int, default=10, help="Number of recent operations to show"
)
@click.option("--clear", is_flag=True, help="Clear all journal history (destructive!)")
def journal_cmd(limit: int, clear: bool) -> None:
    """
    Show BranchPy operation history.

    Displays recent operations that can be undone/redone, including:
    - Merge operations
    - Media autofix/relink
    - Any other reversible BranchPy operations

    Use --clear to reset the journal (warning: irreversible).
    """
    journal = get_journal()

    if clear:
        if not click.confirm("Clear all journal history? This cannot be undone."):
            click.echo("Aborted.")
            return

        journal.clear()
        click.echo("✓ Journal cleared.")
        emit_event("journal.cleared", {})
        return

    # Show journal summary
    click.echo("\nBranchPy Operation Journal")
    click.echo("=" * 60)
    click.echo(f"{journal.summarize()}\n")

    # Show recent operations
    history = journal.get_history(limit=limit)

    if not history:
        click.echo("No operations in history.")
        return

    click.echo(f"Recent operations (newest first, limit={limit}):\n")

    for i, patch in enumerate(history, 1):
        click.echo(f"  #{i:2d}  {patch.describe()}")

    click.echo("\nUse 'branchpy undo' to revert the last operation.")
    click.echo("Use 'branchpy redo' to reapply undone operations.")

    emit_event("journal.viewed", {"history_count": len(history)})
