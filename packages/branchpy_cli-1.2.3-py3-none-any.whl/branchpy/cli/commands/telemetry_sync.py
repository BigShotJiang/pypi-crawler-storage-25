"""
BranchPy CLI - Telemetry Sync Command

Reads JSONL telemetry from .branchpy/logs/telemetry/ and syncs to BranchPyDB.
Runs as trusted backend operation (not in extension).
"""

import json
import sys
from pathlib import Path

try:
    import click
except ImportError:
    print("Error: click package not installed. Run: pip install click", file=sys.stderr)
    sys.exit(1)

from branchpy.config import load_config
from branchpy.telemetry.mysql_sink import (
    MySQLTelemetrySink,
    map_event,
    map_metric,
    map_session,
)


@click.command()
@click.option(
    "--source",
    default=".branchpy/logs/telemetry",
    help="Path to JSONL telemetry files",
)
@click.option(
    "--batch-size",
    default=1000,
    type=int,
    help="Events per batch insert",
)
@click.option(
    "--rotate/--no-rotate",
    default=True,
    help="Rotate synced files to .synced",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Parse files without DB writes",
)
def telemetry_sync(source: str, batch_size: int, rotate: bool, dry_run: bool):
    """
    Sync JSONL telemetry to BranchPyDB.

    Reads .jsonl files from source dir, batches to MySQL, rotates processed files.
    Requires [telemetry.mysql] config section with connection params.

    Example:
        branchpy telemetry-sync
        branchpy telemetry-sync --source /custom/path --batch-size 500
        branchpy telemetry-sync --dry-run
    """
    source_path = Path(source).expanduser().resolve()

    if not source_path.exists():
        click.echo(f"❌ Telemetry directory not found: {source_path}", err=True)
        return 1

    # Find JSONL files
    files = sorted(source_path.glob("*.jsonl"))
    if not files:
        click.echo(f"ℹ️  No telemetry files in {source_path}")
        return 0

    click.echo(f"📦 Found {len(files)} telemetry file(s)")

    # Load config (from project root or cwd)
    project_root = Path.cwd()
    config = load_config(project_root)
    if "telemetry" not in config or "mysql" not in config["telemetry"]:
        click.echo("❌ Missing [telemetry.mysql] config section", err=True)
        return 1

    mysql_config = config["telemetry"]["mysql"]

    # Initialize sink
    sink = None
    if not dry_run:
        try:
            sink = MySQLTelemetrySink(mysql_config)
            if not sink.health_check():
                click.echo("❌ Database connection failed", err=True)
                return 1
            click.echo("✅ Connected to BranchPyDB")
        except Exception as e:
            click.echo(f"❌ Failed to connect: {e}", err=True)
            return 1

    # Process files
    total_sessions = 0
    total_events = 0
    total_metrics = 0

    for file in files:
        click.echo(f"\n📄 Processing {file.name}...")

        sessions = []
        events = []
        metrics = []

        # Parse JSONL
        try:
            with open(file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    record = json.loads(line)
                    record_type = record.get("type")

                    if record_type == "session":
                        sessions.append(map_session(record))
                    elif record_type == "event":
                        events.append(map_event(record))
                    elif record_type == "metric":
                        metrics.append(map_metric(record))
        except Exception as e:
            click.echo(f"⚠️  Parse error: {e}", err=True)
            continue

        click.echo(
            f"   Sessions: {len(sessions)}, Events: {len(events)}, Metrics: {len(metrics)}"
        )

        # Write to DB
        if not dry_run and sink:
            try:
                # Insert sessions first (foreign key dependency)
                for session in sessions:
                    sink.insert_session(session)

                # Batch insert events
                for i in range(0, len(events), batch_size):
                    batch = events[i : i + batch_size]
                    sink.insert_events(batch)

                # Batch insert metrics
                for i in range(0, len(metrics), batch_size):
                    batch = metrics[i : i + batch_size]
                    sink.insert_metrics(batch)

                click.echo("   ✅ Synced to BranchPyDB")
            except Exception as e:
                click.echo(f"   ❌ Sync error: {e}", err=True)
                continue

        total_sessions += len(sessions)
        total_events += len(events)
        total_metrics += len(metrics)

        # Rotate processed file
        if rotate and not dry_run:
            synced_path = file.with_suffix(".synced")
            file.rename(synced_path)
            click.echo(f"   📁 Rotated to {synced_path.name}")

    # Summary
    click.echo(f"\n{'[DRY RUN] ' if dry_run else ''}✅ Sync complete")
    click.echo(f"   Sessions: {total_sessions}")
    click.echo(f"   Events: {total_events}")
    click.echo(f"   Metrics: {total_metrics}")

    return 0


if __name__ == "__main__":
    import sys

    sys.exit(telemetry_sync() or 0)
