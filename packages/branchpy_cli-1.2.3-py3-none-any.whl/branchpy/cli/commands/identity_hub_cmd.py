"""
branchpy.cli.commands.identity_hub_cmd — Identity & Hub CLI commands (v0.9.3).

Commands:
- branchpy login --user <user_id>: Login to local identity provider
- branchpy whoami: Display current user information
- branchpy logout: Clear current session

v0.9.3 — Federation & Cloud Collaboration (local-only foundation)
"""

import click
from rich.console import Console
from rich.table import Table

from branchpy.identity import (
    LocalIdentityProvider,
    clear_session,
    load_current_session,
    save_session,
)

console = Console()


@click.group(name="identity")
def identity_group():
    """Identity and authentication commands (v0.9.3)."""
    pass


@identity_group.command(name="login")
@click.option("--user", "-u", required=True, help="User ID to login as")
def login_cmd(user: str):
    """
    Login to BranchPy local identity provider.

    Example:
        branchpy identity login --user alice

    This creates a local session stored in ~/.branchpy/identity/session.json
    with a 7-day expiration.
    """
    try:
        provider = LocalIdentityProvider()

        # Start auth flow (local mode: no browser redirect)
        console.print(f"[bold cyan]Logging in as user:[/bold cyan] {user}")
        code = provider.start_auth_flow(user_id=user)

        # Exchange code for token
        token = provider.exchange_code_for_token(code)

        # Get user info
        user_info = provider.get_user_info(token)

        # Save session
        save_session(user_info, token)

        # Success message
        console.print("[bold green]✓ Login successful![/bold green]")
        console.print(f"  User: {user_info.display_name}")
        console.print(f"  Email: {user_info.email}")
        console.print(f"  Organization: {user_info.org_id}")
        console.print(
            f"  Session expires: {token.expires_at.strftime('%Y-%m-%d %H:%M:%S UTC')}"
        )

    except ValueError as e:
        console.print(f"[bold red]✗ Login failed:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        raise click.Abort()


@identity_group.command(name="whoami")
def whoami_cmd():
    """
    Display current user information from active session.

    Example:
        branchpy identity whoami

    Shows current user details, session expiration, and organization.
    """
    try:
        session = load_current_session()

        if session is None:
            console.print("[yellow]No active session.[/yellow]")
            console.print(
                "Login first with: [cyan]branchpy identity login --user <user_id>[/cyan]"
            )
            raise click.Abort()

        if session.is_expired():
            console.print("[bold red]✗ Session expired[/bold red]")
            console.print(
                f"  Expired at: {session.token.expires_at.strftime('%Y-%m-%d %H:%M:%S UTC')}"
            )
            console.print(
                "Login again with: [cyan]branchpy identity login --user <user_id>[/cyan]"
            )
            raise click.Abort()

        # Display user info in table
        table = Table(title="Current User", show_header=False)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="bold")

        table.add_row("User ID", session.user.user_id)
        table.add_row("Display Name", session.user.display_name)
        table.add_row("Email", session.user.email)
        table.add_row("Organization", session.user.org_id)
        table.add_row("Status", "Active" if session.user.is_active else "Inactive")
        table.add_row(
            "Login Time", session.login_timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")
        )
        table.add_row(
            "Session Expires",
            session.token.expires_at.strftime("%Y-%m-%d %H:%M:%S UTC"),
        )

        console.print(table)

    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


@identity_group.command(name="logout")
def logout_cmd():
    """
    Logout from current session.

    Example:
        branchpy identity logout

    Clears the active session stored in ~/.branchpy/identity/session.json
    """
    try:
        session = load_current_session()

        if session is None:
            console.print("[yellow]No active session to logout from.[/yellow]")
            return

        clear_session()
        console.print("[bold green]✓ Logged out successfully[/bold green]")
        console.print(f"  User: {session.user.display_name} ({session.user.user_id})")

    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


# ============================================================================
# Convenience Commands (Top-Level Aliases)
# ============================================================================


@click.command(name="login")
@click.option("--user", "-u", required=True, help="User ID to login as")
def login_toplevel(user: str):
    """Login to BranchPy (shortcut for 'branchpy identity login')."""
    ctx = click.get_current_context()
    ctx.invoke(login_cmd, user=user)


@click.command(name="whoami")
def whoami_toplevel():
    """Display current user (shortcut for 'branchpy identity whoami')."""
    ctx = click.get_current_context()
    ctx.invoke(whoami_cmd)


@click.command(name="logout")
def logout_toplevel():
    """Logout (shortcut for 'branchpy identity logout')."""
    ctx = click.get_current_context()
    ctx.invoke(logout_cmd)


# ============================================================================
# Legacy CLI Integration (for branchpy.cli.py _CMD_MAP registration)
# ============================================================================


def add_parser(subparsers):
    """
    Legacy argparse integration (if needed).

    Note: Click is preferred for v0.9.3+ commands, but this provides
    compatibility with existing CLI structure.
    """
    # This would add argparse subparsers, but we're using Click now
    # Kept for compatibility with _CMD_MAP expectations
    pass


def run(args):
    """
    Legacy entry point for argparse-based dispatch.

    Routes to Click commands.
    """
    # Convert args to Click context if needed
    # For now, Click commands are invoked directly
    pass
