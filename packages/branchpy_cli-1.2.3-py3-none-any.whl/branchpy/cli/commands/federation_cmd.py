"""
branchpy.cli.commands.federation_cmd — Federation CLI commands (v0.9.3).

Commands:
- branchpy federation create-share: Create share link for resource
- branchpy federation import-share: Import resource from share link
- branchpy federation list: List all share links

v0.9.3 — Federation & Cloud Collaboration (local-only foundation)
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from branchpy.federation import (
    InvalidShareTokenError,
    create_share_link_with_export,
    import_share_link,
    resolve_share_link_local,
)
from branchpy.hub import HubClient, local_state
from branchpy.rbac import Permission, PermissionDenied, check_permission

console = Console()


@click.group(name="federation")
def federation_group():
    """Federation and share link commands (v0.9.3)."""
    pass


@federation_group.command(name="create-share")
@click.option("--project", "-p", required=True, help="Project ID to share from")
@click.option(
    "--resource-type",
    "-t",
    required=True,
    type=click.Choice(["project", "governance_template", "stats_policy", "audit_log"]),
    help="Resource type to share",
)
@click.option("--resource-id", "-r", help="Resource ID (default: use project ID)")
@click.option(
    "--expires-hours", type=int, help="Expiration time in hours (default: 168 = 7 days)"
)
def create_share_cmd(
    project: str, resource_type: str, resource_id: str, expires_hours: int
):
    """
    Create federation share link for a resource.

    Examples:
        branchpy federation create-share --project demo-vn --resource-type project
        branchpy federation create-share --project demo-vn --resource-type audit_log --expires-hours 24

    Requires: federation.share.create permission
    """
    try:
        # Check permission
        check_permission(Permission.FEDERATION_SHARE_CREATE, project_id=project)

        # Get current user
        hub = HubClient()
        user = hub.get_current_user()

        # Load project data
        project_obj = hub.get_project(project)

        if resource_id is None:
            resource_id = project

        # Prepare resource data (simplified — full implementation would load actual resource)
        resource_data = {
            "project_id": project_obj.project_id,
            "name": project_obj.name,
            "project_type": project_obj.project_type,
            "tags": project_obj.tags,
            "metadata": project_obj.metadata,
            "owner_user_id": project_obj.owner_user_id,
            "org_id": project_obj.org_id,
        }

        # Create share link + export archive
        token, archive_path = create_share_link_with_export(
            resource_type=resource_type,
            resource_data=resource_data,
            created_by=user.user_id,
            project_id=project,
            expires_in_hours=expires_hours,
        )

        # Display result
        console.print(
            Panel.fit(
                f"[bold cyan]{token}[/bold cyan]",
                title="[bold green]✓ Share Link Created[/bold green]",
                border_style="green",
            )
        )

        console.print("\n[bold]Resource Details:[/bold]")
        console.print(f"  Type: {resource_type}")
        console.print(f"  Resource ID: {resource_id}")
        console.print(f"  Project: {project_obj.name} ({project})")
        console.print(f"  Created by: {user.display_name}")

        if expires_hours:
            console.print(f"  Expires in: {expires_hours} hours")

        console.print(f"\n[dim]Archive: {archive_path}[/dim]")

        console.print("\n[bold yellow]To import this share link:[/bold yellow]")
        console.print(f'  [cyan]branchpy federation import-share "{token}"[/cyan]')

    except PermissionDenied as e:
        console.print(f"[bold red]✗ Permission denied:[/bold red] {e}")
        console.print("  You need 'federation.share.create' permission.")
        raise click.Abort()
    except ValueError as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        raise click.Abort()


@federation_group.command(name="import-share")
@click.argument("token")
@click.option("--project", "-p", help="Target project ID for import")
@click.option(
    "--no-verify", is_flag=True, help="Skip signature verification (not recommended)"
)
@click.option("--yes", "-y", is_flag=True, help="Auto-confirm import without prompt")
def import_share_cmd(token: str, project: str, no_verify: bool, yes: bool):
    """
    Import resource from federation share link.

    Examples:
        branchpy federation import-share "branchpy-share://v1/..."
        branchpy federation import-share "branchpy-share://v1/..." --project my-vn --yes

    Requires: federation.share.import permission
    """
    try:
        # Resolve share link first (to show details before confirming)
        console.print("[cyan]Resolving share link...[/cyan]")

        try:
            payload = resolve_share_link_local(token, verify=not no_verify)
        except InvalidShareTokenError as e:
            console.print(f"[bold red]✗ Invalid share token:[/bold red] {e}")
            raise click.Abort()

        # Display share details
        table = Table(title="Share Link Details", show_header=False)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="bold")

        table.add_row("Resource Type", payload.resource_type)
        table.add_row("Resource ID", payload.resource_id)
        table.add_row("Created By", payload.created_by)
        table.add_row("Created At", payload.created_at)

        if payload.project_id:
            table.add_row("Project ID", payload.project_id)

        if payload.expires_at:
            table.add_row("Expires At", payload.expires_at)

        console.print(table)

        # Confirm import (unless --yes flag)
        if not yes:
            confirm = click.confirm("\nImport this resource?", default=False)
            if not confirm:
                console.print("[yellow]Import cancelled.[/yellow]")
                return

        # Check permission (simplified — would check against actual user permissions)
        console.print("\n[cyan]Importing resource...[/cyan]")

        # Import share link
        result = import_share_link(
            token=token,
            target_project_id=project,
            verify_signature=not no_verify,
            auto_confirm=yes,
        )

        if result.success:
            console.print("[bold green]✓ Import successful![/bold green]")
            console.print(f"  Resource Type: {result.resource_type}")
            console.print(f"  Resource ID: {result.resource_id}")

            if result.imported_to_project_id:
                console.print(f"  Imported to Project: {result.imported_to_project_id}")

            if result.metadata:
                console.print(f"\n[dim]Metadata: {result.metadata}[/dim]")
        else:
            console.print(
                f"[bold red]✗ Import failed:[/bold red] {result.error_message}"
            )
            raise click.Abort()

    except InvalidShareTokenError as e:
        console.print(f"[bold red]✗ Invalid share token:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        raise click.Abort()


@federation_group.command(name="list")
def list_shares_cmd():
    """
    List all share links.

    Example:
        branchpy federation list

    Shows all share links created by current user or organization.
    """
    try:
        # Get current user
        hub = HubClient()
        user = hub.get_current_user()

        # Load share links from Hub
        share_links = local_state.load_share_links()

        if not share_links:
            console.print("[yellow]No share links found.[/yellow]")
            console.print(
                "\nCreate one with: [cyan]branchpy federation create-share --project <project_id> --resource-type project[/cyan]"
            )
            return

        # Filter by user's org (simplified)
        user_links = [
            link for link in share_links if link.created_by == user.user_id or True
        ]  # Show all for demo

        # Display in table
        table = Table(title=f"Share Links ({len(user_links)} total)")
        table.add_column("Link ID", style="cyan")
        table.add_column("Resource Type", style="green")
        table.add_column("Resource ID", style="bold")
        table.add_column("Created By", style="dim")
        table.add_column("Expires", style="yellow")
        table.add_column("Project", style="magenta")

        for link in user_links:
            expires_str = "Never"
            if link.expires_at:
                from datetime import datetime

                if datetime.utcnow() > link.expires_at:
                    expires_str = "[red]Expired[/red]"
                else:
                    expires_str = link.expires_at.strftime("%Y-%m-%d")

            table.add_row(
                link.link_id[:12] + "...",
                link.resource_type,
                (
                    link.resource_id[:20] + "..."
                    if len(link.resource_id) > 20
                    else link.resource_id
                ),
                link.created_by,
                expires_str,
                link.project_id or "—",
            )

        console.print(table)

    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


# ============================================================================
# Legacy CLI Integration (for branchpy.cli.py _CMD_MAP registration)
# ============================================================================


def add_parser(subparsers):
    """Legacy argparse integration (if needed)."""
    pass


def run(args):
    """Legacy entry point for argparse-based dispatch."""
    pass
