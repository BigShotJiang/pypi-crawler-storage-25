"""
BranchPy CLI Commands Package

Subcommands for the bpy CLI tool.

NOTE: This file intentionally has NO imports to avoid eager loading.
Commands are lazy-loaded on demand via l10n_cmd._inflate_and_dispatch().
"""
