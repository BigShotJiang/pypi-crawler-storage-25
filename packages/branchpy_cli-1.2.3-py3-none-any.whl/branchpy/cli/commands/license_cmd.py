"""
License management commands for BranchPy.

Commands:
- branchpy license register - Create new BranchPy account
- branchpy license login <email> - Authenticate and receive tokens
- branchpy license logout - Revoke tokens and clear local auth
- branchpy license status - Show current plan and features
- branchpy license refresh - Manually refresh tokens
- branchpy license claim-renpy - Claim free unlimited Ren'Py license
"""

import getpass
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from branchpy import logs
from branchpy.license import auth, detection, entitlements, exceptions
from branchpy.license.status_core import compute_license_status


def add_parser(subparsers):
    """Register license subcommand with argparse."""
    parser = subparsers.add_parser(
        "license", help="Manage BranchPy license and authentication"
    )

    # Create subcommands for license
    license_subparsers = parser.add_subparsers(
        dest="license_action", help="License management actions"
    )

    # register command
    register_parser = license_subparsers.add_parser(
        "register", help="Create new BranchPy account"
    )
    register_parser.add_argument(
        "--email", help="Email address (optional, will prompt if not provided)"
    )
    register_parser.add_argument(
        "--project", help="Path to your project (for Ren'Py auto-detection)"
    )

    # login command
    login_parser = license_subparsers.add_parser(
        "login", help="Authenticate with BranchPy account"
    )
    login_parser.add_argument(
        "email", nargs="?", help="Email address (optional, will prompt if not provided)"
    )
    login_parser.add_argument(
        "--password", help="Password (not recommended, will prompt if not provided)"
    )

    # logout command
    logout_parser = license_subparsers.add_parser(
        "logout", help="Logout and revoke tokens"
    )

    # status command
    status_parser = license_subparsers.add_parser(
        "status", help="Show current license status"
    )
    status_parser.add_argument("--json", action="store_true", help="Output as JSON")
    status_parser.add_argument(
        "--project", help="Project path (default: current directory)"
    )

    # refresh command
    refresh_parser = license_subparsers.add_parser(
        "refresh", help="Refresh authentication tokens"
    )

    # claim-renpy command
    claim_renpy_parser = license_subparsers.add_parser(
        "claim-renpy", help="Claim free unlimited Ren'Py license"
    )
    claim_renpy_parser.add_argument(
        "--project", type=str, help="Path to Ren'Py project (for validation)"
    )

    return parser


def cmd_register(
    email: Optional[str] = None, project_path: Optional[str] = None
) -> int:
    """
    Register new BranchPy account.

    Args:
        email: Email address (optional, will prompt)
        project_path: Project path for Ren'Py auto-detection

    Returns:
        Exit code (0 = success, 1 = error)
    """
    try:
        import re

        import requests

        print("🎉 Welcome to BranchPy!")
        print()

        # Detect engine if project provided
        engine = None
        is_renpy = False
        if project_path:
            project = Path(project_path).resolve()
            if project.exists():
                engine = detection.detect_engine(project)
                is_renpy = engine == "renpy"
                if is_renpy:
                    print(f"✓ Ren'Py project detected: {project}")
                    print("  (You'll get free unlimited access!)")
                    print()

        # Prompt for email if not provided
        if not email:
            email = input("Email address: ").strip()
            if not email:
                print("❌ Email is required", file=sys.stderr)
                return 1

        # Validate email format
        email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if not re.match(email_pattern, email):
            print(f"❌ Invalid email format: {email}", file=sys.stderr)
            return 1

        # Prompt for password
        while True:
            password = getpass.getpass("Password (min 8 characters): ")
            if not password:
                print("❌ Password is required", file=sys.stderr)
                return 1

            if len(password) < 8:
                print("❌ Password must be at least 8 characters", file=sys.stderr)
                continue

            password_confirm = getpass.getpass("Confirm password: ")
            if password != password_confirm:
                print("❌ Passwords do not match", file=sys.stderr)
                continue

            break

        print()
        print("Creating account...", end="", flush=True)

        # Call registration API
        response = requests.post(
            f"{auth.API_BASE_URL}/v1/auth/register",
            json={
                "email": email,
                "password": password,
                "metadata": {"engine": engine, "source": "cli"},
            },
            timeout=10,
        )

        if response.status_code == 409:
            print(" ✗")
            print()
            print(f"❌ Account already exists: {email}", file=sys.stderr)
            print()
            print("Login instead:")
            print(f"  branchpy license login {email}")
            return 1

        if response.status_code == 400:
            error_detail = response.json().get("detail", "Bad request")
            print(" ✗")
            print()
            print(f"❌ {error_detail}", file=sys.stderr)
            return 1

        response.raise_for_status()
        data = response.json()

        # Save tokens
        auth_data = auth.build_auth_data(
            data,
            email,
            data.get("device_id") or auth.get_device_id(),
        )
        auth.save_auth_data(auth_data)

        print(" ✓")
        print()
        user = data.get("user") or {}
        registered_email = user.get("email") or data.get("email") or email
        registered_plan = user.get("plan") or data.get("plan") or data.get("tier")

        print(f"✓ Account created successfully: {registered_email}")
        if registered_plan:
            print(f"  Plan: {registered_plan.upper()}")
        print()

        # Offer Ren'Py claim if detected
        if is_renpy:
            print("🎉 Ren'Py project detected!")
            print()
            print("Claim your FREE unlimited license:")
            print("  branchpy license claim-renpy")
            print()
            print("All features unlocked (free forever) for Ren'Py projects.")
        else:
            print("Start using BranchPy:")
            print("  branchpy analyze --project your_project")
            print()
            if engine:
                recommended = detection.get_recommended_plan(engine, commercial=False)
                if recommended != "free":
                    print(f"For {detection.get_engine_display_name(engine)} projects:")
                    print("  See plans at https://branchpy.com/pricing")

        return 0

    except requests.exceptions.RequestException as e:
        print(f"\n❌ Network error: {e}", file=sys.stderr)
        print()
        print("Please check your internet connection and try again.")
        return 1
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}", file=sys.stderr)
        logs.error(
            "license.register_failed", msg="Register command failed", error=str(e)
        )
        return 1


def cmd_login(email: Optional[str] = None, password: Optional[str] = None) -> int:
    """
    Login command handler.

    Args:
        email: Email address (optional, will prompt)
        password: Password (optional, will prompt)

    Returns:
        Exit code (0 = success, 1 = error)
    """
    try:
        # Prompt for email if not provided
        if not email:
            email = input("Email: ").strip()
            if not email:
                print("Error: Email is required", file=sys.stderr)
                return 1

        # Prompt for password if not provided
        if not password:
            password = getpass.getpass("Password: ")
            if not password:
                print("Error: Password is required", file=sys.stderr)
                return 1

        print("Authenticating...", end="", flush=True)

        # Call login API
        result = auth.login(email, password)

        print(" ✓")
        print()
        user = result.get("user") or {}
        login_email = user.get("email") or result.get("email") or email
        login_plan = user.get("plan") or result.get("plan") or result.get("tier")

        print(f"✓ Successfully logged in as {login_email}")
        if login_plan:
            print(f"  Plan: {login_plan.upper()}")
        print()

        # Show features (first 5)
        try:
            features = entitlements.load_entitlements().get("features", [])
            if features:
                print("Available features:")
                for feature in features[:5]:
                    print(f"  • {feature}")
                if len(features) > 5:
                    print(f"  ... and {len(features) - 5} more")
                print()
        except Exception:
            pass  # Don't fail if we can't load entitlements

        print("Your credentials have been saved locally.")
        print("Use 'branchpy license status' to view your license information.")

        return 0

    except exceptions.AuthenticationError as e:
        print(f"\n✗ Authentication failed: {e}", file=sys.stderr)
        return 1
    except exceptions.LicenseError as e:
        print(f"\n✗ Error: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n✗ Login cancelled", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}", file=sys.stderr)
        logs.error("license.login_failed", msg="Login command failed", error=str(e))
        return 1


def cmd_logout() -> int:
    """
    Logout command handler.

    Returns:
        Exit code (0 = success, 1 = error)
    """
    try:
        # Check if authenticated
        if not auth.is_authenticated():
            print("You are not logged in.")
            return 0

        print("Logging out...", end="", flush=True)

        # Call logout API
        auth.logout()

        print(" ✓")
        print("✓ Successfully logged out")
        print("  Your tokens have been revoked and local credentials cleared.")

        return 0

    except exceptions.LicenseError as e:
        print(f"\n✗ Error: {e}", file=sys.stderr)
        # Still clear local auth even if API call fails
        try:
            auth.save_auth_data(None)
        except Exception:
            pass
        return 1
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}", file=sys.stderr)
        logs.error("license.logout_failed", msg="Logout command failed", error=str(e))
        return 1


def cmd_status(as_json: bool = False, project_path: Optional[str] = None) -> int:
    """
    Enhanced status command handler.

    Args:
        as_json: Output as JSON
        project_path: Project path for engine detection

    Returns:
        Exit code (0 = success, 1 = error)
    """
    # Determine project path
    if project_path:
        proj_path = Path(project_path).resolve()
    else:
        proj_path = Path.cwd()

    # Compute comprehensive status
    status = compute_license_status(proj_path)

    if as_json:
        import json

        data = status.to_json_dict()
        print(json.dumps(data, indent=2))
        return 0

    # Human-readable output
    _print_human_status(status)
    return 0


def _print_human_status(status) -> None:
    """
    Print human-readable license status.

    Args:
        status: LicenseStatus from compute_license_status()
    """
    account = status.account
    token = status.token
    project = status.project
    capabilities = status.capabilities

    print("BranchPy License Status")
    print("─" * 40)
    print()

    # Account
    print("Account")
    if not account.authenticated:
        print("  Status:     Not authenticated")
        print("  Plan:       UNREGISTERED")
    else:
        print("  Status:     Logged in")
        print(f"  Email:      {account.email}")
        print(f"  Plan:       {account.plan.upper() if account.plan else 'UNKNOWN'}")
        if account.source:
            source_label = account.source.replace("_", " ").title()
            print(f"  Source:     {source_label}")
    print()

    # Token
    print("Token")
    if not token.present:
        print("  Status:     No token on file")
    else:
        if token.issued_at:
            print(f"  Issued at:  {token.issued_at.strftime('%Y-%m-%d %H:%M')}")
        if token.expires_at:
            print(f"  Expires at: {token.expires_at.strftime('%Y-%m-%d %H:%M')}")
        if token.offline_days_remaining is not None:
            days = token.offline_days_remaining
            if days > 25:
                print(f"  Offline:    OK ({days} days remaining)")
            elif days > 5:
                print(f"  Offline:    ⚠ {days} days remaining (consider refreshing)")
            else:
                print(f"  Offline:    🔴 {days} days remaining (refresh soon!)")
    print()

    # Project
    print("Current Project")
    if project.path:
        print(f"  Path:       {project.path}")
    else:
        print("  Path:       (none)")

    if project.engine:
        engine_display = detection.get_engine_display_name(project.engine)
        print(f"  Engine:     {engine_display}")

        if project.renpy_free_eligible:
            if project.renpy_claimed:
                print("  License:    Ren'Py (all features free)")
            else:
                print("  License:    Ren'Py eligible (claim available!)")
    else:
        print("  Engine:     Unknown")
    print()

    # Capabilities (grouped)
    def flag(name: str) -> str:
        c = capabilities.get(name)
        if not c:
            return "?"
        return "✅" if c.allowed else "❌"

    def reason_hint(name: str) -> str:
        c = capabilities.get(name)
        if not c or c.allowed:
            return ""
        if c.reason == "unauthenticated":
            return " (requires authentication)"
        elif c.reason == "plan_blocked":
            # Specific upgrade hints
            if name in ("cloud_sync", "cloud_dashboard"):
                return " (requires Pro plan)"
            elif name in ("cloud_team", "team_admin"):
                return " (requires Team plan)"
            elif name == "federation":
                return " (requires Enterprise plan)"
            elif name in ("ai_review", "ai_docgen", "ai_explain"):
                return " (requires Pro plan)"
            elif name in ("pilot", "pfi", "doctor"):
                return " (requires Basic plan)"
            return " (requires upgrade)"
        elif c.reason == "renpy_claim_available":
            return " (claim Ren'Py for free access)"
        return ""

    print("Capabilities")
    print("  Core:")
    print(f"    pilot                {flag('pilot')}{reason_hint('pilot')}")
    print(f"    pfi                  {flag('pfi')}{reason_hint('pfi')}")
    print(f"    doctor               {flag('doctor')}{reason_hint('doctor')}")
    print(f"    tests                {flag('tests')}{reason_hint('tests')}")
    print("  AI:")
    print(f"    ai_review            {flag('ai_review')}{reason_hint('ai_review')}")
    print(f"    ai_docgen            {flag('ai_docgen')}{reason_hint('ai_docgen')}")
    print(f"    ai_explain           {flag('ai_explain')}{reason_hint('ai_explain')}")
    print("  Cloud:")
    print(f"    cloud_sync           {flag('cloud_sync')}{reason_hint('cloud_sync')}")
    print(
        f"    cloud_dashboard      {flag('cloud_dashboard')}{reason_hint('cloud_dashboard')}"
    )
    print("  Team:")
    print(f"    cloud_team           {flag('cloud_team')}{reason_hint('cloud_team')}")
    print(f"    team_admin           {flag('team_admin')}{reason_hint('team_admin')}")
    print(f"    federation           {flag('federation')}{reason_hint('federation')}")
    print()

    # Tips
    print("Tips")
    if not account.authenticated:
        print("  - Create account: branchpy license register")
        print("  - Or login: branchpy license login")
    elif project.renpy_free_eligible and not project.renpy_claimed:
        print("  - Claim FREE Ren'Py license: branchpy license claim-renpy")
        print("  - All features unlocked (free forever)")
    else:
        print("  - View as JSON: branchpy license status --json")
        if account.plan in ("free", "basic"):
            print("  - Upgrade for more features: https://branchpy.com/pricing")
    print()

    if token.offline_days_remaining and token.offline_days_remaining < 5:
        print("⚠ Warning: Token expiring soon. Refresh with: branchpy license refresh")
        print()


def cmd_refresh() -> int:
    """
    Refresh command handler.

    Returns:
        Exit code (0 = success, 1 = error)
    """
    try:
        # Check if authenticated
        if not auth.is_authenticated():
            print("Not logged in.", file=sys.stderr)
            print("Use 'branchpy license login' to authenticate.")
            return 1

        print("Refreshing tokens...", end="", flush=True)

        # Call refresh API
        auth.refresh_token()

        print(" ✓")
        print("✓ Tokens refreshed successfully")

        # Show updated plan
        try:
            ents = entitlements.load_entitlements()
            print(f"  Plan: {ents.get('plan', 'free').upper()}")
            print(f"  Features: {len(ents.get('features', []))}")
        except Exception:
            pass

        return 0

    except exceptions.RefreshTokenRevokedError:
        print("\n✗ Refresh token has been revoked", file=sys.stderr)
        print("Please login again: branchpy license login")
        return 1
    except exceptions.TokenExpiredError:
        print("\n✗ Refresh token has expired", file=sys.stderr)
        print("Please login again: branchpy license login")
        return 1
    except exceptions.LicenseError as e:
        print(f"\n✗ Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}", file=sys.stderr)
        logs.error("license.refresh_failed", msg="Refresh command failed", error=str(e))
        return 1


def cmd_claim_renpy(project_path: Optional[str] = None) -> int:
    """
    Claim free unlimited Ren'Py license.

    Args:
        project_path: Optional path to Ren'Py project for validation

    Returns:
        Exit code
    """
    try:
        # Check if authenticated
        if not auth.is_authenticated():
            print("❌ You must be logged in to claim a Ren'Py license", file=sys.stderr)
            print()
            print("Create a free account:")
            print("  branchpy license register")
            print()
            print("Or login:")
            print("  branchpy license login your@email.com")
            return 1

        # Detect engine if project path provided
        engine = None
        if project_path:
            project = Path(project_path).resolve()
            if not project.exists():
                print(f"❌ Project path does not exist: {project}", file=sys.stderr)
                return 1

            engine = detection.detect_engine(project)

            if engine != "renpy":
                print(f"❌ Ren'Py engine not detected in: {project}", file=sys.stderr)
                print(
                    f"   Detected engine: {detection.get_engine_display_name(engine) if engine else 'Unknown'}"
                )
                print()
                print("The Ren'Py license is only available for Ren'Py projects.")
                print("For other engines, see: https://branchpy.com/pricing")
                return 1

            print(f"[OK] Ren'Py engine detected: {project}")
        else:
            print(
                "[WARNING] No project path provided - claiming without engine validation"
            )
            print("  (The Ren'Py license is based on honor system)")

        print()
        print("Claiming Ren'Py license...", end="", flush=True)

        # Call claim API
        import requests

        from branchpy.license.auth import API_BASE_URL, get_access_token

        access_token = get_access_token()
        if not access_token:
            print("\n❌ No access token found", file=sys.stderr)
            print("Please login again: branchpy license login")
            return 1

        response = requests.post(
            f"{API_BASE_URL}/v1/claim/renpy",
            headers={"Authorization": f"Bearer {access_token}"},
            json={
                "project_path": str(project_path) if project_path else None,
                "engine_evidence": {"engine": engine} if engine else None,
            },
            timeout=10,
        )

        if response.status_code == 400:
            error_detail = response.json().get("detail", "Bad request")
            print(f"\n❌ {error_detail}", file=sys.stderr)
            return 1

        response.raise_for_status()
        data = response.json()

        # Save new license token
        license_token = data.get("license_token")
        if license_token:
            auth_data = auth.load_auth_data()
            auth_data["license_token"] = license_token
            auth.save_auth_data(auth_data)

            # Force entitlements cache refresh so next command sees renpy plan
            from branchpy.license import entitlements

            entitlements.clear_cache()

        print(" ✓")
        print()
        print(data.get("message", "✓ Ren'Py license activated"))
        print()
        print("🎉 All features unlocked (free forever):")
        print("  • Pilot Mode (visual graph navigation)")
        print("  • Project Function Index")
        print("  • Full diagnostics")
        print("  • AI-powered features")
        print("  • Patch engine")
        print("  • Cloud sync")
        print("  • And more!")
        print()
        print("Start using: branchpy stats2 --project your_renpy_game")

        return 0

    except requests.exceptions.RequestException as e:
        print(f"\n❌ Network error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}", file=sys.stderr)
        logs.error(
            "license.claim_renpy_failed",
            msg="Claim Ren'Py command failed",
            error=str(e),
        )
        return 1


def run(args):
    """
    Main entry point for license command.

    Args:
        args: Parsed arguments from argparse

    Returns:
        Exit code
    """
    action = getattr(args, "license_action", None)

    if not action:
        print("Usage: branchpy license <command>", file=sys.stderr)
        print()
        print("Commands:")
        print("  register    - Create new BranchPy account")
        print("  login       - Authenticate with BranchPy account")
        print("  logout      - Logout and revoke tokens")
        print("  status      - Show current license status")
        print("  refresh     - Refresh authentication tokens")
        print("  claim-renpy - Claim free unlimited Ren'Py license")
        print()
        print("Run 'branchpy license <command> --help' for more information")
        return 1

    if action == "register":
        return cmd_register(
            email=getattr(args, "email", None),
            project_path=getattr(args, "project", None),
        )
    elif action == "login":
        return cmd_login(
            email=getattr(args, "email", None), password=getattr(args, "password", None)
        )
    elif action == "logout":
        return cmd_logout()
    elif action == "status":
        return cmd_status(
            as_json=getattr(args, "json", False),
            project_path=getattr(args, "project", None),
        )
    elif action == "refresh":
        return cmd_refresh()
    elif action == "claim-renpy":
        return cmd_claim_renpy(project_path=getattr(args, "project", None))
    else:
        print(f"Unknown license command: {action}", file=sys.stderr)
        return 1
