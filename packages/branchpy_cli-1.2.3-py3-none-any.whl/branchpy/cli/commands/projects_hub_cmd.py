"""
branchpy.cli.commands.projects_hub_cmd — Projects CLI commands (v0.9.3).

Commands:
- branchpy projects list: List all projects with filtering
- branchpy projects show <project_id>: Show project details
- branchpy projects create: Create new project

v0.9.3 — Federation & Cloud Collaboration (local-only foundation)
"""

import click
from rich.console import Console
from rich.table import Table

from branchpy.hub import HubClient
from branchpy.rbac import PermissionDenied

console = Console()


@click.group(name="projects")
def projects_group():
    """Project management commands (v0.9.3 Hub API)."""
    pass


@projects_group.command(name="list")
@click.option("--org", "-o", help="Filter by organization ID")
@click.option("--owner", help="Filter by owner user ID")
@click.option(
    "--type", "-t", "project_type", help="Filter by project type (vn, regular, etc.)"
)
@click.option("--tag", multiple=True, help="Filter by tags (can specify multiple)")
def list_projects_cmd(org: str, owner: str, project_type: str, tag: tuple):
    """
    List all projects with optional filtering.

    Examples:
        branchpy projects list
        branchpy projects list --type vn
        branchpy projects list --tag demo --tag experimental

    Requires: stats.read or analyze.read permission
    """
    try:
        hub = HubClient()

        # Check permission (at least read access required)
        from branchpy.rbac import Permission, check_permission

        try:
            check_permission(Permission.STATS_READ, raise_on_deny=False)
        except Exception:
            check_permission(Permission.ANALYZE_READ)

        # Get current user for default org
        user = hub.get_current_user()
        org_id = org or user.org_id

        # List projects
        projects = hub.list_projects(
            org_id=org_id,
            owner_user_id=owner,
            project_type=project_type,
            tags=list(tag) if tag else None,
        )

        if not projects:
            console.print("[yellow]No projects found.[/yellow]")
            return

        # Display projects in table
        table = Table(title=f"Projects ({len(projects)} total)")
        table.add_column("Project ID", style="cyan")
        table.add_column("Name", style="bold")
        table.add_column("Type", style="green")
        table.add_column("Owner", style="dim")
        table.add_column("Tags", style="magenta")
        table.add_column("Updated", style="dim")

        for project in projects:
            table.add_row(
                project.project_id[:8] + "...",  # Truncate for display
                project.name,
                project.project_type,
                project.owner_user_id,
                ", ".join(project.tags) if project.tags else "—",
                project.updated_at.strftime("%Y-%m-%d"),
            )

        console.print(table)

    except PermissionDenied as e:
        console.print(f"[bold red]✗ Permission denied:[/bold red] {e}")
        raise click.Abort()
    except ValueError as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        raise click.Abort()


@projects_group.command(name="show")
@click.argument("project_id")
def show_project_cmd(project_id: str):
    """
    Show detailed information about a project.

    Example:
        branchpy projects show my-vn-project

    Requires: stats.read or analyze.read permission
    """
    try:
        hub = HubClient()

        # Check permission
        from branchpy.rbac import Permission, check_permission

        try:
            check_permission(Permission.STATS_READ, raise_on_deny=False)
        except Exception:
            check_permission(Permission.ANALYZE_READ)

        # Get project
        project = hub.get_project(project_id)

        # Display project details
        table = Table(title=f"Project: {project.name}", show_header=False)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="bold")

        table.add_row("Project ID", project.project_id)
        table.add_row("Name", project.name)
        table.add_row("Type", project.project_type)
        table.add_row("Organization", project.org_id)
        table.add_row("Owner", project.owner_user_id)
        table.add_row("Tags", ", ".join(project.tags) if project.tags else "—")
        table.add_row("Created", project.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"))
        table.add_row("Updated", project.updated_at.strftime("%Y-%m-%d %H:%M:%S UTC"))

        if project.metadata:
            table.add_row("Metadata", str(project.metadata))

        console.print(table)

    except PermissionDenied as e:
        console.print(f"[bold red]✗ Permission denied:[/bold red] {e}")
        raise click.Abort()
    except ValueError as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        raise click.Abort()


@projects_group.command(name="create")
@click.option("--name", "-n", required=True, help="Project name")
@click.option(
    "--type",
    "-t",
    "project_type",
    required=True,
    help="Project type (vn, regular, etc.)",
)
@click.option("--tag", multiple=True, help="Project tags (can specify multiple)")
def create_project_cmd(name: str, project_type: str, tag: tuple):
    """
    Create a new project.

    Example:
        branchpy projects create --name "My VN" --type vn --tag demo --tag experimental

    Requires: hub.project.create permission
    """
    try:
        hub = HubClient()

        # Create project (permission check is in hub_client.create_project)
        project = hub.create_project(
            name=name,
            project_type=project_type,
            tags=list(tag) if tag else None,
        )

        console.print("[bold green]✓ Project created successfully![/bold green]")
        console.print(f"  Project ID: {project.project_id}")
        console.print(f"  Name: {project.name}")
        console.print(f"  Type: {project.project_type}")

        if project.tags:
            console.print(f"  Tags: {', '.join(project.tags)}")

    except PermissionDenied as e:
        console.print(f"[bold red]✗ Permission denied:[/bold red] {e}")
        console.print("  You need 'hub.project.create' permission.")
        raise click.Abort()
    except ValueError as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        raise click.Abort()


# ============================================================================
# Legacy CLI Integration (for branchpy.cli.py _CMD_MAP registration)
# ============================================================================


def add_parser(subparsers):
    """
    Legacy argparse integration (if needed).

    Note: Click is preferred for v0.9.3+ commands.
    """
    pass


def run(args):
    """
    Legacy entry point for argparse-based dispatch.

    Routes to Click commands.
    """
    pass
