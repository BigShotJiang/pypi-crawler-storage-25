#!/usr/bin/env python3
"""
WebSocket Daemon CLI Command
=============================

Manage the BranchPy WebSocket daemon for instant dashboard/trend commands.

Commands:
    branchpy ws start   -- Start daemon
    branchpy ws stop    -- Stop daemon
    branchpy ws status  -- Show daemon status
    branchpy ws restart -- Restart daemon
    branchpy ws ping    -- Ping daemon and measure latency
"""

import argparse
import os


def build_arg_parser(subparsers):
    """Build argument parser for 'ws' command."""
    parser = subparsers.add_parser(
        "ws",
        help="Manage WebSocket daemon",
        description="Manage the BranchPy WebSocket daemon for instant dashboard access",
    )

    # Subcommands
    ws_subs = parser.add_subparsers(dest="action", required=True, help="Daemon action")

    # Common arguments for all subcommands
    def add_common_args(p):
        p.add_argument(
            "--host",
            default=os.getenv("BRANCHPY_WS_HOST", "127.0.0.1"),
            help="WebSocket host (default: 127.0.0.1)",
        )
        p.add_argument(
            "--port",
            type=int,
            default=int(os.getenv("BRANCHPY_WS_PORT", "8765")),
            help="WebSocket port (default: 8765)",
        )
        p.add_argument(
            "--profile",
            default="default",
            help="Daemon profile name (default: default)",
        )
        p.add_argument(
            "--runtime-dir",
            default=os.path.expanduser("~/.branchpy/wsd"),
            help="Runtime directory for PID/meta files (default: ~/.branchpy/wsd)",
        )
        p.add_argument(
            "--project-root",
            default=None,
            help="Project root directory to watch (default: current directory)",
        )
        p.add_argument(
            "--log-level",
            default="info",
            choices=["debug", "info", "warning", "error"],
            help="Logging level (default: info)",
        )

    # start
    start_parser = ws_subs.add_parser(
        "start",
        help="Start WebSocket daemon",
        description="Start a persistent WebSocket daemon process",
    )
    add_common_args(start_parser)

    # stop
    stop_parser = ws_subs.add_parser(
        "stop",
        help="Stop WebSocket daemon",
        description="Gracefully stop the WebSocket daemon",
    )
    add_common_args(stop_parser)

    # status
    status_parser = ws_subs.add_parser(
        "status",
        help="Show daemon status",
        description="Display current daemon status and health",
    )
    add_common_args(status_parser)
    status_parser.add_argument(
        "--json", action="store_true", help="Output status in JSON format"
    )

    # restart
    restart_parser = ws_subs.add_parser(
        "restart",
        help="Restart WebSocket daemon",
        description="Stop and then start the daemon",
    )
    add_common_args(restart_parser)

    # ping
    ping_parser = ws_subs.add_parser(
        "ping",
        help="Ping daemon and measure latency",
        description="Check daemon health and measure response time",
    )
    add_common_args(ping_parser)
    ping_parser.add_argument(
        "--runs", type=int, default=5, help="Number of ping probes (default: 5)"
    )

    # subscribe (v0.7.28)
    subscribe_parser = ws_subs.add_parser(
        "subscribe",
        help="Subscribe to report auto-refresh",
        description="Enable auto-refresh for specific report types",
    )
    add_common_args(subscribe_parser)
    subscribe_parser.add_argument(
        "reports",
        nargs="+",
        choices=["analyze", "stats", "stats2", "images"],
        help="Report types to subscribe to",
    )
    subscribe_parser.add_argument(
        "--client", default="cli", help="Client ID (default: cli)"
    )

    # unsubscribe (v0.7.28)
    unsubscribe_parser = ws_subs.add_parser(
        "unsubscribe",
        help="Unsubscribe from report auto-refresh",
        description="Disable auto-refresh for specific report types",
    )
    add_common_args(unsubscribe_parser)
    unsubscribe_parser.add_argument(
        "reports",
        nargs="*",
        choices=["analyze", "stats", "stats2", "images"],
        help="Report types to unsubscribe from (omit for all)",
    )
    unsubscribe_parser.add_argument(
        "--client", default="cli", help="Client ID (default: cli)"
    )

    # watch (v0.7.28)
    watch_parser = ws_subs.add_parser(
        "watch",
        help="Control file watching",
        description="Enable or disable automatic file watching",
    )
    add_common_args(watch_parser)
    watch_parser.add_argument(
        "watch_action",
        choices=["enable", "disable", "status"],
        help="Watch control action",
    )

    return parser


def run_ws_cmd(args):
    """Execute ws command based on action."""
    from branchpy.ws.daemon import (
        ping,
        read_status,
        restart_daemon,
        start_daemon,
        stop_daemon,
    )

    action = args.action

    if action == "start":
        return start_daemon(args)
    elif action == "stop":
        return stop_daemon(args)
    elif action == "status":
        return read_status(args)
    elif action == "restart":
        return restart_daemon(args)
    elif action == "ping":
        return ping(args)
    elif action == "subscribe":
        return ws_subscribe(args)
    elif action == "unsubscribe":
        return ws_unsubscribe(args)
    elif action == "watch":
        return ws_watch(args)
    else:
        print(f"Unknown action: {action}")
        return 2


def ws_subscribe(args):
    """Subscribe to report auto-refresh."""
    import asyncio
    import json

    import websockets

    async def send_subscribe():
        uri = f"ws://{args.host}:{args.port}"
        try:
            async with websockets.connect(uri, timeout=5.0) as ws:
                # Send subscribe message
                msg = {
                    "type": "watch.subscribe",
                    "clientId": args.client,
                    "reports": args.reports,
                }
                await ws.send(json.dumps(msg))

                # Wait for response
                response = await asyncio.wait_for(ws.recv(), timeout=5.0)
                data = json.loads(response)

                if data.get("type") == "watch.subscribed":
                    print(f"✓ Subscribed to: {', '.join(args.reports)}")
                    print(f"  Client ID: {args.client}")
                    if data.get("activeReports"):
                        print(f"  Active reports: {', '.join(data['activeReports'])}")
                    return 0
                else:
                    print(f"⚠ Unexpected response: {response}")
                    return 1
        except Exception as e:
            print(f"✗ Failed to subscribe: {e}")
            return 3

    return asyncio.run(send_subscribe())


def ws_unsubscribe(args):
    """Unsubscribe from report auto-refresh."""
    import asyncio
    import json

    import websockets

    async def send_unsubscribe():
        uri = f"ws://{args.host}:{args.port}"
        try:
            async with websockets.connect(uri, timeout=5.0) as ws:
                # Send unsubscribe message
                msg = {"type": "watch.unsubscribe", "clientId": args.client}
                if args.reports:
                    msg["reports"] = args.reports

                await ws.send(json.dumps(msg))

                # Wait for response
                response = await asyncio.wait_for(ws.recv(), timeout=5.0)
                data = json.loads(response)

                if data.get("type") == "watch.unsubscribed":
                    if args.reports:
                        print(f"✓ Unsubscribed from: {', '.join(args.reports)}")
                    else:
                        print("✓ Unsubscribed from all reports")
                    print(f"  Client ID: {args.client}")
                    return 0
                else:
                    print(f"⚠ Unexpected response: {response}")
                    return 1
        except Exception as e:
            print(f"✗ Failed to unsubscribe: {e}")
            return 3

    return asyncio.run(send_unsubscribe())


def ws_watch(args):
    """Control file watching."""
    import asyncio
    import json

    import websockets

    async def send_watch_command():
        uri = f"ws://{args.host}:{args.port}"
        try:
            async with websockets.connect(uri, timeout=5.0) as ws:
                # Send watch command
                if args.watch_action == "enable":
                    msg = {"type": "watch.enable"}
                elif args.watch_action == "disable":
                    msg = {"type": "watch.disable"}
                else:  # status
                    msg = {"type": "watch.status"}

                await ws.send(json.dumps(msg))

                # Wait for response
                response = await asyncio.wait_for(ws.recv(), timeout=5.0)
                data = json.loads(response)

                if data.get("type") == "watch.status":
                    enabled = data.get("enabled", False)
                    active = data.get("activeReports", [])
                    subs = data.get("subscribers", 0)

                    print("Watch Status:")
                    print(f"  Enabled: {'✓' if enabled else '✗'}")
                    print(
                        f"  Active reports: {', '.join(active) if active else '(none)'}"
                    )
                    print(f"  Subscribers: {subs}")
                    return 0
                else:
                    print(f"Response: {json.dumps(data, indent=2)}")
                    return 0
        except Exception as e:
            print(f"✗ Failed to send watch command: {e}")
            return 3

    return asyncio.run(send_watch_command())


if __name__ == "__main__":
    # For testing/standalone use
    parser = argparse.ArgumentParser()
    subs = parser.add_subparsers()
    build_arg_parser(subs)
    args = parser.parse_args()
    exit(run_ws_cmd(args))
