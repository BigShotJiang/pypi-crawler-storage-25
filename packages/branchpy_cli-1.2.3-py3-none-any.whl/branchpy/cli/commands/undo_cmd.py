"""
Undo command - revert last BranchPy operation.
"""

import click

from branchpy.history.journal import get_journal
from branchpy.telemetry import emit_event


@click.command("undo")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed patch information")
def undo_cmd(verbose: bool) -> None:
    """
    Undo the last BranchPy operation.

    This reverts the last operation that modified files, such as:
    - Merge operations
    - Media autofix/relink
    - Any other reversible BranchPy operation

    The operation can be redone later using 'branchpy redo'.
    """
    journal = get_journal()

    if not journal.can_undo():
        click.echo("Nothing to undo.")
        return

    # Emit telemetry
    emit_event("journal.operation.undo.started", {})

    try:
        patch = journal.undo()

        if patch is None:
            click.echo("Nothing to undo.")
            emit_event(
                "journal.operation.undo.completed",
                {"success": False, "reason": "empty_stack"},
            )
            return

        # Success
        click.echo(f"✓ Undid: {patch.describe()}")

        if verbose:
            click.echo("\nPatch details:")
            click.echo(f"  {patch.to_dict()}")

        emit_event(
            "journal.operation.undo.completed",
            {
                "success": True,
                "patch_description": patch.describe(),
            },
        )

    except Exception as e:
        click.echo(f"✗ Error during undo: {e}", err=True)
        emit_event("journal.operation.undo.failed", {"error": str(e)})
        raise
