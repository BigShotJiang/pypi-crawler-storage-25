# branchpy/cli/commands/ai_report_cmd.py
"""
AI Usage Report Command — Query governance logs for AI call statistics.

Usage:
    branchpy ai report [--days N] [--provider PROVIDER] [--capability CAPABILITY] [--json]
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy.core.governance.logger import GovernanceLogger
from branchpy.core.governance.schemas import (
    EVENT_AI_CALL_END,
    EVENT_AI_CALL_ERROR,
    EVENT_AI_CALL_START,
)


def _parse_timestamp(ts: Optional[str]) -> datetime:
    """Parse ISO 8601 timestamp or return epoch if invalid."""
    if not ts:
        return datetime.min

    try:
        # Handle both 'Z' and '+00:00' formats
        ts_clean = ts.replace("Z", "+00:00")
        return datetime.fromisoformat(ts_clean).replace(tzinfo=None)
    except (ValueError, AttributeError):
        return datetime.min


def ai_report_command(
    days: int = 7,
    provider: Optional[str] = None,
    capability: Optional[str] = None,
    json_output: bool = False,
    project_path: Optional[Path] = None,
) -> int:
    """
    Generate AI usage report from governance logs.

    Args:
        days: Number of days to look back (default: 7)
        provider: Filter by provider ID (e.g., "openai", "anthropic")
        capability: Filter by capability (e.g., "code_review", "doc_gen")
        json_output: Output JSON instead of formatted text
        project_path: Project path (defaults to current directory)

    Returns:
        Exit code (0 = success)
    """
    # Initialize governance logger
    if project_path is None:
        project_path = Path.cwd()

    logger = GovernanceLogger(project_root=project_path)

    # Calculate cutoff time
    cutoff = datetime.utcnow() - timedelta(days=days)

    # Query events
    start_events = logger.query_events(event_type=EVENT_AI_CALL_START, limit=10000)
    end_events = logger.query_events(event_type=EVENT_AI_CALL_END, limit=10000)
    error_events = logger.query_events(event_type=EVENT_AI_CALL_ERROR, limit=10000)

    # Filter by time
    start_events = [
        e for e in start_events if _parse_timestamp(e.get("timestamp")) >= cutoff
    ]
    end_events = [
        e for e in end_events if _parse_timestamp(e.get("timestamp")) >= cutoff
    ]
    error_events = [
        e for e in error_events if _parse_timestamp(e.get("timestamp")) >= cutoff
    ]

    # Apply filters
    if provider:
        start_events = [
            e
            for e in start_events
            if e.get("context", {}).get("provider_id") == provider
        ]
        end_events = [
            e for e in end_events if e.get("context", {}).get("provider_id") == provider
        ]
        error_events = [
            e
            for e in error_events
            if e.get("context", {}).get("provider_id") == provider
        ]

    if capability:
        start_events = [
            e
            for e in start_events
            if e.get("context", {}).get("capability") == capability
        ]
        end_events = [
            e
            for e in end_events
            if e.get("context", {}).get("capability") == capability
        ]
        error_events = [
            e
            for e in error_events
            if e.get("context", {}).get("capability") == capability
        ]

    # Build correlation map for end events
    end_by_correlation: Dict[str, Dict[str, Any]] = {}
    for event in end_events:
        corr_id = event.get("correlation_id")
        if corr_id:
            end_by_correlation[corr_id] = event

    # Aggregate statistics
    stats_by_provider: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: {
            "calls": 0,
            "errors": 0,
            "total_tokens": 0,
            "total_latency_ms": 0,
            "capabilities": defaultdict(int),
            "redactions": {"emails": 0, "paths": 0, "secrets": 0},
        }
    )

    # Process start events with matched end events
    for start_event in start_events:
        corr_id = start_event.get("correlation_id")
        context = start_event.get("context", {})
        provider_id = context.get("provider_id", "unknown")
        cap = context.get("capability", "unknown")

        stats = stats_by_provider[provider_id]
        stats["calls"] += 1
        stats["capabilities"][cap] += 1

        # Redaction counts
        stats["redactions"]["emails"] += context.get("emails_redacted", 0)
        stats["redactions"]["paths"] += context.get("paths_redacted", 0)
        stats["redactions"]["secrets"] += context.get("secrets_redacted", 0)

        # Match with end event for token/latency data
        if corr_id in end_by_correlation:
            end_event = end_by_correlation[corr_id]
            end_context = end_event.get("context", {})

            token_usage = end_context.get("token_usage", {})
            stats["total_tokens"] += token_usage.get("total", 0)
            stats["total_latency_ms"] += end_context.get("latency_ms", 0)

    # Count errors
    for error_event in error_events:
        context = error_event.get("context", {})
        provider_id = context.get("provider_id", "unknown")
        stats_by_provider[provider_id]["errors"] += 1

    # Generate report
    if json_output:
        import json

        report = {
            "period_days": days,
            "filters": {
                "provider": provider,
                "capability": capability,
            },
            "providers": dict(stats_by_provider),
            "summary": {
                "total_calls": sum(s["calls"] for s in stats_by_provider.values()),
                "total_errors": sum(s["errors"] for s in stats_by_provider.values()),
                "total_tokens": sum(
                    s["total_tokens"] for s in stats_by_provider.values()
                ),
            },
        }
        print(json.dumps(report, indent=2))
    else:
        _print_text_report(stats_by_provider, days, provider, capability)

    return 0


def _print_text_report(
    stats_by_provider: Dict[str, Dict[str, Any]],
    days: int,
    provider_filter: Optional[str],
    capability_filter: Optional[str],
) -> None:
    """Print formatted text report."""
    print(f"\n=== AI Usage Report (Last {days} days) ===\n")

    if provider_filter:
        print(f"Provider Filter: {provider_filter}")
    if capability_filter:
        print(f"Capability Filter: {capability_filter}")
    if provider_filter or capability_filter:
        print()

    if not stats_by_provider:
        print("No AI calls found in the specified period.")
        return

    # Overall summary
    total_calls = sum(s["calls"] for s in stats_by_provider.values())
    total_errors = sum(s["errors"] for s in stats_by_provider.values())
    total_tokens = sum(s["total_tokens"] for s in stats_by_provider.values())

    print(f"Total Calls: {total_calls}")
    print(f"Total Errors: {total_errors}")
    print(f"Total Tokens: {total_tokens:,}")
    print()

    # Per-provider breakdown
    for provider_id in sorted(stats_by_provider.keys()):
        stats = stats_by_provider[provider_id]
        print(f"Provider: {provider_id}")
        print(f"  Calls: {stats['calls']}")
        print(f"  Errors: {stats['errors']}")
        print(f"  Tokens: {stats['total_tokens']:,}")

        if stats["calls"] > 0:
            avg_latency = stats["total_latency_ms"] / stats["calls"]
            print(f"  Avg Latency: {avg_latency:.0f}ms")

        # Capabilities breakdown
        caps = stats["capabilities"]
        if caps:
            print("  Capabilities:")
            for cap, count in sorted(caps.items()):
                print(f"    {cap}: {count}")

        # Redaction stats
        redactions = stats["redactions"]
        total_redacted = (
            redactions["emails"] + redactions["paths"] + redactions["secrets"]
        )
        if total_redacted > 0:
            print(
                f"  Redactions: {total_redacted} (emails: {redactions['emails']}, paths: {redactions['paths']}, secrets: {redactions['secrets']})"
            )

        print()
