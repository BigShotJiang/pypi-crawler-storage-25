"""
BranchPy L10n Audit CLI Command (BPY-710)

Validates localization coverage across multiple language files.
Detects missing translations and orphaned keys.

Usage:
    bpy l10n audit [OPTIONS]

Examples:
    # Basic usage (auto-detect all locales)
    bpy l10n audit

    # Specify base and target locales
    bpy l10n audit --base game/tl/english --locales game/tl/spanish,game/tl/french

    # CI mode (fail if below threshold)
    bpy l10n audit --strict --min-coverage 90

    # Custom output file
    bpy l10n audit --output reports/l10n-coverage.json
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from branchpy.config import get_ignore_patterns, load_config
from branchpy.contract import VERSION, Exit
from branchpy.localization.coverage_utils import (
    compare_to_baseline_and_enforce,
    coverage_summary,
    save_baseline,
)
from branchpy.localization.validators import (
    suggest_bcp47_correction,
    validate_bcp47_tag,
)


def _write_json_output(payload: Dict[str, Any], out_path: Optional[str] = None) -> None:
    """Write JSON output to file or stdout.

    Args:
        payload: Report dictionary
        out_path: Output file path, or None/'-' for stdout
    """
    json_data = json.dumps(payload, indent=2, ensure_ascii=False)

    if not out_path or out_path == "-":
        print(json_data)
    else:
        try:
            output_file = Path(out_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_text(json_data, encoding="utf-8")
            print(f"✅ Report written to: {output_file}", file=sys.stderr)
        except Exception as e:
            print(f"Error writing output file: {e}", file=sys.stderr)
            sys.exit(1)


def _write_text_output(report: Dict[str, Any], out_path: Optional[str] = None) -> None:
    """Write text output to file or stdout.

    Args:
        report: Report dictionary
        out_path: Output file path, or None/'-' for stdout
    """
    lines = []
    lines.append("=" * 60)
    lines.append("  BranchPy L10n Coverage Audit")
    lines.append("=" * 60)
    lines.append(f"Timestamp: {report.get('timestamp', 'N/A')}")
    lines.append(f"Version: {report.get('version', 'N/A')}")
    lines.append("")

    localization = report.get("localization", {})
    lines.append(f"Base Locale: {localization.get('base_locale', 'N/A')}")
    lines.append(f"Target Locales: {', '.join(localization.get('target_locales', []))}")
    lines.append(f"Minimum Coverage: {localization.get('min_coverage', 0)}%")
    lines.append("")

    coverage_data = localization.get("coverage", {})
    below_threshold = localization.get("below_threshold", [])

    lines.append("Coverage Results:")
    for locale_name in sorted(coverage_data.keys()):
        cov = coverage_data[locale_name]
        status = "❌" if locale_name in below_threshold else "✅"
        lines.append(
            f"  {status} {locale_name}: {cov.get('coverage_percent', 0):.1f}% ({cov.get('covered', 0)}/{cov.get('total', 0)} keys)"
        )

    warnings = localization.get("validation_warnings", [])
    if warnings:
        lines.append("")
        lines.append("Validation Warnings:")
        for warning in warnings:
            lines.append(f"  ⚠️  {warning}")

    lines.append("=" * 60)
    lines.append("")

    text_output = "\n".join(lines)

    if not out_path or out_path == "-":
        print(text_output)
    else:
        try:
            output_file = Path(out_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_text(text_output, encoding="utf-8")
            print(f"✅ Report written to: {output_file}", file=sys.stderr)
        except Exception as e:
            print(f"Error writing output file: {e}", file=sys.stderr)
            sys.exit(1)


def parse_rpy_locale_keys(
    locale_dir: Path,
    validate_tags: bool = True,
    ignore_patterns: Optional[List[str]] = None,
) -> Tuple[Set[str], List[str]]:
    """
    Parse all .rpy files in a locale directory and extract translation keys.

    Args:
        locale_dir: Path to locale directory (e.g., game/tl/english)
        validate_tags: If True, validate BCP-47 language tags
        ignore_patterns: List of glob patterns to ignore (e.g., ["**/*_test.rpy"])

    Returns:
        Tuple of (keys_set, warnings_list)
        - keys_set: Set of translation keys found in the locale
        - warnings_list: List of BCP-47 validation warnings

    Example .rpy structure:
        translate english greeting_morning:
            "Good morning!"
    """
    keys = set()
    warnings = []
    seen_tags = set()
    ignore_patterns = ignore_patterns or []

    if not locale_dir.exists():
        return keys, warnings

    # Validate directory name as BCP-47 tag
    dir_name = locale_dir.name
    if validate_tags:
        is_valid, error = validate_bcp47_tag(dir_name)
        if not is_valid:
            suggestion = suggest_bcp47_correction(dir_name)
            if suggestion:
                warnings.append(
                    f"Locale directory '{dir_name}': {error}. Suggestion: '{suggestion}'"
                )
            else:
                warnings.append(f"Locale directory '{dir_name}': {error}")

    for rpy_file in locale_dir.rglob("*.rpy"):
        # Check ignore patterns
        should_ignore = False
        for pattern in ignore_patterns:
            if rpy_file.match(pattern):
                should_ignore = True
                break

        if should_ignore:
            continue

        try:
            with open(rpy_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    # Match: translate <lang> <key>:
                    if line.startswith("translate ") and line.endswith(":"):
                        parts = line.split()
                        if len(parts) >= 3:
                            # parts[0] = "translate"
                            # parts[1] = language
                            # parts[2] = key (without trailing colon)
                            lang_tag = parts[1]
                            key = parts[2].rstrip(":")
                            keys.add(key)

                            # Validate language tag in translate statement
                            if validate_tags and lang_tag not in seen_tags:
                                seen_tags.add(lang_tag)
                                is_valid, error = validate_bcp47_tag(lang_tag)
                                if not is_valid:
                                    suggestion = suggest_bcp47_correction(lang_tag)
                                    if suggestion:
                                        warnings.append(
                                            f"{rpy_file.name}: Language tag '{lang_tag}': {error}. "
                                            f"Suggestion: '{suggestion}'"
                                        )
                                    else:
                                        warnings.append(
                                            f"{rpy_file.name}: Language tag '{lang_tag}': {error}"
                                        )
        except Exception as e:
            print(f"Warning: Could not parse {rpy_file}: {e}", file=sys.stderr)
            continue

    return keys, warnings


def calculate_coverage(base_keys: Set[str], target_keys: Set[str]) -> Dict[str, Any]:
    """
    Calculate localization coverage metrics.

    Args:
        base_keys: Set of keys from base locale (source of truth)
        target_keys: Set of keys from target locale

    Returns:
        Dict with coverage metrics:
            - total_keys: int
            - missing_keys: int (in base, not in target)
            - orphan_keys: int (in target, not in base)
            - coverage_pct: float
            - missing_key_list: list of str
            - orphan_key_list: list of str
    """
    total = len(base_keys)
    missing = base_keys - target_keys
    orphans = target_keys - base_keys

    coverage_pct = ((total - len(missing)) / total * 100.0) if total > 0 else 100.0

    return {
        "total_keys": total,
        "missing_keys": len(missing),
        "orphan_keys": len(orphans),
        "coverage_pct": round(coverage_pct, 2),
        "missing_key_list": sorted(list(missing)),
        "orphan_key_list": sorted(list(orphans)),
    }


def auto_detect_locales(project_root: Path) -> List[Path]:
    """
    Auto-detect all locale directories in game/tl/*.

    Args:
        project_root: Path to project root (contains game/ directory)

    Returns:
        List of locale directory paths
    """
    tl_dir = project_root / "game" / "tl"
    if not tl_dir.exists():
        return []

    # Find all subdirectories in tl/ (each is a locale)
    locales = [d for d in tl_dir.iterdir() if d.is_dir()]
    return sorted(locales)


def run_l10n_audit(
    base_locale: Path,
    target_locales: List[Path],
    min_coverage: float,
    strict: bool,
    output: Optional[Path],
    output_format: str,
    validate_tags: bool,
    ignore_patterns: Optional[List[str]],
    save_baseline_flag: bool = False,
    compare_baseline_flag: bool = False,
    coverage_locale: Optional[str] = None,
    export_trend_flag: bool = False,
    show_weighted: bool = False,
    policy_mode: str = "error",
    policy_json: bool = False,
) -> int:
    """
    Run localization audit and generate report.

    Args:
        base_locale: Path to base locale directory
        target_locales: List of target locale directory paths
        min_coverage: Minimum coverage percentage (0-100)
        strict: If True, exit with code 1 if any locale below threshold
        output: Path to output JSON file
        validate_tags: If True, validate BCP-47 language tags
        ignore_patterns: List of glob patterns to ignore

    Returns:
        Exit code (0 = success, 1 = threshold breach, 3 = error)
    """
    try:
        # Load base locale keys
        print(f"Loading base locale: {base_locale.name}")
        base_keys, base_warnings = parse_rpy_locale_keys(
            base_locale, validate_tags, ignore_patterns
        )

        # Print BCP-47 warnings for base locale
        for warning in base_warnings:
            print(f"  ⚠️  {warning}", file=sys.stderr)

        if not base_keys:
            print(
                f"Error: No translation keys found in base locale {base_locale}",
                file=sys.stderr,
            )
            return Exit.INTERNAL

        print(f"  Found {len(base_keys)} keys in base locale")

        # Calculate coverage for each target locale
        coverage_data = {}
        below_threshold = []
        all_warnings = list(base_warnings)  # Collect all warnings

        for target_locale in target_locales:
            locale_name = target_locale.name
            print(f"Analyzing locale: {locale_name}")

            target_keys, target_warnings = parse_rpy_locale_keys(
                target_locale, validate_tags, ignore_patterns
            )

            # Print BCP-47 warnings for target locale
            for warning in target_warnings:
                print(f"  ⚠️  {warning}", file=sys.stderr)
                all_warnings.append(f"{locale_name}: {warning}")

            coverage = calculate_coverage(base_keys, target_keys)

            coverage_data[locale_name] = coverage

            # Print summary
            print(
                f"  Coverage: {coverage['coverage_pct']}% "
                f"({coverage['missing_keys']} missing, {coverage['orphan_keys']} orphaned)"
            )

            if coverage["coverage_pct"] < min_coverage:
                below_threshold.append(locale_name)
                if strict:
                    print(f"  ⚠️  Below threshold ({min_coverage}%)", file=sys.stderr)

        # Generate unified report
        report = {
            "version": VERSION,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "command": "l10n",
            "localization": {
                "base_locale": base_locale.name,
                "target_locales": [loc.name for loc in target_locales],
                "min_coverage": min_coverage,
                "coverage": coverage_data,
                "below_threshold": below_threshold,
                "validation_warnings": all_warnings,
            },
        }

        # Write output based on format
        if output_format == "json":
            _write_json_output(report, str(output) if output else None)
        else:
            _write_text_output(report, str(output) if output else None)

        # Coverage baseline enforcement (v0.7.11)
        coverage_failures = []
        if save_baseline_flag or compare_baseline_flag:
            project_root = Path.cwd()
            config = load_config(project_root)

            # Filter locales if --coverage-locale specified
            locales_to_check = (
                [coverage_locale] if coverage_locale else list(coverage_data.keys())
            )

            for locale_name in locales_to_check:
                if locale_name not in coverage_data:
                    print(
                        f"⚠️  Locale '{locale_name}' not found in coverage data, skipping",
                        file=sys.stderr,
                    )
                    continue

                # Convert coverage dict to CoverageSummary
                cov_summary = coverage_summary(locale_name, coverage_data[locale_name])

                # Save baseline
                if save_baseline_flag:
                    baseline_path = save_baseline(
                        config, locale_name, cov_summary, project_root
                    )
                    print(f"💾 Saved baseline for {locale_name}: {baseline_path}")

                # Compare against baseline
                if compare_baseline_flag:
                    success, message = compare_to_baseline_and_enforce(
                        config, locale_name, cov_summary, project_root
                    )
                    print(f"  {message}")

                    if not success:
                        coverage_failures.append(locale_name)

        # Weighted policy enforcement (v0.7.13 - Phase 8B)
        # -------------------------------------------------
        policy_violations_list = []
        weighted_summary = None
        policies_enabled = False

        try:
            # Load config for policy settings
            config = load_config(Path.cwd())

            # Build locale->coverage_pct map (0-100 percentage format)
            locale_to_pct = {
                locale_name: float(cov_data["coverage_pct"])
                for locale_name, cov_data in coverage_data.items()
            }

            tiers_conf = config.get("coverage", {}).get("tiers", {})
            weights_conf = config.get("coverage", {}).get("weights", {})
            policies_conf = config.get("coverage", {}).get("policies", {})
            policies_enabled = policies_conf.get("enabled", False)

            # Import and run policy enforcement
            from branchpy.localization.coverage_utils import CoverageSummary
            from branchpy.localization.weighted_policy import (
                _format_policy_violation,
                compute_weighted_score,
            )
            from branchpy.localization.weighted_policy import (
                enforce_policies as enforce_policy_rules,
            )
            from branchpy.localization.weighted_policy import (
                format_policy_violations_json,
            )

            # Build CoverageSummary objects for weighted calculation
            summaries = {}
            for locale_name, cov_data in coverage_data.items():
                translated_keys = cov_data["total_keys"] - cov_data["missing_keys"]
                summaries[locale_name] = CoverageSummary(
                    locale=locale_name,
                    total_keys=cov_data["total_keys"],
                    translated_keys=translated_keys,
                    coverage_pct=cov_data["coverage_pct"],
                    missing_keys=cov_data["missing_keys"],
                    orphan_keys=cov_data["orphan_keys"],
                )

            # Compute weighted score
            weighted_summary = compute_weighted_score(summaries, config)

            # Enforce policies with specified mode
            policy_success, policy_violations_list = enforce_policy_rules(
                weighted_summary, config, enforcement_mode=policy_mode
            )

            # Output policy violations (JSON or colored text)
            if policy_json and policy_violations_list:
                # JSON output to stdout
                json_output = format_policy_violations_json(
                    policy_violations_list,
                    policy_mode,
                    weighted_summary.weighted_score,
                    policies_enabled,
                )
                print(json_output)
            elif policy_violations_list and policy_mode != "off":
                # Colored text output to stderr
                mode_label = {"error": "ERROR", "warn": "WARNING"}[policy_mode]
                print(f"\n{mode_label}: Policy violations detected", file=sys.stderr)
                for violation in policy_violations_list:
                    formatted = _format_policy_violation(
                        violation, policy_mode, use_color=True
                    )
                    print(f"  {formatted}", file=sys.stderr)

            # Display weighted summary if requested
            if show_weighted:
                print("\n📊 Weighted Coverage Summary:")
                print(f"  Weighted Score: {weighted_summary.weighted_score:.2f}%")
                print(f"  Total Weight: {weighted_summary.total_weight:.2f}")
                print("\n  Per-Locale Breakdown:")
                for locale_name in sorted(weighted_summary.locale_scores.keys()):
                    score = weighted_summary.locale_scores[locale_name]
                    print(
                        f"    - {locale_name}: {score.coverage_pct:.1f}% "
                        f"(tier={score.tier}, weight={score.weight:.2f}, "
                        f"contribution={score.weighted_contribution:.2f})"
                    )

                if policies_enabled:
                    if policy_success or policy_mode == "warn":
                        status = (
                            "PASS"
                            if not policy_violations_list
                            else f"PASS (warn mode, {len(policy_violations_list)} warnings)"
                        )
                        print(f"\n  ✅ Policy Status: {status}")
                    else:
                        print("\n  ❌ Policy Status: FAIL")
                        if not policy_json:  # Don't duplicate if JSON already printed
                            print("  Violations:")
                            for violation in policy_violations_list:
                                print(f"    - {violation}")
                else:
                    print(
                        "\n  ℹ️  Policy enforcement: DISABLED (set coverage.policies.enabled=true to enable)"
                    )

        except Exception as e:
            # Non-fatal: weighted policy enforcement is optional
            print(f"⚠️  Weighted policy check failed: {e}", file=sys.stderr)
            if show_weighted:
                import traceback

                traceback.print_exc()

        # Export trend file if requested (non-fatal if it fails)
        if export_trend_flag:
            try:
                from branchpy.localization.coverage_history import export_trend

                # Load config for history settings (already imported at top)
                config = load_config(Path.cwd())
                trend_path = export_trend(config, project_root=str(Path.cwd()))
                if trend_path:
                    print(f"\n📊 Coverage trend exported to: {trend_path}")
            except Exception as e:
                print(f"⚠️  Trend export failed: {e}", file=sys.stderr)

        # Determine exit code (priority: drift > threshold > policy > success)
        if coverage_failures:
            print(
                f"\n❌ Coverage enforcement failed for {len(coverage_failures)} locale(s)",
                file=sys.stderr,
            )
            return 2  # Exit code 2 for coverage drift

        if strict and below_threshold:
            print(
                f"\n❌ {len(below_threshold)} locale(s) below {min_coverage}% threshold",
                file=sys.stderr,
            )
            return Exit.ISSUES_FOUND

        # Weighted policy violations (exit code depends on mode)
        if policies_enabled and policy_violations_list:
            if policy_mode == "error":
                # In error mode, fail with exit code 3
                if not policy_json:  # Don't duplicate message if JSON already printed
                    print("\n❌ Weighted policy violations detected", file=sys.stderr)
                return 3  # Exit code 3 for policy violations
            elif policy_mode == "warn":
                # In warn mode, exit 0 but violations were logged to stderr
                pass  # Continue to Exit.OK
            # mode "off" would have skipped checks entirely

        return Exit.OK

    except Exception as e:
        print(f"Error during L10n audit: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return Exit.INTERNAL


def main():
    """CLI entry point for bpy l10n audit command."""
    parser = argparse.ArgumentParser(
        prog="bpy l10n audit",
        description="Validate localization coverage across multiple language files",
    )

    parser.add_argument(
        "--base",
        type=str,
        default="game/tl/english",
        help="Base locale directory path (source of truth). Default: game/tl/english",
    )

    parser.add_argument(
        "--locales",
        type=str,
        help="Comma-separated target locale paths. If omitted, auto-detects all tl/*/ directories.",
    )

    parser.add_argument(
        "--min-coverage",
        type=float,
        default=80.0,
        help="Minimum coverage percentage (0-100). Default: 80.0",
    )

    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit with code 1 if any locale below minimum coverage threshold",
    )

    parser.add_argument(
        "--output",
        "--out",
        type=str,
        help="Output file for analysis results (use '-' for stdout). If omitted, prints to stdout for text format or l10n-report.json for JSON.",
    )

    parser.add_argument(
        "--format",
        dest="output_format",
        choices=["text", "json"],
        default="json",
        help="Output format for the audit report (default: json)",
    )

    parser.add_argument(
        "--no-validate-tags",
        action="store_true",
        help="Skip BCP-47 language tag validation (not recommended)",
    )

    parser.add_argument(
        "--save-baseline",
        action="store_true",
        help="Save current coverage as baseline for future drift detection",
    )

    parser.add_argument(
        "--compare-baseline",
        action="store_true",
        help="Compare coverage against saved baseline and fail if coverage drops",
    )

    parser.add_argument(
        "--coverage-locale",
        type=str,
        help="Specific locale for baseline operations (e.g., 'en', 'es'). If omitted, applies to all locales.",
    )

    parser.add_argument(
        "--export-trend",
        action="store_true",
        help="Export coverage trend JSON from snapshot history",
    )

    parser.add_argument(
        "--show-weighted",
        action="store_true",
        help="Show weighted coverage summary using policy weights (v0.7.13)",
    )

    parser.add_argument(
        "--policy-mode",
        type=str,
        choices=["error", "warn", "off"],
        default="error",
        help="Policy enforcement mode: error (exit 3 on violations), warn (exit 0, log warnings), off (skip checks). Default: error",
    )

    parser.add_argument(
        "--policy-json",
        action="store_true",
        help="Output policy violations as JSON to stdout (machine-readable)",
    )

    args = parser.parse_args()

    # Resolve base locale path
    base_locale = Path(args.base).resolve()
    if not base_locale.exists():
        print(f"Error: Base locale directory not found: {base_locale}", file=sys.stderr)
        sys.exit(Exit.INTERNAL)

    # Resolve target locales
    if args.locales:
        # User-specified locales
        target_locales = [
            Path(loc.strip()).resolve() for loc in args.locales.split(",")
        ]
        for loc in target_locales:
            if not loc.exists():
                print(
                    f"Warning: Target locale directory not found: {loc}",
                    file=sys.stderr,
                )
    else:
        # Auto-detect locales
        project_root = Path.cwd()
        target_locales = auto_detect_locales(project_root)

        # Exclude base locale from targets
        target_locales = [loc for loc in target_locales if loc != base_locale]

        if not target_locales:
            print(
                "Error: No target locales found. Use --locales to specify manually.",
                file=sys.stderr,
            )
            sys.exit(Exit.INTERNAL)

    # Validate min-coverage range
    if not (0 <= args.min_coverage <= 100):
        print(
            f"Error: --min-coverage must be between 0 and 100 (got {args.min_coverage})",
            file=sys.stderr,
        )
        sys.exit(Exit.INTERNAL)

    # Load config for ignore patterns
    project_root = Path.cwd()
    config = load_config(project_root)
    ignore_patterns = get_ignore_patterns(config)

    if ignore_patterns:
        print(f"Using ignore patterns from .branchpy.toml: {ignore_patterns}")

    # Run audit
    output_path = Path(args.output).resolve()
    validate_tags = not args.no_validate_tags

    exit_code = run_l10n_audit(
        base_locale=base_locale,
        target_locales=target_locales,
        min_coverage=args.min_coverage,
        strict=args.strict,
        output=output_path,
        validate_tags=validate_tags,
        ignore_patterns=ignore_patterns,
        save_baseline_flag=args.save_baseline,
        compare_baseline_flag=args.compare_baseline,
        coverage_locale=args.coverage_locale,
        export_trend_flag=args.export_trend,
        show_weighted=args.show_weighted,
        policy_mode=args.policy_mode,
        policy_json=args.policy_json,
    )

    sys.exit(exit_code)


def build_arg_parser(subparsers) -> None:
    """
    Register 'audit' subcommand under 'branchpy l10n audit'.

    This function is called by branchpy/commands/l10n_cmd.py to register
    the audit command as a subcommand of 'l10n'.

    Args:
        subparsers: The subparsers object from the parent 'l10n' command
    """
    audit_p = subparsers.add_parser(
        "audit",
        help="Validate localization coverage with weighted policies (v0.7.17)",
        description="Audit translation coverage across all locales with policy enforcement",
    )

    # Base and target locale configuration
    audit_p.add_argument(
        "--base",
        type=str,
        default="game/tl/english",
        help="Base locale directory path (source of truth). Default: game/tl/english",
    )

    audit_p.add_argument(
        "--locales",
        type=str,
        help="Comma-separated target locale paths. If omitted, auto-detects all tl/*/ directories.",
    )

    # Coverage thresholds
    audit_p.add_argument(
        "--min-coverage",
        type=float,
        default=80.0,
        help="Minimum coverage percentage (0-100). Default: 80.0",
    )

    audit_p.add_argument(
        "--strict",
        action="store_true",
        help="Exit with code 1 if any locale below minimum coverage threshold",
    )

    # Output configuration
    audit_p.add_argument(
        "--output",
        type=str,
        default="l10n-report.json",
        help="Output JSON file path. Default: l10n-report.json",
    )

    audit_p.add_argument(
        "--format",
        dest="output_format",
        choices=["text", "json"],
        default="json",
        help="Output format for the audit report (default: json)",
    )

    # Validation options
    audit_p.add_argument(
        "--no-validate-tags",
        action="store_true",
        help="Skip BCP-47 language tag validation (not recommended)",
    )

    # Baseline management
    audit_p.add_argument(
        "--save-baseline",
        action="store_true",
        help="Save current coverage as baseline for future drift detection",
    )

    audit_p.add_argument(
        "--compare-baseline",
        action="store_true",
        help="Compare coverage against saved baseline and fail if coverage drops",
    )

    audit_p.add_argument(
        "--coverage-locale",
        type=str,
        help="Specific locale for baseline operations (e.g., 'en', 'es'). If omitted, applies to all locales.",
    )

    # Trend export
    audit_p.add_argument(
        "--export-trend",
        action="store_true",
        help="Export coverage trend JSON from snapshot history",
    )

    # Weighted coverage
    audit_p.add_argument(
        "--show-weighted",
        action="store_true",
        help="Show weighted coverage summary using policy weights (v0.7.13)",
    )

    # Policy enforcement (Gate 10A - v0.7.17)
    audit_p.add_argument(
        "--policy-mode",
        type=str,
        choices=["error", "warn", "off"],
        default="error",
        help="Policy enforcement mode: error (exit 3 on violations), warn (exit 0, log warnings), off (skip checks). Default: error",
    )

    audit_p.add_argument(
        "--policy-json",
        action="store_true",
        help="Output policy violations as JSON to stdout (machine-readable)",
    )

    # Set handler function
    audit_p.set_defaults(func=run_from_cli)


def run_from_cli(args, env=None) -> int:
    """
    CLI entry point for 'branchpy l10n audit' command.

    This is called when the user runs: branchpy l10n audit [OPTIONS]

    Args:
        args: Parsed command-line arguments from argparse
        env: Optional environment context (unused, for compatibility)

    Returns:
        Exit code (0=success, 1=threshold breach, 3=policy violation, 10=error)
    """
    # Resolve base locale path
    base_locale = Path(args.base).resolve()
    if not base_locale.exists():
        print(f"Error: Base locale directory not found: {base_locale}", file=sys.stderr)
        return Exit.INTERNAL

    # Resolve target locales
    if args.locales:
        # User-specified locales
        target_locales = [
            Path(loc.strip()).resolve() for loc in args.locales.split(",")
        ]
        for loc in target_locales:
            if not loc.exists():
                print(
                    f"Warning: Target locale directory not found: {loc}",
                    file=sys.stderr,
                )
    else:
        # Auto-detect locales
        project_root = Path.cwd()
        target_locales = auto_detect_locales(project_root)

        # Exclude base locale from targets
        target_locales = [loc for loc in target_locales if loc != base_locale]

        if not target_locales:
            print(
                "Error: No target locales found. Use --locales to specify manually.",
                file=sys.stderr,
            )
            return Exit.INTERNAL

    # Validate min-coverage range
    if not (0 <= args.min_coverage <= 100):
        print(
            f"Error: --min-coverage must be between 0 and 100 (got {args.min_coverage})",
            file=sys.stderr,
        )
        return Exit.INTERNAL

    # Load config for ignore patterns
    project_root = Path.cwd()
    config = load_config(project_root)
    ignore_patterns = get_ignore_patterns(config)

    if ignore_patterns:
        print(f"Using ignore patterns from .branchpy.toml: {ignore_patterns}")

    # Run audit
    output_path = Path(args.output).resolve()
    validate_tags = not args.no_validate_tags

    exit_code = run_l10n_audit(
        base_locale=base_locale,
        target_locales=target_locales,
        min_coverage=args.min_coverage,
        strict=args.strict,
        output=output_path,
        output_format=args.output_format,
        validate_tags=validate_tags,
        ignore_patterns=ignore_patterns,
        save_baseline_flag=args.save_baseline,
        compare_baseline_flag=args.compare_baseline,
        coverage_locale=args.coverage_locale,
        export_trend_flag=args.export_trend,
        show_weighted=args.show_weighted,
        policy_mode=args.policy_mode,
        policy_json=args.policy_json,
    )

    return exit_code


if __name__ == "__main__":
    main()
