"""
BranchPy Media Export CLI Command (v0.9.0.2)

Export media references from analyze report to CSV/JSON formats.

Usage:
    bpy export-media [OPTIONS]

Examples:
    # Export to CSV with audit preset
    bpy export-media --preset=audit --output=media_audit.csv

    # Export to JSON with all fields
    bpy export-media --format=json --output=media.json

    # Export only localization-related fields
    bpy export-media --preset=localization --output=voice_assets.csv
"""

import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional

try:
    import click
except ImportError:
    print("Error: click package not installed. Run: pip install click", file=sys.stderr)
    sys.exit(1)

from branchpy.contract import Exit


@click.command("export-media")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["csv", "json"]),
    default="csv",
    help="Export format (csv or json)",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False, writable=True),
    required=True,
    help="Output file path",
)
@click.option(
    "--report",
    "-r",
    type=click.Path(exists=True, dir_okay=False),
    default=".branchpy/reports/unified/unified_report.json",
    help="Path to analyze report JSON",
)
@click.option(
    "--preset",
    type=click.Choice(["audit", "localization", "ui"]),
    default=None,
    help="Export preset (predefined column sets)",
)
def export_media(fmt: str, output: str, report: str, preset: Optional[str]):
    """Export media summary/refs from the latest analyze report."""

    # Load report
    try:
        report_path = Path(report)
        if not report_path.exists():
            click.echo(f"Error: Report file not found: {report}", err=True)
            click.echo("Run 'bpy analyze' first to generate report.", err=True)
            raise SystemExit(Exit.INTERNAL)

        data = json.loads(report_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        click.echo(f"Error: Invalid JSON in report: {e}", err=True)
        raise SystemExit(Exit.INTERNAL)
    except Exception as e:
        click.echo(f"Error reading report: {e}", err=True)
        raise SystemExit(Exit.INTERNAL)

    # Extract media refs
    media = data.get("media", {})
    if not media:
        click.echo(
            "Warning: No media data in report. Run 'bpy analyze' with media enabled.",
            err=True,
        )

    by_label = media.get("by_label", {})
    rows = []

    for label, refs in by_label.items():
        for ref in refs:
            validation = ref.get("validation") or {}
            rows.append(
                {
                    "label": label,
                    "kind": ref.get("kind"),
                    "action": ref.get("action"),
                    "channel": ref.get("channel"),
                    "target": ref.get("target"),
                    "path": ref.get("resolved_path") or ref.get("template_path"),
                    "confidence": ref.get("confidence"),
                    "via_function": ref.get("via_function"),
                    "via_screen": ref.get("via_screen"),
                    "layer": ref.get("target_layer"),
                    "z": ref.get("target_z"),
                    "exists": validation.get("exists"),
                    "source": f'{ref.get("source_file")}:{ref.get("source_line")}',
                }
            )

    # Select columns based on preset
    PRESET_COLS: Dict[str, List[str]] = {
        "audit": [
            "label",
            "kind",
            "action",
            "channel",
            "target",
            "path",
            "confidence",
            "via_function",
            "via_screen",
            "layer",
            "z",
            "exists",
            "source",
        ],
        "localization": ["label", "path", "channel"],
        "ui": ["label", "path", "target", "via_screen", "layer", "z"],
    }
    cols = PRESET_COLS.get(preset or "audit", PRESET_COLS["audit"])

    # Write output
    out = Path(output)
    try:
        if fmt == "json":
            out.write_text(
                json.dumps(
                    {"rows": rows, "summary": media.get("summary", {})}, indent=2
                ),
                encoding="utf-8",
            )
        else:  # csv
            with out.open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=cols)
                w.writeheader()
                for r in rows:
                    w.writerow({k: r.get(k) for k in cols})

        click.echo(f"✓ Exported {len(rows)} media refs → {out}")
        click.echo(f"  Format: {fmt.upper()}, Preset: {preset or 'audit'}")

        # Show summary
        summary = media.get("summary", {})
        if summary:
            click.echo(
                f"  Total: {summary.get('total', 0)}, Missing: {summary.get('missing', 0)}"
            )

    except Exception as e:
        click.echo(f"Error writing output: {e}", err=True)
        raise SystemExit(Exit.INTERNAL)


if __name__ == "__main__":
    export_media()  # Click handles args from sys.argv
