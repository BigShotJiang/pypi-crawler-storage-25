"""
Auto-Detect CLI Command

Command-line interface for auto-detect → BQF policy conversion.

Usage:
    branchpy auto-detect                              # Full workflow
    branchpy auto-detect --mode minimal               # Minimal policies only
    branchpy auto-detect --project-type visual_novel  # Specify project type
    branchpy auto-detect --export-format yaml         # Export format
    branchpy auto-detect --output policies.yaml       # Custom output path

Version: 0.9.6
"""

import argparse
import sys
import time
from pathlib import Path

from branchpy.auto_detect.events import AutoDetectEvents
from branchpy.auto_detect.pattern_miner import PatternMiner
from branchpy.auto_detect.policy_scaffolder import (
    PolicyScaffolder,
    ProjectType,
    ScaffoldingMode,
)
from branchpy.auto_detect.recommendation_engine import RecommendationEngine
from branchpy.auto_detect.rule_inference import RuleInferenceEngine

try:
    from branchpy import logs

    _HAS_LOGS = True
except ImportError:
    _HAS_LOGS = False

    class _LogShim:
        def info(self, cat: str, msg: str, **kwargs):
            print(f"[INFO] {msg}")

        def warn(self, cat: str, msg: str, **kwargs):
            print(f"[WARN] {msg}")

        def error(self, cat: str, msg: str, **kwargs):
            print(f"[ERROR] {msg}")

    logs = _LogShim()


def run(args) -> int:
    """Run auto-detect command.

    Args:
        args: Parsed command-line arguments

    Returns:
        Exit code (0 = success)
    """
    # Parse arguments
    project_root = Path(args.project or Path.cwd())
    if not project_root.exists():
        logs.error("auto_detect.cli.error", f"Project root not found: {project_root}")
        return 1

    # Parse enums
    try:
        project_type = ProjectType(args.project_type)
    except ValueError:
        logs.error(
            "auto_detect.cli.error", f"Invalid project type: {args.project_type}"
        )
        return 1

    try:
        mode = ScaffoldingMode(args.mode)
    except ValueError:
        logs.error("auto_detect.cli.error", f"Invalid mode: {args.mode}")
        return 1

    # Output path
    output_path = (
        Path(args.output)
        if args.output
        else project_root / ".branchpy" / "auto_detect_policies.yaml"
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Start workflow
    correlation_id = AutoDetectEvents.emit_pattern_mining_start(
        project_root=str(project_root), engine_type=args.engine_type
    )

    try:
        # Step 1: Pattern Mining
        print(f"\n[1/4] Mining patterns from {project_root}...")
        start_time = time.perf_counter()

        miner = PatternMiner(
            project_root=project_root,
            engine_type=args.engine_type,
            min_confidence=args.min_confidence,
            max_files=args.max_files,
        )

        patterns = miner.mine_all_patterns()
        pattern_summaries = miner.get_pattern_summaries(
            min_count=args.min_pattern_count, min_confidence=args.min_confidence
        )

        mining_duration = (time.perf_counter() - start_time) * 1000

        AutoDetectEvents.emit_pattern_mining_complete(
            correlation_id=correlation_id,
            pattern_count=len(patterns),
            file_count=miner.file_count,
            line_count=miner.line_count,
            duration_ms=mining_duration,
        )

        print(f"  ✓ Found {len(patterns)} pattern instances")
        print(f"  ✓ Generated {len(pattern_summaries)} pattern summaries")
        print(f"  ✓ Scanned {miner.file_count} files ({miner.line_count} lines)")

        # Step 2: Rule Inference
        print("\n[2/4] Inferring rules from patterns...")
        start_time = time.perf_counter()

        AutoDetectEvents.emit_rule_inference_start(
            correlation_id=correlation_id,
            pattern_count=len(pattern_summaries),
            min_confidence=args.min_confidence,
        )

        inference_engine = RuleInferenceEngine(
            min_confidence=args.min_confidence, min_pattern_count=args.min_pattern_count
        )

        inferred_rules = inference_engine.infer_rules(pattern_summaries)

        inference_duration = (time.perf_counter() - start_time) * 1000

        AutoDetectEvents.emit_rule_inference_complete(
            correlation_id=correlation_id,
            rule_count=len(inferred_rules),
            duration_ms=inference_duration,
        )

        print(f"  ✓ Inferred {len(inferred_rules)} rules")

        # Print rule breakdown
        rule_types = {}
        for rule in inferred_rules:
            rule_types[rule.rule_type.value] = (
                rule_types.get(rule.rule_type.value, 0) + 1
            )
        for rule_type, count in sorted(rule_types.items()):
            print(f"    - {rule_type}: {count}")

        # Step 3: Recommendations
        print("\n[3/4] Analyzing policy gaps and generating recommendations...")
        start_time = time.perf_counter()

        AutoDetectEvents.emit_recommendation_start(
            correlation_id=correlation_id,
            project_type=project_type.value,
            rule_count=len(inferred_rules),
        )

        rec_engine = RecommendationEngine(project_type=project_type.value)
        recommendations = rec_engine.analyze_gaps(
            existing_rules=inferred_rules, pattern_summaries=pattern_summaries
        )

        rec_duration = (time.perf_counter() - start_time) * 1000

        # Get priority counts
        priority_counts = {}
        for rec in recommendations:
            priority_counts[rec.priority.value] = (
                priority_counts.get(rec.priority.value, 0) + 1
            )

        AutoDetectEvents.emit_recommendation_complete(
            correlation_id=correlation_id,
            recommendation_count=len(recommendations),
            by_priority=priority_counts,
            duration_ms=rec_duration,
        )

        print(f"  ✓ Generated {len(recommendations)} recommendations")
        for priority, count in sorted(priority_counts.items()):
            print(f"    - {priority}: {count}")

        # Step 4: Policy Scaffolding
        print("\n[4/4] Generating policy set...")
        start_time = time.perf_counter()

        AutoDetectEvents.emit_scaffolding_start(
            correlation_id=correlation_id,
            project_type=project_type.value,
            mode=mode.value,
        )

        scaffolder = PolicyScaffolder(
            project_type=project_type, mode=mode, min_confidence=args.min_confidence
        )

        policy_set = scaffolder.generate_policy_set(
            inferred_rules=inferred_rules,
            recommendations=recommendations,
            pattern_summaries=pattern_summaries,
        )

        scaffolding_duration = (time.perf_counter() - start_time) * 1000

        AutoDetectEvents.emit_scaffolding_complete(
            correlation_id=correlation_id,
            policy_count=len(policy_set.policies),
            duration_ms=scaffolding_duration,
        )

        print(f"  ✓ Generated {len(policy_set.policies)} policies")

        # Export
        print(f"\n[Export] Writing policy set to {output_path}...")
        scaffolder.export(policy_set, output_path, format=args.export_format)

        AutoDetectEvents.emit_policy_export(
            correlation_id=correlation_id,
            output_path=str(output_path),
            format=args.export_format,
            policy_count=len(policy_set.policies),
        )

        print(f"  ✓ Exported to {output_path}")

        # Generate README if requested
        if args.generate_readme:
            readme_path = output_path.parent / "README.md"
            scaffolder.generate_readme(policy_set, readme_path)
            print(f"  ✓ Generated {readme_path}")

        # Generate reports if requested
        if args.generate_reports:
            reports_dir = output_path.parent / "reports"
            reports_dir.mkdir(exist_ok=True)

            # Pattern summary
            import json

            pattern_report = reports_dir / "pattern_summary.json"
            with open(pattern_report, "w") as f:
                json.dump([s.to_dict() for s in pattern_summaries], f, indent=2)
            print(f"  ✓ Pattern report: {pattern_report}")

            # Rule inference
            rule_report = reports_dir / "inferred_rules.json"
            inference_engine.export_rules_json(str(rule_report))
            print(f"  ✓ Rule report: {rule_report}")

            # Recommendations
            rec_report = reports_dir / "recommendations.md"
            rec_engine.export_report(str(rec_report))
            print(f"  ✓ Recommendation report: {rec_report}")

        # Summary
        total_duration = (
            mining_duration + inference_duration + rec_duration + scaffolding_duration
        )
        print(f"\n{'='*60}")
        print("✓ Auto-detect complete!")
        print(f"{'='*60}")
        print(f"  Patterns:        {len(patterns)} instances")
        print(f"  Rules:           {len(inferred_rules)}")
        print(f"  Recommendations: {len(recommendations)}")
        print(f"  Policies:        {len(policy_set.policies)}")
        print(f"  Duration:        {total_duration:.0f}ms")
        print(f"  Output:          {output_path}")
        print(f"{'='*60}")

        return 0

    except Exception as e:
        AutoDetectEvents.emit_pattern_mining_error(
            correlation_id=correlation_id, error=str(e), error_type=type(e).__name__
        )
        logs.error("auto_detect.cli.error", f"Auto-detect failed: {e}")
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1


def add_parser(subparsers) -> None:
    """Add auto-detect command to CLI parser.

    Args:
        subparsers: Subparser action from argparse
    """
    parser = subparsers.add_parser(
        "auto-detect",
        help="Auto-detect patterns and generate BQF policies",
        description="Analyze codebase patterns and generate customized BQF policy sets",
    )

    # Project options
    parser.add_argument(
        "--project",
        "-p",
        type=str,
        help="Project root directory (default: current directory)",
    )

    parser.add_argument(
        "--engine-type",
        type=str,
        default="auto",
        choices=["auto", "renpy", "unity", "godot", "unreal", "generic"],
        help="Engine type (default: auto-detect)",
    )

    parser.add_argument(
        "--project-type",
        type=str,
        default="generic",
        choices=["visual_novel", "rpg", "puzzle", "adventure", "simulation", "generic"],
        help="Project type for policy customization (default: generic)",
    )

    # Scaffolding options
    parser.add_argument(
        "--mode",
        type=str,
        default="recommended",
        choices=["minimal", "recommended", "comprehensive", "custom"],
        help="Scaffolding mode (default: recommended)",
    )

    # Analysis options
    parser.add_argument(
        "--min-confidence",
        type=float,
        default=0.7,
        help="Minimum confidence for pattern detection (default: 0.7)",
    )

    parser.add_argument(
        "--min-pattern-count",
        type=int,
        default=10,
        help="Minimum pattern occurrences for rule inference (default: 10)",
    )

    parser.add_argument(
        "--max-files",
        type=int,
        default=10000,
        help="Maximum files to scan (default: 10000)",
    )

    # Output options
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        help="Output path for policy set (default: .branchpy/auto_detect_policies.yaml)",
    )

    parser.add_argument(
        "--export-format",
        type=str,
        default="auto",
        choices=["auto", "yaml", "json", "python"],
        help="Export format (default: auto-detect from extension)",
    )

    parser.add_argument(
        "--generate-readme",
        action="store_true",
        help="Generate README.md for policy set",
    )

    parser.add_argument(
        "--generate-reports",
        action="store_true",
        help="Generate detailed analysis reports",
    )

    # Debug options
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Verbose output with stack traces"
    )

    parser.set_defaults(func=run)


# Standalone execution support
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BranchPy Auto-Detect")
    subparsers = parser.add_subparsers(dest="command")
    add_parser(subparsers)

    args = parser.parse_args()
    if hasattr(args, "func"):
        sys.exit(args.func(args))
    else:
        parser.print_help()
        sys.exit(1)
