"""
BranchPy Patch Engine — CLI Commands

Command-line interface for the Patch Engine, providing:
- patch apply: Apply a transaction from JSON file
- patch preview: Preview transaction without applying
- patch rollback: Rollback a previously-applied transaction
- patch log: View patch transaction history
- patch stats: Show patch statistics

This is an internal/dev-facing CLI for v0.9.9 Day 1.
Later versions will integrate with:
- `branchpy fix` for autofix workflows
- VS Code extension for UI-driven patching
- Remote execution via rc-backend

Usage Examples:
    # Preview a patch
    branchpy patch preview transaction.json

    # Apply with Git safety commit
    branchpy patch apply transaction.json --git-commit

    # View recent patch history
    branchpy patch log --limit 10

    # Rollback last transaction
    branchpy patch rollback <transaction-id>

    # Show statistics
    branchpy patch stats

BQS Compliance:
- Cross-platform: Uses pathlib, no shell injection
- Error handling: Comprehensive error messages
- Security: Validates all paths
- Telemetry: Emits events for all operations

Version: v0.9.9
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from branchpy.patches.models import PatchTransaction

# Lazy imports to avoid circular dependencies
# from branchpy.patches import (
#     PatchEngine, PatchContext, PatchTransaction,
#     GitIntegration, PatchStorage
# )


def add_parser(subparsers) -> argparse.ArgumentParser:
    """
    Add 'patch' command parser to subparsers.

    Args:
        subparsers: argparse subparsers object

    Returns:
        The patch command parser
    """
    parser = subparsers.add_parser(
        "patch",
        help="Patch Engine — apply, preview, and manage code patches (v0.9.9)",
        description=(
            "BranchPy Patch Engine provides safe, reversible code modifications "
            "with automatic backup, Git integration, and rollback support."
        ),
    )

    # Add subcommands
    patch_subparsers = parser.add_subparsers(
        dest="patch_subcommand",
        help="Patch Engine subcommands",
    )

    # patch apply
    apply_parser = patch_subparsers.add_parser(
        "apply",
        help="Apply a patch transaction from JSON file",
        description=(
            "Apply a patch transaction to the project with automatic backup creation. "
            "If the transaction fails, no changes are made to disk."
        ),
    )
    apply_parser.add_argument(
        "transaction_file",
        type=Path,
        help="Path to transaction JSON file",
    )
    apply_parser.add_argument(
        "--project-root",
        type=Path,
        default=Path.cwd(),
        help="Project root directory (default: current directory)",
    )
    apply_parser.add_argument(
        "--backup-root",
        type=Path,
        default=None,
        help="Backup directory (default: .branchpy/patch-backups)",
    )
    apply_parser.add_argument(
        "--git-commit",
        action="store_true",
        help="Create Git safety commit before applying",
    )
    apply_parser.add_argument(
        "--log-path",
        type=Path,
        default=None,
        help="Path to patch log file (default: .branchpy/patch-log.jsonl)",
    )

    # patch preview
    preview_parser = patch_subparsers.add_parser(
        "preview",
        help="Preview a patch transaction without applying",
        description=(
            "Show what files would be modified without actually applying changes. "
            "Useful for validating patch operations before commit."
        ),
    )
    preview_parser.add_argument(
        "transaction_file",
        type=Path,
        help="Path to transaction JSON file",
    )
    preview_parser.add_argument(
        "--project-root",
        type=Path,
        default=Path.cwd(),
        help="Project root directory (default: current directory)",
    )
    preview_parser.add_argument(
        "--diff",
        action="store_true",
        help="Show unified diff instead of full file content",
    )
    preview_parser.add_argument(
        "--files-only",
        action="store_true",
        help="Only list affected files (no content preview)",
    )

    # patch rollback
    rollback_parser = patch_subparsers.add_parser(
        "rollback",
        help="Rollback a previously-applied transaction",
        description=(
            "Restore files to their state before a transaction was applied. "
            "This uses backup files created during apply."
        ),
    )
    rollback_parser.add_argument(
        "transaction_id",
        type=str,
        help="Transaction ID to rollback",
    )
    rollback_parser.add_argument(
        "--project-root",
        type=Path,
        default=Path.cwd(),
        help="Project root directory (default: current directory)",
    )
    rollback_parser.add_argument(
        "--log-path",
        type=Path,
        default=None,
        help="Path to patch log file (default: .branchpy/patch-log.jsonl)",
    )
    rollback_parser.add_argument(
        "--backup-root",
        type=Path,
        default=None,
        help="Backup directory (default: .branchpy/patch-backups)",
    )

    # patch log
    log_parser = patch_subparsers.add_parser(
        "log",
        help="View patch transaction history",
        description="Show history of applied, rolled-back, and failed transactions.",
    )
    log_parser.add_argument(
        "--project-root",
        type=Path,
        default=Path.cwd(),
        help="Project root directory (default: current directory)",
    )
    log_parser.add_argument(
        "--log-path",
        type=Path,
        default=None,
        help="Path to patch log file (default: .branchpy/patch-log.jsonl)",
    )
    log_parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Maximum number of entries to show (default: 10)",
    )
    log_parser.add_argument(
        "--status",
        type=str,
        choices=["applied", "rolled_back", "failed", "all"],
        default="all",
        help="Filter by status (default: all)",
    )
    log_parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output as JSON",
    )

    # patch stats
    stats_parser = patch_subparsers.add_parser(
        "stats",
        help="Show patch statistics",
        description="Display statistics about patch transactions and operations.",
    )
    stats_parser.add_argument(
        "--project-root",
        type=Path,
        default=Path.cwd(),
        help="Project root directory (default: current directory)",
    )
    stats_parser.add_argument(
        "--log-path",
        type=Path,
        default=None,
        help="Path to patch log file (default: .branchpy/patch-log.jsonl)",
    )
    stats_parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output as JSON",
    )

    return parser


def run(args: argparse.Namespace) -> int:
    """
    Execute the patch command.

    Args:
        args: Parsed command-line arguments

    Returns:
        Exit code (0 = success, non-zero = error)
    """
    # Lazy import to avoid circular dependencies and improve startup time
    from branchpy.patches import PatchEngineError, PatchValidationError

    subcommand = args.patch_subcommand

    if not subcommand:
        print(
            "Error: No subcommand specified. Use 'branchpy patch --help' for usage.",
            file=sys.stderr,
        )
        return 1

    try:
        if subcommand == "apply":
            return cmd_apply(args)
        elif subcommand == "preview":
            return cmd_preview(args)
        elif subcommand == "rollback":
            return cmd_rollback(args)
        elif subcommand == "log":
            return cmd_log(args)
        elif subcommand == "stats":
            return cmd_stats(args)
        else:
            print(f"Error: Unknown subcommand '{subcommand}'", file=sys.stderr)
            return 1

    except PatchValidationError as e:
        print(f"❌ Validation Error: {e}", file=sys.stderr)
        return 2
    except PatchEngineError as e:
        print(f"❌ Patch Engine Error: {e}", file=sys.stderr)
        return 3
    except Exception as e:
        print(f"❌ Unexpected Error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 4


def cmd_apply(args: argparse.Namespace) -> int:
    """Apply a patch transaction."""
    from branchpy.patches import GitIntegration, PatchContext, PatchEngine, PatchStorage

    # Resolve paths
    project_root = args.project_root.resolve()
    backup_root = args.backup_root or (project_root / ".branchpy" / "patch-backups")
    log_path = args.log_path or (project_root / ".branchpy" / "patch-log.jsonl")

    # Load transaction from JSON
    print(f"📄 Loading transaction from {args.transaction_file}...")
    tx = _load_transaction_from_file(args.transaction_file)
    print(f"✓ Loaded transaction {tx.id}: {tx.description}")
    print(f"  Operations: {len(tx.operations)}")

    # Create context
    context = PatchContext(
        project_root=project_root,
        backup_root=backup_root,
    )

    # Optional Git safety commit
    if args.git_commit:
        git = GitIntegration(project_root)
        if git.is_git_repo():
            print("📝 Creating Git safety commit...")
            commit_hash = git.create_safety_commit(
                f"[BranchPy] Pre-patch safety checkpoint: {tx.id}"
            )
            if commit_hash:
                print(f"✓ Safety commit: {commit_hash[:8]}")
            else:
                print("⚠️  No changes to commit (working tree clean)")
        else:
            print("⚠️  Not a Git repository, skipping safety commit")

    # Create engine and storage
    engine = PatchEngine(context)
    storage = PatchStorage(log_path)

    # Apply transaction
    print("⚙️  Applying transaction...")
    log_entry = engine.apply_transaction(tx)

    # Save to storage
    storage.append(log_entry, flush=True)

    # Report success
    print("✅ Transaction applied successfully!")
    print(f"   Transaction ID: {log_entry.transaction_id}")
    print(f"   Status: {log_entry.status.value}")
    print(f"   Backup: {log_entry.backup_root}")
    print(f"   Operations: {len(log_entry.operation_ids)}")

    return 0


def cmd_preview(args: argparse.Namespace) -> int:
    """Preview a patch transaction."""
    import difflib

    from branchpy.patches import PatchContext, PatchEngine

    # Resolve paths
    project_root = args.project_root.resolve()
    backup_root = project_root / ".branchpy" / "patch-backups"  # Dummy for preview

    # Load transaction
    print(f"📄 Loading transaction from {args.transaction_file}...")
    tx = _load_transaction_from_file(args.transaction_file)
    print(f"✓ Loaded transaction {tx.id}: {tx.description}")

    # Create context and engine
    context = PatchContext(
        project_root=project_root,
        backup_root=backup_root,
    )
    engine = PatchEngine(context)

    # Preview transaction
    print("⚙️  Generating preview...")
    preview = engine.preview_transaction(tx)

    if args.files_only:
        # Just list affected files
        print(f"\n📂 Affected files ({len(preview)}):")
        for file_path in sorted(preview.keys()):
            relative = file_path.relative_to(project_root)
            print(f"   {relative}")
        return 0

    # Show previews for each file
    for file_path in sorted(preview.keys()):
        relative = file_path.relative_to(project_root)
        print(f"\n{'='*60}")
        print(f"📄 {relative}")
        print(f"{'='*60}")

        if args.diff:
            # Show unified diff
            original = file_path.read_text(encoding="utf-8")
            modified = preview[file_path]

            diff = difflib.unified_diff(
                original.splitlines(keepends=True),
                modified.splitlines(keepends=True),
                fromfile=f"a/{relative}",
                tofile=f"b/{relative}",
            )
            print("".join(diff))
        else:
            # Show full modified content
            print(preview[file_path])

    print(f"\n✅ Preview complete ({len(preview)} files affected)")
    return 0


def cmd_rollback(args: argparse.Namespace) -> int:
    """Rollback a patch transaction."""
    from branchpy.patches import PatchContext, PatchEngine, PatchStorage

    # Resolve paths
    project_root = args.project_root.resolve()
    backup_root = args.backup_root or (project_root / ".branchpy" / "patch-backups")
    log_path = args.log_path or (project_root / ".branchpy" / "patch-log.jsonl")

    # Load storage and find transaction
    storage = PatchStorage(log_path)
    log_entry = storage.get_by_transaction_id(args.transaction_id)

    if not log_entry:
        print(f"❌ Transaction not found: {args.transaction_id}", file=sys.stderr)
        return 1

    print(f"📄 Found transaction {log_entry.transaction_id}")
    print(f"   Status: {log_entry.status.value}")
    print(f"   Applied: {log_entry.applied_at}")
    print(f"   Operations: {len(log_entry.operation_ids)}")

    # Check if already rolled back
    if log_entry.status.value == "rolled_back":
        print("⚠️  Transaction already rolled back!")
        return 0

    # Create engine
    context = PatchContext(
        project_root=project_root,
        backup_root=backup_root,
    )
    engine = PatchEngine(context)

    # Rollback
    print("⚙️  Rolling back transaction...")
    engine.rollback_transaction(log_entry)

    # Update storage
    storage.append(log_entry, flush=True)

    print("✅ Transaction rolled back successfully!")
    return 0


def cmd_log(args: argparse.Namespace) -> int:
    """View patch transaction history."""
    from branchpy.patches import PatchStorage, PatchTransactionStatus

    # Resolve paths
    project_root = args.project_root.resolve()
    log_path = args.log_path or (project_root / ".branchpy" / "patch-log.jsonl")

    # Load storage
    storage = PatchStorage(log_path, ensure_exists=False)

    # Get entries
    entries = storage.read_recent(limit=args.limit)

    # Filter by status if requested
    if args.status != "all":
        status_map = {
            "applied": PatchTransactionStatus.APPLIED,
            "rolled_back": PatchTransactionStatus.ROLLED_BACK,
            "failed": PatchTransactionStatus.FAILED,
        }
        target_status = status_map[args.status]
        entries = [e for e in entries if e.status == target_status]

    if not entries:
        print("No patch transactions found.")
        return 0

    # JSON output
    if args.json_output:
        output = [e.dict() for e in entries]
        print(json.dumps(output, indent=2, default=str))
        return 0

    # Human-readable output
    print(f"📋 Patch Transaction Log ({len(entries)} entries)")
    print(f"{'='*60}")

    for entry in entries:
        status_icon = {
            "applied": "✅",
            "rolled_back": "↩️",
            "failed": "❌",
            "pending": "⏳",
        }.get(entry.status.value, "?")

        print(f"\n{status_icon} {entry.transaction_id}")
        print(f"   Status: {entry.status.value}")
        print(f"   Applied: {entry.applied_at}")
        print(f"   Operations: {len(entry.operation_ids)}")
        if entry.backup_root:
            print(f"   Backup: {entry.backup_root}")
        if entry.metadata:
            print(f"   Metadata: {entry.metadata}")

    return 0


def cmd_stats(args: argparse.Namespace) -> int:
    """Show patch statistics."""
    from branchpy.patches import PatchStorage

    # Resolve paths
    project_root = args.project_root.resolve()
    log_path = args.log_path or (project_root / ".branchpy" / "patch-log.jsonl")

    # Load storage
    storage = PatchStorage(log_path, ensure_exists=False)

    # Get statistics
    stats = storage.get_statistics()

    if args.json_output:
        print(json.dumps(stats, indent=2))
        return 0

    # Human-readable output
    print("📊 Patch Engine Statistics")
    print(f"{'='*60}")
    print(f"Total Transactions: {stats['total_entries']}")
    print(f"Applied:            {stats['applied_count']}")
    print(f"Rolled Back:        {stats['rolled_back_count']}")
    print(f"Failed:             {stats['failed_count']}")
    print(f"Total Operations:   {stats['total_operations']}")

    if stats["total_entries"] > 0:
        success_rate = stats["applied_count"] / stats["total_entries"] * 100
        print(f"\nSuccess Rate:       {success_rate:.1f}%")

        if stats["total_entries"] > 0:
            avg_ops = stats["total_operations"] / stats["total_entries"]
            print(f"Avg Operations/Tx:  {avg_ops:.1f}")

    return 0


def _load_transaction_from_file(path: Path) -> "PatchTransaction":
    """
    Load a PatchTransaction from JSON file.

    Args:
        path: Path to JSON file

    Returns:
        PatchTransaction object

    Raises:
        FileNotFoundError: If file doesn't exist
        json.JSONDecodeError: If file is not valid JSON
        ValueError: If JSON doesn't match PatchTransaction schema
    """
    from branchpy.patches import PatchTransaction

    if not path.exists():
        raise FileNotFoundError(f"Transaction file not found: {path}")

    raw = json.loads(path.read_text(encoding="utf-8"))
    return PatchTransaction.parse_obj(raw)


# For backwards compatibility with older CLI dispatchers
cmd_patches = run
