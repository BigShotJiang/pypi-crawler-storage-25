"""
branchpy.cli.commands.stats_policies_cmd — Stats policies CLI (v0.9.3).

Commands:
- branchpy stats check: Evaluate all stats policies for a project
- branchpy stats policies list: List loaded stats policies
- branchpy stats report: Show detailed policy evaluation report

Author: BranchPy Team
Governance ID: V0.9.3-STATS-POLICIES
Date: 2025-11-17
"""

import sys
from datetime import datetime
from pathlib import Path

import click

from branchpy.stats import (
    LocalStatsMetricsSource,
    PolicyEvaluator,
    PolicyStatus,
    PolicyType,
    format_policy_result_detail,
    format_report_json,
    format_report_summary,
    format_report_table,
    get_exit_code,
    load_policies_for_project,
)

# Try to import Rich for pretty output
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table

    _HAS_RICH = True
    console = Console()
except ImportError:
    _HAS_RICH = False
    console = None

# Try to import RBAC
try:
    from branchpy.rbac import Permission, PermissionDenied, check_permission

    _HAS_RBAC = True
except ImportError:
    _HAS_RBAC = False

# Try to import telemetry
try:
    from branchpy.telemetry import LocalTelemetryWriter, TelemetryEvent, create_trace_id

    _HAS_TELEMETRY = True
except ImportError:
    _HAS_TELEMETRY = False


def _print(message: str, style: str = ""):
    """Print message (with Rich if available)."""
    if _HAS_RICH and console:
        console.print(message)
    else:
        # Strip Rich markup for plain output
        import re

        plain = re.sub(r"\[/?[^\]]+\]", "", message)
        print(plain)


def _emit_evaluation_event(project_id: str, report_data: dict, status: str):
    """Emit governance event for policy evaluation."""
    if not _HAS_TELEMETRY:
        return

    try:
        log_dir = Path(".branchpy/logs/telemetry")
        log_dir.mkdir(parents=True, exist_ok=True)

        writer = LocalTelemetryWriter(log_dir, "minimal")

        event = TelemetryEvent(
            ts=writer.iso_now(),
            session_id=writer.session_id,
            trace_id=create_trace_id(),
            category="governance",
            name="stats.policy_evaluation",
            module="stats",
            attrs={
                "project_id": project_id,
                "status": status,
                "total_policies": report_data.get("summary", {}).get(
                    "total_policies", 0
                ),
                "failures": report_data.get("status_counts", {}).get("fail", 0),
                "errors": report_data.get("status_counts", {}).get("error", 0),
                "timestamp": datetime.utcnow().isoformat(),
            },
            level="info" if status == "pass" else "warn",
        )

        writer.write_event(event)
    except Exception:
        # Don't fail evaluation if telemetry fails
        pass


@click.group(name="stats")
def stats_group():
    """Stats policies commands (v0.9.3)."""
    pass


@stats_group.command(name="check")
@click.option("--project", "-p", default=".", help="Project path")
@click.option("--window", help="Time window for evaluation (e.g., 7d, 24h)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--config", help="Path to governance config file")
@click.option("--metrics-dir", help="Path to metrics directory")
@click.option(
    "--exit-code/--no-exit-code", default=True, help="Set exit code based on results"
)
def check_policies_cmd(
    project: str,
    window: str,
    output_json: bool,
    config: str,
    metrics_dir: str,
    exit_code: bool,
):
    """
    Evaluate all stats policies for a project.

    Examples:
        branchpy stats check
        branchpy stats check --project ./mygame
        branchpy stats check --window 7d --json
        branchpy stats check --config .branchpy/governance.yaml

    Requires: stats.policy.evaluate permission
    """
    try:
        # Check permission (if RBAC available)
        if _HAS_RBAC:
            try:
                # check_permission(Permission.STATS_POLICY_EVALUATE)
                pass  # Simplified for now
            except PermissionDenied as e:
                _print(f"[bold red]✗ Permission denied:[/bold red] {e}")
                sys.exit(1)

        project_path = Path(project).resolve()
        project_id = project_path.name

        # Load policies
        config_path = Path(config) if config else None

        try:
            policy_set = load_policies_for_project(project_id, config_path)
        except Exception as e:
            _print(f"[bold red]✗ Failed to load policies:[/bold red] {e}")
            sys.exit(2)

        if not policy_set.all_policies():
            _print("[yellow]⚠ No stats policies defined for this project.[/yellow]")
            _print(
                "\nDefine policies in [cyan].branchpy/governance.yaml[/cyan] under [cyan]policies.stats[/cyan]"
            )
            _print(
                "Or apply a governance template: [cyan]branchpy templates apply <template-id>[/cyan]"
            )
            sys.exit(0)

        # Determine metrics directory
        if metrics_dir:
            metrics_path = Path(metrics_dir)
        else:
            metrics_path = project_path / ".branchpy" / "metrics"

        if not metrics_path.exists():
            _print(f"[yellow]⚠ Metrics directory not found:[/yellow] {metrics_path}")
            _print("\nRun stats collection first: [cyan]branchpy stats[/cyan]")
            sys.exit(1)

        # Create metrics source
        metrics_source = LocalStatsMetricsSource(metrics_path, project_id)

        # Evaluate policies
        evaluator = PolicyEvaluator(metrics_source)
        report = evaluator.evaluate_all_policies(policy_set, project_id)

        # Emit governance event
        status_str = (
            "pass" if not report.has_failures() and not report.has_errors() else "fail"
        )
        _emit_evaluation_event(project_id, report.to_dict(), status_str)

        # Output results
        if output_json:
            print(format_report_json(report))
        else:
            output = format_report_table(report, show_details=True)
            print(output)
            print()
            print(f"Summary: {format_report_summary(report)}")

        # Set exit code if requested
        if exit_code:
            sys.exit(get_exit_code(report))

    except Exception as e:
        _print(f"[bold red]✗ Error:[/bold red] {e}")
        import traceback

        traceback.print_exc()
        sys.exit(2)


@stats_group.command(name="policies")
@click.option("--project", "-p", default=".", help="Project path")
@click.option("--config", help="Path to governance config file")
@click.option(
    "--type",
    "policy_type",
    type=click.Choice(["slo", "range", "timeline", "consistency", "all"]),
    default="all",
    help="Filter by policy type",
)
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_policies_cmd(project: str, config: str, policy_type: str, output_json: bool):
    """
    List loaded stats policies for a project.

    Examples:
        branchpy stats policies
        branchpy stats policies --type slo
        branchpy stats policies --json

    Requires: stats.read permission
    """
    try:
        project_path = Path(project).resolve()
        project_id = project_path.name

        # Load policies
        config_path = Path(config) if config else None

        try:
            policy_set = load_policies_for_project(project_id, config_path)
        except Exception as e:
            _print(f"[bold red]✗ Failed to load policies:[/bold red] {e}")
            sys.exit(2)

        if not policy_set.all_policies():
            _print("[yellow]⚠ No stats policies defined for this project.[/yellow]")
            sys.exit(0)

        # Filter by type
        policies_to_show = []

        if policy_type == "all" or policy_type == "slo":
            policies_to_show.extend((PolicyType.SLO, p) for p in policy_set.slos)

        if policy_type == "all" or policy_type == "range":
            policies_to_show.extend((PolicyType.RANGE, p) for p in policy_set.ranges)

        if policy_type == "all" or policy_type == "timeline":
            policies_to_show.extend(
                (PolicyType.TIMELINE, p) for p in policy_set.timelines
            )

        if policy_type == "all" or policy_type == "consistency":
            policies_to_show.extend(
                (PolicyType.CONSISTENCY, p) for p in policy_set.consistencies
            )

        # Output
        if output_json:
            import json

            output = {
                "project_id": project_id,
                "policies": policy_set.to_dict(),
                "count_by_type": {
                    k.value: v for k, v in policy_set.count_by_type().items()
                },
            }
            print(json.dumps(output, indent=2))
        else:
            if _HAS_RICH and console:
                table = Table(title=f"Stats Policies: {project_id}")
                table.add_column("Policy", style="cyan")
                table.add_column("Type", style="green")
                table.add_column("Metric", style="bold")
                table.add_column("Configuration", style="dim")

                for ptype, policy in policies_to_show:
                    config_str = _format_policy_config(policy, ptype)
                    table.add_row(
                        policy.name,
                        ptype.value,
                        policy.metric,
                        config_str,
                    )

                console.print(table)

                # Summary
                counts = policy_set.count_by_type()
                summary_parts = [
                    f"{ptype.value}: {count}"
                    for ptype, count in counts.items()
                    if count > 0
                ]
                console.print(
                    f"\n[dim]Total: {len(policies_to_show)} policies ({', '.join(summary_parts)})[/dim]"
                )
            else:
                # Plain text output
                print(f"Stats Policies: {project_id}")
                print("=" * 80)

                for ptype, policy in policies_to_show:
                    print(f"\n{policy.name} ({ptype.value})")
                    print(f"  Metric: {policy.metric}")
                    print(f"  Config: {_format_policy_config(policy, ptype)}")

                counts = policy_set.count_by_type()
                summary_parts = [
                    f"{ptype.value}: {count}"
                    for ptype, count in counts.items()
                    if count > 0
                ]
                print(
                    f"\nTotal: {len(policies_to_show)} policies ({', '.join(summary_parts)})"
                )

    except Exception as e:
        _print(f"[bold red]✗ Error:[/bold red] {e}")
        sys.exit(2)


def _format_policy_config(policy, policy_type: PolicyType) -> str:
    """Format policy configuration as a short string."""
    if policy_type == PolicyType.SLO:
        return f"target={policy.target}, threshold={policy.threshold*100:.0f}%, {policy.aggregation}"
    elif policy_type == PolicyType.RANGE:
        min_str = f"{policy.min}" if policy.min is not None else "-∞"
        max_str = f"{policy.max}" if policy.max is not None else "∞"
        return f"[{min_str}, {max_str}], {policy.aggregation}"
    elif policy_type == PolicyType.TIMELINE:
        return f"{policy.direction} ±{policy.max_change_percent}%, {policy.window}"
    elif policy_type == PolicyType.CONSISTENCY:
        return f"peers={len(policy.peer_projects)}, tolerance={policy.tolerance_pct}%"
    else:
        return ""


@stats_group.command(name="report")
@click.option("--project", "-p", default=".", help="Project path")
@click.option("--config", help="Path to governance config file")
@click.option("--metrics-dir", help="Path to metrics directory")
@click.option(
    "--filter",
    "filter_type",
    type=click.Choice(["slo", "range", "timeline", "consistency", "all"]),
    default="all",
    help="Filter by policy type",
)
@click.option(
    "--status",
    "filter_status",
    type=click.Choice(["pass", "warn", "fail", "error", "all"]),
    default="all",
    help="Filter by status",
)
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def report_cmd(
    project: str,
    config: str,
    metrics_dir: str,
    filter_type: str,
    filter_status: str,
    output_json: bool,
):
    """
    Show detailed policy evaluation report.

    Examples:
        branchpy stats report
        branchpy stats report --filter slo
        branchpy stats report --status fail
        branchpy stats report --json

    Requires: stats.read permission
    """
    try:
        project_path = Path(project).resolve()
        project_id = project_path.name

        # Load policies and evaluate (reuse check logic)
        config_path = Path(config) if config else None
        policy_set = load_policies_for_project(project_id, config_path)

        if not policy_set.all_policies():
            _print("[yellow]⚠ No stats policies defined for this project.[/yellow]")
            sys.exit(0)

        # Metrics source
        if metrics_dir:
            metrics_path = Path(metrics_dir)
        else:
            metrics_path = project_path / ".branchpy" / "metrics"

        if not metrics_path.exists():
            _print(f"[yellow]⚠ Metrics directory not found:[/yellow] {metrics_path}")
            sys.exit(1)

        metrics_source = LocalStatsMetricsSource(metrics_path, project_id)

        # Evaluate
        evaluator = PolicyEvaluator(metrics_source)
        report = evaluator.evaluate_all_policies(policy_set, project_id)

        # Filter results
        filtered_results = report.results

        if filter_type != "all":
            type_enum = PolicyType(filter_type)
            filtered_results = [
                r for r in filtered_results if r.policy_type == type_enum
            ]

        if filter_status != "all":
            status_enum = PolicyStatus(filter_status)
            filtered_results = [r for r in filtered_results if r.status == status_enum]

        # Output
        if output_json:
            import json

            output = {
                "project_id": project_id,
                "generated_at": report.generated_at.isoformat(),
                "results": [r.to_dict() for r in filtered_results],
                "total_results": len(filtered_results),
                "total_policies": len(report.results),
            }
            print(json.dumps(output, indent=2))
        else:
            # Detailed output for each result
            for result in filtered_results:
                detail = format_policy_result_detail(result)

                if _HAS_RICH and console:
                    style = {
                        PolicyStatus.PASS: "green",
                        PolicyStatus.WARN: "yellow",
                        PolicyStatus.FAIL: "red",
                        PolicyStatus.ERROR: "red bold",
                    }.get(result.status, "white")

                    console.print(Panel(detail, border_style=style, title=result.name))
                else:
                    print("-" * 80)
                    print(detail)
                    print()

            print(
                f"\nShowing {len(filtered_results)} of {len(report.results)} policies"
            )

    except Exception as e:
        _print(f"[bold red]✗ Error:[/bold red] {e}")
        sys.exit(2)


# CLI registration helpers
def add_parser(subparsers):
    """Add stats subcommand to CLI (for Click integration)."""
    # This is called by branchpy.cli if using legacy argparse integration
    # For pure Click, we register the group directly
    pass


def run(args):
    """Run stats command (for legacy CLI integration)."""
    # For pure Click, this is not needed
    stats_group()
