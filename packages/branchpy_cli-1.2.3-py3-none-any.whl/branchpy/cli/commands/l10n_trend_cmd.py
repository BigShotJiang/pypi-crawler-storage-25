# branchpy/cli/commands/l10n_trend_cmd.py
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from branchpy.localization.trend_visualizer import (
    build_datasets,
    export_annotated_png,
    export_embed_html,
    load_annotations,
    load_baseline_snapshot,
    load_theme,
    render_matplotlib_chart,
    render_plotly_chart,
    render_weighted_gauge,
    save_theme,
)

DEFAULT_TREND_PATH = Path(".branchpy/reports/trends/coverage_trend.json")


def build_arg_parser(subparsers):
    p = subparsers.add_parser("trend", help="Visualize localization coverage trends")
    p.add_argument(
        "--trend-path",
        default=str(DEFAULT_TREND_PATH),
        help="Path to coverage_trend.json",
    )
    p.add_argument("--graph", action="store_true", help="Render charts (PNG + HTML)")
    p.add_argument(
        "--png-out",
        default=".branchpy/reports/trends/trend.png",
        help="Destination path for PNG chart (matplotlib)",
    )
    p.add_argument(
        "--html-out",
        default=".branchpy/reports/trends/trend.html",
        help="Destination path for HTML chart (Plotly)",
    )
    p.add_argument(
        "--export",
        choices=["html", "json"],
        default=None,
        help="Export report (html) or data (json) to file",
    )
    p.add_argument(
        "--include-weighted",
        action="store_true",
        help="Overlay weighted score if available",
    )
    p.add_argument(
        "--compare",
        type=str,
        default=None,
        help="Pin a baseline date (YYYY-MM-DD) to compute deltas and mark a vertical line",
    )
    p.add_argument(
        "--theme",
        choices=["light", "dark"],
        default=None,
        help="Force light/dark theme for generated HTML (overrides saved theme)",
    )
    p.add_argument(
        "--persist-theme",
        action="store_true",
        help="Save the chosen theme to .branchpy/reports/trends/theme.json",
    )
    p.add_argument(
        "--control-center",
        action="store_true",
        help="Generate a Control Center dashboard page (HTML) with gauge + chart",
    )
    p.add_argument(
        "--embed",
        action="store_true",
        help="Generate embeddable widget (no chrome, inline CSS/JS)",
    )
    p.add_argument(
        "--embed-sign",
        type=str,
        metavar="SECRET",
        default=None,
        help="Sign embed URL with HMAC token (requires --embed)",
    )
    p.add_argument(
        "--annotations",
        choices=["on", "off"],
        default="on",
        help="Enable/disable annotation rendering and UI (default: on)",
    )
    p.add_argument(
        "--annotation-ui",
        choices=["on", "off"],
        default="on",
        help="Enable/disable click-to-annotate JavaScript UI (default: on)",
    )
    p.add_argument(
        "--export-annotations",
        type=str,
        metavar="PATH",
        default=None,
        help="Export annotations.json to custom path",
    )
    p.add_argument(
        "--export-annotated",
        choices=["html", "png"],
        default=None,
        help="Export annotated chart (html: self-contained HTML, png: kaleido PNG)",
    )
    p.add_argument(
        "--live-dashboard",
        action="store_true",
        help="Start WebSocket server for live dashboard updates (Gate 10B)",
    )
    p.add_argument(
        "--ws-port",
        type=int,
        default=8765,
        help="WebSocket server port (default: 8765, requires --live-dashboard)",
    )
    p.add_argument(
        "--ws-host",
        type=str,
        default=None,
        help="WebSocket server host (default: from BRANCHPY_WS_HOST env or 127.0.0.1)",
    )
    p.add_argument(
        "--fast-start",
        action="store_true",
        help="Defer heavy preload until first client connects (env: BRANCHPY_WS_FAST_START=1)",
    )
    p.set_defaults(func=run_trend_cmd)
    return p


def _serialize_summary(datasets, weighted):
    from typing import Any, Dict

    data: Dict[str, Any] = {
        "locales": [
            {
                "locale": d.locale,
                "current_coverage": d.current_coverage,
                "trend_slope": d.trend_slope,
                "trend_direction": d.trend_direction,
                "points": len(d.coverages),
                "tier": d.tier,
                "baseline_date": (
                    d.baseline_date.isoformat() if d.baseline_date else None
                ),
                "baseline_coverage": d.baseline_coverage,
                "delta_coverage": d.delta_coverage,
                "baseline_slope": d.baseline_slope,
                "delta_slope": d.delta_slope,
            }
            for d in datasets
        ]
    }
    if weighted is not None:
        data["weighted"] = {
            "current_score": weighted.current_score,
            "points": len(weighted.weighted_scores),
        }
    return data


def _render_html_report(
    datasets, weighted, plot_div: str, compare_date_text: Optional[str], theme: str
) -> str:
    # Minimal, dependency-free HTML wrapper; Plotly script is embedded by render_plotly_chart (cdn)
    dark = theme == "dark"
    rows = []
    for d in datasets:
        # Delta coloring
        dc = d.delta_coverage
        ds = d.delta_slope
        delta_cov_html = (
            "-"
            if dc is None
            else (
                f"<span class='badge pos'>+{dc:.1f}pp</span>"
                if dc >= 0
                else f"<span class='badge neg'>{dc:.1f}pp</span>"
            )
        )
        delta_slope_html = (
            "-"
            if ds is None
            else (
                f"<span class='badge pos'>+{ds:.3f}</span>"
                if ds >= 0
                else f"<span class='badge neg'>{ds:.3f}</span>"
            )
        )
        baseline_cov = (
            f"{d.baseline_coverage:.1f}%" if d.baseline_coverage is not None else "-"
        )
        points = f"{len(d.coverages):,}"
        rows.append(
            f"<tr><td>{d.locale}</td>"
            f"<td class='num'>{d.current_coverage:.1f}%</td>"
            f"<td>{d.trend_direction}</td>"
            f"<td class='num'>{d.trend_slope:.3f}%/day</td>"
            f"<td>{d.tier or '-'}</td>"
            f"<td class='num'>{points}</td>"
            f"<td class='num'>{baseline_cov}</td>"
            f"<td>{delta_cov_html}</td>"
            f"<td>{delta_slope_html}</td></tr>"
        )
    weighted_html = ""
    if weighted is not None:
        weighted_html = f"<p><b>Weighted score:</b> {weighted.current_score:.2f}%</p>"
    compare_banner = (
        f"<p><b>Pinned baseline:</b> {compare_date_text}</p>"
        if compare_date_text
        else ""
    )
    return f"""<!doctype html>
<html><head><meta charset="utf-8">
<title>Localization Trends</title>
<style>
:root{{color-scheme:{'dark' if dark else 'light'};}}
body{{font-family:ui-sans-serif,system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:24px;background:{'#111827' if dark else '#ffffff'};color:{'#e5e7eb' if dark else '#111827'};}}
h1{{margin-bottom:8px}}
small{{color:{'#9ca3af' if dark else '#666'};}}
.code{{font-family:ui-monospace,Menlo,Consolas,monospace;background:{'#1f2937' if dark else '#f3f4f6'};padding:2px 4px;border-radius:4px}}
table{{border-collapse:collapse;margin-top:16px;width:100%}}
th,td{{border:1px solid {('#374151' if dark else '#e5e7eb')};padding:6px 8px;text-align:left;font-size:14px;vertical-align:top}}
thead th{{background:{('#111827' if dark else '#f9fafb')}; position:sticky; top:0; z-index:2}}
.num{{text-align:right; font-variant-numeric: tabular-nums;}}
.badge{{padding:2px 6px;border-radius:9999px;font-weight:600;}}
.badge.pos{{background:{'#065f46' if dark else '#dcfce7'}; color:{'#34d399' if dark else '#065f46'};}}
.badge.neg{{background:{'#7f1d1d' if dark else '#fee2e2'}; color:{'#f87171' if dark else '#7f1d1d'};}}
.plotly-container div{{overflow:visible !important}}
@media (max-width: 720px){{table, thead, tbody, th, td, tr{{font-size:13px}}}}
@media print{{
  body{{background:#fff;color:#000}}
  .plotly-container, button{{display:none}}
  table{{page-break-inside:auto}}
  tr{{page-break-inside:avoid; page-break-after:auto}}
}}
</style>
</head><body>
<h1>Localization Trends</h1>
<small>Source: <span class="code">.branchpy/reports/trends/coverage_trend.json</span></small>
{compare_banner}
{weighted_html}
<div class="plotly-container" style="margin-top:12px">{plot_div}</div>
<table role="table" aria-describedby="meta"><thead><tr>
<th scope="col">Locale</th><th scope="col">Current</th><th scope="col">Dir</th>
<th scope="col">Slope</th><th scope="col">Tier</th><th scope="col">Points</th>
<th scope="col">Baseline</th><th scope="col">Δ Coverage</th><th scope="col">Δ Slope</th>
</tr></thead><tbody>{''.join(rows)}</tbody></table>
<p id="meta" style="margin-top:8px"><small>Positive deltas shown in green, negatives in red. Table header is sticky for long lists.</small></p>
</body></html>"""


def _render_control_center_page(
    datasets, weighted, plot_div: str, gauge_div: str, theme: str
) -> str:
    dark = theme == "dark"
    # Simple dashboard-style page with a header, gauge, actions, and the chart+table.
    rows = []
    for d in datasets:
        dc = d.delta_coverage
        ds = d.delta_slope
        delta_cov_html = (
            "-"
            if dc is None
            else (
                f"<span class='badge pos'>+{dc:.1f}pp</span>"
                if dc >= 0
                else f"<span class='badge neg'>{dc:.1f}pp</span>"
            )
        )
        delta_slope_html = (
            "-"
            if ds is None
            else (
                f"<span class='badge pos'>+{ds:.3f}</span>"
                if ds >= 0
                else f"<span class='badge neg'>{ds:.3f}</span>"
            )
        )
        baseline_cov = (
            f"{d.baseline_coverage:.1f}%" if d.baseline_coverage is not None else "-"
        )
        points = f"{len(d.coverages):,}"
        rows.append(
            f"<tr><td>{d.locale}</td>"
            f"<td class='num'>{d.current_coverage:.1f}%</td>"
            f"<td>{d.trend_direction}</td>"
            f"<td class='num'>{d.trend_slope:.3f}%/day</td>"
            f"<td>{d.tier or '-'}</td>"
            f"<td class='num'>{points}</td>"
            f"<td class='num'>{baseline_cov}</td>"
            f"<td>{delta_cov_html}</td>"
            f"<td>{delta_slope_html}</td></tr>"
        )
    table = "".join(rows)
    return f"""<!doctype html>
<html><head><meta charset="utf-8">
<title>BranchPy Control Center — Localization Trends</title>
<style>
:root{{color-scheme:{'dark' if dark else 'light'};}}
body{{font-family:ui-sans-serif,system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:24px;background:{'#111827' if dark else '#ffffff'};color:{'#e5e7eb' if dark else '#111827'};}}
h1{{margin:0 0 12px}}
.row{{display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap}}
.card{{border:1px solid {('#374151' if dark else '#e5e7eb')};border-radius:12px;padding:12px;flex:1;min-width:320px;background:{('#0b1220' if dark else '#ffffff')};}}
button{{padding:8px 12px;border:1px solid {('#4b5563' if dark else '#d1d5db')};border-radius:8px;background:{('#1f2937' if dark else '#f9fafb')};cursor:pointer;color:{('#e5e7eb' if dark else '#111827')};}}
button:hover{{background:{('#374151' if dark else '#f3f4f6')};}}
button[aria-label]{{cursor:pointer}}
table{{border-collapse:collapse;margin-top:16px;width:100%}}
th,td{{border:1px solid {('#374151' if dark else '#e5e7eb')};padding:6px 8px;text-align:left;font-size:14px;vertical-align:top}}
thead th{{background:{('#111827' if dark else '#f9fafb')}; position:sticky; top:0; z-index:2}}
.num{{text-align:right; font-variant-numeric: tabular-nums;}}
.muted{{color:#6b7280}}
.badge{{padding:2px 6px;border-radius:9999px;font-weight:600;}}
.badge.pos{{background:{'#065f46' if dark else '#dcfce7'}; color:{'#34d399' if dark else '#065f46'};}}
.badge.neg{{background:{'#7f1d1d' if dark else '#fee2e2'}; color:{'#f87171' if dark else '#7f1d1d'};}}
.plotly-container div{{overflow:visible !important}}
@media (max-width: 720px){{table, thead, tbody, th, td, tr{{font-size:13px}}}}
@media print{{
  body{{background:#fff;color:#000}}
  .plotly-container, button, .card:first-of-type{{display:none}}
  table{{page-break-inside:auto}}
  tr{{page-break-inside:avoid; page-break-after:auto}}
}}
</style>
</head><body>
<h1>BranchPy Control Center — Localization Trends</h1>
<div class="row" style="margin-bottom:12px">
  <div class="card" style="max-width:380px">
    <h3 style="margin:4px 0 8px">Weighted Score</h3>
    {gauge_div}
    <div class="muted">Source: coverage_trend.json</div>
  </div>
  <div class="card">
    <h3 style="margin:4px 0 8px">Actions</h3>
    <button onclick="location.reload()" aria-label="Refresh dashboard">Refresh</button>
    <button onclick="window.open('trend.html','_blank')" aria-label="Open detailed trend report">Open Trend Report</button>
    <div class="muted" style="margin-top:8px">Use the buttons to refresh or open the full report.</div>
  </div>
</div>
<div class="card">
  <h3 style="margin:4px 0 8px">Trend Chart</h3>
  <div class="plotly-container">{plot_div}</div>
</div>
<div class="card">
  <h3 style="margin:4px 0 8px">Locale Summary</h3>
  <table role="table" aria-describedby="cc-meta"><thead><tr>
    <th scope="col">Locale</th><th scope="col">Current</th><th scope="col">Dir</th>
    <th scope="col">Slope</th><th scope="col">Tier</th><th scope="col">Points</th>
    <th scope="col">Baseline</th><th scope="col">Δ Coverage</th><th scope="col">Δ Slope</th>
  </tr></thead><tbody>{table}</tbody></table>
  <p id="cc-meta" style="margin-top:8px"><small class="muted">Positive deltas in green, negatives in red. Header is sticky.</small></p>
</div>
</body></html>"""


def _generate_signed_url(secret: str, url: str, expiry_hours: int = 24) -> dict:
    """
    Generate HMAC-signed URL with expiry.

    Args:
        secret: HMAC secret key
        url: URL to sign
        expiry_hours: Token validity period (default: 24h)

    Returns:
        dict with keys: url, token, expiry (ISO 8601)
    """
    import hashlib
    import hmac
    from datetime import datetime, timedelta, timezone

    expiry = datetime.now(timezone.utc) + timedelta(hours=expiry_hours)
    expiry_str = expiry.strftime("%Y-%m-%dT%H:%M:%SZ")

    message = f"{url}|{expiry_str}"
    token = hmac.new(
        secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256
    ).hexdigest()

    return {"url": url, "token": token, "expiry": expiry_str}


def _render_embed_widget(
    datasets, theme: str = "light", signed_url: Optional[dict] = None
) -> str:
    """
    Render minimal embeddable widget (no chrome, inline CSS/JS).

    Args:
        datasets: List of TrendDataset objects
        theme: "light" or "dark"
        signed_url: Optional dict from _generate_signed_url()

    Returns:
        HTML string (self-contained, suitable for iframe)
    """
    import plotly.graph_objects as go

    # Theme colors
    if theme == "dark":
        bg, text, muted = "#1a1a1a", "#e0e0e0", "#888"
    else:
        bg, text, muted = "#fff", "#333", "#999"

    # Generate Plotly chart (single chart, all locales)
    fig = go.Figure()
    for ds in datasets:
        fig.add_trace(
            go.Scatter(
                x=ds.dates,  # List of datetime objects
                y=ds.coverages,  # List of float percentages
                mode="lines+markers",
                name=ds.locale,
            )
        )

    fig.update_layout(
        template="plotly_dark" if theme == "dark" else "plotly",
        margin=dict(l=20, r=20, t=20, b=20),
        height=400,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )

    chart_html = fig.to_html(
        include_plotlyjs="cdn",  # Use CDN for Day 1
        div_id="embed-chart",
        config={"displayModeBar": False},
    )

    # Optional signed URL footer
    footer = ""
    if signed_url:
        footer = f"""
        <div class="embed-footer">
            🔒 Signed URL • Valid until: {signed_url["expiry"]} • Token: {signed_url["token"][:8]}...
        </div>
        """

    # Minimal HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BranchPy Coverage Trend (Embed)</title>
    <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ 
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        background: {bg};
        color: {text};
        padding: 8px;
    }}
    .embed-container {{ width: 100%; min-height: 300px; }}
    .embed-footer {{ 
        font-size: 11px; 
        color: {muted}; 
        text-align: center; 
        margin-top: 8px; 
    }}
    </style>
</head>
<body>
    <div class="embed-container">
        {chart_html}
    </div>
    {footer}
</body>
</html>
"""

    return html


def run_trend_cmd(args, env):
    # Validation: --embed-sign requires --embed
    if getattr(args, "embed_sign", None) and not getattr(args, "embed", False):
        env.logger.error("[trend] --embed-sign requires --embed flag")
        return 1

    # Validation: --embed is incompatible with --control-center
    if getattr(args, "embed", False) and args.control_center:
        env.logger.error("[trend] --embed is incompatible with --control-center")
        return 1

    # Validation: --embed forces --export html
    if getattr(args, "embed", False) and args.export != "html":
        if args.export:
            env.logger.warn(
                f"[trend] --embed overrides --export {args.export}, forcing 'html'"
            )
        args.export = "html"

    trend_path = Path(args.trend_path)
    datasets, weighted = build_datasets(trend_path)
    compare_dt = None
    if args.compare:
        compare_dt = load_baseline_snapshot(datasets, args.compare)
        if compare_dt:
            env.logger.info(
                f"[trend] Pinned baseline date: {compare_dt.strftime('%Y-%m-%d')}"
            )
        else:
            env.logger.warn(
                f"[trend] Ignored --compare (unrecognized date): {args.compare}"
            )

    # Theme resolve/persist (optional)
    chosen_theme = (args.theme or load_theme(Path(env.project_root))).lower()
    if args.persist_theme and args.theme:
        save_theme(args.theme, Path(env.project_root))

    # Load annotations (if enabled)
    annotations = []
    annotation_ui_enabled = False
    if getattr(args, "annotations", "on") == "on":
        annotations = load_annotations(Path(env.project_root))
        if annotations:
            env.logger.info(f"[trend] Loaded {len(annotations)} annotation(s)")

        # Enable annotation UI if requested (default: on)
        if getattr(args, "annotation_ui", "on") == "on":
            annotation_ui_enabled = True

    # Export annotations to custom path
    if getattr(args, "export_annotations", None):
        export_path = Path(args.export_annotations)
        if annotations:
            export_path.parent.mkdir(parents=True, exist_ok=True)
            import shutil

            src = (
                Path(env.project_root)
                / ".branchpy"
                / "reports"
                / "trends"
                / "annotations.json"
            )
            if src.exists():
                shutil.copy2(src, export_path)
                env.logger.info(f"[trend] Annotations exported → {export_path}")
            else:
                env.logger.warn("[trend] No annotations.json found to export")
        else:
            env.logger.warn("[trend] No annotations to export")

    # Export annotated chart (HTML or PNG)
    if getattr(args, "export_annotated", None):
        if not annotations:
            env.logger.warn("[trend] No annotations to export in annotated chart")

        if args.export_annotated == "html":
            # Generate chart with annotations
            div = render_plotly_chart(
                datasets,
                weighted if args.include_weighted else None,
                include_weighted=args.include_weighted,
                compare_date=compare_dt,
                theme=chosen_theme,
                annotations=annotations,
                enable_annotation_ui=False,  # No UI in export
            )
            annotated_html = export_embed_html(div, chosen_theme)
            export_path = Path(args.html_out).with_name("annotated_export.html")
            export_path.parent.mkdir(parents=True, exist_ok=True)
            export_path.write_text(annotated_html, encoding="utf-8")
            env.logger.info(f"[trend] Annotated HTML exported → {export_path}")

        elif args.export_annotated == "png":
            export_path = Path(args.png_out).with_name("annotated_export.png")
            success = export_annotated_png(
                datasets,
                weighted if args.include_weighted else None,
                annotations,
                export_path,
                theme=chosen_theme,
            )
            if success:
                env.logger.info(f"[trend] Annotated PNG exported → {export_path}")
            else:
                env.logger.info(
                    "[trend] PNG export unavailable (kaleido not installed). Install: pip install kaleido"
                )
                # Non-fatal, exit 0

    # Embed widget (short-circuit other exports)
    if getattr(args, "embed", False):
        signed_url = None
        if getattr(args, "embed_sign", None):
            # Generate signed URL (use html_out path as URL)
            html_path = Path(args.html_out)
            url = str(html_path.resolve())
            signed_url = _generate_signed_url(args.embed_sign, url)
            env.logger.info(
                f"[trend] Generated signed URL (expires: {signed_url['expiry']})"
            )

        embed_html = _render_embed_widget(
            datasets, theme=chosen_theme, signed_url=signed_url
        )
        embed_path = Path(args.html_out)
        embed_path.parent.mkdir(parents=True, exist_ok=True)
        embed_path.write_text(embed_html, encoding="utf-8")
        env.logger.info(f"[trend] Embed widget saved → {embed_path}")
        return 0

    # Graphs
    if args.graph:
        # PNG (matplotlib)
        png_path = Path(args.png_out)
        render_matplotlib_chart(
            datasets,
            weighted if args.include_weighted else None,
            png_path,
            include_weighted=args.include_weighted,
            compare_date=compare_dt,
        )
        env.logger.info(f"[trend] PNG saved → {png_path}")

        # HTML (Plotly)
        div = render_plotly_chart(
            datasets,
            weighted if args.include_weighted else None,
            include_weighted=args.include_weighted,
            compare_date=compare_dt,
            theme=chosen_theme,
            annotations=annotations,
            enable_annotation_ui=annotation_ui_enabled,
        )
        html = _render_html_report(
            datasets,
            weighted if args.include_weighted else None,
            div,
            compare_date_text=(compare_dt.strftime("%Y-%m-%d") if compare_dt else None),
            theme=chosen_theme,
        )
        html_path = Path(args.html_out)
        html_path.parent.mkdir(parents=True, exist_ok=True)
        html_path.write_text(html, encoding="utf-8")
        env.logger.info(f"[trend] HTML saved → {html_path}")

    # Control Center panel (dashboard webview shim)
    if args.control_center:
        div = render_plotly_chart(
            datasets,
            weighted if args.include_weighted else None,
            include_weighted=args.include_weighted,
            theme=chosen_theme,
            annotations=annotations,
            enable_annotation_ui=annotation_ui_enabled,
        )
        gauge = render_weighted_gauge(weighted if args.include_weighted else None)
        cc_html = _render_control_center_page(
            datasets,
            weighted if args.include_weighted else None,
            div,
            gauge,
            theme=chosen_theme,
        )
        cc_path = Path(args.html_out).with_name("control_center.html")
        cc_path.parent.mkdir(parents=True, exist_ok=True)
        cc_path.write_text(cc_html, encoding="utf-8")
        env.logger.info(f"[trend] Control Center page saved → {cc_path}")

    # Exports
    if args.export == "json":
        out = _serialize_summary(datasets, weighted if args.include_weighted else None)
        path = Path(args.html_out).with_suffix(".summary.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(out, indent=2), encoding="utf-8")
        env.logger.info(f"[trend] Summary JSON saved → {path}")
    elif args.export == "html" and not args.graph:
        # if user only wants HTML (no PNG), still render Plotly + table
        div = render_plotly_chart(
            datasets,
            weighted if args.include_weighted else None,
            include_weighted=args.include_weighted,
            compare_date=compare_dt,
            theme=chosen_theme,
            annotations=annotations,
            enable_annotation_ui=annotation_ui_enabled,
        )
        html = _render_html_report(
            datasets,
            weighted if args.include_weighted else None,
            div,
            compare_date_text=(compare_dt.strftime("%Y-%m-%d") if compare_dt else None),
            theme=chosen_theme,
        )
        html_path = Path(args.html_out)
        html_path.parent.mkdir(parents=True, exist_ok=True)
        html_path.write_text(html, encoding="utf-8")
        env.logger.info(f"[trend] HTML saved → {html_path}")

    # WebSocket server for live dashboard updates (Gate 10B)
    if getattr(args, "live_dashboard", False):
        try:
            import asyncio
            import os

            from branchpy.dashboard.websocket_server import (
                WebSocketServer,
                run_dashboard_server,
            )

            ws_port = getattr(args, "ws_port", 8765)
            ws_host = getattr(args, "ws_host", None) or os.getenv(
                "BRANCHPY_WS_HOST", "127.0.0.1"
            )
            fast_start = (
                getattr(args, "fast_start", False)
                or os.getenv("BRANCHPY_WS_FAST_START") == "1"
            )

            # Define preload callable for heavy initialization
            def _preload_heavy():
                """Heavy preload work deferred in FAST_START mode."""
                # Future: warm caches, precompute baselines, etc.
                # For now, this is a no-op placeholder
                return True

            env.logger.info(
                f"[trend] Starting WebSocket server on ws://{ws_host}:{ws_port}"
            )
            if fast_start:
                env.logger.info(
                    "[trend] FAST_START mode: deferring heavy work until first client"
                )
            env.logger.info("[trend] Dashboard will auto-update on file changes")
            env.logger.info("[trend] Press Ctrl+C to stop server")

            # Create server with FAST_START support
            server = WebSocketServer(
                host=ws_host,
                port=ws_port,
                fast_start=fast_start,
                preload_callable=_preload_heavy if fast_start else None,
            )

            # Run server in async context
            async def _run_server():
                await server.start()
                # Keep running until interrupted
                try:
                    await asyncio.Event().wait()
                except asyncio.CancelledError:
                    await server.stop()

            asyncio.run(_run_server())

        except ImportError as e:
            env.logger.error(f"[trend] WebSocket server unavailable: {e}")
            env.logger.info("[trend] Install websockets: pip install websockets")
            return 1

        except KeyboardInterrupt:
            env.logger.info("[trend] WebSocket server stopped")

        except Exception as e:
            env.logger.error(f"[trend] WebSocket server error: {e}")
            return 1

    return 0
