"""
Redo command - reapply last undone operation.
"""

import click

from branchpy.history.journal import get_journal
from branchpy.telemetry import emit_event


@click.command("redo")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed patch information")
def redo_cmd(verbose: bool) -> None:
    """
    Redo the last undone BranchPy operation.

    This reapplies an operation that was previously undone.

    Only operations that were undone via 'branchpy undo' can be redone.
    """
    journal = get_journal()

    if not journal.can_redo():
        click.echo("Nothing to redo.")
        return

    # Emit telemetry
    emit_event("journal.operation.redo.started", {})

    try:
        patch = journal.redo()

        if patch is None:
            click.echo("Nothing to redo.")
            emit_event(
                "journal.operation.redo.completed",
                {"success": False, "reason": "empty_stack"},
            )
            return

        # Success
        click.echo(f"✓ Redid: {patch.describe()}")

        if verbose:
            click.echo("\nPatch details:")
            click.echo(f"  {patch.to_dict()}")

        emit_event(
            "journal.operation.redo.completed",
            {
                "success": True,
                "patch_description": patch.describe(),
            },
        )

    except Exception as e:
        click.echo(f"✗ Error during redo: {e}", err=True)
        emit_event("journal.operation.redo.failed", {"error": str(e)})
        raise
