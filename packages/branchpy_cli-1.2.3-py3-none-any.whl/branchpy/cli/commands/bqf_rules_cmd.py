"""
BQF Rules CLI Commands - Step 8 Task 8

Provides CLI interface for semantic rule registry:
- list-rules: View all registered rules
- show-rule: Get detailed rule information
- export-catalog: Export rule catalog to JSON/TOML
- export-policies: Export BQF policies (Step 7 integration)
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Optional

from branchpy.semantics.propagation.rule_registry import (
    RuleCategory,
    RuleMetadata,
    RuleSeverity,
    get_global_registry,
    register_builtin_rules,
)

# ============================================================================
# Formatting Utilities
# ============================================================================


def render_table(rules: List[RuleMetadata], columns: Optional[List[str]] = None) -> str:
    """
    Render rules as ASCII table.

    Args:
        rules: List of rules to render
        columns: Columns to display (default: id, category, severity, legacy, name)

    Returns:
        Formatted table string
    """
    if not rules:
        return "No rules found."

    if columns is None:
        columns = ["id", "category", "severity", "legacy", "name"]

    # Build rows
    rows = []
    for rule in rules:
        row = []
        if "id" in columns:
            row.append(rule.rule_id)
        if "category" in columns:
            row.append(rule.category.value)
        if "severity" in columns:
            row.append(rule.severity.value)
        if "legacy" in columns:
            row.append(rule.legacy_warning_id or "-")
        if "name" in columns:
            row.append(rule.name)
        rows.append(row)

    # Calculate column widths
    headers = []
    if "id" in columns:
        headers.append("ID")
    if "category" in columns:
        headers.append("Category")
    if "severity" in columns:
        headers.append("Severity")
    if "legacy" in columns:
        headers.append("Legacy")
    if "name" in columns:
        headers.append("Short Description")

    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))

    # Format output
    lines = []

    # Header
    header_line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    lines.append(header_line)
    lines.append("-" * len(header_line))

    # Rows
    for row in rows:
        line = "  ".join(str(cell).ljust(w) for cell, w in zip(row, widths))
        lines.append(line)

    return "\n".join(lines)


def serialize_rules_to_json(rules: List[RuleMetadata]) -> str:
    """
    Serialize rules to JSON format.

    Args:
        rules: List of rules

    Returns:
        JSON string
    """
    data = []
    for rule in rules:
        data.append(
            {
                "semantic_rule_id": rule.rule_id,
                "category": rule.category.value,
                "severity": rule.severity.value,
                "legacy_codes": (
                    [rule.legacy_warning_id] if rule.legacy_warning_id else []
                ),
                "title": rule.name,
                "summary": rule.description,
                "tags": rule.tags,
                "message_template": rule.message_template,
                "version": rule.version,
                "status": rule.status.value,
                "source": rule.source.value,
            }
        )
    return json.dumps(data, indent=2)


def serialize_rule_detailed(rule: RuleMetadata, format_type: str = "text") -> str:
    """
    Serialize single rule with full details.

    Args:
        rule: Rule to serialize
        format_type: 'text', 'json', or 'yaml'

    Returns:
        Formatted string
    """
    if format_type == "json":
        data = rule.to_dict()
        return json.dumps(data, indent=2)

    elif format_type == "yaml":
        import yaml

        data = rule.to_dict()
        return yaml.dump(data, default_flow_style=False)

    else:  # text
        lines = []
        lines.append(f"Rule: {rule.rule_id}")
        lines.append(f"Category: {rule.category.value}")
        lines.append(f"Severity: {rule.severity.value}")
        if rule.legacy_warning_id:
            lines.append(f"Legacy codes: {rule.legacy_warning_id}")
        lines.append("")

        lines.append("Title:")
        lines.append(f"  {rule.name}")
        lines.append("")

        lines.append("Description:")
        lines.append(f"  {rule.description}")
        lines.append("")

        if rule.message_template:
            lines.append("Message Template:")
            lines.append(f"  {rule.message_template}")
            lines.append("")

        if rule.fixes:
            lines.append("Suggested Remediation:")
            for fix in rule.fixes:
                lines.append(f"  - {fix}")
            lines.append("")

        if rule.examples:
            lines.append("Examples:")
            for example in rule.examples:
                for line in example.split("\n"):
                    lines.append(f"  {line}")
            lines.append("")

        if rule.tags:
            lines.append("Tags:")
            lines.append(f"  {', '.join(rule.tags)}")
            lines.append("")

        lines.append(f"Version: {rule.version}")
        lines.append(f"Status: {rule.status.value}")
        lines.append(f"Source: {rule.source.value}")

        return "\n".join(lines)


# ============================================================================
# CLI Command Handlers
# ============================================================================


def cmd_list_rules(args: argparse.Namespace) -> int:
    """
    List all registered rules.

    Args:
        args: Parsed arguments with format, category, severity

    Returns:
        Exit code (0 = success)
    """
    registry = get_global_registry()
    register_builtin_rules()  # Ensure rules are loaded

    # Apply filters
    category = None
    if args.category:
        try:
            category = RuleCategory(args.category)
        except ValueError:
            print(f"Error: Invalid category '{args.category}'", file=sys.stderr)
            print(
                f"Valid categories: {', '.join(c.value for c in RuleCategory)}",
                file=sys.stderr,
            )
            return 1

    severity = None
    if args.severity:
        try:
            severity = RuleSeverity(args.severity)
        except ValueError:
            print(f"Error: Invalid severity '{args.severity}'", file=sys.stderr)
            print(
                f"Valid severities: {', '.join(s.value for s in RuleSeverity)}",
                file=sys.stderr,
            )
            return 1

    rules = registry.list_rules(category=category, severity=severity)

    if not rules:
        print("No rules found matching criteria.")
        return 0

    # Format output
    if args.format == "json":
        print(serialize_rules_to_json(rules))
    else:  # table
        print(render_table(rules))
        print(f"\nTotal: {len(rules)} rules")

    return 0


def cmd_show_rule(args: argparse.Namespace) -> int:
    """
    Show detailed information for a specific rule.

    Args:
        args: Parsed arguments with rule_id and format

    Returns:
        Exit code (0 = success, 1 = not found)
    """
    registry = get_global_registry()
    register_builtin_rules()

    rule = registry.get_rule(args.rule_id)

    if not rule:
        print(f"Error: semantic rule '{args.rule_id}' not found.", file=sys.stderr)
        return 1

    output = serialize_rule_detailed(rule, args.format)
    print(output)

    return 0


def cmd_export_catalog(args: argparse.Namespace) -> int:
    """
    Export entire rule catalog to file.

    Args:
        args: Parsed arguments with format and out path

    Returns:
        Exit code (0 = success)
    """
    registry = get_global_registry()
    register_builtin_rules()

    # Determine output path
    if args.out:
        output_path = Path(args.out)
    else:
        ext = "json" if args.format == "json" else "toml"
        output_path = Path(f"rules_catalog.{ext}")

    # Export
    if args.format == "json":
        content = registry.export_to_json(output_path)
    else:  # toml
        content = registry.export_to_toml(output_path)

    print(f"Rule catalog exported to: {output_path}")

    # Get statistics
    stats = registry.get_statistics()
    print(f"Total rules: {stats['total_rules']}")
    print(f"By category: {stats['by_category']}")

    return 0


def cmd_export_policies(args: argparse.Namespace) -> int:
    """
    Export BQF policies to file (Step 7 integration).

    Args:
        args: Parsed arguments with format and out path

    Returns:
        Exit code (0 = success)
    """
    # This is a placeholder for full policy export
    # In practice, you'd have a PolicyRegistry or load policies from config

    # Determine output path
    if args.out:
        output_path = Path(args.out)
    else:
        ext = "json" if args.format == "json" else "toml"
        output_path = Path(f"policies.{ext}")

    # For now, create a basic policy structure
    policies = [
        {
            "policy_id": "BPF_SEM_FLOW_DEFAULT",
            "title": "Default semantic flow policy",
            "description": "Enforces flow analysis rules",
            "rules": [
                {"semantic_rule_id": "SEM_FLOW_001", "severity_override": None},
                {"semantic_rule_id": "SEM_FLOW_002", "severity_override": "error"},
                {"semantic_rule_id": "SEM_FLOW_003", "severity_override": None},
                {"semantic_rule_id": "SEM_FLOW_004", "severity_override": None},
                {"semantic_rule_id": "SEM_FLOW_005", "severity_override": None},
            ],
        },
        {
            "policy_id": "BPF_SEM_EXPR_DEFAULT",
            "title": "Default semantic expression policy",
            "description": "Enforces expression validation rules",
            "rules": [
                {"semantic_rule_id": "SEM_EXPR_001", "severity_override": "error"},
                {"semantic_rule_id": "SEM_EXPR_002", "severity_override": "error"},
                {"semantic_rule_id": "SEM_EXPR_003", "severity_override": "error"},
                {"semantic_rule_id": "SEM_EXPR_004", "severity_override": "error"},
                {"semantic_rule_id": "SEM_EXPR_005", "severity_override": "error"},
                {"semantic_rule_id": "SEM_EXPR_006", "severity_override": "warning"},
                {"semantic_rule_id": "SEM_EXPR_007", "severity_override": "warning"},
                {"semantic_rule_id": "SEM_EXPR_008", "severity_override": "warning"},
            ],
        },
    ]

    # Write output
    if args.format == "json":
        content = json.dumps(policies, indent=2)
    else:  # toml
        import yaml  # Using yaml for now, can switch to toml lib

        content = yaml.dump({"policies": policies}, default_flow_style=False)

    output_path.write_text(content)

    print(f"BQF policies exported to: {output_path}")
    print(f"Total policies: {len(policies)}")

    return 0


# ============================================================================
# Argument Parser Setup
# ============================================================================


def setup_bqf_rules_parser(subparsers) -> None:
    """
    Set up BQF rules CLI subcommands.

    Args:
        subparsers: Subparser from main CLI
    """
    # list-rules command
    list_cmd = subparsers.add_parser(
        "list-rules", help="List all registered semantic rules"
    )
    list_cmd.add_argument(
        "--format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )
    list_cmd.add_argument(
        "--category", help="Filter by category (flow, expression, etc.)"
    )
    list_cmd.add_argument(
        "--severity", help="Filter by severity (error, warning, info, etc.)"
    )
    list_cmd.set_defaults(func=cmd_list_rules)

    # show-rule command
    show_cmd = subparsers.add_parser(
        "show-rule", help="Show detailed information for a specific rule"
    )
    show_cmd.add_argument("rule_id", help="Semantic rule ID (e.g., SEM_FLOW_001)")
    show_cmd.add_argument(
        "--format",
        choices=["text", "json", "yaml"],
        default="text",
        help="Output format (default: text)",
    )
    show_cmd.set_defaults(func=cmd_show_rule)

    # export-catalog command
    export_catalog_cmd = subparsers.add_parser(
        "export-catalog", help="Export entire rule catalog to file"
    )
    export_catalog_cmd.add_argument(
        "--format",
        choices=["json", "toml"],
        default="json",
        help="Output format (default: json)",
    )
    export_catalog_cmd.add_argument(
        "--out", help="Output file path (default: rules_catalog.{format})"
    )
    export_catalog_cmd.set_defaults(func=cmd_export_catalog)

    # export-policies command
    export_policies_cmd = subparsers.add_parser(
        "export-policies", help="Export BQF policies to file"
    )
    export_policies_cmd.add_argument(
        "--format",
        choices=["json", "toml"],
        default="json",
        help="Output format (default: json)",
    )
    export_policies_cmd.add_argument(
        "--out", help="Output file path (default: policies.{format})"
    )
    export_policies_cmd.set_defaults(func=cmd_export_policies)
