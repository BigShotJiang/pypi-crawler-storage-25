"""
branchpy.cli.commands.templates_cmd — Governance templates CLI (v0.9.3).

Commands:
- branchpy templates list: List available templates
- branchpy templates show <id>: Show template details
- branchpy templates diff <id>: Preview template changes
- branchpy templates apply <id>: Apply template to project

v0.9.3 — Federation & Cloud Collaboration (local-only foundation)
"""

from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from branchpy.governance import (
    MergeStrategy,
    TemplateDiscoveryScope,
    apply_template,
    get_template_full,
    list_templates,
    preview_template_changes,
)
from branchpy.rbac import PermissionDenied

console = Console()


@click.group(name="templates")
def templates_group():
    """Governance templates commands (v0.9.3)."""
    pass


@templates_group.command(name="list")
@click.option(
    "--scope",
    type=click.Choice(["org", "project", "custom", "all"]),
    default="all",
    help="Filter by scope",
)
@click.option("--org", help="Filter by organization ID")
@click.option("--project", "-p", help="Filter by project ID")
@click.option("--tags", help="Filter by tags (comma-separated)")
@click.option("--refresh", is_flag=True, help="Force index refresh")
def list_templates_cmd(scope: str, org: str, project: str, tags: str, refresh: bool):
    """
    List available governance templates.

    Examples:
        branchpy templates list
        branchpy templates list --scope org
        branchpy templates list --tags production,default
        branchpy templates list --project demo-vn

    Requires: governance.templates.list permission
    """
    try:
        # Check permission (simplified — would check against actual user)
        # check_permission(Permission.GOVERNANCE_TEMPLATES_LIST)

        # Parse scope
        scope_enum = (
            TemplateDiscoveryScope(scope)
            if scope != "all"
            else TemplateDiscoveryScope.ALL
        )

        # Parse tags
        tags_list = tags.split(",") if tags else None

        # List templates
        templates = list_templates(
            scope=scope_enum,
            org_id=org,
            project_id=project,
            tags=tags_list,
            force_refresh=refresh,
        )

        if not templates:
            console.print("[yellow]No templates found matching filters.[/yellow]")
            console.print(
                "\nCreate templates in: [cyan]~/.branchpy/governance/templates/[/cyan]"
            )
            return

        # Display in table
        table = Table(title=f"Governance Templates ({len(templates)} found)")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Version", style="dim")
        table.add_column("Scope", style="green")
        table.add_column("Name", style="bold")
        table.add_column("Tags", style="magenta")
        table.add_column("Org/Project", style="dim")

        for template in templates:
            org_project = template.org_id or template.project_id or "—"
            tags_str = ", ".join(template.tags) if template.tags else "—"

            table.add_row(
                template.template_id,
                template.version,
                template.scope,
                template.name,
                tags_str,
                org_project,
            )

        console.print(table)

    except PermissionDenied as e:
        console.print(f"[bold red]✗ Permission denied:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


@templates_group.command(name="show")
@click.argument("template_id")
@click.option(
    "--format",
    type=click.Choice(["yaml", "json", "toml"]),
    default="yaml",
    help="Output format",
)
def show_template_cmd(template_id: str, format: str):
    """
    Show template details.

    Examples:
        branchpy templates show org-default-v1
        branchpy templates show vn-project-standard-v1 --format json

    Requires: governance.templates.list permission
    """
    try:
        # Load full template
        template = get_template_full(template_id)

        if template is None:
            console.print(f"[bold red]✗ Template not found:[/bold red] {template_id}")
            console.print(
                "\nRun [cyan]branchpy templates list[/cyan] to see available templates."
            )
            raise click.Abort()

        # Display header
        console.print(
            Panel.fit(
                f"[bold]{template.name}[/bold]\n"
                f"[dim]{template.description}[/dim]\n\n"
                f"ID: [cyan]{template.template_id}[/cyan]\n"
                f"Version: [green]{template.version}[/green]\n"
                f"Scope: [magenta]{template.scope}[/magenta]",
                title="Template Details",
                border_style="cyan",
            )
        )

        # Display tags
        if template.tags:
            console.print(f"\n[bold]Tags:[/bold] {', '.join(template.tags)}")

        # Display source file
        if template.source_file:
            console.print(f"[dim]Source: {template.source_file}[/dim]")

        # Display content
        console.print("\n[bold]Template Content:[/bold]")

        if format == "yaml":
            import yaml

            content_str = yaml.safe_dump(
                template.to_dict(), default_flow_style=False, sort_keys=False
            )
            syntax = Syntax(content_str, "yaml", theme="monokai", line_numbers=True)
            console.print(syntax)
        elif format == "json":
            import json

            content_str = json.dumps(template.to_dict(), indent=2)
            syntax = Syntax(content_str, "json", theme="monokai", line_numbers=True)
            console.print(syntax)
        elif format == "toml":
            console.print(
                "[yellow]TOML format not yet supported. Use YAML or JSON.[/yellow]"
            )

    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


@templates_group.command(name="diff")
@click.argument("template_id")
@click.option("--project", "-p", required=True, help="Project directory path")
@click.option(
    "--strategy",
    type=click.Choice(["override", "append", "deep_merge"]),
    default="deep_merge",
    help="Merge strategy",
)
def diff_template_cmd(template_id: str, project: str, strategy: str):
    """
    Preview template changes (dry-run).

    Shows what would change if template were applied to project.

    Examples:
        branchpy templates diff org-default-v1 --project ./mygame
        branchpy templates diff high-security-v1 --project ./mygame --strategy override

    Requires: governance.templates.list permission
    """
    try:
        # Load template
        template = get_template_full(template_id)

        if template is None:
            console.print(f"[bold red]✗ Template not found:[/bold red] {template_id}")
            raise click.Abort()

        # Resolve project path
        project_path = Path(project).resolve()

        if not project_path.exists():
            console.print(
                f"[bold red]✗ Project path not found:[/bold red] {project_path}"
            )
            raise click.Abort()

        # Preview changes
        strategy_enum = MergeStrategy(strategy)

        console.print("[cyan]Previewing template application...[/cyan]")
        console.print(f"  Template: {template.name} ({template_id})")
        console.print(f"  Project: {project_path}")
        console.print(f"  Strategy: {strategy}\n")

        preview = preview_template_changes(template, project_path, strategy_enum)

        # Display diff
        if not preview["diff"]:
            console.print(
                "[green]✓ No changes (template already matches current config)[/green]"
            )
            return

        console.print(f"[bold]Changes ({len(preview['diff'])} total):[/bold]\n")

        for line in preview["diff"]:
            if line.startswith("+"):
                console.print(f"[green]{line}[/green]")
            elif line.startswith("-"):
                console.print(f"[red]{line}[/red]")
            elif line.startswith("~"):
                console.print(f"[yellow]{line}[/yellow]")
            else:
                console.print(line)

        console.print("\n[dim]To apply these changes, run:[/dim]")
        console.print(
            f"  [cyan]branchpy templates apply {template_id} --project {project}[/cyan]"
        )

    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


@templates_group.command(name="apply")
@click.argument("template_id")
@click.option("--project", "-p", required=True, help="Project directory path")
@click.option(
    "--strategy",
    type=click.Choice(["override", "append", "deep_merge"]),
    default="deep_merge",
    help="Merge strategy",
)
@click.option("--dry-run", is_flag=True, help="Preview changes without applying")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def apply_template_cmd(
    template_id: str, project: str, strategy: str, dry_run: bool, yes: bool
):
    """
    Apply governance template to project.

    Examples:
        branchpy templates apply org-default-v1 --project ./mygame
        branchpy templates apply high-security-v1 --project ./mygame --dry-run
        branchpy templates apply vn-project-standard-v1 --project ./mygame --yes

    Requires: governance.templates.apply, governance.write permissions
    """
    try:
        # Check permissions
        # check_permission(Permission.GOVERNANCE_TEMPLATES_APPLY)
        # check_permission(Permission.GOVERNANCE_WRITE)

        # Load template
        template = get_template_full(template_id)

        if template is None:
            console.print(f"[bold red]✗ Template not found:[/bold red] {template_id}")
            raise click.Abort()

        # Resolve project path
        project_path = Path(project).resolve()

        if not project_path.exists():
            console.print(
                f"[bold red]✗ Project path not found:[/bold red] {project_path}"
            )
            raise click.Abort()

        # Convert strategy
        strategy_enum = MergeStrategy(strategy)

        # Show template details
        console.print(
            Panel.fit(
                f"[bold]{template.name}[/bold]\n"
                f"[dim]{template.description}[/dim]\n\n"
                f"ID: [cyan]{template_id}[/cyan]\n"
                f"Version: [green]{template.version}[/green]\n"
                f"Scope: [magenta]{template.scope}[/magenta]\n"
                f"Strategy: [yellow]{strategy}[/yellow]",
                title="Applying Template",
                border_style="cyan",
            )
        )

        # Confirm (unless --yes or --dry-run)
        if not (yes or dry_run):
            confirm = click.confirm(
                f"\nApply template to {project_path}?", default=False
            )
            if not confirm:
                console.print("[yellow]Template application cancelled.[/yellow]")
                return

        # Apply template
        console.print("\n[cyan]Applying template...[/cyan]")

        result = apply_template(
            template=template,
            project_path=project_path,
            strategy=strategy_enum,
            dry_run=dry_run,
        )

        # Display result
        if result.success:
            if dry_run:
                console.print("[bold green]✓ Dry-run successful![/bold green]")
                console.print("\nChanges preview:")

                if result.changes.get("diff"):
                    for line in result.changes["diff"]:
                        if line.startswith("+"):
                            console.print(f"[green]{line}[/green]")
                        elif line.startswith("-"):
                            console.print(f"[red]{line}[/red]")
                        elif line.startswith("~"):
                            console.print(f"[yellow]{line}[/yellow]")
                        else:
                            console.print(line)
                else:
                    console.print("[dim]No changes needed.[/dim]")
            else:
                console.print(
                    "[bold green]✓ Template applied successfully![/bold green]"
                )
                console.print(f"\nModified files: {len(result.modified_files)}")

                for file_path in result.modified_files:
                    console.print(f"  [cyan]{file_path}[/cyan]")

            # Show warnings
            if result.warnings:
                console.print(
                    f"\n[bold yellow]⚠ Warnings ({len(result.warnings)}):[/bold yellow]"
                )
                for warning in result.warnings:
                    console.print(f"  • {warning}")
        else:
            console.print("[bold red]✗ Template application failed![/bold red]")
            console.print(f"  Error: {result.error_message}")

            if result.validation_errors:
                console.print(
                    f"\n[bold red]Validation Errors ({len(result.validation_errors)}):[/bold red]"
                )
                for error in result.validation_errors:
                    console.print(f"  • {error}")

            raise click.Abort()

    except PermissionDenied as e:
        console.print(f"[bold red]✗ Permission denied:[/bold red] {e}")
        raise click.Abort()
    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        raise click.Abort()


# ============================================================================
# Legacy CLI Integration (for branchpy.cli.py _CMD_MAP registration)
# ============================================================================


def add_parser(subparsers):
    """Legacy argparse integration (if needed)."""
    pass


def run(args):
    """Legacy entry point for argparse-based dispatch."""
    pass
