"""
CLI Commands for AI Features

Provides command-line interface for BranchPy's AI-powered code analysis
and refactoring features.

Commands:
- branchpy ai explain <warning_id> <file>
- branchpy ai review <file> [--function NAME]
- branchpy ai refactor <file> [--function NAME]
- branchpy ai quick-wins <file>

Author: BranchPy Team
Date: 2025-11-26
"""

import asyncio
import json
import sys
from typing import Optional

import click

# Import AI features
try:
    from branchpy.ai.ast_integration.code_review import get_code_reviewer
    from branchpy.ai.ast_integration.explain_warning import get_warning_explainer
    from branchpy.ai.ast_integration.refactor_suggester import get_refactor_suggester
except ImportError:
    print("Error: AI modules not found. Please ensure BranchPy is properly installed.")
    sys.exit(1)


@click.group(name="ai")
def ai_group():
    """AI-powered code analysis and refactoring."""
    pass


@ai_group.command()
@click.argument("warning_id")
@click.argument("file", type=click.Path(exists=True))
@click.option("--json-output", is_flag=True, help="Output as JSON")
def explain(warning_id: str, file: str, json_output: bool):
    """
    Explain a BranchPy warning in natural language.

    Example:
        branchpy ai explain W001 game/script.rpy
    """
    try:
        result = asyncio.run(_explain_warning(warning_id, file))

        if json_output:
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"\n{click.style('Warning Explanation:', fg='cyan', bold=True)}")
            click.echo(f"ID: {click.style(result['warning_id'], fg='yellow')}")
            click.echo(f"File: {click.style(result['file'], fg='blue')}")
            click.echo(f"\n{result['explanation']}")

            if result.get("suggestions"):
                click.echo(f"\n{click.style('Suggestions:', fg='green', bold=True)}")
                for i, suggestion in enumerate(result["suggestions"], 1):
                    click.echo(f"{i}. {suggestion}")

            click.echo(
                f"\n{click.style('Confidence:', fg='magenta')} {result['confidence']:.1%}"
            )

    except Exception as e:
        click.echo(f"{click.style('Error:', fg='red', bold=True)} {str(e)}", err=True)
        sys.exit(1)


@ai_group.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--function", "-f", help="Review specific function only")
@click.option("--json-output", is_flag=True, help="Output as JSON")
@click.option(
    "--severity",
    type=click.Choice(["critical", "high", "medium", "low", "all"]),
    default="all",
)
def review(file: str, function: Optional[str], json_output: bool, severity: str):
    """
    Perform AI-powered code review.

    Example:
        branchpy ai review game/script.rpy --function calculate_score
    """
    try:
        result = asyncio.run(_review_code(file, function, severity))

        if json_output:
            click.echo(json.dumps(result, indent=2))
        else:
            _display_review_results(result)

    except Exception as e:
        click.echo(f"{click.style('Error:', fg='red', bold=True)} {str(e)}", err=True)
        sys.exit(1)


@ai_group.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--function", "-f", help="Refactor specific function only")
@click.option("--json-output", is_flag=True, help="Output as JSON")
@click.option(
    "--category",
    type=click.Choice(
        [
            "extract_method",
            "rename",
            "simplify",
            "decompose",
            "eliminate_duplication",
            "improve_names",
            "add_docs",
            "optimize",
            "all",
        ]
    ),
    default="all",
)
def refactor(file: str, function: Optional[str], json_output: bool, category: str):
    """
    Get AI-powered refactoring suggestions.

    Example:
        branchpy ai refactor game/script.rpy --function update_score
    """
    try:
        result = asyncio.run(_suggest_refactorings(file, function, category))

        if json_output:
            click.echo(json.dumps(result, indent=2))
        else:
            _display_refactoring_suggestions(result)

    except Exception as e:
        click.echo(f"{click.style('Error:', fg='red', bold=True)} {str(e)}", err=True)
        sys.exit(1)


@ai_group.command(name="quick-wins")
@click.argument("file", type=click.Path(exists=True))
@click.option("--json-output", is_flag=True, help="Output as JSON")
def quick_wins(file: str, json_output: bool):
    """
    Get easy refactoring suggestions (trivial/easy effort only).

    Example:
        branchpy ai quick-wins game/script.rpy
    """
    try:
        result = asyncio.run(_suggest_quick_wins(file))

        if json_output:
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(
                f"\n{click.style('Quick Win Refactorings:', fg='green', bold=True)}"
            )
            click.echo(f"File: {click.style(file, fg='blue')}\n")

            if not result["suggestions"]:
                click.echo("No quick wins found. Code looks good! ✓")
                return

            for i, suggestion in enumerate(result["suggestions"], 1):
                _display_suggestion(i, suggestion)

    except Exception as e:
        click.echo(f"{click.style('Error:', fg='red', bold=True)} {str(e)}", err=True)
        sys.exit(1)


# Helper functions


async def _explain_warning(warning_id: str, file: str) -> dict:
    """Explain a warning using AI."""
    explainer = get_warning_explainer()
    explanation = await explainer.explain_warning(warning_id, file)

    return {
        "warning_id": warning_id,
        "file": file,
        "explanation": explanation.explanation,
        "suggestions": explanation.suggestions,
        "confidence": explanation.confidence,
    }


async def _review_code(file: str, function: Optional[str], severity: str) -> dict:
    """Perform code review using AI."""
    reviewer = get_code_reviewer()
    review = await reviewer.review_code(file, function_name=function)

    # Filter by severity if specified
    issues = review.issues
    if severity != "all":
        issues = [issue for issue in issues if issue.severity == severity]

    return {
        "file": file,
        "function": function,
        "overall_rating": review.overall_rating,
        "issues": [
            {
                "severity": issue.severity,
                "category": issue.category,
                "message": issue.message,
                "line": issue.location.get("line_start") if issue.location else None,
                "suggestion": issue.suggestion,
            }
            for issue in issues
        ],
        "summary": review.summary,
    }


async def _suggest_refactorings(
    file: str, function: Optional[str], category: str
) -> dict:
    """Get refactoring suggestions using AI."""
    suggester = get_refactor_suggester()
    suggestions = await suggester.suggest_refactorings(file, function_name=function)

    # Filter by category if specified
    if category != "all":
        suggestions = [s for s in suggestions if s.category == category]

    return {
        "file": file,
        "function": function,
        "suggestions": [
            {
                "title": s.title,
                "priority": s.priority,
                "category": s.category,
                "description": s.description,
                "rationale": s.rationale,
                "line_start": s.location.get("line_start"),
                "line_end": s.location.get("line_end"),
                "original_code": s.original_code,
                "refactored_code": s.refactored_code,
                "confidence": s.confidence,
                "effort": s.estimated_effort,
                "benefits": s.benefits,
            }
            for s in suggestions
        ],
    }


async def _suggest_quick_wins(file: str) -> dict:
    """Get quick win refactoring suggestions."""
    suggester = get_refactor_suggester()
    suggestions = await suggester.suggest_quick_wins(file)

    return {
        "file": file,
        "suggestions": [
            {
                "title": s.title,
                "priority": s.priority,
                "category": s.category,
                "description": s.description,
                "effort": s.estimated_effort,
                "line_start": s.location.get("line_start"),
                "line_end": s.location.get("line_end"),
                "original_code": s.original_code,
                "refactored_code": s.refactored_code,
            }
            for s in suggestions
        ],
    }


def _display_review_results(result: dict):
    """Display code review results in a user-friendly format."""
    click.echo(f"\n{click.style('Code Review Results:', fg='cyan', bold=True)}")
    click.echo(f"File: {click.style(result['file'], fg='blue')}")
    if result["function"]:
        click.echo(f"Function: {click.style(result['function'], fg='blue')}")

    # Overall rating
    rating = result["overall_rating"]
    rating_color = "green" if rating >= 8 else "yellow" if rating >= 6 else "red"
    click.echo(
        f"Overall Rating: {click.style(f'{rating}/10', fg=rating_color, bold=True)}"
    )

    # Issues
    if result["issues"]:
        click.echo(f"\n{click.style('Issues Found:', fg='yellow', bold=True)}")
        for i, issue in enumerate(result["issues"], 1):
            severity_color = {
                "critical": "red",
                "high": "red",
                "medium": "yellow",
                "low": "cyan",
            }.get(issue["severity"], "white")

            click.echo(
                f"\n{i}. [{click.style(issue['severity'].upper(), fg=severity_color)}] "
                f"{click.style(issue['category'], fg='magenta')}"
            )
            if issue["line"]:
                click.echo(f"   Line: {issue['line']}")
            click.echo(f"   {issue['message']}")
            if issue["suggestion"]:
                click.echo(f"   {click.style('→', fg='green')} {issue['suggestion']}")
    else:
        click.echo(f"\n{click.style('No issues found! ✓', fg='green')}")

    # Summary
    if result["summary"]:
        click.echo(f"\n{click.style('Summary:', fg='cyan', bold=True)}")
        click.echo(result["summary"])


def _display_refactoring_suggestions(result: dict):
    """Display refactoring suggestions in a user-friendly format."""
    click.echo(f"\n{click.style('Refactoring Suggestions:', fg='cyan', bold=True)}")
    click.echo(f"File: {click.style(result['file'], fg='blue')}")
    if result["function"]:
        click.echo(f"Function: {click.style(result['function'], fg='blue')}")

    if not result["suggestions"]:
        click.echo(
            f"\n{click.style('No refactoring suggestions. Code looks good! ✓', fg='green')}"
        )
        return

    for i, suggestion in enumerate(result["suggestions"], 1):
        _display_suggestion(i, suggestion)


def _display_suggestion(index: int, suggestion: dict):
    """Display a single refactoring suggestion."""
    priority_color = {
        "critical": "red",
        "high": "red",
        "medium": "yellow",
        "low": "cyan",
    }.get(suggestion["priority"], "white")

    click.echo(f"\n{index}. {click.style(suggestion['title'], bold=True)}")
    click.echo(
        f"   Priority: [{click.style(suggestion['priority'].upper(), fg=priority_color)}] "
        f"Category: {click.style(suggestion['category'], fg='magenta')} "
        f"Effort: {click.style(suggestion['effort'], fg='cyan')}"
    )

    if suggestion.get("line_start"):
        line_range = f"Lines {suggestion['line_start']}"
        if (
            suggestion.get("line_end")
            and suggestion["line_end"] != suggestion["line_start"]
        ):
            line_range += f"-{suggestion['line_end']}"
        click.echo(f"   {line_range}")

    click.echo(f"   {suggestion['description']}")

    if suggestion.get("rationale"):
        click.echo(f"   {click.style('Why:', fg='yellow')} {suggestion['rationale']}")

    if suggestion.get("benefits"):
        click.echo(
            f"   {click.style('Benefits:', fg='green')} {', '.join(suggestion['benefits'])}"
        )

    if suggestion.get("confidence"):
        click.echo(f"   Confidence: {suggestion['confidence']:.1%}")


if __name__ == "__main__":
    ai_group()
