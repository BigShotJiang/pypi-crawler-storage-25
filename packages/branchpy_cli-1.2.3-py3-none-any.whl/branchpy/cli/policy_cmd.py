# BranchPyApp/branchpy/cli/policy_cmd.py
from __future__ import annotations

import asyncio
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import click


# Utilities
def _collect_files(root: str | Path, patterns: Iterable[str]) -> List[str]:
    root = Path(root)
    files: List[str] = []
    for pat in patterns:
        files.extend([str(p) for p in root.rglob(pat)])
    return files


def _display_human_report(report: Dict[str, Any]) -> None:
    if not report:
        click.echo("No policy report returned.", err=True)
        return
    # Accept dict-like or dataclass-ish
    if hasattr(report, "__dict__"):
        report = asdict(report)  # type: ignore
    click.echo("=== Policy Results ===")
    for key in ("pass_count", "warn_count", "fail_count", "skip_count"):
        if key in report:
            click.echo(f"{key.replace('_', ' ').title():<14}: {report[key]}")
    # Print details if present
    if "details" in report and isinstance(report["details"], list):
        click.echo("\nDetails:")
        for d in report["details"]:
            # keep concise rows
            pid = d.get("policy_id", "?")
            status = d.get("status", "?")
            msg = d.get("message", "")
            click.echo(f" - [{status}] {pid}: {msg}")


def _json(obj: Any) -> str:
    # Safe JSON dump that tolerates dataclasses and pydantic
    try:
        return json.dumps(
            obj,
            indent=2,
            default=lambda o: getattr(o, "model_dump", lambda: asdict(o))(),
        )
    except Exception:
        try:
            return json.dumps(asdict(obj), indent=2)  # dataclass fallback
        except Exception:
            return json.dumps(obj, indent=2)


def _export_json_report(events: List[Any], out: str | Path) -> None:
    Path(out).write_text(_json([getattr(e, "model_dump", lambda: e)() for e in events]))


def _export_csv_report(events: List[Any], out: str | Path) -> None:
    # Minimal CSV: governance_id, event_type, module, target_path, pass,warn,fail,skip
    import csv

    cols = [
        "timestamp",
        "governance_id",
        "event_type",
        "module",
        "target_path",
        "pass",
        "warn",
        "fail",
        "skip",
    ]
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for e in events:
            d = getattr(e, "model_dump", lambda: e)()
            pr = d.get("policy_results") or {}
            w.writerow(
                [
                    d.get("timestamp"),
                    d.get("governance_id"),
                    d.get("event_type"),
                    d.get("module"),
                    d.get("target_path"),
                    pr.get("pass", 0),
                    pr.get("warn", 0),
                    pr.get("fail", 0),
                    pr.get("skip", 0),
                ]
            )


def _export_markdown_report(events: List[Any], out: str | Path) -> None:
    lines = ["# Policy Results", ""]
    for e in events:
        d = getattr(e, "model_dump", lambda: e)()
        pr = d.get("policy_results") or {}
        lines.append(f"## {d.get('module','?')} — {d.get('event_type','validation')}")
        lines.append(f"- governance_id: `{d.get('governance_id','')}`")
        lines.append(f"- target_path: `{d.get('target_path','')}`")
        lines.append(f"- timestamp: `{d.get('timestamp','')}`")
        lines.append(
            f"- policy pass/warn/fail/skip: "
            f"{pr.get('pass',0)}/{pr.get('warn',0)}/{pr.get('fail',0)}/{pr.get('skip',0)}"
        )
        lines.append("")
    Path(out).write_text("\n".join(lines), encoding="utf-8")


@click.group(help="Run and report BQF policy checks (Compare, Media, BQF).")
def policy() -> None:
    pass


@policy.command("run")
@click.option(
    "--module",
    "-m",
    required=True,
    type=click.Choice(["compare", "media", "bqf"]),
    help="Policy module to execute",
)
@click.option(
    "--target",
    "-t",
    required=True,
    type=click.Path(exists=True),
    help="Target path (folder or file) for validation",
)
@click.option(
    "--governance-id", "-g", help="Governance ID for telemetry/governance linking"
)
@click.option(
    "--format",
    "-f",
    type=click.Choice(["human", "json"]),
    default="human",
    help="Output format",
)
@click.option(
    "--fail-on-warn", is_flag=True, help="Return non-zero if any warnings occur"
)
def run_cmd(
    module: str,
    target: str,
    governance_id: Optional[str],
    format: str,
    fail_on_warn: bool,
) -> None:
    """
    Execute policies for a module and print a summary (human/json).
    Exit code rules:
      - fail_count > 0 -> exit 1
      - --fail-on-warn & warn_count > 0 -> exit 1
      - else exit 0
    """
    try:
        policy_report: Dict[str, Any] | None = None

        if module == "compare":
            from branchpy.compare.analyzer import run_compare_analysis

            files = _collect_files(target, ["*.rpy", "*.rpyc"])
            result = asyncio.run(
                run_compare_analysis(files=files, governance_id=governance_id)
            )
            policy_report = result.get("policy")

        elif module == "media":
            try:
                from branchpy.image_validation_v3.validator import ImageValidator
            except ImportError as e:
                click.echo(
                    "[policy run] error: Media validation requires additional dependencies",
                    err=True,
                )
                click.echo("Install with: pip install branchpy[ai]", err=True)
                click.echo(f"Details: {e}", err=True)
                sys.exit(2)

            validator = ImageValidator(Path(target))
            # Assume validator returns dict with .get('policy')
            result = validator.validate(
                image_paths=_collect_files(
                    target, ["*.png", "*.jpg", "*.jpeg", "*.webp"]
                ),
                governance_id=governance_id,
            )
            policy_report = result.get("policy")

        elif module == "bqf":
            # Generic module-wide policy run (if supported by your PolicyRunner)
            from branchpy.bqf.runner import PolicyRunner

            runner = PolicyRunner()
            # Assume runner.run_module returns dict with counts & details
            policy_report = asyncio.run(
                runner.run_module(
                    target=str(target), module="bqf", governance_id=governance_id
                )
            )

        if format == "json":
            click.echo(_json(policy_report or {}))
        else:
            _display_human_report(policy_report or {})

        # Exit code logic
        fail = 0
        if policy_report:
            # accept dict-like or object w/ attributes
            get = policy_report.get if isinstance(policy_report, dict) else getattr
            fail_count = get("fail_count", 0)
            warn_count = get("warn_count", 0)
            if isinstance(fail_count, dict):  # tolerate {'fail':N}
                fail_count = fail_count.get("fail", 0)
            if isinstance(warn_count, dict):
                warn_count = warn_count.get("warn", 0)

            if fail_count and int(fail_count) > 0:
                fail = 1
            elif fail_on_warn and int(warn_count) > 0:
                fail = 1

        sys.exit(fail)
    except Exception as e:
        click.echo(f"[policy run] error: {e}", err=True)
        sys.exit(2)


@policy.command("validate")
@click.option(
    "--module",
    "-m",
    required=True,
    type=click.Choice(["compare", "media"]),
    help="Module whose policies to list/validate",
)
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    help="Optional JSON config to validate against policies",
)
def validate_cmd(module: str, config: Optional[str]) -> None:
    """
    List available policies for a module and optionally validate a JSON config
    against policy defaults.
    """
    try:
        from branchpy.bqf.registry import get_global_registry

        registry = get_global_registry()
        policies = registry.list_by_module(module)

        click.echo(f"✓ Found {len(policies)} policies for module '{module}':")
        for policy_cls in policies:
            try:
                policy = policy_cls()
                click.echo(
                    f"  • {getattr(policy, 'POLICY_ID', policy_cls.__name__)}: "
                    f"{getattr(policy, 'DESCRIPTION', '')}"
                )
            except Exception:
                click.echo(f"  • {policy_cls.__name__}")

        if config:
            with open(config, "r", encoding="utf-8") as f:
                user_conf = json.load(f)
            # very light-touch config validation: ensure keys map to known policies
            unknown = [
                k
                for k in user_conf.keys()
                if k not in [getattr(pc(), "POLICY_ID", pc.__name__) for pc in policies]
            ]
            if unknown:
                raise ValueError(f"Unknown policies in config: {unknown}")

        click.echo(f"\n✓ All policies valid for module '{module}'")
        sys.exit(0)
    except Exception as e:
        click.echo(f"[policy validate] error: {e}", err=True)
        sys.exit(2)


@policy.command("report")
@click.option("--governance-id", "-g", required=True, help="Governance ID filter")
@click.option(
    "--format",
    "-f",
    type=click.Choice(["json", "csv", "markdown"]),
    default="json",
    help="Report format",
)
@click.option("--out", "-o", type=click.Path(), required=True, help="Output file path")
def report_cmd(governance_id: str, format: str, out: str) -> None:
    """
    Export policy-aware validation events for a governance_id from telemetry.
    """
    try:
        from branchpy.telemetry.phase3_handler import Phase3TelemetryHandler

        handler = Phase3TelemetryHandler()
        # get events and filter for those carrying policy_results
        events = handler.get_events_by_governance_id(governance_id)
        policy_events = [e for e in events if getattr(e, "policy_results", None)]

        if format == "json":
            _export_json_report(policy_events, out)
        elif format == "csv":
            _export_csv_report(policy_events, out)
        else:
            _export_markdown_report(policy_events, out)

        click.echo(f"✓ Exported {len(policy_events)} policy events to {out}")
        sys.exit(0)
    except Exception as e:
        click.echo(f"[policy report] error: {e}", err=True)
        sys.exit(2)


# Legacy argparse-style compatibility functions
def add_parser(subparsers):
    """
    Register policy command with argparse (forwards to Click).

    Creates a minimal argparse subparser that captures remaining args
    and passes them to the Click application.
    """
    import argparse

    parser = subparsers.add_parser(
        "policy",
        help="Run and report BQF policy checks (Compare, Media, BQF)",
        description="BQF Policy Validation - Run, validate, and report policy checks",
    )
    parser.add_argument(
        "click_args",
        nargs=argparse.REMAINDER,
        help="Arguments to pass to Click policy command",
    )
    parser.set_defaults(handler=lambda args: run(args))


def run(args):
    """
    Execute Click policy command from argparse context.

    Takes remaining arguments from argparse and invokes the Click app.
    """
    import sys

    # Build argv for Click from captured arguments
    # Click expects: ['policy', 'run', '-m', 'compare', ...]
    click_argv = ["policy"] + getattr(args, "click_args", [])

    # Override sys.argv for Click
    old_argv = sys.argv
    try:
        sys.argv = click_argv
        policy(standalone_mode=True)
    except SystemExit:
        raise  # Let Click's exit codes propagate
    finally:
        sys.argv = old_argv


# Click app entrypoint
if __name__ == "__main__":
    policy()
