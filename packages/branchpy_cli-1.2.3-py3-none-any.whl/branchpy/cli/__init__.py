# branchpy/cli package
# Sub-commands for the CLI (serve, test, rules)
# Note: The main CLI is in branchpy/cli.py (sibling module)

# Backward compatibility: proxy all attributes from cli.py module
# This is needed because "from branchpy.cli import X" will hit this package,
# but we want it to get attributes from the cli.py MODULE instead


def __getattr__(name):
    """Lazy-load attributes from branchpy/cli.py module."""
    # Get or load the real cli.py module
    import sys

    # Check if we've already loaded it
    if "branchpy._real_cli_module" in sys.modules:
        cli_module = sys.modules["branchpy._real_cli_module"]
    else:
        # Load cli.py as a separate module
        import importlib.util
        from pathlib import Path

        cli_py = Path(__file__).parent.parent / "cli.py"
        spec = importlib.util.spec_from_file_location(
            "branchpy._real_cli_module", cli_py
        )
        if not (spec and spec.loader):
            raise ImportError(f"Could not load {cli_py}")

        cli_module = importlib.util.module_from_spec(spec)
        # Critical: set __package__ so relative imports in cli.py work correctly
        cli_module.__package__ = "branchpy"
        sys.modules["branchpy._real_cli_module"] = cli_module
        spec.loader.exec_module(cli_module)

    # Return the requested attribute from the real cli module
    if hasattr(cli_module, name):
        return getattr(cli_module, name)

    raise AttributeError(f"module 'branchpy.cli' has no attribute '{name}'")
