from __future__ import annotations

import argparse

from branchpy.server.api import start_api


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        prog="branchpy serve", description="Start local BranchPy services (API)."
    )
    p.add_argument("--port", type=int, default=8765)
    p.add_argument(
        "--no-open", action="store_true", help="(reserved) do not open browser"
    )
    p.add_argument(
        "--show-token", action="store_true", help="print API token to stdout"
    )
    args = p.parse_args(argv)

    thread, token = start_api(port=args.port)
    if args.show_token:
        print(f"BRANCHPY_API_TOKEN={token}")
    print(f"BranchPy API listening on 127.0.0.1:{args.port}")
    print("Auth: send header 'Authorization: Bearer <token>'")
    try:
        thread.join()
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
