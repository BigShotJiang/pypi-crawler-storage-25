"""
CLI commands for managing Phase 8 custom rules.

Provides easy enable/disable/severity controls from command line.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional

import click


def _find_rules_config(config_path: Optional[str] = None) -> Path:
    """Find rules.json configuration file."""
    if config_path:
        return Path(config_path)

    # Look for .branchpy/rules.json in current directory
    candidates = [
        Path(".branchpy/rules.json"),
        Path("rules.json"),
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    # Create default
    default_path = Path(".branchpy/rules.json")
    default_path.parent.mkdir(parents=True, exist_ok=True)
    return default_path


def _load_config(path: Path) -> Dict[str, Any]:
    """Load rules configuration."""
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"rules": {}}


def _save_config(path: Path, cfg: Dict[str, Any]) -> None:
    """Save rules configuration."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")


@click.group("rules")
def rules_group():
    """Manage BranchPy Phase 8 custom rules."""
    pass


@rules_group.command("list")
@click.option("--config", type=click.Path(), help="Path to rules.json")
def list_rules(config):
    """List all configured rules."""
    path = _find_rules_config(config)
    cfg = _load_config(path)

    rules = cfg.get("rules", {})
    if not rules:
        click.echo("No rules configured.")
        return

    click.echo(f"Rules in {path}:\n")
    for rule_id, rule_cfg in sorted(rules.items()):
        if rule_cfg == "OFF" or rule_cfg is False:
            status = click.style("OFF", fg="red")
        elif rule_cfg is True or (
            isinstance(rule_cfg, dict) and rule_cfg.get("enabled", True)
        ):
            status = click.style("ON", fg="green")
        else:
            status = click.style("OFF", fg="red")

        severity = ""
        if isinstance(rule_cfg, dict) and "severity" in rule_cfg:
            sev = rule_cfg["severity"]
            color = {
                "CRITICAL": "red",
                "ERROR": "red",
                "WARNING": "yellow",
                "INFO": "blue",
                "STYLE": "cyan",
                "OFF": "red",
            }.get(sev, "white")
            severity = f" [{click.style(sev, fg=color)}]"

        click.echo(f"  {rule_id}: {status}{severity}")


@rules_group.command("enable")
@click.argument("rule_id")
@click.option("--config", type=click.Path(), help="Path to rules.json")
def enable_rule(rule_id, config):
    """Enable a rule."""
    path = _find_rules_config(config)
    cfg = _load_config(path)
    cfg.setdefault("rules", {})

    cfg["rules"][rule_id] = {"enabled": True}
    _save_config(path, cfg)

    click.echo(f'✓ Enabled rule: {click.style(rule_id, fg="green")}')


@rules_group.command("disable")
@click.argument("rule_id")
@click.option("--config", type=click.Path(), help="Path to rules.json")
def disable_rule(rule_id, config):
    """Disable a rule."""
    path = _find_rules_config(config)
    cfg = _load_config(path)
    cfg.setdefault("rules", {})

    cfg["rules"][rule_id] = "OFF"
    _save_config(path, cfg)

    click.echo(f'✓ Disabled rule: {click.style(rule_id, fg="red")}')


@rules_group.command("toggle")
@click.argument("rule_id")
@click.option("--config", type=click.Path(), help="Path to rules.json")
def toggle_rule(rule_id, config):
    """Toggle a rule on/off."""
    path = _find_rules_config(config)
    cfg = _load_config(path)
    cfg.setdefault("rules", {})

    current = cfg["rules"].get(rule_id, True)

    # Determine if currently enabled
    if current is True or (isinstance(current, dict) and current.get("enabled", True)):
        # Disable
        cfg["rules"][rule_id] = "OFF"
        click.echo(f'✓ Disabled rule: {click.style(rule_id, fg="red")}')
    else:
        # Enable
        cfg["rules"][rule_id] = {"enabled": True}
        click.echo(f'✓ Enabled rule: {click.style(rule_id, fg="green")}')

    _save_config(path, cfg)


@rules_group.command("set-severity")
@click.argument("rule_id")
@click.argument(
    "severity",
    type=click.Choice(
        ["CRITICAL", "ERROR", "WARNING", "INFO", "STYLE", "OFF"], case_sensitive=False
    ),
)
@click.option("--config", type=click.Path(), help="Path to rules.json")
def set_severity(rule_id, severity, config):
    """Set rule severity level."""
    path = _find_rules_config(config)
    cfg = _load_config(path)
    cfg.setdefault("rules", {})

    severity_upper = severity.upper()

    if severity_upper == "OFF":
        cfg["rules"][rule_id] = "OFF"
    else:
        # Get existing config or create new
        existing = cfg["rules"].get(rule_id, {"enabled": True})

        if existing == "OFF":
            entry = {"enabled": True}
        elif isinstance(existing, bool):
            entry = {"enabled": existing}
        else:
            entry = dict(existing)

        entry["severity"] = severity_upper
        cfg["rules"][rule_id] = entry

    _save_config(path, cfg)

    color = {
        "CRITICAL": "red",
        "ERROR": "red",
        "WARNING": "yellow",
        "INFO": "blue",
        "STYLE": "cyan",
        "OFF": "red",
    }.get(severity_upper, "white")

    click.echo(f"✓ Set {rule_id} severity to {click.style(severity_upper, fg=color)}")


if __name__ == "__main__":
    rules_group()
