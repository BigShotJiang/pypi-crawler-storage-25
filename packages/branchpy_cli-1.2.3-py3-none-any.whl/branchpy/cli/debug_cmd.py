"""
Debug commands for testing and troubleshooting.

Includes:
- sleep: Deterministic command for testing interrupt handling
"""

import sys
import time


def add_parser(subparsers):
    """Add debug command parser."""
    parser = subparsers.add_parser(
        "debug",
        help="Debug and testing commands",
        description="Developer and testing utilities for BranchPy",
    )

    debug_subparsers = parser.add_subparsers(
        dest="debug_subcommand", help="Debug subcommands"
    )

    # Sleep command for interrupt testing
    sleep_parser = debug_subparsers.add_parser(
        "sleep",
        help="Sleep for N seconds (for testing interrupts)",
        description="Sleep for specified seconds. Useful for testing Ctrl+C handling and telemetry interrupt events.",
    )
    sleep_parser.add_argument(
        "seconds",
        type=int,
        nargs="?",
        default=10,
        help="Number of seconds to sleep (default: 10)",
    )

    parser.set_defaults(handler=run)
    return parser


def run(args) -> int:
    """Execute debug subcommand."""
    subcommand = getattr(args, "debug_subcommand", None)

    if subcommand == "sleep":
        return _debug_sleep(args)
    else:
        print(
            "Error: No debug subcommand specified. Try: branchpy debug sleep <seconds>",
            file=sys.stderr,
        )
        return 1


def _debug_sleep(args) -> int:
    """Sleep for specified seconds."""
    seconds = int(getattr(args, "seconds", 10))

    print(f"[debug] Sleeping for {seconds} seconds... (press Ctrl+C to interrupt)")

    try:
        time.sleep(seconds)
        print(f"[debug] Sleep completed successfully after {seconds} seconds")
        return 0
    except KeyboardInterrupt:
        # This won't be reached - the CLI dispatch wrapper catches KeyboardInterrupt
        # But we include it for completeness
        print("\n[debug] Sleep interrupted by user", file=sys.stderr)
        raise
