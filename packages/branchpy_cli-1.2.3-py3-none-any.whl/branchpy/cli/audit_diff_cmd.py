import json
import sys
from pathlib import Path

from branchpy.git.diff_tools import audit_changed_entries, changed_files


def register_audit_diff(sub):
    p = sub.add_parser("audit", help="Audit analysis and verification tools")
    sp = p.add_subparsers(dest="audit_cmd")

    d = sp.add_parser("diff", help="Show Git vs Audit differences")
    d.add_argument(
        "rev", nargs="?", default="HEAD", help="Git revision (default: HEAD)"
    )
    d.add_argument(
        "--report",
        default=".branchpy/reports/unified_semantics.json",
        help="Path to unified audit report",
    )
    d.add_argument(
        "--format", choices=["json", "table"], default="json", help="Output format"
    )


def main_audit_diff(args):
    if args.audit_cmd == "diff":
        # Get changed files from git
        g = set(changed_files(args.rev))

        # Get audit changes from report
        report_path = Path(args.report)
        if not report_path.exists():
            print(
                f"Warning: Audit report not found at {args.report}",
                file=sys.stderr,
            )
        a = audit_changed_entries(report_path)

        # Build comparison data
        rows = []
        for f in sorted(g):
            rows.append(
                {
                    "file": f,
                    "audit_changes": a.get(f, 0),
                    "in_git": True,
                    "in_audit": f in a,
                }
            )

        # Add files in audit but not in git diff
        for f in sorted(set(a.keys()) - g):
            rows.append(
                {"file": f, "audit_changes": a[f], "in_git": False, "in_audit": True}
            )

        # Output
        if args.format == "json":
            print(json.dumps(rows, indent=2))
        else:
            # Table format
            print(f"\n{'File':<50} {'Audit Changes':>15} {'Git':>5} {'Audit':>5}")
            print("-" * 80)
            for row in rows:
                git_mark = "✓" if row["in_git"] else "✗"
                audit_mark = "✓" if row["in_audit"] else "✗"
                print(
                    f"{row['file']:<50} {row['audit_changes']:>15} {git_mark:>5} {audit_mark:>5}"
                )

        print(
            f"\n[audit diff] Compared {len(g)} git changes with audit report",
            file=__import__("sys").stderr,
        )
