"""
Minimal CLI Coverage Command for Phase E

Ready-to-drop function for `branchpy telemetry coverage`.
This is the lean v1 - just shows last N analyses with basic metrics.

Add this to branchpy/cli/telemetry_cmd.py after the existing commands.

Governance: v0.9.8 Phase E — Scene Coverage Integration
"""

import json
import sys
from datetime import datetime, timedelta
from typing import Optional

import click


# Placeholder - this should be imported from telemetry_cmd when integrated
class TelemetryGroup:
    @staticmethod
    def command(name):
        return click.command(name)


telemetry_group = TelemetryGroup()


@telemetry_group.command("coverage")
@click.option("--project", help="Filter by project hash (e.g., abc123...)")
@click.option(
    "--days", type=int, default=30, help="Show analyses from last N days (default: 30)"
)
@click.option(
    "--limit", type=int, default=20, help="Maximum analyses to show (default: 20)"
)
@click.option(
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
def coverage_cmd(project: Optional[str], days: int, limit: int, format: str):
    """
    Display scene coverage metrics from recent analyses.

    Shows total scenes, reachable scenes, unreachable scenes, and coverage
    percentage for each analysis run.

    Examples:

        # Show all coverage analyses from last 30 days
        branchpy telemetry coverage

        # Show analyses for specific project
        branchpy telemetry coverage --project abc123

        # Show last 7 days, JSON format
        branchpy telemetry coverage --days 7 --format json

        # Show last 10 analyses
        branchpy telemetry coverage --limit 10
    """
    try:
        # Import storage (lazy to avoid startup penalty)
        from branchpy.telemetry.storage import EventFilter
        from branchpy.telemetry.storage_sqlite import LocalSQLiteSink

        # Initialize storage
        storage = LocalSQLiteSink(db_path=".branchpy/telemetry/events.db")

        # Build filter
        end = datetime.utcnow()
        start = end - timedelta(days=days)

        event_filter = EventFilter(
            category="scene_coverage",
            event_type="scene_coverage.analysis.completed",
            project_hash=project if project else None,
            start=start,
            end=end,
            limit=limit,
        )

        # Query events
        events = storage.read_events(event_filter)

        if not events:
            if project:
                click.echo(
                    f"No coverage data found for project {project} in last {days} days."
                )
            else:
                click.echo(f"No coverage data found in last {days} days.")
            click.echo("\nRun scene coverage analysis to generate data:")
            click.echo("  branchpy analyze --coverage <project_path>")
            return

        # JSON output
        if format == "json":
            output = []
            for event in events:
                output.append(
                    {
                        "timestamp": event.get("occurred_at"),
                        "project_hash": event.get("project_hash"),
                        "total_scenes": event.get("total_scenes"),
                        "reachable_scenes": event.get("reachable_scenes"),
                        "unreachable_scenes": event.get("unreachable_scenes"),
                        "coverage_percentage": event.get("coverage_percentage"),
                        "duration_ms": event.get("duration_ms"),
                    }
                )
            click.echo(json.dumps(output, indent=2))
            return

        # Table output
        from tabulate import tabulate

        # Calculate summary stats
        total_analyses = len(events)
        avg_coverage = (
            sum(e.get("coverage_percentage", 0) for e in events) / total_analyses
            if total_analyses > 0
            else 0
        )
        avg_total_scenes = (
            sum(e.get("total_scenes", 0) for e in events) / total_analyses
            if total_analyses > 0
            else 0
        )
        avg_reachable = (
            sum(e.get("reachable_scenes", 0) for e in events) / total_analyses
            if total_analyses > 0
            else 0
        )

        # Display summary header
        click.echo("\n" + "=" * 70)
        click.echo("  SCENE COVERAGE SUMMARY")
        click.echo("=" * 70)
        click.echo(f"  Period:             Last {days} days")
        click.echo(f"  Total Analyses:     {total_analyses}")
        click.echo(f"  Avg Coverage:       {avg_coverage:.1f}%")
        click.echo(f"  Avg Total Scenes:   {int(avg_total_scenes)}")
        click.echo(f"  Avg Reachable:      {int(avg_reachable)}")
        if project:
            click.echo(f"  Project Filter:     {project}")
        click.echo("=" * 70 + "\n")

        # Build table rows
        table = []
        for event in events:
            # Format timestamp
            timestamp = event.get("occurred_at", "")
            if isinstance(timestamp, str):
                timestamp = timestamp[:19]  # Trim to YYYY-MM-DD HH:MM:SS

            # Format project hash (first 8 chars)
            proj_hash = event.get("project_hash", "unknown")
            if len(proj_hash) > 8:
                proj_hash = proj_hash[:8]

            # Get metrics
            total = event.get("total_scenes", 0)
            reachable = event.get("reachable_scenes", 0)
            unreachable = event.get("unreachable_scenes", 0)
            coverage = event.get("coverage_percentage", 0)
            duration = event.get("duration_ms", 0)

            # Color-code coverage (ANSI colors)
            if coverage >= 90:
                coverage_str = click.style(f"{coverage:.1f}%", fg="green")
            elif coverage >= 70:
                coverage_str = click.style(f"{coverage:.1f}%", fg="yellow")
            else:
                coverage_str = click.style(f"{coverage:.1f}%", fg="red")

            table.append(
                [
                    timestamp,
                    proj_hash,
                    total,
                    reachable,
                    unreachable,
                    coverage_str,
                    f"{duration:,}ms" if duration else "-",
                ]
            )

        # Display table
        headers = [
            "Timestamp",
            "Project",
            "Total",
            "Reachable",
            "Unreach.",
            "Coverage",
            "Duration",
        ]
        click.echo(tabulate(table, headers=headers, tablefmt="simple"))

        click.echo(f"\nShowing {len(events)} of {total_analyses} analyses")

        if len(events) < total_analyses:
            click.echo(f"Use --limit {total_analyses} to see all analyses")

    except ImportError as e:
        click.echo(f"Error: Missing dependency - {e}", err=True)
        click.echo("Install required packages: pip install tabulate", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        import traceback

        traceback.print_exc()
        sys.exit(1)


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================

"""
To add this command to telemetry_cmd.py:

1. Copy the entire `coverage_cmd` function
2. Paste it at the end of telemetry_cmd.py (before any test code)
3. Ensure `telemetry_group` is defined in the file (it should be)
4. Add import for tabulate if not present:
   from tabulate import tabulate

That's it! The command will automatically register under `branchpy telemetry coverage`.

Test:
  branchpy telemetry coverage --help
  branchpy telemetry coverage --days 7
  branchpy telemetry coverage --format json
"""


# ============================================================================
# MINIMAL TEST (OPTIONAL)
# ============================================================================


def test_coverage_command():
    """
    Minimal test to verify command works.

    Run this in a project with coverage data:
        python -c "from branchpy.cli.telemetry_cmd import test_coverage_command; test_coverage_command()"
    """
    from datetime import datetime, timedelta

    from branchpy.telemetry.storage import EventFilter
    from branchpy.telemetry.storage_sqlite import LocalSQLiteSink

    storage = LocalSQLiteSink(db_path=".branchpy/telemetry/events.db")

    event_filter = EventFilter(
        category="scene_coverage",
        event_type="scene_coverage.analysis.completed",
        start=datetime.utcnow() - timedelta(days=30),
        end=datetime.utcnow(),
        limit=10,
    )

    events = storage.read_events(event_filter)

    print(f"Found {len(events)} coverage events")

    if events:
        print("Sample event:")
        print(json.dumps(events[0], indent=2, default=str))
    else:
        print("No coverage data yet - run analyzer first")


if __name__ == "__main__":
    test_coverage_command()
