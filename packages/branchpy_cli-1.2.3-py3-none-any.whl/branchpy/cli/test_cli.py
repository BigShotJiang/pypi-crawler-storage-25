# branchpy/cli/test_cli.py
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Tuple


# Import your real modules
# (These exist based on WS-C1/C2; keep imports local so tests can monkeypatch.)
def _generate_plan(project_root: str) -> Dict[str, Any]:
    """Generate test plan from project CFG."""
    from branchpy.parser import scan_project
    from branchpy.testing.planner import TestPlanner

    # Scan project to get CFG nodes
    project = scan_project(project_root)
    cfg_nodes = getattr(project, "cfg_nodes", [])

    # Generate plan
    planner = TestPlanner(cfg_nodes)
    return planner.generate_plan()


def _compute_gaps_and_summary(
    plan: Dict[str, Any], project_root: str
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    from branchpy.testing.coverage_finder import compute_gaps_and_summary

    return compute_gaps_and_summary(plan, project_root)


EXIT_OK = 0
EXIT_BAD_COVERAGE = 2
EXIT_ERROR = 3


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bpy test", description="BranchPy test planning & coverage tools"
    )
    p.add_argument(
        "--project", default=os.getcwd(), help="Project root (defaults to CWD)"
    )
    # mode flags (mutually exclusive)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--plan", action="store_true", help="Generate deterministic test plan JSON"
    )
    mode.add_argument(
        "--coverage", action="store_true", help="Compute coverage and show gaps"
    )
    # common output opts
    p.add_argument("--output", "-o", help="Write output to file instead of stdout")
    p.add_argument(
        "--format",
        "-f",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    # coverage-only
    p.add_argument(
        "--threshold", type=float, help="Minimum coverage %% (exit 2 if below)"
    )
    return p


def _write(path: str | None, data: str) -> None:
    if path:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fp:
            fp.write(data)
    else:
        sys.stdout.write(data)


def _as_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2) + "\n"


def _fmt_text_coverage(summary: Dict[str, Any], gaps: List[Dict[str, Any]]) -> str:
    pct = summary.get("coveragePct", 0.0)
    covered = summary.get("coveredLabels", 0)
    total = summary.get("totalLabels", 0)
    by_reason = summary.get("byReason", {})
    line1 = f"Coverage: {pct:.1f}% ({covered} / {total})\n"
    parts = []
    if by_reason:
        for r in ["unreachable", "dead_code", "uncovered"]:
            if r in by_reason:
                icon = "⚠" if r == "unreachable" else "ℹ"
                parts.append(f"{icon} {r} ({by_reason[r]})")
    line2 = (("   ".join(parts)) + "\n") if parts else ""
    # optional tail with first few gaps
    tail = ""
    preview = gaps[:10]
    if preview:
        tail = (
            "Gaps:\n"
            + "\n".join(
                f"  - {g.get('label')} [{g.get('reason')}]: {g.get('file')}:{g.get('line')}"
                for g in preview
            )
            + "\n"
        )
    return line1 + line2 + tail


def main(argv: List[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        if args.plan:
            plan = _generate_plan(args.project)
            payload = {
                "paths": plan.get("paths", []),
                "coveredLabels": plan.get("covered_labels", []),
                "unreachableLabels": plan.get("unreachable_labels", []),
                "totalLabels": plan.get("total_labels", 0),
                "coveredCount": plan.get("covered_count", 0),
                "coveragePct": plan.get("coverage_pct", 0.0),
            }
            out = (
                _as_json(payload)
                if args.format == "json"
                else (
                    f"Plan with {len(payload['paths'])} paths; coverage {payload['coveragePct']:.1f}%\n"
                )
            )
            _write(args.output, out)
            return EXIT_OK

        # coverage mode
        plan = _generate_plan(args.project)
        gaps, summary = _compute_gaps_and_summary(plan, args.project)
        # Ensure minimal summary keys exist
        summary.setdefault("coveragePct", plan.get("coverage_pct", 0.0))
        summary.setdefault("totalLabels", plan.get("total_labels", 0))
        summary.setdefault("coveredLabels", plan.get("covered_count", 0))
        summary.setdefault(
            "byReason",
            {
                "unreachable": sum(1 for g in gaps if g.get("reason") == "unreachable"),
                "dead_code": sum(1 for g in gaps if g.get("reason") == "dead_code"),
                "uncovered": sum(1 for g in gaps if g.get("reason") == "uncovered"),
            },
        )

        if args.format == "json":
            _write(args.output, _as_json({"summary": summary, "gaps": gaps}))
        else:
            _write(args.output, _fmt_text_coverage(summary, gaps))

        if args.threshold is not None and summary["coveragePct"] < float(
            args.threshold
        ):
            return EXIT_BAD_COVERAGE
        return EXIT_OK
    except SystemExit:
        raise
    except Exception:
        # Keep it simple: never crash CI without a clear nonzero code
        return EXIT_ERROR


if __name__ == "__main__":
    raise SystemExit(main())
