# branchpy/cli/ai_cli.py
from __future__ import annotations

import argparse
import json  # Added import
import pathlib
import sys
import uuid
from typing import Optional

# You likely already have a TOML loader helper; using a simple sketch here:
# from branchpy.config import load_ai_providers_config  # hypothetical helper
try:
    import tomllib  # Python 3.11+ stdlib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]

from branchpy.ai.data_guard import DataGuard
from branchpy.ai.models import (
    CodeReviewRequest,
    DataClassification,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderCapability,
)
from branchpy.ai.provider_registry import ProviderRegistry
from branchpy.ai.service import AIService

# License gating (LIC-CLI-4: AI commands require Pro+ tier)
from branchpy.license.gating import require_feature_cli


def load_ai_providers_config():
    # A simple placeholder config loader.
    # In a real app, this would search in standard locations.
    config_path = pathlib.Path("ai_providers.toml")
    if not config_path.exists():
        return {}
    return tomllib.loads(config_path.read_text(encoding="utf-8"))


def add_ai_subparser(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    ai_parser = subparsers.add_parser(
        "ai",
        help="AI-powered helpers: review code, generate docs, explain warnings.",
    )
    ai_sub = ai_parser.add_subparsers(dest="ai_command", required=True)

    # branchpy ai review
    review = ai_sub.add_parser("review", help="Review code in a file.")
    review.add_argument("path", help="Path to the source file.")
    review.add_argument(
        "--line",
        type=int,
        default=None,
        help="Cursor line (for context).",
    )
    review.add_argument(
        "--provider",
        default=None,
        help="Provider ID (as defined in ai_providers.toml).",
    )

    # branchpy ai docgen
    docgen = ai_sub.add_parser("docgen", help="Generate or improve documentation.")
    docgen.add_argument("path", help="Path to the source file.")
    docgen.add_argument(
        "--symbol",
        required=False,
        help="Symbol name (function/class/etc.) to document.",
    )
    docgen.add_argument(
        "--provider",
        default=None,
        help="Provider ID (as defined in ai_providers.toml).",
    )

    # branchpy ai explain-warning
    explain = ai_sub.add_parser("explain-warning", help="Explain an analyzer warning.")
    explain.add_argument(
        "warning_id",
        help="BranchPy warning ID (e.g., W001).",
    )
    explain.add_argument(
        "--message",
        required=False,
        help="Optional warning message override.",
    )
    explain.add_argument(
        "--code-path",
        required=False,
        help="Optional path to the affected file for context.",
    )
    explain.add_argument(
        "--provider",
        default=None,
        help="Provider ID (as defined in ai_providers.toml).",
    )

    # branchpy ai autofix (Day 2 - Patch Engine Integration)
    autofix = ai_sub.add_parser(
        "autofix", help="Generate autofix suggestions for warnings."
    )
    autofix.add_argument(
        "warning_file",
        help="Path to warnings JSON file from semantic analysis.",
    )
    autofix.add_argument(
        "--project",
        required=False,
        help="Project root path (defaults to current directory).",
    )
    autofix.add_argument(
        "--engine",
        default="renpy",
        help="Target engine (renpy, godot, unity, unreal).",
    )
    autofix.add_argument(
        "--json",
        action="store_true",
        help="Output suggestions in JSON format.",
    )
    autofix.add_argument(
        "--apply-best",
        action="store_true",
        help="Automatically apply best suggestion (use with caution!).",
    )
    autofix.add_argument(
        "--preview",
        action="store_true",
        help="Show patch preview without applying.",
    )

    # branchpy ai providers
    providers_parser = ai_sub.add_parser(
        "providers", help="List available AI providers."
    )
    providers_parser.add_argument(
        "--json",
        action="store_true",
        help="Output the provider list in JSON format.",
    )

    ai_parser.set_defaults(func=handle_ai_command)


def _generate_request_id() -> str:
    return f"ai-{uuid.uuid4()}"


def _read_file_text(path_str: str) -> str:
    path = pathlib.Path(path_str)
    return path.read_text(encoding="utf-8")


def _handle_review(args: argparse.Namespace, service: AIService) -> int:
    # LIC-CLI-4: AI review requires Pro+ tier
    file_path = pathlib.Path(args.path)
    project_path = file_path.parent if file_path.exists() else None
    require_feature_cli("ai_review", "AI Code Review", project_path)

    code = _read_file_text(args.path)

    request = CodeReviewRequest(
        id=_generate_request_id(),
        capability=ProviderCapability.CODE_REVIEW,
        project=None,  # TODO: derive from .branchpy.toml or workspace
        file_path=args.path,
        data_class=DataClassification.INTERNAL,
        code=code,
        language=None,  # TODO: derive from file extension
        cursor_line=args.line,
    )

    response = service._execute(request, provider_id=args.provider)

    # For now, simple stdout; later, we can add JSON mode / rich formatting
    print(response.content)
    return 0


def _handle_docgen(args: argparse.Namespace, service: AIService) -> int:
    # LIC-CLI-4: AI docgen requires Pro+ tier
    file_path = pathlib.Path(args.path)
    project_path = file_path.parent if file_path.exists() else None
    require_feature_cli("ai_docgen", "AI Documentation Generator", project_path)

    code = _read_file_text(args.path)

    request = DocGenRequest(
        id=_generate_request_id(),
        capability=ProviderCapability.DOC_GEN,
        project=None,
        file_path=args.path,
        data_class=DataClassification.INTERNAL,
        code=code,
        symbol_name=args.symbol,
    )

    response = service._execute(request, provider_id=args.provider)
    print(response.content)
    return 0


def _handle_explain_warning(args: argparse.Namespace, service: AIService) -> int:
    # LIC-CLI-4: AI explain requires Pro+ tier
    code_path_obj = pathlib.Path(args.code_path) if args.code_path else None
    project_path = (
        code_path_obj.parent if code_path_obj and code_path_obj.exists() else None
    )
    require_feature_cli("ai_explain", "AI Warning Explanation", project_path)

    code: Optional[str] = None
    if args.code_path:
        code = _read_file_text(args.code_path)

    request = ExplainWarningRequest(
        id=_generate_request_id(),
        capability=ProviderCapability.EXPLAIN_WARNING,
        project=None,
        file_path=args.code_path,
        data_class=DataClassification.INTERNAL,
        warning_id=args.warning_id,
        warning_message=args.message or "",
        code=code or "",
    )

    response = service._execute(request, provider_id=args.provider)
    print(response.content)
    return 0


def _handle_providers(args: argparse.Namespace, registry: ProviderRegistry) -> int:
    if not args.json:
        print("Provider ID          | Name                     | Capabilities")
        print(
            "--------------------|--------------------------|----------------------------------"
        )
        for provider_id, provider in registry.providers.items():
            caps = ", ".join(c.value for c in provider.capabilities)
            print(f"{provider_id:<20} | {provider.name:<24} | {caps}")
        return 0

    providers_list = []
    for provider_id, provider in registry.providers.items():
        providers_list.append(
            {
                "id": provider_id,
                "name": provider.name,
                "type": provider.type,
                "capabilities": [c.value for c in provider.capabilities],
                "experimental": getattr(provider, "experimental", False),
            }
        )

    print(json.dumps({"providers": providers_list}, indent=2))
    return 0


def _handle_autofix(args: argparse.Namespace) -> int:
    """Handle branchpy ai autofix command."""
    from branchpy.patches import (
        AutofixGenerator,
        PatchContext,
        PatchEngine,
        PropagationWarning,
    )

    # Load warnings from JSON file
    warnings_path = pathlib.Path(args.warning_file)
    if not warnings_path.exists():
        print(f"Error: Warnings file not found: {warnings_path}", file=sys.stderr)
        return 1

    warnings_data = json.loads(warnings_path.read_text(encoding="utf-8"))

    # Parse warnings into PropagationWarning objects
    warnings = []
    for w in warnings_data.get("warnings", []):
        warning = PropagationWarning(
            code=w.get("code", "UNKNOWN"),
            message=w.get("message", ""),
            severity=w.get("severity", "MEDIUM"),
            line=w.get("line"),
            category=w.get("category"),
            context=w.get("context", {}),
            file_path=pathlib.Path(w["file_path"]) if "file_path" in w else None,
        )
        warnings.append(warning)

    if not warnings:
        print("No warnings found in file.", file=sys.stderr)
        return 1

    # Setup autofix generator
    project_root = pathlib.Path(args.project) if args.project else pathlib.Path.cwd()
    generator = AutofixGenerator(
        engine=args.engine,
        project_root=project_root,
        ai_enabled=True,
    )

    # Generate suggestions for all warnings
    all_suggestions = []
    for warning in warnings:
        try:
            ranked = generator.generate_suggestions(warning)
            all_suggestions.append(ranked)
        except ValueError as e:
            print(
                f"Warning: Could not generate fix for {warning.code}: {e}",
                file=sys.stderr,
            )

    if not all_suggestions:
        print("No autofix suggestions generated.", file=sys.stderr)
        return 1

    # Output as JSON
    if args.json:
        output = {
            "suggestions": [s.to_dict() for s in all_suggestions],
            "total_warnings": len(warnings),
            "total_suggestions": sum(len(s.suggestions) for s in all_suggestions),
        }
        print(json.dumps(output, indent=2))
        return 0

    # Human-readable output
    print(f"\n🔧 Autofix Suggestions for {len(warnings)} warnings:\n")
    for idx, ranked in enumerate(all_suggestions, 1):
        warning = ranked.warning
        print(f"{idx}. {warning.category} at line {warning.line}")
        print(f"   {warning.message}")
        print(f"   File: {warning.file_path}")
        print("\n   Suggestions:")
        for s_idx, suggestion in enumerate(ranked.suggestions, 1):
            confidence_emoji = {"high": "✅", "medium": "⚠️", "low": "❌"}
            emoji = confidence_emoji.get(suggestion.confidence.value, "❓")
            print(
                f"   {s_idx}. {emoji} {suggestion.title} ({suggestion.confidence.value} confidence)"
            )
            print(f"      {suggestion.description}")
            if suggestion.ai_explanation:
                print(f"      💡 {suggestion.ai_explanation}")
        print()

    # Auto-apply best suggestion if requested
    if args.apply_best:
        print("\n⚙️  Applying best suggestions...\n")
        context = PatchContext(
            project_root=project_root,
            backup_root=project_root / ".branchpy" / "patch-backups",
        )
        engine = PatchEngine(context)

        for ranked in all_suggestions:
            best = ranked.best_suggestion()
            if not best:
                continue

            print(f"Applying: {best.title}...")
            try:
                log_entry = engine.apply_transaction(best.transaction)
                print(f"  ✅ Success! Backup: {log_entry.backup_root}")
            except Exception as e:
                print(f"  ❌ Failed: {e}", file=sys.stderr)

        print("\n✅ Autofix complete!")
        return 0

    # Show preview if requested
    if args.preview:
        print("\n📄 Preview of changes:\n")
        context = PatchContext(
            project_root=project_root,
            backup_root=project_root / ".branchpy" / "patch-backups",
        )
        engine = PatchEngine(context)

        for ranked in all_suggestions:
            best = ranked.best_suggestion()
            if not best:
                continue

            print(f"Preview: {best.title}")
            try:
                preview = engine.preview_transaction(best.transaction)
                for file_path, new_content in preview.items():
                    print(f"  File: {file_path}")
                    print(f"  New content ({len(new_content)} bytes)")
                    print(f"  {'-' * 60}")
                    print(new_content[:500])  # Show first 500 chars
                    if len(new_content) > 500:
                        print("  ... (truncated)")
                    print()
            except Exception as e:
                print(f"  ❌ Preview failed: {e}", file=sys.stderr)

    return 0


def handle_ai_command(args: argparse.Namespace) -> int:
    # 1) Load provider config and registry
    config = load_ai_providers_config()  # e.g., reads ai_providers.toml into a dict
    registry = ProviderRegistry()
    registry.load_from_dict(config)

    service = AIService(registry=registry, data_guard=DataGuard())

    if args.ai_command == "review":
        return _handle_review(args, service)
    if args.ai_command == "docgen":
        return _handle_docgen(args, service)
    if args.ai_command == "explain-warning":
        return _handle_explain_warning(args, service)
    if args.ai_command == "autofix":
        return _handle_autofix(args)  # No service needed, uses PatchEngine
    if args.ai_command == "providers":
        return _handle_providers(args, registry)

    # Should be unreachable with required=True
    print("Unknown ai command", file=sys.stderr)
    return 1
