# branchpy/cli/l10n_cmd.py
"""
L10n Audit CLI Command — Phase 7 (v0.7.10)

Validates localization coverage across multiple language files.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from branchpy.contract import VERSION, Exit
from branchpy.l10n import CoverageSummary, compute_coverage, extract_strings

# Exit codes for L10n audit
EXIT_OK = Exit.OK  # 0: All locales meet threshold
EXIT_THRESHOLD_BREACH = Exit.ISSUES_FOUND  # 1: Coverage below threshold
EXIT_ERROR = Exit.INTERNAL  # 10: Command error


def build_parser() -> argparse.ArgumentParser:
    """Build argument parser for `bpy l10n audit` command."""
    parser = argparse.ArgumentParser(
        prog="bpy l10n audit",
        description="Validate localization coverage across language files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Audit all locales against default base
  bpy l10n audit

  # Specify custom base locale
  bpy l10n audit --base game/tl/english

  # Check specific locales only
  bpy l10n audit --locales spanish,french

  # Fail CI if coverage below 90%
  bpy l10n audit --strict --min-coverage 90

  # Save report to custom file
  bpy l10n audit --output reports/l10n-audit.json
        """,
    )

    parser.add_argument(
        "--project",
        default=".",
        help="Project root directory (default: current directory)",
    )

    parser.add_argument(
        "--base", default="english", help="Base locale name (default: 'english')"
    )

    parser.add_argument(
        "--locales",
        help="Comma-separated list of target locales (default: auto-detect from tl/)",
    )

    parser.add_argument(
        "--min-coverage",
        type=float,
        default=80.0,
        help="Minimum coverage percentage threshold (default: 80.0)",
    )

    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit with code 1 if any locale below min-coverage",
    )

    parser.add_argument(
        "--output",
        "-o",
        default="l10n-report.json",
        help="Output JSON file path (default: l10n-report.json)",
    )

    parser.add_argument(
        "--format",
        "-f",
        choices=["json", "text"],
        default="text",
        help="Output format for console (default: text)",
    )

    parser.add_argument(
        "--show-missing",
        action="store_true",
        help="Show detailed list of missing translation keys",
    )

    parser.add_argument(
        "--show-orphaned",
        action="store_true",
        help="Show detailed list of orphaned translation keys",
    )

    return parser


def run(args: argparse.Namespace) -> int:
    """
    Execute the l10n audit command.

    Args:
        args: Parsed command-line arguments

    Returns:
        Exit code (0=success, 1=threshold breach, 3=error)
    """
    try:
        project_root = Path(args.project).resolve()
        if not project_root.exists():
            print(
                f"❌ Error: Project directory not found: {project_root}",
                file=sys.stderr,
            )
            return EXIT_ERROR

        # Extract strings from project
        print(f"🔍 Scanning project: {project_root}", file=sys.stderr)
        index = extract_strings(project_root)

        if not index.source:
            print("⚠️  Warning: No source strings found in project", file=sys.stderr)
            return EXIT_ERROR

        # Determine target locales
        if args.locales:
            target_locales = [loc.strip() for loc in args.locales.split(",")]
        else:
            # Auto-detect from index (excludes base locale)
            target_locales = sorted(
                [lang for lang in index.languages if lang != args.base]
            )

        if not target_locales:
            print(
                f"⚠️  Warning: No target locales found (base: {args.base})",
                file=sys.stderr,
            )
            return EXIT_ERROR

        # Compute coverage for each locale
        coverage_results: Dict[str, CoverageSummary] = {}
        for locale in target_locales:
            coverage_results[locale] = compute_coverage(index, locale)

        # Generate unified report
        report = generate_unified_report(
            base_locale=args.base,
            coverage_results=coverage_results,
            project_root=str(project_root),
            total_source_strings=len(index.source),
        )

        # Save JSON report
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        print(f"✅ Report saved: {output_path}", file=sys.stderr)

        # Console output
        if args.format == "json":
            print(json.dumps(report, indent=2, ensure_ascii=False))
        else:
            print_text_summary(
                coverage_results=coverage_results,
                min_coverage=args.min_coverage,
                show_missing=args.show_missing,
                show_orphaned=args.show_orphaned,
            )

        # Check threshold
        failures = [
            locale
            for locale, summary in coverage_results.items()
            if summary.coverage_pct < args.min_coverage
        ]

        if failures and args.strict:
            print(
                f"\n❌ Coverage check failed: {len(failures)} locale(s) below {args.min_coverage}% threshold",
                file=sys.stderr,
            )
            return EXIT_THRESHOLD_BREACH

        return EXIT_OK

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return EXIT_ERROR


def generate_unified_report(
    base_locale: str,
    coverage_results: Dict[str, CoverageSummary],
    project_root: str,
    total_source_strings: int,
) -> Dict[str, Any]:
    """
    Generate unified report conforming to BranchPy report schema.

    Args:
        base_locale: Base locale name
        coverage_results: Coverage summaries by locale
        project_root: Project root path
        total_source_strings: Total count of source strings

    Returns:
        Unified report dictionary
    """
    coverage_data = {}
    for locale, summary in coverage_results.items():
        coverage_data[locale] = {
            "total_keys": summary.total_strings,
            "translated_keys": summary.translated,
            "missing_keys": len(summary.missing),
            "orphan_keys": len(summary.orphaned),
            "coverage_pct": round(summary.coverage_pct, 2),
            "missing_key_ids": (
                sorted(list(summary.missing)) if len(summary.missing) < 100 else []
            ),
            "orphan_key_ids": (
                sorted(list(summary.orphaned)) if len(summary.orphaned) < 100 else []
            ),
            "length_mismatches": len(summary.length_mismatches),
        }

    return {
        "version": VERSION,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "command": "l10n_audit",
        "project_root": str(project_root),
        "localization": {
            "base_locale": base_locale,
            "target_locales": sorted(list(coverage_results.keys())),
            "total_source_strings": total_source_strings,
            "coverage": coverage_data,
        },
    }


def print_text_summary(
    coverage_results: Dict[str, CoverageSummary],
    min_coverage: float,
    show_missing: bool = False,
    show_orphaned: bool = False,
) -> None:
    """
    Print human-readable coverage summary to stdout.

    Args:
        coverage_results: Coverage summaries by locale
        min_coverage: Minimum coverage threshold
        show_missing: Whether to show missing key details
        show_orphaned: Whether to show orphaned key details
    """
    print("\n📊 Localization Coverage Summary")
    print("=" * 70)

    for locale, summary in sorted(coverage_results.items()):
        # Status indicator
        if summary.coverage_pct >= 90:
            status = "✅"
        elif summary.coverage_pct >= min_coverage:
            status = "⚠️ "
        else:
            status = "❌"

        print(f"\n{status} {locale}: {summary.coverage_pct:.1f}% coverage")
        print(f"   Total: {summary.total_strings} | Translated: {summary.translated}")
        print(f"   Missing: {len(summary.missing)} | Orphaned: {len(summary.orphaned)}")

        if summary.length_mismatches:
            print(
                f"   Length mismatches: {len(summary.length_mismatches)} (>50% difference)"
            )

        # Show detailed missing keys
        if show_missing and summary.missing:
            print(f"\n   Missing keys ({len(summary.missing)}):")
            for key_id in sorted(list(summary.missing))[:20]:  # Limit to 20
                print(f"     - {key_id}")
            if len(summary.missing) > 20:
                print(f"     ... and {len(summary.missing) - 20} more")

        # Show detailed orphaned keys
        if show_orphaned and summary.orphaned:
            print(f"\n   Orphaned keys ({len(summary.orphaned)}):")
            for key_id in sorted(list(summary.orphaned))[:20]:  # Limit to 20
                print(f"     - {key_id}")
            if len(summary.orphaned) > 20:
                print(f"     ... and {len(summary.orphaned) - 20} more")

    print("\n" + "=" * 70)

    # Summary statistics
    total_locales = len(coverage_results)
    avg_coverage = (
        sum(s.coverage_pct for s in coverage_results.values()) / total_locales
        if total_locales > 0
        else 0
    )

    passing = sum(
        1 for s in coverage_results.values() if s.coverage_pct >= min_coverage
    )

    print(
        f"\n📈 Overall: {passing}/{total_locales} locales above {min_coverage}% threshold"
    )
    print(f"   Average coverage: {avg_coverage:.1f}%")


def main(argv: List[str] | None = None) -> int:
    """Main entry point for standalone testing."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
