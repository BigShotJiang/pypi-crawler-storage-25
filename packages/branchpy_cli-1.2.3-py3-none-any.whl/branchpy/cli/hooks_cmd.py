from pathlib import Path

from branchpy.git.hooks import install_hooks, status, uninstall_hooks


def register_hooks(sub):
    p = sub.add_parser("hooks", help="Manage Git hooks for policy enforcement")
    sp = p.add_subparsers(dest="hooks_cmd")
    sp.add_parser("install", help="Install pre-commit and pre-push hooks")
    sp.add_parser("uninstall", help="Remove BranchPy hooks")
    sp.add_parser("status", help="Show which hooks are installed")


def main_hooks(args):
    root = Path(".").resolve()

    if args.hooks_cmd == "install":
        install_hooks(root)
        print("[hooks] Hooks installed successfully")
    elif args.hooks_cmd == "uninstall":
        uninstall_hooks(root)
        print("[hooks] Hooks uninstalled successfully")
    elif args.hooks_cmd == "status":
        s = status(root)
        print("[hooks] Hook status:")
        for hook, installed in s.items():
            status_str = "✓ installed" if installed else "✗ not installed"
            print(f"  {hook}: {status_str}")
    else:
        print("[hooks] Usage: branchpy hooks install|uninstall|status")
