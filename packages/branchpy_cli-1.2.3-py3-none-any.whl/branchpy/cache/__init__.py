"""
BranchPy Cache Layer — Advanced Caching Infrastructure

Provides TTL-based caching with pluggable storage backends for provider adapters.

BranchPy v0.9.1.3 — H3 Advanced Caching
Governance ID: AXIS5-V0.9.1.3-20251113-IMPL

Components:
- CacheManager: Central cache orchestration with TTL tracking
- CacheBackend: Abstract storage interface (in-memory, SQLite, Redis)
- @cached decorator: Automatic method result caching
- Key generation: Deterministic SHA-256 hashing

BQS Compliance:
- Cross-platform: Works on Windows/Mac/Linux
- Engine-agnostic: No game engine dependencies
- Performance: ≤5ms lookup latency, ≥80% hit ratio target
- Structured logging: Cache hits/misses logged to telemetry

Usage:
    from branchpy.cache import CacheManager, InMemoryCacheBackend, cached

    # Initialize cache
    cache = CacheManager(backend=InMemoryCacheBackend())

    # Use decorator
    @cached(ttl=900)  # 15 minutes
    async def fetch_data(provider_id: str, path: str):
        # Expensive operation
        return data
"""

from branchpy.cache.backends.base import CacheBackend
from branchpy.cache.backends.memory import InMemoryCacheBackend
from branchpy.cache.backends.redis import RedisCacheBackend
from branchpy.cache.backends.sqlite import SQLiteCacheBackend
from branchpy.cache.decorators import cached
from branchpy.cache.keys import generate_cache_key
from branchpy.cache.manager import CacheManager

__all__ = [
    "CacheManager",
    "CacheBackend",
    "InMemoryCacheBackend",
    "SQLiteCacheBackend",
    "RedisCacheBackend",
    "cached",
    "generate_cache_key",
]

__version__ = "0.9.1.3"
