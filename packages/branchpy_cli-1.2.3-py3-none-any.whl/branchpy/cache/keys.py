"""
Cache key generation utilities.

Provides deterministic SHA-256 cache key generation for provider operations.

BranchPy v0.9.1.3 — H3 Advanced Caching
Governance ID: AXIS5-V0.9.1.3-20251113-IMPL
"""

import hashlib
import json
from typing import Any, Dict


def generate_cache_key(provider_id: str, remote_path: str, **kwargs: Any) -> str:
    """
    Generate deterministic SHA-256 cache key from provider operation parameters.

    Args:
        provider_id: Provider identifier (e.g., "onedrive-prod-001")
        remote_path: Remote resource path (e.g., "/Documents/Reports")
        **kwargs: Additional query parameters (filters, limits, recursive flags)

    Returns:
        Hex-encoded SHA-256 hash (64 characters)

    Examples:
        >>> generate_cache_key("onedrive-prod", "/Documents")
        'a3c7f9e2b1d8c5a4f6e9d2b7c1a8f5e3d9b6c4a2f8e5d1c7b9a6f3e2d8c5b1a4'

        >>> generate_cache_key("dropbox-test", "/Photos", recursive=True, limit=100)
        'f4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3'

    BQS Compliance:
        - Cross-platform: SHA-256 produces same hash on Windows/Mac/Linux
        - Deterministic: Same inputs always produce same output
        - Collision-resistant: 2^256 possible keys (effectively infinite)

    Notes:
        - Keys are sorted before hashing for deterministic ordering
        - Nested dicts/lists in kwargs are recursively sorted
        - Cache key does NOT include credentials (security requirement)
    """
    # Build canonical payload
    payload: Dict[str, Any] = {
        "provider_id": provider_id,
        "remote_path": remote_path,
    }

    # Add additional parameters (sorted for determinism)
    if kwargs:
        payload.update(kwargs)

    # Serialize to JSON with sorted keys
    canonical_json = json.dumps(payload, sort_keys=True, separators=(",", ":"))

    # Generate SHA-256 hash
    hash_bytes = hashlib.sha256(canonical_json.encode("utf-8")).digest()

    # Return hex-encoded string
    return hash_bytes.hex()


def validate_cache_key(key: str) -> bool:
    """
    Validate cache key format.

    Args:
        key: Cache key to validate

    Returns:
        True if key is valid SHA-256 hex string (64 chars), False otherwise

    Examples:
        >>> validate_cache_key("a" * 64)
        True

        >>> validate_cache_key("invalid")
        False
    """
    if not isinstance(key, str):
        return False

    if len(key) != 64:
        return False

    # Check if valid hex
    try:
        int(key, 16)
        return True
    except ValueError:
        return False
