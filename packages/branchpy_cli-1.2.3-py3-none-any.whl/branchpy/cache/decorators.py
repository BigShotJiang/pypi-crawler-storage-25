"""
Cache decorator for automatic method result caching.

Provides @cached decorator for async methods with SHA-256 key generation.

BranchPy v0.9.1.2 — H4 Telemetry Phase 3 Integration
Governance ID: AXIS5-V0.9.1.2-20251113-H4-G2
"""

import inspect
import random
from functools import wraps
from time import perf_counter
from typing import Any, Callable, Optional

from branchpy.cache.keys import generate_cache_key
from branchpy.cache.manager import CacheManager

# Lazy import telemetry to avoid circular dependencies
_telemetry_handler = None
_telemetry_config = None


def _get_telemetry_handler():
    """Lazy load telemetry handler (singleton pattern)."""
    global _telemetry_handler, _telemetry_config
    if _telemetry_handler is None:
        try:
            from branchpy.telemetry.config import TelemetryConfig, load_config
            from branchpy.telemetry.phase3_handler import Phase3TelemetryHandler

            _telemetry_config = load_config()
            _telemetry_handler = Phase3TelemetryHandler(config=_telemetry_config)
        except ImportError:
            # Telemetry not available, disable silently
            pass
    return _telemetry_handler, _telemetry_config


async def _emit_cache_event(
    event_type: str, key: str, backend: str, latency_ms: float, **kwargs
):
    """
    Emit cache telemetry event (non-blocking, best-effort).

    Args:
        event_type: "cache.hit", "cache.miss", "cache.evict", "cache.invalidate", "cache.stats"
        key: Cache key
        backend: Backend name ("InMemory", "SQLite", "Redis")
        latency_ms: Operation latency
        **kwargs: Additional fields (hit_ratio, entry_count, namespace)
    """
    handler, config = _get_telemetry_handler()

    # Telemetry disabled or not available
    if not handler or not config:
        return

    # Feature flag: cache telemetry disabled
    if not config.cache_telemetry_enabled:
        return

    # Sampling: probabilistic event drop
    if random.random() > config.cache_sampling_rate:
        return

    try:
        from branchpy.telemetry.schemas import CacheEventSchema

        event = CacheEventSchema(
            event_type=event_type,
            key=key,
            backend=backend,
            latency_ms=latency_ms,
            **kwargs,
        )
        await handler.ingest_event(event)
    except Exception:
        # Non-blocking: telemetry failure must not break cache operations
        pass


def cached(ttl: int = 900, cache_manager: Optional[CacheManager] = None):
    """
    Decorator for caching async method results with TTL.

    Automatically generates cache keys from method arguments using SHA-256 hashing.

    Args:
        ttl: Time-to-live in seconds (default: 900 = 15 minutes)
        cache_manager: Custom cache manager (default: CacheManager.default())

    BQS Compliance:
        - Cross-platform: SHA-256 key generation works everywhere
        - Deterministic: Same inputs always produce same cache key
        - Security: No credentials included in cache keys

    Example:
        class ProviderAdapter:
            @cached(ttl=600)  # 10 minutes
            async def fetch(self, remote_path: str) -> List[MediaAsset]:
                # Expensive API call
                return await self._fetch_from_api(remote_path)

    Usage Notes:
        - Only works with async methods
        - First argument should be 'self' (instance method)
        - Cache key generated from: self.metadata.provider_id + method args
        - Keyword arguments are included in cache key (sorted)
    """

    def decorator(func: Callable) -> Callable:
        # Verify function is async
        if not inspect.iscoroutinefunction(func):
            raise TypeError(
                f"@cached can only be used with async functions, got {func.__name__}"
            )

        @wraps(func)
        async def wrapper(self, *args, **kwargs) -> Any:
            # Get cache manager
            cache = cache_manager or CacheManager.default()

            # Extract provider_id from self.metadata
            # Handle both dict and object attribute access
            metadata = getattr(self, "metadata", {})
            if isinstance(metadata, dict):
                provider_id = metadata.get("provider_id", "unknown")
            else:
                provider_id = getattr(metadata, "provider_id", "unknown")

            # Generate cache key from arguments
            # Handle both 'path' and 'remote_path' parameter names for backward compatibility
            # First positional arg is the path
            if args:
                path_value = args[0]
            elif "path" in kwargs:
                path_value = kwargs["path"]
            elif "remote_path" in kwargs:
                path_value = kwargs["remote_path"]
            else:
                path_value = ""

            # Build kwargs for cache key (exclude path/remote_path as we pass it explicitly)
            cache_kwargs = {
                k: v for k, v in kwargs.items() if k not in ("path", "remote_path")
            }

            cache_key = generate_cache_key(
                provider_id=provider_id,
                remote_path=str(path_value),
                method=func.__name__,
                **cache_kwargs,
            )

            # Track latency
            start = perf_counter()

            # Try cache hit
            cached_value = await cache.get(cache_key)
            hit = cached_value is not None

            if hit:
                # Cache hit - emit telemetry
                latency_ms = (perf_counter() - start) * 1000
                await _emit_cache_event(
                    event_type="cache.hit",
                    key=cache_key,
                    backend=cache.backend.__class__.__name__.replace(
                        "CacheBackend", ""
                    ),
                    latency_ms=latency_ms,
                )
                return cached_value

            # Cache miss - emit telemetry
            latency_ms = (perf_counter() - start) * 1000
            await _emit_cache_event(
                event_type="cache.miss",
                key=cache_key,
                backend=cache.backend.__class__.__name__.replace("CacheBackend", ""),
                latency_ms=latency_ms,
            )

            # Call original function
            # If called with 'remote_path' but function expects 'path', normalize it
            if not args and "remote_path" in kwargs and "path" not in kwargs:
                # Convert remote_path → path for function call
                func_kwargs = {**kwargs, "path": kwargs["remote_path"]}
                del func_kwargs["remote_path"]
                result = await func(self, **func_kwargs)
            else:
                result = await func(self, *args, **kwargs)

            # Store in cache
            await cache.set(cache_key, result, ttl=ttl)

            return result

        return wrapper

    return decorator


def cache_invalidate(cache_manager: Optional[CacheManager] = None):
    """
    Decorator for invalidating cache after method execution.

    Useful for operations that modify data (upload, delete) to ensure cache consistency.

    Args:
        cache_manager: Custom cache manager (default: CacheManager.default())

    Example:
        class ProviderAdapter:
            @cache_invalidate()
            async def upload(self, local_path: str, remote_path: str):
                # Upload file
                result = await self._upload_to_api(local_path, remote_path)

                # Cache for remote_path is automatically invalidated
                return result

    Usage Notes:
        - Invalidates all cache entries for the affected remote_path
        - Only works with async methods
        - Should be used on write operations (upload, delete, update)
        - Clears entire cache (simple implementation for now)
    """

    def decorator(func: Callable) -> Callable:
        if not inspect.iscoroutinefunction(func):
            raise TypeError("@cache_invalidate can only be used with async functions")

        @wraps(func)
        async def wrapper(self, *args, **kwargs) -> Any:
            # Execute original function
            result = await func(self, *args, **kwargs)

            # Clear entire cache after write operation
            # (Full implementation would selectively invalidate, but this is simpler for H3)
            cache = cache_manager or CacheManager.default()

            # Extract provider_id for telemetry
            metadata = getattr(self, "metadata", {})
            if isinstance(metadata, dict):
                provider_id = metadata.get("provider_id", "unknown")
            else:
                provider_id = getattr(metadata, "provider_id", "unknown")

            # Emit invalidate event before clearing
            await _emit_cache_event(
                event_type="cache.invalidate",
                key="",  # No specific key (clear all)
                backend=cache.backend.__class__.__name__.replace("CacheBackend", ""),
                latency_ms=0.0,
                namespace=provider_id,
            )

            await cache.clear()

            return result

        return wrapper

    return decorator
