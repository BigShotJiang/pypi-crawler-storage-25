"""
Redis distributed cache backend.

Provides high-performance distributed caching with Redis.

BranchPy v0.9.1.3 — H3 Advanced Caching
Governance ID: AXIS5-V0.9.1.3-20251113-IMPL
"""

import asyncio
import pickle
from typing import Any, Optional

from branchpy.cache.backends.base import CacheBackend

# Redis import is optional - gracefully degrade if not available
try:
    import redis.asyncio as redis

    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    redis = None


class RedisCacheBackend(CacheBackend):
    """
    Redis-based distributed cache backend.

    Features:
        - Distributed caching (shared across multiple processes/servers)
        - High performance (in-memory storage)
        - Automatic TTL expiration (Redis native)
        - Connection pooling

    Args:
        host: Redis server host (default: "localhost")
        port: Redis server port (default: 6379)
        db: Redis database number (default: 0)
        password: Redis password (default: None)
        key_prefix: Key prefix for namespacing (default: "branchpy:cache:")
        default_ttl: Default TTL in seconds (default: 900 = 15 minutes)

    BQS Compliance:
        - Cross-platform: Redis works on Windows/Mac/Linux
        - Performance: Sub-millisecond lookups
        - Scalability: Distributed caching for multi-server deployments

    Requirements:
        pip install redis[asyncio]

    Example:
        cache = RedisCacheBackend(host="redis.example.com", password="secret")
        await cache.set("key1", {"data": "value"}, ttl=600)
        value = await cache.get("key1")

    Key Format:
        branchpy:cache:{cache_key}

        Example:
        branchpy:cache:a3c7f9e2b1d8c5a4f6e9d2b7c1a8f5e3d9b6c4a2f8e5d1c7b9a6f3e2d8c5b1a4
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        key_prefix: str = "branchpy:cache:",
        default_ttl: int = 900,
    ):
        """
        Initialize Redis cache backend.

        Args:
            host: Redis server host
            port: Redis server port
            db: Redis database number
            password: Redis password
            key_prefix: Key prefix for namespacing
            default_ttl: Default time-to-live in seconds
        """
        if not REDIS_AVAILABLE:
            raise ImportError(
                "Redis backend requires 'redis' package. "
                "Install with: pip install redis[asyncio]"
            )

        self.host = host
        self.port = port
        self.db = db
        self.password = password
        self.key_prefix = key_prefix
        self.default_ttl = default_ttl

        # Connection will be created lazily
        self._client: Optional[redis.Redis] = None
        self._lock = asyncio.Lock()

        # Statistics (local tracking)
        self._hits = 0
        self._misses = 0

    async def _ensure_connection(self):
        """Ensure Redis connection is established."""
        if self._client is not None:
            return

        self._client = redis.Redis(
            host=self.host,
            port=self.port,
            db=self.db,
            password=self.password,
            decode_responses=False,  # We handle binary data (pickle)
        )

        # Test connection
        await self._client.ping()

    def _make_key(self, key: str) -> str:
        """
        Generate Redis key with prefix.

        Args:
            key: Cache key

        Returns:
            Prefixed key (e.g., "branchpy:cache:abc123...")
        """
        return f"{self.key_prefix}{key}"

    async def get(self, key: str) -> Optional[Any]:
        """
        Retrieve value from Redis cache.

        Args:
            key: Cache key

        Returns:
            Cached value if exists, None otherwise

        Note:
            Redis handles TTL expiration automatically - expired keys return None
        """
        async with self._lock:
            await self._ensure_connection()

            redis_key = self._make_key(key)
            value_bytes = await self._client.get(redis_key)

            if value_bytes is None:
                self._misses += 1
                return None

            # Deserialize value
            try:
                value = pickle.loads(value_bytes)
                self._hits += 1
                return value
            except Exception:
                # Deserialization failed - delete corrupted entry
                await self._client.delete(redis_key)
                self._misses += 1
                return None

    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """
        Store value in Redis cache with TTL.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds

        Note:
            Redis uses SETEX for automatic TTL expiration
        """
        async with self._lock:
            await self._ensure_connection()

            # Serialize value
            value_bytes = pickle.dumps(value)

            # Calculate TTL
            ttl_seconds = ttl if ttl is not None else self.default_ttl

            redis_key = self._make_key(key)

            if ttl_seconds > 0:
                # Set with expiration
                await self._client.setex(redis_key, ttl_seconds, value_bytes)
            else:
                # Set without expiration
                await self._client.set(redis_key, value_bytes)

    async def delete(self, key: str) -> bool:
        """Delete entry from cache."""
        async with self._lock:
            await self._ensure_connection()

            redis_key = self._make_key(key)
            deleted_count = await self._client.delete(redis_key)

            return deleted_count > 0

    async def clear(self):
        """
        Clear all entries from cache (only with matching prefix).

        Note:
            Uses SCAN + DEL for safe deletion (doesn't block Redis)
        """
        async with self._lock:
            await self._ensure_connection()

            pattern = f"{self.key_prefix}*"
            cursor = 0

            while True:
                cursor, keys = await self._client.scan(cursor, match=pattern, count=100)

                if keys:
                    await self._client.delete(*keys)

                if cursor == 0:
                    break

            self._hits = 0
            self._misses = 0

    async def remove_expired(self) -> int:
        """
        Remove expired entries.

        Returns:
            0 (Redis handles expiration automatically)

        Note:
            Redis automatically removes expired keys - this is a no-op
        """
        return 0  # Redis handles TTL expiration natively

    async def size(self) -> int:
        """
        Get current number of cached entries.

        Returns:
            Count of keys with matching prefix
        """
        async with self._lock:
            await self._ensure_connection()

            pattern = f"{self.key_prefix}*"
            cursor = 0
            count = 0

            while True:
                cursor, keys = await self._client.scan(cursor, match=pattern, count=100)
                count += len(keys)

                if cursor == 0:
                    break

            return count

    async def get_stats(self) -> dict:
        """
        Get cache statistics.

        Returns:
            Dict with cache metrics
        """
        async with self._lock:
            await self._ensure_connection()

            # Get Redis server info
            info = await self._client.info("memory")

            # Count our keys
            total_entries = await self.size()

            hit_ratio = (
                self._hits / (self._hits + self._misses)
                if (self._hits + self._misses) > 0
                else 0.0
            )

            return {
                "backend": "Redis",
                "host": self.host,
                "port": self.port,
                "db": self.db,
                "key_prefix": self.key_prefix,
                "total_entries": total_entries,
                "expired_entries": 0,  # Redis handles TTL automatically
                "redis_used_memory": info.get("used_memory", 0),
                "redis_used_memory_human": info.get("used_memory_human", "N/A"),
                "hits": self._hits,
                "misses": self._misses,
                "hit_ratio": round(hit_ratio, 4),
            }

    async def close(self):
        """Close Redis connection."""
        async with self._lock:
            if self._client:
                await self._client.close()
                self._client = None
