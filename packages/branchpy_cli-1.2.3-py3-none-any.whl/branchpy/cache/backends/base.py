"""
Abstract cache backend interface.

Defines the contract for all cache storage implementations.

BranchPy v0.9.1.3 — H3 Advanced Caching
Governance ID: AXIS5-V0.9.1.3-20251113-IMPL
"""

from abc import ABC, abstractmethod
from typing import Any, Optional


class CacheBackend(ABC):
    """
    Abstract base class for cache storage backends.

    All cache backends (in-memory, SQLite, Redis) must implement this interface.

    BQS Compliance:
        - Cross-platform: Interface works on Windows/Mac/Linux
        - Engine-agnostic: No game engine dependencies
        - Async: All methods are async for non-blocking I/O

    Example:
        class MyCustomBackend(CacheBackend):
            async def get(self, key: str) -> Optional[Any]:
                # Custom implementation
                pass

            async def set(self, key: str, value: Any, ttl: Optional[int] = None):
                # Custom implementation
                pass
    """

    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """
        Retrieve value from cache by key.

        Args:
            key: Cache key (SHA-256 hex string)

        Returns:
            Cached value if exists and not expired, None otherwise

        Notes:
            - Must check TTL expiration before returning value
            - Expired entries should be removed automatically
        """
        pass

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """
        Store value in cache with optional TTL.

        Args:
            key: Cache key (SHA-256 hex string)
            value: Value to cache (must be serializable)
            ttl: Time-to-live in seconds (None = no expiration)

        Notes:
            - If TTL is provided, calculate expires_at = now + ttl
            - Serialization format depends on backend (pickle, JSON, etc.)
        """
        pass

    @abstractmethod
    async def delete(self, key: str) -> bool:
        """
        Delete entry from cache.

        Args:
            key: Cache key to delete

        Returns:
            True if entry was deleted, False if key not found

        Use Cases:
            - Manual cache invalidation
            - Clearing specific provider's cache
        """
        pass

    @abstractmethod
    async def clear(self):
        """
        Clear all entries from cache.

        Use Cases:
            - Testing (reset cache between tests)
            - Admin operations (clear all cached data)

        Notes:
            - This is a destructive operation
            - Should be used with caution in production
        """
        pass

    @abstractmethod
    async def remove_expired(self) -> int:
        """
        Remove all expired entries from cache.

        Returns:
            Number of entries removed

        Notes:
            - Called by background cleanup task (every 60s)
            - Should iterate through all entries and check expires_at
        """
        pass

    @abstractmethod
    async def size(self) -> int:
        """
        Get current number of cached entries.

        Returns:
            Total number of entries in cache (including expired)

        Use Cases:
            - Monitoring cache usage
            - Debugging cache performance
            - Telemetry metrics
        """
        pass

    @abstractmethod
    async def get_stats(self) -> dict:
        """
        Get cache statistics.

        Returns:
            Dict with cache metrics:
            - total_entries: int
            - expired_entries: int
            - memory_usage_bytes: int (if applicable)
            - oldest_entry: datetime (if applicable)
            - newest_entry: datetime (if applicable)

        Use Cases:
            - Performance monitoring
            - Capacity planning
            - Telemetry dashboard
        """
        pass
