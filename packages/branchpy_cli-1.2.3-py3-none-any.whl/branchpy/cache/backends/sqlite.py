"""
SQLite persistent cache backend.

Provides durable caching with SQLite database storage.

BranchPy v0.9.1.3 — H3 Advanced Caching
Governance ID: AXIS5-V0.9.1.3-20251113-IMPL
"""

import asyncio
import pickle
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from branchpy.cache.backends.base import CacheBackend


class SQLiteCacheBackend(CacheBackend):
    """
    SQLite-based persistent cache backend.

    Features:
        - Persistent storage (survives process restarts)
        - ACID transactions
        - Indexed lookups (fast key retrieval)
        - Automatic schema migration

    Args:
        db_path: Path to SQLite database file (default: "cache.db")
        default_ttl: Default TTL in seconds (default: 900 = 15 minutes)

    BQS Compliance:
        - Cross-platform: SQLite works on Windows/Mac/Linux
        - Performance: Indexed queries, connection pooling
        - Durability: Data persists across restarts

    Schema:
        CREATE TABLE cache_entries (
            key TEXT PRIMARY KEY,
            value BLOB NOT NULL,
            expires_at TIMESTAMP,
            created_at TIMESTAMP NOT NULL,
            size_bytes INTEGER
        );

        CREATE INDEX idx_expires_at ON cache_entries(expires_at);

    Example:
        cache = SQLiteCacheBackend(db_path="branchpy_cache.db")
        await cache.set("key1", {"data": "value"}, ttl=600)
        value = await cache.get("key1")
    """

    def __init__(self, db_path: str = "cache.db", default_ttl: int = 900):
        """
        Initialize SQLite cache backend.

        Args:
            db_path: Path to SQLite database file
            default_ttl: Default time-to-live in seconds
        """
        self.db_path = Path(db_path)
        self.default_ttl = default_ttl

        # Connection will be created lazily (async)
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = asyncio.Lock()

        # Statistics
        self._hits = 0
        self._misses = 0

    async def _ensure_connection(self):
        """Ensure database connection and schema are initialized."""
        if self._conn is not None:
            return

        # Create connection
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row

        # Create schema
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS cache_entries (
                key TEXT PRIMARY KEY,
                value BLOB NOT NULL,
                expires_at TIMESTAMP,
                created_at TIMESTAMP NOT NULL,
                size_bytes INTEGER
            )
        """
        )

        # Create index for TTL cleanup
        self._conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_expires_at 
            ON cache_entries(expires_at)
        """
        )

        self._conn.commit()

    async def get(self, key: str) -> Optional[Any]:
        """
        Retrieve value from SQLite cache.

        Args:
            key: Cache key

        Returns:
            Cached value if exists and not expired, None otherwise
        """
        async with self._lock:
            await self._ensure_connection()

            cursor = self._conn.execute(
                "SELECT value, expires_at FROM cache_entries WHERE key = ?", (key,)
            )

            row = cursor.fetchone()
            if row is None:
                self._misses += 1
                return None

            # Check expiration
            if row["expires_at"]:
                expires_at = datetime.fromisoformat(row["expires_at"])
                if datetime.now() > expires_at:
                    # Expired - delete and return None
                    self._conn.execute(
                        "DELETE FROM cache_entries WHERE key = ?", (key,)
                    )
                    self._conn.commit()
                    self._misses += 1
                    return None

            # Deserialize value
            try:
                value = pickle.loads(row["value"])
                self._hits += 1
                return value
            except Exception:
                # Deserialization failed - delete corrupted entry
                self._conn.execute("DELETE FROM cache_entries WHERE key = ?", (key,))
                self._conn.commit()
                self._misses += 1
                return None

    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """
        Store value in SQLite cache.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds
        """
        async with self._lock:
            await self._ensure_connection()

            # Serialize value
            value_bytes = pickle.dumps(value)
            size_bytes = len(value_bytes)

            # Calculate expiration
            ttl_seconds = ttl if ttl is not None else self.default_ttl
            expires_at = (
                (datetime.now() + timedelta(seconds=ttl_seconds)).isoformat()
                if ttl_seconds > 0
                else None
            )

            # Insert or replace
            self._conn.execute(
                """
                INSERT OR REPLACE INTO cache_entries 
                (key, value, expires_at, created_at, size_bytes)
                VALUES (?, ?, ?, ?, ?)
            """,
                (key, value_bytes, expires_at, datetime.now().isoformat(), size_bytes),
            )

            self._conn.commit()

    async def delete(self, key: str) -> bool:
        """Delete entry from cache."""
        async with self._lock:
            await self._ensure_connection()

            cursor = self._conn.execute(
                "DELETE FROM cache_entries WHERE key = ?", (key,)
            )
            self._conn.commit()

            return cursor.rowcount > 0

    async def clear(self):
        """Clear all entries from cache."""
        async with self._lock:
            await self._ensure_connection()

            self._conn.execute("DELETE FROM cache_entries")
            self._conn.commit()

            self._hits = 0
            self._misses = 0

    async def remove_expired(self) -> int:
        """Remove all expired entries."""
        async with self._lock:
            await self._ensure_connection()

            cursor = self._conn.execute(
                "DELETE FROM cache_entries WHERE expires_at IS NOT NULL AND expires_at < ?",
                (datetime.now().isoformat(),),
            )
            self._conn.commit()

            return cursor.rowcount

    async def size(self) -> int:
        """Get current number of cached entries."""
        async with self._lock:
            await self._ensure_connection()

            cursor = self._conn.execute("SELECT COUNT(*) as count FROM cache_entries")
            row = cursor.fetchone()
            return row["count"]

    async def get_stats(self) -> dict:
        """Get cache statistics."""
        async with self._lock:
            await self._ensure_connection()

            # Total entries
            cursor = self._conn.execute("SELECT COUNT(*) as count FROM cache_entries")
            total_entries = cursor.fetchone()["count"]

            # Expired entries
            cursor = self._conn.execute(
                """
                SELECT COUNT(*) as count FROM cache_entries 
                WHERE expires_at IS NOT NULL AND expires_at < ?
            """,
                (datetime.now().isoformat(),),
            )
            expired_entries = cursor.fetchone()["count"]

            # Total size
            cursor = self._conn.execute(
                "SELECT SUM(size_bytes) as total FROM cache_entries"
            )
            total_size = cursor.fetchone()["total"] or 0

            # Oldest/newest entries
            cursor = self._conn.execute(
                "SELECT MIN(created_at) as oldest, MAX(created_at) as newest FROM cache_entries"
            )
            row = cursor.fetchone()
            oldest = row["oldest"]
            newest = row["newest"]

            hit_ratio = (
                self._hits / (self._hits + self._misses)
                if (self._hits + self._misses) > 0
                else 0.0
            )

            return {
                "backend": "SQLite",
                "db_path": str(self.db_path),
                "total_entries": total_entries,
                "expired_entries": expired_entries,
                "memory_usage_bytes": total_size,
                "database_size_bytes": total_size,  # Alias for compatibility
                "oldest_entry": oldest,
                "newest_entry": newest,
                "hits": self._hits,
                "misses": self._misses,
                "hit_ratio": round(hit_ratio, 4),
            }

    async def close(self):
        """Close database connection."""
        async with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
