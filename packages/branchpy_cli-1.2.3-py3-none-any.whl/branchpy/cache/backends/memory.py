"""
In-memory cache backend with LRU eviction and TTL support.

Provides fast process-local caching with automatic expiration and size limits.

BranchPy v0.9.1.3 — H3 Advanced Caching
Governance ID: AXIS5-V0.9.1.3-20251113-IMPL
"""

import asyncio
import sys
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import Any, Optional

from branchpy.cache.backends.base import CacheBackend


class InMemoryCacheBackend(CacheBackend):
    """
    In-memory cache backend using OrderedDict for LRU eviction.

    Features:
        - LRU (Least Recently Used) eviction when max_size reached
        - TTL (Time-To-Live) expiration support
        - Thread-safe operations (asyncio lock)
        - Fast lookups (O(1) average case)

    Args:
        max_size: Maximum number of entries (default: 1000)
        default_ttl: Default TTL in seconds (default: 900 = 15 minutes)

    BQS Compliance:
        - Cross-platform: Pure Python implementation
        - Performance: O(1) get/set operations
        - Memory efficient: Automatic LRU eviction

    Example:
        cache = InMemoryCacheBackend(max_size=500, default_ttl=600)
        await cache.set("key1", {"data": "value"}, ttl=300)
        value = await cache.get("key1")  # Returns {"data": "value"}
    """

    def __init__(self, max_size: int = 1000, default_ttl: int = 900):
        """
        Initialize in-memory cache.

        Args:
            max_size: Maximum number of entries before LRU eviction
            default_ttl: Default time-to-live in seconds
        """
        self.max_size = max_size
        self.default_ttl = default_ttl

        # Storage: OrderedDict for LRU behavior
        # Key: cache_key (str)
        # Value: dict with 'data', 'expires_at', 'created_at'
        self._storage: OrderedDict[str, dict] = OrderedDict()

        # Lock for thread-safe operations
        self._lock = asyncio.Lock()

        # Statistics
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    async def get(self, key: str) -> Optional[Any]:
        """
        Retrieve value from cache with LRU update.

        Args:
            key: Cache key

        Returns:
            Cached value if exists and not expired, None otherwise
        """
        async with self._lock:
            if key not in self._storage:
                self._misses += 1
                return None

            entry = self._storage[key]

            # Check expiration
            if entry["expires_at"] and datetime.now() > entry["expires_at"]:
                # Expired - remove and return None
                del self._storage[key]
                self._misses += 1
                return None

            # Cache hit - move to end (most recently used)
            self._storage.move_to_end(key)
            self._hits += 1

            return entry["data"]

    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """
        Store value in cache with TTL.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds (None = use default_ttl)
        """
        async with self._lock:
            # Calculate expiration
            ttl_seconds = ttl if ttl is not None else self.default_ttl
            expires_at = (
                datetime.now() + timedelta(seconds=ttl_seconds)
                if ttl_seconds > 0
                else None
            )

            # Create entry
            entry = {
                "data": value,
                "expires_at": expires_at,
                "created_at": datetime.now(),
                "size_bytes": sys.getsizeof(value),  # Approximate size
            }

            # If key exists, update it (preserves LRU order)
            if key in self._storage:
                self._storage[key] = entry
                self._storage.move_to_end(key)
            else:
                # New entry - check max_size
                if len(self._storage) >= self.max_size:
                    # Evict least recently used (first item)
                    self._storage.popitem(last=False)
                    self._evictions += 1

                self._storage[key] = entry

    async def delete(self, key: str) -> bool:
        """
        Delete entry from cache.

        Args:
            key: Cache key

        Returns:
            True if deleted, False if not found
        """
        async with self._lock:
            if key in self._storage:
                del self._storage[key]
                return True
            return False

    async def clear(self):
        """Clear all entries from cache."""
        async with self._lock:
            self._storage.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0

    async def remove_expired(self) -> int:
        """
        Remove all expired entries.

        Returns:
            Number of entries removed
        """
        async with self._lock:
            now = datetime.now()
            expired_keys = [
                key
                for key, entry in self._storage.items()
                if entry["expires_at"] and now > entry["expires_at"]
            ]

            for key in expired_keys:
                del self._storage[key]

            return len(expired_keys)

    async def size(self) -> int:
        """Get current number of cached entries."""
        async with self._lock:
            return len(self._storage)

    async def get_stats(self) -> dict:
        """
        Get cache statistics.

        Returns:
            Dict with cache metrics
        """
        async with self._lock:
            now = datetime.now()
            expired_count = sum(
                1
                for entry in self._storage.values()
                if entry["expires_at"] and now > entry["expires_at"]
            )

            total_size = sum(
                entry.get("size_bytes", 0) for entry in self._storage.values()
            )

            oldest = None
            newest = None
            if self._storage:
                oldest = min(entry["created_at"] for entry in self._storage.values())
                newest = max(entry["created_at"] for entry in self._storage.values())

            hit_ratio = (
                self._hits / (self._hits + self._misses)
                if (self._hits + self._misses) > 0
                else 0.0
            )

            return {
                "backend": "InMemory",
                "total_entries": len(self._storage),
                "expired_entries": expired_count,
                "max_size": self.max_size,
                "memory_usage_bytes": total_size,
                "oldest_entry": oldest.isoformat() if oldest else None,
                "newest_entry": newest.isoformat() if newest else None,
                "hits": self._hits,
                "misses": self._misses,
                "evictions": self._evictions,
                "hit_ratio": round(hit_ratio, 4),
            }
