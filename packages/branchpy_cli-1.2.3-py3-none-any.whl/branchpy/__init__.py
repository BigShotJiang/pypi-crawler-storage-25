from . import cli  # exposes branchpy.cli
from . import parser, report
from .contract import VERSION

# Try to import telemetry and governance, but don't fail if they have optional dependencies
try:
    from . import telemetry
except (ImportError, ModuleNotFoundError):
    # telemetry has optional dependencies, skip if not available
    pass

try:
    from . import governance
except (ImportError, ModuleNotFoundError):
    # governance may have optional dependencies, skip if not available
    pass

# Expose version as both VERSION and __version__ for compatibility
__version__ = VERSION

__all__ = [
    "cli",
    "parser",
    "report",
    "telemetry",
    "governance",
    "VERSION",
    "__version__",
]
