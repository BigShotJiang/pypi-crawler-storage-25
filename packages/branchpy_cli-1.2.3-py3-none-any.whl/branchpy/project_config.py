# branchpy/project_config.py
"""
Project-level configuration support via .branchpy.toml files.
Allows setting CLI defaults and project-specific preferences.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


@dataclass
class ProjectConfig:
    """Project-level configuration from .branchpy.toml"""

    # CLI defaults
    media_exts: Optional[str] = None  # Default extensions for media commands
    media_ignore: Optional[str] = None  # Default ignore patterns
    media_assets_root: Optional[str] = None  # Default assets root

    # Analysis defaults
    tests_save_report: bool = False  # Auto-save reports by default
    tests_format: str = "summary"  # Default output format

    # Compare defaults
    compare_format: str = "summary"  # Default compare format

    # Project metadata
    name: Optional[str] = None  # Friendly project name
    description: Optional[str] = None  # Project description

    # Advanced settings
    patch_rotation_limit: int = 10  # Number of patches to keep
    log_level: str = "INFO"  # Default log level

    # Watch mode settings
    watch_debounce_ms: int = 300  # Debounce delay in milliseconds
    watch_include: List[str] = field(
        default_factory=lambda: ["**/*.rpy", "assets/**", "game/**", ".branchpy.toml"]
    )
    watch_exclude: List[str] = field(
        default_factory=lambda: ["**/__pycache__/**", "**/.git/**", "**/build/**"]
    )
    watch_default_command: str = "tests"  # Default command to run

    # Serve mode settings
    serve_port: int = 8765  # Default port for local dashboard
    serve_auth: str = "none"  # Authentication mode (none, token)
    serve_auto_open: bool = False  # Auto-open browser
    serve_headless: bool = False  # Run without console output

    # Logs settings
    logs_level: str = "info"  # Log level (debug, info, warning, error)
    logs_max_lines: int = 1000  # Maximum lines to keep
    logs_format: str = "text"  # Log format (text, json)

    # Control Center UI settings
    ui_auto_update: bool = True  # Check for BranchPy updates
    ui_renpy_path: Optional[str] = (
        None  # Path to Ren'Py executable (legacy, use renpy_default)
    )
    ui_patch_directory: str = "./patches"  # Default patch directory
    ui_media_scan_depth: int = 3  # Directory levels to scan for media
    ui_notifications_verbosity: str = (
        "normal"  # Notification level (silent, errors, normal, verbose)
    )

    # Ren'Py SDK Management
    renpy_default: Optional[str] = None  # Default SDK key or version
    renpy_sdks: Dict[str, str] = field(default_factory=dict)  # SDK name -> path mapping
    renpy_project_pin: Optional[str] = None  # Per-project SDK override

    # Custom settings (for extensibility)
    custom: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def default(cls) -> "ProjectConfig":
        """Return default configuration."""
        return cls()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectConfig":
        """Create ProjectConfig from dictionary."""
        # Extract known fields
        known_fields = {
            "media_exts",
            "media_ignore",
            "media_assets_root",
            "tests_save_report",
            "tests_format",
            "compare_format",
            "name",
            "description",
            "patch_rotation_limit",
            "log_level",
            "watch_debounce_ms",
            "watch_include",
            "watch_exclude",
            "watch_default_command",
            "serve_port",
            "serve_auth",
            "serve_auto_open",
            "serve_headless",
            "logs_level",
            "logs_max_lines",
            "logs_format",
            "ui_auto_update",
            "ui_renpy_path",
            "ui_patch_directory",
            "ui_media_scan_depth",
            "ui_notifications_verbosity",
            "renpy_default",
            "renpy_sdks",
            "renpy_project_pin",
        }

        # Handle special nested structures for Ren'Py SDK config
        processed_data = {}
        for key, value in data.items():
            if key == "renpy" and isinstance(value, dict):
                # Handle [renpy] section from TOML
                if "default" in value:
                    processed_data["renpy_default"] = value["default"]
                if "sdks" in value and isinstance(value["sdks"], dict):
                    processed_data["renpy_sdks"] = value["sdks"]
            elif key == "project" and isinstance(value, dict):
                # Handle [project] section from TOML
                if "renpy" in value:
                    processed_data["renpy_project_pin"] = value["renpy"]
                # Add other project fields
                for proj_key, proj_value in value.items():
                    if proj_key != "renpy":
                        processed_data[proj_key] = proj_value
            else:
                processed_data[key] = value

        # Separate known from custom fields
        known_data = {k: v for k, v in processed_data.items() if k in known_fields}
        custom_data = {k: v for k, v in processed_data.items() if k not in known_fields}

        return cls(custom=custom_data, **known_data)

    def to_dict(self) -> Dict[str, Any]:
        """Convert ProjectConfig to dictionary."""
        result = {}

        # Add non-None fields
        if self.media_exts is not None:
            result["media_exts"] = self.media_exts
        if self.media_ignore is not None:
            result["media_ignore"] = self.media_ignore
        if self.media_assets_root is not None:
            result["media_assets_root"] = self.media_assets_root
        if self.tests_save_report:
            result["tests_save_report"] = self.tests_save_report
        if self.tests_format != "summary":
            result["tests_format"] = self.tests_format
        if self.compare_format != "summary":
            result["compare_format"] = self.compare_format
        if self.name is not None:
            result["name"] = self.name
        if self.description is not None:
            result["description"] = self.description
        if self.patch_rotation_limit != 10:
            result["patch_rotation_limit"] = self.patch_rotation_limit
        if self.log_level != "INFO":
            result["log_level"] = self.log_level

        # Watch settings
        if self.watch_debounce_ms != 300:
            result["watch_debounce_ms"] = self.watch_debounce_ms
        if self.watch_include != ["**/*.rpy", "assets/**", "game/**", ".branchpy.toml"]:
            result["watch_include"] = self.watch_include
        if self.watch_exclude != ["**/__pycache__/**", "**/.git/**", "**/build/**"]:
            result["watch_exclude"] = self.watch_exclude
        if self.watch_default_command != "tests":
            result["watch_default_command"] = self.watch_default_command

        # Serve settings
        if self.serve_port != 8765:
            result["serve_port"] = self.serve_port
        if self.serve_auth != "none":
            result["serve_auth"] = self.serve_auth
        if self.serve_auto_open:
            result["serve_auto_open"] = self.serve_auto_open
        if self.serve_headless:
            result["serve_headless"] = self.serve_headless

        # Logs settings
        if self.logs_level != "info":
            result["logs_level"] = self.logs_level
        if self.logs_max_lines != 1000:
            result["logs_max_lines"] = self.logs_max_lines
        if self.logs_format != "text":
            result["logs_format"] = self.logs_format

        # UI settings
        if not self.ui_auto_update:
            result["ui_auto_update"] = self.ui_auto_update
        if self.ui_renpy_path is not None:
            result["ui_renpy_path"] = self.ui_renpy_path
        if self.ui_patch_directory != "./patches":
            result["ui_patch_directory"] = self.ui_patch_directory
        if self.ui_media_scan_depth != 3:
            result["ui_media_scan_depth"] = self.ui_media_scan_depth
        if self.ui_notifications_verbosity != "normal":
            result["ui_notifications_verbosity"] = self.ui_notifications_verbosity

        # Ren'Py SDK settings
        if self.renpy_default is not None:
            result["renpy_default"] = self.renpy_default
        if self.renpy_sdks:
            result["renpy_sdks"] = self.renpy_sdks
        if self.renpy_project_pin is not None:
            result["renpy_project_pin"] = self.renpy_project_pin

        # Add custom fields
        result.update(self.custom)

        return result

    def to_toml_dict(self) -> Dict[str, Any]:
        """Convert ProjectConfig to nested TOML structure."""
        result = {}

        # Add regular fields to their sections
        flat_dict = self.to_dict()

        # Organize into TOML sections
        sections = {
            "project": {},
            "renpy": {},
            "watch": {},
            "serve": {},
            "logs": {},
            "ui": {},
            "advanced": {},
        }

        for key, value in flat_dict.items():
            if key.startswith("watch_"):
                sections["watch"][key] = value
            elif key.startswith("serve_"):
                sections["serve"][key] = value
            elif key.startswith("logs_"):
                sections["logs"][key] = value
            elif key.startswith("ui_"):
                sections["ui"][key] = value
            elif key in [
                "name",
                "description",
                "media_exts",
                "media_ignore",
                "media_assets_root",
            ]:
                sections["project"][key] = value
            elif key in ["patch_rotation_limit", "log_level"]:
                sections["advanced"][key] = value
            elif key == "renpy_project_pin":
                sections["project"]["renpy"] = value
            elif key == "renpy_default":
                sections["renpy"]["default"] = value
            elif key == "renpy_sdks":
                sections["renpy"]["sdks"] = value
            else:
                # Tests and compare defaults go to root
                result[key] = value

        # Add non-empty sections
        for section_name, section_data in sections.items():
            if section_data:
                result[section_name] = section_data

        return result


def find_project_config_file(start_path: Union[str, Path]) -> Optional[Path]:
    """
    Find .branchpy.toml by walking up the directory tree from start_path.
    Returns the path to the config file if found, None otherwise.
    """
    current = Path(start_path).resolve()

    # Walk up the directory tree
    while current != current.parent:
        config_file = current / ".branchpy.toml"
        if config_file.exists() and config_file.is_file():
            return config_file
        current = current.parent

    return None


def load_project_config(project_path: Union[str, Path]) -> ProjectConfig:
    """
    Load project configuration from .branchpy.toml file.
    Returns default config if no file is found.
    """
    config_file = find_project_config_file(project_path)

    if not config_file:
        return ProjectConfig.default()

    try:
        # Use tomllib for Python 3.11+, fallback to parsing manually
        if sys.version_info >= (3, 11):
            import tomllib

            with open(config_file, "rb") as f:
                content = f.read()
                # Strip UTF-8 BOM if present (Windows editors frequently add this)
                if content.startswith(b"\xef\xbb\xbf"):
                    content = content[3:]
                data = tomllib.loads(content.decode("utf-8"))
        else:
            # Fallback: simple TOML-like parsing for basic cases
            data = _parse_simple_toml(config_file)

        # Extract [branchpy] section if it exists
        branchpy_data = data.get("branchpy", data)

        return ProjectConfig.from_dict(branchpy_data)

    except Exception as e:
        # On error, return default config but warn
        print(f"Warning: Could not parse {config_file}: {e}", file=sys.stderr)
        return ProjectConfig.default()


def save_project_config(project_path: Union[str, Path], config: ProjectConfig) -> bool:
    """
    Save project configuration to .branchpy/branchpy.toml file (canonical).
    Returns True if successful, False otherwise.
    """
    try:
        project_root = Path(project_path).resolve()
        branchpy_dir = project_root / ".branchpy"
        config_file = branchpy_dir / "branchpy.toml"

        # Ensure .branchpy directory exists
        branchpy_dir.mkdir(parents=True, exist_ok=True)

        # Create basic TOML content
        content = _generate_toml_content(config)

        with open(config_file, "w", encoding="utf-8") as f:
            f.write(content)

        return True

    except Exception as e:
        print(f"Error: Could not save config to {config_file}: {e}", file=sys.stderr)
        return False


def _parse_simple_toml(file_path: Path) -> Dict[str, Any]:
    """
    Simple TOML parser for basic key=value pairs and [sections].
    This is a fallback for older Python versions without tomllib.
    """
    data = {}
    current_section = data

    with open(file_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Handle sections
            if line.startswith("[") and line.endswith("]"):
                section_name = line[1:-1].strip()
                if section_name not in data:
                    data[section_name] = {}
                current_section = data[section_name]
                continue

            # Handle key=value pairs
            if "=" in line:
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip()

                # Basic type conversion
                if value.lower() in ("true", "false"):
                    value = value.lower() == "true"
                elif value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]  # Remove quotes
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]  # Remove quotes
                elif value.isdigit():
                    value = int(value)
                elif "." in value and value.replace(".", "").isdigit():
                    value = float(value)

                current_section[key] = value

    return data


def _generate_toml_content(config: ProjectConfig) -> str:
    """Generate TOML content from ProjectConfig."""
    lines = [
        "# BranchPy Project Configuration",
        "# This file contains project-specific defaults for BranchPy CLI commands.",
        "",
        "[branchpy]",
        "",
    ]

    data = config.to_dict()

    # Group related settings
    media_settings = {k: v for k, v in data.items() if k.startswith("media_")}
    test_settings = {k: v for k, v in data.items() if k.startswith("tests_")}
    compare_settings = {k: v for k, v in data.items() if k.startswith("compare_")}
    project_settings = {k: v for k, v in data.items() if k in ("name", "description")}
    other_settings = {
        k: v
        for k, v in data.items()
        if not any(k.startswith(prefix) for prefix in ("media_", "tests_", "compare_"))
        and k not in ("name", "description")
    }

    # Add project metadata
    if project_settings:
        lines.append("# Project metadata")
        for key, value in project_settings.items():
            lines.append(_format_toml_line(key, value))
        lines.append("")

    # Add media settings
    if media_settings:
        lines.append("# Media command defaults")
        for key, value in media_settings.items():
            lines.append(_format_toml_line(key, value))
        lines.append("")

    # Add test settings
    if test_settings:
        lines.append("# Tests command defaults")
        for key, value in test_settings.items():
            lines.append(_format_toml_line(key, value))
        lines.append("")

    # Add compare settings
    if compare_settings:
        lines.append("# Compare command defaults")
        for key, value in compare_settings.items():
            lines.append(_format_toml_line(key, value))
        lines.append("")

    # Add other settings
    if other_settings:
        lines.append("# Other settings")
        for key, value in other_settings.items():
            lines.append(_format_toml_line(key, value))
        lines.append("")

    return "\n".join(lines)


def _format_toml_line(key: str, value: Any) -> str:
    """Format a key-value pair as a TOML line."""
    if isinstance(value, bool):
        return f"{key} = {str(value).lower()}"
    elif isinstance(value, str):
        return f'{key} = "{value}"'
    elif isinstance(value, (int, float)):
        return f"{key} = {value}"
    else:
        return f'{key} = "{str(value)}"'
