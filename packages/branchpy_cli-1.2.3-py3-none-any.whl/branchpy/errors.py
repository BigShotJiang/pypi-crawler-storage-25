# branchpy/errors.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# Stable error codes (extend-only in the future)
E_LIC_INVALID = "E_LIC_INVALID"
E_LIC_OFFLINE = "E_LIC_OFFLINE"
E_BIN_MISSING = "E_BIN_MISSING"
E_SIG_FAIL = "E_SIG_FAIL"
E_NET_FAIL = "E_NET_FAIL"
E_PERM_DENIED = "E_PERM_DENIED"
E_UPDATE_BUSY = "E_UPDATE_BUSY"
E_UPDATE_ROLLBACK = "E_UPDATE_ROLLBACK"
E_CFG_CORRUPT = "E_CFG_CORRUPT"


ERROR_MESSAGES = {
    E_LIC_INVALID: "Your license couldn’t be validated.",
    E_LIC_OFFLINE: "License server unreachable (grace period may apply).",
    E_BIN_MISSING: "Expected runtime binary not found.",
    E_SIG_FAIL: "Downloaded file failed integrity verification.",
    E_NET_FAIL: "Network error while contacting a remote service.",
    E_PERM_DENIED: "Insufficient permissions to complete the operation.",
    E_UPDATE_BUSY: "Update is already in progress.",
    E_UPDATE_ROLLBACK: "The new binary failed to start; rolled back to previous version.",
    E_CFG_CORRUPT: "Configuration or state file is malformed.",
}


@dataclass
class BranchPyError(Exception):
    code: str
    detail: Optional[str] = None
    context: Optional[dict] = None

    def __str__(self) -> str:
        base = ERROR_MESSAGES.get(self.code, self.code)
        if self.detail:
            base += f" Detail: {self.detail}"
        return base

    def to_user_block(self, version: str, platform: str, log_path: str) -> str:
        lines = [
            ERROR_MESSAGES.get(self.code, self.code),
            "",
            "Copy this block if you need support:",
            f"CODE: {self.code}",
            f"VERSION: {version}",
            f"PLATFORM: {platform}",
            f"LOG: {log_path}",
        ]
        if self.context:
            for k, v in self.context.items():
                lines.append(f"{k.upper()}: {v}")
        return "\n".join(lines)
