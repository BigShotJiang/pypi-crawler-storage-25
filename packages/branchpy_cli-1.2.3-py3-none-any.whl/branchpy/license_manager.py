from __future__ import annotations

import json
import os
import time
import typing as t
from dataclasses import dataclass


def _home_dir() -> str:
    """
    Cross-platform home directory resolution.
    Priority: USERPROFILE (Windows) → HOME (POSIX) → expanduser fallback.
    """
    # Windows first
    userprofile = os.environ.get("USERPROFILE")
    if userprofile:
        return userprofile
    # POSIX
    home = os.environ.get("HOME")
    if home:
        return home
    # Last resort
    return os.path.expanduser("~")


def _get_license_dir() -> str:
    """Get license directory (cached at module level but recalculated for tests)."""
    return os.path.join(_home_dir(), ".branchpy")


def _get_license_path() -> str:
    """Get license file path (recalculated on each call for test flexibility)."""
    return os.path.join(
        os.environ.get("BRANCHPY_LICENSE_PATH", _get_license_dir()),
        "license.json",
    )


# Backward compatibility: deprecated constant (use _get_license_path() instead)
# Note: This is evaluated once at import time, so won't reflect env changes
LICENSE_PATH = _get_license_path()


@dataclass(frozen=True)
class LicenseInfo:
    tier: t.Literal["Free", "Pro", "Team"] = "Free"
    key: t.Optional[str] = None
    email: t.Optional[str] = None
    issued_at: t.Optional[int] = None  # epoch seconds
    expires_at: t.Optional[int] = None  # optional; None = perpetual
    offline_until: t.Optional[int] = None  # grace window end (epoch)
    source: t.Literal["local", "remote", "default"] = "default"

    @property
    def is_active(self) -> bool:
        if self.tier in ("Pro", "Team"):
            if self.expires_at and time.time() > self.expires_at:
                return False
            return True
        return False


def ensure_dir() -> None:
    os.makedirs(os.path.dirname(_get_license_path()), exist_ok=True)


def mask_key(k: str | None) -> str:
    """Mask license key for safe display (shows first 7 chars)."""
    return (k[:7] + "…") if k else "—"


def load_local() -> LicenseInfo:
    try:
        with open(_get_license_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return LicenseInfo(**data, source="local")  # type: ignore[arg-type]
    except FileNotFoundError:
        return LicenseInfo()
    except Exception:
        return LicenseInfo()


def save_local(info: LicenseInfo) -> None:
    ensure_dir()
    with open(_get_license_path(), "w", encoding="utf-8") as f:
        json.dump(
            {
                "tier": info.tier,
                "key": info.key,
                "email": info.email,
                "issued_at": info.issued_at,
                "expires_at": info.expires_at,
                "offline_until": info.offline_until,
            },
            f,
            indent=2,
        )


# --- simple key "validation" placeholder (upgrade to remote later) ---
def validate_key_format(key: str) -> bool:
    # e.g., BRP-XXXX-XXXX-XXXX where X in [A-Z0-9]
    import re

    return bool(re.fullmatch(r"BRP-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}", key))


def activate_offline(key: str, email: str | None = None) -> LicenseInfo:
    if not validate_key_format(key):
        raise ValueError("Invalid license key format.")
    now = int(time.time())
    # Grace period in days (default 30, override via env)
    grace_days = int(os.environ.get("BRANCHPY_OFFLINE_GRACE_DAYS", "30"))
    grace_seconds = grace_days * 24 * 3600
    # expires_at None = perpetual key placeholder
    info = LicenseInfo(
        tier="Pro",
        key=key,
        email=email,
        issued_at=now,
        offline_until=now + grace_seconds,
        source="local",
    )
    save_local(info)
    return info


def status() -> LicenseInfo:
    return load_local()
