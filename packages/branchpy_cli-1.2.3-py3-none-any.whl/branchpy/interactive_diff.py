# branchpy/interactive_diff.py

"""
Interactive Diff — Phase 2 Workstream B

Computes diffs between two refs enriched with test failures and coverage deltas.
Integrates with History Lanes and Compare views in VS Code.

BQS Compliance:
- Type hints (mypy-compliant)
- Docstrings for all public functions
- Engine-agnostic design
- Cross-platform path handling
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from .interactive_diff_adapter import (
    CoverageDeltaMap,
    FailedTest,
    build_coverage_deltas_from_report,
    build_failed_tests_from_json_report,
    build_interactive_diff_output,
)


def _compute_core_diff(ref_from: str, ref_to: str) -> Dict[str, Any]:
    """
    Compute base diff payload (files, hunks, etc.).

    Uses git diff to get file-level changes between refs.
    Full implementation will integrate with history diff engine.

    Args:
        ref_from: Source ref (branch, commit, checkpoint)
        ref_to: Target ref

    Returns:
        Base diff dictionary with files/hunks
    """
    import subprocess

    try:
        # Run git diff --name-status to get file changes
        result = subprocess.run(
            ["git", "diff", f"{ref_from}..{ref_to}", "--name-status"],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )

        files: List[Dict[str, str]] = []
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            parts = line.split("\t", 1)
            if len(parts) == 2:
                status, path = parts
                files.append(
                    {
                        "status": status,
                        "path": path,
                    }
                )

        return {
            "from_ref": ref_from,
            "to_ref": ref_to,
            "files": files,
            "hunks": [],  # TODO: Parse hunks from git diff -p
        }
    except (
        subprocess.TimeoutExpired,
        subprocess.CalledProcessError,
        FileNotFoundError,
    ):
        # Fallback if git not available or refs invalid
        return {
            "from_ref": ref_from,
            "to_ref": ref_to,
            "files": [],
            "hunks": [],
        }


def interactive_diff(
    ref_from: str,
    ref_to: str,
    *,
    tests_json_path: Optional[str] = None,
    lane_id: Optional[str] = None,
    coverage_json_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Compute an interactive diff between two refs, enriched with
    test failures and coverage deltas when available.

    Args:
        ref_from: Source ref (branch, commit, checkpoint)
        ref_to: Target ref
        tests_json_path: Optional path to pytest JSON test results
        lane_id: Optional History Lane ID to associate failures with
        coverage_json_path: Optional path to coverage.py JSON report

    Returns:
        Complete interactive_diff payload including:
        - Base diff (files, hunks)
        - failed_tests (if tests_json_path provided)
        - coverage_deltas (if coverage_json_path provided)

    Example:
        >>> result = interactive_diff(
        ...     "main",
        ...     "feature/auth",
        ...     tests_json_path="test_results.json",
        ...     lane_id="feature-auth"
        ... )
        >>> assert "failed_tests" in result
    """
    # 1) Run your existing core diff logic to get the base payload.
    base_payload: Dict[str, Any] = _compute_core_diff(ref_from, ref_to)

    # 2) Build failed_tests
    failed_tests: List[FailedTest] = []
    if tests_json_path:
        test_path = Path(tests_json_path)
        if test_path.exists():
            with open(test_path, "r", encoding="utf-8") as f:
                tests_report = json.load(f)
            json_tests = tests_report.get("tests") or tests_report.get("results") or []
            if not isinstance(json_tests, list):
                json_tests = []
            failed_tests = build_failed_tests_from_json_report(
                json_tests=json_tests,
                lane_id=lane_id,
                ref=ref_to,
            )

    # 3) Build coverage_deltas
    coverage_deltas: CoverageDeltaMap = {}
    if coverage_json_path:
        cov_path = Path(coverage_json_path)
        if cov_path.exists():
            with open(cov_path, "r", encoding="utf-8") as f:
                coverage_report = json.load(f)
            coverage_deltas = build_coverage_deltas_from_report(coverage_report)

    # 4) Merge adapter output
    adapter_fragment = build_interactive_diff_output(
        failed_tests=failed_tests,
        coverage_deltas=coverage_deltas,
    )
    base_payload.update(adapter_fragment)

    return base_payload
