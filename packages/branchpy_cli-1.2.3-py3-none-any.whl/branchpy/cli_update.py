# branchpy/cli_update.py
import argparse

from .bootstrap import current_binary
from .errors import BPError, format_user_message
from .update_manager import check_and_stage_if_needed


def add_update_subparser(sub: argparse._SubParsersAction):
    p = sub.add_parser("update", help="Check or apply updates")
    p.add_argument("--check", action="store_true", help="Check for update now")
    p.add_argument("--apply", action="store_true", help="Download+stage update")
    p.add_argument("--channel", choices=["stable", "beta", "nightly"])
    p.add_argument("--no-verify", action="store_true")
    p.set_defaults(func=run)


def run(args, version: str, platform: str, log_path: str):
    from .config_store import load

    cfg = load()
    if args.channel:
        cfg.update["channel"] = args.channel
        cfg.save()
        print(f"Update channel set to: {args.channel}")

    try:
        if args.check or args.apply:
            res = check_and_stage_if_needed(
                local_version=version,
                current_bin=current_binary(),
                verify=not args.no_verify,
            )
            if res.get("update_available"):
                print(f"Update {res['version']} staged → will swap on next run.")
            else:
                print("No update available.")
        else:
            print("Use --check or --apply.")
    except BPError as e:
        print(format_user_message(e, version, platform, log_path))
        raise SystemExit(1)
