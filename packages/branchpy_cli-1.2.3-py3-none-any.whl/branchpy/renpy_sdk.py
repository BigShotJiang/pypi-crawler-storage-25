# branchpy/renpy_sdk.py
"""
Ren'Py SDK management and multi-version support.
Handles detection, validation, and execution across multiple Ren'Py SDKs.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple


@dataclass
class RenpySdk:
    """Represents a Ren'Py SDK installation."""

    name: str  # User-friendly name (e.g., "8.2.2", "nightly")
    path: str  # Absolute path to SDK root
    version: Optional[str] = None  # Detected version (e.g., "8.2.2.24020801")
    valid: bool = True  # Whether SDK is accessible and functional
    launcher_path: Optional[str] = None  # Path to launcher executable
    python_path: Optional[str] = None  # Path to renpy.py


class RenpyRunner:
    """Manages execution of Ren'Py SDKs with project context."""

    def __init__(self, sdk: RenpySdk):
        self.sdk = sdk
        self._validate_sdk()

    def _validate_sdk(self) -> bool:
        """Validate that the SDK is functional."""
        if not os.path.exists(self.sdk.path):
            self.sdk.valid = False
            return False

        # Find renpy.py or equivalent entry point
        sdk_path = Path(self.sdk.path)
        renpy_py = sdk_path / "renpy.py"

        if renpy_py.exists():
            self.sdk.python_path = str(renpy_py)
        else:
            # Look for alternative entry points
            for candidate in ["renpy", "launcher.py"]:
                alt_path = sdk_path / candidate
                if alt_path.exists():
                    self.sdk.python_path = str(alt_path)
                    break

        if not self.sdk.python_path:
            self.sdk.valid = False
            return False

        # Find launcher executable (for GUI operations)
        if platform.system() == "Windows":
            launcher_exe = sdk_path / "launcher.exe"
            if launcher_exe.exists():
                self.sdk.launcher_path = str(launcher_exe)
        else:
            # On Unix-like systems, launcher might be a script
            launcher_script = sdk_path / "launcher"
            if launcher_script.exists():
                self.sdk.launcher_path = str(launcher_script)

        self.sdk.valid = True
        return True

    def get_version(self) -> Optional[str]:
        """Get the version of this Ren'Py SDK."""
        if self.sdk.version:
            return self.sdk.version

        if not self.sdk.valid or not self.sdk.python_path:
            return None

        try:
            # Try to get version via renpy.py --version
            result = subprocess.run(
                [sys.executable, self.sdk.python_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
                cwd=self.sdk.path,
            )

            if result.returncode == 0 and result.stdout:
                # Parse version from output
                version_match = re.search(
                    r"Ren'Py\s+(\d+\.\d+\.\d+(?:\.\d+)?)", result.stdout
                )
                if version_match:
                    self.sdk.version = version_match.group(1)
                    return self.sdk.version

            # Alternative: try to read VERSION.txt or similar
            version_files = ["VERSION.txt", "VERSION", "version.txt"]
            for version_file in version_files:
                version_path = Path(self.sdk.path) / version_file
                if version_path.exists():
                    try:
                        version_content = version_path.read_text().strip()
                        if version_content:
                            self.sdk.version = version_content
                            return self.sdk.version
                    except Exception:
                        continue

        except Exception as e:
            print(f"Error getting version for {self.sdk.name}: {e}")

        return None

    def run(
        self, project_path: str, args: List[str], capture_output: bool = True
    ) -> subprocess.CompletedProcess:
        """Run a Ren'Py command with this SDK."""
        if not self.sdk.valid or not self.sdk.python_path:
            raise ValueError(f"SDK {self.sdk.name} is not valid or accessible")

        cmd = [sys.executable, self.sdk.python_path] + args

        # Set environment to avoid GUI popups
        env = os.environ.copy()
        env["RENPY_HEADLESS"] = "1"

        return subprocess.run(
            cmd, cwd=project_path, capture_output=capture_output, text=True, env=env
        )

    def validate_project(self, project_path: str) -> Tuple[bool, str]:
        """Validate that this SDK can work with the given project."""
        project_dir = Path(project_path)

        # Look for Ren'Py project indicators
        indicators = ["options.rpy", "script.rpy", "gui.rpy"]
        has_indicator = any(
            (project_dir / indicator).exists() for indicator in indicators
        )

        if not has_indicator:
            return False, "No Ren'Py project files found"

        try:
            # Try a basic lint check
            result = self.run(project_path, ["--lint"], capture_output=True)
            if result.returncode == 0:
                return True, "Project compatible"
            else:
                return False, f"Lint failed: {result.stderr}"
        except Exception as e:
            return False, f"Validation error: {e}"


class RenpySdkManager:
    """Manages multiple Ren'Py SDK installations."""

    def __init__(self, cache_dir: Optional[str] = None):
        self.cache_dir = (
            Path(cache_dir) if cache_dir else Path.home() / ".branchpy" / "cache"
        )
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_file = self.cache_dir / "renpy_sdks.json"
        self._sdks: Dict[str, RenpySdk] = {}
        self._load_cache()

    def _load_cache(self):
        """Load cached SDK information."""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, "r") as f:
                    cache_data = json.load(f)

                for name, data in cache_data.get("sdks", {}).items():
                    sdk = RenpySdk(
                        name=name,
                        path=data["path"],
                        version=data.get("version"),
                        valid=data.get("valid", True),
                    )
                    self._sdks[name] = sdk
            except Exception as e:
                print(f"Warning: Could not load SDK cache: {e}")

    def _save_cache(self):
        """Save SDK information to cache."""
        try:
            cache_data = {
                "sdks": {
                    name: {"path": sdk.path, "version": sdk.version, "valid": sdk.valid}
                    for name, sdk in self._sdks.items()
                }
            }

            with open(self.cache_file, "w") as f:
                json.dump(cache_data, f, indent=2)
        except Exception as e:
            print(f"Warning: Could not save SDK cache: {e}")

    def detect_sdks(self, search_paths: Optional[List[str]] = None) -> List[RenpySdk]:
        """Detect Ren'Py SDKs on the system."""
        found_sdks = []

        if search_paths is None:
            search_paths = self._get_default_search_paths()

        for search_path in search_paths:
            found_sdks.extend(self._scan_directory(search_path))

        # Also scan PATH
        found_sdks.extend(self._scan_path())

        # Validate and deduplicate
        validated_sdks = []
        seen_paths = set()

        for sdk in found_sdks:
            if sdk.path not in seen_paths:
                runner = RenpyRunner(sdk)
                if runner.sdk.valid:
                    runner.get_version()  # Populate version
                    validated_sdks.append(runner.sdk)
                    seen_paths.add(sdk.path)

        return validated_sdks

    def _get_default_search_paths(self) -> List[str]:
        """Get default search paths based on the operating system."""
        paths = []

        if platform.system() == "Windows":
            # Common Windows installation paths
            paths.extend(
                [
                    "C:/Ren'Py",
                    "C:/renpy",
                    "C:/Program Files/Ren'Py",
                    "C:/Program Files (x86)/Ren'Py",
                    os.path.expanduser("~/Ren'Py"),
                    os.path.expanduser("~/renpy"),
                    os.path.expanduser("~/AppData/Local/Ren'Py"),
                    os.path.expanduser("~/Downloads"),
                    "D:/Ren'Py",
                    "D:/renpy",
                ]
            )
        elif platform.system() == "Darwin":  # macOS
            paths.extend(
                [
                    "/Applications",
                    os.path.expanduser("~/Applications"),
                    os.path.expanduser("~/renpy"),
                    os.path.expanduser("~/Ren'Py"),
                    os.path.expanduser("~/Downloads"),
                    "/usr/local/renpy",
                    "/opt/renpy",
                ]
            )
        else:  # Linux and other Unix-like
            paths.extend(
                [
                    "/usr/local/renpy",
                    "/opt/renpy",
                    os.path.expanduser("~/renpy"),
                    os.path.expanduser("~/Ren'Py"),
                    os.path.expanduser("~/.local/share/renpy"),
                    os.path.expanduser("~/Downloads"),
                    "/usr/share/renpy",
                ]
            )

        return [p for p in paths if os.path.exists(p)]

    def _scan_directory(self, search_path: str) -> List[RenpySdk]:
        """Scan a directory for Ren'Py installations."""
        found_sdks = []
        search_dir = Path(search_path)

        if not search_dir.exists():
            return found_sdks

        # Look for direct SDK installations
        for item in search_dir.iterdir():
            if item.is_dir():
                # Check if this looks like a Ren'Py SDK
                if self._is_renpy_sdk(item):
                    name = self._generate_sdk_name(item)
                    sdk = RenpySdk(name=name, path=str(item))
                    found_sdks.append(sdk)

        return found_sdks

    def _scan_path(self) -> List[RenpySdk]:
        """Scan PATH for Ren'Py installations."""
        found_sdks = []

        # Look for renpy command in PATH
        renpy_path = shutil.which("renpy")
        if renpy_path:
            # Try to find the SDK root
            renpy_file = Path(renpy_path)
            potential_root = renpy_file.parent

            if self._is_renpy_sdk(potential_root):
                name = f"PATH ({potential_root.name})"
                sdk = RenpySdk(name=name, path=str(potential_root))
                found_sdks.append(sdk)

        return found_sdks

    def _is_renpy_sdk(self, path: Path) -> bool:
        """Check if a directory contains a Ren'Py SDK."""
        # Look for key SDK files
        indicators = [
            "renpy.py",
            "launcher.py",
            "launcher.exe",
            "renpy/__init__.py",
            "launcher",
        ]

        return any((path / indicator).exists() for indicator in indicators)

    def _generate_sdk_name(self, sdk_path: Path) -> str:
        """Generate a user-friendly name for an SDK."""
        dir_name = sdk_path.name.lower()

        # Extract version from directory name
        version_match = re.search(r"(\d+\.\d+(?:\.\d+)?(?:\.\d+)?)", dir_name)
        if version_match:
            return version_match.group(1)

        # Check for common patterns
        if "nightly" in dir_name or "night" in dir_name:
            return "nightly"
        elif "dev" in dir_name or "development" in dir_name:
            return "dev"
        elif "beta" in dir_name:
            return "beta"
        elif "alpha" in dir_name:
            return "alpha"

        # Fallback to directory name
        return sdk_path.name

    def add_sdk(self, name: str, path: str) -> bool:
        """Add an SDK to the registry."""
        if not os.path.exists(path):
            return False

        sdk = RenpySdk(name=name, path=path)
        runner = RenpyRunner(sdk)

        if runner.sdk.valid:
            runner.get_version()  # Populate version
            self._sdks[name] = runner.sdk
            self._save_cache()
            return True

        return False

    def remove_sdk(self, name: str) -> bool:
        """Remove an SDK from the registry."""
        if name in self._sdks:
            del self._sdks[name]
            self._save_cache()
            return True
        return False

    def get_sdk(self, name: str) -> Optional[RenpySdk]:
        """Get an SDK by name."""
        return self._sdks.get(name)

    def list_sdks(self) -> Dict[str, RenpySdk]:
        """Get all registered SDKs."""
        return self._sdks.copy()

    def get_runner(self, name: str) -> Optional[RenpyRunner]:
        """Get a runner for the specified SDK."""
        sdk = self.get_sdk(name)
        if sdk:
            return RenpyRunner(sdk)
        return None

    def refresh_sdk(self, name: str) -> bool:
        """Refresh SDK information (re-validate and get version)."""
        sdk = self.get_sdk(name)
        if sdk:
            runner = RenpyRunner(sdk)
            if runner.sdk.valid:
                runner.get_version()
                self._sdks[name] = runner.sdk
                self._save_cache()
                return True
        return False


def get_project_sdk(project_path: str, config=None) -> Optional[str]:
    """Get the SDK that should be used for a project."""
    from .project_config import load_project_config

    if config is None:
        config = load_project_config(project_path)

    # Check for project-specific pin first
    if config.renpy_project_pin:
        return config.renpy_project_pin

    # Fall back to default
    return config.renpy_default


def validate_sdk_config(config) -> List[str]:
    """Validate SDK configuration and return list of issues."""
    issues = []
    manager = RenpySdkManager()

    # Check if default SDK exists
    if config.renpy_default:
        default_sdk = manager.get_sdk(config.renpy_default)
        if not default_sdk:
            issues.append(f"Default SDK '{config.renpy_default}' not found")
        elif not default_sdk.valid:
            issues.append(f"Default SDK '{config.renpy_default}' is invalid")

    # Check project pin
    if config.renpy_project_pin:
        project_sdk = manager.get_sdk(config.renpy_project_pin)
        if not project_sdk:
            issues.append(f"Project SDK '{config.renpy_project_pin}' not found")
        elif not project_sdk.valid:
            issues.append(f"Project SDK '{config.renpy_project_pin}' is invalid")

    # Check registered SDKs
    for name, path in config.renpy_sdks.items():
        if not os.path.exists(path):
            issues.append(f"SDK '{name}' path does not exist: {path}")

    return issues
