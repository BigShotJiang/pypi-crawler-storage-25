"""
Performance Benchmark Suite

Comprehensive benchmarks for BranchPy v1.0.0 RC performance validation.

Benchmarks:
- AST parsing (with/without cache)
- CFG construction
- Semantic analysis
- QuickFix operations

Author: BranchPy Team
Date: 2025-11-26
"""

import json
import statistics
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, List

# Import components to benchmark
try:
    from branchpy.quickfix.extract_variable import get_extract_operation
    from branchpy.quickfix.inline_variable import get_inline_operation
    from branchpy.semantics.ast.ast_cache_manager import get_cache_manager
    from branchpy.semantics.ast.parser import RenpyASTParser
    from branchpy.semantics.cfg.builder import CFGBuilder
except ImportError:
    print("Warning: Some modules not available for benchmarking")


@dataclass
class BenchmarkResult:
    """Single benchmark result."""

    name: str
    iterations: int
    times_ms: List[float]
    mean_ms: float
    median_ms: float
    p95_ms: float
    p99_ms: float
    min_ms: float
    max_ms: float
    std_dev_ms: float


@dataclass
class ComparisonResult:
    """Comparison between baseline and current."""

    benchmark: str
    baseline_ms: float
    current_ms: float
    improvement_pct: float
    status: str  # 'improved', 'degraded', 'stable'


class BenchmarkSuite:
    """
    Comprehensive performance benchmark suite.

    Runs multiple iterations of each benchmark and computes statistics.
    """

    def __init__(self, iterations: int = 100):
        self.iterations = iterations
        self.results: List[BenchmarkResult] = []

    def run_all(self, test_files: List[str]) -> List[BenchmarkResult]:
        """
        Run all benchmarks.

        Args:
            test_files: List of test file paths to use

        Returns:
            List of benchmark results
        """
        print("Running BranchPy Performance Benchmarks...")
        print(f"Iterations per benchmark: {self.iterations}")
        print("-" * 60)

        # AST Parsing benchmarks
        self._run_benchmark(
            "AST Parse (No Cache)",
            lambda: self._bench_ast_parse_no_cache(test_files[0]),
        )

        self._run_benchmark(
            "AST Parse (Cold Cache)",
            lambda: self._bench_ast_parse_cold_cache(test_files[0]),
        )

        self._run_benchmark(
            "AST Parse (Warm Cache)",
            lambda: self._bench_ast_parse_warm_cache(test_files[0]),
        )

        # QuickFix Operations (if available)
        try:
            self._run_benchmark(
                "QuickFix: Inline Variable (Analyze)",
                lambda: self._bench_inline_variable_analyze(test_files[0]),
            )

            self._run_benchmark(
                "QuickFix: Extract Variable (Analyze)",
                lambda: self._bench_extract_variable_analyze(test_files[0]),
            )
        except NameError:
            print("  Skipping QuickFix benchmarks (modules not available)")

        print("\n" + "=" * 60)
        print("Benchmarks Complete!")

        return self.results

    def _run_benchmark(self, name: str, func: Callable):
        """Run a single benchmark multiple times and collect statistics."""
        print(f"\nRunning: {name}")

        times_ms = []
        for i in range(self.iterations):
            start = time.perf_counter()
            func()
            end = time.perf_counter()
            times_ms.append((end - start) * 1000)

            if (i + 1) % 10 == 0:
                print(f"  Progress: {i + 1}/{self.iterations}", end="\r")

        # Compute statistics
        result = BenchmarkResult(
            name=name,
            iterations=self.iterations,
            times_ms=times_ms,
            mean_ms=statistics.mean(times_ms),
            median_ms=statistics.median(times_ms),
            p95_ms=self._percentile(times_ms, 0.95),
            p99_ms=self._percentile(times_ms, 0.99),
            min_ms=min(times_ms),
            max_ms=max(times_ms),
            std_dev_ms=statistics.stdev(times_ms) if len(times_ms) > 1 else 0.0,
        )

        self.results.append(result)

        print(
            f"  Mean: {result.mean_ms:.2f}ms | "
            f"Median: {result.median_ms:.2f}ms | "
            f"P95: {result.p95_ms:.2f}ms"
        )

    def _percentile(self, data: List[float], percentile: float) -> float:
        """Calculate percentile of data."""
        sorted_data = sorted(data)
        index = int(len(sorted_data) * percentile)
        return sorted_data[min(index, len(sorted_data) - 1)]

    # Benchmark implementations

    def _bench_ast_parse_no_cache(self, file_path: str):
        """Benchmark AST parsing without cache."""
        parser = RenpyASTParser(use_cache=False)
        parser.parse_file(file_path)

    def _bench_ast_parse_cold_cache(self, file_path: str):
        """Benchmark AST parsing with cold cache (first access)."""
        cache_mgr = get_cache_manager()
        cache_mgr.invalidate_all()
        parser = RenpyASTParser(use_cache=True)
        parser.parse_file(file_path)

    def _bench_ast_parse_warm_cache(self, file_path: str):
        """Benchmark AST parsing with warm cache (cache hit)."""
        # Prime the cache
        cache_mgr = get_cache_manager()
        cache_mgr.invalidate_all()
        parser = RenpyASTParser(use_cache=True)
        parser.parse_file(file_path)

        # Now benchmark cache hit
        parser.parse_file(file_path)

    def _bench_cfg_build(self, file_path: str):
        """Benchmark CFG construction."""
        parser = RenpyASTParser()
        nodes = parser.parse_file(file_path)

        builder = CFGBuilder()
        builder.build_cfg(nodes)

    def _bench_semantic_analysis(self, file_paths: List[str]):
        """Benchmark semantic analysis (placeholder - uses parsing as proxy)."""
        parser = RenpyASTParser()
        for file_path in file_paths:
            parser.parse_file(file_path)

    def _bench_inline_variable_analyze(self, file_path: str):
        """Benchmark inline variable analysis."""
        operation = get_inline_operation()
        operation.analyze(file_path, 10, "test_var")

    def _bench_extract_variable_analyze(self, file_path: str):
        """Benchmark extract variable analysis."""
        operation = get_extract_operation()
        operation.analyze(file_path, 10, 15, 35)

    def export_results(self, output_path: str):
        """Export results to JSON file."""
        data = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "iterations": self.iterations,
            "results": [asdict(r) for r in self.results],
        }

        Path(output_path).write_text(json.dumps(data, indent=2), encoding="utf-8")
        print(f"\nResults exported to: {output_path}")

    def compare_with_baseline(self, baseline_path: str) -> List[ComparisonResult]:
        """
        Compare current results with baseline.

        Args:
            baseline_path: Path to baseline results JSON

        Returns:
            List of comparison results
        """
        baseline_data = json.loads(Path(baseline_path).read_text(encoding="utf-8"))
        baseline_results = {r["name"]: r for r in baseline_data["results"]}

        comparisons = []
        for result in self.results:
            if result.name in baseline_results:
                baseline_mean = baseline_results[result.name]["mean_ms"]
                improvement = ((baseline_mean - result.mean_ms) / baseline_mean) * 100

                status = (
                    "improved"
                    if improvement > 5
                    else "degraded" if improvement < -5 else "stable"
                )

                comparisons.append(
                    ComparisonResult(
                        benchmark=result.name,
                        baseline_ms=baseline_mean,
                        current_ms=result.mean_ms,
                        improvement_pct=improvement,
                        status=status,
                    )
                )

        return comparisons

    def display_comparison(self, comparisons: List[ComparisonResult]):
        """Display comparison results in a formatted table."""
        print("\n" + "=" * 80)
        print("Performance Comparison vs. Baseline")
        print("=" * 80)
        print(
            f"{'Benchmark':<40} {'Baseline':<12} {'Current':<12} {'Change':<12} {'Status'}"
        )
        print("-" * 80)

        for comp in comparisons:
            status_icon = {"improved": "✓", "degraded": "✗", "stable": "="}.get(
                comp.status, "?"
            )

            change_str = f"{comp.improvement_pct:+.1f}%"
            print(
                f"{comp.benchmark:<40} "
                f"{comp.baseline_ms:>8.2f}ms   "
                f"{comp.current_ms:>8.2f}ms   "
                f"{change_str:>10}   "
                f"{status_icon} {comp.status}"
            )


def main():
    """Run benchmarks from command line."""
    import argparse

    parser = argparse.ArgumentParser(description="Run BranchPy performance benchmarks")
    parser.add_argument(
        "--iterations",
        "-n",
        type=int,
        default=100,
        help="Number of iterations per benchmark (default: 100)",
    )
    parser.add_argument(
        "--test-files",
        nargs="+",
        required=True,
        help="Test files to use for benchmarks",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="benchmark-results.json",
        help="Output file for results (default: benchmark-results.json)",
    )
    parser.add_argument("--baseline", "-b", help="Baseline results file for comparison")

    args = parser.parse_args()

    # Run benchmarks
    suite = BenchmarkSuite(iterations=args.iterations)
    results = suite.run_all(args.test_files)

    # Export results
    suite.export_results(args.output)

    # Compare with baseline if provided
    if args.baseline:
        comparisons = suite.compare_with_baseline(args.baseline)
        suite.display_comparison(comparisons)


if __name__ == "__main__":
    main()
