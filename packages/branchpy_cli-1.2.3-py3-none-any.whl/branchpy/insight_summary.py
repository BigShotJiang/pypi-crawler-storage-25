"""
branchpy/insight_summary.py

Build and persist a normalized InsightSummary from a single analysis run.

InsightSummary is the *only* stable contract that the future BIS/history
layer will consume.  It must never be bypassed by going back to raw
artifact files.

Spec: docs/Current Version/Analysis/INSIGHT_SUMMARY_SPEC.md
Schema version: 1.0.0
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from branchpy.run_context import RunContext

SCHEMA_VERSION = "1.0.0"
ARTIFACT_FILENAME = "insight_summary.json"


# ── Domain extractors ─────────────────────────────────────────────────────────


def _int_or_none(value: Any) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _extract_runtime_metadata(run_ctx: "RunContext") -> Dict[str, Any]:
    return run_ctx.to_dict()


def _extract_story_health(unified: Dict[str, Any]) -> Dict[str, Any]:
    """Extract from unified_report.json.

    Keypath priority:
      total_labels  — label_stats.label_count → len(label_data) → collapsed_graph node count
      total_files   — label_stats.file_count
      issue counts  — validation_data[].kind / .severity
    """
    label_stats = unified.get("label_stats") or {}
    label_data = unified.get("label_data") or {}
    collapsed_graph = unified.get("collapsed_graph") or {}

    # total_labels: try three fallback paths
    total_labels: Optional[int] = (
        _int_or_none(label_stats.get("label_count"))
        or _int_or_none(label_stats.get("total_labels"))
        or (len(label_data) if label_data else None)
        or _int_or_none(len(collapsed_graph.get("nodes", [])) or None)
    )

    total_files: Optional[int] = _int_or_none(
        label_stats.get("file_count")
    ) or _int_or_none(label_stats.get("total_files"))

    # Issue counts from validation_data
    issues = unified.get("validation_data") or []
    if not isinstance(issues, list):
        issues = []

    orphan_label_count = sum(1 for i in issues if i.get("kind") == "orphan_label")
    unreachable_count = sum(1 for i in issues if i.get("kind") == "unreachable_label")
    unresolved_jump_count = sum(1 for i in issues if i.get("kind") == "missing_jump")
    total_issue_count = len(issues)
    error_count = sum(
        1 for i in issues if str(i.get("severity", "")).lower() == "error"
    )
    warning_count = sum(
        1 for i in issues if str(i.get("severity", "")).lower() == "warning"
    )

    return {
        "total_labels": total_labels,
        "total_files": total_files,
        "orphan_label_count": orphan_label_count,
        "unreachable_label_count": unreachable_count,
        "unresolved_jump_count": unresolved_jump_count,
        "total_issue_count": total_issue_count,
        "error_count": error_count,
        "warning_count": warning_count,
    }


def _extract_complexity(stats2: Dict[str, Any]) -> Dict[str, Any]:
    """Extract from stats2.json (Pilot output)."""
    summary = stats2.get("summary") or {}
    meta = stats2.get("meta") or {}

    # total_variables: try summary first, then meta
    total_variables = _int_or_none(summary.get("total_variables")) or _int_or_none(
        meta.get("variableCount")
    )

    # total_paths_with_variables: try summary first, then meta
    total_paths_with_variables = _int_or_none(
        summary.get("total_paths")
    ) or _int_or_none(meta.get("pathCount"))

    return {
        "paths_enumerated": _int_or_none(summary.get("paths_enumerated")),
        "cfg_nodes": _int_or_none(summary.get("cfg_nodes")),
        "cfg_edges": _int_or_none(summary.get("cfg_edges")),
        "total_variables": total_variables,
        "total_paths_with_variables": total_paths_with_variables,
    }


def _extract_variable_health(stats2: Dict[str, Any]) -> Dict[str, Any]:
    """Extract from stats2.json warnings block."""
    warnings = stats2.get("warnings") or {}

    high_variance = warnings.get("highVariance") or []
    type_incons = warnings.get("typeInconsistencies") or []
    potentially_unused = warnings.get("potentiallyUnused") or []

    return {
        "high_variance_count": (
            len(high_variance) if isinstance(high_variance, list) else None
        ),
        "type_inconsistency_count": (
            len(type_incons) if isinstance(type_incons, list) else None
        ),
        "potentially_unused_count": (
            len(potentially_unused) if isinstance(potentially_unused, list) else None
        ),
    }


def _extract_state_space(omega: Dict[str, Any]) -> Dict[str, Any]:
    """Extract from omega.json."""
    stats = omega.get("stats") or {}
    limits = omega.get("limits") or {}
    impossible_combos = omega.get("impossible_combo_candidates") or []

    return {
        "paths_seen": _int_or_none(stats.get("paths_seen")),
        "events_seen": _int_or_none(stats.get("events_seen")),
        "variables_seen": _int_or_none(stats.get("variables_seen")),
        "impossible_combo_count": (
            len(impossible_combos) if isinstance(impossible_combos, list) else None
        ),
        "capped": bool(limits.get("capped")) if "capped" in limits else None,
        "capped_variable_count": len(limits.get("capped_variables") or []),
    }


def _extract_assets(unified: Dict[str, Any]) -> Dict[str, Any]:
    """Extract from unified_report.json image_validation block.

    image_validation structure: {labels: {label: {images, summary}}, totals: {missing_images, ...}}
    We probe totals first, then fall back to flat candidate keys.
    """
    image_val = unified.get("image_validation")
    if not image_val or not isinstance(image_val, dict):
        return {"image_validation_present": False, "image_issues_count": None}

    issue_count: Optional[int] = None

    # Primary: totals block (produced by image-validate command)
    totals = image_val.get("totals")
    if isinstance(totals, dict):
        for k in ("missing_images", "missing", "issues", "errors"):
            v = totals.get(k)
            if isinstance(v, int):
                issue_count = v
                break

    # Fallback: flat candidate keys
    if issue_count is None:
        for candidate_key in ("issues", "errors", "missing", "warnings", "results"):
            val = image_val.get(candidate_key)
            if isinstance(val, list):
                issue_count = len(val)
                break
            if isinstance(val, int):
                issue_count = val
                break

    # Fallback: count labels dict entries that have missing > 0
    if issue_count is None:
        labels = image_val.get("labels")
        if isinstance(labels, dict):
            issue_count = len(labels)

    return {
        "image_validation_present": True,
        "image_issues_count": issue_count,
    }


def _extract_project_structure_mode(unified: Dict[str, Any]) -> Dict[str, Any]:
    """Classify the project as 'linear', 'hub', or 'mixed' from the collapsed graph."""
    from collections import Counter

    collapsed_graph = unified.get("collapsed_graph") or {}
    nodes = collapsed_graph.get("nodes") or []
    edges = collapsed_graph.get("edges") or []
    total_labels = len(nodes)
    if total_labels == 0:
        # Fall back to label_stats count when nodes list is empty
        total_labels = (
            _int_or_none((unified.get("label_stats") or {}).get("label_count")) or 0
        )

    if total_labels == 0:
        return {
            "project_structure": None,
            "structure_confidence": None,
            "structure_signals": None,
        }

    type_counts: Counter = Counter(n.get("type", "") for n in nodes)
    narrative = type_counts.get("narrative", 0)
    entry = type_counts.get("entry", 0)
    exit_n = type_counts.get("exit", 0)
    total_edges = len(edges)

    exit_ratio = exit_n / total_labels
    narrative_ratio = narrative / total_labels
    avg_out_degree = total_edges / total_labels

    hub_score = 0
    linear_score = 0
    if exit_ratio > 0.6:
        hub_score += 2
    if avg_out_degree > 1.2:  # lowered from 1.5; weight reduced from 2 → 1
        hub_score += 1
    if entry > 1:
        hub_score += 1
    if narrative_ratio < 0.2:
        hub_score += 2
    if total_edges > total_labels * 1.5:
        hub_score += 1

    if exit_ratio < 0.3:
        linear_score += 2
    if avg_out_degree < 1.3:
        linear_score += 2
    if entry == 1:
        linear_score += 2
    if narrative_ratio > 0.4:
        linear_score += 2

    if total_labels < 20:
        structure: str = "mixed"
        confidence: float = 0.3
    elif hub_score >= 5 and hub_score > linear_score + 1:
        structure = "hub"
        total_s = hub_score + linear_score
        confidence = round(hub_score / total_s, 2) if total_s else 0.5
    elif linear_score >= 5 and linear_score > hub_score + 1:
        structure = "linear"
        total_s = hub_score + linear_score
        confidence = round(linear_score / total_s, 2) if total_s else 0.5
    else:
        structure = "mixed"
        confidence = 0.5

    return {
        "project_structure": structure,
        "structure_confidence": confidence,
        "structure_signals": {
            "exit_ratio": round(exit_ratio, 3),
            "narrative_ratio": round(narrative_ratio, 3),
            "avg_out_degree": round(avg_out_degree, 3),
            "entry_count": entry,
            "total_labels": total_labels,
            "total_edges": total_edges,
            "hub_score": hub_score,
            "linear_score": linear_score,
        },
    }


# ── Public API ─────────────────────────────────────────────────────────────────


def build_insight_summary(
    run_ctx: "RunContext",
    unified_report: Optional[Dict[str, Any]],
    stats2: Optional[Dict[str, Any]],
    omega: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build a normalized InsightSummary dict from a single analysis run.

    All domain dicts are always present; individual fields within a domain
    are None when the corresponding stage was not run.

    This is the ONLY input contract for future BIS comparisons.
    Do not bypass this function by re-reading raw artifacts directly in the
    history/delta layer.
    """
    return {
        "schema_version": SCHEMA_VERSION,
        "runtime_metadata": _extract_runtime_metadata(run_ctx),
        "story_health": (
            _extract_story_health(unified_report)
            if unified_report is not None
            else _null_domain_story_health()
        ),
        "complexity": (
            _extract_complexity(stats2)
            if stats2 is not None
            else _null_domain_complexity()
        ),
        "variable_health": (
            _extract_variable_health(stats2)
            if stats2 is not None
            else _null_domain_variable_health()
        ),
        "state_space": (
            _extract_state_space(omega)
            if omega is not None
            else _null_domain_state_space()
        ),
        "assets": (
            _extract_assets(unified_report)
            if unified_report is not None
            else _null_domain_assets()
        ),
        "project_structure": (
            _extract_project_structure_mode(unified_report)
            if unified_report is not None
            else _null_domain_project_structure()
        ),
    }


def write_insight_summary(
    summary: Dict[str, Any],
    project_path: Path,
) -> Path:
    """Persist the InsightSummary as .branchpy/insights/insight_summary.json.

    (M-11) Canonical path moved from `.branchpy/` root to `.branchpy/insights/`.
    Auto-migrates any existing root-level file on first write so no data is lost.

    Returns the Path that was written.
    """
    # New canonical location
    out_dir = project_path / ".branchpy" / "insights"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / ARTIFACT_FILENAME

    # Auto-migrate: if the old root file exists and the new location does not,
    # move it so old data is preserved and no ghost artifact is left behind.
    old_path = project_path / ".branchpy" / ARTIFACT_FILENAME
    if old_path.exists() and not out_path.exists():
        try:
            old_path.rename(out_path)
        except Exception:
            # Cross-device or permission failure — copy then delete
            import shutil

            try:
                shutil.copy2(old_path, out_path)
                old_path.unlink()
            except Exception:
                pass  # migration failed non-fatally; write below will still succeed

    out_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out_path


def build_and_persist(
    run_ctx: "RunContext",
    project_path: Path,
    *,
    unified_report: Optional[Dict[str, Any]] = None,
    stats2: Optional[Dict[str, Any]] = None,
    omega: Optional[Dict[str, Any]] = None,
    read_from_disk: bool = True,
) -> tuple[Dict[str, Any], Path]:
    """Convenience: build + write in one call.

    If *read_from_disk* is True (default), automatically reads whichever
    of the three artifact files are present on disk when the corresponding
    in-memory dict is not supplied.

    Returns (summary_dict, written_path).
    """
    if read_from_disk:
        from branchpy.artifact_freshness import find_artifact_file

        if unified_report is None:
            p = find_artifact_file(project_path, "analyze")
            if p:
                try:
                    unified_report = json.loads(p.read_text(encoding="utf-8"))
                except Exception:
                    pass

        if stats2 is None:
            p = find_artifact_file(project_path, "pilot")
            if p:
                try:
                    stats2 = json.loads(p.read_text(encoding="utf-8"))
                except Exception:
                    pass

        if omega is None:
            p = find_artifact_file(project_path, "omega")
            if p:
                try:
                    omega = json.loads(p.read_text(encoding="utf-8"))
                except Exception:
                    pass

    summary = build_insight_summary(run_ctx, unified_report, stats2, omega)
    path = write_insight_summary(summary, project_path)
    return summary, path


# ── Null domain helpers (absent stage → all fields explicitly None) ────────────


def _null_domain_story_health() -> Dict[str, Any]:
    return {
        k: None
        for k in (
            "total_labels",
            "total_files",
            "orphan_label_count",
            "unreachable_label_count",
            "unresolved_jump_count",
            "total_issue_count",
            "error_count",
            "warning_count",
        )
    }


def _null_domain_complexity() -> Dict[str, Any]:
    return {
        k: None
        for k in (
            "paths_enumerated",
            "cfg_nodes",
            "cfg_edges",
            "total_variables",
            "total_paths_with_variables",
        )
    }


def _null_domain_variable_health() -> Dict[str, Any]:
    return {
        k: None
        for k in (
            "high_variance_count",
            "type_inconsistency_count",
            "potentially_unused_count",
        )
    }


def _null_domain_state_space() -> Dict[str, Any]:
    return {
        k: None
        for k in (
            "paths_seen",
            "events_seen",
            "variables_seen",
            "impossible_combo_count",
            "capped",
            "capped_variable_count",
        )
    }


def _null_domain_assets() -> Dict[str, Any]:
    return {"image_validation_present": False, "image_issues_count": None}


def _null_domain_project_structure() -> Dict[str, Any]:
    return {
        "project_structure": None,
        "structure_confidence": None,
        "structure_signals": None,
    }
