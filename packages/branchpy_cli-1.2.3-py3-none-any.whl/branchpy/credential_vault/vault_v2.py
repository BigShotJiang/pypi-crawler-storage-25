"""
CredentialVault V2 - Enhanced secure credential storage for BranchPy.

New features:
- Master password support with auto-create
- Deterministic key derivation (PBKDF2)
- Rotation support with migration path
- Better error handling and logging
- Backward compatible with legacy vault

Governance ID: AXIS5-V0.9.1.2-20251112-IMPL
Checkpoint: H2 — Credential Vault V2
Created: 2025-11-12
"""

import base64
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

logger = logging.getLogger(__name__)


class CredentialVaultV2:
    """
    Secure encrypted credential storage with master password support.

    V2 enhancements:
    - Master password-based encryption (vs. auto-generated key)
    - Key derivation using PBKDF2 with salt
    - Auto-create vaults with secure defaults
    - Credential rotation support
    - Audit logging for all operations
    """

    SCHEMA_VERSION = "2.0"
    DEFAULT_ITERATIONS = 480000  # OWASP recommendation 2023

    def __init__(
        self,
        vault_path: Optional[Path] = None,
        master_password: Optional[str] = None,
        auto_create: bool = True,
        iterations: int = DEFAULT_ITERATIONS,
    ):
        """
        Initialize credential vault.

        Args:
            vault_path: Path to vault file (default: ~/.branchpy/credentials_v2.vault)
            master_password: Master password for encryption (prompts if None and vault exists)
            auto_create: Create vault if it doesn't exist
            iterations: PBKDF2 iterations for key derivation
        """
        self.vault_path = (
            vault_path or Path.home() / ".branchpy" / "credentials_v2.vault"
        )
        self.vault_path.parent.mkdir(parents=True, exist_ok=True)

        self.iterations = iterations
        self._cipher = None
        self._salt = None

        # Check if vault exists
        vault_exists = self.vault_path.exists()

        if not vault_exists and not auto_create:
            raise ValueError(
                f"Vault not found and auto_create=False: {self.vault_path}"
            )

        if not vault_exists and auto_create:
            # Create new vault
            logger.info("Creating new credential vault")

            if master_password is None:
                # Generate secure random password
                import secrets

                master_password = base64.urlsafe_b64encode(
                    secrets.token_bytes(32)
                ).decode("utf-8")

                # Save to secure location with warning
                password_file = self.vault_path.parent / ".vault_master.key"
                password_file.write_text(master_password)
                password_file.chmod(0o600)

                logger.warning(
                    f"Generated master password saved to: {password_file}\n"
                    f"IMPORTANT: Store this password securely! It cannot be recovered if lost."
                )

            self._initialize_vault(master_password)

        else:
            # Load existing vault
            if master_password is None:
                # Try to load from file
                password_file = self.vault_path.parent / ".vault_master.key"
                if password_file.exists():
                    master_password = password_file.read_text().strip()
                else:
                    raise ValueError(
                        "Vault exists but no master password provided. "
                        "Either provide master_password or ensure .vault_master.key exists."
                    )

            self._load_vault(master_password)

        logger.info(f"CredentialVaultV2 initialized: {self.vault_path}")

    def _initialize_vault(self, master_password: str):
        """
        Initialize a new vault with master password.

        Args:
            master_password: Master password for encryption
        """
        # Generate salt
        self._salt = os.urandom(16)

        # Derive key
        key = self._derive_key(master_password, self._salt)
        self._cipher = Fernet(key)

        # Create initial vault structure
        vault_data = {
            "schema_version": self.SCHEMA_VERSION,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "salt": base64.b64encode(self._salt).decode("utf-8"),
            "iterations": self.iterations,
            "credentials": {},
        }

        self._save_vault(vault_data)

        self._emit_audit_event(
            "vault.created",
            {"schema_version": self.SCHEMA_VERSION, "iterations": self.iterations},
        )

    def _load_vault(self, master_password: str):
        """
        Load and decrypt existing vault.

        Args:
            master_password: Master password for decryption
        """
        with open(self.vault_path, "rb") as f:
            encrypted_data = f.read()

        # Extract header (first 1024 bytes for metadata)
        try:
            # Simple format: salt (base64) + "|" + encrypted_data
            parts = encrypted_data.split(b"|", 1)
            if len(parts) == 2:
                salt_b64, encrypted_payload = parts
                self._salt = base64.b64decode(salt_b64)
            else:
                # Legacy format: try to decrypt directly
                raise ValueError("Invalid vault format")

            # Derive key
            key = self._derive_key(master_password, self._salt)
            self._cipher = Fernet(key)

            # Decrypt payload
            decrypted = self._cipher.decrypt(encrypted_payload)
            vault_data = json.loads(decrypted.decode("utf-8"))

            # Validate schema
            schema_version = vault_data.get("schema_version", "1.0")
            if schema_version != self.SCHEMA_VERSION:
                logger.warning(
                    f"Schema version mismatch: vault={schema_version}, "
                    f"expected={self.SCHEMA_VERSION}"
                )

            self.iterations = vault_data.get("iterations", self.DEFAULT_ITERATIONS)

        except Exception as e:
            logger.error(f"Failed to decrypt vault: {e}")
            raise ValueError(
                "Failed to decrypt vault. Incorrect master password or corrupted vault file."
            ) from e

    def _derive_key(self, master_password: str, salt: bytes) -> bytes:
        """
        Derive encryption key from master password using PBKDF2.

        Args:
            master_password: Master password
            salt: Cryptographic salt

        Returns:
            32-byte encryption key (base64 encoded for Fernet)
        """
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(), length=32, salt=salt, iterations=self.iterations
        )
        key = base64.urlsafe_b64encode(kdf.derive(master_password.encode("utf-8")))
        return key

    def _save_vault(self, vault_data: Dict[str, Any]):
        """
        Encrypt and save vault to disk.

        Args:
            vault_data: Vault data to encrypt
        """
        # Serialize
        json_data = json.dumps(vault_data, indent=2).encode("utf-8")

        # Encrypt
        encrypted = self._cipher.encrypt(json_data)

        # Format: salt_base64 | encrypted_data
        salt_b64 = base64.b64encode(self._salt)
        output = salt_b64 + b"|" + encrypted

        # Save with secure permissions
        self.vault_path.write_bytes(output)
        self.vault_path.chmod(0o600)  # Owner read/write only

        logger.debug("Vault saved (encrypted)")

    def _load_vault_data(self) -> Dict[str, Any]:
        """Load and decrypt vault data."""
        with open(self.vault_path, "rb") as f:
            encrypted_data = f.read()

        # Split salt and payload
        parts = encrypted_data.split(b"|", 1)
        _, encrypted_payload = parts

        # Decrypt
        decrypted = self._cipher.decrypt(encrypted_payload)
        return json.loads(decrypted.decode("utf-8"))

    def set_credentials(self, provider_id: str, credentials: Dict[str, Any]):
        """
        Store credentials for provider.

        Args:
            provider_id: Provider identifier
            credentials: Credential dictionary
        """
        vault_data = self._load_vault_data()

        # Add metadata
        credentials["_stored_at"] = datetime.utcnow().isoformat() + "Z"
        credentials["_schema_version"] = self.SCHEMA_VERSION

        vault_data["credentials"][provider_id] = credentials
        self._save_vault(vault_data)

        self._emit_audit_event("credentials.stored", {"provider": provider_id})

    def get_credentials(self, provider_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve credentials for provider.

        Args:
            provider_id: Provider identifier

        Returns:
            Credentials dict or None
        """
        vault_data = self._load_vault_data()
        return vault_data["credentials"].get(provider_id)

    def delete_credentials(self, provider_id: str) -> bool:
        """
        Delete credentials for provider.

        Args:
            provider_id: Provider identifier

        Returns:
            True if deleted
        """
        vault_data = self._load_vault_data()

        if provider_id in vault_data["credentials"]:
            del vault_data["credentials"][provider_id]
            self._save_vault(vault_data)

            self._emit_audit_event("credentials.deleted", {"provider": provider_id})

            return True

        return False

    def list_providers(self) -> list:
        """List providers with stored credentials."""
        vault_data = self._load_vault_data()
        return list(vault_data["credentials"].keys())

    def has_credentials(self, provider_id: str) -> bool:
        """Check if credentials exist for provider."""
        return provider_id in self.list_providers()

    def rotate_master_password(self, old_password: str, new_password: str):
        """
        Rotate master password and re-encrypt vault.

        Args:
            old_password: Current master password
            new_password: New master password
        """
        # Verify old password by attempting to decrypt
        try:
            vault_data = self._load_vault_data()
        except Exception:
            raise ValueError("Old password incorrect")

        # Generate new salt
        new_salt = os.urandom(16)

        # Derive new key
        new_key = self._derive_key(new_password, new_salt)

        # Update vault
        self._salt = new_salt
        self._cipher = Fernet(new_key)

        vault_data["salt"] = base64.b64encode(new_salt).decode("utf-8")
        vault_data["rotated_at"] = datetime.utcnow().isoformat() + "Z"

        self._save_vault(vault_data)

        # Update password file if it exists
        password_file = self.vault_path.parent / ".vault_master.key"
        if password_file.exists():
            password_file.write_text(new_password)
            password_file.chmod(0o600)

        self._emit_audit_event("vault.password_rotated", {})

        logger.warning("Master password rotated - all credentials re-encrypted")

    def export_unencrypted(self) -> Dict[str, Any]:
        """
        Export vault in unencrypted format.

        WARNING: Returns sensitive data in plain text!

        Returns:
            Unencrypted vault data
        """
        logger.warning("Exporting unencrypted vault data (SENSITIVE!)")

        self._emit_audit_event(
            "vault.exported_unencrypted", {"warning": "sensitive_data_exported"}
        )

        return self._load_vault_data()

    def _emit_audit_event(self, event_type: str, data: Dict[str, Any]):
        """
        Emit audit event (Phase 3 telemetry integration).

        Args:
            event_type: Event type
            data: Event payload
        """
        # TODO: Integrate with telemetry dispatcher
        logger.info(
            json.dumps(
                {
                    "event": f"credentials.{event_type}",
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    **data,
                }
            )
        )
