"""
CredentialVault Migration Utility — BranchPy v0.9.1.2

Migrates legacy CredentialVault configurations (v1/v2) to unified schema v3.
Handles backward compatibility shim for master_key_path + salt_path workflow.

Governance ID: AXIS5-V0.9.1.2-20251112-IMPL
Checkpoint: H2 — Provider Expansion
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class VaultMigrationError(Exception):
    """Raised when vault migration fails."""

    pass


class CredentialVaultMigrator:
    """
    Migrates CredentialVault configurations from v1/v2 to v3.

    Migration scenarios:
    1. Legacy master_key_path + salt_path → master_password + key_derivation
    2. Update schema version to 3.0.0
    3. Validate new schema compliance
    4. Create backward compatibility shim (optional)

    Usage:
        ```python
        migrator = CredentialVaultMigrator()
        result = migrator.migrate_vault_config("config_v2.json", "config_v3.json")
        if result.success:
            print(f"Migrated successfully: {result.message}")
        ```
    """

    def __init__(self, schema_path: Optional[Path] = None):
        """
        Initialize migrator.

        Args:
            schema_path: Path to schema_v3.json for validation (optional)
        """
        self.schema_path = schema_path
        self._schema = self._load_schema() if schema_path else None

    def migrate_vault_config(
        self, source_path: Path, target_path: Path, preserve_legacy: bool = True
    ) -> "MigrationResult":
        """
        Migrate vault configuration from v1/v2 to v3.

        Args:
            source_path: Path to legacy vault config (v1 or v2)
            target_path: Path for migrated v3 config
            preserve_legacy: If True, include legacy_compatibility shim

        Returns:
            MigrationResult with success status and details
        """
        try:
            # Load legacy config
            with open(source_path, "r") as f:
                legacy_config = json.load(f)

            # Detect version
            version = self._detect_version(legacy_config)
            logger.info(f"Detected vault version: {version}")

            # Migrate based on version
            if version in ["1.0", "2.0"]:
                v3_config = self._migrate_from_v1_v2(legacy_config, preserve_legacy)
            else:
                raise VaultMigrationError(f"Unsupported vault version: {version}")

            # Validate against schema
            if self._schema:
                self._validate_schema(v3_config)

            # Write migrated config
            with open(target_path, "w") as f:
                json.dump(v3_config, f, indent=2)

            return MigrationResult(
                success=True,
                source_version=version,
                target_version="3.0.0",
                message=f"Successfully migrated from v{version} to v3.0.0",
                changes_applied=[
                    "Updated vault_version to 3.0.0",
                    "Converted master_key_path to master_password workflow",
                    "Added key_derivation configuration",
                    (
                        "Preserved legacy_compatibility shim"
                        if preserve_legacy
                        else "No legacy shim"
                    ),
                ],
            )

        except Exception as e:
            logger.error(f"Migration failed: {e}", exc_info=True)
            return MigrationResult(
                success=False,
                source_version="unknown",
                target_version="3.0.0",
                message=f"Migration failed: {str(e)}",
                error=str(e),
            )

    def create_backward_compat_shim(
        self, v3_config_path: Path, legacy_master_key_path: Path, legacy_salt_path: Path
    ) -> bool:
        """
        Create backward compatibility shim for v1/v2 integrations.

        Adds legacy_compatibility section to v3 config, allowing legacy
        code paths to continue working during transition period.

        Args:
            v3_config_path: Path to v3 vault config
            legacy_master_key_path: Path to legacy master key file
            legacy_salt_path: Path to legacy salt file

        Returns:
            True if shim created successfully
        """
        try:
            with open(v3_config_path, "r") as f:
                config = json.load(f)

            # Add legacy compatibility section
            if "encryption" not in config:
                config["encryption"] = {}

            config["encryption"]["legacy_compatibility"] = {
                "enabled": True,
                "master_key_path": str(legacy_master_key_path),
                "salt_path": str(legacy_salt_path),
            }

            with open(v3_config_path, "w") as f:
                json.dump(config, f, indent=2)

            logger.info("Backward compatibility shim created")
            return True

        except Exception as e:
            logger.error(f"Failed to create compat shim: {e}")
            return False

    def _detect_version(self, config: Dict[str, Any]) -> str:
        """
        Detect vault configuration version.

        Detection logic:
        - v3: has vault_version = "3.0.0"
        - v2: has encryption.master_key_path (but not vault_version)
        - v1: has master_key_path at root level
        """
        if config.get("vault_version") == "3.0.0":
            return "3.0.0"

        # Check for v2 structure
        if "encryption" in config and "master_key_path" in config["encryption"]:
            return "2.0"

        # Check for v1 structure
        if "master_key_path" in config:
            return "1.0"

        return "unknown"

    def _migrate_from_v1_v2(
        self, legacy_config: Dict[str, Any], preserve_legacy: bool
    ) -> Dict[str, Any]:
        """
        Migrate from v1/v2 to v3 schema.

        Key transformations:
        - Add vault_version = "3.0.0"
        - Convert master_key_path → master_password (env var reference)
        - Add key_derivation config (Argon2id defaults)
        - Move encryption config to proper nesting
        - Add legacy_compatibility if preserve_legacy=True
        """
        v3_config = {
            "vault_id": legacy_config.get("vault_id", self._generate_vault_id()),
            "vault_version": "3.0.0",
            "encryption": {
                "algorithm": legacy_config.get("algorithm", "AES-256-GCM"),
                "master_password": "${BRANCHPY_VAULT_PASSWORD}",
                "auto_create": False,  # Require explicit initialization
                "key_derivation": {
                    "function": "Argon2id",
                    "iterations": 600000,
                    "memory_cost": 65536,
                    "parallelism": 4,
                    "salt_length": 32,
                },
            },
            "providers": legacy_config.get("providers", {}),
            "vault_metadata": {
                "created_at": legacy_config.get("created_at"),
                "updated_at": legacy_config.get("updated_at"),
                "created_by": legacy_config.get("created_by"),
            },
        }

        # Add legacy compatibility shim if requested
        if preserve_legacy:
            # Extract legacy paths from v1/v2 config
            if "master_key_path" in legacy_config:
                # v1 structure
                legacy_key_path = legacy_config["master_key_path"]
                legacy_salt_path = legacy_config.get("salt_path", "")
            elif "encryption" in legacy_config:
                # v2 structure
                legacy_key_path = legacy_config["encryption"].get("master_key_path", "")
                legacy_salt_path = legacy_config["encryption"].get("salt_path", "")
            else:
                legacy_key_path = ""
                legacy_salt_path = ""

            v3_config["encryption"]["legacy_compatibility"] = {
                "enabled": True,
                "master_key_path": legacy_key_path,
                "salt_path": legacy_salt_path,
            }

        return v3_config

    def _generate_vault_id(self) -> str:
        """Generate unique vault ID in format: vault-{uuid}."""
        import uuid

        return f"vault-{uuid.uuid4()}"

    def _load_schema(self) -> Dict[str, Any]:
        """Load v3 JSON schema for validation."""
        try:
            if self.schema_path is None:
                return {}
            with open(self.schema_path, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load schema: {e}")
            return {}

    def _validate_schema(self, config: Dict[str, Any]) -> None:
        """
        Validate config against v3 schema.

        Basic validation - check required fields.
        For full JSON Schema validation, use jsonschema library.
        """
        required = ["vault_id", "vault_version", "encryption"]
        for field in required:
            if field not in config:
                raise VaultMigrationError(f"Missing required field: {field}")

        if config["vault_version"] != "3.0.0":
            raise VaultMigrationError(
                f"Invalid vault_version: {config['vault_version']}"
            )

        # Validate encryption section
        enc = config["encryption"]
        if "master_password" not in enc:
            raise VaultMigrationError("Missing encryption.master_password")


class MigrationResult:
    """
    Result wrapper for vault migration operations.

    Attributes:
        success: Migration success status
        source_version: Original vault version
        target_version: Migrated vault version
        message: Human-readable result message
        changes_applied: List of transformations applied
        error: Error message if success=False
    """

    def __init__(
        self,
        success: bool,
        source_version: str,
        target_version: str,
        message: str,
        changes_applied: Optional[list] = None,
        error: Optional[str] = None,
    ):
        self.success = success
        self.source_version = source_version
        self.target_version = target_version
        self.message = message
        self.changes_applied = changes_applied or []
        self.error = error

    def __repr__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        return (
            f"<MigrationResult {status}: {self.source_version} → {self.target_version}>"
        )


def migrate_vault_cli():
    """
    CLI utility for vault migration.

    Usage:
        python -m branchpy.credential_vault.migrate config_v2.json config_v3.json
    """
    import sys

    if len(sys.argv) < 3:
        print("Usage: python -m branchpy.credential_vault.migrate <source> <target>")
        sys.exit(1)

    source = Path(sys.argv[1])
    target = Path(sys.argv[2])

    migrator = CredentialVaultMigrator()
    result = migrator.migrate_vault_config(source, target)

    if result.success:
        print(f"✅ {result.message}")
        print("\nChanges applied:")
        for change in result.changes_applied:
            print(f"  - {change}")
    else:
        print(f"❌ {result.message}")
        if result.error:
            print(f"Error: {result.error}")
        sys.exit(1)


if __name__ == "__main__":
    migrate_vault_cli()
