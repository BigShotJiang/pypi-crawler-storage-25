"""
Legacy Credential Vault Shim - Backward compatibility wrapper for V1 vault.

Provides deprecation warnings and migration path from V1 to V2.

Usage:
    ```python
    # Legacy code (V1)
    from branchpy.credential_vault import CredentialManager
    vault = CredentialManager()  # Works but emits deprecation warning

    # New code (V2)
    from branchpy.credential_vault.vault_v2 import CredentialVaultV2
    vault = CredentialVaultV2(master_password="...")
    ```

Governance ID: AXIS5-V0.9.1.2-20251112-IMPL
Checkpoint: H2 — Legacy Shim
Created: 2025-11-12
"""

import logging
import warnings
from pathlib import Path
from typing import Any, Dict, Optional

from .vault_v2 import CredentialVaultV2

logger = logging.getLogger(__name__)


class CredentialManager:
    """
    Legacy credential manager (V1 API).

    This class provides backward compatibility with the V1 vault API.
    It wraps CredentialVaultV2 and emits deprecation warnings.

    DEPRECATED: Use CredentialVaultV2 directly for new code.
    """

    def __init__(
        self, creds_path: Optional[Path] = None, master_key: Optional[str] = None
    ):
        """
        Initialize legacy credential manager.

        Args:
            creds_path: Path to credentials file (legacy format)
            master_key: Master encryption key (legacy format)

        Note:
            Emits deprecation warning on initialization.
        """
        warnings.warn(
            "CredentialManager (V1) is deprecated. "
            "Use CredentialVaultV2 for new code. "
            "See docs/v1.0.0/media-validation-v3/VAULT_V2_MIGRATION.md for migration guide.",
            DeprecationWarning,
            stacklevel=2,
        )

        logger.warning(
            "Using legacy CredentialManager (V1). "
            "Consider migrating to CredentialVaultV2."
        )

        # Map legacy args to V2
        vault_path = None
        if creds_path:
            # Convert legacy path to V2 path
            vault_path = creds_path.parent / "credentials_v2.vault"

        master_password = (
            master_key  # V2 uses 'master_password' instead of 'master_key'
        )

        # Initialize V2 vault with auto-migration
        self._vault_v2 = CredentialVaultV2(
            vault_path=vault_path, master_password=master_password, auto_create=True
        )

        # Attempt to migrate V1 data if legacy vault exists
        if creds_path and creds_path.exists():
            self._migrate_from_v1(creds_path, master_key)

    def _migrate_from_v1(self, legacy_path: Path, legacy_key: Optional[str]):
        """
        Migrate credentials from V1 vault to V2.

        Args:
            legacy_path: Path to legacy credential file
            legacy_key: Legacy encryption key
        """
        try:
            logger.info(f"Attempting V1 -> V2 migration from {legacy_path}")

            # Import legacy credential manager implementation
            from branchpy.image_validation_v3.providers_v2.credentials import (
                CredentialManager as LegacyVault,
            )

            # Load legacy vault
            legacy_vault = LegacyVault(creds_path=legacy_path, master_key=legacy_key)

            # Export all credentials
            legacy_data = legacy_vault.export_plain()

            # Import into V2
            for provider_id, credentials in legacy_data.items():
                if provider_id.startswith("_"):
                    continue  # Skip metadata

                logger.info(f"Migrating credentials for provider: {provider_id}")
                self._vault_v2.set_credentials(provider_id, credentials)

            logger.info(f"✓ Migrated {len(legacy_data)} providers from V1 to V2")

            # Optionally backup and remove legacy vault
            backup_path = legacy_path.with_suffix(".v1.backup")
            legacy_path.rename(backup_path)
            logger.info(f"Legacy vault backed up to: {backup_path}")

        except Exception as e:
            logger.error(f"V1 migration failed: {e}")
            logger.warning("Continuing with empty V2 vault")

    def set_credentials(self, provider_id: str, credentials: Dict[str, Any]):
        """Store credentials for provider (V1 API)."""
        warnings.warn(
            "Use CredentialVaultV2.set_credentials() for new code",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._vault_v2.set_credentials(provider_id, credentials)

    def get_credentials(self, provider_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve credentials for provider (V1 API)."""
        return self._vault_v2.get_credentials(provider_id)

    def delete_credentials(self, provider_id: str) -> bool:
        """Delete credentials for provider (V1 API)."""
        return self._vault_v2.delete_credentials(provider_id)

    def list_providers(self) -> list:
        """List providers with stored credentials (V1 API)."""
        return self._vault_v2.list_providers()

    def has_credentials(self, provider_id: str) -> bool:
        """Check if credentials exist (V1 API)."""
        return self._vault_v2.has_credentials(provider_id)

    def refresh_token(
        self,
        provider_id: str,
        new_token: str,
        new_refresh_token: Optional[str] = None,
        expires_in: Optional[int] = None,
    ):
        """
        Update OAuth tokens (V1 API).

        Args:
            provider_id: Provider identifier
            new_token: New access token
            new_refresh_token: New refresh token
            expires_in: Token lifetime in seconds
        """
        from datetime import datetime, timedelta

        creds = self._vault_v2.get_credentials(provider_id)
        if not creds:
            raise ValueError(f"No credentials for {provider_id}")

        creds["access_token"] = new_token
        if new_refresh_token:
            creds["refresh_token"] = new_refresh_token

        if expires_in:
            expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
            creds["expires_at"] = expires_at.isoformat() + "Z"

        creds["_refreshed_at"] = datetime.utcnow().isoformat() + "Z"

        self._vault_v2.set_credentials(provider_id, creds)
        logger.info(f"Refreshed token for {provider_id}")

    def is_token_expired(self, provider_id: str) -> bool:
        """Check if OAuth token is expired (V1 API)."""
        from datetime import datetime, timedelta

        creds = self._vault_v2.get_credentials(provider_id)
        if not creds or "expires_at" not in creds:
            return False

        try:
            expires_str = creds["expires_at"].replace("Z", "").replace("+00:00", "")
            expires_at = datetime.fromisoformat(expires_str)
            # Consider expired if less than 5 minutes remaining
            return datetime.utcnow() >= expires_at - timedelta(minutes=5)
        except Exception:
            return False

    def export_plain(self) -> Dict[str, Any]:
        """Export decrypted credentials (V1 API, SENSITIVE!)."""
        warnings.warn(
            "export_plain() returns sensitive data in plain text!",
            UserWarning,
            stacklevel=2,
        )
        return self._vault_v2.export_unencrypted()["credentials"]

    def rotate_master_key(self, new_master_key: str):
        """
        Re-encrypt with new master key (V1 API).

        Args:
            new_master_key: New master key
        """
        warnings.warn(
            "Use CredentialVaultV2.rotate_master_password() for new code",
            DeprecationWarning,
            stacklevel=2,
        )

        # V2 requires old password; attempt to load from file or prompt
        import getpass

        password_file = Path.home() / ".branchpy" / ".vault_master.key"
        if password_file.exists():
            old_password = password_file.read_text().strip()
        else:
            old_password = getpass.getpass("Enter current master password: ")

        self._vault_v2.rotate_master_password(old_password, new_master_key)


# Provide migration helper
def migrate_v1_to_v2(
    legacy_vault_path: Optional[Path] = None, legacy_key: Optional[str] = None
) -> CredentialVaultV2:
    """
    Migrate V1 credential vault to V2.

    Args:
        legacy_vault_path: Path to legacy creds.enc.json
        legacy_key: Legacy master key

    Returns:
        New CredentialVaultV2 instance with migrated data
    """
    logger.info("Starting V1 -> V2 credential vault migration")

    # Create V2 vault
    vault_v2 = CredentialVaultV2(auto_create=True)

    # Load legacy vault if provided
    if legacy_vault_path and legacy_vault_path.exists():
        from branchpy.image_validation_v3.providers_v2.credentials import (
            CredentialManager as LegacyVault,
        )

        legacy_vault = LegacyVault(creds_path=legacy_vault_path, master_key=legacy_key)

        # Export and import
        legacy_data = legacy_vault.export_plain()

        for provider_id, credentials in legacy_data.items():
            if provider_id.startswith("_"):
                continue

            logger.info(f"Migrating: {provider_id}")
            vault_v2.set_credentials(provider_id, credentials)

        logger.info(f"✓ Migrated {len(legacy_data)} providers")

        # Backup legacy vault
        backup_path = legacy_vault_path.with_suffix(".v1.backup")
        legacy_vault_path.rename(backup_path)
        logger.info(f"Legacy vault backed up to: {backup_path}")

    return vault_v2
