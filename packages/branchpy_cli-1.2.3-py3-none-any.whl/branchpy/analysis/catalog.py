"""
Compatibility shim for branchpy.analysis.catalog (moved to sae.semantics).

This module re-exports the catalog classes from their new location to preserve
backward compatibility for existing code.
"""

from branchpy.analysis.sae.semantics import SemanticsCatalog


# BuiltinSemanticsCatalog was removed - provide empty fallback
class BuiltinSemanticsCatalog(SemanticsCatalog):
    """Legacy builtin catalog - now empty, maintained for compatibility."""

    def __init__(self):
        super().__init__()
        # No builtin semantics loaded by default anymore


__all__ = ["SemanticsCatalog", "BuiltinSemanticsCatalog"]
