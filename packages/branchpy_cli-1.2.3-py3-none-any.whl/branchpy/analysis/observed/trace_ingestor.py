"""
Observed Edges: Runtime Trace Ingestion

Processes trace files (JSONL format) containing label transitions observed during gameplay.
Generates observed edges with confidence=1.0 (ground truth) and aggregates transition counts.

Trace Format:
    {"event": "label_enter", "label": "...", "ts": 1737160000.123, "session": "abc"}

Label Normalization:
    Trace files must use canonical label names exactly as they appear in Ren'Py's internal
    label registry. No additional normalization is applied. Label names are case-sensitive
    and must match the CFG node IDs exactly for proper ERP merging.

Output:
    - obs_status: Transparency object (enabled, executed, trace_files_found, etc.)
    - obs_edges: List of observed transition edges with counts and metadata
"""

import json
import logging
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)


class TraceDiscovery:
    """Discovers trace files in the project directory."""

    @staticmethod
    def find_trace_files(
        project_root: Path, trace_pattern: str = "*.jsonl"
    ) -> List[Path]:
        """
        Find trace files in the project's .branchpy/trace/ directory.

        Args:
            project_root: Root directory of the project
            trace_pattern: Glob pattern for trace files (default: *.jsonl)

        Returns:
            List of Path objects for found trace files
        """
        trace_dir = project_root / ".branchpy" / "trace"

        if not trace_dir.exists():
            logger.debug(f"Trace directory does not exist: {trace_dir}")
            return []

        trace_files = list(trace_dir.glob(trace_pattern))
        logger.info(f"Found {len(trace_files)} trace files in {trace_dir}")

        return sorted(trace_files)


class TraceParser:
    """Parses JSONL trace files and extracts label transitions."""

    def __init__(self):
        self.parse_errors = 0
        self.events_parsed = 0

    def parse_trace_file(self, trace_file: Path) -> List[Dict[str, Any]]:
        """
        Parse a JSONL trace file and extract label_enter events.

        Args:
            trace_file: Path to JSONL trace file

        Returns:
            List of parsed events (dicts with event, label, ts, session fields)
        """
        events = []

        try:
            with open(trace_file, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue

                    try:
                        event = json.loads(line)

                        # Validate event structure
                        if not isinstance(event, dict):
                            logger.warning(
                                f"{trace_file}:{line_num} - Event is not a dict"
                            )
                            self.parse_errors += 1
                            continue

                        if event.get("event") != "label_enter":
                            continue  # Only interested in label transitions

                        if "label" not in event or "ts" not in event:
                            logger.warning(
                                f"{trace_file}:{line_num} - Missing required fields"
                            )
                            self.parse_errors += 1
                            continue

                        events.append(event)
                        self.events_parsed += 1

                    except json.JSONDecodeError as e:
                        logger.warning(
                            f"{trace_file}:{line_num} - JSON decode error: {e}"
                        )
                        self.parse_errors += 1

        except Exception as e:
            logger.error(f"Failed to read trace file {trace_file}: {e}")
            self.parse_errors += 1

        return events

    def extract_transitions(
        self, events: List[Dict[str, Any]]
    ) -> List[Tuple[str, str, Dict[str, Any]]]:
        """
        Extract label transitions from sequential label_enter events.

        Args:
            events: List of label_enter events (sorted by timestamp)

        Returns:
            List of (src_label, dst_label, metadata) tuples
        """
        transitions = []

        # Sort by timestamp to ensure correct sequencing
        sorted_events = sorted(events, key=lambda e: e.get("ts", 0))

        for i in range(len(sorted_events) - 1):
            current = sorted_events[i]
            next_event = sorted_events[i + 1]

            src_label = current.get("label")
            dst_label = next_event.get("label")

            if not src_label or not dst_label:
                continue

            # Extract metadata
            metadata = {
                "session": next_event.get("session", "unknown"),
                "timestamp": next_event.get("ts", 0),
                "next_timestamp": next_event.get("ts", 0),
            }

            transitions.append((src_label, dst_label, metadata))

        return transitions


class ObservedEdgeAggregator:
    """Aggregates observed transitions into edges with counts."""

    def __init__(self):
        self.edge_data = defaultdict(
            lambda: {
                "count": 0,
                "first_seen": float("inf"),
                "last_seen": 0,
                "sessions": set(),
                "trace_files": set(),
            }
        )

    def add_transition(
        self, src: str, dst: str, timestamp: float, session: str, trace_file: str
    ):
        """
        Add a single observed transition to the aggregation.

        Args:
            src: Source label
            dst: Destination label
            timestamp: Event timestamp
            session: Session identifier
            trace_file: Source trace file name
        """
        key = (src, dst)
        data = self.edge_data[key]

        data["count"] += 1
        data["first_seen"] = min(data["first_seen"], timestamp)
        data["last_seen"] = max(data["last_seen"], timestamp)
        data["sessions"].add(session)
        data["trace_files"].add(trace_file)

    def generate_edges(self) -> List[Dict[str, Any]]:
        """
        Generate observed edge records from aggregated data.

        Returns:
            List of observed edge dicts with origin, confidence, meta, etc.
        """
        edges = []

        for (src, dst), data in self.edge_data.items():
            edge = {
                "src": src,
                "dst": dst,
                "origin": "observed",
                "edge_type": "transition",
                "kind": "direct",  # Match CFG edge kind for proper ERP deduplication
                "confidence": "observed",
                "numeric_confidence": 1.0,  # Ground truth
                "meta": {
                    "count": data["count"],
                    "first_seen": data["first_seen"],
                    "last_seen": data["last_seen"],
                    "sessions": list(data["sessions"]),
                    "trace_files": list(data["trace_files"]),
                },
            }
            edges.append(edge)

        return edges


def ingest_observed_edges(
    project_root: Path, enabled: bool = True
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Main entry point for observed edge ingestion.

    Args:
        project_root: Root directory of the project
        enabled: Whether observed edge ingestion is enabled

    Returns:
        Tuple of (obs_edges, obs_status)
        - obs_edges: List of observed edge dicts
        - obs_status: Status dict with enabled, executed, reason, etc.
    """
    obs_status = {
        "enabled": enabled,
        "supported": True,
        "executed": False,
        "reason": "",
        "trace_files_found": 0,
        "trace_files_used": [],
        "parse_errors": 0,
        "transitions_extracted": 0,
        "dedup_suppressed": 0,  # Observed edges suppressed by higher-priority edges (CFG/PFI)
        "labels_unmatched": 0,  # Transitions with labels not in node registry (diagnostic)
    }

    obs_edges = []

    if not enabled:
        obs_status["enabled"] = False
        obs_status["executed"] = False
        obs_status["reason"] = "Observed edge ingestion disabled by config"
        return obs_edges, obs_status

    try:
        # Discover trace files
        trace_files = TraceDiscovery.find_trace_files(project_root)
        obs_status["trace_files_found"] = len(trace_files)

        if not trace_files:
            obs_status["reason"] = "No trace files found in .branchpy/trace/"
            obs_status["executed"] = True
            return obs_edges, obs_status

        # Parse and aggregate
        parser = TraceParser()
        aggregator = ObservedEdgeAggregator()

        for trace_file in trace_files:
            logger.info(f"Processing trace file: {trace_file}")

            events = parser.parse_trace_file(trace_file)
            if not events:
                logger.warning(f"No valid events in {trace_file}")
                continue

            transitions = parser.extract_transitions(events)

            for src, dst, metadata in transitions:
                aggregator.add_transition(
                    src=src,
                    dst=dst,
                    timestamp=metadata["timestamp"],
                    session=metadata["session"],
                    trace_file=trace_file.name,
                )

            obs_status["trace_files_used"].append(trace_file.name)

        # Generate edges
        obs_edges = aggregator.generate_edges()

        # Update status
        obs_status["executed"] = True
        obs_status["parse_errors"] = parser.parse_errors
        obs_status["transitions_extracted"] = sum(e["meta"]["count"] for e in obs_edges)

        if obs_edges:
            obs_status["reason"] = (
                f"Ingested {len(obs_status['trace_files_used'])} trace file(s), "
                f"generated {len(obs_edges)} observed edges from "
                f"{obs_status['transitions_extracted']} transitions"
            )
            logger.info(obs_status["reason"])
        else:
            obs_status["reason"] = (
                "Trace files found but no valid transitions extracted"
            )
            logger.warning(obs_status["reason"])

    except Exception as e:
        obs_status["executed"] = False
        obs_status["reason"] = f"Observed edge ingestion failed: {e}"
        logger.error(obs_status["reason"], exc_info=True)

    return obs_edges, obs_status
