"""Consistency Checker - Detect function-related issues and anti-patterns"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from .function_indexer import FunctionDefinition
from .stat_effect_analyzer import FunctionAnalysis

try:
    from ...core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)


class WarningLevel(Enum):
    """Severity of consistency warning"""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class WarningType(Enum):
    """Type of consistency issue"""

    SIGNATURE_DRIFT = "signature_drift"  # Same name, different params
    SIDE_EFFECT_DRIFT = "side_effect_drift"  # Same name, different stat effects
    DEAD_FUNCTION = "dead_function"  # Defined but never called
    SHADOWED_FUNCTION = "shadowed_function"  # Overridden in same namespace
    DUPLICATE_DEFINITION = "duplicate_definition"  # Multiple definitions
    COMPLEXITY_WARNING = "complexity_warning"  # High cyclomatic complexity
    NAMING_CONVENTION = "naming_convention"  # Violates naming conventions


@dataclass
class ConsistencyWarning:
    """Represents a consistency check warning"""

    warning_type: WarningType
    level: WarningLevel
    function_name: str
    message: str
    file: str
    line: int
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.warning_type.value,
            "level": self.level.value,
            "function": self.function_name,
            "message": self.message,
            "file": self.file,
            "line": self.line,
            "details": self.details,
        }


class ConsistencyChecker:
    """Check function index for consistency issues and anti-patterns"""

    def __init__(
        self,
        complexity_threshold: int = 15,
        enable_naming_checks: bool = True,
        enable_governance: bool = True,
    ):
        """
        Initialize consistency checker.

        Args:
            complexity_threshold: Max acceptable cyclomatic complexity
            enable_naming_checks: Whether to check naming conventions
            enable_governance: Enable governance event logging
        """
        self.complexity_threshold = complexity_threshold
        self.enable_naming_checks = enable_naming_checks
        self.warnings: List[ConsistencyWarning] = []
        self.enable_governance = enable_governance
        self.governance_logger = None

        if enable_governance:
            try:
                from .governance import get_governance_logger

                self.governance_logger = get_governance_logger()
            except ImportError:
                log.warning("pfi.governance_unavailable")
                self.enable_governance = False

    def check_all(
        self,
        functions: List[FunctionDefinition],
        analyses: Optional[Dict[str, FunctionAnalysis]] = None,
    ) -> List[ConsistencyWarning]:
        """
        Run all consistency checks.

        Args:
            functions: List of all function definitions
            analyses: Optional dict of function analyses

        Returns:
            List of consistency warnings
        """
        self.warnings = []

        # Group functions by name
        by_name = defaultdict(list)
        for func in functions:
            by_name[func.name].append(func)

        # Run checks
        self._check_signature_drift(by_name)
        self._check_side_effect_drift(by_name, analyses or {})
        self._check_dead_functions(functions)
        self._check_shadowed_functions(by_name)
        self._check_duplicate_definitions(by_name)
        self._check_complexity(functions)

        if self.enable_naming_checks:
            self._check_naming_conventions(functions)

        log.info("pfi.consistency_check_complete: %d warnings", len(self.warnings))

        return self.warnings

    def _add_warning(self, warning: ConsistencyWarning, project_root: str = "."):
        """Add warning and emit governance event"""
        self.warnings.append(warning)

        # Emit governance event
        if self.enable_governance and self.governance_logger:
            try:
                self.governance_logger.emit_function_warning(
                    project=project_root,
                    function_name=warning.function_name,
                    warning_type=warning.warning_type.value,
                    warning_level=warning.level.value,
                    message=warning.message,
                    file=warning.file,
                    line=warning.line,
                    related_functions=warning.details.get("related_functions", []),
                )
            except Exception as e:
                log.error(f"Failed to emit governance event: {e}")

    def _check_signature_drift(self, by_name: Dict[str, List[FunctionDefinition]]):
        """Detect functions with same name but different signatures"""
        for name, defs in by_name.items():
            if len(defs) <= 1:
                continue

            # Compare signatures
            signatures = [d.signature for d in defs]
            unique_sigs = set(signatures)

            if len(unique_sigs) > 1:
                # Signature drift detected
                self.warnings.append(
                    ConsistencyWarning(
                        warning_type=WarningType.SIGNATURE_DRIFT,
                        level=WarningLevel.WARNING,
                        function_name=name,
                        message=f"Function '{name}' has {len(unique_sigs)} different signatures",
                        file=defs[0].file,
                        line=defs[0].line,
                        details={
                            "signatures": list(unique_sigs),
                            "locations": [
                                {
                                    "file": d.file,
                                    "line": d.line,
                                    "signature": d.signature,
                                }
                                for d in defs
                            ],
                        },
                    )
                )

    def _check_side_effect_drift(
        self,
        by_name: Dict[str, List[FunctionDefinition]],
        analyses: Dict[str, FunctionAnalysis],
    ):
        """Detect functions with same name but different stat effects"""
        for name, defs in by_name.items():
            if len(defs) <= 1:
                continue

            # Get analyses for all definitions
            func_analyses = []
            for d in defs:
                analysis = analyses.get(d.name)
                if analysis:
                    func_analyses.append((d, analysis))

            if len(func_analyses) <= 1:
                continue

            # Compare stat modifications
            stat_sets = [set(a.stats_modified) for _, a in func_analyses]

            # Check if all definitions modify the same stats
            if len(set(frozenset(s) for s in stat_sets)) > 1:
                self.warnings.append(
                    ConsistencyWarning(
                        warning_type=WarningType.SIDE_EFFECT_DRIFT,
                        level=WarningLevel.WARNING,
                        function_name=name,
                        message=f"Function '{name}' modifies different stats in different definitions",
                        file=defs[0].file,
                        line=defs[0].line,
                        details={
                            "variations": [
                                {
                                    "file": d.file,
                                    "line": d.line,
                                    "stats": sorted(list(a.stats_modified)),
                                }
                                for d, a in func_analyses
                            ]
                        },
                    )
                )

    def _check_dead_functions(self, functions: List[FunctionDefinition]):
        """Detect functions that are defined but never called"""

        # Build set of all called functions
        called = set()
        for func in functions:
            called.update(func.calls_functions)
            called.update(func.called_by_functions)

        # Check each function
        for func in functions:
            # Skip if it has documented usages
            if func.total_usages > 0:
                continue

            # Skip if it's called by something
            if func.name in called:
                continue

            # Skip if it's a special method (starts with _)
            if func.name.startswith("_"):
                continue

            # Skip lambdas
            if func.name.startswith("<lambda"):
                continue

            # Dead function detected
            self.warnings.append(
                ConsistencyWarning(
                    warning_type=WarningType.DEAD_FUNCTION,
                    level=WarningLevel.INFO,
                    function_name=func.name,
                    message=f"Function '{func.name}' is defined but never called",
                    file=func.file,
                    line=func.line,
                    details={
                        "signature": func.signature,
                        "context": func.context.value,
                    },
                )
            )

    def _check_shadowed_functions(self, by_name: Dict[str, List[FunctionDefinition]]):
        """Detect functions that shadow earlier definitions in the same file"""
        for name, defs in by_name.items():
            if len(defs) <= 1:
                continue

            # Group by file
            by_file = defaultdict(list)
            for d in defs:
                by_file[d.file].append(d)

            # Check for shadowing within same file
            for file_path, file_defs in by_file.items():
                if len(file_defs) <= 1:
                    continue

                # Sort by line number
                sorted_defs = sorted(file_defs, key=lambda d: d.line)

                # All but first are shadowing
                for shadowing_def in sorted_defs[1:]:
                    self.warnings.append(
                        ConsistencyWarning(
                            warning_type=WarningType.SHADOWED_FUNCTION,
                            level=WarningLevel.WARNING,
                            function_name=name,
                            message=f"Function '{name}' at line {shadowing_def.line} shadows earlier definition",
                            file=shadowing_def.file,
                            line=shadowing_def.line,
                            details={
                                "original_line": sorted_defs[0].line,
                                "shadowed_signature": sorted_defs[0].signature,
                                "shadowing_signature": shadowing_def.signature,
                            },
                        )
                    )

    def _check_duplicate_definitions(
        self, by_name: Dict[str, List[FunctionDefinition]]
    ):
        """Detect true duplicate definitions (same signature, different files)"""
        for name, defs in by_name.items():
            if len(defs) <= 1:
                continue

            # Group by signature
            by_sig = defaultdict(list)
            for d in defs:
                by_sig[d.signature].append(d)

            # Check for duplicates across files
            for sig, sig_defs in by_sig.items():
                if len(sig_defs) <= 1:
                    continue

                # Multiple definitions with same signature
                files = set(d.file for d in sig_defs)
                if len(files) > 1:
                    self.warnings.append(
                        ConsistencyWarning(
                            warning_type=WarningType.DUPLICATE_DEFINITION,
                            level=WarningLevel.ERROR,
                            function_name=name,
                            message=f"Function '{name}' has identical definitions in {len(files)} files",
                            file=sig_defs[0].file,
                            line=sig_defs[0].line,
                            details={
                                "signature": sig,
                                "locations": [
                                    {"file": d.file, "line": d.line} for d in sig_defs
                                ],
                            },
                        )
                    )

    def _check_complexity(self, functions: List[FunctionDefinition]):
        """Detect functions with high cyclomatic complexity"""
        for func in functions:
            if func.complexity > self.complexity_threshold:
                self.warnings.append(
                    ConsistencyWarning(
                        warning_type=WarningType.COMPLEXITY_WARNING,
                        level=WarningLevel.WARNING,
                        function_name=func.name,
                        message=f"Function '{func.name}' has high complexity ({func.complexity} > {self.complexity_threshold})",
                        file=func.file,
                        line=func.line,
                        details={
                            "complexity": func.complexity,
                            "threshold": self.complexity_threshold,
                            "body_lines": func.body_lines,
                        },
                    )
                )

    def _check_naming_conventions(self, functions: List[FunctionDefinition]):
        """Check Python naming conventions (PEP 8)"""
        for func in functions:
            # Skip lambdas
            if func.name.startswith("<lambda"):
                continue

            # Check for snake_case
            if not self._is_snake_case(func.name):
                self.warnings.append(
                    ConsistencyWarning(
                        warning_type=WarningType.NAMING_CONVENTION,
                        level=WarningLevel.INFO,
                        function_name=func.name,
                        message=f"Function '{func.name}' does not follow snake_case naming convention",
                        file=func.file,
                        line=func.line,
                        details={"recommended": self._to_snake_case(func.name)},
                    )
                )

    @staticmethod
    def _is_snake_case(name: str) -> bool:
        """Check if name follows snake_case convention"""
        # Allow single lowercase word
        if name.islower() and "_" not in name:
            return True

        # Must be lowercase with underscores
        if name.replace("_", "").islower() and name.replace("_", "").isalnum():
            return True

        return False

    @staticmethod
    def _to_snake_case(name: str) -> str:
        """Convert name to snake_case"""
        import re

        # Insert underscores before capital letters
        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

    def get_warnings_by_level(self, level: WarningLevel) -> List[ConsistencyWarning]:
        """Get warnings filtered by severity level"""
        return [w for w in self.warnings if w.level == level]

    def get_warnings_by_type(
        self, warning_type: WarningType
    ) -> List[ConsistencyWarning]:
        """Get warnings filtered by type"""
        return [w for w in self.warnings if w.warning_type == warning_type]

    def export_warnings(self) -> Dict[str, Any]:
        """Export warnings to JSON-serializable format"""
        return {
            "warnings": [w.to_dict() for w in self.warnings],
            "summary": {
                "total": len(self.warnings),
                "by_level": {
                    level.value: len(self.get_warnings_by_level(level))
                    for level in WarningLevel
                },
                "by_type": {
                    wtype.value: len(self.get_warnings_by_type(wtype))
                    for wtype in WarningType
                },
            },
        }
