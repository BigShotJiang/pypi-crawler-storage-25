"""Call Site Analyzer - Track function usage across Ren'Py project

Scans all .rpy files to find function call sites and populate call counts.
Complements FunctionIndexer by tracking WHERE functions are actually used.

Features:
- Scan Python blocks for function calls (direct calls, renpy.call, etc.)
- Scan inline $ statements for function usage
- Track call context (label, function, screen)
- Build usage statistics (total calls, called_by_labels, called_by_functions)
- Support both Python AST and regex fallback for edge cases

v1.0.0: Phase 3A - Initial call site tracking
"""

from __future__ import annotations

import ast
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

try:
    from ...core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)


@dataclass
class CallSite:
    """Represents a single function call location"""

    function_name: str
    file: str
    line: int
    context_type: str  # "label", "function", "screen", "init", "python_early"
    context_name: str  # Name of containing label/function/screen
    snippet: str = ""  # Code snippet showing the call


@dataclass
class FunctionUsage:
    """Usage statistics for a single function"""

    function_name: str
    total_calls: int = 0
    call_sites: List[CallSite] = field(default_factory=list)
    called_by_labels: Set[str] = field(default_factory=set)
    called_by_functions: Set[str] = field(default_factory=set)
    called_by_screens: Set[str] = field(default_factory=set)

    def to_dict(self) -> Dict:
        return {
            "function_name": self.function_name,
            "total_calls": self.total_calls,
            "call_sites": [
                {
                    "file": site.file,
                    "line": site.line,
                    "context_type": site.context_type,
                    "context_name": site.context_name,
                    "snippet": site.snippet,
                }
                for site in self.call_sites
            ],
            "called_by_labels": sorted(list(self.called_by_labels)),
            "called_by_functions": sorted(list(self.called_by_functions)),
            "called_by_screens": sorted(list(self.called_by_screens)),
        }


class CallSiteAnalyzer:
    """Analyze function call sites across Ren'Py project"""

    # Regex patterns
    PYTHON_EARLY_RE = re.compile(r"^\s*python\s+early\s*:\s*$", re.MULTILINE)
    PYTHON_BLOCK_RE = re.compile(r"^\s*python\s*:\s*$", re.MULTILINE)
    INIT_PYTHON_RE = re.compile(
        r"^\s*init\s+(?:python\s+)?(-?\d+\s+)?python\s*:\s*$", re.MULTILINE
    )
    INLINE_PYTHON_RE = re.compile(r"^\s*\$\s+(.+)$", re.MULTILINE)
    LABEL_RE = re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:", re.MULTILINE)
    SCREEN_RE = re.compile(r"^\s*screen\s+([A-Za-z_]\w*)\s*", re.MULTILINE)

    # Function call pattern (basic regex fallback)
    CALL_PATTERN = re.compile(r"\b([A-Za-z_]\w*)\s*\(")

    def __init__(self, project_root: Path, known_functions: Set[str]):
        self.project_root = Path(project_root)
        self.game_dir = self.project_root / "game"
        self.known_functions = known_functions  # Set of function names to track
        self.usage_map: Dict[str, FunctionUsage] = defaultdict(
            lambda: FunctionUsage(function_name="")
        )

    def analyze_project(self) -> Dict[str, FunctionUsage]:
        """
        Scan all .rpy files and build call site index.

        Returns:
            Dict mapping function name to FunctionUsage
        """
        log.info(f"call_site.analyze_start project_root={self.project_root}")

        # Scan all .rpy files
        rpy_files = self._scan_files()
        log.info(f"call_site.files_found count={len(rpy_files)}")

        # Parse each file
        for file_path in rpy_files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                rel_path = str(file_path.relative_to(self.project_root))

                # Extract call sites from various contexts
                self._extract_from_file(content, rel_path)

            except Exception as e:
                log.error(
                    "call_site.file_parse_error",
                    extra={"file": str(file_path), "error": str(e)},
                )

        log.info(
            f"call_site.analyze_complete "
            f"tracked_functions={len(self.usage_map)} "
            f"total_call_sites={sum(u.total_calls for u in self.usage_map.values())}"
        )
        return dict(self.usage_map)

    def _scan_files(self) -> List[Path]:
        """Recursively scan game/ directory for .rpy files"""
        if not self.game_dir.exists():
            log.warning(f"call_site.game_dir_missing path={self.game_dir}")
            return []
        return sorted(self.game_dir.rglob("*.rpy"))

    def _extract_from_file(self, content: str, file_path: str):
        """Extract all function calls from a single file"""
        lines = content.split("\n")

        # Track current context
        current_context_type = "global"
        current_context_name = ""
        in_python_block = False
        block_start = 0
        block_indent = 0
        python_lines = []

        for i, line in enumerate(lines, start=1):
            # Detect label context
            if match := self.LABEL_RE.match(line):
                current_context_type = "label"
                current_context_name = match.group(1)
                in_python_block = False
                continue

            # Detect screen context
            if match := self.SCREEN_RE.match(line):
                current_context_type = "screen"
                current_context_name = match.group(1)
                in_python_block = False
                continue

            # Detect python early: block
            if self.PYTHON_EARLY_RE.match(line):
                if in_python_block and python_lines:
                    self._analyze_python_block(
                        python_lines,
                        file_path,
                        block_start,
                        current_context_type,
                        current_context_name,
                    )
                in_python_block = True
                block_start = i + 1
                block_indent = len(line) - len(line.lstrip())
                python_lines = []
                # Update context
                current_context_type = "python_early"
                current_context_name = ""
                continue

            # Detect init python: block
            elif self.INIT_PYTHON_RE.match(line):
                if in_python_block and python_lines:
                    self._analyze_python_block(
                        python_lines,
                        file_path,
                        block_start,
                        current_context_type,
                        current_context_name,
                    )
                in_python_block = True
                block_start = i + 1
                block_indent = len(line) - len(line.lstrip())
                python_lines = []
                current_context_type = "init"
                current_context_name = ""
                continue

            # Detect python: block
            elif self.PYTHON_BLOCK_RE.match(line):
                if in_python_block and python_lines:
                    self._analyze_python_block(
                        python_lines,
                        file_path,
                        block_start,
                        current_context_type,
                        current_context_name,
                    )
                in_python_block = True
                block_start = i + 1
                block_indent = len(line) - len(line.lstrip())
                python_lines = []
                # Inherit current context (label/screen/global)
                continue

            # Inside python block
            if in_python_block:
                python_lines.append(line)

                # Check if we've exited the block (dedent)
                stripped = line.lstrip()
                if stripped and not stripped.startswith("#"):
                    current_indent = len(line) - len(stripped)
                    if current_indent <= block_indent:
                        # Exited block
                        python_lines.pop()
                        self._analyze_python_block(
                            python_lines,
                            file_path,
                            block_start,
                            current_context_type,
                            current_context_name,
                        )
                        in_python_block = False
                        python_lines = []

            # Detect inline $ statements
            elif match := self.INLINE_PYTHON_RE.match(line):
                code = match.group(1).strip()
                self._analyze_inline_statement(
                    code, file_path, i, current_context_type, current_context_name
                )

        # Handle EOF with open python block
        if in_python_block and python_lines:
            self._analyze_python_block(
                python_lines,
                file_path,
                block_start,
                current_context_type,
                current_context_name,
            )

    def _analyze_python_block(
        self,
        lines: List[str],
        file_path: str,
        start_line: int,
        context_type: str,
        context_name: str,
    ):
        """Analyze Python block for function calls"""
        if not lines:
            return

        # Normalize code
        code = "\n".join(lines)

        # Try AST parsing first
        try:
            tree = ast.parse(code, filename=file_path, mode="exec")
            self._extract_calls_from_ast(
                tree, file_path, start_line, context_type, context_name, code
            )
            return
        except SyntaxError:
            # Fallback to regex
            pass

        # Regex fallback
        self._extract_calls_regex(
            code, file_path, start_line, context_type, context_name
        )

    def _analyze_inline_statement(
        self,
        code: str,
        file_path: str,
        line_num: int,
        context_type: str,
        context_name: str,
    ):
        """Analyze inline $ statement for function calls"""
        try:
            tree = ast.parse(code)
            self._extract_calls_from_ast(
                tree, file_path, line_num, context_type, context_name, code
            )
        except SyntaxError:
            # Fallback to regex
            self._extract_calls_regex(
                code, file_path, line_num, context_type, context_name
            )

    def _extract_calls_from_ast(
        self,
        tree: ast.AST,
        file_path: str,
        base_line: int,
        context_type: str,
        context_name: str,
        full_code: str,
    ):
        """Extract function calls using AST"""
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_function_name(node)

                if func_name and func_name in self.known_functions:
                    # Calculate actual line number
                    line = base_line + (
                        node.lineno - 1 if hasattr(node, "lineno") else 0
                    )

                    # Extract snippet
                    snippet = self._extract_snippet(full_code, node)

                    # Record call site
                    self._record_call(
                        func_name, file_path, line, context_type, context_name, snippet
                    )

    def _extract_calls_regex(
        self,
        code: str,
        file_path: str,
        base_line: int,
        context_type: str,
        context_name: str,
    ):
        """Extract function calls using regex (fallback)"""
        for match in self.CALL_PATTERN.finditer(code):
            func_name = match.group(1)

            # Skip Python builtins and common keywords
            if func_name in {
                "if",
                "for",
                "while",
                "def",
                "class",
                "return",
                "import",
                "from",
                "print",
                "len",
                "str",
                "int",
                "float",
                "bool",
                "list",
                "dict",
                "set",
                "tuple",
                "range",
                "enumerate",
                "zip",
                "map",
                "filter",
            }:
                continue

            if func_name in self.known_functions:
                # Calculate line number
                line = base_line + code[: match.start()].count("\n")

                # Extract snippet (line containing the call)
                call_pos = match.start()
                line_start = code.rfind("\n", 0, call_pos) + 1
                line_end = code.find("\n", call_pos)
                if line_end == -1:
                    line_end = len(code)
                snippet = code[line_start:line_end].strip()[:120]

                # Record call site
                self._record_call(
                    func_name, file_path, line, context_type, context_name, snippet
                )

    def _get_function_name(self, node: ast.Call) -> Optional[str]:
        """Extract function name from Call node"""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            # For renpy.some_func(), return "some_func"
            # For module.func(), could track both forms
            # For now, just return the attribute name
            return node.func.attr
        return None

    def _extract_snippet(self, code: str, node: ast.Call) -> str:
        """Extract code snippet around the call"""
        try:
            if hasattr(ast, "unparse"):
                snippet = ast.unparse(node)
                return snippet[:120]
        except Exception:
            pass

        # Fallback: extract from line
        if hasattr(node, "lineno"):
            lines = code.split("\n")
            if 0 <= node.lineno - 1 < len(lines):
                return lines[node.lineno - 1].strip()[:120]

        return ""

    def _record_call(
        self,
        func_name: str,
        file_path: str,
        line: int,
        context_type: str,
        context_name: str,
        snippet: str,
    ):
        """Record a function call site"""
        # Create call site
        call_site = CallSite(
            function_name=func_name,
            file=file_path,
            line=line,
            context_type=context_type,
            context_name=context_name,
            snippet=snippet,
        )

        # Get or create usage record
        if func_name not in self.usage_map:
            self.usage_map[func_name] = FunctionUsage(function_name=func_name)

        usage = self.usage_map[func_name]
        usage.total_calls += 1
        usage.call_sites.append(call_site)

        # Track context
        if context_type == "label" and context_name:
            usage.called_by_labels.add(context_name)
        elif context_type == "function" and context_name:
            usage.called_by_functions.add(context_name)
        elif context_type == "screen" and context_name:
            usage.called_by_screens.add(context_name)

        log.debug(
            f"call_site.recorded function={func_name} "
            f"file={file_path} line={line} "
            f"context={context_type}:{context_name}"
        )
