"""Call Graph Builder - Build function dependency graph"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .function_indexer import FunctionDefinition


@dataclass
class CallEdge:
    """Represents a function call edge in the call graph"""

    caller: str  # Calling function name
    callee: str  # Called function name
    call_count: int = 1  # Number of times called (estimate)
    contexts: List[str] = field(default_factory=list)  # Contexts where call occurs

    def to_dict(self) -> Dict[str, Any]:
        return {
            "caller": self.caller,
            "callee": self.callee,
            "call_count": self.call_count,
            "contexts": self.contexts,
        }


class CallGraph:
    """Build and analyze function call graph"""

    def __init__(self):
        self.edges: List[CallEdge] = []
        self.nodes: Set[str] = set()  # All function names
        self.adjacency: Dict[str, Set[str]] = defaultdict(set)  # caller -> callees
        self.reverse_adjacency: Dict[str, Set[str]] = defaultdict(
            set
        )  # callee -> callers

    def build_from_functions(self, functions: List[FunctionDefinition]):
        """
        Build call graph from function definitions.

        Args:
            functions: List of all function definitions
        """
        # Add all nodes
        for func in functions:
            self.nodes.add(func.name)

        # Build edges
        for func in functions:
            for callee in func.calls_functions:
                self._add_edge(func.name, callee, context=func.context.value)

        # Update usage counts in function definitions
        for func in functions:
            # Count how many functions call this one
            func.called_by_functions = list(
                self.reverse_adjacency.get(func.name, set())
            )
            func.total_usages = len(func.called_by_functions) + len(
                func.called_by_labels
            )

    def _add_edge(self, caller: str, callee: str, context: str = ""):
        """Add or update a call edge"""
        # Find existing edge
        existing = None
        for edge in self.edges:
            if edge.caller == caller and edge.callee == callee:
                existing = edge
                break

        if existing:
            existing.call_count += 1
            if context and context not in existing.contexts:
                existing.contexts.append(context)
        else:
            edge = CallEdge(
                caller=caller, callee=callee, contexts=[context] if context else []
            )
            self.edges.append(edge)

        # Update adjacency
        self.adjacency[caller].add(callee)
        self.reverse_adjacency[callee].add(caller)

    def get_dependencies(self, function_name: str) -> Set[str]:
        """Get all functions that this function calls (direct dependencies)"""
        return self.adjacency.get(function_name, set())

    def get_dependents(self, function_name: str) -> Set[str]:
        """Get all functions that call this function"""
        return self.reverse_adjacency.get(function_name, set())

    def get_transitive_dependencies(self, function_name: str) -> Set[str]:
        """Get all transitive dependencies (functions called directly or indirectly)"""
        visited = set()
        to_visit = [function_name]

        while to_visit:
            current = to_visit.pop()
            if current in visited:
                continue
            visited.add(current)

            deps = self.adjacency.get(current, set())
            to_visit.extend(deps - visited)

        visited.discard(function_name)  # Remove self
        return visited

    def get_call_chain(self, start: str, end: str) -> Optional[List[str]]:
        """
        Find a call chain from start function to end function.

        Returns:
            List of function names forming the call chain, or None if no path exists
        """
        if start == end:
            return [start]

        # BFS to find shortest path
        queue = [(start, [start])]
        visited = {start}

        while queue:
            current, path = queue.pop(0)

            for callee in self.adjacency.get(current, set()):
                if callee == end:
                    return path + [callee]

                if callee not in visited:
                    visited.add(callee)
                    queue.append((callee, path + [callee]))

        return None  # No path found

    def detect_cycles(self) -> List[List[str]]:
        """
        Detect circular dependencies (cycles) in the call graph.

        Returns:
            List of cycles, each represented as a list of function names
        """
        cycles = []
        visited = set()
        rec_stack = set()

        def visit(node: str, path: List[str]):
            if node in rec_stack:
                # Cycle detected
                cycle_start = path.index(node)
                cycle = path[cycle_start:]
                cycles.append(cycle)
                return

            if node in visited:
                return

            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for callee in self.adjacency.get(node, set()):
                visit(callee, path[:])

            rec_stack.remove(node)

        for node in self.nodes:
            if node not in visited:
                visit(node, [])

        return cycles

    def get_leaf_functions(self) -> Set[str]:
        """Get functions that don't call any other functions (leaf nodes)"""
        return {node for node in self.nodes if not self.adjacency.get(node)}

    def get_root_functions(self) -> Set[str]:
        """Get functions that are not called by any other function (root nodes)"""
        return {node for node in self.nodes if not self.reverse_adjacency.get(node)}

    def export_graph(self) -> Dict[str, Any]:
        """Export call graph to JSON-serializable format"""
        return {
            "nodes": sorted(list(self.nodes)),
            "edges": [e.to_dict() for e in self.edges],
            "stats": {
                "total_nodes": len(self.nodes),
                "total_edges": len(self.edges),
                "leaf_functions": len(self.get_leaf_functions()),
                "root_functions": len(self.get_root_functions()),
                "cycles": len(self.detect_cycles()),
            },
        }

    def export_dot(self) -> str:
        """Export call graph in DOT format for visualization"""
        lines = ["digraph CallGraph {"]
        lines.append("  rankdir=LR;")
        lines.append("  node [shape=box];")

        # Add nodes
        for node in sorted(self.nodes):
            lines.append(f'  "{node}";')

        # Add edges
        for edge in self.edges:
            label = f"×{edge.call_count}" if edge.call_count > 1 else ""
            lines.append(f'  "{edge.caller}" -> "{edge.callee}" [label="{label}"];')

        lines.append("}")
        return "\n".join(lines)
