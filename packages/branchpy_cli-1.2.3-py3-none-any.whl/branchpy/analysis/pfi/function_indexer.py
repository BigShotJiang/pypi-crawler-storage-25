"""Function Indexer - Discover and extract custom functions from Ren'Py projects"""

from __future__ import annotations

import ast
import io
import re
import textwrap
import tokenize
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

try:
    from ...core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)


def _open_with_encoding(path: str):
    """
    Open file with PEP 263 encoding detection.
    Falls back to UTF-8 with replace on errors.
    """
    try:
        return tokenize.open(path)  # type: ignore[attr-defined]
    except Exception:
        return io.open(path, "r", encoding="utf-8", errors="replace")


def _normalize_block(lines: List[str]) -> str:
    """
    Normalize Python code block:
    - Unify newlines
    - Convert tabs to spaces
    - Dedent
    - Strip leading blank lines
    """
    if not lines:
        return ""
    # Lines from split('\n') don't include newlines, so add them back
    src = "\n".join(lines) if lines else ""
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = src.replace("\t", "    ")
    src = textwrap.dedent(src).lstrip("\n")
    return src


class FunctionContext(Enum):
    """Context where function is defined"""

    PYTHON_EARLY = "python_early"  # python early: block
    PYTHON_INLINE = "python_inline"  # python: block
    INLINE_STATEMENT = "inline_statement"  # $ def foo(): ...
    INIT_BLOCK = "init_block"  # init python: block
    LABEL_INLINE = "label_inline"  # Inside label body
    LAMBDA_EXPR = "lambda_expr"  # Lambda expression


@dataclass
class FunctionParameter:
    """Represents a function parameter"""

    name: str
    default: Optional[Any] = None
    annotation: Optional[str] = None
    kind: str = (
        "positional"  # "positional", "keyword-only", "var-positional", "var-keyword"
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "default": str(self.default) if self.default is not None else None,
            "annotation": self.annotation,
            "kind": self.kind,
        }


@dataclass
class FunctionDefinition:
    """Represents a discovered function definition"""

    name: str
    params: List[FunctionParameter] = field(default_factory=list)
    file: str = ""
    line: int = 0
    context: FunctionContext = FunctionContext.PYTHON_INLINE

    # Metadata
    docstring: Optional[str] = None
    decorators: List[str] = field(default_factory=list)
    return_annotation: Optional[str] = None

    # Code analysis
    body_lines: int = 0
    complexity: int = 0  # Cyclomatic complexity estimate

    # Dependency tracking
    calls_functions: List[str] = field(
        default_factory=list
    )  # Functions called by this function
    calls_labels: List[str] = field(default_factory=list)  # Labels called/jumped to
    returns_labels: List[str] = field(
        default_factory=list
    )  # String literals returned by function
    reads_vars: Set[str] = field(default_factory=set)  # Variables read
    writes_vars: Set[str] = field(default_factory=set)  # Variables written

    # Usage tracking (populated later)
    called_by_labels: List[str] = field(default_factory=list)
    called_by_functions: List[str] = field(default_factory=list)
    total_usages: int = 0

    # Issues
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Export to JSON-serializable dict"""
        return {
            "name": self.name,
            "params": [p.to_dict() for p in self.params],
            "file": self.file,
            "line": self.line,
            "context": self.context.value,
            "docstring": self.docstring,
            "decorators": self.decorators,
            "return_annotation": self.return_annotation,
            "body_lines": self.body_lines,
            "complexity": self.complexity,
            "calls_functions": self.calls_functions,
            "calls_labels": self.calls_labels,
            "returns_labels": self.returns_labels,
            "reads_vars": sorted(list(self.reads_vars)),
            "writes_vars": sorted(list(self.writes_vars)),
            "called_by_labels": self.called_by_labels,
            "called_by_functions": self.called_by_functions,
            "total_usages": self.total_usages,
            "warnings": self.warnings,
        }

    @property
    def signature(self) -> str:
        """Get function signature for comparison"""
        param_strs = []
        for p in self.params:
            s = p.name
            if p.annotation:
                s += f": {p.annotation}"
            if p.default is not None:
                s += f" = {p.default}"
            param_strs.append(s)
        sig = f"{self.name}({', '.join(param_strs)})"
        if self.return_annotation:
            sig += f" -> {self.return_annotation}"
        return sig


class FunctionIndexer:
    """Extract and index all custom function definitions from Ren'Py project"""

    # Regex patterns for detecting Python blocks
    PYTHON_EARLY_RE = re.compile(r"^\s*python\s+early\s*:\s*$", re.MULTILINE)
    PYTHON_BLOCK_RE = re.compile(
        r"^\s*python\s*:(?P<inline>.*)?$", re.MULTILINE
    )  # Captures inline code after colon
    INIT_PYTHON_RE = re.compile(
        r"^\s*init\s+(?:python\s+)?(-?\d+\s+)?python\s*:\s*$", re.MULTILINE
    )
    INLINE_PYTHON_RE = re.compile(r"^\s*\$\s+(.+)$", re.MULTILINE)
    LABEL_RE = re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:", re.MULTILINE)

    def __init__(self, project_root: Path, enable_governance: bool = True):
        self.project_root = Path(project_root)
        self.game_dir = self.project_root / "game"
        self.functions: Dict[str, List[FunctionDefinition]] = (
            {}
        )  # name -> list of definitions
        self.all_functions: List[FunctionDefinition] = []
        self.enable_governance = enable_governance
        self.governance_logger = None

        if enable_governance:
            try:
                from .governance import get_governance_logger

                self.governance_logger = get_governance_logger()
            except ImportError:
                log.warning("pfi.governance_unavailable")
                self.enable_governance = False

    def index_project(self) -> Dict[str, Any]:
        """
        Scan all .rpy files and build function index.

        Returns:
            Dict with function index data
        """
        log.info("pfi.index_start: %s", str(self.project_root))

        # Scan all .rpy files
        rpy_files = self._scan_files()
        log.info("pfi.files_found: %d files", len(rpy_files))

        # Parse each file
        for file_path in rpy_files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                rel_path = str(file_path.relative_to(self.project_root))

                # Extract functions from various contexts
                self._extract_from_file(content, rel_path)

            except Exception as e:
                log.error(
                    "pfi.file_parse_error",
                    extra={"file": str(file_path), "error": str(e)},
                )

        log.info(
            "pfi.index_complete: %d total functions, %d unique names",
            len(self.all_functions),
            len(self.functions),
        )

        return self._export_index()

    def _scan_files(self) -> List[Path]:
        """Recursively scan game/ directory for .rpy files"""
        if not self.game_dir.exists():
            log.warning("pfi.game_dir_missing: %s", str(self.game_dir))
            return []
        return sorted(self.game_dir.rglob("*.rpy"))

    def _extract_from_file(self, content: str, file_path: str):
        """Extract all function definitions from a single file"""
        lines = content.split("\n")

        # Track current context
        in_python_block = False
        in_init_block = False
        in_python_early = False
        block_start = 0
        block_indent = 0
        python_lines = []
        current_context = FunctionContext.PYTHON_INLINE

        # Extract from python blocks
        for i, line in enumerate(lines):
            # Detect python early: block
            if self.PYTHON_EARLY_RE.match(line):
                if in_python_block and python_lines:
                    self._parse_python_block(
                        python_lines, file_path, block_start, current_context
                    )
                in_python_early = True
                in_python_block = True
                block_start = i + 1
                block_indent = len(line) - len(line.lstrip())
                python_lines = []
                current_context = FunctionContext.PYTHON_EARLY
                continue

            # Detect init python: block
            elif self.INIT_PYTHON_RE.match(line):
                if in_python_block and python_lines:
                    self._parse_python_block(
                        python_lines, file_path, block_start, current_context
                    )
                in_init_block = True
                in_python_block = True
                block_start = i + 1
                block_indent = len(line) - len(line.lstrip())
                python_lines = []
                current_context = FunctionContext.INIT_BLOCK
                continue

            # Detect python: block (or inline python: statement)
            elif match := self.PYTHON_BLOCK_RE.match(line):
                if in_python_block and python_lines:
                    self._parse_python_block(
                        python_lines, file_path, block_start, current_context
                    )

                # Check for inline code on same line
                inline = (match.group("inline") or "").strip()
                if inline:
                    # python: x = 1  # inline statement
                    self._parse_python_block(
                        [inline + "\n"], file_path, i + 1, FunctionContext.PYTHON_INLINE
                    )
                    continue

                # Block start
                in_python_block = True
                block_start = i + 1
                block_indent = len(line) - len(line.lstrip())
                python_lines = []
                current_context = FunctionContext.PYTHON_INLINE
                continue

            # Inside python block
            if in_python_block:
                # Always collect the line first
                python_lines.append(line)

                # Check if we've exited the block (dedent to block level or less)
                # Only check on non-empty, non-comment lines
                stripped = line.lstrip()
                if stripped and not stripped.startswith("#"):
                    current_indent = len(line) - len(stripped)
                    if current_indent <= block_indent:
                        # Exited block - remove the line that caused exit
                        python_lines.pop()
                        self._parse_python_block(
                            python_lines, file_path, block_start, current_context
                        )
                        in_python_block = False
                        in_python_early = False
                        in_init_block = False
                        python_lines = []

            # Detect inline $ statements with function definitions
            elif match := self.INLINE_PYTHON_RE.match(line):
                code = match.group(1).strip()
                if code.startswith("def ") or " lambda " in code:
                    self._parse_inline_statement(code, file_path, i + 1)

        # Handle EOF with open python block
        if in_python_block and python_lines:
            self._parse_python_block(
                python_lines, file_path, block_start, current_context
            )

    def _parse_python_block(
        self,
        lines: List[str],
        file_path: str,
        start_line: int,
        context: FunctionContext,
    ):
        """Parse Python code block and extract function definitions"""
        if not lines:
            return

        # Trim trailing blank lines and comments (they interfere with dedent)
        while lines and (not lines[-1].strip() or lines[-1].lstrip().startswith("#")):
            lines.pop()

        if not lines:
            return

        # Normalize block: newlines, tabs->spaces, dedent, strip leading blanks
        code = _normalize_block(lines)

        if not code.strip():
            return

        try:
            tree = ast.parse(code, filename=file_path, mode="exec")

            # Extract function definitions
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_def = self._extract_function_from_ast(
                        node, file_path, start_line, context
                    )
                    if func_def:
                        self._add_function(func_def)

                # Extract lambdas
                elif isinstance(node, ast.Lambda):
                    lambda_def = self._extract_lambda_from_ast(
                        node, file_path, start_line
                    )
                    if lambda_def:
                        self._add_function(lambda_def)

        except SyntaxError as e:
            # Attach original span for better error reporting
            adjusted_lineno = (e.lineno or 1) + start_line - 1
            log.warning(
                "pfi.python_parse_error",
                extra={
                    "file": file_path,
                    "line": adjusted_lineno,
                    "error": str(e),
                    "code_sample": code[:200],
                },
            )

    def _parse_inline_statement(self, code: str, file_path: str, line_num: int):
        """Parse inline $ statement for function definitions"""
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_def = self._extract_function_from_ast(
                        node, file_path, line_num, FunctionContext.INLINE_STATEMENT
                    )
                    if func_def:
                        self._add_function(func_def)
                elif isinstance(node, ast.Lambda):
                    lambda_def = self._extract_lambda_from_ast(
                        node, file_path, line_num
                    )
                    if lambda_def:
                        self._add_function(lambda_def)
        except SyntaxError:
            pass  # Ignore invalid inline statements

    def _extract_function_from_ast(
        self,
        node: ast.FunctionDef,
        file_path: str,
        base_line: int,
        context: FunctionContext,
    ) -> Optional[FunctionDefinition]:
        """Extract FunctionDefinition from AST node"""

        # Extract parameters
        params = []
        args = node.args

        # Regular positional arguments
        for i, arg in enumerate(args.args):
            default = None
            default_offset = len(args.args) - len(args.defaults)
            if i >= default_offset:
                default_node = args.defaults[i - default_offset]
                default = ast.unparse(default_node) if hasattr(ast, "unparse") else None

            params.append(
                FunctionParameter(
                    name=arg.arg,
                    annotation=(
                        ast.unparse(arg.annotation)
                        if arg.annotation and hasattr(ast, "unparse")
                        else None
                    ),
                    default=default,
                    kind="positional",
                )
            )

        # *args
        if args.vararg:
            params.append(
                FunctionParameter(name=args.vararg.arg, kind="var-positional")
            )

        # Keyword-only args
        for i, arg in enumerate(args.kwonlyargs):
            default = None
            if i < len(args.kw_defaults):
                kw_default = args.kw_defaults[i]
                if kw_default is not None and hasattr(ast, "unparse"):
                    default = ast.unparse(kw_default)

            params.append(
                FunctionParameter(
                    name=arg.arg,
                    annotation=(
                        ast.unparse(arg.annotation)
                        if arg.annotation and hasattr(ast, "unparse")
                        else None
                    ),
                    default=default,
                    kind="keyword-only",
                )
            )

        # **kwargs
        if args.kwarg:
            params.append(FunctionParameter(name=args.kwarg.arg, kind="var-keyword"))

        # Extract docstring
        docstring = ast.get_docstring(node)

        # Extract decorators
        decorators = []
        for dec in node.decorator_list:
            if hasattr(ast, "unparse"):
                decorators.append(ast.unparse(dec))
            elif isinstance(dec, ast.Name):
                decorators.append(dec.id)

        # Return annotation
        return_annotation = None
        if node.returns and hasattr(ast, "unparse"):
            return_annotation = ast.unparse(node.returns)

        # Analyze function body
        body_lines = len(node.body)
        complexity = self._estimate_complexity(node)

        # Extract calls, returns, and variable usage
        calls_functions, calls_labels, returns_labels, reads_vars, writes_vars = (
            self._analyze_function_body(node)
        )

        func_def = FunctionDefinition(
            name=node.name,
            params=params,
            file=file_path,
            line=base_line + (node.lineno if hasattr(node, "lineno") else 0),
            context=context,
            docstring=docstring,
            decorators=decorators,
            return_annotation=return_annotation,
            body_lines=body_lines,
            complexity=complexity,
            calls_functions=calls_functions,
            calls_labels=calls_labels,
            returns_labels=returns_labels,
            reads_vars=reads_vars,
            writes_vars=writes_vars,
        )

        return func_def

    def _extract_lambda_from_ast(
        self, node: ast.Lambda, file_path: str, line_num: int
    ) -> Optional[FunctionDefinition]:
        """Extract lambda expression as FunctionDefinition"""

        # Generate synthetic name based on location
        name = f"<lambda@{file_path}:{line_num}>"

        # Extract parameters (simplified for lambdas)
        params = []
        for arg in node.args.args:
            params.append(FunctionParameter(name=arg.arg, kind="positional"))

        # Analyze lambda body
        reads_vars, writes_vars = set(), set()
        for sub_node in ast.walk(node.body):
            if isinstance(sub_node, ast.Name):
                if isinstance(sub_node.ctx, ast.Store):
                    writes_vars.add(sub_node.id)
                else:
                    reads_vars.add(sub_node.id)

        return FunctionDefinition(
            name=name,
            params=params,
            file=file_path,
            line=line_num,
            context=FunctionContext.LAMBDA_EXPR,
            body_lines=1,
            complexity=1,
            reads_vars=reads_vars,
            writes_vars=writes_vars,
        )

    def _estimate_complexity(self, node: ast.FunctionDef) -> int:
        """Estimate cyclomatic complexity (simplified)"""
        complexity = 1  # Base complexity

        for sub_node in ast.walk(node):
            # Add 1 for each branch point
            if isinstance(sub_node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(sub_node, ast.BoolOp):
                complexity += len(sub_node.values) - 1

        return complexity

    def _analyze_function_body(
        self, node: ast.FunctionDef
    ) -> Tuple[List[str], List[str], List[str], Set[str], Set[str]]:
        """Analyze function body for calls, returns, and variable usage"""
        calls_functions = []
        calls_labels = []
        returns_labels = []
        reads_vars = set()
        writes_vars = set()

        for sub_node in ast.walk(node):
            # Function calls
            if isinstance(sub_node, ast.Call):
                func_name = None
                if isinstance(sub_node.func, ast.Name):
                    func_name = sub_node.func.id
                elif isinstance(sub_node.func, ast.Attribute):
                    # Handle renpy.jump(), renpy.call(), etc.
                    parts = []
                    current = sub_node.func
                    while isinstance(current, ast.Attribute):
                        parts.append(current.attr)
                        current = current.value
                    if isinstance(current, ast.Name):
                        parts.append(current.id)
                    func_name = ".".join(reversed(parts))

                if func_name:
                    # Check if it's a label call/jump
                    if func_name in ("renpy.jump", "renpy.call", "jump", "call"):
                        # Try to extract label name from first argument
                        if sub_node.args and isinstance(sub_node.args[0], ast.Constant):
                            calls_labels.append(sub_node.args[0].value)
                    else:
                        calls_functions.append(func_name)

            # Return statements with string literals
            elif isinstance(sub_node, ast.Return):
                if sub_node.value:
                    if isinstance(sub_node.value, ast.Constant) and isinstance(
                        sub_node.value.value, str
                    ):
                        # Direct string return: return "label_name"
                        returns_labels.append(sub_node.value.value)

            # Variable reads/writes
            elif isinstance(sub_node, ast.Name):
                if isinstance(sub_node.ctx, ast.Store):
                    writes_vars.add(sub_node.id)
                elif isinstance(sub_node.ctx, ast.Load):
                    reads_vars.add(sub_node.id)

        return calls_functions, calls_labels, returns_labels, reads_vars, writes_vars

    def _add_function(self, func_def: FunctionDefinition):
        """Add function to index"""
        self.all_functions.append(func_def)

        if func_def.name not in self.functions:
            self.functions[func_def.name] = []
        self.functions[func_def.name].append(func_def)

        log.debug(
            "pfi.function_discovered: %s at %s:%d (context: %s)",
            func_def.name,
            func_def.file,
            func_def.line,
            func_def.context.value,
        )

        # Emit governance event
        if self.enable_governance and self.governance_logger:
            try:
                self.governance_logger.emit_function_discovered(
                    project=str(self.project_root),
                    function_name=func_def.name,
                    file=func_def.file,
                    line=func_def.line,
                    context=func_def.context.value,
                    param_count=len(func_def.params),
                    has_docstring=bool(func_def.docstring),
                )
            except Exception as e:
                log.error(f"Failed to emit governance event: {e}")

    def _export_index(self) -> Dict[str, Any]:
        """Export index to JSON-serializable format"""
        return {
            "functions": [f.to_dict() for f in self.all_functions],
            "by_name": {
                name: [f.to_dict() for f in defs]
                for name, defs in self.functions.items()
            },
            "stats": {
                "total_functions": len(self.all_functions),
                "unique_names": len(self.functions),
                "contexts": {
                    ctx.value: sum(1 for f in self.all_functions if f.context == ctx)
                    for ctx in FunctionContext
                },
            },
        }
