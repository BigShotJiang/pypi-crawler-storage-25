"""Enhanced Function Analyzer - Phase 3B

Extracts rich metadata from functions:
- Parameter type inference (from defaults, annotations, usage)
- Return type detection (from annotations, return statements)
- Effects analysis (stat changes, jumps, calls, variable mutations)
- Usage patterns and common call contexts

Builds on FunctionIndexer and StatEffectAnalyzer with deeper analysis.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .function_indexer import FunctionDefinition, FunctionParameter

try:
    from ...core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)


@dataclass
class InferredType:
    """Represents an inferred type for a parameter or return value"""

    primary_type: str  # "str", "int", "bool", "float", "list", "dict", "Any"
    confidence: str  # "high", "medium", "low"
    source: str  # "annotation", "default", "usage", "inference"
    examples: List[Any] = field(default_factory=list)  # Sample values

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.primary_type,
            "confidence": self.confidence,
            "source": self.source,
            "examples": [str(ex) for ex in self.examples[:3]],  # Limit to 3 examples
        }


@dataclass
class EnhancedParameter:
    """Enhanced parameter with inferred type information"""

    name: str
    declared_type: Optional[str] = None  # From annotation
    inferred_type: Optional[InferredType] = None
    default_value: Optional[Any] = None
    is_optional: bool = False

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "name": self.name,
            "declared_type": self.declared_type,
            "default_value": (
                str(self.default_value) if self.default_value is not None else None
            ),
            "is_optional": self.is_optional,
        }
        if self.inferred_type:
            result["inferred_type"] = self.inferred_type.to_dict()
        return result


@dataclass
class EffectSummary:
    """High-level summary of function effects"""

    modifies_stats: bool = False
    modified_stats: List[str] = field(default_factory=list)
    has_jumps: bool = False
    jump_targets: List[str] = field(default_factory=list)
    has_calls: bool = False
    call_targets: List[str] = field(default_factory=list)
    reads_variables: List[str] = field(default_factory=list)
    writes_variables: List[str] = field(default_factory=list)

    # Natural language description
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "modifies_stats": self.modifies_stats,
            "modified_stats": self.modified_stats,
            "has_jumps": self.has_jumps,
            "jump_targets": self.jump_targets,
            "has_calls": self.has_calls,
            "call_targets": self.call_targets,
            "reads_variables": self.reads_variables,
            "writes_variables": self.writes_variables,
            "description": self.description,
        }


@dataclass
class EnhancedFunctionMetadata:
    """Complete enhanced metadata for a function"""

    name: str
    parameters: List[EnhancedParameter] = field(default_factory=list)
    return_type: Optional[InferredType] = None
    effects: EffectSummary = field(default_factory=EffectSummary)

    # Additional context
    docstring: Optional[str] = None
    complexity: int = 0
    total_lines: int = 0

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "name": self.name,
            "parameters": [p.to_dict() for p in self.parameters],
            "effects": self.effects.to_dict(),
            "docstring": self.docstring,
            "complexity": self.complexity,
            "total_lines": self.total_lines,
        }
        if self.return_type:
            result["return_type"] = self.return_type.to_dict()
        return result


class EnhancedFunctionAnalyzer:
    """Analyze functions for rich metadata extraction"""

    # Type inference patterns
    STRING_PATTERNS = [
        re.compile(r'^["\'].*["\']$'),  # String literals
        re.compile(r".*\.(format|replace|strip|lower|upper)\("),  # String methods
    ]

    NUMBER_PATTERNS = [
        re.compile(r"^\d+$"),  # Integer literals
        re.compile(r"^\d+\.\d+$"),  # Float literals
    ]

    # Common stat variables (Ren'Py game dev)
    COMMON_STATS = {
        "trust",
        "arousal",
        "affection",
        "love",
        "friendship",
        "health",
        "energy",
        "mana",
        "stamina",
        "hunger",
        "score",
        "money",
        "gold",
        "credits",
        "points",
        "reputation",
        "karma",
        "morality",
        "corruption",
    }

    def __init__(self, known_stats: Optional[Set[str]] = None):
        """
        Initialize analyzer.

        Args:
            known_stats: Set of known stat variable names (optional)
        """
        self.known_stats = known_stats or self.COMMON_STATS

    def analyze(
        self, func_def: FunctionDefinition, source_code: str
    ) -> EnhancedFunctionMetadata:
        """
        Perform enhanced analysis on a function.

        Args:
            func_def: FunctionDefinition from FunctionIndexer
            source_code: Full source code of the file

        Returns:
            EnhancedFunctionMetadata with rich type and effect information
        """
        metadata = EnhancedFunctionMetadata(
            name=func_def.name,
            docstring=func_def.docstring,
            complexity=func_def.complexity,
            total_lines=func_def.body_lines,
        )

        # Analyze parameters
        for param in func_def.params:
            enhanced_param = self._analyze_parameter(param, func_def, source_code)
            metadata.parameters.append(enhanced_param)

        # Analyze return type
        metadata.return_type = self._analyze_return_type(func_def, source_code)

        # Analyze effects
        metadata.effects = self._analyze_effects(func_def)

        # Generate description
        metadata.effects.description = self._generate_description(metadata)

        return metadata

    def _analyze_parameter(
        self, param: FunctionParameter, func_def: FunctionDefinition, source_code: str
    ) -> EnhancedParameter:
        """Analyze parameter and infer type"""
        enhanced = EnhancedParameter(
            name=param.name,
            declared_type=param.annotation,
            default_value=param.default,
            is_optional=param.default is not None,
        )

        # If annotation exists, use it with high confidence
        if param.annotation:
            enhanced.inferred_type = InferredType(
                primary_type=param.annotation, confidence="high", source="annotation"
            )
            return enhanced

        # Infer from default value
        if param.default is not None:
            inferred = self._infer_type_from_value(param.default)
            if inferred:
                enhanced.inferred_type = InferredType(
                    primary_type=inferred,
                    confidence="high",
                    source="default",
                    examples=[param.default],
                )
                return enhanced

        # Infer from usage in function body
        usage_type = self._infer_type_from_usage(param.name, func_def)
        if usage_type:
            enhanced.inferred_type = InferredType(
                primary_type=usage_type, confidence="medium", source="usage"
            )
            return enhanced

        # Default to Any
        enhanced.inferred_type = InferredType(
            primary_type="Any", confidence="low", source="inference"
        )

        return enhanced

    def _infer_type_from_value(self, value: Any) -> Optional[str]:
        """Infer Python type from a value"""
        if value is None:
            return None

        value_str = str(value)

        # Check for quoted strings
        if (value_str.startswith('"') and value_str.endswith('"')) or (
            value_str.startswith("'") and value_str.endswith("'")
        ):
            return "str"

        # Check for numbers
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, int):
            return "int"
        if isinstance(value, float):
            return "float"

        # Check string patterns
        try:
            int(value_str)
            return "int"
        except (ValueError, TypeError):
            pass

        try:
            float(value_str)
            return "float"
        except (ValueError, TypeError):
            pass

        # Default string inference
        if isinstance(value, str):
            return "str"

        return None

    def _infer_type_from_usage(
        self, param_name: str, func_def: FunctionDefinition
    ) -> Optional[str]:
        """Infer type from how parameter is used in function"""

        # Check if used in arithmetic operations (likely number)
        if param_name in func_def.writes_vars:
            # Check calls_functions for numeric operations
            for call in func_def.calls_functions:
                if any(
                    op in call
                    for op in ["add", "sub", "mul", "div", "increment", "decrement"]
                ):
                    return "int"

        # Check if used as jump target (likely string)
        if param_name in func_def.calls_labels:
            return "str"

        # Check if compared with known types
        # (This would require deeper AST analysis - placeholder for now)

        return None

    def _analyze_return_type(
        self, func_def: FunctionDefinition, source_code: str
    ) -> Optional[InferredType]:
        """Analyze and infer return type"""

        # Check annotation first
        if func_def.return_annotation:
            return InferredType(
                primary_type=func_def.return_annotation,
                confidence="high",
                source="annotation",
            )

        # Check returns_labels (returns string)
        if func_def.returns_labels:
            return InferredType(
                primary_type="str",
                confidence="high",
                source="inference",
                examples=func_def.returns_labels[:3],
            )

        # If no returns found, assume None
        return InferredType(
            primary_type="None", confidence="medium", source="inference"
        )

    def _analyze_effects(self, func_def: FunctionDefinition) -> EffectSummary:
        """Analyze function effects and generate summary"""
        effects = EffectSummary()

        # Stat modifications
        stat_vars = [
            v
            for v in func_def.writes_vars
            if v.lower() in self.known_stats or "stat" in v.lower()
        ]
        if stat_vars:
            effects.modifies_stats = True
            effects.modified_stats = sorted(stat_vars)

        # Jump targets
        if func_def.calls_labels:
            effects.has_jumps = True
            effects.jump_targets = sorted(func_def.calls_labels)

        # Function calls
        if func_def.calls_functions:
            effects.has_calls = True
            effects.call_targets = sorted(func_def.calls_functions)[:10]  # Limit to 10

        # Variable access
        effects.reads_variables = sorted(list(func_def.reads_vars))[:10]
        effects.writes_variables = sorted(list(func_def.writes_vars))[:10]

        return effects

    def _generate_description(self, metadata: EnhancedFunctionMetadata) -> str:
        """Generate natural language description of function behavior"""
        parts = []

        # Describe what it does
        if metadata.effects.modifies_stats:
            stats_str = ", ".join(metadata.effects.modified_stats[:3])
            if len(metadata.effects.modified_stats) > 3:
                stats_str += f" (+{len(metadata.effects.modified_stats) - 3} more)"
            parts.append(f"Modifies stats: {stats_str}")

        if metadata.effects.has_jumps:
            target = (
                metadata.effects.jump_targets[0]
                if metadata.effects.jump_targets
                else "unknown"
            )
            if len(metadata.effects.jump_targets) > 1:
                parts.append(f"Jumps to {target} or other labels")
            else:
                parts.append(f"Jumps to {target}")

        if metadata.effects.has_calls:
            call_count = len(metadata.effects.call_targets)
            if call_count == 1:
                parts.append(f"Calls {metadata.effects.call_targets[0]}")
            else:
                parts.append(f"Calls {call_count} other functions")

        # Describe parameters
        if metadata.parameters:
            param_count = len(metadata.parameters)
            optional_count = sum(1 for p in metadata.parameters if p.is_optional)
            if optional_count > 0:
                parts.append(
                    f"Takes {param_count} parameters ({optional_count} optional)"
                )
            else:
                parts.append(f"Takes {param_count} parameters")

        if not parts:
            # Fallback description
            if metadata.docstring:
                # Use first line of docstring
                first_line = metadata.docstring.split("\n")[0].strip()
                return first_line[:100]
            return "Function behavior not yet analyzed"

        return ". ".join(parts)


def analyze_function_batch(
    functions: List[FunctionDefinition],
    source_files: Dict[str, str],
    known_stats: Optional[Set[str]] = None,
) -> Dict[str, EnhancedFunctionMetadata]:
    """
    Analyze a batch of functions.

    Args:
        functions: List of FunctionDefinition objects
        source_files: Dict mapping file path to source code
        known_stats: Optional set of known stat variable names

    Returns:
        Dict mapping function name to EnhancedFunctionMetadata
    """
    analyzer = EnhancedFunctionAnalyzer(known_stats)
    results = {}

    for func in functions:
        try:
            # Get source code for function's file
            source = source_files.get(func.file, "")

            # Analyze
            metadata = analyzer.analyze(func, source)
            results[func.name] = metadata

        except Exception as e:
            log.error(
                "enhanced_analyzer.error",
                extra={"function": func.name, "error": str(e)},
            )

    return results
