"""PFI Exporter - Export function index to JSON"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from .call_graph import CallGraph
from .consistency_checker import ConsistencyChecker
from .function_indexer import FunctionIndexer
from .stat_effect_analyzer import StatEffectAnalyzer


class PFIExporter:
    """Export Project Function Index to various formats"""

    def __init__(
        self,
        indexer: FunctionIndexer,
        analyzer: Optional[StatEffectAnalyzer] = None,
        checker: Optional[ConsistencyChecker] = None,
        call_graph: Optional[CallGraph] = None,
    ):
        """
        Initialize exporter.

        Args:
            indexer: Function indexer instance
            analyzer: Optional stat effect analyzer
            checker: Optional consistency checker
            call_graph: Optional call graph builder
        """
        self.indexer = indexer
        self.analyzer = analyzer
        self.checker = checker
        self.call_graph = call_graph

    def export_full(self) -> Dict[str, Any]:
        """
        Export complete function index with all analysis data.

        Returns:
            Complete PFI data structure
        """
        data = {"version": "0.8.9", "functions": []}

        # Export each function
        for func in self.indexer.all_functions:
            func_data = func.to_dict()

            # Add analysis data if available
            if self.analyzer:
                analysis = self.analyzer.get_analysis(func.name)
                if analysis:
                    func_data["analysis"] = analysis.to_dict()

            data["functions"].append(func_data)

        # Add index summary
        data["summary"] = {
            "total_functions": len(self.indexer.all_functions),
            "unique_names": len(self.indexer.functions),
            "by_context": {},
        }

        # Count by context
        from .function_indexer import FunctionContext

        for ctx in FunctionContext:
            count = sum(1 for f in self.indexer.all_functions if f.context == ctx)
            if count > 0:
                data["summary"]["by_context"][ctx.value] = count

        # Add stat effects summary
        if self.analyzer:
            data["summary"]["stat_effects"] = self.analyzer.export_all()["summary"]

        # Add consistency warnings
        if self.checker:
            data["warnings"] = self.checker.export_warnings()

        # Add call graph
        if self.call_graph:
            data["call_graph"] = self.call_graph.export_graph()

        return data

    def export_compact(self) -> Dict[str, Any]:
        """
        Export compact format with just essential data for VS Code UI.

        Returns:
            Compact PFI data
        """
        functions = []

        for func in self.indexer.all_functions:
            # Get stat effects if available
            stats_affected = []
            if self.analyzer:
                analysis = self.analyzer.get_analysis(func.name)
                if analysis:
                    stats_affected = sorted(list(analysis.stats_modified))

            functions.append(
                {
                    "name": func.name,
                    "params": [p.name for p in func.params],
                    "stats": stats_affected,
                    "usages": func.total_usages,
                    "file": func.file,
                    "line": func.line,
                    "signature": func.signature,
                }
            )

        return {"version": "0.8.9", "functions": functions}

    def export_by_stat(self) -> Dict[str, List[str]]:
        """
        Export functions grouped by stats they affect.

        Returns:
            Dict mapping stat name to list of function names
        """
        if not self.analyzer:
            return {}

        by_stat = {}
        for func in self.indexer.all_functions:
            analysis = self.analyzer.get_analysis(func.name)
            if analysis:
                for stat in analysis.stats_modified:
                    if stat not in by_stat:
                        by_stat[stat] = []
                    by_stat[stat].append(func.name)

        return by_stat

    def save_to_file(self, output_path: Path, format: str = "full"):
        """
        Save function index to JSON file.

        Args:
            output_path: Path to output JSON file
            format: Export format ("full", "compact", "by_stat")
        """
        if format == "full":
            data = self.export_full()
        elif format == "compact":
            data = self.export_compact()
        elif format == "by_stat":
            data = self.export_by_stat()
        else:
            raise ValueError(f"Unknown export format: {format}")

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def save_call_graph_dot(self, output_path: Path):
        """
        Save call graph in DOT format for visualization.

        Args:
            output_path: Path to output .dot file
        """
        if not self.call_graph:
            raise ValueError("Call graph not available")

        dot_content = self.call_graph.export_dot()

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(dot_content)
