"""Governance Event Integration for PFI Operations - v0.8.9

Logs function discovery, analysis, and consistency events to the Policy Engine for audit trail.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from ...core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)


@dataclass
class PFIGovernanceEvent:
    """Represents a governance event for PFI operations."""

    event_type: str
    """Event type: FUNCTION_DISCOVERED, FUNCTION_ANALYZED, FUNCTION_WARNING, PFI_INDEXED"""

    correlation_id: str
    """Unique correlation ID for tracking"""

    timestamp: str
    """ISO8601 timestamp"""

    actor: str
    """Actor performing the action"""

    project: str
    """Project path"""

    payload: Dict[str, Any]
    """Event-specific payload"""

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return asdict(self)

    @classmethod
    def create_discovered_event(
        cls,
        project: str,
        function_name: str,
        file: str,
        line: int,
        context: str,
        param_count: int,
        has_docstring: bool,
        actor: str = "branchpy-cli",
        correlation_id: Optional[str] = None,
    ) -> PFIGovernanceEvent:
        """Create FUNCTION_DISCOVERED event.

        Args:
            project: Project path
            function_name: Name of discovered function
            file: File path
            line: Line number
            context: Function context (python_inline, init_block, etc.)
            param_count: Number of parameters
            has_docstring: Whether function has docstring
            actor: Actor performing discovery
            correlation_id: Optional correlation ID

        Returns:
            Governance event
        """
        return cls(
            event_type="FUNCTION_DISCOVERED",
            correlation_id=correlation_id or str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "function_name": function_name,
                "file": file,
                "line": line,
                "context": context,
                "param_count": param_count,
                "has_docstring": has_docstring,
            },
        )

    @classmethod
    def create_analyzed_event(
        cls,
        project: str,
        function_name: str,
        is_stat_modifier: bool,
        stats_modified: List[str],
        has_jumps: bool,
        has_calls: bool,
        actor: str = "branchpy-cli",
        correlation_id: Optional[str] = None,
    ) -> PFIGovernanceEvent:
        """Create FUNCTION_ANALYZED event.

        Args:
            project: Project path
            function_name: Name of analyzed function
            is_stat_modifier: Whether function modifies stats
            stats_modified: List of modified stat names
            has_jumps: Whether function contains jumps
            has_calls: Whether function contains calls
            actor: Actor performing analysis
            correlation_id: Optional correlation ID

        Returns:
            Governance event
        """
        return cls(
            event_type="FUNCTION_ANALYZED",
            correlation_id=correlation_id or str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "function_name": function_name,
                "is_stat_modifier": is_stat_modifier,
                "stats_modified": stats_modified,
                "has_jumps": has_jumps,
                "has_calls": has_calls,
            },
        )

    @classmethod
    def create_warning_event(
        cls,
        project: str,
        function_name: str,
        warning_type: str,
        warning_level: str,
        message: str,
        file: str,
        line: int,
        related_functions: List[str],
        actor: str = "branchpy-cli",
        correlation_id: Optional[str] = None,
    ) -> PFIGovernanceEvent:
        """Create FUNCTION_WARNING event.

        Args:
            project: Project path
            function_name: Function with warning
            warning_type: Type of warning (SIGNATURE_DRIFT, etc.)
            warning_level: Severity level (ERROR, WARNING, INFO)
            message: Warning message
            file: File path
            line: Line number
            related_functions: Other involved functions
            actor: Actor detecting warning
            correlation_id: Optional correlation ID

        Returns:
            Governance event
        """
        return cls(
            event_type="FUNCTION_WARNING",
            correlation_id=correlation_id or str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "function_name": function_name,
                "warning_type": warning_type,
                "warning_level": warning_level,
                "message": message,
                "file": file,
                "line": line,
                "related_functions": related_functions,
            },
        )

    @classmethod
    def create_indexed_event(
        cls,
        project: str,
        total_functions: int,
        stat_modifiers: int,
        unused_functions: int,
        redefined_functions: int,
        total_warnings: int,
        files_scanned: int,
        duration_ms: float,
        actor: str = "branchpy-cli",
        correlation_id: Optional[str] = None,
    ) -> PFIGovernanceEvent:
        """Create PFI_INDEXED event.

        Args:
            project: Project path
            total_functions: Total functions discovered
            stat_modifiers: Number of stat-modifying functions
            unused_functions: Number of unused functions
            redefined_functions: Number of redefined functions
            total_warnings: Total warnings generated
            files_scanned: Number of .rpy files scanned
            duration_ms: Indexing duration in milliseconds
            actor: Actor performing indexing
            correlation_id: Optional correlation ID

        Returns:
            Governance event
        """
        return cls(
            event_type="PFI_INDEXED",
            correlation_id=correlation_id or str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "total_functions": total_functions,
                "stat_modifiers": stat_modifiers,
                "unused_functions": unused_functions,
                "redefined_functions": redefined_functions,
                "total_warnings": total_warnings,
                "files_scanned": files_scanned,
                "duration_ms": duration_ms,
            },
        )


class GovernanceLogger:
    """Logs PFI governance events to JSONL audit log."""

    def __init__(self, log_path: Optional[Path] = None):
        """Initialize governance logger.

        Args:
            log_path: Path to JSONL log file (default: ~/.branchpy/pfi_governance.jsonl)
        """
        if log_path is None:
            log_dir = Path.home() / ".branchpy"
            log_dir.mkdir(exist_ok=True)
            log_path = log_dir / "pfi_governance.jsonl"

        self.log_path = Path(log_path)
        log.info(f"PFI governance logger initialized: {self.log_path}")

    def emit(self, event: PFIGovernanceEvent) -> None:
        """Emit governance event to JSONL log.

        Args:
            event: Governance event to log
        """
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event.to_dict()) + "\n")
            log.debug(f"Emitted governance event: {event.event_type}")
        except Exception as e:
            log.error(f"Failed to emit governance event: {e}")

    def emit_function_discovered(
        self,
        project: str,
        function_name: str,
        file: str,
        line: int,
        context: str,
        param_count: int,
        has_docstring: bool,
        correlation_id: Optional[str] = None,
    ) -> None:
        """Emit function discovered event.

        Args:
            project: Project path
            function_name: Function name
            file: File path
            line: Line number
            context: Function context
            param_count: Number of parameters
            has_docstring: Has docstring
            correlation_id: Optional correlation ID
        """
        event = PFIGovernanceEvent.create_discovered_event(
            project=project,
            function_name=function_name,
            file=file,
            line=line,
            context=context,
            param_count=param_count,
            has_docstring=has_docstring,
            correlation_id=correlation_id,
        )
        self.emit(event)

    def emit_function_analyzed(
        self,
        project: str,
        function_name: str,
        is_stat_modifier: bool,
        stats_modified: List[str],
        has_jumps: bool,
        has_calls: bool,
        correlation_id: Optional[str] = None,
    ) -> None:
        """Emit function analyzed event.

        Args:
            project: Project path
            function_name: Function name
            is_stat_modifier: Modifies stats
            stats_modified: Modified stats
            has_jumps: Has jumps
            has_calls: Has calls
            correlation_id: Optional correlation ID
        """
        event = PFIGovernanceEvent.create_analyzed_event(
            project=project,
            function_name=function_name,
            is_stat_modifier=is_stat_modifier,
            stats_modified=stats_modified,
            has_jumps=has_jumps,
            has_calls=has_calls,
            correlation_id=correlation_id,
        )
        self.emit(event)

    def emit_function_warning(
        self,
        project: str,
        function_name: str,
        warning_type: str,
        warning_level: str,
        message: str,
        file: str,
        line: int,
        related_functions: List[str],
        correlation_id: Optional[str] = None,
    ) -> None:
        """Emit function warning event.

        Args:
            project: Project path
            function_name: Function name
            warning_type: Warning type
            warning_level: Severity level
            message: Warning message
            file: File path
            line: Line number
            related_functions: Related functions
            correlation_id: Optional correlation ID
        """
        event = PFIGovernanceEvent.create_warning_event(
            project=project,
            function_name=function_name,
            warning_type=warning_type,
            warning_level=warning_level,
            message=message,
            file=file,
            line=line,
            related_functions=related_functions,
            correlation_id=correlation_id,
        )
        self.emit(event)

    def emit_pfi_indexed(
        self,
        project: str,
        total_functions: int,
        stat_modifiers: int,
        unused_functions: int,
        redefined_functions: int,
        total_warnings: int,
        files_scanned: int,
        duration_ms: float,
        correlation_id: Optional[str] = None,
    ) -> None:
        """Emit PFI indexed event.

        Args:
            project: Project path
            total_functions: Total functions
            stat_modifiers: Stat modifiers count
            unused_functions: Unused count
            redefined_functions: Redefined count
            total_warnings: Total warnings
            files_scanned: Files scanned
            duration_ms: Duration in ms
            correlation_id: Optional correlation ID
        """
        event = PFIGovernanceEvent.create_indexed_event(
            project=project,
            total_functions=total_functions,
            stat_modifiers=stat_modifiers,
            unused_functions=unused_functions,
            redefined_functions=redefined_functions,
            total_warnings=total_warnings,
            files_scanned=files_scanned,
            duration_ms=duration_ms,
            correlation_id=correlation_id,
        )
        self.emit(event)


# Global governance logger instance
_governance_logger: Optional[GovernanceLogger] = None


def get_governance_logger() -> GovernanceLogger:
    """Get or create global governance logger instance."""
    global _governance_logger
    if _governance_logger is None:
        _governance_logger = GovernanceLogger()
    return _governance_logger
