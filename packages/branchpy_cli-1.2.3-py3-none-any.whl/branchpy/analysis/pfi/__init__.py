"""Project Function Index (PFI) - v0.8.9

Comprehensive function discovery, classification, and indexing system for Ren'Py projects.
Provides semantic awareness for Stats 2.x, Compare, Governance, and VS Code UI.

Components:
- function_indexer: Parse and extract function definitions from .rpy files
- stat_effect_analyzer: Detect stat mutations and control flow within functions
- consistency_checker: Find signature drift, dead functions, shadowing
- exporter: Export to JSON for API and VS Code panel consumption
- call_graph: Build function call graph for dependency analysis

v0.8.9: Initial release - Function discovery and indexing MVP.
"""

from .call_graph import CallEdge, CallGraph
from .call_site_analyzer import CallSite, CallSiteAnalyzer, FunctionUsage
from .consistency_checker import ConsistencyChecker, ConsistencyWarning
from .enhanced_analyzer import (
    EffectSummary,
    EnhancedFunctionAnalyzer,
    EnhancedFunctionMetadata,
    EnhancedParameter,
    InferredType,
    analyze_function_batch,
)
from .exporter import PFIExporter
from .function_indexer import FunctionDefinition, FunctionIndexer
from .governance import GovernanceLogger, PFIGovernanceEvent, get_governance_logger
from .stat_effect_analyzer import StatEffect, StatEffectAnalyzer

__all__ = [
    "FunctionIndexer",
    "FunctionDefinition",
    "StatEffectAnalyzer",
    "StatEffect",
    "ConsistencyChecker",
    "ConsistencyWarning",
    "PFIExporter",
    "CallGraph",
    "CallEdge",
    "CallSiteAnalyzer",
    "CallSite",
    "FunctionUsage",
    "EnhancedFunctionAnalyzer",
    "EnhancedFunctionMetadata",
    "EnhancedParameter",
    "InferredType",
    "EffectSummary",
    "analyze_function_batch",
    "PFIGovernanceEvent",
    "GovernanceLogger",
    "get_governance_logger",
]

__version__ = "0.8.9"
