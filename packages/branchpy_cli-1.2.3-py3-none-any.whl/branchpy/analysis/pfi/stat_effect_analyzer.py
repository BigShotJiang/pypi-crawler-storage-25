"""Stat Effect Analyzer - Detect stat mutations and control flow in functions"""

from __future__ import annotations

import ast
import textwrap
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from .function_indexer import FunctionDefinition

try:
    from ...core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)


class EffectType(Enum):
    """Type of side effect"""

    STAT_INCREMENT = "stat_increment"  # var += value
    STAT_DECREMENT = "stat_decrement"  # var -= value
    STAT_ASSIGN = "stat_assign"  # var = value
    JUMP = "jump"  # renpy.jump()
    CALL = "call"  # renpy.call()
    CONDITIONAL = "conditional"  # if/elif/else
    LOOP = "loop"  # while/for
    RETURN = "return"

    # Media Intelligence effects (Phase B - v0.9.0+)
    MEDIA_SHOW = "media_show"  # scene/show, renpy.show()
    MEDIA_HIDE = "media_hide"  # hide, renpy.hide()
    MEDIA_PLAY = "media_play"  # play/queue, renpy.music.play()
    MEDIA_STOP = "media_stop"  # stop, renpy.music.stop()
    MEDIA_DEFINE = "media_define"  # image definition
    MEDIA_LOAD = "media_load"  # preload/load operations
    MEDIA_ASSIGN = "media_assign"  # variable assignment of media asset


@dataclass
class StatEffect:
    """Represents a side effect in a function"""

    effect_type: EffectType
    variable: Optional[str] = None  # For stat changes
    target: Optional[str] = None  # For jumps/calls
    value: Optional[Any] = None  # For assignments
    condition: Optional[str] = None  # For conditionals
    line: int = 0  # Relative line in function

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary with stable, clean keys"""
        return {
            "type": self.effect_type.value,
            "variable": self.variable or "",
            "target": self.target or "",
            "value": str(self.value) if self.value is not None else "",
            "condition": self.condition or "",
            "line": self.line,
        }


@dataclass
class FunctionAnalysis:
    """Complete analysis of a function's effects"""

    function_name: str
    stat_effects: List[StatEffect] = field(default_factory=list)
    control_flow_effects: List[StatEffect] = field(default_factory=list)
    stats_modified: Set[str] = field(default_factory=set)
    labels_accessed: Set[str] = field(default_factory=set)

    # Derived metrics
    is_stat_modifier: bool = False
    is_control_flow: bool = False
    complexity_score: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary with sorted effects for deterministic output"""
        # Sort effects by line number, then by variable/target name
        sorted_stat_effects = sorted(
            self.stat_effects, key=lambda e: (e.line, e.variable or "")
        )
        sorted_cf_effects = sorted(
            self.control_flow_effects, key=lambda e: (e.line, e.target or "")
        )

        return {
            "function_name": self.function_name,
            "stat_effects": [e.to_dict() for e in sorted_stat_effects],
            "control_flow_effects": [e.to_dict() for e in sorted_cf_effects],
            "stats_modified": sorted(list(self.stats_modified)),
            "labels_accessed": sorted(list(self.labels_accessed)),
            "is_stat_modifier": self.is_stat_modifier,
            "is_control_flow": self.is_control_flow,
            "complexity_score": self.complexity_score,
        }


class EffectVisitor(ast.NodeVisitor):
    """AST visitor for extracting side effects from function bodies"""

    def __init__(self, known_stats: Set[str]):
        self.known_stats = known_stats
        self.stat_effects: List[StatEffect] = []
        self.control_flow_effects: List[StatEffect] = []
        self.stats_modified: Set[str] = set()
        self.labels_accessed: Set[str] = set()

    def _name_of(self, node: ast.AST) -> Optional[str]:
        """Extract dotted name from AST node (handles Name, Attribute, Subscript)"""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            base = self._name_of(node.value)
            return f"{base}.{node.attr}" if base else None
        if isinstance(node, ast.Subscript):
            base = self._name_of(node.value)
            return f"{base}[]" if base else None
        return None

    def _record_stat_effect(
        self,
        effect_type: EffectType,
        var_name: str,
        value: Any = None,
        op: Optional[str] = None,
        line: int = 0,
    ):
        """Record a stat modification effect"""
        effect = StatEffect(
            effect_type=effect_type, variable=var_name, value=value, line=line
        )
        self.stat_effects.append(effect)
        if var_name in self.known_stats:
            self.stats_modified.add(var_name)

    def visit_Assign(self, node: ast.Assign):
        """Handle regular assignments (x = 5, a.b = 10, etc.)"""
        for target in node.targets:
            var_name = self._name_of(target)
            if var_name:
                # Extract value
                value = None
                if isinstance(node.value, ast.Constant):
                    value = node.value.value
                elif hasattr(ast, "unparse"):
                    try:
                        value = ast.unparse(node.value)
                    except Exception:
                        pass

                self._record_stat_effect(
                    EffectType.STAT_ASSIGN,
                    var_name,
                    value=value,
                    line=node.lineno if hasattr(node, "lineno") else 0,
                )
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign):
        """Handle annotated assignments (x: int = 5)"""
        var_name = self._name_of(node.target)
        if var_name and node.value:  # Only if actually assigned
            value = None
            if isinstance(node.value, ast.Constant):
                value = node.value.value
            elif hasattr(ast, "unparse"):
                try:
                    value = ast.unparse(node.value)
                except Exception:
                    pass

            self._record_stat_effect(
                EffectType.STAT_ASSIGN,
                var_name,
                value=value,
                line=node.lineno if hasattr(node, "lineno") else 0,
            )
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign):
        """Handle augmented assignments (x += 5, x -= 3, etc.)"""
        var_name = self._name_of(node.target)
        if var_name:
            # Determine effect type
            if isinstance(node.op, ast.Add):
                effect_type = EffectType.STAT_INCREMENT
            elif isinstance(node.op, ast.Sub):
                effect_type = EffectType.STAT_DECREMENT
            else:
                effect_type = EffectType.STAT_ASSIGN

            # Extract value
            value = None
            if isinstance(node.value, ast.Constant):
                value = node.value.value
            elif hasattr(ast, "unparse"):
                try:
                    value = ast.unparse(node.value)
                except Exception:
                    pass

            self._record_stat_effect(
                effect_type,
                var_name,
                value=value,
                line=node.lineno if hasattr(node, "lineno") else 0,
            )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        """Handle function calls (jumps, calls)"""
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name):
                func_name = f"{node.func.value.id}.{node.func.attr}"

        if func_name in ("renpy.jump", "jump"):
            # Extract target label
            target = None
            if node.args and isinstance(node.args[0], ast.Constant):
                const_value = node.args[0].value
                if isinstance(const_value, str):
                    target = const_value

            effect = StatEffect(
                effect_type=EffectType.JUMP,
                target=target,
                line=node.lineno if hasattr(node, "lineno") else 0,
            )
            self.control_flow_effects.append(effect)
            if target:
                self.labels_accessed.add(target)

        elif func_name in ("renpy.call", "call"):
            # Extract target label
            target = None
            if node.args and isinstance(node.args[0], ast.Constant):
                const_value = node.args[0].value
                if isinstance(const_value, str):
                    target = const_value

            effect = StatEffect(
                effect_type=EffectType.CALL,
                target=target,
                line=node.lineno if hasattr(node, "lineno") else 0,
            )
            self.control_flow_effects.append(effect)
            if target:
                self.labels_accessed.add(target)

        self.generic_visit(node)

    def visit_If(self, node: ast.If):
        """Handle conditionals"""
        condition = None
        if hasattr(ast, "unparse"):
            try:
                condition = ast.unparse(node.test)
            except Exception:
                pass

        effect = StatEffect(
            effect_type=EffectType.CONDITIONAL,
            condition=condition,
            line=node.lineno if hasattr(node, "lineno") else 0,
        )
        self.control_flow_effects.append(effect)
        self.generic_visit(node)

    def visit_While(self, node: ast.While):
        """Handle while loops"""
        effect = StatEffect(
            effect_type=EffectType.LOOP,
            line=node.lineno if hasattr(node, "lineno") else 0,
        )
        self.control_flow_effects.append(effect)
        self.generic_visit(node)

    def visit_For(self, node: ast.For):
        """Handle for loops"""
        effect = StatEffect(
            effect_type=EffectType.LOOP,
            line=node.lineno if hasattr(node, "lineno") else 0,
        )
        self.control_flow_effects.append(effect)
        self.generic_visit(node)

    def visit_Return(self, node: ast.Return):
        """Handle return statements"""
        value = None
        if node.value and hasattr(ast, "unparse"):
            try:
                value = ast.unparse(node.value)
            except Exception:
                pass

        effect = StatEffect(
            effect_type=EffectType.RETURN,
            value=value,
            line=node.lineno if hasattr(node, "lineno") else 0,
        )
        self.control_flow_effects.append(effect)
        self.generic_visit(node)


class StatEffectAnalyzer:
    """Analyze functions for stat mutations and control flow effects"""

    # Common stat variable patterns
    COMMON_STATS = {
        "trust",
        "affection",
        "relationship",
        "score",
        "points",
        "level",
        "boldness",
        "obedience",
        "loyalty",
        "friendship",
        "love",
        "respect",
        "corruption",
        "purity",
        "reputation",
        "money",
        "health",
        "energy",
        "happiness",
        "stress",
        "confidence",
        "intelligence",
        "strength",
    }

    def __init__(
        self, known_stats: Optional[Set[str]] = None, enable_governance: bool = True
    ):
        """
        Initialize analyzer.

        Args:
            known_stats: Set of known stat variable names (optional)
            enable_governance: Enable governance event logging
        """
        self.known_stats = known_stats or self.COMMON_STATS.copy()
        self.analyses: Dict[str, FunctionAnalysis] = {}
        self.enable_governance = enable_governance
        self.governance_logger = None

        if enable_governance:
            try:
                from .governance import get_governance_logger

                self.governance_logger = get_governance_logger()
            except ImportError:
                log.warning("pfi.governance_unavailable")
                self.enable_governance = False

    def analyze_function(
        self, func_def: FunctionDefinition, source_code: str
    ) -> FunctionAnalysis:
        """
        Analyze a function for stat effects and control flow.

        Args:
            func_def: Function definition to analyze
            source_code: Full source code of the file containing the function

        Returns:
            FunctionAnalysis with detected effects
        """
        analysis = FunctionAnalysis(function_name=func_def.name)

        # Parse function body from source if possible
        try:
            # Extract function code (simplified - may need refinement)
            lines = source_code.split("\n")
            if func_def.line > 0 and func_def.line <= len(lines):
                # Try to parse the function
                # Note: This is simplified - real implementation should extract full function body
                func_code = self._extract_function_code(lines, func_def.line - 1)
                if func_code:
                    tree = ast.parse(func_code)
                    self._analyze_ast(tree, analysis)
        except Exception as e:
            log.warning(
                "pfi.stat_analysis_error",
                extra={"function": func_def.name, "error": str(e)},
            )

        # Use pre-extracted data from func_def
        analysis.stats_modified = func_def.writes_vars.intersection(self.known_stats)
        analysis.labels_accessed = set(func_def.calls_labels)

        # Set flags
        analysis.is_stat_modifier = len(analysis.stats_modified) > 0
        analysis.is_control_flow = (
            len(analysis.labels_accessed) > 0 or len(analysis.control_flow_effects) > 0
        )
        analysis.complexity_score = func_def.complexity

        # Store analysis
        self.analyses[func_def.name] = analysis

        log.debug(
            "pfi.function_analyzed",
            extra={
                "function": func_def.name,
                "stats": len(analysis.stats_modified),
                "labels": len(analysis.labels_accessed),
            },
        )

        # Emit governance event
        if self.enable_governance and self.governance_logger:
            try:
                self.governance_logger.emit_function_analyzed(
                    project=str(getattr(func_def, "project_root", ".")),
                    function_name=func_def.name,
                    is_stat_modifier=analysis.is_stat_modifier,
                    stats_modified=sorted(list(analysis.stats_modified)),
                    has_jumps=any(
                        e.effect_type == EffectType.JUMP
                        for e in analysis.control_flow_effects
                    ),
                    has_calls=any(
                        e.effect_type == EffectType.CALL
                        for e in analysis.control_flow_effects
                    ),
                )
            except Exception as e:
                log.error(f"Failed to emit governance event: {e}")

        return analysis

    def _extract_function_code(
        self, lines: List[str], start_line: int
    ) -> Optional[str]:
        """
        Extract function code from source lines.

        Args:
            lines: All source lines
            start_line: 0-based line number of function def

        Returns:
            Function code as string, or None
        """
        if start_line >= len(lines):
            return None

        # Get base indentation
        def_line = lines[start_line]
        base_indent = len(def_line) - len(def_line.lstrip())

        # Collect function lines
        func_lines = [def_line]
        for i in range(start_line + 1, len(lines)):
            line = lines[i]
            if not line.strip():  # Empty line
                func_lines.append(line)
                continue

            current_indent = len(line) - len(line.lstrip())
            if current_indent <= base_indent and line.strip():
                # Dedented - function ends
                break

            func_lines.append(line)

        # Normalize: unify newlines, tabs->spaces, dedent, strip leading blanks
        snippet = "".join(func_lines).replace("\r\n", "\n").replace("\r", "\n")
        snippet = snippet.replace("\t", "    ")
        return textwrap.dedent(snippet).lstrip("\n")

    def _analyze_ast(self, tree: ast.AST, analysis: FunctionAnalysis):
        """Walk AST and extract effects using visitor pattern"""
        visitor = EffectVisitor(self.known_stats)
        visitor.visit(tree)

        # Transfer results to analysis
        analysis.stat_effects.extend(visitor.stat_effects)
        analysis.control_flow_effects.extend(visitor.control_flow_effects)
        analysis.stats_modified.update(visitor.stats_modified)
        analysis.labels_accessed.update(visitor.labels_accessed)

    def get_analysis(self, function_name: str) -> Optional[FunctionAnalysis]:
        """Get analysis results for a function"""
        return self.analyses.get(function_name)

    def export_all(self) -> Dict[str, Any]:
        """Export all analyses to JSON-serializable format"""
        return {
            "analyses": {
                name: analysis.to_dict() for name, analysis in self.analyses.items()
            },
            "summary": {
                "total_functions": len(self.analyses),
                "stat_modifiers": sum(
                    1 for a in self.analyses.values() if a.is_stat_modifier
                ),
                "control_flow": sum(
                    1 for a in self.analyses.values() if a.is_control_flow
                ),
                "stats_touched": len(
                    set(
                        stat
                        for a in self.analyses.values()
                        for stat in a.stats_modified
                    )
                ),
            },
        }
