"""
Semantic Edge Reconciliation Pipeline (ERP)

Phase 1: Edge schema normalization and dedup
- Normalizes edges to include origin, confidence, meta fields
- Deduplicates edges using canonical key (src, dst, kind)
- Filters edges with missing endpoints

Future phases (Phase 2+):
- PFI edge extraction and merge
- SAE edge extraction and merge
- Synthetic entry node generation for unresolved dynamics
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

# Ranking constants for edge preference when dedupping
ORIGIN_RANK = {"cfg": 3, "pfi": 2, "sae": 1}
CONF_RANK = {"definite": 3, "probable": 2, "possible": 1}


def extract_pfi_edges(pfi_result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract edges from PFI (Project Function Index) results.

    PFI provides inter-procedural call targets and inferred flows.
    Handles two possible PFI result shapes:

    Shape 1 (indexed):
        {
            "call_index": {"label_a": ["label_b", "label_c"]},
            "jump_index": {"label_x": ["label_y"]}
        }

    Shape 2 (edge list):
        {
            "edges": [
                {"src": "label_a", "dst": "label_b", "kind": "call"},
                ...
            ]
        }

    Returns:
        List of edges with src, dst, kind, edge_type, meta fields.
        SER will inject origin="pfi" and confidence="probable".

    Args:
        pfi_result: Output from PFI analyzer

    Returns:
        List of normalized edge dicts
    """
    if not pfi_result:
        return []

    edges = []

    # Try Shape 2 first: direct edge list
    if "edges" in pfi_result:
        for pfi_edge in pfi_result.get("edges", []):
            if not isinstance(pfi_edge, dict):
                continue
            edge = {
                "src": pfi_edge.get("src", ""),
                "dst": pfi_edge.get("dst", ""),
                "kind": pfi_edge.get("kind", "unknown"),
                "edge_type": pfi_edge.get("edge_type", pfi_edge.get("kind", "unknown")),
                "meta": {
                    "pfi_source": "edge_list",
                },
            }
            if edge["src"] and edge["dst"]:
                edges.append(edge)
        return edges

    # Try Shape 1: call_index and jump_index
    call_index = pfi_result.get("call_index", {})
    jump_index = pfi_result.get("jump_index", {})
    call_sites = pfi_result.get("call_sites", [])  # D11: per-site with file/line
    dynamic_call_sites = pfi_result.get("dynamic_call_sites", [])  # D11: dynamic calls

    # Process call_sites if present (D11: carries file/line for call_bundle_id).
    # Fall back to call_index if call_sites is not populated.
    if call_sites:
        for site in call_sites:
            src = site.get("src", "")
            dst = site.get("dst", "")
            if src and dst:
                edges.append(
                    {
                        "src": src,
                        "dst": dst,
                        "kind": "call",
                        "edge_type": "call",
                        "meta": {
                            "pfi_source": "call_sites",
                            "call_file": site.get("file"),
                            "call_line": site.get("line"),
                        },
                    }
                )
    else:
        # Process call_index: {label: [targets]} (no per-site line info)
        for src, targets in call_index.items():
            if not src or not isinstance(targets, list):
                continue
            for dst in targets:
                if dst:
                    edges.append(
                        {
                            "src": src,
                            "dst": dst,
                            "kind": "call",
                            "edge_type": "call",
                            "meta": {
                                "pfi_source": "call_index",
                            },
                        }
                    )

    # D11: emit DYNAMIC_CALL edges from dynamic_call_sites.
    for dyn in dynamic_call_sites:
        src = dyn.get("src", "")
        if src:
            edges.append(
                {
                    "src": src,
                    "dst": "?",
                    "kind": "dynamic_call",
                    "edge_type": "dynamic_call",
                    "meta": {
                        "pfi_source": "dynamic_call_sites",
                        "call_file": dyn.get("file"),
                        "call_line": dyn.get("line"),
                    },
                }
            )

    # Process jump_index: {label: [targets]}
    for src, targets in jump_index.items():
        if not src or not isinstance(targets, list):
            continue
        for dst in targets:
            if dst:
                edges.append(
                    {
                        "src": src,
                        "dst": dst,
                        "kind": "jump",
                        "edge_type": "jump",
                        "meta": {
                            "pfi_source": "jump_index",
                        },
                    }
                )

    return edges


def extract_sae_edges(sae_result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract edges from SAE (Semantic Analysis Engine) results.

    SAE provides inferred edges based on semantic patterns and data flow analysis.
    Permissive adapter handles multiple possible result shapes:

    Shape 1 (edge list):
        {
            "edges": [
                {"src": "label_a", "dst": "label_b", "kind": "inferred"},
                ...
            ]
        }

    Shape 2 (inferred flows):
        {
            "inferred_flows": [
                {"from_label": "label_a", "to_label": "label_b", "pattern": "..."},
                ...
            ]
        }

    Per-edge fields (all optional):
        - src / from_label: source label
        - dst / to_label: destination label
        - kind: edge type (defaults to "inferred")
        - confidence: numeric confidence (stored in meta, not used for hierarchy)
        - pattern / analysis_id: semantic pattern that inferred the edge

    Returns:
        List of edges with src, dst, kind, edge_type, meta fields.
        SER will inject origin="sae" and confidence="possible".

    Args:
        sae_result: Output from SAE analyzer

    Returns:
        List of normalized edge dicts
    """
    if not sae_result:
        return []

    edges = []

    # Try Shape 1: direct edge list
    if "edges" in sae_result:
        for sae_edge in sae_result.get("edges", []):
            if not isinstance(sae_edge, dict):
                continue
            # Flexible field names: src or from_label
            src = sae_edge.get("src") or sae_edge.get("from_label", "")
            dst = sae_edge.get("dst") or sae_edge.get("to_label", "")
            if src and dst:
                edge = {
                    "src": src,
                    "dst": dst,
                    "kind": sae_edge.get("kind", "inferred"),
                    "edge_type": sae_edge.get(
                        "edge_type", sae_edge.get("kind", "inferred")
                    ),
                    "meta": {
                        "sae_source": "edge_list",
                    },
                }
                # Optional fields stored in meta (not used for hierarchy, just provenance)
                if "confidence" in sae_edge:
                    edge["meta"]["sae_confidence"] = sae_edge["confidence"]
                if "pattern" in sae_edge:
                    edge["meta"]["sae_pattern"] = sae_edge["pattern"]
                if "analysis_id" in sae_edge:
                    edge["meta"]["sae_analysis_id"] = sae_edge["analysis_id"]
                edges.append(edge)
        return edges

    # Try Shape 2: inferred_flows list
    if "inferred_flows" in sae_result:
        for sae_flow in sae_result.get("inferred_flows", []):
            if not isinstance(sae_flow, dict):
                continue
            # Flexible field names: from_label/to_label
            src = sae_flow.get("from_label") or sae_flow.get("src", "")
            dst = sae_flow.get("to_label") or sae_flow.get("dst", "")
            if src and dst:
                edge = {
                    "src": src,
                    "dst": dst,
                    "kind": sae_flow.get("kind", "inferred"),
                    "edge_type": sae_flow.get(
                        "edge_type", sae_flow.get("kind", "inferred")
                    ),
                    "meta": {
                        "sae_source": "inferred_flows",
                    },
                }
                # Optional fields stored in meta
                if "confidence" in sae_flow:
                    edge["meta"]["sae_confidence"] = sae_flow["confidence"]
                if "pattern" in sae_flow:
                    edge["meta"]["sae_pattern"] = sae_flow["pattern"]
                if "analysis_id" in sae_flow:
                    edge["meta"]["sae_analysis_id"] = sae_flow["analysis_id"]
                edges.append(edge)
        return edges

    return edges


def edge_key(e: Dict[str, Any]) -> Tuple[str, str, str]:
    """
    Canonical key for deduplication: (src, dst, kind).
    Used to identify duplicate edges from different sources.
    """
    return (e.get("src", ""), e.get("dst", ""), e.get("kind", "unknown"))


def normalize_edge(
    e: Dict[str, Any],
    default_origin: str = "cfg",
    default_confidence: str = "definite",
    default_kind: str = "unknown",
) -> Dict[str, Any]:
    """
    Ensure all required provenance fields exist in edge.

    Args:
        e: Edge dict (may be missing origin/confidence/meta)
        default_origin: Origin to assign if missing (cfg, pfi, sae)
        default_confidence: Confidence level if missing
        default_kind: Edge kind/type if missing

    Returns:
        Normalized edge dict with all required fields
    """
    out = dict(e)
    out.setdefault("src", "")
    out.setdefault("dst", "")
    out.setdefault("kind", default_kind)
    out.setdefault("origin", default_origin)
    out.setdefault("confidence", default_confidence)
    out.setdefault("meta", {})

    # Preserve existing isInternal and isImplicitReturn flags from renpy_engine
    if "isInternal" not in out:
        out["isInternal"] = False
    if "isImplicitReturn" not in out:
        out["isImplicitReturn"] = False

    return out


def prefer_edge(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    """
    Return the edge that should 'win' for rendering when two edges
    share the same canonical key (src, dst, kind).

    Preference order:
    1. Higher confidence (definite > probable > possible)
    2. Higher origin rank (cfg > pfi > sae)

    Args:
        a: First edge candidate
        b: Second edge candidate

    Returns:
        The edge that should be used in the merged output
    """
    a_conf = CONF_RANK.get(a.get("confidence", "possible"), 1)
    b_conf = CONF_RANK.get(b.get("confidence", "possible"), 1)

    # Higher confidence wins
    if a_conf != b_conf:
        return a if a_conf > b_conf else b

    # If confidence tied, higher origin rank wins
    a_org = ORIGIN_RANK.get(a.get("origin", "sae"), 1)
    b_org = ORIGIN_RANK.get(b.get("origin", "sae"), 1)

    return a if a_org >= b_org else b


def merge_meta(winner: Dict[str, Any], loser: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge metadata from loser into winner.
    Tracks multiple origins when edges are merged.

    Args:
        winner: The winning edge (to be returned)
        loser: The losing edge (being merged away)

    Returns:
        Winner edge with merged metadata
    """
    w = dict(winner)
    meta = dict(w.get("meta") or {})

    # Track all origins that contributed to this edge
    origins = set(meta.get("origins") or [w.get("origin")])
    origins.add(loser.get("origin"))
    meta["origins"] = sorted(o for o in origins if o)

    # Keep count of merged candidates
    merged = meta.get("merged_candidates", 0)
    meta["merged_candidates"] = merged + 1

    w["meta"] = meta
    return w


# Phase 5: Numeric Confidence & Adaptive Scoring
CONFIDENCE_DEFAULTS = {
    "cfg": 1.0,  # Definite (explicit source code)
    "pfi": 0.75,  # Probable (pattern inference)
    "observed": 1.0,  # Ground truth (runtime traces)
    "sae": 0.55,  # Possible (semantic analysis)
    "synthetic": 0.50,  # Uncertain (inferred from SAE)
}

GLOBAL_THRESHOLD = 0.65  # Minimum confidence to include edge (PROBABLE tier floor)


def assign_numeric_confidence(
    edges: List[Dict[str, Any]],
    strategy: str = "global",
    threshold: Optional[float] = None,
    defaults: Optional[Dict[str, float]] = None,
    apply_threshold_filter: bool = False,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Assign numeric confidence [0.0, 1.0] to all edges.

    Implements Phase 5: Adaptive Confidence & Numeric Scoring.

    Algorithm:
    1. Assign numeric_confidence to every edge (numeric if present; default by origin otherwise)
    2. Optionally filter edges by global threshold (drop if numeric_confidence < threshold)
    3. Track statistics for telemetry (distribution, averages, drops)

    Args:
        edges: List of edge dicts with optional "numeric_confidence" field
        strategy: Merge strategy ("global" for single threshold, "per_source" for dict)
        threshold: Confidence threshold for filtering (default: GLOBAL_THRESHOLD=0.65)
        defaults: Per-origin confidence defaults (default: CONFIDENCE_DEFAULTS)
        apply_threshold_filter: If True, drop edges below threshold (Phase 6+ feature)

    Returns:
        (filtered_edges, stats_dict) where:
        - filtered_edges: edges with numeric_confidence assigned and optionally filtered
        - stats_dict: confidence distribution, drops, averages

    Confidence Tiers:
        [0.90–1.00] DEFINITE (3)    - High confidence, verified
        [0.65–0.89] PROBABLE (2)    - Moderate confidence, inferred correctly
        [0.40–0.64] POSSIBLE (1)    - Low confidence, speculative
        [0.00–0.39] UNCERTAIN (0)   - Exclude from merge (if filtering enabled)
    """
    if threshold is None:
        threshold = GLOBAL_THRESHOLD
    if defaults is None:
        defaults = CONFIDENCE_DEFAULTS

    # Stats tracker
    stats = {
        "confidence_total_edges": 0,
        "confidence_distribution": {
            "definite (0.90+)": 0,
            "probable (0.65-0.89)": 0,
            "possible (0.40-0.64)": 0,
            "uncertain (0.00-0.39)": 0,
        },
        "confidence_filtered_dropped": 0,
        "confidence_avg_global": 0.0,
        "confidence_by_origin": {},
        "confidence_inferred_from_origin": 0,
    }

    # Phase 1: Assign numeric confidence to all edges
    assigned_edges = []
    for edge in edges:
        assigned_edge = dict(edge)

        # Get numeric confidence if present; otherwise use origin default
        numeric_conf = edge.get("numeric_confidence")
        origin = edge.get("origin", "sae")

        if numeric_conf is not None:
            # Use provided numeric confidence
            # Clamp to [0.0, 1.0] range
            numeric_conf = max(0.0, min(1.0, numeric_conf))
        else:
            # Assign source default
            numeric_conf = defaults.get(origin, 0.5)
            stats["confidence_inferred_from_origin"] += 1

        assigned_edge["numeric_confidence"] = numeric_conf
        assigned_edges.append(assigned_edge)

    # Phase 2: Filter edges by global threshold (only if apply_threshold_filter=True)
    filtered_edges = []
    if apply_threshold_filter:
        for edge in assigned_edges:
            conf = edge.get("numeric_confidence", 0.0)
            if conf >= threshold:
                filtered_edges.append(edge)
            else:
                stats["confidence_filtered_dropped"] += 1
    else:
        # No filtering: keep all edges
        filtered_edges = assigned_edges

    # Phase 3: Build statistics
    stats["confidence_total_edges"] = len(filtered_edges)

    origin_stats = {}
    conf_sum = 0.0

    for edge in filtered_edges:
        conf = edge.get("numeric_confidence", 0.0)
        origin = edge.get("origin", "sae")

        # Categorize by tier
        if conf >= 0.90:
            stats["confidence_distribution"]["definite (0.90+)"] += 1
        elif conf >= 0.65:
            stats["confidence_distribution"]["probable (0.65-0.89)"] += 1
        elif conf >= 0.40:
            stats["confidence_distribution"]["possible (0.40-0.64)"] += 1
        else:
            stats["confidence_distribution"]["uncertain (0.00-0.39)"] += 1

        # Per-origin stats
        if origin not in origin_stats:
            origin_stats[origin] = {"count": 0, "sum": 0.0}
        origin_stats[origin]["count"] += 1
        origin_stats[origin]["sum"] += conf

        conf_sum += conf

    # Calculate averages
    if filtered_edges:
        stats["confidence_avg_global"] = conf_sum / len(filtered_edges)

    for origin, data in origin_stats.items():
        avg = data["sum"] / data["count"] if data["count"] > 0 else 0.0
        stats["confidence_by_origin"][origin] = {"count": data["count"], "avg": avg}

    return filtered_edges, stats


def generate_synthetic_nodes(
    sae_edges: List[Dict[str, Any]],
    known_node_ids: set,
) -> List[Dict[str, Any]]:
    """
    Generate synthetic nodes for SAE edges targeting unknown endpoints.

    Phase 4: Synthetic entry nodes for inferred flows to unknown labels.

    For each SAE edge targeting an unknown label, creates a deterministic
    synthetic node that serves as a placeholder entry point. Multiple edges
    targeting the same unknown label are deduplicated into a single synthetic
    node with aggregated metadata.

    Args:
        sae_edges: SAE edges (post-normalization, pre-filtering)
        known_node_ids: Set of node IDs currently in story graph

    Returns:
        List of synthetic node dicts, deduplicated by target label.
        Each node has:
            - id: "__synthetic_entry::<target_label>"
            - label: target label name
            - type: "synthetic_entry"
            - synthetic: True
            - origin: "sae"
            - meta: {"source_edges": count, "inferred_patterns": [...]}

    Example:
        SAE edges targeting unknown labels label_d (2x) and label_e (1x):
        → Returns 2 synthetic nodes (__synthetic_entry::label_d with source_edges=2,
                                    __synthetic_entry::label_e with source_edges=1)
    """
    if not sae_edges:
        return []

    # Track synthetic nodes by dedup key (target label)
    synthetic_by_key: Dict[str, Dict[str, Any]] = {}

    for sae_edge in sae_edges:
        dst = sae_edge.get("dst", "")
        if not dst or dst in known_node_ids:
            # Skip if missing dst or if target is already known
            continue

        # Dedup key: the target label
        dedup_key = dst

        if dedup_key not in synthetic_by_key:
            # First reference to this synthetic target: create node
            synthetic_node = {
                "id": f"__synthetic_entry::{dst}",
                "label": dst,
                "type": "synthetic_entry",
                "synthetic": True,
                "origin": "sae",
                "meta": {
                    "source_edges": 1,
                    "inferred_patterns": [],
                    "created_at": "phase_4",
                    "dedup_key": dedup_key,
                },
                "file": "",
                "line": 0,
            }
            synthetic_by_key[dedup_key] = synthetic_node
        else:
            # Duplicate: increment source edge count and aggregate patterns
            synthetic_by_key[dedup_key]["meta"]["source_edges"] += 1

            # Aggregate inferred patterns if present
            if "pattern" in sae_edge.get("meta", {}):
                pattern = sae_edge["meta"]["pattern"]
                patterns = synthetic_by_key[dedup_key]["meta"]["inferred_patterns"]
                if pattern not in patterns:  # Avoid duplicates
                    patterns.append(pattern)

    return list(synthetic_by_key.values())


def resolve_semantic_edges(
    nodes: List[Dict[str, Any]],
    cfg_edges: List[Dict[str, Any]],
    pfi_edges: Optional[List[Dict[str, Any]]] = None,
    sae_edges: Optional[List[Dict[str, Any]]] = None,
    observed_edges: Optional[List[Dict[str, Any]]] = None,
    keep_only_known_endpoints: bool = True,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Edge Reconciliation Pipeline (ERP): normalize and dedup edges.

    Merges edges from multiple analysis sources with provenance tracking.
    Priority: CFG > PFI > Observed > SAE

    Args:
        nodes: List of node dicts with 'id' field
        cfg_edges: CFG edges from story graph (high confidence)
        pfi_edges: PFI edges (Phase 2+) - probable confidence
        sae_edges: SAE edges (Phase 3+) - inferred confidence
        observed_edges: Observed edges from runtime traces - ground truth
        keep_only_known_endpoints: If True, drop edges where src/dst not in nodes

    Returns:
        (merged_edges, stats_dict)

        merged_edges: List of deduplicated edges with provenance fields
        stats_dict: Metadata about merge process:
            - cfg_in: number of CFG edges input
            - pfi_in: number of PFI edges input
            - sae_in: number of SAE edges input
            - observed_in: number of observed edges input
            - normalized_total: number of unique (src, dst, kind) keys
            - merged_out: number of final edges
            - duplicate_groups: number of keys with >1 edge
            - dropped_missing_endpoints: number of edges filtered out
    """
    pfi_edges = pfi_edges or []
    sae_edges = sae_edges or []
    observed_edges = observed_edges or []

    # Build set of valid node IDs for endpoint validation
    node_ids = {n.get("id") for n in nodes if n.get("id")}

    def endpoints_exist(e: Dict[str, Any]) -> bool:
        return (e.get("src") in node_ids) and (e.get("dst") in node_ids)

    # Normalize all edges to include provenance fields
    all_edges: List[Dict[str, Any]] = []

    # CFG edges: definite confidence (from explicit story graph)
    for e in cfg_edges:
        all_edges.append(
            normalize_edge(e, default_origin="cfg", default_confidence="definite")
        )

    # Phase 2: PFI edges (inter-procedural analysis)
    for e in pfi_edges:
        all_edges.append(
            normalize_edge(e, default_origin="pfi", default_confidence="probable")
        )

    # Phase 2B: Observed edges (runtime traces) - ground truth
    for e in observed_edges:
        all_edges.append(
            normalize_edge(e, default_origin="observed", default_confidence="observed")
        )

    # Phase 3: SAE edges (semantic analysis engine) - possible confidence
    for e in sae_edges:
        all_edges.append(
            normalize_edge(e, default_origin="sae", default_confidence="possible")
        )

    # Phase 4: Generate synthetic nodes for SAE edges targeting unknown endpoints
    synthetic_nodes = generate_synthetic_nodes(sae_edges, {n.get("id") for n in nodes})
    nodes.extend(synthetic_nodes)
    synthetic_nodes_created = len(synthetic_nodes)

    # Phase 5: Apply numeric confidence assignment (with optional filtering for Phase 6)
    all_edges, confidence_stats = assign_numeric_confidence(
        all_edges,
        strategy="global",
        threshold=GLOBAL_THRESHOLD,
        defaults=CONFIDENCE_DEFAULTS,
        apply_threshold_filter=False,
    )

    # Optionally drop edges with missing endpoints
    dropped = 0
    if keep_only_known_endpoints:
        before = len(all_edges)
        all_edges = [e for e in all_edges if endpoints_exist(e)]
        dropped = before - len(all_edges)

    # Dedup: group by canonical key and select winner
    grouped: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for e in all_edges:
        grouped[edge_key(e)].append(e)

    merged_edges: List[Dict[str, Any]] = []
    dup_groups = 0
    edges_merged_by_confidence = 0
    observed_suppressed = 0  # Count observed edges suppressed by higher-priority edges

    for k, group in grouped.items():
        if len(group) == 1:
            # No duplicates for this key
            merged_edges.append(group[0])
            continue

        # Multiple edges with same key: select winner by numeric confidence (Phase 5)
        dup_groups += 1
        # Winner is edge with maximum numeric_confidence (hybrid strategy: weighting within threshold)
        winner = max(group, key=lambda e: e.get("numeric_confidence", 0.0))

        # Merge metadata from all losers
        for loser in group:
            if loser is not winner:
                winner = merge_meta(winner, loser)
                edges_merged_by_confidence += 1

                # Track when observed edges are suppressed
                if loser.get("origin") == "observed":
                    observed_suppressed += 1

        merged_edges.append(winner)

    stats = {
        "cfg_in": len(cfg_edges),
        "pfi_in": len(pfi_edges),
        "sae_in": len(sae_edges),
        "observed_in": len(observed_edges),
        "observed_suppressed": observed_suppressed,  # Observed edges suppressed by CFG/PFI
        "normalized_total": len(grouped),  # number of unique canonical keys
        "merged_out": len(merged_edges),
        "duplicate_groups": dup_groups,
        "dropped_missing_endpoints": dropped,
        "synthetic_nodes_created": synthetic_nodes_created,
        # Phase 5: Numeric confidence metrics
        "confidence_total_edges": confidence_stats.get("confidence_total_edges", 0),
        "confidence_distribution": confidence_stats.get("confidence_distribution", {}),
        "confidence_filtered_dropped": confidence_stats.get(
            "confidence_filtered_dropped", 0
        ),
        "confidence_avg_global": confidence_stats.get("confidence_avg_global", 0.0),
        "confidence_by_origin": confidence_stats.get("confidence_by_origin", {}),
        "confidence_inferred_from_origin": confidence_stats.get(
            "confidence_inferred_from_origin", 0
        ),
        "edges_merged_by_confidence": edges_merged_by_confidence,
    }
    return merged_edges, stats
