# branchpy/analysis/variable_flow.py
"""
Phase 1.2-1.3: Variable Flow Analysis for Stats 2.0

This module provides path-aware variable analysis using SAE CFG data.
"""

import re
from typing import Any, Dict, List, Optional


def extract_assignments_from_cfg(cfg_graph, index=None) -> Dict[str, List[dict]]:
    """
    Phase 1.2: Extract variable assignments from CFG grouped by label.

    Args:
        cfg_graph: ControlFlowGraph from SAE or adapter
        index: Optional ProjectIndex with variable assignment data

    Returns:
        Dictionary mapping label names to lists of variable assignments:
        {
            "<label_name>": [
                {
                    "var": str,           # Variable name
                    "op": "=" | "+=" | "-=" | "*=" | "/=",  # Assignment operator
                    "file": str | None,   # Source file
                    "line": int | None,   # Line number
                    "node": str,          # CFG node ID
                },
                ...
            ],
            ...
        }

    Example:
        {
            "start": [
                {"var": "hero_name", "op": "=", "file": "script.rpy", "line": 12, "node": "n5"},
                {"var": "trust", "op": "+=", "file": "script.rpy", "line": 15, "node": "n8"}
            ],
            "chapter1": [
                {"var": "chapter", "op": "=", "file": "chapter1.rpy", "line": 5, "node": "n42"}
            ]
        }
    """
    assignments_by_label: Dict[str, List[dict]] = {}

    # If we have an index, use it to get variable assignments
    if index and hasattr(index, "variables"):
        # Build label → file/line range mapping from CFG
        label_ranges = _build_label_ranges(cfg_graph)

        # Map each variable assignment to its containing label
        for var_name, entries in index.variables.items():
            for entry in entries:
                # Find which label contains this assignment
                containing_label = _find_containing_label(
                    entry.file, entry.line, label_ranges
                )
                if containing_label:
                    if containing_label not in assignments_by_label:
                        assignments_by_label[containing_label] = []

                    # Default to = operator (index doesn't track operator type)
                    assignments_by_label[containing_label].append(
                        {
                            "var": var_name,
                            "op": "=",  # Index doesn't distinguish operators
                            "file": entry.file,
                            "line": entry.line,
                            "node": None,  # No direct CFG node mapping available
                        }
                    )

        return assignments_by_label

    # Fallback: Try to extract from CFG Python nodes (rare)
    current_label = None

    # Get nodes - handle both dict and callable
    nodes_raw = cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes

    # Convert to dict if it's a list
    if isinstance(nodes_raw, dict):
        nodes = nodes_raw
    elif isinstance(nodes_raw, list):
        nodes = {n.get("id"): n for n in nodes_raw}  # type: ignore
    else:
        # If it's some other iterable, try to convert
        try:
            nodes = {n.get("id"): n for n in nodes_raw}  # type: ignore
        except (AttributeError, TypeError):
            # Fall back to empty dict if we can't process it
            nodes = {}

    # Iterate through all nodes in order
    for node_id, node in nodes.items():
        node_kind = _get_node_kind(node)

        # Track current label context
        if node_kind == "label":
            current_label = _get_node_name(node)
            if current_label and current_label not in assignments_by_label:
                assignments_by_label[current_label] = []

        # Extract assignments from Python nodes
        elif node_kind == "python" and current_label:
            code = _get_node_code(node)
            if code:
                # Parse assignments from Python code
                assignments = _parse_assignments(code)
                for var_name, op in assignments:
                    assignments_by_label[current_label].append(
                        {
                            "var": var_name,
                            "op": op,
                            "file": _get_node_attr(node, "file"),
                            "line": _get_node_attr(node, "line"),
                            "node": node_id,
                        }
                    )

        # Extract variable interpolations from say nodes (less common but possible)
        elif node_kind == "say" and current_label:
            text = _get_node_name(node)
            if text:
                # Check for [var_name] interpolations (read, not write)
                # We'll skip these for now as they're variable reads, not assignments
                pass

    return assignments_by_label


def _build_label_ranges(cfg_graph) -> Dict[str, Dict[str, Any]]:
    """
    Build a mapping of label names to their file/line ranges.

    Returns:
        {
            "label_name": {
                "file": str,
                "start_line": int,
                "end_line": int  # Approximation based on next label
            }
        }
    """
    label_ranges = {}

    # Get nodes
    nodes_raw = cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes
    if isinstance(nodes_raw, dict):
        nodes = list(nodes_raw.values())
    else:
        nodes = list(nodes_raw) if hasattr(nodes_raw, "__iter__") else []  # type: ignore[arg-type]

    # Find all label nodes
    labels = []
    for n in nodes:
        if _get_node_kind(n) == "label":
            name = _get_node_name(n)
            file = _get_node_attr(n, "file")
            line = _get_node_attr(n, "line")
            if name and file and line:
                labels.append({"name": name, "file": file, "line": line})

    # Sort by file and line
    labels.sort(key=lambda lbl: (lbl["file"], lbl["line"]))

    # Build ranges — O(n): since list is sorted, the next label in the same file
    # is always labels[i+1] if it shares the same file, so no inner scan needed.
    for i, label in enumerate(labels):
        next_line = None
        if i + 1 < len(labels) and labels[i + 1]["file"] == label["file"]:
            next_line = labels[i + 1]["line"]

        label_ranges[label["name"]] = {
            "file": label["file"],
            "start_line": label["line"],
            "end_line": next_line or 999999,  # Large number if no next label
        }

    return label_ranges


# Module-level cache: built once per extract_assignments_from_cfg call.
# Maps normalized_file -> sorted list of (start_line, end_line, label_name).
_label_index_cache: Dict[str, Any] = {}


def _build_label_index(label_ranges: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Build a per-file sorted index of (start_line, end_line, label_name) tuples
    so _find_containing_label can binary-search instead of scanning all labels."""
    import bisect
    from pathlib import Path

    index: Dict[str, list] = (
        {}
    )  # normalized_file -> [(start_line, end_line, name), ...]
    for label_name, r in label_ranges.items():
        try:
            nf = str(Path(r["file"]).resolve())
        except Exception:
            nf = r["file"]
        index.setdefault(nf, []).append((r["start_line"], r["end_line"], label_name))
    for lst in index.values():
        lst.sort()  # sort by start_line
    return index


def _find_containing_label(
    file: str, line: int, label_ranges: Dict[str, Dict[str, Any]]
) -> Optional[str]:
    """Find which label contains a given file:line location.
    Uses a per-file sorted index + bisect for O(log n) lookup."""
    import bisect
    from pathlib import Path

    # Build index on first call (keyed by id of label_ranges dict)
    key = id(label_ranges)
    if key not in _label_index_cache:
        _label_index_cache[key] = _build_label_index(label_ranges)
    file_index = _label_index_cache[key]

    try:
        file_normalized = str(Path(file).resolve())
    except Exception:
        file_normalized = file

    candidates = file_index.get(file_normalized)
    if candidates is None:
        # Fallback: try basename match for relative paths
        for nf, lst in file_index.items():
            if nf.endswith(file) or file.endswith(nf):
                candidates = lst
                break
    if not candidates:
        return None

    # Binary search: find rightmost entry with start_line <= line
    # candidates is sorted by start_line
    starts = [c[0] for c in candidates]
    pos = bisect.bisect_right(starts, line) - 1
    if pos < 0:
        return None
    start_line, end_line, label_name = candidates[pos]
    if start_line <= line < end_line:
        return label_name
    return None
    """
    Phase 1.2: Extract variable assignments from CFG grouped by label.
    
    Args:
        cfg_graph: ControlFlowGraph from SAE or adapter
    
    Returns:
        Dictionary mapping label names to lists of variable assignments:
        {
            "<label_name>": [
                {
                    "var": str,           # Variable name
                    "op": "=" | "+=" | "-=" | "*=" | "/=",  # Assignment operator
                    "file": str | None,   # Source file
                    "line": int | None,   # Line number
                    "node": str,          # CFG node ID
                },
                ...
            ],
            ...
        }
    
    Example:
        {
            "start": [
                {"var": "hero_name", "op": "=", "file": "script.rpy", "line": 12, "node": "n5"},
                {"var": "trust", "op": "+=", "file": "script.rpy", "line": 15, "node": "n8"}
            ],
            "chapter1": [
                {"var": "chapter", "op": "=", "file": "chapter1.rpy", "line": 5, "node": "n42"}
            ]
        }
    """
    assignments_by_label: Dict[str, List[dict]] = {}
    current_label = None

    # STABILIZATION (2026-04-02): cfg_graph is not in scope for this code path.
    # nodes is deliberately set to an empty dict to prevent NameError.
    # The function returns an empty assignments dict, which is safe for all callers.
    # DO NOT restore the commented-out cfg_graph references below without first
    # wiring the correct cfg_graph parameter through the call chain.
    nodes: Dict = {}

    # Dead code commented out:
    # Get nodes - handle both dict and callable
    # nodes_raw = cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes  # noqa: F821
    # Convert to dict if it's a list
    # if isinstance(nodes_raw, dict):
    #     nodes = nodes_raw
    # elif isinstance(nodes_raw, list):
    #     nodes = {n.get("id"): n for n in nodes_raw}  # type: ignore
    # else:
    #     # If it's some other iterable, try to convert
    #     try:
    #         nodes = {n.get("id"): n for n in nodes_raw}  # type: ignore
    #     except (AttributeError, TypeError):
    #         # Fall back to empty dict if we can't process it
    #         nodes = {}

    # Iterate through all nodes in order
    for node_id, node in nodes.items():
        node_kind = _get_node_kind(node)

        # Track current label context
        if node_kind == "label":
            current_label = _get_node_name(node)
            if current_label and current_label not in assignments_by_label:
                assignments_by_label[current_label] = []

        # Extract assignments from Python nodes
        elif node_kind == "python" and current_label:
            code = _get_node_code(node)
            if code:
                # Parse assignments from Python code
                assignments = _parse_assignments(code)
                for var_name, op in assignments:
                    assignments_by_label[current_label].append(
                        {
                            "var": var_name,
                            "op": op,
                            "file": _get_node_attr(node, "file"),
                            "line": _get_node_attr(node, "line"),
                            "node": node_id,
                        }
                    )

        # Extract variable interpolations from say nodes (less common but possible)
        elif node_kind == "say" and current_label:
            text = _get_node_name(node)
            if text:
                # Check for [var_name] interpolations (read, not write)
                # We'll skip these for now as they're variable reads, not assignments
                pass

    return assignments_by_label


def _get_node_kind(node) -> str:
    """Extract node kind from node dict or object."""
    if isinstance(node, dict):
        kind = node.get("kind", "")
    else:
        kind = getattr(node, "kind", "")

    # Handle enum values
    if kind and hasattr(kind, "value"):
        return str(kind.value).lower()  # type: ignore
    return str(kind).lower()


def _get_node_name(node) -> Optional[str]:
    """Extract node name from node dict or object."""
    if isinstance(node, dict):
        return node.get("name")
    return getattr(node, "name", None)


def _get_node_code(node) -> Optional[str]:
    """Extract Python code from node meta or attributes."""
    if isinstance(node, dict):
        meta = node.get("meta", {})
        return meta.get("code") or meta.get("text")
    else:
        meta = getattr(node, "meta", {})
        return meta.get("code") or meta.get("text")


def _get_node_attr(node, attr: str) -> Any:
    """Extract attribute from node dict or object."""
    if isinstance(node, dict):
        return node.get(attr)
    return getattr(node, attr, None)


def _parse_assignments(code: str) -> List[tuple]:
    """
    Parse Python code for variable assignments.

    Supports:
    - $ var = value
    - $ var += value
    - $ var -= value
    - $ var *= value
    - $ var /= value
    - Multiple assignments on same line: $ a = 1; b = 2

    Args:
        code: Python code string (may have leading $)

    Returns:
        List of (variable_name, operator) tuples
    """
    assignments = []

    # Remove leading $ if present
    code = code.lstrip("$").strip()

    # Split by semicolons for multiple statements
    statements = [s.strip() for s in code.split(";")]

    for stmt in statements:
        # Match assignment patterns: var_name op value
        # Patterns: =, +=, -=, *=, /=, %=, //=, **=
        match = re.match(
            r"^\s*([a-zA-Z_]\w*)\s*(=|\+=|-=|\*=|/=|%=|//=|\*\*=)\s*", stmt
        )
        if match:
            var_name = match.group(1)
            operator = match.group(2)
            assignments.append((var_name, operator))

    return assignments


def build_variable_flow_graph(
    assignments: Dict[str, List[dict]], cfg_graph
) -> Dict[str, Dict[str, Any]]:
    """
    Phase 1.3: Build variable flow graph from assignments and CFG.

    Args:
        assignments: Output from extract_assignments_from_cfg()
        cfg_graph: ControlFlowGraph for path analysis

    Returns:
        Dictionary mapping variable names to per-label state info:
        {
            "<var_name>": {
                "<label_name>": {
                    "min": float | None,        # Minimum value (if numeric)
                    "max": float | None,        # Maximum value (if numeric)
                    "types": set[str],          # Set of types seen
                    "operations": list[str],    # List of operations (=, +=, -=, etc.)
                    "paths": list[str],         # List of paths (label sequences) where var is modified
                },
                ...
            },
            ...
        }

    Example:
        {
            "trust": {
                "start": {
                    "min": 50.0,
                    "max": 50.0,
                    "types": {"number"},
                    "operations": ["="],
                    "paths": [["start"]]
                },
                "chapter1_good": {
                    "min": 60.0,
                    "max": 60.0,
                    "types": {"number"},
                    "operations": ["+="],
                    "paths": [["start", "chapter1_intro", "chapter1_good"]]
                }
            }
        }
    """
    flow_graph: Dict[str, Dict[str, Any]] = {}

    # Build label → label edges from CFG
    label_edges = _build_label_edges(cfg_graph)

    # For each variable, track its state in each label
    for label_name, label_assignments in assignments.items():
        for assign in label_assignments:
            var_name = assign["var"]
            op = assign["op"]

            # Initialize variable entry
            if var_name not in flow_graph:
                flow_graph[var_name] = {}

            # Initialize label entry for this variable
            if label_name not in flow_graph[var_name]:
                flow_graph[var_name][label_name] = {
                    "min": None,
                    "max": None,
                    "types": set(),
                    "operations": [],
                    "paths": [],
                    "count": 0,
                }

            # Update state
            state = flow_graph[var_name][label_name]
            state["operations"].append(op)
            state["count"] += 1

            # Note: We can't determine actual values or types without executing code
            # For now, mark as 'unknown' type
            state["types"].add("unknown")

    # Build paths for each variable
    for var_name, label_states in flow_graph.items():
        # Find all labels where this variable is modified
        modified_labels = list(label_states.keys())

        # For each modified label, find paths from entry points
        for label in modified_labels:
            paths = _find_paths_to_label(label, label_edges, max_depth=10)
            label_states[label]["paths"] = paths

    # Convert sets to lists for JSON serialization
    for var_name, label_states in flow_graph.items():
        for label_name, state in label_states.items():
            state["types"] = list(state["types"])

    return flow_graph


def _build_label_edges(cfg_graph) -> Dict[str, List[str]]:
    """
    Build a mapping of label → [successor labels].

    Returns:
        {"label1": ["label2", "label3"], ...}
    """
    label_edges: Dict[str, List[str]] = {}

    # Get nodes and edges
    nodes_raw = cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes
    edges_raw = cfg_graph.edges() if callable(cfg_graph.edges) else cfg_graph.edges

    # Build node_id → label name mapping
    node_to_label: Dict[str, str] = {}
    if isinstance(nodes_raw, dict):
        nodes = nodes_raw.values()
    else:
        nodes = nodes_raw if hasattr(nodes_raw, "__iter__") else []  # type: ignore[arg-type]

    for n in nodes:  # type: ignore[union-attr]
        if _get_node_kind(n) == "label":
            node_id = _get_node_attr(n, "id")
            label_name = _get_node_name(n)
            if node_id and label_name:
                node_to_label[str(node_id)] = label_name

    # Build label → label edges from CFG edges
    if hasattr(edges_raw, "__iter__"):
        edges = edges_raw  # type: ignore[assignment]
    else:
        edges = []

    for e in edges:  # type: ignore[union-attr]
        from_node = _get_edge_attr(e, "from_node") or _get_edge_attr(e, "src")
        to_node = _get_edge_attr(e, "to_node") or _get_edge_attr(e, "dst")

        if from_node and to_node:
            from_label = node_to_label.get(str(from_node))
            to_label = node_to_label.get(str(to_node))

            if from_label and to_label and from_label != to_label:
                if from_label not in label_edges:
                    label_edges[from_label] = []
                if to_label not in label_edges[from_label]:
                    label_edges[from_label].append(to_label)

    return label_edges


def _find_paths_to_label(
    target_label: str, label_edges: Dict[str, List[str]], max_depth: int = 10
) -> List[List[str]]:
    """
    Find all paths to a target label (simplified BFS).

    For now, just return the label itself as a single-element path.
    Full path finding would require entry point detection and graph traversal.
    """
    # Simplified: Just return the target label as a path
    # Full implementation would do BFS from entry points to target
    return [[target_label]]


def _get_edge_attr(edge, attr: str) -> Any:
    """Extract attribute from edge dict or object."""
    if isinstance(edge, dict):
        return edge.get(attr)
    return getattr(edge, attr, None)
