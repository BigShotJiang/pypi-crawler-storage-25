"""
group_types.py — Group dataclass and fingerprint utilities for semantic grouping.

Part of FLOWCHART-SEMANTIC-COMPRESSION-V1 (feature/semantic-compression branch).
Spec: docs/Current Version/flowchart/SEMANTIC_COMPRESSION_SPEC_V1.md
"""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from typing import Any, Optional


@dataclass
class Group:
    """
    A first-class persisted object representing a logical group of graph nodes.
    Two visual states: collapsed (proxy node) or expanded (container).

    The ``collapsed`` field uses a tri-state:
      None  → renderer picks default (True for auto groups, False for manual)
      True  → user has explicitly collapsed this group
      False → user has explicitly expanded this group
    Only written as True/False after the first user interaction.
    """

    group_id: str
    """Deterministic 12-char SHA-1 prefix. See make_group_id()."""

    origin: str
    """'manual' | 'auto'"""

    motif_type: str
    """'orphan_cluster' | 'peripheral_island' | 'linear_chain' | 'utility_burst' | 'manual'"""

    label: str
    """Human-readable label: '{motif} · {N} nodes · {anchor}'"""

    member_node_ids: list[str]
    """Original node IDs inside this group."""

    entry_node_ids: list[str]
    """Members that have incoming edges from outside the group."""

    exit_node_ids: list[str]
    """Members that have outgoing edges to outside the group."""

    collapsed: Optional[bool]
    """Tri-state: None=renderer default, True=explicitly collapsed, False=explicitly expanded."""

    pinned: bool
    """If True, never auto-regenerated (user-owned)."""

    stale: bool
    """True if source has changed and this group needs review."""

    reason: str
    """Why it was grouped, e.g. 'Strict linear chain, 1 in / 1 out, same file'"""

    score: float
    """0–1 confidence score. Always 1.0 for manual groups."""

    generation_fingerprint: str = ""
    """SHA-1 prefix of member_node_ids + their per-node source fingerprints. See make_fingerprint()."""

    style_overrides: dict[str, Any] = field(default_factory=dict)
    """Label rename, color, shape overrides on the group node."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Motif-specific extras (chain length, hub label, file name, etc.)"""


# ---------------------------------------------------------------------------
# Deterministic ID helpers
# ---------------------------------------------------------------------------


def make_group_id(
    motif_type: str,
    member_node_ids: list[str],
    entry_node_ids: list[str],
    exit_node_ids: list[str],
) -> str:
    """
    Return a 12-char hex string that is stable across runs, machines, and minor graph edits.

    Formula: sha1(motif_type | sorted(member_ids) | sorted(entry_ids + exit_ids))[:12]
    """
    boundary_ids = sorted(set(entry_node_ids) | set(exit_node_ids))
    payload = "|".join(
        [
            motif_type,
            "|".join(sorted(member_node_ids)),
            "|".join(boundary_ids),
        ]
    )
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:12]


def make_fingerprint(
    member_node_ids: list[str],
    node_fingerprints: dict[str, str],
) -> str:
    """
    Return a 16-char hex fingerprint capturing both membership and per-node source state.

    Changes if any member node's source content changes or membership changes.
    """
    parts = sorted(f"{nid}:{node_fingerprints.get(nid, '')}" for nid in member_node_ids)
    return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()[:16]


def make_exclusion_key(motif_type: str, member_node_ids: list[str]) -> str:
    """
    Return a 12-char hex key identifying a user-rejected group pattern.
    Used by the 'never group this' exclusion memory (Phase 2).
    """
    payload = motif_type + "|" + "|".join(sorted(member_node_ids))
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def group_to_dict(g: Group) -> dict[str, Any]:
    """Serialise a Group to a JSON-compatible dict. collapsed=None → null."""
    d = asdict(g)
    # asdict preserves None for Optional[bool]; json.dumps handles it as null
    return d


def group_from_dict(d: dict[str, Any]) -> Group:
    """Deserialise a Group from a dict produced by group_to_dict().

    collapsed=null in JSON → None in Python (tri-state preserved).
    """
    return Group(
        group_id=str(d["group_id"]),
        origin=str(d["origin"]),
        motif_type=str(d["motif_type"]),
        label=str(d["label"]),
        member_node_ids=list(d.get("member_node_ids", [])),
        entry_node_ids=list(d.get("entry_node_ids", [])),
        exit_node_ids=list(d.get("exit_node_ids", [])),
        collapsed=d.get("collapsed"),  # None preserved from JSON null
        pinned=bool(d.get("pinned", False)),
        stale=bool(d.get("stale", False)),
        reason=str(d.get("reason", "")),
        score=float(d.get("score", 0.0)),
        generation_fingerprint=str(d.get("generation_fingerprint", "")),
        style_overrides=dict(d.get("style_overrides", {})),
        metadata=dict(d.get("metadata", {})),
    )
