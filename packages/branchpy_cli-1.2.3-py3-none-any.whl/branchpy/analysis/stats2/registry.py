"""
Stats 2.x Registry - Lazy Loading Infrastructure
================================================

Provides lazy-loaded component registration for Stats 2.x modules.
Supports on-demand loading to improve CLI startup performance.

v0.7.29 addition for lazy-loading support.
"""

from importlib import import_module
from typing import Any, Callable, Dict


class Registry:
    """Lazy-loading registry for Stats 2.x components."""

    def __init__(self):
        self._lazy: Dict[str, Callable[[], Any] | Any] = {}

    def register(self, key: str, loader: Callable[[], Any]) -> None:
        """Register a component with lazy loader.

        Args:
            key: Component identifier
            loader: Callable that returns the component when invoked
        """
        self._lazy[key] = loader

    def get(self, key: str) -> Any:
        """Get component, loading if necessary.

        Args:
            key: Component identifier

        Returns:
            The loaded component

        Raises:
            KeyError: If component not registered
        """
        if key not in self._lazy:
            raise KeyError(f"Component '{key}' not registered in Stats 2.x registry")

        value = self._lazy[key]

        # If it's still a callable (loader), invoke it and cache result
        if callable(value):
            value = value()
            self._lazy[key] = value

        return value

    def is_registered(self, key: str) -> bool:
        """Check if component is registered.

        Args:
            key: Component identifier

        Returns:
            True if registered
        """
        return key in self._lazy


# Global registry instance
registry = Registry()

# Register default components (lazy-loaded)
registry.register(
    "ranges", lambda: import_module("branchpy.analysis.stats2.ranges").Ranges()
)
