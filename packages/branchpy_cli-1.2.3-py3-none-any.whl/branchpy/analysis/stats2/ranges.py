"""
Stats 2.x Ranges - CFG Interval Estimation
==========================================

Provides interval estimation for stat values using control flow graph analysis.
Propagates config bounds and expression evaluation through the CFG.

v0.7.29: Ranges MVP for Stats 2.x unification.
"""

from typing import Any, Dict, Optional


class Ranges:
    """Interval estimation for Stats 2.x.

    Analyzes CFG to estimate min/max bounds for stat variables at each node.
    Combines config bounds with expression evaluation.
    """

    def estimate(
        self, project_model: Any, config_bounds: Dict[str, Dict[str, int]]
    ) -> Dict[str, Any]:
        """Estimate stat value ranges using CFG analysis.

        Args:
            project_model: Project model from analysis
            config_bounds: Config-provided bounds dict {stat: {min, max}}

        Returns:
            Dict with by_node structure:
            {"by_node": {"file:line": {"stat": {"min": 0, "max": 0}}}}
        """
        result = {"by_node": {}}

        # Extract CFG nodes if available
        nodes = self._get_cfg_nodes(project_model)

        for node in nodes:
            node_key = self._node_key(node)
            node_ranges = {}

            # Get stats that are modified or referenced at this node
            stats = self._get_node_stats(node, project_model)

            for stat in stats:
                # Use config bounds as starting point
                bounds = config_bounds.get(stat, {})

                if bounds:
                    node_ranges[stat] = {
                        "min": bounds.get("min", 0),
                        "max": bounds.get("max", 0),
                    }
                else:
                    # No config bounds - try to infer from assignments
                    inferred = self._infer_bounds(node, stat, project_model)
                    if inferred:
                        node_ranges[stat] = inferred

            if node_ranges:
                result["by_node"][node_key] = node_ranges

        return result

    def _get_cfg_nodes(self, project_model: Any) -> list:
        """Extract CFG nodes from project model.

        Args:
            project_model: Project model

        Returns:
            List of CFG node objects
        """
        if hasattr(project_model, "cfg_nodes"):
            return project_model.cfg_nodes()
        elif hasattr(project_model, "get_nodes"):
            return project_model.get_nodes()
        return []

    def _node_key(self, node: Any) -> str:
        """Generate node key in format 'file:line'.

        Args:
            node: CFG node object

        Returns:
            String key like 'game/script.rpy:42'
        """
        file_path = getattr(node, "file", "unknown")
        line_num = getattr(node, "line", 0)
        return f"{file_path}:{line_num}"

    def _get_node_stats(self, node: Any, project_model: Any) -> list:
        """Get list of stats referenced at this node.

        Args:
            node: CFG node
            project_model: Project model

        Returns:
            List of stat variable names
        """
        stats = []

        # Try to get from node attributes
        if hasattr(node, "modified_vars"):
            stats.extend(node.modified_vars)

        if hasattr(node, "referenced_vars"):
            stats.extend(node.referenced_vars)

        return list(set(stats))  # Deduplicate

    def _infer_bounds(
        self, node: Any, stat: str, project_model: Any
    ) -> Optional[Dict[str, int]]:
        """Infer bounds for stat from node assignments.

        Args:
            node: CFG node
            stat: Stat variable name
            project_model: Project model

        Returns:
            Dict with min/max or None if can't infer
        """
        # Try to get assignment expression
        if hasattr(node, "assignments"):
            assignments = node.assignments
            if stat in assignments:
                expr = assignments[stat]

                # Try to evaluate literal expressions
                if isinstance(expr, (int, float)):
                    return {"min": int(expr), "max": int(expr)}

                # Handle simple arithmetic ranges
                # (More sophisticated analysis would use expr_evaluator.py)

        return None
