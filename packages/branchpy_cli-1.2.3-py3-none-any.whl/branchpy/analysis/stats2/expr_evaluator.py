"""
Expression Evaluator for Stats 2.0 Symbolic Analysis

Evaluates AST expressions against a variable environment.

Supports:
- Constants (number, boolean, string)
- Variables (lookup in environment)
- Binary operations (+, -) on numeric values

Semantics:
- Booleans coerce to 1/0 for numeric operations
- Strings are not supported in arithmetic (returns unknown)
- Unknown variables propagate as unknown
- Pure, side-effect free evaluation
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple, Union

Number = Union[int, float]


@dataclass(frozen=True)
class EvalResult:
    """Result of expression evaluation."""

    value: Optional[Any]
    kind: str  # "number" | "boolean" | "string" | "unknown"
    unknown: bool
    error: Optional[str] = None

    def __repr__(self) -> str:
        if self.unknown:
            return f"EvalResult(unknown, error={self.error!r})"
        return f"EvalResult({self.value!r}, {self.kind})"


def _kind_of(value: Any) -> str:
    """Infer type kind from Python value."""
    if value is None:
        return "unknown"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, str):
        return "string"
    return "unknown"


def _coerce_numeric(v: Any) -> Tuple[Optional[Number], bool]:
    """
    Coerce value to numeric if possible.

    Booleans are treated as 1/0.
    Strings are not numeric.

    Returns:
        (coerced_number_or_None, is_numeric_like)
    """
    if isinstance(v, bool):
        return (1 if v else 0, True)
    if isinstance(v, (int, float)):
        return (v, True)
    return (None, False)


def eval_expr(expr: Any, env: Dict[str, Any]) -> EvalResult:
    """
    Evaluate an AST expression against an environment.

    Args:
        expr: AST node from expr_parser (Const, Var, or BinOp)
        env: Variable environment (name -> value)

    Returns:
        EvalResult with computed value and type

    Examples:
        >>> from branchpy.analysis.stats2.expr_parser import parse_expr
        >>> expr = parse_expr("trust + 10")
        >>> result = eval_expr(expr, {"trust": 50})
        >>> result.value
        60

        >>> result = eval_expr(parse_expr("missing"), {})
        >>> result.unknown
        True
    """
    # Import AST nodes (avoid circular dependency)
    from branchpy.analysis.stats2.expr_parser import BinOp, Const, Var

    # Handle Const
    if isinstance(expr, Const):
        k = _kind_of(expr.value)
        return EvalResult(
            value=expr.value, kind=k, unknown=(k == "unknown"), error=None
        )

    # Handle Var
    if isinstance(expr, Var):
        if expr.name not in env:
            return EvalResult(
                value=None,
                kind="unknown",
                unknown=True,
                error=f"Unknown var: {expr.name}",
            )
        val = env[expr.name]
        k = _kind_of(val)
        return EvalResult(value=val, kind=k, unknown=(k == "unknown"), error=None)

    # Handle BinOp
    if isinstance(expr, BinOp):
        left = eval_expr(expr.left, env)
        right = eval_expr(expr.right, env)

        # If either side is unknown, propagate
        if left.unknown or right.unknown:
            return EvalResult(
                value=None, kind="unknown", unknown=True, error="Operand unknown"
            )

        # Only support + and -
        op = expr.op
        if op not in {"+", "-"}:
            return EvalResult(
                value=None, kind="unknown", unknown=True, error=f"Unsupported op: {op}"
            )

        # Numeric arithmetic only (booleans allowed as 1/0)
        lnum, l_ok = _coerce_numeric(left.value)
        rnum, r_ok = _coerce_numeric(right.value)
        if not (l_ok and r_ok):
            return EvalResult(
                value=None, kind="unknown", unknown=True, error="Non-numeric operands"
            )

        # Compute result
        if op == "+":
            out = lnum + rnum  # type: ignore
        else:  # op == "-"
            out = lnum - rnum  # type: ignore

        # Normalize -0.0 → 0.0
        if isinstance(out, float) and out == 0.0:
            out = 0.0

        return EvalResult(value=out, kind="number", unknown=False, error=None)

    # Unknown node type
    return EvalResult(
        value=None,
        kind="unknown",
        unknown=True,
        error=f"Unsupported AST: {type(expr).__name__}",
    )
