"""
Assignment Extractor for Stats 2.0 - Parse simple Ren'Py variable assignments

Extracts assignments from code lines:
- Simple assignments: $ var = value
- Compound operators: $ var += value, $ var -= value
- Literals: numbers, booleans, strings

Scope (v0.7.26):
- IN: Simple literals, one-line assignments
- OUT: Complex expressions, function calls, list/dict mutations
"""

import re
from typing import Any, Dict, List, Optional, Tuple

# Assignment pattern: matches $ var = value, $ var += value, $ var -= value
ASSIGN_RE = re.compile(
    r"^\s*\$?\s*(?P<name>[A-Za-z_]\w*)\s*(?P<op>=|\+=|-=)\s*(?P<rhs>.+?)\s*(?:#.*)?$"
)


def extract_simple_assignments(lines: List[Tuple[int, str]]) -> List[Dict[str, Any]]:
    """
    Extract simple variable assignments from code lines.

    Args:
        lines: List of (line_number, text) tuples

    Returns:
        List of assignment events:
        {
            "var": str,        # Variable name
            "op": str,         # Operator: "=", "+=", "-="
            "kind": str,       # Type: "number", "boolean", "string", "unknown"
            "value": Any,      # Parsed value (int/float/bool/str/None)
            "line": int        # Line number
        }
    """
    assignments = []

    for line_num, text in lines:
        # Strip leading/trailing whitespace
        text = text.strip()

        # Skip empty lines and comments
        if not text or text.startswith("#"):
            continue

        # Try to match assignment pattern
        match = ASSIGN_RE.match(text)
        if not match:
            continue

        var_name = match.group("name")
        operator = match.group("op")
        rhs = match.group("rhs").strip()

        # Infer type and value from RHS
        kind, value = infer_literal(rhs)

        assignments.append(
            {
                "var": var_name,
                "op": operator,
                "kind": kind,
                "value": value,
                "line": line_num,
            }
        )

    return assignments


def infer_literal(rhs: str) -> Tuple[str, Optional[Any]]:
    """
    Infer the type and value of a literal RHS expression.

    Args:
        rhs: Right-hand side of assignment (e.g., "42", "True", '"hello"')

    Returns:
        (kind, value) where:
        - kind: "number", "boolean", "string", "unknown"
        - value: Parsed value or None if unknown
    """
    # Remove inline comments
    if "#" in rhs:
        rhs = rhs.split("#")[0].strip()

    # Boolean literals
    if rhs in ("True", "False"):
        return ("boolean", rhs == "True")

    # Numeric literals (int or float)
    try:
        if "." in rhs or "e" in rhs.lower():
            return ("number", float(rhs))
        else:
            return ("number", int(rhs))
    except ValueError:
        pass

    # String literals (single or double quotes)
    if (rhs.startswith('"') and rhs.endswith('"')) or (
        rhs.startswith("'") and rhs.endswith("'")
    ):
        return ("string", rhs[1:-1])

    # Unknown (variables, expressions, function calls, etc.)
    return ("unknown", None)


def reconcile_kind(old_kind: str, new_kind: str) -> str:
    """
    Reconcile type kinds when a variable is reassigned.

    If types disagree, mark as "unknown" to flag type inconsistency.

    Args:
        old_kind: Previous type kind
        new_kind: New type kind

    Returns:
        Reconciled kind ("unknown" if inconsistent)
    """
    # First assignment
    if old_kind == "unknown":
        return new_kind

    # Same type - no conflict
    if old_kind == new_kind:
        return old_kind

    # Type mismatch - flag as unknown
    return "unknown"


def apply_op(
    before_value: Optional[Any],
    operator: str,
    rhs_value: Optional[Any],
    before_kind: str = "unknown",
    rhs_kind: str = "unknown",
) -> Tuple[Optional[Any], Optional[float]]:
    """
    Apply an assignment operator to compute after value and delta.

    Args:
        before_value: Previous value (None if unknown)
        operator: "=", "+=", "-="
        rhs_value: Right-hand side value
        before_kind: Type of before value
        rhs_kind: Type of rhs value

    Returns:
        (after_value, delta) where:
        - after_value: New value (None if unknown)
        - delta: Numeric change (None if non-numeric or unknown)
    """
    # Simple assignment: after = rhs
    if operator == "=":
        after = rhs_value

        # Compute delta if both are numeric
        if before_value is not None and rhs_value is not None:
            if before_kind == "number" and rhs_kind == "number":
                try:
                    delta = float(rhs_value) - float(before_value)
                    return (after, delta)
                except (TypeError, ValueError):
                    pass

        return (after, None)

    # Compound assignment: += or -=
    if operator in ("+=", "-="):
        # If rhs is numeric
        if rhs_kind == "number" and rhs_value is not None:
            # If before is unknown, treat as baseline
            if before_value is None:
                after = rhs_value if operator == "+=" else -rhs_value
                delta = after
                return (after, delta)

            # If before is numeric, compute
            if before_kind == "number":
                try:
                    before_num = float(before_value)
                    rhs_num = float(rhs_value)

                    if operator == "+=":
                        after = before_num + rhs_num
                        delta = rhs_num
                    else:  # -=
                        after = before_num - rhs_num
                        delta = -rhs_num

                    return (after, delta)
                except (TypeError, ValueError):
                    pass

        # Non-numeric compound assignment - unknown result
        return (None, None)

    # Unknown operator
    return (None, None)
