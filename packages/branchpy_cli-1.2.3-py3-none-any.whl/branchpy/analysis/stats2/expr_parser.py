"""
Expression Parser for Stats 2.0 Symbolic Analysis

Parses simple Ren'Py variable expressions into AST nodes.

Supported (Phase 3 MVP):
- Literals: 50, 10.5, True, False, "text"
- Variables: trust, gold (without $ prefix)
- Binary ops: +, -

Not supported (Phase 4+):
- Multiply/divide: *, /, //, %
- Parentheses: (a + b) * 2
- Comparisons: >, <, ==, !=
- Function calls: min(), max(), int()
- String concatenation
"""

import re
from dataclasses import dataclass
from typing import Optional, Union

# ============================================================================
# AST Node Types
# ============================================================================


@dataclass
class Const:
    """Constant literal value."""

    value: Union[int, float, bool, str]
    type: str  # 'number', 'boolean', 'string'

    def __repr__(self) -> str:
        if self.type == "string":
            return f'Const("{self.value}", {self.type})'
        return f"Const({self.value}, {self.type})"


@dataclass
class Var:
    """Variable reference (without $ prefix)."""

    name: str

    def __repr__(self) -> str:
        return f"Var({self.name})"


@dataclass
class BinOp:
    """Binary operation (+ or -)."""

    op: str  # '+' or '-'
    left: "Expr"
    right: "Expr"

    def __repr__(self) -> str:
        return f"BinOp({self.op!r}, {self.left!r}, {self.right!r})"


# Type alias for expression nodes
Expr = Union[Const, Var, BinOp]


# ============================================================================
# Parser
# ============================================================================


def parse_expr(text: str) -> Optional[Expr]:
    """
    Parse a simple expression into an AST.

    Supported syntax:
    - Literals: 50, 10.5, True, False, "hello"
    - Variables: trust, gold
    - Binary ops: trust + 10, gold - 5, a + b

    Args:
        text: Expression text (RHS of assignment, no $ prefix on vars)

    Returns:
        AST node or None if parse fails

    Examples:
        >>> parse_expr("50")
        Const(50, number)

        >>> parse_expr("trust")
        Var(trust)

        >>> parse_expr("trust + 10")
        BinOp('+', Var(trust), Const(10, number))

        >>> parse_expr("trust * 2")  # Not supported
        None
    """
    if not text or not isinstance(text, str):
        return None

    # Remove whitespace
    text = text.strip()
    if not text:
        return None

    # Try to parse as binary operation first (contains + or -)
    # Look for + or - NOT inside quotes
    # Simple approach: split on + or - if not in string literal

    # Check if it's a string literal (don't parse operators inside)
    if text.startswith('"') and text.endswith('"'):
        return _parse_string_literal(text)
    if text.startswith("'") and text.endswith("'"):
        return _parse_string_literal(text)

    # Try binary operators (+ and -)
    # Find the operator position (rightmost to handle left-to-right evaluation)
    op_pos = -1
    op_char = None

    # Scan from left to right, find first + or -
    for i, char in enumerate(text):
        if char in ("+", "-"):
            # Make sure it's not part of a negative number at the start
            if char == "-" and i == 0:
                continue  # Could be negative literal
            op_pos = i
            op_char = char
            break

    if op_pos > 0 and op_char:
        # Found a binary operator
        left_text = text[:op_pos].strip()
        right_text = text[op_pos + 1 :].strip()

        if left_text and right_text:
            left_expr = parse_expr(left_text)
            right_expr = parse_expr(right_text)

            if left_expr and right_expr:
                return BinOp(op=op_char, left=left_expr, right=right_expr)

    # Not a binary op, try literal or variable

    # Try boolean literal
    if text == "True":
        return Const(value=True, type="boolean")
    if text == "False":
        return Const(value=False, type="boolean")

    # Try number literal (int or float)
    try:
        # Try int first
        if "." not in text:
            val = int(text)
            return Const(value=val, type="number")
        else:
            val = float(text)
            return Const(value=val, type="number")
    except ValueError:
        pass

    # Try variable (identifier: letters, digits, underscore)
    if _is_identifier(text):
        return Var(name=text)

    # Failed to parse
    return None


def _parse_string_literal(text: str) -> Optional[Const]:
    """Parse a string literal (with quotes)."""
    if len(text) < 2:
        return None

    quote = text[0]
    if text[-1] != quote:
        return None

    # Extract string content (strip quotes)
    content = text[1:-1]
    return Const(value=content, type="string")


def _is_identifier(text: str) -> bool:
    """Check if text is a valid Python identifier (variable name)."""
    if not text:
        return False

    # Simple regex: starts with letter or underscore, contains letters/digits/underscore
    pattern = r"^[a-zA-Z_][a-zA-Z0-9_]*$"
    return bool(re.match(pattern, text))


def is_simple_expr(text: str) -> bool:
    """
    Quick check if text is a parseable expression.

    Faster than full parsing for checking if we should attempt parsing.

    Args:
        text: Expression text

    Returns:
        True if likely parseable (not guaranteed)
    """
    if not text or not isinstance(text, str):
        return False

    text = text.strip()

    # Empty
    if not text:
        return False

    # String literal
    if (text.startswith('"') and text.endswith('"')) or (
        text.startswith("'") and text.endswith("'")
    ):
        return True

    # Boolean literal
    if text in ("True", "False"):
        return True

    # Number literal
    try:
        float(text)
        return True
    except ValueError:
        pass

    # Identifier
    if _is_identifier(text):
        return True

    # Contains + or - (likely binary op)
    if "+" in text or "-" in text:
        # But not if it's just a negative number
        if text.startswith("-") and len(text) > 1:
            try:
                float(text)
                return True  # It's a negative number
            except ValueError:
                pass
        return True

    return False
