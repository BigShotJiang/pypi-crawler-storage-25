"""Cross-Path Stats Aggregation for Stats 2.0

Aggregates variable statistics across multiple execution paths to compute
min/max/avg/delta and detect imbalances.

Phase 3 Update: Leverages computed timelines from expression evaluator to
provide richer statistics including delta series and per-path range tracking.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from statistics import mean, median, pstdev, stdev
from typing import Any, Dict, List, Optional


@dataclass
class VariableAggregateStats:
    """Aggregate statistics for a variable across all paths."""

    var_name: str

    # Path coverage
    paths_where_assigned: int = 0
    paths_where_read: int = 0
    total_paths: int = 0

    # Numeric stats (if applicable)
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    mean_value: Optional[float] = None
    median_value: Optional[float] = None
    stddev_value: Optional[float] = None

    # Value distribution
    value_distribution: Dict[Any, int] = field(default_factory=dict)  # value -> count

    # Delta analysis (change from start to end of path)
    min_delta: Optional[float] = None
    max_delta: Optional[float] = None
    mean_delta: Optional[float] = None

    # Type consistency
    types_seen: List[str] = field(default_factory=list)
    is_type_consistent: bool = True

    # Flags for special patterns
    is_stat_variable: bool = False  # trust, affection, etc.
    is_flag_variable: bool = False  # is_*, has_*, *_flag
    is_potentially_unused: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON export."""
        return {
            "var_name": self.var_name,
            "coverage": {
                "assigned_in": self.paths_where_assigned,
                "read_in": self.paths_where_read,
                "total_paths": self.total_paths,
                "assignment_rate": (
                    self.paths_where_assigned / self.total_paths
                    if self.total_paths > 0
                    else 0
                ),
            },
            "numeric_stats": (
                {
                    "min": self.min_value,
                    "max": self.max_value,
                    "mean": self.mean_value,
                    "median": self.median_value,
                    "stddev": self.stddev_value,
                }
                if self.min_value is not None
                else None
            ),
            "delta_stats": (
                {
                    "min": self.min_delta,
                    "max": self.max_delta,
                    "mean": self.mean_delta,
                }
                if self.min_delta is not None
                else None
            ),
            "type_consistency": {
                "types": self.types_seen,
                "is_consistent": self.is_type_consistent,
            },
            "flags": {
                "is_stat": self.is_stat_variable,
                "is_flag": self.is_flag_variable,
                "potentially_unused": self.is_potentially_unused,
            },
        }


def _safe_stats(nums: List[float]) -> Optional[Dict[str, Any]]:
    """Compute statistics from a list of numbers, handling edge cases.

    Args:
        nums: List of numeric values

    Returns:
        Dictionary with min/max/mean/median/stddev or None if empty
    """
    if not nums:
        return None
    if len(nums) == 1:
        n = nums[0]
        return {"min": n, "max": n, "mean": n, "median": n, "stddev": 0.0}
    return {
        "min": min(nums),
        "max": max(nums),
        "mean": float(mean(nums)),
        "median": float(median(nums)),
        "stddev": float(pstdev(nums)),  # population stddev
    }


class StatsAggregator:
    """Aggregates variable statistics across multiple execution paths."""

    def __init__(self):
        self.aggregates: Dict[str, VariableAggregateStats] = {}

    def aggregate_paths(
        self, path_analyses: Dict[List[str], Dict[str, List[Any]]]
    ) -> Dict[str, VariableAggregateStats]:
        """Aggregate statistics from multiple path analyses.

        Args:
            path_analyses: Dictionary mapping paths to their variable change timelines
                          Format: {path: {var_name: [StateChange, ...]}}

        Returns:
            Dictionary mapping variable names to aggregate statistics
        """
        # Reset aggregates
        self.aggregates = {}

        total_paths = len(path_analyses)

        # Collect all variables across all paths
        all_vars: set[str] = set()
        for path_changes in path_analyses.values():
            all_vars.update(path_changes.keys())

        # Aggregate stats for each variable
        for var_name in all_vars:
            stats = VariableAggregateStats(var_name=var_name, total_paths=total_paths)

            # Collect data from all paths
            final_values: List[float] = []
            deltas: List[float] = []
            types_seen: set[str] = set()

            for path, path_changes in path_analyses.items():
                if var_name in path_changes:
                    changes = path_changes[var_name]
                    stats.paths_where_assigned += 1

                    # Get final state and delta
                    if changes:
                        final_state = (
                            changes[-1].after if hasattr(changes[-1], "after") else None
                        )
                        initial_state = (
                            changes[0].before if hasattr(changes[0], "before") else None
                        )

                        if final_state:
                            types_seen.add(
                                getattr(final_state, "value_type", "unknown")
                            )

                            # Track numeric values
                            if (
                                hasattr(final_state, "value_type")
                                and final_state.value_type == "number"
                            ):
                                try:
                                    val = float(final_state.value)
                                    final_values.append(val)

                                    # Calculate delta
                                    if initial_state and hasattr(
                                        initial_state, "value"
                                    ):
                                        try:
                                            initial_val = (
                                                float(initial_state.value)
                                                if initial_state.value is not None
                                                else 0
                                            )
                                            deltas.append(val - initial_val)
                                        except (TypeError, ValueError):
                                            pass
                                except (TypeError, ValueError):
                                    pass

            # Compute numeric statistics
            if final_values:
                stats.min_value = min(final_values)
                stats.max_value = max(final_values)
                stats.mean_value = mean(final_values)
                stats.median_value = median(final_values)
                if len(final_values) > 1:
                    stats.stddev_value = stdev(final_values)

            # Compute delta statistics
            if deltas:
                stats.min_delta = min(deltas)
                stats.max_delta = max(deltas)
                stats.mean_delta = mean(deltas)

            # Type consistency check
            stats.types_seen = list(types_seen)
            stats.is_type_consistent = len(types_seen) <= 1 or (
                len(types_seen) == 2 and "unknown" in types_seen
            )

            # Detect special patterns
            var_lower = var_name.lower()
            stats.is_stat_variable = any(
                pattern in var_lower
                for pattern in [
                    "trust",
                    "affection",
                    "relationship",
                    "score",
                    "points",
                    "level",
                    "boldness",
                    "obedience",
                    "loyalty",
                    "friendship",
                    "love",
                    "respect",
                ]
            )
            stats.is_flag_variable = (
                var_lower.startswith("is_")
                or var_lower.startswith("has_")
                or var_lower.endswith("_flag")
            )
            # NOTE: paths_where_read is not yet populated (read tracking unimplemented).
            # Setting potentially_unused=False prevents all variables from being
            # incorrectly flagged. Re-enable once read tracking is in place.
            stats.is_potentially_unused = False  # TODO: track reads

            self.aggregates[var_name] = stats

        return self.aggregates

    def get_imbalanced_stats(
        self, threshold: float = 0.5
    ) -> List[VariableAggregateStats]:
        """Find stat variables with high variance (potential balance issues).

        Args:
            threshold: Coefficient of variation threshold (stddev/mean)

        Returns:
            List of stat variables with high variance
        """
        imbalanced = []

        for stats in self.aggregates.values():
            if (
                stats.is_stat_variable
                and stats.mean_value is not None
                and stats.stddev_value is not None
                and stats.mean_value > 0
            ):

                cv = stats.stddev_value / stats.mean_value
                if cv > threshold:
                    imbalanced.append(stats)

        return sorted(imbalanced, key=lambda s: s.stddev_value or 0, reverse=True)

    def get_type_inconsistencies(self) -> List[VariableAggregateStats]:
        """Find variables with type consistency issues."""
        return [
            stats for stats in self.aggregates.values() if not stats.is_type_consistent
        ]

    def aggregate_paths_v2(
        self, path_analyses: Dict[tuple, Dict[str, List[Any]]]
    ) -> Dict[str, Dict[str, Any]]:
        """Aggregate statistics using Phase 3 computed timelines (v2 schema).

        This new method leverages expression evaluation results to provide:
        - Legacy top-level stats (final "after" per path) - backward compatible
        - Delta series (all numeric deltas across all changes)
        - Path ranges (per-path min/max span for volatility tracking)
        - Enhanced counts and diagnostics

        Args:
            path_analyses: Dictionary mapping path tuples to variable change timelines
                          Format: {path_tuple: {var_name: [StateChange, ...]}}

        Returns:
            Dictionary with enhanced aggregate stats per variable (v2 schema)
        """
        by_var_finals: Dict[str, List[float]] = {}
        by_var_deltas: Dict[str, List[float]] = {}
        by_var_spans: Dict[str, List[float]] = {}
        by_var_types: Dict[str, set] = {}

        total_paths = len(path_analyses)

        for path_tuple, var_map in path_analyses.items():
            for var, changes in var_map.items():
                # Initialize collections
                finals_list = by_var_finals.setdefault(var, [])
                deltas_list = by_var_deltas.setdefault(var, [])
                spans_list = by_var_spans.setdefault(var, [])
                types_set = by_var_types.setdefault(var, set())

                # Collect numeric deltas from all changes
                for change in changes:
                    # Track types
                    if hasattr(change, "after") and change.after:
                        types_set.add(getattr(change.after, "value_type", "unknown"))

                    # Deltas via the delta() method or compute from before/after
                    if hasattr(change, "delta"):
                        delta_val = change.delta()
                        if delta_val is not None:
                            deltas_list.append(float(delta_val))
                    elif hasattr(change, "before") and hasattr(change, "after"):
                        before_val = (
                            getattr(change.before, "value", None)
                            if change.before
                            else None
                        )
                        after_val = (
                            getattr(change.after, "value", None)
                            if change.after
                            else None
                        )
                        if isinstance(before_val, (int, float)) and isinstance(
                            after_val, (int, float)
                        ):
                            deltas_list.append(float(after_val) - float(before_val))

                # Collect per-path "after" values for span calculation
                after_vals = []
                for change in changes:
                    if hasattr(change, "after") and change.after:
                        val = getattr(change.after, "value", None)
                        if isinstance(val, (int, float)):
                            after_vals.append(float(val))

                if after_vals:
                    # Span = range within this path
                    span = max(after_vals) - min(after_vals)
                    spans_list.append(span)

                # Final "after" (MUST be the actual last value, and it must be numeric)
                if changes:
                    last_change = changes[-1]
                    if hasattr(last_change, "after") and last_change.after:
                        val = getattr(last_change.after, "value", None)
                        if isinstance(val, (int, float)):
                            finals_list.append(float(val))

        # Build aggregates with new schema
        aggregates = {}
        all_vars = sorted(set(by_var_finals) | set(by_var_deltas) | set(by_var_spans))

        for var in all_vars:
            finals_stats = _safe_stats(by_var_finals.get(var, []))
            delta_stats = _safe_stats(by_var_deltas.get(var, []))
            span_stats = _safe_stats(by_var_spans.get(var, []))

            entry = {}

            # Legacy top-level stats (basis: final "after" per path)
            if finals_stats:
                entry.update(finals_stats)
                entry["basis"] = "after"
            else:
                entry.update(
                    {
                        "min": None,
                        "max": None,
                        "mean": None,
                        "median": None,
                        "stddev": None,
                        "basis": "after",
                    }
                )

            # Counts diagnostics
            entry["counts"] = {
                "paths": total_paths,
                "finals": len(by_var_finals.get(var, [])),
                "deltas": len(by_var_deltas.get(var, [])),
            }

            # Series: separate stats for finals vs deltas
            entry["series"] = {
                "after": finals_stats
                or {
                    "min": None,
                    "max": None,
                    "mean": None,
                    "median": None,
                    "stddev": None,
                },
                "delta": delta_stats
                or {
                    "min": None,
                    "max": None,
                    "mean": None,
                    "median": None,
                    "stddev": None,
                },
            }

            # Path ranges (intra-path volatility)
            if span_stats:
                entry["pathRanges"] = {
                    "minSpan": span_stats["min"],
                    "maxSpan": span_stats["max"],
                    "meanSpan": span_stats["mean"],
                    "medianSpan": span_stats["median"],
                    "observations": len(by_var_spans.get(var, [])),
                }
            else:
                entry["pathRanges"] = {
                    "minSpan": None,
                    "maxSpan": None,
                    "meanSpan": None,
                    "medianSpan": None,
                    "observations": 0,
                }

            # Type consistency
            types_seen = list(by_var_types.get(var, set()))
            is_consistent = len(types_seen) <= 1 or (
                len(types_seen) == 2 and "unknown" in types_seen
            )
            entry["type_consistency"] = {
                "types": types_seen,
                "is_consistent": is_consistent,
            }

            # Pattern detection flags
            var_lower = var.lower()
            entry["flags"] = {
                "is_stat": any(
                    pattern in var_lower
                    for pattern in [
                        "trust",
                        "affection",
                        "relationship",
                        "score",
                        "points",
                        "level",
                        "boldness",
                        "obedience",
                        "loyalty",
                        "friendship",
                        "love",
                        "respect",
                    ]
                ),
                "is_flag": (
                    var_lower.startswith("is_")
                    or var_lower.startswith("has_")
                    or var_lower.endswith("_flag")
                ),
                "potentially_unused": False,  # TODO: track from reads
            }

            aggregates[var] = entry

        return aggregates

    def compute_high_variance_flags(
        self, aggregates: Dict[str, Dict[str, Any]]
    ) -> List[str]:
        """Identify variables with high variance based on final "after" values.

        Rule: Flag if stddev >= max(5.0, mean * 0.25)

        Args:
            aggregates: Aggregates dictionary from aggregate_paths_v2

        Returns:
            List of variable names with high variance
        """
        flagged = []
        for var, agg in aggregates.items():
            series_after = agg.get("series", {}).get("after", {})
            mean_after = series_after.get("mean")
            stddev_after = series_after.get("stddev")

            if isinstance(mean_after, (int, float)) and isinstance(
                stddev_after, (int, float)
            ):
                threshold = max(5.0, float(mean_after) * 0.25)
                if stddev_after >= threshold:
                    flagged.append(var)

        return sorted(flagged)

    def to_dict(self) -> Dict[str, Any]:
        """Export all aggregate statistics to dictionary."""
        return {
            var_name: stats.to_dict() for var_name, stats in self.aggregates.items()
        }
