"""Stats 2.0 - Path-Aware Variable Analysis

This module provides advanced statistical analysis capabilities with path-aware
variable tracking, enabling per-route analysis of variable evolution.

Components:
- path_stats: Per-path variable tracking and timeline generation
- aggregator: Cross-path aggregation and statistical summaries
- exporter: Stats 2.0 JSON export schema
- assignment_extractor: Parse simple Ren'Py variable assignments
- compute: Unified SAE integration and stats computation
- registry: Lazy-loading component registry
- ranges: CFG interval estimation for stat bounds

v0.7.29: Stats 2.x finalization - SAE unification, ranges MVP, lazy loading.
"""

from .aggregator import StatsAggregator
from .assignment_extractor import (
    apply_op,
    extract_simple_assignments,
    infer_literal,
    reconcile_kind,
)
from .compute import compute, merge_sae
from .exporter import Stats2Exporter
from .path_stats import PathStatsAnalyzer, VariableState
from .ranges import Ranges
from .registry import registry

__all__ = [
    "PathStatsAnalyzer",
    "VariableState",
    "StatsAggregator",
    "Stats2Exporter",
    "extract_simple_assignments",
    "infer_literal",
    "reconcile_kind",
    "apply_op",
    "registry",
    "compute",
    "merge_sae",
    "Ranges",
]

__version__ = "0.8.0"
