"""
Stats 2.x Compute - Unified SAE Integration
===========================================

Merges SAE (Static Analysis Engine) data with Stats 2.x analysis.
Provides unified reading-time, path metrics, usage/modifies tracking.

v0.7.29: Complete SAE unification for Stats 2.x.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional

from .registry import registry


def merge_sae(project_model: Any, sae_index: Any) -> Dict[str, Any]:
    """Merge SAE aggregates into stats payload.

    Unifies SAE data (reading-time, paths) with Stats 2.x metrics.

    Args:
        project_model: Project model from analysis
        sae_index: SAE indexer instance

    Returns:
        Dict with reading_time and paths_summary
    """
    result = {}

    # Extract reading-time data from SAE
    if hasattr(sae_index, "reading_time"):
        result["reading_time"] = sae_index.reading_time()

    # Extract path summaries from SAE
    if hasattr(sae_index, "paths_summary"):
        result["paths"] = sae_index.paths_summary()

    return result


def compute(
    project_model: Any,
    sae_index: Any,
    cfg: Dict[str, Any],
    policy_mode: str = "off",
    policy_json: Optional[Path] = None,
) -> Dict[str, Any]:
    """Compute complete Stats 2.x report with SAE unification.

    Main entry point for Stats 2.x computation. Merges:
    - Usage tracking (symbols, labels, files)
    - Modifies tracking (assignments)
    - Read locations (with deep links)
    - Config bounds (from config)
    - Ranges (interval estimation)

    Args:
        project_model: Project model from analysis
        sae_index: SAE indexer instance
        cfg: Configuration dict (may contain min_max bounds)
        policy_mode: Policy enforcement mode (off|warn|strict)
        policy_json: Optional path to policy JSON file

    Returns:
        Complete stats report dict
    """
    # Extract core metrics
    usage = _usage(project_model)
    modifies = _modifies(project_model)
    read_locations = _read_locs(project_model)

    # Get config bounds if available
    config_bounds = cfg.get("min_max", {}) if cfg else {}

    # Compute ranges using lazy-loaded registry
    ranges = {}
    try:
        ranges_module = registry.get("ranges")
        ranges = ranges_module.estimate(project_model, config_bounds)
    except (KeyError, Exception):
        # Ranges module not available or failed - continue without
        ranges = {"by_node": {}}

    # Build complete report
    report = {
        "stats": {
            "usage": usage,
            "modifies": modifies,
            "read_locations": read_locations,
            "config_bounds": config_bounds,
            "ranges": ranges,
        }
    }

    # Merge SAE data if available
    if sae_index:
        sae_data = merge_sae(project_model, sae_index)
        report["stats"].update(sae_data)

    return report


def _usage(project_model: Any) -> Dict[str, Dict[str, int]]:
    """Extract usage frequencies (symbols, labels, files).

    Args:
        project_model: Project model

    Returns:
        Dict with symbols, labels, files usage counts
    """
    usage = {"symbols": {}, "labels": {}, "files": {}}

    # Extract from project model if available
    if hasattr(project_model, "get_usage"):
        usage_data = project_model.get_usage()
        if isinstance(usage_data, dict):
            usage.update(usage_data)

    return usage


def _modifies(project_model: Any) -> Dict[str, int]:
    """Extract modification frequencies (assignments).

    Args:
        project_model: Project model

    Returns:
        Dict mapping variable names to modification counts
    """
    modifies = {}

    # Extract from project model if available
    if hasattr(project_model, "get_modifies"):
        modifies_data = project_model.get_modifies()
        if isinstance(modifies_data, dict):
            modifies.update(modifies_data)

    return modifies


def _read_locs(project_model: Any) -> List[Dict[str, Any]]:
    """Extract read locations with deep links.

    Args:
        project_model: Project model

    Returns:
        List of read location dicts with file, line, label, deeplink
    """
    locations = []

    # Extract from project model if available
    if hasattr(project_model, "get_read_locations"):
        locs_data = project_model.get_read_locations()
        if isinstance(locs_data, list):
            locations.extend(locs_data)

    return locations
