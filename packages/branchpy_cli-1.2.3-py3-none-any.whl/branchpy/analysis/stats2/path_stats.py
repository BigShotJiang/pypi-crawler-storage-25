"""Path-Aware Variable Tracking for Stats 2.0

This module tracks variable state changes along specific execution paths,
enabling per-route statistical analysis.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

# Import state change tracker (PILOT integration)
try:
    from branchpy.sae.state_tracker import StateChangeTracker

    _HAS_STATE_TRACKER = True
except ImportError:
    _HAS_STATE_TRACKER = False
    StateChangeTracker: Optional[type] = None  # type: ignore

# Import assignment extractor
try:
    from .assignment_extractor import (
        apply_op,
        extract_simple_assignments,
        reconcile_kind,
    )

    _HAS_EXTRACTOR = True
except ImportError:
    _HAS_EXTRACTOR = False
    extract_simple_assignments: Optional[Callable] = None  # type: ignore
    reconcile_kind: Optional[Callable] = None  # type: ignore
    apply_op: Optional[Callable] = None  # type: ignore

# Import expression parser and evaluator (Phase 3)
try:
    from .expr_evaluator import eval_expr
    from .expr_parser import is_simple_expr, parse_expr

    _HAS_EXPR_EVAL = True
except ImportError:
    _HAS_EXPR_EVAL = False
    parse_expr: Optional[Callable] = None  # type: ignore
    is_simple_expr: Optional[Callable] = None  # type: ignore
    eval_expr: Optional[Callable] = None  # type: ignore

# Import variable flow analysis utilities (legacy)
try:
    from ..variable_flow import extract_assignments_from_cfg

    _HAS_VARIABLE_FLOW = True
except ImportError:
    _HAS_VARIABLE_FLOW = False
    extract_assignments_from_cfg = None  # type: ignore


@dataclass
class VariableState:
    """Represents the state of a variable at a specific point in execution."""

    var_name: str
    value: Any = None  # Symbolic value (number, bool, string, or unknown)
    value_type: str = "unknown"  # number, bool, string, list, dict, unknown
    min_value: Optional[float] = None  # For numeric variables
    max_value: Optional[float] = None  # For numeric variables
    possible_values: Set[Any] = field(default_factory=set)  # For enums/strings

    # Metadata
    file: Optional[str] = None
    line: Optional[int] = None
    label: Optional[str] = None  # Label where this state was set
    node_id: Optional[str] = None  # CFG node ID

    def __repr__(self) -> str:
        if self.value_type == "number" and self.min_value is not None:
            return f"{self.var_name}={self.value} [{self.min_value}..{self.max_value}]"
        elif self.value_type in ("string", "bool"):
            return f"{self.var_name}={self.value!r}"
        else:
            return f"{self.var_name}=<{self.value_type}>"


@dataclass
class StateChange:
    """Represents a change to a variable's state along a path."""

    var_name: str
    before: Optional[VariableState]
    after: VariableState
    operation: str  # "assign", "modify", "increment", "decrement"

    # Location
    file: str
    line: int
    label: Optional[str] = None
    node_id: Optional[str] = None

    # Phase 3: Expression evaluation diagnostics (optional)
    expr: Optional[str] = None  # RHS source expression
    eval_result: Optional[Dict[str, Any]] = None  # {value, kind, unknown}
    is_calculated: bool = False  # True if computed from expression

    # Phase 3 Commit 5: Guard annotations (read-only, optional)
    guard: Optional[str] = None  # Condition text that led to this label

    def delta(self) -> Optional[float]:
        """Calculate numeric delta if both states are numeric."""
        if (
            self.before
            and self.before.value_type == "number"
            and self.after.value_type == "number"
        ):
            try:
                before_val = (
                    float(self.before.value) if self.before.value is not None else 0
                )
                after_val = (
                    float(self.after.value) if self.after.value is not None else 0
                )
                return after_val - before_val
            except (TypeError, ValueError):
                return None
        return None


class PathStatsAnalyzer:
    """Analyzes variable statistics along specific execution paths.

    This class integrates with the PathEnumerator to track variable states
    as they evolve through different story routes.
    """

    def __init__(self, cfg_graph, index=None, project_root: Optional[Path] = None):
        """Initialize the path stats analyzer.

        Args:
            cfg_graph: Control flow graph from SAE
            index: Optional SAE index for variable metadata
            project_root: Project root directory
        """
        self.cfg = cfg_graph
        self.index = index
        self.project_root = Path(project_root) if project_root else None

        # Cache of variable states by path
        self._path_states: Dict[tuple, Dict[str, List[VariableState]]] = {}

        # Variable timeline cache (path_tuple -> var_name -> changes)
        self._timelines: Dict[tuple, Dict[str, List[StateChange]]] = {}

        # Assignment cache (label -> list of assignment events)
        self._assignment_cache: Dict[str, List[Dict[str, Any]]] = {}

        # PILOT: State change tracker for engine-agnostic variable analysis
        if _HAS_STATE_TRACKER:
            self.state_tracker = StateChangeTracker()  # type: ignore
        else:
            self.state_tracker = None

        # Build assignment cache from CFG
        if _HAS_EXTRACTOR:
            self._build_assignment_cache()
        else:
            print("[PathStatsAnalyzer] Warning: assignment_extractor not available")

    def _build_assignment_cache(self):
        """Build cache of assignments for each label by reading source files and matching to CFG nodes."""
        # Handle both CFG styles: method-based (mock) and attribute-based (real)
        if hasattr(self.cfg, "nodes"):
            if callable(self.cfg.nodes):
                # Method-based (mock CFG)
                nodes_dict = self.cfg.nodes()
            elif isinstance(self.cfg.nodes, dict):
                # Attribute-based (real CFG)
                nodes_dict = self.cfg.nodes
            else:
                nodes_dict = {}
        else:
            nodes_dict = {}

        # First pass: Extract from mock python nodes (for testing)
        # This handles mock CFGs where assignments are in node.meta["code"]
        if hasattr(self.cfg, "edges"):
            if callable(self.cfg.edges):
                edges_list = self.cfg.edges()
            elif isinstance(self.cfg.edges, list):
                edges_list = self.cfg.edges
            else:
                edges_list = []
        else:
            edges_list = []

        # Build adjacency to find which python nodes follow which labels
        label_to_python: Dict[str, List[str]] = {}  # label_name -> [python_node_ids]
        for edge in edges_list:
            src = getattr(edge, "from_node", None)
            dst = getattr(edge, "to_node", None)
            if not src or not dst:
                continue

            src_node = nodes_dict.get(src)
            dst_node = nodes_dict.get(dst)
            if not src_node or not dst_node:
                continue

            src_kind = str(getattr(src_node, "kind", ""))
            dst_kind = str(getattr(dst_node, "kind", ""))
            src_name = getattr(src_node, "name", None)

            # If source is a label and dest is python, associate them
            if (
                "label" in src_kind.lower()
                and src_name
                and "python" in dst_kind.lower()
            ):
                label_to_python.setdefault(src_name, []).append(dst)

        # Extract assignments from python nodes following labels
        for label_name, python_node_ids in label_to_python.items():
            assignments_for_label = []
            for python_id in python_node_ids:
                python_node = nodes_dict.get(python_id)
                if not python_node:
                    continue

                meta = getattr(python_node, "meta", {})
                code = meta.get("code", "") if isinstance(meta, dict) else ""

                if code:
                    # Extract assignments from this code line
                    code_lines = [(1, code)]  # Line number doesn't matter for mock
                    extracted = extract_simple_assignments(code_lines)  # type: ignore
                    if extracted:
                        # Add source for debugging
                        for assignment in extracted:
                            assignment.setdefault("src", code)
                        assignments_for_label.extend(extracted)

            if assignments_for_label:
                self._assignment_cache[label_name] = assignments_for_label

        # Second pass: Group nodes by file for file-based extraction (real CFGs)
        nodes_by_file: Dict[str, List[tuple]] = {}  # file -> [(node_id, node), ...]

        for node_id, node in nodes_dict.items():
            kind = getattr(node, "kind", None)
            name = getattr(node, "name", None)
            file_path = getattr(node, "file", None)

            # Only process label nodes with file info
            if str(kind) != "NodeKind.LABEL" or not name or not file_path:
                continue

            nodes_by_file.setdefault(file_path, []).append((node_id, node))

        # Read source files and extract assignments
        for file_path, file_nodes in nodes_by_file.items():
            # Read source file
            source_lines = self._read_source_file(file_path)
            if not source_lines:
                continue

            # Process each label in this file
            for node_id, node in file_nodes:
                label_name = getattr(node, "name", None)
                label_line = getattr(node, "line", None)

                if not label_name or label_line is None:
                    continue

                # Skip if we already extracted from mock nodes
                if label_name in self._assignment_cache:
                    continue

                # Extract code lines for this label (from label line to next label or EOF)
                label_code_lines = self._extract_label_code_lines(
                    source_lines, label_line, file_nodes
                )

                if not label_code_lines:
                    continue

                # Extract assignments
                assignments = extract_simple_assignments(label_code_lines)  # type: ignore

                if assignments:
                    self._assignment_cache[label_name] = assignments
                    print(
                        f"[PathStatsAnalyzer] Label '{label_name}': {len(assignments)} assignments"
                    )

    def _read_source_file(self, file_path: str) -> List[tuple]:
        """Read source file and return list of (line_num, text) tuples.

        Args:
            file_path: Path to source file (may be relative or absolute)

        Returns:
            List of (1-based line number, line text) tuples
        """
        # Convert to Path object
        path = Path(file_path)

        # If already absolute and exists, use it
        if path.is_absolute() and path.exists():
            full_path = path
        # Otherwise, try relative to project root
        elif self.project_root:
            full_path = self.project_root / file_path
            if not full_path.exists():
                # Try removing project_root prefix if it's in the path
                try:
                    rel_path = path.relative_to(self.project_root)
                    full_path = self.project_root / rel_path
                except ValueError:
                    pass
        else:
            return []

        if not full_path.exists():
            print(
                f"[PathStatsAnalyzer] File not found: {file_path} (tried: {full_path})"
            )
            return []

        try:
            with open(full_path, "r", encoding="utf-8") as f:
                lines = [(i + 1, line.rstrip("\n\r")) for i, line in enumerate(f)]
            return lines
        except Exception as e:
            print(f"[PathStatsAnalyzer] Error reading {file_path}: {e}")
            return []

    def _extract_label_code_lines(
        self, source_lines: List[tuple], label_line: int, all_file_nodes: List[tuple]
    ) -> List[tuple]:
        """Extract code lines belonging to a label (from label line to next label).

        Args:
            source_lines: All (line_num, text) tuples from source file
            label_line: Line number where this label starts
            all_file_nodes: All nodes in this file (to find next label)

        Returns:
            List of (line_num, text) tuples for this label's code
        """
        # Find next label line (if any)
        next_label_line = None
        for _, node in all_file_nodes:
            node_line = getattr(node, "line", None)
            if node_line and node_line > label_line:
                if next_label_line is None or node_line < next_label_line:
                    next_label_line = node_line

        # Extract lines between this label and next (or EOF)
        end_line = next_label_line if next_label_line else float("inf")

        label_lines = []
        for line_num, text in source_lines:
            if label_line <= line_num < end_line:
                # Skip the label definition line itself (e.g., "label start:")
                if line_num == label_line and text.strip().startswith("label "):
                    continue
                label_lines.append((line_num, text))

        return label_lines

    def _extract_guard_from_label(self, label: str) -> Optional[str]:
        """Extract guard condition text that leads to this label (Phase 3 Commit 5).

        Detects control-flow conditions (if/elif/menu) from CFG predecessors.
        Returns None if no guard or if extraction fails.

        Args:
            label: Label name to check for incoming guards

        Returns:
            Guard text (e.g., "trust > 50") or None
        """
        try:
            # Try to get CFG node for this label
            nodes_dict = (
                self.cfg.nodes
                if hasattr(self.cfg, "nodes") and isinstance(self.cfg.nodes, dict)
                else {}
            )

            # Find node with matching label name
            label_node_id = None
            for node_id, node in nodes_dict.items():
                name = (
                    node.get("name")
                    if isinstance(node, dict)
                    else getattr(node, "name", None)
                )
                if name == label:
                    label_node_id = node_id
                    break

            if not label_node_id:
                return None

            # Get predecessor edges
            guards = []
            if hasattr(self.cfg, "get_predecessors"):
                pred_ids = self.cfg.get_predecessors(label_node_id)
            elif hasattr(self.cfg, "edges"):
                # Fallback: manually search edges
                pred_ids = []
                for edge in self.cfg.edges:
                    to_node = (
                        edge.to_node
                        if hasattr(edge, "to_node")
                        else edge.get("to_node")
                    )
                    if to_node == label_node_id:
                        from_node = (
                            edge.from_node
                            if hasattr(edge, "from_node")
                            else edge.get("from_node")
                        )
                        pred_ids.append(from_node)
            else:
                pred_ids = []

            # Check each predecessor for condition text
            for pred_id in pred_ids:
                pred_node = nodes_dict.get(pred_id)
                if not pred_node:
                    continue

                # Try to extract condition from edge
                guard_text = None
                for edge in self.cfg.edges if hasattr(self.cfg, "edges") else []:
                    from_n = (
                        edge.from_node
                        if hasattr(edge, "from_node")
                        else edge.get("from_node")
                    )
                    to_n = (
                        edge.to_node
                        if hasattr(edge, "to_node")
                        else edge.get("to_node")
                    )

                    if from_n == pred_id and to_n == label_node_id:
                        # Check edge type and condition
                        edge_type = (
                            edge.edge_type
                            if hasattr(edge, "edge_type")
                            else edge.get("edge_type")
                        )

                        # BRANCH_TRUE or BRANCH_FALSE edges may have conditions
                        if str(edge_type) in (
                            "EdgeType.BRANCH_TRUE",
                            "EdgeType.BRANCH_FALSE",
                            "branch_true",
                            "branch_false",
                        ):
                            # Try to get condition from edge
                            cond = (
                                getattr(edge, "cond", None) or edge.get("cond")
                                if isinstance(edge, dict)
                                else None
                            )
                            label_text = (
                                getattr(edge, "label", None) or edge.get("label")
                                if isinstance(edge, dict)
                                else None
                            )

                            if cond:
                                guard_text = str(cond).strip()
                            elif label_text and not label_text.startswith('"'):
                                # Menu choice text (not a dialogue label)
                                guard_text = f'choice="{label_text}"'

                        break

                # Fallback: Try to extract from predecessor node itself
                if not guard_text:
                    guard_text = self._best_effort_condition_text(pred_node)

                if guard_text:
                    guards.append(guard_text)

            if not guards:
                return None

            # Deduplicate and join with &&
            unique_guards = []
            for g in guards:
                if g not in unique_guards:
                    unique_guards.append(g)

            return " && ".join(unique_guards) if unique_guards else None

        except Exception:
            # Fail-open: return None if anything goes wrong
            return None

    def _best_effort_condition_text(self, node: Any) -> Optional[str]:
        """Best-effort extraction of condition text from a CFG node.

        Args:
            node: CFG node (dict or object)

        Returns:
            Condition text or None
        """
        try:
            # Check node metadata for condition
            if isinstance(node, dict):
                meta = node.get("meta", {})
                cond = meta.get("condition") or meta.get("cond")
                if cond:
                    return str(cond).strip()
            else:
                meta = getattr(node, "meta", {})
                if isinstance(meta, dict):
                    cond = meta.get("condition") or meta.get("cond")
                    if cond:
                        return str(cond).strip()

            return None
        except Exception:
            return None

    def analyze_path(self, path: List[str]) -> Dict[str, List[StateChange]]:
        """Analyze variable changes along a specific path.

        This builds the complete timeline of variable state changes by:
        1. Walking through each label in the path
        2. Applying assignments found at each label
        3. Tracking before/after state and computing deltas
        4. Evaluating RHS expressions when possible (Phase 3)
        5. Recording engine-agnostic state changes (PILOT)

        Args:
            path: List of label names representing the execution path

        Returns:
            Dictionary mapping variable names to their change timeline
        """
        path_key = tuple(path)

        # Return cached result if available
        if path_key in self._timelines:
            return self._timelines[path_key]

        # PILOT: Initialize state tracker for this path
        if self.state_tracker:
            self.state_tracker.start_path(
                path_id="-".join(path[:3]) if len(path) > 0 else "empty"
            )

        # Track state changes along the path
        changes: Dict[str, List[StateChange]] = {}
        current_states: Dict[str, Dict[str, Any]] = {}  # var -> {value, kind}
        env: Dict[str, Any] = {}  # Environment for expression evaluation

        # Phase 3 Commit 5: Track pending guards for labels
        pending_guards: Dict[str, str] = {}  # label -> guard text

        # Walk through each label in the path
        for step_index, label in enumerate(path):
            # PILOT: Enter label for state tracking
            if self.state_tracker:
                self.state_tracker.enter_label(label)

            # Extract guard condition for this label (if any)
            guard_text = self._extract_guard_from_label(label)
            if guard_text:
                pending_guards[label] = guard_text

            # Get assignments at this label from cache
            assignments = self._assignment_cache.get(label, [])

            # Track if this is the first change at this label (for guard attachment)
            first_change_at_label = True

            for assignment in assignments:
                var_name = assignment["var"]
                operator = assignment["op"]
                rhs_src = assignment.get("src", "")  # RHS source text
                line_num = assignment["line"]

                # Get current state (before)
                before_state = current_states.get(
                    var_name, {"value": None, "kind": "unknown"}
                )
                before_value = before_state["value"]
                before_kind = before_state["kind"]

                # Phase 3: Try expression evaluation first
                rhs_value = None
                rhs_kind = "unknown"
                expr_str = None
                eval_result_dict = None
                is_calc = False
                expr_evaluated = False  # Track if we evaluated an expression

                if _HAS_EXPR_EVAL and rhs_src and is_simple_expr(rhs_src):  # type: ignore
                    # Parse and evaluate expression
                    ast = parse_expr(rhs_src)  # type: ignore
                    if ast:
                        eval_result = eval_expr(ast, env)  # type: ignore
                        # Capture result even if there's an error (e.g., string arithmetic)
                        # The error just means we can't compute a concrete value
                        expr_evaluated = True
                        expr_str = rhs_src
                        eval_result_dict = {
                            "value": eval_result.value,
                            "kind": eval_result.kind,
                            "unknown": eval_result.unknown,
                        }

                        # Only use the evaluated value if it's not unknown
                        if not eval_result.unknown:
                            rhs_value = eval_result.value
                            rhs_kind = eval_result.kind
                            is_calc = True

                # Fallback to literal parsing if expression evaluation failed
                if not expr_evaluated:
                    rhs_value = assignment.get("value")
                    rhs_kind = assignment.get("kind", "unknown")

                # Apply operator to compute after value
                after_value, delta = self._apply_operator(
                    operator, before_value, rhs_value, before_kind, rhs_kind
                )

                # Reconcile type
                after_kind = reconcile_kind(before_kind, rhs_kind)  # type: ignore

                # Get file path for this label (if available)
                file_path = self._get_file_for_label(label)

                # Phase 3 Commit 5: Attach guard to first change at this label
                change_guard = None
                if first_change_at_label and label in pending_guards:
                    change_guard = pending_guards.pop(label)
                    first_change_at_label = False

                # Create state change record
                before_var_state = (
                    VariableState(
                        var_name=var_name,
                        value=before_value,
                        value_type=before_kind,
                        file=file_path,
                        line=line_num,
                        label=label,
                    )
                    if before_value is not None
                    else None
                )

                after_var_state = VariableState(
                    var_name=var_name,
                    value=after_value,
                    value_type=after_kind,
                    file=file_path,
                    line=line_num,
                    label=label,
                )

                change = StateChange(
                    var_name=var_name,
                    before=before_var_state,
                    after=after_var_state,
                    operation=operator,
                    file=file_path or "unknown",
                    line=line_num,
                    label=label,
                    expr=expr_str,
                    eval_result=eval_result_dict,
                    is_calculated=is_calc,
                    guard=change_guard,  # Phase 3 Commit 5: Guard annotation
                )

                # PILOT: Record state change in tracker
                if self.state_tracker:
                    # Prepare location dict for state tracker
                    location_dict = {"file": file_path or "unknown", "line": line_num}

                    self.state_tracker.record_change(
                        name=var_name,
                        prev_value=before_value,
                        next_value=after_value,
                        location=location_dict,
                        ast_node=None,  # No AST node available, will use value-based inference
                        guard=change_guard,
                    )

                # Add to timeline
                if var_name not in changes:
                    changes[var_name] = []
                changes[var_name].append(change)

                # Update current state and environment
                current_states[var_name] = {"value": after_value, "kind": after_kind}
                if (
                    after_value is not None
                    and not isinstance(after_value, str)
                    or (isinstance(after_value, str) and after_value != "unknown")
                ):
                    env[var_name] = after_value

        # Cache and return
        self._timelines[path_key] = changes
        return changes

    def get_state_changes_for_path(self, path: List[str]) -> List[Dict[str, Any]]:
        """Get engine-agnostic state changes for a path (PILOT integration).

        Args:
            path: Execution path (list of labels)

        Returns:
            List of canonical state change records
        """
        if not self.state_tracker:
            return []

        path_key = "-".join(path[:3]) if len(path) > 0 else "empty"
        return self.state_tracker.get_changes_for_path(path_key)

    def _apply_operator(
        self, op: str, before: Any, rhs: Any, before_kind: str, rhs_kind: str
    ) -> Tuple[Any, Optional[Any]]:
        """Apply an operator to compute after value and delta.

        Args:
            op: Operator (=, +=, -=, etc.)
            before: Before value
            rhs: Right-hand side value
            before_kind: Before value type
            rhs_kind: RHS value type

        Returns:
            Tuple of (after_value, delta)
        """
        # Use existing apply_op for compatibility
        return apply_op(before, op, rhs, before_kind, rhs_kind)  # type: ignore

    def _get_file_for_label(self, label: str) -> Optional[str]:
        """Get the file path for a given label.

        Args:
            label: Label name

        Returns:
            File path or None if not found
        """
        # Try to get from index
        if self.index and hasattr(self.index, "get_label_file"):
            return self.index.get_label_file(label)

        # Try to get from CFG nodes
        nodes_dict = (
            self.cfg.nodes
            if hasattr(self.cfg, "nodes") and isinstance(self.cfg.nodes, dict)
            else {}
        )
        for node_id, node in nodes_dict.items():
            name = (
                node.get("name")
                if isinstance(node, dict)
                else getattr(node, "name", None)
            )
            if name == label:
                file = (
                    node.get("file")
                    if isinstance(node, dict)
                    else getattr(node, "file", None)
                )
                if file:
                    return str(file)

        return None

    def get_variable_timeline(
        self, path: List[str], var_name: str
    ) -> List[StateChange]:
        """Get the timeline of changes for a specific variable along a path.

        Args:
            path: Execution path (list of labels)
            var_name: Variable name to track

        Returns:
            Ordered list of state changes for this variable
        """
        all_changes = self.analyze_path(path)
        return all_changes.get(var_name, [])

    def get_final_state(
        self, path: List[str], var_name: str
    ) -> Optional[VariableState]:
        """Get the final state of a variable at the end of a path.

        Args:
            path: Execution path
            var_name: Variable name

        Returns:
            Final VariableState or None if never assigned
        """
        timeline = self.get_variable_timeline(path, var_name)
        if timeline:
            return timeline[-1].after
        return None
