"""
narrative_paths.py — BranchPy Narrative Paths heuristic (Phase 1)

Computes a writer-facing estimate of the number of distinct story routes
a player can experience from the narrative entry point to an ending-like
outcome.  The result complements the raw Execution Paths count already
produced by _enumerate_paths_simple().

Public API
----------
    compute_narrative_paths(cfg, stat_variable_names=None) -> dict

Returned dict keys (all serialise directly into stats2.json summary):
    narrative_entry_label      : str | None
    narrative_paths_estimate   : int | str  (">10000" when capped)
    narrative_outcomes_estimate: int | None
    narrative_confidence       : "high" | "medium" | "low" | "not_computed"
    narrative_notes            : list[str]
    narrative_breakdown        : list[str]  (max 50 compressed sequences)
    structure_type             : "finite_branching" | "loop_hub" | "hybrid" | "not_computed"
    structure_confidence       : "high" | "medium" | "low" | "not_computed"
    structure_summary          : str | None
    structure_path_coverage_ratio : float | None
    structure_covered_labels   : list[str]  (Class C only — label names in narrative graph touched by paths)
    structure_uncovered_labels : list[str]  (Class C only — label names in narrative graph not touched by any path)

Internal helpers (importable for testing)
-----------------------------------------
    resolve_narrative_entry_label(cfg) -> tuple[str|None, str|None, list[str]]
    detect_terminal_candidates(cfg, adj, nodes_dict) -> set[str]
    score_branch_significance(node_id, cfg, adj, nodes_dict,
                              stat_variable_names) -> int
    compress_to_narrative_graph(cfg, adj, nodes_dict, entry_id,
                                terminals, stat_variable_names)
        -> tuple[dict[str,list[str]], set[str]]
    cluster_narrative_outcomes(terminals, nodes_dict) -> dict[str, str]
    count_narrative_paths(compressed_adj, entry_id, terminal_cluster_map)
        -> tuple[int|str, list[str], list[str]]
    classify_confidence(notes, entry_label, terminals, raw_path_count) -> str
    _classify_topology(np_estimate, np_outcomes, confidence,
                       quick_remerge_ratio, has_loops) -> str
    _derive_structure_type(topology, paths_enumerated, np_estimate,
                           coverage_ratio=None) -> str
        v3: coverage_ratio < HYBRID_MIN_COVERAGE_RATIO demotes hybrid -> loop_hub
    _build_structure_summary(structure_type, topology, np_estimate,
                             np_outcomes, coverage_ratio=None) -> str | None
    _compute_coverage_ratio(compressed_label_names, path_label_union) -> float | None
    _compute_coverage_sets(compressed_label_names, path_label_union)
        -> tuple[list[str], list[str]]  (covered, uncovered) — sorted for determinism
    _count_route_variants(compressed_adj, entry_id, terminals, np_estimate) -> int
    _find_valid_remerge(compressed_adj, split, arms, terminals) -> str | None
    _has_split_within_k(compressed_adj, node, k, terminals) -> bool
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Set, Tuple, Union

# ---------------------------------------------------------------------------
# Constants (spec §14 locked decisions)
# ---------------------------------------------------------------------------

# Minimum narrative significance score for a branch to be kept in the
# compressed narrative graph (spec §4.3, §6 step 5a).
NARRATIVE_SPLIT_THRESHOLD: int = 3

# A branch that remerges within this many labels of the split is collapsed
# regardless of its significance score (spec §6 step 5b, §14 decision 1).
REMERGE_THRESHOLD: int = 2

# DFS path cap to prevent combinatorial explosion (spec §14 decision 4).
NARRATIVE_PATH_CAP: int = 10_000

# Maximum entries in narrative_breakdown output (spec §6 step 11).
BREAKDOWN_MAX: int = 50

# Hybrid structure detection thresholds.
# A project is classified as "hybrid" (rather than pure loop_hub) only when
# BOTH a loop/hub cycle topology AND a meaningful finite-path signal are present.
# Conservative bounds prevent over-firing on projects with a trivial intro before a hub.
#
#   HYBRID_MIN_FINITE_PATHS  — minimum PILOT execution paths that must be enumerated
#                               (proves the finite-path portion is reachable, not absent).
#                               Set to 2 so that a single trivial path (e.g. a short
#                               linear intro before a hub) does not produce hybrid — it
#                               requires actual branching structure (≥ 2 paths).
#   HYBRID_MIN_NP_ESTIMATE   — minimum CFG narrative-path estimate (int, not capped) that
#                               must exist alongside the loop topology. np_estimate == 1
#                               for a pure hub project (one dominant loop) — requiring >= 2
#                               means the project also has meaningfully distinct finite routes.
#   HYBRID_MIN_COVERAGE_RATIO — v3 refinement: if the computed structure_path_coverage_ratio
#                               is below this threshold AFTER hybrid fires on the first two
#                               gates, the classification is demoted back to loop_hub.
#                               Rationale: paths_enumerated >= 2 and np_estimate >= 2 can
#                               fire on projects with a 2-label finite preamble before a 98-
#                               label hub. The coverage ratio reveals whether the finite
#                               portion is structurally significant (>= 15%) or a trivial
#                               entry sequence (< 15%). Conservative threshold: 0.15 means
#                               at least 15% of narrative-graph labels must be path-coverable.
#                               Only applies when coverage_ratio is computable (not None).
HYBRID_MIN_FINITE_PATHS: int = 2
HYBRID_MIN_NP_ESTIMATE: int = 2
HYBRID_MIN_COVERAGE_RATIO: float = 0.15
# IMPORTANT: coverage_ratio is a STRUCTURAL PROXY (label-count based),
# not a semantic importance measure.
# It is only used to demote trivial hybrids, not to rank structures.

# Coverage-aware messaging bands for hybrid structure_summary (UX only — no effect on
# classification).  Thresholds describe the *weight* of the finite portion relative to
# the overall narrative graph:
#   ratio < TINY  → loop-dominant with a finite preamble
#   TINY ≤ ratio < BALANCED → genuine mixture
#   ratio ≥ BALANCED → branching-dominant with minor loop/hub segments
HYBRID_SUMMARY_TINY_THRESHOLD: float = 0.20
HYBRID_SUMMARY_BALANCED_THRESHOLD: float = 0.60

# Ren'Py ending-like label name patterns (spec §14 decision 2).
TERMINAL_LABEL_PATTERNS: Tuple[re.Pattern, ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in [
        r".*\bend\b.*",
        r".*ending.*",
        r".*finale.*",
        r".*epilogue.*",
        r".*credits.*",
        r".*gameover.*",
        r".*game_over.*",
        r".*bad_end.*",
        r".*good_end.*",
        r".*true_end.*",
        r".*normal_end.*",
    ]
)

# Label name prefixes/substrings treated as utility/system labels (low significance).
UTILITY_LABEL_PATTERNS: Tuple[re.Pattern, ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in [
        r"^screen_",
        r"^init_",
        r"^gui_",
        r".*_helper$",
        r".*_setup$",
        r".*_transition$",
        r"^_",  # underscore-prefixed = private helper
        r"^splashscreen$",
        r"^before_main_menu$",
    ]
)

# Known Ren'Py engine namespaces (automatic low-significance penalty).
RENPY_SYSTEM_PREFIXES: Tuple[str, ...] = (
    "renpy_",
    "renpy.",
    "_renpy",
    "main_menu",
    "after_load",
    "quit_confirm",
    "choice_",
)


# ---------------------------------------------------------------------------
# Helper: CFG accessors
# ---------------------------------------------------------------------------


def _node_name(node: Any) -> Optional[str]:
    if isinstance(node, dict):
        return node.get("name")
    return getattr(node, "name", None)


def _node_kind(node: Any) -> str:
    kind = node.get("kind") if isinstance(node, dict) else getattr(node, "kind", None)
    return str(kind) if kind else ""


def _is_label_node(node: Any) -> bool:
    return "LABEL" in _node_kind(node)


def _build_adj(cfg: Any) -> Dict[str, List[Tuple[str, str]]]:
    """Return adjacency list: node_id -> [(target_id, edge_type_str), ...]"""
    edges_list = (
        cfg.edges if hasattr(cfg, "edges") and isinstance(cfg.edges, list) else []
    )
    adj: Dict[str, List[Tuple[str, str]]] = {}
    for edge in edges_list:
        if isinstance(edge, dict):
            src, dst, etype = edge.get("from"), edge.get("to"), edge.get("type", "seq")
        else:
            src = getattr(edge, "from_node", None) or getattr(edge, "src", None)
            dst = getattr(edge, "to_node", None) or getattr(edge, "dst", None)
            etype = getattr(edge, "edge_type", "seq")
        if src and dst:
            adj.setdefault(src, []).append((dst, str(etype) if etype else "seq"))
    return adj


def _label_nodes(nodes_dict: Dict[str, Any]) -> Dict[str, str]:
    """Return {node_id: label_name} for all LABEL-kind nodes."""
    return {
        nid: _node_name(n)
        for nid, n in nodes_dict.items()
        if _is_label_node(n) and _node_name(n)
    }


def _is_utility(name: str) -> bool:
    return any(p.match(name) for p in UTILITY_LABEL_PATTERNS)


def _is_renpy_system(name: str) -> bool:
    return any(name.lower().startswith(pfx) for pfx in RENPY_SYSTEM_PREFIXES)


def _is_terminal_name(name: str) -> bool:
    return any(p.match(name) for p in TERMINAL_LABEL_PATTERNS)


# ---------------------------------------------------------------------------
# Step 1: resolve_narrative_entry_label
# ---------------------------------------------------------------------------


def resolve_narrative_entry_label(
    cfg: Any,
    entry_label_override: Optional[str] = None,
) -> Tuple[Optional[str], Optional[str], List[str]]:
    """
    Locate the narrative entry node in the CFG.

    Returns (entry_node_id, entry_label_name, notes).

    Resolution order (spec §3.1):
      0. entry_label_override if provided — used as authoritative; warns if not found.
      1. Node named exactly "start".
      2. If "start" is a trivial single-edge redirect (no outgoing menu/branch),
         follow unconditional jumps until a node with multiple outgoing edges or
         a menu-originating edge.
      3. If "start" not found, return (None, None, [note]).
    """
    nodes_dict: Dict[str, Any] = (
        cfg.nodes if hasattr(cfg, "nodes") and isinstance(cfg.nodes, dict) else {}
    )
    adj = _build_adj(cfg)
    labels = _label_nodes(nodes_dict)
    notes: List[str] = []

    # --- override: user-configured entry label wins, permissive mode ---
    if entry_label_override:
        override_id: Optional[str] = None
        for nid, name in labels.items():
            if name == entry_label_override:
                override_id = nid
                break
        if override_id is not None:
            notes.append(
                f"Using configured narrative entry label: '{entry_label_override}'."
            )
            return override_id, entry_label_override, notes
        else:
            # Permissive: warn and fall through to auto-detection
            notes.append(
                f"Configured narrative entry label '{entry_label_override}' was not found "
                "in the CFG. Falling back to automatic detection."
            )

    # --- find "start" node ---
    start_id: Optional[str] = None
    for nid, name in labels.items():
        if name and name.lower() == "start":
            start_id = nid
            break

    if start_id is None:
        notes.append(
            "Entry label 'start' not found in CFG. "
            "Configure branchpy.narrativeEntryLabel to override."
        )
        return None, None, notes

    # --- follow trivial redirect chain ---
    visited_redirect: Set[str] = set()
    current_id = start_id
    current_name = labels.get(start_id, "start")
    redirected = False

    while True:
        outgoing = adj.get(current_id, [])
        # Trivial = exactly one edge, unconditional (seq / jump)
        if len(outgoing) == 1:
            neighbor_id, etype = outgoing[0]
            if "BRANCH" not in etype.upper() and "MENU" not in etype.upper():
                # Check if neighbour is itself a label node
                if neighbor_id in labels and neighbor_id not in visited_redirect:
                    next_name = labels[neighbor_id]
                    # Don't redirect into utility/system trampolines — stop here
                    # and keep the current node as the narrative entry.
                    if _is_utility(next_name) or _is_renpy_system(next_name):
                        break
                    visited_redirect.add(current_id)
                    current_id = neighbor_id
                    current_name = next_name
                    redirected = True
                    continue
        break

    if redirected:
        notes.append(
            f"'start' is a trivial redirect; using '{current_name}' as narrative root."
        )

    return current_id, current_name, notes


# ---------------------------------------------------------------------------
# Step 2: detect_terminal_candidates
# ---------------------------------------------------------------------------


def detect_terminal_candidates(
    cfg: Any,
    adj: Dict[str, List[Tuple[str, str]]],
    nodes_dict: Dict[str, Any],
) -> Set[str]:
    """
    Return the set of node_ids that are strong or soft terminal candidates.

    Strong terminals (spec §3.2):
      - Label node with no outgoing edges (dead end / final return absorbed).
      - Label name matches TERMINAL_LABEL_PATTERNS.

    Soft terminals:
      - Label node whose only outgoing edges are back-edges to already-seen
        ancestors (self-loops or menu-return loops).
        Detection: node has outgoing edges, but none lead to new label nodes
        reachable in the reachable set after this node.

    In v1 we use a simple proxy: a label node is soft-terminal if all its
    outgoing edges lead to non-label nodes only (e.g. narration/return
    statements) or back to a known menu/hub node.
    """
    labels = _label_nodes(nodes_dict)
    terminals: Set[str] = set()

    for nid, name in labels.items():
        out = adj.get(nid, [])

        # Strong: no outgoing edges
        if not out:
            terminals.add(nid)
            continue

        # Strong: name matches ending pattern
        if _is_terminal_name(name):
            terminals.add(nid)
            continue

        # Soft: all outgoing edges go to non-label nodes only
        out_to_labels = [dst for dst, _ in out if dst in labels]
        if not out_to_labels:
            terminals.add(nid)

    return terminals


# ---------------------------------------------------------------------------
# Step 3: score_branch_significance
# ---------------------------------------------------------------------------


def score_branch_significance(
    node_id: str,
    cfg: Any,
    adj: Dict[str, List[Tuple[str, str]]],
    nodes_dict: Dict[str, Any],
    stat_variable_names: Optional[Set[str]] = None,
    terminals: Optional[Set[str]] = None,
    terminal_cluster_map: Optional[Dict[str, str]] = None,
) -> int:
    """
    Compute the narrative significance score for a branch originating at node_id.

    Positive signals promote a branch to a narrative split.
    Negative signals collapse it as execution-only.

    See spec §4.1 and §4.2 for weight rationale.
    """
    node = nodes_dict.get(node_id)
    if node is None:
        return 0

    name: str = _node_name(node) or ""
    labels = _label_nodes(nodes_dict)
    outgoing = adj.get(node_id, [])
    score = 0

    # --- Positive signals ---

    # +5: originates from a menu block (edge type contains MENU or CHOICE)
    if any(
        "MENU" in etype.upper() or "CHOICE" in etype.upper() for _, etype in outgoing
    ):
        score += 5

    # +4: direct choice point — 2+ non-utility, non-system label children originate here.
    # Defines meaningful divergence by what branches FROM this node, not where paths end up.
    # Fires regardless of whether the arms later reconverge at the same terminal.
    non_util_out = [
        d
        for d, _ in outgoing
        if d in labels
        and not _is_utility(labels.get(d, ""))
        and not _is_renpy_system(labels.get(d, ""))
    ]
    if len(non_util_out) >= 2:
        score += 4

    # +3: gated by a detected stat variable that appears in ≥2 distinct branches
    #     (spec §4.1 strict condition — prevents false splits from imperfect detection)
    if stat_variable_names:
        # Heuristic: check node's condition string if available
        cond = None
        if isinstance(node, dict):
            cond = node.get("condition") or node.get("guard") or node.get("text", "")
        else:
            cond = (
                getattr(node, "condition", None)
                or getattr(node, "guard", None)
                or getattr(node, "text", None)
                or ""
            )
        if cond:
            matched_vars = [v for v in stat_variable_names if v in str(cond)]
            if matched_vars and len(outgoing) >= 2:
                score += 3

    # +3: leads to distinct non-trivial labels (>REMERGE_THRESHOLD nodes before remerge)
    out_label_targets = [dst for dst, _ in outgoing if dst in labels]
    if len(out_label_targets) >= 2:
        score += 3

    # +2: branch persists across >5 labels before remerging (approximated by
    #     checking if any out-label has ≥5 reachable labels)
    for tgt in out_label_targets[:4]:  # cap to avoid perf cost
        reachable_count = _count_reachable_labels(tgt, adj, labels, limit=6)
        if reachable_count >= 5:
            score += 2
            break

    # --- Negative signals ---

    # -5: inside a utility/system label
    if _is_utility(name):
        score -= 5

    # -3: belongs to Ren'Py engine namespace
    if _is_renpy_system(name):
        score -= 3

    # Early remerge check: how many hops before all branches meet again?
    if len(out_label_targets) >= 2:
        remerge_distance = _estimate_remerge_distance(out_label_targets, adj, labels)
        if remerge_distance <= REMERGE_THRESHOLD:
            score -= 4  # -4: remerges immediately (spec §4.2)

    return score


def _count_reachable_labels(
    start: str,
    adj: Dict[str, List[Tuple[str, str]]],
    labels: Dict[str, str],
    limit: int = 6,
) -> int:
    """BFS count of label nodes reachable from start (up to limit)."""
    seen: Set[str] = {start}
    frontier = [start]
    count = 0
    while frontier and count < limit:
        nxt = []
        for nid in frontier:
            for dst, _ in adj.get(nid, []):
                if dst not in seen:
                    seen.add(dst)
                    nxt.append(dst)
                    if dst in labels:
                        count += 1
        frontier = nxt
    return count


def _estimate_remerge_distance(
    branch_roots: List[str],
    adj: Dict[str, List[Tuple[str, str]]],
    labels: Dict[str, str],
    max_hops: int = 4,
) -> int:
    """
    Estimate in label-hops how quickly the given branch roots reconverge.
    Returns the first hop count at which all branches share a common reachable label.
    Returns max_hops + 1 if no convergence found within the window.
    """
    if len(branch_roots) < 2:
        return max_hops + 1

    # frontier_sets[i] = set of label nodes reachable from branch_roots[i] within hop budget
    frontier_sets: List[Set[str]] = [set() for _ in branch_roots]
    frontiers: List[List[str]] = [[r] for r in branch_roots]
    seen_sets: List[Set[str]] = [set(f) for f in frontiers]

    for hop in range(1, max_hops + 1):
        for i, frontier in enumerate(frontiers):
            nxt: List[str] = []
            for nid in frontier:
                for dst, _ in adj.get(nid, []):
                    if dst not in seen_sets[i]:
                        seen_sets[i].add(dst)
                        nxt.append(dst)
                        if dst in labels:
                            frontier_sets[i].add(dst)
            frontiers[i] = nxt

        # Check for common label reachable by all branches
        common = frontier_sets[0].copy()
        for fs in frontier_sets[1:]:
            common &= fs
        if common:
            return hop

    return max_hops + 1


# ---------------------------------------------------------------------------
# Step 4: compress_to_narrative_graph
# ---------------------------------------------------------------------------


def compress_to_narrative_graph(
    cfg: Any,
    adj: Dict[str, List[Tuple[str, str]]],
    nodes_dict: Dict[str, Any],
    entry_id: str,
    terminals: Set[str],
    stat_variable_names: Optional[Set[str]] = None,
) -> Tuple[Dict[str, List[str]], Set[str]]:
    """
    Build a compressed narrative graph.

    Returns:
      compressed_adj : dict[node_id -> list[node_id]] of narrative-only edges
      narrative_nodes: set of node_ids retained in the narrative graph

    Two collapse rules (spec §6 step 5):
      a. Significance score < NARRATIVE_SPLIT_THRESHOLD → collapse
      b. Remerge within REMERGE_THRESHOLD labels → collapse

    Terminal nodes are always kept.
    """
    labels = _label_nodes(nodes_dict)
    terminal_cluster_map = cluster_narrative_outcomes(terminals, nodes_dict)

    # Score every label node
    kept: Set[str] = set()
    kept.add(entry_id)
    kept.update(terminals)

    _total_branches = 0  # branch nodes (2+ label children) evaluated
    _quick_remerge_count = 0  # of those, how many remerged within REMERGE_THRESHOLD

    for nid in labels:
        if nid in kept:
            continue
        # Only score nodes that are themselves branch points (≥2 outgoing label edges)
        out_labels = [dst for dst, _ in adj.get(nid, []) if dst in labels]
        if len(out_labels) < 2:
            # Not a branch point — keep only if reachable from entry through kept nodes
            # (resolved later in traversal)
            continue

        score = score_branch_significance(
            nid,
            cfg,
            adj,
            nodes_dict,
            stat_variable_names,
            terminals,
            terminal_cluster_map,
        )
        collapse_reason = None

        dist = _estimate_remerge_distance(out_labels, adj, labels)
        low_score = score < NARRATIVE_SPLIT_THRESHOLD
        early_remerge = dist <= REMERGE_THRESHOLD
        _total_branches += 1
        if early_remerge:
            _quick_remerge_count += 1

        # Collapse only when BOTH conditions are met simultaneously (AND logic).
        # A high-scoring branch (meaningful menu choice) is kept even if its
        # branches converge quickly — that convergence point is a shared merge
        # node, not a sign that the choice is narratively irrelevant.
        if low_score and early_remerge:
            collapse_reason = (
                f"low score ({score} < {NARRATIVE_SPLIT_THRESHOLD}) "
                f"+ early remerge (distance={dist} ≤ {REMERGE_THRESHOLD})"
            )

        if collapse_reason is None:
            kept.add(nid)

    # Second pass: keep the direct label children of every narratively-significant
    # scored branch node.  This preserves individual choices (e.g. choice_a /
    # choice_b) even when they are not themselves branch points, so the DFS
    # can enumerate each arm as a distinct narrative path.
    scored_branch_nodes = kept - {entry_id} - terminals
    children_to_add: Set[str] = set()
    for nid in scored_branch_nodes:
        for dst, _ in adj.get(nid, []):
            if dst in labels and dst not in kept:
                children_to_add.add(dst)
    kept.update(children_to_add)

    # Build compressed adjacency: for each kept node, find the nearest kept
    # descendant(s) via BFS through discarded nodes.
    compressed_adj: Dict[str, List[str]] = {}

    for nid in kept:
        reachable_kept = _find_nearest_kept(nid, adj, kept)
        if reachable_kept:
            compressed_adj[nid] = list(reachable_kept)

    quick_remerge_ratio = (
        _quick_remerge_count / _total_branches if _total_branches > 0 else 0.0
    )
    return compressed_adj, kept, quick_remerge_ratio


def _find_nearest_kept(
    start: str,
    adj: Dict[str, List[Tuple[str, str]]],
    kept: Set[str],
    max_depth: int = 30,
) -> List[str]:
    """
    BFS from start through nodes not in kept, returning the first kept
    nodes encountered (exclusive of start itself).
    """
    found: List[str] = []
    seen: Set[str] = {start}
    frontier = [start]

    for _ in range(max_depth):
        nxt: List[str] = []
        for nid in frontier:
            for dst, _ in adj.get(nid, []):
                if dst in seen:
                    continue
                seen.add(dst)
                if dst in kept:
                    found.append(dst)
                else:
                    nxt.append(dst)
        if found or not nxt:
            break
        frontier = nxt

    return found


def _has_loops(compressed_adj: Dict[str, List[str]]) -> bool:
    """Return True if the compressed narrative graph contains any cycle (back-edge)."""
    on_stack: Set[str] = set()
    done: Set[str] = set()
    for start in list(compressed_adj):
        if start in done:
            continue
        stack: List[Tuple[str, List[str]]] = [
            (start, list(compressed_adj.get(start, [])))
        ]
        on_stack.add(start)
        while stack:
            node, children = stack[-1]
            if children:
                child = children.pop()
                if child in on_stack:
                    return True
                if child not in done:
                    on_stack.add(child)
                    stack.append((child, list(compressed_adj.get(child, []))))
            else:
                stack.pop()
                on_stack.discard(node)
                done.add(node)
    return False


# ---------------------------------------------------------------------------
# Step 5: cluster_narrative_outcomes
# ---------------------------------------------------------------------------


def cluster_narrative_outcomes(
    terminals: Set[str],
    nodes_dict: Dict[str, Any],
) -> Dict[str, str]:
    """
    Map each terminal node_id to a cluster name.

    V1 rule (spec §5): label-based only.
      - Identical label name → same cluster.
      - Longest common prefix (≥4 chars, split on _ boundaries) → cluster.
      - All others → "Ending N" fallback.

    Returns dict[terminal_node_id -> cluster_name].
    """
    terminal_names: Dict[str, str] = {}  # node_id -> label name
    for nid in terminals:
        node = nodes_dict.get(nid)
        if node:
            name = _node_name(node)
            if name:
                terminal_names[nid] = name

    names = list(terminal_names.values())
    cluster_map: Dict[str, str] = {}  # node_id -> cluster name

    # Group by identical name first
    name_to_group: Dict[str, str] = {}
    for name in names:
        if name not in name_to_group:
            # Find prefix match with existing groups
            matched = None
            for existing in list(name_to_group.values()):
                prefix = _common_prefix(name, existing)
                if len(prefix) >= 4:
                    matched = existing
                    break
            name_to_group[name] = matched if matched else name

    # Build cluster label names from group representative
    group_display: Dict[str, str] = {}
    for group_rep in set(name_to_group.values()):
        members = [n for n, g in name_to_group.items() if g == group_rep]
        prefix = _common_prefix(*members) if len(members) > 1 else group_rep
        display = prefix.strip("_").replace("_", " ").title() or "Ending"
        group_display[group_rep] = display

    # Assign
    for nid, name in terminal_names.items():
        group = name_to_group.get(name, name)
        cluster_map[nid] = group_display.get(group, "Ending")

    # Fallback for terminals with no name
    fallback_n = 1
    for nid in terminals:
        if nid not in cluster_map:
            cluster_map[nid] = f"Ending {fallback_n}"
            fallback_n += 1

    return cluster_map


def _common_prefix(*names: str) -> str:
    if not names:
        return ""
    prefix = names[0]
    for name in names[1:]:
        i = 0
        while i < len(prefix) and i < len(name) and prefix[i] == name[i]:
            i += 1
        prefix = prefix[:i]
    # Trim to last _ boundary for cleanliness
    if "_" in prefix:
        prefix = prefix[: prefix.rfind("_") + 1].rstrip("_")
    return prefix


# ---------------------------------------------------------------------------
# Step 6: count_narrative_paths  (DFS on compressed graph)
# ---------------------------------------------------------------------------


def count_narrative_paths(
    compressed_adj: Dict[str, List[str]],
    entry_id: str,
    terminal_cluster_map: Dict[str, str],
) -> Tuple[Union[int, str], List[str], List[str]]:
    """
    DFS on the compressed narrative graph from entry_id to terminal nodes.

    Deduplicates paths by **choice sequence** (divergence history), not by
    terminal destination.  Two paths that take different branches are counted
    as distinct narrative paths even if they eventually converge at the same
    ending label.  Two paths that reach the same sequence of branch decisions
    are considered the same narrative route even if they end at different
    (same-cluster) terminals.

    Returns:
      count          : int or ">10000" string if capped
      notes          : list of informational notes
      breakdown_ids  : deduplicated path sequences as " → ".join(node_ids),
                       max BREAKDOWN_MAX entries
    """
    terminals: Set[str] = set(terminal_cluster_map.keys())
    notes: List[str] = []

    # Pre-compute branch nodes: nodes with ≥2 outgoing edges in the compressed graph.
    # These are the decision points that define narrative divergence.
    branch_nodes: frozenset = frozenset(
        n for n, nbrs in compressed_adj.items() if len(nbrs) >= 2
    )

    # seen_signatures deduplicates on choice sequence: a tuple of
    # (branch_node, chosen_child) pairs recording every branch decision made.
    # Falls back to full path tuple when no branch points were encountered
    # (e.g. a perfectly linear story with only one route).
    seen_signatures: Set[Tuple[str, ...]] = set()
    breakdown_ids: List[str] = []

    # Stack entries: (current_node, path_tuple, choice_sig_tuple)
    stack: List[Tuple[str, Tuple[str, ...], Tuple[str, ...]]] = [
        (entry_id, (entry_id,), ())
    ]
    count = 0

    while stack:
        node, path, choice_sig = stack.pop()

        if node in terminals:
            sig = choice_sig if choice_sig else path
            if sig not in seen_signatures:
                seen_signatures.add(sig)
                count += 1
                if len(breakdown_ids) < BREAKDOWN_MAX:
                    breakdown_ids.append(" → ".join(path))
            if count >= NARRATIVE_PATH_CAP:
                notes.append(
                    "Narrative path count exceeded cap (10,000). "
                    "Project may have hub/sandbox structure."
                )
                return ">10000", notes, breakdown_ids
            continue

        neighbors = compressed_adj.get(node, [])
        if not neighbors:
            # Dead end (not a recognised terminal) — counts as a path
            sig = choice_sig if choice_sig else path
            if sig not in seen_signatures:
                seen_signatures.add(sig)
                count += 1
                if len(breakdown_ids) < BREAKDOWN_MAX:
                    breakdown_ids.append(" → ".join(path))
            continue

        for nb in neighbors:
            # Cycle guard: never revisit a node already on this path
            if nb in path:
                continue
            # Extend choice signature when leaving a branch point:
            # record (branch_node_id, chosen_child_id) so paths that
            # diverge here get distinct signatures even if they later merge.
            if node in branch_nodes:
                new_sig = choice_sig + (node, nb)
            else:
                new_sig = choice_sig
            stack.append((nb, path + (nb,), new_sig))

    return count, notes, breakdown_ids

    return count, notes, breakdown_ids


# ---------------------------------------------------------------------------
# Step 7: classify_confidence
# ---------------------------------------------------------------------------


def classify_confidence(
    notes: List[str],
    entry_label: Optional[str],
    terminals: Set[str],
    nodes_dict: Dict[str, Any],
    raw_path_count: Union[int, str],
) -> str:
    """
    Classify narrative confidence per spec §7.

    High   — clean start, clear ending labels, no confidence degraders in notes.
    Medium — some inferred terminals, soft terminals used, or redirected entry.
    Low    — capped, no clear ending labels, or heavy degraders.
    Not computed — no entry label found.
    """
    if entry_label is None:
        return "not_computed"

    degraders = [n for n in notes if "cap" in n.lower() or "not found" in n.lower()]
    if degraders or raw_path_count == ">10000":
        return "low"

    # Check how many terminals are strong (name-matched) vs soft (inferred)
    strong_count = sum(
        1
        for nid in terminals
        if _is_terminal_name(_node_name(nodes_dict.get(nid)) or "")
    )
    soft_count = len(terminals) - strong_count

    # Medium if any soft terminals or any redirect note
    redirect_note = any("redirect" in n.lower() for n in notes)
    if soft_count > 0 or redirect_note:
        return "medium"

    # No terminals at all → low
    if not terminals:
        return "low"

    return "high"


# ---------------------------------------------------------------------------
# Step 8: build_narrative_breakdown  (label names from node_id sequences)
# ---------------------------------------------------------------------------


def build_narrative_breakdown(
    breakdown_ids: List[str],
    nodes_dict: Dict[str, Any],
) -> List[str]:
    """
    Convert node_id sequences (space-separated by ' → ') into label-name sequences.
    Falls back to the node_id string when no name is available.
    """
    result: List[str] = []
    for seq in breakdown_ids:
        node_ids = seq.split(" → ")
        names = []
        for nid in node_ids:
            node = nodes_dict.get(nid)
            name = _node_name(node) if node else None
            names.append(name if name else nid)
        result.append(" → ".join(names))
    return result


# ---------------------------------------------------------------------------
# Route Variants — _count_route_variants  (spec §17, v2)
# ---------------------------------------------------------------------------

# Max arm depth (in narrative-significant nodes) searched for a remerge horizon.
# Arms that require more hops are treated as outcome divergence, not variants.
VARIANT_MAX_DEPTH: int = 8

# Ceiling on route_variants_estimate; display as "50+" if reached.
VARIANT_CAP: int = 50

# Lookahead hops after a candidate remerge node to confirm no immediate re-split.
REMERGE_K: int = 2


def _has_split_within_k(
    compressed_adj: Dict[str, List[str]],
    node: str,
    k: int,
    terminals: Set[str],
) -> bool:
    """
    Return True if any node within k hops of *node* (exclusive of *node* itself)
    has out_degree >= 2 in compressed_adj.

    Used to reject false remerge candidates that immediately re-diverge
    (e.g. pass-through helpers that happen to be common successors).
    """
    from collections import deque

    visited: Set[str] = set()
    queue: "deque[Tuple[str, int]]" = deque([(node, 0)])
    while queue:
        n, depth = queue.popleft()
        if n in visited or n in terminals:
            continue
        visited.add(n)
        if depth > 0 and len(compressed_adj.get(n, [])) >= 2:
            return True
        if depth < k:
            for nbr in compressed_adj.get(n, []):
                queue.append((nbr, depth + 1))
    return False


def _find_valid_remerge(
    compressed_adj: Dict[str, List[str]],
    split: str,
    arms: List[str],
    terminals: Set[str],
) -> Optional[str]:
    """
    Find the nearest valid remerge node for a split with the given arms.

    Validity (spec §17.2, Issue 3 fix):
      1. Reached by ALL arms within VARIANT_MAX_DEPTH hops (BFS per arm).
      2. Not a terminal node and not the split node itself.
      3. Has no split (out_degree >= 2) within REMERGE_K downstream hops,
         unless it has out_degree <= 1 (unconditional pass-through accepted).

    Returns the remerge node_id, or None if no valid candidate exists.
    """
    from collections import deque

    if not arms:
        return None

    # BFS from each arm up to VARIANT_MAX_DEPTH; record node → min_depth reached
    arm_reachable: List[Dict[str, int]] = []
    for arm in arms:
        visited: Dict[str, int] = {}
        queue: "deque[Tuple[str, int]]" = deque([(arm, 0)])
        while queue:
            node, depth = queue.popleft()
            if node in visited or depth > VARIANT_MAX_DEPTH:
                continue
            visited[node] = depth
            if node not in terminals:
                for nbr in compressed_adj.get(node, []):
                    if nbr not in visited:
                        queue.append((nbr, depth + 1))
        arm_reachable.append(visited)

    # Candidates = nodes reachable by ALL arms, excluding split itself and terminals
    candidates: Set[str] = set(arm_reachable[0].keys())
    for reach in arm_reachable[1:]:
        candidates &= reach.keys()
    candidates.discard(split)
    candidates -= terminals

    if not candidates:
        return None

    # Sort by max depth across arms to prefer earliest shared arrival
    def _sort_key(n: str) -> int:
        return max(r.get(n, VARIANT_MAX_DEPTH + 1) for r in arm_reachable)

    ordered = sorted(candidates, key=_sort_key)

    # Accept first candidate that passes the re-divergence check (Issue 3)
    for candidate in ordered:
        successors = compressed_adj.get(candidate, [])
        if len(successors) <= 1:
            return candidate  # unconditional continuation — clean merge
        if not _has_split_within_k(compressed_adj, candidate, REMERGE_K, terminals):
            return candidate  # no immediate re-divergence

    return None  # every candidate re-diverges immediately


def _collect_arm_nodes(
    compressed_adj: Dict[str, List[str]],
    arms: List[str],
    remerge: Optional[str],
) -> Set[str]:
    """
    Collect all nodes reachable from *arms* before hitting *remerge* or exceeding
    VARIANT_MAX_DEPTH.  Used by the independence classifier in _count_route_variants
    to determine which graph regions have already been "claimed" by a prior split.
    """
    from collections import deque

    result: Set[str] = set()
    for arm in arms:
        visited: Set[str] = set()
        queue: "deque[Tuple[str, int]]" = deque([(arm, 0)])
        while queue:
            node, depth = queue.popleft()
            if node in visited or depth > VARIANT_MAX_DEPTH or node == remerge:
                continue
            visited.add(node)
            result.add(node)
            for nbr in compressed_adj.get(node, []):
                queue.append((nbr, depth + 1))
    return result


def _topological_order(
    compressed_adj: Dict[str, List[str]],
    entry_id: str,
) -> List[str]:
    """
    Return nodes reachable from entry_id in topological order (Kahn's algorithm).
    Cycles are silently skipped — this is best-effort for a graph that may have
    back-edges (hub_loop topology).
    """
    from collections import deque

    # Build in-degree map over the reachable subgraph
    reachable: Set[str] = set()
    stack = [entry_id]
    while stack:
        n = stack.pop()
        if n in reachable:
            continue
        reachable.add(n)
        for nbr in compressed_adj.get(n, []):
            stack.append(nbr)

    in_degree: Dict[str, int] = {n: 0 for n in reachable}
    for n in reachable:
        for nbr in compressed_adj.get(n, []):
            if nbr in in_degree:
                in_degree[nbr] = in_degree.get(nbr, 0) + 1

    queue: "deque[str]" = deque([n for n in reachable if in_degree[n] == 0])
    order: List[str] = []
    while queue:
        n = queue.popleft()
        order.append(n)
        for nbr in compressed_adj.get(n, []):
            if nbr in in_degree:
                in_degree[nbr] -= 1
                if in_degree[nbr] == 0:
                    queue.append(nbr)

    return order


def _count_route_variants(
    compressed_adj: Dict[str, List[str]],
    entry_id: str,
    terminals: Set[str],
    np_estimate: Union[int, str, None],
) -> int:
    """
    Estimate the number of distinct player-facing route variants through the
    compressed narrative graph.

    A route variant is a distinct traversal path before terminal convergence —
    meaningful even when multiple variants share the same ending.

    Algorithm (spec §17.2):
      1. Walk split nodes in topological order.
      2. Classify each split as INDEPENDENT (not inside a prior arm's subgraph)
         or DEPENDENT (nested inside a prior arm).
      3. Independent splits: multiply route_variants by arm count.
         Dependent splits: max(route_variants, arm count) — conservative to
         avoid overcount from non-independent splits.
         NOTE: "split-point in prior arm_nodes" is a conservative proxy for
         nesting, not a full dominance analysis. Edge cases with complex fan-outs
         may conservatively under-count; this is the intentional bias (spec §17.4).
      4. Enforce floor: route_variants >= np_estimate (spec invariant, Issue 2 fix).
      5. Cap at VARIANT_CAP.

    Returns int in [1, VARIANT_CAP].
    """
    split_nodes = [
        n
        for n in _topological_order(compressed_adj, entry_id)
        if len(compressed_adj.get(n, [])) >= 2 and n not in terminals
    ]

    if not split_nodes:
        # No splits — pure linear or hub with no choice points
        np_floor = np_estimate if isinstance(np_estimate, int) else 1
        return max(1, np_floor)

    # Step 1 — gather split info (remerge, arm subgraph, contribution)
    SplitInfo = Dict[str, Any]  # local type alias for readability
    split_info: Dict[str, SplitInfo] = {}
    for split in split_nodes:
        arms = compressed_adj.get(split, [])
        remerge = _find_valid_remerge(compressed_adj, split, arms, terminals)
        arm_nodes = _collect_arm_nodes(compressed_adj, arms, remerge)
        contribution = len(arms) if remerge is not None else 0
        split_info[split] = {
            "remerge": remerge,
            "arm_nodes": arm_nodes,
            "contribution": contribution,
        }

    # Step 2 — classify splits as independent or dependent.
    # NOTE: Dependent split detection uses arm-node containment as a proxy for
    # nesting — a split is classified as dependent if its split-point node
    # appears inside the arm_nodes of a previously processed (independent) split.
    # This is a conservative heuristic, not a full dominance/post-dominator
    # analysis. Edge cases with shared intermediate nodes or complex fan-outs
    # may conservatively misclassify an independent split as dependent.
    # The intentional bias is toward undercounting — avoids overcounting variants.
    # A full dominator tree would improve precision in v2 if real-world projects
    # surface meaningful undercounting complaints.
    claimed_nodes: Set[str] = set()
    independent: List[str] = []
    dependent: List[str] = []
    for split in split_nodes:
        if split in claimed_nodes:
            dependent.append(split)
        else:
            independent.append(split)
            claimed_nodes.update(split_info[split]["arm_nodes"])

    # Step 3 — accumulate
    route_variants = 1

    for split in independent:
        c = split_info[split]["contribution"]
        if c > 0:
            route_variants = min(route_variants * c, VARIANT_CAP)

    for split in dependent:
        c = split_info[split]["contribution"]
        if c > 0:
            route_variants = min(max(route_variants, c), VARIANT_CAP)

    # Step 4 — enforce floor invariant: route_variants >= np_estimate (Issue 2)
    np_floor = np_estimate if isinstance(np_estimate, int) else 1
    route_variants = max(route_variants, np_floor)

    # Step 5 — final cap
    return min(route_variants, VARIANT_CAP)


# ---------------------------------------------------------------------------
# Public entry point: compute_narrative_paths
# ---------------------------------------------------------------------------


def _classify_topology(
    np_estimate: Union[int, str, None],
    np_outcomes: int,
    confidence: str,
    quick_remerge_ratio: float = 0.0,
    has_loops: bool = False,
) -> str:
    """
    Classify the narrative structure type.

    Key rule: hub_loop requires structural back-edges in the compressed graph.
    Segment/outcome count alone is NOT sufficient — a linear story with many
    quickly-remerging scene branches can also produce high outcome counts.

    branching       — 3+ distinct choice-divergent paths.
    hub_loop        — actual back-edges detected, OR DFS capped at ≥10 000
                      (implies loop-like state explosion).
    linear_variant  — 1-2 paths + high quick-remerge ratio (paths exist but routes converge):
                      quick-remerge scene branches or multiple outcome clusters.
                      One main story spine with state-driven scene variations.
    linear          — 1 path, no loops, no notable local branching.
    not_computed    — entry not found or computation failed.
    """
    if confidence == "not_computed" or np_estimate is None:
        return "not_computed"
    if isinstance(np_estimate, str):  # ">10000" capped — implies loop-like explosion
        return "hub_loop"
    # 2+ paths with low remerge ratio → genuinely distinct routes → branching.
    # High remerge ratio (≥ 0.8) with 2 paths means the second "path" is an
    # illusory variant that quickly rejoins the main spine → linear_variant.
    # 3+ paths always branching regardless of remerge ratio.
    if np_estimate >= 3:
        return "branching"
    if np_estimate >= 2 and quick_remerge_ratio < 0.8:
        return "branching"
    # 1-2 paths: back-edges are the ONLY reliable signal for hub_loop.
    # Outcome count alone can be high in linear_variant games (many scene
    # branches that quickly remerge) — do not use it to gate hub_loop.
    if has_loops:
        return "hub_loop"
    # No loops: classify by presence of any local branching signal.
    if quick_remerge_ratio >= 0.6 or np_outcomes >= 2:
        return "linear_variant"
    return "linear"


def _derive_structure_type(
    topology: str,
    paths_enumerated: int = 0,
    np_estimate: Union[int, str, None] = None,
    coverage_ratio: Optional[float] = None,
) -> str:
    """Map narrative_topology to the product-level structure_type contract.

    finite_branching — directed story with one or more distinct narrative paths
                       (linear, linear_variant, or branching topology).
    loop_hub         — structural back-edges detected; hub/sandbox pattern;
                       discrete finite paths are not defined.
    hybrid           — back-edges detected (loops exist) AND a meaningful finite-
                       path signal is also present (paths_enumerated >= HYBRID_MIN_FINITE_PATHS
                       AND np_estimate >= HYBRID_MIN_NP_ESTIMATE as an int).
                       v3 refinement: if coverage_ratio < HYBRID_MIN_COVERAGE_RATIO the
                       finite portion is too small to be structurally significant and the
                       classification is demoted to loop_hub.
                       Path metrics are meaningful for only part of the project.
    not_computed     — topology could not be determined.
    """
    # hybrid: loop topology confirmed + finite signals both exceed their thresholds.
    # Checked first so hub_loop with finite paths routes to hybrid, not loop_hub.
    if (
        topology == "hub_loop"
        and paths_enumerated >= HYBRID_MIN_FINITE_PATHS
        and isinstance(np_estimate, int)
        and np_estimate >= HYBRID_MIN_NP_ESTIMATE
    ):
        # v3 refinement: demote to loop_hub when coverage evidence is negligible.
        # coverage_ratio is None when the compressed graph is empty (not computable);
        # in that case we cannot refine and keep hybrid as classified above.
        if coverage_ratio is not None and coverage_ratio < HYBRID_MIN_COVERAGE_RATIO:
            return "loop_hub"
        return "hybrid"
    if topology in ("linear", "linear_variant", "branching"):
        return "finite_branching"
    if topology == "hub_loop":
        return "loop_hub"
    return "not_computed"


def _build_structure_summary(
    structure_type: str,
    topology: str,
    np_estimate: Union[int, str, None],
    np_outcomes: Optional[int],
    coverage_ratio: Optional[float] = None,
) -> Optional[str]:
    """Build the human-readable structure_summary field.

    Computed at analysis time so both PILOT and OMEGA can display it without
    independently re-deriving it from the topology classification.

    For hybrid projects, coverage_ratio drives three UX messaging bands:
      < HYBRID_SUMMARY_TINY_THRESHOLD     → finite intro before hub-dominant structure
      < HYBRID_SUMMARY_BALANCED_THRESHOLD → balanced hybrid structure
      >= HYBRID_SUMMARY_BALANCED_THRESHOLD → mostly branching with minor hub loops
    When coverage_ratio is None the neutral message is used (backward-compatible).
    """
    if structure_type == "not_computed":
        return None
    if structure_type == "hybrid":
        # v3: coverage-aware label for the finite portion weight.
        if coverage_ratio is not None:
            if coverage_ratio < HYBRID_SUMMARY_TINY_THRESHOLD:
                label = "Finite intro before hub-dominant structure"
            elif coverage_ratio < HYBRID_SUMMARY_BALANCED_THRESHOLD:
                label = "Balanced hybrid structure"
            else:
                label = "Mostly branching with minor hub loops"
        else:
            label = "Mixed finite-branching and Loop / Hub structure"
        if np_outcomes is not None:
            return f"{label}, {np_outcomes} reachable segments"
        return label
    if structure_type == "loop_hub":
        if np_outcomes is not None:
            return f"Loop / Hub structure, {np_outcomes} reachable segments"
        return "Loop / Hub structure"
    # finite_branching
    if topology == "linear":
        return "Linear story"
    if topology == "linear_variant":
        if np_outcomes is not None:
            return f"Linear story with {np_outcomes} reachable segments"
        return "Linear story with branching scene variations"
    if topology == "branching":
        if isinstance(np_estimate, int) and np_estimate >= 2:
            return f"Branching story — {np_estimate} distinct paths"
        if np_outcomes is not None:
            return f"Branching story — {np_outcomes} distinct outcomes"
        return "Branching story"
    return None


def _compute_coverage_ratio(
    compressed_label_names: Set[str],
    path_label_union: Optional[Set[str]],
) -> Optional[float]:
    """Fraction of narrative-significant labels covered by at least one enumerated path.

    Parameters
    ----------
    compressed_label_names
        The set of label names retained in the compressed narrative graph
        (derived from `narrative_nodes` returned by compress_to_narrative_graph).
    path_label_union
        Union of all label names that appear in any enumerated PILOT execution path.
        Pass None or an empty set when no paths were enumerated (ratio → 0.0).

    Returns
    -------
    float in [0.0, 1.0], or None if `compressed_label_names` is empty.
    0.0 when no paths are present (not null — 'no coverage' is a valid measurement).
    """
    if not compressed_label_names:
        return None
    covered = compressed_label_names.intersection(path_label_union or set())
    return len(covered) / len(compressed_label_names)


def _compute_coverage_sets(
    compressed_label_names: Set[str],
    path_label_union: Optional[Set[str]],
) -> Tuple[List[str], List[str]]:
    """Decompose coverage into covered and uncovered label name lists.

    Returns sorted lists for deterministic output.  Complement of
    _compute_coverage_ratio — same denominator/numerator logic, different
    return shape (label names instead of a scalar).

    Returns
    -------
    (covered, uncovered) — both sorted(list[str])
    Returns ([], []) when compressed_label_names is empty.
    """
    if not compressed_label_names:
        return [], []
    path_set = path_label_union or set()
    covered = sorted(compressed_label_names.intersection(path_set))
    uncovered = sorted(compressed_label_names.difference(path_set))
    return covered, uncovered


def compute_narrative_paths(
    cfg: Any,
    stat_variable_names: Optional[Set[str]] = None,
    entry_label_override: Optional[str] = None,
    paths_enumerated: int = 0,
    path_label_union: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """
    Compute the full set of Narrative Paths metrics for a PILOT report.

    Parameters
    ----------
    cfg
        The CFG object produced by StatementCFGBuilder (has .nodes and .edges).
    stat_variable_names
        Optional set of variable names already classified as player stats by the
        PILOT run.  Used to boost branch significance scores (spec §4.1).

    Returns
    -------
    dict with keys:
        narrative_entry_label              : str | None
        narrative_paths_estimate           : int | str
        narrative_outcomes_estimate        : int | None
        narrative_route_variants_estimate  : int | None
        narrative_confidence               : "high"|"medium"|"low"|"not_computed"
        narrative_notes                    : list[str]
        narrative_breakdown                : list[str]
        structure_type                     : "finite_branching"|"loop_hub"|"hybrid"|"not_computed"
        structure_confidence               : "high"|"medium"|"low"|"not_computed"
        structure_summary                  : str | None
        structure_path_coverage_ratio      : float | None
    """
    null_result: Dict[str, Any] = {
        "narrative_entry_label": None,
        "narrative_paths_estimate": None,
        "narrative_outcomes_estimate": None,
        "narrative_route_variants_estimate": None,
        "narrative_topology": "not_computed",
        "narrative_confidence": "not_computed",
        "narrative_unavailable_reason": None,
        "narrative_root_candidates": [],
        "narrative_notes": [],
        "narrative_breakdown": [],
        "structure_type": "not_computed",
        "structure_confidence": "not_computed",
        "structure_summary": None,
        "structure_path_coverage_ratio": None,
        "structure_covered_labels": [],
        "structure_uncovered_labels": [],
    }

    nodes_dict: Dict[str, Any] = (
        cfg.nodes if hasattr(cfg, "nodes") and isinstance(cfg.nodes, dict) else {}
    )
    if not nodes_dict:
        null_result["narrative_notes"] = ["CFG has no nodes."]
        null_result["narrative_unavailable_reason"] = "no_nodes"
        return null_result

    adj = _build_adj(cfg)

    # --- Step 1: entry label ---
    entry_id, entry_label, notes = resolve_narrative_entry_label(
        cfg, entry_label_override=entry_label_override
    )
    if entry_id is None:
        # Root analysis: find label nodes with no incoming edges to explain why.
        labels = _label_nodes(nodes_dict)
        in_degree: Dict[str, int] = {nid: 0 for nid in labels}
        for neighbors in adj.values():
            for dst_id, _ in neighbors:
                if dst_id in in_degree:
                    in_degree[dst_id] += 1
        roots = [nid for nid, deg in in_degree.items() if deg == 0]
        root_names = [labels[r] for r in roots if labels.get(r)]
        null_result["narrative_root_candidates"] = root_names[:10]
        if len(roots) > 1:
            null_result["narrative_unavailable_reason"] = "multiple_roots"
            notes.append(
                f"{len(roots)} entry root(s) found: "
                + ", ".join(repr(n) for n in root_names[:5])
                + (f" and {len(root_names) - 5} more" if len(root_names) > 5 else "")
                + ". Set branchpy.narrativeEntryLabel to select one."
            )
        else:
            null_result["narrative_unavailable_reason"] = "no_entry_label"
        null_result["narrative_notes"] = notes
        return null_result

    # --- Step 2: terminals ---
    terminals = detect_terminal_candidates(cfg, adj, nodes_dict)
    if not terminals:
        notes.append("No terminal candidates found in CFG.")
        return {
            **null_result,
            "narrative_entry_label": entry_label,
            "narrative_unavailable_reason": "no_terminals",
            "narrative_confidence": "low",
            "narrative_notes": notes,
        }

    # --- Step 3–4: compress ---
    compressed_adj, narrative_nodes, quick_remerge_ratio = compress_to_narrative_graph(
        cfg, adj, nodes_dict, entry_id, terminals, stat_variable_names
    )

    # --- Step 5: cluster ---
    terminal_cluster_map = cluster_narrative_outcomes(terminals, nodes_dict)
    outcome_clusters = set(terminal_cluster_map.values())

    # --- Step 6: DFS count ---
    raw_count, dfs_notes, breakdown_ids = count_narrative_paths(
        compressed_adj, entry_id, terminal_cluster_map
    )
    notes.extend(dfs_notes)

    # Informational: describe terminal clusters
    cluster_names = sorted(set(terminal_cluster_map.values()))
    if cluster_names:
        notes.append(
            f"{len(cluster_names)} narrative outcome cluster(s) detected: "
            + ", ".join(f"'{c}'" for c in cluster_names[:10])
            + ("…" if len(cluster_names) > 10 else ".")
        )

    # --- Step 7: confidence ---
    confidence = classify_confidence(
        notes, entry_label, terminals, nodes_dict, raw_count
    )

    # --- Step 8: human-readable breakdown ---
    breakdown = build_narrative_breakdown(breakdown_ids, nodes_dict)

    # --- Step 9: route variants ---
    topology = _classify_topology(
        raw_count,
        len(outcome_clusters),
        confidence,
        quick_remerge_ratio,
        _has_loops(compressed_adj),
    )
    route_variants = _count_route_variants(
        compressed_adj, entry_id, terminals, raw_count
    )

    # Coverage ratio + drill-down sets: fraction and decomposition of
    # compressed narrative labels touched by enumerated paths.
    # Computed BEFORE finalising structure_type so v3 refinement can use it.
    _all_labels = _label_nodes(nodes_dict)
    _compressed_label_names = {
        _all_labels[nid] for nid in narrative_nodes if nid in _all_labels
    }
    coverage_ratio = _compute_coverage_ratio(_compressed_label_names, path_label_union)
    covered_labels, uncovered_labels = _compute_coverage_sets(
        _compressed_label_names, path_label_union
    )

    # v3: pass coverage_ratio to _derive_structure_type so degenerate hybrid
    # classification (minimal finite preamble before a large hub) can be demoted
    # to loop_hub when the finite-path portion is below HYBRID_MIN_COVERAGE_RATIO.
    structure_type = _derive_structure_type(
        topology, paths_enumerated, raw_count, coverage_ratio
    )
    structure_summary = _build_structure_summary(
        structure_type, topology, raw_count, len(outcome_clusters), coverage_ratio
    )

    return {
        "narrative_entry_label": entry_label,
        "narrative_paths_estimate": raw_count,
        "narrative_outcomes_estimate": len(outcome_clusters),
        "narrative_route_variants_estimate": route_variants,
        "narrative_topology": topology,
        "narrative_confidence": confidence,
        "narrative_unavailable_reason": None,
        "narrative_root_candidates": [],
        "narrative_notes": notes,
        "narrative_breakdown": breakdown,
        "structure_type": structure_type,
        "structure_confidence": confidence,
        "structure_summary": structure_summary,
        "structure_path_coverage_ratio": coverage_ratio,
        "structure_covered_labels": covered_labels,
        "structure_uncovered_labels": uncovered_labels,
    }
