from __future__ import annotations

import hashlib
import json
import time
from collections import deque
from typing import Any, Dict, Iterable, List, Mapping, Set

BACKBONE_WEIGHTS: Dict[str, int] = {
    "reachable_depth": 5,
    "reachable_nodes": 3,
    "terminal_count": 2,
    "cycle_penalty": 4,
}

MIN_CLUSTER_GUTTER = 120
MIN_BACKBONE_CLEARANCE = 160
BACKBONE_ROW_SPACING = 140
BRANCH_COLUMN_STEP = 120
BRANCH_STACK_SPACING = 110
UTILITY_ROW_SPACING = 100
NARRATIVE_ROW_SPACING = 90
MERGE_CORRIDOR_OFFSET = 280
LAYOUT_NODE_HALF_WIDTH = 70
LAYOUT_NODE_HALF_HEIGHT = 28
LOCAL_NUDGE_STEP = 48
MAX_LOCAL_NUDGE_PASSES = 3
MAX_LOCAL_NUDGES_PER_COMPONENT = 400
MAX_REORDERED_BRANCH_HUBS = 64

CLEANUP_FULL_MAX_NODES = 20
CLEANUP_LIMITED_MAX_NODES = 50
MAX_LOCAL_NUDGE_PASSES_LIMITED = 1
MAX_LOCAL_NUDGES_PER_COMPONENT_LIMITED = 5
PERFORMANCE_BUDGET_SMALL_MAX_NODES = 100


PERFORMANCE_BUDGET_MEDIUM_MAX_NODES = 500
PERFORMANCE_BUDGET_LARGE_MAX_NODES = 2000
PERFORMANCE_BUDGET_SMALL_MS = 50
PERFORMANCE_BUDGET_MEDIUM_MS = 200
PERFORMANCE_BUDGET_LARGE_MS = 1000

LARGE_GRAPH_CLUSTER_ONLY_THRESHOLD = 150
LARGE_GRAPH_BREADTH_FIRST_THRESHOLD = 400

COMPONENT_ISLAND_BONUS = 128  # extra px per non-primary component; keeps side islands visually separated from main story body
MIN_BUNDLE_CLEARANCE = (
    40  # minimum px gap between bottom child of hub[i] and top child of hub[i+1]
)

BRANCH_HUB_KINDS = {"choice", "routing", "menu", "branch"}
UTILITY_KINDS = {
    "execution_container",
    "utility",
    "function",
    "call",
    "script",
}


def _build_components(
    node_ids: Set[str],
    outgoing: Mapping[str, Set[str]],
    incoming: Mapping[str, Dict[str, Any] | Set[str]],
) -> List[List[str]]:
    """Build deterministic weakly-connected components."""

    undirected: Dict[str, Set[str]] = {node_id: set() for node_id in node_ids}
    for node_id in node_ids:
        undirected[node_id].update(outgoing.get(node_id, set()))
        undirected[node_id].update(incoming.get(node_id, set()))

    seen: Set[str] = set()
    components: List[List[str]] = []
    for start in sorted(node_ids):
        if start in seen:
            continue
        queue: deque[str] = deque([start])
        comp: List[str] = []
        seen.add(start)
        while queue:
            cur = queue.popleft()
            comp.append(cur)
            for nxt in sorted(undirected.get(cur, set())):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        components.append(sorted(comp))

    return components


def _bfs_reachable(
    start: str,
    outgoing: Mapping[str, Set[str]],
    allowed: Set[str],
) -> tuple[Set[str], Dict[str, int], Dict[str, str]]:
    """Deterministic BFS restricted to component nodes."""

    reachable: Set[str] = set()
    distance: Dict[str, int] = {}
    parent: Dict[str, str] = {}
    queue: deque[tuple[str, int]] = deque([(start, 0)])

    while queue:
        node_id, depth = queue.popleft()
        if node_id in reachable:
            continue
        reachable.add(node_id)
        distance[node_id] = depth
        for nxt in sorted(outgoing.get(node_id, set())):
            if nxt in allowed and nxt not in reachable:
                if nxt not in parent:
                    parent[nxt] = node_id
                queue.append((nxt, depth + 1))

    return reachable, distance, parent


def _reconstruct_backbone_path(
    start: str, end: str, parent: Mapping[str, str]
) -> List[str]:
    """Reconstruct path from deterministic BFS tree."""

    path: List[str] = [end]
    cur = end
    while cur != start and cur in parent:
        cur = parent[cur]
        path.append(cur)
    path.reverse()
    return path if path and path[0] == start else [start]


def _score_backbone_candidate(
    start: str,
    component_nodes: Set[str],
    outgoing: Mapping[str, Set[str]],
    out_degree: Mapping[str, int],
) -> Dict[str, Any]:
    """Score candidate backbone from a single entry start."""

    reachable, distance, parent = _bfs_reachable(start, outgoing, component_nodes)
    max_depth = max(distance.values(), default=0)
    farthest = sorted(
        [node_id for node_id, depth in distance.items() if depth == max_depth]
    )
    end = farthest[0] if farthest else start
    path = _reconstruct_backbone_path(start, end, parent)

    terminal_count = sum(1 for node_id in path if out_degree.get(node_id, 0) == 0)
    cycle_penalty = 0
    for src in sorted(reachable):
        src_depth = distance.get(src, 0)
        for dst in sorted(outgoing.get(src, set())):
            if dst in reachable and distance.get(dst, 0) <= src_depth:
                cycle_penalty += 1

    score = (
        (max_depth * BACKBONE_WEIGHTS["reachable_depth"])
        + (len(reachable) * BACKBONE_WEIGHTS["reachable_nodes"])
        + (terminal_count * BACKBONE_WEIGHTS["terminal_count"])
        - (cycle_penalty * BACKBONE_WEIGHTS["cycle_penalty"])
    )

    return {
        "entry_candidate": start,
        "score": int(score),
        "reachable_depth": int(max_depth),
        "reachable_nodes": int(len(reachable)),
        "terminal_count": int(terminal_count),
        "cycle_penalty": int(cycle_penalty),
        "backbone_path": path,
    }


def _deterministic_signature(payload: Mapping[str, Any]) -> str:
    """Stable checksum for QA deterministic assertions."""

    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha1(encoded).hexdigest()


# ---------------------------------------------------------------------------
# D1a — Linear Chain Compaction
# ---------------------------------------------------------------------------

# Node kinds that are structural boundaries — never compacted as interior nodes.
_CHAIN_BOUNDARY_KINDS: frozenset[str] = frozenset(
    {
        "entry",
        "exit",
        "choice",
        "routing",
        "menu",
        "branch",  # branch hub
        "merge",  # explicit merge node
        "call",  # function call — structural
        "return",  # explicit return — structural
        "risk",  # diagnostic/risk overlay
        "warning",  # warning-bearing node
        "dead_end",  # dead-end diagnostic
        "checkpoint",  # author-marked checkpoint
    }
)

# Minimum interior-node count for a corridor to be emitted as a chain.
_D1A_MIN_CHAIN_LEN: int = 3


def _compact_linear_chains(
    node_ids: Set[str],
    outgoing: Mapping[str, Set[str]],
    incoming: Mapping[str, Set[str]],
    kind_by_id: Mapping[str, str],
    min_chain_len: int = _D1A_MIN_CHAIN_LEN,
) -> Dict[str, Any]:
    """
    D1a pre-pass: identify strict linear chains and emit a reversible compaction map.

    A chain is a maximal sequence of interior nodes where every interior node has:
      - component-local in_degree == 1
      - component-local out_degree == 1
      - kind not in _CHAIN_BOUNDARY_KINDS

    The first and last nodes in the emitted corridor are the boundary anchors
    (entry and exit of the corridor); they are NOT interior nodes and are not
    absorbed.

    Returns a dict with:
      - ``chains``: list of chain descriptors (sorted by chain_id for determinism)
      - ``compacted_node_count``: total interior nodes across all chains
      - ``chain_count``: number of emitted chains
      - ``min_chain_len``: gate that was applied
      - ``version``: "d1a-v1"
    """
    is_boundary: set[str] = {
        node_id
        for node_id in node_ids
        if kind_by_id.get(node_id, "label") in _CHAIN_BOUNDARY_KINDS
    }

    visited: set[str] = set()
    chains: list[Dict[str, Any]] = []
    chain_seq = 0

    for start in sorted(node_ids):
        if start in visited or start in is_boundary:
            continue
        if len(outgoing.get(start, set())) != 1 or len(incoming.get(start, set())) != 1:
            continue

        # Walk backward to find the boundary predecessor (corridor entry anchor).
        head = start
        steps = 0
        while True:
            preds = incoming.get(head, set())
            if len(preds) != 1:
                break
            pred = next(iter(preds))
            if pred in is_boundary or len(outgoing.get(pred, set())) != 1:
                break
            if len(incoming.get(pred, set())) != 1:
                break
            head = pred
            steps += 1
            if steps > len(node_ids):
                # Cycle guard: abort backward walk.
                head = start
                break

        # Walk forward collecting interior nodes.
        # Append current before following the edge so head is always included.
        interior: list[str] = []
        current = head
        seen_in_walk: set[str] = set()
        while True:
            if current in seen_in_walk:
                # Cycle detected — discard this corridor.
                interior = []
                break
            seen_in_walk.add(current)
            succs = outgoing.get(current, set())
            if len(succs) != 1:
                # current has multiple/no successors — not a valid interior node
                break
            nxt = next(iter(succs))
            # current is valid interior (out_degree=1; in_degree=1 ensured by backward walk)
            interior.append(current)
            preds_of_nxt = incoming.get(nxt, set())
            if len(preds_of_nxt) != 1 or nxt in is_boundary:
                # nxt is a merge point or structural boundary — corridor ends here
                break
            current = nxt
        if len(interior) < min_chain_len:
            continue

        if any(n in visited for n in interior):
            continue

        # Determine entry_anchor (predecessor of head) and exit_anchor (successor of last interior).
        head_preds = incoming.get(head, set())
        entry_anchor: str | None = (
            next(iter(head_preds)) if len(head_preds) == 1 else None
        )
        last_interior = interior[-1]
        last_succs = outgoing.get(last_interior, set())
        exit_anchor: str | None = (
            next(iter(last_succs)) if len(last_succs) == 1 else None
        )

        visited.update(interior)
        chain_seq += 1
        chain_id = f"chain_{chain_seq:04d}"

        chains.append(
            {
                "chain_id": chain_id,
                "entry_anchor": entry_anchor,
                "exit_anchor": exit_anchor,
                "interior_node_ids": interior,
                "interior_node_count": len(interior),
                "expandable": True,
            }
        )

    chains.sort(key=lambda c: c["chain_id"])

    return {
        "version": "d1a-v1",
        "min_chain_len": min_chain_len,
        "chain_count": len(chains),
        "compacted_node_count": sum(c["interior_node_count"] for c in chains),
        "chains": chains,
    }


def _build_dual_metrics(
    raw_node_count: int,
    chain_compaction: Mapping[str, Any],
) -> Dict[str, int]:
    """Derive additive raw-vs-visible metrics from the current compaction map."""

    chain_count = int(chain_compaction.get("chain_count", 0))
    collapsed_nodes_total = int(chain_compaction.get("compacted_node_count", 0))
    collapsed_edges_total = sum(
        max(int(chain.get("interior_node_count", 0)) - 1, 0)
        for chain in chain_compaction.get("chains", [])
    )
    layout_visible_node_count = max(
        raw_node_count - collapsed_nodes_total + chain_count, 0
    )

    return {
        "raw_node_count": int(raw_node_count),
        "layout_visible_node_count": int(layout_visible_node_count),
        "collapsed_nodes_total": int(collapsed_nodes_total),
        "collapsed_edges_total": int(collapsed_edges_total),
    }


def _build_expand_on_demand_stub(
    chain_compaction: Mapping[str, Any],
) -> Dict[str, Any]:
    """
    D3 expand-on-demand contract stub (M10).

    Derives a stable, versioned expansion contract from the D1a chain_compaction
    map so that a future expand-on-demand UI has a canonical entry point without
    parsing D1a internals.

    Emits ``semantic_summary.expand_on_demand`` with:
      - ``contract_version``: "d3-stub-v1"
      - ``segment_count``: number of expandable segments
      - ``segments``: list of segment descriptors (one-to-one with D1a chains)

    Each segment descriptor:
      - ``segment_id``: stable ID matching the D1a ``chain_id``
      - ``entry_anchor``: first boundary node (predecessor of the corridor)
      - ``exit_anchor``: last boundary node (successor of the corridor)
      - ``member_ids``: ordered list of interior node IDs (fully reversible)
      - ``member_count``: length of ``member_ids``
      - ``expandable``: True

    No UI wiring in this milestone. Additive-only — no existing fields are
    removed or renamed.
    """
    segments = [
        {
            "segment_id": chain["chain_id"],
            "entry_anchor": chain.get("entry_anchor"),
            "exit_anchor": chain.get("exit_anchor"),
            "member_ids": list(chain.get("interior_node_ids", [])),
            "member_count": int(chain.get("interior_node_count", 0)),
            "expandable": True,
        }
        for chain in chain_compaction.get("chains", [])
    ]
    return {
        "contract_version": "d3-stub-v1",
        "segment_count": len(segments),
        "segments": segments,
    }


# Minimum interior-node count for a D1b corridor to be emitted as a segment.
_D1B_MIN_SEGMENT_LEN: int = 3


def _compact_narrative_segments(
    node_ids: Set[str],
    outgoing: Mapping[str, Set[str]],
    incoming: Mapping[str, Set[str]],
    kind_by_id: Mapping[str, str],
    min_segment_len: int = _D1B_MIN_SEGMENT_LEN,
    enabled: bool = False,
) -> Dict[str, Any]:
    """
    D1b — Narrative Segment Compression (M11).

    Phase-1 conservative compression pass that absorbs low-information interior
    nodes into reversible segment objects.  Default ``enabled=False`` — when
    off, emits a stable contract block with ``enabled=False``, zero segments,
    and the same count fields as the disabled baseline so downstream consumers
    can rely on the schema without checking the flag first.

    A node is a **boundary** when:
      - ``out_degree > 1`` (branch hub)
      - ``in_degree > 1``  (merge point)
      - kind is in ``_CHAIN_BOUNDARY_KINDS`` (entry, exit, choice, menu,
        risk, warning, call, return, dead_end, checkpoint, …)

    A corridor from boundary A → … → boundary B is **compressible** when every
    interior node has in_degree=1, out_degree=1 and is not boundary-qualified,
    and the interior length is at least ``min_segment_len``.

    Emits ``semantic_summary.segment_compression`` with:
      - ``enabled``: bool
      - ``version``: "d1b-v1"
      - ``raw_node_count``: total analyzable nodes
      - ``layout_visible_node_count``: raw - collapsed_nodes_total
      - ``segment_count``: number of emitted segments
      - ``collapsed_nodes_total``: total interior nodes across all segments
      - ``collapsed_edges_total``: total interior edges across all segments
      - ``min_segment_len``: gate applied
      - ``determinism_signature``: SHA1 of segment map for quick diff

    Each segment in ``segments[]``:
      - ``segment_id``
      - ``entry_node_id``
      - ``exit_node_id``
      - ``interior_node_ids`` (ordered)
      - ``collapsed_node_count``
      - ``collapsed_edge_count``
      - ``expandable``: True

    Variable-metadata fields deferred to a later slice:
      ``contains_menu``, ``contains_jump``, ``contains_call``,
      ``contains_return``, ``contains_warning``, ``contains_screen``,
      ``estimated_text_weight``, ``label_preview`` — all emitted as None
      placeholder values in this first slice so the contract shape is stable.
    """
    raw_node_count = len(node_ids)

    _disabled_block = {
        "enabled": False,
        "version": "d1b-v1",
        "raw_node_count": raw_node_count,
        "layout_visible_node_count": raw_node_count,
        "segment_count": 0,
        "collapsed_nodes_total": 0,
        "collapsed_edges_total": 0,
        "min_segment_len": min_segment_len,
        "determinism_signature": "",
        "segments": [],
    }
    if not enabled:
        return _disabled_block

    # --- boundary classification -------------------------------------------
    is_boundary: set[str] = set()
    for node_id in node_ids:
        if (
            kind_by_id.get(node_id, "label") in _CHAIN_BOUNDARY_KINDS
            or len(outgoing.get(node_id, set())) > 1
            or len(incoming.get(node_id, set())) > 1
        ):
            is_boundary.add(node_id)

    # --- segment extraction ------------------------------------------------
    visited: set[str] = set()
    segments: list[Dict[str, Any]] = []
    seg_seq = 0

    for start in sorted(node_ids):
        if start in visited or start in is_boundary:
            continue
        if len(outgoing.get(start, set())) != 1 or len(incoming.get(start, set())) != 1:
            continue

        # walk backward to corridor head
        head = start
        steps = 0
        while True:
            preds = incoming.get(head, set())
            if len(preds) != 1:
                break
            pred = next(iter(preds))
            if pred in is_boundary or len(outgoing.get(pred, set())) != 1:
                break
            if len(incoming.get(pred, set())) != 1:
                break
            head = pred
            steps += 1
            if steps > len(node_ids):
                head = start
                break

        # walk forward collecting interior nodes
        interior: list[str] = []
        current = head
        seen_walk: set[str] = set()
        while True:
            if current in seen_walk:
                interior = []
                break
            seen_walk.add(current)
            succs = outgoing.get(current, set())
            if len(succs) != 1:
                break
            nxt = next(iter(succs))
            interior.append(current)
            preds_of_nxt = incoming.get(nxt, set())
            if len(preds_of_nxt) != 1 or nxt in is_boundary:
                break
            current = nxt

        if len(interior) < min_segment_len:
            continue
        if any(n in visited for n in interior):
            continue

        # determine entry/exit boundary anchors
        head_preds = incoming.get(head, set())
        entry_node_id: str | None = (
            next(iter(head_preds)) if len(head_preds) == 1 else None
        )
        last_interior = interior[-1]
        last_succs = outgoing.get(last_interior, set())
        exit_node_id: str | None = (
            next(iter(last_succs)) if len(last_succs) == 1 else None
        )

        visited.update(interior)
        seg_seq += 1
        seg_id = f"seg_{seg_seq:04d}"

        segments.append(
            {
                "segment_id": seg_id,
                "entry_node_id": entry_node_id,
                "exit_node_id": exit_node_id,
                "interior_node_ids": interior,
                "collapsed_node_count": len(interior),
                "collapsed_edge_count": max(len(interior) - 1, 0),
                "expandable": True,
                # Phase-1: content metadata deferred
                "contains_menu": None,
                "contains_jump": None,
                "contains_call": None,
                "contains_return": None,
                "contains_warning": None,
                "contains_screen": None,
                "estimated_text_weight": None,
                "label_preview": None,
            }
        )

    segments.sort(key=lambda s: s["segment_id"])

    collapsed_nodes_total = sum(s["collapsed_node_count"] for s in segments)
    collapsed_edges_total = sum(s["collapsed_edge_count"] for s in segments)
    layout_visible = max(raw_node_count - collapsed_nodes_total, 0)

    # determinism signature: SHA1 over stable segment id+interior list
    import hashlib
    import json as _json

    sig_payload = _json.dumps(
        [{"id": s["segment_id"], "interior": s["interior_node_ids"]} for s in segments],
        sort_keys=True,
    ).encode()
    det_sig = hashlib.sha1(sig_payload).hexdigest()

    return {
        "enabled": True,
        "version": "d1b-v1",
        "raw_node_count": raw_node_count,
        "layout_visible_node_count": layout_visible,
        "segment_count": len(segments),
        "collapsed_nodes_total": collapsed_nodes_total,
        "collapsed_edges_total": collapsed_edges_total,
        "min_segment_len": min_segment_len,
        "determinism_signature": det_sig,
        "segments": segments,
    }


# ---------------------------------------------------------------------------
# D9 — Narrative Structure Diagnostics (M14, research slice, feature-flagged)
# ---------------------------------------------------------------------------

# SCR band boundaries (initial research defaults).
_SCR_BANDS: tuple[tuple[float, str], ...] = (
    (0.08, "extremely_clean"),
    (0.15, "healthy"),
    (0.25, "busy"),
    (0.35, "difficult"),
)
_SCR_BAND_MAX = "spaghetti_risk"

# RBI band boundaries.
_RBI_BANDS: tuple[tuple[float, str], ...] = (
    (0.30, "extreme_imbalance"),
    (0.50, "strong_imbalance"),
    (0.75, "mild_imbalance"),
)
_RBI_BAND_MAX = "balanced"


def _scr_band(scr: float) -> str:
    for threshold, label in _SCR_BANDS:
        if scr < threshold:
            return label
    return _SCR_BAND_MAX


def _rbi_band(rbi: float) -> str:
    for threshold, label in _RBI_BANDS:
        if rbi <= threshold:
            return label
    return _RBI_BAND_MAX


# Advisory notes for non-benign bands only.  Suppressed for: extremely_clean,
# healthy (SCR) and balanced (RBI).  Wording is descriptive, non-prescriptive.
SCR_BAND_NOTES: dict[str, str] = {
    "busy": "branch density is somewhat higher than corridor throughput",
    "difficult": "branch density noticeably exceeds corridor throughput",
    "spaghetti_risk": "branch density is high relative to corridor structure",
}
RBI_BAND_NOTES: dict[str, str] = {
    "mild_imbalance": "route lengths are somewhat uneven",
    "strong_imbalance": "route sizes differ noticeably",
    "extreme_imbalance": "route lengths differ greatly",
}


def _compute_narrative_structure(
    node_ids: Set[str],
    outgoing: Mapping[str, Set[str]],
    incoming: Mapping[str, Set[str]],
    kind_by_id: Mapping[str, str],
    enabled: bool = False,
) -> Dict[str, Any]:
    """
    D9 — Narrative Structure Diagnostics (M14, research slice).

    Topology-only inference producing non-authoritative candidate diagnostics.
    All outputs are labelled with ``research=True`` and must not be treated as
    ground truth. Feature flag default ``enabled=False`` — when off, emits a
    stable disabled block so consumers can rely on the schema shape without
    checking the flag.

    Emits ``semantic_summary.narrative_structure`` with:
      - ``research``: True
      - ``version``: "d9-v1"
      - ``enabled``: bool
      - ``raw_node_count``: total analyzable nodes
      - SCR fields: ``structural_complexity_ratio_raw``,
        ``structural_complexity_band``, ``structural_nodes``, ``corridor_nodes``
      - Hub fields: ``major_branch_hub_count``, ``major_merge_hub_count``,
        ``dominant_hub_out_degree``
      - Corridor stats: ``corridor_count``, ``longest_corridor_len``,
        ``mean_corridor_len``
      - Hub-return lattice: ``hub_return_lattice_count``,
        ``detachable_scene_count``
      - Route candidates (labelled "candidate"):
        ``route_candidate_count``, ``routes[]``
      - RBI / dominance: ``route_balance_index``, ``route_balance_band``,
        ``route_dominance``
    """
    raw_node_count = len(node_ids)

    _disabled_block: Dict[str, Any] = {
        "research": True,
        "version": "d9-v1",
        "enabled": False,
        "raw_node_count": raw_node_count,
        "structural_complexity_ratio_raw": None,
        "structural_complexity_band": None,
        "structural_nodes": None,
        "corridor_nodes": None,
        "major_branch_hub_count": None,
        "major_merge_hub_count": None,
        "dominant_hub_out_degree": None,
        "corridor_count": None,
        "longest_corridor_len": None,
        "mean_corridor_len": None,
        "hub_return_lattice_count": None,
        "detachable_scene_count": None,
        "route_candidate_count": None,
        "routes": [],
        "route_balance_index": None,
        "route_balance_band": None,
        "route_dominance": None,
    }
    if not enabled:
        return _disabled_block

    # --- SCR: structural complexity ratio (raw topology) ------------------
    corridor_node_ids = {
        n
        for n in node_ids
        if len(outgoing.get(n, set())) == 1
        and len(incoming.get(n, set())) == 1
        and kind_by_id.get(n, "label") not in _CHAIN_BOUNDARY_KINDS
    }
    structural_node_ids = node_ids - corridor_node_ids
    corridor_count_raw = len(corridor_node_ids)
    structural_count = len(structural_node_ids)
    scr_raw = structural_count / raw_node_count if raw_node_count > 0 else 0.0
    scr_band = _scr_band(scr_raw)

    # --- Hub detection ----------------------------------------------------
    branch_hubs = sorted(n for n in node_ids if len(outgoing.get(n, set())) >= 2)
    merge_hubs = sorted(n for n in node_ids if len(incoming.get(n, set())) >= 2)
    dominant_hub_out = max(
        (len(outgoing.get(n, set())) for n in branch_hubs), default=0
    )

    # --- Corridor stats ---------------------------------------------------
    # Walk each contiguous run of corridor nodes (degree-1 chains).
    visited_corridor: set[str] = set()
    corridor_runs: list[int] = []

    for start in sorted(corridor_node_ids):
        if start in visited_corridor:
            continue
        # walk backward to corridor head
        head = start
        for _ in range(raw_node_count + 1):
            preds = incoming.get(head, set())
            if len(preds) != 1:
                break
            pred = next(iter(preds))
            if pred not in corridor_node_ids:
                break
            if pred in visited_corridor:
                break
            head = pred
        # walk forward
        run: list[str] = []
        cur = head
        seen: set[str] = set()
        while (
            cur in corridor_node_ids and cur not in visited_corridor and cur not in seen
        ):
            seen.add(cur)
            run.append(cur)
            nexts = outgoing.get(cur, set())
            if len(nexts) != 1:
                break
            cur = next(iter(nexts))
        if run:
            visited_corridor.update(run)
            corridor_runs.append(len(run))

    longest_corridor = max(corridor_runs, default=0)
    mean_corridor = (sum(corridor_runs) / len(corridor_runs)) if corridor_runs else 0.0

    # --- Hub-return lattice detection ------------------------------------
    #
    # A candidate hub H is a hub-return lattice root when at least two of its
    # outgoing branches return to H (directly or transitively) before reaching
    # any other major hub.  These branches are detachable scenes.
    #
    hub_return_lattice_roots: set[str] = set()
    detachable_branch_total = 0

    for hub in branch_hubs:
        detachable_count = 0
        for child in outgoing.get(hub, set()):
            # follow branch path until we return to hub, reach another major hub,
            # or terminate — cycle-safe with depth limit
            visited_branch: set[str] = set()
            cur = child
            returned = False
            for _ in range(raw_node_count + 1):
                if cur == hub:
                    returned = True
                    break
                if cur in visited_branch:
                    break
                visited_branch.add(cur)
                if cur != child and cur in branch_hubs and cur != hub:
                    # reached another major hub — not a detachable scene
                    break
                nexts = outgoing.get(cur, set())
                if len(nexts) == 0:
                    break
                if len(nexts) > 1:
                    # branching before returning — not simple detachable scene
                    break
                cur = next(iter(nexts))
            if returned:
                detachable_count += 1
        if detachable_count >= 2:
            hub_return_lattice_roots.add(hub)
            detachable_branch_total += detachable_count

    # --- Route candidate detection ----------------------------------------
    #
    # Route candidates: from each branch hub that is NOT a hub-return lattice
    # root, trace each outgoing branch until next major hub or termination.
    # Exclude detachable-scene branches (branches that return to the same hub).
    #
    route_hub_candidates = [h for h in branch_hubs if h not in hub_return_lattice_roots]
    routes: list[Dict[str, Any]] = []

    for hub in route_hub_candidates:
        for child in sorted(outgoing.get(hub, set())):
            # skip if this child returns to hub (detachable scene branch)
            first_succ = outgoing.get(child, set())
            if len(first_succ) == 1 and next(iter(first_succ)) == hub:
                continue

            # trace route depth and node count
            visited_route: set[str] = set()
            stack = [child]
            route_nodes: set[str] = set()
            depth = 0
            while stack:
                node = stack.pop()
                if node in visited_route or node == hub:
                    continue
                visited_route.add(node)
                route_nodes.add(node)
                depth = max(depth, len(visited_route))
                succs = outgoing.get(node, set())
                if len(succs) == 1:
                    nxt = next(iter(succs))
                    if nxt not in visited_route:
                        stack.append(nxt)
                # stop branch expansion at merge hubs or other branch hubs
            routes.append(
                {
                    "entry_hub_id": hub,
                    "branch_entry_node_id": child,
                    "candidate": True,
                    "node_count": len(route_nodes),
                    "depth": depth,
                }
            )

    routes.sort(key=lambda r: (r["entry_hub_id"], r["branch_entry_node_id"]))

    # --- RBI / route dominance -------------------------------------------
    route_sizes = [r["node_count"] for r in routes if r["node_count"] > 0]
    if len(route_sizes) >= 2:
        min_size = min(route_sizes)
        max_size = max(route_sizes)
        total_route_nodes = sum(route_sizes)
        rbi = min_size / max_size if max_size > 0 else None
        route_dominance = (
            max_size / total_route_nodes if total_route_nodes > 0 else None
        )
        rbi_band = _rbi_band(rbi) if rbi is not None else None
    else:
        rbi = None
        route_dominance = None
        rbi_band = None

    return {
        "research": True,
        "version": "d9-v1",
        "enabled": True,
        "raw_node_count": raw_node_count,
        "structural_complexity_ratio_raw": round(scr_raw, 4),
        "structural_complexity_band": scr_band,
        "structural_nodes": structural_count,
        "corridor_nodes": corridor_count_raw,
        "major_branch_hub_count": len(branch_hubs),
        "major_merge_hub_count": len(merge_hubs),
        "dominant_hub_out_degree": dominant_hub_out,
        "corridor_count": len(corridor_runs),
        "longest_corridor_len": longest_corridor,
        "mean_corridor_len": round(mean_corridor, 2),
        "hub_return_lattice_count": len(hub_return_lattice_roots),
        "detachable_scene_count": detachable_branch_total,
        "route_candidate_count": len(routes),
        "routes": routes,
        "route_balance_index": round(rbi, 4) if rbi is not None else None,
        "route_balance_band": rbi_band,
        "route_dominance": (
            round(route_dominance, 4) if route_dominance is not None else None
        ),
    }


def _nearest_backbone_anchor(
    start: str,
    incoming: Mapping[str, Set[str]],
    component_nodes: Set[str],
    backbone_nodes: Set[str],
) -> str | None:
    """Find nearest upstream backbone node for deterministic terminal grouping."""

    if start in backbone_nodes:
        return start

    queue: deque[str] = deque([start])
    visited: Set[str] = set()
    while queue:
        cur = queue.popleft()
        if cur in visited:
            continue
        visited.add(cur)

        for prev in sorted(incoming.get(cur, set())):
            if prev not in component_nodes:
                continue
            if prev in backbone_nodes:
                return prev
            if prev not in visited:
                queue.append(prev)

    return None


def _component_in_degree(
    node_id: str,
    incoming: Mapping[str, Set[str]],
    component_nodes: Set[str],
) -> int:
    return len([src for src in incoming.get(node_id, set()) if src in component_nodes])


def _build_branch_assignment(
    branch_hubs_in_component: List[str],
    outgoing: Mapping[str, Set[str]],
    component_set: Set[str],
    backbone_set: Set[str],
    bundle_id_by_hub: Mapping[str, str],
    ordered_children_by_hub: Mapping[str, List[str]] | None = None,
) -> tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, float]]]:
    branch_assignment: Dict[str, Dict[str, Any]] = {}
    hub_child_slots: Dict[str, Dict[str, float]] = {}

    for hub in branch_hubs_in_component:
        children = [
            node_id
            for node_id in outgoing.get(hub, set())
            if node_id in component_set and node_id not in backbone_set
        ]
        if ordered_children_by_hub and hub in ordered_children_by_hub:
            allowed = set(children)
            children = [
                child for child in ordered_children_by_hub[hub] if child in allowed
            ]
        else:
            children = sorted(children)

        if not children:
            continue

        center_slot = (len(children) - 1) / 2.0
        bundle_id = bundle_id_by_hub.get(hub)
        child_slots = {
            child: (child_index - center_slot)
            for child_index, child in enumerate(children)
        }
        hub_child_slots[hub] = child_slots

        for child in children:
            queue: deque[tuple[str, int]] = deque([(child, 0)])
            local_best_depth: Dict[str, int] = {}
            while queue:
                current_node, branch_depth = queue.popleft()
                if current_node in backbone_set:
                    continue
                previous_best_depth = local_best_depth.get(current_node)
                if (
                    previous_best_depth is not None
                    and branch_depth >= previous_best_depth
                ):
                    continue
                local_best_depth[current_node] = branch_depth

                candidate_rank = (branch_depth, str(child), str(hub), str(current_node))
                existing_assignment = branch_assignment.get(current_node)
                if (
                    existing_assignment is None
                    or candidate_rank < existing_assignment["rank"]
                ):
                    branch_assignment[current_node] = {
                        "bundle_id": bundle_id,
                        "hub": hub,
                        "branch_root": child,
                        "fan_slot": child_slots[child],
                        "branch_depth": branch_depth,
                        "rank": candidate_rank,
                    }

                for nxt in sorted(outgoing.get(current_node, set())):
                    if nxt in component_set and nxt not in backbone_set:
                        queue.append((nxt, branch_depth + 1))

    return branch_assignment, hub_child_slots


def _build_merge_corridors(
    component: List[str],
    component_id: str,
    component_set: Set[str],
    backbone_set: Set[str],
    incoming: Mapping[str, Set[str]],
    branch_assignment: Mapping[str, Dict[str, Any]],
    backbone_y: Mapping[str, int],
    anchors: Mapping[str, Dict[str, int]],
) -> tuple[List[Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    merge_corridors: List[Dict[str, Any]] = []
    merge_corridor_map: Dict[str, Dict[str, Any]] = {}

    for node_id in component:
        if node_id in backbone_set:
            continue
        incoming_preds = sorted(
            pred for pred in incoming.get(node_id, set()) if pred in component_set
        )
        incoming_branch_roots = sorted(
            {
                str(branch_assignment[pred]["branch_root"])
                for pred in incoming_preds
                if pred in branch_assignment
                and branch_assignment[pred].get("branch_root")
            }
        )
        incoming_bundles = sorted(
            {
                str(branch_assignment[pred]["bundle_id"])
                for pred in incoming_preds
                if pred in branch_assignment
                and branch_assignment[pred].get("bundle_id")
            }
        )
        if len(incoming_branch_roots) < 2:
            continue

        predecessor_rows: List[int] = []
        predecessor_columns: List[int] = []
        for pred in incoming_preds:
            if pred in branch_assignment:
                pred_assignment = branch_assignment[pred]
                hub_y = backbone_y.get(pred_assignment["hub"], 0)
                predecessor_rows.append(
                    int(
                        round(
                            hub_y + (pred_assignment["fan_slot"] * BRANCH_STACK_SPACING)
                        )
                    )
                )
                predecessor_columns.append(int(pred_assignment["branch_depth"]))

        corridor_y = (
            int(round(sum(predecessor_rows) / len(predecessor_rows)))
            if predecessor_rows
            else 0
        )
        corridor_x = int(
            anchors["branch_bundle"]["x"]
            + max(predecessor_columns, default=0) * BRANCH_COLUMN_STEP
            + MERGE_CORRIDOR_OFFSET
        )

        merge_corridor_id = f"{component_id}:mc{len(merge_corridors) + 1:02d}"
        merge_corridor = {
            "merge_corridor_id": merge_corridor_id,
            "merge_node": node_id,
            "incoming_branch_bundles": incoming_bundles,
            "incoming_branch_roots": incoming_branch_roots,
            "anchor": {"x": corridor_x, "y": corridor_y},
        }
        merge_corridors.append(merge_corridor)
        merge_corridor_map[node_id] = merge_corridor

    return merge_corridors, merge_corridor_map


def _build_downstream_merge_target(
    merge_corridors: List[Dict[str, Any]],
    component_set: Set[str],
    backbone_set: Set[str],
    incoming: Mapping[str, Set[str]],
) -> Dict[str, Dict[str, Any]]:
    downstream_merge_target: Dict[str, Dict[str, Any]] = {}

    for merge_corridor in merge_corridors:
        merge_node = str(merge_corridor["merge_node"])
        queue: deque[tuple[str, int]] = deque([(merge_node, 0)])
        best_distance: Dict[str, int] = {}
        while queue:
            current_node, distance_to_merge = queue.popleft()
            previous_best = best_distance.get(current_node)
            if previous_best is not None and distance_to_merge >= previous_best:
                continue
            best_distance[current_node] = distance_to_merge

            if current_node != merge_node and current_node not in backbone_set:
                candidate_rank = (
                    distance_to_merge,
                    str(merge_node),
                    str(current_node),
                )
                existing_target = downstream_merge_target.get(current_node)
                if existing_target is None or candidate_rank < existing_target["rank"]:
                    downstream_merge_target[current_node] = {
                        "merge_corridor_id": str(merge_corridor["merge_corridor_id"]),
                        "distance_to_merge": distance_to_merge,
                        "anchor": dict(merge_corridor["anchor"]),
                        "rank": candidate_rank,
                    }

            for prev in sorted(incoming.get(current_node, set())):
                if prev in component_set and prev not in backbone_set:
                    queue.append((prev, distance_to_merge + 1))

    return downstream_merge_target


def _branch_subtree_weight(
    child: str,
    component_set: Set[str],
    backbone_set: Set[str],
    outgoing: Mapping[str, Set[str]],
) -> int:
    """Compute deterministic branch subtree weight for ordering at a hub.

    Weight is the count of reachable non-backbone nodes starting from `child`,
    staying inside the current component and stopping when traversal reaches
    backbone nodes.
    """

    weight = 0
    queue: deque[str] = deque([child])
    seen: Set[str] = set()

    while queue:
        current_node = queue.popleft()
        if current_node in seen:
            continue
        seen.add(current_node)

        if current_node not in component_set or current_node in backbone_set:
            continue

        weight += 1
        for nxt in sorted(outgoing.get(current_node, set())):
            if nxt in component_set and nxt not in seen:
                queue.append(nxt)

    return int(weight)


def _determine_branch_child_order(
    branch_hubs_in_component: List[str],
    outgoing: Mapping[str, Set[str]],
    component_set: Set[str],
    backbone_set: Set[str],
) -> Dict[str, List[str]]:
    ordered_children_by_hub: Dict[str, List[str]] = {}

    for hub in branch_hubs_in_component:
        children = sorted(
            node_id
            for node_id in outgoing.get(hub, set())
            if node_id in component_set and node_id not in backbone_set
        )
        if len(children) < 2:
            continue

        child_scores: List[tuple[int, str]] = []
        for child in children:
            subtree_weight = _branch_subtree_weight(
                child,
                component_set,
                backbone_set,
                outgoing,
            )
            child_scores.append((subtree_weight, str(child)))

        ordered_children_by_hub[hub] = [
            child_id
            for _, child_id in sorted(
                child_scores,
                key=lambda item: (-int(item[0]), item[1]),
            )
        ]

    return ordered_children_by_hub


def _build_node_layout_positions(
    component: List[str],
    component_set: Set[str],
    backbone_set: Set[str],
    kind_by_id: Mapping[str, str],
    out_degree_map: Mapping[str, int],
    incoming: Mapping[str, Set[str]],
    component_distance: Mapping[str, int],
    entry_distance: Mapping[str, int],
    backbone_index: Mapping[str, int],
    backbone_y: Mapping[str, int],
    anchors: Mapping[str, Dict[str, int]],
    branch_assignment: Mapping[str, Dict[str, Any]],
    merge_corridor_map: Mapping[str, Dict[str, Any]],
    downstream_merge_target: Mapping[str, Dict[str, Any]],
    terminal_bundle_anchor_by_id: Mapping[str, Dict[str, int]],
    node_to_terminal_bundle: Mapping[str, str],
) -> tuple[
    Dict[str, Dict[str, int]],
    Dict[str, int],
    Dict[str, int],
    Dict[str, str],
    Dict[str, int],
    Dict[str, float],
]:
    node_layout_positions_local: Dict[str, Dict[str, int]] = {}
    node_layout_columns_local: Dict[str, int] = {}
    node_layout_rows_local: Dict[str, int] = {}
    downstream_merge_ids: Dict[str, str] = {}
    distance_to_merge_ids: Dict[str, int] = {}
    branch_fan_slots: Dict[str, float] = {}
    utility_index = 0
    narrative_index = 0
    terminal_index_by_bundle: Dict[str, int] = {}

    node_process_order = sorted(
        component,
        key=lambda node_id: (
            0 if node_id in backbone_set else 1,
            component_distance.get(node_id, entry_distance.get(node_id, 10**6)),
            str(node_id),
        ),
    )

    for node_id in node_process_order:
        kind = kind_by_id.get(node_id, "node")
        if node_id in backbone_set:
            row_y = backbone_y[node_id]
            node_layout_positions_local[node_id] = {
                "x": anchors["backbone"]["x"],
                "y": row_y,
            }
            node_layout_columns_local[node_id] = 0
            node_layout_rows_local[node_id] = backbone_index[
                node_id
            ]  # logical row order, not pixel Y
            continue

        if kind in UTILITY_KINDS:
            node_layout_positions_local[node_id] = {
                "x": anchors["utility"]["x"],
                "y": utility_index * UTILITY_ROW_SPACING,
            }
            node_layout_columns_local[node_id] = -1
            node_layout_rows_local[node_id] = utility_index
            utility_index += 1
            continue

        if node_id in merge_corridor_map:
            merge_anchor = dict(merge_corridor_map[node_id]["anchor"])
            node_layout_positions_local[node_id] = merge_anchor
            node_layout_columns_local[node_id] = int(
                round(
                    (merge_anchor["x"] - anchors["backbone"]["x"]) / BRANCH_COLUMN_STEP
                )
            )
            node_layout_rows_local[node_id] = int(
                round(merge_anchor["y"] / NARRATIVE_ROW_SPACING)
            )
            continue

        branch_data = branch_assignment.get(node_id)
        if branch_data is not None:
            hub_position = node_layout_positions_local.get(branch_data["hub"])
            if hub_position is None:
                hub_backbone_anchor = _nearest_backbone_anchor(
                    branch_data["hub"],
                    incoming,
                    component_set,
                    backbone_set,
                )
                fallback_hub_y = 0
                if hub_backbone_anchor in node_layout_positions_local:
                    fallback_hub_y = node_layout_positions_local[hub_backbone_anchor][
                        "y"
                    ]
                hub_position = {
                    "x": anchors["branch_bundle"]["x"],
                    "y": fallback_hub_y,
                }

            base_branch_x = int(
                anchors["branch_bundle"]["x"]
                + (branch_data["branch_depth"] + 1) * BRANCH_COLUMN_STEP
            )
            base_branch_y = int(
                round(
                    hub_position["y"] + (branch_data["fan_slot"] * BRANCH_STACK_SPACING)
                )
            )
            merge_target = downstream_merge_target.get(node_id)
            if merge_target is not None:
                pull_strength = 1.0 / float(merge_target["distance_to_merge"] + 1)
                merge_anchor = merge_target["anchor"]
                base_branch_x = int(
                    round(
                        (base_branch_x * (1.0 - pull_strength))
                        + (merge_anchor["x"] * pull_strength)
                    )
                )
                base_branch_y = int(
                    round(
                        (base_branch_y * (1.0 - pull_strength))
                        + (merge_anchor["y"] * pull_strength)
                    )
                )
                downstream_merge_ids[node_id] = str(merge_target["merge_corridor_id"])
                distance_to_merge_ids[node_id] = int(merge_target["distance_to_merge"])

            if out_degree_map.get(node_id, 0) == 0:
                base_branch_x = max(base_branch_x, anchors["terminal_bundle"]["x"])

            node_layout_positions_local[node_id] = {
                "x": base_branch_x,
                "y": base_branch_y,
            }
            node_layout_columns_local[node_id] = int(
                round((base_branch_x - anchors["backbone"]["x"]) / BRANCH_COLUMN_STEP)
            )
            node_layout_rows_local[node_id] = int(
                round(base_branch_y / NARRATIVE_ROW_SPACING)
            )
            branch_fan_slots[node_id] = float(branch_data["fan_slot"])
            continue

        if out_degree_map.get(node_id, 0) == 0:
            bundle_id = node_to_terminal_bundle.get(node_id)
            bundle_anchor = terminal_bundle_anchor_by_id.get(
                bundle_id or "", anchors["terminal_bundle"]
            )
            terminal_slot = terminal_index_by_bundle.get(bundle_id or node_id, 0)
            terminal_index_by_bundle[bundle_id or node_id] = terminal_slot + 1
            backbone_anchor = _nearest_backbone_anchor(
                node_id,
                incoming,
                component_set,
                backbone_set,
            )
            anchor_y = 0
            if backbone_anchor in node_layout_positions_local:
                anchor_y = node_layout_positions_local[backbone_anchor]["y"]
            node_layout_positions_local[node_id] = {
                "x": bundle_anchor["x"],
                "y": anchor_y + (terminal_slot * BRANCH_STACK_SPACING),
            }
            node_layout_columns_local[node_id] = int(
                round(
                    (bundle_anchor["x"] - anchors["backbone"]["x"]) / BRANCH_COLUMN_STEP
                )
            )
            node_layout_rows_local[node_id] = int(
                round(
                    (anchor_y + (terminal_slot * BRANCH_STACK_SPACING))
                    / NARRATIVE_ROW_SPACING
                )
            )
            continue

        backbone_anchor = _nearest_backbone_anchor(
            node_id,
            incoming,
            component_set,
            backbone_set,
        )
        anchor_y = 0
        if backbone_anchor in node_layout_positions_local:
            anchor_y = node_layout_positions_local[backbone_anchor]["y"]
        narrative_y = anchor_y + (narrative_index * NARRATIVE_ROW_SPACING)
        narrative_x = anchors["branch_bundle"]["x"] + BRANCH_COLUMN_STEP
        node_layout_positions_local[node_id] = {
            "x": narrative_x,
            "y": narrative_y,
        }
        node_layout_columns_local[node_id] = int(
            round((narrative_x - anchors["backbone"]["x"]) / BRANCH_COLUMN_STEP)
        )
        node_layout_rows_local[node_id] = int(
            round(narrative_y / NARRATIVE_ROW_SPACING)
        )
        narrative_index += 1

    return (
        node_layout_positions_local,
        node_layout_columns_local,
        node_layout_rows_local,
        downstream_merge_ids,
        distance_to_merge_ids,
        branch_fan_slots,
    )


def _orientation(ax: int, ay: int, bx: int, by: int, cx: int, cy: int) -> int:
    value = (by - ay) * (cx - bx) - (bx - ax) * (cy - by)
    if value == 0:
        return 0
    return 1 if value > 0 else -1


def _on_segment(ax: int, ay: int, bx: int, by: int, cx: int, cy: int) -> bool:
    return min(ax, cx) <= bx <= max(ax, cx) and min(ay, cy) <= by <= max(ay, cy)


def _segments_intersect(
    p1: tuple[int, int],
    p2: tuple[int, int],
    q1: tuple[int, int],
    q2: tuple[int, int],
) -> bool:
    o1 = _orientation(p1[0], p1[1], p2[0], p2[1], q1[0], q1[1])
    o2 = _orientation(p1[0], p1[1], p2[0], p2[1], q2[0], q2[1])
    o3 = _orientation(q1[0], q1[1], q2[0], q2[1], p1[0], p1[1])
    o4 = _orientation(q1[0], q1[1], q2[0], q2[1], p2[0], p2[1])

    if o1 != o2 and o3 != o4:
        return True
    if o1 == 0 and _on_segment(p1[0], p1[1], q1[0], q1[1], p2[0], p2[1]):
        return True
    if o2 == 0 and _on_segment(p1[0], p1[1], q2[0], q2[1], p2[0], p2[1]):
        return True
    if o3 == 0 and _on_segment(q1[0], q1[1], p1[0], p1[1], q2[0], q2[1]):
        return True
    if o4 == 0 and _on_segment(q1[0], q1[1], p2[0], p2[1], q2[0], q2[1]):
        return True
    return False


def _segment_intersects_box(
    start: tuple[int, int],
    end: tuple[int, int],
    center: tuple[int, int],
) -> bool:
    left = center[0] - LAYOUT_NODE_HALF_WIDTH
    right = center[0] + LAYOUT_NODE_HALF_WIDTH
    top = center[1] - LAYOUT_NODE_HALF_HEIGHT
    bottom = center[1] + LAYOUT_NODE_HALF_HEIGHT

    if left <= start[0] <= right and top <= start[1] <= bottom:
        return True
    if left <= end[0] <= right and top <= end[1] <= bottom:
        return True

    box_edges = [
        ((left, top), (right, top)),
        ((right, top), (right, bottom)),
        ((right, bottom), (left, bottom)),
        ((left, bottom), (left, top)),
    ]
    return any(
        _segments_intersect(start, end, box_start, box_end)
        for box_start, box_end in box_edges
    )


def _edge_segment_metrics(
    node_positions: Mapping[str, Dict[str, int]],
    component_edges: List[tuple[str, str]],
) -> Dict[str, tuple[tuple[int, int], tuple[int, int]]]:
    return {
        f"{src}->{dst}": (
            (int(node_positions[src]["x"]), int(node_positions[src]["y"])),
            (int(node_positions[dst]["x"]), int(node_positions[dst]["y"])),
        )
        for src, dst in component_edges
        if src in node_positions and dst in node_positions
    }


def _compute_layout_metrics(
    node_positions: Mapping[str, Dict[str, int]],
    component_edges: List[tuple[str, str]],
) -> Dict[str, Any]:
    edge_segments = _edge_segment_metrics(node_positions, component_edges)
    edge_keys = sorted(edge_segments)
    crossing_count = 0
    overlap_pairs: List[Dict[str, str]] = []

    for index, edge_key in enumerate(edge_keys):
        src_a, dst_a = edge_key.split("->", 1)
        start_a, end_a = edge_segments[edge_key]
        for other_key in edge_keys[index + 1 :]:
            src_b, dst_b = other_key.split("->", 1)
            if {src_a, dst_a} & {src_b, dst_b}:
                continue
            start_b, end_b = edge_segments[other_key]
            if _segments_intersect(start_a, end_a, start_b, end_b):
                crossing_count += 1

        for node_id, position in node_positions.items():
            if node_id in {src_a, dst_a}:
                continue
            center = (int(position["x"]), int(position["y"]))
            if _segment_intersects_box(start_a, end_a, center):
                overlap_pairs.append({"edge_id": edge_key, "node_id": node_id})

    edge_count = len(edge_segments)
    normalized_crossings = float(crossing_count / edge_count) if edge_count else 0.0
    return {
        "crossing_count": crossing_count,
        "normalized_crossings": normalized_crossings,
        "edge_overlap_count": len(overlap_pairs),
        "edge_node_overlaps": sorted(
            overlap_pairs, key=lambda item: (item["edge_id"], item["node_id"])
        ),
    }


def _empty_layout_metrics() -> Dict[str, Any]:
    return {
        "crossing_count": 0,
        "normalized_crossings": 0.0,
        "edge_overlap_count": 0,
        "edge_node_overlaps": [],
    }


def _performance_budget_for_node_count(node_count: int) -> tuple[str, int]:
    if node_count <= PERFORMANCE_BUDGET_SMALL_MAX_NODES:
        return "small", PERFORMANCE_BUDGET_SMALL_MS
    if node_count <= PERFORMANCE_BUDGET_MEDIUM_MAX_NODES:
        return "medium", PERFORMANCE_BUDGET_MEDIUM_MS
    return "large", PERFORMANCE_BUDGET_LARGE_MS


def _cleanup_tier_for_node_count(node_count: int) -> str:
    """Return cleanup band: 'full', 'limited', or 'skip' based on total graph size."""
    if node_count <= CLEANUP_FULL_MAX_NODES:
        return "full"
    if node_count <= CLEANUP_LIMITED_MAX_NODES:
        return "limited"
    return "skip"


def _build_breadth_first_fallback_positions(
    component: List[str],
    entry_distance: Mapping[str, int],
    anchors: Mapping[str, Dict[str, int]],
) -> tuple[Dict[str, Dict[str, int]], Dict[str, int], Dict[str, int]]:
    positions: Dict[str, Dict[str, int]] = {}
    columns: Dict[str, int] = {}
    rows: Dict[str, int] = {}
    row_by_depth: Dict[int, int] = {}

    ordered_nodes = sorted(
        component,
        key=lambda node_id: (
            entry_distance.get(node_id, 10**6),
            str(node_id),
        ),
    )

    for node_id in ordered_nodes:
        depth = int(entry_distance.get(node_id, 0))
        row_slot = row_by_depth.get(depth, 0)
        row_by_depth[depth] = row_slot + 1
        x = int(anchors["backbone"]["x"] + (depth * BRANCH_COLUMN_STEP))
        y = int(row_slot * NARRATIVE_ROW_SPACING)
        positions[node_id] = {"x": x, "y": y}
        columns[node_id] = depth
        rows[node_id] = row_slot

    return positions, columns, rows


def _apply_local_overlap_cleanup(
    node_positions: Dict[str, Dict[str, int]],
    component_edges: List[tuple[str, str]],
    backbone_set: Set[str],
    merge_corridor_map: Mapping[str, Dict[str, Any]],
    kind_by_id: Mapping[str, str],
    nudge_pass_limit: int = MAX_LOCAL_NUDGE_PASSES,
    nudge_count_limit: int = MAX_LOCAL_NUDGES_PER_COMPONENT,
) -> tuple[Dict[str, Dict[str, int]], Dict[str, Dict[str, int]], Dict[str, Any]]:
    cleaned_positions = {
        node_id: {"x": int(pos["x"]), "y": int(pos["y"])}
        for node_id, pos in node_positions.items()
    }
    node_nudges: Dict[str, Dict[str, int]] = {}
    total_nudges = 0

    for _ in range(nudge_pass_limit):
        if total_nudges >= nudge_count_limit:
            break
        metrics = _compute_layout_metrics(cleaned_positions, component_edges)
        overlaps = metrics["edge_node_overlaps"]
        if not overlaps:
            break

        moved_this_pass = False
        candidate_nodes = sorted({item["node_id"] for item in overlaps})
        for node_id in candidate_nodes:
            if node_id in backbone_set or node_id in merge_corridor_map:
                continue
            if kind_by_id.get(node_id, "") in UTILITY_KINDS:
                continue

            current = cleaned_positions.get(node_id)
            if current is None:
                continue

            node_overlaps = [item for item in overlaps if item["node_id"] == node_id]
            preferred_direction = 1
            if node_overlaps:
                edge_midpoint_y = 0.0
                for item in node_overlaps:
                    src_id, dst_id = item["edge_id"].split("->", 1)
                    edge_midpoint_y += (
                        cleaned_positions[src_id]["y"] + cleaned_positions[dst_id]["y"]
                    ) / 2.0
                edge_midpoint_y /= float(len(node_overlaps))
                preferred_direction = 1 if current["y"] >= edge_midpoint_y else -1

            candidate_offsets = [
                preferred_direction * LOCAL_NUDGE_STEP,
                -preferred_direction * LOCAL_NUDGE_STEP,
            ]
            best_candidate = None
            best_metrics = None
            current_metrics = _compute_layout_metrics(
                cleaned_positions, component_edges
            )

            for offset in candidate_offsets:
                trial_positions = {
                    key: {"x": int(pos["x"]), "y": int(pos["y"])}
                    for key, pos in cleaned_positions.items()
                }
                trial_positions[node_id]["y"] = current["y"] + offset
                trial_metrics = _compute_layout_metrics(
                    trial_positions, component_edges
                )
                trial_node_overlap_count = sum(
                    1
                    for item in trial_metrics["edge_node_overlaps"]
                    if item["node_id"] == node_id
                )
                current_node_overlap_count = sum(
                    1
                    for item in current_metrics["edge_node_overlaps"]
                    if item["node_id"] == node_id
                )
                candidate_rank = (
                    trial_node_overlap_count,
                    trial_metrics["edge_overlap_count"],
                    trial_metrics["crossing_count"],
                    abs(offset),
                )
                current_rank = (
                    current_node_overlap_count,
                    current_metrics["edge_overlap_count"],
                    current_metrics["crossing_count"],
                    0,
                )
                if candidate_rank < current_rank and (
                    best_candidate is None or candidate_rank < best_candidate
                ):
                    best_candidate = candidate_rank
                    best_metrics = (trial_positions, trial_metrics, offset)

            if best_metrics is None:
                continue

            cleaned_positions = best_metrics[0]
            node_nudges[node_id] = {
                "dx": 0,
                "dy": node_nudges.get(node_id, {}).get("dy", 0) + int(best_metrics[2]),
            }
            total_nudges += 1
            if total_nudges >= nudge_count_limit:
                moved_this_pass = True
                break
            moved_this_pass = True

        if not moved_this_pass:
            break

    final_metrics = _compute_layout_metrics(cleaned_positions, component_edges)
    final_metrics["local_nudge_count"] = total_nudges
    return cleaned_positions, node_nudges, final_metrics


def analyze_flow_graph(
    nodes: Iterable[Mapping[str, Any]],
    edges: Iterable[Mapping[str, Any]],
) -> Dict[str, Any]:
    """Compute reusable reachability and dead-end metadata for collapsed flow graphs."""

    analysis_started_at = time.perf_counter()

    node_list = [dict(node) for node in nodes]
    edge_list = [dict(edge) for edge in edges]

    analyzable_nodes = [
        node
        for node in node_list
        if str(node.get("type", node.get("kind", ""))) != "execution_container"
        and node.get("id")
    ]
    node_ids = {str(node["id"]) for node in analyzable_nodes}

    outgoing: Dict[str, Set[str]] = {node_id: set() for node_id in node_ids}
    incoming: Dict[str, Set[str]] = {node_id: set() for node_id in node_ids}

    for edge in edge_list:
        src = str(edge.get("src") or edge.get("source") or "")
        dst = str(edge.get("dst") or edge.get("target") or "")
        if src in node_ids and dst in node_ids:
            outgoing[src].add(dst)
            incoming[dst].add(src)

    # D11 — Call/Return Relations Phase 1
    # These helpers are defined inline to stay local to this function scope.
    def _is_call_edge(e: Dict[str, Any]) -> bool:
        return e.get("kind") == "call" or e.get("edge_type") == "call"

    def _is_return_edge(e: Dict[str, Any]) -> bool:
        return e.get("kind") == "return" or e.get("edge_type") == "return"

    # Build set of callee node_ids: nodes with at least one CALL-kinded inbound edge.
    d11_call_inbound: Set[str] = set()
    for _e in edge_list:
        _dst = str(_e.get("dst") or _e.get("target") or "")
        if _dst in node_ids and _is_call_edge(_e):
            d11_call_inbound.add(_dst)

    # Build call_return_pairs from CALL edges; compute call_bundle_id per call site.
    d11_call_return_pairs: List[Dict[str, Any]] = []
    _d11_seen_sites: set = set()
    for _e in edge_list:
        if not _is_call_edge(_e):
            continue
        _src = str(_e.get("src") or _e.get("source") or "")
        _dst = str(_e.get("dst") or _e.get("target") or "")
        if _src not in node_ids or _dst not in node_ids:
            continue
        _meta = _e.get("meta") or {}
        _call_file = str(_meta.get("call_file") or "")
        _call_line = int(_meta.get("call_line") or 0)
        _site_key = (_src, _dst, _call_file, _call_line)
        if _site_key in _d11_seen_sites:
            continue
        _d11_seen_sites.add(_site_key)
        _bundle_bytes = f"{_call_file}:{_src}:{_call_line}:{_dst}".encode()
        _call_bundle_id = hashlib.sha256(_bundle_bytes).hexdigest()[:12]
        d11_call_return_pairs.append(
            {
                "caller": _src,
                "callee": _dst,
                # D11 Phase 3: continuation = caller at label granularity.
                # After `return`, execution resumes in the calling label (the call site).
                "continuation_site": _src,
                "call_bundle_id": _call_bundle_id,
            }
        )

    # D11 Phase 3: Build synthetic RETURN edges (callee → continuation_site) for visualization.
    # At label granularity, continuation_site = caller (return jumps back to the call site label).
    # These edges are additive-only; they do not affect the reachability analysis that already ran.
    d11_synthetic_return_edges: List[Dict[str, Any]] = []
    _seen_return_pairs: Set[tuple] = set()
    for _pair in d11_call_return_pairs:
        _callee = _pair["callee"]
        _cont = _pair["continuation_site"]  # = caller
        if _callee == "?" or not _cont:
            # Skip dynamic calls (no resolved callee) and pairs with no continuation.
            continue
        _rkey = (_callee, _cont)
        if _rkey in _seen_return_pairs:
            continue
        _seen_return_pairs.add(_rkey)
        d11_synthetic_return_edges.append(
            {
                "src": _callee,
                "dst": _cont,
                "kind": "return",
                "edge_type": "return",
                "origin": "d11",
                "confidence": "definite",
                "isInternal": False,
                "isImplicitReturn": False,
                "meta": {
                    "d11_source": "synthetic_return",
                    "call_bundle_id": _pair["call_bundle_id"],
                },
            }
        )

    # Classify RETURN vs RETURN_NO_CALL for nodes with return-kind outgoing edges.
    d11_return_classification: Dict[str, str] = {}
    for _e in edge_list:
        if not _is_return_edge(_e):
            continue
        _src = str(_e.get("src") or _e.get("source") or "")
        if _src not in node_ids:
            continue
        _cls = "RETURN" if _src in d11_call_inbound else "RETURN_NO_CALL"
        # Upgrade to RETURN if we see any CALL inbound (takes precedence).
        if _src not in d11_return_classification or (
            d11_return_classification[_src] == "RETURN_NO_CALL" and _cls == "RETURN"
        ):
            d11_return_classification[_src] = _cls

    entry_ids = sorted(
        str(node["id"])
        for node in analyzable_nodes
        if str(node.get("type", node.get("kind", ""))) == "entry"
    )
    if not entry_ids:
        entry_ids = sorted(node_id for node_id in node_ids if not incoming[node_id])

    kind_by_id: Dict[str, str] = {
        str(node["id"]): str(node.get("type", node.get("kind", "node")))
        for node in analyzable_nodes
    }
    out_degree_map: Dict[str, int] = {
        node_id: len(outgoing[node_id]) for node_id in node_ids
    }

    reachable: Set[str] = set()
    entry_distance: Dict[str, int] = {}
    bfs_queue: deque[tuple[str, int]] = deque((node_id, 0) for node_id in entry_ids)

    while bfs_queue:
        node_id, depth = bfs_queue.popleft()
        if node_id in reachable:
            continue
        reachable.add(node_id)
        entry_distance[node_id] = depth
        for nxt in sorted(outgoing.get(node_id, set())):
            if nxt not in reachable:
                bfs_queue.append((nxt, depth + 1))

    node_meta: Dict[str, Dict[str, Any]] = {}
    warnings: List[Dict[str, Any]] = []
    unreachable_nodes: List[str] = []
    dead_end_nodes: List[str] = []
    terminal_end_nodes: List[str] = []
    branch_hub_nodes: List[str] = []
    utility_nodes: List[str] = []
    narrative_nodes: List[str] = []
    component_entry_candidates: Dict[str, List[str]] = {}
    node_to_component: Dict[str, str] = {}
    node_to_lane: Dict[str, str] = {}
    node_to_branch_bundle: Dict[str, str] = {}
    node_to_terminal_bundle: Dict[str, str] = {}
    node_to_branch_fan_slot: Dict[str, float] = {}
    node_to_merge_corridor: Dict[str, str] = {}
    node_to_downstream_merge: Dict[str, str] = {}
    node_to_distance_to_merge: Dict[str, int] = {}
    node_to_layout_position: Dict[str, Dict[str, int]] = {}
    node_to_layout_column: Dict[str, int] = {}
    node_to_layout_row: Dict[str, int] = {}
    node_to_layout_nudge: Dict[str, Dict[str, int]] = {}
    backbone_scores: Dict[str, int] = {}
    backbone_nodes: Set[str] = set()
    component_summaries: List[Dict[str, Any]] = []
    cluster_layout: List[Dict[str, Any]] = []
    component_anchors: Dict[str, Dict[str, Dict[str, int]]] = {}
    component_backbone_nodes: Dict[str, Set[str]] = {}
    component_branch_nodes: Dict[str, Set[str]] = {}
    component_terminal_nodes: Dict[str, Set[str]] = {}
    component_merge_corridors: Dict[str, List[Dict[str, Any]]] = {}
    total_backbone_length = 0
    total_branch_bundle_count = 0
    total_terminal_bundle_count = 0
    total_merge_corridor_count = 0
    total_crossing_count_before_cleanup = 0
    total_crossing_count = 0
    total_edge_overlap_count_before_cleanup = 0
    total_edge_overlap_count = 0
    total_local_nudge_count = 0
    total_reordered_branch_hub_count = 0
    total_layout_edge_count = 0
    longest_reachable_depth = max(entry_distance.values(), default=0)
    total_fallback_components = 0

    fallback_mode = "none"
    if len(analyzable_nodes) > LARGE_GRAPH_BREADTH_FIRST_THRESHOLD:
        fallback_mode = "breadth_first"
    elif len(analyzable_nodes) > LARGE_GRAPH_CLUSTER_ONLY_THRESHOLD:
        fallback_mode = "cluster_only"

    cleanup_tier = _cleanup_tier_for_node_count(len(analyzable_nodes))

    # D1a — linear chain compaction (additive pre-pass; does not alter layout).
    chain_compaction = _compact_linear_chains(
        node_ids=node_ids,
        outgoing=outgoing,
        incoming=incoming,
        kind_by_id=kind_by_id,
    )

    # D1b — narrative segment compression (feature-flagged; default off).
    segment_compression = _compact_narrative_segments(
        node_ids=node_ids,
        outgoing=outgoing,
        incoming=incoming,
        kind_by_id=kind_by_id,
        enabled=False,
    )

    # D9 — narrative structure diagnostics (enabled; research output).
    narrative_structure = _compute_narrative_structure(
        node_ids=node_ids,
        outgoing=outgoing,
        incoming=incoming,
        kind_by_id=kind_by_id,
        enabled=True,
    )

    t_semantic_end = time.perf_counter()
    stage_ms_semantic = float((t_semantic_end - analysis_started_at) * 1000.0)
    stage_ms_cluster_layout = 0.0
    stage_ms_cleanup_reorder = 0.0
    stage_ms_cleanup_overlap_nudge = 0.0

    components = _build_components(node_ids, outgoing, incoming)

    # D2 — component ordering: entry-kind first, then by size, then by id.
    def _cluster_priority(comp: List[str]) -> tuple:
        has_entry = any(kind_by_id.get(n, "") == "entry" for n in comp)
        return (0 if has_entry else 1, -len(comp), comp[0])

    components = sorted(components, key=_cluster_priority)

    for component_index, component in enumerate(components, start=1):
        # D2 — base_x includes island gutter bonus for non-primary components.
        base_x_for_component = (component_index - 1) * (
            MIN_CLUSTER_GUTTER + 520 + COMPONENT_ISLAND_BONUS
        )
        component_id = f"c{component_index:04d}"
        component_set = set(component)

        explicit_entries = sorted(
            node_id for node_id in component if kind_by_id.get(node_id, "") == "entry"
        )
        if explicit_entries:
            entry_candidates = explicit_entries
        else:
            roots = sorted(
                node_id
                for node_id in component
                if not any(src in component_set for src in incoming.get(node_id, set()))
            )
            if roots:
                entry_candidates = roots
            else:
                min_in_degree = min(
                    _component_in_degree(node_id, incoming, component_set)
                    for node_id in component
                )
                entry_candidates = sorted(
                    node_id
                    for node_id in component
                    if _component_in_degree(node_id, incoming, component_set)
                    == min_in_degree
                )

        component_entry_candidates[component_id] = entry_candidates

        candidate_scores = [
            _score_backbone_candidate(
                start=node_id,
                component_nodes=component_set,
                outgoing=outgoing,
                out_degree=out_degree_map,
            )
            for node_id in entry_candidates
        ]
        candidate_scores.sort(
            key=lambda item: (
                -int(item["score"]),
                -int(item["reachable_depth"]),
                -int(item["reachable_nodes"]),
                str(item["entry_candidate"]),
            )
        )
        winner = candidate_scores[0] if candidate_scores else None

        for node_id in component:
            node_to_component[node_id] = component_id
        if winner:
            backbone_nodes.update(winner.get("backbone_path", []))
            backbone_scores[winner["entry_candidate"]] = int(winner["score"])

        selected_entry = winner.get("entry_candidate") if winner else None
        component_reachable: Set[str] = set()
        component_distance: Dict[str, int] = {}
        if selected_entry:
            component_reachable, component_distance, _ = _bfs_reachable(
                selected_entry,
                outgoing,
                component_set,
            )

        backbone_path: List[str] = winner.get("backbone_path", []) if winner else []
        backbone_set = set(backbone_path)
        component_backbone_nodes[component_id] = backbone_set
        backbone_index = {node_id: idx for idx, node_id in enumerate(backbone_path)}

        # M16 — D10: adaptive cumulative backbone stride (bilateral fan sum)
        backbone_y: Dict[str, int] = {}
        _cumulative_y = 0
        for _i, _node in enumerate(backbone_path):
            backbone_y[_node] = _cumulative_y
            _fan_cur = len(
                [
                    _c
                    for _c in outgoing.get(_node, set())
                    if _c in component_set and _c not in backbone_set
                ]
            )
            _next = backbone_path[_i + 1] if _i + 1 < len(backbone_path) else None
            _fan_nxt = (
                len(
                    [
                        _c
                        for _c in outgoing.get(_next, set())
                        if _c in component_set and _c not in backbone_set
                    ]
                )
                if _next is not None
                else 0
            )
            _half_cur = (
                ((_fan_cur - 1) / 2) * BRANCH_STACK_SPACING if _fan_cur > 0 else 0
            )
            _half_nxt = (
                ((_fan_nxt - 1) / 2) * BRANCH_STACK_SPACING if _fan_nxt > 0 else 0
            )
            _cumulative_y += max(
                BACKBONE_ROW_SPACING, int(_half_cur + _half_nxt) + MIN_BUNDLE_CLEARANCE
            )

        branch_hubs_in_component = sorted(
            node_id
            for node_id in component
            if out_degree_map.get(node_id, 0) >= 2
            or kind_by_id.get(node_id, "") in BRANCH_HUB_KINDS
        )
        branch_bundle_specs: List[Dict[str, Any]] = []
        branch_nodes_in_component: Set[str] = set()
        for branch_index, hub in enumerate(branch_hubs_in_component, start=1):
            children = sorted(
                node_id
                for node_id in outgoing.get(hub, set())
                if node_id in component_set and node_id not in backbone_set
            )
            if not children:
                continue
            bundle_id = f"{component_id}:bb{branch_index:02d}"
            for child in children:
                node_to_branch_bundle[child] = bundle_id
            node_to_branch_bundle[hub] = bundle_id
            branch_nodes_in_component.add(hub)
            branch_nodes_in_component.update(children)
            branch_bundle_specs.append(
                {
                    "bundle_id": bundle_id,
                    "hub": hub,
                    "children": children,
                    "anchor": {
                        "x": base_x_for_component + MIN_BACKBONE_CLEARANCE,
                        "y": 0,
                    },
                }
            )

        component_branch_nodes[component_id] = branch_nodes_in_component

        terminal_nodes_component = sorted(
            node_id for node_id in component if out_degree_map.get(node_id, 0) == 0
        )
        terminal_nodes_set = set(terminal_nodes_component)
        component_terminal_nodes[component_id] = terminal_nodes_set

        terminal_grouped: Dict[str, List[str]] = {}
        for terminal in terminal_nodes_component:
            anchor = _nearest_backbone_anchor(
                terminal,
                incoming,
                component_set,
                backbone_set,
            )
            if anchor is None:
                anchor = backbone_path[0] if backbone_path else terminal
            terminal_grouped.setdefault(anchor, []).append(terminal)

        terminal_bundle_specs: List[Dict[str, Any]] = []
        terminal_bundle_anchor_by_id: Dict[str, Dict[str, int]] = {}
        for terminal_index, anchor in enumerate(sorted(terminal_grouped), start=1):
            bundle_id = f"{component_id}:tb{terminal_index:02d}"
            terminals = sorted(terminal_grouped[anchor])
            for terminal in terminals:
                node_to_terminal_bundle[terminal] = bundle_id
            bundle_anchor = {
                "x": base_x_for_component + (MIN_BACKBONE_CLEARANCE * 2),
                "y": 0,
            }
            terminal_bundle_anchor_by_id[bundle_id] = bundle_anchor
            terminal_bundle_specs.append(
                {
                    "bundle_id": bundle_id,
                    "anchor_backbone_node": anchor,
                    "terminals": terminals,
                    "anchor": bundle_anchor,
                }
            )

        base_x = base_x_for_component
        anchors = {
            "backbone": {"x": base_x, "y": 0},
            "branch_bundle": {"x": base_x + MIN_BACKBONE_CLEARANCE, "y": 0},
            "terminal_bundle": {"x": base_x + (MIN_BACKBONE_CLEARANCE * 2), "y": 0},
            "utility": {"x": base_x - MIN_BACKBONE_CLEARANCE, "y": 0},
        }
        component_anchors[component_id] = anchors

        bundle_id_by_hub = {
            str(spec["hub"]): str(spec["bundle_id"]) for spec in branch_bundle_specs
        }
        component_fallback_mode = fallback_mode
        reordered_branch_hubs: List[str] = []
        branch_fan_slots: Dict[str, float] = {}
        downstream_merge_ids: Dict[str, str] = {}
        distance_to_merge_ids: Dict[str, int] = {}

        if component_fallback_mode == "breadth_first":
            total_fallback_components += 1
            branch_assignment, _ = _build_branch_assignment(
                branch_hubs_in_component,
                outgoing,
                component_set,
                backbone_set,
                bundle_id_by_hub,
            )
            merge_corridors = []
            merge_corridor_map: Dict[str, Dict[str, Any]] = {}
            downstream_merge_target: Dict[str, Dict[str, Any]] = {}
            pre_cleanup_positions, pre_cleanup_columns, pre_cleanup_rows = (
                _build_breadth_first_fallback_positions(
                    component,
                    entry_distance,
                    anchors,
                )
            )
            node_layout_positions_local = pre_cleanup_positions
            node_layout_columns_local = pre_cleanup_columns
            node_layout_rows_local = pre_cleanup_rows
            pre_cleanup_metrics = _empty_layout_metrics()
            node_nudges: Dict[str, Dict[str, int]] = {}
            final_layout_metrics = _empty_layout_metrics()
            final_layout_metrics["local_nudge_count"] = 0
            for spec in branch_bundle_specs:
                spec["cleanup_applied"] = False
        else:
            initial_branch_assignment, _ = _build_branch_assignment(
                branch_hubs_in_component,
                outgoing,
                component_set,
                backbone_set,
                bundle_id_by_hub,
            )
            initial_merge_corridors, initial_merge_corridor_map = (
                _build_merge_corridors(
                    component,
                    component_id,
                    component_set,
                    backbone_set,
                    incoming,
                    initial_branch_assignment,
                    backbone_y,
                    anchors,
                )
            )
            initial_downstream_merge_target = _build_downstream_merge_target(
                initial_merge_corridors,
                component_set,
                backbone_set,
                incoming,
            )

            if component_fallback_mode == "cluster_only":
                total_fallback_components += 1
                branch_assignment = initial_branch_assignment
                merge_corridors = []
                merge_corridor_map = {}
                downstream_merge_target = {}
                (
                    node_layout_positions_local,
                    node_layout_columns_local,
                    node_layout_rows_local,
                    downstream_merge_ids,
                    distance_to_merge_ids,
                    branch_fan_slots,
                ) = _build_node_layout_positions(
                    component,
                    component_set,
                    backbone_set,
                    kind_by_id,
                    out_degree_map,
                    incoming,
                    component_distance,
                    entry_distance,
                    backbone_index,
                    backbone_y,
                    anchors,
                    branch_assignment,
                    merge_corridor_map,
                    downstream_merge_target,
                    terminal_bundle_anchor_by_id,
                    node_to_terminal_bundle,
                )
                pre_cleanup_metrics = _empty_layout_metrics()
                node_nudges = {}
                final_layout_metrics = _empty_layout_metrics()
                final_layout_metrics["local_nudge_count"] = 0
                for spec in branch_bundle_specs:
                    spec["cleanup_applied"] = False
            else:
                if cleanup_tier == "full":
                    pre_cleanup_positions, _, _, _, _, _ = _build_node_layout_positions(
                        component,
                        component_set,
                        backbone_set,
                        kind_by_id,
                        out_degree_map,
                        incoming,
                        component_distance,
                        entry_distance,
                        backbone_index,
                        backbone_y,
                        anchors,
                        initial_branch_assignment,
                        initial_merge_corridor_map,
                        initial_downstream_merge_target,
                        terminal_bundle_anchor_by_id,
                        node_to_terminal_bundle,
                    )

                    _t_reorder = time.perf_counter()
                    ordered_children_by_hub = _determine_branch_child_order(
                        branch_hubs_in_component,
                        outgoing,
                        component_set,
                        backbone_set,
                    )
                    reordered_branch_hubs = sorted(
                        hub
                        for hub in ordered_children_by_hub
                        if ordered_children_by_hub[hub]
                        != sorted(
                            node_id
                            for node_id in outgoing.get(hub, set())
                            if node_id in component_set and node_id not in backbone_set
                        )
                    )[:MAX_REORDERED_BRANCH_HUBS]
                    ordered_children_by_hub = {
                        hub: ordered_children_by_hub[hub]
                        for hub in reordered_branch_hubs
                    }
                    branch_assignment, _ = _build_branch_assignment(
                        branch_hubs_in_component,
                        outgoing,
                        component_set,
                        backbone_set,
                        bundle_id_by_hub,
                        ordered_children_by_hub,
                    )
                    for spec in branch_bundle_specs:
                        hub = str(spec["hub"])
                        if hub in ordered_children_by_hub:
                            spec["children"] = list(ordered_children_by_hub[hub])
                            spec["cleanup_applied"] = hub in reordered_branch_hubs
                        else:
                            spec["cleanup_applied"] = False

                    merge_corridors, merge_corridor_map = _build_merge_corridors(
                        component,
                        component_id,
                        component_set,
                        backbone_set,
                        incoming,
                        branch_assignment,
                        backbone_y,
                        anchors,
                    )
                    downstream_merge_target = _build_downstream_merge_target(
                        merge_corridors,
                        component_set,
                        backbone_set,
                        incoming,
                    )

                    (
                        node_layout_positions_local,
                        node_layout_columns_local,
                        node_layout_rows_local,
                        downstream_merge_ids,
                        distance_to_merge_ids,
                        branch_fan_slots,
                    ) = _build_node_layout_positions(
                        component,
                        component_set,
                        backbone_set,
                        kind_by_id,
                        out_degree_map,
                        incoming,
                        component_distance,
                        entry_distance,
                        backbone_index,
                        backbone_y,
                        anchors,
                        branch_assignment,
                        merge_corridor_map,
                        downstream_merge_target,
                        terminal_bundle_anchor_by_id,
                        node_to_terminal_bundle,
                    )
                    stage_ms_cleanup_reorder += (
                        time.perf_counter() - _t_reorder
                    ) * 1000.0

                    component_edges = sorted(
                        (src, dst)
                        for src in component
                        for dst in sorted(outgoing.get(src, set()))
                        if dst in component_set
                    )
                    pre_cleanup_metrics = _compute_layout_metrics(
                        pre_cleanup_positions, component_edges
                    )

                    _t_nudge = time.perf_counter()
                    cleaned_positions, node_nudges, final_layout_metrics = (
                        _apply_local_overlap_cleanup(
                            node_layout_positions_local,
                            component_edges,
                            backbone_set,
                            merge_corridor_map,
                            kind_by_id,
                        )
                    )
                    stage_ms_cleanup_overlap_nudge += (
                        time.perf_counter() - _t_nudge
                    ) * 1000.0
                    for node_id, layout_position in cleaned_positions.items():
                        node_layout_positions_local[node_id] = layout_position
                else:
                    # limited tier: skip sibling reorder; use initial assignment and corridors; limited nudge caps
                    (
                        node_layout_positions_local,
                        node_layout_columns_local,
                        node_layout_rows_local,
                        downstream_merge_ids,
                        distance_to_merge_ids,
                        branch_fan_slots,
                    ) = _build_node_layout_positions(
                        component,
                        component_set,
                        backbone_set,
                        kind_by_id,
                        out_degree_map,
                        incoming,
                        component_distance,
                        entry_distance,
                        backbone_index,
                        backbone_y,
                        anchors,
                        initial_branch_assignment,
                        initial_merge_corridor_map,
                        initial_downstream_merge_target,
                        terminal_bundle_anchor_by_id,
                        node_to_terminal_bundle,
                    )
                    merge_corridors = initial_merge_corridors
                    merge_corridor_map = initial_merge_corridor_map
                    downstream_merge_target = initial_downstream_merge_target
                    branch_assignment = initial_branch_assignment
                    reordered_branch_hubs = []
                    for spec in branch_bundle_specs:
                        spec["cleanup_applied"] = False

                    component_edges = sorted(
                        (src, dst)
                        for src in component
                        for dst in sorted(outgoing.get(src, set()))
                        if dst in component_set
                    )
                    pre_cleanup_metrics = _compute_layout_metrics(
                        node_layout_positions_local, component_edges
                    )

                    if cleanup_tier == "limited":
                        _t_nudge = time.perf_counter()
                        _t_nudge = time.perf_counter()
                        cleaned_positions, node_nudges, final_layout_metrics = (
                            _apply_local_overlap_cleanup(
                                node_layout_positions_local,
                                component_edges,
                                backbone_set,
                                merge_corridor_map,
                                kind_by_id,
                                nudge_pass_limit=MAX_LOCAL_NUDGE_PASSES_LIMITED,
                                nudge_count_limit=MAX_LOCAL_NUDGES_PER_COMPONENT_LIMITED,
                            )
                        )
                        stage_ms_cleanup_overlap_nudge += (
                            time.perf_counter() - _t_nudge
                        ) * 1000.0
                        for node_id, layout_position in cleaned_positions.items():
                            node_layout_positions_local[node_id] = layout_position
                    else:
                        # skip tier: no overlap cleanup at all
                        node_nudges = {}
                        final_layout_metrics = _empty_layout_metrics()
                        final_layout_metrics["local_nudge_count"] = 0

        component_merge_corridors[component_id] = merge_corridors
        total_merge_corridor_count += len(merge_corridors)
        for merge_corridor in merge_corridors:
            node_to_merge_corridor[str(merge_corridor["merge_node"])] = str(
                merge_corridor["merge_corridor_id"]
            )

        component_edges = sorted(
            (src, dst)
            for src in component
            for dst in sorted(outgoing.get(src, set()))
            if dst in component_set
        )
        total_layout_edge_count += len(component_edges)

        if component_fallback_mode != "none":
            pre_cleanup_metrics = _empty_layout_metrics()
            final_layout_metrics = _empty_layout_metrics()
            final_layout_metrics["local_nudge_count"] = 0
            node_nudges = {}

        total_crossing_count_before_cleanup += int(
            pre_cleanup_metrics["crossing_count"]
        )
        total_crossing_count += int(final_layout_metrics["crossing_count"])
        total_edge_overlap_count_before_cleanup += int(
            pre_cleanup_metrics["edge_overlap_count"]
        )
        total_edge_overlap_count += int(final_layout_metrics["edge_overlap_count"])
        total_local_nudge_count += int(final_layout_metrics.get("local_nudge_count", 0))
        total_reordered_branch_hub_count += len(reordered_branch_hubs)

        for node_id, layout_position in node_layout_positions_local.items():
            node_to_layout_position[node_id] = layout_position
            node_to_layout_column[node_id] = node_layout_columns_local.get(node_id, 0)
            node_to_layout_row[node_id] = node_layout_rows_local.get(node_id, 0)
            if node_id in downstream_merge_ids:
                node_to_downstream_merge[node_id] = downstream_merge_ids[node_id]
            if node_id in distance_to_merge_ids:
                node_to_distance_to_merge[node_id] = distance_to_merge_ids[node_id]
            if node_id in branch_fan_slots:
                node_to_branch_fan_slot[node_id] = branch_fan_slots[node_id]
            if node_id in node_nudges:
                node_to_layout_nudge[node_id] = node_nudges[node_id]

        cluster_layout.append(
            {
                "component_id": component_id,
                "origin": {"x": base_x, "y": 0},
                "cluster_gutter": MIN_CLUSTER_GUTTER,
                "backbone_clearance": MIN_BACKBONE_CLEARANCE,
                "anchors": anchors,
                "backbone_path": backbone_path,
                "branch_bundles": branch_bundle_specs,
                "terminal_bundles": terminal_bundle_specs,
                "merge_corridors": merge_corridors,
                "cleanup": {
                    "reordered_branch_hubs": reordered_branch_hubs,
                    "fallback_mode": component_fallback_mode,
                    "pre_cleanup_metrics": pre_cleanup_metrics,
                    "final_metrics": final_layout_metrics,
                },
                "metrics": {
                    "backbone_length": len(backbone_path),
                    "branch_bundle_count": len(branch_bundle_specs),
                    "terminal_bundle_count": len(terminal_bundle_specs),
                    "merge_corridor_count": len(merge_corridors),
                    "crossing_count_before_cleanup": int(
                        pre_cleanup_metrics["crossing_count"]
                    ),
                    "crossing_count": int(final_layout_metrics["crossing_count"]),
                    "edge_overlap_count_before_cleanup": int(
                        pre_cleanup_metrics["edge_overlap_count"]
                    ),
                    "edge_overlap_count": int(
                        final_layout_metrics["edge_overlap_count"]
                    ),
                    "local_nudge_count": int(
                        final_layout_metrics.get("local_nudge_count", 0)
                    ),
                    "reordered_branch_hub_count": len(reordered_branch_hubs),
                },
            }
        )

        total_backbone_length += len(backbone_path)
        total_branch_bundle_count += len(branch_bundle_specs)
        total_terminal_bundle_count += len(terminal_bundle_specs)

        component_summaries.append(
            {
                "component_id": component_id,
                "node_count": len(component),
                "node_ids": component,
                "entry_candidates": entry_candidates,
                "backbone": {
                    "selected_entry": winner.get("entry_candidate") if winner else None,
                    "path": winner.get("backbone_path", []) if winner else [],
                    "score": winner.get("score") if winner else None,
                },
                "candidate_scores": candidate_scores,
                "merge_corridors": merge_corridors,
                "cleanup": {
                    "reordered_branch_hubs": reordered_branch_hubs,
                    "fallback_mode": component_fallback_mode,
                    "pre_cleanup_metrics": pre_cleanup_metrics,
                    "final_metrics": final_layout_metrics,
                },
            }
        )

    normalized_crossings_before_cleanup = (
        float(total_crossing_count_before_cleanup / total_layout_edge_count)
        if total_layout_edge_count
        else 0.0
    )
    normalized_crossings = (
        float(total_crossing_count / total_layout_edge_count)
        if total_layout_edge_count
        else 0.0
    )

    for node in analyzable_nodes:
        node_id = str(node["id"])
        kind = str(node.get("type", node.get("kind", "node")))
        is_reachable = node_id in reachable
        out_degree = len(outgoing.get(node_id, set()))
        in_degree = len(incoming.get(node_id, set()))
        terminal_end = out_degree == 0
        # Tier 1.6: Labels that end with `call screen X` are UI-controlled terminals.
        # The screen drives the next transition; the node itself has no outgoing edge
        # by design, so it is NOT a structural dead-end bug.
        is_ui_terminal = bool(node.get("ui_terminal", False))
        dead_end = (
            is_reachable and kind != "exit" and out_degree == 0 and not is_ui_terminal
        )
        warning_codes: List[str] = []

        component_id = node_to_component.get(node_id)
        entry_candidates = component_entry_candidates.get(component_id or "", [])
        is_entry_candidate = node_id in entry_candidates

        is_branch_hub = out_degree >= 2 or kind in BRANCH_HUB_KINDS
        is_utility = kind in UTILITY_KINDS
        if is_utility:
            semantic_role = "utility"
            utility_nodes.append(node_id)
        elif terminal_end:
            semantic_role = "terminal"
        elif is_branch_hub:
            semantic_role = "branch_hub"
            branch_hub_nodes.append(node_id)
        else:
            semantic_role = "narrative"
            narrative_nodes.append(node_id)

        if terminal_end:
            terminal_end_nodes.append(node_id)

        lane = "narrative"
        if node_id in component_backbone_nodes.get(component_id or "", set()):
            lane = "backbone"
        elif is_utility:
            lane = "utility"
        elif node_id in node_to_merge_corridor:
            lane = "narrative"
        elif node_id in component_terminal_nodes.get(component_id or "", set()):
            lane = "terminal_bundle"
        elif node_id in component_branch_nodes.get(component_id or "", set()):
            lane = "branch_bundle"
        node_to_lane[node_id] = lane

        anchors = component_anchors.get(component_id or "", {})
        lane_anchor = anchors.get(lane) or anchors.get("backbone") or {"x": 0, "y": 0}

        if not is_reachable:
            unreachable_nodes.append(node_id)
            warning_codes.append("FLOW_UNREACHABLE_NODE")
            warnings.append(
                {
                    "code": "FLOW_UNREACHABLE_NODE",
                    "severity": "warning",
                    "node_id": node_id,
                    "file": str(node.get("file", "")),
                    "line": int(node.get("line") or 0),
                    "message": f"Node '{node_id}' is not reachable from any entry node.",
                    "evidence": {"entry_nodes": entry_ids},
                }
            )

        if dead_end:
            dead_end_nodes.append(node_id)
            warning_codes.append("FLOW_DEAD_END_NON_EXIT")
            warnings.append(
                {
                    "code": "FLOW_DEAD_END_NON_EXIT",
                    "severity": "warning",
                    "node_id": node_id,
                    "file": str(node.get("file", "")),
                    "line": int(node.get("line") or 0),
                    "message": f"Node '{node_id}' ends the flow but is not marked as an exit.",
                    "evidence": {"out_degree": out_degree, "kind": kind},
                }
            )

        if is_reachable and is_ui_terminal and out_degree == 0:
            # Screen-call terminal: flow exits through a Ren'Py screen (intentional UI end).
            # This is informational, not a structural warning.
            warning_codes.append("FLOW_SCREEN_TERMINAL")
            warnings.append(
                {
                    "code": "FLOW_SCREEN_TERMINAL",
                    "severity": "info",
                    "node_id": node_id,
                    "file": str(node.get("file", "")),
                    "line": int(node.get("line") or 0),
                    "message": (
                        f"Node '{node_id}' ends flow via screen "
                        f"'{node.get('via_screen', '?')}' (UI-controlled terminal)."
                    ),
                    "evidence": {
                        "via_screen": node.get("via_screen", ""),
                        "out_degree": out_degree,
                    },
                }
            )

        node_meta[node_id] = {
            "is_reachable": is_reachable,
            "terminal_end": terminal_end,
            "dead_end": dead_end,
            "ui_terminal": is_ui_terminal,
            "in_degree": in_degree,
            "out_degree": out_degree,
            "entry_distance": entry_distance.get(node_id),
            "component_id": component_id,
            "entry_candidate": is_entry_candidate,
            "backbone_score": backbone_scores.get(node_id),
            "on_backbone": node_id in backbone_nodes,
            "semantic_role": semantic_role,
            "branch_hub": is_branch_hub,
            "cluster_lane": lane,
            "cluster_anchor": lane_anchor,
            "layout_position": node_to_layout_position.get(node_id),
            "cluster_column": node_to_layout_column.get(node_id),
            "cluster_row": node_to_layout_row.get(node_id),
            "branch_bundle_id": node_to_branch_bundle.get(node_id),
            "branch_fan_slot": node_to_branch_fan_slot.get(node_id),
            "terminal_bundle_id": node_to_terminal_bundle.get(node_id),
            "merge_corridor_id": node_to_merge_corridor.get(node_id),
            "downstream_merge_corridor_id": node_to_downstream_merge.get(node_id),
            "distance_to_merge_corridor": node_to_distance_to_merge.get(node_id),
            "layout_nudge": node_to_layout_nudge.get(node_id),
            "warning_codes": warning_codes,
            "classification_source": (
                "framework protection rule"
                if kind == "execution_container"
                else "graph reachability analysis"
            ),
        }

    runtime_ms = float((time.perf_counter() - analysis_started_at) * 1000.0)
    budget_tier, budget_ms = _performance_budget_for_node_count(len(analyzable_nodes))
    dual_metrics = _build_dual_metrics(
        raw_node_count=len(analyzable_nodes),
        chain_compaction=chain_compaction,
    )
    expand_on_demand = _build_expand_on_demand_stub(chain_compaction)
    # segment_compression already computed above (D1b, feature-flagged)

    semantic_summary = {
        "version": "m6-performance-hardening-v1",
        "backbone_weights": {
            "W1_reachable_depth": BACKBONE_WEIGHTS["reachable_depth"],
            "W2_reachable_nodes": BACKBONE_WEIGHTS["reachable_nodes"],
            "W3_terminal_count": BACKBONE_WEIGHTS["terminal_count"],
            "W4_cycle_penalty": BACKBONE_WEIGHTS["cycle_penalty"],
        },
        "tie_breakers": [
            "longest_reachable_depth",
            "highest_downstream_node_count",
            "lexicographic_node_id",
        ],
        "components": component_summaries,
        "cluster_layout": cluster_layout,
        "cleanup": {
            "crossing_count_before_cleanup": int(total_crossing_count_before_cleanup),
            "crossing_count": int(total_crossing_count),
            "normalized_crossings_before_cleanup": normalized_crossings_before_cleanup,
            "normalized_crossings": normalized_crossings,
            "edge_overlap_count_before_cleanup": int(
                total_edge_overlap_count_before_cleanup
            ),
            "edge_overlap_count": int(total_edge_overlap_count),
            "local_nudge_count": int(total_local_nudge_count),
            "reordered_branch_hub_count": int(total_reordered_branch_hub_count),
            "cleanup_tier_count_basis": "raw_node_count",
            "caps": {
                "max_local_nudge_passes": int(MAX_LOCAL_NUDGE_PASSES),
                "max_local_nudges_per_component": int(MAX_LOCAL_NUDGES_PER_COMPONENT),
                "max_local_nudge_passes_limited": int(MAX_LOCAL_NUDGE_PASSES_LIMITED),
                "max_local_nudges_per_component_limited": int(
                    MAX_LOCAL_NUDGES_PER_COMPONENT_LIMITED
                ),
                "max_reordered_branch_hubs": int(MAX_REORDERED_BRANCH_HUBS),
                "cleanup_full_max_nodes": int(CLEANUP_FULL_MAX_NODES),
                "cleanup_limited_max_nodes": int(CLEANUP_LIMITED_MAX_NODES),
            },
            "fallback": {
                "mode": fallback_mode,
                "node_count_basis": "raw_node_count",
                "cluster_only_threshold": int(LARGE_GRAPH_CLUSTER_ONLY_THRESHOLD),
                "breadth_first_threshold": int(LARGE_GRAPH_BREADTH_FIRST_THRESHOLD),
                "fallback_component_count": int(total_fallback_components),
            },
        },
        "performance": {
            "runtime_ms": runtime_ms,
            "budget_tier": budget_tier,
            "budget_target_ms": int(budget_ms),
            "within_budget": runtime_ms <= float(budget_ms),
            "node_count": len(analyzable_nodes),
            "node_count_basis": "raw_node_count",
            "cleanup_tier": cleanup_tier,
            "stages": {
                "semantic_pass": round(stage_ms_semantic, 2),
                "cluster_layout": round(stage_ms_cluster_layout, 2),
                "cleanup_reorder": round(stage_ms_cleanup_reorder, 2),
                "cleanup_overlap_nudge": round(stage_ms_cleanup_overlap_nudge, 2),
            },
        },
        "counts": {
            "component_count": len(component_summaries),
            "cluster_count": len(cluster_layout),
            "backbone_length": int(total_backbone_length),
            "branch_bundle_count": int(total_branch_bundle_count),
            "terminal_bundle_count": int(total_terminal_bundle_count),
            "merge_corridor_count": int(total_merge_corridor_count),
            "crossing_count_before_cleanup": int(total_crossing_count_before_cleanup),
            "crossing_count": int(total_crossing_count),
            "normalized_crossings_before_cleanup": normalized_crossings_before_cleanup,
            "normalized_crossings": normalized_crossings,
            "edge_overlap_count_before_cleanup": int(
                total_edge_overlap_count_before_cleanup
            ),
            "edge_overlap_count": int(total_edge_overlap_count),
            "local_nudge_count": int(total_local_nudge_count),
            "reordered_branch_hub_count": int(total_reordered_branch_hub_count),
            "fallback_component_count": int(total_fallback_components),
            "branch_hub_nodes": len(set(branch_hub_nodes)),
            "utility_nodes": len(set(utility_nodes)),
            "terminal_nodes": len(set(terminal_end_nodes)),
            "narrative_nodes": len(set(narrative_nodes)),
        },
        "chain_compaction": chain_compaction,
        "dual_metrics": dual_metrics,
        "expand_on_demand": expand_on_demand,
        "segment_compression": segment_compression,
        "narrative_structure": narrative_structure,
        # D11 — Call/Return Relations Phase 1 + Phase 3
        "edge_model_version": "d11-v1",
        "call_return_pairs": d11_call_return_pairs,
        "return_classification": d11_return_classification,
    }

    semantic_summary["deterministic_signature"] = _deterministic_signature(
        {
            "components": semantic_summary["components"],
            "cluster_layout": semantic_summary["cluster_layout"],
            "weights": semantic_summary["backbone_weights"],
            "ties": semantic_summary["tie_breakers"],
            "counts": semantic_summary["counts"],
            "cleanup": semantic_summary["cleanup"],
            "d11_call_pairs": [
                {
                    "caller": p["caller"],
                    "callee": p["callee"],
                    "id": p["call_bundle_id"],
                }
                for p in d11_call_return_pairs
            ],
            "node_layout": {
                node_id: {
                    "position": node_meta[node_id].get("layout_position"),
                    "column": node_meta[node_id].get("cluster_column"),
                    "row": node_meta[node_id].get("cluster_row"),
                    "merge_corridor_id": node_meta[node_id].get("merge_corridor_id"),
                    "downstream_merge_corridor_id": node_meta[node_id].get(
                        "downstream_merge_corridor_id"
                    ),
                    "layout_nudge": node_meta[node_id].get("layout_nudge"),
                }
                for node_id in sorted(node_meta)
            },
        }
    )

    return {
        "entry_nodes": entry_ids,
        "reachable_nodes": sorted(reachable),
        "unreachable_nodes": sorted(unreachable_nodes),
        "terminal_end_nodes": sorted(terminal_end_nodes),
        "dead_end_nodes": sorted(dead_end_nodes),
        "screen_terminal_nodes": sorted(
            n["id"] for n in analyzable_nodes if n.get("ui_terminal") and n.get("id")
        ),
        "branch_hub_nodes": sorted(set(branch_hub_nodes)),
        "utility_nodes": sorted(set(utility_nodes)),
        "narrative_nodes": sorted(set(narrative_nodes)),
        "components": component_summaries,
        "cluster_layout": cluster_layout,
        "semantic_summary": semantic_summary,
        "longest_reachable_depth": longest_reachable_depth,
        "node_metadata": node_meta,
        "warnings": warnings,
        # D11 Phase 3: synthetic RETURN edges to append to the graph edge list.
        "synthetic_return_edges": d11_synthetic_return_edges,
    }
