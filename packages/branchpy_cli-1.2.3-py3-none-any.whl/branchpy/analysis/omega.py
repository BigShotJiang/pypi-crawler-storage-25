# BranchPyApp/branchpy/analysis/omega.py

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


@dataclass(frozen=True)
class OmegaLimits:
    value_cap: int = 50
    combo_cap: int = 2000


def _is_number(x: Any) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _safe_hashable(v: Any) -> Optional[str]:
    """
    Convert values into a stable string bucket for sets.
    Avoid huge blobs; cap collection repr length.
    """
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if _is_number(v):
        return str(v)
    if isinstance(v, str):
        return v if len(v) <= 200 else (v[:200] + "…")
    if isinstance(v, (list, tuple, set, dict)):
        s = (
            json.dumps(v, ensure_ascii=False)
            if not isinstance(v, set)
            else json.dumps(sorted(list(v)), ensure_ascii=False)
        )
        return s if len(s) <= 300 else (s[:300] + "…")
    return str(v)[:300]


def _walk_for_events(obj: Any) -> Iterable[Dict[str, Any]]:
    """
    Walk an unknown stats2.json structure and yield dicts that look like state-change events.
    We accept a dict as an "event" if it has at least:
      - variable name key: 'var' or 'name' or 'variable'
      - and either before/after or op
    """
    if isinstance(obj, dict):
        # candidate event
        keys = set(obj.keys())
        has_var = any(k in keys for k in ("var", "name", "variable"))
        has_signal = any(
            k in keys for k in ("before", "after", "op", "operation", "mutation")
        )
        if has_var and has_signal:
            yield obj

        for v in obj.values():
            yield from _walk_for_events(v)

    elif isinstance(obj, list):
        for it in obj:
            yield from _walk_for_events(it)


def run_omega(
    stats2_path: Path, omega_path: Path, limits: OmegaLimits
) -> Dict[str, Any]:
    data = json.loads(stats2_path.read_text(encoding="utf-8"))
    _paths_raw = data.get("paths", []) if isinstance(data, dict) else []

    # Accumulators
    vars_summary: Dict[str, Dict[str, Any]] = {}
    capped_vars: Set[str] = set()

    # Collect per-variable observed end-state facts for co-occurrence
    # MVP: build a path-final "snapshot" by applying last-seen "after" for each var.
    snapshots: List[Dict[str, str]] = []

    # Heuristic: group events by path if stats2 has explicit path buckets; otherwise treat as one bucket.
    # We'll attempt to detect top-level list of paths like data.get('paths') or similar.
    path_objs: List[Any] = []
    if isinstance(data, dict):
        for k in ("paths", "stats2_paths", "all_paths"):
            if k in data and isinstance(data[k], list):
                path_objs = data[k]
                break

    if not path_objs:
        # fallback: one implicit path over all events
        path_objs = [data]

    total_events = 0

    for pobj in path_objs:
        snapshot: Dict[str, str] = {}
        for ev in _walk_for_events(pobj):
            total_events += 1
            var = ev.get("var") or ev.get("name") or ev.get("variable")
            var = str(var)

            op = ev.get("op") or ev.get("operation") or ev.get("mutation") or "unknown"
            before = ev.get("before", ev.get("from_value", None))
            after = ev.get("after", ev.get("to_value", None))

            # Initialize
            if var not in vars_summary:
                vars_summary[var] = {
                    "type": "unknown",
                    "min": None,
                    "max": None,
                    "seen_true": False,
                    "seen_false": False,
                    "_values_set": set(),
                    "values_truncated": False,
                    "observed_ops": set(),
                }

            info = vars_summary[var]
            info["observed_ops"].add(str(op))

            # Determine type / update stats
            if isinstance(after, bool) or isinstance(before, bool):
                info["type"] = "boolean"
                if after is True or before is True:
                    info["seen_true"] = True
                if after is False or before is False:
                    info["seen_false"] = True

            elif _is_number(after) or _is_number(before):
                info["type"] = "number"
                for val in (before, after):
                    if _is_number(val):
                        mn = info["min"]
                        mx = info["max"]
                        info["min"] = val if mn is None else min(mn, val)
                        info["max"] = val if mx is None else max(mx, val)

            else:
                # enum/string bucket
                if info["type"] == "unknown":
                    info["type"] = "enum_or_string"
                for val in (before, after):
                    sv = _safe_hashable(val)
                    if sv is None:
                        continue
                    if sv not in info["_values_set"]:
                        if len(info["_values_set"]) >= limits.value_cap:
                            info["values_truncated"] = True
                            capped_vars.add(var)
                        else:
                            info["_values_set"].add(sv)

            # Update snapshot (use after if present else before)
            sv2 = _safe_hashable(after if after is not None else before)
            if sv2 is not None:
                snapshot[var] = sv2

        if snapshot:
            snapshots.append(snapshot)

    # Impossible combo candidates (MVP): end-of-path co-occurrence only.
    # Build facts: (var=value) appears in snapshot; then see which pairs never co-occur.
    # Guardrail: compute only for top N vars by occurrence.
    var_counts: Dict[str, int] = {}
    # val_counts[(var, val_str)] = number of END-OF-PATH SNAPSHOTS where var=val.
    # NOTE: this counts snapshot occurrences, NOT unique paths.  A path that has one
    # final snapshot contributes exactly once.  The name 'path_count_*' in the output
    # refers to this per-snapshot count (paths_total == len(snapshots)).
    val_counts: Dict[Tuple[str, str], int] = {}
    for snap in snapshots:
        for v, sv in snap.items():
            var_counts[v] = var_counts.get(v, 0) + 1
            key_vc = (v, sv)
            val_counts[key_vc] = val_counts.get(key_vc, 0) + 1

    top_vars = [
        v for v, _ in sorted(var_counts.items(), key=lambda t: t[1], reverse=True)
    ][:30]
    # Build set of observed pairs
    observed_pairs: Set[Tuple[str, str, str, str]] = (
        set()
    )  # (v1,val1,v2,val2) ordered by name
    for snap in snapshots:
        items = [(v, snap[v]) for v in snap.keys() if v in top_vars]
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                v1, a1 = items[i]
                v2, a2 = items[j]
                if v2 < v1:
                    v1, v2 = v2, v1
                    a1, a2 = a2, a1
                observed_pairs.add((v1, a1, v2, a2))

    # Candidates: choose some plausible "never-seen" combos by sampling value sets
    impossible_candidates: List[Dict[str, Any]] = []
    checked = 0
    for i in range(len(top_vars)):
        for j in range(i + 1, len(top_vars)):
            v1 = top_vars[i]
            v2 = top_vars[j]
            s1 = list(vars_summary[v1]["_values_set"])[
                : min(10, len(vars_summary[v1]["_values_set"]))
            ]
            s2 = list(vars_summary[v2]["_values_set"])[
                : min(10, len(vars_summary[v2]["_values_set"]))
            ]
            for a1 in s1:
                for a2 in s2:
                    if checked >= limits.combo_cap:
                        break
                    checked += 1
                    key = (v1, a1, v2, a2) if v1 < v2 else (v2, a2, v1, a1)
                    if key not in observed_pairs:
                        # Evidence counts = number of end-of-path snapshots in which each
                        # side value was the final observed value for that variable.
                        # 'path_count_v1/v2' naming kept for UI readability; semantically
                        # these are snapshot-occurrence counts (one per path, one snapshot
                        # per path by construction of the MVP co-occurrence model).
                        impossible_candidates.append(
                            {
                                "vars": [v1, v2],
                                "combo": [a1, a2],
                                "path_count_v1": val_counts.get((v1, a1), 0),
                                "path_count_v2": val_counts.get((v2, a2), 0),
                                "paths_total": len(snapshots),
                            }
                        )
                if checked >= limits.combo_cap:
                    break
            if checked >= limits.combo_cap:
                break
        if checked >= limits.combo_cap:
            break

    # Finalize variable summaries
    out_vars: Dict[str, Any] = {}
    for var, info in vars_summary.items():
        observed_ops = sorted(list(info["observed_ops"]))
        if info["type"] == "number":
            out_vars[var] = {
                "type": "number",
                "min": info["min"],
                "max": info["max"],
                "observed_ops": observed_ops,
            }
        elif info["type"] == "boolean":
            out_vars[var] = {
                "type": "boolean",
                "seen_true": bool(info["seen_true"]),
                "seen_false": bool(info["seen_false"]),
                "observed_ops": observed_ops,
            }
        else:
            vals = sorted(list(info["_values_set"]))
            out_vars[var] = {
                "type": "enum_or_string",
                "values": vals,
                "truncated": bool(info["values_truncated"]),
                "observed_ops": observed_ops,
            }

    # --- Public Class B output: summary counts only; no per-variable value sets ---
    # Full variable detail (out_vars) and impossible_combo_candidates are Class C
    # engine internals that reveal the Ω state-space analysis method.
    # They remain in memory / available to callers but are NOT written to the public file.
    capped_flag = (len(capped_vars) > 0) or (checked >= limits.combo_cap)

    # Per-variable thin summary: type + observed_op_count only (no value sets / ranges)
    thin_vars: Dict[str, Any] = {}
    for var, vinfo in out_vars.items():
        thin_vars[var] = {
            "type": vinfo["type"],
            "observed_ops_count": len(vinfo["observed_ops"]),
        }

    result: Dict[str, Any] = {
        "omega_version": "0.1.0",
        "source": {
            "tool": "pilot",
        },
        "stats": {
            "paths_seen": len(snapshots),
            "events_seen": total_events,
            "variables_seen": len(out_vars),
        },
        # Class B public summary — no per-variable value sets or per-node metrics
        "variables_summary": thin_vars,
        "impossible_combo_count": len(impossible_candidates),
        "limits": {
            "value_cap": limits.value_cap,
            "combo_cap": limits.combo_cap,
            "capped": capped_flag,
            "capped_variables_count": len(capped_vars),
            "combo_checks": checked,
        },
    }

    omega_path.parent.mkdir(parents=True, exist_ok=True)
    omega_path.write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # Write explanation-layer payload to .internal/omega_full.json.
    # Contains full variable bounds + impossible_combo_candidates with evidence fields.
    # GOVERNANCE: This file is internal — do not expose via CLI help, API, or public docs.
    # Only read by the VS Code panel (loadOmegaReport). Never written if paths = 0.
    omega_full_path = omega_path.parent / ".internal" / "omega_full.json"
    omega_full_path.parent.mkdir(parents=True, exist_ok=True)
    omega_full_payload: Dict[str, Any] = {
        "omega_version": result["omega_version"],
        "variables": out_vars,
        "impossible_combo_candidates": impossible_candidates,
    }
    omega_full_path.write_text(
        json.dumps(omega_full_payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # Full Class C payload kept in return value for in-process callers (daemon wire format).
    result["_internal"] = {
        "variables": out_vars,
        "impossible_combo_candidates": impossible_candidates,
        "capped_variables": sorted(list(capped_vars)),
    }
    return result
