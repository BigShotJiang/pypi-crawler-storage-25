"""
Image scanner - Build index of all images in project
Cross-platform and engine-agnostic (RenPy, Unity, Godot, Unreal, etc.)
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import List, Optional

try:  # Optional dependency (installed via image_validation extra)
    from PIL import Image  # type: ignore

    _PIL_AVAILABLE = True
except ImportError:  # pragma: no cover
    Image = None  # type: ignore
    _PIL_AVAILABLE = False

from .models import ImageFile


class ImageScanner:
    """Scan project for image files and build index"""

    # Supported image formats
    SUPPORTED_FORMATS = {".png", ".webp", ".jpg", ".jpeg", ".gif", ".bmp"}

    # Directories to skip
    SKIP_DIRS = {
        "__pycache__",
        ".git",
        ".vscode",
        "node_modules",
        ".branchpy",
        "cache",
        "temp",
    }

    # Engine-specific default image directories
    ENGINE_DEFAULTS = {
        "renpy": ["game/images", "game/gui"],
        "unity": ["Assets/Sprites", "Assets/Textures", "Assets/UI"],
        "godot": ["assets/images", "assets/sprites"],
        "unreal": ["Content/Textures", "Content/UI"],
        "generic": ["images", "assets", "sprites", "graphics"],
    }

    def __init__(
        self,
        project_dir: Path,
        images_dir: Optional[Path] = None,
        engine: str = "renpy",
        recursive: bool = True,
    ):
        """
        Initialize scanner

        Args:
            project_dir: Root directory of project
            images_dir: Custom images directory (overrides engine defaults)
            engine: Engine type ('renpy', 'unity', 'godot', 'unreal', 'generic')
            recursive: Recursively scan subdirectories
        """
        self.project_dir = project_dir
        self.engine = engine
        self.recursive = recursive
        self.scanned_files: List[ImageFile] = []

        # Determine images directory
        if images_dir:
            self.images_dirs = [images_dir]
        else:
            # Use engine defaults
            default_paths = self.ENGINE_DEFAULTS.get(
                engine, self.ENGINE_DEFAULTS["generic"]
            )
            self.images_dirs = [project_dir / path for path in default_paths]

    def scan(self) -> List[ImageFile]:
        """
        Scan images directory and build file index

        Returns:
            List of ImageFile objects
        """
        self.scanned_files = []

        # Try each potential images directory
        found_any = False
        for images_dir in self.images_dirs:
            if images_dir.exists():
                print(
                    f"[ImageScanner] Scanning: {images_dir.relative_to(self.project_dir)}"
                )
                self._scan_directory(images_dir)
                found_any = True

        if not found_any:
            print("[ImageScanner] Warning: No image directories found")
            print(
                f"  Tried: {', '.join(str(d.relative_to(self.project_dir)) for d in self.images_dirs)}"
            )
            print("  Hint: Use --images-dir to specify custom location")

        print(f"[ImageScanner] Scanned {len(self.scanned_files)} images")
        return self.scanned_files

    def _scan_directory(self, directory: Path) -> None:
        """Recursively scan directory for image files"""
        try:
            for item in directory.iterdir():
                # Skip hidden files and excluded directories
                if item.name.startswith(".") or item.name in self.SKIP_DIRS:
                    continue

                if item.is_dir():
                    self._scan_directory(item)
                elif item.is_file() and item.suffix.lower() in self.SUPPORTED_FORMATS:
                    image_file = self._process_image(item)
                    if image_file:
                        self.scanned_files.append(image_file)
        except PermissionError:
            print(f"[ImageScanner] Permission denied: {directory}")
        except Exception as e:
            print(f"[ImageScanner] Error scanning {directory}: {e}")

    def _process_image(self, path: Path) -> ImageFile | None:
        """
        Extract metadata from image file

        Args:
            path: Absolute path to image file

        Returns:
            ImageFile object or None if processing failed
        """
        try:
            # Get file size
            size_bytes = path.stat().st_size

            # Open image to get dimensions and format
            if not _PIL_AVAILABLE:
                # Minimal fallback without Pillow: we cannot read dimensions
                width, height = 0, 0
                img_format = path.suffix[1:].upper()
            else:
                with Image.open(path) as img:  # type: ignore[attr-defined]
                    width, height = img.size
                    img_format = getattr(img, "format", None) or path.suffix[1:].upper()

            # Compute MD5 hash for exact duplicate detection
            md5_hash = self._compute_md5(path)

            # Relative path from project root
            rel_path = str(path.relative_to(self.project_dir)).replace("\\", "/")

            return ImageFile(
                path=rel_path,
                abs_path=path,
                size_bytes=size_bytes,
                width=width,
                height=height,
                format=img_format,
                hash_md5=md5_hash,
            )

        except Exception as e:
            print(f"[ImageScanner] Failed to process {path.name}: {e}")
            return None

    def _compute_md5(self, path: Path) -> str:
        """Compute MD5 hash of file contents"""
        md5 = hashlib.md5()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                md5.update(chunk)
        return md5.hexdigest()
