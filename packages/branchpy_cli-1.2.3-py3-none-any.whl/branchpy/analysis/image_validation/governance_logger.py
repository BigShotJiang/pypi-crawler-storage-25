"""
Image Validation Governance Logger
Structured JSONL event logging for audit trail integration
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy.core.governance.logger import GovernanceLogger

logger = logging.getLogger(__name__)


class ImageValidationLogger:
    """
    Governance logger for image validation operations.

    Emits structured JSONL events for:
    - Validation runs (scan, hash, cluster)
    - Cache operations (hit/miss, invalidation)
    - Semantic tagging operations
    - Provider synchronization (Phase 2)

    Integrates with BranchPy audit system for:
    - RBAC enforcement tracking
    - Compliance reporting
    - Performance analytics
    """

    def __init__(self, project_root: Path, correlation_id: Optional[str] = None):
        """
        Initialize logger.

        Args:
            project_root: Project root directory
            correlation_id: Optional correlation ID for grouping events
        """
        self.project_root = project_root
        self.correlation_id = correlation_id or str(uuid.uuid4())
        self.governance_logger = GovernanceLogger(project_root, use_batching=True)

    def log_validation_start(
        self,
        backend: str,
        engine: str,
        images_dir: Optional[Path],
        use_cache: bool,
        semantic: bool,
    ) -> None:
        """Log validation pipeline start"""
        event = {
            "event_type": "IMAGE_VALIDATION_START",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation",
            "actor": "system",
            "context": {
                "backend": backend,
                "engine": engine,
                "images_dir": str(images_dir) if images_dir else None,
                "cache_enabled": use_cache,
                "semantic_enabled": semantic,
                "project_root": str(self.project_root),
            },
        }
        self.governance_logger.log_event(event)
        logger.info(f"[ImageValidation] Started (correlation_id={self.correlation_id})")

    def log_scan_complete(
        self, total_images: int, scan_time_ms: float, directories_scanned: list[str]
    ) -> None:
        """Log image scanning completion"""
        event = {
            "event_type": "IMAGE_SCAN_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation",
            "actor": "system",
            "context": {
                "total_images": total_images,
                "scan_time_ms": scan_time_ms,
                "directories_scanned": directories_scanned,
                "images_per_second": (
                    total_images / (scan_time_ms / 1000) if scan_time_ms > 0 else 0
                ),
            },
        }
        self.governance_logger.log_event(event)

    def log_feature_extraction(
        self,
        backend: str,
        total_images: int,
        cache_hits: int,
        cache_misses: int,
        extraction_time_ms: float,
    ) -> None:
        """Log feature extraction metrics"""
        event = {
            "event_type": "FEATURE_EXTRACTION_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation",
            "actor": "system",
            "context": {
                "backend": backend,
                "total_images": total_images,
                "cache_hits": cache_hits,
                "cache_misses": cache_misses,
                "cache_hit_rate": cache_hits / total_images if total_images > 0 else 0,
                "extraction_time_ms": extraction_time_ms,
                "images_per_second": (
                    total_images / (extraction_time_ms / 1000)
                    if extraction_time_ms > 0
                    else 0
                ),
            },
        }
        self.governance_logger.log_event(event)

    def log_cache_operation(
        self,
        operation: str,
        backend: str,
        success: bool,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log cache operations (get, set, invalidate, purge)"""
        event = {
            "event_type": f"CACHE_{operation.upper()}",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.cache",
            "actor": "system",
            "context": {
                "operation": operation,
                "backend": backend,
                "success": success,
                **(details or {}),
            },
        }
        self.governance_logger.log_event(event)

    def log_cache_hit(
        self, cache_layer: str, key: str, backend: Optional[str] = None
    ) -> None:
        event = {
            "event_type": "CACHE_HIT",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.cache",
            "actor": "system",
            "context": {
                "cache_layer": cache_layer,  # lru | redis | feature_store
                "key": key,
                "backend": backend,
            },
        }
        self.governance_logger.log_event(event)

    def log_cache_miss(
        self, cache_layer: str, key: str, backend: Optional[str] = None
    ) -> None:
        event = {
            "event_type": "CACHE_MISS",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.cache",
            "actor": "system",
            "context": {
                "cache_layer": cache_layer,
                "key": key,
                "backend": backend,
            },
        }
        self.governance_logger.log_event(event)

    def log_clustering_complete(
        self, duplicates_found: int, similarity_clusters: int, clustering_time_ms: float
    ) -> None:
        """Log clustering results"""
        event = {
            "event_type": "CLUSTERING_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation",
            "actor": "system",
            "context": {
                "duplicates_found": duplicates_found,
                "similarity_clusters": similarity_clusters,
                "clustering_time_ms": clustering_time_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_semantic_linking(
        self,
        nodes_created: int,
        images_tagged: int,
        confidence_avg: float,
        linking_time_ms: float,
    ) -> None:
        """Log semantic auto-tagging results"""
        event = {
            "event_type": "SEMANTIC_LINKING_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.semantic",
            "actor": "system",
            "context": {
                "nodes_created": nodes_created,
                "images_tagged": images_tagged,
                "confidence_avg": confidence_avg,
                "linking_time_ms": linking_time_ms,
                "tagging_rate": (
                    images_tagged / (linking_time_ms / 1000)
                    if linking_time_ms > 0
                    else 0
                ),
            },
        }
        self.governance_logger.log_event(event)

    def log_validation_complete(
        self,
        total_images: int,
        duplicates: int,
        clusters: int,
        total_time_ms: float,
        report_path: Optional[Path] = None,
    ) -> None:
        """Log validation pipeline completion"""
        event = {
            "event_type": "IMAGE_VALIDATION_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation",
            "actor": "system",
            "context": {
                "total_images": total_images,
                "duplicates_found": duplicates,
                "similarity_clusters": clusters,
                "total_time_ms": total_time_ms,
                "report_path": str(report_path) if report_path else None,
                "throughput": (
                    total_images / (total_time_ms / 1000) if total_time_ms > 0 else 0
                ),
            },
        }
        self.governance_logger.log_event(event)
        logger.info(
            f"[ImageValidation] Complete (correlation_id={self.correlation_id})"
        )

    # ------------------------------------------------------------------
    # Phase 3 Governance Additions: Semantic Tag & Canonical operations
    # ------------------------------------------------------------------

    def log_semantic_tag_updated(
        self, cluster_id: str, tag: str, action: str, actor: str = "user"
    ) -> None:
        """Log semantic tag add/remove events

        Args:
            cluster_id: target cluster id
            tag: tag modified
            action: 'add' | 'remove'
            actor: source actor (default user)
        """
        event = {
            "event_type": (
                "SEMANTIC_TAG_UPDATED" if action == "add" else "SEMANTIC_TAG_REMOVED"
            ),
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.semantic.tag",
            "actor": actor,
            "context": {"cluster_id": cluster_id, "tag": tag, "action": action},
        }
        self.governance_logger.log_event(event)

    def log_canonical_set(
        self,
        cluster_id: str,
        canonical_path: str,
        previous: Optional[str],
        actor: str = "user",
    ) -> None:
        """Log canonical image selection"""
        event = {
            "event_type": "CANONICAL_SET",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.canonical",
            "actor": actor,
            "context": {
                "cluster_id": cluster_id,
                "canonical_path": canonical_path,
                "previous": previous,
            },
        }
        self.governance_logger.log_event(event)

    def log_canonical_unset(self, cluster_id: str, actor: str = "user") -> None:
        event = {
            "event_type": "CANONICAL_UNSET",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.canonical",
            "actor": actor,
            "context": {"cluster_id": cluster_id},
        }
        self.governance_logger.log_event(event)

    def log_error(
        self, error_type: str, message: str, details: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log validation errors"""
        event = {
            "event_type": "IMAGE_VALIDATION_ERROR",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.error",
            "actor": "system",
            "context": {
                "error_type": error_type,
                "message": message,
                **(details or {}),
            },
        }
        self.governance_logger.log_event(event)
        logger.error(f"[ImageValidation] Error: {error_type} - {message}")

    def flush(self) -> None:
        """Flush any buffered events (important for batched writes)"""
        if (
            hasattr(self.governance_logger, "_batcher")
            and self.governance_logger._batcher
        ):
            try:
                self.governance_logger._batcher.flush()
            except Exception as e:
                logger.warning(f"Failed to flush event batcher: {e}")

    # Phase 2: Provider Operations Logging

    def log_provider_connect_start(
        self, provider_id: str, provider_display_name: str
    ) -> None:
        """Log provider connection start"""
        event = {
            "event_type": "PROVIDER_CONNECT_START",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "provider_display_name": provider_display_name,
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_connect_ok(self, provider_id: str, duration_ms: float) -> None:
        """Log successful provider connection"""
        event = {
            "event_type": "PROVIDER_CONNECT_OK",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider",
            "actor": "system",
            "context": {"provider_id": provider_id, "duration_ms": duration_ms},
        }
        self.governance_logger.log_event(event)

    def log_provider_connect_error(
        self, provider_id: str, error_type: str, error_message: str, duration_ms: float
    ) -> None:
        """Log provider connection error"""
        event = {
            "event_type": "PROVIDER_CONNECT_ERROR",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.error",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "error_type": error_type,
                "error_message": error_message,
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_list_assets(
        self,
        provider_id: str,
        asset_count: int,
        folder: Optional[str],
        duration_ms: float,
        bytes_transferred: int = 0,
    ) -> None:
        """Log provider asset listing"""
        event = {
            "event_type": "PROVIDER_LIST_ASSETS",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "asset_count": asset_count,
                "folder": folder,
                "duration_ms": duration_ms,
                "bytes_transferred": bytes_transferred,
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_fetch_asset(
        self, provider_id: str, asset_id: str, size_bytes: int, duration_ms: float
    ) -> None:
        """Log provider asset fetch"""
        event = {
            "event_type": "PROVIDER_FETCH_ASSET",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "asset_id": asset_id,
                "size_bytes": size_bytes,
                "duration_ms": duration_ms,
                "throughput_mbps": (
                    (size_bytes / (duration_ms / 1000)) / (1024 * 1024)
                    if duration_ms > 0
                    else 0
                ),
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_push_report(
        self,
        provider_id: str,
        remote_path: str,
        size_bytes: int,
        duration_ms: float,
        report_id: Optional[str] = None,
    ) -> None:
        """Log report upload to provider"""
        event = {
            "event_type": "PROVIDER_PUSH_REPORT",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "remote_path": remote_path,
                "report_id": report_id,
                "size_bytes": size_bytes,
                "duration_ms": duration_ms,
                "throughput_mbps": (
                    (size_bytes / (duration_ms / 1000)) / (1024 * 1024)
                    if duration_ms > 0
                    else 0
                ),
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_health_check(
        self,
        provider_id: str,
        status: str,
        latency_ms: Optional[float],
        quota_used: Optional[int],
        quota_total: Optional[int],
    ) -> None:
        """Log provider health check result"""
        event = {
            "event_type": "PROVIDER_HEALTH_CHECK",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "status": status,
                "latency_ms": latency_ms,
                "quota_used": quota_used,
                "quota_total": quota_total,
                "quota_percentage": (
                    (quota_used / quota_total * 100)
                    if quota_used and quota_total
                    else None
                ),
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_credential_rotate_start(
        self, provider_id: Optional[str] = None
    ) -> None:
        """Log credential rotation start"""
        event = {
            "event_type": "PROVIDER_CREDENTIAL_ROTATE_START",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.security",
            "actor": "system",
            "context": {
                "provider_id": provider_id or "all",
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_credential_rotate_complete(
        self, provider_count: int, duration_ms: float, provider_id: Optional[str] = None
    ) -> None:
        """Log credential rotation completion"""
        event = {
            "event_type": "PROVIDER_CREDENTIAL_ROTATE_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.security",
            "actor": "system",
            "context": {
                "provider_id": provider_id or "all",
                "provider_count": provider_count,
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_credential_rotate_error(
        self, error_message: str, duration_ms: float, provider_id: Optional[str] = None
    ) -> None:
        """Log credential rotation error"""
        event = {
            "event_type": "PROVIDER_CREDENTIAL_ROTATE_ERROR",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.security.error",
            "actor": "system",
            "context": {
                "provider_id": provider_id or "all",
                "error_message": error_message,
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_credential_rotate_dry_run(
        self,
        provider_count: int,
        duration_ms: float,
        status: str,
        errors: Optional[list] = None,
    ) -> None:
        """Log credential rotation dry-run simulation"""
        event = {
            "event_type": "PROVIDER_CREDENTIAL_ROTATE_DRY_RUN",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.security.simulation",
            "actor": "system",
            "context": {
                "provider_count": provider_count,
                "duration_ms": duration_ms,
                "status": status,
                "error_count": len(errors) if errors else 0,
                "errors": errors or [],
            },
        }
        self.governance_logger.log_event(event)

    # ------------------------------------------------------------------
    # Phase 2+ Expansion: Validation Progress & Issue Emission
    # ------------------------------------------------------------------

    def log_validation_progress_step(
        self,
        step: str,
        detail: Optional[str] = None,
        percent: Optional[float] = None,
        stage_time_ms: Optional[float] = None,
    ) -> None:
        """Log incremental validation progress step.
        Args:
            step: High-level stage identifier (e.g., 'scan', 'feature_extract').
            detail: Optional human-readable detail.
            percent: Optional overall progress percent (0-100).
            stage_time_ms: Optional elapsed stage time.
        """
        event = {
            "event_type": "VALIDATION_PROGRESS_STEP",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.progress",
            "actor": "system",
            "context": {
                "step": step,
                "detail": detail,
                "percent": percent,
                "stage_time_ms": stage_time_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_validation_issue_emitted(
        self,
        issue_type: str,
        image_path: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log an individual validation issue emission for streaming UI updates."""
        event = {
            "event_type": "VALIDATION_ISSUE_EMITTED",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.issue",
            "actor": "system",
            "context": {
                "issue_type": issue_type,
                "image_path": image_path,
                **(metadata or {}),
            },
        }
        self.governance_logger.log_event(event)

    # ------------------------------------------------------------------
    # Phase 5 Streaming & Advanced Integrity / Anomaly Events
    # ------------------------------------------------------------------

    def log_validation_stream_row(
        self,
        row_index: int,
        image_path: str,
        cluster_id: Optional[str] = None,
        tags: Optional[list[str]] = None,
        anomaly_score: Optional[float] = None,
        issues: Optional[list[Dict[str, Any]]] = None,
    ) -> None:
        """Log a single streamed validation result row.

        Args:
            row_index: Sequential index of the streamed row (0-based).
            image_path: Path to the image.
            cluster_id: Optional duplicate cluster identifier.
            tags: Optional semantic tags.
            anomaly_score: Optional anomaly score (0-1, higher indicates more anomalous).
            issues: Optional list of issue dicts already detected for this image.
        """
        event = {
            "event_type": "VALIDATION_STREAM_ROW",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.stream",
            "actor": "system",
            "context": {
                "row_index": row_index,
                "image_path": image_path,
                "cluster_id": cluster_id,
                "tags": tags or [],
                "anomaly_score": anomaly_score,
                "issue_count": len(issues) if issues else 0,
                "issues": issues or [],
            },
        }
        self.governance_logger.log_event(event)

    def log_validation_stream_complete(
        self,
        total_rows: int,
        duration_ms: float,
        anomalies_flagged: int,
        first_row_latency_ms: Optional[float] = None,
    ) -> None:
        """Log completion of streaming phase for a validation run."""
        event = {
            "event_type": "VALIDATION_STREAM_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.stream",
            "actor": "system",
            "context": {
                "total_rows": total_rows,
                "duration_ms": duration_ms,
                "rows_per_second": (
                    total_rows / (duration_ms / 1000) if duration_ms > 0 else None
                ),
                "anomalies_flagged": anomalies_flagged,
                "first_row_latency_ms": first_row_latency_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_validation_anomaly_flag(
        self,
        image_path: str,
        score: float,
        threshold: float,
        reason: Optional[str] = None,
        cluster_id: Optional[str] = None,
    ) -> None:
        """Log an anomaly flag event when an image exhibits unusual characteristics."""
        event = {
            "event_type": "VALIDATION_ANOMALY_FLAG",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.anomaly",
            "actor": "system",
            "context": {
                "image_path": image_path,
                "score": score,
                "threshold": threshold,
                "reason": reason,
                "cluster_id": cluster_id,
            },
        }
        self.governance_logger.log_event(event)

    def log_validation_hash_chain_status(
        self,
        verified: bool,
        chain_head_hash: str,
        event_count: int,
        missing_indices: Optional[list[int]] = None,
        duration_ms: Optional[float] = None,
    ) -> None:
        """Log integrity pane hash-chain verification result."""
        event = {
            "event_type": "VALIDATION_HASH_CHAIN_STATUS",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.integrity",
            "actor": "system",
            "context": {
                "verified": verified,
                "chain_head_hash": chain_head_hash,
                "event_count": event_count,
                "missing_indices": missing_indices or [],
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)

    # ------------------------------------------------------------------
    # Provider Policy DSL Events (rule violations, evaluation summary)
    # ------------------------------------------------------------------
    def log_provider_policy_violation(
        self,
        rule_id: str,
        severity: str,
        message: str,
        provider_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log a single provider policy rule violation.

        Args:
            rule_id: Unique rule identifier
            severity: one of INFO|WARN|ERROR
            message: Human readable violation message
            provider_id: Target provider (optional)
            context: Additional structured fields (e.g. size, pattern)
        """
        event = {
            "event_type": "PROVIDER_POLICY_RULE_VIOLATION",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.policy",
            "actor": "system",
            "context": {
                "rule_id": rule_id,
                "severity": severity,
                "message": message,
                "provider_id": provider_id,
                **(context or {}),
            },
        }
        self.governance_logger.log_event(event)

    def log_provider_policy_evaluation_summary(
        self,
        total_rules: int,
        violations: int,
        duration_ms: float,
        provider_filter: Optional[str] = None,
    ) -> None:
        event = {
            "event_type": "PROVIDER_POLICY_EVALUATION_SUMMARY",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.policy",
            "actor": "system",
            "context": {
                "total_rules": total_rules,
                "violations": violations,
                "duration_ms": duration_ms,
                "provider_filter": provider_filter or "all",
            },
        }
        self.governance_logger.log_event(event)

    # ------------------------------------------------------------------
    # RBAC Denial Logging (Cross-cutting governance)
    # ------------------------------------------------------------------
    def log_rbac_denied(
        self,
        capability: str,
        user_role: str,
        command: Optional[str] = None,
        reason: Optional[str] = None,
        user_uuid: Optional[str] = None,
        exit_code: int = 65,
        denial_reason: Optional[str] = None,
    ) -> None:
        """Log RBAC denial event for audit + UX instrumentation + persistent history. Unified schema with STANDARD_COMMAND_DENIED."""
        event = {
            "event_type": "RBAC_DENIED",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "governance.rbac",
            "actor": "system",
            "context": {
                "capability": capability,
                "user_role": user_role,
                "user_uuid": user_uuid or "unknown",
                "command": command,
                "reason": reason,
                "exit_code": exit_code,
                "denial_reason": denial_reason or reason or "capability_missing",
            },
        }
        self.governance_logger.log_event(event)

        # Also log to denial history for persistent tracking
        try:
            from ...core.governance.denial_history import DenialHistoryStore

            history_store = DenialHistoryStore()
            history_store.add_denial(
                capability=capability,
                user_role=user_role,
                user_uuid=user_uuid or "unknown",
                command=command,
                reason=reason,
                correlation_id=self.correlation_id,
            )
        except Exception:
            # Non-critical if history logging fails
            pass

    # ------------------------------------------------------------------
    # Placeholder future events (thumbnail rebuild, canonical set/unset, etc.)
    # Implemented later; stubs ensure forward compatibility in tests.
    # ------------------------------------------------------------------
    def log_thumbnail_rebuild_start(self, provider_id: str) -> None:  # stub
        event = {
            "event_type": "PROVIDER_THUMBNAIL_REBUILD_START",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.thumbnail",
            "actor": "system",
            "context": {"provider_id": provider_id},
        }
        self.governance_logger.log_event(event)

    def log_thumbnail_rebuild_complete(
        self, provider_id: str, rebuilt_count: int, duration_ms: float
    ) -> None:  # stub
        event = {
            "event_type": "PROVIDER_THUMBNAIL_REBUILD_COMPLETE",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.thumbnail",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "rebuilt_count": rebuilt_count,
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)

    def log_thumbnail_rebuild_error(
        self, provider_id: str, error_message: str, duration_ms: float
    ) -> None:  # stub
        event = {
            "event_type": "PROVIDER_THUMBNAIL_REBUILD_ERROR",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.thumbnail.error",
            "actor": "system",
            "context": {
                "provider_id": provider_id,
                "error_message": error_message,
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)

    # Provider report list (Phase 3)
    def log_provider_report_list(
        self,
        provider_id: str,
        report_count: int,
        duration_ms: float,
        actor: str = "system",
    ) -> None:
        event = {
            "event_type": "PROVIDER_REPORT_LIST",
            "correlation_id": self.correlation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "category": "image_validation.provider.report",
            "actor": actor,
            "context": {
                "provider_id": provider_id,
                "report_count": report_count,
                "duration_ms": duration_ms,
            },
        }
        self.governance_logger.log_event(event)
