"""Distributed Embedding/Thumbnail Cache Prototype.

Goal:
    Provide an optional Redis-backed cache layer for expensive feature embeddings
    and generated thumbnails to accelerate duplicate / similarity analysis.

Design:
    - In-memory LRU (always available) for small projects.
    - Optional Redis backend (enabled if REDIS_URL env or config provided).
    - Key namespace: bpy:emb:{sha256(path)} and bpy:thumb:{sha256(path)}
    - Embedding stored as JSON list of floats; thumbnail stored as PNG base64.
    - TTL configurable; default no expiration.
    - Governance events (future) could hook here for cache hit/miss metrics.

Contract:
    get_embedding(path) -> Optional[List[float]]
    set_embedding(path, vector: List[float])
    get_thumbnail(path) -> Optional[str]
    set_thumbnail(path, b64_png: str)

Edge Cases:
    - Redis unavailable: gracefully fallback to local-only.
    - Serialization errors: logged, operation skipped.
    - Large vectors: truncated if exceed max_vector_len (configurable).
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from collections import OrderedDict
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

try:
    import redis  # type: ignore

    _REDIS_AVAILABLE = True
except ImportError:
    redis = None  # type: ignore
    _REDIS_AVAILABLE = False

DEFAULT_MAX_VECTOR = 4096  # safety upper bound


class _LRU:
    def __init__(self, capacity: int = 512):
        self.capacity = capacity
        self._data: OrderedDict[str, Any] = OrderedDict()

    def get(self, k: str) -> Any:
        if k not in self._data:
            return None
        v = self._data.pop(k)
        self._data[k] = v
        return v

    def set(self, k: str, v: Any) -> None:
        if k in self._data:
            self._data.pop(k)
        self._data[k] = v
        if len(self._data) > self.capacity:
            self._data.popitem(last=False)


class EmbeddingCache:
    def __init__(
        self,
        redis_url: Optional[str] = None,
        lru_capacity: int = 512,
        max_vector_len: int = DEFAULT_MAX_VECTOR,
    ):
        self.max_vector_len = max_vector_len
        self.lru = _LRU(lru_capacity)
        if not redis_url:
            redis_url = os.environ.get("REDIS_URL")
        self.redis = None
        if redis_url and _REDIS_AVAILABLE and redis is not None:  # type: ignore
            try:
                client = redis.Redis.from_url(redis_url, socket_timeout=0.5)  # type: ignore[attr-defined]
                client.ping()
                self.redis = client
                logger.info(f"EmbeddingCache: Connected to Redis at {redis_url}")
            except Exception as e:
                logger.warning(
                    f"EmbeddingCache: Redis unavailable ({e}); using local LRU only"
                )
                self.redis = None
        elif redis_url and not _REDIS_AVAILABLE:
            logger.warning(
                "EmbeddingCache: redis-py not installed; set 'pip install redis' to enable distributed cache"
            )

    # Key helpers
    @staticmethod
    def _hash_path(p: str) -> str:
        return hashlib.sha256(p.encode("utf-8")).hexdigest()

    def _emb_key(self, p: str) -> str:
        return f"bpy:emb:{self._hash_path(p)}"

    def _thumb_key(self, p: str) -> str:
        return f"bpy:thumb:{self._hash_path(p)}"

    # Embedding operations
    def get_embedding(
        self, path: str, gov_logger: Optional[Any] = None
    ) -> Optional[List[float]]:
        k = self._emb_key(path)
        # LRU first
        v = self.lru.get(k)
        if v is not None:
            if gov_logger:
                gov_logger.log_cache_hit("lru", k, backend="embedding")
            return v
        if self.redis:
            try:
                raw = self.redis.get(k)
                if raw:
                    vec = json.loads(raw)
                    if isinstance(vec, list):
                        self.lru.set(k, vec)
                        if gov_logger:
                            gov_logger.log_cache_hit("redis", k, backend="embedding")
                        return vec
                    else:
                        if gov_logger:
                            gov_logger.log_cache_miss("redis", k, backend="embedding")
            except Exception as e:
                logger.debug(f"EmbeddingCache: Redis get failed for {k}: {e}")
        if gov_logger:
            gov_logger.log_cache_miss("lru", k, backend="embedding")
        return None

    def set_embedding(self, path: str, vector: List[float]) -> None:
        if not isinstance(vector, list):
            logger.warning("EmbeddingCache: vector must be list of floats")
            return
        if len(vector) > self.max_vector_len:
            logger.debug(
                f"EmbeddingCache: truncating vector {len(vector)} -> {self.max_vector_len}"
            )
            vector = vector[: self.max_vector_len]
        k = self._emb_key(path)
        self.lru.set(k, vector)
        if self.redis:
            try:
                self.redis.set(k, json.dumps(vector))
            except Exception as e:
                logger.debug(f"EmbeddingCache: Redis set failed for {k}: {e}")

    # Thumbnail operations
    def get_thumbnail(
        self, path: str, gov_logger: Optional[Any] = None
    ) -> Optional[str]:
        k = self._thumb_key(path)
        v = self.lru.get(k)
        if v is not None:
            if gov_logger:
                gov_logger.log_cache_hit("lru", k, backend="thumbnail")
            return v
        if self.redis:
            try:
                raw = self.redis.get(k)
                if raw:
                    thumb = raw.decode("utf-8")
                    self.lru.set(k, thumb)
                    if gov_logger:
                        gov_logger.log_cache_hit("redis", k, backend="thumbnail")
                    return thumb
                else:
                    if gov_logger:
                        gov_logger.log_cache_miss("redis", k, backend="thumbnail")
            except Exception as e:
                logger.debug(f"EmbeddingCache: Redis get thumbnail failed: {e}")
        if gov_logger:
            gov_logger.log_cache_miss("lru", k, backend="thumbnail")
        return None

    def set_thumbnail(self, path: str, b64_png: str) -> None:
        if not isinstance(b64_png, str):
            logger.warning("EmbeddingCache: thumbnail must be base64 string")
            return
        k = self._thumb_key(path)
        self.lru.set(k, b64_png)
        if self.redis:
            try:
                self.redis.set(k, b64_png)
            except Exception as e:
                logger.debug(f"EmbeddingCache: Redis set thumbnail failed: {e}")


__all__ = ["EmbeddingCache"]
