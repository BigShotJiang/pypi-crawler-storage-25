"""Provider Policy DSL - Rule evaluation framework.

This module introduces a lightweight policy system allowing declaration of
rules that validate provider or asset metadata. Violations are logged via
`ImageValidationLogger` governance events.

Rule Schema (YAML/JSON expected externally):
[
  {
    "id": "img.size.max",
    "kind": "image_size",
    "max_width": 1920,
    "max_height": 1080,
    "severity": "WARN"
  },
  {
    "id": "img.name.pattern",
    "kind": "name_pattern",
    "pattern": "^[a-z0-9_\\-]+$",
    "severity": "ERROR"
  }
]

Kinds:
- image_size: checks width/height bounds
- name_pattern: filename regex
- tag_required: ensures tag presence in metadata tags list

Evaluation Contract:
Inputs:
  - provider_id: str
  - assets: Iterable[dict] with at least {"path": str, "width": int, "height": int, "tags": list[str]}
  - rules: list[dict]
Outputs:
  - violations: list[PolicyViolation]
  - governance events emitted for each violation + summary

Edge Cases Covered:
  - Missing fields gracefully skipped (treated as non-violations with INFO severity option)
  - Regex compilation failure downgrades to ERROR violation for rule itself
  - Zero assets => summary still emitted
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class PolicyViolation:
    rule_id: str
    severity: str  # INFO | WARN | ERROR
    message: str
    provider_id: Optional[str]
    asset_path: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


class ProviderPolicyEngine:
    def __init__(self, logger):
        """Initialize with an ImageValidationLogger instance (or stub).
        The logger must provide log_provider_policy_violation and
        log_provider_policy_evaluation_summary methods.
        """
        self.logger = logger

    def evaluate(
        self,
        provider_id: str,
        assets: Iterable[Dict[str, Any]],
        rules: List[Dict[str, Any]],
    ) -> List[PolicyViolation]:
        start = time.perf_counter()
        violations: List[PolicyViolation] = []
        asset_list = list(assets)

        for rule in rules:
            rid = rule.get("id") or "(unknown)"
            severity = rule.get("severity", "WARN").upper()
            kind = rule.get("kind")
            if kind == "image_size":
                max_w = rule.get("max_width")
                max_h = rule.get("max_height")
                for a in asset_list:
                    w = a.get("width")
                    h = a.get("height")
                    if w is None or h is None or max_w is None or max_h is None:
                        continue
                    if w > max_w or h > max_h:
                        msg = f"Image exceeds size bounds ({w}x{h} > {max_w}x{max_h})"
                        v = PolicyViolation(
                            rid,
                            severity,
                            msg,
                            provider_id,
                            a.get("path"),
                            {"width": w, "height": h},
                        )
                        violations.append(v)
                        self.logger.log_provider_policy_violation(
                            rid, severity, msg, provider_id, v.context
                        )
            elif kind == "name_pattern":
                pattern = rule.get("pattern")
                try:
                    rx = re.compile(pattern) if pattern else None
                except re.error as e:
                    msg = f"Invalid regex pattern for rule {rid}: {e}"
                    v = PolicyViolation(
                        rid, "ERROR", msg, provider_id, None, {"pattern": pattern}
                    )
                    violations.append(v)
                    self.logger.log_provider_policy_violation(
                        rid, "ERROR", msg, provider_id, v.context
                    )
                    continue
                for a in asset_list:
                    p = a.get("path")
                    if not p or not rx:
                        continue
                    name = p.split("/")[-1]
                    if not rx.match(name):
                        msg = f"Filename '{name}' does not match pattern {pattern}"
                        v = PolicyViolation(
                            rid,
                            severity,
                            msg,
                            provider_id,
                            p,
                            {"filename": name, "pattern": pattern},
                        )
                        violations.append(v)
                        self.logger.log_provider_policy_violation(
                            rid, severity, msg, provider_id, v.context
                        )
            elif kind == "tag_required":
                tag = rule.get("tag")
                for a in asset_list:
                    tags = a.get("tags") or []
                    if tag and tag not in tags:
                        msg = f"Required tag '{tag}' missing"
                        v = PolicyViolation(
                            rid,
                            severity,
                            msg,
                            provider_id,
                            a.get("path"),
                            {"missing_tag": tag},
                        )
                        violations.append(v)
                        self.logger.log_provider_policy_violation(
                            rid, severity, msg, provider_id, v.context
                        )
            else:
                msg = f"Unknown rule kind '{kind}'"
                v = PolicyViolation(
                    rid, "ERROR", msg, provider_id, None, {"kind": kind}
                )
                violations.append(v)
                self.logger.log_provider_policy_violation(
                    rid, "ERROR", msg, provider_id, v.context
                )

        duration_ms = (time.perf_counter() - start) * 1000.0
        self.logger.log_provider_policy_evaluation_summary(
            len(rules), len(violations), duration_ms, provider_id
        )
        return violations


__all__ = ["ProviderPolicyEngine", "PolicyViolation"]
