"""
Image Preprocessing Pipeline
Handles EXIF orientation, ICC color profile normalization, and deterministic resizing
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Tuple

if TYPE_CHECKING:
    import numpy as np
    from numpy import ndarray
    from PIL.Image import Image as PILImage
else:
    ndarray = Any
    PILImage = Any

try:
    import numpy as np
    from PIL import Image, ImageCms
    from PIL.Image import Transpose

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    Transpose = None  # type: ignore
    np = None  # type: ignore
    Image = None  # type: ignore
    ImageCms = None  # type: ignore

from .config import IV_CONFIG

logger = logging.getLogger(__name__)


# EXIF orientation tag mapping
# Reference: https://exif.org/Exif2-2.PDF Section 4.6.5 Tag 0x0112
EXIF_ORIENTATION_TAG = 0x0112


# Transpose enum values (available when PIL is installed)
def _get_transpose_transforms():
    """Get orientation transforms using Transpose enum"""
    if not PIL_AVAILABLE or Transpose is None:
        return {}

    return {
        1: None,  # Normal
        2: Transpose.FLIP_LEFT_RIGHT,  # Mirrored
        3: Transpose.ROTATE_180,  # Rotated 180°
        4: Transpose.FLIP_TOP_BOTTOM,  # Mirrored and rotated 180°
        5: Transpose.TRANSPOSE,  # Mirrored and rotated 90° CCW
        6: Transpose.ROTATE_270,  # Rotated 90° CW
        7: Transpose.TRANSVERSE,  # Mirrored and rotated 90° CW
        8: Transpose.ROTATE_90,  # Rotated 90° CCW
    }


ORIENTATION_TRANSFORMS = _get_transpose_transforms()


def load_and_normalize_image(
    image_path: Path,
    target_size: Optional[Tuple[int, int]] = None,
    grayscale: bool = False,
    fix_orientation: bool = True,
    normalize_color: bool = True,
) -> PILImage:
    """
    Load image with full normalization pipeline

    Pipeline steps:
    1. Load image from disk
    2. Apply EXIF orientation correction (if enabled)
    3. Convert ICC color profile to sRGB (if enabled)
    4. Convert to grayscale (if requested)
    5. Resize to target size (if specified)

    Args:
        image_path: Path to image file
        target_size: Optional (width, height) for resizing
        grayscale: Convert to grayscale (L mode)
        fix_orientation: Auto-rotate per EXIF orientation tag
        normalize_color: Convert ICC profiles to sRGB

    Returns:
        Normalized PIL Image object

    Raises:
        FileNotFoundError: If image file doesn't exist
        PIL.UnidentifiedImageError: If file is not a valid image
    """
    if not PIL_AVAILABLE:
        raise ImportError("Image preprocessing requires: pip install Pillow")

    if not image_path.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    # Step 1: Load image
    img = Image.open(image_path)  # type: ignore

    # Step 2: Apply EXIF orientation correction
    if fix_orientation and IV_CONFIG.EXIF_ORIENTATION_AUTO_FIX:
        img = apply_exif_orientation(img)

    # Step 3: Normalize color profile to sRGB
    if normalize_color:
        img = normalize_color_profile(img)

    # Step 4: Convert to grayscale (before resize for efficiency)
    if grayscale:
        img = img.convert("L")

    # Step 5: Resize if target size specified
    if target_size is not None:
        img = resize_deterministic(img, target_size)

    return img  # type: ignore


def apply_exif_orientation(img: PILImage) -> PILImage:
    """
    Auto-rotate image based on EXIF orientation tag

    Many cameras and phones store images in one orientation but tag them
    with EXIF metadata for correct display. This function applies the
    transformation to match the intended orientation.

    Args:
        img: PIL Image object

    Returns:
        Oriented image (may be rotated/flipped)
    """
    try:
        # Get EXIF data
        exif = img.getexif()
        if exif is None:
            return img

        # Get orientation tag (274 = 0x0112)
        orientation = exif.get(EXIF_ORIENTATION_TAG)
        if orientation is None or orientation == 1:
            return img  # Normal orientation, no transform needed

        # Apply transform
        transform = ORIENTATION_TRANSFORMS.get(orientation)
        if transform is not None:
            logger.debug(f"Applying EXIF orientation {orientation}: {transform}")
            img = img.transpose(transform)  # type: ignore[arg-type]

        # Clear orientation tag after applying (image is now in correct orientation)
        if hasattr(img, "_getexif"):
            # Remove orientation from EXIF data
            exif_dict = img.getexif()
            if EXIF_ORIENTATION_TAG in exif_dict:
                del exif_dict[EXIF_ORIENTATION_TAG]

        return img

    except Exception as e:
        logger.warning(f"Failed to apply EXIF orientation: {e}")
        return img  # Return original on error


def normalize_color_profile(img: PILImage) -> PILImage:
    """
    Convert embedded ICC color profile to sRGB

    Different cameras/monitors use different color profiles (Adobe RGB, ProPhoto, etc).
    This normalizes all images to sRGB for consistent perceptual hashing.

    Args:
        img: PIL Image object

    Returns:
        Image with sRGB color profile
    """
    try:
        # Check if image has embedded ICC profile
        if "icc_profile" not in img.info:
            # No embedded profile - assume sRGB
            return img

        # Get embedded profile
        embedded_profile = img.info.get("icc_profile")
        if not embedded_profile:
            return img

        # Fix import for BytesIO
        import io

        # Create ImageCms profile objects
        input_profile = ImageCms.ImageCmsProfile(io.BytesIO(embedded_profile))  # type: ignore
        output_profile = ImageCms.createProfile("sRGB")  # type: ignore

        # Convert image to sRGB
        img_srgb = ImageCms.profileToProfile(  # type: ignore
            img,
            input_profile,
            output_profile,
            renderingIntent=ImageCms.Intent.PERCEPTUAL,  # type: ignore # Perceptual intent for photos
            outputMode="RGB",
        )

        logger.debug("Converted ICC profile to sRGB")
        return img_srgb  # type: ignore

    except Exception as e:
        logger.warning(f"Failed to normalize color profile: {e}")
        return img  # Return original on error


def resize_deterministic(img: PILImage, target_size: Tuple[int, int]) -> PILImage:
    """
    Resize image with deterministic high-quality resampling

    Uses LANCZOS filter for high-quality downsampling with minimal artifacts.
    Maintains aspect ratio by fitting within target_size box.

    Args:
        img: PIL Image object
        target_size: (width, height) target dimensions

    Returns:
        Resized image
    """
    # Use LANCZOS (Lanczos3) filter for high-quality downsampling
    # This is deterministic and produces sharp results
    resample_filter = Image.Resampling.LANCZOS  # type: ignore

    # PIL's thumbnail() method maintains aspect ratio
    img_copy = img.copy()
    img_copy.thumbnail(target_size, resample_filter)

    return img_copy  # type: ignore


def preprocess_for_phash(image_path: Path, hash_size: int = 8) -> ndarray:
    """
    Preprocess image for perceptual hashing (pHash)

    Pipeline:
    1. Load and normalize (EXIF + ICC)
    2. Convert to 8-bit grayscale (L mode)
    3. Resize to (hash_size+1) x (hash_size+1) using LANCZOS

    Args:
        image_path: Path to image file
        hash_size: Hash grid size (default 8 for 8x8 = 64-bit hash)

    Returns:
        Preprocessed image as float32 numpy array
    """
    target_size = (hash_size + 1, hash_size + 1)

    # Load with full normalization
    img = load_and_normalize_image(
        image_path,
        target_size=target_size,
        grayscale=True,
        fix_orientation=True,
        normalize_color=True,
    )

    # Convert to numpy array (uint8 -> float32)
    arr = np.asarray(img, dtype=np.float32)  # type: ignore

    return arr  # type: ignore


def preprocess_for_clip(image_path: Path) -> PILImage:
    """
    Preprocess image for CLIP embedding extraction

    Pipeline:
    1. Load and normalize (EXIF + ICC)
    2. Keep in RGB mode
    3. No resize (CLIP model handles this internally)

    Args:
        image_path: Path to image file

    Returns:
        Normalized PIL Image in RGB mode
    """
    # Load with orientation and color normalization
    img = load_and_normalize_image(
        image_path,
        target_size=None,  # CLIP model resizes internally
        grayscale=False,  # Keep RGB
        fix_orientation=True,
        normalize_color=True,
    )

    # Ensure RGB mode (CLIP expects RGB)
    if img.mode != "RGB":
        img = img.convert("RGB")

    return img


__all__ = [
    "load_and_normalize_image",
    "apply_exif_orientation",
    "normalize_color_profile",
    "resize_deterministic",
    "preprocess_for_phash",
    "preprocess_for_clip",
]
