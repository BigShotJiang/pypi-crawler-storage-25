"""
Clustering algorithm for grouping similar images
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Set

from .models import ImageCluster, ImageFile


class ImageClusterer:
    """Group similar images into clusters"""

    def __init__(self, similarity_threshold: float = 0.85):
        """
        Initialize clusterer

        Args:
            similarity_threshold: Minimum similarity (0-1) to group images
        """
        self.similarity_threshold = similarity_threshold

    def cluster_by_phash(
        self, images: List[ImageFile], hamming_distance_threshold: int = 10
    ) -> List[ImageCluster]:
        """
        Cluster images by perceptual hash similarity

        Uses simple threshold-based clustering:
        - Images with Hamming distance <= threshold are grouped
        - Forms clusters by transitivity

        Args:
            images: List of images with pHash computed
            hamming_distance_threshold: Max Hamming distance for grouping (default 10/64 bits)

        Returns:
            List of ImageCluster objects
        """
        # Filter images that have pHash
        hashed_images = [img for img in images if img.hash_phash]

        if not hashed_images:
            return []

        # Build adjacency list of similar images
        similar_pairs: Dict[str, Set[str]] = defaultdict(set)

        for i, img1 in enumerate(hashed_images):
            for img2 in hashed_images[i + 1 :]:
                distance = self._hamming_distance(img1.hash_phash, img2.hash_phash)
                if distance <= hamming_distance_threshold:
                    similar_pairs[img1.path].add(img2.path)
                    similar_pairs[img2.path].add(img1.path)

        # Find connected components (clusters)
        visited: Set[str] = set()
        clusters: List[List[str]] = []

        for img in hashed_images:
            if img.path not in visited:
                cluster = self._dfs_cluster(img.path, similar_pairs, visited)
                if len(cluster) > 1:  # Only include multi-image clusters
                    clusters.append(cluster)

        # Convert to ImageCluster objects
        result = []
        for idx, cluster_members in enumerate(clusters):
            group_id = f"G{idx+1:04d}"

            # Select canonical (largest file as heuristic)
            canonical = self._select_canonical(cluster_members, hashed_images)

            # Compute average similarity
            avg_sim = self._compute_avg_similarity(cluster_members, hashed_images)

            result.append(
                ImageCluster(
                    group_id=group_id,
                    members=cluster_members,
                    canonical=canonical,
                    avg_similarity=avg_sim,
                )
            )

        return result

    def cluster_by_md5(self, images: List[ImageFile]) -> List[ImageCluster]:
        """
        Find exact duplicates using MD5 hash

        Args:
            images: List of images with MD5 hash computed

        Returns:
            List of ImageCluster objects for exact duplicates
        """
        # Group by MD5 hash
        md5_groups: Dict[str, List[str]] = defaultdict(list)

        for img in images:
            if img.hash_md5:
                md5_groups[img.hash_md5].append(img.path)

        # Convert to clusters (only duplicates, not singles)
        clusters = []
        cluster_idx = 1

        for md5, paths in md5_groups.items():
            if len(paths) > 1:
                group_id = f"D{cluster_idx:04d}"  # D for Duplicate
                clusters.append(
                    ImageCluster(
                        group_id=group_id,
                        members=paths,
                        canonical=paths[0],  # First one as canonical
                        avg_similarity=1.0,  # Exact duplicates
                    )
                )
                cluster_idx += 1

        return clusters

    def _dfs_cluster(
        self, start: str, adjacency: Dict[str, Set[str]], visited: Set[str]
    ) -> List[str]:
        """
        Depth-first search to find connected component

        Args:
            start: Starting node (image path)
            adjacency: Adjacency list of similar images
            visited: Set of already visited nodes

        Returns:
            List of image paths in the cluster
        """
        cluster = []
        stack = [start]

        while stack:
            node = stack.pop()
            if node in visited:
                continue

            visited.add(node)
            cluster.append(node)

            # Add neighbors to stack
            for neighbor in adjacency.get(node, set()):
                if neighbor not in visited:
                    stack.append(neighbor)

        return cluster

    def _hamming_distance(self, hash1: str | None, hash2: str | None) -> int:
        """Compute Hamming distance between two hex hashes"""
        if not hash1 or not hash2 or len(hash1) != len(hash2):
            return 64

        bin1 = bin(int(hash1, 16))[2:].zfill(len(hash1) * 4)
        bin2 = bin(int(hash2, 16))[2:].zfill(len(hash2) * 4)

        return sum(c1 != c2 for c1, c2 in zip(bin1, bin2))

    def _select_canonical(
        self, cluster_members: List[str], all_images: List[ImageFile]
    ) -> str:
        """
        Select canonical version from cluster

        Heuristic: Choose largest file (assumed to be highest quality)

        Args:
            cluster_members: List of image paths in cluster
            all_images: Full list of ImageFile objects

        Returns:
            Path to canonical image
        """
        # Build lookup
        image_lookup = {img.path: img for img in all_images}

        # Find largest file in cluster
        largest = max(
            cluster_members,
            key=lambda path: image_lookup.get(
                path, ImageFile("", Path(""), 0, 0, 0, "")
            ).size_bytes,
        )

        return largest

    def _compute_avg_similarity(
        self, cluster_members: List[str], all_images: List[ImageFile]
    ) -> float:
        """
        Compute average pairwise similarity in cluster

        Args:
            cluster_members: List of image paths
            all_images: Full list of ImageFile objects

        Returns:
            Average similarity score (0-1)
        """
        if len(cluster_members) < 2:
            return 1.0

        # Build lookup
        image_lookup = {img.path: img for img in all_images}

        # Compute pairwise distances
        total_similarity = 0.0
        pair_count = 0

        for i, path1 in enumerate(cluster_members):
            for path2 in cluster_members[i + 1 :]:
                img1 = image_lookup.get(path1)
                img2 = image_lookup.get(path2)

                if img1 and img2 and img1.hash_phash and img2.hash_phash:
                    distance = self._hamming_distance(img1.hash_phash, img2.hash_phash)
                    similarity = 1.0 - (distance / 64.0)
                    total_similarity += similarity
                    pair_count += 1

        return total_similarity / pair_count if pair_count > 0 else 0.0
