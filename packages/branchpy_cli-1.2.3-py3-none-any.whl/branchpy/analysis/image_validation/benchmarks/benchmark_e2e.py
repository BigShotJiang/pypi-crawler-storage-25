"""
Benchmark: End-to-End Validation Pipeline
Test complete workflow from scan to report generation
"""

import shutil
import sys
import tempfile
import time
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

from branchpy.analysis.image_validation.benchmarks import create_test_images
from branchpy.analysis.image_validation.validator import ImageValidator


def benchmark_e2e_pipeline():
    """Benchmark end-to-end validation pipeline"""
    temp_dir = tempfile.mkdtemp()
    try:
        # Create test project
        project_dir = Path(temp_dir) / "project"
        images_dir = project_dir / "images"
        create_test_images(images_dir, count=200, size=(512, 512))

        print("Created test project with 200 images")
        print(f"Project: {project_dir}")

        # Benchmark: pHash backend (cold cache)
        print("\n" + "=" * 80)
        print("Benchmark: pHash Backend (Cold Cache)")
        print("=" * 80)

        validator_phash = ImageValidator(
            project_dir=project_dir,
            backend="phash",
            fast_mode=False,
            use_cache=True,
            engine="generic",
            images_dir=images_dir,
        )

        start = time.perf_counter()
        report_phash_cold = validator_phash.validate()
        time_phash_cold = (time.perf_counter() - start) * 1000
        validator_phash.close()

        print("\nResults:")
        print(f"  Total images:     {report_phash_cold.total_images}")
        print(f"  Total time:       {time_phash_cold:.1f} ms")
        print(
            f"  Throughput:       {report_phash_cold.total_images / (time_phash_cold / 1000):.1f} images/sec"
        )

        # Benchmark: pHash backend (warm cache)
        print("\n" + "=" * 80)
        print("Benchmark: pHash Backend (Warm Cache)")
        print("=" * 80)

        validator_phash2 = ImageValidator(
            project_dir=project_dir,
            backend="phash",
            fast_mode=False,
            use_cache=True,
            engine="generic",
            images_dir=images_dir,
        )

        start = time.perf_counter()
        report_phash_warm = validator_phash2.validate()
        time_phash_warm = (time.perf_counter() - start) * 1000
        validator_phash2.close()

        print("\nResults:")
        print(f"  Total images:     {report_phash_warm.total_images}")
        print(f"  Total time:       {time_phash_warm:.1f} ms")
        print(
            f"  Throughput:       {report_phash_warm.total_images / (time_phash_warm / 1000):.1f} images/sec"
        )
        print(f"  Cache speedup:    {time_phash_cold / time_phash_warm:.1f}x")

        # Benchmark: pHash fast mode
        print("\n" + "=" * 80)
        print("Benchmark: pHash Fast Mode (4×4 hash)")
        print("=" * 80)

        validator_fast = ImageValidator(
            project_dir=project_dir,
            backend="phash",
            fast_mode=True,
            use_cache=False,  # Disable to measure pure speed
            engine="generic",
            images_dir=images_dir,
        )

        start = time.perf_counter()
        report_fast = validator_fast.validate()
        time_fast = (time.perf_counter() - start) * 1000
        validator_fast.close()

        print("\nResults:")
        print(f"  Total images:     {report_fast.total_images}")
        print(f"  Total time:       {time_fast:.1f} ms")
        print(
            f"  Throughput:       {report_fast.total_images / (time_fast / 1000):.1f} images/sec"
        )

        # Summary
        print("\n" + "=" * 80)
        print("SUMMARY: End-to-End Pipeline Performance")
        print("=" * 80)
        print(
            f"pHash (cold cache):  {report_phash_cold.total_images / (time_phash_cold / 1000):.1f} images/sec"
        )
        print(
            f"pHash (warm cache):  {report_phash_warm.total_images / (time_phash_warm / 1000):.1f} images/sec"
        )
        print(
            f"pHash Fast Mode:     {report_fast.total_images / (time_fast / 1000):.1f} images/sec"
        )
        print("=" * 80)

    finally:
        shutil.rmtree(temp_dir)


if __name__ == "__main__":
    benchmark_e2e_pipeline()
