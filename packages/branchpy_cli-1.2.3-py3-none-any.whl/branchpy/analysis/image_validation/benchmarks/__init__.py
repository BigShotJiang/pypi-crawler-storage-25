"""
Benchmark Suite for Image Validation V3
Performance testing for backends, cache, and end-to-end pipelines
"""

import shutil
import statistics
import tempfile
import time
from pathlib import Path

from PIL import Image

try:
    import numpy as np

    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    print("Warning: NumPy not available, some benchmarks will be skipped")


class BenchmarkRunner:
    """Base class for running benchmarks"""

    def __init__(self, name: str):
        self.name = name
        self.results = []

    def run(self, func, iterations: int = 10):
        """Run benchmark function multiple times and collect stats"""
        times = []
        for i in range(iterations):
            start = time.perf_counter()
            func()
            elapsed = (time.perf_counter() - start) * 1000  # milliseconds
            times.append(elapsed)

        self.results.append(
            {
                "name": self.name,
                "iterations": iterations,
                "min_ms": min(times),
                "max_ms": max(times),
                "mean_ms": statistics.mean(times),
                "median_ms": statistics.median(times),
                "stdev_ms": statistics.stdev(times) if len(times) > 1 else 0,
            }
        )

        return self.results[-1]

    def print_results(self):
        """Print benchmark results in table format"""
        print(f"\n{'='*80}")
        print(f"Benchmark: {self.name}")
        print(f"{'='*80}")

        for result in self.results:
            print(f"Iterations:  {result['iterations']}")
            print(f"Mean:        {result['mean_ms']:.2f} ms")
            print(f"Median:      {result['median_ms']:.2f} ms")
            print(f"Min:         {result['min_ms']:.2f} ms")
            print(f"Max:         {result['max_ms']:.2f} ms")
            print(f"Stdev:       {result['stdev_ms']:.2f} ms")

            # Calculate throughput if applicable
            if "throughput" in result:
                print(f"Throughput:  {result['throughput']:.2f} images/sec")

        print(f"{'='*80}\n")


def create_test_image(path: Path, size=(256, 256), color=(128, 128, 128)):
    """Create a test image with solid color"""
    img = Image.new("RGB", size, color)
    img.save(path)


def create_test_images(directory: Path, count: int, size=(256, 256)):
    """Create multiple test images with random colors"""
    import random

    directory.mkdir(parents=True, exist_ok=True)

    for i in range(count):
        color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        create_test_image(directory / f"test_{i:04d}.png", size, color)


if __name__ == "__main__":
    print("Image Validation V3 - Benchmark Suite")
    print("=" * 80)
    print("This suite benchmarks:")
    print("  1. pHash backend (CPU)")
    print("  2. CLIP backend (GPU/CPU)")
    print("  3. LMDB cache latency")
    print("  4. End-to-end validation pipeline")
    print("=" * 80)
