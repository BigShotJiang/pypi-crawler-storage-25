"""
Benchmark: LMDB Cache Performance
Test cache read/write latency and throughput
"""

import shutil
import sys
import tempfile
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

try:
    import numpy as np

    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    print("Error: NumPy not available")
    sys.exit(1)

from branchpy.analysis.image_validation.benchmarks import (
    BenchmarkRunner,
    create_test_images,
)
from branchpy.analysis.image_validation.cache.feature_store import FeatureStore


def benchmark_cache_latency():
    """Benchmark LMDB cache read/write latency"""
    temp_dir = tempfile.mkdtemp()
    try:
        # Create test data
        cache_dir = Path(temp_dir) / "cache"
        images_dir = Path(temp_dir) / "images"
        create_test_images(images_dir, count=100, size=(256, 256))
        image_paths = list(images_dir.glob("*.png"))

        # Initialize cache
        cache = FeatureStore(cache_dir)

        # Create embeddings for testing
        embeddings = {
            path: np.random.rand(512).astype(np.float32) for path in image_paths
        }

        # Benchmark: Cache WRITE performance
        print("\nBenchmarking cache WRITE operations...")
        runner_write = BenchmarkRunner("LMDB Cache Write")

        def write_all():
            for path, embedding in embeddings.items():
                cache.set_embedding(path, "clip", embedding)

        result_write = runner_write.run(write_all, iterations=5)
        result_write["throughput"] = 100 / (result_write["mean_ms"] / 1000)
        result_write["latency_per_write"] = result_write["mean_ms"] / 100
        runner_write.print_results()

        # Benchmark: Cache READ performance (warm cache)
        print("Benchmarking cache READ operations (warm cache)...")
        runner_read = BenchmarkRunner("LMDB Cache Read")

        def read_all():
            for path in image_paths:
                cache.get_embedding(path, "clip", validate_cache=False)

        result_read = runner_read.run(read_all, iterations=10)
        result_read["throughput"] = 100 / (result_read["mean_ms"] / 1000)
        result_read["latency_per_read"] = result_read["mean_ms"] / 100
        runner_read.print_results()

        # Benchmark: Cache READ with validation
        print("Benchmarking cache READ with mtime validation...")
        runner_validate = BenchmarkRunner("LMDB Cache Read + Validate")

        def read_all_validate():
            for path in image_paths:
                cache.get_embedding(path, "clip", validate_cache=True)

        result_validate = runner_validate.run(read_all_validate, iterations=10)
        result_validate["throughput"] = 100 / (result_validate["mean_ms"] / 1000)
        result_validate["latency_per_read"] = result_validate["mean_ms"] / 100
        runner_validate.print_results()

        # Benchmark: Cache status query
        print("Benchmarking cache status() operation...")
        runner_status = BenchmarkRunner("LMDB Cache Status")

        def get_status():
            cache.status()

        result_status = runner_status.run(get_status, iterations=100)
        runner_status.print_results()

        # Summary
        print("\n" + "=" * 80)
        print("SUMMARY: LMDB Cache Performance")
        print("=" * 80)
        print(f"Write latency:       {result_write['latency_per_write']:.2f} ms/entry")
        print(f"Read latency:        {result_read['latency_per_read']:.2f} ms/entry")
        print(
            f"Read + validate:     {result_validate['latency_per_read']:.2f} ms/entry"
        )
        print(f"Status query:        {result_status['mean_ms']:.2f} ms")
        print(f"\nWrite throughput:    {result_write['throughput']:.0f} entries/sec")
        print(f"Read throughput:     {result_read['throughput']:.0f} entries/sec")
        print("=" * 80)

        # Verify targets
        print("\nTarget Verification:")
        if result_read["latency_per_read"] < 1.0:
            print("✅ Read latency <1ms (PASS)")
        else:
            print(
                f"❌ Read latency {result_read['latency_per_read']:.2f}ms (target: <1ms)"
            )

        if result_write["latency_per_write"] < 5.0:
            print("✅ Write latency <5ms (PASS)")
        else:
            print(
                f"❌ Write latency {result_write['latency_per_write']:.2f}ms (target: <5ms)"
            )

        cache.close()

    finally:
        shutil.rmtree(temp_dir)


if __name__ == "__main__":
    benchmark_cache_latency()
