"""
Benchmark: CLIP Backend Performance
Test OpenAI CLIP (ViT-B/32) embedding extraction speed on GPU/CPU
"""

import shutil
import sys
import tempfile
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

try:
    from branchpy.analysis.image_validation.backends.clip_backend import CLIPBackend

    CLIP_AVAILABLE = True
except ImportError:
    CLIP_AVAILABLE = False
    print("Error: CLIP backend not available")
    print("Install with: pip install torch torchvision")
    print("             pip install git+https://github.com/openai/CLIP.git")
    sys.exit(1)

from branchpy.analysis.image_validation.benchmarks import (
    BenchmarkRunner,
    create_test_images,
)


def benchmark_clip_extraction():
    """Benchmark CLIP feature extraction speed"""
    temp_dir = tempfile.mkdtemp()
    try:
        # Create test images
        print("Creating 50 test images...")
        images_dir = Path(temp_dir) / "images"
        create_test_images(images_dir, count=50, size=(512, 512))

        image_paths = list(images_dir.glob("*.png"))

        # Benchmark CLIP on available device
        backend = CLIPBackend(model_name="ViT-B/32")
        print(f"\nBenchmarking CLIP on {backend.device}...")
        print(f"Model: {backend.model_name}")
        print(f"Feature dimension: {backend.feature_dim}")

        runner = BenchmarkRunner(f"CLIP ViT-B/32 ({backend.device})")

        def extract_all():
            for path in image_paths:
                backend.extract_features(path)

        result = runner.run(extract_all, iterations=3)
        result["throughput"] = 50 / (result["mean_ms"] / 1000)
        runner.print_results()

        # Benchmark batch extraction (if GPU available)
        if backend.supports_gpu:
            print("Benchmarking CLIP batch extraction (32 images/batch)...")
            runner_batch = BenchmarkRunner("CLIP Batch Mode")

            def extract_batch():
                backend.batch_extract(image_paths[:32])

            result_batch = runner_batch.run(extract_batch, iterations=3)
            result_batch["throughput"] = 32 / (result_batch["mean_ms"] / 1000)
            runner_batch.print_results()

            print("\n" + "=" * 80)
            print("SUMMARY: CLIP Performance")
            print("=" * 80)
            print(f"Single extraction:   {result['throughput']:.1f} images/sec")
            print(f"Batch extraction:    {result_batch['throughput']:.1f} images/sec")
            print(
                f"Batch speedup:       {result_batch['throughput'] / result['throughput']:.1f}x"
            )
            print("=" * 80)
        else:
            print("\n" + "=" * 80)
            print("SUMMARY: CLIP Performance")
            print("=" * 80)
            print(f"Single extraction:   {result['throughput']:.1f} images/sec")
            print(f"Device:              {backend.device}")
            print("=" * 80)

    finally:
        shutil.rmtree(temp_dir)


if __name__ == "__main__":
    benchmark_clip_extraction()
