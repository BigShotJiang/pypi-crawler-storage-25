"""
Benchmark: pHash Backend Performance
Test DCT-based perceptual hashing speed
"""

import shutil
import sys
import tempfile
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

from branchpy.analysis.image_validation.backends.phash_backend import PHashBackend
from branchpy.analysis.image_validation.benchmarks import (
    BenchmarkRunner,
    create_test_images,
)


def benchmark_phash_extraction():
    """Benchmark pHash feature extraction speed"""
    temp_dir = tempfile.mkdtemp()
    try:
        # Create test images
        print("Creating 100 test images...")
        images_dir = Path(temp_dir) / "images"
        create_test_images(images_dir, count=100, size=(512, 512))

        image_paths = list(images_dir.glob("*.png"))

        # Benchmark standard mode (8×8 hash)
        print("\nBenchmarking pHash (8×8 hash, 64-dim)...")
        backend = PHashBackend(hash_size=8, fast_mode=False)
        runner = BenchmarkRunner("pHash Standard Mode")

        def extract_all():
            for path in image_paths:
                backend.extract_features(path)

        result = runner.run(extract_all, iterations=5)
        result["throughput"] = 100 / (result["mean_ms"] / 1000)
        runner.print_results()

        # Benchmark fast mode (4×4 hash)
        print("Benchmarking pHash (4×4 hash, 16-dim)...")
        backend_fast = PHashBackend(hash_size=4, fast_mode=True)
        runner_fast = BenchmarkRunner("pHash Fast Mode")

        def extract_all_fast():
            for path in image_paths:
                backend_fast.extract_features(path)

        result_fast = runner_fast.run(extract_all_fast, iterations=5)
        result_fast["throughput"] = 100 / (result_fast["mean_ms"] / 1000)
        runner_fast.print_results()

        # Summary
        print("\n" + "=" * 80)
        print("SUMMARY: pHash Performance")
        print("=" * 80)
        print(f"Standard Mode (8×8):  {result['throughput']:.1f} images/sec")
        print(f"Fast Mode (4×4):      {result_fast['throughput']:.1f} images/sec")
        print(
            f"Speedup:              {result_fast['throughput'] / result['throughput']:.1f}x"
        )
        print("=" * 80)

    finally:
        shutil.rmtree(temp_dir)


if __name__ == "__main__":
    benchmark_phash_extraction()
