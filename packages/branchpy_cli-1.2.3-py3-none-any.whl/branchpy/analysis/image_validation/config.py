"""
Image Validation Configuration
Centralized thresholds and constants
"""

from dataclasses import dataclass


@dataclass
class IVConfig:
    """
    Centralized configuration for Image Validation thresholds

    All similarity thresholds and distance metrics should reference this.
    Replaces scattered magic numbers across similarity.py, clusterer.py, etc.
    """

    # Similarity thresholds (0-1 scale, 1.0 = identical)
    PHASH_SIMILARITY_THRESHOLD: float = 0.85  # Hamming similarity for pHash clustering
    AHASH_SIMILARITY_THRESHOLD: float = (
        0.80  # Hamming similarity for aHash (less strict)
    )
    DHASH_SIMILARITY_THRESHOLD: float = (
        0.90  # Hamming similarity for dHash (directional, more strict)
    )
    CLIP_SIMILARITY_THRESHOLD: float = 0.92  # Cosine similarity for CLIP embeddings

    # Distance thresholds (inverse: lower = more similar)
    HAMMING_DISTANCE_MAX: int = 10  # Maximum Hamming distance for pHash clusters
    COSINE_DISTANCE_THRESHOLD: float = 0.08  # 1 - CLIP_SIMILARITY_THRESHOLD

    # Hash parameters
    PHASH_SIZE: int = 8  # 8x8 DCT grid = 64-bit hash
    AHASH_SIZE: int = 8  # 8x8 average hash grid
    DHASH_SIZE: int = 8  # 8x8 difference hash grid

    # Preprocessing constants
    TARGET_COLORSPACE: str = "sRGB"  # Target color profile for ICC normalization
    EXIF_ORIENTATION_AUTO_FIX: bool = (
        True  # Auto-rotate images per EXIF orientation tag
    )
    RESIZE_MODE: str = (
        "LANCZOS"  # PIL.Image.Resampling.LANCZOS for high-quality downsampling
    )

    # Clustering parameters
    MIN_CLUSTER_SIZE: int = 2  # Minimum images to form a cluster
    MAX_CLUSTER_RADIUS: float = (
        0.15  # Maximum diversity within cluster (1 - similarity)
    )

    # Cache and performance
    CACHE_ENABLED: bool = True
    BATCH_SIZE: int = 32  # Batch size for GPU backends (CLIP)

    @classmethod
    def get_similarity_threshold(cls, backend: str) -> float:
        """
        Get similarity threshold for a specific backend

        Args:
            backend: Backend name ("phash", "ahash", "dhash", "clip")

        Returns:
            Similarity threshold (0-1)
        """
        backend_lower = backend.lower()
        if backend_lower == "phash":
            return cls.PHASH_SIMILARITY_THRESHOLD
        elif backend_lower == "ahash":
            return cls.AHASH_SIMILARITY_THRESHOLD
        elif backend_lower == "dhash":
            return cls.DHASH_SIMILARITY_THRESHOLD
        elif backend_lower == "clip":
            return cls.CLIP_SIMILARITY_THRESHOLD
        else:
            return cls.PHASH_SIMILARITY_THRESHOLD  # Default fallback

    @classmethod
    def get_distance_threshold(cls, backend: str) -> float:
        """
        Get distance threshold for a specific backend

        Args:
            backend: Backend name ("phash", "clip")

        Returns:
            Distance threshold (backend-specific scale)
        """
        backend_lower = backend.lower()
        if backend_lower in ("phash", "ahash", "dhash"):
            # Hamming distance: integer count of differing bits
            hash_size = (
                cls.PHASH_SIZE
                if backend_lower == "phash"
                else (cls.AHASH_SIZE if backend_lower == "ahash" else cls.DHASH_SIZE)
            )
            similarity = cls.get_similarity_threshold(backend_lower)
            # Convert similarity to max Hamming distance
            # similarity = 1 - (hamming / total_bits)
            # hamming = (1 - similarity) * total_bits
            total_bits = hash_size * hash_size
            return int((1.0 - similarity) * total_bits)
        elif backend_lower == "clip":
            # Cosine distance: 1 - cosine_similarity
            return cls.COSINE_DISTANCE_THRESHOLD
        else:
            return float(cls.HAMMING_DISTANCE_MAX)


# Singleton instance
IV_CONFIG = IVConfig()


__all__ = ["IVConfig", "IV_CONFIG"]
