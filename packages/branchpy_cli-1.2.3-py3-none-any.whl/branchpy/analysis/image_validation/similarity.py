"""
Similarity computation with stable normalization
Enforces float32 dtype and L2-normalized vectors
"""

from typing import Union

import numpy as np


def cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """
    Compute cosine similarity between two L2-normalized vectors

    CRITICAL: Assumes inputs are already L2-normalized (unit vectors).
    If not normalized, use cosine_similarity_safe() instead.

    Args:
        vec1: First vector (must be L2-normalized, float32)
        vec2: Second vector (must be L2-normalized, float32)

    Returns:
        Cosine similarity in range [-1, 1] (1.0 = identical direction)

    Raises:
        ValueError: If vectors have different shapes
    """
    if vec1.shape != vec2.shape:
        raise ValueError(f"Shape mismatch: {vec1.shape} vs {vec2.shape}")

    # For L2-normalized vectors: cosine_similarity = dot_product
    # No need to divide by norms (they are 1.0)
    similarity = float(np.dot(vec1, vec2))

    # Clamp to [-1, 1] to handle floating-point precision errors
    return np.clip(similarity, -1.0, 1.0)


def cosine_similarity_safe(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """
    Compute cosine similarity with automatic normalization

    Use this when input vectors may not be L2-normalized.
    Slightly slower due to norm computation.

    Args:
        vec1: First vector (any scale, will be normalized)
        vec2: Second vector (any scale, will be normalized)

    Returns:
        Cosine similarity in range [-1, 1]

    Raises:
        ValueError: If vectors have different shapes or zero norm
    """
    if vec1.shape != vec2.shape:
        raise ValueError(f"Shape mismatch: {vec1.shape} vs {vec2.shape}")

    # Compute L2 norms
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)

    # Handle zero vectors
    if norm1 == 0.0 or norm2 == 0.0:
        raise ValueError("Cannot compute cosine similarity for zero vector")

    # Compute cosine similarity
    similarity = float(np.dot(vec1, vec2) / (norm1 * norm2))

    # Clamp to [-1, 1]
    return np.clip(similarity, -1.0, 1.0)


def l2_normalize(vec: np.ndarray, epsilon: float = 1e-12) -> np.ndarray:
    """
    L2-normalize a vector to unit length

    Args:
        vec: Input vector (any shape)
        epsilon: Small constant to prevent division by zero

    Returns:
        L2-normalized vector (same shape as input, dtype=float32)

    Raises:
        ValueError: If input has zero norm
    """
    # Ensure float32 dtype
    vec = vec.astype(np.float32)

    # Compute L2 norm
    norm = np.linalg.norm(vec)

    # Handle zero vector
    if norm < epsilon:
        raise ValueError(f"Vector has near-zero norm ({norm}), cannot normalize")

    # Normalize
    normalized = vec / norm

    return normalized.astype(np.float32)


def ensure_float32(vec: Union[np.ndarray, list, tuple]) -> np.ndarray:
    """
    Ensure vector is numpy array with float32 dtype

    Args:
        vec: Input vector (ndarray, list, or tuple)

    Returns:
        numpy array with dtype=float32
    """
    if not isinstance(vec, np.ndarray):
        vec = np.array(vec, dtype=np.float32)
    else:
        vec = vec.astype(np.float32)

    return vec


def hamming_distance(hash1: np.ndarray, hash2: np.ndarray) -> int:
    """
    Compute Hamming distance between binary hash vectors

    Args:
        hash1: First binary hash (0/1 values)
        hash2: Second binary hash (0/1 values)

    Returns:
        Number of differing bits

    Raises:
        ValueError: If hashes have different shapes
    """
    if hash1.shape != hash2.shape:
        raise ValueError(f"Hash shape mismatch: {hash1.shape} vs {hash2.shape}")

    # Count differing bits (XOR then sum)
    distance = int(np.sum(hash1 != hash2))

    return distance


def hamming_similarity(hash1: np.ndarray, hash2: np.ndarray) -> float:
    """
    Convert Hamming distance to similarity score

    Args:
        hash1: First binary hash
        hash2: Second binary hash

    Returns:
        Similarity in range [0, 1] (1.0 = identical)
    """
    distance = hamming_distance(hash1, hash2)
    max_distance = hash1.size

    # similarity = 1 - (distance / max_distance)
    similarity = 1.0 - (distance / max_distance)

    return float(similarity)


def batch_cosine_similarity(query_vec: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    """
    Compute cosine similarity between query vector and matrix of vectors

    Optimized for comparing one vector against many (e.g., nearest neighbor search).
    Assumes all vectors are L2-normalized.

    Args:
        query_vec: Query vector (shape: [D], L2-normalized, float32)
        matrix: Matrix of vectors (shape: [N, D], each row L2-normalized, float32)

    Returns:
        Similarity scores (shape: [N], range [-1, 1])

    Raises:
        ValueError: If dimensions don't match
    """
    if query_vec.shape[0] != matrix.shape[1]:
        raise ValueError(
            f"Dimension mismatch: query {query_vec.shape[0]} vs matrix {matrix.shape[1]}"
        )

    # For L2-normalized vectors: cosine = dot product
    # Matrix multiply: [N, D] @ [D, 1] = [N, 1]
    similarities = matrix @ query_vec  # type: ignore[operator]

    # Clamp to [-1, 1]
    similarities = np.clip(similarities, -1.0, 1.0)

    return similarities.astype(np.float32)


def pairwise_cosine_similarity(matrix: np.ndarray) -> np.ndarray:
    """
    Compute pairwise cosine similarity for all vectors in matrix

    Assumes all vectors are L2-normalized.

    Args:
        matrix: Matrix of vectors (shape: [N, D], each row L2-normalized, float32)

    Returns:
        Similarity matrix (shape: [N, N], symmetric, diagonal = 1.0)
    """
    # For L2-normalized vectors: similarity matrix = matrix @ matrix.T
    similarity_matrix = matrix @ matrix.T  # type: ignore[operator]

    # Clamp to [-1, 1] (handle floating-point errors)
    similarity_matrix = np.clip(similarity_matrix, -1.0, 1.0)

    return similarity_matrix.astype(np.float32)


__all__ = [
    "cosine_similarity",
    "cosine_similarity_safe",
    "l2_normalize",
    "ensure_float32",
    "hamming_distance",
    "hamming_similarity",
    "batch_cosine_similarity",
    "pairwise_cosine_similarity",
]
