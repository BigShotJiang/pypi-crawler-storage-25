"""
Dropbox Provider - Dropbox API v2 Integration

Configuration:
{
    "access_token": "...",
    "refresh_token": "..." (optional),
    "client_id": "..." (for refresh),
    "client_secret": "..." (for refresh)
}
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Any, Dict, Iterator, Optional

try:
    import requests

    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from ..base import (
    AssetType,
    DeltaResult,
    ProviderContext,
    ProviderHealth,
    ProviderStatus,
    RemoteAsset,
    ReportMeta,
)
from ..errors import AuthenticationError, ConflictError, NotFoundError, ProviderError
from ..registry import ProviderRegistry

logger = logging.getLogger(__name__)


@ProviderRegistry.register
class DropboxProvider:
    """Dropbox cloud storage provider using API v2"""

    id = "dropbox"
    display_name = "Dropbox"

    API_BASE = "https://api.dropboxapi.com/2"
    CONTENT_BASE = "https://content.dropboxapi.com/2"
    TOKEN_URL = "https://api.dropboxapi.com/oauth2/token"

    IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff"}

    def __init__(self):
        if not REQUESTS_AVAILABLE:
            raise ProviderError("requests library required", provider_id=self.id)

        self._context: Optional[ProviderContext] = None
        self._access_token: Optional[str] = None

    def connect(self, context: ProviderContext) -> None:
        self._context = context
        self._access_token = context.get_credential("access_token")

        if not self._access_token:
            refresh_token = context.get_credential("refresh_token")
            if refresh_token:
                self._refresh_access_token()
            else:
                raise AuthenticationError(
                    "Missing access_token or refresh_token", provider_id=self.id
                )

        logger.info(f"[{self.id}] Connected")

    def _refresh_access_token(self) -> None:
        refresh_token = self._context.get_credential("refresh_token")
        client_id = self._context.get_credential("client_id")
        client_secret = self._context.get_credential("client_secret")

        if not all([refresh_token, client_id, client_secret]):
            raise AuthenticationError(
                "Missing refresh credentials", provider_id=self.id
            )

        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret,
        }

        response = requests.post(
            self.TOKEN_URL, data=payload, timeout=self._context.timeout
        )
        response.raise_for_status()

        data = response.json()
        self._access_token = data["access_token"]
        self._context.credentials["access_token"] = self._access_token

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self._access_token}",
            "User-Agent": self._context.user_agent if self._context else "BranchPy/1.0",
        }

    def list_assets(
        self,
        folder: Optional[str] = None,
        asset_type: Optional[AssetType] = None,
        recursive: bool = False,
    ) -> Iterator[RemoteAsset]:
        path = f"/{folder}" if folder else ""

        url = f"{self.API_BASE}/files/list_folder"
        payload = {"path": path, "recursive": recursive}

        while True:
            response = requests.post(
                url,
                headers=self._headers(),
                json=payload,
                timeout=self._context.timeout,
            )

            if not response.ok:
                raise ProviderError(
                    f"List failed: {response.text}", provider_id=self.id
                )

            data = response.json()

            for entry in data.get("entries", []):
                entry_type = self._classify_type(entry)

                if asset_type and entry_type != asset_type:
                    continue

                yield RemoteAsset(
                    id=entry["id"],
                    name=entry["name"],
                    path=entry["path_display"],
                    asset_type=entry_type,
                    size_bytes=entry.get("size"),
                    modified_at=self._parse_datetime(entry.get("client_modified")),
                    metadata={"rev": entry.get("rev")},
                )

            if not data.get("has_more"):
                break

            # Continue with cursor
            url = f"{self.API_BASE}/files/list_folder/continue"
            payload = {"cursor": data["cursor"]}

    def fetch_asset(self, asset_id: str) -> bytes:
        # Need path for download, use metadata to get it
        meta_url = f"{self.API_BASE}/files/get_metadata"
        meta_response = requests.post(
            meta_url,
            headers=self._headers(),
            json={"path": asset_id},  # Dropbox uses path as ID
            timeout=self._context.timeout,
        )

        if not meta_response.ok:
            raise NotFoundError(f"Asset not found: {asset_id}", provider_id=self.id)

        path = meta_response.json()["path_display"]

        url = f"{self.CONTENT_BASE}/files/download"
        headers = self._headers()
        headers["Dropbox-API-Arg"] = __import__("json").dumps({"path": path})

        response = requests.post(url, headers=headers, timeout=60)

        if not response.ok:
            raise ProviderError(
                f"Download failed: {response.text}", provider_id=self.id
            )

        return response.content

    def push_report(
        self,
        path: str,
        content: bytes,
        *,
        overwrite: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReportMeta:
        path = f"/{path.lstrip('/')}"

        url = f"{self.CONTENT_BASE}/files/upload"
        headers = self._headers()
        headers["Content-Type"] = "application/octet-stream"
        headers["Dropbox-API-Arg"] = __import__("json").dumps(
            {
                "path": path,
                "mode": "overwrite" if overwrite else "add",
                "autorename": False,
            }
        )

        response = requests.post(url, headers=headers, data=content, timeout=60)

        if not response.ok:
            if response.status_code == 409:
                raise ConflictError(f"File exists: {path}", provider_id=self.id)
            raise ProviderError(f"Upload failed: {response.text}", provider_id=self.id)

        data = response.json()

        return ReportMeta(
            id=data["id"],
            path=data["path_display"],
            size_bytes=data.get("size"),
            uploaded_at=self._parse_datetime(data.get("client_modified")),
        )

    def health_check(self) -> ProviderHealth:
        start = time.time()

        try:
            url = f"{self.API_BASE}/users/get_space_usage"
            response = requests.post(url, headers=self._headers(), timeout=10)

            latency = (time.time() - start) * 1000

            if not response.ok:
                return ProviderHealth(
                    status=ProviderStatus.DEGRADED, message=response.text
                )

            data = response.json()
            allocation = data.get("allocation", {}).get("allocated", 0)
            used = data.get("used", 0)

            return ProviderHealth(
                status=ProviderStatus.HEALTHY,
                latency_ms=latency,
                quota_used=used,
                quota_total=allocation,
            )

        except Exception as e:
            return ProviderHealth(status=ProviderStatus.UNAVAILABLE, message=str(e))

    def fetch_thumbnail(self, asset_id: str) -> Optional[bytes]:
        url = f"{self.CONTENT_BASE}/files/get_thumbnail_v2"
        headers = self._headers()
        headers["Dropbox-API-Arg"] = __import__("json").dumps(
            {"resource": {".tag": "path", "path": asset_id}, "size": "w256h256"}
        )

        response = requests.post(url, headers=headers, timeout=10)

        if response.ok:
            return response.content
        return None

    def store_thumbnail(
        self,
        asset_id: str,
        png_bytes: bytes,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.push_report(
            f".thumbnails/{asset_id.replace('/', '_')}.png", png_bytes, overwrite=True
        )

    def supports_delta(self) -> bool:
        return True

    def list_delta(self, cursor: Optional[str] = None) -> DeltaResult:
        if cursor:
            url = f"{self.API_BASE}/files/list_folder/continue"
            payload = {"cursor": cursor}
        else:
            url = f"{self.API_BASE}/files/list_folder/get_latest_cursor"
            payload = {"path": "", "recursive": True}

            response = requests.post(
                url, headers=self._headers(), json=payload, timeout=30
            )

            if not response.ok:
                raise ProviderError("Delta init failed", provider_id=self.id)

            cursor = response.json()["cursor"]
            payload = {"cursor": cursor}
            url = f"{self.API_BASE}/files/list_folder/continue"

        response = requests.post(url, headers=self._headers(), json=payload, timeout=30)

        if not response.ok:
            raise ProviderError("Delta query failed", provider_id=self.id)

        data = response.json()
        modified = []
        removed = []

        for entry in data.get("entries", []):
            if entry[".tag"] == "deleted":
                removed.append(entry["path_display"])
            else:
                asset_type = self._classify_type(entry)
                modified.append(
                    RemoteAsset(
                        id=entry["id"],
                        name=entry["name"],
                        path=entry["path_display"],
                        asset_type=asset_type,
                        size_bytes=entry.get("size"),
                        modified_at=self._parse_datetime(entry.get("client_modified")),
                    )
                )

        return DeltaResult(
            cursor=data["cursor"],
            added=[],  # Dropbox doesn't distinguish new vs modified easily
            modified=modified,
            removed=removed,
            has_more=data.get("has_more", False),
        )

    def disconnect(self) -> None:
        self._access_token = None
        self._context = None

    def _classify_type(self, entry: Dict[str, Any]) -> AssetType:
        if entry[".tag"] == "folder":
            return AssetType.FOLDER

        name = entry.get("name", "").lower()
        ext = "." + name.split(".")[-1] if "." in name else ""

        if ext in self.IMAGE_EXTENSIONS:
            return AssetType.IMAGE
        elif ext in (".json", ".html"):
            return AssetType.REPORT
        else:
            return AssetType.UNKNOWN

    @staticmethod
    def _parse_datetime(dt_str: Optional[str]) -> Optional[datetime]:
        if not dt_str:
            return None
        try:
            return datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        except Exception:
            return None
