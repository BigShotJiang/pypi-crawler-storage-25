"""
Credential Vault - Secure Storage for Provider Credentials

Features:
- AES-256-GCM encryption
- PBKDF2 key derivation (100,000 iterations)
- Per-provider credential isolation
- Atomic rotation with rollback
- Audit logging integration
- Windows DPAPI fallback support
"""

from __future__ import annotations

import base64
import json
import logging
import os
import secrets
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

# Cryptography imports
try:
    from cryptography.hazmat.backends import default_backend  # type: ignore
    from cryptography.hazmat.primitives import hashes  # type: ignore
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # type: ignore
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC  # type: ignore

    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

    # Lightweight stubs to satisfy static analysis while runtime guards prevent use
    class _AESGCMStub:  # type: ignore
        def __init__(self, *a, **k):
            pass

        def encrypt(self, *a, **k):
            raise EncryptionError("cryptography not installed")

        def decrypt(self, *a, **k):
            raise EncryptionError("cryptography not installed")

    AESGCM = _AESGCMStub  # type: ignore

    class _PBKDF2HMACStub:  # type: ignore
        def __init__(self, *a, **k):
            pass

        def derive(self, *a, **k):
            raise EncryptionError("cryptography not installed")

    PBKDF2HMAC = _PBKDF2HMACStub  # type: ignore

    class _HashesStub:  # type: ignore
        @staticmethod
        def SHA256():
            raise EncryptionError("cryptography not installed")

    hashes = _HashesStub()  # type: ignore

    def default_backend():  # type: ignore
        raise EncryptionError("cryptography not installed")


# Optional keyring dependency
try:
    import keyring  # type: ignore
except ImportError:
    keyring = None  # type: ignore

from .errors import EncryptionError, VaultError

logger = logging.getLogger(__name__)


class RotationJournal:
    """
    Journal for tracking rotation progress with rollback capability.

    File format (.branchpy/.rotation_journal.json):
    {
        "rotation_id": "uuid",
        "started_at": "ISO-8601",
        "status": "in_progress|completed|failed",
        "providers": {
            "onedrive": {"status": "pending|completed|failed", "completed_at": "ISO-8601"},
            "dropbox": {"status": "completed", "completed_at": "ISO-8601"}
        },
        "backup_path": "path/to/vault.bak",
        "completed_at": "ISO-8601"
    }
    """

    def __init__(self, journal_path: Path):
        """Initialize rotation journal"""
        self.journal_path = journal_path
        self._data: Dict[str, Any] = {}

    def start(self, provider_ids: list[str], backup_path: Path) -> str:
        """
        Start new rotation and return rotation ID.

        Args:
            provider_ids: List of provider IDs to rotate
            backup_path: Path to vault backup

        Returns:
            Rotation ID (UUID)
        """
        import uuid

        rotation_id = str(uuid.uuid4())

        self._data = {
            "rotation_id": rotation_id,
            "started_at": datetime.utcnow().isoformat() + "Z",
            "status": "in_progress",
            "providers": {
                provider_id: {"status": "pending"} for provider_id in provider_ids
            },
            "backup_path": str(backup_path),
        }

        self._save()
        return rotation_id

    def mark_provider_completed(self, provider_id: str) -> None:
        """Mark provider as successfully rotated"""
        if provider_id in self._data.get("providers", {}):
            self._data["providers"][provider_id] = {
                "status": "completed",
                "completed_at": datetime.utcnow().isoformat() + "Z",
            }
            self._save()

    def mark_provider_failed(self, provider_id: str, error: str) -> None:
        """Mark provider rotation as failed"""
        if provider_id in self._data.get("providers", {}):
            self._data["providers"][provider_id] = {
                "status": "failed",
                "error": error,
                "failed_at": datetime.utcnow().isoformat() + "Z",
            }
            self._save()

    def complete(self) -> None:
        """Mark rotation as fully completed"""
        self._data["status"] = "completed"
        self._data["completed_at"] = datetime.utcnow().isoformat() + "Z"
        self._save()

    def fail(self, error: str) -> None:
        """Mark rotation as failed"""
        self._data["status"] = "failed"
        self._data["error"] = error
        self._data["failed_at"] = datetime.utcnow().isoformat() + "Z"
        self._save()

    def get_backup_path(self) -> Optional[Path]:
        """Get backup path from journal"""
        backup_str = self._data.get("backup_path")
        return Path(backup_str) if backup_str else None

    def is_in_progress(self) -> bool:
        """Check if rotation is in progress"""
        return self._data.get("status") == "in_progress"

    def get_pending_providers(self) -> list[str]:
        """Get list of providers not yet completed"""
        providers = self._data.get("providers", {})
        return [
            provider_id
            for provider_id, info in providers.items()
            if info.get("status") == "pending"
        ]

    def _save(self) -> None:
        """Save journal atomically"""
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)

        temp_path = self.journal_path.with_suffix(".tmp")

        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2, ensure_ascii=False)

        temp_path.replace(self.journal_path)

    def load(self) -> bool:
        """
        Load existing journal.

        Returns:
            True if journal exists and was loaded
        """
        if not self.journal_path.exists():
            return False

        with open(self.journal_path, "r", encoding="utf-8") as f:
            self._data = json.load(f)

        return True

    def delete(self) -> None:
        """Delete journal file"""
        if self.journal_path.exists():
            self.journal_path.unlink()

    def get_status(self) -> Dict[str, Any]:
        """Get current journal status"""
        return dict(self._data)


class CredentialVault:
    """
    Encrypted credential storage for cloud providers.

    File format:
    {
        "version": "1.0",
        "salt": "base64...",
        "created_at": "ISO-8601",
        "providers": {
            "onedrive": {
                "encrypted": "base64...",
                "nonce": "base64...",
                "updated_at": "ISO-8601"
            }
        }
    }
    """

    VERSION = "1.0"
    PBKDF2_ITERATIONS = 100_000
    KEY_SIZE = 32  # 256 bits
    NONCE_SIZE = 12  # 96 bits (GCM standard)

    def __init__(
        self,
        vault_path: Path,
        master_password: Optional[str] = None,
        auto_create: bool = True,
    ):
        """
        Initialize vault.

        Args:
            vault_path: Path to vault file
            master_password: Master password (None = auto-generate and store in keyring)
            auto_create: Create vault if doesn't exist
        """
        if not CRYPTO_AVAILABLE:
            raise VaultError(
                "Cryptography library not available. "
                "Install with: pip install cryptography"
            )

        self.vault_path = vault_path
        self._master_password = master_password
        self._key: Optional[bytes] = None
        self._data: Dict[str, Any] = {}

        if vault_path.exists():
            self._load()
        elif auto_create:
            self._initialize()
        else:
            raise VaultError(f"Vault not found: {vault_path}")

    def _get_master_password(self) -> str:
        """
        Get master password (from parameter, keyring, or environment).
        """
        if self._master_password:
            return self._master_password

        # Try environment variable
        env_password = os.environ.get("BRANCHPY_VAULT_PASSWORD")
        if env_password:
            return env_password

        # Try keyring (optional dependency, imported globally)
        if "keyring" in globals() and keyring:  # type: ignore
            try:
                password = keyring.get_password("branchpy", "vault_master_key")  # type: ignore
                if password:
                    return password
            except Exception:
                pass

        # Try Windows DPAPI (fallback)
        if os.name == "nt":
            try:
                return self._get_dpapi_key()
            except Exception as e:
                logger.warning(f"DPAPI fallback failed: {e}")

        raise VaultError(
            "No master password available. Set via:\n"
            "  1. Constructor parameter\n"
            "  2. BRANCHPY_VAULT_PASSWORD environment variable\n"
            "  3. System keyring (install 'keyring' package)"
        )

    def _get_dpapi_key(self) -> str:
        """Generate persistent key using Windows DPAPI"""
        import win32crypt

        # Use machine-specific entropy
        machine_id = os.environ.get("COMPUTERNAME", "branchpy-default")
        entropy = machine_id.encode("utf-8")

        # Generate or retrieve protected key
        key_file = self.vault_path.parent / ".vault_dpapi_key"

        if key_file.exists():
            # Decrypt existing key
            encrypted_key = key_file.read_bytes()
            decrypted = win32crypt.CryptUnprotectData(
                encrypted_key, entropy, None, None, 0
            )
            return decrypted[1].decode("utf-8")
        else:
            # Generate new key
            new_key = secrets.token_hex(32)
            encrypted = win32crypt.CryptProtectData(
                new_key.encode("utf-8"),
                "BranchPy Vault Master Key",
                entropy,
                None,
                None,
                0,
            )
            key_file.write_bytes(encrypted)
            return new_key

    def _derive_key(self, salt: bytes) -> bytes:
        """
        Derive encryption key from master password using PBKDF2.

        Args:
            salt: Cryptographic salt

        Returns:
            32-byte encryption key
        """
        password = self._get_master_password()

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=self.KEY_SIZE,
            salt=salt,
            iterations=self.PBKDF2_ITERATIONS,
            backend=default_backend(),
        )

        return kdf.derive(password.encode("utf-8"))

    def _initialize(self) -> None:
        """Create new vault with random salt"""
        salt = secrets.token_bytes(32)

        self._data = {
            "version": self.VERSION,
            "salt": base64.b64encode(salt).decode("ascii"),
            "created_at": datetime.utcnow().isoformat() + "Z",
            "providers": {},
        }

        self._key = self._derive_key(salt)
        self._save()

        logger.info(f"Initialized new credential vault: {self.vault_path}")

    def _load(self) -> None:
        """Load and verify vault"""
        try:
            with open(self.vault_path, "r", encoding="utf-8") as f:
                self._data = json.load(f)
        except json.JSONDecodeError as e:
            raise VaultError(f"Vault corrupted (invalid JSON): {e}")
        except Exception as e:
            raise VaultError(f"Failed to load vault: {e}")

        # Verify version
        if self._data.get("version") != self.VERSION:
            raise VaultError(f"Unsupported vault version: {self._data.get('version')}")

        # Derive key
        salt_b64 = self._data.get("salt")
        if not salt_b64:
            raise VaultError("Vault missing salt")

        salt = base64.b64decode(salt_b64)
        self._key = self._derive_key(salt)

        logger.debug(f"Loaded credential vault: {self.vault_path}")

    def _save(self) -> None:
        """Save vault atomically"""
        # Write to temp file first
        temp_path = self.vault_path.with_suffix(".tmp")

        try:
            self.vault_path.parent.mkdir(parents=True, exist_ok=True)

            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)

            # Atomic rename
            temp_path.replace(self.vault_path)

            logger.debug(f"Saved credential vault: {self.vault_path}")
        except Exception as e:
            if temp_path.exists():
                temp_path.unlink()
            raise VaultError(f"Failed to save vault: {e}")

    def _encrypt(self, plaintext: str) -> tuple[str, str]:
        """
        Encrypt plaintext using AES-256-GCM.

        Returns:
            (ciphertext_b64, nonce_b64)
        """
        if not self._key:
            raise EncryptionError("Vault not initialized")

        nonce = secrets.token_bytes(self.NONCE_SIZE)
        aesgcm = AESGCM(self._key)

        try:
            ciphertext = aesgcm.encrypt(
                nonce, plaintext.encode("utf-8"), None  # no additional data
            )

            return (
                base64.b64encode(ciphertext).decode("ascii"),
                base64.b64encode(nonce).decode("ascii"),
            )
        except Exception as e:
            raise EncryptionError(f"Encryption failed: {e}")

    def _decrypt(self, ciphertext_b64: str, nonce_b64: str) -> str:
        """
        Decrypt ciphertext using AES-256-GCM.

        Returns:
            Plaintext string
        """
        if not self._key:
            raise EncryptionError("Vault not initialized")

        try:
            ciphertext = base64.b64decode(ciphertext_b64)
            nonce = base64.b64decode(nonce_b64)

            aesgcm = AESGCM(self._key)
            plaintext_bytes = aesgcm.decrypt(nonce, ciphertext, None)

            return plaintext_bytes.decode("utf-8")
        except Exception as e:
            raise EncryptionError(
                f"Decryption failed (wrong password or corrupted data): {e}"
            )

    def store_credentials(self, provider_id: str, credentials: Dict[str, Any]) -> None:
        """
        Store provider credentials (encrypted).

        Args:
            provider_id: Provider identifier
            credentials: Credential dictionary (will be JSON-serialized)
        """
        # Serialize credentials
        plaintext = json.dumps(credentials, ensure_ascii=False)

        # Encrypt
        ciphertext, nonce = self._encrypt(plaintext)

        # Store
        if "providers" not in self._data:
            self._data["providers"] = {}

        self._data["providers"][provider_id] = {
            "encrypted": ciphertext,
            "nonce": nonce,
            "updated_at": datetime.utcnow().isoformat() + "Z",
        }

        self._save()
        logger.info(f"Stored credentials for provider: {provider_id}")

    def get_credentials(self, provider_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve provider credentials (decrypted).

        Args:
            provider_id: Provider identifier

        Returns:
            Credential dictionary or None if not found
        """
        providers = self._data.get("providers", {})

        if provider_id not in providers:
            return None

        entry = providers[provider_id]
        ciphertext = entry.get("encrypted")
        nonce = entry.get("nonce")

        if not ciphertext or not nonce:
            raise VaultError(f"Invalid vault entry for {provider_id}")

        # Decrypt
        plaintext = self._decrypt(ciphertext, nonce)

        # Deserialize
        try:
            return json.loads(plaintext)
        except json.JSONDecodeError as e:
            raise VaultError(f"Corrupted credentials for {provider_id}: {e}")

    def remove_credentials(self, provider_id: str) -> bool:
        """
        Remove provider credentials.

        Args:
            provider_id: Provider identifier

        Returns:
            True if removed, False if not found
        """
        providers = self._data.get("providers", {})

        if provider_id in providers:
            del providers[provider_id]
            self._save()
            logger.info(f"Removed credentials for provider: {provider_id}")
            return True

        return False

    def list_providers(self) -> list[str]:
        """List provider IDs with stored credentials"""
        return list(self._data.get("providers", {}).keys())

    def rotate_key(self, new_password: Optional[str] = None) -> None:
        """
        Rotate encryption key (re-encrypt all credentials).

        Args:
            new_password: New master password (None = generate random)

        Raises:
            VaultError: If rotation fails (vault will be rolled back)
        """
        logger.info("Starting credential vault key rotation...")
        rotation_start = datetime.utcnow().isoformat() + "Z"
        start_perf = None
        try:
            import time as _time

            start_perf = _time.perf_counter()
        except Exception:
            start_perf = None

        # Initialize rotation journal
        journal_path = self.vault_path.parent / ".rotation_journal.json"
        journal = RotationJournal(journal_path)

        # Backup current vault
        backup_path = self.vault_path.with_suffix(".bak")
        if self.vault_path.exists():
            import shutil

            shutil.copy2(self.vault_path, backup_path)

        # Get provider list
        provider_ids = self.list_providers()

        # Start journal
        rotation_id = journal.start(provider_ids, backup_path)
        logger.info(f"Rotation journal started: {rotation_id}")

        try:
            # Decrypt all credentials with old key
            decrypted_providers = {}
            for provider_id in provider_ids:
                try:
                    credentials = self.get_credentials(provider_id)
                    if credentials:
                        decrypted_providers[provider_id] = credentials
                except Exception as e:
                    logger.error(f"Failed to decrypt {provider_id}: {e}")
                    journal.mark_provider_failed(provider_id, str(e))
                    raise

            # Generate new salt and key
            new_salt = secrets.token_bytes(32)

            if new_password:
                old_password = self._master_password
                self._master_password = new_password

            self._key = self._derive_key(new_salt)

            # Update vault metadata
            self._data["salt"] = base64.b64encode(new_salt).decode("ascii")
            self._data["rotated_at"] = datetime.utcnow().isoformat() + "Z"
            self._data["rotation_id"] = rotation_id
            self._data["providers"] = {}

            # Re-encrypt all credentials
            for provider_id, credentials in decrypted_providers.items():
                try:
                    plaintext = json.dumps(credentials, ensure_ascii=False)
                    ciphertext, nonce = self._encrypt(plaintext)

                    self._data["providers"][provider_id] = {
                        "encrypted": ciphertext,
                        "nonce": nonce,
                        "updated_at": datetime.utcnow().isoformat() + "Z",
                    }

                    # Verify decryption works
                    test_decrypt = self._decrypt(ciphertext, nonce)
                    if test_decrypt != plaintext:
                        raise EncryptionError(f"Verification failed for {provider_id}")

                    # Mark provider completed in journal
                    journal.mark_provider_completed(provider_id)
                    logger.debug(f"Rotated credentials for {provider_id}")

                except Exception as e:
                    logger.error(f"Failed to re-encrypt {provider_id}: {e}")
                    journal.mark_provider_failed(provider_id, str(e))
                    raise

            # Save atomically
            self._save()

            # Mark journal as complete
            journal.complete()

            # Remove backup on success
            if backup_path.exists():
                backup_path.unlink()

            # Clean up journal
            journal.delete()

            # Governance-like audit log line (structure similar to ImageValidationLogger events)
            duration_ms = None
            if start_perf is not None:
                import time as _time

                duration_ms = (_time.perf_counter() - start_perf) * 1000.0
            logger.info(
                json.dumps(
                    {
                        "event_type": "PROVIDER_CREDENTIAL_ROTATE_COMPLETE",
                        "timestamp": datetime.utcnow().isoformat() + "Z",
                        "rotation_id": rotation_id,
                        "rotation_started_at": rotation_start,
                        "provider_count": len(decrypted_providers),
                        "duration_ms": duration_ms,
                    }
                )
            )

        except Exception as e:
            # Mark journal as failed
            journal.fail(str(e))

            # Rollback on failure
            logger.error(f"Key rotation failed: {e}")

            if backup_path.exists():
                import shutil

                shutil.copy2(backup_path, self.vault_path)
                logger.info("Rolled back to previous vault state")

            duration_ms = None
            if start_perf is not None:
                import time as _time

                duration_ms = (_time.perf_counter() - start_perf) * 1000.0
            logger.error(
                json.dumps(
                    {
                        "event_type": "PROVIDER_CREDENTIAL_ROTATE_ERROR",
                        "timestamp": datetime.utcnow().isoformat() + "Z",
                        "rotation_id": rotation_id,
                        "rotation_started_at": rotation_start,
                        "error_message": str(e),
                        "duration_ms": duration_ms,
                    }
                )
            )
            raise VaultError(f"Key rotation failed (rolled back): {e}")

    def rotate_key_dry_run(self) -> Dict[str, Any]:
        """
        Simulate key rotation without making changes.

        Returns:
            Preview report showing what would be rotated
        """
        logger.info("Starting DRY RUN of credential vault key rotation...")

        start_perf = None
        try:
            import time as _time

            start_perf = _time.perf_counter()
        except Exception:
            start_perf = None

        report = {
            "dry_run": True,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "vault_path": str(self.vault_path),
            "current_version": self._data.get("version"),
            "created_at": self._data.get("created_at"),
            "last_rotated_at": self._data.get("rotated_at", "Never"),
            "provider_count": len(self.list_providers()),
            "providers": [],
            "operations": [],
            "estimated_duration_ms": None,
            "status": "success",
            "errors": [],
        }

        provider_ids = self.list_providers()

        # Test decryption of all providers
        for provider_id in provider_ids:
            provider_info = {
                "provider_id": provider_id,
                "current_status": "encrypted",
                "can_decrypt": False,
                "credentials_present": False,
                "error": None,
            }

            try:
                credentials = self.get_credentials(provider_id)
                if credentials:
                    provider_info["can_decrypt"] = True
                    provider_info["credentials_present"] = True
                    provider_info["credential_keys"] = list(credentials.keys())
                else:
                    provider_info["credentials_present"] = False
            except Exception as e:
                provider_info["error"] = str(e)
                report["errors"].append({"provider_id": provider_id, "error": str(e)})

            report["providers"].append(provider_info)

        # Simulate operations
        report["operations"] = [
            "1. Create backup at vault.bak",
            "2. Start rotation journal",
            "3. Decrypt all provider credentials with current key",
            "4. Generate new salt and derive new encryption key",
            "5. Re-encrypt all credentials with new key",
            "6. Verify decryption with new key",
            "7. Save vault atomically",
            "8. Complete journal",
            "9. Remove backup",
            "10. Delete journal",
        ]

        # Estimate duration (rough calculation based on provider count)
        if start_perf is not None:
            import time as _time

            check_duration = (_time.perf_counter() - start_perf) * 1000.0
            # Estimate: current checks + 50ms per provider for re-encryption
            estimated = check_duration + (len(provider_ids) * 50.0)
            report["estimated_duration_ms"] = estimated

        # Set status based on errors
        if report["errors"]:
            report["status"] = "would_fail"
            report["recommendation"] = "Fix decryption errors before rotating"
        else:
            report["status"] = "would_succeed"
            report["recommendation"] = "Ready for rotation"

        logger.info(
            f"Dry run complete: {report['status']} ({len(provider_ids)} providers)"
        )

        return report

    def export_plaintext(self, output_path: Path) -> None:
        """
        Export all credentials in plaintext (DANGER: use only for backup/migration).

        Args:
            output_path: Output file path
        """
        logger.warning(
            f"Exporting credentials in PLAINTEXT to {output_path}. "
            "This is a SECURITY RISK!"
        )

        export_data = {
            "exported_at": datetime.utcnow().isoformat() + "Z",
            "vault_version": self.VERSION,
            "providers": {},
        }

        for provider_id in self.list_providers():
            credentials = self.get_credentials(provider_id)
            if credentials:
                export_data["providers"][provider_id] = credentials

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)

        logger.info(f"Exported {len(export_data['providers'])} provider credentials")

    def import_plaintext(self, input_path: Path) -> None:
        """
        Import credentials from plaintext export.

        Args:
            input_path: Export file path
        """
        logger.info(f"Importing credentials from {input_path}...")

        with open(input_path, "r", encoding="utf-8") as f:
            import_data = json.load(f)

        providers = import_data.get("providers", {})

        for provider_id, credentials in providers.items():
            self.store_credentials(provider_id, credentials)

        logger.info(f"Imported {len(providers)} provider credentials")

    def get_metadata(self) -> Dict[str, Any]:
        """Get vault metadata (non-sensitive)"""
        return {
            "version": self._data.get("version"),
            "created_at": self._data.get("created_at"),
            "rotated_at": self._data.get("rotated_at"),
            "provider_count": len(self._data.get("providers", {})),
            "providers": list(self._data.get("providers", {}).keys()),
        }
