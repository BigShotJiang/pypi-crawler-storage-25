"""
Provider Framework V2 - Cloud Integration for Image Validation

Modular provider architecture for cloud asset synchronization, report storage,
and thumbnail management across multiple platforms.

Supported Providers:
- OneDrive (Microsoft Graph API)
- Google Drive (Drive API v3)
- Dropbox (API v2)
- WebDAV (Generic protocol)
- GitHub (Contents API)
- M-Files (Enterprise REST API)
"""

from .base import (
    DeltaResult,
    Provider,
    ProviderContext,
    ProviderHealth,
    RemoteAsset,
    ReportMeta,
)
from .errors import (
    AuthenticationError,
    ConnectionError,
    ProviderError,
    QuotaExceededError,
    RateLimitError,
)
from .registry import ProviderRegistry, get_provider
from .vault import CredentialVault

__all__ = [
    # Base types
    "Provider",
    "ProviderContext",
    "RemoteAsset",
    "ReportMeta",
    "ProviderHealth",
    "DeltaResult",
    # Errors
    "ProviderError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "ConnectionError",
    # Registry
    "ProviderRegistry",
    "get_provider",
    # Security
    "CredentialVault",
]
