"""
Provider Framework Errors

Exception hierarchy for cloud provider operations.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

# Explicit export list for import hygiene (Axis5 v0.9.1)
__all__ = [
    "ProviderError",
    "AuthenticationError",
    "TokenExpiredError",
    "RateLimitError",
    "QuotaExceededError",
    "ConnectionError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "EncryptionError",
    "VaultError",
]


class ProviderError(Exception):
    """Base exception for all provider errors"""

    def __init__(
        self,
        message: str,
        provider_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.provider_id = provider_id
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        """Serialize error for logging"""
        return {
            "error_type": self.__class__.__name__,
            "message": str(self),
            "provider_id": self.provider_id,
            "details": self.details,
        }


class AuthenticationError(ProviderError):
    """Authentication or authorization failure"""

    def __init__(
        self,
        message: str = "Authentication failed",
        provider_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)


class TokenExpiredError(AuthenticationError):
    """OAuth token expired and refresh failed"""

    pass


class RateLimitError(ProviderError):
    """Rate limit exceeded"""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        provider_id: Optional[str] = None,
        retry_after: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)
        self.retry_after = retry_after  # seconds

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["retry_after"] = self.retry_after
        return data


class QuotaExceededError(ProviderError):
    """Storage quota or API quota exceeded"""

    def __init__(
        self,
        message: str = "Quota exceeded",
        provider_id: Optional[str] = None,
        quota_type: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)
        self.quota_type = quota_type  # 'storage' or 'api'

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["quota_type"] = self.quota_type
        return data


class ConnectionError(ProviderError):
    """Network or connection failure"""

    def __init__(
        self,
        message: str = "Connection failed",
        provider_id: Optional[str] = None,
        retryable: bool = True,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)
        self.retryable = retryable

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["retryable"] = self.retryable
        return data


class NotFoundError(ProviderError):
    """Resource not found"""

    def __init__(
        self,
        message: str = "Resource not found",
        provider_id: Optional[str] = None,
        resource_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)
        self.resource_id = resource_id

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["resource_id"] = self.resource_id
        return data


class ConflictError(ProviderError):
    """Conflict on write (e.g., duplicate file, ETag mismatch)"""

    def __init__(
        self,
        message: str = "Resource conflict",
        provider_id: Optional[str] = None,
        conflict_type: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)
        self.conflict_type = conflict_type  # 'duplicate', 'etag', etc.

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["conflict_type"] = self.conflict_type
        return data


class ValidationError(ProviderError):
    """Input validation failure"""

    def __init__(
        self,
        message: str = "Validation failed",
        provider_id: Optional[str] = None,
        field: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, provider_id, details)
        self.field = field

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["field"] = self.field
        return data


class EncryptionError(ProviderError):
    """Encryption or decryption failure"""

    pass


class VaultError(ProviderError):
    """Credential vault operation failure"""

    pass
