"""
Report Synchronization Module

Manages synchronization of validation reports to cloud providers,
including index maintenance and conflict resolution.
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import Provider, ReportMeta
from .errors import ConflictError, ProviderError
from .registry import ProviderContext, get_provider

logger = logging.getLogger(__name__)


class ReportSync:
    """
    Synchronizes validation reports to cloud providers.

    Features:
    - Maintains index.json with report metadata
    - Conflict resolution (append -n suffix)
    - Version tagging (semantic version + git commit)
    - Correlation ID tracking
    """

    def __init__(self, provider: Provider):
        """
        Initialize sync manager.

        Args:
            provider: Connected provider instance
        """
        self.provider = provider

    def push_report(
        self,
        report_path: Path,
        remote_path: str,
        *,
        correlation_id: Optional[str] = None,
        overwrite: bool = False,
        version: Optional[str] = None,
        git_commit: Optional[str] = None,
    ) -> ReportMeta:
        """
        Upload validation report to cloud.

        Args:
            report_path: Local report file
            remote_path: Remote path (e.g., 'reports/2025-01/report.json')
            correlation_id: Validation run correlation ID
            overwrite: Allow overwriting existing file
            version: Semantic version tag
            git_commit: Git commit hash

        Returns:
            Report metadata

        Raises:
            ConflictError: If file exists and overwrite=False
        """
        if not report_path.exists():
            raise FileNotFoundError(f"Report not found: {report_path}")

        # Read report content
        content = report_path.read_bytes()

        # Calculate hash
        report_hash = hashlib.sha256(content).hexdigest()

        # Build metadata
        metadata = {
            "correlation_id": correlation_id,
            "version": version,
            "git_commit": git_commit,
            "sha256": report_hash,
            "uploaded_at": datetime.utcnow().isoformat() + "Z",
            "local_path": str(report_path),
        }

        try:
            # Upload report
            report_meta = self.provider.push_report(
                remote_path, content, overwrite=overwrite, metadata=metadata
            )

            logger.info(
                f"[ReportSync] Uploaded report to {remote_path} "
                f"(correlation_id={correlation_id}, size={len(content)} bytes)"
            )

            # Update index
            self._update_index(remote_path, report_meta, metadata)

            return report_meta

        except ConflictError:
            if not overwrite:
                # Try append suffix
                remote_path_resolved = self._resolve_conflict(remote_path)
                logger.warning(
                    f"[ReportSync] Conflict detected, retrying with {remote_path_resolved}"
                )
                return self.push_report(
                    report_path,
                    remote_path_resolved,
                    correlation_id=correlation_id,
                    overwrite=False,
                    version=version,
                    git_commit=git_commit,
                )
            raise

    def _resolve_conflict(self, remote_path: str) -> str:
        """
        Resolve filename conflict by appending -n suffix.

        Args:
            remote_path: Original path

        Returns:
            New path with suffix
        """
        path_obj = Path(remote_path)
        stem = path_obj.stem
        suffix = path_obj.suffix
        parent = path_obj.parent

        # Find available suffix
        for i in range(1, 100):
            new_name = f"{stem}-{i}{suffix}"
            new_path = str(parent / new_name)

            # Check if this path is available (simplified check)
            # In production, would query provider
            return new_path

        raise ProviderError("Too many conflicts, cannot resolve")

    def _update_index(
        self, remote_path: str, report_meta: ReportMeta, metadata: Dict[str, Any]
    ) -> None:
        """
        Update index.json with new report entry.

        Args:
            remote_path: Remote report path
            report_meta: Report metadata from upload
            metadata: Additional metadata
        """
        index_path = "reports/index.json"

        try:
            # Download existing index
            try:
                index_content = self.provider.fetch_asset(index_path)
                index_data = json.loads(index_content.decode("utf-8"))
            except Exception:
                # Index doesn't exist, create new
                index_data = {"version": "1.0", "reports": []}

            # Add new report entry
            entry = {
                "path": remote_path,
                "id": report_meta.id,
                "correlation_id": metadata.get("correlation_id"),
                "version": metadata.get("version"),
                "git_commit": metadata.get("git_commit"),
                "sha256": metadata.get("sha256"),
                "uploaded_at": metadata.get("uploaded_at"),
                "size_bytes": report_meta.size_bytes,
                "url": report_meta.url,
            }

            # Remove duplicate entries (same correlation ID)
            correlation_id = metadata.get("correlation_id")
            if correlation_id:
                index_data["reports"] = [
                    r
                    for r in index_data.get("reports", [])
                    if r.get("correlation_id") != correlation_id
                ]

            index_data["reports"].append(entry)

            # Sort by uploaded_at (newest first)
            index_data["reports"].sort(
                key=lambda r: r.get("uploaded_at", ""), reverse=True
            )

            # Upload updated index
            index_json = json.dumps(index_data, indent=2, ensure_ascii=False)

            self.provider.push_report(
                index_path, index_json.encode("utf-8"), overwrite=True
            )

            logger.debug(
                f"[ReportSync] Updated index with {len(index_data['reports'])} reports"
            )

        except Exception as e:
            logger.warning(f"[ReportSync] Failed to update index: {e}")
            # Don't fail the whole upload if index update fails

    def list_reports(self) -> List[Dict[str, Any]]:
        """
        List all synchronized reports from index.

        Returns:
            List of report entries
        """
        index_path = "reports/index.json"

        try:
            index_content = self.provider.fetch_asset(index_path)
            index_data = json.loads(index_content.decode("utf-8"))
            return index_data.get("reports", [])

        except Exception as e:
            logger.warning(f"[ReportSync] Failed to load index: {e}")
            return []

    def fetch_report(self, remote_path: str) -> bytes:
        """
        Download report from cloud.

        Args:
            remote_path: Remote report path

        Returns:
            Report content
        """
        return self.provider.fetch_asset(remote_path)

    def get_latest_report(
        self, correlation_id: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Get latest report metadata.

        Args:
            correlation_id: Filter by correlation ID (None = overall latest)

        Returns:
            Report entry or None
        """
        reports = self.list_reports()

        if correlation_id:
            reports = [r for r in reports if r.get("correlation_id") == correlation_id]

        if reports:
            return reports[0]  # Already sorted by uploaded_at desc

        return None


def sync_report(
    provider_id: str,
    context: ProviderContext,
    report_path: Path,
    remote_path: str,
    **kwargs,
) -> ReportMeta:
    """
    Convenience function to sync a report.

    Args:
        provider_id: Provider identifier
        context: Provider context
        report_path: Local report file
        remote_path: Remote path
        **kwargs: Additional arguments for push_report

    Returns:
        Report metadata
    """
    provider = get_provider(provider_id, context)
    syncer = ReportSync(provider)
    return syncer.push_report(report_path, remote_path, **kwargs)
