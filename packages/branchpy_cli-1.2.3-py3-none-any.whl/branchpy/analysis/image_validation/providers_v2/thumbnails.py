"""
Thumbnail Generation and Storage

Generates optimized thumbnails for remote asset reuse.
"""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

try:
    from PIL import Image

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

from .base import Provider
from .errors import ProviderError

logger = logging.getLogger(__name__)


class ThumbnailGenerator:
    """
    Generates and manages thumbnails for cloud-stored images.

    Features:
    - 256px max edge with aspect ratio preservation
    - PNG output format
    - Hash-based invalidation
    - Remote storage via provider
    """

    TARGET_SIZE = 256
    OUTPUT_FORMAT = "PNG"

    def __init__(self, provider: Provider):
        """
        Initialize thumbnail generator.

        Args:
            provider: Connected provider instance
        """
        if not PIL_AVAILABLE:
            raise ProviderError(
                "Pillow library required for thumbnail generation. "
                "Install with: pip install Pillow"
            )

        self.provider = provider

    def generate_thumbnail(
        self, image_path: Path, *, max_size: int = TARGET_SIZE
    ) -> bytes:
        """
        Generate thumbnail from local image.

        Args:
            image_path: Path to source image
            max_size: Maximum edge dimension (default: 256px)

        Returns:
            PNG thumbnail bytes

        Raises:
            FileNotFoundError: If image doesn't exist
            ProviderError: If thumbnail generation fails
        """
        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        try:
            with Image.open(image_path) as img:
                # Convert to RGB if needed (handles RGBA, palette, etc.)
                if img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")

                # Calculate new size preserving aspect ratio
                width, height = img.size

                if width > height:
                    new_width = max_size
                    new_height = int((height / width) * max_size)
                else:
                    new_height = max_size
                    new_width = int((width / height) * max_size)

                # Resize using high-quality resampling
                thumbnail = img.resize(
                    (new_width, new_height), Image.Resampling.LANCZOS
                )

                # Save to bytes
                from io import BytesIO

                buffer = BytesIO()
                thumbnail.save(buffer, format=self.OUTPUT_FORMAT, optimize=True)

                png_bytes = buffer.getvalue()

                logger.debug(
                    f"[Thumbnail] Generated {new_width}x{new_height} thumbnail "
                    f"({len(png_bytes)} bytes) from {image_path.name}"
                )

                return png_bytes

        except Exception as e:
            raise ProviderError(f"Thumbnail generation failed: {e}")

    def generate_and_store(
        self,
        asset_id: str,
        image_path: Path,
        *,
        force: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Generate thumbnail and upload to provider.

        Args:
            asset_id: Remote asset identifier
            image_path: Local image path
            force: Force regeneration even if thumbnail exists
            metadata: Additional metadata (source hash, etc.)

        Returns:
            True if thumbnail was generated/stored, False if skipped
        """
        # Check if thumbnail already exists (unless force=True)
        if not force:
            existing = self.provider.fetch_thumbnail(asset_id)
            if existing:
                logger.debug(f"[Thumbnail] Skipping {asset_id} (already exists)")
                return False

        # Generate thumbnail
        png_bytes = self.generate_thumbnail(image_path)

        # Calculate source image hash
        image_hash = self._hash_file(image_path)

        # Merge metadata
        full_metadata = {
            "source_hash": image_hash,
            "generated_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
            "thumbnail_size": len(png_bytes),
            **(metadata or {}),
        }

        # Store thumbnail
        try:
            self.provider.store_thumbnail(asset_id, png_bytes, metadata=full_metadata)

            logger.info(f"[Thumbnail] Stored thumbnail for {asset_id}")
            return True

        except Exception as e:
            logger.error(f"[Thumbnail] Failed to store {asset_id}: {e}")
            raise

    def invalidate_if_changed(self, asset_id: str, current_image_path: Path) -> bool:
        """
        Check if thumbnail needs regeneration (source changed).

        Args:
            asset_id: Remote asset identifier
            current_image_path: Current local image path

        Returns:
            True if thumbnail was invalidated, False otherwise
        """
        # Fetch existing thumbnail metadata (simplified)
        # In production, would fetch metadata from provider

        # For now, just check if file exists
        existing = self.provider.fetch_thumbnail(asset_id)

        if not existing:
            return False  # No thumbnail to invalidate

        # Calculate current hash
        current_hash = self._hash_file(current_image_path)

        # TODO: Compare with stored hash
        # For now, assume changed
        logger.info(f"[Thumbnail] Invalidated {asset_id} (source changed)")
        return True

    def rebuild_all(
        self,
        local_assets: Dict[str, Path],
        *,
        force: bool = False,
        batch_size: int = 10,
    ) -> Tuple[int, int]:
        """
        Rebuild thumbnails for multiple assets.

        Args:
            local_assets: Map of asset_id -> local image path
            force: Force regeneration for all
            batch_size: Process in batches (for progress logging)

        Returns:
            Tuple of (generated_count, skipped_count)
        """
        generated = 0
        skipped = 0
        total = len(local_assets)

        for idx, (asset_id, image_path) in enumerate(local_assets.items(), 1):
            if idx % batch_size == 0:
                logger.info(
                    f"[Thumbnail] Progress: {idx}/{total} "
                    f"(generated={generated}, skipped={skipped})"
                )

            try:
                if self.generate_and_store(asset_id, image_path, force=force):
                    generated += 1
                else:
                    skipped += 1
            except Exception as e:
                logger.error(f"[Thumbnail] Error processing {asset_id}: {e}")
                skipped += 1

        logger.info(
            f"[Thumbnail] Rebuild complete: "
            f"{generated} generated, {skipped} skipped, {total} total"
        )

        return generated, skipped

    @staticmethod
    def _hash_file(path: Path) -> str:
        """Calculate SHA-256 hash of file"""
        hasher = hashlib.sha256()

        with open(path, "rb") as f:
            while chunk := f.read(8192):
                hasher.update(chunk)

        return hasher.hexdigest()
