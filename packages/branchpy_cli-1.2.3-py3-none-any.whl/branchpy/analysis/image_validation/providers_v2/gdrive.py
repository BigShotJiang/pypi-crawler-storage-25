"""
Google Drive Provider - Drive API v3 Integration

Authenticates via OAuth2 and provides access to Google Drive files.

Configuration:
{
    "client_id": "...",
    "client_secret": "...",
    "refresh_token": "..."
}
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Iterator, Optional

try:
    import requests  # type: ignore

    REQUESTS_AVAILABLE = True
except ImportError:

    class _RequestsStub:  # type: ignore
        class RequestException(Exception):
            pass

        def __getattr__(self, name):
            raise ProviderError("requests library not installed", provider_id="gdrive")

    requests = _RequestsStub()  # type: ignore
    REQUESTS_AVAILABLE = False

from .base import (
    AssetType,
    DeltaResult,
    ProviderContext,
    ProviderHealth,
    ProviderStatus,
    RemoteAsset,
    ReportMeta,
)
from .errors import AuthenticationError, ConflictError
from .errors import ConnectionError as ProviderConnectionError
from .errors import NotFoundError, ProviderError, QuotaExceededError, RateLimitError
from .registry import ProviderRegistry

logger = logging.getLogger(__name__)


@ProviderRegistry.register
class GoogleDriveProvider:
    """
    Google Drive cloud storage provider.

    Uses Google Drive API v3 for file operations.
    """

    id = "gdrive"
    display_name = "Google Drive"

    DRIVE_API_BASE = "https://www.googleapis.com/drive/v3"
    TOKEN_URL = "https://oauth2.googleapis.com/token"

    # MIME types
    IMAGE_MIME_TYPES = {
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "image/bmp",
        "image/tiff",
    }

    FOLDER_MIME_TYPE = "application/vnd.google-apps.folder"

    def __init__(self):
        if not REQUESTS_AVAILABLE:
            raise ProviderError(
                "requests library not available. Install with: pip install requests",
                provider_id=self.id,
            )

        self._context: Optional[ProviderContext] = None
        self._access_token: Optional[str] = None
        self._token_expires: Optional[datetime] = None

    def connect(self, context: ProviderContext) -> None:
        """Initialize connection and obtain access token"""
        self._context = context
        self._refresh_access_token()

        logger.info(f"[{self.id}] Connected successfully")

    def _refresh_access_token(self) -> None:
        """Obtain fresh access token using refresh token"""
        if not self._context:
            raise AuthenticationError("Provider not initialized", provider_id=self.id)

        refresh_token = self._context.get_credential("refresh_token")
        client_id = self._context.get_credential("client_id")
        client_secret = self._context.get_credential("client_secret")

        if not all([refresh_token, client_id, client_secret]):
            raise AuthenticationError(
                "Missing credentials: refresh_token, client_id, or client_secret",
                provider_id=self.id,
            )

        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret,
        }

        try:
            response = requests.post(
                self.TOKEN_URL, data=payload, timeout=self._context.timeout
            )
            response.raise_for_status()

            data = response.json()
            self._access_token = data["access_token"]

            # Calculate expiry
            expires_in = data.get("expires_in", 3600)
            self._token_expires = datetime.utcnow() + timedelta(seconds=expires_in - 60)

            logger.debug(f"[{self.id}] Access token refreshed")

        except requests.RequestException as e:
            raise AuthenticationError(f"Token refresh failed: {e}", provider_id=self.id)

    def _ensure_token(self) -> None:
        """Ensure access token is valid (refresh if needed)"""
        if not self._access_token or not self._token_expires:
            self._refresh_access_token()
        elif datetime.utcnow() >= self._token_expires:
            self._refresh_access_token()

    def _headers(self) -> Dict[str, str]:
        """Build request headers with auth"""
        self._ensure_token()
        return {
            "Authorization": f"Bearer {self._access_token}",
            "User-Agent": self._context.user_agent if self._context else "BranchPy/1.0",
        }

    def _handle_error(self, response) -> None:
        """Handle Drive API error responses"""
        if response.status_code == 401:
            self._refresh_access_token()
            raise AuthenticationError(
                "Authentication failed (token refreshed, retry)", provider_id=self.id
            )

        elif response.status_code == 404:
            raise NotFoundError("Resource not found", provider_id=self.id)

        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise RateLimitError(
                "Rate limit exceeded", provider_id=self.id, retry_after=retry_after
            )

        elif response.status_code == 403:
            # Check if quota error
            try:
                error_data = response.json()
                if "quotaExceeded" in str(error_data):
                    raise QuotaExceededError(
                        "Storage quota exceeded",
                        provider_id=self.id,
                        quota_type="storage",
                    )
            except Exception:
                pass

            raise ProviderError(f"Forbidden: {response.text}", provider_id=self.id)

        else:
            try:
                error_data = response.json()
                message = error_data.get("error", {}).get("message", "Unknown error")
            except Exception:
                message = response.text

            raise ProviderError(
                f"Drive API error ({response.status_code}): {message}",
                provider_id=self.id,
            )

    def _classify_asset_type(self, item: Dict[str, Any]) -> AssetType:
        """Classify Drive API item as asset type"""
        mime_type = item.get("mimeType", "")

        if mime_type == self.FOLDER_MIME_TYPE:
            return AssetType.FOLDER
        elif mime_type in self.IMAGE_MIME_TYPES:
            return AssetType.IMAGE
        elif mime_type in ("application/json", "text/html"):
            return AssetType.REPORT
        elif "thumbnail" in item.get("name", "").lower():
            return AssetType.THUMBNAIL
        else:
            return AssetType.UNKNOWN

    def _find_folder_id(self, folder_path: str) -> Optional[str]:
        """Find folder ID by path"""
        if not folder_path:
            return "root"

        # Split path and traverse
        parts = folder_path.strip("/").split("/")
        current_id = "root"

        for part in parts:
            # Search for folder with this name under current parent
            query = f"name = '{part}' and '{current_id}' in parents and mimeType = '{self.FOLDER_MIME_TYPE}' and trashed = false"

            url = f"{self.DRIVE_API_BASE}/files"
            params = {
                "q": query,
                "fields": "files(id, name)",
                "pageSize": 1,
            }

            try:
                response = requests.get(
                    url,
                    headers=self._headers(),
                    params=params,
                    timeout=self._context.timeout if self._context else 30,
                )

                if not response.ok:
                    self._handle_error(response)

                data = response.json()
                files = data.get("files", [])

                if not files:
                    return None  # Folder not found

                current_id = files[0]["id"]

            except requests.RequestException as e:
                raise ProviderConnectionError(
                    f"Folder lookup failed: {e}", provider_id=self.id
                )

        return current_id

    def list_assets(
        self,
        folder: Optional[str] = None,
        asset_type: Optional[AssetType] = None,
        recursive: bool = False,
    ) -> Iterator[RemoteAsset]:
        """List Google Drive files"""
        folder_id = self._find_folder_id(folder) if folder else "root"

        if not folder_id:
            raise NotFoundError(f"Folder not found: {folder}", provider_id=self.id)

        # Build query
        query = f"'{folder_id}' in parents and trashed = false"

        if asset_type == AssetType.IMAGE:
            mime_conditions = " or ".join(
                f"mimeType = '{mt}'" for mt in self.IMAGE_MIME_TYPES
            )
            query += f" and ({mime_conditions})"

        url = f"{self.DRIVE_API_BASE}/files"
        params = {
            "q": query,
            "fields": "nextPageToken, files(id, name, mimeType, size, modifiedTime, webViewLink, parents)",
            "pageSize": 100,
        }

        page_token = None

        while True:
            if page_token:
                params["pageToken"] = page_token

            try:
                response = requests.get(
                    url,
                    headers=self._headers(),
                    params=params,
                    timeout=self._context.timeout if self._context else 30,
                )

                if not response.ok:
                    self._handle_error(response)

                data = response.json()

                for item in data.get("files", []):
                    item_type = self._classify_asset_type(item)

                    # Filter by asset type if specified
                    if asset_type and item_type != asset_type:
                        if item_type == AssetType.FOLDER and recursive:
                            # Recurse into folder
                            folder_name = item.get("name", "")
                            subfolder_path = (
                                f"{folder}/{folder_name}" if folder else folder_name
                            )
                            yield from self.list_assets(
                                subfolder_path, asset_type, recursive
                            )
                        continue

                    # Build logical path (Drive doesn't store full paths)
                    path = f"{folder}/{item['name']}" if folder else item["name"]

                    asset = RemoteAsset(
                        id=item["id"],
                        name=item["name"],
                        path=path,
                        asset_type=item_type,
                        size_bytes=(
                            int(item.get("size", 0)) if item.get("size") else None
                        ),
                        mime_type=item.get("mimeType"),
                        modified_at=self._parse_datetime(item.get("modifiedTime")),
                        metadata={
                            "webViewLink": item.get("webViewLink"),
                        },
                    )

                    yield asset

                    # Recurse if needed
                    if recursive and item_type == AssetType.FOLDER:
                        folder_name = item.get("name", "")
                        subfolder_path = (
                            f"{folder}/{folder_name}" if folder else folder_name
                        )
                        yield from self.list_assets(
                            subfolder_path, asset_type, recursive
                        )

                # Pagination
                page_token = data.get("nextPageToken")
                if not page_token:
                    break

            except requests.RequestException as e:
                raise ProviderConnectionError(f"List failed: {e}", provider_id=self.id)

    def fetch_asset(self, asset_id: str) -> bytes:
        """Download asset content"""
        url = f"{self.DRIVE_API_BASE}/files/{asset_id}?alt=media"

        try:
            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 60,
            )

            if not response.ok:
                self._handle_error(response)

            return response.content

        except requests.RequestException as e:
            raise ProviderConnectionError(f"Download failed: {e}", provider_id=self.id)

    def push_report(
        self,
        path: str,
        content: bytes,
        *,
        overwrite: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReportMeta:
        """Upload report to Google Drive"""
        # Parse path to get parent folder and filename
        path_parts = path.strip("/").split("/")
        filename = path_parts[-1]
        folder_path = "/".join(path_parts[:-1]) if len(path_parts) > 1 else None

        # Find or create parent folder
        parent_id = self._find_folder_id(folder_path) if folder_path else "root"

        if not parent_id and folder_path:
            # Create folder hierarchy
            parent_id = self._create_folder_hierarchy(folder_path)

        # Check if file exists
        query = f"name = '{filename}' and '{parent_id}' in parents and trashed = false"

        check_url = f"{self.DRIVE_API_BASE}/files"
        check_params = {
            "q": query,
            "fields": "files(id)",
            "pageSize": 1,
        }

        try:
            check_response = requests.get(
                check_url,
                headers=self._headers(),
                params=check_params,
                timeout=self._context.timeout if self._context else 30,
            )

            if check_response.ok:
                files = check_response.json().get("files", [])

                if files and not overwrite:
                    raise ConflictError(
                        f"File already exists: {path}",
                        provider_id=self.id,
                        conflict_type="duplicate",
                    )

                if files and overwrite:
                    # Update existing file
                    file_id = files[0]["id"]
                    return self._update_file(file_id, content, filename)

            # Create new file
            assert (
                parent_id is not None
            ), "parent_id should have been resolved or created"
            return self._create_file(parent_id, filename, content, metadata)

        except requests.RequestException as e:
            raise ProviderConnectionError(f"Upload failed: {e}", provider_id=self.id)

    def _create_folder_hierarchy(self, folder_path: str) -> str:
        """Create nested folders and return final folder ID"""
        parts = folder_path.strip("/").split("/")
        current_id = "root"

        for part in parts:
            # Check if folder exists
            query = f"name = '{part}' and '{current_id}' in parents and mimeType = '{self.FOLDER_MIME_TYPE}' and trashed = false"

            check_url = f"{self.DRIVE_API_BASE}/files"
            check_params = {
                "q": query,
                "fields": "files(id)",
                "pageSize": 1,
            }

            response = requests.get(
                check_url,
                headers=self._headers(),
                params=check_params,
                timeout=self._context.timeout if self._context else 30,
            )

            if response.ok:
                files = response.json().get("files", [])

                if files:
                    current_id = files[0]["id"]
                    continue

            # Create folder
            create_url = f"{self.DRIVE_API_BASE}/files"
            file_metadata = {
                "name": part,
                "mimeType": self.FOLDER_MIME_TYPE,
                "parents": [current_id],
            }

            response = requests.post(
                create_url,
                headers=self._headers(),
                json=file_metadata,
                timeout=self._context.timeout if self._context else 30,
            )

            if not response.ok:
                self._handle_error(response)

            current_id = response.json()["id"]

        return current_id

    def _create_file(
        self,
        parent_id: str,
        filename: str,
        content: bytes,
        metadata: Optional[Dict[str, Any]],
    ) -> ReportMeta:
        """Create new file"""
        # Multipart upload

        # Metadata
        file_metadata = {"name": filename, "parents": [parent_id]}

        # Determine MIME type
        if filename.endswith(".json"):
            mime_type = "application/json"
        elif filename.endswith(".html"):
            mime_type = "text/html"
        else:
            mime_type = "application/octet-stream"

        url = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,size,modifiedTime"

        # Build multipart request
        boundary = "===============7330845974216740156=="
        headers = self._headers()
        headers["Content-Type"] = f"multipart/related; boundary={boundary}"

        body = (
            f"--{boundary}\r\n"
            f"Content-Type: application/json; charset=UTF-8\r\n\r\n"
            f"{__import__('json').dumps(file_metadata)}\r\n"
            f"--{boundary}\r\n"
            f"Content-Type: {mime_type}\r\n\r\n"
        ).encode("utf-8")

        body += content
        body += f"\r\n--{boundary}--\r\n".encode("utf-8")

        response = requests.post(
            url,
            headers=headers,
            data=body,
            timeout=self._context.timeout if self._context else 60,
        )

        if not response.ok:
            self._handle_error(response)

        data = response.json()

        return ReportMeta(
            id=data["id"],
            path=f"{parent_id}/{filename}",
            url=data.get("webViewLink"),
            uploaded_at=self._parse_datetime(data.get("modifiedTime")),
            size_bytes=int(data.get("size", 0)) if data.get("size") else None,
        )

    def _update_file(self, file_id: str, content: bytes, filename: str) -> ReportMeta:
        """Update existing file"""
        url = f"https://www.googleapis.com/upload/drive/v3/files/{file_id}?uploadType=media&fields=id,name,webViewLink,size,modifiedTime"

        # Determine MIME type
        if filename.endswith(".json"):
            mime_type = "application/json"
        elif filename.endswith(".html"):
            mime_type = "text/html"
        else:
            mime_type = "application/octet-stream"

        headers = self._headers()
        headers["Content-Type"] = mime_type

        response = requests.patch(
            url,
            headers=headers,
            data=content,
            timeout=self._context.timeout if self._context else 60,
        )

        if not response.ok:
            self._handle_error(response)

        data = response.json()

        return ReportMeta(
            id=data["id"],
            path=filename,
            url=data.get("webViewLink"),
            uploaded_at=self._parse_datetime(data.get("modifiedTime")),
            size_bytes=int(data.get("size", 0)) if data.get("size") else None,
        )

    def health_check(self) -> ProviderHealth:
        """Check Google Drive connectivity and quota"""
        start_time = time.time()

        try:
            url = f"{self.DRIVE_API_BASE}/about?fields=storageQuota,user"

            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 10,
            )

            latency_ms = (time.time() - start_time) * 1000

            if not response.ok:
                self._handle_error(response)

            data = response.json()
            quota = data.get("storageQuota", {})

            return ProviderHealth(
                status=ProviderStatus.HEALTHY,
                latency_ms=latency_ms,
                quota_used=int(quota.get("usage", 0)),
                quota_total=int(quota.get("limit", 0)) if quota.get("limit") else None,
                metadata={
                    "user": data.get("user", {}).get("emailAddress"),
                },
            )

        except AuthenticationError as e:
            return ProviderHealth(status=ProviderStatus.UNAUTHORIZED, message=str(e))

        except ProviderConnectionError as e:
            return ProviderHealth(status=ProviderStatus.UNAVAILABLE, message=str(e))

        except Exception as e:
            return ProviderHealth(status=ProviderStatus.DEGRADED, message=str(e))

    def fetch_thumbnail(self, asset_id: str) -> Optional[bytes]:
        """Fetch Google Drive thumbnail"""
        # Get thumbnail link
        url = f"{self.DRIVE_API_BASE}/files/{asset_id}?fields=thumbnailLink"

        try:
            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 10,
            )

            if not response.ok:
                return None

            data = response.json()
            thumbnail_link = data.get("thumbnailLink")

            if not thumbnail_link:
                return None

            # Download thumbnail
            thumb_response = requests.get(
                thumbnail_link, headers=self._headers(), timeout=10
            )

            if thumb_response.ok:
                return thumb_response.content

            return None

        except Exception as e:
            logger.warning(f"[{self.id}] Failed to fetch thumbnail: {e}")
            return None

    def store_thumbnail(
        self,
        asset_id: str,
        png_bytes: bytes,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Store custom thumbnail"""
        thumbnail_path = f".thumbnails/{asset_id}.png"

        try:
            self.push_report(
                thumbnail_path, png_bytes, overwrite=True, metadata=metadata
            )
        except Exception as e:
            logger.error(f"[{self.id}] Failed to store thumbnail: {e}")
            raise

    def supports_delta(self) -> bool:
        """Google Drive supports changes API"""
        return True

    def list_delta(self, cursor: Optional[str] = None) -> DeltaResult:
        """List changes using changes API"""
        url = f"{self.DRIVE_API_BASE}/changes"

        if cursor:
            params = {
                "pageToken": cursor,
                "fields": "nextPageToken, newStartPageToken, changes(fileId, removed, file(id, name, mimeType, size, modifiedTime, parents))",
            }
        else:
            # Get initial start token
            start_url = f"{self.DRIVE_API_BASE}/changes/startPageToken"
            start_response = requests.get(
                start_url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 30,
            )

            if not start_response.ok:
                self._handle_error(start_response)

            start_token = start_response.json()["startPageToken"]
            params = {
                "pageToken": start_token,
                "fields": "nextPageToken, newStartPageToken, changes(fileId, removed, file(id, name, mimeType, size, modifiedTime, parents))",
            }

        try:
            response = requests.get(
                url,
                headers=self._headers(),
                params=params,
                timeout=self._context.timeout if self._context else 30,
            )

            if not response.ok:
                self._handle_error(response)

            data = response.json()

            added = []
            modified = []
            removed = []

            for change in data.get("changes", []):
                if change.get("removed") or not change.get("file"):
                    removed.append(change["fileId"])
                    continue

                file_data = change["file"]
                asset_type = self._classify_asset_type(file_data)

                asset = RemoteAsset(
                    id=file_data["id"],
                    name=file_data["name"],
                    path=file_data["name"],  # Simplified path
                    asset_type=asset_type,
                    size_bytes=(
                        int(file_data.get("size", 0)) if file_data.get("size") else None
                    ),
                    mime_type=file_data.get("mimeType"),
                    modified_at=self._parse_datetime(file_data.get("modifiedTime")),
                )

                # Simplified: all non-removed are "modified"
                modified.append(asset)

            next_cursor = data.get("nextPageToken") or data.get("newStartPageToken")

            return DeltaResult(
                cursor=next_cursor,
                added=added,
                modified=modified,
                removed=removed,
                has_more="nextPageToken" in data,
            )

        except requests.RequestException as e:
            raise ProviderConnectionError(
                f"Delta query failed: {e}", provider_id=self.id
            )

    def disconnect(self) -> None:
        """Clean up resources"""
        self._access_token = None
        self._token_expires = None
        self._context = None

    @staticmethod
    def _parse_datetime(dt_str: Optional[str]) -> Optional[datetime]:
        """Parse RFC 3339 datetime"""
        if not dt_str:
            return None

        try:
            # Replace 'Z' with '+00:00' for fromisoformat
            if dt_str.endswith("Z"):
                dt_str = dt_str[:-1] + "+00:00"
            return datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        except Exception:
            return None
