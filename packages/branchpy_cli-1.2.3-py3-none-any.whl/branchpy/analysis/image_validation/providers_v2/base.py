"""
Provider Base Types and Protocols

Core interfaces and data models for cloud provider integration.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Iterator, List, Optional, Protocol


class ProviderStatus(Enum):
    """Provider health status"""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"
    UNAUTHORIZED = "unauthorized"


class AssetType(Enum):
    """Remote asset type"""

    IMAGE = "image"
    REPORT = "report"
    THUMBNAIL = "thumbnail"
    FOLDER = "folder"
    UNKNOWN = "unknown"


@dataclass
class CredentialsV2:
    """
    Unified credentials schema for provider adapters.

    Replaces loose Dict[str, Any] with typed fields.
    All providers should use this schema.
    """

    provider: str  # "m-files", "onedrive", "webdav", etc.

    # Common OAuth2 fields
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    token_expires_at: Optional[datetime] = None

    # Basic auth fields
    username: Optional[str] = None
    password: Optional[str] = None

    # API key fields
    api_key: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None

    # M-Files specific
    vault_guid: Optional[str] = None

    # WebDAV specific
    base_url: Optional[str] = None

    # Additional metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_oauth(self) -> bool:
        """Check if using OAuth2"""
        return self.access_token is not None

    def is_basic_auth(self) -> bool:
        """Check if using basic auth"""
        return self.username is not None and self.password is not None

    def is_api_key(self) -> bool:
        """Check if using API key auth"""
        return self.api_key is not None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (for legacy Dict[str, Any] APIs)"""
        result = {"provider": self.provider}

        if self.access_token:
            result["access_token"] = self.access_token
        if self.refresh_token:
            result["refresh_token"] = self.refresh_token
        if self.token_expires_at:
            result["token_expires_at"] = self.token_expires_at.isoformat()
        if self.username:
            result["username"] = self.username
        if self.password:
            result["password"] = self.password
        if self.api_key:
            result["api_key"] = self.api_key
        if self.client_id:
            result["client_id"] = self.client_id
        if self.client_secret:
            result["client_secret"] = self.client_secret
        if self.vault_guid:
            result["vault_guid"] = self.vault_guid
        if self.base_url:
            result["base_url"] = self.base_url

        result.update(self.metadata)
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CredentialsV2":
        """Create from dictionary"""
        # Extract known fields
        known_fields = {
            "provider",
            "access_token",
            "refresh_token",
            "token_expires_at",
            "username",
            "password",
            "api_key",
            "client_id",
            "client_secret",
            "vault_guid",
            "base_url",
        }

        creds_dict = {}
        metadata = {}

        for key, value in data.items():
            if key in known_fields:
                # Handle datetime conversion
                if key == "token_expires_at" and isinstance(value, str):
                    creds_dict[key] = datetime.fromisoformat(value)
                else:
                    creds_dict[key] = value
            else:
                metadata[key] = value

        creds_dict["metadata"] = metadata
        return cls(**creds_dict)


@dataclass
class ProviderContext:
    """
    Execution context for provider operations.

    Contains credentials, configuration, and runtime state.
    """

    provider_id: str
    credentials: Dict[str, Any]  # TODO: Migrate to CredentialsV2
    config: Dict[str, Any] = field(default_factory=dict)
    correlation_id: Optional[str] = None
    user_agent: str = "BranchPy-ImageValidation/1.0"
    timeout: int = 30  # seconds

    def get_credential(self, key: str, default: Any = None) -> Any:
        """Safely retrieve credential"""
        return self.credentials.get(key, default)

    def get_config(self, key: str, default: Any = None) -> Any:
        """Safely retrieve config value"""
        return self.config.get(key, default)


@dataclass
class RemoteAsset:
    """
    Represents a remote file or folder.
    """

    id: str  # provider-specific unique ID
    name: str
    path: str  # logical path (may be virtual)
    asset_type: AssetType
    size_bytes: Optional[int] = None
    mime_type: Optional[str] = None
    modified_at: Optional[datetime] = None
    etag: Optional[str] = None  # for conflict detection
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_image(self) -> bool:
        """Check if asset is an image"""
        return self.asset_type == AssetType.IMAGE

    def is_folder(self) -> bool:
        """Check if asset is a folder"""
        return self.asset_type == AssetType.FOLDER

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "path": self.path,
            "asset_type": self.asset_type.value,
            "size_bytes": self.size_bytes,
            "mime_type": self.mime_type,
            "modified_at": self.modified_at.isoformat() if self.modified_at else None,
            "etag": self.etag,
            "metadata": self.metadata,
        }


@dataclass
class ReportMeta:
    """
    Metadata for uploaded report.
    """

    id: str  # provider-specific ID
    path: str  # remote path
    url: Optional[str] = None  # direct access URL (if available)
    version: Optional[str] = None  # report version/hash
    uploaded_at: Optional[datetime] = None
    size_bytes: Optional[int] = None
    etag: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary"""
        return {
            "id": self.id,
            "path": self.path,
            "url": self.url,
            "version": self.version,
            "uploaded_at": self.uploaded_at.isoformat() if self.uploaded_at else None,
            "size_bytes": self.size_bytes,
            "etag": self.etag,
        }


@dataclass
class ProviderHealth:
    """
    Provider health check result.
    """

    status: ProviderStatus
    message: Optional[str] = None
    latency_ms: Optional[float] = None  # API response time
    quota_used: Optional[int] = None  # bytes used
    quota_total: Optional[int] = None  # total bytes available
    last_sync: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_healthy(self) -> bool:
        """Check if provider is healthy"""
        return self.status == ProviderStatus.HEALTHY

    def quota_percentage(self) -> Optional[float]:
        """Calculate quota usage percentage"""
        if self.quota_used is not None and self.quota_total is not None:
            return (self.quota_used / self.quota_total) * 100
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary"""
        return {
            "status": self.status.value,
            "message": self.message,
            "latency_ms": self.latency_ms,
            "quota_used": self.quota_used,
            "quota_total": self.quota_total,
            "quota_percentage": self.quota_percentage(),
            "last_sync": self.last_sync.isoformat() if self.last_sync else None,
            "metadata": self.metadata,
        }


@dataclass
class DeltaResult:
    """
    Result from incremental (delta) listing.
    """

    cursor: Optional[str]  # opaque cursor for next delta
    added: List[RemoteAsset] = field(default_factory=list)
    modified: List[RemoteAsset] = field(default_factory=list)
    removed: List[str] = field(default_factory=list)  # removed IDs
    has_more: bool = False

    def total_changes(self) -> int:
        """Total number of changes"""
        return len(self.added) + len(self.modified) + len(self.removed)


class Provider(Protocol):
    """
    Protocol defining cloud provider interface.

    All provider implementations must satisfy this contract.
    """

    # Provider metadata
    id: str  # unique identifier (e.g., 'onedrive', 'gdrive')
    display_name: str  # human-readable name

    def connect(self, context: ProviderContext) -> None:
        """
        Initialize connection and authenticate.

        Args:
            context: Provider context with credentials

        Raises:
            AuthenticationError: If authentication fails
            ConnectionError: If connection cannot be established
        """
        ...

    def list_assets(
        self,
        folder: Optional[str] = None,
        asset_type: Optional[AssetType] = None,
        recursive: bool = False,
    ) -> Iterator[RemoteAsset]:
        """
        List remote assets.

        Args:
            folder: Folder path (None = root)
            asset_type: Filter by type (None = all)
            recursive: Recurse into subfolders

        Yields:
            RemoteAsset objects

        Raises:
            NotFoundError: If folder doesn't exist
            ProviderError: On API errors
        """
        ...

    def fetch_asset(self, asset_id: str) -> bytes:
        """
        Download asset content.

        Args:
            asset_id: Provider-specific asset ID

        Returns:
            Asset content as bytes

        Raises:
            NotFoundError: If asset doesn't exist
            QuotaExceededError: If download quota exceeded
            ProviderError: On API errors
        """
        ...

    def push_report(
        self,
        path: str,
        content: bytes,
        *,
        overwrite: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReportMeta:
        """
        Upload validation report to cloud.

        Args:
            path: Remote path (e.g., 'reports/2025-01/report.json')
            content: Report content (JSON or HTML bytes)
            overwrite: Allow overwriting existing file
            metadata: Optional metadata tags

        Returns:
            Report metadata with upload details

        Raises:
            ConflictError: If file exists and overwrite=False
            QuotaExceededError: If storage quota exceeded
            ProviderError: On API errors
        """
        ...

    def health_check(self) -> ProviderHealth:
        """
        Check provider health and connectivity.

        Returns:
            Health status with latency and quota info
        """
        ...

    def fetch_thumbnail(self, asset_id: str) -> Optional[bytes]:
        """
        Fetch pre-generated thumbnail (if available).

        Args:
            asset_id: Provider-specific asset ID

        Returns:
            PNG thumbnail bytes or None if not available
        """
        ...

    def store_thumbnail(
        self,
        asset_id: str,
        png_bytes: bytes,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Store generated thumbnail.

        Args:
            asset_id: Source asset ID
            png_bytes: 256px PNG thumbnail
            metadata: Optional metadata (source hash, etc.)

        Raises:
            QuotaExceededError: If storage quota exceeded
            ProviderError: On API errors
        """
        ...

    def supports_delta(self) -> bool:
        """Check if provider supports delta (incremental) listing"""
        return False

    def list_delta(self, cursor: Optional[str] = None) -> DeltaResult:
        """
        List changes since last cursor.

        Args:
            cursor: Opaque cursor from previous delta (None = initial)

        Returns:
            Delta result with changes and new cursor

        Raises:
            NotImplementedError: If provider doesn't support delta
        """
        raise NotImplementedError(f"{self.id} does not support delta listing")

    def disconnect(self) -> None:
        """Clean up resources (optional)"""
        pass
