"""
Provider Registry - Dynamic Provider Discovery and Management

Manages available cloud providers and provides unified access interface.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Type

from .base import Provider, ProviderContext, ProviderHealth
from .errors import ProviderError, ValidationError

logger = logging.getLogger(__name__)


class ProviderRegistry:
    """
    Central registry for cloud provider implementations.

    Providers are registered at module import time and can be
    dynamically instantiated by ID.
    """

    _providers: Dict[str, Type[Provider]] = {}
    _instances: Dict[str, Provider] = {}

    @classmethod
    def register(cls, provider_class: Type[Provider]) -> Type[Provider]:
        """
        Register a provider implementation.

        Usage:
            @ProviderRegistry.register
            class OneDriveProvider:
                id = "onedrive"
                ...

        Args:
            provider_class: Provider class to register

        Returns:
            The provider class (for decorator pattern)
        """
        if not hasattr(provider_class, "id"):
            raise ValidationError(
                f"Provider class {provider_class.__name__} missing 'id' attribute"
            )

        provider_id = provider_class.id

        if provider_id in cls._providers:
            logger.warning(f"Provider '{provider_id}' already registered, overwriting")

        cls._providers[provider_id] = provider_class
        logger.debug(f"Registered provider: {provider_id}")

        return provider_class

    @classmethod
    def get_provider(
        cls,
        provider_id: str,
        context: Optional[ProviderContext] = None,
        singleton: bool = True,
    ) -> Provider:
        """
        Get provider instance by ID.

        Args:
            provider_id: Provider identifier
            context: Provider context (for initialization)
            singleton: Reuse existing instance if available

        Returns:
            Provider instance

        Raises:
            ProviderError: If provider not found or instantiation fails
        """
        if provider_id not in cls._providers:
            available = ", ".join(cls.list_provider_ids())
            raise ProviderError(
                f"Provider '{provider_id}' not found. " f"Available: {available}"
            )

        # Return singleton instance if available
        if singleton and provider_id in cls._instances:
            return cls._instances[provider_id]

        # Instantiate provider
        provider_class = cls._providers[provider_id]

        try:
            instance = provider_class()

            # Initialize connection if context provided
            if context:
                instance.connect(context)

            if singleton:
                cls._instances[provider_id] = instance

            return instance

        except Exception as e:
            raise ProviderError(
                f"Failed to instantiate provider '{provider_id}': {e}",
                provider_id=provider_id,
            )

    @classmethod
    def list_provider_ids(cls) -> List[str]:
        """List all registered provider IDs"""
        return list(cls._providers.keys())

    @classmethod
    def get_provider_info(cls, provider_id: str) -> Dict[str, Any]:
        """
        Get provider metadata.

        Returns:
            {
                "id": "onedrive",
                "display_name": "Microsoft OneDrive",
                "class": "OneDriveProvider"
            }
        """
        if provider_id not in cls._providers:
            raise ProviderError(f"Provider '{provider_id}' not found")

        provider_class = cls._providers[provider_id]

        return {
            "id": provider_id,
            "display_name": getattr(provider_class, "display_name", provider_id),
            "class": provider_class.__name__,
            # capability flags are booleans
            "supports_delta": bool(
                getattr(
                    provider_class,
                    "supports_delta",
                    hasattr(provider_class, "list_delta"),
                )
            ),
        }

    @classmethod
    def check_all_health(
        cls, contexts: Dict[str, ProviderContext]
    ) -> Dict[str, ProviderHealth]:
        """
        Check health of all configured providers.

        Args:
            contexts: Map of provider_id -> context

        Returns:
            Map of provider_id -> health status
        """
        results = {}

        for provider_id, context in contexts.items():
            try:
                provider = cls.get_provider(provider_id, context, singleton=False)
                health = provider.health_check()
                results[provider_id] = health
            except Exception as e:
                logger.error(f"Health check failed for {provider_id}: {e}")
                from .base import ProviderStatus

                results[provider_id] = ProviderHealth(
                    status=ProviderStatus.UNAVAILABLE, message=str(e)
                )

        return results

    @classmethod
    def clear_instances(cls) -> None:
        """Clear all singleton instances (useful for testing)"""
        for instance in cls._instances.values():
            try:
                instance.disconnect()
            except Exception as e:
                logger.warning(f"Error disconnecting provider: {e}")

        cls._instances.clear()


# Convenience function
def get_provider(
    provider_id: str, context: Optional[ProviderContext] = None
) -> Provider:
    """
    Get provider instance (convenience wrapper).

    Args:
        provider_id: Provider identifier
        context: Optional provider context

    Returns:
        Provider instance
    """
    return ProviderRegistry.get_provider(provider_id, context)


def list_providers() -> List[str]:
    """List all available provider IDs"""
    return ProviderRegistry.list_provider_ids()
