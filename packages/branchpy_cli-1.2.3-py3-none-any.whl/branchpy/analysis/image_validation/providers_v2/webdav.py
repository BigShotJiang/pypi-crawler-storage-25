"""
WebDAV Provider - Generic WebDAV Protocol Support

Configuration:
{
    "url": "https://webdav.example.com/",
    "username": "...",
    "password": "..."
}
"""

from __future__ import annotations

import logging
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Any, Dict, Iterator, Optional

try:
    import requests
    from requests.auth import HTTPBasicAuth

    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from ..base import (
    AssetType,
    ProviderContext,
    ProviderHealth,
    ProviderStatus,
    RemoteAsset,
    ReportMeta,
)
from ..errors import AuthenticationError, ConflictError, ProviderError
from ..registry import ProviderRegistry

logger = logging.getLogger(__name__)


@ProviderRegistry.register
class WebDAVProvider:
    """Generic WebDAV provider for legacy systems"""

    id = "webdav"
    display_name = "WebDAV"

    IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff"}

    def __init__(self):
        if not REQUESTS_AVAILABLE:
            raise ProviderError("requests library required", provider_id=self.id)

        self._context: Optional[ProviderContext] = None
        self._base_url: Optional[str] = None
        self._auth: Optional[HTTPBasicAuth] = None

    def connect(self, context: ProviderContext) -> None:
        self._context = context
        self._base_url = context.get_credential("url", "").rstrip("/")
        username = context.get_credential("username")
        password = context.get_credential("password")

        if not all([self._base_url, username, password]):
            raise AuthenticationError(
                "Missing url, username, or password", provider_id=self.id
            )

        self._auth = HTTPBasicAuth(username, password)
        logger.info(f"[{self.id}] Connected to {self._base_url}")

    def list_assets(
        self,
        folder: Optional[str] = None,
        asset_type: Optional[AssetType] = None,
        recursive: bool = False,
    ) -> Iterator[RemoteAsset]:
        path = f"/{folder}" if folder else "/"
        url = f"{self._base_url}{path}"

        # PROPFIND request
        headers = {"Depth": "infinity" if recursive else "1"}

        response = requests.request(
            "PROPFIND",
            url,
            auth=self._auth,
            headers=headers,
            timeout=self._context.timeout,
        )

        if not response.ok:
            raise ProviderError(
                f"PROPFIND failed: {response.status_code}", provider_id=self.id
            )

        # Parse XML response
        root = ET.fromstring(response.content)
        ns = {"d": "DAV:"}

        for response_elem in root.findall("d:response", ns):
            href = response_elem.find("d:href", ns)
            if href is None:
                continue

            path_str = href.text
            name = path_str.rstrip("/").split("/")[-1]

            if not name:
                continue

            propstat = response_elem.find("d:propstat", ns)
            if propstat is None:
                continue

            prop = propstat.find("d:prop", ns)
            if prop is None:
                continue

            # Check if collection (folder)
            resourcetype = prop.find("d:resourcetype", ns)
            is_collection = (
                resourcetype is not None
                and resourcetype.find("d:collection", ns) is not None
            )

            # Get size and modified time
            content_length = prop.find("d:getcontentlength", ns)
            size_bytes = (
                int(content_length.text)
                if content_length is not None and content_length.text
                else None
            )

            lastmodified = prop.find("d:getlastmodified", ns)
            modified_at = (
                self._parse_http_date(lastmodified.text)
                if lastmodified is not None
                else None
            )

            # Classify type
            if is_collection:
                asset_type_val = AssetType.FOLDER
            else:
                ext = "." + name.split(".")[-1].lower() if "." in name else ""
                if ext in self.IMAGE_EXTENSIONS:
                    asset_type_val = AssetType.IMAGE
                elif ext in (".json", ".html"):
                    asset_type_val = AssetType.REPORT
                else:
                    asset_type_val = AssetType.UNKNOWN

            if asset_type and asset_type_val != asset_type:
                continue

            yield RemoteAsset(
                id=path_str,
                name=name,
                path=path_str,
                asset_type=asset_type_val,
                size_bytes=size_bytes,
                modified_at=modified_at,
            )

    def fetch_asset(self, asset_id: str) -> bytes:
        url = f"{self._base_url}{asset_id}"
        response = requests.get(url, auth=self._auth, timeout=60)

        if not response.ok:
            raise ProviderError(
                f"GET failed: {response.status_code}", provider_id=self.id
            )

        return response.content

    def push_report(
        self,
        path: str,
        content: bytes,
        *,
        overwrite: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReportMeta:
        path = f"/{path.lstrip('/')}"
        url = f"{self._base_url}{path}"

        # Check if exists
        head_response = requests.head(url, auth=self._auth, timeout=10)

        if head_response.ok and not overwrite:
            raise ConflictError(f"File exists: {path}", provider_id=self.id)

        # PUT file
        response = requests.put(url, auth=self._auth, data=content, timeout=60)

        if not response.ok:
            raise ProviderError(
                f"PUT failed: {response.status_code}", provider_id=self.id
            )

        return ReportMeta(
            id=path, path=path, size_bytes=len(content), uploaded_at=datetime.utcnow()
        )

    def health_check(self) -> ProviderHealth:
        start = time.time()

        try:
            response = requests.request(
                "OPTIONS", self._base_url, auth=self._auth, timeout=10
            )
            latency = (time.time() - start) * 1000

            if response.ok:
                return ProviderHealth(status=ProviderStatus.HEALTHY, latency_ms=latency)
            else:
                return ProviderHealth(
                    status=ProviderStatus.DEGRADED,
                    message=f"Status: {response.status_code}",
                )

        except Exception as e:
            return ProviderHealth(status=ProviderStatus.UNAVAILABLE, message=str(e))

    def fetch_thumbnail(self, asset_id: str) -> Optional[bytes]:
        return None  # WebDAV doesn't have native thumbnail support

    def store_thumbnail(
        self,
        asset_id: str,
        png_bytes: bytes,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.push_report(
            f".thumbnails/{asset_id.replace('/', '_')}.png", png_bytes, overwrite=True
        )

    def disconnect(self) -> None:
        self._auth = None
        self._context = None

    @staticmethod
    def _parse_http_date(date_str: Optional[str]) -> Optional[datetime]:
        if not date_str:
            return None

        try:
            from email.utils import parsedate_to_datetime

            return parsedate_to_datetime(date_str)
        except Exception:
            return None
