"""
OneDrive Provider - Microsoft Graph API Integration

Authenticates via OAuth2 and provides access to OneDrive files.

Configuration:
{
    "client_id": "...",
    "client_secret": "...",
    "refresh_token": "...",
    "tenant_id": "common" (optional)
}
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Iterator, Optional

try:
    import requests  # type: ignore

    REQUESTS_AVAILABLE = True
except ImportError:

    class _RequestsStub:  # type: ignore
        class RequestException(Exception):
            pass

        def __getattr__(self, name):  # minimal attribute access for stubbing
            raise ProviderError(
                "requests library not installed", provider_id="onedrive"
            )

    requests = _RequestsStub()  # type: ignore
    REQUESTS_AVAILABLE = False

from .base import (
    AssetType,
    DeltaResult,
    ProviderContext,
    ProviderHealth,
    ProviderStatus,
    RemoteAsset,
    ReportMeta,
)
from .errors import AuthenticationError, ConflictError
from .errors import ConnectionError as ProviderConnectionError
from .errors import NotFoundError, ProviderError, QuotaExceededError, RateLimitError
from .registry import ProviderRegistry

logger = logging.getLogger(__name__)


@ProviderRegistry.register
class OneDriveProvider:
    """
    Microsoft OneDrive cloud storage provider.

    Uses Microsoft Graph API for file operations.
    """

    id = "onedrive"
    display_name = "Microsoft OneDrive"

    GRAPH_API_BASE = "https://graph.microsoft.com/v1.0"
    TOKEN_URL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"

    # MIME types for images
    IMAGE_MIME_TYPES = {
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "image/bmp",
        "image/tiff",
    }

    def __init__(self):
        if not REQUESTS_AVAILABLE:
            raise ProviderError(
                "requests library not available. Install with: pip install requests",
                provider_id=self.id,
            )

        self._context: Optional[ProviderContext] = None
        self._access_token: Optional[str] = None
        self._token_expires: Optional[datetime] = None

    def connect(self, context: ProviderContext) -> None:
        """Initialize connection and obtain access token"""
        self._context = context
        self._refresh_access_token()

        logger.info(f"[{self.id}] Connected successfully")

    def _refresh_access_token(self) -> None:
        """Obtain fresh access token using refresh token"""
        if not self._context:
            raise AuthenticationError("Provider not initialized", provider_id=self.id)

        refresh_token = self._context.get_credential("refresh_token")
        client_id = self._context.get_credential("client_id")
        client_secret = self._context.get_credential("client_secret")
        tenant = self._context.get_credential("tenant_id", "common")

        if not all([refresh_token, client_id, client_secret]):
            raise AuthenticationError(
                "Missing credentials: refresh_token, client_id, or client_secret",
                provider_id=self.id,
            )

        token_url = self.TOKEN_URL.format(tenant=tenant)

        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": "Files.ReadWrite.All offline_access",
        }

        try:
            response = requests.post(
                token_url, data=payload, timeout=self._context.timeout
            )
            response.raise_for_status()

            data = response.json()
            self._access_token = data["access_token"]

            # Update refresh token if provided
            if "refresh_token" in data:
                self._context.credentials["refresh_token"] = data["refresh_token"]

            # Calculate expiry
            expires_in = data.get("expires_in", 3600)
            self._token_expires = datetime.utcnow() + timedelta(seconds=expires_in - 60)

            logger.debug(f"[{self.id}] Access token refreshed")

        except requests.RequestException as e:
            raise AuthenticationError(f"Token refresh failed: {e}", provider_id=self.id)

    def _ensure_token(self) -> None:
        """Ensure access token is valid (refresh if needed)"""
        if not self._access_token or not self._token_expires:
            self._refresh_access_token()
        elif datetime.utcnow() >= self._token_expires:
            self._refresh_access_token()

    def _headers(self) -> Dict[str, str]:
        """Build request headers with auth"""
        self._ensure_token()
        return {
            "Authorization": f"Bearer {self._access_token}",
            "User-Agent": self._context.user_agent if self._context else "BranchPy/1.0",
        }

    def _handle_error(self, response) -> None:
        """Handle Graph API error responses"""
        if response.status_code == 401:
            # Token might be invalid, try refresh once
            self._refresh_access_token()
            raise AuthenticationError(
                "Authentication failed (token refreshed, retry)", provider_id=self.id
            )

        elif response.status_code == 404:
            raise NotFoundError("Resource not found", provider_id=self.id)

        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise RateLimitError(
                "Rate limit exceeded", provider_id=self.id, retry_after=retry_after
            )

        elif response.status_code == 507:
            raise QuotaExceededError(
                "Storage quota exceeded", provider_id=self.id, quota_type="storage"
            )

        elif response.status_code == 409:
            raise ConflictError("Resource conflict", provider_id=self.id)

        else:
            try:
                error_data = response.json()
                message = error_data.get("error", {}).get("message", "Unknown error")
            except Exception:
                message = response.text

            raise ProviderError(
                f"Graph API error ({response.status_code}): {message}",
                provider_id=self.id,
            )

    def _classify_asset_type(self, item: Dict[str, Any]) -> AssetType:
        """Classify Graph API item as asset type"""
        if "folder" in item:
            return AssetType.FOLDER

        mime_type = item.get("file", {}).get("mimeType", "")

        if mime_type in self.IMAGE_MIME_TYPES:
            return AssetType.IMAGE
        elif mime_type in ("application/json", "text/html"):
            return AssetType.REPORT
        elif "thumbnail" in item.get("name", "").lower():
            return AssetType.THUMBNAIL
        else:
            return AssetType.UNKNOWN

    def list_assets(
        self,
        folder: Optional[str] = None,
        asset_type: Optional[AssetType] = None,
        recursive: bool = False,
    ) -> Iterator[RemoteAsset]:
        """List OneDrive items"""
        if folder:
            url = f"{self.GRAPH_API_BASE}/me/drive/root:/{folder}:/children"
        else:
            url = f"{self.GRAPH_API_BASE}/me/drive/root/children"

        while url:
            try:
                response = requests.get(
                    url,
                    headers=self._headers(),
                    timeout=self._context.timeout if self._context else 30,
                )

                if not response.ok:
                    self._handle_error(response)

                data = response.json()

                for item in data.get("value", []):
                    item_type = self._classify_asset_type(item)

                    # Filter by asset type if specified
                    if asset_type and item_type != asset_type:
                        if item_type == AssetType.FOLDER and recursive:
                            # Recurse into folders
                            folder_path = item.get("parentReference", {}).get(
                                "path", ""
                            )
                            folder_name = item.get("name", "")
                            full_path = f"{folder_path}/{folder_name}".lstrip("/")
                            yield from self.list_assets(
                                full_path, asset_type, recursive
                            )
                        continue

                    # Parse item
                    asset = RemoteAsset(
                        id=item["id"],
                        name=item["name"],
                        path=item.get("parentReference", {}).get("path", "")
                        + "/"
                        + item["name"],
                        asset_type=item_type,
                        size_bytes=item.get("size"),
                        mime_type=item.get("file", {}).get("mimeType"),
                        modified_at=self._parse_datetime(
                            item.get("lastModifiedDateTime")
                        ),
                        etag=item.get("eTag"),
                        metadata={
                            "webUrl": item.get("webUrl"),
                            "downloadUrl": item.get("@microsoft.graph.downloadUrl"),
                        },
                    )

                    yield asset

                    # Recurse into folders if needed
                    if recursive and item_type == AssetType.FOLDER:
                        folder_path = item.get("parentReference", {}).get("path", "")
                        folder_name = item.get("name", "")
                        full_path = f"{folder_path}/{folder_name}".lstrip("/")
                        yield from self.list_assets(full_path, asset_type, recursive)

                # Pagination
                url = data.get("@odata.nextLink")

            except requests.RequestException as e:
                raise ProviderConnectionError(
                    f"Network error: {e}", provider_id=self.id
                )

    def fetch_asset(self, asset_id: str) -> bytes:
        """Download asset content"""
        url = f"{self.GRAPH_API_BASE}/me/drive/items/{asset_id}/content"

        try:
            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 30,
            )

            if not response.ok:
                self._handle_error(response)

            return response.content

        except requests.RequestException as e:
            raise ProviderConnectionError(f"Download failed: {e}", provider_id=self.id)

    def push_report(
        self,
        path: str,
        content: bytes,
        *,
        overwrite: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReportMeta:
        """Upload report to OneDrive"""
        # Ensure path doesn't start with /
        path = path.lstrip("/")

        # Check if file exists
        check_url = f"{self.GRAPH_API_BASE}/me/drive/root:/{path}"

        try:
            check_response = requests.get(
                check_url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 30,
            )

            if check_response.ok and not overwrite:
                raise ConflictError(
                    f"File already exists: {path}",
                    provider_id=self.id,
                    conflict_type="duplicate",
                )
        except NotFoundError:
            # File doesn't exist, good to upload
            pass

        # Upload file
        upload_url = f"{self.GRAPH_API_BASE}/me/drive/root:/{path}:/content"

        try:
            response = requests.put(
                upload_url,
                headers=self._headers(),
                data=content,
                timeout=self._context.timeout if self._context else 60,
            )

            if not response.ok:
                self._handle_error(response)

            data = response.json()

            return ReportMeta(
                id=data["id"],
                path=path,
                url=data.get("webUrl"),
                uploaded_at=self._parse_datetime(data.get("createdDateTime")),
                size_bytes=data.get("size"),
                etag=data.get("eTag"),
            )

        except requests.RequestException as e:
            raise ProviderConnectionError(f"Upload failed: {e}", provider_id=self.id)

    def health_check(self) -> ProviderHealth:
        """Check OneDrive connectivity and quota"""
        start_time = time.time()

        try:
            # Get drive info
            url = f"{self.GRAPH_API_BASE}/me/drive"

            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 10,
            )

            latency_ms = (time.time() - start_time) * 1000

            if not response.ok:
                self._handle_error(response)

            data = response.json()
            quota = data.get("quota", {})

            return ProviderHealth(
                status=ProviderStatus.HEALTHY,
                latency_ms=latency_ms,
                quota_used=quota.get("used"),
                quota_total=quota.get("total"),
                metadata={
                    "drive_type": data.get("driveType"),
                    "owner": data.get("owner", {}).get("user", {}).get("displayName"),
                },
            )

        except AuthenticationError as e:
            return ProviderHealth(status=ProviderStatus.UNAUTHORIZED, message=str(e))

        except ProviderConnectionError as e:
            return ProviderHealth(status=ProviderStatus.UNAVAILABLE, message=str(e))

        except Exception as e:
            return ProviderHealth(status=ProviderStatus.DEGRADED, message=str(e))

    def fetch_thumbnail(self, asset_id: str) -> Optional[bytes]:
        """Fetch OneDrive-generated thumbnail"""
        url = f"{self.GRAPH_API_BASE}/me/drive/items/{asset_id}/thumbnails"

        try:
            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 10,
            )

            if not response.ok:
                if response.status_code == 404:
                    return None
                self._handle_error(response)

            data = response.json()
            thumbnails = data.get("value", [])

            if not thumbnails:
                return None

            # Get medium size (usually 256px)
            thumbnail_set = thumbnails[0]
            medium_url = thumbnail_set.get("medium", {}).get("url")

            if not medium_url:
                return None

            # Download thumbnail
            thumb_response = requests.get(medium_url, timeout=10)

            if thumb_response.ok:
                return thumb_response.content

            return None

        except Exception as e:
            logger.warning(f"[{self.id}] Failed to fetch thumbnail: {e}")
            return None

    def store_thumbnail(
        self,
        asset_id: str,
        png_bytes: bytes,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Store custom thumbnail (upload to .thumbnails/ folder)"""
        # Store in .thumbnails/ folder
        thumbnail_path = f".thumbnails/{asset_id}.png"

        try:
            self.push_report(
                thumbnail_path, png_bytes, overwrite=True, metadata=metadata
            )
        except Exception as e:
            logger.error(f"[{self.id}] Failed to store thumbnail: {e}")
            raise

    def supports_delta(self) -> bool:
        """OneDrive supports delta queries"""
        return True

    def list_delta(self, cursor: Optional[str] = None) -> DeltaResult:
        """List changes using delta query"""
        if cursor:
            url = cursor  # Delta URL contains full endpoint
        else:
            url = f"{self.GRAPH_API_BASE}/me/drive/root/delta"

        try:
            response = requests.get(
                url,
                headers=self._headers(),
                timeout=self._context.timeout if self._context else 30,
            )

            if not response.ok:
                self._handle_error(response)

            data = response.json()

            added = []
            modified = []
            removed = []

            for item in data.get("value", []):
                # Deleted items
                if "deleted" in item:
                    removed.append(item["id"])
                    continue

                # New or modified items
                asset_type = self._classify_asset_type(item)

                asset = RemoteAsset(
                    id=item["id"],
                    name=item["name"],
                    path=item.get("parentReference", {}).get("path", "")
                    + "/"
                    + item["name"],
                    asset_type=asset_type,
                    size_bytes=item.get("size"),
                    mime_type=item.get("file", {}).get("mimeType"),
                    modified_at=self._parse_datetime(item.get("lastModifiedDateTime")),
                    etag=item.get("eTag"),
                )

                # Determine if new or modified (simplified heuristic)
                if item.get("createdDateTime") == item.get("lastModifiedDateTime"):
                    added.append(asset)
                else:
                    modified.append(asset)

            # Next delta link
            next_cursor = data.get("@odata.deltaLink") or data.get("@odata.nextLink")

            return DeltaResult(
                cursor=next_cursor,
                added=added,
                modified=modified,
                removed=removed,
                has_more="@odata.nextLink" in data,
            )

        except requests.RequestException as e:
            raise ProviderConnectionError(
                f"Delta query failed: {e}", provider_id=self.id
            )

    def disconnect(self) -> None:
        """Clean up resources"""
        self._access_token = None
        self._token_expires = None
        self._context = None

    @staticmethod
    def _parse_datetime(dt_str: Optional[str]) -> Optional[datetime]:
        """Parse ISO-8601 datetime"""
        if not dt_str:
            return None

        try:
            # Remove 'Z' suffix and parse
            if dt_str.endswith("Z"):
                dt_str = dt_str[:-1]
            return datetime.fromisoformat(dt_str)
        except Exception:
            return None
