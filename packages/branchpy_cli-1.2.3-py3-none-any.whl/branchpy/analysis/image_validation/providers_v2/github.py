"""
GitHub Provider - GitHub Contents API Integration

Configuration:
{
    "token": "ghp_...",  # Personal access token
    "repository": "owner/repo",
    "branch": "main" (optional)
}
"""

from __future__ import annotations

import base64
import logging
import time
from typing import Any, Dict, Iterator, Optional

try:
    import requests

    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from ..base import (
    AssetType,
    ProviderContext,
    ProviderHealth,
    ProviderStatus,
    RemoteAsset,
    ReportMeta,
)
from ..errors import AuthenticationError, ConflictError, NotFoundError, ProviderError
from ..registry import ProviderRegistry

logger = logging.getLogger(__name__)


@ProviderRegistry.register
class GitHubProvider:
    """GitHub repository storage provider"""

    id = "github"
    display_name = "GitHub"

    API_BASE = "https://api.github.com"
    IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"}

    def __init__(self):
        if not REQUESTS_AVAILABLE:
            raise ProviderError("requests library required", provider_id=self.id)

        self._context: Optional[ProviderContext] = None
        self._token: Optional[str] = None
        self._repo: Optional[str] = None
        self._branch: str = "main"

    def connect(self, context: ProviderContext) -> None:
        self._context = context
        self._token = context.get_credential("token")
        self._repo = context.get_credential("repository")
        self._branch = context.get_credential("branch", "main")

        if not all([self._token, self._repo]):
            raise AuthenticationError(
                "Missing token or repository", provider_id=self.id
            )

        logger.info(f"[{self.id}] Connected to {self._repo}")

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def list_assets(
        self,
        folder: Optional[str] = None,
        asset_type: Optional[AssetType] = None,
        recursive: bool = False,
    ) -> Iterator[RemoteAsset]:
        path = folder or ""
        url = f"{self.API_BASE}/repos/{self._repo}/contents/{path}"

        params = {"ref": self._branch}

        response = requests.get(
            url, headers=self._headers(), params=params, timeout=self._context.timeout
        )

        if not response.ok:
            if response.status_code == 404:
                raise NotFoundError(f"Path not found: {path}", provider_id=self.id)
            raise ProviderError(
                f"Contents API failed: {response.status_code}", provider_id=self.id
            )

        items = response.json()

        if not isinstance(items, list):
            items = [items]

        for item in items:
            item_type = self._classify_type(item)

            if asset_type and item_type != asset_type:
                if item_type == AssetType.FOLDER and recursive:
                    yield from self.list_assets(item["path"], asset_type, recursive)
                continue

            yield RemoteAsset(
                id=item["sha"],
                name=item["name"],
                path=item["path"],
                asset_type=item_type,
                size_bytes=item.get("size"),
                metadata={
                    "download_url": item.get("download_url"),
                    "html_url": item.get("html_url"),
                },
            )

            if recursive and item_type == AssetType.FOLDER:
                yield from self.list_assets(item["path"], asset_type, recursive)

    def fetch_asset(self, asset_id: str) -> bytes:
        # asset_id is the path for GitHub
        url = f"{self.API_BASE}/repos/{self._repo}/contents/{asset_id}"
        params = {"ref": self._branch}

        response = requests.get(url, headers=self._headers(), params=params, timeout=60)

        if not response.ok:
            raise ProviderError(
                f"Fetch failed: {response.status_code}", provider_id=self.id
            )

        data = response.json()

        # Content is base64 encoded
        content_b64 = data.get("content", "")
        return base64.b64decode(content_b64)

    def push_report(
        self,
        path: str,
        content: bytes,
        *,
        overwrite: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReportMeta:
        url = f"{self.API_BASE}/repos/{self._repo}/contents/{path}"

        # Check if file exists
        check_response = requests.get(
            url, headers=self._headers(), params={"ref": self._branch}, timeout=10
        )

        sha = None
        if check_response.ok:
            if not overwrite:
                raise ConflictError(f"File exists: {path}", provider_id=self.id)
            sha = check_response.json()["sha"]

        # Create or update file
        content_b64 = base64.b64encode(content).decode("ascii")

        payload = {
            "message": f"Upload report: {path}",
            "content": content_b64,
            "branch": self._branch,
        }

        if sha:
            payload["sha"] = sha

        response = requests.put(url, headers=self._headers(), json=payload, timeout=60)

        if not response.ok:
            raise ProviderError(
                f"Upload failed: {response.status_code}", provider_id=self.id
            )

        data = response.json()

        return ReportMeta(
            id=data["content"]["sha"],
            path=path,
            url=data["content"]["html_url"],
            size_bytes=data["content"]["size"],
        )

    def health_check(self) -> ProviderHealth:
        start = time.time()

        try:
            url = f"{self.API_BASE}/repos/{self._repo}"
            response = requests.get(url, headers=self._headers(), timeout=10)

            latency = (time.time() - start) * 1000

            if not response.ok:
                return ProviderHealth(
                    status=ProviderStatus.DEGRADED,
                    message=f"Status: {response.status_code}",
                )

            data = response.json()

            return ProviderHealth(
                status=ProviderStatus.HEALTHY,
                latency_ms=latency,
                metadata={
                    "full_name": data.get("full_name"),
                    "private": data.get("private"),
                    "size": data.get("size"),  # KB
                },
            )

        except Exception as e:
            return ProviderHealth(status=ProviderStatus.UNAVAILABLE, message=str(e))

    def fetch_thumbnail(self, asset_id: str) -> Optional[bytes]:
        return None  # GitHub doesn't provide thumbnails

    def store_thumbnail(
        self,
        asset_id: str,
        png_bytes: bytes,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.push_report(
            f".thumbnails/{asset_id.replace('/', '_')}.png", png_bytes, overwrite=True
        )

    def disconnect(self) -> None:
        self._token = None
        self._context = None

    def _classify_type(self, item: Dict[str, Any]) -> AssetType:
        if item.get("type") == "dir":
            return AssetType.FOLDER

        name = item.get("name", "").lower()
        ext = "." + name.split(".")[-1] if "." in name else ""

        if ext in self.IMAGE_EXTENSIONS:
            return AssetType.IMAGE
        elif ext in (".json", ".html"):
            return AssetType.REPORT
        else:
            return AssetType.UNKNOWN
