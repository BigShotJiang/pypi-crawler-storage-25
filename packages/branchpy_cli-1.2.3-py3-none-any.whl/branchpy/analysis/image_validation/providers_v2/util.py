"""
Provider Utility Functions
Path normalization, error classification, retry logic
"""

import logging
import time
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def norm_join(*parts: str) -> str:
    """
    Normalize and join path segments with forward slashes.

    Handles mixed separator styles (backslash/forward slash) and
    ensures consistent forward-slash delimited paths for cloud APIs.

    Edge cases:
    - Strips leading/trailing slashes from individual parts
    - Collapses multiple consecutive slashes
    - Preserves empty strings as empty segments (not skipped)
    - Returns "/" for empty input

    Args:
        *parts: Path segments to join

    Returns:
        Normalized path with forward slashes

    Examples:
        >>> norm_join("assets", "images", "cover.png")
        'assets/images/cover.png'
        >>> norm_join("/mnt/vault", "\\game\\images\\", "bg.jpg")
        'mnt/vault/game/images/bg.jpg'
        >>> norm_join("", "images", "")
        '/images/'  # Empty parts preserved
    """
    if not parts:
        return "/"

    # Convert all parts to strings and replace backslashes with forward slashes
    normalized = [str(p).replace("\\", "/") for p in parts]

    # Strip leading/trailing slashes from each part (except if entire part is "/")
    stripped = []
    for part in normalized:
        if part == "/":
            # Special case: preserve single slash
            stripped.append("")
        else:
            # Strip leading/trailing slashes
            stripped.append(part.strip("/"))

    # Join with forward slash
    joined = "/".join(stripped)

    # Collapse multiple consecutive slashes
    while "//" in joined:
        joined = joined.replace("//", "/")

    # Remove leading slash if present (unless result is just "/")
    if joined.startswith("/") and joined != "/":
        joined = joined[1:]

    return joined


def classify_http_error(status_code: int) -> Tuple[str, bool]:
    """
    Classify HTTP status code into error category and retryability.

    Categories:
    - "auth_error": 401, 403 (credentials invalid/expired)
    - "not_found": 404 (resource doesn't exist)
    - "conflict": 409, 412 (concurrent modification, ETag mismatch)
    - "rate_limit": 429 (too many requests)
    - "server_error": 500, 502, 503, 504 (upstream failure)
    - "client_error": other 4xx (malformed request)
    - "unknown": other codes

    Retryable errors: 429, 500, 502, 503, 504
    Non-retryable: 401, 403, 404, 409, 412, other 4xx

    Args:
        status_code: HTTP status code

    Returns:
        Tuple of (category, is_retryable)

    Examples:
        >>> classify_http_error(401)
        ('auth_error', False)
        >>> classify_http_error(429)
        ('rate_limit', True)
        >>> classify_http_error(503)
        ('server_error', True)
    """
    # Authentication errors (non-retryable)
    if status_code in (401, 403):
        return ("auth_error", False)

    # Not found (non-retryable)
    if status_code == 404:
        return ("not_found", False)

    # Conflict errors (non-retryable)
    if status_code in (409, 412):
        return ("conflict", False)

    # Rate limiting (retryable with backoff)
    if status_code == 429:
        return ("rate_limit", True)

    # Server errors (retryable)
    if status_code in (500, 502, 503, 504):
        return ("server_error", True)

    # Other 4xx client errors (non-retryable)
    if 400 <= status_code < 500:
        return ("client_error", False)

    # Unknown/other codes (non-retryable by default)
    return ("unknown", False)


def retry_with_backoff(
    func,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    backoff_factor: float = 2.0,
    retryable_exceptions: Tuple = (ConnectionError, TimeoutError),
):
    """
    Retry a function with exponential backoff.

    Retry logic:
    - Delay doubles on each retry: base_delay, base_delay*2, base_delay*4, ...
    - Capped at max_delay
    - Only retries exceptions in retryable_exceptions tuple

    Args:
        func: Callable to retry
        max_retries: Maximum retry attempts (default 3)
        base_delay: Initial delay in seconds (default 1.0)
        max_delay: Maximum delay in seconds (default 30.0)
        backoff_factor: Multiplier for delay (default 2.0)
        retryable_exceptions: Tuple of exception types to retry

    Returns:
        Function result if successful

    Raises:
        Last exception if all retries exhausted

    Example:
        >>> def fetch_data():
        ...     # May raise ConnectionError
        ...     return requests.get("https://api.example.com/data")
        >>> result = retry_with_backoff(fetch_data, max_retries=3)
    """
    last_exception = None

    for attempt in range(max_retries + 1):  # max_retries + initial attempt
        try:
            return func()
        except retryable_exceptions as e:
            last_exception = e

            if attempt < max_retries:
                # Calculate delay with exponential backoff
                delay = min(base_delay * (backoff_factor**attempt), max_delay)

                logger.warning(
                    f"Attempt {attempt + 1}/{max_retries + 1} failed: {e}. "
                    f"Retrying in {delay:.1f}s..."
                )

                time.sleep(delay)
            else:
                # Final attempt failed
                logger.error(f"All {max_retries + 1} attempts failed. Last error: {e}")
                raise

    # Should never reach here, but satisfy type checker
    if last_exception:
        raise last_exception


def parse_content_range(content_range: str) -> Optional[Tuple[int, int, int]]:
    """
    Parse HTTP Content-Range header.

    Format: "bytes start-end/total"
    Example: "bytes 0-1023/5000"

    Args:
        content_range: Content-Range header value

    Returns:
        Tuple of (start, end, total) or None if invalid

    Examples:
        >>> parse_content_range("bytes 0-1023/5000")
        (0, 1023, 5000)
        >>> parse_content_range("bytes */5000")  # Unknown range
        None
    """
    if not content_range or not content_range.startswith("bytes "):
        return None

    try:
        # Strip "bytes " prefix
        range_part = content_range[6:]

        # Split into range and total
        range_str, total_str = range_part.split("/")

        # Handle unknown range (bytes */total)
        if range_str == "*":
            return None

        # Parse start-end
        start_str, end_str = range_str.split("-")

        start = int(start_str)
        end = int(end_str)
        total = int(total_str)

        return (start, end, total)

    except (ValueError, AttributeError):
        logger.warning(f"Invalid Content-Range header: {content_range}")
        return None


def format_bytes(size_bytes: int) -> str:
    """
    Format byte size as human-readable string.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted string (e.g., "1.5 MB", "350 KB")

    Examples:
        >>> format_bytes(1500)
        '1.5 KB'
        >>> format_bytes(1500000)
        '1.4 MB'
        >>> format_bytes(42)
        '42 B'
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


__all__ = [
    "norm_join",
    "classify_http_error",
    "retry_with_backoff",
    "parse_content_range",
    "format_bytes",
]
