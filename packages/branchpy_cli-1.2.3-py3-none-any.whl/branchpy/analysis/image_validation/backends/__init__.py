"""
Image Validation V3 - Backend Abstraction
Supports multiple hashing/embedding backends: pHash, CLIP, ResNet50
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

import numpy as np


class BaseBackend(ABC):
    """Abstract base class for feature extraction backends"""

    @property
    @abstractmethod
    def name(self) -> str:
        """Backend identifier (e.g., 'phash', 'clip', 'resnet50')"""
        pass

    @property
    @abstractmethod
    def feature_dim(self) -> int:
        """Dimensionality of feature vector (e.g., 64 for pHash, 512 for CLIP)"""
        pass

    @property
    @abstractmethod
    def supports_gpu(self) -> bool:
        """Whether backend can use GPU acceleration"""
        pass

    @abstractmethod
    def extract_features(self, image_path: Path) -> np.ndarray:
        """Extract feature vector from image"""
        pass

    @abstractmethod
    def compute_similarity(self, features1: np.ndarray, features2: np.ndarray) -> float:
        """Compute similarity score between two feature vectors"""
        pass

    def batch_extract(self, image_paths: list[Path]) -> dict[str, np.ndarray]:
        """Extract features from multiple images (can be overridden for batch optimization)"""
        features = {}
        for path in image_paths:
            features[str(path)] = self.extract_features(path)
        return features


__all__ = ["BaseBackend"]
