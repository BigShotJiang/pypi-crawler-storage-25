"""
pHash Backend - Perceptual hashing using DCT
Refactored from hasher.py to implement BaseBackend interface
Uses canonical preprocessing pipeline for stable hashing
"""

import logging
from pathlib import Path

try:
    import numpy as np
    from PIL import Image

    PHASH_AVAILABLE = True
except ImportError:
    PHASH_AVAILABLE = False

from . import BaseBackend

# Import canonical preprocessing
try:
    from ..config import IV_CONFIG
    from ..preprocess import preprocess_for_phash

    PREPROCESSING_AVAILABLE = True
except ImportError:
    PREPROCESSING_AVAILABLE = False
    preprocess_for_phash = None  # type: ignore
    IV_CONFIG = None  # type: ignore

logger = logging.getLogger(__name__)


class PHashBackend(BaseBackend):
    """
    Perceptual hash (pHash) backend using Discrete Cosine Transform
    Produces 64-dimensional binary feature vector (8x8 DCT grid)

    Now uses canonical preprocessing:
    - EXIF orientation correction
    - ICC -> sRGB color normalization
    - 8-bit grayscale conversion
    - Deterministic LANCZOS resizing
    - Stable np.rint() rounding
    """

    def __init__(self, hash_size: int = 8, fast_mode: bool = False):
        """
        Initialize pHash backend

        Args:
            hash_size: Size of DCT grid (default 8x8 = 64-bit hash)
            fast_mode: Use smaller hash for speed (not recommended)
        """
        if not PHASH_AVAILABLE:
            raise ImportError("pHash backend requires: pip install Pillow numpy")

        self.hash_size = hash_size
        self.fast_mode = fast_mode

        if fast_mode:
            self.hash_size = 4  # 4x4 = 16-bit hash (5x faster, less accurate)

        logger.info(
            f"pHash backend initialized: {self.hash_size}x{self.hash_size} hash (canonical preprocessing)"
        )

    @property
    def name(self) -> str:
        return "phash"

    @property
    def feature_dim(self) -> int:
        return self.hash_size * self.hash_size  # 64 for 8x8

    @property
    def supports_gpu(self) -> bool:
        return False  # CPU-only

    def extract_features(self, image_path: Path) -> "np.ndarray":
        """
        Extract perceptual hash as binary feature vector

        Uses canonical preprocessing pipeline for consistency.

        Args:
            image_path: Path to image file

        Returns:
            Binary array (64 elements for 8x8 hash, dtype=float32)
        """
        try:
            # Use canonical preprocessing if available
            if PREPROCESSING_AVAILABLE and preprocess_for_phash is not None:
                pixels = preprocess_for_phash(image_path, hash_size=self.hash_size)
            else:
                # Fallback to legacy preprocessing
                pixels = self._legacy_preprocess(image_path)

            # Compute DCT (simplified using FFT)
            dct = self._dct2d(pixels)

            # Extract top-left hash_size x hash_size region (skip DC component)
            dct_low = dct[1 : self.hash_size + 1, 1 : self.hash_size + 1]

            # Compute median
            median = np.median(dct_low)

            # Create binary hash using stable rounding
            # np.rint ensures consistent rounding at 0.5 boundaries
            binary_hash = np.rint(dct_low > median).astype(np.float32).flatten()

            return binary_hash

        except Exception as e:
            logger.error(f"Failed to extract pHash from {image_path}: {e}")
            # Return zero vector on failure
            return np.zeros(self.feature_dim, dtype=np.float32)

    def _legacy_preprocess(self, image_path: Path) -> "np.ndarray":
        """
        Legacy preprocessing (fallback when preprocess module unavailable)

        This is less robust - doesn't handle EXIF/ICC normalization
        """
        logger.warning(
            "Using legacy preprocessing - install preprocess module for canonical pipeline"
        )

        with Image.open(image_path) as img:
            # Convert to grayscale
            img = img.convert("L")

            # Resize to (hash_size + 1) x (hash_size + 1)
            img = img.resize(
                (self.hash_size + 1, self.hash_size + 1), Image.Resampling.LANCZOS
            )

            # Convert to numpy array
            pixels = np.asarray(img, dtype=np.float32)

        return pixels

    def compute_similarity(
        self, features1: "np.ndarray", features2: "np.ndarray"
    ) -> float:
        """
        Compute Hamming similarity between pHash vectors

        Args:
            features1: First binary hash (64-dim)
            features2: Second binary hash (64-dim)

        Returns:
            Similarity score (1.0 = identical, 0.0 = completely different)
        """
        # Compute Hamming distance (count differing bits)
        hamming_distance = np.sum(features1 != features2)

        # Convert to similarity score
        max_distance = self.feature_dim
        similarity = 1.0 - (hamming_distance / max_distance)

        return float(similarity)

    def compute_hash_hex(self, image_path: Path) -> str:
        """
        Legacy method: Compute perceptual hash as hex string

        This maintains backward compatibility with hasher.py API

        Args:
            image_path: Path to image file

        Returns:
            Hex string representation of hash
        """
        features = self.extract_features(image_path)

        # Convert binary array to hex string
        binary_str = "".join("1" if b > 0.5 else "0" for b in features)
        hex_str = hex(int(binary_str, 2))[2:].zfill(self.feature_dim // 4)

        return hex_str

    def hamming_distance(self, hash1: str, hash2: str) -> int:
        """
        Legacy method: Compute Hamming distance between hex hashes

        Maintains backward compatibility with hasher.py API

        Args:
            hash1, hash2: Hex hash strings

        Returns:
            Number of differing bits
        """
        if not hash1 or not hash2 or len(hash1) != len(hash2):
            return self.feature_dim  # Maximum distance

        # Convert hex to binary
        bin1 = bin(int(hash1, 16))[2:].zfill(len(hash1) * 4)
        bin2 = bin(int(hash2, 16))[2:].zfill(len(hash2) * 4)

        # Count differing bits
        return sum(c1 != c2 for c1, c2 in zip(bin1, bin2))

    def similarity_score(self, hash1: str, hash2: str) -> float:
        """
        Legacy method: Compute similarity from hex hashes

        Maintains backward compatibility with hasher.py API

        Args:
            hash1, hash2: Hex hash strings

        Returns:
            Similarity score (0-1)
        """
        distance = self.hamming_distance(hash1, hash2)
        return 1.0 - (distance / self.feature_dim)

    def _dct2d(self, image: "np.ndarray") -> "np.ndarray":
        """
        Simplified 2D Discrete Cosine Transform using FFT

        Args:
            image: 2D numpy array

        Returns:
            DCT coefficients
        """
        # Pad to next power of 2 for efficient FFT
        h, w = image.shape
        size = max(h, w)
        padded = np.zeros((size, size), dtype=np.float32)
        padded[:h, :w] = image

        # Compute FFT (approximation of DCT for speed)
        fft = np.fft.fft2(padded)

        # Take real part of top-left quadrant
        dct = np.real(fft[:h, :w])

        return dct


__all__ = ["PHashBackend"]
