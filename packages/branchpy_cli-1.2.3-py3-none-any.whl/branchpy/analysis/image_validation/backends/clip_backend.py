"""
CLIP Backend - ML-powered semantic image embeddings
Uses OpenAI CLIP (ViT-B/32) for 512-dimensional feature extraction
"""

import logging
from pathlib import Path
from typing import Optional

try:
    import clip
    import numpy as np
    import torch
    from PIL import Image

    CLIP_AVAILABLE = True
except ImportError:
    CLIP_AVAILABLE = False

from . import BaseBackend

logger = logging.getLogger(__name__)


class CLIPBackend(BaseBackend):
    """
    CLIP-based feature extraction using ViT-B/32 model
    Produces 512-dimensional semantic embeddings
    """

    def __init__(self, model_name: str = "ViT-B/32", device: Optional[str] = None):
        """
        Initialize CLIP backend

        Args:
            model_name: CLIP model architecture (ViT-B/32, ViT-B/16, RN50)
            device: Device to use ('cuda', 'cpu', or None for auto-detect)
        """
        if not CLIP_AVAILABLE:
            raise ImportError(
                "CLIP backend requires: pip install torch torchvision "
                "git+https://github.com/openai/CLIP.git"
            )

        # Auto-detect device if not specified
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"

        self.device = device
        self.model_name = model_name

        logger.info(f"Loading CLIP model {model_name} on {device}...")
        self.model, self.preprocess = clip.load(model_name, device=device)
        self.model.eval()  # Inference mode

        logger.info(f"CLIP backend initialized: {model_name} on {device}")

    @property
    def name(self) -> str:
        return "clip"

    @property
    def feature_dim(self) -> int:
        return 512  # ViT-B/32 output dimension

    @property
    def supports_gpu(self) -> bool:
        return True

    def extract_features(self, image_path: Path) -> "np.ndarray":
        """
        Extract 512-dim CLIP embedding from image

        Args:
            image_path: Path to image file

        Returns:
            512-dimensional numpy array (L2-normalized)
        """
        try:
            # Load and preprocess image
            image = Image.open(image_path).convert("RGB")
            image_tensor = self.preprocess(image).unsqueeze(0).to(self.device)

            # Extract features
            with torch.no_grad():
                features = self.model.encode_image(image_tensor)
                # Normalize to unit length (cosine similarity)
                features = features / features.norm(dim=-1, keepdim=True)

            # Convert to numpy
            embedding = features.cpu().numpy().flatten()

            return embedding

        except Exception as e:
            logger.error(f"Failed to extract CLIP features from {image_path}: {e}")
            # Return zero vector on failure
            return np.zeros(self.feature_dim, dtype=np.float32)

    def compute_similarity(
        self, features1: "np.ndarray", features2: "np.ndarray"
    ) -> float:
        """
        Compute cosine similarity between CLIP embeddings

        Args:
            features1: First embedding (512-dim)
            features2: Second embedding (512-dim)

        Returns:
            Cosine similarity (0.0 to 1.0)
        """
        # Features are already L2-normalized, so dot product = cosine similarity
        similarity = float(np.dot(features1, features2))

        # Clamp to [0, 1] range (CLIP embeddings are normalized)
        # Cosine similarity ranges from [-1, 1], but CLIP typically gives [0, 1]
        similarity = max(0.0, min(1.0, similarity))

        return similarity

    def batch_extract(self, image_paths: list[Path]) -> dict[str, "np.ndarray"]:
        """
        Extract features from multiple images in batch (GPU-optimized)

        Args:
            image_paths: List of image paths

        Returns:
            Dictionary mapping path -> feature vector
        """
        if not image_paths:
            return {}

        features = {}
        batch_size = 32  # Process 32 images at a time

        for i in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[i : i + batch_size]

            try:
                # Load and preprocess batch
                images = []
                valid_paths = []

                for path in batch_paths:
                    try:
                        img = Image.open(path).convert("RGB")
                        images.append(self.preprocess(img))
                        valid_paths.append(path)
                    except Exception as e:
                        logger.warning(f"Failed to load {path}: {e}")
                        features[str(path)] = np.zeros(
                            self.feature_dim, dtype=np.float32
                        )

                if not images:
                    continue

                # Stack into batch tensor
                batch_tensor = torch.stack(images).to(self.device)

                # Extract features
                with torch.no_grad():
                    batch_features = self.model.encode_image(batch_tensor)
                    batch_features = batch_features / batch_features.norm(
                        dim=-1, keepdim=True
                    )

                # Store results
                embeddings = batch_features.cpu().numpy()
                for path, embedding in zip(valid_paths, embeddings):
                    features[str(path)] = embedding

            except Exception as e:
                logger.error(f"Batch processing failed: {e}")
                # Fallback to individual processing
                for path in batch_paths:
                    if str(path) not in features:
                        features[str(path)] = self.extract_features(path)

        return features


__all__ = ["CLIPBackend"]
