"""
Data models for Image Validation V3
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ImageFile:
    """Represents a single image file in the project"""

    path: str  # Relative path from project root
    abs_path: Path  # Absolute file path
    size_bytes: int
    width: int
    height: int
    format: str  # PNG, WEBP, JPG, etc.
    hash_phash: Optional[str] = None  # Perceptual hash (64-bit hex)
    hash_md5: Optional[str] = None  # Content hash for exact duplicates
    embedding: Optional[List[float]] = None  # CLIP embedding (512-dim)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        return {
            "path": self.path,
            "size_bytes": self.size_bytes,
            "width": self.width,
            "height": self.height,
            "format": self.format,
            "hash_phash": self.hash_phash,
            "hash_md5": self.hash_md5,
        }


@dataclass
class ImageCluster:
    """Group of similar images"""

    group_id: str  # e.g., "G0001"
    members: List[str]  # Relative paths
    canonical: Optional[str] = None  # Path to selected canonical version
    avg_similarity: float = 0.0  # Average similarity score (0-1)
    centroid: Optional[List[float]] = None  # Average embedding

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        return {
            "group_id": self.group_id,
            "members": self.members,
            "canonical": self.canonical,
            "avg_similarity": round(self.avg_similarity, 3),
            "centroid": (
                self.centroid[:10] if self.centroid else None
            ),  # First 10 dims for preview
        }


@dataclass
class ValidationReport:
    """Complete validation report"""

    timestamp: str
    project_dir: str
    total_images: int
    indexed_images: int
    clusters_detected: int
    duplicates: int  # Exact duplicates (MD5 match)
    clusters: List[ImageCluster] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    # Wave 4: BQF-Core validation summary (optional)
    bqf_validation: Optional[Dict[str, Any]] = field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict matching panel format"""
        out = {
            "timestamp": self.timestamp,
            "project_dir": self.project_dir,
            "total_images": self.total_images,
            "indexed_images": self.indexed_images,
            "clusters_detected": self.clusters_detected,
            "duplicates": self.duplicates,
            "clusters": [c.to_dict() for c in self.clusters],
            "metadata": self.metadata,
        }
        if self.bqf_validation is not None:
            out["bqf_validation"] = self.bqf_validation
        return out

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> ValidationReport:
        """Load from JSON dict"""
        clusters = [
            ImageCluster(
                group_id=c["group_id"],
                members=c["members"],
                canonical=c.get("canonical"),
                avg_similarity=c.get("avg_similarity", 0.0),
                centroid=c.get("centroid"),
            )
            for c in data.get("clusters", [])
        ]

        return ValidationReport(
            timestamp=data["timestamp"],
            project_dir=data["project_dir"],
            total_images=data["total_images"],
            indexed_images=data["indexed_images"],
            clusters_detected=data["clusters_detected"],
            duplicates=data["duplicates"],
            clusters=clusters,
            metadata=data.get("metadata", {}),
        )
