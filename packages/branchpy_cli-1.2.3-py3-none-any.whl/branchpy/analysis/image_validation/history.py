"""
Validation Run History & Timeline Replay

Manages historical validation run metadata for timeline replay feature (Phase 5).

Provides:
- Storage/retrieval of validation run summaries indexed by correlation ID
- Timeline metadata (timestamp, duration, cluster count, issue count)
- Efficient query by date range, correlation ID, or recency
- Pruning of old runs (configurable retention policy)

Storage Format:
    .branchpy/validation_history.jsonl — one line per validation run
    Each line: {
        "correlation_id": "abc123",
        "timestamp": "2025-11-09T14:23:45.678Z",
        "duration_ms": 12345,
        "total_images": 523,
        "cluster_count": 42,
        "issue_count": 18,
        "anomaly_count": 3,
        "summary": { ... },
        "status": "completed" | "failed" | "cancelled"
    }

Usage:
    from branchpy.analysis.image_validation.history import ValidationHistory

    history = ValidationHistory(project_root)

    # Record run
    history.record_run(
        correlation_id="abc123",
        duration_ms=12345,
        total_images=523,
        cluster_count=42,
        issue_count=18,
        status="completed"
    )

    # Query recent runs
    recent = history.get_recent_runs(limit=50)

    # Query by date range
    runs = history.get_runs_by_date_range(
        start="2025-11-01T00:00:00Z",
        end="2025-11-09T23:59:59Z"
    )

    # Get specific run
    run = history.get_run("abc123")

Version: v0.9.2 (Phase 5 - Advanced Intelligence & Streaming)
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

_logger = logging.getLogger(__name__)


@dataclass
class ValidationRunSummary:
    """Summary metadata for a single validation run."""

    correlation_id: str
    timestamp: str  # ISO 8601
    duration_ms: float
    total_images: int
    cluster_count: int
    issue_count: int
    anomaly_count: int
    status: str  # "completed" | "failed" | "cancelled"
    summary: Optional[Dict[str, Any]] = None  # Full report summary (optional)


class ValidationHistory:
    """
    Manages historical validation run metadata for timeline replay.

    Stores validation run summaries in JSONL format for efficient append
    and query operations. Supports timeline replay UI with ≥50 historical runs.
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize validation history manager.

        Args:
            project_root: Project root directory (defaults to current directory)
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self.history_path = self.project_root / ".branchpy" / "validation_history.jsonl"
        self.history_path.parent.mkdir(parents=True, exist_ok=True)

    def record_run(
        self,
        correlation_id: str,
        duration_ms: float,
        total_images: int,
        cluster_count: int,
        issue_count: int,
        anomaly_count: int = 0,
        status: str = "completed",
        summary: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Record a validation run to history.

        Args:
            correlation_id: Unique correlation ID for the run
            duration_ms: Total duration in milliseconds
            total_images: Number of images validated
            cluster_count: Number of duplicate clusters detected
            issue_count: Number of issues found
            anomaly_count: Number of anomalies flagged (Phase 5)
            status: Run status ("completed" | "failed" | "cancelled")
            summary: Optional full report summary dictionary

        Side effects:
            - Appends to .branchpy/validation_history.jsonl
        """
        run_summary = ValidationRunSummary(
            correlation_id=correlation_id,
            timestamp=datetime.utcnow().isoformat() + "Z",
            duration_ms=duration_ms,
            total_images=total_images,
            cluster_count=cluster_count,
            issue_count=issue_count,
            anomaly_count=anomaly_count,
            status=status,
            summary=summary,
        )

        try:
            with open(self.history_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(asdict(run_summary), default=str) + "\n")

            _logger.info(
                f"Recorded validation run: {correlation_id} "
                f"({total_images} images, {cluster_count} clusters, {issue_count} issues)"
            )
        except Exception as e:
            _logger.error(f"Failed to record validation run history: {e}")

    def get_recent_runs(self, limit: int = 50) -> List[ValidationRunSummary]:
        """
        Get most recent validation runs.

        Args:
            limit: Maximum number of runs to return (default 50)

        Returns:
            List of ValidationRunSummary objects, most recent first
        """
        runs = self._read_all_runs()

        # Sort by timestamp descending
        runs_sorted = sorted(runs, key=lambda r: r.timestamp, reverse=True)

        return runs_sorted[:limit]

    def get_runs_by_date_range(
        self, start: str, end: str
    ) -> List[ValidationRunSummary]:
        """
        Get validation runs within a date range.

        Args:
            start: Start timestamp (ISO 8601)
            end: End timestamp (ISO 8601)

        Returns:
            List of ValidationRunSummary objects within range, sorted by timestamp
        """
        runs = self._read_all_runs()

        # Filter by date range
        filtered = [run for run in runs if start <= run.timestamp <= end]

        # Sort by timestamp ascending
        return sorted(filtered, key=lambda r: r.timestamp)

    def get_run(self, correlation_id: str) -> Optional[ValidationRunSummary]:
        """
        Get a specific validation run by correlation ID.

        Args:
            correlation_id: Correlation ID to look up

        Returns:
            ValidationRunSummary if found, None otherwise
        """
        runs = self._read_all_runs()

        for run in runs:
            if run.correlation_id == correlation_id:
                return run

        return None

    def prune_old_runs(self, max_age_days: int = 90) -> int:
        """
        Remove validation runs older than max_age_days.

        Args:
            max_age_days: Maximum age in days (default 90)

        Returns:
            Number of runs pruned

        Side effects:
            - Rewrites .branchpy/validation_history.jsonl with filtered runs
        """
        runs = self._read_all_runs()

        # Calculate cutoff timestamp
        cutoff = datetime.utcnow()
        cutoff = cutoff.replace(day=cutoff.day - max_age_days).isoformat() + "Z"

        # Filter runs newer than cutoff
        kept_runs = [run for run in runs if run.timestamp >= cutoff]

        pruned_count = len(runs) - len(kept_runs)

        if pruned_count > 0:
            # Rewrite history file
            try:
                with open(self.history_path, "w", encoding="utf-8") as f:
                    for run in kept_runs:
                        f.write(json.dumps(asdict(run), default=str) + "\n")

                _logger.info(
                    f"Pruned {pruned_count} old validation runs (>{max_age_days} days)"
                )
            except Exception as e:
                _logger.error(f"Failed to prune validation history: {e}")
                return 0

        return pruned_count

    def _read_all_runs(self) -> List[ValidationRunSummary]:
        """
        Read all validation runs from history file.

        Returns:
            List of ValidationRunSummary objects
        """
        if not self.history_path.exists():
            return []

        runs = []
        try:
            with open(self.history_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue

                    try:
                        data = json.loads(line)
                        runs.append(ValidationRunSummary(**data))
                    except (json.JSONDecodeError, TypeError) as e:
                        _logger.warning(f"Skipping malformed history line: {e}")
                        continue
        except Exception as e:
            _logger.error(f"Failed to read validation history: {e}")
            return []

        return runs
