"""
Main Image Validator - Orchestrates scanning, hashing, and clustering
"""

from __future__ import annotations

import json
import logging
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

from .backends import BaseBackend
from .backends.phash_backend import PHashBackend
from .cache import FeatureStore
from .clustering import ImageClusterer
from .embedding_cache import EmbeddingCache
from .governance_logger import ImageValidationLogger
from .hasher import PerceptualHasher  # Legacy API
from .models import ImageCluster, ImageFile, ValidationReport
from .scanner import ImageScanner

# Wave 4 BQF imports
try:
    from BranchPyApp.validation.registry import registry

    from .policies_bqf import register_bqf_policies

    _BQF_AVAILABLE = True
except ImportError:
    _BQF_AVAILABLE = False
    register_bqf_policies = None
    registry = None

try:
    from branchpy import logs
except Exception:

    class _Shim:
        def info(self, e, m="", **k):
            print(e, m, k)

        def warn(self, e, m="", **k):
            print(e, m, k)

        def error(self, e, m="", **k):
            print(e, m, k)

    logs = _Shim()

try:
    from .backends.clip_backend import CLIPBackend

    CLIP_AVAILABLE = True
except ImportError:
    CLIP_AVAILABLE = False

logger = logging.getLogger(__name__)

# Register BQF policies at import (safe if run once per process)
if _BQF_AVAILABLE and register_bqf_policies:
    try:
        register_bqf_policies()
    except Exception as _e:
        pass


def _emit_validation_for_assets(assets: list, context: Mapping[str, Any]) -> dict:
    """
    Applies all 'asset' policies and emits BQF events:
    - validation.request.start
    - validation.policy.applied  (per asset x policy)
    - validation.request.complete
    Returns a summary dict.
    """
    if not _BQF_AVAILABLE or not registry:
        return {
            "requestId": "",
            "status": "skipped",
            "items": [],
            "summary": {"total": 0, "passed": 0, "failed": 0, "errors": 0},
        }

    corr = str(uuid.uuid4())
    req_id = str(uuid.uuid4())
    logs.info(
        "validation.request.start",
        "Image Validation (BQF) started",
        requestId=req_id,
        engine=context.get("engine", "generic"),
        kind="asset",
        correlationId=corr,
    )

    total = passed = failed = 0
    items: List[Dict[str, Any]] = []
    for path in assets:
        for pol in registry.list():
            if getattr(pol, "target", None) != "asset":
                continue
            ok = pol.evaluate(path, context)
            total += 1
            passed += int(ok)
            failed += int(not ok)
            logs.info(
                "validation.policy.applied",
                f"Applied {getattr(pol, 'id', getattr(pol, 'name', ''))} to {path}",
                requestId=req_id,
                policyId=getattr(pol, "id", getattr(pol, "name", "")),
                target=path,
                severity=getattr(pol, "severity", ""),
                passed=ok,
                correlationId=corr,
            )
            items.append(
                {
                    "target": str(path),
                    "policyId": getattr(pol, "id", getattr(pol, "name", "")),
                    "severity": getattr(pol, "severity", ""),
                    "passed": ok,
                }
            )

    status = "success" if failed == 0 else ("partial" if passed > 0 else "failed")
    summary = {"total": total, "passed": passed, "failed": failed, "errors": 0}
    logs.info(
        "validation.request.complete",
        "Image Validation (BQF) complete",
        requestId=req_id,
        status=status,
        summary=summary,
        correlationId=corr,
    )
    return {"requestId": req_id, "status": status, "items": items, "summary": summary}


class ImageValidator:
    """
    Main validator class for Image Validation V3

    Usage:
        validator = ImageValidator(project_dir=Path("."), backend="phash", fast_mode=False)
        report = validator.validate()
    """

    def __init__(
        self,
        project_dir: Path,
        backend: str = "phash",
        fast_mode: bool = False,
        similarity_threshold: float = 0.85,
        cache_dir: Optional[Path] = None,
        use_cache: bool = True,
        engine: str = "renpy",
        images_dir: Optional[Path] = None,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize validator

        Args:
            project_dir: Root directory of project
            backend: Hashing backend ("phash" or "clip")
            fast_mode: Use fast mode (lower quality but 5× faster)
            similarity_threshold: Minimum similarity for clustering (0-1)
            cache_dir: Cache directory (default: project_dir/.branchpy/image_cache)
            use_cache: Enable LMDB feature caching
            engine: Engine type ('renpy', 'unity', 'godot', 'unreal', 'generic')
            images_dir: Custom images directory (overrides engine defaults)
            correlation_id: Optional correlation ID for governance logging
        """
        self.project_dir = Path(project_dir)
        self.backend_name = backend
        self.fast_mode = fast_mode
        self.similarity_threshold = similarity_threshold
        self.use_cache = use_cache
        self.engine = engine
        self.images_dir = images_dir

        # Initialize governance logger
        self.gov_logger = ImageValidationLogger(
            project_root=self.project_dir, correlation_id=correlation_id
        )

        # Initialize backend
        if backend == "clip":
            if not CLIP_AVAILABLE:
                logger.warning("CLIP backend not available, falling back to pHash")
                self.backend_name = "phash"
                self.backend: BaseBackend = PHashBackend(fast_mode=fast_mode)
            else:
                logger.info("Using CLIP backend for semantic embeddings")
                self.backend = CLIPBackend()  # type: ignore
        else:
            self.backend = PHashBackend(fast_mode=fast_mode)

        # Initialize cache
        if use_cache:
            if cache_dir is None:
                cache_dir = self.project_dir / ".branchpy" / "image_cache"

            try:
                self.cache = FeatureStore(cache_dir)
                logger.info(f"Feature cache enabled at {cache_dir}")
            except Exception as e:
                logger.warning(f"Failed to initialize cache: {e}")
                self.cache = None
                self.use_cache = False
        else:
            self.cache = None

        # Initialize distributed embedding cache prototype (always available, falls back to LRU)
        try:
            self.embedding_cache = EmbeddingCache()
        except Exception as e:
            logger.warning(f"Failed to initialize embedding cache: {e}")
            self.embedding_cache = None

        # Initialize components
        self.scanner = ImageScanner(
            self.project_dir, images_dir=images_dir, engine=engine
        )
        self.clusterer = ImageClusterer(similarity_threshold=similarity_threshold)

        # Legacy hasher for backward compatibility
        self.hasher = PerceptualHasher(hash_size=4 if fast_mode else 8)

        # Results
        self.scanned_images: List[ImageFile] = []
        self.clusters: List[ImageCluster] = []
        self.duplicates: List[ImageCluster] = []

    def validate(
        self, refresh_cache: bool = False, auto_adopt: bool = False
    ) -> ValidationReport:
        """
        Run full validation pipeline

        Args:
            refresh_cache: Force re-scan (ignore cache)
            auto_adopt: Automatically select canonical versions

        Returns:
            ValidationReport object
        """
        start_time = time.time()

        # Log validation start
        self.gov_logger.log_validation_start(
            backend=self.backend_name,
            engine=self.engine,
            images_dir=self.images_dir,
            use_cache=self.use_cache,
            semantic=False,  # TODO: Add semantic parameter
        )

        print("[ImageValidator] Starting validation...")
        print(f"  Project: {self.project_dir}")
        print(f"  Backend: {self.backend_name}")
        print(f"  Fast mode: {self.fast_mode}")
        print(f"  Cache: {'enabled' if self.use_cache else 'disabled'}")
        print(f"  Correlation ID: {self.gov_logger.correlation_id}")

        # Emit progress sentinel for streaming UI
        print("##BPyProgress:0:Starting validation")

        # Step 1: Scan images
        print("\n[1/4] Scanning images...")
        print("##BPyProgress:25:Scanning images")
        self.gov_logger.log_validation_progress_step(
            "scan", "Discovering image files", 25
        )

        scan_start = time.time()
        self.scanned_images = self.scanner.scan()
        scan_time = (time.time() - scan_start) * 1000

        # Log scan completion
        scanned_dirs = [str(d) for d in self.scanner.images_dirs if d.exists()]
        self.gov_logger.log_scan_complete(
            total_images=len(self.scanned_images),
            scan_time_ms=scan_time,
            directories_scanned=scanned_dirs,
        )

        # --- BQF Validation: Evaluate and emit events for all scanned images ---
        # Build context for BQF policies
        # (Assume fs adapter, metadata, checksums, etc. are available or can be stubbed)
        fs = getattr(self.scanner, "fs_adapter", None)
        metadata = getattr(self.scanner, "metadata", lambda: {})()
        checksums = getattr(self.scanner, "read_checksums", lambda: {})()
        checksums_computed = getattr(self.scanner, "compute_checksums", lambda xs: {})(
            [img.abs_path for img in self.scanned_images]
        )
        context = {
            "engine": self.engine,
            "project": str(self.project_dir),
            "fs": fs,
            "metadata": metadata,
            "checksums": checksums,
            "checksums_computed": checksums_computed,
        }
        bqf_validation = _emit_validation_for_assets(
            [img.abs_path for img in self.scanned_images], context
        )

        if not self.scanned_images:
            print("No images found in game/images directory")
            print("##BPyProgress:100:Complete - No images found")
            report = self._create_empty_report()
            self.gov_logger.log_validation_complete(
                total_images=0,
                duplicates=0,
                clusters=0,
                total_time_ms=(time.time() - start_time) * 1000,
            )
            self.gov_logger.flush()
            # Save empty report and emit path sentinel
            default_report_path = (
                self.project_dir / ".branchpy" / "reports" / "image_validation.json"
            )
            default_report_path.parent.mkdir(parents=True, exist_ok=True)
            with open(default_report_path, "w", encoding="utf-8") as f:
                json.dump(report.to_dict(), f, indent=2, ensure_ascii=False)
            print(f"##BPyReportPath:{default_report_path}")
            sys.stdout.flush()  # Ensure sentinel is flushed to subprocess
            # Attach BQF validation summary (empty)
            report.bqf_validation = {}
            return report

        # Step 2: Compute hashes
        # (BQF validation already run above; results in bqf_validation)
        print(
            f"\n[2/4] Computing perceptual hashes for {len(self.scanned_images)} images..."
        )
        print("##BPyProgress:50:Computing perceptual hashes")
        self.gov_logger.log_validation_progress_step(
            "feature_extract",
            f"Processing {len(self.scanned_images)} images",
            50,
            scan_time,
        )

        extraction_start = time.time()
        cache_hits, cache_misses = self._compute_hashes()
        extraction_time = (time.time() - extraction_start) * 1000

        # Log feature extraction
        self.gov_logger.log_feature_extraction(
            backend=self.backend_name,
            total_images=len(self.scanned_images),
            cache_hits=cache_hits,
            cache_misses=cache_misses,
            extraction_time_ms=extraction_time,
        )

        # Step 3: Find exact duplicates (MD5)
        print("\n[3/4] Finding exact duplicates...")
        print("##BPyProgress:75:Finding exact duplicates")
        self.gov_logger.log_validation_progress_step(
            "duplicates", "Identifying exact duplicates", 75, extraction_time
        )

        cluster_start = time.time()
        self.duplicates = self.clusterer.cluster_by_md5(self.scanned_images)
        print(f"  Found {len(self.duplicates)} duplicate groups")

        # Emit issue events for duplicate groups
        for dup_cluster in self.duplicates:
            if len(dup_cluster.members) > 1:
                # Emit governance event
                self.gov_logger.log_validation_issue_emitted(
                    issue_type="duplicate_group",
                    image_path=dup_cluster.members[0],
                    metadata={
                        "group_id": dup_cluster.group_id,
                        "member_count": len(dup_cluster.members),
                        "canonical": dup_cluster.canonical,
                    },
                )
                # Emit sentinel for streaming UI
                print(
                    f"##BPyIssue:duplicate_group:{dup_cluster.group_id}:{len(dup_cluster.members)} duplicates"
                )

        # Step 4: Cluster similar images (pHash)
        print("\n[4/4] Clustering similar images...")
        print("##BPyProgress:90:Clustering similar images")
        self.gov_logger.log_validation_progress_step(
            "cluster", "Grouping similar images", 90
        )

        hamming_threshold = 5 if self.fast_mode else 10
        self.clusters = self.clusterer.cluster_by_phash(
            self.scanned_images, hamming_distance_threshold=hamming_threshold
        )
        print(f"  Found {len(self.clusters)} similarity clusters")
        cluster_time = (time.time() - cluster_start) * 1000

        # Phase 5: Streaming row emission
        # Emit row-by-row events for incremental UI updates
        stream_start = time.time()
        anomaly_count = 0
        first_row_latency = None

        for row_index, img in enumerate(self.scanned_images):
            # Find cluster membership
            cluster_id = None
            tags = []
            issues = []

            # Check if image is in any duplicate cluster
            for dup_cluster in self.duplicates:
                if img.path in dup_cluster.members:
                    cluster_id = dup_cluster.group_id
                    issues.append(
                        {
                            "type": "exact_duplicate",
                            "detail": f"{len(dup_cluster.members)} identical copies",
                        }
                    )
                    break

            # Check if image is in any similarity cluster (if not already in duplicate)
            if not cluster_id:
                for sim_cluster in self.clusters:
                    if img.path in sim_cluster.members:
                        cluster_id = sim_cluster.group_id
                        similarity_pct = int(sim_cluster.avg_similarity * 100)
                        issues.append(
                            {
                                "type": "similar_image",
                                "detail": f"{len(sim_cluster.members)} similar images ({similarity_pct}%)",
                            }
                        )
                        break

            # Placeholder anomaly scoring (Phase 5 stub - deterministic mock)
            anomaly_score = self._calculate_anomaly_score_stub(img, cluster_id)
            if anomaly_score >= 0.8:  # Threshold for flagging
                anomaly_count += 1
                self.gov_logger.log_validation_anomaly_flag(
                    image_path=img.path,
                    score=anomaly_score,
                    threshold=0.8,
                    reason=(
                        "high hash entropy variation"
                        if anomaly_score > 0.9
                        else "unusual similarity pattern"
                    ),
                    cluster_id=cluster_id,
                )

            # Emit streaming row event
            self.gov_logger.log_validation_stream_row(
                row_index=row_index,
                image_path=img.path,
                cluster_id=cluster_id,
                tags=tags,
                anomaly_score=anomaly_score,
                issues=issues,
            )

            # Track first row latency
            if row_index == 0:
                first_row_latency = (time.time() - stream_start) * 1000

        # Emit stream complete event
        stream_duration = (time.time() - stream_start) * 1000
        self.gov_logger.log_validation_stream_complete(
            total_rows=len(self.scanned_images),
            duration_ms=stream_duration,
            anomalies_flagged=anomaly_count,
            first_row_latency_ms=first_row_latency,
        )

        # Emit issue events for similarity clusters (legacy support)
        for sim_cluster in self.clusters:
            if len(sim_cluster.members) > 1:
                # Emit governance event
                self.gov_logger.log_validation_issue_emitted(
                    issue_type="similarity_cluster",
                    image_path=sim_cluster.members[0],
                    metadata={
                        "group_id": sim_cluster.group_id,
                        "member_count": len(sim_cluster.members),
                        "avg_similarity": sim_cluster.avg_similarity,
                        "canonical": sim_cluster.canonical,
                    },
                )
                # Emit sentinel for streaming UI
                similarity_pct = int(sim_cluster.avg_similarity * 100)
                print(
                    f"##BPyIssue:similarity_cluster:{sim_cluster.group_id}:{len(sim_cluster.members)} images ({similarity_pct}% similar)"
                )

        # Wrap remaining logic in try/except to catch any hidden exceptions
        try:
            # Log clustering
            self.gov_logger.log_clustering_complete(
                duplicates_found=len(self.duplicates),
                similarity_clusters=len(self.clusters),
                clustering_time_ms=cluster_time,
            )

            # Create report
            report = self._create_report()
            # Attach BQF validation summary to report (for downstream consumers)
            report.bqf_validation = bqf_validation
            total_time = (time.time() - start_time) * 1000

            # Log validation complete
            self.gov_logger.log_validation_complete(
                total_images=report.total_images,
                duplicates=report.duplicates,
                clusters=report.clusters_detected,
                total_time_ms=total_time,
            )
            self.gov_logger.flush()

            print("\n[OK] Validation complete!")
            print(f"  Total images: {report.total_images}")
            print(f"  Duplicates: {report.duplicates}")
            print(f"  Similarity clusters: {report.clusters_detected}")
            print(f"  Total time: {total_time:.1f}ms")

            # Save report to default location and emit path sentinel
            default_report_path = (
                self.project_dir / ".branchpy" / "reports" / "image_validation.json"
            )
            default_report_path.parent.mkdir(parents=True, exist_ok=True)
            with open(default_report_path, "w", encoding="utf-8") as f:
                json.dump(report.to_dict(), f, indent=2, ensure_ascii=False)

            print(f"\nReport saved to: {default_report_path}")
            print(f"##BPyReportPath:{default_report_path}")
            sys.stdout.flush()  # Ensure sentinel is flushed to subprocess

            # Emit final progress sentinel
            print("##BPyProgress:100:Validation complete")
            sys.stdout.flush()  # Ensure final progress is flushed

            return report
        except Exception as exc:
            print(f"\n[ERROR] [VALIDATOR] {type(exc).__name__}: {exc}", file=sys.stderr)
            import traceback

            traceback.print_exc(file=sys.stderr)
            sys.stderr.flush()
            raise

    def _compute_hashes(self) -> tuple[int, int]:
        """
        Compute features using configured backend with cache support

        Returns:
            Tuple of (cache_hits, cache_misses)
        """
        cache_hits = 0
        cache_misses = 0

        for idx, img in enumerate(self.scanned_images, 1):
            if idx % 50 == 0:
                print(
                    f"  Processed {idx}/{len(self.scanned_images)} images (cache hits: {cache_hits})..."
                )

            # Try cache first
            # First try distributed embedding cache (semantic future) then feature store
            if self.embedding_cache:
                emb = self.embedding_cache.get_embedding(
                    str(img.abs_path), self.gov_logger
                )
                if emb is not None:
                    cache_hits += 1
                    img.hash_phash = self.hasher.compute_hash(img.abs_path)
                    continue

            if self.use_cache and self.cache:
                try:
                    cached_features = self.cache.get_embedding(
                        img.abs_path, self.backend_name, validate_cache=True
                    )

                    if cached_features is not None:
                        cache_hits += 1
                        # Skip extraction, but still compute legacy pHash for clustering
                        img.hash_phash = self.hasher.compute_hash(img.abs_path)
                        continue
                except Exception as e:
                    logger.warning(f"Cache read error for {img.abs_path.name}: {e}")
                    self.gov_logger.log_cache_operation(
                        operation="GET",
                        backend=self.backend_name,
                        success=False,
                        details={"error": str(e), "file": str(img.abs_path)},
                    )

            # Cache miss - extract features
            cache_misses += 1
            try:
                features = self.backend.extract_features(img.abs_path)

                # Store in cache
                if self.use_cache and self.cache:
                    try:
                        self.cache.set_embedding(
                            img.abs_path, self.backend_name, features
                        )
                    except Exception as e:
                        logger.warning(
                            f"Cache write error for {img.abs_path.name}: {e}"
                        )
                        self.gov_logger.log_cache_operation(
                            operation="SET",
                            backend=self.backend_name,
                            success=False,
                            details={"error": str(e), "file": str(img.abs_path)},
                        )
                # Populate distributed embedding cache (normalize to list[float])
                if self.embedding_cache:
                    try:
                        vec: List[float]
                        if hasattr(features, "tolist"):
                            vec = features.tolist()  # type: ignore[attr-defined]
                        elif isinstance(features, (list, tuple)):
                            vec = list(features)
                        else:
                            # Best-effort coercion; may raise if non-iterable
                            vec = list(features)  # type: ignore
                        # Coerce numeric types
                        vec = [float(x) for x in vec]
                        self.embedding_cache.set_embedding(str(img.abs_path), vec)
                    except Exception as e:
                        logger.debug(f"Embedding cache set failed: {e}")
                        # Do not treat embedding cache failure as fatal; skip gov failure log to reduce noise

                # Compute legacy pHash for clustering (TODO: use CLIP embeddings)
                img.hash_phash = self.hasher.compute_hash(img.abs_path)
            except Exception as e:
                logger.error(f"Feature extraction failed for {img.abs_path.name}: {e}")
                self.gov_logger.log_error(
                    error_type="FEATURE_EXTRACTION_ERROR",
                    message=f"Failed to extract features from {img.abs_path.name}",
                    details={"file": str(img.abs_path), "error": str(e)},
                )

        logger.info(
            f"Feature extraction: {cache_hits} cache hits, {cache_misses} cache misses"
        )
        return (cache_hits, cache_misses)

    def _create_report(self) -> ValidationReport:
        """Create validation report from results"""
        return ValidationReport(
            timestamp=datetime.now().isoformat(),
            project_dir=str(self.project_dir),
            total_images=len(self.scanned_images),
            indexed_images=len([img for img in self.scanned_images if img.hash_phash]),
            clusters_detected=len(self.clusters),
            duplicates=len(self.duplicates),
            clusters=self.clusters
            + self.duplicates,  # Combine similarity clusters and exact duplicates
            metadata={
                "backend": self.backend_name,
                "fast_mode": self.fast_mode,
                "similarity_threshold": self.similarity_threshold,
                "cache_enabled": self.use_cache,
                "cache_status": self.cache.status() if self.cache else None,
            },
        )

    def _create_empty_report(self) -> ValidationReport:
        """Create empty report when no images found"""
        return ValidationReport(
            timestamp=datetime.now().isoformat(),
            project_dir=str(self.project_dir),
            total_images=0,
            indexed_images=0,
            clusters_detected=0,
            duplicates=0,
            clusters=[],
            metadata={
                "backend": self.backend_name,
                "fast_mode": self.fast_mode,
                "cache_enabled": self.use_cache,
            },
        )

    def export_report(self, output_path: Path) -> None:
        """
        Export validation report to JSON file

        Args:
            output_path: Path to output JSON file
        """
        report = self._create_report()

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report.to_dict(), f, indent=2, ensure_ascii=False)

        print(f"\nReport saved to: {output_path}")
        # Emit sentinel for streaming UI to know where report is
        print(f"##BPyReportPath:{output_path}")

    def close(self) -> None:
        """Clean up resources (close cache connection)"""
        if self.cache:
            self.cache.close()
            logger.info("Validator resources closed")

    def _calculate_anomaly_score_stub(
        self, img: ImageFile, cluster_id: Optional[str]
    ) -> float:
        """
        Phase 5 anomaly scoring stub - deterministic mock implementation.

        In production, this would use ML model or statistical analysis.
        For now, generates synthetic scores based on image properties.

        Args:
            img: ImageFile to score
            cluster_id: Optional cluster membership

        Returns:
            Anomaly score between 0 and 1 (higher = more anomalous)
        """
        # Deterministic seed from file path for reproducibility
        import hashlib

        seed = int(hashlib.md5(img.path.encode()).hexdigest()[:8], 16)

        # Base score from path hash (deterministic)
        base_score = (seed % 100) / 100.0

        # Adjust based on cluster membership
        if cluster_id:
            # Images in clusters are less anomalous
            base_score *= 0.7
        else:
            # Singleton images slightly more anomalous
            base_score *= 1.2

        # File size factor (very small or very large files are more anomalous)
        try:
            size_bytes = img.abs_path.stat().st_size
            if size_bytes < 10000:  # < 10KB
                base_score *= 1.3
            elif size_bytes > 5000000:  # > 5MB
                base_score *= 1.2
        except Exception:
            pass

        # Clamp to [0, 1]
        return min(1.0, max(0.0, base_score))
