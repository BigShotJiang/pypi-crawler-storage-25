from __future__ import annotations

# Use relative imports to work within the branchpy package structure
import sys
from pathlib import Path
from typing import Any, Mapping

# Add parent paths to allow imports
_root = Path(__file__).parent.parent.parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from BranchPyApp.validation.policy import ValidationPolicy
from BranchPyApp.validation.registry import registry


def _asset_integrity(target: str, ctx: Mapping[str, Any]) -> bool:
    fs = ctx.get("fs")
    if not fs or not hasattr(fs, "exists"):
        return False
    exists = bool(fs.exists(target))
    meta = ctx.get("metadata", {}).get(target, {})
    return bool(exists and meta)


def _checksum_verified(target: str, ctx: Mapping[str, Any]) -> bool:
    expected = ctx.get("checksums", {}).get(target)
    actual = ctx.get("checksums_computed", {}).get(target)
    return (expected is None) or (expected == actual)


def register_bqf_policies() -> None:
    registry.register(
        ValidationPolicy(
            name="asset.integrity",
            summary="Asset exists and has metadata",
            predicate=lambda ctx: _asset_integrity(ctx.get("target", ""), ctx),
        )
    )
    registry.register(
        ValidationPolicy(
            name="checksum.verified",
            summary="Checksum matches expected value",
            predicate=lambda ctx: _checksum_verified(ctx.get("target", ""), ctx),
        )
    )
