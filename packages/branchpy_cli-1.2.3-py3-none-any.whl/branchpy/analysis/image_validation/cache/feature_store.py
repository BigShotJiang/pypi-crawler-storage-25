"""
LMDB Feature Store - Persistent caching for image embeddings
Stores CLIP/pHash features with metadata for incremental updates
"""

import json
import logging
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

try:
    import lmdb
    import numpy as np

    LMDB_AVAILABLE = True
except ImportError:
    LMDB_AVAILABLE = False

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """Metadata for cached feature vector"""

    file_path: str
    file_size: int
    file_mtime: float
    backend: str  # 'phash' or 'clip'
    feature_dim: int
    cached_at: str  # ISO timestamp

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, data: str) -> "CacheEntry":
        return cls(**json.loads(data))


class FeatureStore:
    """
    LMDB-based persistent storage for image feature vectors

    Uses two databases:
    - vectors: file_path -> numpy array (feature vector)
    - meta: file_path -> CacheEntry (metadata)

    Cache invalidation based on file mtime/size changes
    """

    def __init__(
        self,
        db_path: Path,
        map_size: int = 10 * 1024 * 1024 * 1024,  # 10GB
        readonly: bool = False,
    ):
        """
        Initialize feature store

        Args:
            db_path: Path to LMDB database directory
            map_size: Maximum database size (default 10GB)
            readonly: Open in read-only mode
        """
        if not LMDB_AVAILABLE:
            raise ImportError("FeatureStore requires: pip install lmdb numpy")

        self.db_path = Path(db_path)
        self.db_path.mkdir(parents=True, exist_ok=True)

        # Open LMDB environment with two named databases
        self.env = lmdb.open(
            str(self.db_path),
            map_size=map_size,
            max_dbs=2,
            readonly=readonly,
            lock=not readonly,
        )

        # Create/open named databases
        with self.env.begin(write=True) as txn:
            self.vectors_db = self.env.open_db(b"vectors", txn=txn)
            self.meta_db = self.env.open_db(b"meta", txn=txn)

        logger.info(f"Feature store initialized at {self.db_path}")

    def get_embedding(
        self, file_path: Path, backend: str, validate_cache: bool = True
    ) -> Optional["np.ndarray"]:
        """
        Retrieve cached feature vector

        Args:
            file_path: Path to image file
            backend: Backend name ('phash' or 'clip')
            validate_cache: Check if cache is still valid

        Returns:
            Feature vector if cached and valid, else None
        """
        key = self._make_key(file_path, backend)

        with self.env.begin() as txn:
            # Get metadata
            meta_data = txn.get(key, db=self.meta_db)
            if meta_data is None:
                return None

            entry = CacheEntry.from_json(meta_data.decode("utf-8"))

            # Validate cache if requested
            if validate_cache:
                if not self._is_valid(file_path, entry):
                    logger.debug(f"Cache invalidated for {file_path.name}")
                    return None

            # Get feature vector
            vector_data = txn.get(key, db=self.vectors_db)
            if vector_data is None:
                return None

            # Deserialize numpy array
            features = np.frombuffer(vector_data, dtype=np.float32)

            return features

    def set_embedding(
        self, file_path: Path, backend: str, features: "np.ndarray"
    ) -> None:
        """
        Store feature vector in cache

        Args:
            file_path: Path to image file
            backend: Backend name
            features: Feature vector to cache
        """
        key = self._make_key(file_path, backend)

        # Get file metadata
        stat = file_path.stat()
        entry = CacheEntry(
            file_path=str(file_path),
            file_size=stat.st_size,
            file_mtime=stat.st_mtime,
            backend=backend,
            feature_dim=len(features),
            cached_at=datetime.utcnow().isoformat(),
        )

        # Serialize data
        meta_data = entry.to_json().encode("utf-8")
        vector_data = features.astype(np.float32).tobytes()

        # Store in database
        with self.env.begin(write=True) as txn:
            txn.put(key, meta_data, db=self.meta_db)
            txn.put(key, vector_data, db=self.vectors_db)

        logger.debug(f"Cached features for {file_path.name}")

    def invalidate(self, file_path: Path, backend: str) -> None:
        """Delete cached entry"""
        key = self._make_key(file_path, backend)

        with self.env.begin(write=True) as txn:
            txn.delete(key, db=self.meta_db)
            txn.delete(key, db=self.vectors_db)

    def purge(self, backend: Optional[str] = None) -> int:
        """
        Remove all cached entries

        Args:
            backend: Only purge specific backend (None = all)

        Returns:
            Number of entries removed
        """
        count = 0

        with self.env.begin(write=True) as txn:
            cursor = txn.cursor(db=self.meta_db)

            for key, value in cursor:
                # Filter by backend if specified
                if backend:
                    entry = CacheEntry.from_json(value.decode("utf-8"))
                    if entry.backend != backend:
                        continue

                # Delete from both databases
                txn.delete(key, db=self.meta_db)
                txn.delete(key, db=self.vectors_db)
                count += 1

        logger.info(f"Purged {count} entries from cache")
        return count

    def status(self) -> Dict[str, Any]:
        """
        Get cache statistics

        Returns:
            Dictionary with stats (total_entries, size_mb, backends)
        """
        stats = {"total_entries": 0, "size_mb": 0.0, "backends": {}}

        with self.env.begin() as txn:
            # Count entries by backend
            cursor = txn.cursor(db=self.meta_db)
            for key, value in cursor:
                entry = CacheEntry.from_json(value.decode("utf-8"))

                stats["total_entries"] += 1
                stats["backends"][entry.backend] = (
                    stats["backends"].get(entry.backend, 0) + 1
                )

        # Get database size
        env_info = self.env.info()
        stats["size_mb"] = env_info["map_size"] / (1024 * 1024)

        return stats

    def close(self):
        """Close database connection"""
        self.env.close()
        logger.info("Feature store closed")

    def _make_key(self, file_path: Path, backend: str) -> bytes:
        """Generate cache key from file path and backend"""
        # Use normalized absolute path + backend as key
        path_str = str(file_path.resolve())
        key = f"{backend}:{path_str}"
        return key.encode("utf-8")

    def _is_valid(self, file_path: Path, entry: CacheEntry) -> bool:
        """Check if cached entry is still valid"""
        try:
            stat = file_path.stat()

            # Invalidate if file size or mtime changed
            if stat.st_size != entry.file_size:
                return False
            if stat.st_mtime != entry.file_mtime:
                return False

            return True

        except FileNotFoundError:
            return False


__all__ = ["FeatureStore", "CacheEntry"]
