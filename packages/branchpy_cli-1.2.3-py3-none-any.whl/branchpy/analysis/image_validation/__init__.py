"""
Image Validation V3 - Advanced duplicate detection and similarity clustering

Components:
- scanner: Scan game/images directory and build file index
- hasher: Compute perceptual hashes (pHash) for duplicate detection
- clustering: Group similar images using DBSCAN or hierarchical clustering
- clip_backend: (Optional) Use CLIP embeddings for semantic similarity
- exporter: Generate JSON reports for VS Code panel

Usage:
    from branchpy.analysis.image_validation import ImageValidator

    validator = ImageValidator(project_dir=Path("."), backend="phash", fast_mode=False)
    report = validator.validate()
"""

__version__ = "0.8.8.5"

from .models import ImageCluster, ImageFile, ValidationReport
from .validator import ImageValidator

__all__ = [
    "ImageValidator",
    "ValidationReport",
    "ImageCluster",
    "ImageFile",
]
