"""
Perceptual hashing (pHash) for duplicate/similar image detection
Uses canonical preprocessing pipeline for stable hashing
"""

from __future__ import annotations

from pathlib import Path

try:
    import numpy as np
    from PIL import Image

    HAS_PIL = True
except ImportError:
    HAS_PIL = False

from .config import IV_CONFIG
from .preprocess import preprocess_for_phash


class PerceptualHasher:
    """
    Compute perceptual hashes for images using canonical preprocessing

    All hashing now uses:
    - EXIF orientation correction
    - ICC -> sRGB color normalization
    - 8-bit grayscale conversion
    - Deterministic LANCZOS resizing
    - Stable np.rint() rounding for binary threshold
    """

    def __init__(self, hash_size: int = 8):
        """
        Initialize hasher

        Args:
            hash_size: Size of hash grid (default 8x8 = 64-bit hash)
        """
        if not HAS_PIL:
            raise ImportError(
                "PIL (Pillow) is required for perceptual hashing. Install with: pip install Pillow"
            )

        self.hash_size = hash_size or IV_CONFIG.PHASH_SIZE

    def compute_hash(self, image_path: Path) -> str:
        """
        Compute canonical perceptual hash (pHash) for an image

        Pipeline:
        1. Preprocess with canonical pipeline (EXIF, ICC, grayscale, resize)
        2. Compute DCT
        3. Extract top-left 8x8 from DCT
        4. Compare to median using stable rounding
        5. Convert binary to hex string

        Args:
            image_path: Path to image file

        Returns:
            64-character hex string representing the hash
        """
        try:
            # Use canonical preprocessing pipeline
            pixels = preprocess_for_phash(image_path, hash_size=self.hash_size)

            # Compute DCT (simplified version using FFT for speed)
            dct = self._dct2d(pixels)

            # Extract top-left hash_size x hash_size region (skip DC component)
            dct_low = dct[1 : self.hash_size + 1, 1 : self.hash_size + 1]

            # Compute median
            median = np.median(dct_low)

            # Create binary hash using stable rounding
            # np.rint ensures consistent rounding at 0.5 boundaries
            binary_hash = np.rint(dct_low > median).astype(np.uint8)

            # Convert to hex string
            hex_hash = self._binary_array_to_hex(binary_hash.flatten())

            return hex_hash

        except Exception as e:
            print(f"[pHash] Failed to hash {image_path.name}: {e}")
            return ""

    def hamming_distance(self, hash1: str, hash2: str) -> int:
        """
        Compute Hamming distance between two hashes

        Args:
            hash1, hash2: Hex hash strings

        Returns:
            Number of differing bits (0-64 for 8x8 hash)
        """
        if not hash1 or not hash2 or len(hash1) != len(hash2):
            return self.hash_size * self.hash_size  # Maximum distance if invalid

        # Convert hex to binary
        bin1 = bin(int(hash1, 16))[2:].zfill(len(hash1) * 4)
        bin2 = bin(int(hash2, 16))[2:].zfill(len(hash2) * 4)

        # Count differing bits
        return sum(c1 != c2 for c1, c2 in zip(bin1, bin2))

    def similarity_score(self, hash1: str, hash2: str) -> float:
        """
        Compute similarity score (0-1) between two hashes

        Args:
            hash1, hash2: Hex hash strings

        Returns:
            Similarity score (1.0 = identical, 0.0 = completely different)
        """
        distance = self.hamming_distance(hash1, hash2)
        max_distance = self.hash_size * self.hash_size  # 64 for 8x8
        return 1.0 - (distance / max_distance)

    def _dct2d(self, image: np.ndarray) -> np.ndarray:
        """
        Simplified 2D Discrete Cosine Transform using FFT

        Args:
            image: 2D numpy array

        Returns:
            DCT coefficients
        """
        # Pad to next power of 2 for efficient FFT
        h, w = image.shape
        size = max(h, w)
        padded = np.zeros((size, size), dtype=np.float32)
        padded[:h, :w] = image

        # Compute FFT (approximation of DCT for speed)
        fft = np.fft.fft2(padded)

        # Take real part of top-left quadrant
        dct = np.real(fft[:h, :w])

        return dct

    def _binary_array_to_hex(self, binary_array: np.ndarray) -> str:
        """
        Convert binary numpy array to hex string

        Uses stable conversion: uint8 array -> binary string -> hex
        """
        # Convert uint8 array to binary string
        binary_str = "".join("1" if b else "0" for b in binary_array)

        # Convert to hex (pad to correct length)
        hex_str = hex(int(binary_str, 2))[2:].zfill(len(binary_array) // 4)

        return hex_str
