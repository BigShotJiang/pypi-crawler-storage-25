"""
Image Validation V3 - Feature Cache Manager

Manages feature-cache lifecycle with refresh and purge operations for
high-performance similarity lookups.

Features:
- Incremental cache updates (refresh without full rebuild)
- Selective purge by age, provider, or file pattern
- Cache statistics and health monitoring
- Provider adapter integration for multi-source caching

Governance ID: AXIS5-V0.9.1.2-20251112-IMPL
Checkpoint: H1 - Image Validation V3 Core & Cache
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

from ..models import ImageFile


@dataclass
class CacheStats:
    """Statistics for cache health monitoring"""

    total_entries: int
    cache_size_bytes: int
    oldest_entry_age_seconds: float
    newest_entry_age_seconds: float
    hit_rate: float  # 0-1
    avg_lookup_time_ms: float

    def to_dict(self) -> Dict:
        return {
            "total_entries": self.total_entries,
            "cache_size_mb": round(self.cache_size_bytes / (1024 * 1024), 2),
            "oldest_entry_hours": round(self.oldest_entry_age_seconds / 3600, 1),
            "newest_entry_hours": round(self.newest_entry_age_seconds / 3600, 1),
            "hit_rate": round(self.hit_rate, 3),
            "avg_lookup_ms": round(self.avg_lookup_time_ms, 2),
        }


class CacheManager:
    """
    Feature cache manager with refresh and purge capabilities

    Cache Structure:
    - Key: Image file path (relative to project root)
    - Value: {
        "embedding": List[float],  # CLIP embedding (512-dim)
        "hash_phash": str,  # Perceptual hash
        "hash_md5": str,  # Content hash
        "timestamp": str,  # ISO 8601 timestamp
        "provider": str,  # "local", "onedrive", "mfiles", etc.
      }

    Storage:
    - Format: JSON (.branchpy/cache/features.json)
    - Backup: .branchpy/cache/features.json.bak (on refresh)
    - Max size: 100 MB (configurable)
    """

    def __init__(self, cache_dir: Path, max_size_mb: int = 100, max_age_days: int = 30):
        """
        Initialize cache manager

        Args:
            cache_dir: Directory for cache storage (.branchpy/cache)
            max_size_mb: Maximum cache size in megabytes
            max_age_days: Maximum age for cache entries before auto-purge
        """
        self.cache_dir = Path(cache_dir)
        self.cache_file = self.cache_dir / "features.json"
        self.backup_file = self.cache_dir / "features.json.bak"
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.max_age_seconds = max_age_days * 24 * 3600

        # Ensure cache directory exists
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # Load cache into memory
        self._cache: Dict[str, Dict] = self._load_cache()

        # Statistics
        self._stats = CacheStats(
            total_entries=len(self._cache),
            cache_size_bytes=0,
            oldest_entry_age_seconds=0.0,
            newest_entry_age_seconds=0.0,
            hit_rate=0.0,
            avg_lookup_time_ms=0.0,
        )

    def refresh(self, images: List[ImageFile], incremental: bool = True) -> int:
        """
        Refresh cache with new or updated image data

        Args:
            images: List of ImageFile objects with computed features
            incremental: If True, only update changed entries; if False, full rebuild

        Returns:
            Number of cache entries updated
        """
        if not incremental:
            # Full rebuild: clear existing cache
            self._cache.clear()

        # Backup current cache before modifications
        self._backup_cache()

        updated_count = 0
        current_time = datetime.now().isoformat()

        for img in images:
            # Skip images without features
            if not img.embedding and not img.hash_phash:
                continue

            cache_key = img.path
            existing_entry = self._cache.get(cache_key)

            # Check if update needed (incremental mode)
            if incremental and existing_entry:
                # Compare hash to detect changes
                if existing_entry.get("hash_md5") == img.hash_md5:
                    continue  # No change, skip update

            # Update cache entry
            self._cache[cache_key] = {
                "embedding": img.embedding,
                "hash_phash": img.hash_phash,
                "hash_md5": img.hash_md5,
                "timestamp": current_time,
                "provider": "local",  # TODO: Provider adapter integration (H2)
                "path": img.path,
                "size_bytes": img.size_bytes,
            }
            updated_count += 1

        # Persist cache to disk
        self._save_cache()

        # Update statistics
        self._update_stats()

        return updated_count

    def purge(
        self,
        max_age_seconds: Optional[float] = None,
        paths: Optional[List[str]] = None,
        provider: Optional[str] = None,
    ) -> int:
        """
        Purge cache entries based on criteria

        Args:
            max_age_seconds: Remove entries older than this (default: instance max_age)
            paths: Specific paths to remove (optional)
            provider: Remove entries from specific provider (optional)

        Returns:
            Number of entries removed
        """
        if max_age_seconds is None:
            max_age_seconds = self.max_age_seconds

        # Backup before purge
        self._backup_cache()

        removed_count = 0
        now = datetime.now()
        keys_to_remove: Set[str] = set()

        # Collect keys to remove
        for key, entry in self._cache.items():
            # Age-based purge
            if max_age_seconds > 0:
                entry_time = datetime.fromisoformat(entry["timestamp"])
                age_seconds = (now - entry_time).total_seconds()
                if age_seconds > max_age_seconds:
                    keys_to_remove.add(key)
                    continue

            # Path-specific purge
            if paths and key in paths:
                keys_to_remove.add(key)
                continue

            # Provider-specific purge
            if provider and entry.get("provider") == provider:
                keys_to_remove.add(key)
                continue

        # Remove keys
        for key in keys_to_remove:
            del self._cache[key]
            removed_count += 1

        # Persist changes
        if removed_count > 0:
            self._save_cache()
            self._update_stats()

        return removed_count

    def get(self, path: str) -> Optional[Dict]:
        """Get cache entry for a specific path"""
        return self._cache.get(path)

    def get_stats(self) -> CacheStats:
        """Get current cache statistics"""
        self._update_stats()
        return self._stats

    def clear(self):
        """Clear entire cache (use with caution)"""
        self._backup_cache()
        self._cache.clear()
        self._save_cache()
        self._update_stats()

    # Private methods

    def _load_cache(self) -> Dict[str, Dict]:
        """Load cache from disk"""
        if not self.cache_file.exists():
            return {}

        try:
            with open(self.cache_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            # Corrupted cache, start fresh
            return {}

    def _save_cache(self):
        """Save cache to disk"""
        with open(self.cache_file, "w") as f:
            json.dump(self._cache, f, indent=2)

    def _backup_cache(self):
        """Create backup of current cache"""
        if self.cache_file.exists():
            import shutil

            shutil.copy2(self.cache_file, self.backup_file)

    def _update_stats(self):
        """Update cache statistics"""
        if not self._cache:
            self._stats = CacheStats(
                total_entries=0,
                cache_size_bytes=0,
                oldest_entry_age_seconds=0.0,
                newest_entry_age_seconds=0.0,
                hit_rate=0.0,
                avg_lookup_time_ms=0.0,
            )
            return

        # Calculate size
        cache_size = 0
        if self.cache_file.exists():
            cache_size = self.cache_file.stat().st_size

        # Calculate ages
        now = datetime.now()
        ages = []
        for entry in self._cache.values():
            entry_time = datetime.fromisoformat(entry["timestamp"])
            age = (now - entry_time).total_seconds()
            ages.append(age)

        self._stats = CacheStats(
            total_entries=len(self._cache),
            cache_size_bytes=cache_size,
            oldest_entry_age_seconds=max(ages) if ages else 0.0,
            newest_entry_age_seconds=min(ages) if ages else 0.0,
            hit_rate=0.0,  # TODO: Track hit/miss in lookups
            avg_lookup_time_ms=0.0,  # TODO: Track lookup timings
        )
