"""
Image Validation V3 - Advanced cluster detection engine for 10,000+ image scalability

This module implements the V3 architecture for image validation with:
- High-performance cluster detection (≤0.9s per image at 10k scale)
- Feature-cache refresh and purge mechanisms
- Provider adapter integration framework
- Telemetry hooks for validation latency tracking

Governance ID: AXIS5-V0.9.1.2-20251112-IMPL
Phase: H1 - Image Validation V3 Core & Cache
"""

from __future__ import annotations

__version__ = "0.9.1.2"
__all__ = ["ClusterEngine", "CacheManager"]


# Lazy imports to avoid circular dependencies
def __getattr__(name: str):
    if name == "ClusterEngine":
        from .cluster_engine import ClusterEngine

        return ClusterEngine
    elif name == "CacheManager":
        from .cache_manager import CacheManager

        return CacheManager
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
