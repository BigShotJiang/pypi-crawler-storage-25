"""
Image Validation V3 - Semantic Linkage
Auto-tagging for characters, scenes, locations, and objects
"""

from .linker import SemanticLinker
from .nodes import NodeType, SemanticNode

__all__ = ["SemanticNode", "NodeType", "SemanticLinker"]
