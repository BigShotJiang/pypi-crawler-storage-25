"""
Semantic Node Models - Character, Scene, Location, Object taxonomy
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import numpy as np

    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False


class NodeType(str, Enum):
    """Semantic node types for visual novel assets"""

    CHARACTER = "character"
    SCENE = "scene"
    LOCATION = "location"
    OBJECT = "object"
    UNKNOWN = "unknown"


@dataclass
class SemanticNode:
    """
    Semantic node representing a logical entity in the visual novel

    Examples:
    - Character: "alice", "bob", "protagonist"
    - Scene: "bedroom_morning", "cafe_afternoon"
    - Location: "school", "downtown", "beach"
    - Object: "sword", "letter", "phone"
    """

    node_id: str  # Unique identifier (e.g., "char_alice")
    node_type: NodeType
    display_name: str  # Human-readable name
    members: List[str] = field(default_factory=list)  # Image file paths
    centroid: Optional[List[float]] = None  # Average CLIP embedding (512-dim)
    confidence: float = 0.0  # Confidence score (0-1)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def add_member(
        self, image_path: str, embedding: Optional["np.ndarray"] = None
    ) -> None:
        """
        Add image to this node and update centroid

        Args:
            image_path: Path to image file
            embedding: CLIP embedding (512-dim numpy array)
        """
        if image_path not in self.members:
            self.members.append(image_path)

        # Update centroid with running average
        if embedding is not None and NUMPY_AVAILABLE:
            if self.centroid is None:
                self.centroid = embedding.tolist()
            else:
                # Running average: new_centroid = old_centroid + (new_embedding - old_centroid) / count
                centroid_array = np.array(self.centroid)
                count = len(self.members)
                new_centroid = centroid_array + (embedding - centroid_array) / count
                self.centroid = new_centroid.tolist()

    def compute_similarity(self, embedding: "np.ndarray") -> float:
        """
        Compute cosine similarity between embedding and node centroid

        Args:
            embedding: CLIP embedding to compare

        Returns:
            Similarity score (0-1)
        """
        if not NUMPY_AVAILABLE or self.centroid is None:
            return 0.0

        centroid_array = np.array(self.centroid)

        # Cosine similarity (both are L2-normalized)
        similarity = float(np.dot(centroid_array, embedding))
        return max(0.0, min(1.0, similarity))

    def to_dict(self) -> Dict[str, Any]:
        """Export to dictionary"""
        return {
            "node_id": self.node_id,
            "node_type": self.node_type.value,
            "display_name": self.display_name,
            "members": self.members,
            "member_count": len(self.members),
            "centroid": self.centroid,
            "confidence": self.confidence,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SemanticNode":
        """Load from dictionary"""
        return cls(
            node_id=data["node_id"],
            node_type=NodeType(data["node_type"]),
            display_name=data["display_name"],
            members=data.get("members", []),
            centroid=data.get("centroid"),
            confidence=data.get("confidence", 0.0),
            metadata=data.get("metadata", {}),
        )


@dataclass
class SemanticGraph:
    """Collection of semantic nodes with save/load capability"""

    nodes: Dict[str, SemanticNode] = field(default_factory=dict)  # node_id -> node
    project_dir: Optional[Path] = None

    def add_node(self, node: SemanticNode) -> None:
        """Add or update node"""
        self.nodes[node.node_id] = node

    def get_node(self, node_id: str) -> Optional[SemanticNode]:
        """Retrieve node by ID"""
        return self.nodes.get(node_id)

    def get_nodes_by_type(self, node_type: NodeType) -> List[SemanticNode]:
        """Get all nodes of specific type"""
        return [node for node in self.nodes.values() if node.node_type == node_type]

    def find_best_match(
        self,
        embedding: "np.ndarray",
        node_type: Optional[NodeType] = None,
        threshold: float = 0.7,
    ) -> Optional[SemanticNode]:
        """
        Find most similar node to given embedding

        Args:
            embedding: CLIP embedding
            node_type: Filter by node type (optional)
            threshold: Minimum similarity required

        Returns:
            Best matching node or None
        """
        candidates = self.nodes.values()
        if node_type:
            candidates = [n for n in candidates if n.node_type == node_type]

        best_node = None
        best_similarity = threshold

        for node in candidates:
            if node.centroid is None:
                continue

            similarity = node.compute_similarity(embedding)
            if similarity > best_similarity:
                best_similarity = similarity
                best_node = node

        return best_node

    def save(self, output_path: Path) -> None:
        """Save graph to JSON file"""
        data = {
            "nodes": {node_id: node.to_dict() for node_id, node in self.nodes.items()},
            "project_dir": str(self.project_dir) if self.project_dir else None,
        }

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, input_path: Path) -> "SemanticGraph":
        """Load graph from JSON file"""
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        graph = cls(
            project_dir=Path(data["project_dir"]) if data.get("project_dir") else None
        )

        for node_id, node_data in data.get("nodes", {}).items():
            graph.add_node(SemanticNode.from_dict(node_data))

        return graph

    def stats(self) -> Dict[str, Any]:
        """Get statistics"""
        stats = {
            "total_nodes": len(self.nodes),
            "total_images": sum(len(node.members) for node in self.nodes.values()),
            "by_type": {},
        }

        for node_type in NodeType:
            nodes = self.get_nodes_by_type(node_type)
            if nodes:
                stats["by_type"][node_type.value] = {
                    "count": len(nodes),
                    "images": sum(len(node.members) for node in nodes),
                }

        return stats


__all__ = ["NodeType", "SemanticNode", "SemanticGraph"]
