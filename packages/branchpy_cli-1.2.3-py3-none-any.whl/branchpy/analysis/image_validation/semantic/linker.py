"""
Semantic Linker - Auto-tagging engine for image classification

Extracts hints from filenames and CLIP embeddings to automatically
classify images into character/scene/location/object nodes.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import numpy as np

    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

from ..backends import BaseBackend
from .nodes import NodeType, SemanticGraph, SemanticNode

logger = logging.getLogger(__name__)


class FilenameHintExtractor:
    """Extract semantic hints from image filenames"""

    # Common RenPy/visual novel naming conventions
    PATTERNS = {
        NodeType.CHARACTER: [
            r"^char[_-]([a-zA-Z0-9]+)",  # char_alice.png
            r"^([a-zA-Z]+)[_-](?:normal|happy|sad|angry)",  # alice_happy.png
            r"^sprite[_-]([a-zA-Z0-9]+)",  # sprite_bob.png
        ],
        NodeType.SCENE: [
            r"^(?:cg|scene)[_-]([a-zA-Z0-9_]+)",  # cg_bedroom_morning.png
            r"^event[_-]([a-zA-Z0-9_]+)",  # event_confession.png
        ],
        NodeType.LOCATION: [
            r"^(?:bg|background)[_-]([a-zA-Z0-9_]+)",  # bg_school.png
            r"^loc[_-]([a-zA-Z0-9_]+)",  # loc_downtown.png
        ],
        NodeType.OBJECT: [
            r"^(?:item|obj|object)[_-]([a-zA-Z0-9_]+)",  # item_sword.png
            r"^prop[_-]([a-zA-Z0-9_]+)",  # prop_letter.png
        ],
    }

    def extract(self, filename: str) -> Optional[Tuple[NodeType, str]]:
        """
        Extract node type and identifier from filename

        Args:
            filename: Image filename (e.g., "char_alice_happy.png")

        Returns:
            (NodeType, identifier) or None if no pattern matches
        """
        stem = Path(filename).stem.lower()

        for node_type, patterns in self.PATTERNS.items():
            for pattern in patterns:
                match = re.match(pattern, stem)
                if match:
                    identifier = match.group(1)
                    return (node_type, identifier)

        return None

    def suggest_display_name(self, identifier: str, node_type: NodeType) -> str:
        """
        Generate human-readable display name

        Args:
            identifier: Raw identifier (e.g., "alice" or "bedroom_morning")
            node_type: Node type

        Returns:
            Display name (e.g., "Alice" or "Bedroom (Morning)")
        """
        # Replace underscores with spaces
        display = identifier.replace("_", " ").replace("-", " ")

        # Title case each word
        display = " ".join(word.capitalize() for word in display.split())

        return display


class SemanticLinker:
    """
    Auto-tagging engine using filename hints + CLIP embeddings

    Algorithm:
    1. Extract filename hints (char_, bg_, etc.)
    2. For images with hints: create/update nodes
    3. For images without hints: cluster by CLIP similarity
    4. Update centroids incrementally
    5. Compute confidence scores
    """

    def __init__(
        self,
        backend: BaseBackend,
        similarity_threshold: float = 0.75,
        min_cluster_size: int = 3,
    ):
        """
        Initialize semantic linker

        Args:
            backend: Feature extraction backend (should be CLIP for best results)
            similarity_threshold: Minimum similarity to link to existing node
            min_cluster_size: Minimum images to form new node
        """
        self.backend = backend
        self.similarity_threshold = similarity_threshold
        self.min_cluster_size = min_cluster_size
        self.hint_extractor = FilenameHintExtractor()

    def build_graph(
        self,
        image_paths: List[Path],
        embeddings: Dict[str, "np.ndarray"],
        existing_graph: Optional[SemanticGraph] = None,
    ) -> SemanticGraph:
        """
        Build semantic graph from images and embeddings

        Args:
            image_paths: List of image paths
            embeddings: Dictionary mapping path -> CLIP embedding
            existing_graph: Existing graph to update (or None for new)

        Returns:
            Updated semantic graph
        """
        if not NUMPY_AVAILABLE:
            logger.warning("NumPy not available, semantic linking disabled")
            return existing_graph or SemanticGraph()

        graph = existing_graph or SemanticGraph()

        # Track images that couldn't be auto-classified
        unclassified: List[Tuple[Path, np.ndarray]] = []

        # Step 1: Process images with filename hints
        logger.info("Processing filename hints...")
        for image_path in image_paths:
            path_str = str(image_path)
            embedding = embeddings.get(path_str)

            if embedding is None:
                logger.warning(f"No embedding for {image_path.name}")
                continue

            hint = self.hint_extractor.extract(image_path.name)

            if hint:
                node_type, identifier = hint
                node_id = f"{node_type.value}_{identifier}"

                # Get or create node
                node = graph.get_node(node_id)
                if node is None:
                    display_name = self.hint_extractor.suggest_display_name(
                        identifier, node_type
                    )
                    node = SemanticNode(
                        node_id=node_id,
                        node_type=node_type,
                        display_name=display_name,
                        confidence=0.9,  # High confidence from filename
                    )
                    graph.add_node(node)

                # Add image to node
                node.add_member(path_str, embedding)
                logger.debug(f"Linked {image_path.name} → {node_id}")

            else:
                # No filename hint, queue for clustering
                unclassified.append((image_path, embedding))

        # Step 2: Try to link unclassified images to existing nodes
        logger.info(f"Linking {len(unclassified)} unclassified images...")
        still_unclassified: List[Tuple[Path, np.ndarray]] = []

        for image_path, embedding in unclassified:
            best_node = graph.find_best_match(
                embedding, threshold=self.similarity_threshold
            )

            if best_node:
                best_node.add_member(str(image_path), embedding)
                logger.debug(
                    f"Linked {image_path.name} → {best_node.node_id} (similarity)"
                )
            else:
                still_unclassified.append((image_path, embedding))

        # Step 3: Cluster remaining images
        if still_unclassified and len(still_unclassified) >= self.min_cluster_size:
            logger.info(f"Clustering {len(still_unclassified)} remaining images...")
            new_nodes = self._cluster_images(still_unclassified)

            for node in new_nodes:
                graph.add_node(node)
                logger.info(
                    f"Created cluster: {node.node_id} ({len(node.members)} images)"
                )

        # Step 4: Compute confidence scores
        self._compute_confidence_scores(graph)

        logger.info(
            f"Semantic graph built: {len(graph.nodes)} nodes, {sum(len(n.members) for n in graph.nodes.values())} images"
        )

        return graph

    def _cluster_images(
        self, images: List[Tuple[Path, "np.ndarray"]]
    ) -> List[SemanticNode]:
        """
        Cluster unclassified images using hierarchical clustering

        Args:
            images: List of (path, embedding) tuples

        Returns:
            List of new semantic nodes
        """
        if not NUMPY_AVAILABLE:
            return []

        # Build similarity matrix
        n = len(images)
        similarity_matrix = np.zeros((n, n))

        for i in range(n):
            for j in range(i + 1, n):
                sim = float(np.dot(images[i][1], images[j][1]))
                similarity_matrix[i, j] = sim
                similarity_matrix[j, i] = sim

        # Simple agglomerative clustering
        clusters: List[List[int]] = [[i] for i in range(n)]

        while len(clusters) > 1:
            # Find most similar cluster pair
            best_sim = -1.0
            best_pair = (0, 1)

            for i in range(len(clusters)):
                for j in range(i + 1, len(clusters)):
                    # Average linkage
                    sims = [
                        similarity_matrix[a, b]
                        for a in clusters[i]
                        for b in clusters[j]
                    ]
                    avg_sim = sum(sims) / len(sims) if sims else 0.0

                    if avg_sim > best_sim:
                        best_sim = avg_sim
                        best_pair = (i, j)

            # Stop if similarity too low
            if best_sim < self.similarity_threshold:
                break

            # Merge clusters
            i, j = best_pair
            clusters[i].extend(clusters[j])
            clusters.pop(j)

        # Create nodes from clusters
        nodes = []
        for cluster_idx, cluster in enumerate(clusters):
            if len(cluster) < self.min_cluster_size:
                continue

            # Compute centroid
            cluster_embeddings = [images[i][1] for i in cluster]
            centroid = np.mean(cluster_embeddings, axis=0)

            # Create node
            node_id = f"cluster_{cluster_idx:03d}"
            node = SemanticNode(
                node_id=node_id,
                node_type=NodeType.UNKNOWN,
                display_name=f"Cluster {cluster_idx + 1}",
                centroid=centroid.tolist(),
                confidence=0.5,  # Medium confidence from clustering
            )

            # Add members
            for i in cluster:
                node.add_member(str(images[i][0]), images[i][1])

            nodes.append(node)

        return nodes

    def _compute_confidence_scores(self, graph: SemanticGraph) -> None:
        """
        Compute confidence scores for all nodes

        Factors:
        - Filename hints: 0.9
        - CLIP similarity: 0.7-0.9 (based on intra-cluster variance)
        - Cluster size: bonus for larger clusters
        """
        if not NUMPY_AVAILABLE:
            return

        for node in graph.nodes.values():
            if node.confidence > 0.0:
                # Already set (e.g., from filename hints)
                continue

            if not node.centroid or len(node.members) < 2:
                node.confidence = 0.3  # Low confidence
                continue

            # Compute intra-cluster similarity (cohesion)
            # Higher cohesion = higher confidence
            centroid = np.array(node.centroid)
            similarities = []

            # We don't have embeddings stored in node, so use placeholder
            # In real implementation, would recalculate or cache
            node.confidence = 0.7  # Default medium-high for clustered nodes

            # Bonus for larger clusters
            if len(node.members) >= 10:
                node.confidence = min(1.0, node.confidence + 0.1)
            elif len(node.members) >= 5:
                node.confidence = min(1.0, node.confidence + 0.05)


__all__ = ["SemanticLinker", "FilenameHintExtractor"]
