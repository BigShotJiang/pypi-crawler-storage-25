"""Statement Extractor - Parse Ren'Py statements for CFG construction"""

from __future__ import annotations

import ast as python_ast
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class StatementType(Enum):
    """Ren'Py statement types"""

    LABEL = "label"
    SAY = "say"
    MENU = "menu"
    MENU_CHOICE = "menu_choice"
    PYTHON = "python"
    PYTHON_BLOCK = "python_block"
    IF = "if"
    ELIF = "elif"
    ELSE = "else"
    JUMP = "jump"
    CALL = "call"
    RETURN = "return"
    SHOW = "show"
    HIDE = "hide"
    SCENE = "scene"
    PLAY = "play"
    STOP = "stop"
    WITH = "with"
    WINDOW = "window"
    SCREEN = "screen"
    SCREEN_ACTION = "screen_action"
    EXECUTION_CONTAINER = "execution_container"  # For example:, minigames, screen loops
    UNKNOWN = "unknown"


@dataclass
class Statement:
    """Represents a single Ren'Py statement"""

    type: StatementType
    line: int
    file: str
    raw: str  # Raw text of the statement
    indent: int = 0

    # Type-specific data
    label_name: Optional[str] = None  # For LABEL
    speaker: Optional[str] = None  # For SAY
    text: Optional[str] = None  # For SAY, MENU_CHOICE
    target: Optional[str] = None  # For JUMP, CALL, SCREEN_ACTION
    condition: Optional[str] = None  # For IF, ELIF
    python_code: Optional[str] = None  # For PYTHON, PYTHON_BLOCK
    asset_name: Optional[str] = None  # For SHOW, HIDE, SCENE, PLAY
    choices: List[Statement] = field(default_factory=list)  # For MENU (child choices)

    # Screen action specific
    action_type: Optional[str] = None  # For SCREEN_ACTION: "jump", "call", "show"
    screen_name: Optional[str] = None  # For SCREEN, SCREEN_ACTION
    widget_type: Optional[str] = None  # For SCREEN_ACTION: "button", "textbutton", etc.

    # Execution container specific
    container_type: Optional[str] = (
        None  # For EXECUTION_CONTAINER: "example", "minigame", "screen_loop"
    )
    container_name: Optional[str] = None  # For EXECUTION_CONTAINER: name/identifier
    subgraph: List[Statement] = field(default_factory=list)  # Internal statements
    entry_points: List[str] = field(default_factory=list)  # Entry labels/edges
    exit_points: List[str] = field(default_factory=list)  # Exit labels/edges

    meta: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"Statement({self.type.value}, line={self.line}, target={self.target}, text={self.text[:30] if self.text else None})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert statement to JSON-serializable dict"""
        return {
            "type": self.type.value,
            "line": self.line,
            "file": self.file,
            "raw": self.raw,
            "indent": self.indent,
            "label_name": self.label_name,
            "speaker": self.speaker,
            "text": self.text,
            "target": self.target,
            "condition": self.condition,
            "python_code": self.python_code,
            "asset_name": self.asset_name,
            "choices": [c.to_dict() for c in self.choices],
            "action_type": self.action_type,
            "screen_name": self.screen_name,
            "widget_type": self.widget_type,
            "container_type": self.container_type,
            "container_name": self.container_name,
            "subgraph": [s.to_dict() for s in self.subgraph],
            "entry_points": self.entry_points,
            "exit_points": self.exit_points,
            "meta": self.meta,
        }


class StatementExtractor:
    """Extract statement-level information from Ren'Py files"""

    def __init__(self):
        # Regex patterns for various statement types
        self.patterns = {
            "label": re.compile(r"^(\s*)label\s+([A-Za-z_]\w*)\s*:\s*(.*)$"),
            "example": re.compile(
                r"^(\s*)example\s+([A-Za-z_][\w\s]*?)\s*:\s*(.*)$"
            ),  # example minigame:, example large:, etc.
            "say_with_speaker": re.compile(r'^(\s*)([A-Za-z_]\w*)\s+"([^"]*)"'),
            "say_narration": re.compile(r'^(\s*)"([^"]*)"'),
            "menu": re.compile(r"^(\s*)menu\s*:\s*(.*)$"),
            "menu_choice": re.compile(r'^(\s*)"([^"]+)"\s*:\s*(.*)$'),
            "python_inline": re.compile(r"^(\s*)\$\s+(.+)$"),
            "python_block": re.compile(r"^(\s*)python\s*:\s*(.*)$"),
            "if": re.compile(r"^(\s*)if\s+(.+):\s*(.*)$"),
            "elif": re.compile(r"^(\s*)elif\s+(.+):\s*(.*)$"),
            "else": re.compile(r"^(\s*)else\s*:\s*(.*)$"),
            "jump": re.compile(r"^(\s*)jump\s+([A-Za-z_]\w*|\S+)\s*(.*)$"),
            # Call pattern captures: call <target> [from <callsite>] OR call screen <target>(...)
            # Target can be: label name, 'screen <name>', or any non-whitespace
            "call": re.compile(
                r"^(\s*)call\s+(screen\s+)?([A-Za-z_]\w*|\S+?)(?:\s+from\s+([A-Za-z_]\w*))?(?:\s*\(.*\))?\s*(.*)$"
            ),
            "return": re.compile(r"^(\s*)return\s*(.*)$"),
            "show": re.compile(r"^(\s*)show\s+(\S+)(.*)$"),
            "hide": re.compile(r"^(\s*)hide\s+(\S+)(.*)$"),
            "scene": re.compile(r"^(\s*)scene\s+(\S+)(.*)$"),
            "play": re.compile(r"^(\s*)play\s+(\w+)\s+(.+)$"),
            "stop": re.compile(r"^(\s*)stop\s+(\w+)(.*)$"),
            "with": re.compile(r"^(\s*)with\s+(\S+)(.*)$"),
            "screen": re.compile(r"^(\s*)screen\s+([A-Za-z_]\w*)\s*(.*):\s*(.*)$"),
        }

        # Pattern for screen actions in action= attributes
        # Match: action Jump("label") or action=Jump("label") or action [Call, Show, Return, etc]
        self.action_pattern = re.compile(r"action\s+(.+?)$|action\s*=\s*(.+)$")
        # Jump/Call with a string literal target: Jump("label") or Jump('label')
        self.jump_action = re.compile(r'Jump\s*\(\s*["\']([^"\']+)["\']\s*\)')
        self.call_action = re.compile(r'Call\s*\(\s*["\']([^"\']+)["\']\s*\)')
        # Jump/Call with a variable (identifier) target: Jump(var) or Call(var)
        self.jump_action_var = re.compile(r"Jump\s*\(\s*([A-Za-z_]\w*)\s*\)")
        self.call_action_var = re.compile(r"Call\s*\(\s*([A-Za-z_]\w*)\s*\)")
        self.show_action = re.compile(r'Show\s*\(\s*["\']([^"\']+)["\']\s*\)')
        self.return_action = re.compile(
            r'Return\s*\(\s*(?:["\']([^"\']+)["\']\s*)?\)'
        )  # Return() or Return(value)
        # Tier 3: Screen write actions (SetVariable, ToggleVariable, SetField)
        # SetVariable("var_name", value) - Extracts var_name
        self.setvariable_action = re.compile(
            r'SetVariable\s*\(\s*["\']([^"\']+)["\']\s*,\s*(.+?)\)'
        )
        # ToggleVariable("var_name") - Extracts var_name
        self.togglevariable_action = re.compile(
            r'ToggleVariable\s*\(\s*["\']([^"\']+)["\']\s*\)'
        )
        # SetField(object, "field_name", value) - Extracts object and field_name
        self.setfield_action = re.compile(
            r'SetField\s*\(\s*([^,]+?)\s*,\s*["\']([^"\']+)["\']\s*,\s*(.+?)\)'
        )
        # Patterns for Python-driven flow (renpy.jump/call in Python blocks)
        # Only match string literals (not variables) for RC-safe extraction
        self.renpy_jump_pattern = re.compile(
            r'renpy\.jump\s*\(\s*["\']([^"\']+)["\']\s*\)'
        )
        self.renpy_call_pattern = re.compile(
            r'renpy\.call\s*\(\s*["\']([^"\']+)["\']\s*(?:,.*?)?\)'
        )
        self.renpy_call_context_pattern = re.compile(
            r'renpy\.call_in_new_context\s*\(\s*["\']([^"\']+)["\']\s*(?:,.*?)?\)'
        )

    def extract_statements(self, content: str, file_path: str) -> List[Statement]:
        """
        Extract all statements from Ren'Py file content.

        Args:
            content: File content as string
            file_path: Relative path to file (for tracking)

        Returns:
            List of Statement objects with full context
        """
        statements: List[Statement] = []
        lines = content.split("\n")

        in_python_block = False
        python_block_lines: List[str] = []
        python_block_start = 0
        python_block_indent = 0

        in_example_block = False
        example_block_statements: List[Statement] = []
        example_block_start = 0
        example_block_indent = 0
        example_container_name = ""
        example_container_type = "example"

        in_menu = False
        menu_start_line = 0
        menu_indent = 0
        menu_choices: List[Statement] = []
        menu_stmt_index = -1  # Track index of menu statement in statements list

        for i, line in enumerate(lines, start=1):
            # Skip empty lines and comments
            if not line.strip() or line.strip().startswith("#"):
                continue

            indent = len(line) - len(line.lstrip())

            # Handle python blocks (multi-line)
            if in_python_block:
                if line.strip() and not line.strip().startswith("#"):
                    # Check if we're still in the block (indented more than python: line)
                    if indent > python_block_indent or not line.strip():
                        python_block_lines.append(line)
                        continue

                # End of python block
                python_code = "\\n".join(python_block_lines)
                stmt = Statement(
                    type=StatementType.PYTHON_BLOCK,
                    line=python_block_start,
                    file=file_path,
                    raw=python_code,
                    indent=python_block_indent,
                    python_code=python_code,
                )
                statements.append(stmt)

                # Extract Python flow edges (renpy.jump/call)
                python_flow_edges = self.extract_python_flow_edges(
                    python_code, python_block_start, file_path
                )
                statements.extend(python_flow_edges)

                in_python_block = False
                python_block_lines = []
                # Fall through to process current line

            # Handle example blocks (execution containers)
            if in_example_block:
                if line.strip() and not line.strip().startswith("#"):
                    # Check if we're still in the block (indented more than example: line)
                    if indent > example_block_indent or not line.strip():
                        # Recursively extract statements within example block
                        # Process this line as a normal statement
                        inner_stmt = self._extract_single_statement(
                            line, i, file_path, lines
                        )
                        if inner_stmt:
                            example_block_statements.extend(inner_stmt)
                        continue

                # End of example block - create container
                container_stmt = Statement(
                    type=StatementType.EXECUTION_CONTAINER,
                    line=example_block_start,
                    file=file_path,
                    raw=f"example {example_container_name}:",
                    indent=example_block_indent,
                    container_type=example_container_type,
                    container_name=example_container_name,
                    subgraph=example_block_statements,
                    meta={
                        "execution_container": True,
                        "container_category": "tutorial",
                        "collapsed_by_default": True,
                    },
                )
                statements.append(container_stmt)

                in_example_block = False
                example_block_statements = []
                # Fall through to process current line

            # Handle menu blocks
            if in_menu:
                # Check if still in menu (indented more than menu: line)
                if indent > menu_indent:
                    # This is a menu choice or action within choice
                    choice_match = self.patterns["menu_choice"].match(line)
                    if choice_match:
                        choice_indent, choice_text, rest = choice_match.groups()
                        choice_stmt = Statement(
                            type=StatementType.MENU_CHOICE,
                            line=i,
                            file=file_path,
                            raw=line.strip(),
                            indent=len(choice_indent),
                            text=choice_text,
                        )
                        menu_choices.append(choice_stmt)
                        continue  # Skip further processing of menu choice line itself
                    # If not a choice line, fall through to process as normal statement
                    # (these are statements INSIDE menu choices, like jumps, calls, python, etc.)
                else:
                    # End of menu
                    if menu_stmt_index >= 0 and menu_stmt_index < len(statements):
                        menu_stmt = statements[menu_stmt_index]
                        menu_stmt.choices = menu_choices
                    in_menu = False
                    menu_choices = []
                    menu_stmt_index = -1
                    # Fall through to process current line

            # Try to match statement patterns
            matched = False

            # Label
            if m := self.patterns["label"].match(line):
                indent_str, label_name, rest = m.groups()
                stmt = Statement(
                    type=StatementType.LABEL,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    label_name=label_name,
                )
                statements.append(stmt)
                matched = True

            # Screen
            elif m := self.patterns["screen"].match(line):
                indent_str, screen_name = m.groups()[:2]
                stmt = Statement(
                    type=StatementType.SCREEN,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    screen_name=screen_name,
                )
                statements.append(stmt)
                matched = True

                # Extract screen actions from the rest of the file
                # (Simple approach: scan from here to end or next screen/label)
                screen_content_lines = []
                screen_line_numbers = []  # Track actual line numbers
                j = i  # Start from current line (i is 1-indexed)
                screen_indent = len(indent_str)
                while j < len(lines):
                    next_line = lines[j]  # j is now 0-indexed relative to lines array
                    if not next_line.strip():
                        j += 1
                        continue
                    next_indent = len(next_line) - len(next_line.lstrip())
                    if next_indent <= screen_indent and next_line.strip() and j > i - 1:
                        # End of screen block (j > i - 1 ensures we don't stop on screen: line itself)
                        break
                    if j > i - 1:  # Don't include the screen: line itself
                        screen_content_lines.append(next_line)
                        screen_line_numbers.append(j + 1)  # Convert back to 1-indexed
                    j += 1

                # Extract actions from screen content
                if screen_content_lines:
                    screen_actions = self.extract_screen_actions(
                        screen_content_lines,
                        screen_line_numbers,
                        file_path,
                        screen_name,
                    )
                    statements.extend(screen_actions)

            # Menu
            elif m := self.patterns["menu"].match(line):
                indent_str, rest = m.groups()
                stmt = Statement(
                    type=StatementType.MENU,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                )
                statements.append(stmt)
                menu_stmt_index = (
                    len(statements) - 1
                )  # Save index to update choices later
                in_menu = True
                menu_start_line = i
                menu_indent = len(indent_str)
                matched = True

            # Example block (execution container)
            elif m := self.patterns["example"].match(line):
                indent_str, container_name, rest = m.groups()
                in_example_block = True
                example_block_start = i
                example_block_indent = len(indent_str)
                example_container_name = container_name.strip()
                example_block_statements = []
                # Detect minigame vs generic example
                if "minigame" in example_container_name.lower():
                    example_container_type = "minigame"
                else:
                    example_container_type = "example"
                matched = True

            # Python block
            elif m := self.patterns["python_block"].match(line):
                indent_str, rest = m.groups()
                in_python_block = True
                python_block_start = i
                python_block_indent = len(indent_str)
                python_block_lines = [line]
                matched = True

            # Inline Python
            elif m := self.patterns["python_inline"].match(line):
                indent_str, code = m.groups()
                stmt = Statement(
                    type=StatementType.PYTHON,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    python_code=code.strip(),
                )
                statements.append(stmt)

                # Extract Python flow edges from inline Python
                python_flow_edges = self.extract_python_flow_edges(
                    code.strip(), i, file_path
                )
                statements.extend(python_flow_edges)

                matched = True

            # Jump
            elif m := self.patterns["jump"].match(line):
                indent_str, target, rest = m.groups()
                stmt = Statement(
                    type=StatementType.JUMP,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    target=target,
                )
                statements.append(stmt)
                matched = True

            # Call (includes 'call screen foo(...)')
            elif m := self.patterns["call"].match(line):
                indent_str, screen_kw, target, callsite, rest = m.groups()

                # Store metadata if this is a screen call
                is_screen_call = bool(screen_kw)

                stmt = Statement(
                    type=StatementType.CALL,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    target=target,
                )
                # Store callsite metadata (for return edge creation)
                if callsite:
                    stmt.meta["callsite"] = callsite
                if is_screen_call:
                    stmt.meta["call_type"] = "screen"
                statements.append(stmt)
                matched = True

            # Return
            elif m := self.patterns["return"].match(line):
                indent_str, rest = m.groups()
                stmt = Statement(
                    type=StatementType.RETURN,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                )
                statements.append(stmt)
                matched = True

            # If
            elif m := self.patterns["if"].match(line):
                indent_str, condition, rest = m.groups()
                stmt = Statement(
                    type=StatementType.IF,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    condition=condition.strip(),
                )
                statements.append(stmt)
                matched = True

            # Elif
            elif m := self.patterns["elif"].match(line):
                indent_str, condition, rest = m.groups()
                stmt = Statement(
                    type=StatementType.ELIF,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    condition=condition.strip(),
                )
                statements.append(stmt)
                matched = True

            # Else
            elif m := self.patterns["else"].match(line):
                indent_str, rest = m.groups()
                stmt = Statement(
                    type=StatementType.ELSE,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                )
                statements.append(stmt)
                matched = True

            # Show
            elif m := self.patterns["show"].match(line):
                indent_str, asset, rest = m.groups()
                stmt = Statement(
                    type=StatementType.SHOW,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    asset_name=asset,
                )
                statements.append(stmt)
                matched = True

            # Say with speaker
            elif m := self.patterns["say_with_speaker"].match(line):
                indent_str, speaker, text = m.groups()
                stmt = Statement(
                    type=StatementType.SAY,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    speaker=speaker,
                    text=text,
                )
                statements.append(stmt)
                matched = True

            # Say narration (no speaker)
            elif m := self.patterns["say_narration"].match(line):
                indent_str, text = m.groups()
                stmt = Statement(
                    type=StatementType.SAY,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=len(indent_str),
                    text=text,
                )
                statements.append(stmt)
                matched = True

            # Unknown statement type
            if not matched and line.strip():
                stmt = Statement(
                    type=StatementType.UNKNOWN,
                    line=i,
                    file=file_path,
                    raw=line.strip(),
                    indent=indent,
                )
                statements.append(stmt)

        return statements

    def _collect_multiline_action_block(
        self,
        content_lines: List[str],
        start_idx: int,
    ) -> str:
        """
        Given that content_lines[start_idx] contains an unclosed '[',
        scan forward until a matching ']' is found and return the concatenated
        text of the whole block (all lines joined with spaces).
        """
        text = content_lines[start_idx]
        depth = text.count("[") - text.count("]")
        i = start_idx + 1
        while depth > 0 and i < len(content_lines):
            chunk = content_lines[i]
            text += " " + chunk
            depth += chunk.count("[") - chunk.count("]")
            i += 1
        return text

    def _emit_jump_call_from_expr(
        self,
        action_expr: str,
        line_num: int,
        file_path: str,
        screen_name: str,
        widget_type: Optional[str],
    ) -> List["Statement"]:
        """
        Given a (possibly multi-line, bracket-collected) action expression,
        emit SCREEN_ACTION statements for every Jump()/Call() found — both
        string-literal and variable-identifier forms.

        A string-literal target (Jump("label")) → target is the label name.
        A variable-identifier target (Jump(var)) → target is the variable name;
        _add_call_screen_edge will later resolve it through dataflow.
        """
        results: List[Statement] = []

        # String-literal Jump  e.g. Jump("morning_after")
        for m in self.jump_action.finditer(action_expr):
            results.append(
                Statement(
                    type=StatementType.SCREEN_ACTION,
                    line=line_num,
                    file=file_path,
                    raw=action_expr[:120],  # truncate for readability
                    target=m.group(1),
                    action_type="jump",
                    screen_name=screen_name,
                    widget_type=widget_type,
                )
            )

        # Variable-identifier Jump  e.g. Jump(next_chapter)
        if not results:  # only fall through if no literal match
            for m in self.jump_action_var.finditer(action_expr):
                var = m.group(1)
                # Skip Python built-ins / known non-label identifiers
                if var in ("True", "False", "None"):
                    continue
                results.append(
                    Statement(
                        type=StatementType.SCREEN_ACTION,
                        line=line_num,
                        file=file_path,
                        raw=action_expr[:120],
                        target=var,  # variable name; resolved later via dataflow
                        action_type="jump",
                        screen_name=screen_name,
                        widget_type=widget_type,
                    )
                )

        # String-literal Call  e.g. Call("label")
        for m in self.call_action.finditer(action_expr):
            results.append(
                Statement(
                    type=StatementType.SCREEN_ACTION,
                    line=line_num,
                    file=file_path,
                    raw=action_expr[:120],
                    target=m.group(1),
                    action_type="call",
                    screen_name=screen_name,
                    widget_type=widget_type,
                )
            )

        # Variable-identifier Call  e.g. Call(next_scene)
        if not any(s.action_type == "call" for s in results):
            for m in self.call_action_var.finditer(action_expr):
                var = m.group(1)
                if var in ("True", "False", "None"):
                    continue
                results.append(
                    Statement(
                        type=StatementType.SCREEN_ACTION,
                        line=line_num,
                        file=file_path,
                        raw=action_expr[:120],
                        target=var,
                        action_type="call",
                        screen_name=screen_name,
                        widget_type=widget_type,
                    )
                )

        return results

    def extract_screen_actions(
        self,
        content_lines: List[str],
        line_numbers: List[int],
        file_path: str,
        screen_name: str,
    ) -> List[Statement]:
        """
        Extract action statements from screen blocks (Jump/Call/Show from buttons).

        This is a simple pattern-based extractor that finds textbutton/imagebutton/button
        with action= containing Jump(), Call(), or Show().

        Args:
            content_lines: List of lines from the screen block
            line_numbers: List of actual line numbers in the original file
            file_path: File path for tracking
            screen_name: Name of the screen
        """
        actions: List[Statement] = []

        for idx, line in enumerate(content_lines):
            # Skip comments and empty lines
            if not line.strip() or line.strip().startswith("#"):
                continue

            # ── Button widgets that carry navigation actions ─────────────────
            if "action" in line and any(
                widget in line.lower()
                for widget in ["textbutton", "imagebutton", "button"]
            ):
                widget_type = None
                for widget in ["textbutton", "imagebutton", "button"]:
                    if widget in line.lower():
                        widget_type = widget
                        break

                action_match = self.action_pattern.search(line)
                if action_match:
                    action_expr = action_match.group(1) or action_match.group(2)
                    action_expr = action_expr.strip() if action_expr else ""
                    line_num = line_numbers[idx] if idx < len(line_numbers) else idx + 1

                    # Multi-line action list:  action [\n  ...\n  Jump(var)\n  ...]
                    # When the captured expression starts with '[' and that bracket
                    # is never closed on the same line, collect continuation lines.
                    if action_expr.startswith("[") and action_expr.count(
                        "["
                    ) > action_expr.count("]"):
                        action_expr = self._collect_multiline_action_block(
                            content_lines, idx
                        )

                    # ── Navigation actions: Jump / Call (literal or variable) ─
                    nav_stmts = self._emit_jump_call_from_expr(
                        action_expr, line_num, file_path, screen_name, widget_type
                    )
                    if nav_stmts:
                        actions.extend(nav_stmts)
                        continue  # navigation and state actions are mutually exclusive

                    # ── Show() ───────────────────────────────────────────────
                    if show_match := self.show_action.search(action_expr):
                        actions.append(
                            Statement(
                                type=StatementType.SCREEN_ACTION,
                                line=line_num,
                                file=file_path,
                                raw=line.strip(),
                                target=show_match.group(1),
                                action_type="show",
                                screen_name=screen_name,
                                widget_type=widget_type,
                            )
                        )
                        continue

                    # ── Return() ─────────────────────────────────────────────
                    if self.return_action.search(action_expr):
                        actions.append(
                            Statement(
                                type=StatementType.SCREEN_ACTION,
                                line=line_num,
                                file=file_path,
                                raw=line.strip(),
                                target=None,
                                action_type="return",
                                screen_name=screen_name,
                                widget_type=widget_type,
                            )
                        )
                        continue

                    # ── Tier 3: state-mutation actions ────────────────────────
                    if setvariable_match := self.setvariable_action.search(action_expr):
                        var_name = setvariable_match.group(1)
                        value_expr = setvariable_match.group(2).strip()
                        actions.append(
                            Statement(
                                type=StatementType.SCREEN_ACTION,
                                line=line_num,
                                file=file_path,
                                raw=line.strip(),
                                target=var_name,
                                action_type="setvariable",
                                screen_name=screen_name,
                                widget_type=widget_type,
                                meta={"value": value_expr},
                            )
                        )
                        continue

                    if togglevariable_match := self.togglevariable_action.search(
                        action_expr
                    ):
                        actions.append(
                            Statement(
                                type=StatementType.SCREEN_ACTION,
                                line=line_num,
                                file=file_path,
                                raw=line.strip(),
                                target=togglevariable_match.group(1),
                                action_type="togglevariable",
                                screen_name=screen_name,
                                widget_type=widget_type,
                            )
                        )
                        continue

                    if setfield_match := self.setfield_action.search(action_expr):
                        object_name = setfield_match.group(1).strip()
                        field_name = setfield_match.group(2)
                        value_expr = setfield_match.group(3).strip()
                        actions.append(
                            Statement(
                                type=StatementType.SCREEN_ACTION,
                                line=line_num,
                                file=file_path,
                                raw=line.strip(),
                                target=f"{object_name}.{field_name}",
                                action_type="setfield",
                                screen_name=screen_name,
                                widget_type=widget_type,
                                meta={
                                    "object": object_name,
                                    "field": field_name,
                                    "value": value_expr,
                                },
                            )
                        )

        return actions

    def extract_python_flow_edges(
        self,
        python_code: str,
        line_num: int,
        file_path: str,
    ) -> List[Statement]:
        """
        Extract flow control edges from Python code (renpy.jump/call).

        Only extracts string-literal targets (RC-safe, low risk).
        Dynamic targets (variables, expressions) are ignored for v1.0.

        Args:
            python_code: Python code to analyze (from $ line or python: block)
            line_num: Line number in original file
            file_path: File path for tracking

        Returns:
            List of Statement objects with flow edges
        """
        edges: List[Statement] = []

        # Split into lines for line-accurate reporting
        lines = python_code.split("\n")

        for offset, line in enumerate(lines):
            actual_line = line_num + offset

            # Skip comments and empty lines
            if not line.strip() or line.strip().startswith("#"):
                continue

            # Check for renpy.jump("label")
            if jump_match := self.renpy_jump_pattern.search(line):
                target = jump_match.group(1)
                edges.append(
                    Statement(
                        type=StatementType.JUMP,
                        line=actual_line,
                        file=file_path,
                        raw=line.strip(),
                        target=target,
                        meta={"flow_source": "python", "flow_pattern": "renpy.jump"},
                    )
                )

            # Check for renpy.call("label")
            elif call_match := self.renpy_call_pattern.search(line):
                target = call_match.group(1)
                edges.append(
                    Statement(
                        type=StatementType.CALL,
                        line=actual_line,
                        file=file_path,
                        raw=line.strip(),
                        target=target,
                        meta={"flow_source": "python", "flow_pattern": "renpy.call"},
                    )
                )

            # Check for renpy.call_in_new_context("label")
            elif context_match := self.renpy_call_context_pattern.search(line):
                target = context_match.group(1)
                edges.append(
                    Statement(
                        type=StatementType.CALL,
                        line=actual_line,
                        file=file_path,
                        raw=line.strip(),
                        target=target,
                        meta={
                            "flow_source": "python",
                            "flow_pattern": "renpy.call_in_new_context",
                        },
                    )
                )

        return edges

    def _extract_single_statement(
        self, line: str, line_num: int, file_path: str, all_lines: List[str]
    ) -> List[Statement]:
        """
        Extract a single statement from a line (used for example block content).
        Returns list because some statements (like screens) may generate multiple entries.

        This is a simplified, non-recursive version for use within example blocks.
        """
        statements = []

        if not line.strip() or line.strip().startswith("#"):
            return statements

        indent = len(line) - len(line.lstrip())

        # Label
        if m := self.patterns["label"].match(line):
            indent_str, label_name, rest = m.groups()
            stmt = Statement(
                type=StatementType.LABEL,
                line=line_num,
                file=file_path,
                raw=line.strip(),
                indent=len(indent_str),
                label_name=label_name,
                meta={"inside_example": True},  # Mark as inside example container
            )
            statements.append(stmt)

        # Jump
        elif m := self.patterns["jump"].match(line):
            indent_str, target, rest = m.groups()
            stmt = Statement(
                type=StatementType.JUMP,
                line=line_num,
                file=file_path,
                raw=line.strip(),
                indent=len(indent_str),
                target=target,
                meta={"inside_example": True},
            )
            statements.append(stmt)

        # Call
        elif m := self.patterns["call"].match(line):
            indent_str, screen_kw, target, callsite, rest = m.groups()
            stmt = Statement(
                type=StatementType.CALL,
                line=line_num,
                file=file_path,
                raw=line.strip(),
                indent=len(indent_str),
                target=target,
                meta={"inside_example": True},
            )
            if screen_kw:
                stmt.meta["call_type"] = "screen"
            if callsite:
                stmt.meta["callsite"] = callsite
            statements.append(stmt)

        # Return
        elif m := self.patterns["return"].match(line):
            indent_str, rest = m.groups()
            stmt = Statement(
                type=StatementType.RETURN,
                line=line_num,
                file=file_path,
                raw=line.strip(),
                indent=len(indent_str),
                meta={"inside_example": True},
            )
            statements.append(stmt)

        # Python inline ($)
        elif m := self.patterns["python_inline"].match(line):
            indent_str, code = m.groups()
            stmt = Statement(
                type=StatementType.PYTHON,
                line=line_num,
                file=file_path,
                raw=line.strip(),
                indent=len(indent_str),
                python_code=code.strip(),
                meta={"inside_example": True},
            )
            statements.append(stmt)

            # Extract Python flow edges
            python_flow_edges = self.extract_python_flow_edges(
                code.strip(), line_num, file_path
            )
            for edge in python_flow_edges:
                edge.meta["inside_example"] = True
            statements.extend(python_flow_edges)

        return statements

    def analyze_python_code(self, code: str) -> Dict[str, Any]:
        """
        Analyze Python code for function calls, assignments, jumps.

        Returns:
            Dict with: calls, assignments, jumps, unresolved
        """
        result = {
            "calls": [],  # Function calls
            "assignments": {},  # var -> value (if constant)
            "jumps": [],  # renpy.jump() calls
            "unresolved": [],  # Dynamic/unknown patterns
        }

        try:
            tree = python_ast.parse(code)

            for node in python_ast.walk(tree):
                # Assignments
                if isinstance(node, python_ast.Assign):
                    for target in node.targets:
                        if isinstance(target, python_ast.Name):
                            # Check if value is a constant
                            if isinstance(node.value, python_ast.Constant):
                                result["assignments"][target.id] = node.value.value
                            elif isinstance(node.value, python_ast.Name):
                                # Copy propagation: x = y
                                result["assignments"][target.id] = (
                                    "var",
                                    node.value.id,
                                )

                # Function calls
                elif isinstance(node, python_ast.Call):
                    func_name = self._get_call_name(node)
                    if func_name:
                        args = self._extract_call_args(node)
                        result["calls"].append({"name": func_name, "args": args})

                        # Check for renpy.jump()
                        if func_name in ("renpy.jump", "jump"):
                            if args and isinstance(args[0], str):
                                result["jumps"].append(args[0])
                            else:
                                result["unresolved"].append(
                                    {"type": "dynamic_jump", "call": func_name}
                                )

        except SyntaxError:
            result["unresolved"].append({"type": "parse_error", "code": code[:50]})

        return result

    def _get_call_name(self, node: python_ast.Call) -> Optional[str]:
        """Extract function name from Call node"""
        if isinstance(node.func, python_ast.Name):
            return node.func.id
        elif isinstance(node.func, python_ast.Attribute):
            # Handle module.function() calls
            parts = []
            current = node.func
            while isinstance(current, python_ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, python_ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None

    def _extract_call_args(self, node: python_ast.Call) -> List[Any]:
        """Extract arguments from Call node (constants only)"""
        args = []
        for arg in node.args:
            if isinstance(arg, python_ast.Constant):
                args.append(arg.value)
            elif isinstance(arg, python_ast.Name):
                args.append(("var", arg.id))
            else:
                args.append(None)  # Complex expression
        return args
