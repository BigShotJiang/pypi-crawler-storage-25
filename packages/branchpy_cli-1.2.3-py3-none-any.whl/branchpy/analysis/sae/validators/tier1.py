"""Tier-1 Validation Rules - Labels, Assets, Variables, Project Layout"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


class Severity(Enum):
    """Issue severity levels"""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class ValidationIssue:
    """Represents a validation issue"""

    rule_id: str
    severity: Severity
    message: str
    file: str
    line: int
    column: int = 0
    extra: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        d = {
            "rule_id": self.rule_id,
            "severity": self.severity.value,
            "message": self.message,
            "file": self.file,
            "line": self.line,
        }
        if self.column:
            d["column"] = self.column
        if self.extra:
            d["extra"] = self.extra
        return d


class Tier1Validator:
    """Tier-1 validation: labels, assets, variables, project layout"""

    def __init__(
        self,
        project_root: str | Path,
        index: Any,
        cfg: Any = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        """
        Args:
            project_root: Project root directory
            index: ProjectIndex from Indexer
            cfg: ControlFlowGraph from CFGBuilder (optional)
            config: Configuration dict for analysis rules
        """
        self.project_root = Path(project_root)
        self.index = index
        self.cfg = cfg
        self.config = config or {}
        self.issues: List[ValidationIssue] = []
        self.variable_metrics: Optional[Dict[str, Any]] = None
        self.locale_metrics: Optional[Dict[str, Any]] = None

    def validate(self) -> List[ValidationIssue]:
        """
        Run all Tier-1 validation rules.

        Returns:
            List of ValidationIssue objects
        """
        self.issues = []

        # TODO Gate 4: Implement validation rules
        self._validate_labels()
        self._validate_assets()
        self._validate_variables()
        self._validate_project_layout()

        # Phase 7: CFG-based validation rules
        if self.cfg:
            self._validate_cfg()

        # Phase 3: Character & Dialogue validation
        self._validate_dialogue()

        # Phase 4: Variable & Game State Analysis
        self._validate_game_state()

        # Phase 7: Localization Coverage (v0.7.7)
        self._validate_localization()

        return self.issues

    # === Label & Control Flow Rules ===

    def _validate_labels(self) -> None:
        """Validate label definitions and usage"""
        self._check_undefined_label_target()
        self._check_unused_label()
        self._check_duplicate_label()

    def _check_undefined_label_target(self) -> None:
        """Check for jumps/calls to undefined labels"""
        defined_labels = set(self.index.labels.keys())

        # Check jumps
        for jump_entry in self.index.jumps:
            if jump_entry.name not in defined_labels:
                self._add_issue(
                    rule_id="undefined_label_target",
                    severity=Severity.ERROR,
                    message=f"Jump to undefined label '{jump_entry.name}'",
                    file=jump_entry.file,
                    line=jump_entry.line,
                    target=jump_entry.name,
                )

        # Check calls
        for call_entry in self.index.calls:
            if call_entry.name not in defined_labels:
                self._add_issue(
                    rule_id="undefined_label_target",
                    severity=Severity.ERROR,
                    message=f"Call to undefined label '{call_entry.name}'",
                    file=call_entry.file,
                    line=call_entry.line,
                    target=call_entry.name,
                )

    def _check_unused_label(self) -> None:
        """Check for defined but unreferenced labels

        Excludes Ren'Py special labels that are auto-called by the engine.
        """
        # Load special labels from config
        special_labels = set(self.config.get("special_labels", []))

        # Add default Ren'Py special labels
        default_special = {
            "splashscreen",
            "before_main_menu",
            "main_menu",
            "after_load",
            "before_save",
            "quit",
            "_setup_common",
            "after_warp",
            "hide_windows",
        }
        special_labels.update(default_special)

        defined_labels = set(self.index.labels.keys())
        referenced_labels = set()

        # Collect all referenced labels
        for jump_entry in self.index.jumps:
            referenced_labels.add(jump_entry.name)
        for call_entry in self.index.calls:
            referenced_labels.add(call_entry.name)

        # 'start' is always considered used (entry point)
        referenced_labels.add("start")

        # Add all special labels as implicitly referenced
        referenced_labels.update(special_labels)

        # Find unused labels
        unused = defined_labels - referenced_labels
        for label_name in sorted(unused):
            label_entry = self.index.labels[label_name]
            self._add_issue(
                rule_id="unused_label",
                severity=Severity.WARNING,
                message=f"Label '{label_name}' is defined but never used",
                file=label_entry.file,
                line=label_entry.line,
                label=label_name,
            )

    def _check_duplicate_label(self) -> None:
        """Check for duplicate label definitions"""
        # Track label occurrences
        label_occurrences: Dict[str, List[Any]] = {}
        for label_name, label_entry in self.index.labels.items():
            if label_name not in label_occurrences:
                label_occurrences[label_name] = []
            label_occurrences[label_name].append(label_entry)

        # Report duplicates
        for label_name, entries in label_occurrences.items():
            if len(entries) > 1:
                for entry in entries:
                    self._add_issue(
                        rule_id="duplicate_label",
                        severity=Severity.ERROR,
                        message=f"Duplicate label definition: '{label_name}'",
                        file=entry.file,
                        line=entry.line,
                        label=label_name,
                        occurrences=len(entries),
                    )

    # === CFG-Based Rules (Phase 7) ===

    def _validate_cfg(self) -> None:
        """Validate CFG-based rules (requires StatementCFGBuilder)"""
        self._check_dynamic_jump_unresolved()
        self._check_semantics_miss()
        self._check_unreachable_code()
        self._check_menu_missing_fallthrough()
        self._check_menu_fallthrough()  # Phase 1: Menu fallthrough detection

    def _check_dynamic_jump_unresolved(self) -> None:
        """Check for JUMP_DYNAMIC edges that indicate unresolved targets"""
        if not self.cfg:
            return

        from branchpy.analysis.sae.cfg_builder import EdgeType

        for edge in self.cfg.edges:
            if edge.edge_type == EdgeType.JUMP_DYNAMIC:
                # Extract metadata from edge
                meta = edge.meta or {}
                expr_snippet = meta.get("expr_snippet", "?")
                reason = meta.get("reason", "unknown")

                # Get source node info
                source_node = self.cfg.nodes.get(edge.from_node)
                if not source_node:
                    continue

                # Build helpful message
                message = f"Jump target unresolved: `{expr_snippet}` ({reason})"
                suggestion = "Consider adding function to .branchpy/semantics.yaml or simplifying expression"

                self._add_issue(
                    rule_id="dynamic_jump_unresolved",
                    severity=Severity.WARNING,
                    message=message,
                    file=source_node.file,
                    line=source_node.line,
                    expr_snippet=expr_snippet,
                    reason=reason,
                    suggestion=suggestion,
                )

    def _check_semantics_miss(self) -> None:
        """Suggest reviewing semantics catalog for frequently unresolved wrapper functions"""
        if not self.cfg:
            return

        from branchpy.analysis.sae.cfg_builder import EdgeType

        # Track unresolved calls by function name
        unresolved_by_function: Dict[str, List[Any]] = {}

        for edge in self.cfg.edges:
            if edge.edge_type == EdgeType.JUMP_DYNAMIC:
                meta = edge.meta or {}

                # Extract callee from metadata
                callee = meta.get("callee")
                if not callee:
                    continue

                # Skip built-ins
                if callee.startswith("renpy."):
                    continue

                # Track this unresolved call
                if callee not in unresolved_by_function:
                    unresolved_by_function[callee] = []

                source_node = self.cfg.nodes.get(edge.from_node)
                if source_node:
                    unresolved_by_function[callee].append((source_node, edge))

        # Report functions with multiple unresolved calls (likely needs catalog tuning)
        for callee, occurrences in unresolved_by_function.items():
            if (
                len(occurrences) >= 2
            ):  # Multiple unresolved calls suggests catalog issue
                # Get first occurrence for reporting
                source_node, edge = occurrences[0]

                # Build suggested YAML entry
                yaml_suggestion = f"""
functions:
  - name: {callee}
    module: "*"
    kind: jump
    arg_index: 0
    # Consider adding transforms if needed
"""

                message = f"Function `{callee}` has {len(occurrences)} unresolved jump(s) - consider reviewing semantics.yaml"

                self._add_issue(
                    rule_id="semantics_miss",
                    severity=Severity.INFO,
                    message=message,
                    file=source_node.file,
                    line=source_node.line,
                    function=callee,
                    occurrences=len(occurrences),
                    suggestion=f"Review or enhance .branchpy/semantics.yaml:{yaml_suggestion.strip()}",
                )

    def _check_unreachable_code(self) -> None:
        """Detect statements after terminal jumps/returns by finding orphaned nodes"""
        if not self.cfg:
            return

        from branchpy.analysis.sae.cfg_builder import EdgeType, NodeKind

        # Build set of nodes that have incoming edges
        nodes_with_incoming: Set[str] = set()
        for edge in self.cfg.edges:
            nodes_with_incoming.add(edge.to_node)

        # Find all nodes without incoming edges (except entry points and labels)
        for node in self.cfg.nodes.values():
            # Skip labels (they're entry points)
            if node.kind == NodeKind.LABEL:
                continue

            # Skip if node has incoming edges
            if node.id in nodes_with_incoming:
                continue

            # Skip if this is an entry node
            if node.id in self.cfg.entry_nodes:
                continue

            # This node is unreachable - try to find what made it unreachable
            # Look for a terminal statement before this node in the same label
            terminal_type = "terminal statement"

            # Search backwards in the file for the terminal statement
            # (This is heuristic - we check for JUMP/RETURN nodes in same file with lower line numbers)
            for potential_terminal in self.cfg.nodes.values():
                if (
                    potential_terminal.file == node.file
                    and potential_terminal.line < node.line
                ):
                    if potential_terminal.kind == NodeKind.RETURN:
                        terminal_type = "return"
                        break
                    # Check if this node has a JUMP edge
                    has_jump = any(
                        e.from_node == potential_terminal.id
                        and e.edge_type == EdgeType.JUMP
                        for e in self.cfg.edges
                    )
                    if has_jump:
                        terminal_type = "jump"
                        break

            message = f"Code after `{terminal_type}` is unreachable"

            self._add_issue(
                rule_id="unreachable_code",
                severity=Severity.WARNING,
                message=message,
                file=node.file,
                line=node.line,
                terminal_type=terminal_type,
                suggestion="Remove or move to conditional block",
            )

    def _check_menu_missing_fallthrough(self) -> None:
        """Enhanced menu fallthrough check with severity grading"""
        if not self.cfg:
            return

        from branchpy.analysis.sae.cfg_builder import EdgeType, NodeKind

        # Find all menu nodes
        menu_nodes = [n for n in self.cfg.nodes.values() if n.kind == NodeKind.MENU]

        for menu_node in menu_nodes:
            # Get outgoing branch edges
            branch_edges = [
                e
                for e in self.cfg.edges
                if e.from_node == menu_node.id
                and e.edge_type in [EdgeType.BRANCH_TRUE, EdgeType.BRANCH_FALSE]
            ]

            # Check if there's an unconditional fallthrough (no condition)
            has_fallthrough = any(e.cond is None or e.cond == "" for e in branch_edges)

            if not has_fallthrough and len(branch_edges) > 0:
                # Determine severity based on number of choices
                if len(branch_edges) == 1:
                    severity = (
                        Severity.ERROR
                    )  # Single choice without fallthrough is likely a bug
                elif len(branch_edges) == 2:
                    severity = (
                        Severity.WARNING
                    )  # Two choices should probably have fallthrough
                else:
                    severity = Severity.INFO  # Many choices might be intentional

                message = f"Menu with {len(branch_edges)} choice(s) has no fallthrough/default option"

                self._add_issue(
                    rule_id="menu_missing_fallthrough",
                    severity=severity,
                    message=message,
                    file=menu_node.file,
                    line=menu_node.line,
                    choice_count=len(branch_edges),
                    suggestion="Add an unconditional choice or ensure all cases are covered",
                )

    # === Asset Rules ===

    def _validate_assets(self) -> None:
        """Validate asset references"""
        self._check_missing_image_file()
        self._check_missing_audio_file()
        self._check_unsupported_asset_ext()

    def _check_missing_image_file(self) -> None:
        """Check for missing image files"""
        # Look for images in common locations
        image_dirs = [
            self.project_root / "game" / "images",
            self.project_root / "images",
            self.project_root / "game",
        ]

        # Collect available image files
        available_images = set()
        for img_dir in image_dirs:
            if img_dir.exists():
                for ext in [".png", ".jpg", ".jpeg", ".webp"]:
                    available_images.update(f.stem for f in img_dir.rglob(f"*{ext}"))

        # Check each referenced image
        for image_name, image_entry in self.index.images.items():
            # Simple check: does the image name exist as a file?
            if image_name not in available_images:
                self._add_issue(
                    rule_id="missing_image_file",
                    severity=Severity.ERROR,
                    message=f"Image '{image_name}' not found in project",
                    file=image_entry.file,
                    line=image_entry.line,
                    asset_name=image_name,
                )

    def _check_missing_audio_file(self) -> None:
        """Check for missing audio files"""
        # Look for audio in common locations
        audio_dirs = [
            self.project_root / "game" / "audio",
            self.project_root / "audio",
            self.project_root / "game",
        ]

        # Collect available audio files
        available_audio = set()
        for audio_dir in audio_dirs:
            if audio_dir.exists():
                for ext in [".mp3", ".ogg", ".wav", ".opus"]:
                    available_audio.update(
                        str(f.relative_to(audio_dir))
                        for f in audio_dir.rglob(f"*{ext}")
                    )

        # Check each referenced audio file
        for audio_name, audio_entry in self.index.audio.items():
            # Check if the audio file exists (use the full name with extension)
            if audio_name not in available_audio:
                self._add_issue(
                    rule_id="missing_audio_file",
                    severity=Severity.ERROR,
                    message=f"Audio file '{audio_name}' not found in project",
                    file=audio_entry.file,
                    line=audio_entry.line,
                    asset_name=audio_name,
                )

    def _check_unsupported_asset_ext(self) -> None:
        """Check for unsupported asset extensions"""
        SUPPORTED_IMAGE = {".png", ".jpg", ".jpeg", ".webp"}
        SUPPORTED_AUDIO = {".mp3", ".ogg", ".wav", ".opus"}

        # Check audio files for unsupported extensions
        for audio_name, audio_entry in self.index.audio.items():
            audio_path = Path(audio_name)
            if audio_path.suffix and audio_path.suffix.lower() not in SUPPORTED_AUDIO:
                self._add_issue(
                    rule_id="unsupported_asset_ext",
                    severity=Severity.WARNING,
                    message=f"Unsupported audio extension: {audio_path.suffix}",
                    file=audio_entry.file,
                    line=audio_entry.line,
                    asset_name=audio_name,
                    extension=audio_path.suffix,
                )

    # === Variable Rules (Shallow) ===

    def _validate_variables(self) -> None:
        """Validate variable usage (shallow analysis)"""
        self._check_shadow_builtins()
        # read_before_write requires data flow analysis - skipped for Tier-1

    def _check_read_before_write(self) -> None:
        """Check for variables read before write (best-effort)"""
        # Stub - requires data flow analysis, deferred to Tier-2
        pass

    def _check_shadow_builtins(self) -> None:
        """Check for variables shadowing built-ins"""
        RENPY_BUILTINS = {
            "renpy",
            "config",
            "persistent",
            "True",
            "False",
            "None",
            "menu",
            "scene",
            "show",
            "hide",
            "with",
            "jump",
            "call",
            "return",
            "define",
            "default",
            "init",
            "label",
            "if",
            "elif",
            "else",
            "while",
            "for",
            "python",
            "image",
            "play",
            "stop",
            "voice",
            "transform",
        }

        for var_name, var_entries in self.index.variables.items():
            if var_name in RENPY_BUILTINS:
                for entry in var_entries:
                    self._add_issue(
                        rule_id="shadow_builtins",
                        severity=Severity.WARNING,
                        message=f"Variable '{var_name}' shadows a built-in name",
                        file=entry.file,
                        line=entry.line,
                        variable=var_name,
                    )

    # === Project Layout Rules ===

    def _validate_project_layout(self) -> None:
        """Validate project structure"""
        self._check_missing_game_dir()
        self._check_non_utf8_file()

    def _check_missing_game_dir(self) -> None:
        """Check for required game/ directory"""
        game_dir = self.project_root / "game"
        if not game_dir.exists():
            self._add_issue(
                rule_id="missing_game_dir",
                severity=Severity.ERROR,
                message="Required 'game/' directory not found",
                file="",
                line=0,
            )

    def _check_non_utf8_file(self) -> None:
        """Check for non-UTF-8 files"""
        # Check all indexed files
        for file_path in self.index.files:
            full_path = self.project_root / file_path
            if full_path.exists():
                try:
                    full_path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    self._add_issue(
                        rule_id="non_utf8_file",
                        severity=Severity.WARNING,
                        message="File is not UTF-8 encoded",
                        file=file_path,
                        line=0,
                    )

    def _check_menu_fallthrough(self) -> None:
        """Phase 1: Check for menu false choices and choices with no action"""
        if not self.cfg:
            return

        from branchpy.analysis.sae.validators.menu_fallthrough_validator import (
            validate_menu_fallthrough,
        )

        # Run menu fallthrough validator
        menu_issues = validate_menu_fallthrough(self.cfg)

        # Convert to ValidationIssue format and add to issues list
        for issue in menu_issues:
            self.issues.append(
                ValidationIssue(
                    rule_id=issue.rule_id,
                    severity=Severity.WARNING,  # All menu issues are warnings
                    message=issue.message,
                    file=issue.file,
                    line=issue.line,
                    extra=(
                        {"suggestion": issue.suggestion} if issue.suggestion else None
                    ),
                )
            )

    def _validate_dialogue(self) -> None:
        """Phase 3: Character & Dialogue validation"""
        from branchpy.analysis.sae.validators.dialogue_validator import (
            validate_dialogue_phase3,
        )

        # Run Phase 3 dialogue validation
        dialogue_issues, dialogue_metrics = validate_dialogue_phase3(
            self.index, self.project_root
        )

        # Convert dialogue issues to ValidationIssue format
        for issue in dialogue_issues:
            severity_map = {
                "error": Severity.ERROR,
                "warning": Severity.WARNING,
                "info": Severity.INFO,
            }

            self.issues.append(
                ValidationIssue(
                    rule_id=issue["rule_id"],
                    severity=severity_map.get(issue["severity"], Severity.INFO),
                    message=issue["message"],
                    file=issue["file"],
                    line=issue["line"],
                    extra=issue.get("extra"),
                )
            )

        # Store metrics for reporting (attached to validator instance)
        if not hasattr(self, "dialogue_metrics"):
            self.dialogue_metrics = dialogue_metrics

    def _validate_game_state(self) -> None:
        """Phase 4: Variables & Game State Analysis"""
        from branchpy.analysis.sae.validators.variable_analyzer import VariableAnalyzer

        # Run Phase 4 variable analysis
        analyzer = VariableAnalyzer(
            project_root=self.project_root,
            index=self.index,
            cfg=self.cfg,
            config=self.config,
        )

        var_issues, var_metrics = analyzer.run()

        # Convert variable issues to ValidationIssue format
        for issue in var_issues:
            severity_map = {
                "error": Severity.ERROR,
                "warning": Severity.WARNING,
                "info": Severity.INFO,
            }

            self.issues.append(
                ValidationIssue(
                    rule_id=issue["rule_id"],
                    severity=severity_map.get(issue["severity"], Severity.INFO),
                    message=issue["message"],
                    file=issue["file"],
                    line=issue["line"],
                    extra=issue.get("extra"),
                )
            )

        # Store metrics for reporting
        self.variable_metrics = var_metrics

    def _validate_localization(self) -> None:
        """Phase 7: Localization Coverage (v0.7.7)"""
        from branchpy.analysis.sae.locale_parser import LocaleParser
        from branchpy.analysis.sae.validators.locale_validator import (
            validate_locale_phase7,
        )

        # Check if localization is configured
        l10n_config = self.config.get("l10n", {})
        if not l10n_config.get("enabled", False):
            # Localization validation not enabled, skip
            return

        try:
            # Parse locale data
            parser = LocaleParser(self.project_root)
            languages = l10n_config.get("languages", [])
            locale_index = parser.parse(languages=languages if languages else None)

            # Skip if no languages detected
            if not locale_index.languages:
                return

            # Run Phase 7 locale validation
            required_languages = l10n_config.get("required", [])
            coverage_threshold = l10n_config.get("coverage_threshold", 80.0)

            locale_issues, locale_metrics = validate_locale_phase7(
                locale_index,
                self.project_root,
                required_languages=required_languages,
                coverage_threshold=coverage_threshold,
            )

            # Convert locale issues to ValidationIssue format
            for issue in locale_issues:
                self.issues.append(issue)

            # Store metrics for reporting
            self.locale_metrics = {
                "total_languages": locale_metrics.total_languages,
                "total_source_strings": locale_metrics.total_source_strings,
                "avg_coverage_pct": locale_metrics.avg_coverage_pct,
                "coverage_by_language": locale_metrics.coverage_by_language,
                "missing_count": locale_metrics.missing_count,
                "orphaned_count": locale_metrics.orphaned_count,
                "mismatch_count": locale_metrics.mismatch_count,
            }

            # Export locale index for reporting
            parser.export_index()

        except Exception as e:
            # Log warning but don't fail analysis
            import logging

            logger = logging.getLogger(__name__)
            logger.warning(f"Localization validation failed (non-fatal): {e}")

    def _add_issue(
        self,
        rule_id: str,
        severity: Severity,
        message: str,
        file: str,
        line: int,
        **extra,
    ) -> None:
        """Helper to add validation issue"""
        self.issues.append(
            ValidationIssue(
                rule_id=rule_id,
                severity=severity,
                message=message,
                file=file,
                line=line,
                extra=extra if extra else None,
            )
        )
