"""Phase 3: Character & Dialogue Validation - SAE v0.7.3

Validates character definitions, dialogue syntax, references, quality, and interpolation.

Rule Groups:
- C01: Character Definition Consistency
- C02: Dialogue Syntax Validation
- C03: Character Reference Validation
- C04: Dialogue Quality & Readability
- C05: Interpolation Integrity
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


@dataclass
class DialogueMetrics:
    """Dialogue analysis metrics"""

    dialogue_count: int = 0
    unique_characters: int = 0
    avg_read_time: float = 0.0
    errors: int = 0
    warnings: int = 0
    info: int = 0

    # Detailed metrics
    total_words: int = 0
    min_length: int = 0
    max_length: int = 0
    avg_length: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "dialogue_count": self.dialogue_count,
            "unique_characters": self.unique_characters,
            "avg_read_time": round(self.avg_read_time, 2),
            "errors": self.errors,
            "warnings": self.warnings,
            "info": self.info,
            "total_words": self.total_words,
            "min_length": self.min_length,
            "max_length": self.max_length,
            "avg_length": round(self.avg_length, 2),
        }


def validate_dialogue_phase3(
    index: Any, project_root: str | Path
) -> tuple[List[Dict[str, Any]], DialogueMetrics]:
    """
    Run Phase 3 character and dialogue validation.

    Args:
        index: ProjectIndex from Indexer with characters and dialogues
        project_root: Project root directory path

    Returns:
        Tuple of (issues_list, metrics)
    """
    validator = DialogueValidator(index, Path(project_root))
    issues = validator.validate()
    metrics = validator.metrics

    return issues, metrics


class DialogueValidator:
    """Phase 3: Character & Dialogue Validation"""

    def __init__(self, index: Any, project_root: Path):
        """
        Initialize dialogue validator.

        Args:
            index: ProjectIndex with characters and dialogues attributes
            project_root: Project root directory
        """
        self.index = index
        self.project_root = project_root
        self.issues: List[Dict[str, Any]] = []
        self.metrics = DialogueMetrics()

        # Reading speed constants (words per minute)
        self.WPM_FAST = 250
        self.WPM_NORMAL = 180
        self.WPM_SLOW = 130

        # Load project configuration (if exists)
        self.ignored_characters = self._load_ignored_characters()

    def _load_ignored_characters(self) -> Set[str]:
        """Load ignored character names from .branchpy/config.yaml"""
        import yaml

        # Try new location first: .branchpy/config.yaml
        config_file = self.project_root / ".branchpy" / "config.yaml"

        # Fallback to legacy location: .branchpy.yaml (for backward compatibility)
        if not config_file.exists():
            config_file = self.project_root / ".branchpy.yaml"

        if not config_file.exists():
            # Default ignored characters (Ren'Py built-ins)
            return {
                "style",
                "text",
                "background",
                "color",
                "hover_color",
                "hover_background",
                "insensitive_background",
                "id",
                "thumb",
                "scrollbars",
                "layout",
                "variant",
                "font",
                "size_group",
                "style_prefix",
                "add",
                "menu",
                "screen",
                "narrator",
            }

        try:
            with open(config_file, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
                if (
                    config
                    and "analysis" in config
                    and "ignored_characters" in config["analysis"]
                ):
                    return set(config["analysis"]["ignored_characters"])
        except Exception as e:
            print(f"Warning: Failed to load BranchPy config from {config_file}: {e}")

        # Return default if config loading fails
        return {
            "style",
            "text",
            "background",
            "color",
            "hover_color",
            "hover_background",
            "insensitive_background",
            "id",
            "thumb",
            "scrollbars",
            "layout",
            "variant",
            "font",
            "size_group",
            "style_prefix",
            "add",
            "menu",
            "screen",
            "narrator",
        }

    def validate(self) -> List[Dict[str, Any]]:
        """
        Execute all Phase 3 validation rules.

        Returns:
            List of validation issues
        """
        self.issues = []

        # C01: Character Definition Consistency
        self._validate_character_definitions()

        # C02: Dialogue Syntax Validation
        self._validate_dialogue_syntax()

        # C03: Character Reference Validation
        self._validate_character_references()

        # C04: Dialogue Quality & Readability
        self._validate_dialogue_quality()

        # C05: Interpolation Integrity
        self._validate_interpolation()

        # Compute final metrics
        self._compute_metrics()

        return self.issues

    # ========== C01: Character Definition Consistency ==========

    def _validate_character_definitions(self) -> None:
        """Validate character definitions for undefined, duplicate, and unused characters"""
        self._check_undefined_characters()
        self._check_duplicate_characters()
        self._check_unused_characters()

    def _check_undefined_characters(self) -> None:
        """C01-001: Dialogue line uses character not defined via 'define'"""
        if not hasattr(self.index, "characters") or not hasattr(
            self.index, "dialogues"
        ):
            return

        # Get all defined character names (characters is now Dict[str, List[IndexEntry]])
        defined_characters = set(self.index.characters.keys())

        for dialogue in self.index.dialogues:
            speaker = dialogue.extra.get("speaker")
            if not speaker:
                continue

            # Allow narrator (empty speaker or None)
            if speaker in ["", "narrator", None]:
                continue

            # Skip ignored characters (from config or defaults)
            if speaker in self.ignored_characters:
                continue

            # Check if character is defined
            if speaker not in defined_characters:
                self._add_issue(
                    rule_id="C01-001",
                    severity="error",
                    message=f'"{speaker}" is not defined as a Character before use.',
                    file=dialogue.file,
                    line=dialogue.line,
                    extra={
                        "character": speaker,
                        "suggestion": f"Add: define {speaker} = Character(...)",
                    },
                )

    def _check_duplicate_characters(self) -> None:
        """C01-002: Same character ID defined twice"""
        if not hasattr(self.index, "characters"):
            return

        # Characters is now Dict[str, List[IndexEntry]]
        for char_name, char_entries in self.index.characters.items():
            if len(char_entries) > 1:
                # Report duplicate for each occurrence
                for entry in char_entries:
                    self._add_issue(
                        rule_id="C01-002",
                        severity="warning",
                        message=f'"{char_name}" is defined multiple times.',
                        file=entry.file,
                        line=entry.line,
                        extra={
                            "character": char_name,
                            "occurrences": len(char_entries),
                        },
                    )

    def _check_unused_characters(self) -> None:
        """C01-003: Character defined but never used"""
        if not hasattr(self.index, "characters") or not hasattr(
            self.index, "dialogues"
        ):
            return

        defined_characters = set(self.index.characters.keys())
        used_characters = set()

        # Collect all used characters
        for dialogue in self.index.dialogues:
            speaker = dialogue.extra.get("speaker")
            if speaker:
                used_characters.add(speaker)

        # Find unused characters
        unused = defined_characters - used_characters
        for char_name in sorted(unused):
            # Characters is now a list - use first entry for reporting
            char_entry = self.index.characters[char_name][0]

            self._add_issue(
                rule_id="C01-003",
                severity="warning",
                message=f'"{char_name}" is defined but unused in dialogue.',
                file=char_entry.file,
                line=char_entry.line,
                extra={"character": char_name},
            )

    # ========== C02: Dialogue Syntax Validation ==========

    def _validate_dialogue_syntax(self) -> None:
        """Validate dialogue line syntax"""
        self._check_unclosed_quotes()
        self._check_orphan_text()
        self._check_empty_dialogue()
        self._check_invalid_label_context()

    def _check_unclosed_quotes(self) -> None:
        """C02-001: Dialogue line missing closing quote

        This checks ALL .rpy files for unclosed quotes, not just successfully parsed dialogues.
        The parser may skip lines with syntax errors, so we need to scan the raw source.

        Ren'Py dialogue syntax:
        - character "text"
        - character 'text'
        - "text" (narrator)
        - 'text' (narrator)
        """
        # Scan all .rpy files in the project
        game_dir = self.project_root / "game"
        if not game_dir.exists():
            return

        for rpy_file in game_dir.rglob("*.rpy"):
            try:
                with open(rpy_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()

                for line_num, raw_line in enumerate(lines, start=1):
                    # Check if this line looks like dialogue and has unclosed quotes
                    if self._line_has_unclosed_quotes(raw_line):
                        # Make file path relative to project root
                        relative_path = str(rpy_file.relative_to(self.project_root))

                        self._add_issue(
                            rule_id="C02-001",
                            severity="error",
                            message="Dialogue line missing closing quote",
                            file=relative_path,
                            line=line_num,
                            extra={
                                "raw_line": raw_line.strip(),
                                "suggestion": "Add closing quote at end of line",
                            },
                        )

            except (IOError, OSError, UnicodeDecodeError):
                # File read error - skip this file
                continue

    def _line_has_unclosed_quotes(self, line: str) -> bool:
        """
        Check if a Ren'Py dialogue line has unclosed quotes.

        Patterns:
        - character "text"
        - "text"
        - character 'text'
        - 'text'

        Returns True if quotes are unclosed.
        """
        # Strip leading whitespace and comments
        line = line.strip()
        if not line or line.startswith("#"):
            return False

        # Find the first quote in the line (after potential character name)
        first_double = line.find('"')
        first_single = line.find("'")

        # No quotes at all - not a dialogue line or uses different syntax
        if first_double == -1 and first_single == -1:
            return False

        # Determine which quote type comes first
        if first_double != -1 and (first_single == -1 or first_double < first_single):
            # Line uses double quotes
            quote_char = '"'
            start_pos = first_double
        else:
            # Line uses single quotes
            quote_char = "'"
            start_pos = first_single

        # Count quotes from the first quote onward, handling escapes
        quote_count = 0
        i = start_pos
        while i < len(line):
            if line[i] == "\\" and i + 1 < len(line):
                # Skip escaped character
                i += 2
                continue

            if line[i] == quote_char:
                quote_count += 1

            i += 1

        # If odd number of quotes, the line has unclosed quotes
        return quote_count % 2 != 0

    def _check_orphan_text(self) -> None:
        """C02-002: Text line outside character or narrator context"""
        if not hasattr(self.index, "dialogues"):
            return

        for dialogue in self.index.dialogues:
            speaker = dialogue.extra.get("speaker")
            text = dialogue.extra.get("text", "")

            # If we have text but no speaker context, it might be orphaned
            # (This is more of a sanity check - the parser should handle this)
            if text and speaker is None:
                self._add_issue(
                    rule_id="C02-002",
                    severity="warning",
                    message="Text not bound to any speaker.",
                    file=dialogue.file,
                    line=dialogue.line,
                    extra={
                        "text_snippet": text[:50] + "..." if len(text) > 50 else text
                    },
                )

    def _check_empty_dialogue(self) -> None:
        """C02-003: Empty or whitespace-only dialogue lines"""
        if not hasattr(self.index, "dialogues"):
            return

        for dialogue in self.index.dialogues:
            text = dialogue.extra.get("text", "")

            if not text or not text.strip():
                speaker = dialogue.extra.get("speaker", "narrator")
                self._add_issue(
                    rule_id="C02-003",
                    severity="info",
                    message="Empty dialogue line — may be unintentional.",
                    file=dialogue.file,
                    line=dialogue.line,
                    extra={"speaker": speaker},
                )

    def _check_invalid_label_context(self) -> None:
        """C02-004: Dialogue found before any label or scene context"""
        if not hasattr(self.index, "dialogues") or not hasattr(self.index, "labels"):
            return

        # Build a map of file -> earliest label line
        file_earliest_label: Dict[str, int] = {}
        for label_entry in self.index.labels.values():
            file_path = label_entry.file
            if file_path not in file_earliest_label:
                file_earliest_label[file_path] = label_entry.line
            else:
                file_earliest_label[file_path] = min(
                    file_earliest_label[file_path], label_entry.line
                )

        # Check dialogues that appear before first label
        for dialogue in self.index.dialogues:
            file_path = dialogue.file
            dialogue_line = dialogue.line

            # If file has labels, check if dialogue is before first label
            if file_path in file_earliest_label:
                if dialogue_line < file_earliest_label[file_path]:
                    self._add_issue(
                        rule_id="C02-004",
                        severity="error",
                        message="Dialogue outside valid label context.",
                        file=dialogue.file,
                        line=dialogue.line,
                        extra={"suggestion": "Move dialogue after a label definition"},
                    )

    # ========== C03: Character Reference Validation ==========

    def _validate_character_references(self) -> None:
        """Validate character asset references"""
        self._check_missing_voice_asset()
        self._check_portrait_mismatch()

    def _check_missing_voice_asset(self) -> None:
        """C03-001: Voice-over file reference missing for character with VO mode"""
        if not hasattr(self.index, "characters"):
            return

        # Check for characters that specify voice tags but missing voice files
        for char_name, char_entries in self.index.characters.items():
            # Use first definition
            char_entry = char_entries[0]

            # Check if character definition includes voice_tag
            voice_tag = char_entry.extra.get("voice_tag")
            if voice_tag:
                # Check if any audio files reference this voice tag
                has_voice_files = False
                if hasattr(self.index, "audio"):
                    for audio_name in self.index.audio.keys():
                        if voice_tag in audio_name:
                            has_voice_files = True
                            break

                if not has_voice_files:
                    self._add_issue(
                        rule_id="C03-001",
                        severity="warning",
                        message=f"Expected VO for {char_name}, file not found.",
                        file=char_entry.file,
                        line=char_entry.line,
                        extra={"character": char_name, "voice_tag": voice_tag},
                    )

    def _check_portrait_mismatch(self) -> None:
        """C03-002: Portrait key not found for given character"""
        if not hasattr(self.index, "characters"):
            return

        # Check for characters that specify image tags but missing image definitions
        for char_name, char_entries in self.index.characters.items():
            # Use first definition
            char_entry = char_entries[0]

            # Check if character definition includes image attribute
            image_tag = char_entry.extra.get("image_tag")
            if image_tag:
                # Check if image definition exists
                has_image = False
                if hasattr(self.index, "images"):
                    if image_tag in self.index.images:
                        has_image = True
                    # Also check for composite image names (character + expression)
                    for img_name in self.index.images.keys():
                        if img_name.startswith(image_tag):
                            has_image = True
                            break

                if not has_image:
                    self._add_issue(
                        rule_id="C03-002",
                        severity="warning",
                        message=f"Character {char_name} references missing portrait {image_tag}.",
                        file=char_entry.file,
                        line=char_entry.line,
                        extra={"character": char_name, "image_tag": image_tag},
                    )

    # ========== C04: Dialogue Quality & Readability ==========

    def _validate_dialogue_quality(self) -> None:
        """Validate dialogue quality and readability"""
        self._check_overlong_line()
        self._check_underlong_line()
        self._compute_reading_time()

    def _check_overlong_line(self) -> None:
        """C04-001: Dialogue line exceeds 140 characters"""
        if not hasattr(self.index, "dialogues"):
            return

        MAX_LENGTH = 140

        for dialogue in self.index.dialogues:
            text = dialogue.extra.get("text", "")

            if len(text) > MAX_LENGTH:
                self._add_issue(
                    rule_id="C04-001",
                    severity="warning",
                    message=f"Dialogue too long (length={len(text)}).",
                    file=dialogue.file,
                    line=dialogue.line,
                    extra={
                        "length": len(text),
                        "text_snippet": text[:50] + "..." if len(text) > 50 else text,
                    },
                )

    def _check_underlong_line(self) -> None:
        """C04-002: Dialogue line < 3 characters → may be artifact"""
        if not hasattr(self.index, "dialogues"):
            return

        MIN_LENGTH = 3

        for dialogue in self.index.dialogues:
            text = dialogue.extra.get("text", "").strip()

            if text and len(text) < MIN_LENGTH:
                self._add_issue(
                    rule_id="C04-002",
                    severity="info",
                    message="Dialogue very short.",
                    file=dialogue.file,
                    line=dialogue.line,
                    extra={"length": len(text), "text": text},
                )

    def _compute_reading_time(self) -> None:
        """C04-003: Compute reading time statistics for each dialogue line"""
        if not hasattr(self.index, "dialogues"):
            return

        for dialogue in self.index.dialogues:
            text = dialogue.extra.get("text", "")

            # Count words (split by whitespace)
            words = len(text.split())

            if words > 0:
                # Calculate reading times
                time_fast = (words / self.WPM_FAST) * 60  # seconds
                time_normal = (words / self.WPM_NORMAL) * 60
                time_slow = (words / self.WPM_SLOW) * 60

                # Add as info-level issue with reading time data
                self._add_issue(
                    rule_id="C04-003",
                    severity="info",
                    message=f"Estimated reading time {time_normal:.1f}s.",
                    file=dialogue.file,
                    line=dialogue.line,
                    extra={
                        "words": words,
                        "reading_time": {
                            "fast": round(time_fast, 2),
                            "normal": round(time_normal, 2),
                            "slow": round(time_slow, 2),
                        },
                    },
                )

    # ========== C05: Interpolation Integrity ==========

    def _validate_interpolation(self) -> None:
        """Validate string interpolation in dialogue"""
        self._check_broken_interpolation()
        self._check_escaped_brace_error()

    def _check_broken_interpolation(self) -> None:
        """C05-001: Invalid variable interpolation in dialogue"""
        if not hasattr(self.index, "dialogues"):
            return

        # Regex to match Python-style string interpolation: {variable}
        interpolation_re = re.compile(r"\{([^}]*)\}")

        for dialogue in self.index.dialogues:
            text = dialogue.extra.get("text", "")

            # Find all interpolations
            for match in interpolation_re.finditer(text):
                expr = match.group(1)

                # Check for common issues
                if not expr:
                    # Empty braces {}
                    self._add_issue(
                        rule_id="C05-001",
                        severity="error",
                        message="Invalid interpolation in dialogue: empty braces",
                        file=dialogue.file,
                        line=dialogue.line,
                        extra={"expr": "{}", "text_snippet": text[:50] + "..."},
                    )
                elif expr.strip() != expr:
                    # Leading/trailing whitespace
                    self._add_issue(
                        rule_id="C05-001",
                        severity="warning",
                        message=f"Invalid interpolation in dialogue: {{{expr}}}",
                        file=dialogue.file,
                        line=dialogue.line,
                        extra={
                            "expr": f"{{{expr}}}",
                            "suggestion": f"Remove whitespace: {{{expr.strip()}}}",
                        },
                    )

    def _check_escaped_brace_error(self) -> None:
        """C05-002: Missing escape for literal { or }

        Checks for single braces that might need escaping, while properly
        recognizing Ren'Py text tags like {i}, {b}, {u}, {color}, etc.
        """
        if not hasattr(self.index, "dialogues"):
            return

        # Ren'Py text tags that use braces (these are valid, not errors)
        valid_renpy_tags = {
            "i",
            "b",
            "u",
            "s",
            "a",
            "size",
            "color",
            "font",
            "outlinecolor",
            "alpha",
            "cps",
            "w",
            "p",
            "nw",
            "fast",
            "done",
        }

        for dialogue in self.index.dialogues:
            text = dialogue.extra.get("text", "")

            # Look for single { not followed by valid identifier, {, or Ren'Py tag
            # Pattern: {something} or {/something} (closing tag)
            tag_pattern = re.compile(r"\{/?([a-zA-Z_][a-zA-Z0-9_=]*)\}")

            # Find all brace patterns
            i = 0
            while i < len(text):
                if text[i] == "{":
                    # Check if this is {{
                    if i + 1 < len(text) and text[i + 1] == "{":
                        i += 2
                        continue

                    # Check if this matches a Ren'Py tag pattern
                    match = tag_pattern.match(text, i)
                    if match:
                        tag_name = match.group(1)
                        # Extract just the tag name (before any =)
                        base_tag = tag_name.split("=")[0]

                        # Check if it's a valid Ren'Py tag or looks like a variable
                        if base_tag in valid_renpy_tags or tag_name[0].islower():
                            # Valid Ren'Py tag or variable interpolation - skip it
                            i = match.end()
                            continue

                    # Check if it looks like variable interpolation {variable_name}
                    var_match = re.match(r"\{[a-zA-Z_][a-zA-Z0-9_\.]*\}", text[i:])
                    if var_match:
                        # Valid variable interpolation
                        i += var_match.end()
                        continue

                    # If we get here, might be a literal brace that needs escaping
                    # But be conservative - only flag obvious cases
                    context = text[max(0, i - 10) : min(len(text), i + 10)]

                    # Don't flag if it looks like it might be a complex expression
                    # Only flag completely isolated braces
                    if i + 1 < len(text) and text[i + 1] in " \t\n}":
                        self._add_issue(
                            rule_id="C05-002",
                            severity="warning",
                            message="Use {{ or }} for literal braces.",
                            file=dialogue.file,
                            line=dialogue.line,
                            extra={
                                "suggestion": "Escape literal braces with {{ or }}",
                                "context": context,
                            },
                        )

                i += 1

    # ========== Metrics Computation ==========

    def _compute_metrics(self) -> None:
        """Compute final dialogue metrics"""
        if not hasattr(self.index, "dialogues"):
            return

        dialogues = self.index.dialogues
        self.metrics.dialogue_count = len(dialogues)

        # Count unique characters
        unique_chars = set()
        for dialogue in dialogues:
            speaker = dialogue.extra.get("speaker")
            if speaker and speaker not in ["", "narrator", None]:
                unique_chars.add(speaker)
        self.metrics.unique_characters = len(unique_chars)

        # Compute text statistics
        lengths = []
        total_words = 0
        total_read_time = 0.0

        for dialogue in dialogues:
            text = dialogue.extra.get("text", "")
            lengths.append(len(text))
            words = len(text.split())
            total_words += words

            # Calculate normal reading time
            if words > 0:
                total_read_time += (words / self.WPM_NORMAL) * 60

        if lengths:
            self.metrics.min_length = min(lengths)
            self.metrics.max_length = max(lengths)
            self.metrics.avg_length = sum(lengths) / len(lengths)

        self.metrics.total_words = total_words
        self.metrics.avg_read_time = total_read_time / max(len(dialogues), 1)

        # Count severity levels
        for issue in self.issues:
            severity = issue.get("severity", "info")
            if severity == "error":
                self.metrics.errors += 1
            elif severity == "warning":
                self.metrics.warnings += 1
            elif severity == "info":
                self.metrics.info += 1

    # ========== Helper Methods ==========

    def _add_issue(
        self,
        rule_id: str,
        severity: str,
        message: str,
        file: str,
        line: int,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Add a validation issue"""
        issue = {
            "rule_id": rule_id,
            "severity": severity,
            "message": message,
            "file": file,
            "line": line,
        }

        if extra:
            issue["extra"] = extra

        self.issues.append(issue)
