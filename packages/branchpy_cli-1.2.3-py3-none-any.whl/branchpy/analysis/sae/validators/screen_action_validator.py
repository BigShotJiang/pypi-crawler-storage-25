"""Screen Action Validator - Validate screen button actions"""

from typing import List

from ..cfg_builder import ControlFlowGraph, EdgeType


class Issue:
    """Validation issue"""

    def __init__(
        self,
        rule_id: str,
        severity: str,
        message: str,
        file: str,
        line: int,
        suggestion: str = "",
    ):
        self.rule_id = rule_id
        self.severity = severity
        self.message = message
        self.file = file
        self.line = line
        self.suggestion = suggestion


def validate_screen_actions(cfg: ControlFlowGraph) -> List[Issue]:
    """
    Validate that screen actions have valid targets.

    Rule: screen_action_missing_target
    Severity: ERROR

    Detects:
    - Screen actions (Jump/Call/Show) that reference non-existent labels or screens
    """
    issues = []

    for edge in cfg.edges:
        if edge.edge_type == EdgeType.SCREEN_ACTION:
            # Check if edge has a valid target
            if not edge.to_node or edge.to_node not in cfg.nodes:
                # Missing or invalid target
                source_node = cfg.nodes.get(edge.from_node)
                if source_node:
                    action_type = (
                        edge.meta.get("action", "unknown") if edge.meta else "unknown"
                    )
                    target = (
                        edge.meta.get("target", "unknown") if edge.meta else "unknown"
                    )
                    screen_name = (
                        edge.meta.get("screen", "unknown") if edge.meta else "unknown"
                    )

                    issues.append(
                        Issue(
                            rule_id="screen_action_missing_target",
                            severity="error",
                            message=f"Screen action {action_type}('{target}') in screen '{screen_name}' targets non-existent label",
                            file=source_node.file,
                            line=source_node.line,
                            suggestion=f"Define label '{target}' or fix the {action_type}() action in screen '{screen_name}'",
                        )
                    )

    return issues
