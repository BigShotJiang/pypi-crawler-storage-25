"""Phase 4 - Variables & Game State Analyzer

This module implements SAE rules V01-V04:
- V01: Variable Usage (undefined, unused, typos, type drift, etc.)
- V02: Persistent State (unsafe writes, migrations, save-breaking changes)
- V03: Flags & Scores (set-never-checked, score drift, impossible combos)
- V04: State Integrity (tautologies, inconsistent merges, re-entry hazards)
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from ..config_schema import get_severity, get_variable_config, load_config
from ..graphs.variable_graph import Assign, Ctx, Kind, Scope, Symbol, Use, VariableGraph


class VariableAnalyzer:
    """Analyzes variable usage, game state, flags, and scores across a Ren'Py project."""

    def __init__(
        self,
        project_root: str | Path,
        index: Any,
        cfg: Any = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        """
        Args:
            project_root: Project root directory
            index: ProjectIndex from Indexer
            cfg: ControlFlowGraph from CFGBuilder (optional, for advanced analysis)
            config: Configuration dict with rule settings (will be validated and merged with defaults)
        """
        self.root = (
            Path(project_root) if isinstance(project_root, str) else project_root
        )
        self.index = index
        self.cfg = cfg

        # Load and validate config (merges with defaults)
        self.config = load_config(config)
        self.var_config = get_variable_config(self.config)

        self.issues: List[Dict[str, Any]] = []
        self.metrics: Dict[str, Any] = {
            "variable_count": 0,
            "undefined_references": 0,
            "unused_variables": 0,
            "type_flips": 0,
            "persistent_vars": 0,
            "flag_vars": 0,
            "score_vars": 0,
            "affection_vars": 0,  # Kept for continuity with prior phases
            "impossible_combos": 0,
        }

        # Rule configuration (extract from validated config)
        self._load_config()

    def _load_user_config(self) -> None:
        """Load user configuration from .branchpy/config.yaml"""
        import yaml

        # Try new location first: .branchpy/config.yaml
        config_file = self.root / ".branchpy" / "config.yaml"

        # Fallback to legacy location: .branchpy.yaml (for backward compatibility)
        if not config_file.exists():
            config_file = self.root / ".branchpy.yaml"

        # Initialize user_config dict
        self.user_config = {}

        if config_file.exists():
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    self.user_config = yaml.safe_load(f) or {}
            except Exception as e:
                print(
                    f"Warning: Failed to load BranchPy config from {config_file}: {e}"
                )
                self.user_config = {}

    def _load_config(self) -> None:
        """Load and parse configuration for variable analysis rules."""
        # Load user project config from .branchpy/config.yaml
        self._load_user_config()

        # Builtin symbols to check for shadowing
        self.builtins = set(self.var_config.get("builtins", []))

        # Score-like variable detection config
        score_config = self.var_config.get("score_like", {})
        self.score_patterns = score_config.get("include_name_patterns", [])
        self.score_exclude_patterns = score_config.get("exclude_name_patterns", [])
        self.score_min_observations = score_config.get("min_observations", 4)
        self.score_outlier_method = score_config.get("outlier_method", "iqr")
        self.score_outlier_params = score_config.get("outlier_params", {"iqr_k": 2.5})

        # Typo detection config
        typo_config = self.var_config.get("typo", {})
        self.typo_distance = typo_config.get("distance", 2)
        self.typo_min_reads = typo_config.get("min_candidate_reads", 2)

        # Persistent config
        persistent_config = self.var_config.get("persistent", {})
        self.persistent_guard_window = persistent_config.get("guard_window", 8)
        self.persistent_version_vars = set(persistent_config.get("version_vars", []))
        self.persistent_migration_markers = set(
            persistent_config.get("migration_markers", [])
        )

        # Flag config
        flag_config = self.var_config.get("flags", {})
        self.flag_patterns = flag_config.get("boolean_patterns", [])

    def build_graph(self) -> VariableGraph:
        """Extract variable graph from indexer + python blocks, attach CFG facts.

        Returns:
            VariableGraph with all symbols, assigns, uses, and facts
        """
        vg = VariableGraph()

        # Add global scope
        vg.add_scope(Scope(id="global", parent=None, type="global"))

        # Extract variable definitions (writes)
        for var_name, entries in self.index.variables.items():
            for entry in entries:
                # Determine kind
                kind = self._classify_variable(var_name)

                # Add symbol
                symbol = Symbol(
                    name=var_name, kind=kind, decl_file=entry.file, decl_line=entry.line
                )
                vg.add_symbol(symbol)

                # Create assignment record (indexer treats definitions as assigns)
                scope_id = self._determine_scope(entry.file, entry.line)
                expr = entry.extra.get("expr", "") if entry.extra else ""
                assign = Assign(
                    symbol=var_name,
                    scope=scope_id,
                    file=entry.file,
                    line=entry.line,
                    expr=expr,
                    type_domain=self._infer_type(expr),
                )
                vg.add_assign(assign)

        # Extract variable uses (reads/references) - Phase 4
        if hasattr(self.index, "variable_uses"):
            for var_name, use_entries in self.index.variable_uses.items():
                for use_entry in use_entries:
                    context_str = (
                        use_entry.extra.get("context", "read")
                        if use_entry.extra
                        else "read"
                    )

                    # Map context string to Ctx type
                    ctx: Ctx
                    if context_str == "write":
                        ctx = "write"
                    elif context_str == "cond":
                        ctx = "cond"
                    elif context_str == "call":
                        ctx = "call"
                    elif context_str == "mutate":
                        ctx = "mutate"
                    else:
                        ctx = "read"

                    scope_id = self._determine_scope(use_entry.file, use_entry.line)

                    use = Use(
                        symbol=var_name,
                        scope=scope_id,
                        file=use_entry.file,
                        line=use_entry.line,
                        ctx=ctx,
                    )
                    vg.add_use(use)

        # Attach CFG facts if available
        if self.cfg:
            self._attach_cfg_facts(vg)

        return vg

    def _classify_variable(self, var_name: str) -> Kind:
        """Classify a variable by its name."""
        if var_name.startswith("persistent."):
            return "persistent"
        elif var_name in self.builtins:
            return "builtin"
        elif var_name.isupper():
            return "global"
        else:
            return "local"

    def _determine_scope(self, file: str, line: int) -> str:
        """Determine the scope ID for a given file/line location."""
        # Simple heuristic: find the label that contains this line
        # In a full implementation, we'd use the CFG or parse tree
        for label_name, label_entry in self.index.labels.items():
            if label_entry.file == file and label_entry.line <= line:
                # Rough approximation - would need better logic
                return f"label:{label_name}"
        return "global"

    def _infer_type(self, expr: str) -> str:
        """Infer abstract type domain from an expression string."""
        if not expr:
            return "unknown"

        expr = expr.strip()

        # Boolean literals
        if expr in ("True", "False"):
            return "bool"

        # Numeric literals
        if re.match(r"^-?\d+$", expr):
            return "int"
        if re.match(r"^-?\d+\.\d+$", expr):
            return "float"

        # String literals
        if (expr.startswith('"') and expr.endswith('"')) or (
            expr.startswith("'") and expr.endswith("'")
        ):
            return "str"

        # List/dict literals
        if expr.startswith("[") and expr.endswith("]"):
            return "list"
        if expr.startswith("{") and expr.endswith("}"):
            return "dict"

        return "object"

    def _attach_cfg_facts(self, vg: VariableGraph) -> None:
        """Attach control flow facts from CFG to the variable graph."""
        # TODO: Extract path conditions from CFG edges
        # This will be implemented when CFG integration is complete
        pass

    def _create_issue(
        self, rule: str, message: str, file: str, line: int, **context
    ) -> Dict[str, Any]:
        """
        Create an issue dict with correct severity from config.

        Args:
            rule: Rule ID (e.g., "V01-001")
            message: Issue description
            file: File path where issue occurs
            line: Line number where issue occurs
            **context: Additional context information

        Returns:
            Issue dictionary
        """
        severity = get_severity(self.config, rule)

        issue = {
            "rule_id": rule,  # Use rule_id for backward compatibility
            "severity": severity,
            "message": message,
            "file": str(file),
            "line": line,
        }

        if context:
            issue["extra"] = context  # Use extra for backward compatibility

        return issue

    def run(self) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """Run all variable analysis rules.

        Returns:
            Tuple of (issues list, metrics dict)
        """
        vg = self.build_graph()

        # Run rule groups
        self._v01_usage(vg)
        self._v02_persistent(vg)
        self._v03_flags_scores(vg)
        self._v04_integrity(vg)

        # Finalize metrics
        self._finalize_metrics(vg)

        return self.issues, self.metrics

    # ========================================================================
    # V01 - Variable Usage Rules
    # ========================================================================

    def _v01_usage(self, vg: VariableGraph) -> None:
        """V01 rule group: Usage analysis."""
        self._v01_001_undefined(vg)
        self._v01_002_unused(vg)
        self._v01_003_typos(vg)
        self._v01_004_type_drift(vg)
        self._v01_005_persistent_vs_regular(vg)
        self._v01_006_shadow_builtin(vg)

    def _v01_001_undefined(self, vg: VariableGraph) -> None:
        """V01-001: Detect uses of undefined variables.

        This check is aware of:
        - Ren'Py built-in modules and special variables
        - Python built-in functions
        - Common loop/iteration variable names
        - Screen language parameters (who, what, args, kwargs, etc.)
        - Function parameters (common parameter names)
        - Project-specific constants and functions
        All defined in the configuration file (.branchpy/config.yaml).
        """
        # Load configuration sections from user config (.branchpy/config.yaml)
        renpy_builtins = set(self.user_config.get("renpy_builtins", []))
        loop_vars = set(self.user_config.get("loop_variables", []))
        screen_params = set(self.user_config.get("screen_parameters", []))
        function_params = set(self.user_config.get("function_parameters", []))
        project_constants = set(self.user_config.get("project_constants", []))
        project_functions = set(self.user_config.get("project_functions", []))

        # Combine all allowed variables
        allowed_vars = (
            renpy_builtins
            | loop_vars
            | screen_params
            | function_params
            | project_constants
            | project_functions
        )

        # Add default Ren'Py built-ins if not in config
        default_builtins = {
            "renpy",
            "config",
            "persistent",
            "preferences",
            "gui",
            "store",
            "_preferences",
            "narrator",
            "nvl_clear",
            "nvl_window",
            # Python built-ins commonly used in Ren'Py
            "len",
            "str",
            "int",
            "float",
            "bool",
            "list",
            "dict",
            "set",
            "isinstance",
            "hasattr",
            "getattr",
            "any",
            "all",
            "callable",
            "re",
            "types",
            "main_menu",
            "_history_list",
            "_in_replay",
            # Screen language
            "h",
            "who",
            "what",
            "_it",
        }
        allowed_vars.update(default_builtins)

        # Add default loop variables
        default_loop_vars = {
            "i",
            "j",
            "k",
            "n",
            "m",
            "x",
            "y",
            "z",
            "item",
            "key",
            "value",
        }
        allowed_vars.update(default_loop_vars)

        # For each use with ctx='read' or 'cond', check if there's a prior assign
        for use in vg.uses:
            if use.ctx in ("read", "cond"):
                var_name = use.symbol

                # CRITICAL FIX: Extract base variable name from dot notation
                # If variable is "INTENT_NSF.search", only check "INTENT_NSF"
                # If variable is "family_name.strip", only check "family_name"
                base_var = var_name.split(".")[0] if "." in var_name else var_name

                # Check if the BASE variable is in allowed variables (exact match)
                if base_var in allowed_vars:
                    continue

                # Check if it's a Ren'Py built-in with prefix match (e.g., "renpy.random")
                is_builtin = False
                for builtin in allowed_vars:
                    # Check for module prefix (e.g., "renpy.random" matches "renpy")
                    if "." not in builtin and base_var.startswith(builtin + "."):
                        is_builtin = True
                        break

                # Skip if it's a built-in
                if is_builtin:
                    continue

                # Check if variable starts with underscore (internal/private)
                # These are often defined in init python blocks
                if base_var.startswith("_") and len(base_var) > 1:
                    # Skip variables with single underscore (Ren'Py convention for internal vars)
                    continue

                # Check if variable is ALL_CAPS (constant convention)
                # These are typically defined in init python blocks
                if base_var.isupper() and len(base_var) > 1 and "_" in base_var:
                    # Skip ALL_CAPS_WITH_UNDERSCORES (constant pattern)
                    continue

                # Simple check: is there ANY assignment to this symbol?
                # More advanced: check reachability via CFG
                # NOTE: Check assignments using the BASE variable name for dot notation
                assigns = vg.get_assigns_for(base_var)
                if not assigns:
                    self._emit(
                        rule_id="V01-001",
                        file=use.file,
                        line=use.line,
                        message=f'Variable "{var_name}" used before assignment',
                        variable=var_name,
                        scope=use.scope,
                    )
                    self.metrics["undefined_references"] += 1

    def _v01_002_unused(self, vg: VariableGraph) -> None:
        """V01-002: Detect variables that are assigned but never read."""
        # Track which symbols have read uses
        read_symbols = {u.symbol for u in vg.uses if u.ctx in ("read", "cond", "call")}

        for symbol in vg.symbols.values():
            assigns = vg.get_assigns_for(symbol.name)
            if assigns and symbol.name not in read_symbols:
                # Variable is assigned but never read
                first_assign = assigns[0]
                self._emit(
                    rule_id="V01-002",
                    file=first_assign.file,
                    line=first_assign.line,
                    message=f'Variable "{symbol.name}" is assigned but never used',
                    variable=symbol.name,
                )
                self.metrics["unused_variables"] += 1

    def _v01_003_typos(self, vg: VariableGraph) -> None:
        """V01-003: Detect potential typos in variable names."""
        # Only check variables with reads (to avoid false positives on write-only vars)
        symbols_with_reads = {}
        for use in vg.uses:
            if use.ctx in ("read", "cond"):
                if use.symbol not in symbols_with_reads:
                    symbols_with_reads[use.symbol] = []
                symbols_with_reads[use.symbol].append(use)

        # Check for similar names
        symbol_list = list(symbols_with_reads.keys())
        for i, sym1 in enumerate(symbol_list):
            for sym2 in symbol_list[i + 1 :]:
                distance = self._levenshtein_distance(sym1, sym2)
                if distance <= self.typo_distance:
                    # Require sufficient reads on both
                    if (
                        len(symbols_with_reads[sym1]) >= self.typo_min_reads
                        and len(symbols_with_reads[sym2]) >= self.typo_min_reads
                    ):
                        # Emit warning for the less-used one
                        if len(symbols_with_reads[sym1]) < len(
                            symbols_with_reads[sym2]
                        ):
                            target = sym1
                            similar = sym2
                            use_site = symbols_with_reads[sym1][0]
                        else:
                            target = sym2
                            similar = sym1
                            use_site = symbols_with_reads[sym2][0]

                        self._emit(
                            rule_id="V01-003",
                            file=use_site.file,
                            line=use_site.line,
                            message=f'Variable "{target}" may be a typo of "{similar}" (Levenshtein distance: {distance})',
                            variable=target,
                            similar_to=similar,
                            distance=distance,
                        )

    def _v01_004_type_drift(self, vg: VariableGraph) -> None:
        """V01-004: Detect type drift - variable assigned incompatible types."""
        # Group assigns by symbol
        for symbol in vg.symbols.values():
            assigns = vg.get_assigns_for(symbol.name)
            if len(assigns) < 2:
                continue

            # Check if types are incompatible
            types = {a.type_domain for a in assigns}
            # Remove 'unknown' from consideration
            types.discard("unknown")

            if len(types) > 1:
                # Check if they're incompatible (e.g., int vs str)
                if self._are_types_incompatible(types):
                    first_assign = assigns[0]
                    conflicting_assigns = [
                        a for a in assigns if a.type_domain != first_assign.type_domain
                    ]

                    for conflict in conflicting_assigns[:3]:  # Limit to first 3
                        self._emit(
                            rule_id="V01-004",
                            file=conflict.file,
                            line=conflict.line,
                            message=f'Variable "{symbol.name}" type drift: assigned {conflict.type_domain} here, but {first_assign.type_domain} at line {first_assign.line}',
                            variable=symbol.name,
                            types=list(types),
                        )
                        self.metrics["type_flips"] += 1

    def _v01_005_persistent_vs_regular(self, vg: VariableGraph) -> None:
        """V01-005: Detect when both `var` and `persistent.var` are used."""
        # Build mapping of base names to their persistent counterparts
        regular_vars = {
            name for name in vg.symbols.keys() if not name.startswith("persistent.")
        }
        persistent_vars = {
            name for name in vg.symbols.keys() if name.startswith("persistent.")
        }

        for reg_var in regular_vars:
            persistent_equiv = f"persistent.{reg_var}"
            if persistent_equiv in persistent_vars:
                # Both exist - emit warning
                reg_uses = vg.get_uses_for(reg_var)
                per_uses = vg.get_uses_for(persistent_equiv)

                if reg_uses and per_uses:
                    self._emit(
                        rule_id="V01-005",
                        file=reg_uses[0].file,
                        line=reg_uses[0].line,
                        message=f'Both "{reg_var}" and "{persistent_equiv}" are used - potential confusion',
                        variable=reg_var,
                        persistent_equiv=persistent_equiv,
                    )

    def _v01_006_shadow_builtin(self, vg: VariableGraph) -> None:
        """V01-006: Detect variables that shadow built-in names."""
        for symbol in vg.symbols.values():
            if symbol.name in self.builtins and symbol.kind != "builtin":
                assigns = vg.get_assigns_for(symbol.name)
                if assigns:
                    self._emit(
                        rule_id="V01-006",
                        file=assigns[0].file,
                        line=assigns[0].line,
                        message=f'Variable "{symbol.name}" shadows a built-in name',
                        variable=symbol.name,
                    )

    # ========================================================================
    # V02 - Persistent State Rules
    # ========================================================================

    def _v02_persistent(self, vg: VariableGraph) -> None:
        """V02 rule group: Persistent state analysis."""
        self._v02_001_unsafe_write(vg)
        self._v02_002_missing_migration(vg)
        self._v02_003_save_breaking(vg)
        self._v02_004_corruption_prone(vg)

    def _v02_001_unsafe_write(self, vg: VariableGraph) -> None:
        """V02-001: Detect writes to persistent without guards."""
        persistent_symbols = vg.get_symbols_by_kind("persistent")

        for symbol in persistent_symbols:
            assigns = vg.get_assigns_for(symbol.name)
            for assign in assigns:
                # Check if there's a guard nearby (simple heuristic)
                if not self._has_nearby_guard(assign):
                    self._emit(
                        rule_id="V02-001",
                        file=assign.file,
                        line=assign.line,
                        message=f'Unsafe write to "{symbol.name}" without version guard or migration marker',
                        variable=symbol.name,
                    )

    def _v02_002_missing_migration(self, vg: VariableGraph) -> None:
        """V02-002: Detect persistent keys used without migration logic."""
        # This requires tracking persistent_version usage - simplified for now
        persistent_symbols = vg.get_symbols_by_kind("persistent")
        has_version_check = any(
            "persistent_version" in s.name or "save_version" in s.name
            for s in vg.symbols.values()
        )

        if persistent_symbols and not has_version_check:
            # Project uses persistent but no version tracking
            for symbol in persistent_symbols[:3]:  # Limit warnings
                assigns = vg.get_assigns_for(symbol.name)
                if assigns:
                    self._emit(
                        rule_id="V02-002",
                        file=assigns[0].file,
                        line=assigns[0].line,
                        message=f'Persistent variable "{symbol.name}" used without save version tracking',
                        variable=symbol.name,
                    )

    def _v02_003_save_breaking(self, vg: VariableGraph) -> None:
        """V02-003: Detect type changes in persistent that could break saves."""
        persistent_symbols = vg.get_symbols_by_kind("persistent")

        for symbol in persistent_symbols:
            assigns = vg.get_assigns_for(symbol.name)
            if len(assigns) < 2:
                continue

            types = {a.type_domain for a in assigns}
            types.discard("unknown")

            if len(types) > 1:
                self._emit(
                    rule_id="V02-003",
                    file=assigns[-1].file,
                    line=assigns[-1].line,
                    message=f'Persistent variable "{symbol.name}" has type changes that could break saved games',
                    variable=symbol.name,
                    types=list(types),
                    severity="error",
                )

    def _v02_004_corruption_prone(self, vg: VariableGraph) -> None:
        """V02-004: Detect in-place mutations of persistent objects."""
        # Look for uses with ctx='mutate' on persistent vars
        persistent_symbols = {s.name for s in vg.get_symbols_by_kind("persistent")}

        for use in vg.uses:
            if use.ctx == "mutate" and use.symbol in persistent_symbols:
                self._emit(
                    rule_id="V02-004",
                    file=use.file,
                    line=use.line,
                    message=f'In-place mutation of persistent variable "{use.symbol}" - risk of corruption without guards',
                    variable=use.symbol,
                )

    # ========================================================================
    # V03 - Flags & Scores Rules
    # ========================================================================

    def _v03_flags_scores(self, vg: VariableGraph) -> None:
        """V03 rule group: Flags and scores analysis."""
        # Identify flags and scores
        flags, scores = self._identify_flags_and_scores(vg)

        self.metrics["flag_vars"] = len(flags)
        self.metrics["score_vars"] = len(scores)

        self._v03_001_set_never_checked(vg, flags)
        self._v03_002_unchecked_negative(vg, flags)
        self._v03_003_score_drift(vg, scores)
        self._v03_004_impossible_combo(vg, flags)

    def _identify_flags_and_scores(
        self, vg: VariableGraph
    ) -> Tuple[Set[str], Set[str]]:
        """Identify which variables are flags (boolean) vs scores (numeric)."""
        flags = set()
        scores = set()

        for symbol in vg.symbols.values():
            # Skip persistent prefix for pattern matching
            base_name = symbol.name.replace("persistent.", "")

            # Check if it's score-like by name
            is_score_name = any(
                pattern.lower() in base_name.lower() for pattern in self.score_patterns
            )
            is_excluded = any(
                pattern.lower() in base_name.lower()
                for pattern in self.score_exclude_patterns
            )

            if is_excluded:
                continue

            # Analyze usage patterns
            assigns = vg.get_assigns_for(symbol.name)
            uses = vg.get_uses_for(symbol.name)

            # Check for numeric updates (+=, -=)
            has_delta = any(a.delta is not None for a in assigns)

            # Check for boolean assignments
            has_bool_assigns = any(a.type_domain == "bool" for a in assigns)

            # Check for conditional uses
            has_cond_uses = any(u.ctx == "cond" for u in uses)

            # Classification logic
            if has_delta or is_score_name:
                if len(assigns) >= self.score_min_observations:
                    scores.add(symbol.name)
            elif has_bool_assigns and has_cond_uses:
                flags.add(symbol.name)

        return flags, scores

    def _v03_001_set_never_checked(self, vg: VariableGraph, flags: Set[str]) -> None:
        """V03-001: Detect flags that are set but never checked."""
        for flag in flags:
            uses = vg.get_uses_for(flag)
            has_cond = any(u.ctx == "cond" for u in uses)
            assigns = vg.get_assigns_for(flag)

            if assigns and not has_cond:
                self._emit(
                    rule_id="V03-001",
                    file=assigns[0].file,
                    line=assigns[0].line,
                    message=f'Flag "{flag}" is set but never checked in conditions',
                    variable=flag,
                )

    def _v03_002_unchecked_negative(self, vg: VariableGraph, flags: Set[str]) -> None:
        """V03-002: Detect flags only checked in positive branch."""
        # This requires CFG analysis - simplified for now
        # Would check if both True and False branches are reachable
        pass

    def _v03_003_score_drift(self, vg: VariableGraph, scores: Set[str]) -> None:
        """V03-003: Detect unusual score changes (outliers)."""
        for score in scores:
            assigns = vg.get_assigns_for(score)
            deltas = [a.delta for a in assigns if a.delta is not None]

            if len(deltas) < self.score_min_observations:
                continue

            # Calculate baseline (median of absolute deltas)
            abs_deltas = [abs(d) for d in deltas]
            baseline = self._median(abs_deltas)

            if baseline == 0:
                continue

            # Check for outliers
            for assign in assigns:
                if assign.delta is None:
                    continue

                if self._is_outlier(assign.delta, deltas, baseline):
                    self._emit(
                        rule_id="V03-003",
                        file=assign.file,
                        line=assign.line,
                        message=f'Unusual change for score "{score}": Δ={assign.delta:.1f} (typical |Δ|≈{baseline:.1f})',
                        variable=score,
                        delta=assign.delta,
                        baseline=baseline,
                    )

    def _v03_004_impossible_combo(self, vg: VariableGraph, flags: Set[str]) -> None:
        """V03-004: Detect impossible flag combinations."""
        # This requires SAT/constraint solving - simplified for now
        # Would analyze path conditions to find contradictions
        pass

    # ========================================================================
    # V04 - State Integrity Rules
    # ========================================================================

    def _v04_integrity(self, vg: VariableGraph) -> None:
        """V04 rule group: State integrity analysis."""
        self._v04_001_tautology(vg)
        self._v04_002_inconsistent_merge(vg)
        self._v04_003_reentry_hazard(vg)

    def _v04_001_tautology(self, vg: VariableGraph) -> None:
        """V04-001: Detect tautologies and contradictions in conditions."""
        # Requires constant propagation - simplified
        pass

    def _v04_002_inconsistent_merge(self, vg: VariableGraph) -> None:
        """V04-002: Detect inconsistent types at merge points."""
        # Requires CFG merge analysis - simplified
        pass

    def _v04_003_reentry_hazard(self, vg: VariableGraph) -> None:
        """V04-003: Detect label re-entry with missing variables."""
        # Check labels that use variables not guaranteed to be defined
        pass

    # ========================================================================
    # Helper Methods
    # ========================================================================

    def _emit(self, rule_id: str, file: str, line: int, message: str, **extra) -> None:
        """Emit a validation issue using config-based severity."""
        issue = self._create_issue(
            rule=rule_id, message=message, file=file, line=line, **extra
        )
        self.issues.append(issue)

    def _severity(self, rule_id: str) -> str:
        """Get severity level for a rule ID from config."""
        return get_severity(self.config, rule_id)

    def _finalize_metrics(self, vg: VariableGraph) -> None:
        """Calculate final metrics from the variable graph."""
        self.metrics["variable_count"] = len(vg.symbols)
        self.metrics["persistent_vars"] = len(vg.get_symbols_by_kind("persistent"))

    def _has_nearby_guard(self, assign: Assign) -> bool:
        """Check if an assignment has a nearby guard (±8 lines)."""
        # Simple heuristic: look for keywords in nearby lines
        # In full implementation, would parse the actual code
        guard_keywords = [
            "hasattr",
            "persistent_version",
            "save_version",
            "migration",
            "if",
        ]
        # This would require reading the file - simplified for now
        return False

    def _are_types_incompatible(self, types: Set[str]) -> bool:
        """Check if a set of types are incompatible."""
        # Simplified: treat numeric types as compatible
        numeric = {"int", "float"}
        if types.issubset(numeric):
            return False
        # Everything else is incompatible
        return True

    def _levenshtein_distance(self, s1: str, s2: str) -> int:
        """Calculate Levenshtein distance between two strings."""
        if len(s1) < len(s2):
            return self._levenshtein_distance(s2, s1)

        if len(s2) == 0:
            return len(s1)

        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row

        return previous_row[-1]

    def _median(self, values: List[float]) -> float:
        """Calculate median of a list of values."""
        if not values:
            return 0.0
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        if n % 2 == 0:
            return (sorted_vals[n // 2 - 1] + sorted_vals[n // 2]) / 2
        else:
            return sorted_vals[n // 2]

    def _is_outlier(
        self, value: float, all_values: List[float], baseline: float
    ) -> bool:
        """Check if a value is an outlier using configured method."""
        if self.score_outlier_method == "iqr":
            k = self.score_outlier_params.get("iqr_k", 2.5)
            return abs(value) > k * baseline
        else:
            # Default: simple threshold
            return abs(value) > 3 * baseline
