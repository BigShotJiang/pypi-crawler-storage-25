"""Phase 7: Localization Coverage Validation - SAE v0.7.7

Validates translation completeness, consistency, and quality.

Rule Groups:
- L01: Missing Translation Keys
- L02: Orphaned/Unused Translations
- L03: Length Mismatch Detection
- L04: Locale Tag Consistency
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.analysis.sae.locale_parser import LocaleIndexSchema
from branchpy.analysis.sae.validators.tier1 import Severity, ValidationIssue


@dataclass
class LocaleMetrics:
    """Localization coverage metrics"""

    total_languages: int = 0
    total_source_strings: int = 0
    avg_coverage_pct: float = 0.0
    coverage_by_language: Optional[Dict[str, float]] = None
    missing_count: int = 0
    orphaned_count: int = 0
    mismatch_count: int = 0

    def __post_init__(self):
        if self.coverage_by_language is None:
            self.coverage_by_language = {}


def validate_locale_phase7(
    locale_index: LocaleIndexSchema,
    project_root: str | Path,
    required_languages: Optional[List[str]] = None,
    coverage_threshold: float = 80.0,
) -> tuple[List[ValidationIssue], LocaleMetrics]:
    """
    Run Phase 7 localization validation.

    Args:
        locale_index: Locale index from LocaleParser
        project_root: Project root directory
        required_languages: Languages that must have 100% coverage
        coverage_threshold: Minimum coverage % for warnings (default: 80%)

    Returns:
        Tuple of (issues, metrics)
    """
    validator = LocaleValidator(
        locale_index, project_root, required_languages, coverage_threshold
    )
    return validator.validate(), validator.metrics


class LocaleValidator:
    """Phase 7: Localization Coverage Validation"""

    def __init__(
        self,
        locale_index: LocaleIndexSchema,
        project_root: str | Path,
        required_languages: Optional[List[str]] = None,
        coverage_threshold: float = 80.0,
    ):
        """
        Args:
            locale_index: Locale index from LocaleParser
            project_root: Project root directory
            required_languages: Languages that must have 100% coverage (ERROR if incomplete)
            coverage_threshold: Minimum coverage % for warnings (default: 80%)
        """
        self.locale_index = locale_index
        self.project_root = Path(project_root)
        self.required_languages = set(required_languages or [])
        self.coverage_threshold = coverage_threshold
        self.issues: List[ValidationIssue] = []
        self.metrics = LocaleMetrics()

    def validate(self) -> List[ValidationIssue]:
        """
        Run all Phase 7 validation rules.

        Returns:
            List of ValidationIssue objects
        """
        self.issues = []

        # Build metrics
        self._compute_metrics()

        # L01: Missing translations
        self._check_missing_translations()

        # L02: Orphaned translations
        self._check_orphaned_translations()

        # L03: Length mismatches
        self._check_length_mismatches()

        # L04: Coverage thresholds
        self._check_coverage_thresholds()

        return self.issues

    def _compute_metrics(self) -> None:
        """Compute localization metrics"""
        total_langs = len(self.locale_index.languages)
        total_source = self.locale_index.total_source_strings

        coverage_sum = 0.0
        coverage_by_lang = {}
        total_missing = 0
        total_orphaned = 0
        total_mismatch = 0

        for lang in self.locale_index.languages:
            cov_data = self.locale_index.coverage.get(lang, {})
            coverage_pct = cov_data.get("coveragePercent", 0.0)
            coverage_by_lang[lang] = coverage_pct
            coverage_sum += coverage_pct

            total_missing += cov_data.get("missing", 0)
            total_orphaned += cov_data.get("orphaned", 0)
            total_mismatch += cov_data.get("lengthMismatches", 0)

        avg_coverage = coverage_sum / total_langs if total_langs > 0 else 0.0

        self.metrics = LocaleMetrics(
            total_languages=total_langs,
            total_source_strings=total_source,
            avg_coverage_pct=round(avg_coverage, 2),
            coverage_by_language=coverage_by_lang,
            missing_count=total_missing,
            orphaned_count=total_orphaned,
            mismatch_count=total_mismatch,
        )

    def _add_issue(
        self,
        rule_id: str,
        severity: Severity | str,
        message: str,
        file: str,
        line: int,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Add a validation issue"""
        if isinstance(severity, str):
            severity = Severity(severity)

        self.issues.append(
            ValidationIssue(
                rule_id=rule_id,
                severity=severity,
                message=message,
                file=file,
                line=line,
                extra=extra or {},
            )
        )

    # === L01: Missing Translation Keys ===

    def _check_missing_translations(self) -> None:
        """L01-001: Detect missing translations for each language"""
        for lang in self.locale_index.languages:
            cov_data = self.locale_index.coverage.get(lang, {})
            missing_ids = cov_data.get("missingIds", [])

            # Severity: ERROR for required languages, WARNING otherwise
            severity = (
                Severity.ERROR if lang in self.required_languages else Severity.WARNING
            )

            for string_id in missing_ids:
                source_text = self.locale_index.source_strings.get(string_id, "")
                location = self.locale_index.locator.get(
                    string_id, {"file": "<unknown>", "line": 1}
                )

                # Truncate long source text
                text_snippet = (
                    source_text[:60] + "..." if len(source_text) > 60 else source_text
                )

                self._add_issue(
                    rule_id="L01-001",
                    severity=severity,
                    message=f'Missing {lang} translation: "{text_snippet}"',
                    file=location["file"],
                    line=location["line"],
                    extra={
                        "language": lang,
                        "stringId": string_id,
                        "sourceText": source_text,
                        "coverage": cov_data.get("coveragePercent", 0.0),
                    },
                )

    # === L02: Orphaned/Unused Translations ===

    def _check_orphaned_translations(self) -> None:
        """L02-001: Detect orphaned translations (no source string)"""
        for lang in self.locale_index.languages:
            cov_data = self.locale_index.coverage.get(lang, {})
            orphaned_ids = cov_data.get("orphanedIds", [])

            for string_id in orphaned_ids:
                trans_text = self.locale_index.translations[lang].get(string_id, "")
                text_snippet = (
                    trans_text[:60] + "..." if len(trans_text) > 60 else trans_text
                )

                self._add_issue(
                    rule_id="L02-001",
                    severity=Severity.INFO,
                    message=f'Orphaned {lang} translation (no source): "{text_snippet}"',
                    file="<l10n>",
                    line=1,
                    extra={
                        "language": lang,
                        "stringId": string_id,
                        "translatedText": trans_text,
                    },
                )

    # === L03: Length Mismatch Detection ===

    def _check_length_mismatches(self) -> None:
        """L03-001: Detect significant length differences between source and translation"""
        for lang in self.locale_index.languages:
            cov_data = self.locale_index.coverage.get(lang, {})
            mismatch_ids = cov_data.get("mismatchIds", [])

            for string_id in mismatch_ids:
                source_text = self.locale_index.source_strings.get(string_id, "")
                trans_text = self.locale_index.translations[lang].get(string_id, "")
                location = self.locale_index.locator.get(
                    string_id, {"file": "<unknown>", "line": 1}
                )

                src_len = len(source_text)
                trans_len = len(trans_text)

                if src_len > 0:
                    diff_pct = abs(trans_len - src_len) / src_len * 100
                else:
                    diff_pct = 0.0

                text_snippet = (
                    source_text[:40] + "..." if len(source_text) > 40 else source_text
                )

                self._add_issue(
                    rule_id="L03-001",
                    severity=Severity.WARNING,
                    message=f'{lang} translation length differs by {diff_pct:.0f}%: "{text_snippet}"',
                    file=location["file"],
                    line=location["line"],
                    extra={
                        "language": lang,
                        "stringId": string_id,
                        "sourceLength": src_len,
                        "translatedLength": trans_len,
                        "differencePercent": round(diff_pct, 2),
                    },
                )

    # === L04: Coverage Threshold Checks ===

    def _check_coverage_thresholds(self) -> None:
        """L04-001: Warn if coverage falls below threshold"""
        for lang in self.locale_index.languages:
            cov_data = self.locale_index.coverage.get(lang, {})
            coverage_pct = cov_data.get("coveragePercent", 0.0)

            if coverage_pct < self.coverage_threshold:
                missing_count = cov_data.get("missing", 0)

                severity = (
                    Severity.ERROR
                    if lang in self.required_languages
                    else Severity.WARNING
                )

                self._add_issue(
                    rule_id="L04-001",
                    severity=severity,
                    message=f"{lang} coverage is {coverage_pct:.1f}% (threshold: {self.coverage_threshold}%, missing: {missing_count})",
                    file="<project>",
                    line=1,
                    extra={
                        "language": lang,
                        "coverage": coverage_pct,
                        "threshold": self.coverage_threshold,
                        "missing": missing_count,
                    },
                )
