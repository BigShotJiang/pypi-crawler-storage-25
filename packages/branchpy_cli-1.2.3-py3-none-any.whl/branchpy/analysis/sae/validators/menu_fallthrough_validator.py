"""Menu Fallthrough Validator - Detect false choices and choices with no action"""

from typing import List, Optional

from ..cfg_builder import ControlFlowGraph, EdgeType, NodeKind


class Issue:
    """Validation issue"""

    def __init__(
        self,
        rule_id: str,
        severity: str,
        message: str,
        file: str,
        line: int,
        suggestion: str = "",
    ):
        self.rule_id = rule_id
        self.severity = severity
        self.message = message
        self.file = file
        self.line = line
        self.suggestion = suggestion


def validate_menu_fallthrough(cfg: ControlFlowGraph) -> List[Issue]:
    """
    Validate menu choices for false choices and missing actions.

    Rules:
    - menu_false_choice: All menu choices lead to same outcome
    - menu_choice_no_action: Menu choice has no effect (no jump/call/state change)
    - menu_no_choices: Menu has no choices

    Severity: WARNING
    """
    issues = []

    # Find all MENU nodes
    menu_nodes = [n for n in cfg.nodes.values() if n.kind == NodeKind.MENU]

    for menu_node in menu_nodes:
        # Get all BRANCH edges from this menu
        branch_edges = [
            e
            for e in cfg.edges
            if e.from_node == menu_node.id and e.edge_type == EdgeType.BRANCH_TRUE
        ]

        if not branch_edges:
            # Menu with no choices
            issues.append(
                Issue(
                    rule_id="menu_no_choices",
                    severity="warning",
                    message="Menu has no choices",
                    file=menu_node.file,
                    line=menu_node.line,
                    suggestion="Add at least one menu choice or remove the menu block",
                )
            )
            continue

        # Find the merge point (where all choices reconverge)
        merge_point = _find_merge_point(cfg, [e.to_node for e in branch_edges])

        # Track where each choice leads (for false choice detection)
        choice_outcomes = []
        for edge in branch_edges:
            outcome = _trace_choice_outcome(cfg, edge.to_node, merge_point, depth=10)
            choice_outcomes.append((edge.label, outcome))

        # Check if all choices lead to same place (false choice)
        unique_outcomes = set(o for _, o in choice_outcomes if o)
        if len(unique_outcomes) == 1 and len(branch_edges) > 1:
            issues.append(
                Issue(
                    rule_id="menu_false_choice",
                    severity="warning",
                    message=f"All {len(branch_edges)} menu choices lead to the same outcome",
                    file=menu_node.file,
                    line=menu_node.line,
                    suggestion="Add different outcomes for choices (different jumps, calls, or state changes) or remove the menu",
                )
            )

        # Check each choice for missing action
        for edge in branch_edges:
            has_action = _choice_has_action(cfg, edge.to_node, merge_point, depth=5)
            if not has_action:
                choice_label = edge.label or "unnamed choice"
                issues.append(
                    Issue(
                        rule_id="menu_choice_no_action",
                        severity="warning",
                        message=f"Menu choice '{choice_label}' has no effect",
                        file=menu_node.file,
                        line=menu_node.line,
                        suggestion=f"Add jump, call, or variable assignment in choice block for '{choice_label}'",
                    )
                )

    return issues


def _find_merge_point(cfg: ControlFlowGraph, start_nodes: List[str]) -> Optional[str]:
    """
    Find where multiple choice paths converge (merge point).

    Returns the first node ID that all paths can reach, or None if no common merge point.
    """
    if len(start_nodes) < 2:
        return None

    # Trace reachable nodes from each starting point (within reasonable depth)
    reachable_sets = []
    for start in start_nodes:
        reachable = set()
        visited = set()
        queue = [(start, 0)]
        max_depth = 20  # Reasonable limit

        while queue:
            current, depth = queue.pop(0)
            if current in visited or current not in cfg.nodes or depth > max_depth:
                continue
            visited.add(current)
            reachable.add(current)

            # Follow SEQ edges (the normal flow)
            for edge in cfg.edges:
                if edge.from_node == current and edge.to_node not in visited:
                    queue.append((edge.to_node, depth + 1))

        reachable_sets.append(reachable)

    # Find intersection of all reachable sets
    if not reachable_sets:
        return None

    common_nodes = set.intersection(*reachable_sets)

    if not common_nodes:
        return None

    # Return the closest common node (minimum distance from all start nodes)
    # For simplicity, just return the first one found
    # A better approach would calculate actual distances
    min_distance = float("inf")
    best_node = None

    for node_id in common_nodes:
        # Calculate average distance from all start nodes
        distances = []
        for start in start_nodes:
            dist = _get_distance(cfg, start, node_id)
            if dist is None:
                break
            distances.append(dist)

        if len(distances) == len(start_nodes):
            avg_dist = sum(distances) / len(distances)
            if avg_dist < min_distance:
                min_distance = avg_dist
                best_node = node_id

    return best_node


def _get_distance(
    cfg: ControlFlowGraph, from_node: str, to_node: str, max_depth: int = 20
) -> Optional[int]:
    """Get the shortest path distance between two nodes."""
    if from_node == to_node:
        return 0

    visited = set()
    queue = [(from_node, 0)]

    while queue:
        current, depth = queue.pop(0)
        if current == to_node:
            return depth
        if depth >= max_depth or current in visited or current not in cfg.nodes:
            continue
        visited.add(current)

        for edge in cfg.edges:
            if edge.from_node == current and edge.to_node not in visited:
                queue.append((edge.to_node, depth + 1))

    return None


def _trace_choice_outcome(
    cfg: ControlFlowGraph,
    start_node_id: str,
    merge_point: Optional[str] = None,
    depth: int = 10,
) -> Optional[str]:
    """
    Trace a choice to its eventual jump/call target.

    Stops at merge_point if provided (to avoid attributing shared code to individual choices).

    Returns the target label name or None if no clear target.
    """
    if depth <= 0:
        return None

    visited = set()
    current = start_node_id

    for _ in range(depth):
        if current in visited or current not in cfg.nodes:
            break

        # Stop if we reached the merge point
        if merge_point and current == merge_point:
            return None

        visited.add(current)

        # Get outgoing edges from current node
        outgoing = [e for e in cfg.edges if e.from_node == current]

        if not outgoing:
            # Dead end
            return current

        # Look for JUMP or CALL edges (these are the "outcomes")
        for edge in outgoing:
            if edge.edge_type in (EdgeType.JUMP, EdgeType.CALL):
                # Found outcome - return target node
                if edge.to_node in cfg.nodes:
                    target_node = cfg.nodes[edge.to_node]
                    return target_node.name or edge.to_node
                return edge.to_node

        # Follow SEQ edge if no jump/call
        seq_edges = [e for e in outgoing if e.edge_type == EdgeType.SEQ]
        if seq_edges:
            current = seq_edges[0].to_node
        else:
            break

    return None


def _choice_has_action(
    cfg: ControlFlowGraph,
    start_node_id: str,
    merge_point: Optional[str] = None,
    depth: int = 3,
) -> bool:
    """
    Check if a choice block has any meaningful action (jump/call/python) before reaching the merge point.

    Uses shallow depth (3) to avoid attributing actions from other choices or shared code.

    A choice has "no action" if it only contains:
    - pass statements (SAY nodes with no content)
    - Dialogue (SAY nodes)
    - Then reaches merge point or dead end

    Returns True if action found, False if just dialogue/no action.
    """
    if depth <= 0:
        return False

    visited = set()
    current = start_node_id

    for step in range(depth):
        if current in visited or current not in cfg.nodes:
            break

        # Stop if we reached the merge point - no action found in choice-specific code
        if merge_point and current == merge_point:
            return False

        # Check if this node has multiple incoming edges (merge point)
        # This indicates we've left the choice-specific code
        incoming_edges = [e for e in cfg.edges if e.to_node == current]
        if len(incoming_edges) > 1 and step > 0:  # Skip first node (the choice start)
            # Multiple paths converge here - stop searching
            return False

        visited.add(current)

        current_node = cfg.nodes[current]

        # Get outgoing edges
        outgoing = [e for e in cfg.edges if e.from_node == current]

        # JUMP or CALL edges are actions - check this FIRST before following SEQ edges
        for edge in outgoing:
            if edge.edge_type in (EdgeType.JUMP, EdgeType.CALL, EdgeType.JUMP_DYNAMIC):
                return True

        # If we find multiple outgoing SEQ edges, we've hit a merge point
        # This means we've left the choice-specific code
        seq_edges = [e for e in outgoing if e.edge_type == EdgeType.SEQ]
        if len(seq_edges) > 1:
            # Multiple paths converge here - stop searching
            return False

        # Follow single SEQ edge to next node
        if seq_edges:
            current = seq_edges[0].to_node
        else:
            # Dead end with no action
            break

    # No action found in the limited depth
    return False
