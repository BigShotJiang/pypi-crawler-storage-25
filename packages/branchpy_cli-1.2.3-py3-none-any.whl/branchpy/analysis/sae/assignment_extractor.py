"""
SAE Assignment Extractor - Extract static assignment events (writes) from Ren'Py AST.

Phase A Implementation:
- Walk AST/IR nodes from branchpy.semantics.ast.nodes
- Extract variable assignments from Python code
- Track context: label, file, line, guard (if/menu), confidence
- Delegate Python parsing to branchpy.semantics.ast.python_ast_parser

Data Contract:
- Produces normalized AssignmentEvent stream for STATS2/VARMAP consumption
- Emits result.sae.assignments[] in analyze reports

Architecture:
- Leverages existing PythonASTParser for assignment detection
- Handles guard context from IfNode and MenuNode
- Marks confidence: 'definite' (unconditional) vs 'possible' (under guard)

Phase A Scope (v1):
- Supports: x = expr, x += expr, x -= expr, x *= expr, x /= expr
- Supports: default/define statements
- Supports: if/elif/else guards
- Supports: menu choice guards
- Deferred: dict subscripts, setattr, globals(), list mutations
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Any, List, Optional

from branchpy.semantics.ast.nodes import (
    ChoiceNode,
    DefineNode,
    ElifNode,
    ElseNode,
    IfNode,
    LabelNode,
    MenuNode,
    PythonNode,
    WhileNode,
)
from branchpy.semantics.ast.python_ast_parser import PythonASTParser


@dataclass(frozen=True)
class AssignmentEvent:
    """
    Represents a single variable assignment (write) event.

    Attributes:
        var: Canonical variable name (e.g., "score", "persistent.flag", "stats[trust]")
        op: Assignment operator ("=", "+=", "-=", "*=", "/=", "//=", "%=", "MUTATE")
        value_repr: String representation of RHS value (best-effort)
        expr: Original expression/statement text
        file: Source file path
        line: Line number (1-based)
        label: Containing label name
        guard: Condition context (None if unconditional)
        confidence: 'definite' (unconditional) | 'possible' (under guard)
        node_type: Context type ('python_inline', 'python_block', 'define', 'default')
        target_type: Target classification (None, 'simple', 'subscript', 'attribute', 'call')
        container: Container name for subscript/attribute targets (None for simple assigns)
        key: Subscript key for subscript targets (None for non-subscript)
        mutation_method: Method name for mutations (e.g., 'append', 'setattr')
        mutation_target: Target variable for mutations (same as var for self-mutations)
        indirect: True if target cannot be statically resolved (dynamic keys/attributes)
        call_site: Reserved for Phase C PFI bridge (None for Phase B)
    """

    var: str
    op: str
    value_repr: str
    expr: str
    file: str
    line: int
    label: str
    guard: Optional[str]
    confidence: str  # 'definite' | 'possible'
    node_type: str
    # Phase B fields (all optional for backwards compatibility)
    target_type: Optional[str] = None
    container: Optional[str] = None
    key: Optional[str] = None
    mutation_method: Optional[str] = None
    mutation_target: Optional[str] = None
    indirect: bool = False
    call_site: Optional[str] = None  # Reserved for Phase C

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dictionary for report output."""
        result = {
            "var": self.var,
            "op": self.op,
            "value": self.value_repr,
            "expr": self.expr,
            "file": self.file,
            "line": self.line,
            "label": self.label,
            "guard": self.guard,
            "confidence": self.confidence,
            "node_type": self.node_type,
        }
        # Phase B fields (only include if set)
        if self.target_type is not None:
            result["target_type"] = self.target_type
        if self.container is not None:
            result["container"] = self.container
        if self.key is not None:
            result["key"] = self.key
        if self.mutation_method is not None:
            result["mutation_method"] = self.mutation_method
        if self.mutation_target is not None:
            result["mutation_target"] = self.mutation_target
        if self.indirect:
            result["indirect"] = self.indirect
        if self.call_site is not None:
            result["call_site"] = self.call_site
        return result


class AssignmentExtractor:
    """
    SAE Phase A: Extract static assignment events (writes) from Ren'Py AST/IR.

    Consumes nodes from branchpy.semantics.ast.nodes.
    Delegates Python parsing to branchpy.semantics.ast.python_ast_parser.

    Usage:
        extractor = AssignmentExtractor()
        events = extractor.extract_from_labels(label_nodes)

    Output:
        List[AssignmentEvent] for result.sae.assignments[]
    """

    def __init__(self) -> None:
        """Initialize extractor with Python AST parser."""
        self._py_parser = PythonASTParser()

    def extract_from_labels(self, labels: List[LabelNode]) -> List[AssignmentEvent]:
        """
        Extract all assignment events from a list of label nodes.

        Args:
            labels: List of LabelNode objects from RenpyASTParser

        Returns:
            List of AssignmentEvent objects representing all writes
        """
        events: List[AssignmentEvent] = []
        for label in labels:
            events.extend(self.extract_from_label(label))
        return events

    def extract_from_screen_actions(self, statements: dict) -> List[AssignmentEvent]:
        """
        Extract assignment events from screen write actions (Tier 3).

        Args:
            statements: Dict of {file_path: [Statement]} from StatementExtractor

        Returns:
            List of AssignmentEvent objects from screen actions (SetVariable, ToggleVariable, SetField)
        """
        from branchpy.analysis.sae.statement_extractor import StatementType

        events: List[AssignmentEvent] = []

        for file_path, stmt_list in statements.items():
            for stmt in stmt_list:
                # Handle both dict and object formats (defensive)
                stmt_type = (
                    stmt.get("type")
                    if isinstance(stmt, dict)
                    else getattr(stmt, "type", None)
                )

                # Only process screen write actions
                if stmt_type != StatementType.SCREEN_ACTION:
                    continue

                action_type = (
                    stmt.get("action_type")
                    if isinstance(stmt, dict)
                    else getattr(stmt, "action_type", None)
                )
                if action_type not in ("setvariable", "togglevariable", "setfield"):
                    continue

                # Extract variable name from target (handle dict/object)
                var_name = (
                    stmt.get("target")
                    if isinstance(stmt, dict)
                    else getattr(stmt, "target", None)
                )
                if not var_name:
                    continue

                # Determine operator based on action type
                if action_type == "setvariable":
                    op = "="
                    meta = (
                        stmt.get("meta", {})
                        if isinstance(stmt, dict)
                        else getattr(stmt, "meta", {})
                    )
                    value_repr = (
                        meta.get("value", "<unknown>")
                        if isinstance(meta, dict)
                        else getattr(meta, "value", "<unknown>")
                    )
                elif action_type == "togglevariable":
                    op = "toggle"
                    value_repr = "!{var}"  # Toggle indicator
                elif action_type == "setfield":
                    op = "="
                    meta = (
                        stmt.get("meta", {})
                        if isinstance(stmt, dict)
                        else getattr(stmt, "meta", {})
                    )
                    value_repr = (
                        meta.get("value", "<unknown>")
                        if isinstance(meta, dict)
                        else getattr(meta, "value", "<unknown>")
                    )
                else:
                    continue

                # Determine target type
                if action_type == "setfield":
                    # SetField(object, "field", value) → object.field
                    meta = (
                        stmt.get("meta", {})
                        if isinstance(stmt, dict)
                        else getattr(stmt, "meta", {})
                    )
                    target_type = "attribute"
                    container = (
                        meta.get("object", "")
                        if isinstance(meta, dict)
                        else getattr(meta, "object", "")
                    )
                    key = (
                        meta.get("field", "")
                        if isinstance(meta, dict)
                        else getattr(meta, "field", "")
                    )
                else:
                    # SetVariable/ToggleVariable
                    target_type = "simple"
                    container = None
                    key = None

                # Create assignment event (handle dict/object for all fields)
                events.append(
                    AssignmentEvent(
                        var=var_name,
                        op=op,
                        value_repr=value_repr,
                        expr=(
                            stmt.get("raw", "")
                            if isinstance(stmt, dict)
                            else getattr(stmt, "raw", "")
                        ),
                        file=file_path,
                        line=(
                            stmt.get("line", 0)
                            if isinstance(stmt, dict)
                            else getattr(stmt, "line", 0)
                        ),
                        label=(
                            stmt.get("screen_name", "<screen>")
                            if isinstance(stmt, dict)
                            else getattr(stmt, "screen_name", "<screen>")
                        ),  # Use screen name as label
                        guard=None,  # Screen actions are user-triggered, not conditional
                        confidence="definite",  # Screen actions always execute when clicked
                        node_type="screen_action",
                        target_type=target_type,
                        container=container,
                        key=key,
                        mutation_method=None,
                        mutation_target=None,
                        indirect=False,
                    )
                )

        return events

    def extract_from_label(self, label: LabelNode) -> List[AssignmentEvent]:
        """
        Extract assignment events from a single label node.

        Args:
            label: LabelNode to analyze

        Returns:
            List of AssignmentEvent objects for this label (deduplicated)
        """
        events: List[AssignmentEvent] = []
        children = getattr(label, "children", [])
        self._walk_block(
            nodes=children, events=events, label_name=label.name, guard=None
        )

        # Deduplicate events based on canonical identity (var, op, file)
        return self._deduplicate_events(events)

    def _walk_block(
        self,
        nodes: List[Any],
        events: List[AssignmentEvent],
        label_name: str,
        guard: Optional[str],
    ) -> None:
        """
        Recursively walk a block of nodes, extracting assignments.

        Args:
            nodes: List of AST nodes to process
            events: Accumulator list for assignment events
            label_name: Current label name context
            guard: Current guard condition (None if unconditional)
        """
        for node in nodes:
            # Python code ($ statements and python: blocks)
            if isinstance(node, PythonNode):
                events.extend(
                    self._extract_from_python_node(
                        node, label_name=label_name, guard=guard
                    )
                )
                continue

            # Define statements (define var = value)
            if isinstance(node, DefineNode):
                events.extend(
                    self._extract_from_define_node(
                        node, label_name=label_name, guard=guard
                    )
                )
                continue

            # Conditional branches (if/elif/else)
            if isinstance(node, IfNode):
                self._walk_if(node, events, label_name, guard)
                continue

            # Menu choices
            if isinstance(node, MenuNode):
                self._walk_menu(node, events, label_name, guard)
                continue

            # While loops (treat condition as guard)
            if isinstance(node, WhileNode):
                cond = getattr(node, "condition", "while(<unknown>)")
                combined_guard = self._combine_guard(guard, str(cond))
                children = getattr(node, "children", [])
                self._walk_block(children, events, label_name, combined_guard)
                continue

            # Phase A: Ignore other node types (Jump, Call, Return, Say, etc.)

    def _walk_if(
        self,
        if_node: IfNode,
        events: List[AssignmentEvent],
        label_name: str,
        parent_guard: Optional[str],
    ) -> None:
        """
        Walk if/elif/else branches with guard context.

        Args:
            if_node: IfNode to analyze
            events: Accumulator list for assignment events
            label_name: Current label name
            parent_guard: Parent guard condition
        """
        # Primary if branch
        cond = getattr(if_node, "condition", "if(<unknown>)")
        combined_guard = self._combine_guard(parent_guard, str(cond))
        if_children = getattr(if_node, "children", [])
        self._walk_block(if_children, events, label_name, combined_guard)

        # Elif branches (walk children looking for ElifNode)
        for child in if_children:
            if isinstance(child, ElifNode):
                elif_cond = getattr(child, "condition", "elif(<unknown>)")
                elif_guard = self._combine_guard(parent_guard, str(elif_cond))
                elif_children = getattr(child, "children", [])
                self._walk_block(elif_children, events, label_name, elif_guard)

            # Else branch
            elif isinstance(child, ElseNode):
                # Else implies NOT of all previous conditions
                else_guard = self._combine_guard(parent_guard, f"NOT({cond})")
                else_children = getattr(child, "children", [])
                self._walk_block(else_children, events, label_name, else_guard)

    def _walk_menu(
        self,
        menu_node: MenuNode,
        events: List[AssignmentEvent],
        label_name: str,
        parent_guard: Optional[str],
    ) -> None:
        """
        Walk menu choice blocks with guard context.

        Args:
            menu_node: MenuNode to analyze
            events: Accumulator list for assignment events
            label_name: Current label name
            parent_guard: Parent guard condition
        """
        # Menu choices are children of MenuNode
        children = getattr(menu_node, "children", [])
        for child in children:
            if isinstance(child, ChoiceNode):
                # Choice condition (if specified)
                choice_cond = getattr(child, "condition", None)
                choice_text = getattr(child, "text", "menu_choice")

                # Build guard: use condition if present, otherwise choice text
                if choice_cond:
                    guard_part = str(choice_cond)
                else:
                    # Use choice text as identifier (sanitized)
                    guard_part = f"choice({choice_text[:50]})"

                combined_guard = self._combine_guard(parent_guard, guard_part)

                # Walk choice body
                choice_children = getattr(child, "children", [])
                self._walk_block(choice_children, events, label_name, combined_guard)

    def _extract_from_python_node(
        self,
        py_node: PythonNode,
        label_name: str,
        guard: Optional[str],
    ) -> List[AssignmentEvent]:
        """
        Extract assignments from a PythonNode using PythonASTParser.

        Args:
            py_node: PythonNode containing Python code
            label_name: Current label name
            guard: Current guard condition

        Returns:
            List of AssignmentEvent objects
        """
        code = getattr(py_node, "code", "")
        file_path = getattr(py_node, "file_path", "") or ""
        line = int(getattr(py_node, "line_number", 0) or 0)
        is_single_line = getattr(py_node, "is_single_line", False)

        # Use existing PythonASTParser to extract assignments
        py_assignments = self._extract_assignments_from_python(code)

        # Determine default confidence based on guard
        # Phase C Tier 2 (GAP-010): Use "guarded" instead of "possible" for conditional paths
        # Old: "possible" if guard else "definite"
        # New: "guarded" if guard else "definite"
        # Rationale: "guarded" better conveys that the write is behind a condition
        default_confidence = "guarded" if guard else "definite"

        # Determine node type
        node_type = "python_inline" if is_single_line else "python_block"

        # Convert to AssignmentEvent objects (Phase A + Phase B fields)
        events: List[AssignmentEvent] = []
        for a in py_assignments:
            # Phase C: Use extracted confidence if provided, otherwise use default
            confidence = a.get("confidence", default_confidence)

            events.append(
                AssignmentEvent(
                    var=a["var"],
                    op=a["op"],
                    value_repr=a.get("value_repr", ""),
                    expr=a.get("expr", ""),
                    file=file_path,
                    line=line + a.get("line_offset", 0),
                    label=label_name,
                    guard=guard,
                    confidence=confidence,
                    node_type=node_type,
                    # Phase B fields (optional, with defaults)
                    target_type=a.get("target_type"),
                    container=a.get("container"),
                    key=a.get("key"),
                    mutation_method=a.get("mutation_method"),
                    mutation_target=a.get("mutation_target"),
                    indirect=a.get("indirect", False),
                    call_site=None,  # Reserved for Phase C
                )
            )
        return events

    def _extract_from_define_node(
        self,
        define_node: DefineNode,
        label_name: str,
        guard: Optional[str],
    ) -> List[AssignmentEvent]:
        """
        Extract assignment from a define/default statement.

        Args:
            define_node: DefineNode to analyze
            label_name: Current label name
            guard: Current guard condition

        Returns:
            List containing single AssignmentEvent
        """
        var_name = getattr(define_node, "name", "")
        value_text = getattr(define_node, "value_text", "")
        file_path = getattr(define_node, "file_path", "") or ""
        line = int(getattr(define_node, "line_number", 0) or 0)

        # Define statements are always definite (top-level)
        confidence = "definite"

        return [
            AssignmentEvent(
                var=var_name,
                op="=",
                value_repr=value_text,
                expr=f"define {var_name} = {value_text}",
                file=file_path,
                line=line,
                label=label_name,
                guard=guard,  # Usually None for define
                confidence=confidence,
                node_type="define",
                target_type="simple",  # define/default are simple assignments
            )
        ]

    def _extract_assignments_from_python(self, code: str) -> List[dict]:
        """
        Adapter layer: Extract assignments from Python code using AST.

        Phase A: Simple/attribute assigns, augmented assigns
        Phase B: Subscript writes, mutations, indirect writes (setattr/globals)

        Args:
            code: Python code string

        Returns:
            List of dicts with keys: var, op, value_repr, expr, line_offset
            Phase B adds: target_type, container, key, mutation_method, mutation_target, indirect
        """
        if not code.strip():
            return []

        assignments: List[dict] = []

        try:
            tree = ast.parse(code)

            for stmt in ast.walk(tree):
                # Simple assignment: x = value
                if isinstance(stmt, ast.Assign):
                    for target in stmt.targets:
                        # Phase B: Multi-target assignment (tuple/list unpacking)
                        # x, y = 10, 20 or [a, b] = [1, 2]
                        if isinstance(target, (ast.Tuple, ast.List)):
                            # Flatten nested tuples/lists to get all variable names
                            target_names = self._flatten_assignment_targets(target)
                            value_str = (
                                ast.unparse(stmt.value)
                                if hasattr(ast, "unparse")
                                else repr(stmt.value)
                            )
                            line_offset = getattr(stmt, "lineno", 1) - 1

                            # Emit one event per target variable
                            for var_name in target_names:
                                expr_str = f"{var_name} = {value_str}"
                                assignments.append(
                                    {
                                        "var": var_name,
                                        "op": "=",
                                        "value_repr": value_str,
                                        "expr": expr_str,
                                        "line_offset": line_offset,
                                        "target_type": "simple",
                                    }
                                )

                        # Simple name assignment: x = value
                        elif isinstance(target, ast.Name):
                            var_name = target.id
                            value_str = (
                                ast.unparse(stmt.value)
                                if hasattr(ast, "unparse")
                                else repr(stmt.value)
                            )
                            expr_str = f"{var_name} = {value_str}"
                            line_offset = getattr(stmt, "lineno", 1) - 1

                            assignments.append(
                                {
                                    "var": var_name,
                                    "op": "=",
                                    "value_repr": value_str,
                                    "expr": expr_str,
                                    "line_offset": line_offset,
                                    "target_type": "simple",
                                }
                            )

                        # Attribute assignment: obj.attr = value (e.g., persistent.x)
                        elif isinstance(target, ast.Attribute):
                            # Build full path: obj.attr or obj.attr.subattr
                            var_name = self._get_attribute_path(target)
                            container, key = self._extract_attribute_metadata(target)
                            value_str = (
                                ast.unparse(stmt.value)
                                if hasattr(ast, "unparse")
                                else repr(stmt.value)
                            )
                            expr_str = f"{var_name} = {value_str}"
                            line_offset = getattr(stmt, "lineno", 1) - 1

                            assignments.append(
                                {
                                    "var": var_name,
                                    "op": "=",
                                    "value_repr": value_str,
                                    "expr": expr_str,
                                    "line_offset": line_offset,
                                    "target_type": "attribute",
                                    "container": container,
                                    "key": key,
                                }
                            )

                        # Phase B: Subscript assignment: container[key] = value
                        elif isinstance(target, ast.Subscript):
                            result = self._extract_subscript_write(
                                target, "=", stmt.value, stmt
                            )
                            if result:
                                assignments.append(result)

                # Augmented assignment: x += value, x -= value, etc.
                elif isinstance(stmt, ast.AugAssign):
                    op_map = {
                        ast.Add: "+=",
                        ast.Sub: "-=",
                        ast.Mult: "*=",
                        ast.Div: "/=",
                        ast.FloorDiv: "//=",
                        ast.Mod: "%=",
                        ast.Pow: "**=",
                    }
                    op = op_map.get(type(stmt.op), "?=")

                    if isinstance(stmt.target, ast.Name):
                        var_name = stmt.target.id
                        value_str = (
                            ast.unparse(stmt.value)
                            if hasattr(ast, "unparse")
                            else repr(stmt.value)
                        )
                        expr_str = f"{var_name} {op} {value_str}"
                        line_offset = getattr(stmt, "lineno", 1) - 1

                        assignments.append(
                            {
                                "var": var_name,
                                "op": op,
                                "value_repr": value_str,
                                "expr": expr_str,
                                "line_offset": line_offset,
                                "target_type": "simple",
                            }
                        )

                    # Augmented assignment to attribute: obj.attr += value
                    elif isinstance(stmt.target, ast.Attribute):
                        var_name = self._get_attribute_path(stmt.target)
                        container, key = self._extract_attribute_metadata(stmt.target)
                        value_str = (
                            ast.unparse(stmt.value)
                            if hasattr(ast, "unparse")
                            else repr(stmt.value)
                        )
                        expr_str = f"{var_name} {op} {value_str}"
                        line_offset = getattr(stmt, "lineno", 1) - 1

                        assignments.append(
                            {
                                "var": var_name,
                                "op": op,
                                "value_repr": value_str,
                                "expr": expr_str,
                                "line_offset": line_offset,
                                "target_type": "attribute",
                                "container": container,
                                "key": key,
                            }
                        )

                    # Phase B: Augmented subscript: container[key] += value
                    elif isinstance(stmt.target, ast.Subscript):
                        result = self._extract_subscript_write(
                            stmt.target, op, stmt.value, stmt
                        )
                        if result:
                            assignments.append(result)

                # Phase B: Mutation calls (append, extend, update, etc.)
                elif isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
                    result = self._extract_mutation_call(stmt.value, stmt)
                    if result:
                        assignments.append(result)

            # Phase B: Detect setattr/globals in any statement context
            for stmt in ast.walk(tree):
                if isinstance(stmt, ast.Call):
                    result = self._extract_indirect_write(stmt, stmt)
                    if result and result not in assignments:
                        assignments.append(result)

        except SyntaxError:
            # Silently skip unparseable code (may be incomplete/invalid)
            pass

        return assignments

    def _extract_subscript_write(
        self, target: ast.Subscript, op: str, value: ast.AST, stmt: ast.AST
    ) -> Optional[dict]:
        """
        Extract subscript write: container[key] = value or container[key] += value.

        Phase B normalization rules:
        - container must be ast.Name (resolvable)
        - key: literal string/int → stable; Name → @name:<id>; complex → indirect=True
        - Canonical var: "container[key]"
        - Structured: container, key, target_type="subscript"

        Args:
            target: ast.Subscript node
            op: Assignment operator (=, +=, etc.)
            value: RHS value node
            stmt: Statement node for line number

        Returns:
            Assignment dict or None if not extractable
        """
        # Container must be resolvable (ast.Name or ast.Attribute)
        # Phase C Tier 2 (GAP-006): Special handling for globals()/locals()
        if isinstance(target.value, ast.Call):
            # Check for globals() or locals() calls
            if isinstance(target.value.func, ast.Name) and target.value.func.id in (
                "globals",
                "locals",
            ):
                container_name = target.value.func.id
                # Mark as indirect write to special namespace
                indirect = True
                var_name = f"{container_name}().<dynamic>"

                value_str = (
                    ast.unparse(value) if hasattr(ast, "unparse") else repr(value)
                )
                expr_str = (
                    ast.unparse(stmt)
                    if hasattr(ast, "unparse")
                    else f"{container_name}()[...] = ..."
                )
                line_offset = getattr(stmt, "lineno", 1) - 1

                return {
                    "var": var_name,
                    "op": "=",
                    "value_repr": value_str,
                    "expr": expr_str,
                    "line_offset": line_offset,
                    "target_type": "indirect",
                    "indirect": True,
                    "confidence": "guarded",
                }
            # Other call expressions - skip
            return None

        if isinstance(target.value, ast.Name):
            container_name = target.value.id
        elif isinstance(target.value, ast.Attribute):
            container_name = self._get_attribute_path(target.value)
        else:
            # Complex container (call, subscript, etc.) - skip for now
            return None

        # Normalize key according to spec
        key_str = None
        indirect = False

        if isinstance(target.slice, ast.Constant):
            # Literal string or int
            if isinstance(target.slice.value, str):
                # String key: normalize to single quotes for canonicalization
                key_str = f"'{target.slice.value}'"
            else:
                # Numeric key: no quotes
                key_str = str(target.slice.value)
        elif isinstance(target.slice, ast.Name):
            # Variable key: use @name:<id> pattern
            key_str = f"@name:{target.slice.id}"
        else:
            # Complex expression (call, binop, etc.)
            indirect = True
            key_str = None  # Unresolved

        # Canonical var format
        if key_str and not indirect:
            # Preserve quotes in canonical format: stats["trust"] → stats['trust']
            var_name = f"{container_name}[{key_str}]"
        else:
            # Indirect or unresolved
            var_name = f"{container_name}[?]"

        value_str = ast.unparse(value) if hasattr(ast, "unparse") else repr(value)
        expr_str = f"{container_name}[{key_str or '...'}] {op} {value_str}"
        line_offset = getattr(stmt, "lineno", 1) - 1

        return {
            "var": var_name,
            "op": op,
            "value_repr": value_str,
            "expr": expr_str,
            "line_offset": line_offset,
            "target_type": "subscript",
            "container": container_name,
            "key": key_str,
            "indirect": indirect,
        }

    def _extract_mutation_call(self, call: ast.Call, stmt: ast.AST) -> Optional[dict]:
        """
        Extract mutation method calls: list.append(x), dict.update(x), etc.

        Phase B patterns:
        - container.method(args) where method in (append, extend, update, add, remove, pop, clear, ...)
        - op="MUTATE", target_type="call"
        - mutation_method=method name, mutation_target=container

        Args:
            call: ast.Call node
            stmt: Statement node for line number

        Returns:
            Assignment dict or None if not a mutation
        """
        # Must be method call: obj.method(...)
        if not isinstance(call.func, ast.Attribute):
            return None

        method_name = call.func.attr
        mutation_methods = {
            "append",
            "extend",
            "insert",
            "remove",
            "pop",
            "clear",
            "sort",
            "reverse",  # list
            "update",
            "setdefault",
            "popitem",  # dict
            "add",
            "discard",
            "remove",
            "pop",
            "clear",  # set
        }

        if method_name not in mutation_methods:
            return None

        # Get container
        if isinstance(call.func.value, ast.Name):
            container_name = call.func.value.id
        elif isinstance(call.func.value, ast.Attribute):
            container_name = self._get_attribute_path(call.func.value)
        else:
            # Complex container - skip
            return None

        # Build expression
        args_str = ", ".join(
            ast.unparse(arg) if hasattr(ast, "unparse") else repr(arg)
            for arg in call.args
        )
        expr_str = f"{container_name}.{method_name}({args_str})"
        line_offset = getattr(stmt, "lineno", 1) - 1

        # Phase C Tier 2 (GAP-004a/b): Map mutation_method to op field
        # Old: op="MUTATE" (generic), target_type="call"
        # New: op=method_name (specific), target_type="mutation"
        return {
            "var": container_name,
            "op": method_name,  # Phase C: "append", "update", etc.
            "value_repr": f"{method_name}({args_str})",
            "expr": expr_str,
            "line_offset": line_offset,
            "target_type": "mutation",  # Phase C: explicit mutation type
            "mutation_method": method_name,
            "mutation_target": container_name,
            "indirect": False,
        }

    def _extract_indirect_write(self, call: ast.Call, stmt: ast.AST) -> Optional[dict]:
        """
        Extract indirect writes: setattr, globals()/locals() assignments.

        Phase B patterns:
        - setattr(obj, "attr", value) - resolved if attr is literal
        - setattr(obj, name, value) - indirect=True if attr is variable
        - globals()[key] = value - treated as subscript write on "globals"

        Args:
            call: ast.Call node
            stmt: Statement node for line number

        Returns:
            Assignment dict or None if not an indirect write
        """
        # setattr(obj, attr, value)
        if isinstance(call.func, ast.Name) and call.func.id == "setattr":
            if len(call.args) != 3:
                return None

            obj_arg, attr_arg, value_arg = call.args

            # Get object name
            if isinstance(obj_arg, ast.Name):
                obj_name = obj_arg.id
            elif isinstance(obj_arg, ast.Attribute):
                obj_name = self._get_attribute_path(obj_arg)
            else:
                # Complex object - skip
                return None

            # Check if attribute is resolvable
            indirect = True  # Phase C Tier 2 (GAP-006): setattr is ALWAYS indirect
            if isinstance(attr_arg, ast.Constant) and isinstance(attr_arg.value, str):
                attr_name = attr_arg.value
                var_name = f"{obj_name}.<dynamic>"  # Phase C: explicit dynamic marker
            else:
                # Dynamic attribute (variable key)
                var_name = f"{obj_name}.<dynamic>"
                attr_name = None

            value_str = (
                ast.unparse(value_arg) if hasattr(ast, "unparse") else repr(value_arg)
            )
            expr_str = (
                ast.unparse(call)
                if hasattr(ast, "unparse")
                else f"setattr({obj_name}, ..., {value_str})"
            )
            line_offset = getattr(stmt, "lineno", 1) - 1

            # Phase C Tier 2 (GAP-006): Classify setattr as indirect operation
            # Old: op="=", target_type="attribute", indirect=conditional, confidence="definite"
            # New: op="setattr", target_type="indirect", indirect=True, confidence="guarded"
            return {
                "var": var_name,
                "op": "setattr",  # Phase C: explicit operation
                "value_repr": value_str,
                "expr": expr_str,
                "line_offset": line_offset,
                "target_type": "indirect",  # Phase C: explicit indirect type
                "mutation_method": "setattr",
                "indirect": True,  # Phase C: always indirect
                "confidence": "guarded",  # Phase C: reduced confidence for runtime operation
            }

        # globals()[key] = value (handled in subscript writes, but detect here for completeness)
        # This will be caught by subscript write detection if in assignment context

        return None

    def _flatten_assignment_targets(self, target: ast.AST) -> List[str]:
        """
        Recursively flatten tuple/list assignment targets to variable names.

        Handles:
        - (x, y) → ["x", "y"]
        - [a, b, c] → ["a", "b", "c"]
        - (x, (y, z)) → ["x", "y", "z"]  (nested unpacking)

        Args:
            target: ast.Tuple or ast.List node

        Returns:
            List of variable names in order
        """
        names = []

        if isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                # Recursively handle nested tuples/lists
                if isinstance(element, (ast.Tuple, ast.List)):
                    names.extend(self._flatten_assignment_targets(element))
                # Extract simple name
                elif isinstance(element, ast.Name):
                    names.append(element.id)
                # Skip complex targets (subscripts, attributes in tuple)
                # e.g., x, obj.attr = ... → only extract x

        return names

    def _get_attribute_path(self, attr_node: ast.Attribute) -> str:
        """
        Recursively build full attribute path (e.g., 'persistent.flag').

        Args:
            attr_node: ast.Attribute node

        Returns:
            Full path as string (e.g., "persistent.flag", "store.score")
        """
        parts = [attr_node.attr]
        value = attr_node.value

        while isinstance(value, ast.Attribute):
            parts.insert(0, value.attr)
            value = value.value

        # Base object (usually Name)
        if isinstance(value, ast.Name):
            parts.insert(0, value.id)

        return ".".join(parts)

    def _extract_attribute_metadata(self, attr_node: ast.Attribute) -> tuple[str, str]:
        """
        Extract container and key from attribute node.

        For obj.attr -> ("obj", "attr")
        For obj.sub.attr -> ("obj.sub", "attr")
        For store.x -> ("store", "x")

        Args:
            attr_node: ast.Attribute node

        Returns:
            Tuple of (container, key)
        """
        # Key is always the final attribute
        key = attr_node.attr

        # Container is everything before the final attribute
        value = attr_node.value
        container_parts = []

        while isinstance(value, ast.Attribute):
            container_parts.insert(0, value.attr)
            value = value.value

        # Base object (usually Name)
        if isinstance(value, ast.Name):
            container_parts.insert(0, value.id)

        container = ".".join(container_parts) if container_parts else ""

        return container, key

    def _deduplicate_events(
        self, events: List[AssignmentEvent]
    ) -> List[AssignmentEvent]:
        """
        Deduplicate assignment events based on canonical identity.

        Deduplication key: (var, op, file)
        Line numbers do NOT participate in deduplication.

        When duplicates are found, keep the first occurrence.

        Args:
            events: List of assignment events (may contain duplicates)

        Returns:
            Deduplicated list of assignment events
        """
        seen = set()
        deduplicated = []

        for event in events:
            # Canonical identity: (var, op, file)
            # Note: line number explicitly excluded from dedup key
            key = (event.var, event.op, event.file)

            if key not in seen:
                seen.add(key)
                deduplicated.append(event)

        return deduplicated

    @staticmethod
    def _combine_guard(parent: Optional[str], child: str) -> str:
        """
        Combine parent and child guard conditions with AND.

        Args:
            parent: Parent guard (None if no parent)
            child: Child guard condition

        Returns:
            Combined guard string
        """
        if not parent:
            return child
        return f"({parent}) AND ({child})"


# ============================================================================
# Report Integration
# ============================================================================


def extract_assignments_for_report(
    labels: List[LabelNode], statements: Optional[dict] = None
) -> dict:
    """
    Extract assignments and format for report JSON output.

    Args:
        labels: List of LabelNode objects from analysis
        statements: Optional dict of {file_path: [Statement]} for screen action extraction (Tier 3)

    Returns:
        Dictionary for result.sae section with:
        - version: SAE schema version
        - assignments: List of assignment event dicts
        - variables: Variable inventory (index)
        - summaries: Aggregate statistics (Phase A + Phase B + Tier 3)
    """
    extractor = AssignmentExtractor()
    events = extractor.extract_from_labels(labels)

    # Tier 3: Extract screen write actions (SetVariable, ToggleVariable, SetField)
    if statements:
        events.extend(extractor.extract_from_screen_actions(statements))

    # Build variable inventory
    variables: dict = {}
    for event in events:
        if event.var not in variables:
            variables[event.var] = {
                "writes": 0,
                "files": set(),
                "labels": set(),
                "definite_writes": 0,
                "possible_writes": 0,
            }

        # Phase B: Count MUTATE operations as writes to the container
        variables[event.var]["writes"] += 1
        variables[event.var]["files"].add(event.file)
        variables[event.var]["labels"].add(event.label)

        if event.confidence == "definite":
            variables[event.var]["definite_writes"] += 1
        else:
            variables[event.var]["possible_writes"] += 1

    # Convert sets to lists for JSON serialization
    for var_info in variables.values():
        var_info["files"] = sorted(list(var_info["files"]))
        var_info["labels"] = sorted(list(var_info["labels"]))

    # Build summaries (Phase A + Phase B)
    summaries = {
        "total_assignments": len(events),
        "total_variables": len(variables),
        "definite_assignments": sum(1 for e in events if e.confidence == "definite"),
        "possible_assignments": sum(1 for e in events if e.confidence == "possible"),
        "by_op": {},
        # Phase B aggregations
        "by_target_type": {},
        "by_mutation_method": {},
    }

    # Count by operator
    for event in events:
        summaries["by_op"][event.op] = summaries["by_op"].get(event.op, 0) + 1

        # Phase B: Count by target type
        if event.target_type:
            summaries["by_target_type"][event.target_type] = (
                summaries["by_target_type"].get(event.target_type, 0) + 1
            )

        # Phase B: Count by mutation method
        if event.mutation_method:
            summaries["by_mutation_method"][event.mutation_method] = (
                summaries["by_mutation_method"].get(event.mutation_method, 0) + 1
            )

    return {
        "version": "0.1.0",
        "assignments": [e.to_dict() for e in events],
        "variables": variables,
        "summaries": summaries,
    }
