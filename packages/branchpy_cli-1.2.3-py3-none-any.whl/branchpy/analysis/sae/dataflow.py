"""Data Flow Analyzer - Lightweight constant propagation for CFG construction"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Set, Tuple


@dataclass
class DataFlowContext:
    """Track variable values within a scope (label/block)"""

    constants: Dict[str, Any] = field(default_factory=dict)  # var -> constant value
    aliases: Dict[str, str] = field(
        default_factory=dict
    )  # var -> other_var (copy propagation)
    modified: Set[str] = field(default_factory=set)  # Variables that have been modified

    def set_constant(self, var_name: str, value: Any) -> None:
        """Record a constant assignment"""
        self.constants[var_name] = value
        self.modified.add(var_name)
        # Remove from aliases if it was aliased
        if var_name in self.aliases:
            del self.aliases[var_name]

    def set_alias(self, var_name: str, alias_to: str) -> None:
        """Record a copy assignment (x = y)"""
        self.aliases[var_name] = alias_to
        self.modified.add(var_name)
        # Remove from constants if it was constant
        if var_name in self.constants:
            del self.constants[var_name]

    def resolve(self, var_name: str) -> Tuple[str, Any]:
        """
        Resolve a variable to its value.

        Returns:
            ('constant', value) if var is constant
            ('alias', other_var) if var is an alias
            ('unknown', None) if var is unknown
        """
        # Check constants first
        if var_name in self.constants:
            return ("constant", self.constants[var_name])

        # Check aliases
        if var_name in self.aliases:
            # Follow alias chain (max depth 5 to avoid loops)
            visited = set()
            current = var_name
            for _ in range(5):
                if current in visited:
                    break  # Circular reference
                visited.add(current)

                if current in self.aliases:
                    current = self.aliases[current]
                else:
                    # End of chain - check if it's a constant
                    if current in self.constants:
                        return ("constant", self.constants[current])
                    return ("alias", current)

        return ("unknown", None)

    def invalidate(self, var_name: str) -> None:
        """Mark a variable as modified/unknown"""
        if var_name in self.constants:
            del self.constants[var_name]
        if var_name in self.aliases:
            del self.aliases[var_name]
        self.modified.add(var_name)

    def merge(self, other: "DataFlowContext") -> "DataFlowContext":
        """
        Merge two contexts (for control flow joins).
        Only keep constants that have the same value in both contexts.
        """
        merged = DataFlowContext()

        # Keep constants that match in both
        for var, value in self.constants.items():
            if var in other.constants and other.constants[var] == value:
                merged.constants[var] = value

        # Aliases are harder to merge - skip for now (too conservative)
        # In practice, this means we lose alias info at control flow joins

        merged.modified = self.modified | other.modified

        return merged

    def copy(self) -> "DataFlowContext":
        """Create a deep copy of this context"""
        return DataFlowContext(
            constants=self.constants.copy(),
            aliases=self.aliases.copy(),
            modified=self.modified.copy(),
        )

    def evaluate(self, expr_str: str) -> Tuple[str, Any]:
        """
        Evaluate an expression to get its possible values.

        Returns:
            ('literal', value) - Single constant value
            ('set', {val1, val2, ...}) - Multiple possible values
            ('unknown', None) - Cannot determine
        """
        import ast

        # Handle string literals directly
        if expr_str.startswith('"') or expr_str.startswith("'"):
            try:
                # Try to parse as Python literal
                value = ast.literal_eval(expr_str)
                return ("literal", value)
            except Exception:
                return ("unknown", None)

        # Try to parse as Python expression
        try:
            tree = ast.parse(expr_str, mode="eval")
            return self._evaluate_ast(tree.body)
        except Exception:
            # If can't parse, try as variable name
            if expr_str.isidentifier():
                kind, value = self.resolve(expr_str)
                if kind == "constant":
                    return ("literal", value)
            return ("unknown", None)

    def _evaluate_ast(self, node: Any) -> Tuple[str, Any]:
        """Evaluate an AST node"""
        import ast

        # Constant literals
        if isinstance(node, ast.Constant):
            return ("literal", node.value)

        # Variable reference
        if isinstance(node, ast.Name):
            kind, value = self.resolve(node.id)
            if kind == "constant":
                return ("literal", value)
            return ("unknown", None)

        # Binary operations (string concat)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left_kind, left_val = self._evaluate_ast(node.left)
            right_kind, right_val = self._evaluate_ast(node.right)

            if left_kind == "literal" and right_kind == "literal":
                if isinstance(left_val, str) and isinstance(right_val, str):
                    return ("literal", left_val + right_val)

        # Conditional expression (ternary)
        if isinstance(node, ast.IfExp):
            # Can't evaluate condition, so return both branches
            true_kind, true_val = self._evaluate_ast(node.body)
            false_kind, false_val = self._evaluate_ast(node.orelse)

            values = set()
            if true_kind == "literal":
                values.add(true_val)
            if false_kind == "literal":
                values.add(false_val)

            if values:
                return ("set", values)

        return ("unknown", None)


class SimpleDataFlow:
    """Simple intra-procedural data-flow analysis"""

    def __init__(self):
        self.label_contexts: Dict[str, DataFlowContext] = (
            {}
        )  # label_name -> context at entry

    def analyze_python_assignment(self, code: str, context: DataFlowContext) -> None:
        """
        Analyze a Python assignment and update context.

        Handles:
        - x = "literal" -> constant
        - x = y -> alias
        - x = expr -> invalidate
        """
        import ast

        try:
            tree = ast.parse(code)

            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id

                            # Check if RHS is a constant
                            if isinstance(node.value, ast.Constant):
                                context.set_constant(var_name, node.value.value)

                            # Check if RHS is another variable (copy)
                            elif isinstance(node.value, ast.Name):
                                context.set_alias(var_name, node.value.id)

                            # Check for simple string operations
                            elif isinstance(node.value, ast.BinOp):
                                resolved = self._try_resolve_binop(node.value, context)
                                if resolved is not None:
                                    context.set_constant(var_name, resolved)
                                else:
                                    context.invalidate(var_name)

                            # Complex expression - invalidate
                            else:
                                context.invalidate(var_name)

        except SyntaxError:
            # If we can't parse, don't crash - just skip analysis
            pass

    def _try_resolve_binop(self, node: Any, context: DataFlowContext) -> Optional[Any]:
        """Try to resolve a binary operation to a constant"""
        import ast

        if not isinstance(node, ast.BinOp):
            return None

        # Only handle string concatenation for now
        if not isinstance(node.op, ast.Add):
            return None

        # Resolve left side
        left = None
        if isinstance(node.left, ast.Constant):
            left = node.left.value
        elif isinstance(node.left, ast.Name):
            kind, val = context.resolve(node.left.id)
            if kind == "constant":
                left = val

        # Resolve right side
        right = None
        if isinstance(node.right, ast.Constant):
            right = node.right.value
        elif isinstance(node.right, ast.Name):
            kind, val = context.resolve(node.right.id)
            if kind == "constant":
                right = val

        # If both are strings, concatenate
        if isinstance(left, str) and isinstance(right, str):
            return left + right

        return None

    def resolve_variable(
        self, var_name: str, context: DataFlowContext
    ) -> Tuple[str, Any]:
        """
        Resolve a variable using the data-flow context.

        Returns:
            ('constant', value) if resolved to constant
            ('unknown', None) otherwise
        """
        kind, value = context.resolve(var_name)
        return (kind, value)

    def get_label_context(self, label_name: str) -> DataFlowContext:
        """Get or create the data-flow context for a label"""
        if label_name not in self.label_contexts:
            self.label_contexts[label_name] = DataFlowContext()
        return self.label_contexts[label_name]
