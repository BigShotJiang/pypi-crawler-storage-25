"""
Unified report exporter - combines CFG, validation, and summary data.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Optional

from branchpy.analysis.sae.cfg_builder import ControlFlowGraph, NodeKind
from branchpy.analysis.sae.validators.tier1 import ValidationIssue


class UnifiedReportExporter:
    """
    Export comprehensive analysis report.

    Combines:
    - Summary statistics (labels, edges, issues, reading time)
    - Validation issues
    - Phase metrics (dialogue, variables, etc.)
    - Reference to flowgraph (if exported separately)
    """

    def __init__(
        self,
        cfg: ControlFlowGraph,
        issues: list[ValidationIssue],
        project_root: str,
        flowgraph_path: Optional[str] = None,
        dialogue_metrics: Optional[dict[str, Any]] = None,
        variable_metrics: Optional[dict[str, Any]] = None,
        phase8_findings: Optional[list] = None,
        locale_metrics: Optional[dict[str, Any]] = None,
        custom_violations: Optional[list] = None,
        image_validation: Optional[dict[str, Any]] = None,
    ):
        """
        Initialize unified report exporter.

        Args:
            cfg: Control flow graph
            issues: List of validation issues
            project_root: Absolute path to project root
            flowgraph_path: Optional path to flowgraph.json (relative to report)
            dialogue_metrics: Optional Phase 3 dialogue metrics
            variable_metrics: Optional Phase 4 variable metrics
            phase8_findings: Optional Phase 8 custom rule findings
            locale_metrics: Optional Phase 7 localization metrics (v0.7.7)
            custom_violations: Optional custom rule violations (v0.7.8)
            image_validation: Optional image validation results
        """
        self.cfg = cfg
        self.issues = issues
        self.project_root = Path(project_root)
        self.flowgraph_path = flowgraph_path
        self.dialogue_metrics = dialogue_metrics
        self.variable_metrics = variable_metrics
        self.phase8_findings = phase8_findings or []
        self.locale_metrics = locale_metrics
        self.custom_violations = custom_violations or []
        self.image_validation = image_validation

    def export(self, output_path: Optional[str] = None) -> dict[str, Any]:
        """
        Export unified report.

        Args:
            output_path: Optional file path to write JSON (if None, returns dict only)

        Returns:
            Report data as dictionary
        """
        # Calculate summary statistics
        error_count = sum(1 for i in self.issues if i.severity.value == "error")
        warning_count = sum(1 for i in self.issues if i.severity.value == "warning")
        info_count = sum(1 for i in self.issues if i.severity.value == "info")

        # Calculate total reading time (normal pace)
        total_reading_time = 0.0
        for node in self.cfg.nodes.values():
            if node.reading_time:
                total_reading_time += node.reading_time.get("normal", 0.0)

        # Build report structure
        report = {
            "version": "0.7.4-alpha",
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "project_root": str(self.project_root),
            "summary": {
                "labels": len(
                    [n for n in self.cfg.nodes.values() if n.kind == NodeKind.LABEL]
                ),
                "nodes": len(self.cfg.nodes),
                "edges": len(self.cfg.edges),
                "errors": error_count,
                "warnings": warning_count,
                "info": info_count,
                "reading_time_total": {
                    "normal": round(total_reading_time, 1),
                },
            },
            "validation": [
                {
                    "rule_id": issue.rule_id,
                    "severity": issue.severity.value,
                    "message": issue.message,
                    "file": issue.file,
                    "line": issue.line,
                    **({"extra": issue.extra} if issue.extra else {}),
                }
                for issue in self.issues
            ],
        }

        # Add dialogue metrics if available (Phase 3)
        if self.dialogue_metrics:
            report["summary"]["dialogue_metrics"] = (
                self.dialogue_metrics.to_dict()
                if hasattr(self.dialogue_metrics, "to_dict")
                else self.dialogue_metrics
            )

        # Add variable metrics if available (Phase 4)
        if self.variable_metrics:
            report["summary"]["variable_metrics"] = (
                self.variable_metrics.to_dict()
                if hasattr(self.variable_metrics, "to_dict")
                else self.variable_metrics
            )

        # Add localization metrics if available (Phase 7 - v0.7.7)
        if self.locale_metrics:
            report["localization"] = {
                "enabled": True,
                "total_languages": self.locale_metrics.get("total_languages", 0),
                "total_source_strings": self.locale_metrics.get(
                    "total_source_strings", 0
                ),
                "avg_coverage_pct": self.locale_metrics.get("avg_coverage_pct", 0.0),
                "coverage_by_language": self.locale_metrics.get(
                    "coverage_by_language", {}
                ),
                "issues": {
                    "missing": self.locale_metrics.get("missing_count", 0),
                    "orphaned": self.locale_metrics.get("orphaned_count", 0),
                    "mismatch": self.locale_metrics.get("mismatch_count", 0),
                },
            }

        # Add Phase 8 custom rule findings (if any)
        if self.phase8_findings:
            from branchpy.analysis.sae.finding_adapter import finding_to_dict

            report["phase8_findings"] = [
                finding_to_dict(f) for f in self.phase8_findings
            ]

        # Add custom rule violations (v0.7.8)
        if self.custom_violations:
            report["customRules"] = {
                "enabled": True,
                "total_violations": len(self.custom_violations),
                "by_severity": self._count_violations_by_severity(
                    self.custom_violations
                ),
                "by_category": self._count_violations_by_category(
                    self.custom_violations
                ),
                "violations": [
                    {
                        "rule_id": v.rule_id,
                        "severity": v.severity.value,
                        "message": v.message,
                        "category": v.category,
                        "line": v.line_number,
                        **({"matched_text": v.matched_text} if v.matched_text else {}),
                    }
                    for v in self.custom_violations
                ],
            }

        # Add image validation results if available
        if self.image_validation:
            report["image_validation"] = self.image_validation

        # Add flowgraph reference if provided
        if self.flowgraph_path:
            report["flowgraph"] = self.flowgraph_path

        # Write to file if path provided
        if output_path:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            with output_file.open("w", encoding="utf-8") as f:
                json.dump(report, f, indent=2, ensure_ascii=False)

        return report

    def _count_violations_by_severity(self, violations: list) -> dict[str, int]:
        """Count violations grouped by severity level."""
        from branchpy.analysis.sae.custom_rule_loader import RuleSeverity

        counts = {severity.value: 0 for severity in RuleSeverity}
        for v in violations:
            counts[v.severity.value] = counts.get(v.severity.value, 0) + 1
        return counts

    def _count_violations_by_category(self, violations: list) -> dict[str, int]:
        """Count violations grouped by category."""
        counts = {}
        for v in violations:
            counts[v.category] = counts.get(v.category, 0) + 1
        return counts

    @staticmethod
    def validate_schema(data: dict[str, Any]) -> bool:
        """
        Basic schema validation for unified report.

        Args:
            data: Report data to validate

        Returns:
            True if valid, raises ValueError if invalid
        """
        required = ["version", "generated_at", "project_root", "summary", "validation"]
        for field in required:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")

        # Validate summary fields
        summary = data["summary"]
        summary_fields = ["labels", "nodes", "edges", "errors", "warnings", "info"]
        for field in summary_fields:
            if field not in summary:
                raise ValueError(f"Missing summary field: {field}")

        # Validate validation issues structure
        for issue in data["validation"]:
            required_issue = ["rule_id", "severity", "message", "file", "line"]
            for field in required_issue:
                if field not in issue:
                    raise ValueError(f"Missing issue field: {field}")

        return True
