"""Flowgraph Exporter - Export CFG to stable JSON format"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy.contract import VERSION as BRANCHPY_VERSION


class FlowgraphExporter:
    """Export CFG to flowgraph.json format"""

    VERSION = BRANCHPY_VERSION  # Imported from branchpy.contract

    def __init__(self, cfg: Any, project_root: str | Path):
        """
        Args:
            cfg: ControlFlowGraph from CFGBuilder
            project_root: Project root directory path
        """
        self.cfg = cfg
        self.project_root = Path(project_root)

    def export(
        self,
        output_path: Optional[str | Path] = None,
        analysis_duration_ms: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Export flowgraph to JSON.

        Args:
            output_path: Output file path (optional, returns dict if None)
            analysis_duration_ms: Analysis duration in milliseconds

        Returns:
            Flowgraph dictionary
        """
        flowgraph = {
            "version": self.VERSION,
            "engine": "renpy",
            "nodes": [node.to_dict() for node in self.cfg.nodes.values()],
            "edges": [edge.to_dict() for edge in self.cfg.edges],
            "meta": {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "project_root": str(self.project_root),
                "generator": f"BranchPy SAE {self.VERSION}",
            },
        }

        if analysis_duration_ms is not None:
            flowgraph["meta"]["analysis_duration_ms"] = analysis_duration_ms

        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(flowgraph, f, indent=2, ensure_ascii=False)

        return flowgraph

    @staticmethod
    def validate_schema(flowgraph: Dict[str, Any]) -> bool:
        """
        Validate flowgraph against schema (basic checks).

        Args:
            flowgraph: Flowgraph dictionary

        Returns:
            True if valid, False otherwise
        """
        required_keys = {"version", "engine", "nodes", "edges", "meta"}
        if not all(k in flowgraph for k in required_keys):
            return False

        if flowgraph["engine"] != "renpy":
            return False

        if not isinstance(flowgraph["nodes"], list):
            return False

        if not isinstance(flowgraph["edges"], list):
            return False

        # Validate node structure
        for node in flowgraph["nodes"]:
            if not all(k in node for k in ["id", "kind", "file", "line"]):
                return False

        # Validate edge structure
        for edge in flowgraph["edges"]:
            if not all(k in edge for k in ["from", "to", "type"]):
                return False

        return True
