"""SAE Indexer - Extract labels, jumps, assets, and variables from Ren'Py projects"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class IndexEntry:
    """Represents a single indexed item (label, asset, variable, etc.)"""

    kind: str  # "label", "image", "audio", "variable"
    name: str
    file: str  # Relative to project root
    line: int
    extra: Dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default=None):
        """Dictionary-like access for compatibility"""
        if key == "kind":
            return self.kind
        elif key == "name":
            return self.name
        elif key == "file":
            return self.file
        elif key == "line":
            return self.line
        elif key == "extra":
            return self.extra
        else:
            return default


@dataclass
class ProjectIndex:
    """Complete index of project elements"""

    labels: Dict[str, IndexEntry] = field(default_factory=dict)
    jumps: List[IndexEntry] = field(default_factory=list)
    calls: List[IndexEntry] = field(default_factory=list)
    dynamic_calls: List[IndexEntry] = field(
        default_factory=list
    )  # D11: call expression <var>
    images: Dict[str, IndexEntry] = field(default_factory=dict)
    audio: Dict[str, IndexEntry] = field(default_factory=dict)
    variables: Dict[str, List[IndexEntry]] = field(default_factory=dict)
    variable_uses: Dict[str, List[IndexEntry]] = field(
        default_factory=dict
    )  # Phase 4: track reads
    characters: Dict[str, List[IndexEntry]] = field(
        default_factory=dict
    )  # Phase 3: track ALL definitions including duplicates
    dialogues: List[IndexEntry] = field(default_factory=list)  # Phase 3
    files: List[str] = field(default_factory=list)
    statements: Dict[str, List[Any]] = field(
        default_factory=dict
    )  # rc.1.4: statement-level data for execution containers
    choice_points: List[Dict[str, Any]] = field(
        default_factory=list
    )  # Phase 3B.1: menu choice points for automated runner
    project_path: str = ""  # Added for diagnostics

    def get(self, key: str, default=None):
        """Dictionary-like access for compatibility with engine"""
        if key == "files":
            # Return dict with files as keys for compatibility
            return {f: {} for f in self.files}
        elif key == "labels":
            return self.labels
        elif key == "jumps":
            return self.jumps
        elif key == "calls":
            return self.calls
        elif key == "dynamic_calls":
            return self.dynamic_calls
        elif key == "images":
            return self.images
        elif key == "audio":
            return self.audio
        elif key == "variables":
            return self.variables
        elif key == "variable_uses":
            return self.variable_uses
        elif key == "characters":
            return self.characters
        elif key == "dialogues":
            return self.dialogues
        elif key == "statements":
            return self.statements
        elif key == "choice_points":
            return self.choice_points
        elif key == "project_path":
            return self.project_path
        else:
            return default

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "labels": {
                k: {"file": v.file, "line": v.line, "extra": v.extra}
                for k, v in self.labels.items()
            },
            "jumps": [
                {"name": j.name, "file": j.file, "line": j.line} for j in self.jumps
            ],
            "calls": [
                {"name": c.name, "file": c.file, "line": c.line} for c in self.calls
            ],
            "dynamic_calls": [
                {"name": c.name, "file": c.file, "line": c.line}
                for c in self.dynamic_calls
            ],
            "images": {
                k: {"file": v.file, "line": v.line} for k, v in self.images.items()
            },
            "audio": {
                k: {"file": v.file, "line": v.line} for k, v in self.audio.items()
            },
            "variables": {
                k: [{"file": v.file, "line": v.line} for v in vals]
                for k, vals in self.variables.items()
            },
            "variable_uses": {
                k: [{"file": v.file, "line": v.line, "extra": v.extra} for v in vals]
                for k, vals in self.variable_uses.items()
            },
            "characters": {
                k: [{"file": v.file, "line": v.line, "extra": v.extra} for v in vals]
                for k, vals in self.characters.items()
            },
            "dialogues": [
                {"file": d.file, "line": d.line, "extra": d.extra}
                for d in self.dialogues
            ],
            "files": {
                f: {} for f in self.files
            },  # Convert list to dict for compatibility
            # rc.1.4: Convert statements to JSON-serializable dicts
            "statements": {
                file_path: [
                    stmt.to_dict() if hasattr(stmt, "to_dict") else stmt
                    for stmt in stmts
                ]
                for file_path, stmts in self.statements.items()
            },
            "choice_points": self.choice_points,  # Phase 3B.1: already in dict format
            "project_path": self.project_path,
        }


class Indexer:
    """Build project index from Ren'Py source files"""

    def __init__(self, project_root: str | Path):
        self.project_root = Path(project_root)
        self.game_dir = self.project_root / "game"

    def build_index(self) -> ProjectIndex:
        """
        Scan project and build complete index.

        Returns:
            ProjectIndex with all labels, jumps, assets, variables
        """
        index = ProjectIndex()
        index.project_path = str(self.project_root)

        # Scan all .rpy files
        rpy_files = self._scan_files()
        index.files = [str(f.relative_to(self.project_root)) for f in rpy_files]

        # Parse each file and extract elements
        for file_path in rpy_files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                rel_path = str(file_path.relative_to(self.project_root))

                # Extract labels
                for label_name, line_num in self._extract_labels(content):
                    index.labels[label_name] = IndexEntry(
                        kind="label", name=label_name, file=rel_path, line=line_num
                    )

                # Extract jumps and calls
                for (
                    jump_target,
                    line_num,
                    conditional,
                    condition_kind,
                ) in self._extract_jumps(content):
                    index.jumps.append(
                        IndexEntry(
                            kind="jump",
                            name=jump_target,
                            file=rel_path,
                            line=line_num,
                            extra={
                                "conditional": conditional,
                                "condition_kind": condition_kind,
                            },
                        )
                    )

                for call_target, line_num in self._extract_calls(content):
                    index.calls.append(
                        IndexEntry(
                            kind="call", name=call_target, file=rel_path, line=line_num
                        )
                    )

                # D11: extract dynamic call sites (call expression <var>)
                for line_num in self._extract_dynamic_calls(content):
                    index.dynamic_calls.append(
                        IndexEntry(
                            kind="dynamic_call", name="?", file=rel_path, line=line_num
                        )
                    )

                # Extract assets (images and audio)
                for image_name, line_num in self._extract_images(content):
                    if image_name not in index.images:
                        index.images[image_name] = IndexEntry(
                            kind="image", name=image_name, file=rel_path, line=line_num
                        )

                for audio_name, line_num in self._extract_audio(content):
                    if audio_name not in index.audio:
                        index.audio[audio_name] = IndexEntry(
                            kind="audio", name=audio_name, file=rel_path, line=line_num
                        )

                # Extract variable definitions
                for var_name, line_num in self._extract_variables(content):
                    if var_name not in index.variables:
                        index.variables[var_name] = []
                    index.variables[var_name].append(
                        IndexEntry(
                            kind="variable", name=var_name, file=rel_path, line=line_num
                        )
                    )

                # Phase 3: Extract character definitions (track ALL including duplicates)
                for char_name, line_num, extra in self._extract_characters(content):
                    if char_name not in index.characters:
                        index.characters[char_name] = []
                    index.characters[char_name].append(
                        IndexEntry(
                            kind="character",
                            name=char_name,
                            file=rel_path,
                            line=line_num,
                            extra=extra,
                        )
                    )

                # Phase 3: Extract dialogue lines
                for speaker, text, line_num in self._extract_dialogues(content):
                    index.dialogues.append(
                        IndexEntry(
                            kind="dialogue",
                            name=speaker or "narrator",
                            file=rel_path,
                            line=line_num,
                            extra={"speaker": speaker, "text": text},
                        )
                    )

                # Phase 4: Extract variable uses (reads/references)
                self._extract_variable_uses(content, rel_path, index)

                # rc.1.4: Extract full statements (for execution containers)
                try:
                    from branchpy.analysis.sae.statement_extractor import (
                        StatementExtractor,
                    )

                    extractor = StatementExtractor()
                    statements = extractor.extract_statements(content, rel_path)
                    index.statements[rel_path] = statements
                except Exception as stmt_error:
                    # Non-fatal - statement extraction is for advanced features
                    import sys

                    print(
                        f"[DEBUG] Statement extraction failed for {rel_path}: {stmt_error}",
                        file=sys.stderr,
                    )

                # Phase 3B.1: Extract menu choice points (for automated runner)
                choice_points = self._extract_menu_choice_points(content, rel_path)
                index.choice_points.extend(choice_points)

            except Exception:
                # Keep robust - don't crash on bad files
                continue

        return index

    def _scan_files(self) -> List[Path]:
        """Recursively scan game/ directory for .rpy files"""
        if not self.game_dir.exists():
            return []
        return sorted(self.game_dir.rglob("*.rpy"))

    def _extract_labels(self, content: str) -> List[tuple[str, int]]:
        """Extract label definitions from file content"""
        import re

        # Allow optional whitespace and comments after colon
        label_re = re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:", re.MULTILINE)
        results = []
        for match in label_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            results.append((match.group(1), line_num))
        return results

    def _extract_jumps(
        self, content: str
    ) -> List[tuple[str, int, bool, Optional[str]]]:
        """Extract jump statements from file content with conditional context tracking"""
        import re

        # Regex patterns
        block_re = re.compile(
            r"^(\s*)(if|elif|else|while|for|try|except|finally)\b.*:\s*$", re.MULTILINE
        )
        jump_re = re.compile(r"^(\s*)jump\s+([A-Za-z_]\w*)(?:\s|#|$)", re.MULTILINE)

        # Track active conditional blocks by indent level
        block_stack: list[tuple[int, str]] = []  # [(indent, kind)]

        # Parse line by line to track indentation context
        lines = content.split("\n")
        results = []

        for line_num, line in enumerate(lines, start=1):
            if not line.strip():  # Skip empty lines
                continue

            # Calculate indentation
            indent = len(line) - len(line.lstrip(" \t"))

            # Pop blocks when indent decreases
            while block_stack and indent <= block_stack[-1][0]:
                block_stack.pop()

            # Check for block opener
            block_match = block_re.match(line)
            if block_match:
                block_indent = len(block_match.group(1))
                block_kind = block_match.group(2)
                block_stack.append((block_indent, block_kind))
                continue

            # Check for jump statement
            jump_match = jump_re.match(line)
            if jump_match:
                target = jump_match.group(2)
                conditional = bool(block_stack)
                results.append(
                    (
                        target,
                        line_num,
                        conditional,
                        block_stack[-1][1] if block_stack else None,
                    )
                )

        return results

    def _extract_calls(self, content: str) -> List[tuple[str, int]]:
        """Extract call statements from file content (excludes 'call screen')"""
        import re

        # Match: call label_name (but not "call screen screen_name" or "call expression")
        # Allow optional whitespace and comments after label name
        call_re = re.compile(
            r"^\s*call\s+(?!screen\s)(?!expression\s)([A-Za-z_]\w*)(?:\s|#|$)",
            re.MULTILINE,
        )
        results = []
        for match in call_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            results.append((match.group(1), line_num))
        return results

    def _extract_dynamic_calls(self, content: str) -> List[int]:
        """Extract 'call expression ...' dynamic call sites (no literal target). D11."""
        import re

        dyn_re = re.compile(r"^\s*call\s+expression\s+", re.MULTILINE)
        results = []
        for match in dyn_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            results.append(line_num)
        return results

    def _extract_images(self, content: str) -> List[tuple[str, int]]:
        """Extract image references (show, scene, image statements)"""
        import re

        # Match: show/scene image_name (can be multi-word: "bg office_day")
        # Capture everything up to 'at', 'with', 'as', 'onlayer', or end of line/comment
        show_re = re.compile(
            r"^\s*(?:show|scene)\s+([A-Za-z_][\w\s]+?)(?:\s+(?:at|with|as|onlayer|behind)\s|\s*(?:#|$))",
            re.MULTILINE,
        )
        # Match: image definitions - can also be multi-word
        image_re = re.compile(
            r"^\s*image\s+([A-Za-z_][\w\s]+?)(?:\s*[=:]|\s*$)", re.MULTILINE
        )
        results = []

        for match in show_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            # Clean up the captured name (remove trailing whitespace)
            image_name = match.group(1).strip()
            results.append((image_name, line_num))

        for match in image_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            image_name = match.group(1).strip()
            results.append((image_name, line_num))

        return results

    def _extract_audio(self, content: str) -> List[tuple[str, int]]:
        """Extract audio references (play, voice statements)"""
        import re

        # Match: play music "file.ogg", play sound "file.mp3", voice "file.ogg"
        play_re = re.compile(
            r'^\s*play\s+(?:music|sound|audio)\s+["\']([^"\']+)["\']', re.MULTILINE
        )
        voice_re = re.compile(r'^\s*voice\s+["\']([^"\']+)["\']', re.MULTILINE)
        results = []

        for match in play_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            results.append((match.group(1), line_num))

        for match in voice_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            results.append((match.group(1), line_num))

        return results

    def _extract_variables(self, content: str) -> List[tuple[str, int]]:
        """Extract variable definitions (default, define, $, python: blocks)"""
        import ast
        import re

        results = []

        # 1) Extract default/define statements
        var_re = re.compile(
            r"^\s*(?:default|define)\s+([A-Za-z_][\w.]*)\s*=\s*(.*)$", re.MULTILINE
        )
        for match in var_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            var_name = match.group(1)
            expr = match.group(2).strip()
            results.append((var_name, line_num, expr))

        # 2) Extract $ variable assignments
        dollar_re = re.compile(
            r"^\s*\$\s+([A-Za-z_][\w.]*)\s*([+\-*/%])?=\s*(.*)$", re.MULTILINE
        )
        for match in dollar_re.finditer(content):
            line_num = content[: match.start()].count("\n") + 1
            var_name = match.group(1)
            operator = match.group(2)  # +, -, etc. if compound assignment
            expr = match.group(3).strip()
            results.append((var_name, line_num, expr))

        # 3) Extract variables from python: blocks
        python_blocks = self._extract_python_blocks(content)
        for block_content, block_start_line in python_blocks:
            try:
                tree = ast.parse(block_content)
                for node in ast.walk(tree):
                    if isinstance(node, ast.Assign):
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                # Adjust line number relative to block start
                                line_num = block_start_line + (node.lineno - 1)
                                var_name = target.id
                                # Get expression as string (simplified)
                                expr = (
                                    ast.unparse(node.value)
                                    if hasattr(ast, "unparse")
                                    else ""
                                )
                                results.append((var_name, line_num, expr))
                            elif isinstance(target, ast.Attribute):
                                # Handle persistent.x, etc.
                                line_num = block_start_line + (node.lineno - 1)
                                var_name = (
                                    ast.unparse(target)
                                    if hasattr(ast, "unparse")
                                    else str(target)
                                )
                                expr = (
                                    ast.unparse(node.value)
                                    if hasattr(ast, "unparse")
                                    else ""
                                )
                                results.append((var_name, line_num, expr))
            except SyntaxError:
                # Skip blocks with syntax errors
                continue

        # Convert to old format for compatibility (name, line) - store expr in extra
        formatted_results = []
        for var_name, line_num, expr in results:
            formatted_results.append((var_name, line_num))

        return formatted_results

    def _extract_python_blocks(self, content: str) -> List[Tuple[str, int]]:
        """Extract python: blocks and their starting line numbers.

        Returns:
            List of (block_content, start_line_number) tuples
        """
        import re

        blocks = []
        lines = content.split("\n")
        in_python_block = False
        block_lines = []
        block_start = 0
        base_indent = 0

        for i, line in enumerate(lines):
            # Check for python: statement
            if re.match(r"^\s*python:", line):
                in_python_block = True
                block_lines = []
                block_start = i + 1  # Line numbers are 1-indexed
                # Calculate base indentation
                base_indent = len(line) - len(line.lstrip())
                continue

            if in_python_block:
                # Check if we've exited the block (dedent or empty line at base level)
                current_indent = len(line) - len(line.lstrip())

                # End block if we hit a line at or before the base indent (unless it's blank)
                if line.strip() and current_indent <= base_indent:
                    # Block ended
                    in_python_block = False
                    if block_lines:
                        blocks.append(("\n".join(block_lines), block_start))
                    block_lines = []
                else:
                    # Continue collecting block content
                    # Remove base indentation to make valid Python
                    if line.strip():
                        dedented = (
                            line[base_indent + 4 :]
                            if len(line) > base_indent + 4
                            else line.strip()
                        )
                        block_lines.append(dedented)
                    else:
                        block_lines.append("")

        # Handle unclosed block at end of file
        if in_python_block and block_lines:
            blocks.append(("\n".join(block_lines), block_start))

        return blocks

    def _extract_characters(
        self, content: str
    ) -> List[tuple[str, int, Dict[str, Any]]]:
        """
        Extract character definitions (define character_name = Character(...))

        Returns:
            List of (character_name, line_number, extra_data) tuples
        """
        import re

        # Match: define character_name = Character(...)
        # Capture optional parameters like voice_tag and image
        char_re = re.compile(
            r"^\s*define\s+([A-Za-z_]\w*)\s*=\s*Character\s*\((.*?)\)",
            re.MULTILINE | re.DOTALL,
        )

        results = []
        for match in char_re.finditer(content):
            char_name = match.group(1)
            params = match.group(2)
            line_num = content[: match.start()].count("\n") + 1

            # Parse common parameters from the Character() call
            extra: Dict[str, Any] = {}

            # Extract voice_tag parameter
            voice_match = re.search(r'voice_tag\s*=\s*["\']([^"\']+)["\']', params)
            if voice_match:
                extra["voice_tag"] = voice_match.group(1)

            # Extract image parameter
            image_match = re.search(r'image\s*=\s*["\']([^"\']+)["\']', params)
            if image_match:
                extra["image_tag"] = image_match.group(1)

            # Extract name parameter (display name)
            name_match = re.search(r'^["\']([^"\']+)["\']', params.strip())
            if name_match:
                extra["display_name"] = name_match.group(1)

            results.append((char_name, line_num, extra))

        return results

    def _extract_dialogues(self, content: str) -> List[tuple[str | None, str, int]]:
        """
        Extract dialogue lines (say statements: 'character "text"' or '"text"')

        Returns:
            List of (speaker, text, line_number) tuples
            speaker is None for narrator dialogue
        """
        import re

        results = []
        lines = content.split("\n")

        # Track if we're inside a screen/python/init block to avoid false positives
        in_block = False
        block_base_indent = 0

        for line_idx, line in enumerate(lines):
            line_num = line_idx + 1
            stripped = line.strip()

            # Skip empty lines and comments
            if not stripped or stripped.startswith("#"):
                continue

            # Calculate indentation
            indent = len(line) - len(line.lstrip())

            # Check if we're entering a block that should be skipped
            if any(
                stripped.startswith(kw)
                for kw in ["screen ", "python:", "init python:", "init ", "style "]
            ):
                in_block = True
                block_base_indent = indent
                continue

            # Check if we're exiting the block (dedent back to or before block level)
            if in_block and indent <= block_base_indent and stripped:
                in_block = False

            # Skip lines inside blocks
            if in_block:
                continue

            # Skip obvious non-dialogue statements
            if any(
                stripped.startswith(kw)
                for kw in [
                    "label",
                    "jump",
                    "call",
                    "return",
                    "if",
                    "elif",
                    "else",
                    "while",
                    "for",
                    "define",
                    "default",
                    "image",
                    "scene",
                    "show",
                    "hide",
                    "with",
                    "menu",
                    "play",
                    "stop",
                    "voice",
                    "transform",
                    "$",
                ]
            ):
                continue

            # Match character dialogue: character_name "dialogue text"
            # Pattern: word followed by quoted string (including empty strings)
            char_dialogue = re.match(
                r'^([A-Za-z_]\w*)\s+(["\'])(.*?)\2\s*$', stripped, re.DOTALL
            )

            if char_dialogue:
                speaker = char_dialogue.group(1)
                text = char_dialogue.group(3)
                results.append((speaker, text, line_num))
                continue

            # Match narrator dialogue: "dialogue text" (no character prefix, including empty)
            narrator_dialogue = re.match(r'^(["\'])(.*?)\1\s*$', stripped, re.DOTALL)

            if narrator_dialogue:
                text = narrator_dialogue.group(2)
                results.append((None, text, line_num))
                continue

        return results

    def _extract_variable_uses(
        self, content: str, rel_path: str, index: ProjectIndex
    ) -> None:
        """Extract all variable uses (reads/references) from file content (Phase 4)"""
        from branchpy.analysis.sae.variable_usage_extractor import (
            VariableUsageExtractor,
        )

        extractor = VariableUsageExtractor()
        references = extractor.extract_from_file(content)

        for ref in references:
            var_name = ref.name

            if var_name not in index.variable_uses:
                index.variable_uses[var_name] = []

            index.variable_uses[var_name].append(
                IndexEntry(
                    kind="variable_use",
                    name=var_name,
                    file=rel_path,
                    line=ref.line,
                    extra={"context": ref.context, "expression": ref.expression},
                )
            )

    def _extract_menu_choice_points(
        self, content: str, rel_path: str
    ) -> List[Dict[str, Any]]:
        """
        Extract menu choice points from file content (Phase 3B.1 + 3B.3).

        Now supports syntactic nesting (menu inside choice block).

        Returns list of choice point dicts with:
        - choice_point_id: Stable hash-based ID
        - location: {file, line, label}
        - kind: "menu_ast"
        - options: [{index, text, targets, condition_raw}]
        - parent_choice_point_id: (optional) ID of parent menu if syntactically nested
        - parent_choice_index: (optional) Index of parent choice containing this menu
        - is_syntactically_nested: (optional) True if nested inside choice block
        """
        import re

        results: List[Dict[str, Any]] = []
        lines = content.split("\n")

        current_label = None

        # Stack of menu contexts for syntactic nesting
        menu_stack: List[Dict[str, Any]] = []

        def cur_menu():
            return menu_stack[-1] if menu_stack else None

        def finalize_option_block(ctx: Dict[str, Any]) -> None:
            """Finalize the current option block's target extraction."""
            if (
                ctx["in_option_block"]
                and ctx["option_block_lines"]
                and ctx["current_options"]
            ):
                targets = self._extract_targets_from_option_block(
                    ctx["option_block_lines"]
                )
                ctx["current_options"][-1]["targets"] = targets
            ctx["in_option_block"] = False
            ctx["option_block_indent"] = 0
            ctx["option_block_lines"] = []

        def finalize_menu(ctx: Dict[str, Any]) -> None:
            """Finalize and emit the current menu context."""
            # Finalize last option
            finalize_option_block(ctx)

            if not ctx["current_options"]:
                return

            choice_point_id = self._generate_choice_point_id(
                rel_path, ctx["menu_start_line"], ctx["menu_label"]
            )

            cp = {
                "choice_point_id": choice_point_id,
                "location": {
                    "file": rel_path,
                    "line": ctx["menu_start_line"],
                    "label": ctx["menu_label"],
                },
                "kind": "menu_ast",
                "options": ctx["current_options"],
            }

            # Optional syntactic-parent linkage
            if ctx.get("parent_choice_point_id"):
                cp["parent_choice_point_id"] = ctx["parent_choice_point_id"]
                cp["parent_choice_index"] = ctx["parent_choice_index"]
                cp["is_syntactically_nested"] = True

            results.append(cp)

            # Store the generated id back into ctx for child linkage
            ctx["choice_point_id"] = choice_point_id

        for line_idx, line in enumerate(lines):
            line_num = line_idx + 1
            stripped = line.strip()

            if not stripped or stripped.startswith("#"):
                continue

            indent = len(line) - len(line.lstrip())

            # ---------- 1) Handle menu/option exits by indentation (stack-aware) ----------
            # Close option blocks first (top context only)
            ctx = cur_menu()
            if ctx and ctx["in_option_block"]:
                # Check for nested menu BEFORE collecting as option block line
                # This allows nested menus to break out of option block collection
                if re.match(r"^\s*menu\s*:\s*$", line):
                    # Nested menu detected - finalize option block without target extraction
                    # The nested menu will be the logical "target" via parent linkage

                    # Policy: First nested menu wins; multiple nested menus in same option
                    # block produce multiple child choice points with same parent_choice_index
                    # (rare edge case, but valid Ren'Py syntax)

                    ctx["in_option_block"] = False
                    ctx["option_block_lines"] = (
                        []
                    )  # Clear lines, nested menu supersedes

                    # Mark this option as containing nested menu (optional field)
                    if ctx["current_options"]:
                        ctx["current_options"][-1][
                            "targets"
                        ] = []  # Empty targets (required)
                        ctx["current_options"][-1][
                            "contains_nested_menu"
                        ] = True  # Optional hint
                    # Fall through to process menu: line below
                # Leaving option block if dedent to or before option indent
                elif indent <= ctx["option_block_indent"] and stripped:
                    finalize_option_block(ctx)
                    # Fall through: the current line could be a new option or menu end
                else:
                    # Normal option block line - collect it
                    ctx["option_block_lines"].append(line)
                    continue

            # Close one or more menus if we dedent to or before the current menu base indent
            # IMPORTANT: Do NOT 'continue' after closing; re-process same line under new state
            while menu_stack:
                ctx = cur_menu()
                if indent <= ctx["menu_base_indent"] and stripped:
                    finalize_menu(ctx)
                    menu_stack.pop()
                    # Continue loop: could close multiple nested menus
                    continue
                break

            # Refresh ctx after possible pops
            ctx = cur_menu()

            # ---------- 2) Track label context ----------
            label_match = re.match(r"^\s*label\s+([A-Za-z_]\w*)\s*:", line)
            if label_match:
                current_label = label_match.group(1)
                continue

            # ---------- 3) Detect menu start (can be nested) ----------
            if re.match(r"^\s*menu\s*:\s*$", line):
                # Determine syntactic parent linkage if we are inside an option block
                parent_choice_point_id = None
                parent_choice_index = None
                is_nested = False

                if ctx and ctx.get("last_option_index") is not None:
                    # We are syntactically nested if:
                    # - We're inside a menu context
                    # - Indent is greater than menu base (we're in option block scope)
                    # - We just processed an option (last_option_index exists)
                    if indent > ctx["menu_base_indent"]:
                        is_nested = True
                        # Generate parent ID deterministically (parent not finalized yet)
                        parent_choice_point_id = self._generate_choice_point_id(
                            rel_path, ctx["menu_start_line"], ctx["menu_label"]
                        )
                        parent_choice_index = ctx["last_option_index"]

                new_ctx = {
                    "menu_start_line": line_num,
                    "menu_base_indent": indent,
                    "menu_label": current_label,
                    "current_options": [],
                    "option_index": 0,
                    "in_option_block": False,
                    "option_block_indent": 0,
                    "option_block_lines": [],
                    # Track option association for nested menu detection
                    "last_option_index": None,
                }
                if is_nested:
                    new_ctx["parent_choice_point_id"] = parent_choice_point_id
                    new_ctx["parent_choice_index"] = parent_choice_index

                menu_stack.append(new_ctx)
                continue

            # If we are not in any menu at this point, skip
            ctx = cur_menu()
            if not ctx:
                continue

            # ---------- 4) Match option lines within current menu ----------
            option_match = re.match(r'^\s*"([^"]+)"\s*:\s*$', line)
            if option_match:
                option_text = option_match.group(1)
                ctx["current_options"].append(
                    {
                        "index": ctx["option_index"],
                        "text": option_text,
                        "targets": [],
                        "condition_raw": None,
                    }
                )
                ctx["last_option_index"] = ctx["option_index"]
                ctx["option_index"] += 1

                # Start option block tracking
                ctx["in_option_block"] = True
                ctx["option_block_indent"] = indent
                ctx["option_block_lines"] = []
                continue

            option_cond_match = re.match(r'^\s*"([^"]+)"\s+if\s+(.+):\s*$', line)
            if option_cond_match:
                option_text = option_cond_match.group(1)
                condition = option_cond_match.group(2)
                ctx["current_options"].append(
                    {
                        "index": ctx["option_index"],
                        "text": option_text,
                        "targets": [],
                        "condition_raw": condition,
                    }
                )
                ctx["last_option_index"] = ctx["option_index"]
                ctx["option_index"] += 1

                ctx["in_option_block"] = True
                ctx["option_block_indent"] = indent
                ctx["option_block_lines"] = []
                continue

        # ---------- 5) EOF: finalize remaining open menus ----------
        while menu_stack:
            ctx = cur_menu()
            finalize_menu(ctx)
            menu_stack.pop()

        return results

    def _extract_targets_from_option_block(self, lines: List[str]) -> List[str]:
        """
        Analyze option block lines to infer target labels.

        Looks for:
        - jump <label>
        - call <label>
        - return (treated as empty targets)

        Returns list of target labels (may be empty).
        """
        import re

        targets = []

        for line in lines:
            stripped = line.strip()

            # Match jump statement
            jump_match = re.match(r"^jump\s+([A-Za-z_]\w*)(?:\s|#|$)", stripped)
            if jump_match:
                targets.append(jump_match.group(1))
                # For MVP, take first jump found
                break

            # Match call statement (not "call screen")
            call_match = re.match(
                r"^call\s+(?!screen\s)([A-Za-z_]\w*)(?:\s|#|$)", stripped
            )
            if call_match:
                targets.append(call_match.group(1))
                # For MVP, take first call found
                break

            # Match return statement (terminal, no target)
            if re.match(r"^return(?:\s|#|$)", stripped):
                # Return means terminal - no targets
                break

        return targets

    def _generate_choice_point_id(
        self, rel_path: str, line: int, label: str | None
    ) -> str:
        """
        Generate stable choice point ID for reproducibility.

        Uses SHA1 hash of (file:line:label) to ensure consistent IDs
        across runs and support plan replay.
        """
        import hashlib

        # Build deterministic ID string
        id_str = f"{rel_path}:{line}:{label or ''}"
        hash_obj = hashlib.sha1(id_str.encode("utf-8"))
        hash_hex = hash_obj.hexdigest()[:10]

        return f"cp_{hash_hex}"
