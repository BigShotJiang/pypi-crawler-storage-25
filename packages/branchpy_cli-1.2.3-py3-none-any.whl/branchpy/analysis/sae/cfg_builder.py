"""CFG Builder - Construct categorized control-flow graph (CCFG) from project index"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class EdgeType(Enum):
    """CCFG edge types"""

    SEQ = "seq"  # Sequential fall-through
    JUMP = "jump"  # Explicit goto
    JUMP_DYNAMIC = "jump_dynamic"  # Dynamic jump (unresolved target)
    BRANCH_TRUE = "branch_true"  # Conditional true path
    BRANCH_FALSE = "branch_false"  # Conditional false path
    CALL = "call"  # Subroutine call
    RETURN = "return"  # Return from call
    SCREEN_ACTION = "screen_action"  # Screen button/action


class NodeKind(Enum):
    """CFG node kinds"""

    LABEL = "label"
    MENU = "menu"
    SAY = "say"
    CALL = "call"
    RETURN = "return"
    END = "end"
    SHOW = "show"
    PLAY = "play"
    SCENE = "scene"
    PYTHON = "python"
    JUMP = "jump"
    SCREEN = "screen"
    SCREEN_ACTION = "screen_action"
    EXECUTION_CONTAINER = "execution_container"  # Examples, minigames, screen loops


@dataclass
class CFGNode:
    """Control-flow graph node"""

    id: str
    kind: NodeKind
    name: Optional[str] = None
    file: str = ""
    line: int = 0
    line_start: int = 0  # Start line for multi-line nodes
    line_end: int = 0  # End line for multi-line nodes
    label: str = ""  # Canonical label for mapping (Ren'Py label name)
    reading_time: Optional[Dict[str, float]] = None
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        d = {
            "id": self.id,
            "kind": self.kind.value,
            "file": self.file,
            "line": self.line,
        }
        # Include anchors for deterministic mapping
        if self.line_start > 0:
            d["line_start"] = self.line_start
        if self.line_end > 0:
            d["line_end"] = self.line_end
        if self.label:
            d["label"] = self.label
        if self.name:
            d["name"] = self.name
        if self.reading_time:
            d["reading_time"] = self.reading_time
        if self.meta:
            d["meta"] = self.meta
        return d


@dataclass
class CFGEdge:
    """Control-flow graph edge"""

    from_node: str
    to_node: str
    edge_type: EdgeType
    cond: Optional[str] = None
    label: Optional[str] = None
    meta: Optional[Dict[str, Any]] = None  # For dynamic jump metadata

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        d = {
            "from": self.from_node,
            "to": self.to_node,
            "type": self.edge_type.value,
        }
        if self.cond:
            d["cond"] = self.cond
        if self.label:
            d["label"] = self.label
        if self.meta:
            d["meta"] = self.meta  # type: ignore[assignment]
        return d


@dataclass
class ControlFlowGraph:
    """Complete control-flow graph"""

    nodes: Dict[str, CFGNode] = field(default_factory=dict)
    edges: List[CFGEdge] = field(default_factory=list)
    entry_nodes: Set[str] = field(default_factory=set)
    # Adjacency indexes — populated by add_edge for O(1) traversal
    _succ: Dict[str, List[str]] = field(default_factory=dict, repr=False, compare=False)
    _pred: Dict[str, List[str]] = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self) -> None:
        # Rebuild indexes if the graph was constructed without add_edge
        # (e.g. deserialized or built in a test fixture)
        if self.edges and not self._succ:
            for e in self.edges:
                self._succ.setdefault(e.from_node, []).append(e.to_node)
                self._pred.setdefault(e.to_node, []).append(e.from_node)

    def add_node(self, node: CFGNode) -> None:
        """Add node to graph"""
        self.nodes[node.id] = node

    def add_edge(self, edge: CFGEdge) -> None:
        """Add edge to graph and update adjacency indexes"""
        self.edges.append(edge)
        self._succ.setdefault(edge.from_node, []).append(edge.to_node)
        self._pred.setdefault(edge.to_node, []).append(edge.from_node)

    def get_successors(self, node_id: str) -> List[str]:
        """Get all successor node IDs — O(1) via adjacency index"""
        return self._succ.get(node_id, [])

    def get_predecessors(self, node_id: str) -> List[str]:
        """Get all predecessor node IDs — O(1) via adjacency index"""
        return self._pred.get(node_id, [])

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges],
            "entry_nodes": list(self.entry_nodes),
        }


class CFGBuilder:
    """Build CCFG from project index"""

    def __init__(self, index: Any):
        """
        Args:
            index: ProjectIndex from Indexer
        """
        self.index = index
        self.cfg = ControlFlowGraph()
        self._node_counter = 0
        self._label_to_node_id: Dict[str, str] = {}  # label_name -> node_id mapping

    def build(self) -> ControlFlowGraph:
        """
        Construct control-flow graph with typed edges.

        Returns:
            ControlFlowGraph with nodes and edges
        """
        # Step 1: Create nodes for all labels
        for label_name, label_entry in self.index.labels.items():
            node = CFGNode(
                id=self._gen_node_id(),
                kind=NodeKind.LABEL,
                name=label_name,
                file=label_entry.file,
                line=label_entry.line,
            )
            self.cfg.add_node(node)
            self._label_to_node_id[label_name] = node.id

        # Step 2: Add entry node if 'start' label exists
        if "start" in self._label_to_node_id:
            self.cfg.entry_nodes.add(self._label_to_node_id["start"])

        # Step 3: Process jumps (create jump edges)
        for jump_entry in self.index.jumps:
            # Find the source label for this jump
            source_label = self._find_containing_label(jump_entry.file, jump_entry.line)
            if source_label and jump_entry.name in self._label_to_node_id:
                from_id = self._label_to_node_id[source_label]
                to_id = self._label_to_node_id[jump_entry.name]
                edge = CFGEdge(
                    from_node=from_id, to_node=to_id, edge_type=EdgeType.JUMP
                )
                self.cfg.add_edge(edge)

        # Step 4: Process calls (create call edges)
        for call_entry in self.index.calls:
            source_label = self._find_containing_label(call_entry.file, call_entry.line)
            if source_label and call_entry.name in self._label_to_node_id:
                from_id = self._label_to_node_id[source_label]
                to_id = self._label_to_node_id[call_entry.name]
                edge = CFGEdge(
                    from_node=from_id, to_node=to_id, edge_type=EdgeType.CALL
                )
                self.cfg.add_edge(edge)

        # Step 5: Process sequential flow (labels that don't have explicit jumps/calls might fall through)
        # For now, we keep this simple - explicit edges only

        return self.cfg

    def _find_containing_label(self, file: str, line: int) -> Optional[str]:
        """
        Find which label contains the given file:line location.

        Returns:
            Label name or None if not found
        """
        # Find all labels in the same file, sorted by line number
        labels_in_file = [
            (name, entry.line)
            for name, entry in self.index.labels.items()
            if entry.file == file
        ]
        labels_in_file.sort(key=lambda x: x[1])

        # Find the label that contains this line (label with highest line <= target line)
        containing_label = None
        for label_name, label_line in labels_in_file:
            if label_line <= line:
                containing_label = label_name
            else:
                break

        return containing_label

    def _gen_node_id(self) -> str:
        """Generate unique node ID"""
        self._node_counter += 1
        return f"n{self._node_counter}"

    def _process_label(self, label_name: str, label_data: Any) -> CFGNode:
        """Create CFG node for label"""
        # Stub
        return CFGNode(
            id=self._gen_node_id(),
            kind=NodeKind.LABEL,
            name=label_name,
        )

    def _process_menu(self, menu_data: Any) -> tuple[CFGNode, List[CFGEdge]]:
        """Process menu and create branch edges"""
        # Stub - returns (menu_node, branch_edges)
        return CFGNode(id=self._gen_node_id(), kind=NodeKind.MENU), []

    def _calculate_reading_time(self, text: str) -> Dict[str, float]:
        """
        Calculate reading time for dialogue text.

        Args:
            text: Dialogue/narration text

        Returns:
            Dict with 'fast', 'normal', 'slow' reading times (seconds)
        """
        # Stub - Gate 3 will implement proper WPM calculation
        word_count = len(text.split())
        return {
            "fast": word_count / 250 * 60,  # 250 WPM
            "normal": word_count / 200 * 60,  # 200 WPM
            "slow": word_count / 150 * 60,  # 150 WPM
        }


class StatementCFGBuilder:
    """Build statement-level CCFG with sequential edges and semantic analysis"""

    def __init__(
        self,
        index: Any,
        project_root: Optional[str] = None,
        statement_extractor: Optional[Any] = None,
        semantics_catalog: Optional[Any] = None,
        dataflow_context: Optional[Any] = None,
    ):
        """
        Args:
            index: ProjectIndex from Indexer
            project_root: Project root directory (optional, inferred from index if None)
            statement_extractor: StatementExtractor instance (optional, created if None)
            semantics_catalog: SemanticsCatalog instance (optional)
            dataflow_context: DataFlowContext instance (optional, created if None)
        """
        self.index = index
        self.cfg = ControlFlowGraph()
        self._node_counter = 0
        self._stmt_to_node_id: Dict[tuple, str] = {}  # (file, line) -> node_id
        self._label_to_first_stmt: Dict[str, tuple] = (
            {}
        )  # label_name -> (file, line) of first stmt
        self._call_sites: Dict[str, List[str]] = (
            {}
        )  # label_name -> list of call site node IDs

        # Infer project root from first label file if not provided
        if project_root is None:
            if index.labels:
                # Get first label's file and walk up to find project root
                first_file = next(iter(index.labels.values())).file
                # Assume file is relative to project root (e.g., "game/script.rpy")
                # So we need to be given the project root or figure it out
                # For now, store None and require caller to provide it
                self.project_root = None
            else:
                self.project_root = None
        else:
            self.project_root = project_root

        # Import and create statement extractor if not provided
        if statement_extractor is None:
            from .statement_extractor import StatementExtractor

            self.stmt_extractor = StatementExtractor()
        else:
            self.stmt_extractor = statement_extractor

        # Import and create semantics catalog if not provided
        if semantics_catalog is None:
            from .semantics import SemanticsCatalog

            self.semantics = SemanticsCatalog()
        else:
            self.semantics = semantics_catalog

        # Import and create dataflow context if not provided
        if dataflow_context is None:
            from .dataflow import DataFlowContext

            self.dataflow = DataFlowContext()
        else:
            self.dataflow = dataflow_context

    def build(self) -> ControlFlowGraph:
        """
        Construct statement-level control-flow graph with SEQ edges.

        Returns:
            ControlFlowGraph with statement nodes and typed edges
        """
        from .statement_extractor import StatementType

        # Step 1: Extract all statements from all script files
        all_statements = []
        for file_path in self._get_script_files():
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                statements = self.stmt_extractor.extract_statements(content, file_path)
                all_statements.extend(statements)
            except Exception:
                # Skip files that can't be read
                continue

        # Store for cross-file resolution (e.g. variable-backed screen jumps)
        self._all_statements = all_statements

        # Step 2: Create nodes for all statements (including menu choices)
        for stmt in all_statements:
            loc_key = (stmt.file, stmt.line)

            # Check if we already created a node for this (file, line)
            # This handles cases where multiple statement types are extracted for the same line
            # (e.g., PYTHON and JUMP for "$ renpy.jump(...)")
            if loc_key in self._stmt_to_node_id:
                # If existing node is generic PYTHON (SAY kind) and new stmt is more specific (JUMP/CALL/RETURN),
                # replace it with the more specific version
                existing_node_id = self._stmt_to_node_id[loc_key]
                existing_node = self.cfg.nodes.get(existing_node_id)

                if existing_node and stmt.type == StatementType.PYTHON:
                    # New statement is generic PYTHON - skip it, keep existing specific node
                    continue
                elif existing_node and existing_node.kind == NodeKind.SAY:
                    # Existing is generic PYTHON/SAY - check if new is more specific
                    if stmt.type in (
                        StatementType.JUMP,
                        StatementType.CALL,
                        StatementType.RETURN,
                    ):
                        # Replace with more specific node
                        new_kind = self._stmt_type_to_node_kind(stmt.type)
                        existing_node.kind = new_kind
                        existing_node.meta = (
                            stmt.meta if stmt.meta else existing_node.meta
                        )
                continue

            node_kind = self._stmt_type_to_node_kind(stmt.type)
            # Get name from type-specific fields
            name = None
            if stmt.label_name:
                name = stmt.label_name
            elif stmt.text:
                name = stmt.text[:50]  # Truncate long text

            node = CFGNode(
                id=self._gen_node_id(),
                kind=node_kind,
                name=name,
                file=stmt.file,
                line=stmt.line,
                meta=stmt.meta,
            )
            self.cfg.add_node(node)
            self._stmt_to_node_id[loc_key] = node.id

            # Track first statement after labels
            if stmt.type == StatementType.LABEL and stmt.label_name:
                self._label_to_first_stmt[stmt.label_name] = (stmt.file, stmt.line)

            # For menu statements, also create nodes for each choice
            if stmt.type == StatementType.MENU and stmt.choices:
                for choice in stmt.choices:
                    choice_kind = self._stmt_type_to_node_kind(choice.type)
                    choice_node = CFGNode(
                        id=self._gen_node_id(),
                        kind=choice_kind,
                        name=choice.text[:50] if choice.text else None,
                        file=choice.file,
                        line=choice.line,
                        meta=choice.meta,
                    )
                    self.cfg.add_node(choice_node)
                    self._stmt_to_node_id[(choice.file, choice.line)] = choice_node.id

        # Step 3: Add entry node (first statement in 'start' label)
        if "start" in self._label_to_first_stmt:
            start_loc = self._label_to_first_stmt["start"]
            if start_loc in self._stmt_to_node_id:
                self.cfg.entry_nodes.add(self._stmt_to_node_id[start_loc])

        # Step 4: Add edges (SEQ, JUMP, BRANCH, etc.)
        self._add_edges(all_statements)

        # Step 5: Add RETURN edges from label ends to call sites
        self._add_return_edges(all_statements)

        return self.cfg

    def _get_script_files(self) -> List[str]:
        """Get all .rpy script files from index"""
        # Collect unique file paths from index (relative to project root)
        files = set()
        for label_entry in self.index.labels.values():
            files.add(label_entry.file)
        for jump_entry in self.index.jumps:
            files.add(jump_entry.file)
        for call_entry in self.index.calls:
            files.add(call_entry.file)

        # Convert to absolute paths using project_root if available
        if self.project_root:
            import os

            abs_files = []
            for rel_path in files:
                abs_path = os.path.join(self.project_root, rel_path)
                if os.path.exists(abs_path):
                    abs_files.append(abs_path)
            return sorted(abs_files)
        else:
            # No project root - return empty (caller must provide project_root)
            return []

    def _stmt_type_to_node_kind(self, stmt_type: Any) -> NodeKind:
        """Map StatementType to NodeKind"""
        from .statement_extractor import StatementType

        mapping = {
            StatementType.LABEL: NodeKind.LABEL,
            StatementType.SAY: NodeKind.SAY,
            StatementType.MENU: NodeKind.MENU,
            StatementType.MENU_CHOICE: NodeKind.MENU,  # Choices also use MENU kind
            StatementType.JUMP: NodeKind.CALL,  # Reuse CALL for now, differentiate by metadata
            StatementType.CALL: NodeKind.CALL,
            StatementType.RETURN: NodeKind.RETURN,
            StatementType.IF: NodeKind.SAY,  # Use SAY as generic for conditionals
            StatementType.ELIF: NodeKind.SAY,
            StatementType.ELSE: NodeKind.SAY,
            StatementType.PYTHON: NodeKind.SAY,
        }
        return mapping.get(stmt_type, NodeKind.SAY)

    def _add_edges(self, statements: List[Any]) -> None:
        """Add all edges to CFG"""

        # Group statements by file for sequential processing
        by_file: Dict[str, List[Any]] = {}
        for stmt in statements:
            if stmt.file not in by_file:
                by_file[stmt.file] = []
            by_file[stmt.file].append(stmt)

        # Sort each file's statements by line number
        for file_path in by_file:
            by_file[file_path].sort(key=lambda s: s.line)

        # Process each file
        for file_path, file_stmts in by_file.items():
            self._add_file_edges(file_path, file_stmts)

    def _add_file_edges(self, file_path: str, statements: List[Any]) -> None:
        """Add edges for all statements in a file"""
        from .statement_extractor import StatementType

        # Track dataflow context through the file
        # Reset dataflow for each file/label scope
        for i, stmt in enumerate(statements):
            # Update dataflow context for Python assignments
            if stmt.type == StatementType.PYTHON and stmt.python_code:
                self._update_dataflow(stmt.python_code)

            from_id = self._stmt_to_node_id.get((stmt.file, stmt.line))
            if not from_id:
                continue

            # Handle different statement types
            if stmt.type == StatementType.JUMP:
                self._add_jump_edge(stmt, from_id)

            elif stmt.type == StatementType.CALL:
                self._add_call_edge(stmt, from_id)

            elif stmt.type == StatementType.SCREEN_ACTION:
                self._add_screen_action_edge(stmt, from_id)

            elif stmt.type == StatementType.RETURN:
                # Terminal - no outgoing edges
                pass

            elif stmt.type == StatementType.IF:
                self._add_conditional_edges(statements, i, stmt, from_id)

            elif stmt.type == StatementType.ELIF:
                self._add_conditional_edges(statements, i, stmt, from_id)

            elif stmt.type == StatementType.ELSE:
                # Else only has true branch (always executes)
                if i + 1 < len(statements):
                    next_stmt = statements[i + 1]
                    to_id = self._stmt_to_node_id.get((next_stmt.file, next_stmt.line))
                    if to_id:
                        edge = CFGEdge(
                            from_node=from_id, to_node=to_id, edge_type=EdgeType.SEQ
                        )
                        self.cfg.add_edge(edge)

            elif stmt.type == StatementType.MENU:
                self._add_menu_edges(stmt, from_id, statements)

            elif stmt.type == StatementType.MENU_CHOICE:
                # Menu choice - add SEQ edge to next statement (might be jump, python, etc.)
                if i + 1 < len(statements):
                    next_stmt = statements[i + 1]
                    to_id = self._stmt_to_node_id.get((next_stmt.file, next_stmt.line))
                    if to_id:
                        edge = CFGEdge(
                            from_node=from_id, to_node=to_id, edge_type=EdgeType.SEQ
                        )
                        self.cfg.add_edge(edge)

            elif stmt.type == StatementType.PYTHON:
                # Check for dynamic jumps in Python code
                self._add_python_edges(stmt, from_id)
                # Only add SEQ edge if Python code doesn't contain terminal operations
                # Check if there's a JUMP/CALL/RETURN statement on the same line (indicating terminal)
                has_terminal_on_line = any(
                    s.file == stmt.file
                    and s.line == stmt.line
                    and s.type in (StatementType.JUMP, StatementType.RETURN)
                    for s in statements
                )
                if not has_terminal_on_line and i + 1 < len(statements):
                    next_stmt = statements[i + 1]
                    to_id = self._stmt_to_node_id.get((next_stmt.file, next_stmt.line))
                    if to_id and to_id != from_id:  # Don't create self-loops
                        edge = CFGEdge(
                            from_node=from_id, to_node=to_id, edge_type=EdgeType.SEQ
                        )
                        self.cfg.add_edge(edge)

            else:
                # Add SEQ edge to next statement if not terminal
                if i + 1 < len(statements):
                    next_stmt = statements[i + 1]
                    to_id = self._stmt_to_node_id.get((next_stmt.file, next_stmt.line))
                    if to_id:
                        edge = CFGEdge(
                            from_node=from_id, to_node=to_id, edge_type=EdgeType.SEQ
                        )
                        self.cfg.add_edge(edge)

    def _add_jump_edge(self, stmt: Any, from_id: str) -> None:
        """Add jump edge (with semantic resolution if needed)"""
        target = stmt.target

        if not target:
            # Try to extract from raw statement
            target = self._extract_jump_target(stmt.raw)

        if target and target in self._label_to_first_stmt:
            # Direct jump to known label
            to_loc = self._label_to_first_stmt[target]
            to_id = self._stmt_to_node_id.get(to_loc)
            if to_id:
                edge = CFGEdge(
                    from_node=from_id, to_node=to_id, edge_type=EdgeType.JUMP
                )
                self.cfg.add_edge(edge)
        else:
            # Dynamic or unresolved jump - create JUMP_DYNAMIC edge
            # This will be handled in Phase 6 with full semantic resolution
            pass

    def _add_call_edge(self, stmt: Any, from_id: str) -> None:
        """Add call edge and track call site for return edge"""
        target = stmt.target

        if not target:
            target = self._extract_call_target(stmt.raw)

        if target and target in self._label_to_first_stmt:
            to_loc = self._label_to_first_stmt[target]
            to_id = self._stmt_to_node_id.get(to_loc)
            if to_id:
                edge = CFGEdge(
                    from_node=from_id, to_node=to_id, edge_type=EdgeType.CALL
                )
                self.cfg.add_edge(edge)

                # Track call site for return edge creation
                if target not in self._call_sites:
                    self._call_sites[target] = []
                self._call_sites[target].append(from_id)

        elif stmt.meta.get("call_type") == "screen":
            # 'call screen X' — resolve through screen's Jump/Call actions + dataflow.
            # Handles the common Ren'Py chapter-transition pattern:
            #   $ next_chapter = "intro_scene"
            #   call screen end_of_day_summary with dissolve
            self._add_call_screen_edge(target or "", from_id)

    def _add_call_screen_edge(self, screen_name: str, from_id: str) -> None:
        """
        Resolve 'call screen X' edges by finding X's Jump/Call SCREEN_ACTION
        statements and resolving any variable targets through the current
        dataflow context.

        Emits a JUMP (or CALL) edge for each resolvable Jump(var)/Call(var)
        action found in the screen, using the constant value of `var` recorded
        in self.dataflow at the point of the 'call screen' statement.
        """
        from .statement_extractor import StatementType

        all_stmts = getattr(self, "_all_statements", [])
        if not all_stmts or not screen_name:
            return

        emitted = set()  # avoid duplicate edges for the same resolved target
        for stmt in all_stmts:
            if (
                stmt.type == StatementType.SCREEN_ACTION
                and stmt.screen_name == screen_name
                and stmt.action_type in ("jump", "call")
            ):
                target = stmt.target
                if not target:
                    continue

                resolved_var: Optional[str] = None

                # If target is not a known label, try to resolve it as a variable
                if target not in self._label_to_first_stmt:
                    kind, value = self.dataflow.resolve(target)
                    if kind == "constant" and isinstance(value, str):
                        resolved_var = target
                        target = value
                    else:
                        continue  # Cannot resolve — skip

                if target not in self._label_to_first_stmt:
                    continue

                if target in emitted:
                    continue
                emitted.add(target)

                to_loc = self._label_to_first_stmt[target]
                to_id = self._stmt_to_node_id.get(to_loc)
                if not to_id:
                    continue

                edge_type = (
                    EdgeType.CALL if stmt.action_type == "call" else EdgeType.JUMP
                )
                meta: Dict[str, Any] = {
                    "via_screen": screen_name,
                    "screen_action": stmt.action_type,
                    "pfi_source": "variable_screen_jump",
                }
                if resolved_var:
                    meta["resolved_var"] = resolved_var

                self.cfg.add_edge(
                    CFGEdge(
                        from_node=from_id,
                        to_node=to_id,
                        edge_type=edge_type,
                        meta=meta,
                    )
                )

    def _add_conditional_edges(
        self, statements: List[Any], stmt_idx: int, stmt: Any, from_id: str
    ) -> None:
        """Add branch edges for if/elif/else"""

        # Find the next statement (true branch - first statement in if block)
        if stmt_idx + 1 < len(statements):
            next_stmt = statements[stmt_idx + 1]
            to_id = self._stmt_to_node_id.get((next_stmt.file, next_stmt.line))
            if to_id:
                edge = CFGEdge(
                    from_node=from_id,
                    to_node=to_id,
                    edge_type=EdgeType.BRANCH_TRUE,
                    cond=stmt.condition,
                )
                self.cfg.add_edge(edge)

        # Find the else/elif branch or statement after the if block (false branch)
        false_target = self._find_false_branch_target(statements, stmt_idx, stmt)
        if false_target:
            to_id = self._stmt_to_node_id.get(false_target)
            if to_id:
                edge = CFGEdge(
                    from_node=from_id,
                    to_node=to_id,
                    edge_type=EdgeType.BRANCH_FALSE,
                    cond=f"not ({stmt.condition})",
                )
                self.cfg.add_edge(edge)

    def _find_false_branch_target(
        self, statements: List[Any], if_idx: int, if_stmt: Any
    ) -> Optional[tuple]:
        """Find the target for the false branch of an if statement.

        Returns (file, line) tuple of the elif/else statement or the first
        statement after the if block ends.
        """
        from .statement_extractor import StatementType

        if_indent = if_stmt.indent

        # Scan forward to find elif/else at same indent, or first statement with <= indent
        for i in range(if_idx + 1, len(statements)):
            stmt = statements[i]

            # Skip statements inside the if block (greater indent)
            if stmt.indent > if_indent:
                continue

            # Found elif or else at same indent - this is the false branch
            if stmt.indent == if_indent and stmt.type in (
                StatementType.ELIF,
                StatementType.ELSE,
            ):
                return (stmt.file, stmt.line)

            # Found statement at same or lower indent - this is after the if block
            if stmt.indent <= if_indent:
                return (stmt.file, stmt.line)

        # No statement found after if block (end of file/scope)
        return None

    def _add_menu_edges(
        self, stmt: Any, from_id: str, all_statements: List[Any]
    ) -> None:
        """Add menu choice edges with BRANCH edges to each choice and SEQ edges to body statements"""

        # Menu statement should have choices
        if not stmt.choices or len(stmt.choices) == 0:
            # Empty menu - just fall through
            return

        # Create BRANCH edges from menu node to each choice's first statement
        # Each choice in stmt.choices is a MENU_CHOICE statement
        for choice_stmt in stmt.choices:
            # Find the node ID for this choice statement
            choice_id = self._stmt_to_node_id.get((choice_stmt.file, choice_stmt.line))
            if choice_id:
                # Create BRANCH edge from menu to choice
                # Use choice text as label
                edge = CFGEdge(
                    from_node=from_id,
                    to_node=choice_id,
                    edge_type=EdgeType.BRANCH_TRUE,  # All menu branches are "true" paths
                    label=choice_stmt.text,  # Choice text for visualization
                )
                self.cfg.add_edge(edge)

                # Now find the first body statement for this choice
                # Body statements come after the choice in the file and have greater indent
                choice_line = choice_stmt.line
                choice_indent = choice_stmt.indent

                # Find body statements (they should be in all_statements)
                # Look for statements with same file, line > choice_line, indent > choice_indent
                for body_stmt in all_statements:
                    if (
                        body_stmt.file == choice_stmt.file
                        and body_stmt.line > choice_line
                        and body_stmt.indent > choice_indent
                    ):
                        # This is a body statement - create SEQ edge from choice to it
                        body_id = self._stmt_to_node_id.get(
                            (body_stmt.file, body_stmt.line)
                        )
                        if body_id:
                            body_edge = CFGEdge(
                                from_node=choice_id,
                                to_node=body_id,
                                edge_type=EdgeType.SEQ,
                            )
                            self.cfg.add_edge(body_edge)
                            break  # Only connect to FIRST body statement

        # Note: Menu choices may have their own statements (jumps, calls, etc.)
        # Those will be handled separately when we process MENU_CHOICE statements

    def _add_python_edges(self, stmt: Any, from_id: str) -> None:
        """Add edges for Python statements that might contain dynamic jumps"""
        import ast

        if not stmt.python_code:
            return

        try:
            # Parse Python code to find function calls
            tree = ast.parse(stmt.python_code)

            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    self._process_python_call(node, stmt, from_id)

        except SyntaxError:
            # Can't parse - skip
            pass

    def _process_python_call(self, call_node: Any, stmt: Any, from_id: str) -> None:
        """Process a Python function call for potential jump/call"""
        import ast

        # Get function name
        func_name = None
        module_name = None

        if isinstance(call_node.func, ast.Name):
            func_name = call_node.func.id
        elif isinstance(call_node.func, ast.Attribute):
            func_name = call_node.func.attr
            if isinstance(call_node.func.value, ast.Name):
                module_name = call_node.func.value.id

        if not func_name:
            return

        # Look up in semantics catalog
        from .semantics import FunctionKind

        semantics = self.semantics.lookup(func_name, module_name)

        if not semantics or semantics.kind not in [
            FunctionKind.JUMP,
            FunctionKind.CALL,
        ]:
            return

        # Extract the label argument
        if len(call_node.args) <= semantics.arg_index:
            return

        label_arg = call_node.args[semantics.arg_index]

        # Evaluate the argument
        kind, value = self._evaluate_label_expression(label_arg, stmt)

        # Build metadata
        callee_fqn = f"{module_name}.{func_name}" if module_name else func_name

        # Emit edges based on evaluation result
        if kind == "literal":
            # Single target - emit JUMP edge
            self._emit_resolved_jump(
                from_id, value, semantics, callee_fqn, confidence="high"
            )

        elif kind == "set" and isinstance(value, set) and len(value) <= 6:
            # Small set of candidates - emit multiple JUMP edges
            for target in sorted(value):
                self._emit_resolved_jump(
                    from_id,
                    target,
                    semantics,
                    callee_fqn,
                    confidence="medium",
                    candidates=list(value),
                )

        else:
            # Unknown or too many candidates - emit JUMP_DYNAMIC
            expr_snippet = (
                ast.unparse(call_node) if hasattr(ast, "unparse") else str(call_node)
            )
            self._emit_dynamic_jump(from_id, expr_snippet, semantics, callee_fqn)

    def _evaluate_label_expression(self, expr_node: Any, stmt: Any) -> tuple:
        """Evaluate a label expression using dataflow analysis"""
        import ast

        # For literals, return directly
        if isinstance(expr_node, ast.Constant):
            return ("literal", expr_node.value)

        # For variables, use dataflow
        if isinstance(expr_node, ast.Name):
            kind, value = self.dataflow.resolve(expr_node.id)
            if kind == "constant":
                return ("literal", value)
            return ("unknown", None)

        # For ternary expressions (a if cond else b)
        if isinstance(expr_node, ast.IfExp):
            # Evaluate both branches
            true_kind, true_val = self._evaluate_label_expression(expr_node.body, stmt)
            false_kind, false_val = self._evaluate_label_expression(
                expr_node.orelse, stmt
            )

            values = set()
            if true_kind == "literal":
                values.add(true_val)
            if false_kind == "literal":
                values.add(false_val)

            if values:
                return ("set", values)

        # For binary operations (string concat)
        if isinstance(expr_node, ast.BinOp) and isinstance(expr_node.op, ast.Add):
            left_kind, left_val = self._evaluate_label_expression(expr_node.left, stmt)
            right_kind, right_val = self._evaluate_label_expression(
                expr_node.right, stmt
            )

            if left_kind == "literal" and right_kind == "literal":
                if isinstance(left_val, str) and isinstance(right_val, str):
                    return ("literal", left_val + right_val)

        return ("unknown", None)

    def _emit_resolved_jump(
        self,
        from_id: str,
        target: str,
        semantics: Any,
        callee_fqn: str,
        confidence: str,
        candidates: Optional[List[str]] = None,
    ) -> None:
        """Emit a JUMP edge to a resolved target"""
        # Check if target label exists
        if target not in self._label_to_first_stmt:
            # Target label doesn't exist - emit JUMP_DYNAMIC instead
            self._emit_dynamic_jump(
                from_id,
                f"jump to '{target}'",
                semantics,
                callee_fqn,
                reason=f"label '{target}' not found",
            )
            return

        to_loc = self._label_to_first_stmt[target]
        to_id = self._stmt_to_node_id.get(to_loc)

        if to_id:
            # Build metadata
            meta = semantics.to_meta(callee_fqn, confidence)
            if candidates:
                meta["candidates"] = candidates

            edge = CFGEdge(
                from_node=from_id, to_node=to_id, edge_type=EdgeType.JUMP, meta=meta
            )
            self.cfg.add_edge(edge)

    def _emit_dynamic_jump(
        self,
        from_id: str,
        expr_snippet: str,
        semantics: Any,
        callee_fqn: str,
        reason: str = "unresolved expression",
    ) -> None:
        """Emit a JUMP_DYNAMIC edge for unresolved jump"""
        # Build metadata
        meta = semantics.to_meta(callee_fqn, "low")
        meta["expr_snippet"] = expr_snippet
        meta["reason"] = reason

        # JUMP_DYNAMIC edges don't have a to_node
        # We'll use a dummy node ID for now (Phase 7 will handle this better)
        edge = CFGEdge(
            from_node=from_id,
            to_node="",  # No target
            edge_type=EdgeType.JUMP_DYNAMIC,
            meta=meta,
        )
        self.cfg.add_edge(edge)

    def _update_dataflow(self, python_code: str) -> None:
        """Update dataflow context with Python assignments"""
        import ast

        try:
            tree = ast.parse(python_code)

            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id

                            # Check if RHS is a constant
                            if isinstance(node.value, ast.Constant):
                                self.dataflow.set_constant(var_name, node.value.value)

                            # Check if RHS is another variable (alias)
                            elif isinstance(node.value, ast.Name):
                                self.dataflow.set_alias(var_name, node.value.id)

                            # Otherwise, mark as unknown
                            else:
                                self.dataflow.invalidate(var_name)

        except SyntaxError:
            # Can't parse - skip
            pass

    def _extract_jump_target(self, content: str) -> Optional[str]:
        """Extract jump target from statement content"""
        import re

        match = re.match(r"\s*jump\s+(\w+)", content)
        if match:
            return match.group(1)
        return None

    def _extract_call_target(self, content: str) -> Optional[str]:
        """Extract call target from statement content"""
        import re

        match = re.match(r"\s*call\s+(\w+)", content)
        if match:
            return match.group(1)
        return None

    def _add_screen_action_edge(self, stmt: Any, from_id: str) -> None:
        """Add edge for screen action (Jump/Call/Show from button)"""
        if not stmt.action_type or not stmt.target:
            return

        # For jump and call actions, create edges to labels
        if stmt.action_type in ("jump", "call"):
            if stmt.target in self._label_to_first_stmt:
                to_loc = self._label_to_first_stmt[stmt.target]
                to_id = self._stmt_to_node_id.get(to_loc)
                if to_id:
                    edge = CFGEdge(
                        from_node=from_id,
                        to_node=to_id,
                        edge_type=EdgeType.SCREEN_ACTION,
                        meta={
                            "action": stmt.action_type,
                            "screen": stmt.screen_name,
                            "widget": stmt.widget_type,
                            "target": stmt.target,
                        },
                    )
                    self.cfg.add_edge(edge)

                    # If it's a call action, track for return edge
                    if stmt.action_type == "call":
                        if stmt.target not in self._call_sites:
                            self._call_sites[stmt.target] = []
                        self._call_sites[stmt.target].append(from_id)
            # If target doesn't exist, validator will catch it

        # For show actions, we don't create edges (screen-to-screen not in CFG)
        # But we could track them in metadata for validation

    def _add_return_edges(self, all_statements: List[Any]) -> None:
        """Add RETURN edges from label ends back to call sites"""
        from .statement_extractor import StatementType

        # For each label that has been called, find its end and create return edges
        for label_name, call_site_ids in self._call_sites.items():
            if label_name not in self._label_to_first_stmt:
                continue

            # Find the last statement in this label
            label_start_loc = self._label_to_first_stmt[label_name]
            label_file, label_line = label_start_loc

            # Get all statements in this label's file
            label_stmts = [
                s
                for s in all_statements
                if s.file == label_file and s.line >= label_line
            ]
            label_stmts.sort(key=lambda s: s.line)

            if not label_stmts:
                continue

            # Find where this label ends (next label or explicit return/jump)
            label_end_stmt = None
            for i, stmt in enumerate(label_stmts):
                # Skip the label statement itself
                if stmt.type == StatementType.LABEL and stmt.label_name == label_name:
                    continue

                # If we hit another label, previous statement was the end
                if stmt.type == StatementType.LABEL and stmt.label_name != label_name:
                    if i > 0:
                        label_end_stmt = label_stmts[i - 1]
                    break

                # If explicit return, this is the end
                if stmt.type == StatementType.RETURN:
                    label_end_stmt = stmt
                    break

                # If explicit jump, this is the end (no return)
                if stmt.type == StatementType.JUMP:
                    # No return edge needed for jumps
                    label_end_stmt = None
                    break

                # Last statement in file
                if i == len(label_stmts) - 1:
                    label_end_stmt = stmt

            # If we found an end statement and it's not a jump, add return edges
            if label_end_stmt and label_end_stmt.type != StatementType.JUMP:
                label_end_id = self._stmt_to_node_id.get(
                    (label_end_stmt.file, label_end_stmt.line)
                )

                if label_end_id:
                    # Create RETURN edges to each call site
                    for call_site_id in call_site_ids:
                        # Find the statement after the call site
                        call_site_node = self.cfg.nodes.get(call_site_id)
                        if not call_site_node:
                            continue

                        # Get all statements in the same file as call site
                        call_file_stmts = [
                            s for s in all_statements if s.file == call_site_node.file
                        ]
                        call_file_stmts.sort(key=lambda s: s.line)

                        # Find the statement after the call
                        return_target_stmt = None
                        for i, stmt in enumerate(call_file_stmts):
                            if stmt.line == call_site_node.line and i + 1 < len(
                                call_file_stmts
                            ):
                                return_target_stmt = call_file_stmts[i + 1]
                                break

                        if return_target_stmt:
                            return_target_id = self._stmt_to_node_id.get(
                                (return_target_stmt.file, return_target_stmt.line)
                            )
                            if return_target_id:
                                edge = CFGEdge(
                                    from_node=label_end_id,
                                    to_node=return_target_id,
                                    edge_type=EdgeType.RETURN,
                                    meta={
                                        "called_from": call_site_id,
                                        "label": label_name,
                                    },
                                )
                                self.cfg.add_edge(edge)

    def _gen_node_id(self) -> str:
        """Generate unique node ID"""
        self._node_counter += 1
        return f"s{self._node_counter}"  # 's' prefix for statement nodes
