"""
Phase 8 Finding Postprocessor

Applies rule configuration overrides after analysis:
- Global severity overrides
- Per-file/per-glob rule overrides
- Inline suppression comments
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# Valid severity levels
_VALID_SEVERITIES = {"CRITICAL", "ERROR", "WARNING", "INFO", "STYLE", "OFF"}

# Inline suppression patterns
_DISABLE_FILE = re.compile(r"#\s*branchpy-disable-file\s+(.+)", re.IGNORECASE)
_DISABLE_NEXT = re.compile(r"#\s*branchpy-disable-next-line\s+(.+)", re.IGNORECASE)
_DISABLE_LINE = re.compile(r"#\s*branchpy-disable\s+(.+)", re.IGNORECASE)
_ENABLE_LINE = re.compile(r"#\s*branchpy-enable\s+(.+)", re.IGNORECASE)


def apply_overrides(
    findings: List[Dict[str, Any]],
    rules_cfg: Dict[str, Any],
    overrides_cfg: Optional[List[Dict[str, Any]]] = None,
    file_contents: Optional[Dict[str, str]] = None,
    project_root: str = ".",
) -> List[Dict[str, Any]]:
    """
    Apply rule configuration overrides to findings.

    Applies in order:
    1. Global rule severity overrides
    2. Per-file/glob overrides
    3. Inline suppression comments

    Args:
        findings: List of finding dicts
        rules_cfg: Global rules configuration
        overrides_cfg: Per-file override rules
        file_contents: Map of file paths to content (for inline suppression)
        project_root: Project root path for glob matching

    Returns:
        Filtered and modified findings list
    """
    # Build global severity overrides
    global_overrides = _build_global_overrides(rules_cfg or {})

    # Parse inline suppressions
    inline_suppressions = {}
    if file_contents:
        inline_suppressions = _parse_inline_suppressions(file_contents)

    out = []
    for f in findings:
        rid = f.get("ruleId", "")
        if not rid:
            continue

        file_path = f.get("location", {}).get("file", "")
        line = f.get("location", {}).get("startLine", 1)

        # Check inline suppressions first (highest precedence)
        if _is_suppressed_inline(rid, file_path, line, inline_suppressions):
            continue

        # Apply per-file overrides
        file_override = _get_file_override(
            file_path, rid, overrides_cfg or [], project_root
        )
        if file_override == "OFF":
            continue
        if file_override in _VALID_SEVERITIES and file_override != "OFF":
            f = dict(f)
            f["severity"] = file_override
            out.append(f)
            continue

        # Apply global overrides
        global_sev = global_overrides.get(rid)
        if global_sev == "OFF":
            continue
        if global_sev in _VALID_SEVERITIES and global_sev != "OFF":
            f = dict(f)
            f["severity"] = global_sev

        out.append(f)

    return out


def _build_global_overrides(rules_cfg: Dict[str, Any]) -> Dict[str, str]:
    """Extract severity overrides from global rules config."""
    overrides = {}
    for rid, rc in rules_cfg.items():
        if rc == "OFF":
            overrides[rid] = "OFF"
        elif isinstance(rc, dict) and rc.get("severity") in _VALID_SEVERITIES:
            overrides[rid] = rc["severity"]
    return overrides


def _get_file_override(
    file_path: str, rule_id: str, overrides: List[Dict[str, Any]], project_root: str
) -> Optional[str]:
    """
    Get per-file override for a rule.

    Returns severity override or None.
    """
    from fnmatch import fnmatch

    # Normalize path
    try:
        rel_path = Path(file_path).relative_to(project_root).as_posix()
    except ValueError:
        rel_path = file_path

    # Check each override (last match wins)
    result = None
    for override in overrides:
        patterns = override.get("files", [])
        if not isinstance(patterns, list):
            patterns = [patterns]

        # Check if file matches any pattern
        matches = any(fnmatch(rel_path, pattern) for pattern in patterns)
        if not matches:
            continue

        # Get rule override
        rule_overrides = override.get("rules", {})
        rule_cfg = rule_overrides.get(rule_id)

        if rule_cfg == "OFF":
            result = "OFF"
        elif rule_cfg is False:
            result = "OFF"
        elif isinstance(rule_cfg, dict):
            if rule_cfg.get("enabled") is False:
                result = "OFF"
            elif rule_cfg.get("severity") in _VALID_SEVERITIES:
                result = rule_cfg["severity"]

    return result


def _parse_inline_suppressions(file_contents: Dict[str, str]) -> Dict[str, Any]:
    """
    Parse inline suppression comments from file contents.

    Returns:
        {
            file_path: {
                "disabled_file": set(rule_ids),
                "disabled_lines": {line_num: set(rule_ids)},
                "disabled_next": {line_num: set(rule_ids)}
            }
        }
    """
    suppressions = {}

    for file_path, content in file_contents.items():
        file_info = {"disabled_file": set(), "disabled_lines": {}, "disabled_next": {}}

        currently_disabled = set()
        lines = content.split("\n")

        for line_num, line in enumerate(lines, start=1):
            # File-level disable
            m = _DISABLE_FILE.search(line)
            if m:
                rules = _parse_rule_list(m.group(1))
                file_info["disabled_file"].update(rules)

            # Next-line disable
            m = _DISABLE_NEXT.search(line)
            if m:
                rules = _parse_rule_list(m.group(1))
                file_info["disabled_next"][line_num + 1] = rules

            # Line disable (affects subsequent lines including current)
            m = _DISABLE_LINE.search(line)
            if m:
                rules = _parse_rule_list(m.group(1))
                currently_disabled.update(rules)

            # Store current state BEFORE processing enable
            # (so the line with disable is itself disabled)
            if currently_disabled:
                file_info["disabled_lines"][line_num] = currently_disabled.copy()

            # Line enable (affects subsequent lines, not current)
            m = _ENABLE_LINE.search(line)
            if m:
                rules = _parse_rule_list(m.group(1))
                currently_disabled.difference_update(rules)

        suppressions[file_path] = file_info

    return suppressions


def _parse_rule_list(rule_str: str) -> Set[str]:
    """Parse comma-separated rule IDs from suppression comment."""
    rules = set()
    for r in rule_str.split(","):
        r = r.strip()
        if r:
            rules.add(r)
    return rules


def _is_suppressed_inline(
    rule_id: str, file_path: str, line: int, suppressions: Dict[str, Any]
) -> bool:
    """Check if a finding is suppressed by inline comments."""
    file_info = suppressions.get(file_path)
    if not file_info:
        return False

    # File-level suppression
    if rule_id in file_info["disabled_file"]:
        return True

    # Next-line suppression
    next_line_rules = file_info["disabled_next"].get(line, set())
    if rule_id in next_line_rules:
        return True

    # Line-level suppression
    line_rules = file_info["disabled_lines"].get(line, set())
    if rule_id in line_rules:
        return True

    return False
