"""
Job queue models and management for SAE async API.
"""

from __future__ import annotations

import secrets
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class JobStatus(Enum):
    """Job lifecycle states."""

    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELED = "canceled"


class JobType(Enum):
    """Types of analysis jobs."""

    ANALYZE_DEEP = "analyze_deep"
    ANALYZE_QUICK = "analyze_quick"
    EXPORT_CFG = "export_cfg"
    VALIDATE = "validate"


@dataclass
class JobProgress:
    """Progress tracking for analysis phases."""

    percent: int = 0
    phase: str = "queued"
    message: str = ""

    # Progress milestones (from SAE_INTERFACES.md)
    # 10%: Indexing complete
    # 35%: Parsing complete
    # 65%: CFG construction complete
    # 85%: Validation complete
    # 100%: Export complete


@dataclass
class JobArtifact:
    """Output artifact from completed job."""

    name: str
    path: str
    size_bytes: int = 0


@dataclass
class Job:
    """
    Represents an async analysis job.

    Attributes:
        id: Unique job identifier (e.g., "j_8f2a9b3c")
        type: Job type (analyze_deep, etc.)
        status: Current job status
        args: Job arguments (project path, flags, etc.)
        created_at: Unix timestamp (seconds)
        started_at: Unix timestamp when job started running
        completed_at: Unix timestamp when job finished
        progress: Current progress state
        error: Error message if failed
        artifacts: List of generated files
    """

    id: str
    type: JobType
    status: JobStatus
    args: dict[str, Any]
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    progress: JobProgress = field(default_factory=JobProgress)
    error: Optional[str] = None
    artifacts: list[JobArtifact] = field(default_factory=list)

    @staticmethod
    def generate_id() -> str:
        """Generate unique job ID with 'j_' prefix."""
        return f"j_{secrets.token_hex(4)}"

    def to_dict(self, include_artifacts: bool = False) -> dict[str, Any]:
        """
        Serialize job to JSON-compatible dict.

        Args:
            include_artifacts: Whether to include artifact details
        """
        data = {
            "id": self.id,
            "type": self.type.value,
            "status": self.status.value,
            "args": self.args,
            "created_at": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.created_at)
            ),
            "progress": self.progress.percent,
        }

        if self.started_at is not None:
            data["started_at"] = time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.started_at)
            )

        if self.completed_at is not None:
            data["completed_at"] = time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.completed_at)
            )
            data["duration_ms"] = int(
                (self.completed_at - (self.started_at or self.created_at)) * 1000
            )

        if self.error:
            data["error"] = self.error

        if include_artifacts and self.artifacts:
            data["artifacts"] = [
                {"name": a.name, "path": a.path, "size_bytes": a.size_bytes}
                for a in self.artifacts
            ]

        return data

    def update_progress(self, percent: int, phase: str, message: str = "") -> None:
        """Update job progress (thread-safe update)."""
        self.progress.percent = percent
        self.progress.phase = phase
        self.progress.message = message


class JobQueue:
    """
    Thread-safe job queue manager.

    Stores jobs in memory with basic CRUD operations.
    Not persistent across restarts (acceptable for v0.7.0-alpha).
    """

    def __init__(self):
        self._jobs: dict[str, Job] = {}
        self._lock = __import__(
            "threading"
        ).RLock()  # Re-entrant to avoid self-deadlocks

    def __repr__(self) -> str:
        """Non-blocking repr for pytest/debugging."""
        return f"<JobQueue jobs={len(self._jobs)}>"

    def create(self, job_type: JobType, args: dict[str, Any]) -> Job:
        """
        Create and enqueue a new job.

        Args:
            job_type: Type of analysis job
            args: Job-specific arguments

        Returns:
            Created job instance
        """
        with self._lock:
            job = Job(
                id=Job.generate_id(),
                type=job_type,
                status=JobStatus.QUEUED,
                args=args,
            )
            self._jobs[job.id] = job
            return job

    def get(self, job_id: str) -> Optional[Job]:
        """Retrieve job by ID."""
        with self._lock:
            return self._jobs.get(job_id)

    def update_status(self, job_id: str, status: JobStatus) -> None:
        """Update job status (thread-safe)."""
        with self._lock:
            if job_id in self._jobs:
                job = self._jobs[job_id]
                job.status = status

                if status == JobStatus.RUNNING and job.started_at is None:
                    job.started_at = time.time()

                if status in (
                    JobStatus.SUCCEEDED,
                    JobStatus.FAILED,
                    JobStatus.CANCELED,
                ):
                    job.completed_at = time.time()

    def update_progress(
        self, job_id: str, percent: int, phase: str, message: str = ""
    ) -> None:
        """Update job progress (thread-safe)."""
        with self._lock:
            if job_id in self._jobs:
                self._jobs[job_id].update_progress(percent, phase, message)

    def set_error(self, job_id: str, error: str) -> None:
        """Set error message and mark job as failed."""
        with self._lock:
            if job_id in self._jobs:
                self._jobs[job_id].error = error
                self.update_status(job_id, JobStatus.FAILED)

    def add_artifact(self, job_id: str, artifact: JobArtifact) -> None:
        """Add output artifact to job."""
        with self._lock:
            if job_id in self._jobs:
                self._jobs[job_id].artifacts.append(artifact)

    def list_jobs(self, limit: int = 100) -> list[Job]:
        """List all jobs (most recent first)."""
        with self._lock:
            jobs = sorted(self._jobs.values(), key=lambda j: j.created_at, reverse=True)
            return jobs[:limit]

    def cancel(self, job_id: str) -> bool:
        """
        Cancel a job (if not already completed).

        Returns:
            True if job was canceled, False if not found or already completed
        """
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return False

            if job.status in (
                JobStatus.SUCCEEDED,
                JobStatus.FAILED,
                JobStatus.CANCELED,
            ):
                return False  # Already finished

            job.status = JobStatus.CANCELED
            job.completed_at = time.time()
            return True

    def cleanup_old_jobs(self, max_age_seconds: int = 3600) -> int:
        """
        Remove jobs older than max_age_seconds.

        Returns:
            Number of jobs removed
        """
        now = time.time()
        with self._lock:
            to_remove = [
                job_id
                for job_id, job in self._jobs.items()
                if (job.completed_at or job.created_at) < now - max_age_seconds
            ]
            for job_id in to_remove:
                del self._jobs[job_id]
            return len(to_remove)
