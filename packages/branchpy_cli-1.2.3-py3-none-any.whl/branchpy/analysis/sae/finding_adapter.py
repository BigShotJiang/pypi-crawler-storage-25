"""
Phase 8 Report Utilities

Adapters for converting Phase 8 dataclasses to JSON-serializable dicts.
Ensures deterministic output with sorted keys.
"""

from __future__ import annotations

from typing import Any, Dict

from branchpy.rules.v2.types import Finding, Fix, FixEdit


def finding_to_dict(f: Finding) -> Dict[str, Any]:
    """
    Convert Finding dataclass to JSON-serializable dict.

    Args:
        f: Finding instance

    Returns:
        Dict with camelCase keys matching schema
    """
    d: Dict[str, Any] = {
        "id": f.id,
        "ruleId": f.rule_id,
        "severity": (
            f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        ),
        "message": f.message,
        "location": {
            "file": f.location.file,
            "startLine": f.location.start_line,
        },
    }

    # Optional location fields
    if f.location.start_col > 1:
        d["location"]["startCol"] = f.location.start_col
    if f.location.end_line is not None:
        d["location"]["endLine"] = f.location.end_line
    if f.location.end_col is not None:
        d["location"]["endCol"] = f.location.end_col

    # Optional finding fields
    if f.docs_url:
        d["docsUrl"] = f.docs_url
    if f.related:
        d["related"] = list(f.related)
    if f.category:
        d["category"] = f.category
    if f.tags:
        d["tags"] = sorted(f.tags)  # Sorted for determinism
    if f.fingerprint:
        d["fingerprint"] = f.fingerprint
    if f.metadata:
        d["metadata"] = dict(f.metadata)
    if f.fix:
        d["fix"] = fix_to_dict(f.fix)

    return d


def fix_to_dict(fx: Fix) -> Dict[str, Any]:
    """Convert Fix to JSON-serializable dict."""
    return {
        "title": fx.title,
        "edits": [edit_to_dict(e) for e in (fx.edits or [])],
        "isSafe": bool(fx.is_safe),
    }


def edit_to_dict(e: FixEdit) -> Dict[str, Any]:
    """Convert FixEdit to JSON-serializable dict."""
    return {
        "file": e.file,
        "startLine": e.start_line,
        "startCol": e.start_col,
        "endLine": e.end_line,
        "endCol": e.end_col,
        "replacement": e.replacement,
    }
