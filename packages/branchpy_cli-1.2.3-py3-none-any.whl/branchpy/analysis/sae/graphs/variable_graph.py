"""Variable Graph Data Model for Phase 4 - Variables & Game State Analysis

This module defines the core data structures for representing variable usage,
definitions, scopes, and control flow facts across a Ren'Py project.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Tuple

# Type aliases for clarity
Kind = Literal["local", "global", "persistent", "builtin", "unknown"]
Ctx = Literal["read", "write", "cond", "call", "mutate"]


@dataclass
class Symbol:
    """Represents a variable/symbol in the program.

    Attributes:
        name: Variable name (e.g., "score", "persistent.save_version")
        kind: Classification of the variable (local, global, persistent, etc.)
        decl_file: File where first declared/defined (if known)
        decl_line: Line number of first declaration (if known)
    """

    name: str
    kind: Kind
    decl_file: Optional[str] = None
    decl_line: Optional[int] = None

    def __hash__(self) -> int:
        return hash((self.name, self.kind))


@dataclass
class Scope:
    """Represents a lexical scope in the program.

    Attributes:
        id: Unique identifier (e.g., "label:start", "function:calculate_score")
        parent: Parent scope ID (for nested scopes)
        type: Kind of scope
    """

    id: str
    parent: Optional[str]
    type: Literal["global", "label", "block", "function"]

    def __hash__(self) -> int:
        return hash(self.id)


@dataclass
class Assign:
    """Represents a variable assignment/definition.

    Attributes:
        symbol: Variable name being assigned
        scope: Scope ID where assignment occurs
        file: Source file path
        line: Line number
        expr: Right-hand side expression (as string)
        type_domain: Abstract type domain tag (e.g., "int", "str", "bool", "object")
        delta: Numeric delta if detectable (for += / -= operations)
    """

    symbol: str
    scope: str
    file: str
    line: int
    expr: str
    type_domain: str = "unknown"
    delta: Optional[float] = None

    def __hash__(self) -> int:
        return hash((self.symbol, self.file, self.line))


@dataclass
class Use:
    """Represents a variable use/reference.

    Attributes:
        symbol: Variable name being used
        scope: Scope ID where use occurs
        file: Source file path
        line: Line number
        ctx: Context of use (read, write, condition, call, mutate)
    """

    symbol: str
    scope: str
    file: str
    line: int
    ctx: Ctx

    def __hash__(self) -> int:
        return hash((self.symbol, self.file, self.line, self.ctx))


@dataclass
class Fact:
    """Represents a path condition fact from control flow analysis.

    Attributes:
        expr: Expression representing the fact (e.g., "flag == True", "score > 10")
    """

    expr: str

    def __hash__(self) -> int:
        return hash(self.expr)


@dataclass
class VariableGraph:
    """Complete graph representation of variable usage and control flow.

    This is the central data structure built by the variable analyzer,
    containing all symbols, scopes, assignments, uses, and path facts
    extracted from the project.

    Attributes:
        symbols: Map from symbol name to Symbol object
        scopes: Map from scope ID to Scope object
        assigns: List of all variable assignments
        uses: List of all variable uses
        facts_by_edge: Map from CFG edge to list of path condition facts
    """

    symbols: Dict[str, Symbol] = field(default_factory=dict)
    scopes: Dict[str, Scope] = field(default_factory=dict)
    assigns: List[Assign] = field(default_factory=list)
    uses: List[Use] = field(default_factory=list)
    facts_by_edge: Dict[Tuple[str, str], List[Fact]] = field(default_factory=dict)

    def add_symbol(self, symbol: Symbol) -> None:
        """Add or update a symbol in the graph."""
        if symbol.name not in self.symbols:
            self.symbols[symbol.name] = symbol
        else:
            # Update declaration info if we have better data
            existing = self.symbols[symbol.name]
            if symbol.decl_file and not existing.decl_file:
                existing.decl_file = symbol.decl_file
                existing.decl_line = symbol.decl_line

    def add_scope(self, scope: Scope) -> None:
        """Add a scope to the graph."""
        self.scopes[scope.id] = scope

    def add_assign(self, assign: Assign) -> None:
        """Add an assignment to the graph."""
        self.assigns.append(assign)
        # Ensure the symbol exists
        if assign.symbol not in self.symbols:
            kind = self._infer_kind(assign.symbol)
            self.add_symbol(
                Symbol(
                    name=assign.symbol,
                    kind=kind,
                    decl_file=assign.file,
                    decl_line=assign.line,
                )
            )

    def add_use(self, use: Use) -> None:
        """Add a use to the graph."""
        self.uses.append(use)
        # Ensure the symbol exists
        if use.symbol not in self.symbols:
            kind = self._infer_kind(use.symbol)
            self.add_symbol(Symbol(name=use.symbol, kind=kind))

    def add_fact(self, edge: Tuple[str, str], fact: Fact) -> None:
        """Add a path condition fact for a CFG edge."""
        if edge not in self.facts_by_edge:
            self.facts_by_edge[edge] = []
        self.facts_by_edge[edge].append(fact)

    def get_assigns_for(self, symbol: str) -> List[Assign]:
        """Get all assignments for a specific symbol."""
        return [a for a in self.assigns if a.symbol == symbol]

    def get_uses_for(self, symbol: str) -> List[Use]:
        """Get all uses for a specific symbol."""
        return [u for u in self.uses if u.symbol == symbol]

    def get_symbols_by_kind(self, kind: Kind) -> List[Symbol]:
        """Get all symbols of a specific kind."""
        return [s for s in self.symbols.values() if s.kind == kind]

    def _infer_kind(self, symbol_name: str) -> Kind:
        """Infer the kind of a symbol from its name."""
        if symbol_name.startswith("persistent."):
            return "persistent"
        elif symbol_name in {
            "config",
            "_preferences",
            "persistent",
            "store",
            "renpy",
            "gui",
            "build",
            "define",
            "_window_subtitle",
        }:
            return "builtin"
        # Simple heuristic: if it looks like a constant (UPPERCASE), treat as global
        elif symbol_name.isupper():
            return "global"
        else:
            # Default to local, will be refined during analysis
            return "local"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "symbols": {
                name: {
                    "kind": sym.kind,
                    "decl_file": sym.decl_file,
                    "decl_line": sym.decl_line,
                }
                for name, sym in self.symbols.items()
            },
            "scopes": {
                sid: {"parent": scope.parent, "type": scope.type}
                for sid, scope in self.scopes.items()
            },
            "assigns": [
                {
                    "symbol": a.symbol,
                    "scope": a.scope,
                    "file": a.file,
                    "line": a.line,
                    "expr": a.expr,
                    "type_domain": a.type_domain,
                    "delta": a.delta,
                }
                for a in self.assigns
            ],
            "uses": [
                {
                    "symbol": u.symbol,
                    "scope": u.scope,
                    "file": u.file,
                    "line": u.line,
                    "ctx": u.ctx,
                }
                for u in self.uses
            ],
            "facts": {
                f"{edge[0]}->{edge[1]}": [{"expr": fact.expr} for fact in facts]
                for edge, facts in self.facts_by_edge.items()
            },
        }
