"""
Worker pool for executing SAE analysis jobs asynchronously.
"""

from __future__ import annotations

import logging
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from branchpy.analysis.sae.cfg_builder import CFGBuilder

# Phase 8 custom rules imports
from branchpy.analysis.sae.custom_rule_registry import CustomRuleRegistry
from branchpy.analysis.sae.exporters.flowgraph import FlowgraphExporter
from branchpy.analysis.sae.exporters.unified_report import UnifiedReportExporter

# Image validation imports
from branchpy.analysis.sae.image_validator import ImageValidator
from branchpy.analysis.sae.indexer import Indexer
from branchpy.analysis.sae.job import Job, JobArtifact, JobStatus, JobType
from branchpy.analysis.sae.registry import get_job_queue
from branchpy.analysis.sae.validators.tier1 import Tier1Validator

# L10n imports
from branchpy.l10n import extract_strings, generate_l10n_findings
from branchpy.rules.v2.api import BranchPyRule
from branchpy.rules.v2.context import ProjectSnapshot, RuleContext

# Phase 8 imports
from branchpy.rules.v2.loader import discover_rules

logger = logging.getLogger(__name__)


def _should_run_rule(rule: BranchPyRule, project_engine: str) -> bool:
    """
    Check if a rule should run on a project based on engine targeting.

    Rules with engine_targets = ["*"] run on all projects.
    Otherwise, project_engine must be in the rule's engine_targets list.

    Args:
        rule: Rule to check
        project_engine: Project's engine identifier (e.g., "renpy", "unity")

    Returns:
        True if rule should run, False if filtered out

    Examples:
        >>> rule.engine_targets = ["*"]
        >>> _should_run_rule(rule, "renpy")
        True
        >>> rule.engine_targets = ["unity"]
        >>> _should_run_rule(rule, "renpy")
        False
    """
    targets = rule.engine_targets
    return "*" in targets or project_engine in targets


class WorkerPool:
    """
    Thread pool for executing SAE analysis jobs.

    Each job runs in a separate thread with progress callbacks.
    """

    def __init__(self, max_workers: int = 4):
        """
        Initialize worker pool.

        Args:
            max_workers: Maximum number of concurrent jobs
        """
        self._executor = ThreadPoolExecutor(
            max_workers=max_workers, thread_name_prefix="sae-worker"
        )
        self._artifacts_dir = Path(".branchpy/artifacts")
        self._artifacts_dir.mkdir(parents=True, exist_ok=True)

    def submit_job(self, job_id: str) -> None:
        """
        Submit a job for async execution.

        Args:
            job_id: Job ID to execute
        """
        self._executor.submit(self._run_job, job_id)

    def _run_job(self, job_id: str) -> None:
        """
        Execute a job (runs in worker thread).

        Args:
            job_id: Job ID to execute
        """
        queue = get_job_queue()
        job = queue.get(job_id)

        if not job:
            logger.error(f"Job {job_id} not found in queue")
            return

        # Mark as running
        queue.update_status(job_id, JobStatus.RUNNING)
        queue.update_progress(job_id, 0, "starting", "Initializing analysis...")

        try:
            if job.type == JobType.ANALYZE_DEEP:
                self._run_analyze_deep(job)
            elif job.type == JobType.EXPORT_CFG:
                self._run_export_cfg(job)
            elif job.type == JobType.VALIDATE:
                self._run_validate(job)
            else:
                raise ValueError(f"Unsupported job type: {job.type}")

            # Mark as succeeded
            queue.update_status(job_id, JobStatus.SUCCEEDED)
            queue.update_progress(job_id, 100, "completed", "Analysis complete")

        except Exception as e:
            logger.error(f"Job {job_id} failed: {e}\n{traceback.format_exc()}")
            queue.set_error(job_id, f"{type(e).__name__}: {str(e)}")

    def _run_analyze_deep(self, job: Job) -> None:
        """
        Execute deep analysis job.

        Progress milestones:
        - 10%: Indexing complete
        - 35%: Parsing complete (not implemented yet, using index as proxy)
        - 65%: CFG construction complete
        - 85%: Validation complete
        - 100%: Export complete
        """
        queue = get_job_queue()
        project_path = job.args.get("project")
        export_cfg = job.args.get("export_cfg", True)
        out_dir = job.args.get("out", "reports")

        if not project_path:
            raise ValueError("Missing required argument: project")

        project_root = Path(project_path)
        if not project_root.exists():
            raise FileNotFoundError(f"Project path not found: {project_path}")

        # Create job-specific artifact directory
        artifact_dir = self._artifacts_dir / job.id
        artifact_dir.mkdir(exist_ok=True)

        # Phase 1: Index (0% → 10%)
        queue.update_progress(job.id, 0, "indexing", "Scanning project files...")
        indexer = Indexer(str(project_root))
        index = indexer.build_index()
        queue.update_progress(
            job.id, 10, "indexing", f"Indexed {len(index.labels)} labels"
        )

        # Phase 2: Parse (10% → 35%)
        # NOTE: Currently we don't have a separate parsing phase - indexing extracts everything
        # This milestone is reserved for future when we add AST-level parsing
        queue.update_progress(job.id, 35, "parsing", "Parsing complete")

        # Phase 3: Build CFG (35% → 65%)
        queue.update_progress(job.id, 35, "cfg", "Building control-flow graph...")
        builder = CFGBuilder(index)
        cfg = builder.build()
        queue.update_progress(
            job.id, 65, "cfg", f"Built CFG with {len(cfg.nodes)} nodes"
        )

        # Phase 4: Validate (65% → 85%)
        queue.update_progress(job.id, 65, "validation", "Running Tier-1 validators...")
        validator = Tier1Validator(str(project_root), index, cfg)
        issues = validator.validate()
        error_count = sum(1 for i in issues if i.severity.value == "error")
        warning_count = sum(1 for i in issues if i.severity.value == "warning")
        queue.update_progress(
            job.id,
            75,
            "validation",
            f"Found {error_count} errors, {warning_count} warnings",
        )

        # Phase 4.5: Phase 8 Custom Rules (75% → 85%)
        queue.update_progress(job.id, 75, "rules", "Running custom rules...")
        phase8_findings = []
        rules_config = job.args.get("rulesConfig", {})  # Define outside try block
        try:
            # Get active profile (from config or default)
            active_profile = rules_config.get("activeProfile", "default")

            # Build ProjectSnapshot from index and cfg
            # Extract file paths from IndexEntry objects for images/audio/videos/fonts
            images_dict = getattr(index, "images", {})
            audio_dict = getattr(index, "audio", {})
            videos_dict = getattr(index, "videos", {})
            fonts_dict = getattr(index, "fonts", {})

            snapshot = ProjectSnapshot(
                files=[str(f) for f in index.files] if hasattr(index, "files") else [],
                images={
                    name: (entry.file if hasattr(entry, "file") else str(entry))
                    for name, entry in images_dict.items()
                },
                audio={
                    name: (entry.file if hasattr(entry, "file") else str(entry))
                    for name, entry in audio_dict.items()
                },
                videos={
                    name: (entry.file if hasattr(entry, "file") else str(entry))
                    for name, entry in videos_dict.items()
                },
                fonts={
                    name: (entry.file if hasattr(entry, "file") else str(entry))
                    for name, entry in fonts_dict.items()
                },
                labels={
                    name: {"file": label.file, "line": label.line}
                    for name, label in index.labels.items()
                },
                variables=getattr(index, "variables", {}),
                cfg=cfg,
                project_root=str(project_root),
                renpy_version=getattr(index, "renpy_version", None),
            )

            # Discover and run rules with active profile
            registry = discover_rules(rules_config, active_profile)
            ctx = RuleContext(snapshot, rules_config)

            for rule in registry.all():
                try:
                    # Engine filtering: skip if project engine not in rule's targets
                    if not _should_run_rule(rule, snapshot.engine):
                        logger.debug(
                            f"Skipping rule {rule.rule_id} (engine filter: {snapshot.engine} not in {rule.engine_targets})"
                        )
                        continue

                    for finding in rule.analyze(ctx):
                        phase8_findings.append(finding)
                except Exception as e:
                    logger.warning(f"Rule {rule.rule_id} failed: {e}")
                    continue

            logger.info(f"Phase 8 rules generated {len(phase8_findings)} findings")
        except Exception as e:
            logger.warning(f"Phase 8 custom rules failed (non-fatal): {e}")
            # Continue analysis - never fail due to plugin errors

        # Phase 4.6: L10n Analysis (85%)
        queue.update_progress(job.id, 85, "l10n", "Analyzing translations...")
        try:
            # Extract L10n configuration from rules config
            l10n_config = rules_config.get("l10n", {})
            languages = l10n_config.get("languages", [])
            required_langs = set(l10n_config.get("required", []))

            # Only run L10n if languages are configured
            if languages:
                l10n_index = extract_strings(project_root)
                l10n_findings = generate_l10n_findings(
                    l10n_index, languages, required_langs=list(required_langs)
                )
                phase8_findings.extend(l10n_findings)
                logger.info(
                    f"L10n analysis generated {len(l10n_findings)} findings for {len(languages)} languages"
                )
            else:
                logger.debug("L10n analysis skipped (no languages configured)")
        except Exception as e:
            logger.warning(f"L10n analysis failed (non-fatal): {e}")
            # Continue analysis - never fail due to L10n errors

        queue.update_progress(
            job.id,
            85,
            "validation",
            f"Validation complete ({len(phase8_findings)} custom rule findings)",
        )

        # Phase 4.7: Image Validation (85% → 87%)
        queue.update_progress(job.id, 85, "images", "Validating image references...")
        image_validation = None
        try:
            # Check if image validation is enabled (default: True)
            rules_config = job.args.get("rulesConfig", {})
            validate_images = rules_config.get("validate_images", True)

            if validate_images:
                # Build label data for image validator - extract content from source files
                label_data = {}
                for label_name, label_info in index.labels.items():
                    try:
                        # Read the source file and extract label content
                        file_path = project_root / label_info.file
                        if file_path.exists():
                            content = file_path.read_text(
                                encoding="utf-8", errors="ignore"
                            )

                            # Extract label body (simple approach: from label definition to next label or end)
                            import re

                            label_pattern = re.compile(
                                rf"^\s*label\s+{re.escape(label_name)}\s*:(.*?)(?=^\s*label\s+|\Z)",
                                re.MULTILINE | re.DOTALL,
                            )
                            match = label_pattern.search(content)
                            label_content = match.group(1) if match else ""

                            label_data[label_name] = {
                                "content": label_content,
                                "file": label_info.file,
                                "line": label_info.line,
                            }
                    except Exception as e:
                        logger.warning(
                            f"Failed to extract content for label {label_name}: {e}"
                        )
                        continue

                validator_img = ImageValidator(str(project_root))
                image_validation = validator_img.validate_project(label_data)

                total_missing = image_validation.get("totals", {}).get(
                    "missing_images", 0
                )
                total_placeholders = image_validation.get("totals", {}).get(
                    "placeholders", 0
                )

                queue.update_progress(
                    job.id,
                    87,
                    "images",
                    f"Image validation complete ({total_missing} missing, {total_placeholders} placeholders)",
                )
                logger.info(
                    f"Image validation: {total_missing} missing, {total_placeholders} placeholders"
                )
            else:
                queue.update_progress(job.id, 87, "images", "Image validation disabled")
                logger.debug("Image validation skipped (disabled in config)")
        except Exception as e:
            logger.warning(f"Image validation failed (non-fatal): {e}")
            queue.update_progress(
                job.id, 87, "images", "Image validation skipped due to error"
            )

        # Phase 5: Custom Rules (87% → 90%)
        queue.update_progress(
            job.id, 85, "custom_rules", "Running custom validation rules..."
        )
        custom_violations = []
        try:
            # Check for custom rules file
            custom_rules_path = project_root / ".branchpy" / "rules_custom.yml"
            if custom_rules_path.exists():
                # Load custom rules
                registry = CustomRuleRegistry()
                loaded_count = registry.load_from_file(custom_rules_path)
                logger.info(
                    f"Loaded {loaded_count} custom rules from {custom_rules_path}"
                )

                # Validate all project files
                for rpy_file in project_root.glob("game/**/*.rpy"):
                    try:
                        file_violations = registry.validate_file(rpy_file)
                        custom_violations.extend(file_violations)
                    except Exception as e:
                        logger.warning(
                            f"Custom rule validation failed for {rpy_file}: {e}"
                        )
                        continue

                logger.info(
                    f"Custom rules generated {len(custom_violations)} violations"
                )
                queue.update_progress(
                    job.id,
                    90,
                    "custom_rules",
                    f"Found {len(custom_violations)} custom rule violations",
                )
            else:
                logger.debug("No custom rules file found, skipping custom validation")
                queue.update_progress(
                    job.id, 90, "custom_rules", "No custom rules configured"
                )
        except Exception as e:
            logger.warning(f"Custom rules validation failed (non-fatal): {e}")
            queue.update_progress(
                job.id, 90, "custom_rules", "Custom rules skipped due to error"
            )

        # Phase 6: Export (90% → 100%)
        queue.update_progress(job.id, 90, "export", "Generating artifacts...")

        # Extract metrics from validator
        dialogue_metrics = getattr(validator, "dialogue_metrics", None)
        variable_metrics = getattr(validator, "variable_metrics", None)
        locale_metrics = getattr(validator, "locale_metrics", None)

        # Export unified report (always)
        report_exporter = UnifiedReportExporter(
            cfg,
            issues,
            str(project_root),
            dialogue_metrics=dialogue_metrics,
            variable_metrics=variable_metrics,
            phase8_findings=phase8_findings,  # Add Phase 8 findings
            locale_metrics=locale_metrics,  # Add Phase 7 locale metrics (v0.7.7)
            custom_violations=custom_violations,  # Add custom rule violations (v0.7.8)
            image_validation=image_validation,  # Add image validation results
        )
        report_path = artifact_dir / "unified_report.json"
        report_exporter.export(str(report_path))
        queue.add_artifact(
            job.id,
            JobArtifact(
                name="unified_report.json",
                path=f"/.branchpy/artifacts/{job.id}/unified_report.json",
                size_bytes=report_path.stat().st_size,
            ),
        )

        # Export flowgraph (if requested)
        if export_cfg:
            flowgraph_exporter = FlowgraphExporter(cfg, str(project_root))
            flowgraph_path = artifact_dir / "flowgraph.json"
            flowgraph_exporter.export(str(flowgraph_path))
            queue.add_artifact(
                job.id,
                JobArtifact(
                    name="flowgraph.json",
                    path=f"/.branchpy/artifacts/{job.id}/flowgraph.json",
                    size_bytes=flowgraph_path.stat().st_size,
                ),
            )

        queue.update_progress(job.id, 100, "export", "All artifacts generated")

    def _run_export_cfg(self, job: Job) -> None:
        """
        Execute CFG export job (no validation).
        """
        queue = get_job_queue()
        project_path = job.args.get("project")

        if not project_path:
            raise ValueError("Missing required argument: project")

        project_root = Path(project_path)
        artifact_dir = self._artifacts_dir / job.id
        artifact_dir.mkdir(exist_ok=True)

        # Index + CFG only
        queue.update_progress(job.id, 0, "indexing", "Scanning project...")
        indexer = Indexer(str(project_root))
        index = indexer.build_index()

        queue.update_progress(job.id, 50, "cfg", "Building CFG...")
        builder = CFGBuilder(index)
        cfg = builder.build()

        queue.update_progress(job.id, 90, "export", "Exporting flowgraph...")
        exporter = FlowgraphExporter(cfg, str(project_root))
        flowgraph_path = artifact_dir / "flowgraph.json"
        exporter.export(str(flowgraph_path))

        queue.add_artifact(
            job.id,
            JobArtifact(
                name="flowgraph.json",
                path=f"/artifacts/{job.id}/flowgraph.json",
                size_bytes=flowgraph_path.stat().st_size,
            ),
        )

    def _run_validate(self, job: Job) -> None:
        """
        Execute validation-only job (no CFG export).
        """
        queue = get_job_queue()
        project_path = job.args.get("project")

        if not project_path:
            raise ValueError("Missing required argument: project")

        project_root = Path(project_path)
        artifact_dir = self._artifacts_dir / job.id
        artifact_dir.mkdir(exist_ok=True)

        # Index + CFG + Validate
        queue.update_progress(job.id, 0, "indexing", "Scanning project...")
        indexer = Indexer(str(project_root))
        index = indexer.build_index()

        queue.update_progress(job.id, 30, "cfg", "Building CFG...")
        builder = CFGBuilder(index)
        cfg = builder.build()

        queue.update_progress(job.id, 60, "validation", "Running validators...")
        validator = Tier1Validator(str(project_root), index, cfg)
        issues = validator.validate()

        queue.update_progress(job.id, 90, "export", "Generating report...")
        exporter = UnifiedReportExporter(cfg, issues, str(project_root))
        report_path = artifact_dir / "unified_report.json"
        exporter.export(str(report_path))

        queue.add_artifact(
            job.id,
            JobArtifact(
                name="unified_report.json",
                path=f"/.branchpy/artifacts/{job.id}/unified_report.json",
                size_bytes=report_path.stat().st_size,
            ),
        )

    def shutdown(self, wait: bool = True) -> None:
        """
        Shutdown worker pool.

        Args:
            wait: If True, block until all jobs complete
        """
        self._executor.shutdown(wait=wait)
