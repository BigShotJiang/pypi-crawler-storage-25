"""
Image Validation Module

Detects and validates image references in Ren'Py scripts.
Identifies missing images and placeholder assets.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# Ren'Py image statement patterns
SHOW_PATTERN = re.compile(
    r"^\s*show\s+([a-zA-Z0-9_\s]+?)(?:\s+at\s+|\s+with\s+|\s*$)", re.MULTILINE
)
SCENE_PATTERN = re.compile(
    r"^\s*scene\s+([a-zA-Z0-9_\s]+?)(?:\s+with\s+|\s*$)", re.MULTILINE
)
IMAGE_DEF_PATTERN = re.compile(
    r'^\s*image\s+([a-zA-Z0-9_\s]+?)\s*=\s*["\']([^"\']+)["\']', re.MULTILINE
)

# Placeholder detection keywords
PLACEHOLDER_KEYWORDS = ["placeholder", "temp", "test", "dummy", "todo", "wip"]
PLACEHOLDER_DIRS = ["placeholder", "placeholders", "temp", "test"]

# Default Ren'Py images (don't validate as files)
RENPY_DEFAULT_IMAGES = {"black", "white", "text"}


@dataclass
class ImageReference:
    """Represents an image reference found in script"""

    reference: str  # Original reference (e.g., "bg bedroom")
    path: Optional[str] = None  # Resolved file path
    exists: bool = False
    is_placeholder: bool = False
    is_default: bool = False
    line: int = 0


@dataclass
class LabelImageSummary:
    """Summary of images for a single label"""

    total: int = 0
    existing: int = 0
    missing: int = 0
    placeholders: int = 0
    defaults: int = 0


class ImageValidator:
    """Validates image references in Ren'Py scripts"""

    def __init__(self, project_path: str):
        """
        Initialize image validator.

        Args:
            project_path: Root path of Ren'Py project
        """
        self.project_path = Path(project_path)
        self.game_dir = self.project_path / "game"
        self.images_dir = self.game_dir / "images"

        # Cache for validation results
        self._validation_cache: Dict[str, ImageReference] = {}

        # Build image definition mapping (image name -> file path)
        self._image_map: Dict[str, str] = {}
        self._build_image_map()

    def _build_image_map(self) -> None:
        """Build mapping of image names to file paths from image definitions"""
        if not self.game_dir.exists():
            return

        for rpy_file in self.game_dir.rglob("*.rpy"):
            try:
                content = rpy_file.read_text(encoding="utf-8", errors="ignore")
                for match in IMAGE_DEF_PATTERN.finditer(content):
                    image_name = match.group(1).strip()
                    image_path = match.group(2).strip()

                    # Resolve relative to game directory
                    if not os.path.isabs(image_path):
                        image_path = str(self.game_dir / image_path)

                    self._image_map[image_name] = image_path
            except Exception:
                continue

    def detect_images_in_label(
        self, label_name: str, content: str, file_path: str, start_line: int = 0
    ) -> List[ImageReference]:
        """
        Extract all image references from label content.

        Args:
            label_name: Name of the label
            content: Label body content
            file_path: Source file path
            start_line: Starting line number of label

        Returns:
            List of ImageReference objects
        """
        images: List[ImageReference] = []
        seen: Set[str] = set()  # Avoid duplicates

        # Split content into lines for line tracking
        lines = content.split("\n")

        # Detect show statements
        for line_idx, line in enumerate(lines):
            line_num = start_line + line_idx

            # Check for show statements
            show_match = SHOW_PATTERN.match(line)
            if show_match:
                img_ref = show_match.group(1).strip()
                if img_ref not in seen:
                    seen.add(img_ref)
                    validation = self._validate_image(img_ref)
                    validation.line = line_num
                    images.append(validation)

            # Check for scene statements
            scene_match = SCENE_PATTERN.match(line)
            if scene_match:
                img_ref = scene_match.group(1).strip()
                if img_ref not in seen:
                    seen.add(img_ref)
                    validation = self._validate_image(img_ref)
                    validation.line = line_num
                    images.append(validation)

        return images

    def _validate_image(self, image_ref: str) -> ImageReference:
        """
        Validate a single image reference (with caching).

        Args:
            image_ref: Image reference string (e.g., "bg bedroom")

        Returns:
            ImageReference with validation results
        """
        # Check cache
        if image_ref in self._validation_cache:
            return self._validation_cache[image_ref]

        result = ImageReference(reference=image_ref)

        # Check if it's a default Ren'Py image
        if image_ref.lower() in RENPY_DEFAULT_IMAGES:
            result.is_default = True
            result.exists = True
            self._validation_cache[image_ref] = result
            return result

        # Try to resolve image path
        resolved_path = self._resolve_image_path(image_ref)

        if resolved_path:
            result.path = resolved_path
            result.exists = os.path.exists(resolved_path)
            result.is_placeholder = self._is_placeholder(resolved_path)
        else:
            result.exists = False

        self._validation_cache[image_ref] = result
        return result

    def _resolve_image_path(self, image_ref: str) -> Optional[str]:
        """
        Resolve image reference to file path.

        Args:
            image_ref: Image reference (e.g., "bg bedroom")

        Returns:
            Absolute file path or None if not found
        """
        # Check explicit image definitions first
        if image_ref in self._image_map:
            return self._image_map[image_ref]

        # Try common Ren'Py conventions
        # 1. Direct filename in images/
        # 2. Replace spaces with underscores
        # 3. Try subdirectories based on prefix

        candidates = []

        # Convert "bg bedroom" -> "bg_bedroom"
        filename_base = image_ref.replace(" ", "_")

        # Try common extensions
        for ext in [".png", ".jpg", ".jpeg", ".webp"]:
            # Direct in images/
            candidates.append(self.images_dir / f"{filename_base}{ext}")

            # Try prefix as subdirectory (e.g., "bg bedroom" -> "images/bg/bedroom.png")
            parts = image_ref.split(maxsplit=1)
            if len(parts) == 2:
                prefix, name = parts
                name = name.replace(" ", "_")
                candidates.append(self.images_dir / prefix / f"{name}{ext}")
                candidates.append(self.images_dir / prefix / f"{filename_base}{ext}")

        # Return first existing candidate
        for candidate in candidates:
            if candidate.exists():
                return str(candidate)

        return None

    def _is_placeholder(self, file_path: str) -> bool:
        """
        Check if an image is a placeholder.

        Args:
            file_path: Path to image file

        Returns:
            True if image appears to be a placeholder
        """
        path = Path(file_path)
        filename_lower = path.stem.lower()

        # Check filename for placeholder keywords (whole word match to avoid false positives like "test" in "latest")
        if any(
            f"_{keyword}" in filename_lower or keyword in filename_lower.split("_")
            for keyword in PLACEHOLDER_KEYWORDS
        ):
            return True

        # Check if in placeholder directory (only check immediate parent, not full path)
        parent_name = path.parent.name.lower() if path.parent else ""
        if any(pdir == parent_name for pdir in PLACEHOLDER_DIRS):
            return True

        return False

    def get_label_summary(self, images: List[ImageReference]) -> LabelImageSummary:
        """
        Generate summary statistics for a label's images.

        Args:
            images: List of ImageReference objects

        Returns:
            LabelImageSummary with counts
        """
        summary = LabelImageSummary()
        summary.total = len(images)

        for img in images:
            if img.is_default:
                summary.defaults += 1
                summary.existing += 1  # Defaults count as existing
            elif img.exists:
                summary.existing += 1
                if img.is_placeholder:
                    summary.placeholders += 1
            else:
                summary.missing += 1

        return summary

    def validate_project(self, labels: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Validate all images across the project.

        Args:
            labels: Dictionary of label_name -> label_data
                    Each label_data should have 'content', 'file', 'line'

        Returns:
            Dictionary with image validation results
        """
        label_results = {}
        all_images: Set[str] = set()
        total_missing = 0
        total_placeholders = 0

        for label_name, label_data in labels.items():
            content = label_data.get("content", "")
            file_path = label_data.get("file", "")
            start_line = label_data.get("line", 0)

            images = self.detect_images_in_label(
                label_name, content, file_path, start_line
            )

            if not images:
                continue

            summary = self.get_label_summary(images)

            # Track unique images
            for img in images:
                if not img.is_default:
                    all_images.add(img.reference)

            total_missing += summary.missing
            total_placeholders += summary.placeholders

            label_results[label_name] = {
                "images": [
                    {
                        "reference": img.reference,
                        "path": img.path,
                        "exists": img.exists,
                        "is_placeholder": img.is_placeholder,
                        "is_default": img.is_default,
                        "line": img.line,
                    }
                    for img in images
                ],
                "summary": {
                    "total": summary.total,
                    "existing": summary.existing,
                    "missing": summary.missing,
                    "placeholders": summary.placeholders,
                    "defaults": summary.defaults,
                },
            }

        return {
            "labels": label_results,
            "totals": {
                "labels_with_images": len(label_results),
                "unique_images": len(all_images),
                "missing_images": total_missing,
                "placeholders": total_placeholders,
            },
        }
