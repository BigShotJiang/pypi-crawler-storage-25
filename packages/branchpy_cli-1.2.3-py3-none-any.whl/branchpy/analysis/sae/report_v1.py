"""
Phase 8 Report Generation (v1.0.0 Schema)

Deterministic JSON report generation for analyzer findings.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional


def emit_v1_report(
    findings: List[Dict[str, Any]],
    schema_version: str = "1.0.0",
    engine_version: Optional[str] = None,
    project_root: Optional[str] = None,
    renpy_version: Optional[str] = None,
    stats: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Generate a v1.0.0 schema-compliant analysis report.

    Args:
        findings: List of finding dicts
        schema_version: Schema version (default: 1.0.0)
        engine_version: BranchPy version
        project_root: Project root path
        renpy_version: Detected Ren'Py version
        stats: Analysis statistics

    Returns:
        Complete report dict (deterministically sorted)
    """
    report = {
        "schemaVersion": schema_version,
        "engineVersion": engine_version or _get_engine_version(),
        "createdAt": _utc_now(),
        "project": {
            "root": project_root or ".",
        },
        "stats": stats or {"files": 0, "labels": 0, "durationMs": 0},
        "findings": _sort_findings(findings),
    }

    # Optional project fields
    if renpy_version:
        report["project"]["renpyVersion"] = renpy_version

    return report


def _sort_findings(fs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Sort findings deterministically.

    Order: severity (CRITICAL first) → ruleId → file → line → id
    """

    def severity_order(sev: str) -> int:
        return {
            "CRITICAL": 0,
            "ERROR": 1,
            "WARNING": 2,
            "INFO": 3,
            "STYLE": 4,
        }.get(sev, 999)

    return sorted(
        fs,
        key=lambda f: (
            severity_order(f.get("severity", "WARNING")),
            f.get("ruleId", ""),
            f.get("location", {}).get("file", ""),
            f.get("location", {}).get("startLine", 0),
            f.get("id", ""),
        ),
    )


def _utc_now() -> str:
    """Get current UTC timestamp in ISO8601 format."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _get_engine_version() -> str:
    """Get BranchPy engine version."""
    try:
        from branchpy import VERSION

        return VERSION
    except ImportError:
        return "0.7.7"  # Fallback
