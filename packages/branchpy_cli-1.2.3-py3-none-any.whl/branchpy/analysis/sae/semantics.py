"""Semantic Function Catalog - Define behaviors of custom functions"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml  # type: ignore
except ImportError:
    yaml = None  # Optional dependency


class FunctionKind(Enum):
    """Types of function behaviors"""

    JUMP = "jump"  # Function performs a jump
    CALL = "call"  # Function performs a call
    RETURN = "return"  # Function returns/ends flow
    TRANSFORM = "transform"  # Function transforms data but maintains flow
    UNKNOWN = "unknown"  # Function behavior unknown


class TransformType(Enum):
    """Types of argument transformations"""

    PASSTHROUGH = "passthrough"  # arg passed as-is
    PREFIX = "prefix"  # prefix + arg
    SUFFIX = "suffix"  # arg + suffix
    FORMAT = "format"  # f-string or format() call
    CONCAT = "concat"  # multiple args concatenated


@dataclass
class FunctionSemantics:
    """Semantic definition of a function's behavior"""

    name: str
    module: str  # "*" for any module, or specific module name
    kind: FunctionKind
    arg_index: int = 0  # Which argument is the label/target
    transforms: Optional[List[Dict[str, Any]]] = None  # Transformation rules
    returns_value: bool = False
    description: str = ""

    def matches(self, func_name: str, module_name: Optional[str] = None) -> bool:
        """Check if this semantic matches the given function call"""
        # Check name match
        if self.name != func_name:
            # Also check full qualified name
            if module_name and f"{module_name}.{func_name}" != self.name:
                return False

        # Check module match
        if self.module != "*":
            if module_name != self.module:
                return False

        return True

    def apply_transform(
        self, arg_value: Any, context: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Apply transformation rules to argument value"""
        if not self.transforms:
            return arg_value

        result = arg_value
        for transform in self.transforms:
            transform_type = TransformType(transform.get("type", "passthrough"))

            if transform_type == TransformType.PASSTHROUGH:
                pass  # No transformation
            elif transform_type == TransformType.PREFIX:
                prefix = transform.get("value", "")
                if isinstance(result, str):
                    result = f"{prefix}{result}"
            elif transform_type == TransformType.SUFFIX:
                suffix = transform.get("value", "")
                if isinstance(result, str):
                    result = f"{result}{suffix}"
            elif transform_type == TransformType.CONCAT:
                parts = transform.get("parts", [])
                if context:
                    # Resolve variables from context
                    resolved_parts = []
                    for part in parts:
                        if isinstance(part, str) and part.startswith("$"):
                            var_name = part[1:]
                            resolved_parts.append(context.get(var_name, part))
                        else:
                            resolved_parts.append(part)
                    result = "".join(str(p) for p in resolved_parts)

        return result

    def to_meta(self, callee_fqn: str, confidence: str) -> Dict[str, Any]:
        """Generate metadata dict for edge"""
        via_prefix = "builtin" if self.module == "renpy" else "semantics"
        return {
            "via": f"{via_prefix}:{self.name}",
            "confidence": confidence,
            "callee": callee_fqn,
        }


@dataclass
class SemanticsCatalog:
    """Catalog of function semantic definitions"""

    functions: Dict[str, List[FunctionSemantics]]  # name -> List[semantics]

    def __init__(self):
        self.functions = {}

    def add(self, semantics: FunctionSemantics) -> None:
        """Add a function semantic definition"""
        if semantics.name not in self.functions:
            self.functions[semantics.name] = []
        self.functions[semantics.name].append(semantics)

    def lookup(
        self, func_name: str, module_name: Optional[str] = None
    ) -> Optional[FunctionSemantics]:
        """Look up semantics for a function call"""
        # Try exact name match first
        if func_name in self.functions:
            for sem in self.functions[func_name]:
                if sem.matches(func_name, module_name):
                    return sem

        # Try qualified name
        if module_name:
            full_name = f"{module_name}.{func_name}"
            if full_name in self.functions:
                for sem in self.functions[full_name]:
                    if sem.matches(func_name, module_name):
                        return sem

        return None

    @classmethod
    def from_yaml(cls, yaml_path: Path | str) -> "SemanticsCatalog":
        """Load catalog from YAML file"""
        catalog = cls()

        if yaml is None:
            print("Warning: PyYAML not installed. Semantics catalog disabled.")
            return catalog

        if not Path(yaml_path).exists():
            # Return empty catalog if file doesn't exist
            return catalog

        try:
            with open(yaml_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not data or "functions" not in data:
                return catalog

            for func_def in data["functions"]:
                sem = FunctionSemantics(
                    name=func_def["name"],
                    module=func_def.get("module", "*"),
                    kind=FunctionKind(func_def.get("kind", "unknown")),
                    arg_index=func_def.get("arg_index", 0),
                    transforms=func_def.get("transforms"),
                    returns_value=func_def.get("returns_value", False),
                    description=func_def.get("description", ""),
                )
                catalog.add(sem)

        except Exception as e:
            # Log error but don't crash
            print(f"Warning: Failed to load semantics from {yaml_path}: {e}")

        return catalog

    @classmethod
    def get_default_catalog(cls) -> "SemanticsCatalog":
        """Get catalog with built-in Ren'Py functions"""
        catalog = cls()

        # Built-in Ren'Py jump/call functions
        catalog.add(
            FunctionSemantics(
                name="renpy.jump",
                module="renpy",
                kind=FunctionKind.JUMP,
                arg_index=0,
                description="Ren'Py built-in jump function",
            )
        )

        catalog.add(
            FunctionSemantics(
                name="renpy.call",
                module="renpy",
                kind=FunctionKind.CALL,
                arg_index=0,
                description="Ren'Py built-in call function",
            )
        )

        catalog.add(
            FunctionSemantics(
                name="Jump",
                module="renpy",
                kind=FunctionKind.JUMP,
                arg_index=0,
                description="Ren'Py Action class for jump",
            )
        )

        return catalog
