"""
BranchPy Project Policy Engine — Phase 8 (v0.7.8)
Manages project-level and organization-wide policy enforcement for custom rules.

This module enables teams to define enforcement levels (warn, strict, off) for
validation rules and apply them consistently across projects.

Usage:
    from branchpy.analysis.sae.project_policy import load_policy, EnforcementLevel

    policy = load_policy(".branchpy/policy.toml")
    if policy.enforcement == EnforcementLevel.STRICT:
        # Fail build on violations
        raise BuildError("Policy violations detected")
"""

from __future__ import annotations

import tomllib  # Python 3.11+, use tomli for 3.10
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, Optional, Set


class EnforcementLevel(Enum):
    """Policy enforcement levels."""

    OFF = "off"  # Disabled - rules not checked
    WARN = "warn"  # Enabled but non-blocking (warnings only)
    STRICT = "strict"  # Enabled and blocking (fail on violations)


@dataclass
class RulePolicyConfig:
    """
    Policy configuration for a specific rule or rule group.

    Attributes:
        rule_id: Rule ID (e.g., "CUST001") or pattern (e.g., "CUST*")
        enforcement: Enforcement level for this rule
        threshold: Optional violation threshold (errors allowed before failing)
        message: Optional custom message override
    """

    rule_id: str
    enforcement: EnforcementLevel = EnforcementLevel.WARN
    threshold: Optional[int] = None
    message: Optional[str] = None


@dataclass
class PolicyConfig:
    """
    Complete project policy configuration.

    Attributes:
        version: Policy schema version
        default_enforcement: Default enforcement for all rules
        rule_overrides: Per-rule enforcement overrides
        required_rules: Rules that must be enabled
        disabled_rules: Rules that must be disabled
        metadata: Additional policy metadata (team, contact, etc.)
    """

    version: str = "1.0"
    default_enforcement: EnforcementLevel = EnforcementLevel.WARN
    rule_overrides: Dict[str, RulePolicyConfig] = field(default_factory=dict)
    required_rules: Set[str] = field(default_factory=set)
    disabled_rules: Set[str] = field(default_factory=set)
    metadata: Dict[str, str] = field(default_factory=dict)

    def get_enforcement(self, rule_id: str) -> EnforcementLevel:
        """
        Get enforcement level for a specific rule.

        Args:
            rule_id: Rule ID to check

        Returns:
            Enforcement level (considers overrides and defaults)
        """
        # Check if rule is explicitly disabled
        if rule_id in self.disabled_rules:
            return EnforcementLevel.OFF

        # Check for exact rule override
        if rule_id in self.rule_overrides:
            return self.rule_overrides[rule_id].enforcement

        # Check for pattern-based override (e.g., "CUST*")
        for pattern, config in self.rule_overrides.items():
            if self._matches_pattern(rule_id, pattern):
                return config.enforcement

        # Check if rule is required (must be at least WARN)
        if rule_id in self.required_rules:
            # If default is OFF, upgrade to WARN
            if self.default_enforcement == EnforcementLevel.OFF:
                return EnforcementLevel.WARN

        # Fall back to default enforcement
        return self.default_enforcement

    def get_threshold(self, rule_id: str) -> Optional[int]:
        """
        Get violation threshold for a specific rule.

        Args:
            rule_id: Rule ID to check

        Returns:
            Threshold (number of violations allowed) or None
        """
        if rule_id in self.rule_overrides:
            return self.rule_overrides[rule_id].threshold

        # Check pattern-based overrides
        for pattern, config in self.rule_overrides.items():
            if self._matches_pattern(rule_id, pattern):
                return config.threshold

        return None

    def is_rule_enabled(self, rule_id: str) -> bool:
        """Check if a rule is enabled (not OFF)."""
        return self.get_enforcement(rule_id) != EnforcementLevel.OFF

    def is_strict_mode(self, rule_id: str) -> bool:
        """Check if a rule is in strict enforcement mode."""
        return self.get_enforcement(rule_id) == EnforcementLevel.STRICT

    @staticmethod
    def _matches_pattern(rule_id: str, pattern: str) -> bool:
        """
        Check if rule_id matches a pattern.

        Supports:
        - Exact match: "CUST001"
        - Wildcard suffix: "CUST*" (matches CUST001, CUST002, etc.)
        - Wildcard prefix: "*001" (matches CUST001, TEAM001, etc.)
        """
        if pattern == rule_id:
            return True

        if pattern.endswith("*"):
            prefix = pattern[:-1]
            return rule_id.startswith(prefix)

        if pattern.startswith("*"):
            suffix = pattern[1:]
            return rule_id.endswith(suffix)

        return False


def load_policy(policy_path: str | Path) -> PolicyConfig:
    """
    Load project policy from TOML configuration file.

    Args:
        policy_path: Path to policy.toml file

    Returns:
        PolicyConfig object

    Raises:
        FileNotFoundError: If policy file doesn't exist
        ValueError: If policy file has invalid format

    Example:
        >>> policy = load_policy(".branchpy/policy.toml")
        >>> print(f"Default enforcement: {policy.default_enforcement.value}")
        Default enforcement: warn
    """
    policy_file = Path(policy_path)

    if not policy_file.exists():
        raise FileNotFoundError(f"Policy file not found: {policy_path}")

    # Load TOML content (Python 3.11+ has tomllib built-in)
    try:
        with open(policy_file, "rb") as f:
            data = tomllib.load(f)
    except Exception as e:
        # Fallback to tomli for Python 3.10
        try:
            import tomli

            with open(policy_file, "rb") as f:
                data = tomli.load(f)
        except ImportError:
            raise ValueError(
                f"TOML parsing requires Python 3.11+ or 'tomli' package: {e}"
            )
        except Exception as e2:
            raise ValueError(f"Invalid TOML in policy file: {e2}")

    # Validate schema version
    version = data.get("version", "1.0")
    if version != "1.0":
        raise ValueError(f"Unsupported policy schema version: {version}")

    # Parse default enforcement
    default_enforcement_str = data.get("default_enforcement", "warn")
    try:
        default_enforcement = EnforcementLevel(default_enforcement_str.lower())
    except ValueError:
        raise ValueError(
            f"Invalid default_enforcement '{default_enforcement_str}': must be off, warn, or strict"
        )

    # Parse rule overrides
    rule_overrides = {}
    for rule_id, rule_data in data.get("rules", {}).items():
        if isinstance(rule_data, dict):
            enforcement_str = rule_data.get("enforcement", "warn")
            try:
                enforcement = EnforcementLevel(enforcement_str.lower())
            except ValueError:
                raise ValueError(
                    f"Invalid enforcement '{enforcement_str}' for rule {rule_id}"
                )

            rule_overrides[rule_id] = RulePolicyConfig(
                rule_id=rule_id,
                enforcement=enforcement,
                threshold=rule_data.get("threshold"),
                message=rule_data.get("message"),
            )
        elif isinstance(rule_data, str):
            # Shorthand: rules.CUST001 = "strict"
            try:
                enforcement = EnforcementLevel(rule_data.lower())
            except ValueError:
                raise ValueError(
                    f"Invalid enforcement '{rule_data}' for rule {rule_id}"
                )

            rule_overrides[rule_id] = RulePolicyConfig(
                rule_id=rule_id,
                enforcement=enforcement,
            )

    # Parse required and disabled rules
    required_rules = set(data.get("required_rules", []))
    disabled_rules = set(data.get("disabled_rules", []))

    # Validate no overlap between required and disabled
    overlap = required_rules & disabled_rules
    if overlap:
        raise ValueError(f"Rules cannot be both required and disabled: {overlap}")

    # Parse metadata
    metadata = data.get("metadata", {})

    return PolicyConfig(
        version=version,
        default_enforcement=default_enforcement,
        rule_overrides=rule_overrides,
        required_rules=required_rules,
        disabled_rules=disabled_rules,
        metadata=metadata,
    )


def load_policy_with_fallback(
    project_root: Path, global_policy_path: Optional[Path] = None
) -> PolicyConfig:
    """
    Load project policy with global fallback.

    Priority:
    1. Project-level: .branchpy/policy.toml
    2. Global policy: Provided path or default location
    3. Default policy: WARN enforcement for all rules

    Args:
        project_root: Project root directory
        global_policy_path: Optional global policy file path

    Returns:
        PolicyConfig object (never None - returns default if no policies found)
    """
    # Try project-level policy first
    project_policy = project_root / ".branchpy" / "policy.toml"
    if project_policy.exists():
        try:
            return load_policy(project_policy)
        except Exception as e:
            # Log warning but continue to global fallback
            import logging

            logging.warning(f"Failed to load project policy: {e}")

    # Try global policy if provided
    if global_policy_path and global_policy_path.exists():
        try:
            return load_policy(global_policy_path)
        except Exception as e:
            import logging

            logging.warning(f"Failed to load global policy: {e}")

    # Return default policy (WARN enforcement)
    return PolicyConfig(
        version="1.0",
        default_enforcement=EnforcementLevel.WARN,
    )


def validate_policy_file(policy_path: str | Path) -> tuple[bool, Optional[str]]:
    """
    Validate a policy file without loading it.

    Args:
        policy_path: Path to policy.toml file

    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        load_policy(policy_path)
        return True, None
    except Exception as e:
        return False, str(e)
