"""Static Analysis Engine (SAE) - Core Module

Provides control-flow graph (CFG) construction, validation, and analysis
for Ren'Py projects.

SAE Phase A Extensions:
- AssignmentExtractor: Variable write detection and tracking
- extract_assignments_for_report: Report integration for result.sae
"""

from branchpy.contract import VERSION

from .assignment_extractor import (
    AssignmentEvent,
    AssignmentExtractor,
    extract_assignments_for_report,
)
from .cfg_builder import CFGBuilder
from .exporters.flowgraph import FlowgraphExporter
from .indexer import Indexer

__all__ = [
    "CFGBuilder",
    "Indexer",
    "FlowgraphExporter",
    "AssignmentExtractor",
    "AssignmentEvent",
    "extract_assignments_for_report",
]

__version__ = VERSION  # Imported from branchpy.contract
