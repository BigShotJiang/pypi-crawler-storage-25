"""
Lazy registry for global SAE singletons.

Prevents import-time side effects that cause pytest collection deadlocks.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from branchpy.analysis.sae.job import JobQueue
    from branchpy.analysis.sae.worker import WorkerPool

# Lazy singletons - initialized on first access only
_JOB_QUEUE: Optional[JobQueue] = None
_WORKER_POOL: Optional[WorkerPool] = None


def get_job_queue() -> JobQueue:
    """
    Get the global job queue instance (lazy singleton).

    Returns:
        JobQueue instance
    """
    global _JOB_QUEUE
    if _JOB_QUEUE is None:
        from branchpy.analysis.sae.job import JobQueue

        _JOB_QUEUE = JobQueue()
    return _JOB_QUEUE


def get_worker_pool() -> WorkerPool:
    """
    Get the global worker pool instance (lazy singleton).

    Returns:
        WorkerPool instance
    """
    global _WORKER_POOL
    if _WORKER_POOL is None:
        from branchpy.analysis.sae.worker import WorkerPool

        _WORKER_POOL = WorkerPool(max_workers=4)
    return _WORKER_POOL


def reset_registries() -> None:
    """
    Reset global singletons (for testing only).

    This allows tests to use fresh instances without side effects.
    """
    global _JOB_QUEUE, _WORKER_POOL

    # Shutdown worker pool if active
    if _WORKER_POOL is not None:
        _WORKER_POOL.shutdown(wait=False)

    _JOB_QUEUE = None
    _WORKER_POOL = None
