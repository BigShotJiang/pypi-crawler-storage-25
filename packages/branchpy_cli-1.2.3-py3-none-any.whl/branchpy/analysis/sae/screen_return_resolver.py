"""
SAE Rule: screen_return_property_dispatch

Resolves patterns where a screen returns an object, that object is assigned to _return,
and then a property is accessed to determine the next label via call/jump expression.

Pattern:
    call screen <screen_name>
    $ <var> = _return
    call expression <var>.<property>

Example (Ren'Py tutorial):
    call screen tutorials(adj=tutorials_adjustment)
    $ tutorial = _return
    call expression tutorial.label from _call_expression

This resolver:
1. Finds `var = _return` assignments (from SAE)
2. Scans surrounding source lines for the pattern
3. Parses init python blocks to extract object property mappings
4. Generates SAE edges for each possible target label
"""

import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ScreenReturnPatternMatcher:
    """Detects screen return property dispatch patterns in source code."""

    def __init__(self, file_content: str, assignments: List[Dict[str, Any]]):
        """
        Args:
            file_content: Full source code content
            assignments: SAE assignments list (must have label, line, var, value fields)
        """
        self.lines = file_content.split("\n")
        self.assignments = assignments

    def find_patterns(self) -> List[Dict[str, Any]]:
        """
        Find all screen return property dispatch patterns.

        Returns:
            List of pattern dicts with keys:
                - label: Label where pattern occurs
                - screen_name: Name of the screen being called
                - return_var: Variable assigned from _return
                - property_field: Property accessed (e.g., 'label')
                - source_line: Line number of _return assignment
        """
        patterns = []

        # Find all `var = _return` assignments
        return_assignments = [
            a
            for a in self.assignments
            if a.get("value") == "_return" and a.get("op") == "="
        ]

        for assignment in return_assignments:
            pattern = self._analyze_assignment_context(assignment)
            if pattern:
                patterns.append(pattern)

        return patterns

    def _analyze_assignment_context(
        self, assignment: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Analyze source lines around a `var = _return` assignment to detect the pattern.

        Args:
            assignment: SAE assignment dict with line, var, label fields

        Returns:
            Pattern dict if detected, None otherwise
        """
        line_num = assignment.get("line")
        var_name = assignment.get("var")
        label_name = assignment.get("label")

        if not all([line_num, var_name, label_name]):
            return None

        # Note: line_num is 1-indexed, convert to 0-indexed for array access
        line_idx = line_num - 1

        # Bounds check
        if line_idx < 0 or line_idx >= len(self.lines):
            return None

        # Search window: 10 lines before, 30 lines after
        start_idx = max(0, line_idx - 10)
        end_idx = min(len(self.lines), line_idx + 30)

        # Find preceding `call screen <name>`
        screen_name = None
        for i in range(line_idx - 1, start_idx - 1, -1):
            if i < 0 or i >= len(self.lines):
                continue
            match = re.search(r"call\s+screen\s+(\w+)", self.lines[i])
            if match:
                screen_name = match.group(1)
                break

        if not screen_name:
            return None

        # Find subsequent `call expression var.property` or `jump expression var.property`
        property_field = None
        for i in range(line_idx, end_idx):
            if i < 0 or i >= len(self.lines):
                continue
            # Match: call/jump expression <var>.<property>
            pattern = rf"(?:call|jump)\s+expression\s+{re.escape(var_name)}\.(\w+)"
            match = re.search(pattern, self.lines[i])
            if match:
                property_field = match.group(1)
                break

        if not property_field:
            return None

        return {
            "label": label_name,
            "screen_name": screen_name,
            "return_var": var_name,
            "property_field": property_field,
            "source_line": line_num,
        }


class InitPythonParser:
    """Parses init python blocks to extract object property mappings."""

    def __init__(self, file_content: str):
        """
        Args:
            file_content: Full source code content
        """
        self.content = file_content

    def extract_property_mappings(
        self, class_name: str, property_field: str
    ) -> List[str]:
        """
        Extract property values from constructor calls in init python blocks.

        For example, given:
            init python:
                Tutorial("tutorial_playing", "Player Experience")
                Tutorial("tutorial_create", "Creating a New Game")

        With class_name="Tutorial" and property_field="label", this returns:
            ["tutorial_playing", "tutorial_create"]

        Args:
            class_name: Name of the class to search for
            property_field: Property field to extract (e.g., 'label')

        Returns:
            List of property values (label strings)
        """
        values = []

        # Find init python blocks
        init_blocks = self._extract_init_python_blocks()

        for block in init_blocks:
            # Find constructor calls: ClassName("arg1", "arg2", ...)
            pattern = rf'{re.escape(class_name)}\s*\(\s*["\']([^"\']+)["\']'
            matches = re.finditer(pattern, block)

            for match in matches:
                # For MVP, assume first string arg is the property value
                # This works for Tutorial("label", ...) pattern
                value = match.group(1)
                if value and value not in values:
                    values.append(value)

        return values

    def _extract_init_python_blocks(self) -> List[str]:
        """
        Extract all init python blocks from source.

        Returns:
            List of block content strings
        """
        blocks = []
        lines = self.content.split("\n")

        in_block = False
        current_block = []
        base_indent = None

        for line in lines:
            # Detect init python start
            if re.match(r"^\s*init\s+python\s*:", line):
                in_block = True
                current_block = []
                base_indent = None
                continue

            if in_block:
                # Detect end of block (dedent back to base level or blank line followed by dedent)
                stripped = line.lstrip()

                if not stripped:
                    # Blank line - continue
                    current_block.append(line)
                    continue

                # Calculate indentation
                indent = len(line) - len(stripped)

                if base_indent is None:
                    # First non-blank line sets base indent
                    base_indent = indent
                    current_block.append(line)
                elif indent >= base_indent:
                    # Still in block
                    current_block.append(line)
                else:
                    # Dedented - block ended
                    in_block = False
                    blocks.append("\n".join(current_block))
                    current_block = []
                    base_indent = None

        # Handle block at end of file
        if in_block and current_block:
            blocks.append("\n".join(current_block))

        return blocks

    def detect_class_for_property(self, property_field: str) -> Optional[str]:
        """
        Attempt to detect which class defines a given property.

        For MVP, this looks for class definitions with `self.<property>` assignments.

        Args:
            property_field: Property name to search for (e.g., 'label')

        Returns:
            Class name if found, None otherwise
        """
        # Find class definitions
        class_pattern = r"class\s+(\w+)\s*\([^)]*\)\s*:"
        property_pattern = rf"self\.{re.escape(property_field)}\s*="

        lines = self.content.split("\n")
        current_class = None

        for line in lines:
            # Check for class definition
            class_match = re.search(class_pattern, line)
            if class_match:
                current_class = class_match.group(1)
                continue

            # Check for property assignment in class
            if current_class and re.search(property_pattern, line):
                return current_class

        return None


def infer_call_screen_jump_variable_edges(
    files: List[str],
    known_labels: set,
) -> List[Dict[str, Any]]:
    """
    SAE Rule: call_screen_jump_variable

    Resolves edges produced by the pattern:
        $ var = "target_label"
        call screen X
    where screen X contains a button with ``action [..., Jump(var), ...]``.

    This covers the common EoD / chapter-transition idiom where the
    destination is stored in a variable immediately before the screen call.

    Algorithm:
      Pass 1 – build screen-jump-vars index:
          For every screen definition, collect the variable names used as
          Jump(var) targets inside button action lists (including multi-line
          bracket lists).
      Pass 2 – find call sites:
          For every file, track the current label and the string constants
          assigned to variables since the last label declaration.  When a
          ``call screen X`` line is reached, look up X in the screen-jump-vars
          index, resolve each jump variable through the accumulated assignments,
          and emit an edge if the resolved value is a known label.

    Args:
        files: Absolute paths to all .rpy script files in the project.
        known_labels: Set of label names that exist in the project index.

    Returns:
        List of SAE edge dicts with origin="sae" and
        rule="call_screen_jump_variable" in meta.
    """
    _JUMP_VAR_RE = re.compile(r"Jump\s*\(\s*([A-Za-z_]\w*)\s*\)")

    # ── Pass 1: collect {screen_name → {var_names used in Jump()}} ─────────
    screen_jump_vars: Dict[str, set] = {}
    all_content: Dict[str, str] = {}

    for fp in files:
        try:
            content = open(fp, encoding="utf-8", errors="replace").read()
            all_content[fp] = content
        except Exception:
            continue

    for fp, content in all_content.items():
        lines = content.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            sm = re.match(r"^\s*screen\s+([A-Za-z_]\w*)", line)
            if sm:
                screen_name = sm.group(1)
                screen_indent = len(line) - len(line.lstrip())
                screen_jump_vars.setdefault(screen_name, set())
                i += 1
                while i < len(lines):
                    sl = lines[i]
                    if sl.strip() and not sl.strip().startswith("#"):
                        sl_indent = len(sl) - len(sl.lstrip())
                        if sl_indent <= screen_indent:
                            break  # end of screen block
                        # Look for Jump(var) inside button action expressions
                        if "action" in sl and any(
                            w in sl.lower()
                            for w in ("textbutton", "imagebutton", "button")
                        ):
                            action_block = sl
                            if "[" in action_block:
                                depth = action_block.count("[") - action_block.count(
                                    "]"
                                )
                                j = i + 1
                                while depth > 0 and j < len(lines):
                                    chunk = lines[j]
                                    action_block += " " + chunk
                                    depth += chunk.count("[") - chunk.count("]")
                                    j += 1
                            for vm in _JUMP_VAR_RE.finditer(action_block):
                                var = vm.group(1)
                                if var not in ("True", "False", "None"):
                                    screen_jump_vars[screen_name].add(var)
                    i += 1
                continue
            i += 1

    # ── Pass 2: find $ var = "val" … call screen X patterns ────────────────
    edges: List[Dict[str, Any]] = []
    _ASSIGN_RE = re.compile(r'^\s*\$\s+([A-Za-z_]\w*)\s*=\s*["\']([^"\']+)["\']\s*')
    _CALL_SCREEN_RE = re.compile(r"^\s*call\s+screen\s+([A-Za-z_]\w*)")
    _LABEL_RE = re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:")
    seen: set = set()  # avoid duplicate edges

    for fp, content in all_content.items():
        lines = content.split("\n")
        current_label: Optional[str] = None
        label_assignments: Dict[str, str] = {}

        for lineno, line in enumerate(lines, start=1):
            # Skip blank and comment lines
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # Track label context – reset accumulated assignments on each new label
            lm = _LABEL_RE.match(line)
            if lm:
                current_label = lm.group(1)
                label_assignments = {}
                continue

            # Accumulate string-constant assignments: $ var = "value"
            am = _ASSIGN_RE.match(line)
            if am:
                label_assignments[am.group(1)] = am.group(2)
                continue

            # Detect: call screen X
            csm = _CALL_SCREEN_RE.match(line)
            if csm and current_label:
                screen_name = csm.group(1)
                jump_vars = screen_jump_vars.get(screen_name, set())
                for var in jump_vars:
                    target = label_assignments.get(var)
                    if target and target in known_labels:
                        key = (current_label, target)
                        if key not in seen:
                            seen.add(key)
                            edges.append(
                                {
                                    "src": current_label,
                                    "dst": target,
                                    "kind": "jump",
                                    "edge_type": "jump",
                                    "meta": {
                                        "sae_rule": "call_screen_jump_variable",
                                        "screen": screen_name,
                                        "via_var": var,
                                        "file": fp,
                                        "line": lineno,
                                    },
                                }
                            )

    return edges


def infer_pfi_callable_semantics_edges(
    files: List[str],
    pfi_functions: List[Dict[str, Any]],
    known_labels: set,
) -> List[Dict[str, Any]]:
    """
    SAE Rule: pfi_callable_semantics (Layer 3 — Inter-Procedural Bridge)

    Resolves edges produced when a screen uses ``Function(foo)`` as a button
    action and ``foo`` is a Python function whose body contains jumps/calls to
    known labels (as recorded by PFI).

    Join path::

        caller_label -[call screen S]-> screen S -[Function(foo)]-> PFI(foo) -> target_label

    The *source* label is always the label that executes ``call screen S``,
    not whatever label happens to appear before the ``screen S:`` definition
    in the file.  One screen may be called from many labels; the bridge fans
    out from all of them independently.

    Semantic distinctions:

    * ``calls_labels`` in PFI   = function body contains ``renpy.call`` or
      ``call <label>`` → emitted with ``edge_type = "call"``
    * ``returns_labels`` in PFI = function body contains ``return "label"``
      (dynamic dispatch) → emitted with ``edge_type = "jump"``

    These are tracked separately so downstream consumers can distinguish
    call-return- controllable edges from late-bound dispatch.

    Qualified names (``Function(store.foo)``): only the last attribute
    component is matched against the PFI index, which stores bare names.

    Deduplication and provenance:
      Graph edges are deduplicated on ``(src_label, target_label, func_name,
      edge_type)``.  When multiple distinct screens route the same function to
      the same target from the same source label, only one graph edge is
      emitted, but all contributing screens are listed in
      ``meta.screens`` and the total number of call-sites is recorded in
      ``meta.callsite_count``.  This preserves debuggability without
      inflating the graph.

    Scope limitations:
      * Only **literal** ``call screen X`` syntax is resolved.  Dynamic
        ``call screen expression`` with a computed name is out of scope and
        silently skipped (Rule 2 has the same restriction).
      * Wrapper chains (``Function(bar)`` where ``bar()`` calls ``foo()`` which
        jumps) are not followed; only direct PFI hits on ``bar`` are emitted.
      * ``store.``-qualified names (``Function(store.foo)``) are reduced to the
        terminal component ``foo`` before lookup.

    Algorithm:
      Pass 1 — build ``screen_functions: {screen_name -> Set[func_name]}``
        Walk each .rpy file; inside every ``screen X:`` block, collect every
        ``Function(foo)`` name that has a PFI entry.  Multi-line bracket action
        lists are accumulated before scanning.
      Pass 2 — build ``callers: List[(src_label, screen_name)]``
        Walk each .rpy file; track the current label; record every
        ``call screen X`` line encountered inside a label body.
      Join
        For every ``(src_label, screen_name)`` pair, expand through
        ``screen_functions[screen_name]`` then through ``pfi_index[func_name]``
        and emit edges.
    """
    edges: List[Dict[str, Any]] = []

    if not pfi_functions or not files:
        return edges

    # ── PFI index: func_name -> {calls: [...], returns: [...]} ───────────────
    # Only store functions that have at least one target in known_labels.
    # calls_labels: body uses renpy.jump / renpy.call / jump / call
    # returns_labels: body returns a string literal (dynamic dispatch)
    pfi_index: Dict[str, Dict[str, List[str]]] = {}
    for func in pfi_functions:
        name = (
            func.get("name") if isinstance(func, dict) else getattr(func, "name", None)
        )
        if not name:
            continue
        raw_calls = (
            func.get("calls_labels", [])
            if isinstance(func, dict)
            else getattr(func, "calls_labels", [])
        )
        raw_returns = (
            func.get("returns_labels", [])
            if isinstance(func, dict)
            else getattr(func, "returns_labels", [])
        )
        filtered_calls = [lb for lb in (raw_calls or []) if lb in known_labels]
        filtered_returns = [lb for lb in (raw_returns or []) if lb in known_labels]
        if filtered_calls or filtered_returns:
            pfi_index[name] = {"calls": filtered_calls, "returns": filtered_returns}

    if not pfi_index:
        return edges

    # ── Regex patterns ────────────────────────────────────────────────────────
    _screen_def_re = re.compile(r"^\s*screen\s+([A-Za-z_]\w*)\s*[\(:]")
    _label_re = re.compile(r"^\s*label\s+([A-Za-z_]\w*)\s*:")
    _call_screen_re = re.compile(r"^\s*call\s+screen\s+([A-Za-z_]\w*)")
    # Capture the bare identifier for both `Function(foo)` and `Function(store.foo)`
    _function_action_re = re.compile(r"\bFunction\s*\(\s*(?:\w+\.)*(\w+)")

    # ── Load file contents once (shared across both passes) ──────────────────
    all_content: Dict[str, str] = {}
    for fp in files:
        try:
            all_content[fp] = open(fp, encoding="utf-8", errors="replace").read()
        except Exception:
            continue

    # ── Pass 1: screen_functions index ───────────────────────────────────────
    screen_functions: Dict[str, set] = {}

    for fp, content in all_content.items():
        lines = content.split("\n")
        i = 0
        while i < len(lines):
            sm = _screen_def_re.match(lines[i])
            if sm:
                screen_name = sm.group(1)
                screen_indent = len(lines[i]) - len(lines[i].lstrip())
                screen_functions.setdefault(screen_name, set())
                i += 1
                while i < len(lines):
                    sl = lines[i]
                    stripped = sl.strip()
                    if stripped and not stripped.startswith("#"):
                        if len(sl) - len(sl.lstrip()) <= screen_indent:
                            break  # end of screen block
                        if "Function(" in sl:
                            # Accumulate multi-line bracket action list
                            action_text = stripped
                            if "[" in action_text:
                                depth = action_text.count("[") - action_text.count("]")
                                j = i + 1
                                while depth > 0 and j < len(lines):
                                    chunk = lines[j].strip()
                                    action_text += " " + chunk
                                    depth += chunk.count("[") - chunk.count("]")
                                    j += 1
                            for m in _function_action_re.finditer(action_text):
                                func_name = m.group(1)
                                if func_name in pfi_index:
                                    screen_functions[screen_name].add(func_name)
                    i += 1
                continue
            i += 1

    # ── Pass 2: call-screen callers — (src_label, screen_name) pairs ─────────
    callers: List[tuple] = []

    for fp, content in all_content.items():
        current_label: Optional[str] = None
        for line in content.split("\n"):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            lm = _label_re.match(line)
            if lm:
                current_label = lm.group(1)
                continue
            if current_label:
                csm = _call_screen_re.match(line)
                if csm:
                    callers.append((current_label, csm.group(1)))

    if not callers:
        return edges

    # ── Join: caller_label x screen x Function(foo) x PFI -> edges ───────────
    # Graph dedup key: (src_label, target_label, func_name, edge_type)
    # A single graph edge is emitted per unique key. When multiple distinct
    # screens route through the same function to the same target from the same
    # calling label (or the same screen is called multiple times from the same
    # label), all contributing screens are accumulated in meta.screens and
    # meta.callsite_count is incremented — so provenance is preserved even
    # though the graph gets one edge.
    #
    # Note: edge_type is included in the key so calls_labels and returns_labels
    # from the same function can coexist as distinct graph edges.

    # accum key -> {screens: set, callsite_count: int, edge fields...}
    accum: Dict[tuple, Dict[str, Any]] = {}

    for src_label, screen_name in callers:
        for func_name in screen_functions.get(screen_name, set()):
            pfi_targets = pfi_index.get(func_name, {})

            for target_label in pfi_targets.get("calls", []):
                key = (src_label, target_label, func_name, "call")
                if key not in accum:
                    accum[key] = {
                        "src": src_label,
                        "dst": target_label,
                        "edge_type": "call",
                        "function_name": func_name,
                        "screens": set(),
                        "callsite_count": 0,
                    }
                accum[key]["screens"].add(screen_name)
                accum[key]["callsite_count"] += 1

            for target_label in pfi_targets.get("returns", []):
                key = (src_label, target_label, func_name, "jump")
                if key not in accum:
                    accum[key] = {
                        "src": src_label,
                        "dst": target_label,
                        "edge_type": "jump",
                        "function_name": func_name,
                        "screens": set(),
                        "callsite_count": 0,
                    }
                accum[key]["screens"].add(screen_name)
                accum[key]["callsite_count"] += 1

    for data in accum.values():
        edges.append(
            {
                "src": data["src"],
                "dst": data["dst"],
                "edge_type": data["edge_type"],
                "origin": "sae",
                "confidence": "inferred_pfi_callable",
                "meta": {
                    "sae_rule": "pfi_callable_semantics",
                    "screens": sorted(data["screens"]),
                    "function_name": data["function_name"],
                    "callsite_count": data["callsite_count"],
                    "via": "call_screen + Function() + PFI",
                },
            }
        )

    return edges


def infer_screen_return_property_dispatch_edges(
    file_path: str, file_content: str, assignments: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Main entry point for screen_return_property_dispatch SAE rule.

    Args:
        file_path: Path to source file being analyzed
        file_content: Full source code content
        assignments: SAE assignments list from analysis

    Returns:
        List of SAE edge dicts with keys:
            - src: Source label
            - dst: Destination label (inferred from property value)
            - edge_type: 'call' (since original pattern uses call expression)
            - origin: 'sae'
            - confidence: 'inferred_finite_set'
            - meta: Dict with rule, screen, property, etc.
    """
    edges = []

    try:
        # Step 1: Find patterns
        matcher = ScreenReturnPatternMatcher(file_content, assignments)
        patterns = matcher.find_patterns()

        if not patterns:
            logger.debug(
                f"No screen return property dispatch patterns found in {file_path}"
            )
            return edges

        logger.info(
            f"Found {len(patterns)} screen return property dispatch patterns in {file_path}"
        )

        # Step 2: Parse init python for property mappings
        parser = InitPythonParser(file_content)

        for pattern in patterns:
            property_field = pattern["property_field"]

            # Detect which class defines this property
            class_name = parser.detect_class_for_property(property_field)

            if not class_name:
                logger.warning(
                    f"Could not detect class for property '{property_field}' in {file_path}"
                )
                continue

            # Extract property values (target labels)
            target_labels = parser.extract_property_mappings(class_name, property_field)

            if not target_labels:
                logger.warning(
                    f"No property mappings found for {class_name}.{property_field} in {file_path}"
                )
                continue

            logger.info(
                f"Resolved {len(target_labels)} target labels for pattern in '{pattern['label']}' via {class_name}.{property_field}"
            )

            # Step 3: Generate edges
            for target_label in target_labels:
                edge = {
                    "src": pattern["label"],
                    "dst": target_label,
                    "edge_type": "call",  # Original uses call expression
                    "kind": "direct",
                    "origin": "sae",
                    "confidence": "inferred_finite_set",
                    "numeric_confidence": 0.95,
                    "meta": {
                        "rule": "screen_return_property_dispatch",
                        "screen_name": pattern["screen_name"],
                        "return_var": pattern["return_var"],
                        "property_field": property_field,
                        "class_name": class_name,
                        "source_line": pattern["source_line"],
                    },
                }
                edges.append(edge)

    except Exception as e:
        logger.error(
            f"Error in screen_return_property_dispatch resolver for {file_path}: {e}",
            exc_info=True,
        )

    return edges
