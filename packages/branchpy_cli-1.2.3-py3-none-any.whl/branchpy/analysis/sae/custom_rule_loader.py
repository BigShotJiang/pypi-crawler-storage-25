"""
BranchPy Custom Rule Loader — Phase 8 (v0.7.8)
Loads and validates user-defined validation rules from YAML/JSON configuration.

This module enables teams to extend BranchPy's built-in Static Analysis Engine
with project-specific or organization-wide validation logic.

Usage:
    from branchpy.analysis.sae.custom_rule_loader import load_custom_rules

    rules = load_custom_rules(".branchpy/rules_custom.yml")
    for rule in rules:
        print(f"{rule.id}: {rule.name} ({rule.severity})")
"""

import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


class RuleSeverity(Enum):
    """Severity levels for custom rules (matches SAE Severity)."""

    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


class CheckType(Enum):
    """Type of validation check."""

    PATTERN = "pattern"  # Regex-based pattern matching
    STRUCTURAL = "structural"  # Requires AST analysis (future)


@dataclass
class CustomRuleSchema:
    """
    Schema for a single custom validation rule.

    Attributes:
        id: Unique identifier (e.g., CUST001)
        name: Human-readable rule name
        description: Detailed explanation of the rule
        pattern: Regex pattern for pattern-based checks
        severity: Rule severity (INFO/WARNING/ERROR)
        message: User-facing violation message
        category: Logical grouping (naming, usability, etc.)
        enabled: Whether rule is active
        check_type: Type of check (pattern or structural)
        metadata: Additional custom metadata
    """

    id: str
    name: str
    description: str
    pattern: str
    severity: RuleSeverity
    message: str
    category: str
    enabled: bool = True
    check_type: CheckType = CheckType.PATTERN
    metadata: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        """Validate rule configuration after initialization."""
        # Validate ID format
        if not re.match(r"^CUST\d{3,}$", self.id):
            raise ValueError(
                f"Invalid custom rule ID '{self.id}': must match CUST### format"
            )

        # Convert string severity to enum if needed
        if isinstance(self.severity, str):
            try:
                self.severity = RuleSeverity[self.severity.upper()]
            except KeyError:
                raise ValueError(
                    f"Invalid severity '{self.severity}': must be INFO, WARNING, or ERROR"
                )

        # Convert string check_type to enum if needed
        if isinstance(self.check_type, str):
            try:
                self.check_type = CheckType[self.check_type.upper()]
            except KeyError:
                raise ValueError(
                    f"Invalid check_type '{self.check_type}': must be pattern or structural"
                )

        # Validate regex pattern
        if self.check_type == CheckType.PATTERN:
            try:
                re.compile(self.pattern)
            except re.error as e:
                raise ValueError(f"Invalid regex pattern in rule {self.id}: {e}")

    def matches(self, line: str) -> bool:
        """
        Check if a line of code matches this rule's pattern.

        Args:
            line: Line of source code to check

        Returns:
            True if pattern matches (violation detected)
        """
        if not self.enabled or self.check_type != CheckType.PATTERN:
            return False

        return bool(re.search(self.pattern, line))


def load_custom_rules(rules_path: str | Path) -> List[CustomRuleSchema]:
    """
    Load custom validation rules from YAML configuration file.

    Args:
        rules_path: Path to rules_custom.yml file

    Returns:
        List of validated CustomRuleSchema objects

    Raises:
        FileNotFoundError: If rules file doesn't exist
        ValueError: If rules file has invalid format or schema

    Example:
        >>> rules = load_custom_rules(".branchpy/rules_custom.yml")
        >>> print(f"Loaded {len(rules)} custom rules")
        Loaded 4 custom rules
    """
    rules_file = Path(rules_path)

    if not rules_file.exists():
        raise FileNotFoundError(f"Custom rules file not found: {rules_path}")

    # Load YAML content
    try:
        with open(rules_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in custom rules file: {e}")

    if not isinstance(data, dict):
        raise ValueError("Custom rules file must contain a YAML dictionary")

    # Validate schema version
    schema_version = data.get("version", "1.0")
    if schema_version != "1.0":
        raise ValueError(f"Unsupported custom rules schema version: {schema_version}")

    # Extract rules array
    custom_rules_data = data.get("custom_rules", [])
    if not isinstance(custom_rules_data, list):
        raise ValueError("'custom_rules' must be a list")

    # Parse and validate each rule
    rules: List[CustomRuleSchema] = []
    seen_ids = set()

    for idx, rule_data in enumerate(custom_rules_data):
        if not isinstance(rule_data, dict):
            raise ValueError(f"Rule at index {idx} must be a dictionary")

        # Check for required fields
        required_fields = [
            "id",
            "name",
            "description",
            "pattern",
            "severity",
            "message",
            "category",
        ]
        missing = [f for f in required_fields if f not in rule_data]
        if missing:
            raise ValueError(f"Rule at index {idx} missing required fields: {missing}")

        # Check for duplicate IDs
        rule_id = rule_data["id"]
        if rule_id in seen_ids:
            raise ValueError(f"Duplicate custom rule ID: {rule_id}")
        seen_ids.add(rule_id)

        # Create CustomRuleSchema object (validation happens in __post_init__)
        try:
            rule = CustomRuleSchema(
                id=rule_data["id"],
                name=rule_data["name"],
                description=rule_data["description"],
                pattern=rule_data["pattern"],
                severity=rule_data["severity"],
                message=rule_data["message"],
                category=rule_data["category"],
                enabled=rule_data.get("enabled", True),
                check_type=rule_data.get("check_type", "pattern"),
                metadata=rule_data.get("metadata"),
            )
            rules.append(rule)
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid rule at index {idx} ({rule_id}): {e}")

    return rules


def validate_rules_file(rules_path: str | Path) -> tuple[bool, Optional[str]]:
    """
    Validate a custom rules file without loading the rules.

    Args:
        rules_path: Path to rules_custom.yml file

    Returns:
        Tuple of (is_valid, error_message)

    Example:
        >>> valid, error = validate_rules_file(".branchpy/rules_custom.yml")
        >>> if not valid:
        ...     print(f"Validation failed: {error}")
    """
    try:
        load_custom_rules(rules_path)
        return True, None
    except Exception as e:
        return False, str(e)


def get_rule_statistics(rules: List[CustomRuleSchema]) -> Dict[str, Any]:
    """
    Generate statistics about a set of custom rules.

    Args:
        rules: List of CustomRuleSchema objects

    Returns:
        Dictionary with rule statistics
    """
    total = len(rules)
    enabled = sum(1 for r in rules if r.enabled)
    disabled = total - enabled

    by_severity = {}
    for severity in RuleSeverity:
        count = sum(1 for r in rules if r.severity == severity and r.enabled)
        by_severity[severity.value] = count

    by_category = {}
    for rule in rules:
        if rule.enabled:
            by_category[rule.category] = by_category.get(rule.category, 0) + 1

    by_check_type = {}
    for check_type in CheckType:
        count = sum(1 for r in rules if r.check_type == check_type and r.enabled)
        by_check_type[check_type.value] = count

    return {
        "total_rules": total,
        "enabled_rules": enabled,
        "disabled_rules": disabled,
        "by_severity": by_severity,
        "by_category": by_category,
        "by_check_type": by_check_type,
    }
