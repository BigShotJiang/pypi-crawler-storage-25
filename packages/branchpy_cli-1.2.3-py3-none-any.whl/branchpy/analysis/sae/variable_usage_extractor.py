"""
Variable Usage Extractor - Comprehensive parsing of variable reads and writes

This module extends the indexer to track not just variable definitions,
but also all places where variables are used (read/referenced).

Handles:
- String interpolations: "Score is [player_score]"
- Conditions: if flag, if score > 10, while counter < 100
- Expressions: $ x = y + z, show image_name if condition
- Python blocks: full AST analysis
- Function calls: renpy.call(label_var)
- Comparisons and operations
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from typing import List, Optional, Set


@dataclass
class VariableReference:
    """A reference to a variable (read or write)"""

    name: str
    line: int
    context: str  # 'read', 'write', 'cond', 'call', 'mutate'
    expression: str  # The full expression containing the reference


class VariableUsageExtractor:
    """Extract all variable usages from Ren'Py code"""

    def __init__(self):
        self.references: List[VariableReference] = []

    def extract_from_file(self, content: str) -> List[VariableReference]:
        """Extract all variable references from file content"""
        self.references = []
        lines = content.split("\n")

        for line_idx, line in enumerate(lines):
            line_num = line_idx + 1

            # Extract from different statement types
            self._extract_from_interpolations(line, line_num)
            self._extract_from_conditions(line, line_num)
            self._extract_from_expressions(line, line_num)
            self._extract_from_show_hide(line, line_num)

        # Extract from python: blocks separately (need multi-line context)
        self._extract_from_python_blocks(content)

        return self.references

    def _extract_from_interpolations(self, line: str, line_num: int) -> None:
        """Extract variables from string interpolations like [variable_name]"""
        # Match [variable_name] or [persistent.var] patterns
        # Ren'Py uses square brackets for interpolation
        interpolation_pattern = r"\[([A-Za-z_][\w.]*)\]"

        for match in re.finditer(interpolation_pattern, line):
            var_name = match.group(1)
            # Filter out obvious non-variables (like numbers, function calls with parens)
            if not var_name[0].isdigit() and "(" not in var_name:
                self.references.append(
                    VariableReference(
                        name=var_name,
                        line=line_num,
                        context="read",
                        expression=line.strip(),
                    )
                )

    def _extract_from_conditions(self, line: str, line_num: int) -> None:
        """Extract variables from if/elif/while conditions"""
        # Match: if condition:, elif condition:, while condition:
        cond_patterns = [
            r"^\s*if\s+(.+):",
            r"^\s*elif\s+(.+):",
            r"^\s*while\s+(.+):",
        ]

        for pattern in cond_patterns:
            match = re.match(pattern, line)
            if match:
                condition_expr = match.group(1).strip()
                vars_in_cond = self._extract_vars_from_expression(condition_expr)

                for var_name in vars_in_cond:
                    self.references.append(
                        VariableReference(
                            name=var_name,
                            line=line_num,
                            context="cond",
                            expression=condition_expr,
                        )
                    )

    def _extract_from_expressions(self, line: str, line_num: int) -> None:
        """Extract variables from $ expressions and assignments"""
        # Match: $ variable = expression, $ variable += expression, etc.
        dollar_match = re.match(
            r"^\s*\$\s+([A-Za-z_][\w.]*)\s*([+\-*/%])?=\s*(.+)$", line
        )

        if dollar_match:
            lhs_var = dollar_match.group(1)
            operator = dollar_match.group(2)  # +, -, etc. for compound assignment
            rhs_expr = dollar_match.group(3).strip()

            # LHS is a write (or mutate if compound assignment)
            context = "mutate" if operator else "write"
            self.references.append(
                VariableReference(
                    name=lhs_var,
                    line=line_num,
                    context=context,
                    expression=line.strip(),
                )
            )

            # RHS variables are reads
            rhs_vars = self._extract_vars_from_expression(rhs_expr)
            for var_name in rhs_vars:
                self.references.append(
                    VariableReference(
                        name=var_name,
                        line=line_num,
                        context="read",
                        expression=rhs_expr,
                    )
                )

    def _extract_from_show_hide(self, line: str, line_num: int) -> None:
        """Extract variables from show/hide statements with conditional expressions"""
        # Match: show image if condition, hide sprite if not flag
        show_if_pattern = r"^\s*(?:show|hide)\s+[\w]+\s+if\s+(.+)$"

        match = re.match(show_if_pattern, line)
        if match:
            condition = match.group(1).strip()
            vars_in_cond = self._extract_vars_from_expression(condition)

            for var_name in vars_in_cond:
                self.references.append(
                    VariableReference(
                        name=var_name,
                        line=line_num,
                        context="cond",
                        expression=condition,
                    )
                )

    def _extract_from_python_blocks(self, content: str) -> None:
        """Extract variables from python: blocks using AST analysis"""
        lines = content.split("\n")
        in_python_block = False
        block_lines = []
        block_start = 0
        base_indent = 0

        for i, line in enumerate(lines):
            # Check for python: statement
            if re.match(r"^\s*python:", line):
                in_python_block = True
                block_lines = []
                block_start = i + 1
                base_indent = len(line) - len(line.lstrip())
                continue

            if in_python_block:
                current_indent = len(line) - len(line.lstrip())

                # End block if we hit a line at or before the base indent (unless it's blank)
                if line.strip() and current_indent <= base_indent:
                    in_python_block = False
                    if block_lines:
                        self._analyze_python_block("\n".join(block_lines), block_start)
                    block_lines = []
                else:
                    # Continue collecting block content
                    if line.strip():
                        dedented = (
                            line[base_indent + 4 :]
                            if len(line) > base_indent + 4
                            else line.strip()
                        )
                        block_lines.append(dedented)
                    else:
                        block_lines.append("")

        # Handle unclosed block at end of file
        if in_python_block and block_lines:
            self._analyze_python_block("\n".join(block_lines), block_start)

    def _analyze_python_block(self, code: str, start_line: int) -> None:
        """Analyze a python block using AST to extract variable references"""
        try:
            tree = ast.parse(code)

            for node in ast.walk(tree):
                line_num = start_line + (getattr(node, "lineno", 1) - 1)

                # Assignments (writes)
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        var_names = self._extract_names_from_ast_node(target)
                        for var_name in var_names:
                            self.references.append(
                                VariableReference(
                                    name=var_name,
                                    line=line_num,
                                    context="write",
                                    expression=(
                                        ast.unparse(node)
                                        if hasattr(ast, "unparse")
                                        else ""
                                    ),
                                )
                            )

                    # RHS is read
                    rhs_names = self._extract_names_from_ast_node(node.value)
                    for var_name in rhs_names:
                        self.references.append(
                            VariableReference(
                                name=var_name,
                                line=line_num,
                                context="read",
                                expression=(
                                    ast.unparse(node.value)
                                    if hasattr(ast, "unparse")
                                    else ""
                                ),
                            )
                        )

                # Augmented assignments (+=, -=, etc.)
                elif isinstance(node, ast.AugAssign):
                    target_names = self._extract_names_from_ast_node(node.target)
                    for var_name in target_names:
                        self.references.append(
                            VariableReference(
                                name=var_name,
                                line=line_num,
                                context="mutate",
                                expression=(
                                    ast.unparse(node) if hasattr(ast, "unparse") else ""
                                ),
                            )
                        )

                    # Value is read
                    value_names = self._extract_names_from_ast_node(node.value)
                    for var_name in value_names:
                        self.references.append(
                            VariableReference(
                                name=var_name,
                                line=line_num,
                                context="read",
                                expression=(
                                    ast.unparse(node.value)
                                    if hasattr(ast, "unparse")
                                    else ""
                                ),
                            )
                        )

                # If/While conditions
                elif isinstance(node, (ast.If, ast.While)):
                    cond_names = self._extract_names_from_ast_node(node.test)
                    for var_name in cond_names:
                        self.references.append(
                            VariableReference(
                                name=var_name,
                                line=line_num,
                                context="cond",
                                expression=(
                                    ast.unparse(node.test)
                                    if hasattr(ast, "unparse")
                                    else ""
                                ),
                            )
                        )

                # Function/method calls
                elif isinstance(node, ast.Call):
                    # Arguments are reads
                    for arg in node.args:
                        arg_names = self._extract_names_from_ast_node(arg)
                        for var_name in arg_names:
                            self.references.append(
                                VariableReference(
                                    name=var_name,
                                    line=line_num,
                                    context="call",
                                    expression=(
                                        ast.unparse(arg)
                                        if hasattr(ast, "unparse")
                                        else ""
                                    ),
                                )
                            )

                # Subscript operations (list[index], dict[key])
                elif isinstance(node, ast.Subscript):
                    # Both the value and the slice can reference variables
                    names = self._extract_names_from_ast_node(node)
                    for var_name in names:
                        # Determine if it's a read or write based on parent context
                        # Default to read for now
                        self.references.append(
                            VariableReference(
                                name=var_name,
                                line=line_num,
                                context="read",
                                expression=(
                                    ast.unparse(node) if hasattr(ast, "unparse") else ""
                                ),
                            )
                        )

        except SyntaxError:
            # Skip blocks with syntax errors
            pass

    def _extract_names_from_ast_node(self, node) -> Set[str]:
        """Recursively extract all Name nodes from an AST node"""
        names = set()

        for child in ast.walk(node):
            if isinstance(child, ast.Name):
                names.add(child.id)
            elif isinstance(child, ast.Attribute):
                # Handle persistent.var, store.var, etc.
                full_name = self._get_full_attribute_name(child)
                if full_name:
                    names.add(full_name)

        return names

    def _get_full_attribute_name(self, node: ast.Attribute) -> Optional[str]:
        """Get the full dotted name from an Attribute node (e.g., persistent.save_data)"""
        parts = []
        current = node

        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value

        if isinstance(current, ast.Name):
            parts.append(current.id)
            return ".".join(reversed(parts))

        return None

    def _extract_vars_from_expression(self, expr: str) -> Set[str]:
        """Extract variable names from a simple expression string"""
        vars_found = set()

        # Try to parse as Python expression
        try:
            tree = ast.parse(expr, mode="eval")
            vars_found = self._extract_names_from_ast_node(tree.body)
        except SyntaxError:
            # Fall back to regex-based extraction
            # Match identifiers that look like variables
            # Exclude Python keywords and literals
            keywords = {
                "True",
                "False",
                "None",
                "and",
                "or",
                "not",
                "in",
                "is",
                "if",
                "else",
                "elif",
                "for",
                "while",
                "def",
                "class",
                "return",
                "pass",
                "break",
                "continue",
                "import",
                "from",
            }

            # Find all identifier-like tokens
            tokens = re.findall(r"[A-Za-z_][\w.]*", expr)

            for token in tokens:
                # Skip keywords and built-in functions
                if token not in keywords and not token.startswith("__"):
                    vars_found.add(token)

        return vars_found
