"""
Configuration schema and validation for BranchPy SAE.

Provides default configuration values, schema validation, and config merging.
"""

import copy
from typing import Any, Dict, List, Optional

# Default configuration values
DEFAULT_CONFIG: Dict[str, Any] = {
    "rules": {
        "dialogue": {
            "enabled": True,
            "min_word_count": 1,
            "max_word_count": 10000,
            "reading_speed": {"fast_wpm": 300, "normal_wpm": 200, "slow_wpm": 150},
            "speaker_validation": {
                "enabled": True,
                "known_speakers": [],
                "warn_unknown": True,
                "case_sensitive": False,
            },
            "severity": {
                "D01-001": "warning",  # Unknown speaker
                "D01-002": "info",  # Speaker case mismatch
                "D02-001": "info",  # Very short dialogue
                "D02-002": "warning",  # Very long dialogue
            },
        },
        "choices": {
            "enabled": True,
            "min_options": 2,
            "max_options": 10,
            "warn_single_choice": True,
            "branch_coverage": {
                "enabled": True,
                "min_coverage_percent": 80,
                "warn_unreachable": True,
            },
            "severity": {
                "C01-001": "warning",  # Single choice menu
                "C01-002": "warning",  # Too many choices
                "C02-001": "warning",  # Low branch coverage
                "C02-002": "error",  # Unreachable branch
            },
        },
        "media": {
            "enabled": True,
            "extensions": [".png", ".jpg", ".jpeg", ".webp", ".ogg", ".mp3", ".wav"],
            "check_missing": True,
            "check_unused": True,
            "ignore_patterns": ["_old", "_backup", "test_"],
            "severity": {
                "M01-001": "error",  # Missing media file
                "M01-002": "warning",  # Unused media file
            },
        },
        "variables": {
            "enabled": True,
            "typo": {"distance": 2, "min_candidate_reads": 2},
            "builtins": [
                "config",
                "renpy",
                "persistent",
                "store",
                "gui",
                "style",
                "_preferences",
            ],
            "persistent": {
                "guard_window": 8,
                "version_vars": ["persistent_version", "save_version", "game_version"],
                "migration_markers": [
                    "migrate",
                    "migration",
                    "upgrade",
                    "version_check",
                ],
            },
            "score_like": {
                "include_name_patterns": [
                    "score",
                    "points",
                    "xp",
                    "experience",
                    "level",
                    "reputation",
                    "karma",
                    "honor",
                    "fame",
                    "coins",
                    "gold",
                    "money",
                    "cash",
                    "credits",
                    "trust",
                    "affection",
                    "love",
                    "friendship",
                    "relationship",
                    "bond",
                    "loyalty",
                ],
                "exclude_name_patterns": ["temp", "tmp", "debug", "test", "old", "new"],
                "min_observations": 4,
                "outlier_method": "iqr",
                "outlier_params": {
                    "iqr_k": 2.5,
                    "zscore_threshold": 3.0,
                    "mad_threshold": 3.5,
                },
            },
            "flags": {
                "boolean_patterns": [
                    "flag",
                    "enabled",
                    "disabled",
                    "active",
                    "inactive",
                    "seen",
                    "visited",
                    "unlocked",
                    "completed",
                    "finished",
                    "available",
                    "accessible",
                    "triggered",
                    "activated",
                ]
            },
            "severity": {
                "V01-001": "error",
                "V01-002": "warning",
                "V01-003": "warning",
                "V01-004": "warning",
                "V01-005": "warning",
                "V01-006": "warning",
                "V02-001": "warning",
                "V02-002": "warning",
                "V02-003": "error",
                "V02-004": "warning",
                "V03-001": "warning",
                "V03-002": "warning",
                "V03-003": "warning",
                "V03-004": "error",
                "V04-001": "warning",
                "V04-002": "warning",
                "V04-003": "warning",
            },
        },
    }
}


class ConfigValidationError(Exception):
    """Raised when configuration validation fails."""

    pass


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries, with override values taking precedence.

    Args:
        base: Base dictionary (defaults)
        override: Override dictionary (user config)

    Returns:
        Merged dictionary
    """
    result = copy.deepcopy(base)

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)

    return result


def validate_config(config: Dict[str, Any]) -> List[str]:
    """
    Validate configuration against schema rules.

    Args:
        config: Configuration dictionary to validate

    Returns:
        List of validation warnings (empty if valid)
    """
    warnings = []

    rules_config = config.get("rules", {})

    # Validate dialogue config
    dialogue_config = rules_config.get("dialogue", {})
    if "min_word_count" in dialogue_config:
        if (
            not isinstance(dialogue_config["min_word_count"], int)
            or dialogue_config["min_word_count"] < 0
        ):
            warnings.append(
                f"Invalid 'rules.dialogue.min_word_count': must be >= 0, got {dialogue_config['min_word_count']}"
            )
    if "reading_speed" in dialogue_config:
        speed = dialogue_config["reading_speed"]
        for key in ["fast_wpm", "normal_wpm", "slow_wpm"]:
            if key in speed:
                if not isinstance(speed[key], int) or speed[key] < 50:
                    warnings.append(
                        f"Invalid 'rules.dialogue.reading_speed.{key}': must be >= 50, got {speed[key]}"
                    )

    # Validate choice config
    choice_config = rules_config.get("choices", {})
    if "min_options" in choice_config:
        if (
            not isinstance(choice_config["min_options"], int)
            or choice_config["min_options"] < 1
        ):
            warnings.append(
                f"Invalid 'rules.choices.min_options': must be >= 1, got {choice_config['min_options']}"
            )
    if "branch_coverage" in choice_config:
        cov = choice_config["branch_coverage"]
        if "min_coverage_percent" in cov:
            if not isinstance(cov["min_coverage_percent"], (int, float)) or not (
                0 <= cov["min_coverage_percent"] <= 100
            ):
                warnings.append(
                    f"Invalid 'rules.choices.branch_coverage.min_coverage_percent': must be 0-100, got {cov['min_coverage_percent']}"
                )

    # Validate media config
    media_config = rules_config.get("media", {})
    if "extensions" in media_config:
        if not isinstance(media_config["extensions"], list):
            warnings.append(
                f"Invalid 'rules.media.extensions': must be a list, got {type(media_config['extensions']).__name__}"
            )

    # Validate variable config
    var_config = rules_config.get("variables", {})

    # Validate typo settings
    if "typo" in var_config:
        typo = var_config["typo"]
        if "distance" in typo:
            if not isinstance(typo["distance"], int) or typo["distance"] < 1:
                warnings.append(
                    f"Invalid 'rules.variables.typo.distance': must be >= 1, got {typo['distance']}"
                )
        if "min_candidate_reads" in typo:
            if (
                not isinstance(typo["min_candidate_reads"], int)
                or typo["min_candidate_reads"] < 1
            ):
                warnings.append(
                    f"Invalid 'rules.variables.typo.min_candidate_reads': must be >= 1, got {typo['min_candidate_reads']}"
                )

    # Validate builtins
    if "builtins" in var_config:
        if not isinstance(var_config["builtins"], list):
            warnings.append(
                f"Invalid 'rules.variables.builtins': must be a list, got {type(var_config['builtins']).__name__}"
            )
        elif not all(isinstance(b, str) for b in var_config["builtins"]):
            warnings.append(
                "Invalid 'rules.variables.builtins': all items must be strings"
            )

    # Validate persistent settings
    if "persistent" in var_config:
        persistent = var_config["persistent"]
        if "guard_window" in persistent:
            if (
                not isinstance(persistent["guard_window"], int)
                or persistent["guard_window"] < 1
            ):
                warnings.append(
                    f"Invalid 'rules.variables.persistent.guard_window': must be >= 1, got {persistent['guard_window']}"
                )

    # Validate score_like settings
    if "score_like" in var_config:
        score = var_config["score_like"]
        if "min_observations" in score:
            if (
                not isinstance(score["min_observations"], int)
                or score["min_observations"] < 3
            ):
                warnings.append(
                    f"Invalid 'rules.variables.score_like.min_observations': must be >= 3, got {score['min_observations']}"
                )
        if "outlier_method" in score:
            valid_methods = ["iqr", "zscore", "mad"]
            if score["outlier_method"] not in valid_methods:
                warnings.append(
                    f"Invalid 'rules.variables.score_like.outlier_method': must be one of {valid_methods}, got '{score['outlier_method']}'"
                )
        if "outlier_params" in score:
            params = score["outlier_params"]
            if "iqr_k" in params:
                if (
                    not isinstance(params["iqr_k"], (int, float))
                    or params["iqr_k"] < 1.0
                ):
                    warnings.append(
                        f"Invalid 'rules.variables.score_like.outlier_params.iqr_k': must be >= 1.0, got {params['iqr_k']}"
                    )

    # Validate severity overrides
    if "severity" in var_config:
        valid_severities = ["error", "warning", "info", "hint"]
        for rule, severity in var_config["severity"].items():
            if severity not in valid_severities:
                warnings.append(
                    f"Invalid severity for rule '{rule}': must be one of {valid_severities}, got '{severity}'"
                )

    return warnings


def load_config(user_config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Load and validate configuration, merging user config with defaults.

    Args:
        user_config: User-provided configuration (optional)

    Returns:
        Merged and validated configuration
    """
    # Start with defaults
    config = copy.deepcopy(DEFAULT_CONFIG)

    # Merge user config if provided
    if user_config:
        config = deep_merge(config, user_config)

    # Validate
    warnings = validate_config(config)

    # Log warnings (in production, use proper logger)
    if warnings:
        import sys

        for warning in warnings:
            print(f"WARNING: {warning}", file=sys.stderr)
            print("WARNING: Falling back to default value", file=sys.stderr)

    return config


def get_variable_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract variable analysis configuration section.

    Args:
        config: Full configuration dictionary

    Returns:
        Variable configuration section
    """
    return config.get("rules", {}).get("variables", {})


def is_variable_analysis_enabled(config: Dict[str, Any]) -> bool:
    """
    Check if variable analysis is enabled.

    Args:
        config: Full configuration dictionary

    Returns:
        True if variable analysis is enabled
    """
    var_config = get_variable_config(config)
    return var_config.get("enabled", True)


def get_severity(config: Dict[str, Any], rule: str) -> str:
    """
    Get severity level for a specific rule.

    Args:
        config: Full configuration dictionary
        rule: Rule ID (e.g., "V01-001", "D01-001", "C01-001", "M01-001")

    Returns:
        Severity level ("error", "warning", "info", or "hint")
    """
    # Determine which section to check based on rule prefix
    if rule.startswith("V"):
        section_name = "variables"
        section_config = get_variable_config(config)
    elif rule.startswith("D"):
        section_name = "dialogue"
        section_config = get_dialogue_config(config)
    elif rule.startswith("C"):
        section_name = "choices"
        section_config = get_choice_config(config)
    elif rule.startswith("M"):
        section_name = "media"
        section_config = get_media_config(config)
    else:
        # Unknown rule prefix, default to warning
        return "warning"

    severity_overrides = section_config.get("severity", {})

    # Get from overrides or use default
    default_severities = DEFAULT_CONFIG["rules"][section_name]["severity"]
    return severity_overrides.get(rule, default_severities.get(rule, "warning"))


def get_dialogue_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract dialogue analysis configuration section.

    Args:
        config: Full configuration dictionary

    Returns:
        Dialogue configuration section
    """
    return config.get("rules", {}).get("dialogue", {})


def is_dialogue_analysis_enabled(config: Dict[str, Any]) -> bool:
    """
    Check if dialogue analysis is enabled.

    Args:
        config: Full configuration dictionary

    Returns:
        True if dialogue analysis is enabled
    """
    dialogue_config = get_dialogue_config(config)
    return dialogue_config.get("enabled", True)


def get_choice_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract choice analysis configuration section.

    Args:
        config: Full configuration dictionary

    Returns:
        Choice configuration section
    """
    return config.get("rules", {}).get("choices", {})


def is_choice_analysis_enabled(config: Dict[str, Any]) -> bool:
    """
    Check if choice analysis is enabled.

    Args:
        config: Full configuration dictionary

    Returns:
        True if choice analysis is enabled
    """
    choice_config = get_choice_config(config)
    return choice_config.get("enabled", True)


def get_media_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract media analysis configuration section.

    Args:
        config: Full configuration dictionary

    Returns:
        Media configuration section
    """
    return config.get("rules", {}).get("media", {})


def is_media_analysis_enabled(config: Dict[str, Any]) -> bool:
    """
    Check if media analysis is enabled.

    Args:
        config: Full configuration dictionary

    Returns:
        True if media analysis is enabled
    """
    media_config = get_media_config(config)
    return media_config.get("enabled", True)
