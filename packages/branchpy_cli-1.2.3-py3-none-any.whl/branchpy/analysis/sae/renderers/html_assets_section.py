from __future__ import annotations

from typing import Any, Dict, List


def render_assets_section(summary: Dict[str, int], issues: List[Dict[str, Any]]) -> str:
    """
    Render the 'Assets & Media' HTML section for the unified report.
    `summary` must include: total_files, images, audio, video, fonts, image_definitions, references
    `issues` are JSON-serializable dicts (rule_id, severity, message, file, line, extra?)
    """

    def group(sev: str) -> list[Dict[str, Any]]:
        return [i for i in issues if str(i.get("severity", "")).upper() == sev]

    errors = group("ERROR")
    warns = group("WARN")
    infos = group("INFO")

    def badge(v: int, label: str) -> str:
        return f"""
        <div class="summary-card">
          <div class="card-value">{v}</div>
          <div class="card-label">{label}</div>
        </div>"""

    summary_html = f"""
    <div class="asset-summary-cards">
      {badge(summary.get('total_files', 0), 'Total Assets')}
      {badge(summary.get('images', 0), 'Images')}
      {badge(summary.get('audio', 0), 'Audio')}
      {badge(summary.get('video', 0), 'Video')}
      {badge(summary.get('fonts', 0), 'Fonts')}
    </div>"""

    def table(title: str, rows: list[Dict[str, Any]], klass: str) -> str:
        if not rows:
            return f'<h3>{title} (0)</h3><p class="no-issues">✓ No {title.lower()} found</p>'
        trs = []
        for i in rows:
            extra = i.get("extra") or {}
            sugg = extra.get("suggestions")
            extra_html = ""
            if sugg:
                extra_html = (
                    f"<br><small>Suggestions: {', '.join(map(str, sugg))}</small>"
                )
            size = extra.get("file_size")
            if size:
                extra_html += f"<br><small>File size: {int(size)//1024} KB</small>"
            trs.append(
                f"""
            <tr class="{klass}">
              <td class="severity-badge">{i.get('severity')}</td>
              <td class="rule-id">{i.get('rule_id')}</td>
              <td class="message">{i.get('message','')}{extra_html}</td>
              <td class="location"><a class="file-link" href="file://{i.get('file','')}">{i.get('file','')}</a>:<span class="line-number">{i.get('line','')}</span></td>
            </tr>"""
            )
        return f"""
        <h3>{title} ({len(rows)})</h3>
        <table class="issues-table {klass}">
          <thead><tr><th>Severity</th><th>Rule</th><th>Message</th><th>Location</th></tr></thead>
          <tbody>{''.join(trs)}</tbody>
        </table>"""

    section = f"""
    <section id="assets-section" class="report-section">
      <h2>📦 Assets &amp; Media</h2>
      {summary_html}
      <div class="issues-container">
        {table("Missing Assets (Errors)", errors, "error-row")}
        {table("Typo Warnings", warns, "warning-row")}
        {table("Unused Assets (Info)", infos, "info-row")}
      </div>
    </section>
    <style>
      .asset-summary-cards {{ display:flex; gap:15px; margin:20px 0; flex-wrap:wrap; }}
      .summary-card {{ background: var(--vscode-editor-background); border:1px solid var(--vscode-panel-border);
                       border-radius:8px; padding:15px 20px; text-align:center; min-width:120px; }}
      .card-value {{ font-size:32px; font-weight:bold; color: var(--vscode-textLink-foreground); }}
      .card-label {{ font-size:12px; color: var(--vscode-descriptionForeground); margin-top:5px; }}
      .issues-table {{ width:100%; border-collapse:collapse; margin:15px 0; }}
      .issues-table th {{ background: var(--vscode-editor-background); padding:10px; text-align:left;
                          border-bottom:2px solid var(--vscode-panel-border); }}
      .issues-table td {{ padding:10px; border-bottom:1px solid var(--vscode-panel-border); }}
      .error-row {{ background: rgba(244, 67, 54, 0.08); }}
      .warning-row {{ background: rgba(255, 152, 0, 0.10); }}
      .info-row {{ background: rgba(33, 150, 243, 0.08); }}
      .severity-badge {{ font-weight:bold; padding:4px 8px; border-radius:4px; font-size:11px; color:#fff; }}
      .error-row .severity-badge {{ background:#f44336; }}
      .warning-row .severity-badge {{ background:#ff9800; }}
      .info-row .severity-badge {{ background:#2196f3; }}
      .file-link {{ color: var(--vscode-textLink-foreground); text-decoration:none; }}
      .file-link:hover {{ text-decoration:underline; }}
      .line-number {{ color: var(--vscode-descriptionForeground); font-size:11px; }}
      .no-issues {{ color:#4caf50; padding:15px; text-align:center; font-weight:bold; }}
    </style>
    """
    return section
