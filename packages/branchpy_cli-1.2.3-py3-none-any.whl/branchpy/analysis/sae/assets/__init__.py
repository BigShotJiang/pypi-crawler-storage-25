"""
SAE Asset Validation Module - v0.8.7.5

Provides filesystem scanning, definition extraction, reference validation,
fuzzy matching, similarity detection, dimension validation, and governance
integration for Ren'Py assets (images, audio, video, fonts).

Extended in v0.8.7.5 with Image Validation V2 features.
"""

from .models import AssetFile, AssetIndex, AssetRef, AssetReferences, FontDef, ImageDef

# v0.8.7.5 additions
try:
    from .csv_export import AssetCSVExporter, AssetValidationRow, merge_similarity_data
    from .dimension_validator import (
        DimensionValidator,
        ValidationConfig,
        ValidationIssue,
        ValidationProfile,
        aspect_matches,
        choose_primary,
    )
    from .governance import AssetGovernanceEvent, GovernanceLogger
    from .similarity import ImageMetadata, ImageSimilarityDetector, SimilarityCluster
    from .sync_provider import AssetMetadata, AssetSyncProvider, SyncResult

    __all__ = [
        # Core models (v0.7.1)
        "AssetFile",
        "ImageDef",
        "FontDef",
        "AssetRef",
        "AssetReferences",
        "AssetIndex",
        # v0.8.7.5 additions
        "ImageSimilarityDetector",
        "ImageMetadata",
        "SimilarityCluster",
        "DimensionValidator",
        "ValidationConfig",
        "ValidationProfile",
        "ValidationIssue",
        "aspect_matches",
        "choose_primary",
        "AssetCSVExporter",
        "AssetValidationRow",
        "merge_similarity_data",
        "AssetGovernanceEvent",
        "GovernanceLogger",
        "AssetSyncProvider",
        "AssetMetadata",
        "SyncResult",
    ]
except ImportError:
    # v0.8.7.5 modules not available
    __all__ = [
        "AssetFile",
        "ImageDef",
        "FontDef",
        "AssetRef",
        "AssetReferences",
        "AssetIndex",
    ]
