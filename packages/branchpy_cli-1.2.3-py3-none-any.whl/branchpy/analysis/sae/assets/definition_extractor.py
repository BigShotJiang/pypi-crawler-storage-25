"""
Definition Extractor - Script Parsing

Extracts asset definitions from Ren'Py scripts:
- `image` statements
- Font definitions from style blocks
- Audio/video configuration hints
"""

import re
from pathlib import Path

from .asset_scanner import normalize_asset_key
from .models import FontDef, ImageDef, SrcLoc

# Regex patterns for definition extraction
# Updated to properly capture multi-word image names like "bg office_day"
IMAGE_DEF_PATTERN = re.compile(
    r"^\s*image\s+([a-zA-Z0-9_][\w\s]+?)\s*=\s*(.+?)$", re.MULTILINE
)

FONT_STYLE_PATTERN = re.compile(
    r'style\s+(\w+).*?font\s+["\']([^"\']+)["\']', re.DOTALL
)


class DefinitionExtractor:
    """
    Extracts asset definitions from Ren'Py script files.

    Parses .rpy files to find:
    - Image definitions: `image claire happy = "claire_happy.png"`
    - Font definitions: `style default: font "DejaVuSans.ttf"`
    - Layered image definitions (as raw expressions)
    """

    def extract_from_files(
        self, script_files: list[Path]
    ) -> tuple[dict[str, ImageDef], dict[str, FontDef]]:
        """
        Extract definitions from list of script files.

        Args:
            script_files: List of .rpy file paths to parse

        Returns:
            Tuple of (image_defs, font_defs) as dicts keyed by normalized name
        """
        image_defs: dict[str, ImageDef] = {}
        font_defs: dict[str, FontDef] = {}

        for script_file in script_files:
            try:
                content = script_file.read_text(encoding="utf-8")

                # Extract image definitions
                for img_def in self._extract_image_defs(content, script_file):
                    # Use normalized key for lookup
                    key = normalize_asset_key(img_def.name)
                    image_defs[key] = img_def

                # Extract font definitions
                for font_def in self._extract_font_defs(content, script_file):
                    key = normalize_asset_key(font_def.name)
                    font_defs[key] = font_def

            except Exception as e:
                # Log but don't fail on individual file errors
                # TODO: Add proper logging once logger integrated
                print(f"Warning: Failed to parse {script_file}: {e}")
                continue

        return image_defs, font_defs

    def _extract_image_defs(self, content: str, file_path: Path) -> list[ImageDef]:
        """
        Extract `image` definitions from script content.

        Matches patterns like:
            image claire happy = "claire_happy.png"
            image eileen concerned = "eileen/concerned.png"
            image bg city = "backgrounds/city.jpg"

        Args:
            content: Script file content
            file_path: Path for location tracking

        Returns:
            List of ImageDef objects
        """
        defs = []

        for match in IMAGE_DEF_PATTERN.finditer(content):
            name = match.group(1).strip()
            source = match.group(2).strip()

            # Remove quotes from source if present
            source = source.strip("\"'")

            # Calculate line number
            line_num = content[: match.start()].count("\n") + 1

            location = SrcLoc(
                file=str(file_path),
                line=line_num,
                col=match.start() - content.rfind("\n", 0, match.start()),
            )

            defs.append(ImageDef(name=name, source=source, location=location))

        return defs

    def _extract_font_defs(self, content: str, file_path: Path) -> list[FontDef]:
        """
        Extract font definitions from style blocks.

        Matches patterns like:
            style default:
                font "DejaVuSans.ttf"

            style gui_text:
                font "fonts/Roboto-Regular.ttf"

        Args:
            content: Script file content
            file_path: Path for location tracking

        Returns:
            List of FontDef objects
        """
        defs = []

        for match in FONT_STYLE_PATTERN.finditer(content):
            style_name = match.group(1).strip()
            font_path = match.group(2).strip()

            # Calculate line number
            line_num = content[: match.start()].count("\n") + 1

            location = SrcLoc(file=str(file_path), line=line_num, col=None)

            defs.append(FontDef(name=style_name, path=font_path, location=location))

        return defs


def extract_definitions(
    script_files: list[Path],
) -> tuple[dict[str, ImageDef], dict[str, FontDef]]:
    """
    Convenience function to extract definitions from scripts.

    Args:
        script_files: List of .rpy files to parse

    Returns:
        Tuple of (image_defs, font_defs)
    """
    extractor = DefinitionExtractor()
    return extractor.extract_from_files(script_files)
