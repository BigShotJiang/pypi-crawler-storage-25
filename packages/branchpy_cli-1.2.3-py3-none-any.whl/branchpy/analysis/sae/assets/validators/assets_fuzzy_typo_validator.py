"""
Fuzzy Typo Validator

Detects potential typos in asset references and suggests corrections.
"""

from typing import List

from ...validators.tier1 import Severity, ValidationIssue
from ..fuzzy import suggest_corrections
from ..models import AssetIndex


def validate_typo_image_reference(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: typo_image_reference

    Detect image references that don't match exactly but have close candidates.
    Only reports if suggestions exist (to avoid false positives).

    Severity: WARN
    Message: Unknown image "{raw}". Did you mean: {suggestions}?

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues with suggestions
    """
    issues = []

    # Build universe of valid keys (definitions + files)
    valid_keys = set(asset_index.image_defs.keys()) | set(asset_index.images.keys())

    for ref in asset_index.references.images:
        # Skip if already validated (exact match exists)
        if ref.logical in valid_keys:
            continue

        # Try to find similar candidates
        suggestions = suggest_corrections(
            ref.logical,
            list(valid_keys),
            min_score=0.5,  # Only suggest if reasonably close
        )

        # Only report if we have suggestions (avoid noise)
        if suggestions:
            suggestion_text = ", ".join(f'"{s}"' for s in suggestions[:3])
            issues.append(
                ValidationIssue(
                    rule_id="typo_image_reference",
                    severity=Severity.WARNING,
                    message=f'Unknown image "{ref.raw}". Did you mean: {suggestion_text}?',
                    file=ref.location.file,
                    line=ref.location.line,
                    column=ref.location.col or 0,
                    extra={
                        "logical": ref.logical,
                        "raw": ref.raw,
                        "suggestions": suggestions,
                    },
                )
            )

    return issues


def validate_typo_audio_reference(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: typo_audio_reference

    Detect audio references that don't match exactly but have close candidates.

    Severity: WARN
    Message: Unknown audio "{raw}" on channel {channel}. Did you mean: {suggestions}?

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues with suggestions
    """
    issues = []

    # Build universe of valid audio keys
    valid_keys = set(asset_index.audio.keys())

    for ref in asset_index.references.audio:
        # Skip if already validated
        if ref.logical in valid_keys:
            continue

        # Try to find similar candidates
        suggestions = suggest_corrections(ref.logical, list(valid_keys), min_score=0.5)

        if suggestions:
            suggestion_text = ", ".join(f'"{s}"' for s in suggestions[:3])
            issues.append(
                ValidationIssue(
                    rule_id="typo_audio_reference",
                    severity=Severity.WARNING,
                    message=f'Unknown audio "{ref.raw}" on channel {ref.channel}. Did you mean: {suggestion_text}?',
                    file=ref.location.file,
                    line=ref.location.line,
                    column=ref.location.col or 0,
                    extra={
                        "logical": ref.logical,
                        "raw": ref.raw,
                        "channel": ref.channel,
                        "suggestions": suggestions,
                    },
                )
            )

    return issues


def validate_all_typos(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Run all typo validators.

    Args:
        asset_index: Complete asset index for project

    Returns:
        Combined list of all typo issues with suggestions
    """
    issues = []
    issues.extend(validate_typo_image_reference(asset_index))
    issues.extend(validate_typo_audio_reference(asset_index))
    return issues
