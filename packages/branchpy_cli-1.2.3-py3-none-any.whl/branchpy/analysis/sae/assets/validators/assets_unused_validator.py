"""
Unused Asset Validators

Detects asset files on disk that are never referenced in scripts.
"""

from typing import List

from ...validators.tier1 import Severity, ValidationIssue
from ..models import AssetIndex


def validate_unused_image_file(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: unused_image_file

    Detect image files that are never referenced and have no definition.

    Severity: INFO (configurable to WARN)
    Message: Unused image file: {path}

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    # DEBUG logging
    import os

    if os.environ.get("CI"):
        print(
            f"[UNUSED_VALIDATOR] Images in index: {len(asset_index.images)}", flush=True
        )
        print(
            f"[UNUSED_VALIDATOR] Image refs: {len(asset_index.references.images)}",
            flush=True,
        )
        print(
            f"[UNUSED_VALIDATOR] Image defs: {len(asset_index.image_defs)}", flush=True
        )
        if asset_index.images:
            print(
                f"[UNUSED_VALIDATOR] First image: {list(asset_index.images.items())[0]}",
                flush=True,
            )

    # Get all referenced logical keys
    referenced_keys = {ref.logical for ref in asset_index.references.images}

    # Get all defined logical keys
    defined_keys = set(asset_index.image_defs.keys())

    # Find files that are neither referenced nor defined
    for logical, asset_file in asset_index.images.items():
        is_referenced = logical in referenced_keys
        is_defined = logical in defined_keys

        if not is_referenced and not is_defined:
            issues.append(
                ValidationIssue(
                    rule_id="unused_image_file",
                    severity=Severity.INFO,
                    message=f"Unused image file: {asset_file.path}",
                    file=asset_file.path,
                    line=0,  # No line number for filesystem files
                    column=0,
                    extra={
                        "logical": logical,
                        "path": asset_file.path,
                        "size_bytes": asset_file.size_bytes,
                    },
                )
            )

    return issues


def validate_unused_audio_file(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: unused_audio_file

    Detect audio files that are never referenced.

    Severity: INFO (configurable to WARN)
    Message: Unused audio file: {path}

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    # Get all referenced logical keys
    referenced_keys = {ref.logical for ref in asset_index.references.audio}

    # Find files that are not referenced
    for logical, asset_file in asset_index.audio.items():
        if logical not in referenced_keys:
            issues.append(
                ValidationIssue(
                    rule_id="unused_audio_file",
                    severity=Severity.INFO,
                    message=f"Unused audio file: {asset_file.path}",
                    file=asset_file.path,
                    line=0,
                    column=0,
                    extra={
                        "logical": logical,
                        "path": asset_file.path,
                        "size_bytes": asset_file.size_bytes,
                    },
                )
            )

    return issues


def validate_unused_video_file(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: unused_video_file

    Detect video files that are never referenced.

    Severity: INFO
    Message: Unused video file: {path}

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    # Get all referenced logical keys
    referenced_keys = {ref.logical for ref in asset_index.references.video}

    # Find files that are not referenced
    for logical, asset_file in asset_index.video.items():
        if logical not in referenced_keys:
            issues.append(
                ValidationIssue(
                    rule_id="unused_video_file",
                    severity=Severity.INFO,
                    message=f"Unused video file: {asset_file.path}",
                    file=asset_file.path,
                    line=0,
                    column=0,
                    extra={
                        "logical": logical,
                        "path": asset_file.path,
                        "size_bytes": asset_file.size_bytes,
                    },
                )
            )

    return issues


def validate_all_unused(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Run all unused asset validators.

    Args:
        asset_index: Complete asset index for project

    Returns:
        Combined list of all unused asset issues
    """
    issues = []
    issues.extend(validate_unused_image_file(asset_index))
    issues.extend(validate_unused_audio_file(asset_index))
    issues.extend(validate_unused_video_file(asset_index))
    return issues
