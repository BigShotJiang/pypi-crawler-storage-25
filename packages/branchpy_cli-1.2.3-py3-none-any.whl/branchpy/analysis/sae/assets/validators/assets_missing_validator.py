"""
Missing Asset Validators

Detects references to assets that don't exist (missing files or definitions).
"""

from typing import List

from ...validators.tier1 import Severity, ValidationIssue
from ..models import AssetIndex


def validate_missing_image_def(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: missing_image_def

    Detect image references (show/scene/hide) that have no matching definition
    or file on disk.

    Severity: ERROR
    Message: Image "{raw}" not defined and no matching file found.

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    for ref in asset_index.references.images:
        # Check if logical key matches any definition
        has_def = ref.logical in asset_index.image_defs

        # Check if logical key matches any file
        has_file = ref.logical in asset_index.images

        if not has_def and not has_file:
            issues.append(
                ValidationIssue(
                    rule_id="missing_image_def",
                    severity=Severity.ERROR,
                    message=f'Image "{ref.raw}" not defined and no matching file found.',
                    file=ref.location.file,
                    line=ref.location.line,
                    column=ref.location.col or 0,
                    extra={
                        "logical": ref.logical,
                        "raw": ref.raw,
                    },
                )
            )

    return issues


def validate_missing_image_file(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: missing_image_file

    Detect image definitions that reference non-existent files.

    Severity: ERROR
    Message: Image definition "{name}" references missing file "{path}".

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    for key, img_def in asset_index.image_defs.items():
        # Check if source file exists
        # Note: This is a simplified check - in reality, we'd need to resolve
        # the path relative to project root and check filesystem
        # For now, we check if the source matches any known file logical key
        from ..asset_scanner import normalize_asset_key

        source_key = normalize_asset_key(img_def.source)

        if source_key not in asset_index.images:
            issues.append(
                ValidationIssue(
                    rule_id="missing_image_file",
                    severity=Severity.ERROR,
                    message=f'Image definition "{img_def.name}" references missing file "{img_def.source}".',
                    file=img_def.location.file,
                    line=img_def.location.line,
                    column=img_def.location.col or 0,
                    extra={
                        "definition_name": img_def.name,
                        "source_path": img_def.source,
                    },
                )
            )

    return issues


def validate_missing_audio_file(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: missing_audio_file

    Detect audio references (play music/sound/voice) that don't match any file.

    Severity: ERROR
    Message: Audio "{raw}" not found on channel {channel}.

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    for ref in asset_index.references.audio:
        # Check if logical key matches any audio file
        if ref.logical not in asset_index.audio:
            issues.append(
                ValidationIssue(
                    rule_id="missing_audio_file",
                    severity=Severity.ERROR,
                    message=f'Audio "{ref.raw}" not found on channel {ref.channel}.',
                    file=ref.location.file,
                    line=ref.location.line,
                    column=ref.location.col or 0,
                    extra={
                        "logical": ref.logical,
                        "raw": ref.raw,
                        "channel": ref.channel,
                    },
                )
            )

    return issues


def validate_missing_video_file(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Rule: missing_video_file

    Detect video references that don't match any file.

    Severity: ERROR
    Message: Video "{raw}" not found.

    Args:
        asset_index: Complete asset index for project

    Returns:
        List of validation issues
    """
    issues = []

    for ref in asset_index.references.video:
        # Check if logical key matches any video file
        if ref.logical not in asset_index.video:
            issues.append(
                ValidationIssue(
                    rule_id="missing_video_file",
                    severity=Severity.ERROR,
                    message=f'Video "{ref.raw}" not found.',
                    file=ref.location.file,
                    line=ref.location.line,
                    column=ref.location.col or 0,
                    extra={
                        "logical": ref.logical,
                        "raw": ref.raw,
                    },
                )
            )

    return issues


def validate_all_missing(asset_index: AssetIndex) -> List[ValidationIssue]:
    """
    Run all missing asset validators.

    Args:
        asset_index: Complete asset index for project

    Returns:
        Combined list of all missing asset issues
    """
    issues = []
    issues.extend(validate_missing_image_def(asset_index))
    issues.extend(validate_missing_image_file(asset_index))
    issues.extend(validate_missing_audio_file(asset_index))
    issues.extend(validate_missing_video_file(asset_index))
    return issues
