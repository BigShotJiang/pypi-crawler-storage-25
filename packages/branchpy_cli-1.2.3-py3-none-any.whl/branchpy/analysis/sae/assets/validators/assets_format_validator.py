"""
Asset Format Validators (Phase 2.5 Session F)

Validates asset file formats for compatibility and best practices.
Focuses on audio/video format recommendations for web distribution.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from ...validators.tier1 import Severity, ValidationIssue

if TYPE_CHECKING:
    from ..models import AssetIndex


# Recommended formats for Ren'Py/web distribution
PREFERRED_AUDIO_FORMATS = {".ogg", ".opus"}  # Better compression, open formats
ACCEPTABLE_AUDIO_FORMATS = {".mp3", ".wav", ".flac"}  # Widely supported
DEPRECATED_AUDIO_FORMATS = {".wma", ".aac", ".m4a"}  # Limited browser support

PREFERRED_VIDEO_FORMATS = {".webm", ".ogv"}  # Open, web-optimized
ACCEPTABLE_VIDEO_FORMATS = {".mp4", ".mkv"}  # Widely supported
DEPRECATED_VIDEO_FORMATS = {".avi", ".wmv", ".flv", ".mov"}  # Large/outdated


def validate_audio_format_mismatch(idx: "AssetIndex") -> list[ValidationIssue]:
    """
    Detect audio files using suboptimal formats.

    Recommends .ogg/.opus over .mp3 for:
    - Better compression (smaller file sizes)
    - Open format (no licensing issues)
    - Native Ren'Py support

    Warns about deprecated formats (.wma, .aac, .m4a) with limited browser support.

    Args:
        idx: AssetIndex with scanned audio files

    Returns:
        List of WARN severity issues for suboptimal formats

    Example Issue:
        {
            "rule_id": "audio_format_mismatch",
            "severity": "warning",
            "message": "Audio file 'theme.mp3' uses .mp3 format. Consider .ogg for better compression.",
            "file": "game/audio/theme.mp3",
            "line": 0,
            "extra": {
                "current_format": ".mp3",
                "suggested_formats": [".ogg", ".opus"]
            }
        }
    """
    issues = []

    for logical_key, asset in idx.audio.items():
        ext = asset.ext.lower()

        # Deprecated formats - high priority warning
        if ext in DEPRECATED_AUDIO_FORMATS:
            issues.append(
                ValidationIssue(
                    rule_id="audio_format_mismatch",
                    severity=Severity.WARNING,
                    message=f"Audio file '{asset.path}' uses deprecated {ext} format. Recommend .ogg for wider compatibility.",
                    file=str(asset.path),
                    line=0,
                    extra={
                        "current_format": ext,
                        "suggested_formats": list(PREFERRED_AUDIO_FORMATS),
                        "reason": "deprecated_format",
                    },
                )
            )

        # Acceptable but not optimal formats - info/suggestion
        elif ext in ACCEPTABLE_AUDIO_FORMATS and ext != ".ogg":
            issues.append(
                ValidationIssue(
                    rule_id="audio_format_mismatch",
                    severity=Severity.WARNING,
                    message=f"Audio file '{asset.path}' uses {ext} format. Consider .ogg for better compression and open licensing.",
                    file=str(asset.path),
                    line=0,
                    extra={
                        "current_format": ext,
                        "suggested_formats": list(PREFERRED_AUDIO_FORMATS),
                        "reason": "suboptimal_format",
                    },
                )
            )

    return issues


def validate_audio_channel_inconsistent(idx: "AssetIndex") -> list[ValidationIssue]:
    """
    Detect inconsistent audio channel configurations (mono vs stereo).

    Mixed channel counts can indicate:
    - Inconsistent asset pipeline
    - Potential volume/quality discrepancies
    - Unintentional mono exports

    This is informational - both mono and stereo are valid, but consistency
    is preferred for user experience.

    Args:
        idx: AssetIndex with scanned audio files

    Returns:
        List of INFO severity issues if channel inconsistency detected

    Example Issue:
        {
            "rule_id": "audio_channel_inconsistent",
            "severity": "info",
            "message": "Project mixes mono and stereo audio files. Consider standardizing for consistency.",
            "file": "game/audio",
            "line": 0,
            "extra": {
                "mono_files": ["sfx_click.ogg", "sfx_beep.ogg"],
                "stereo_files": ["theme.ogg", "ambient.ogg"],
                "recommendation": "Use stereo for music/ambient, mono for short SFX"
            }
        }
    """
    issues = []

    # Note: Channel detection requires audio file metadata parsing
    # For now, we'll provide a placeholder that detects based on naming conventions
    # A full implementation would use libraries like mutagen, pydub, or ffprobe

    # Heuristic: files with "music", "theme", "ambient" are likely stereo
    # Files with "sfx", "click", "beep" are likely mono
    potential_stereo = []
    potential_mono = []

    for logical_key, asset in idx.audio.items():
        name_lower = Path(asset.path).stem.lower()

        # Heuristic classification (would be replaced with actual metadata reading)
        if any(
            keyword in name_lower
            for keyword in ["music", "theme", "ambient", "bgm", "background"]
        ):
            potential_stereo.append(asset.path)
        elif any(
            keyword in name_lower
            for keyword in ["sfx", "sound", "effect", "click", "beep", "voice"]
        ):
            potential_mono.append(asset.path)

    # If we have both categories, suggest standardization
    if potential_stereo and potential_mono and len(idx.audio) >= 3:
        issues.append(
            ValidationIssue(
                rule_id="audio_channel_inconsistent",
                severity=Severity.INFO,
                message=f"Project appears to mix different audio types ({len(potential_stereo)} music/ambient, {len(potential_mono)} SFX). Ensure channel count is appropriate for each type.",
                file="game/audio",
                line=0,
                extra={
                    "music_ambient_count": len(potential_stereo),
                    "sfx_count": len(potential_mono),
                    "recommendation": "Use stereo (2ch) for music/ambient, mono (1ch) for short SFX to optimize file size",
                },
            )
        )

    return issues


def validate_unsupported_video_format(idx: "AssetIndex") -> list[ValidationIssue]:
    """
    Detect video files using unsupported or suboptimal formats.

    Recommends .webm/.ogv for:
    - Best web compatibility
    - Open formats (no licensing)
    - Efficient compression
    - Ren'Py native support

    Warns about deprecated formats (.avi, .wmv, .flv, .mov) with:
    - Large file sizes
    - Limited browser support
    - Potential playback issues

    Args:
        idx: AssetIndex with scanned video files

    Returns:
        List of WARN severity issues for unsupported formats

    Example Issue:
        {
            "rule_id": "unsupported_video_format",
            "severity": "warning",
            "message": "Video file 'intro.avi' uses .avi format. Recommend .webm for better compression and web support.",
            "file": "game/video/intro.avi",
            "line": 0,
            "extra": {
                "current_format": ".avi",
                "suggested_formats": [".webm", ".ogv"],
                "file_size_mb": 45.2
            }
        }
    """
    issues = []

    for logical_key, asset in idx.video.items():
        ext = asset.ext.lower()
        file_size_mb = asset.size_bytes / (1024 * 1024)

        # Deprecated/problematic formats - high priority
        if ext in DEPRECATED_VIDEO_FORMATS:
            issues.append(
                ValidationIssue(
                    rule_id="unsupported_video_format",
                    severity=Severity.WARNING,
                    message=f"Video file '{asset.path}' uses deprecated {ext} format. Recommend .webm for better compression and web support.",
                    file=str(asset.path),
                    line=0,
                    extra={
                        "current_format": ext,
                        "suggested_formats": list(PREFERRED_VIDEO_FORMATS),
                        "file_size_mb": round(file_size_mb, 2),
                        "reason": "deprecated_format",
                    },
                )
            )

        # Acceptable but not optimal formats
        elif ext in ACCEPTABLE_VIDEO_FORMATS and ext not in PREFERRED_VIDEO_FORMATS:
            # Only warn if file is large (> 10MB) - optimization opportunity
            if file_size_mb > 10:
                issues.append(
                    ValidationIssue(
                        rule_id="unsupported_video_format",
                        severity=Severity.WARNING,
                        message=f"Video file '{asset.path}' ({file_size_mb:.1f}MB) uses {ext}. Consider .webm for {30-50}% smaller file size.",
                        file=str(asset.path),
                        line=0,
                        extra={
                            "current_format": ext,
                            "suggested_formats": list(PREFERRED_VIDEO_FORMATS),
                            "file_size_mb": round(file_size_mb, 2),
                            "reason": "large_file_optimization",
                        },
                    )
                )

    return issues
