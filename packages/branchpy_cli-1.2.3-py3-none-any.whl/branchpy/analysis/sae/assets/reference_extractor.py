"""
Reference Extractor - Script Reference Parsing

Extracts asset references from Ren'Py scripts:
- Image references: show, hide, scene
- Audio references: play music/sound/voice
- Video references: movie cutscene, play movie
- Font references: style font usage
"""

import re
from pathlib import Path

from .asset_scanner import normalize_asset_key
from .models import AssetRef, AssetReferences, SrcLoc

# Regex patterns for reference extraction
# Image references: show, hide, scene
# Updated to capture multi-word image names like "bg office_day", "claire happy"
# Stops at keywords (at, with, as, onlayer, behind) or end of line
IMAGE_SHOW_PATTERN = re.compile(
    r"^\s*show\s+([a-zA-Z0-9_][\w\s]+?)(?:\s+(?:at|with|as|onlayer|behind)\s|\s*(?:#|$))",
    re.MULTILINE,
)
IMAGE_HIDE_PATTERN = re.compile(
    r"^\s*hide\s+([a-zA-Z0-9_][\w\s]+?)(?:\s+(?:with|onlayer)\s|\s*(?:#|$))",
    re.MULTILINE,
)
IMAGE_SCENE_PATTERN = re.compile(
    r"^\s*scene\s+([a-zA-Z0-9_][\w\s]+?)(?:\s+(?:with|onlayer)\s|\s*(?:#|$))",
    re.MULTILINE,
)

# Audio references: play music/sound/voice
AUDIO_PLAY_PATTERN = re.compile(
    r'^\s*play\s+(music|sound|voice)\s+["\']([^"\']+)["\']', re.MULTILINE
)
AUDIO_VOICE_PATTERN = re.compile(r'^\s*voice\s+["\']([^"\']+)["\']', re.MULTILINE)

# Video references
VIDEO_MOVIE_PATTERN = re.compile(
    r'renpy\.movie_cutscene\(["\']([^"\']+)["\']', re.MULTILINE
)
VIDEO_PLAY_PATTERN = re.compile(r'^\s*play\s+movie\s+["\']([^"\']+)["\']', re.MULTILINE)


class ReferenceExtractor:
    """
    Extracts asset references from Ren'Py script files.

    Parses .rpy files to find all references to images, audio, video, and fonts
    that will be cross-validated against filesystem and definitions.
    """

    def extract_from_files(self, script_files: list[Path]) -> AssetReferences:
        """
        Extract all asset references from script files.

        Args:
            script_files: List of .rpy file paths to parse

        Returns:
            AssetReferences containing all discovered references
        """
        images: list[AssetRef] = []
        audio: list[AssetRef] = []
        video: list[AssetRef] = []
        fonts: list[AssetRef] = []

        for script_file in script_files:
            try:
                content = script_file.read_text(encoding="utf-8")

                # Extract image references
                images.extend(self._extract_image_refs(content, script_file))

                # Extract audio references
                audio.extend(self._extract_audio_refs(content, script_file))

                # Extract video references
                video.extend(self._extract_video_refs(content, script_file))

                # Extract font references (future)
                # fonts.extend(self._extract_font_refs(content, script_file))

            except Exception as e:
                # Log but don't fail on individual file errors
                print(f"Warning: Failed to parse {script_file}: {e}")
                continue

        return AssetReferences(
            images=images,
            audio=audio,
            video=video,
            fonts=fonts,
        )

    def _extract_image_refs(self, content: str, file_path: Path) -> list[AssetRef]:
        """
        Extract image references (show/hide/scene).

        Matches patterns like:
            show claire happy
            hide eileen
            scene bg city
            show claire happy at left with dissolve

        Args:
            content: Script file content
            file_path: Path for location tracking

        Returns:
            List of AssetRef objects for images
        """
        refs = []

        # Extract 'show' statements
        for match in IMAGE_SHOW_PATTERN.finditer(content):
            name = match.group(1).strip()
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="image",
                    logical=normalize_asset_key(name),
                    raw=name,
                    location=SrcLoc(file=str(file_path), line=line_num),
                )
            )

        # Extract 'hide' statements
        for match in IMAGE_HIDE_PATTERN.finditer(content):
            name = match.group(1).strip()
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="image",
                    logical=normalize_asset_key(name),
                    raw=name,
                    location=SrcLoc(file=str(file_path), line=line_num),
                )
            )

        # Extract 'scene' statements
        for match in IMAGE_SCENE_PATTERN.finditer(content):
            name = match.group(1).strip()
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="image",
                    logical=normalize_asset_key(name),
                    raw=name,
                    location=SrcLoc(file=str(file_path), line=line_num),
                )
            )

        return refs

    def _extract_audio_refs(self, content: str, file_path: Path) -> list[AssetRef]:
        """
        Extract audio references (play music/sound/voice).

        Matches patterns like:
            play music "bgm.mp3"
            play sound "sfx_click.ogg"
            voice "claire/happy_01.ogg"

        Args:
            content: Script file content
            file_path: Path for location tracking

        Returns:
            List of AssetRef objects for audio
        """
        refs = []

        # Extract 'play music/sound/voice' statements
        for match in AUDIO_PLAY_PATTERN.finditer(content):
            channel = match.group(1)  # music, sound, or voice
            audio_path = match.group(2)
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="audio",
                    logical=normalize_asset_key(audio_path),
                    raw=audio_path,
                    location=SrcLoc(file=str(file_path), line=line_num),
                    channel=channel,
                )
            )

        # Extract standalone 'voice' statements
        for match in AUDIO_VOICE_PATTERN.finditer(content):
            audio_path = match.group(1)
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="audio",
                    logical=normalize_asset_key(audio_path),
                    raw=audio_path,
                    location=SrcLoc(file=str(file_path), line=line_num),
                    channel="voice",
                )
            )

        return refs

    def _extract_video_refs(self, content: str, file_path: Path) -> list[AssetRef]:
        """
        Extract video references.

        Matches patterns like:
            renpy.movie_cutscene("intro.mp4")
            play movie "cutscene.webm"

        Args:
            content: Script file content
            file_path: Path for location tracking

        Returns:
            List of AssetRef objects for video
        """
        refs = []

        # Extract renpy.movie_cutscene calls
        for match in VIDEO_MOVIE_PATTERN.finditer(content):
            video_path = match.group(1)
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="video",
                    logical=normalize_asset_key(video_path),
                    raw=video_path,
                    location=SrcLoc(file=str(file_path), line=line_num),
                )
            )

        # Extract 'play movie' statements
        for match in VIDEO_PLAY_PATTERN.finditer(content):
            video_path = match.group(1)
            line_num = content[: match.start()].count("\n") + 1

            refs.append(
                AssetRef(
                    kind="video",
                    logical=normalize_asset_key(video_path),
                    raw=video_path,
                    location=SrcLoc(file=str(file_path), line=line_num),
                )
            )

        return refs


def extract_references(script_files: list[Path]) -> AssetReferences:
    """
    Convenience function to extract references from scripts.

    Args:
        script_files: List of .rpy files to parse

    Returns:
        AssetReferences with all discovered references
    """
    extractor = ReferenceExtractor()
    return extractor.extract_from_files(script_files)
