"""
Asset Data Models

Immutable data structures for representing Ren'Py assets discovered via
filesystem scanning and script parsing.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class SrcLoc:
    """Source code location for definitions and references."""

    file: str
    line: int
    col: Optional[int] = None

    def __str__(self) -> str:
        if self.col is not None:
            return f"{self.file}:{self.line}:{self.col}"
        return f"{self.file}:{self.line}"


@dataclass(frozen=True)
class AssetFile:
    """
    Represents a physical file on disk (image/audio/video/font).

    Attributes:
        logical: Normalized key (lowercase, underscores, no ext)
        path: Relative path from project root (e.g., 'game/images/claire_happy.png')
        ext: File extension with dot (e.g., '.png', '.mp3')
        size_bytes: File size in bytes
        hash_md5: Optional MD5 hash for content identity (future caching)
    """

    logical: str
    path: str
    ext: str
    size_bytes: int
    hash_md5: Optional[str] = None


@dataclass(frozen=True)
class ImageDef:
    """
    Represents an `image` definition from Ren'Py script.

    Example:
        image claire happy = "claire_happy.png"
        image eileen = "eileen_happy.png"

    Attributes:
        name: Logical image name as defined (e.g., 'claire happy')
        source: Source expression (file path or layered image expression)
        location: Where this definition appears in code
    """

    name: str
    source: str
    location: SrcLoc


@dataclass(frozen=True)
class FontDef:
    """
    Represents a font definition from style blocks.

    Example:
        style default:
            font "DejaVuSans.ttf"

    Attributes:
        name: Style name or font identifier
        path: Path to font file
        location: Where this definition appears
    """

    name: str
    path: str
    location: SrcLoc


@dataclass(frozen=True)
class AssetRef:
    """
    Represents a reference to an asset in Ren'Py script.

    Examples:
        show claire happy     -> kind='image', logical='claire_happy'
        play music "bgm.mp3"  -> kind='audio', channel='music'

    Attributes:
        kind: Asset type ('image', 'audio', 'video', 'font')
        logical: Normalized key for matching
        raw: Raw token as it appears in source
        location: Where this reference appears
        channel: Audio channel if applicable ('music', 'sound', 'voice')
    """

    kind: str
    logical: str
    raw: str
    location: SrcLoc
    channel: Optional[str] = None


@dataclass(frozen=True)
class AssetReferences:
    """
    Collection of all asset references extracted from scripts.

    Organized by asset type for efficient validation.
    """

    images: list[AssetRef] = field(default_factory=list)
    audio: list[AssetRef] = field(default_factory=list)
    video: list[AssetRef] = field(default_factory=list)
    fonts: list[AssetRef] = field(default_factory=list)

    def all_refs(self) -> list[AssetRef]:
        """Return flattened list of all references."""
        return self.images + self.audio + self.video + self.fonts


@dataclass(frozen=True)
class AssetIndex:
    """
    Complete asset index for a Ren'Py project.

    Built by combining filesystem scans (AssetScanner) and script parsing
    (DefinitionExtractor, ReferenceExtractor).

    Stored in ProjectSnapshot.assets and consumed by asset validators.

    Attributes:
        images: Physical image files indexed by logical name
        audio: Physical audio files indexed by logical name
        video: Physical video files indexed by logical name
        fonts: Physical font files indexed by logical name
        image_defs: Image definitions from scripts
        font_defs: Font definitions from styles
        references: All asset references from scripts
    """

    images: dict[str, AssetFile] = field(default_factory=dict)
    audio: dict[str, AssetFile] = field(default_factory=dict)
    video: dict[str, AssetFile] = field(default_factory=dict)
    fonts: dict[str, AssetFile] = field(default_factory=dict)
    image_defs: dict[str, ImageDef] = field(default_factory=dict)
    font_defs: dict[str, FontDef] = field(default_factory=dict)
    references: AssetReferences = field(default_factory=AssetReferences)

    def total_files(self) -> int:
        """Total count of physical asset files."""
        return len(self.images) + len(self.audio) + len(self.video) + len(self.fonts)

    def total_defs(self) -> int:
        """Total count of script definitions."""
        return len(self.image_defs) + len(self.font_defs)

    def total_refs(self) -> int:
        """Total count of asset references."""
        return len(self.references.all_refs())
