"""Image Similarity Detection Engine - v0.8.7.5

Detects similar and duplicate images using perceptual hashing and clustering.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# Optional dependencies
try:
    from PIL import Image

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import imagehash

    IMAGEHASH_AVAILABLE = True
except ImportError:
    IMAGEHASH_AVAILABLE = False


@dataclass
class ImageMetadata:
    """Metadata for an image file."""

    path: Path
    """File path"""

    width: int = 0
    """Image width in pixels"""

    height: int = 0
    """Image height in pixels"""

    size_bytes: int = 0
    """File size in bytes"""

    format: str = ""
    """Image format (PNG, JPEG, etc.)"""

    aspect_ratio: float = 0.0
    """Width / height ratio"""

    perceptual_hash: Optional[str] = None
    """Perceptual hash for similarity detection"""

    md5_hash: Optional[str] = None
    """MD5 hash for exact duplicate detection"""

    cluster_id: Optional[int] = None
    """Similarity cluster ID"""

    @property
    def size_kb(self) -> float:
        """File size in kilobytes."""
        return self.size_bytes / 1024.0

    def to_dict(self) -> Dict:
        """Export as dictionary."""
        return {
            "path": str(self.path),
            "width": self.width,
            "height": self.height,
            "size_kb": round(self.size_kb, 2),
            "format": self.format,
            "aspect_ratio": round(self.aspect_ratio, 3),
            "perceptual_hash": self.perceptual_hash,
            "md5_hash": self.md5_hash,
            "cluster_id": self.cluster_id,
        }


@dataclass
class SimilarityCluster:
    """Group of similar images."""

    cluster_id: int
    """Unique cluster ID"""

    images: List[ImageMetadata] = field(default_factory=list)
    """Images in this cluster"""

    representative: Optional[ImageMetadata] = None
    """Representative image for the cluster"""

    similarity_score: float = 1.0
    """Average similarity score within cluster"""

    def add_image(self, image: ImageMetadata) -> None:
        """Add image to cluster."""
        self.images.append(image)
        image.cluster_id = self.cluster_id

        # Update representative (choose largest by size)
        if not self.representative or image.size_bytes > self.representative.size_bytes:
            self.representative = image

    def to_dict(self) -> Dict:
        """Export as dictionary."""
        return {
            "cluster_id": self.cluster_id,
            "image_count": len(self.images),
            "images": [img.to_dict() for img in self.images],
            "representative": (
                self.representative.to_dict() if self.representative else None
            ),
            "similarity_score": round(self.similarity_score, 3),
        }


class ImageSimilarityDetector:
    """Detects similar and duplicate images."""

    def __init__(
        self,
        similarity_threshold: float = 0.90,
        hash_size: int = 8,
    ):
        """Initialize similarity detector.

        Args:
            similarity_threshold: Threshold for considering images similar (0.0-1.0)
            hash_size: Size of perceptual hash (default 8x8)
        """
        if not PIL_AVAILABLE:
            raise ImportError(
                "PIL/Pillow is required for image similarity detection. Install with: pip install Pillow"
            )

        self.similarity_threshold = similarity_threshold
        self.hash_size = hash_size
        self.use_imagehash = IMAGEHASH_AVAILABLE

        self.images: Dict[str, ImageMetadata] = {}
        self.clusters: List[SimilarityCluster] = []

    def scan_directory(
        self,
        directory: str | Path,
        extensions: Optional[Set[str]] = None,
    ) -> List[ImageMetadata]:
        """Scan directory for images and extract metadata.

        Args:
            directory: Directory to scan
            extensions: Set of extensions to include (default: {'.png', '.jpg', '.jpeg', '.webp'})

        Returns:
            List of image metadata
        """
        if extensions is None:
            extensions = {".png", ".jpg", ".jpeg", ".webp", ".gif"}

        directory = Path(directory)
        images = []

        for ext in extensions:
            for img_path in directory.rglob(f"*{ext}"):
                if img_path.is_file():
                    metadata = self.extract_metadata(img_path)
                    if metadata:
                        images.append(metadata)
                        self.images[str(img_path)] = metadata

        return images

    def extract_metadata(self, image_path: str | Path) -> Optional[ImageMetadata]:
        """Extract metadata from image file.

        Args:
            image_path: Path to image

        Returns:
            Image metadata or None if failed
        """
        path = Path(image_path)

        if not path.exists():
            return None

        try:
            # Get file size
            size_bytes = path.stat().st_size

            # Open image and get dimensions
            with Image.open(path) as img:
                width, height = img.size
                format_name = img.format or ""

                # Calculate aspect ratio
                aspect = width / height if height > 0 else 0.0

                # Calculate perceptual hash
                p_hash = self._calculate_perceptual_hash(img)

                # Calculate MD5 hash
                md5_hash = self._calculate_md5(path)

                return ImageMetadata(
                    path=path,
                    width=width,
                    height=height,
                    size_bytes=size_bytes,
                    format=format_name,
                    aspect_ratio=aspect,
                    perceptual_hash=p_hash,
                    md5_hash=md5_hash,
                )

        except Exception:
            return None

    def _calculate_perceptual_hash(self, img: Image.Image) -> str:
        """Calculate perceptual hash for image.

        Args:
            img: PIL Image object

        Returns:
            Hex string of perceptual hash
        """
        if self.use_imagehash:
            # Use imagehash library for better accuracy
            return str(imagehash.average_hash(img, hash_size=self.hash_size))
        else:
            # Fallback: simple average hash
            # Resize to hash_size x hash_size
            img_resized = img.resize(
                (self.hash_size, self.hash_size), Image.Resampling.LANCZOS
            )
            img_gray = img_resized.convert("L")

            # Get pixel values
            pixels = list(img_gray.getdata())
            avg = sum(pixels) / len(pixels)

            # Create hash: 1 if pixel > avg, 0 otherwise
            bits = "".join("1" if p > avg else "0" for p in pixels)

            # Convert to hex
            return hex(int(bits, 2))[2:].zfill(self.hash_size * self.hash_size // 4)

    def _calculate_md5(self, file_path: Path) -> str:
        """Calculate MD5 hash of file.

        Args:
            file_path: Path to file

        Returns:
            MD5 hash hex string
        """
        md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                md5.update(chunk)
        return md5.hexdigest()

    def find_duplicates(self) -> List[List[ImageMetadata]]:
        """Find exact duplicates using MD5 hash.

        Returns:
            List of duplicate groups
        """
        hash_map: Dict[str, List[ImageMetadata]] = {}

        for img in self.images.values():
            if img.md5_hash:
                if img.md5_hash not in hash_map:
                    hash_map[img.md5_hash] = []
                hash_map[img.md5_hash].append(img)

        # Return only groups with 2+ images
        return [group for group in hash_map.values() if len(group) > 1]

    def compute_similarity(self, hash1: str, hash2: str) -> float:
        """Compute similarity between two perceptual hashes.

        Args:
            hash1: First hash
            hash2: Second hash

        Returns:
            Similarity score (0.0 to 1.0)
        """
        if not hash1 or not hash2:
            return 0.0

        if self.use_imagehash:
            # Use imagehash library
            h1 = imagehash.hex_to_hash(hash1)
            h2 = imagehash.hex_to_hash(hash2)
            distance = h1 - h2
            max_distance = len(hash1) * 4  # 4 bits per hex digit
            return 1.0 - (distance / max_distance)
        else:
            # Fallback: Hamming distance on hex strings
            if len(hash1) != len(hash2):
                return 0.0

            # Convert to binary and count differences
            try:
                bits1 = bin(int(hash1, 16))[2:].zfill(len(hash1) * 4)
                bits2 = bin(int(hash2, 16))[2:].zfill(len(hash2) * 4)

                differences = sum(c1 != c2 for c1, c2 in zip(bits1, bits2))
                total_bits = len(bits1)

                return 1.0 - (differences / total_bits)
            except ValueError:
                return 0.0

    def cluster_similar_images(self) -> List[SimilarityCluster]:
        """Cluster similar images.

        Returns:
            List of similarity clusters
        """
        self.clusters = []
        processed: Set[str] = set()
        cluster_id = 0

        image_list = list(self.images.values())

        for i, img1 in enumerate(image_list):
            if str(img1.path) in processed:
                continue

            # Start new cluster
            cluster = SimilarityCluster(cluster_id=cluster_id)
            cluster.add_image(img1)
            processed.add(str(img1.path))

            # Find similar images
            for img2 in image_list[i + 1 :]:
                if str(img2.path) in processed:
                    continue

                if img1.perceptual_hash and img2.perceptual_hash:
                    similarity = self.compute_similarity(
                        img1.perceptual_hash, img2.perceptual_hash
                    )

                    if similarity >= self.similarity_threshold:
                        cluster.add_image(img2)
                        processed.add(str(img2.path))

            # Only save cluster if it has multiple images
            if len(cluster.images) > 1:
                self.clusters.append(cluster)
                cluster_id += 1

        return self.clusters

    def suggest_replacements(
        self,
        cluster: SimilarityCluster,
    ) -> List[Tuple[ImageMetadata, ImageMetadata]]:
        """Suggest replacements for images in cluster.

        Args:
            cluster: Similarity cluster

        Returns:
            List of (source, target) replacement pairs
        """
        if not cluster.representative:
            return []

        replacements = []
        for img in cluster.images:
            if img != cluster.representative:
                replacements.append((img, cluster.representative))

        return replacements

    def export_report(self, output_file: str | Path) -> None:
        """Export similarity report to JSON.

        Args:
            output_file: Path to output file
        """
        import json

        data = {
            "total_images": len(self.images),
            "total_clusters": len(self.clusters),
            "similarity_threshold": self.similarity_threshold,
            "clusters": [c.to_dict() for c in self.clusters],
            "duplicates": [
                [img.to_dict() for img in group] for group in self.find_duplicates()
            ],
        }

        Path(output_file).write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
        )
