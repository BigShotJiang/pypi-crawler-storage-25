"""Asset Synchronization Provider Interface - v0.8.7.5

Plugin architecture for integrating external asset management systems.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class AssetMetadata:
    """Metadata for an asset in external system."""

    asset_id: str
    """Unique identifier in external system"""

    name: str
    """Asset name"""

    path: str
    """Path in external system"""

    local_path: Optional[Path] = None
    """Local file path (if synced)"""

    version: str = "1.0"
    """Version number"""

    modified_date: Optional[datetime] = None
    """Last modified timestamp"""

    size_bytes: int = 0
    """File size"""

    checksum: Optional[str] = None
    """File checksum (MD5, SHA256, etc.)"""

    metadata: Dict[str, Any] = field(default_factory=dict)
    """Additional system-specific metadata"""


@dataclass
class SyncResult:
    """Result of a sync operation."""

    success: bool = False
    """Whether operation succeeded"""

    assets_synced: int = 0
    """Number of assets synced"""

    assets_updated: int = 0
    """Number of assets updated"""

    assets_deleted: int = 0
    """Number of assets deleted"""

    errors: List[str] = field(default_factory=list)
    """List of errors encountered"""


class AssetSyncProvider(ABC):
    """Abstract base class for asset synchronization providers.

    Implementations integrate with external asset management systems
    like M-Files, OneDrive, SharePoint, DAM systems, etc.
    """

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Name of the provider (e.g., 'M-Files', 'OneDrive')."""
        pass

    @property
    @abstractmethod
    def provider_version(self) -> str:
        """Version of the provider implementation."""
        pass

    @abstractmethod
    def connect(self, config: Dict[str, Any]) -> bool:
        """Connect to external system.

        Args:
            config: Connection configuration (API keys, endpoints, etc.)

        Returns:
            True if connection successful
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Disconnect from external system."""
        pass

    @abstractmethod
    def list_assets(
        self,
        path: Optional[str] = None,
        recursive: bool = False,
    ) -> List[AssetMetadata]:
        """List assets in external system.

        Args:
            path: Optional path filter
            recursive: Whether to list recursively

        Returns:
            List of asset metadata
        """
        pass

    @abstractmethod
    def download_asset(
        self,
        asset_id: str,
        local_path: str | Path,
    ) -> bool:
        """Download asset from external system.

        Args:
            asset_id: Asset identifier
            local_path: Local destination path

        Returns:
            True if download successful
        """
        pass

    @abstractmethod
    def upload_asset(
        self,
        local_path: str | Path,
        remote_path: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """Upload asset to external system.

        Args:
            local_path: Local file path
            remote_path: Remote destination path
            metadata: Optional metadata to attach

        Returns:
            Asset ID if successful, None otherwise
        """
        pass

    @abstractmethod
    def sync_to_local(
        self,
        local_dir: str | Path,
        remote_path: Optional[str] = None,
    ) -> SyncResult:
        """Sync assets from external system to local directory.

        Args:
            local_dir: Local directory to sync to
            remote_path: Optional remote path filter

        Returns:
            Sync operation result
        """
        pass

    @abstractmethod
    def sync_to_remote(
        self,
        local_dir: str | Path,
        remote_path: str,
    ) -> SyncResult:
        """Sync local assets to external system.

        Args:
            local_dir: Local directory to sync from
            remote_path: Remote destination path

        Returns:
            Sync operation result
        """
        pass

    @abstractmethod
    def get_asset_metadata(self, asset_id: str) -> Optional[AssetMetadata]:
        """Get metadata for specific asset.

        Args:
            asset_id: Asset identifier

        Returns:
            Asset metadata or None if not found
        """
        pass

    @abstractmethod
    def update_asset_metadata(
        self,
        asset_id: str,
        metadata: Dict[str, Any],
    ) -> bool:
        """Update metadata for asset.

        Args:
            asset_id: Asset identifier
            metadata: Metadata to update

        Returns:
            True if successful
        """
        pass

    @abstractmethod
    def delete_asset(self, asset_id: str) -> bool:
        """Delete asset from external system.

        Args:
            asset_id: Asset identifier

        Returns:
            True if successful
        """
        pass

    def validate_config(self, config: Dict[str, Any]) -> List[str]:
        """Validate provider configuration.

        Args:
            config: Configuration to validate

        Returns:
            List of validation errors (empty if valid)
        """
        return []


class LocalFileSystemProvider(AssetSyncProvider):
    """Example provider for local filesystem (for testing)."""

    @property
    def provider_name(self) -> str:
        return "LocalFileSystem"

    @property
    def provider_version(self) -> str:
        return "0.8.7.5"

    def __init__(self):
        self.root_path: Optional[Path] = None

    def connect(self, config: Dict[str, Any]) -> bool:
        """Connect to local filesystem.

        Args:
            config: Must contain 'root_path' key
        """
        root = config.get("root_path")
        if not root:
            return False

        self.root_path = Path(root)
        return self.root_path.exists()

    def disconnect(self) -> None:
        """Disconnect (no-op for local filesystem)."""
        self.root_path = None

    def list_assets(
        self,
        path: Optional[str] = None,
        recursive: bool = False,
    ) -> List[AssetMetadata]:
        """List files in local filesystem."""
        if not self.root_path:
            return []

        search_path = self.root_path / path if path else self.root_path
        assets = []

        pattern = "**/*" if recursive else "*"
        for file_path in search_path.glob(pattern):
            if file_path.is_file():
                stat = file_path.stat()
                assets.append(
                    AssetMetadata(
                        asset_id=str(file_path.relative_to(self.root_path)),
                        name=file_path.name,
                        path=str(file_path.relative_to(self.root_path)),
                        local_path=file_path,
                        size_bytes=stat.st_size,
                        modified_date=datetime.fromtimestamp(stat.st_mtime),
                    )
                )

        return assets

    def download_asset(
        self,
        asset_id: str,
        local_path: str | Path,
    ) -> bool:
        """Copy file to destination."""
        if not self.root_path:
            return False

        source = self.root_path / asset_id
        if not source.exists():
            return False

        import shutil

        shutil.copy2(source, local_path)
        return True

    def upload_asset(
        self,
        local_path: str | Path,
        remote_path: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """Copy file to root path."""
        if not self.root_path:
            return None

        dest = self.root_path / remote_path
        dest.parent.mkdir(parents=True, exist_ok=True)

        import shutil

        shutil.copy2(local_path, dest)
        return remote_path

    def sync_to_local(
        self,
        local_dir: str | Path,
        remote_path: Optional[str] = None,
    ) -> SyncResult:
        """Sync from root to local directory."""
        result = SyncResult()

        if not self.root_path:
            result.errors.append("Not connected")
            return result

        assets = self.list_assets(remote_path, recursive=True)

        for asset in assets:
            try:
                dest = Path(local_dir) / asset.path
                dest.parent.mkdir(parents=True, exist_ok=True)

                if self.download_asset(asset.asset_id, dest):
                    result.assets_synced += 1
                else:
                    result.errors.append(f"Failed to download {asset.asset_id}")
            except Exception as e:
                result.errors.append(f"Error syncing {asset.asset_id}: {e}")

        result.success = len(result.errors) == 0
        return result

    def sync_to_remote(
        self,
        local_dir: str | Path,
        remote_path: str,
    ) -> SyncResult:
        """Sync from local to root."""
        result = SyncResult()

        if not self.root_path:
            result.errors.append("Not connected")
            return result

        local_dir = Path(local_dir)
        for file_path in local_dir.rglob("*"):
            if file_path.is_file():
                try:
                    rel_path = file_path.relative_to(local_dir)
                    remote_file = f"{remote_path}/{rel_path}".replace("\\", "/")

                    if self.upload_asset(file_path, remote_file):
                        result.assets_synced += 1
                    else:
                        result.errors.append(f"Failed to upload {file_path}")
                except Exception as e:
                    result.errors.append(f"Error syncing {file_path}: {e}")

        result.success = len(result.errors) == 0
        return result

    def get_asset_metadata(self, asset_id: str) -> Optional[AssetMetadata]:
        """Get metadata for file."""
        if not self.root_path:
            return None

        file_path = self.root_path / asset_id
        if not file_path.exists():
            return None

        stat = file_path.stat()
        return AssetMetadata(
            asset_id=asset_id,
            name=file_path.name,
            path=asset_id,
            local_path=file_path,
            size_bytes=stat.st_size,
            modified_date=datetime.fromtimestamp(stat.st_mtime),
        )

    def update_asset_metadata(
        self,
        asset_id: str,
        metadata: Dict[str, Any],
    ) -> bool:
        """Update metadata (no-op for local filesystem)."""
        return True

    def delete_asset(self, asset_id: str) -> bool:
        """Delete file."""
        if not self.root_path:
            return False

        file_path = self.root_path / asset_id
        if not file_path.exists():
            return False

        file_path.unlink()
        return True


# Provider registry
_PROVIDERS: Dict[str, type[AssetSyncProvider]] = {
    "local": LocalFileSystemProvider,
}


def register_provider(name: str, provider_class: type[AssetSyncProvider]) -> None:
    """Register an asset sync provider.

    Args:
        name: Provider name
        provider_class: Provider class
    """
    _PROVIDERS[name] = provider_class


def get_provider(name: str) -> Optional[type[AssetSyncProvider]]:
    """Get provider class by name.

    Args:
        name: Provider name

    Returns:
        Provider class or None if not found
    """
    return _PROVIDERS.get(name)


def list_providers() -> List[str]:
    """List all registered providers.

    Returns:
        List of provider names
    """
    return list(_PROVIDERS.keys())
