"""Governance Event Integration for Asset Operations - v0.8.7.5

Logs asset validation and replacement events to the Policy Engine for audit trail.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class AssetGovernanceEvent:
    """Represents a governance event for asset operations."""

    event_type: str
    """Event type: ASSET_VALIDATED, ASSET_REPLACED, ASSET_SYNCED, ASSET_IGNORED"""

    correlation_id: str
    """Unique correlation ID for tracking"""

    timestamp: str
    """ISO8601 timestamp"""

    actor: str
    """Actor performing the action"""

    project: str
    """Project path"""

    payload: Dict[str, Any]
    """Event-specific payload"""

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return asdict(self)

    @classmethod
    def create_validated_event(
        cls,
        project: str,
        total_images: int,
        errors: int,
        warnings: int,
        duplicates: int,
        clusters: int,
        config_hash: str,
        actor: str = "branchpy-cli",
    ) -> AssetGovernanceEvent:
        """Create ASSET_VALIDATED event.

        Args:
            project: Project path
            total_images: Total images validated
            errors: Number of errors found
            warnings: Number of warnings
            duplicates: Number of duplicates
            clusters: Number of similarity clusters
            config_hash: Hash of validation config
            actor: Actor performing validation

        Returns:
            Governance event
        """
        return cls(
            event_type="ASSET_VALIDATED",
            correlation_id=str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "total_images": total_images,
                "errors": errors,
                "warnings": warnings,
                "duplicates": duplicates,
                "clusters": clusters,
                "config_hash": config_hash,
            },
        )

    @classmethod
    def create_replaced_event(
        cls,
        project: str,
        from_path: str,
        to_path: str,
        issues: List[str],
        decision: str,
        hash_before: str,
        hash_after: str,
        backup_path: Optional[str],
        status: str,
        reason: str = "",
        actor: str = "branchpy-cli",
    ) -> AssetGovernanceEvent:
        """Create ASSET_REPLACED event.

        Args:
            project: Project path
            from_path: Original image path
            to_path: Replacement image path
            issues: List of issue codes
            decision: 'manual' or 'auto'
            hash_before: MD5 hash before replacement
            hash_after: MD5 hash after replacement
            backup_path: Backup file path
            status: 'success', 'skipped', or 'failed'
            reason: Human-readable reason
            actor: Actor performing replacement

        Returns:
            Governance event
        """
        return cls(
            event_type="ASSET_REPLACED",
            correlation_id=str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "from": from_path,
                "to": to_path,
                "issues": issues,
                "decision": decision,
                "hash_before": hash_before,
                "hash_after": hash_after,
                "backup_path": backup_path,
                "status": status,
                "reason": reason,
            },
        )

    @classmethod
    def create_synced_event(
        cls,
        project: str,
        provider: str,
        direction: str,
        files_synced: int,
        bytes_transferred: int,
        checksum: str,
        status: str,
        actor: str = "branchpy-cli",
    ) -> AssetGovernanceEvent:
        """Create ASSET_SYNCED event.

        Args:
            project: Project path
            provider: Sync provider name
            direction: 'upload', 'download', or 'bidirectional'
            files_synced: Number of files synced
            bytes_transferred: Bytes transferred
            checksum: Checksum of synced content
            status: 'success' or 'failed'
            actor: Actor performing sync

        Returns:
            Governance event
        """
        return cls(
            event_type="ASSET_SYNCED",
            correlation_id=str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "provider": provider,
                "direction": direction,
                "files_synced": files_synced,
                "bytes_transferred": bytes_transferred,
                "checksum": checksum,
                "status": status,
            },
        )

    @classmethod
    def create_ignored_event(
        cls,
        project: str,
        path: str,
        issue: str,
        until: Optional[str],
        reason: str = "",
        actor: str = "branchpy-cli",
    ) -> AssetGovernanceEvent:
        """Create ASSET_IGNORED event.

        Args:
            project: Project path
            path: Asset path being ignored
            issue: Issue code being ignored
            until: Expiration date (ISO8601 or None)
            reason: Human-readable reason
            actor: Actor adding ignore

        Returns:
            Governance event
        """
        return cls(
            event_type="ASSET_IGNORED",
            correlation_id=str(uuid.uuid4()),
            timestamp=datetime.now().isoformat(),
            actor=actor,
            project=project,
            payload={
                "path": path,
                "issue": issue,
                "until": until,
                "reason": reason,
            },
        )


class GovernanceLogger:
    """Logger for governance events."""

    def __init__(self, log_dir: str | Path):
        """Initialize governance logger.

        Args:
            log_dir: Directory to store governance logs
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / "asset_events.jsonl"

    def log_event(self, event: AssetGovernanceEvent) -> None:
        """Log governance event to JSONL file.

        Args:
            event: Governance event
        """
        with open(self.log_file, "a", encoding="utf-8") as f:
            json.dump(event.to_dict(), f)
            f.write("\n")

    def get_events(
        self,
        event_type: Optional[str] = None,
        correlation_id: Optional[str] = None,
        since: Optional[datetime] = None,
    ) -> List[AssetGovernanceEvent]:
        """Query governance events.

        Args:
            event_type: Filter by event type
            correlation_id: Filter by correlation ID
            since: Filter events after timestamp

        Returns:
            List of matching events
        """
        events = []

        if not self.log_file.exists():
            return events

        with open(self.log_file, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    event_dict = json.loads(line)

                    # Apply filters
                    if event_type and event_dict.get("event_type") != event_type:
                        continue

                    if (
                        correlation_id
                        and event_dict.get("correlation_id") != correlation_id
                    ):
                        continue

                    if since:
                        event_time = datetime.fromisoformat(
                            event_dict.get("timestamp", "")
                        )
                        if event_time < since:
                            continue

                    events.append(AssetGovernanceEvent(**event_dict))

                except (json.JSONDecodeError, TypeError, ValueError):
                    continue

        return events
