"""
Fuzzy Matching Utilities

Provides fuzzy string matching for typo detection and suggestion generation.
Uses Damerau-Levenshtein distance for edit-distance calculations.
"""

from typing import List, Tuple


def damerau_levenshtein_distance(s1: str, s2: str) -> int:
    """
    Calculate Damerau-Levenshtein distance between two strings.

    Supports:
    - Insertions
    - Deletions
    - Substitutions
    - Transpositions (adjacent character swaps)

    Args:
        s1: First string
        s2: Second string

    Returns:
        Edit distance (minimum number of operations)

    Examples:
        >>> damerau_levenshtein_distance("claire", "clare")
        1  # deletion of 'i'
        >>> damerau_levenshtein_distance("clarie", "claire")
        1  # transposition of 'ri' -> 'ir'
    """
    len1, len2 = len(s1), len(s2)

    # Create distance matrix
    # d[i][j] = distance between s1[:i] and s2[:j]
    d = [[0] * (len2 + 1) for _ in range(len1 + 1)]

    # Initialize base cases
    for i in range(len1 + 1):
        d[i][0] = i
    for j in range(len2 + 1):
        d[0][j] = j

    # Fill matrix
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else 1

            d[i][j] = min(
                d[i - 1][j] + 1,  # deletion
                d[i][j - 1] + 1,  # insertion
                d[i - 1][j - 1] + cost,  # substitution
            )

            # Transposition
            if i > 1 and j > 1 and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + cost)

    return d[len1][len2]


def fuzzy_match(
    query: str, candidates: List[str], max_distance: int = 2, max_results: int = 3
) -> List[Tuple[str, float]]:
    """
    Find fuzzy matches for a query string from candidates.

    Returns top matches sorted by:
    1. Edit distance (ascending)
    2. Common prefix length (descending)
    3. Alphabetical order

    Args:
        query: String to match
        candidates: List of candidate strings
        max_distance: Maximum edit distance to consider (default: 2)
        max_results: Maximum number of results to return (default: 3)

    Returns:
        List of (candidate, score) tuples, where score is normalized 0-1
        (1.0 = perfect match, lower = worse match)

    Examples:
        >>> fuzzy_match("clarie", ["claire", "clara", "eileen"])
        [("claire", 0.95), ("clara", 0.80)]
    """
    matches = []

    for candidate in candidates:
        distance = damerau_levenshtein_distance(query.lower(), candidate.lower())

        # Skip if distance exceeds threshold
        if distance > max_distance:
            continue

        # Calculate common prefix length (bonus for same start)
        common_prefix = 0
        for q_char, c_char in zip(query.lower(), candidate.lower()):
            if q_char == c_char:
                common_prefix += 1
            else:
                break

        # Normalize score: 1.0 = perfect, 0.0 = max_distance
        # Include prefix bonus (up to 0.2 bonus)
        max_len = max(len(query), len(candidate))
        if max_len == 0:
            continue

        base_score = 1.0 - (distance / (max_distance + 1))
        prefix_bonus = (common_prefix / max_len) * 0.2
        score = min(1.0, base_score + prefix_bonus)

        matches.append((candidate, score, distance, common_prefix))

    # Sort by: distance (asc), prefix (desc), candidate (asc)
    matches.sort(key=lambda x: (x[2], -x[3], x[0]))

    # Return top N with scores only
    return [(candidate, score) for candidate, score, _, _ in matches[:max_results]]


def suggest_corrections(
    query: str, candidates: List[str], min_score: float = 0.5
) -> List[str]:
    """
    Get correction suggestions for a query.

    Convenience wrapper around fuzzy_match that filters by minimum score
    and returns only candidate names.

    Args:
        query: Potentially misspelled string
        candidates: List of correct strings
        min_score: Minimum normalized score to include (default: 0.5)

    Returns:
        List of suggested corrections (up to 3)

    Examples:
        >>> suggest_corrections("clarie", ["claire", "clara", "eileen"])
        ["claire", "clara"]
    """
    matches = fuzzy_match(query, candidates)
    return [candidate for candidate, score in matches if score >= min_score]


# Quick test function (can be removed in production)
if __name__ == "__main__":
    # Test cases
    print("Testing Damerau-Levenshtein distance:")
    print(f"claire -> clare: {damerau_levenshtein_distance('claire', 'clare')}")  # 1
    print(f"clarie -> claire: {damerau_levenshtein_distance('clarie', 'claire')}")  # 1
    print(
        f"bg_city -> bg_cty: {damerau_levenshtein_distance('bg_city', 'bg_cty')}"
    )  # 1

    print("\nTesting fuzzy_match:")
    candidates = ["claire_happy", "claire_sad", "eileen_concerned", "bg_city"]
    results = fuzzy_match("clarie_happy", candidates)
    for cand, score in results:
        print(f"  {cand}: {score:.2f}")

    print("\nTesting suggest_corrections:")
    suggestions = suggest_corrections("bg_cty", candidates)
    print(f"  Suggestions for 'bg_cty': {suggestions}")
