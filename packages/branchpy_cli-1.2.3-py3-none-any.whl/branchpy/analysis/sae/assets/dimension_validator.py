"""Dimension Validation for Asset Quality Control - v0.8.7.5

Validates image dimensions against configurable thresholds and per-kind profiles.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ValidationProfile:
    """Validation profile for a specific asset kind."""

    min_width: int = 0
    """Minimum width in pixels"""

    min_height: int = 0
    """Minimum height in pixels"""

    aspect: Optional[str] = None
    """Expected aspect ratio (e.g., '16:9', '3:4')"""

    max_size_kb: int = 0
    """Maximum file size in KB (0 = no limit)"""


@dataclass
class ValidationConfig:
    """Configuration for asset dimension validation."""

    min_width: int = 1920
    """Default minimum width"""

    min_height: int = 1080
    """Default minimum height"""

    aspect_tolerance_pct: float = 5.0
    """Aspect ratio tolerance percentage"""

    similarity_threshold: float = 0.90
    """Similarity threshold for clustering"""

    max_size_kb: int = 0
    """Maximum file size in KB (0 = no limit)"""

    warn_if_upscale: bool = True
    """Warn when replacing small image with larger one"""

    enforce_kind_profiles: bool = True
    """Apply per-kind profiles if present"""

    profiles: Optional[Dict[str, ValidationProfile]] = None
    """Per-kind validation profiles"""

    def __post_init__(self):
        """Initialize default profiles."""
        if self.profiles is None:
            self.profiles = {
                "background": ValidationProfile(
                    min_width=2560,
                    min_height=1440,
                    aspect="16:9",
                ),
                "sprite": ValidationProfile(
                    min_width=1200,
                    min_height=1600,
                    aspect="3:4",
                ),
                "cg": ValidationProfile(
                    min_width=2560,
                    min_height=1440,
                    aspect="16:9",
                ),
            }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> ValidationConfig:
        """Create config from dictionary.

        Args:
            config_dict: Config dictionary

        Returns:
            Validation config
        """
        validation = config_dict.get("validation", {})
        profiles_data = config_dict.get("profiles", {})

        profiles = {}
        for kind, prof_data in profiles_data.items():
            profiles[kind] = ValidationProfile(
                min_width=prof_data.get("min_width", 0),
                min_height=prof_data.get("min_height", 0),
                aspect=prof_data.get("aspect"),
                max_size_kb=prof_data.get("max_size_kb", 0),
            )

        return cls(
            min_width=validation.get("min_width", 1920),
            min_height=validation.get("min_height", 1080),
            aspect_tolerance_pct=validation.get("aspect_tolerance_pct", 5.0),
            similarity_threshold=validation.get("similarity_threshold", 0.90),
            max_size_kb=validation.get("max_size_kb", 0),
            warn_if_upscale=validation.get("warn_if_upscale", True),
            enforce_kind_profiles=validation.get("enforce_kind_profiles", True),
            profiles=profiles or None,
        )


@dataclass
class ValidationIssue:
    """Represents a validation issue."""

    code: str
    """Issue code (e.g., 'dim-too-small', 'aspect-off')"""

    severity: str
    """Severity: info, warn, error"""

    message: str
    """Human-readable message"""

    actual_value: Any = None
    """Actual value that triggered issue"""

    expected_value: Any = None
    """Expected value"""


class DimensionValidator:
    """Validates image dimensions against configured thresholds."""

    # Issue codes
    ISSUE_DIM_TOO_SMALL = "dim-too-small"
    ISSUE_ASPECT_OFF = "aspect-off"
    ISSUE_FILE_TOO_LARGE = "file-too-large"
    ISSUE_DUPLICATE = "duplicate"
    ISSUE_SIMILAR_HIGH = "similar-high"
    ISSUE_UPSCALE_RISK = "upscale-risk"

    def __init__(self, config: ValidationConfig):
        """Initialize validator.

        Args:
            config: Validation configuration
        """
        self.config = config

    def validate_image(
        self,
        width: int,
        height: int,
        size_kb: float,
        kind: str = "unknown",
    ) -> List[ValidationIssue]:
        """Validate image dimensions.

        Args:
            width: Image width
            height: Image height
            size_kb: File size in KB
            kind: Asset kind

        Returns:
            List of validation issues
        """
        issues = []

        # Get applicable profile
        profile = self._get_profile(kind)

        # Check minimum dimensions
        min_w = profile.min_width if profile else self.config.min_width
        min_h = profile.min_height if profile else self.config.min_height

        if width < min_w or height < min_h:
            issues.append(
                ValidationIssue(
                    code=self.ISSUE_DIM_TOO_SMALL,
                    severity="error",
                    message=f"Image dimensions {width}x{height} below minimum {min_w}x{min_h}",
                    actual_value=f"{width}x{height}",
                    expected_value=f"{min_w}x{min_h}",
                )
            )

        # Check aspect ratio
        if profile and profile.aspect:
            if not self._check_aspect(width, height, profile.aspect):
                issues.append(
                    ValidationIssue(
                        code=self.ISSUE_ASPECT_OFF,
                        severity="warn",
                        message=f"Aspect ratio {width}:{height} doesn't match expected {profile.aspect}",
                        actual_value=f"{width / height:.2f}",
                        expected_value=profile.aspect,
                    )
                )

        # Check file size
        max_size = (
            profile.max_size_kb
            if profile and profile.max_size_kb > 0
            else self.config.max_size_kb
        )
        if max_size > 0 and size_kb > max_size:
            issues.append(
                ValidationIssue(
                    code=self.ISSUE_FILE_TOO_LARGE,
                    severity="warn",
                    message=f"File size {size_kb:.1f} KB exceeds maximum {max_size} KB",
                    actual_value=size_kb,
                    expected_value=max_size,
                )
            )

        return issues

    def validate_replacement(
        self,
        from_width: int,
        from_height: int,
        to_width: int,
        to_height: int,
    ) -> List[ValidationIssue]:
        """Validate a replacement operation.

        Args:
            from_width: Original image width
            from_height: Original image height
            to_width: Replacement image width
            to_height: Replacement image height

        Returns:
            List of validation issues
        """
        issues = []

        if not self.config.warn_if_upscale:
            return issues

        # Check for upscaling (replacing small with larger)
        from_area = from_width * from_height
        to_area = to_width * to_height

        if to_area > from_area * 1.5:  # 50% larger
            issues.append(
                ValidationIssue(
                    code=self.ISSUE_UPSCALE_RISK,
                    severity="info",
                    message=f"Replacement {to_width}x{to_height} significantly larger than original {from_width}x{from_height}",
                    actual_value=f"{to_width}x{to_height}",
                    expected_value=f"{from_width}x{from_height}",
                )
            )

        return issues

    def _get_profile(self, kind: str) -> Optional[ValidationProfile]:
        """Get validation profile for asset kind.

        Args:
            kind: Asset kind

        Returns:
            Validation profile or None
        """
        if not self.config.enforce_kind_profiles:
            return None

        if not self.config.profiles:
            return None

        return self.config.profiles.get(kind)

    def _check_aspect(self, width: int, height: int, target_ratio: str) -> bool:
        """Check if aspect ratio matches target.

        Args:
            width: Image width
            height: Image height
            target_ratio: Target ratio (e.g., '16:9')

        Returns:
            True if aspect matches within tolerance
        """
        if ":" not in target_ratio:
            return True

        try:
            tr_w, tr_h = map(float, target_ratio.split(":"))
            actual = width / height
            target = tr_w / tr_h
            tolerance = target * (self.config.aspect_tolerance_pct / 100.0)

            return abs(actual - target) <= tolerance
        except (ValueError, ZeroDivisionError):
            return True


def parse_aspect_ratio(ratio_str: str) -> Tuple[float, float]:
    """Parse aspect ratio string.

    Args:
        ratio_str: Ratio string (e.g., '16:9')

    Returns:
        Tuple of (width_ratio, height_ratio)
    """
    if ":" in ratio_str:
        parts = ratio_str.split(":")
        return float(parts[0]), float(parts[1])
    else:
        return 1.0, 1.0


def aspect_matches(
    width: int,
    height: int,
    target_ratio: str,
    tolerance_pct: float = 5.0,
) -> bool:
    """Check if image aspect ratio matches target.

    Args:
        width: Image width
        height: Image height
        target_ratio: Target ratio (e.g., '16:9')
        tolerance_pct: Tolerance percentage

    Returns:
        True if aspect matches
    """
    try:
        w, h = map(float, (width, height))
        tr_w, tr_h = parse_aspect_ratio(target_ratio)

        actual = w / h
        target = tr_w / tr_h
        tolerance = target * (tolerance_pct / 100.0)

        return abs(actual - target) <= tolerance
    except (ValueError, ZeroDivisionError):
        return False


def choose_primary(candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Choose primary image from cluster candidates.

    Selection heuristic: largest area, tie-break by file size.

    Args:
        candidates: List of candidate metadata dicts

    Returns:
        Best candidate
    """
    if not candidates:
        raise ValueError("No candidates provided")

    def score(candidate: Dict[str, Any]) -> Tuple[int, float]:
        """Calculate score for candidate."""
        w = candidate.get("width", 0)
        h = candidate.get("height", 0)
        size = candidate.get("size_kb", 0.0)
        return (w * h, size)

    return max(candidates, key=score)
