"""Extended CSV Export for Asset Validation - v0.8.7.5

Exports comprehensive asset validation results to CSV format with dimensions,
similarity clusters, and suggested replacements.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class AssetValidationRow:
    """Represents a single row in the asset validation CSV."""

    project_path: str
    """Project root path"""

    image_path: str
    """Relative image path or reference"""

    kind: str = "unknown"
    """Asset kind: background, sprite, cg, ui, unknown"""

    width: int = 0
    """Image width in pixels"""

    height: int = 0
    """Image height in pixels"""

    aspect: str = ""
    """Aspect ratio (e.g., '16:9', '3:4')"""

    size_kb: float = 0.0
    """File size in kilobytes"""

    hash_md5: str = ""
    """MD5 hash for exact duplicate detection"""

    perceptual_hash: str = ""
    """Perceptual hash for similarity detection"""

    similarity_cluster: str = ""
    """Similarity cluster ID"""

    similarity_score: float = 0.0
    """Similarity score (0.0-1.0)"""

    duplicate_of: str = ""
    """Canonical path if exact duplicate detected"""

    status: str = "ok"
    """Status: ok, warn, error, replaced, skipped, missing_ref, unused"""

    issues: str = ""
    """Semicolon-separated list of issues"""

    suggested_replacement: str = ""
    """Best candidate from cluster"""

    notes: str = ""
    """Human comments or auto hints"""

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary for CSV writing."""
        return {
            "ProjectPath": self.project_path,
            "ImagePath": self.image_path,
            "Kind": self.kind,
            "Width": self.width,
            "Height": self.height,
            "Aspect": self.aspect,
            "SizeKB": round(self.size_kb, 2),
            "HashMD5": self.hash_md5,
            "PerceptualHash": self.perceptual_hash,
            "SimilarityCluster": self.similarity_cluster,
            "SimilarityScore": round(self.similarity_score, 3),
            "DuplicateOf": self.duplicate_of,
            "Status": self.status,
            "Issues": self.issues,
            "SuggestedReplacement": self.suggested_replacement,
            "Notes": self.notes,
        }


class AssetCSVExporter:
    """Exports asset validation results to CSV format."""

    HEADERS = [
        "ProjectPath",
        "ImagePath",
        "Kind",
        "Width",
        "Height",
        "Aspect",
        "SizeKB",
        "HashMD5",
        "PerceptualHash",
        "SimilarityCluster",
        "SimilarityScore",
        "DuplicateOf",
        "Status",
        "Issues",
        "SuggestedReplacement",
        "Notes",
    ]

    def __init__(self, project_path: str):
        """Initialize CSV exporter.

        Args:
            project_path: Project root path
        """
        self.project_path = project_path
        self.rows: List[AssetValidationRow] = []

    def add_image_row(
        self,
        image_path: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AssetValidationRow:
        """Add an image row to the export.

        Args:
            image_path: Relative image path
            metadata: Optional metadata dict

        Returns:
            Created row
        """
        metadata = metadata or {}

        row = AssetValidationRow(
            project_path=self.project_path,
            image_path=image_path,
            kind=self._infer_kind(image_path),
            width=metadata.get("width", 0),
            height=metadata.get("height", 0),
            aspect=self._format_aspect(metadata.get("aspect_ratio", 0.0)),
            size_kb=metadata.get("size_kb", 0.0),
            hash_md5=metadata.get("md5_hash", ""),
            perceptual_hash=metadata.get("perceptual_hash", ""),
            similarity_cluster=(
                str(metadata.get("cluster_id", ""))
                if metadata.get("cluster_id") is not None
                else ""
            ),
            similarity_score=metadata.get("similarity_score", 0.0),
            duplicate_of=metadata.get("duplicate_of", ""),
            status=metadata.get("status", "ok"),
            issues=metadata.get("issues", ""),
            suggested_replacement=metadata.get("suggested_replacement", ""),
            notes=metadata.get("notes", ""),
        )

        self.rows.append(row)
        return row

    def add_reference_row(
        self,
        reference: str,
        status: str = "missing_ref",
        notes: str = "",
    ) -> AssetValidationRow:
        """Add a reference-only row (missing or unused).

        Args:
            reference: Image reference from .rpy file
            status: Status (missing_ref or unused)
            notes: Additional notes

        Returns:
            Created row
        """
        row = AssetValidationRow(
            project_path=self.project_path,
            image_path=reference,
            kind="reference",
            status=status,
            notes=notes,
        )

        self.rows.append(row)
        return row

    def write_csv(self, output_file: str | Path) -> None:
        """Write rows to CSV file.

        Args:
            output_file: Output CSV file path
        """
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.HEADERS)
            writer.writeheader()

            for row in self.rows:
                writer.writerow(row.to_dict())

    def _infer_kind(self, image_path: str) -> str:
        """Infer asset kind from path.

        Args:
            image_path: Image path

        Returns:
            Asset kind
        """
        path_lower = image_path.lower()

        if "/bg/" in path_lower or "/background" in path_lower:
            return "background"
        elif "/sprite" in path_lower or "/char" in path_lower:
            return "sprite"
        elif "/cg/" in path_lower or "/event" in path_lower:
            return "cg"
        elif "/ui/" in path_lower or "/gui/" in path_lower:
            return "ui"
        else:
            return "unknown"

    def _format_aspect(self, aspect_ratio: float) -> str:
        """Format aspect ratio as string.

        Args:
            aspect_ratio: Numeric aspect ratio

        Returns:
            Formatted string (e.g., '16:9')
        """
        if aspect_ratio == 0.0:
            return ""

        # Common aspect ratios
        ratios = {
            16 / 9: "16:9",
            4 / 3: "4:3",
            3 / 4: "3:4",
            21 / 9: "21:9",
            1 / 1: "1:1",
            9 / 16: "9:16",
        }

        # Find closest match
        for ratio_val, ratio_str in ratios.items():
            if abs(aspect_ratio - ratio_val) < 0.01:
                return ratio_str

        # Return decimal format
        return f"{aspect_ratio:.2f}"

    @staticmethod
    def read_csv(csv_file: str | Path) -> List[AssetValidationRow]:
        """Read CSV file into rows.

        Args:
            csv_file: CSV file path

        Returns:
            List of validation rows
        """
        rows = []

        with open(csv_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            for row_dict in reader:
                row = AssetValidationRow(
                    project_path=row_dict.get("ProjectPath", ""),
                    image_path=row_dict.get("ImagePath", ""),
                    kind=row_dict.get("Kind", "unknown"),
                    width=int(row_dict.get("Width", 0)),
                    height=int(row_dict.get("Height", 0)),
                    aspect=row_dict.get("Aspect", ""),
                    size_kb=float(row_dict.get("SizeKB", 0)),
                    hash_md5=row_dict.get("HashMD5", ""),
                    perceptual_hash=row_dict.get("PerceptualHash", ""),
                    similarity_cluster=row_dict.get("SimilarityCluster", ""),
                    similarity_score=float(row_dict.get("SimilarityScore", 0)),
                    duplicate_of=row_dict.get("DuplicateOf", ""),
                    status=row_dict.get("Status", "ok"),
                    issues=row_dict.get("Issues", ""),
                    suggested_replacement=row_dict.get("SuggestedReplacement", ""),
                    notes=row_dict.get("Notes", ""),
                )
                rows.append(row)

        return rows


def merge_similarity_data(
    csv_exporter: AssetCSVExporter,
    similarity_clusters: List[Dict[str, Any]],
    duplicates: List[List[Dict[str, Any]]],
) -> None:
    """Merge similarity and duplicate data into CSV rows.

    Args:
        csv_exporter: CSV exporter with existing rows
        similarity_clusters: List of similarity clusters
        duplicates: List of duplicate groups
    """
    # Build lookup maps
    path_to_row: Dict[str, AssetValidationRow] = {
        row.image_path: row for row in csv_exporter.rows
    }

    # Process duplicates
    for dup_group in duplicates:
        if not dup_group:
            continue

        # Choose primary (first one)
        primary = dup_group[0]
        primary_path = primary.get("path", "")

        for dup in dup_group[1:]:
            dup_path = str(dup.get("path", ""))

            if dup_path in path_to_row:
                row = path_to_row[dup_path]
                row.duplicate_of = primary_path
                row.status = "warn" if row.status == "ok" else row.status

                # Add to issues
                issues = row.issues.split(";") if row.issues else []
                if "duplicate" not in issues:
                    issues.append("duplicate")
                row.issues = ";".join(issues)

    # Process similarity clusters
    for cluster in similarity_clusters:
        cluster_id = str(cluster.get("cluster_id", ""))
        images = cluster.get("images", [])
        representative = cluster.get("representative")
        similarity_score = cluster.get("similarity_score", 1.0)

        rep_path = str(representative.get("path", "")) if representative else ""

        for img in images:
            img_path = str(img.get("path", ""))

            if img_path in path_to_row:
                row = path_to_row[img_path]
                row.similarity_cluster = cluster_id
                row.similarity_score = similarity_score

                # Suggest replacement if not the representative
                if img_path != rep_path and rep_path:
                    row.suggested_replacement = rep_path

                    # Add to issues
                    issues = row.issues.split(";") if row.issues else []
                    if "similar-high" not in issues:
                        issues.append("similar-high")
                    row.issues = ";".join(issues)
