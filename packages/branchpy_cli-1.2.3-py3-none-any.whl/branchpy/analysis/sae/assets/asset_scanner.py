"""
Asset Scanner - Filesystem Discovery

Scans project directories to discover and index asset files (images, audio,
video, fonts) with normalized naming for cross-reference validation.
"""

import hashlib
import re
from pathlib import Path
from typing import Optional

from .models import AssetFile

# Asset type mappings by file extension
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
AUDIO_EXTS = {".mp3", ".ogg", ".wav", ".flac", ".opus"}
VIDEO_EXTS = {".mp4", ".webm", ".ogv", ".avi", ".mkv"}
FONT_EXTS = {".ttf", ".otf", ".woff", ".woff2"}

# Directories to ignore during scanning
IGNORE_DIRS = {
    "cache",
    "__pycache__",
    ".git",
    ".vscode",
    "saves",
    "tmp",
    "temp",
}


def normalize_asset_key(name: str, drop_ext: bool = True) -> str:
    """
    Normalize asset name to canonical form for matching.

    Rules:
    - Lowercase
    - Replace spaces/hyphens with underscores
    - Strip leading/trailing underscores
    - Optionally drop file extension

    Examples:
        'Claire Happy.png' -> 'claire_happy'
        'bg-city-night.jpg' -> 'bg_city_night'
        'BGM_001.mp3' -> 'bgm_001'

    Args:
        name: Original asset name or path
        drop_ext: Whether to remove file extension

    Returns:
        Normalized key suitable for dictionary lookup
    """
    # Drop directory path if present
    name = Path(name).stem if drop_ext else Path(name).name

    # Lowercase
    key = name.lower()

    # Replace runs of spaces/hyphens with single underscore
    key = re.sub(r"[-\s]+", "_", key)

    # Strip leading/trailing underscores
    key = key.strip("_")

    return key


class AssetScanner:
    """
    Scans project filesystem to build asset index.

    Walks through game/ directory and subdirectories to discover image, audio,
    video, and font files. Produces normalized asset keys for cross-reference
    validation against script definitions and references.
    """

    def __init__(
        self, compute_hash: bool = False, additional_ignores: Optional[set[str]] = None
    ):
        """
        Initialize scanner.

        Args:
            compute_hash: If True, compute MD5 hash for each file (slower)
            additional_ignores: Extra directory names to skip
        """
        self.compute_hash = compute_hash
        self.ignore_dirs = IGNORE_DIRS | (additional_ignores or set())

    def scan(self, project_root: Path) -> dict[str, dict[str, AssetFile]]:
        """
        Scan project for all asset files.

        Args:
            project_root: Path to Ren'Py project root

        Returns:
            Dict mapping asset type to dict of {logical_key: AssetFile}
            Example: {
                'images': {'claire_happy': AssetFile(...)},
                'audio': {'bgm_title': AssetFile(...)},
                ...
            }
        """
        game_dir = project_root / "game"
        if not game_dir.exists():
            import os

            if os.environ.get("CI"):
                print(
                    f"[ASSET_SCANNER] game_dir does not exist: {game_dir}", flush=True
                )
                print(
                    f"[ASSET_SCANNER] project_root exists: {project_root.exists()}",
                    flush=True,
                )
                if project_root.exists():
                    print(
                        f"[ASSET_SCANNER] project_root contents: {list(project_root.iterdir())}",
                        flush=True,
                    )
            return {
                "images": {},
                "audio": {},
                "video": {},
                "fonts": {},
            }

        images: dict[str, AssetFile] = {}
        audio: dict[str, AssetFile] = {}
        video: dict[str, AssetFile] = {}
        fonts: dict[str, AssetFile] = {}

        import os

        if os.environ.get("CI"):
            print(f"[ASSET_SCANNER] Scanning game_dir: {game_dir}", flush=True)
            print(f"[ASSET_SCANNER] game_dir exists: {game_dir.exists()}", flush=True)
            all_files = list(self._walk_files(game_dir))
            print(f"[ASSET_SCANNER] Found {len(all_files)} files total", flush=True)
            if all_files:
                print(f"[ASSET_SCANNER] First few files: {all_files[:5]}", flush=True)

        # Walk through all files under /game
        file_count = 0
        for file_path in self._walk_files(game_dir):
            file_count += 1

            # Skip if in ignored directory (check relative to game_dir only)
            try:
                relative_parts = file_path.relative_to(game_dir).parts
            except ValueError:
                # File is not under game_dir, skip it
                continue

            if any(ignore in relative_parts for ignore in self.ignore_dirs):
                if os.environ.get("CI"):
                    print(
                        f"[ASSET_SCANNER] Skipped (ignored dir): {file_path}",
                        flush=True,
                    )
                continue

            ext = file_path.suffix.lower()

            if os.environ.get("CI") and file_count <= 3:
                print(
                    f"[ASSET_SCANNER] Checking file: {file_path.name}, ext='{ext}'",
                    flush=True,
                )
                print(
                    f"[ASSET_SCANNER]   in IMAGE_EXTS={ext in IMAGE_EXTS}, in AUDIO_EXTS={ext in AUDIO_EXTS}, in VIDEO_EXTS={ext in VIDEO_EXTS}, in FONT_EXTS={ext in FONT_EXTS}",
                    flush=True,
                )

            # Categorize by extension
            if ext in IMAGE_EXTS:
                asset = self._create_asset_file(file_path, project_root)
                images[asset.logical] = asset
                if os.environ.get("CI"):
                    print(
                        f"[ASSET_SCANNER] Added image: {asset.logical} from {file_path}",
                        flush=True,
                    )
            elif ext in AUDIO_EXTS:
                asset = self._create_asset_file(file_path, project_root)
                audio[asset.logical] = asset
                if os.environ.get("CI"):
                    print(
                        f"[ASSET_SCANNER] Added audio: {asset.logical} from {file_path}",
                        flush=True,
                    )
            elif ext in VIDEO_EXTS:
                asset = self._create_asset_file(file_path, project_root)
                video[asset.logical] = asset
                if os.environ.get("CI"):
                    print(
                        f"[ASSET_SCANNER] Added video: {asset.logical} from {file_path}",
                        flush=True,
                    )
            elif ext in FONT_EXTS:
                asset = self._create_asset_file(file_path, project_root)
                fonts[asset.logical] = asset
                if os.environ.get("CI"):
                    print(
                        f"[ASSET_SCANNER] Added font: {asset.logical} from {file_path}",
                        flush=True,
                    )

        if os.environ.get("CI"):
            print(
                f"[ASSET_SCANNER] Categorization loop processed {file_count} files",
                flush=True,
            )
            print(
                f"[ASSET_SCANNER] Result: images={len(images)}, audio={len(audio)}, video={len(video)}, fonts={len(fonts)}",
                flush=True,
            )

        return {
            "images": images,
            "audio": audio,
            "video": video,
            "fonts": fonts,
        }

    def _walk_files(self, root: Path):
        """Recursively yield all files under root."""
        try:
            for item in root.iterdir():
                if item.is_file():
                    yield item
                elif item.is_dir():
                    yield from self._walk_files(item)
        except PermissionError:
            # Skip directories we can't read
            pass

    def _create_asset_file(self, path: Path, project_root: Path) -> AssetFile:
        """
        Create AssetFile from filesystem path.

        Args:
            path: Absolute path to file
            project_root: Project root for computing relative path

        Returns:
            AssetFile with normalized key and metadata
        """
        # Compute relative path from project root
        try:
            rel_path = path.relative_to(project_root)
        except ValueError:
            # Fallback if path isn't under project_root
            rel_path = path

        # Normalize to logical key (stem only)
        logical = normalize_asset_key(path.stem, drop_ext=True)

        # Get file size
        size_bytes = path.stat().st_size

        # Optionally compute hash
        hash_md5 = None
        if self.compute_hash:
            hash_md5 = self._compute_hash(path)

        return AssetFile(
            logical=logical,
            path=str(rel_path.as_posix()),
            ext=path.suffix.lower(),
            size_bytes=size_bytes,
            hash_md5=hash_md5,
        )

    def _compute_hash(self, path: Path) -> str:
        """Compute MD5 hash of file contents."""
        md5 = hashlib.md5()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                md5.update(chunk)
        return md5.hexdigest()


def scan_project_assets(
    project_root: Path, compute_hash: bool = False
) -> dict[str, dict[str, AssetFile]]:
    """
    Convenience function to scan project assets.

    Args:
        project_root: Path to Ren'Py project
        compute_hash: Whether to compute file hashes

    Returns:
        Asset index organized by type
    """
    scanner = AssetScanner(compute_hash=compute_hash)
    return scanner.scan(project_root)
