"""
BranchPy Custom Rule Registry — Phase 8 (v0.7.8)
Manages dynamic registration and execution of user-defined validation rules.

This module provides a centralized registry for custom rules with conflict
detection, priority handling, and integration with the SAE rule engine.

Usage:
    from branchpy.analysis.sae.custom_rule_registry import CustomRuleRegistry

    registry = CustomRuleRegistry()
    registry.load_from_file(".branchpy/rules_custom.yml")

    for issue in registry.validate_line("label very_long_label_name_that_exceeds_limit:", 1):
        print(f"Line {issue.line}: {issue.message}")
"""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

from branchpy.analysis.sae.custom_rule_loader import (
    CustomRuleSchema,
    RuleSeverity,
    load_custom_rules,
)


@dataclass
class RuleViolation:
    """
    Represents a violation of a custom rule.

    Attributes:
        rule_id: ID of the violated rule
        line_number: Line number where violation occurred
        message: Violation message
        severity: Severity level
        category: Rule category
        matched_text: The text that matched the pattern
    """

    rule_id: str
    line_number: int
    message: str
    severity: RuleSeverity
    category: str
    matched_text: Optional[str] = None


@dataclass
class RegistryStatistics:
    """Statistics about registered rules."""

    total_rules: int = 0
    enabled_rules: int = 0
    rules_by_severity: Dict[str, int] = field(default_factory=dict)
    rules_by_category: Dict[str, int] = field(default_factory=dict)
    conflicting_ids: List[str] = field(default_factory=list)


class CustomRuleRegistry:
    """
    Central registry for managing custom validation rules.

    Features:
    - Dynamic rule loading from YAML files
    - Conflict detection for duplicate rule IDs
    - Priority-based rule override system
    - Bulk validation across file contents
    - Statistics and reporting

    Example:
        >>> registry = CustomRuleRegistry()
        >>> registry.load_from_file(".branchpy/rules_custom.yml")
        >>> violations = registry.validate_file("game/script.rpy")
        >>> print(f"Found {len(violations)} violations")
    """

    def __init__(self):
        """Initialize an empty rule registry."""
        self._rules: Dict[str, CustomRuleSchema] = {}
        self._rules_by_category: Dict[str, List[CustomRuleSchema]] = {}
        self._load_history: List[str] = []
        self._conflicts: Set[str] = set()

    def register_rule(self, rule: CustomRuleSchema, override: bool = False) -> bool:
        """
        Register a custom rule in the registry.

        Args:
            rule: CustomRuleSchema to register
            override: If True, replace existing rule with same ID

        Returns:
            True if rule was registered, False if conflict and not override
        """
        if rule.id in self._rules and not override:
            self._conflicts.add(rule.id)
            return False

        self._rules[rule.id] = rule

        # Update category index
        if rule.category not in self._rules_by_category:
            self._rules_by_category[rule.category] = []

        # Remove old rule from category if overriding
        if override:
            self._rules_by_category[rule.category] = [
                r for r in self._rules_by_category[rule.category] if r.id != rule.id
            ]

        self._rules_by_category[rule.category].append(rule)

        return True

    def load_from_file(self, rules_path: str | Path, override: bool = False) -> int:
        """
        Load custom rules from a YAML file.

        Args:
            rules_path: Path to rules_custom.yml
            override: If True, replace conflicting rules

        Returns:
            Number of rules successfully loaded

        Raises:
            FileNotFoundError: If rules file doesn't exist
            ValueError: If rules file has invalid format
        """
        rules = load_custom_rules(rules_path)
        loaded_count = 0

        for rule in rules:
            if self.register_rule(rule, override=override):
                loaded_count += 1

        self._load_history.append(str(rules_path))
        return loaded_count

    def get_rule(self, rule_id: str) -> Optional[CustomRuleSchema]:
        """Get a rule by ID."""
        return self._rules.get(rule_id)

    def get_rules_by_category(self, category: str) -> List[CustomRuleSchema]:
        """Get all enabled rules in a category."""
        return [r for r in self._rules_by_category.get(category, []) if r.enabled]

    def get_all_rules(self, enabled_only: bool = True) -> List[CustomRuleSchema]:
        """
        Get all registered rules.

        Args:
            enabled_only: If True, return only enabled rules

        Returns:
            List of CustomRuleSchema objects
        """
        rules = list(self._rules.values())
        if enabled_only:
            rules = [r for r in rules if r.enabled]
        return rules

    def validate_line(self, line: str, line_number: int) -> List[RuleViolation]:
        """
        Validate a single line of code against all registered rules.

        Args:
            line: Source code line
            line_number: Line number in file

        Returns:
            List of RuleViolation objects
        """
        violations = []

        for rule in self.get_all_rules(enabled_only=True):
            if rule.matches(line):
                # Extract matched text
                match = re.search(rule.pattern, line)
                matched_text = match.group(0) if match else None

                violation = RuleViolation(
                    rule_id=rule.id,
                    line_number=line_number,
                    message=rule.message,
                    severity=rule.severity,
                    category=rule.category,
                    matched_text=matched_text,
                )
                violations.append(violation)

        return violations

    def validate_file(self, file_path: str | Path) -> List[RuleViolation]:
        """
        Validate an entire file against all registered rules.

        Args:
            file_path: Path to source file

        Returns:
            List of all RuleViolation objects found in file
        """
        violations = []

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line_number, line in enumerate(f, start=1):
                    line_violations = self.validate_line(line.rstrip("\n"), line_number)
                    violations.extend(line_violations)
        except FileNotFoundError:
            pass  # File doesn't exist - no violations
        except Exception:
            pass  # Other errors - skip file

        return violations

    def validate_content(self, content: str) -> List[RuleViolation]:
        """
        Validate string content against all registered rules.

        Args:
            content: Source code content

        Returns:
            List of RuleViolation objects
        """
        violations = []

        for line_number, line in enumerate(content.splitlines(), start=1):
            line_violations = self.validate_line(line, line_number)
            violations.extend(line_violations)

        return violations

    def get_statistics(self) -> RegistryStatistics:
        """
        Get statistics about registered rules.

        Returns:
            RegistryStatistics object
        """
        all_rules = list(self._rules.values())
        enabled_rules = [r for r in all_rules if r.enabled]

        by_severity = {}
        for severity in RuleSeverity:
            count = sum(1 for r in enabled_rules if r.severity == severity)
            by_severity[severity.value] = count

        by_category = {}
        for rule in enabled_rules:
            by_category[rule.category] = by_category.get(rule.category, 0) + 1

        return RegistryStatistics(
            total_rules=len(all_rules),
            enabled_rules=len(enabled_rules),
            rules_by_severity=by_severity,
            rules_by_category=by_category,
            conflicting_ids=list(self._conflicts),
        )

    def clear(self):
        """Remove all registered rules."""
        self._rules.clear()
        self._rules_by_category.clear()
        self._load_history.clear()
        self._conflicts.clear()

    def disable_rule(self, rule_id: str) -> bool:
        """
        Disable a rule by ID.

        Args:
            rule_id: ID of rule to disable

        Returns:
            True if rule was disabled, False if not found
        """
        rule = self._rules.get(rule_id)
        if rule:
            rule.enabled = False
            return True
        return False

    def enable_rule(self, rule_id: str) -> bool:
        """
        Enable a rule by ID.

        Args:
            rule_id: ID of rule to enable

        Returns:
            True if rule was enabled, False if not found
        """
        rule = self._rules.get(rule_id)
        if rule:
            rule.enabled = True
            return True
        return False
