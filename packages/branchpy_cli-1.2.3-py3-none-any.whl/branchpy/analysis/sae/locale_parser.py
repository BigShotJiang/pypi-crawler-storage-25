"""
SAE Locale Parser - Phase 7 (v0.7.7)

Integrates L10n extraction into the Static Analysis Engine.
Builds locales_index.json for validation and reporting.

This module bridges the existing branchpy.l10n module with SAE's validation pipeline.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.l10n import L10nIndex, compute_coverage, extract_strings


@dataclass
class LocaleIndexSchema:
    """
    SAE-compatible locale index schema for validation and reporting.

    This is the output schema for locales_index.json, which is consumed by:
    - locale_validator.py (SAE validation rules)
    - unified report exporter (HTML/JSON reports)
    - VS Code webview dashboard

    Schema v1.0 (v0.7.7)
    """

    # Core extraction data
    total_source_strings: int
    languages: List[str]
    source_strings: Dict[str, str]  # string_id -> text
    translations: Dict[str, Dict[str, str]]  # lang -> {string_id -> text}
    locator: Dict[str, Dict[str, Any]]  # string_id -> {file, line}

    # Coverage summaries (per language)
    coverage: Dict[
        str, Dict[str, Any]
    ]  # lang -> {totalStrings, translated, coveragePercent, missing, orphaned, lengthMismatches}

    # Metadata
    project_root: str
    extraction_timestamp: str
    version: str = "1.0"

    def to_json(self) -> str:
        """Serialize to JSON string"""
        return json.dumps(asdict(self), indent=2, default=list)

    def save(self, output_path: Path) -> None:
        """Save to locales_index.json"""
        output_path.write_text(self.to_json(), encoding="utf-8")


class LocaleParser:
    """
    SAE Locale Parser

    Extracts localization data and generates locales_index.json for validation.
    Wraps the existing branchpy.l10n module with SAE-specific schema.
    """

    def __init__(self, project_root: str | Path):
        """
        Args:
            project_root: Project root directory (must contain game/ directory)
        """
        self.project_root = Path(project_root)
        self.l10n_index: Optional[L10nIndex] = None
        self.locale_index: Optional[LocaleIndexSchema] = None

    def parse(self, languages: Optional[List[str]] = None) -> LocaleIndexSchema:
        """
        Parse project and build locale index.

        Args:
            languages: Languages to analyze (default: auto-detect from project)

        Returns:
            LocaleIndexSchema ready for validation
        """
        # Extract strings using existing l10n module
        self.l10n_index = extract_strings(self.project_root)

        # Auto-detect languages if not specified
        detected_languages = list(self.l10n_index.languages)
        target_languages = languages or detected_languages

        # Compute coverage for each language
        coverage_summaries = {}
        for lang in target_languages:
            summary = compute_coverage(self.l10n_index, lang)
            coverage_summaries[lang] = {
                "language": lang,
                "totalStrings": summary.total_strings,
                "translated": summary.translated,
                "coveragePercent": round(summary.coverage_pct, 2),
                "missing": len(summary.missing),
                "orphaned": len(summary.orphaned),
                "lengthMismatches": len(summary.length_mismatches),
                "missingIds": list(summary.missing),  # For detailed reporting
                "orphanedIds": list(summary.orphaned),
                "mismatchIds": list(summary.length_mismatches),
            }

        # Build locator map (string_id -> {file, line})
        locator_map = {}
        for string_id, (file, line) in self.l10n_index.locator.items():
            locator_map[string_id] = {"file": file, "line": line}

        # Build schema
        self.locale_index = LocaleIndexSchema(
            total_source_strings=len(self.l10n_index.source),
            languages=target_languages,
            source_strings=self.l10n_index.source,
            translations=self.l10n_index.translations,
            locator=locator_map,
            coverage=coverage_summaries,
            project_root=str(self.project_root),
            extraction_timestamp=datetime.now(timezone.utc).isoformat(),
        )

        return self.locale_index

    def export_index(self, output_path: Optional[Path] = None) -> Path:
        """
        Export locales_index.json to .branchpy/artifacts/

        Args:
            output_path: Custom output path (default: .branchpy/artifacts/locales_index.json)

        Returns:
            Path to exported file
        """
        if not self.locale_index:
            raise RuntimeError("Must call parse() before export_index()")

        if output_path is None:
            artifacts_dir = self.project_root / ".branchpy" / "artifacts"
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            output_path = artifacts_dir / "locales_index.json"
        else:
            # Ensure parent directory exists when explicit path is provided
            output_path.parent.mkdir(parents=True, exist_ok=True)

        self.locale_index.save(output_path)
        return output_path

    def get_missing_translations(self, lang: str) -> List[Dict[str, Any]]:
        """
        Get list of missing translations for a language.

        Args:
            lang: Language code

        Returns:
            List of {stringId, sourceText, file, line} dicts
        """
        if not self.locale_index:
            raise RuntimeError("Must call parse() before get_missing_translations()")

        missing_ids = self.locale_index.coverage[lang]["missingIds"]

        results = []
        for string_id in missing_ids:
            source_text = self.locale_index.source_strings.get(string_id, "")
            location = self.locale_index.locator.get(
                string_id, {"file": "<unknown>", "line": 1}
            )

            results.append(
                {
                    "stringId": string_id,
                    "sourceText": source_text,
                    "file": location["file"],
                    "line": location["line"],
                }
            )

        return results

    def get_orphaned_translations(self, lang: str) -> List[Dict[str, Any]]:
        """
        Get list of orphaned translations for a language.

        Args:
            lang: Language code

        Returns:
            List of {stringId, translatedText} dicts
        """
        if not self.locale_index:
            raise RuntimeError("Must call parse() before get_orphaned_translations()")

        orphaned_ids = self.locale_index.coverage[lang]["orphanedIds"]

        results = []
        for string_id in orphaned_ids:
            trans_text = self.locale_index.translations[lang].get(string_id, "")

            results.append(
                {
                    "stringId": string_id,
                    "translatedText": trans_text,
                }
            )

        return results

    def get_length_mismatches(self, lang: str) -> List[Dict[str, Any]]:
        """
        Get list of length-mismatched translations for a language.

        Args:
            lang: Language code

        Returns:
            List of {stringId, sourceText, translatedText, sourceLength, translatedLength, file, line} dicts
        """
        if not self.locale_index:
            raise RuntimeError("Must call parse() before get_length_mismatches()")

        mismatch_ids = self.locale_index.coverage[lang]["mismatchIds"]

        results = []
        for string_id in mismatch_ids:
            source_text = self.locale_index.source_strings.get(string_id, "")
            trans_text = self.locale_index.translations[lang].get(string_id, "")
            location = self.locale_index.locator.get(
                string_id, {"file": "<unknown>", "line": 1}
            )

            results.append(
                {
                    "stringId": string_id,
                    "sourceText": source_text,
                    "translatedText": trans_text,
                    "sourceLength": len(source_text),
                    "translatedLength": len(trans_text),
                    "file": location["file"],
                    "line": location["line"],
                }
            )

        return results


def build_locale_index(
    project_root: str | Path, languages: Optional[List[str]] = None
) -> LocaleIndexSchema:
    """
    Convenience function to build locale index in one call.

    Args:
        project_root: Project root directory
        languages: Languages to analyze (default: auto-detect)

    Returns:
        LocaleIndexSchema
    """
    parser = LocaleParser(project_root)
    return parser.parse(languages)
