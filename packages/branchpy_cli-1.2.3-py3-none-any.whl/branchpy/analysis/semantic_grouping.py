"""
semantic_grouping.py — Motif detection, scoring, and group generation pipeline.

Phase 1 (active): M1 (orphan cluster) + M2 (peripheral island).
Phase 1.5 (active): M3 (linear narrative chain) — balanced/aggressive only.

Part of FLOWCHART-SEMANTIC-COMPRESSION-V1 (feature/semantic-compression branch).
Spec: docs/Current Version/flowchart/SEMANTIC_COMPRESSION_SPEC_V1.md
"""

from __future__ import annotations

import os
from typing import Any

from branchpy.analysis.group_types import Group, make_fingerprint, make_group_id

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_AUTO_GROUP_PRESET: str = "off"

# M1 — Orphan cluster
ORPHAN_MAX_IMPORTANCE_SCORE: float = 0.3
ORPHAN_MIN_CLUSTER_SIZE: int = 2  # at least 2 degree-0 nodes to form a group

# M2 — Peripheral island
ISLAND_MAX_NODES: int = 8
ISLAND_MAX_CROSS_EDGES: int = 2

# M3 / M4 — Deferred to Phase 2
# Per-preset minimum chain length: aggressive allows shorter chains (≥3 = head+1 interior+tail)
LINEAR_MIN_LENGTH: int = 4
LINEAR_MIN_LENGTH_AGGRESSIVE: int = 3
LINEAR_MAX_FILE_SPAN: int = 2
BURST_MAX_NODES: int = 6

# Scoring thresholds per preset
SCORE_THRESHOLD_CONSERVATIVE: float = 0.80
SCORE_THRESHOLD_BALANCED: float = 0.65
SCORE_THRESHOLD_AGGRESSIVE: float = 0.50

# Scoring weights
WEIGHT_TOPOLOGY_SIMPLICITY: float = 2.0
WEIGHT_LOW_EXTERNAL_LINKS: float = 2.5
WEIGHT_SAME_FILE: float = 1.0
WEIGHT_LOW_IMPORTANCE: float = 1.5
WEIGHT_SIZE_BENEFIT: float = 1.0

_TOTAL_WEIGHT = (
    WEIGHT_TOPOLOGY_SIMPLICITY
    + WEIGHT_LOW_EXTERNAL_LINKS
    + WEIGHT_SAME_FILE
    + WEIGHT_LOW_IMPORTANCE
    + WEIGHT_SIZE_BENEFIT
)


# ---------------------------------------------------------------------------
# Internal graph helpers
# ---------------------------------------------------------------------------


def _parse_edge_endpoints(edge: dict[str, Any]) -> tuple[str, str]:
    """Return (src, dst) from an edge dict, tolerating multiple field name conventions."""
    src = str(
        edge.get(
            "source",
            edge.get(
                "from", edge.get("src", edge.get("from_node", edge.get("from_id", "")))
            ),
        )
    )
    dst = str(
        edge.get(
            "target",
            edge.get("to", edge.get("dst", edge.get("to_node", edge.get("to_id", "")))),
        )
    )
    return src, dst


def _build_adjacency(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """
    Return (out_adj, in_adj) adjacency sets indexed by node_id.
    Only includes IDs that appear in the nodes list.
    """
    node_ids = {str(n.get("id", "")) for n in nodes if n.get("id")}
    out_adj: dict[str, set[str]] = {nid: set() for nid in node_ids}
    in_adj: dict[str, set[str]] = {nid: set() for nid in node_ids}

    for edge in edges:
        src, dst = _parse_edge_endpoints(edge)
        if src in node_ids and dst in node_ids:
            out_adj[src].add(dst)
            in_adj[dst].add(src)

    return out_adj, in_adj


def _node_type(node: dict[str, Any]) -> str:
    return str(node.get("type", node.get("kind", "node")))


def _node_file(node: dict[str, Any]) -> str:
    raw = str(node.get("file", ""))
    return os.path.basename(raw) if raw else ""


def _node_file_basename_no_ext(node: dict[str, Any]) -> str:
    name = _node_file(node)
    return os.path.splitext(name)[0] if name else ""


def _derive_importance(node: dict[str, Any]) -> float:
    """
    Derive a 0-1 importance score from available node metadata.
    High importance: entry points, branch hubs, backbone nodes.
    Low importance: utility, unreachable, leaf-terminal nodes.
    """
    ntype = _node_type(node)
    if ntype in ("entry",):
        return 1.0
    if ntype in ("exit",):
        return 0.9
    semantic_role = str(node.get("semantic_role", ""))
    if semantic_role == "branch_hub" or node.get("branch_hub"):
        return 0.85
    if node.get("on_backbone"):
        return 0.7
    if node.get("entry_candidate"):
        return 0.65
    # Derive from degree
    in_deg = int(node.get("in_degree") or 0)
    out_deg = int(node.get("out_degree") or 0)
    total_deg = in_deg + out_deg
    if total_deg == 0:
        # Orphan; importance is zero for connectivity purposes but may vary for semantic
        if ntype in ("utility", "screen", "execution_container"):
            return 0.1
        return 0.2
    deg_score = min(1.0, total_deg / 8.0)  # cap at 8 connections
    if semantic_role == "utility" or ntype in ("utility", "screen"):
        return min(0.3, deg_score * 0.4)
    return min(0.8, deg_score * 0.6)


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------


def _score_candidate(
    member_node_ids: list[str],
    entry_node_ids: list[str],
    exit_node_ids: list[str],
    node_map: dict[str, dict[str, Any]],
) -> float:
    """
    Compute a 0-1 composite score for a group candidate.
    Higher = safer to auto-group.
    """
    if not member_node_ids:
        return 0.0

    members = [node_map[nid] for nid in member_node_ids if nid in node_map]
    n = len(members)
    boundary_count = len(set(entry_node_ids) | set(exit_node_ids))

    # 1. Topology simplicity: ratio of internal connectivity vs boundary exposure
    internal_max = n * (n - 1)
    cross = boundary_count
    topology_score = max(0.0, 1.0 - (cross / max(1, n))) if n > 0 else 0.0

    # 2. Low external links: fewer boundary nodes = cleaner group
    ext_link_score = 1.0 - (cross / max(1, n * 2))
    ext_link_score = max(0.0, ext_link_score)

    # 3. File locality: fraction sharing the most common file basename
    file_counts: dict[str, int] = {}
    for node in members:
        fname = _node_file(node)
        if fname:
            file_counts[fname] = file_counts.get(fname, 0) + 1
    if file_counts:
        max_same = max(file_counts.values())
        file_score = max_same / n
    else:
        file_score = 0.5  # unknown file — neutral

    # 4. Low importance: members with low importance are safer to group
    importances = [_derive_importance(node) for node in members]
    avg_importance = sum(importances) / len(importances) if importances else 0.5
    importance_score = 1.0 - avg_importance

    # 5. Size benefit: larger groups are worth grouping more
    size_score = min(1.0, n / 10.0)

    return (
        WEIGHT_TOPOLOGY_SIMPLICITY * topology_score
        + WEIGHT_LOW_EXTERNAL_LINKS * ext_link_score
        + WEIGHT_SAME_FILE * file_score
        + WEIGHT_LOW_IMPORTANCE * importance_score
        + WEIGHT_SIZE_BENEFIT * size_score
    ) / _TOTAL_WEIGHT


# ---------------------------------------------------------------------------
# Motif M1: Orphan cluster
# ---------------------------------------------------------------------------


def detect_orphan_clusters(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    node_fingerprints: dict[str, str],
) -> list[Group]:
    """
    M1: Groups degree-0 nodes that share a source file (or type if no file data).

    Safety gates:
    - Node type is not 'entry'
    - Node importance <= ORPHAN_MAX_IMPORTANCE_SCORE
    - At least ORPHAN_MIN_CLUSTER_SIZE nodes per group
    """
    out_adj, in_adj = _build_adjacency(nodes, edges)
    node_map = {str(n.get("id", "")): n for n in nodes if n.get("id")}

    # Collect degree-0 nodes passing safety gates
    orphan_ids: list[str] = []
    for nid, node in node_map.items():
        if out_adj.get(nid) or in_adj.get(nid):
            continue  # not degree-0
        if _node_type(node) == "entry":
            continue  # safety gate
        if node.get("entry_candidate"):
            continue  # safety gate (PFI entry)
        if _derive_importance(node) > ORPHAN_MAX_IMPORTANCE_SCORE:
            continue
        orphan_ids.append(nid)

    if not orphan_ids:
        return []

    # Group by file basename; fall back to type for nodes without file info
    buckets: dict[str, list[str]] = {}
    for nid in orphan_ids:
        node = node_map[nid]
        key = _node_file_basename_no_ext(node) or _node_type(node) or "unknown"
        buckets.setdefault(key, []).append(nid)

    groups: list[Group] = []
    for bucket_key, member_ids in buckets.items():
        if len(member_ids) < ORPHAN_MIN_CLUSTER_SIZE:
            continue

        entry_ids: list[str] = []  # degree-0, no incoming edges from outside
        exit_ids: list[str] = []  # degree-0, no outgoing edges to outside

        score = _score_candidate(member_ids, entry_ids, exit_ids, node_map)
        fp = make_fingerprint(member_ids, node_fingerprints)
        gid = make_group_id("orphan_cluster", member_ids, entry_ids, exit_ids)

        label = f"Orphan cluster · {len(member_ids)} nodes · {bucket_key}"
        reason = f"Degree-0 nodes sharing file/type '{bucket_key}'"

        groups.append(
            Group(
                group_id=gid,
                origin="auto",
                motif_type="orphan_cluster",
                label=label,
                member_node_ids=sorted(member_ids),
                entry_node_ids=entry_ids,
                exit_node_ids=exit_ids,
                collapsed=None,
                pinned=False,
                stale=False,
                reason=reason,
                score=score,
                generation_fingerprint=fp,
                metadata={"file_key": bucket_key, "size": len(member_ids)},
            )
        )

    return groups


# ---------------------------------------------------------------------------
# Motif M2: Peripheral island
# ---------------------------------------------------------------------------


def _find_components(
    node_ids: set[str], undirected_adj: dict[str, set[str]]
) -> list[set[str]]:
    """BFS to find weakly-connected components."""
    visited: set[str] = set()
    components: list[set[str]] = []
    for start in node_ids:
        if start in visited:
            continue
        component: set[str] = set()
        queue = [start]
        while queue:
            cur = queue.pop()
            if cur in visited:
                continue
            visited.add(cur)
            component.add(cur)
            for nbr in undirected_adj.get(cur, set()):
                if nbr not in visited:
                    queue.append(nbr)
        components.append(component)
    return components


def detect_peripheral_islands(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    node_fingerprints: dict[str, str],
) -> list[Group]:
    """
    M2: Groups weakly-connected components with few cross-edges to the main graph.

    Safety gates:
    - No node has type 'entry' or is entry_candidate
    - Component size <= ISLAND_MAX_NODES
    - Cross-edges to the rest of the graph <= ISLAND_MAX_CROSS_EDGES
    """
    out_adj, in_adj = _build_adjacency(nodes, edges)
    node_map = {str(n.get("id", "")): n for n in nodes if n.get("id")}
    node_ids = set(node_map.keys())

    # Build undirected adjacency for component detection
    undirected_adj: dict[str, set[str]] = {nid: set() for nid in node_ids}
    for nid in node_ids:
        for nbr in out_adj.get(nid, set()):
            undirected_adj[nid].add(nbr)
            undirected_adj[nbr].add(nid)

    components = _find_components(node_ids, undirected_adj)

    # Filter to components that aren't the main (largest) component
    if not components:
        return []
    largest_size = max(len(c) for c in components)

    groups: list[Group] = []
    for component in components:
        if len(component) == largest_size:
            continue  # skip main component
        if len(component) < 2:
            continue  # single nodes handled by M1 if degree-0
        if len(component) > ISLAND_MAX_NODES:
            continue  # too large

        # Safety gate: no entry-type nodes
        if any(
            _node_type(node_map[nid]) == "entry" or node_map[nid].get("entry_candidate")
            for nid in component
            if nid in node_map
        ):
            continue

        # Count cross-edges (edges between component and outside)
        cross_edges = 0
        entry_ids: list[str] = []
        exit_ids: list[str] = []
        for nid in component:
            for nbr in out_adj.get(nid, set()):
                if nbr not in component:
                    cross_edges += 1
                    if nid not in exit_ids:
                        exit_ids.append(nid)
            for nbr in in_adj.get(nid, set()):
                if nbr not in component:
                    cross_edges += 1
                    if nid not in entry_ids:
                        entry_ids.append(nid)

        if cross_edges > ISLAND_MAX_CROSS_EDGES:
            continue

        member_ids = sorted(component)
        score = _score_candidate(member_ids, entry_ids, exit_ids, node_map)
        fp = make_fingerprint(member_ids, node_fingerprints)
        gid = make_group_id("peripheral_island", member_ids, entry_ids, exit_ids)

        # Anchor: label of highest-importance member (alphabetical tiebreak)
        anchor_node = (
            sorted(
                (node_map[nid] for nid in member_ids if nid in node_map),
                key=lambda n: (
                    -_derive_importance(n),
                    str(n.get("label", n.get("id", ""))),
                ),
            )[0]
            if member_ids
            else None
        )
        anchor_label = (
            str(anchor_node.get("label", anchor_node.get("id", "island")))
            if anchor_node
            else "island"
        )

        label = f"Peripheral island · {len(member_ids)} nodes · {anchor_label}"
        reason = (
            f"Weakly-connected component, {cross_edges} cross-edge(s) to main graph"
        )

        groups.append(
            Group(
                group_id=gid,
                origin="auto",
                motif_type="peripheral_island",
                label=label,
                member_node_ids=member_ids,
                entry_node_ids=sorted(entry_ids),
                exit_node_ids=sorted(exit_ids),
                collapsed=None,
                pinned=False,
                stale=False,
                reason=reason,
                score=score,
                generation_fingerprint=fp,
                metadata={
                    "anchor_label": anchor_label,
                    "cross_edges": cross_edges,
                    "size": len(member_ids),
                },
            )
        )

    return groups


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Motif M3: Linear narrative chain
# ---------------------------------------------------------------------------


def detect_linear_chains(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    node_fingerprints: dict[str, str],
    min_length: int = LINEAR_MIN_LENGTH,
) -> list[Group]:
    """
    M3: Finds maximal paths where every internal node has in-degree 1 and
    out-degree 1 (strict linear segments). The head node may have multiple
    predecessors and the tail may have multiple successors — they are the
    natural entry/exit points. Internal nodes must have no cross-references
    outside the chain.

    Parameters
    ----------
    min_length:
        Minimum total chain length (head + internals + tail). Defaults to
        LINEAR_MIN_LENGTH (4). Aggressive preset passes LINEAR_MIN_LENGTH_AGGRESSIVE
        (3) to catch shorter-but-valid chains on highly branching VN graphs.

    Safety gates (per spec):
    - No internal node has type 'entry' or 'exit'
    - No internal node is an entry_candidate
    - Chain spans ≤ LINEAR_MAX_FILE_SPAN distinct source files
    - Minimum length ≥ min_length (head+internal+tail nodes total)
    """
    out_adj, in_adj = _build_adjacency(nodes, edges)
    node_map = {str(n.get("id", "")): n for n in nodes if n.get("id")}
    node_ids = set(node_map.keys())

    # Build the set of "pass-through" nodes: exactly 1 in-edge and 1 out-edge.
    # These are the candidates for chain interiors (and may also be chain heads
    # when their sole predecessor is a branch hub).
    passthrough: set[str] = {
        nid
        for nid in node_ids
        if len(out_adj.get(nid, set())) == 1 and len(in_adj.get(nid, set())) == 1
    }

    # Find maximal chains: walk forward from nodes that are NOT pass-through
    # (i.e. they have != 1 successor OR != 1 predecessor) into runs of
    # pass-through nodes. The start node itself is the chain entry.
    #
    # CRITICAL: mark nodes visited immediately as they join the chain — not only
    # when the chain is accepted.  Without this, two bugs arise on VN graphs:
    #   1. Failed chains (rejected by safety gates) leave their nodes unguarded,
    #      causing every downstream start to re-walk the same segment → O(n²).
    #   2. VN back-edges (label loops) create passthrough cycles (A→B→A) that
    #      the while-condition can never escape → infinite loop.
    visited: set[str] = set()
    groups: list[Group] = []

    for start in sorted(node_ids):  # sorted for determinism
        if start in visited:
            continue
        successors = out_adj.get(start, set())
        if len(successors) != 1:
            continue  # start node must have exactly 1 successor to begin a chain
        next_node = next(iter(successors))
        if next_node not in passthrough:
            continue  # successor must be a pass-through node

        # Walk the chain forward through pass-through nodes.
        # Mark each node visited immediately so cycles and re-walks are impossible.
        chain: list[str] = [start]
        visited.add(start)
        cur = next_node
        while cur in passthrough and cur not in visited:
            chain.append(cur)
            visited.add(cur)  # ← eager mark: prevents cycles + redundant re-walk
            nexts = out_adj.get(cur, set())
            if not nexts:
                break
            cur = next(iter(nexts))
        # cur is now the tail (first non-passthrough after the chain); do NOT add to
        # visited so it remains a valid chain start if it has passthrough successors.
        if cur not in visited and cur not in chain:
            chain.append(cur)

        # Length gate: need at least min_length nodes total
        if len(chain) < min_length:
            continue

        # The head is chain[0] (entry), tail is chain[-1] (exit),
        # internal nodes are chain[1:-1].
        internal = chain[1:-1]
        entry_node = chain[0]
        exit_node = chain[-1]

        # Safety gate: no internal node of type entry/exit or entry_candidate
        if any(
            _node_type(node_map[nid]) in ("entry", "exit")
            or node_map[nid].get("entry_candidate")
            for nid in internal
            if nid in node_map
        ):
            continue

        # Safety gate: no internal node has external cross-references
        # (i.e. it should have no edges to/from nodes outside the chain)
        chain_set = set(chain)
        has_cross = False
        for nid in internal:
            ext_out = out_adj.get(nid, set()) - chain_set
            ext_in = in_adj.get(nid, set()) - chain_set
            if ext_out or ext_in:
                has_cross = True
                break
        if has_cross:
            continue

        # File span gate: chain must not span too many distinct source files
        files = {
            _node_file_basename_no_ext(node_map[nid])
            for nid in chain
            if nid in node_map
        }
        files.discard("")  # nodes with no file info don't count against the span
        if len(files) > LINEAR_MAX_FILE_SPAN:
            continue

        # All gates passed — build the group
        member_ids = sorted(chain)
        # (nodes already in visited; no extra update needed)

        entry_ids = [entry_node]
        exit_ids = [exit_node]
        score = _score_candidate(member_ids, entry_ids, exit_ids, node_map)
        fp = make_fingerprint(member_ids, node_fingerprints)
        gid = make_group_id("linear_chain", member_ids, entry_ids, exit_ids)

        # Anchor = label of entry node
        anchor_label = str(
            node_map[entry_node].get(
                "label", node_map[entry_node].get("id", entry_node)
            )
            if entry_node in node_map
            else entry_node
        )
        label = f"Linear chain \u00b7 {len(chain)} nodes \u00b7 {anchor_label}"
        reason = (
            f"Strict linear chain (1 in / 1 out per internal node), "
            f"{len(chain)} nodes, {len(files) or 'unknown'} source file(s)"
        )

        groups.append(
            Group(
                group_id=gid,
                origin="auto",
                motif_type="linear_chain",
                label=label,
                member_node_ids=member_ids,
                entry_node_ids=entry_ids,
                exit_node_ids=exit_ids,
                collapsed=None,
                pinned=False,
                stale=False,
                reason=reason,
                score=score,
                generation_fingerprint=fp,
                metadata={
                    "anchor_label": anchor_label,
                    "chain_length": len(chain),
                    "file_span": sorted(files),
                },
            )
        )

    return groups


# ---------------------------------------------------------------------------
# Main entry point


def detect_auto_groups(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    preset: str,
    existing_groups: list[Group],
    node_fingerprints: dict[str, str],
) -> list[Group]:
    """
    Detect auto-groups for the given graph and preset.

    Returns only newly detected auto-groups (not existing manual/pinned ones).
    Never produces groups that overlap with manual or pinned groups.

    Parameters
    ----------
    nodes:
        List of node dicts from collapsed_graph["nodes"].
    edges:
        List of edge dicts from collapsed_graph["edges"].
    preset:
        One of 'off', 'conservative', 'balanced', 'aggressive'.
    existing_groups:
        Groups already saved (manual + pinned). Used for pre-claiming nodes.
    node_fingerprints:
        Dict mapping node_id → hash of its source content. Pass {} if unavailable.

    Returns
    -------
    list[Group]
        Newly detected auto groups, non-overlapping and scored above threshold.
    """
    if preset == "off":
        return []

    threshold = {
        "conservative": SCORE_THRESHOLD_CONSERVATIVE,
        "balanced": SCORE_THRESHOLD_BALANCED,
        "aggressive": SCORE_THRESHOLD_AGGRESSIVE,
    }.get(preset, SCORE_THRESHOLD_CONSERVATIVE)

    # M1+M2: all presets
    # M3 (linear chain): balanced + aggressive only (spec: disabled for conservative)
    #   aggressive uses a shorter minimum (3 nodes) to catch chains on games with
    #   highly branching structures (e.g. MAS) where long linear runs are rare.
    detectors = [detect_orphan_clusters, detect_peripheral_islands]

    # Collect all candidates across detectors
    candidates: list[Group] = []
    for detector in detectors:
        new_candidates = [
            g for g in detector(nodes, edges, node_fingerprints) if g.score >= threshold
        ]
        if new_candidates:
            candidates.extend(new_candidates)

    # M3: called directly so we can pass the per-preset min_length
    if preset in ("balanced", "aggressive"):
        m3_min = (
            LINEAR_MIN_LENGTH_AGGRESSIVE
            if preset == "aggressive"
            else LINEAR_MIN_LENGTH
        )
        m3_candidates = [
            g
            for g in detect_linear_chains(
                nodes, edges, node_fingerprints, min_length=m3_min
            )
            if g.score >= threshold
        ]
        candidates.extend(m3_candidates)

    if not candidates:
        return []

    # Non-overlap enforcement:
    # Step 1: pre-claim nodes owned by manual or pinned groups
    claimed_nodes: set[str] = set()
    for g in existing_groups:
        if g.origin == "manual" or g.pinned:
            claimed_nodes.update(g.member_node_ids)

    # Step 2: rank candidates by (score DESC, size DESC, group_id ASC for full determinism)
    result: list[Group] = []
    for candidate in sorted(
        candidates,
        key=lambda c: (c.score, len(c.member_node_ids), c.group_id),
        reverse=True,
    ):
        if set(candidate.member_node_ids).isdisjoint(claimed_nodes):
            result.append(candidate)
            claimed_nodes.update(candidate.member_node_ids)
        # else: skip entirely — no splitting, no partial acceptance

    return result
