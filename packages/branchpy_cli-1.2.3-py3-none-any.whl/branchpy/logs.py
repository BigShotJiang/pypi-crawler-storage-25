# branchpy/logs.py
"""
Comprehensive structured logging system for BranchPy v0.7.21+
Provides:
- Structured JSONL event logging with correlation IDs
- Ring buffer for in-memory tail
- File rotation and redaction
- Support bundle generation
"""
from __future__ import annotations

import hashlib
import inspect
import json
import os
import platform
import re
import sys
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Log levels (aligned with common practice, TRACE below DEBUG, FATAL at top)
# Numeric values loosely follow customary spacing used by log frameworks.
# Keeping our custom map to avoid depending on Python's logging module here.
LEVELS = {
    "TRACE": 5,  # ultra-fine events (high volume)
    "DEBUG": 10,  # diagnostic information for developers
    "INFO": 20,  # high-level progress information
    "WARN": 30,  # something unexpected, but the app can continue
    "ERROR": 40,  # a failure that prevents an operation from succeeding
    "FATAL": 50,  # unrecoverable / process should terminate or restart
}

# Per-level metrics counters (in-memory, not persisted). Incremented for every accepted event.
_metrics = {name: 0 for name in LEVELS.keys()}
_metrics_lock = threading.Lock()
_trace_window_start = 0.0
_trace_window_count = 0
_trace_rate_limit_per_sec = 500  # default max TRACE events per second
_trace_rate_dropped = 0

# Default configuration
_config = {
    "level": "INFO",
    "component": "cli",
    "sinks": [
        "file",
        "mem",
    ],  # FIXED: controlcenter disabled by default (causes 0.5s timeout per log event!)
    "maxFileMB": 10,
    "rotation_count": 5,
    "redaction": "standard",  # standard | strict | off
    "ring_buffer_size": 5000,
    "controlcenter_url": "http://localhost:8765",  # Dashboard URL for Control Center integration
    "controlcenter_enabled": False,  # Explicitly opt-in to avoid performance issues
}

# Thread-local context
_run = threading.local()
_run.session_id = None
_run.run_id = None
_run.project_id = None
_run.install_id = None

# Ring buffer for in-memory tail
_ring_buffer: deque = deque(maxlen=_config["ring_buffer_size"])
_ring_lock = threading.Lock()

# Installation ID (stable UUID)
_install_id_file: Optional[Path] = None

# Control Center connection state (fail-fast after first failure)
_controlcenter_available = None  # None = unknown, True = working, False = failed
_controlcenter_last_check = 0.0


def _get_install_id() -> str:
    """Get or create a stable installation ID."""
    global _install_id_file
    if not _install_id_file:
        base = _get_base_dir()
        _install_id_file = base / "install_id.txt"

    if _install_id_file.exists():
        return _install_id_file.read_text().strip()

    install_id = str(uuid.uuid4())
    _install_id_file.write_text(install_id)
    return install_id


def _get_base_dir() -> Path:
    """Get BranchPy base directory (~/.branchpy or %LOCALAPPDATA%\\BranchPy)."""
    if sys.platform.startswith("win"):
        base = (
            os.environ.get("LOCALAPPDATA")
            or os.environ.get("APPDATA")
            or str(Path.home())
        )
        return Path(base) / "BranchPy"
    return Path.home() / ".branchpy"


def _get_logs_dir() -> Path:
    """Get logs directory."""
    logs_dir = _get_base_dir() / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    return logs_dir


def _get_log_file(component: str = "events") -> Path:
    """Get log file path for a component."""
    return _get_logs_dir() / f"{component}.jsonl"


def _now() -> str:
    """Return ISO 8601 timestamp with milliseconds."""
    return (
        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        + f".{int(time.time() % 1 * 1000):03d}Z"
    )


def _hash_project(path: str) -> str:
    """Create a stable, redacted project ID from path."""
    return "proj_" + hashlib.sha256(path.encode()).hexdigest()[:8]


def set_context(
    component: Optional[str] = None,
    session_id: Optional[str] = None,
    run_id: Optional[str] = None,
    project_id: Optional[str] = None,
    level: Optional[str] = None,
):
    """Set logging context for current thread."""
    global _config
    if component:
        _config["component"] = component
    if level:
        _config["level"] = level.upper()
    _run.session_id = session_id or getattr(_run, "session_id", None)
    _run.run_id = run_id or getattr(_run, "run_id", None)
    _run.project_id = project_id or getattr(_run, "project_id", None)
    _run.install_id = _get_install_id()


def set_level(
    level: str, component: Optional[str] = None, duration_minutes: Optional[int] = None
):
    """
    Set log level globally or for a specific component.
    If duration_minutes is set, auto-downshift after that time.
    """
    global _config
    level = level.upper()
    if level not in LEVELS:
        raise ValueError(f"Invalid log level: {level}")

    _config["level"] = level

    if duration_minutes:
        # Schedule auto-downshift to INFO after duration
        def downshift():
            time.sleep(duration_minutes * 60)
            _config["level"] = "INFO"
            info(
                "log_level_downshift",
                msg=f"Auto-downshifted to INFO after {duration_minutes} min",
            )

        thread = threading.Thread(target=downshift, daemon=True)
        thread.start()


def enable_trace(duration_minutes: Optional[int] = None):
    """Elevate logging to TRACE temporarily for deep diagnostics.

    Args:
        duration_minutes: Auto-revert to previous level after this many minutes.
    """
    prev = _config.get("level", "INFO")
    set_level("TRACE")
    info(
        "log_level_trace_enabled",
        msg=f"TRACE enabled (prev={prev}) duration_minutes={duration_minutes}",
    )
    if duration_minutes:

        def revert():
            time.sleep(duration_minutes * 60)
            set_level(prev)
            info("log_level_reverted", msg=f"TRACE reverted to {prev}")

        threading.Thread(target=revert, daemon=True).start()


def event(level: str, event_name: str, msg: Optional[str] = None, **attrs: Any):
    """
    Log a structured event.

    Args:
        level: Log level (TRACE, DEBUG, INFO, WARN, ERROR, FATAL)
        event_name: Short event identifier (snake_case recommended)
        msg: Human-readable message
        **attrs: Additional event attributes
    """
    if LEVELS.get(level, 0) < LEVELS.get(_config["level"], 30):
        return

    # Rate limit TRACE events to prevent flooding
    if level == "TRACE":
        global _trace_window_start, _trace_window_count, _trace_rate_dropped
        now = time.time()
        if now - _trace_window_start >= 1.0:
            # new window
            if _trace_rate_dropped > 0:
                # Emit a single WARN summarizing dropped events from previous window
                _emit_rate_limit_summary(_trace_rate_dropped, _trace_rate_limit_per_sec)
            _trace_window_start = now
            _trace_window_count = 0
            _trace_rate_dropped = 0
        _trace_window_count += 1
        if _trace_window_count > _trace_rate_limit_per_sec:
            _trace_rate_dropped += 1
            return  # drop silently (summary emitted next second)

    # Get caller info
    frame = inspect.currentframe()
    if frame and frame.f_back:
        f = frame.f_back
        source = {
            "file": os.path.basename(f.f_code.co_filename),
            "line": f.f_lineno,
            "func": f.f_code.co_name,
        }
    else:
        source = {"file": "unknown", "line": 0, "func": "unknown"}

    # Build event record
    rec = {
        "ts": _now(),
        "level": level,
        "component": _config.get("component", "cli"),
        "sub": attrs.pop("sub", None),
        "event": event_name,
        "msg": msg,
        "attrs": attrs or None,
        "source": source,
        "ids": {
            "install": getattr(_run, "install_id", None) or _get_install_id(),
            "session": getattr(_run, "session_id", None),
            "run": getattr(_run, "run_id", None),
            "project": getattr(_run, "project_id", None),
        },
        "host": {
            "os": sys.platform,
            "py": platform.python_version(),
            "bpy": _get_branchpy_version(),
        },
    }

    # Metrics
    with _metrics_lock:
        if level in _metrics:
            _metrics[level] += 1

    # Write to sinks
    _write_event(rec)


# Convenience methods
def trace(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Log a TRACE event."""
    event("TRACE", event_name, msg, **attrs)


def debug(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Log a DEBUG event."""
    event("DEBUG", event_name, msg, **attrs)


def info(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Log an INFO event."""
    event("INFO", event_name, msg, **attrs)


def warn(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Log a WARN event."""
    event("WARN", event_name, msg, **attrs)


def warning(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Alias for warn() - for compatibility with logging.warning()."""
    event("WARN", event_name, msg, **attrs)


def error(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Log an ERROR event."""
    event("ERROR", event_name, msg, **attrs)


def fatal(event_name: str, msg: Optional[str] = None, **attrs: Any):
    """Log a FATAL event."""
    event("FATAL", event_name, msg, **attrs)


def emit_sample_events(component: Optional[str] = None):
    """Emit one sample event at each level for visual verification.

    Optionally override component for these events (does not persist).
    """
    original = _config.get("component")
    if component:
        _config["component"] = component
    trace("sample.trace", msg="Trace level diagnostic", detail="low")
    debug("sample.debug", msg="Debug level diagnostic", computation="ok")
    info("sample.info", msg="Informational event", phase="init")
    warn("sample.warn", msg="Something unexpected but continuing", retry="allowed")
    error("sample.error", msg="Operation failed", action="degraded")
    fatal("sample.fatal", msg="Unrecoverable condition detected", action="terminate")
    if component:
        _config["component"] = original


def enable_controlcenter(url: Optional[str] = None):
    """Enable Control Center sink at runtime.

    Args:
        url: Optional override for dashboard base URL.
    """
    if "controlcenter" not in _config.get("sinks", []):
        _config["sinks"].append("controlcenter")
    _config["controlcenter_enabled"] = True
    if url:
        _config["controlcenter_url"] = url
    info(
        "controlcenter.enabled",
        msg="Control Center sink enabled",
        url=_config.get("controlcenter_url"),
    )


def find_events_range(
    min_level: str, max_level: str, component: Optional[str] = None, limit: int = 1000
) -> List[Dict[str, Any]]:
    """Retrieve events whose level is within [min_level, max_level] inclusive.

    Args:
        min_level: Lowest severity to include.
        max_level: Highest severity to include.
        component: Optional component filter.
        limit: Max number of events returned (tail semantics).

    Returns:
        List of matching event dicts ordered by insertion (oldest first, trimmed to tail of range).
    """
    min_val = LEVELS.get(min_level.upper(), 0)
    max_val = LEVELS.get(max_level.upper(), 999)
    with _ring_lock:
        events = list(_ring_buffer)
    if component:
        events = [e for e in events if e.get("component") == component]
    filtered = [
        e for e in events if min_val <= LEVELS.get(e.get("level", "INFO"), 0) <= max_val
    ]
    return filtered[-limit:]


def _emit_rate_limit_summary(dropped: int, limit: int):
    # Internal helper: record summary of dropped TRACE events without recursion
    rec = {
        "ts": _now(),
        "level": "WARN",
        "component": _config.get("component", "cli"),
        "event": "logs.trace_rate_limited",
        "msg": f"Dropped {dropped} TRACE events (limit={limit}/sec)",
        "attrs": {"dropped": dropped, "limit_per_sec": limit},
        "source": {"file": "logs.py", "line": 0, "func": "_emit_rate_limit_summary"},
        "ids": {
            "install": getattr(_run, "install_id", None) or _get_install_id(),
            "session": getattr(_run, "session_id", None),
            "run": getattr(_run, "run_id", None),
            "project": getattr(_run, "project_id", None),
        },
        "host": {
            "os": sys.platform,
            "py": platform.python_version(),
            "bpy": _get_branchpy_version(),
        },
    }
    with _metrics_lock:
        _metrics["WARN"] += 1
    _write_event(rec)


def set_trace_rate_limit(per_second: int):
    """Update TRACE rate limit threshold at runtime."""
    global _trace_rate_limit_per_sec
    _trace_rate_limit_per_sec = max(10, per_second)
    info(
        "logs.trace_rate_limit_updated", msg=f"TRACE rate limit set to {per_second}/sec"
    )


def get_metrics() -> Dict[str, int]:
    """Return a snapshot of per-level event emission counts."""
    with _metrics_lock:
        return dict(_metrics)


def reset_metrics(levels: Optional[List[str]] = None):
    """Reset metrics counters (all or specific levels)."""
    with _metrics_lock:
        if levels:
            for lvl in levels:
                if lvl in _metrics:
                    _metrics[lvl] = 0
        else:
            for k in _metrics.keys():
                _metrics[k] = 0


def _get_branchpy_version() -> str:
    """Get BranchPy version."""
    try:
        from .contract import VERSION

        return VERSION
    except Exception:
        return "unknown"


def _write_event(rec: Dict[str, Any]):
    """Write event to configured sinks."""
    # Sink: ring buffer
    if "mem" in _config.get("sinks", []):
        with _ring_lock:
            _ring_buffer.append(rec)

    # Sink: file
    if "file" in _config.get("sinks", []):
        _write_to_file(rec)

    # Sink: Control Center (v0.8.5.5 - Centralized Logging)
    if "controlcenter" in _config.get("sinks", []):
        _write_to_controlcenter(rec)


def _write_to_file(rec: Dict[str, Any]):
    """Write event to JSONL file with rotation."""
    try:
        component = rec.get("component", "events")
        log_file = _get_log_file(component)

        # Rotate if needed
        max_bytes = _config.get("maxFileMB", 10) * 1024 * 1024
        if log_file.exists() and log_file.stat().st_size > max_bytes:
            _rotate_log(log_file)

        # Append to file
        line = json.dumps(rec, ensure_ascii=False, separators=(",", ":"))
        with log_file.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        # Best-effort logging; don't crash on write failures
        print(f"[BranchPy Logs] Failed to write event: {e}", file=sys.stderr)


def _write_to_controlcenter(rec: Dict[str, Any]):
    """
    Write event to Control Center via dashboard API (v0.8.5.5).
    Maps structured log events to Control Center format.

    PERFORMANCE NOTE: This makes a blocking HTTP call with 0.5s timeout.
    Only enable if Control Center dashboard is actually running!
    """
    global _controlcenter_available, _controlcenter_last_check

    # Check if explicitly enabled (not just in sinks list)
    if not _config.get("controlcenter_enabled", False):
        return

    # Fail-fast: if previously failed, don't retry for 60 seconds
    now = time.time()
    if _controlcenter_available is False:
        if now - _controlcenter_last_check < 60:
            return  # Skip silently
        # Retry after 60s
        _controlcenter_available = None

    try:
        import requests

        # Map log level to Control Center format (attempt full fidelity)
        level_map = {
            "TRACE": "trace",
            "DEBUG": "debug",
            "INFO": "info",
            "WARN": "warn",
            "ERROR": "error",
            "FATAL": "fatal",
        }

        raw_level = rec.get("level", "INFO")
        level = level_map.get(raw_level, "info")

        component = rec.get("component", "cli")

        # Determine source based on component
        source_map = {
            "cli": "cli",
            "daemon": "daemon",
            "server": "server",
            "vscode": "vscode",
            "web": "web",
        }
        source = source_map.get(component, "cli")

        # Build message
        event_name = rec.get("event", "")
        msg = rec.get("msg", "")
        message = f"{event_name}: {msg}" if msg else event_name

        # Include structured details
        details = {
            "event": event_name,
            "attrs": rec.get("attrs"),
            "source_file": rec.get("source", {}).get("file"),
            "source_line": rec.get("source", {}).get("line"),
            "ids": rec.get("ids"),
        }

        # Remove None values
        details = {k: v for k, v in details.items() if v is not None}

        # POST to dashboard API
        url = f"{_config.get('controlcenter_url', 'http://localhost:8765')}/api/v1/logs/dashboard"
        payload = {
            "level": level,
            "message": message,
            "details": details,
            "timestamp": rec.get("ts"),
            "source": source,
        }

        response = requests.post(url, json=payload, timeout=0.5)
        # Graceful degradation: if server rejects custom levels like 'trace'/'fatal', retry as 'debug'/'error'
        if response.status_code >= 400 and level in {"trace", "fatal"}:
            fallback = "debug" if level == "trace" else "error"
            payload["level"] = fallback
            response = requests.post(url, json=payload, timeout=0.5)
        response.raise_for_status()

        # Success - mark as available
        _controlcenter_available = True
        _controlcenter_last_check = now

    except Exception:
        # Mark as unavailable and record check time
        _controlcenter_available = False
        _controlcenter_last_check = now
        # Silently fail - Control Center integration is optional
        pass


def _rotate_log(log_file: Path):
    """Rotate log file (log.jsonl -> log.1.jsonl -> log.2.jsonl -> ...)."""
    try:
        rotation_count = _config.get("rotation_count", 5)

        # Remove oldest
        oldest = log_file.with_suffix(f".{rotation_count}.jsonl")
        if oldest.exists():
            oldest.unlink()

        # Shift existing backups
        for i in range(rotation_count - 1, 0, -1):
            old_file = log_file.with_suffix(f".{i}.jsonl")
            new_file = log_file.with_suffix(f".{i + 1}.jsonl")
            if old_file.exists():
                old_file.rename(new_file)

        # Rotate current to .1
        if log_file.exists():
            log_file.rename(log_file.with_suffix(".1.jsonl"))
    except Exception as e:
        print(f"[BranchPy Logs] Failed to rotate log: {e}", file=sys.stderr)


def get_ring_buffer(
    component: Optional[str] = None, level: Optional[str] = None, limit: int = 1000
) -> List[Dict[str, Any]]:
    """
    Get events from the in-memory ring buffer.

    Args:
        component: Filter by component (None = all)
        level: Filter by minimum level (None = all)
        limit: Maximum number of events to return

    Returns:
        List of event records
    """
    with _ring_lock:
        events = list(_ring_buffer)

    # Filter by component
    if component:
        events = [e for e in events if e.get("component") == component]

    # Filter by level
    if level:
        min_level = LEVELS.get(level.upper(), 0)
        events = [
            e for e in events if LEVELS.get(e.get("level", "INFO"), 0) >= min_level
        ]

    # Limit
    return events[-limit:]


def tail_file(component: str = "events", lines: int = 100) -> List[str]:
    """
    Tail the last N lines from a log file.

    Args:
        component: Component name (e.g., "cli", "daemon", "vscode")
        lines: Number of lines to return

    Returns:
        List of JSON strings (one per line)
    """
    log_file = _get_log_file(component)
    if not log_file.exists():
        return []

    try:
        with log_file.open("r", encoding="utf-8") as f:
            all_lines = f.readlines()
            return [line.rstrip() for line in all_lines[-lines:]]
    except Exception as e:
        return [f'{{"error": "Failed to read log: {e}"}}']


def find_events(
    event_name: Optional[str] = None,
    component: Optional[str] = None,
    level: Optional[str] = None,
    since_hours: Optional[int] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """
    Search for events matching criteria.

    Args:
        event_name: Filter by event name (substring match)
        component: Filter by component
        level: Filter by minimum level
        since_hours: Only include events from last N hours
        limit: Maximum results

    Returns:
        List of matching event records
    """
    # Start with ring buffer
    events = get_ring_buffer(component=component, level=level, limit=limit)

    # Filter by event name
    if event_name:
        events = [e for e in events if event_name in e.get("event", "")]

    # Filter by time
    if since_hours:
        cutoff = datetime.utcnow() - timedelta(hours=since_hours)
        cutoff_str = cutoff.isoformat()
        events = [e for e in events if e.get("ts", "") >= cutoff_str]

    return events[-limit:]


# ========================================
# Redaction
# ========================================


def redact_path(path: str) -> str:
    """Redact absolute paths to use placeholders."""
    import re

    # Try home substitution first (works on any OS)
    home = str(Path.home())
    if path.startswith(home):
        return path.replace(home, "${HOME}")

    # Windows drive letters - detect and redact regardless of current OS
    # Match pattern like "C:\Users\username\" or "C:/Users/username/"
    if len(path) > 2 and path[1] == ":":
        # Redact C:\Users\<username>\ pattern (handles both \ and / separators)
        path = re.sub(
            r"([A-Z]:[/\\]Users[/\\])[^/\\]+",
            r"\1${USER}",
            path,
            flags=re.IGNORECASE,
        )
        if not path.startswith("${"):
            return "${DRIVE}" + path[2:]

    return path


def redact_email(text: str) -> str:
    """Redact email addresses."""
    pattern = r"\b([a-zA-Z0-9._%+-]+)@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b"

    def replacer(match):
        name, domain = match.groups()
        if len(name) <= 3:
            redacted_name = "*" * len(name)
        else:
            redacted_name = name[0] + "*" * (len(name) - 1)
        return f"{redacted_name}@{domain}"

    return re.sub(pattern, replacer, text)


def redact_tokens(text: str) -> str:
    """Redact tokens and API keys."""
    # Match key=value patterns
    text = re.sub(
        r'(token|key|password|secret|api_key)\s*[=:]\s*["\']?([^"\'\s]+)["\']?',
        lambda m: f"{m.group(1)}=***",
        text,
        flags=re.IGNORECASE,
    )

    # Match Authorization headers
    text = re.sub(
        r"Authorization:\s*Bearer\s+\S+",
        "Authorization: Bearer ***",
        text,
        flags=re.IGNORECASE,
    )

    return text


def redact_record(rec: Dict[str, Any], mode: str = "standard") -> Dict[str, Any]:
    """
    Redact sensitive information from an event record.

    Args:
        rec: Event record
        mode: Redaction mode ("standard", "strict", "off")

    Returns:
        Redacted record
    """
    if mode == "off":
        return rec

    rec = rec.copy()

    # Redact paths
    if "source" in rec and "file" in rec["source"]:
        rec["source"]["file"] = os.path.basename(rec["source"]["file"])

    # Redact message
    if "msg" in rec and rec["msg"]:
        rec["msg"] = redact_email(rec["msg"])
        rec["msg"] = redact_tokens(rec["msg"])

    # Redact attributes
    if "attrs" in rec and rec["attrs"]:
        for key, value in rec["attrs"].items():
            if isinstance(value, str):
                value = redact_email(value)
                value = redact_tokens(value)
                if "/" in value or "\\" in value:
                    value = redact_path(value)
                rec["attrs"][key] = value

    # Strict mode: remove project_id
    if mode == "strict":
        if "ids" in rec and "project" in rec["ids"]:
            rec["ids"]["project"] = "***"

    return rec


# Alias for support bundle generation
def redact_obj(obj: Dict[str, Any], strict: bool = True) -> Dict[str, Any]:
    """
    Redact sensitive information from any dictionary object.
    Alias for redact_record with simplified API.
    """
    mode = "strict" if strict else "standard"
    return redact_record(obj, mode=mode)


# ========================================
# Decorator for automatic tracing
# ========================================


def traced(event_prefix: str, capture_args: bool = False, capture_result: bool = False):
    """
    Decorator to automatically trace function execution.

    Args:
        event_prefix: Prefix for event names (e.g., "analyze" -> "analyze_start", "analyze_ok")
        capture_args: Whether to capture function arguments
        capture_result: Whether to capture return value

    Example:
        @traced("analyze", capture_args=True)
        def run_analysis(project, deep=False):
            # ...
    """

    def decorator(fn):
        def wrapper(*args, **kwargs):
            t0 = time.perf_counter()

            attrs = {}
            if capture_args:
                attrs["args"] = str(args)[:200]  # Truncate to avoid huge logs
                attrs["kwargs"] = str(kwargs)[:200]

            # Use TRACE for start if trace is enabled, else INFO to avoid verbosity explosion
            start_level = (
                "TRACE"
                if LEVELS.get(_config.get("level", "INFO"), 20) <= LEVELS["TRACE"]
                else "INFO"
            )
            event(start_level, f"{event_prefix}_start", None, **attrs)

            try:
                result = fn(*args, **kwargs)
                duration_ms = int((time.perf_counter() - t0) * 1000)

                result_attrs: Dict[str, Any] = {"duration_ms": duration_ms}
                if capture_result:
                    result_attrs["result"] = str(result)[:200]

                event(start_level, f"{event_prefix}_ok", None, **result_attrs)
                return result
            except Exception as e:
                duration_ms = int((time.perf_counter() - t0) * 1000)
                # Escalate to ERROR unless current level is TRACE/DEBUG (still an error severity)
                error(
                    f"{event_prefix}_err",
                    msg=str(e),
                    duration_ms=duration_ms,
                    exc_type=type(e).__name__,
                )
                raise

        return wrapper

    return decorator


# ========================================
# Support bundle
# ========================================


def get_all_log_paths() -> Dict[str, str]:
    """
    Get paths to all BranchPy log files.

    Returns:
        Dictionary mapping log type to file path
    """
    base = _get_base_dir()
    logs_dir = _get_logs_dir()

    paths = {
        "base_dir": str(base),
        "logs_dir": str(logs_dir),
        "cli_events": str(logs_dir / "cli.jsonl"),
        "daemon_events": str(logs_dir / "daemon.jsonl"),
        "vscode_events": str(logs_dir / "vscode.jsonl"),
        "dashboard_events": str(logs_dir / "dashboard.jsonl"),
        "sae_events": str(logs_dir / "sae.jsonl"),
        "ws_daemon_log": str(base / "ws_daemon.log"),
        "ws_daemon_meta": str(base / "ws_daemon_meta.json"),
    }

    # Add project-specific logs if we have a project context
    project_id = getattr(_run, "project_id", None)
    if project_id:
        paths["project_logs"] = str(Path.cwd() / ".branchpy" / "logs")

    return paths


def create_support_blob(extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Create a support information blob.

    Args:
        extra: Additional key-value pairs to include

    Returns:
        Dictionary with system and runtime info
    """
    data = {
        "timestamp": _now(),
        "branchpy_version": _get_branchpy_version(),
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "os": sys.platform,
        "cwd": os.getcwd(),
        "user": os.environ.get("USER") or os.environ.get("USERNAME") or "unknown",
        "install_id": _get_install_id(),
        "session_id": getattr(_run, "session_id", None),
        "env_vars": sorted([k for k in os.environ.keys() if k.startswith("BRANCHPY")]),
        "log_paths": get_all_log_paths(),
    }

    if extra:
        data.update(extra)

    return data
