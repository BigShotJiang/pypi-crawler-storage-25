# branchpy/interactive_diff_adapter.py

"""
Interactive Diff Adapter — Phase 2 Workstream B

Transforms raw test/coverage data into the schema consumed by
the VS Code extension for History Lanes + Compare view.

BQS Compliance:
- Type hints (mypy-compliant)
- Dataclasses for schema validation
- Docstrings for all public functions
- Engine-agnostic design
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple


@dataclass
class FailedTest:
    """
    Represents a single failed test from interactive_diff.

    Maps to History Lanes for visual navigation.
    """

    test_id: str
    file: str  # workspace-relative path
    line_range: Tuple[int, int]  # (start_line, end_line)
    status: str  # "failed" | "error" | "timeout"
    lane_id: Optional[str]  # maps to History Lane
    ref: str  # git ref or checkpoint ID


@dataclass
class CoverageFileDelta:
    """
    Coverage delta for a single file between two refs.
    """

    lines_added: int
    lines_removed: int
    coverage_before: float  # 0–100
    coverage_after: float  # 0–100


CoverageDeltaMap = Dict[str, CoverageFileDelta]


@dataclass
class InteractiveDiffOutput:
    """
    Complete interactive_diff enrichment payload.
    """

    failed_tests: List[FailedTest]
    coverage_deltas: CoverageDeltaMap


def build_interactive_diff_output(
    *,
    failed_tests: Iterable[FailedTest],
    coverage_deltas: CoverageDeltaMap,
) -> Dict[str, object]:
    """
    Build the JSON-serializable interactive_diff output fragment.

    This adapter is the single place where we define the schema
    consumed by the VS Code extension.

    Args:
        failed_tests: Iterable of FailedTest objects
        coverage_deltas: Map of file paths to coverage deltas

    Returns:
        Dict ready to be merged into the overall interactive_diff payload.

    Example:
        >>> output = build_interactive_diff_output(
        ...     failed_tests=[FailedTest(...)],
        ...     coverage_deltas={"game.rpy": CoverageFileDelta(...)}
        ... )
        >>> assert "failed_tests" in output
    """
    return {
        "failed_tests": [
            {
                "test_id": ft.test_id,
                "file": ft.file,
                "line_range": [ft.line_range[0], ft.line_range[1]],
                "status": ft.status,
                "lane_id": ft.lane_id,
                "ref": ft.ref,
            }
            for ft in failed_tests
        ],
        "coverage_deltas": {
            file_path: {
                "lines_added": delta.lines_added,
                "lines_removed": delta.lines_removed,
                "coverage_before": delta.coverage_before,
                "coverage_after": delta.coverage_after,
            }
            for file_path, delta in coverage_deltas.items()
        },
    }


def build_failed_tests_from_json_report(
    *,
    json_tests: List[Dict[str, object]],
    lane_id: Optional[str],
    ref: str,
) -> List[FailedTest]:
    """
    Convert a pytest-style JSON test report into FailedTest objects.

    Assumes entries like:
      {
        "nodeid": "tests/test_auth.py::test_login_timeout",
        "outcome": "failed",
        "call": {"lineno": 45, "end_lineno": 52}
      }

    Args:
        json_tests: List of test result dictionaries
        lane_id: Optional History Lane ID to associate failures with
        ref: Git ref or checkpoint ID where tests ran

    Returns:
        List of FailedTest objects (only failed/error/timeout)

    Example:
        >>> tests = [{"nodeid": "test.py::test_fail", "outcome": "failed", "call": {"lineno": 10}}]
        >>> result = build_failed_tests_from_json_report(json_tests=tests, lane_id="main", ref="HEAD")
        >>> assert len(result) == 1
    """
    failed: List[FailedTest] = []
    for entry in json_tests:
        outcome = str(entry.get("outcome") or "")
        if outcome not in {"failed", "error", "timeout"}:
            continue

        nodeid = str(entry.get("nodeid") or "")
        file_path, _, test_name = nodeid.partition("::")
        call = entry.get("call") or {}
        if not isinstance(call, dict):
            call = {}
        start_line = int(call.get("lineno") or 1)
        end_line = int(call.get("end_lineno") or start_line)

        failed.append(
            FailedTest(
                test_id=test_name or nodeid,
                file=file_path,
                line_range=(start_line, end_line),
                status=outcome,
                lane_id=lane_id,
                ref=ref,
            )
        )
    return failed


def build_coverage_deltas_from_report(
    report: Dict[str, object],
) -> CoverageDeltaMap:
    """
    Convert a coverage.py-style JSON report into CoverageDeltaMap.

    For v0.9.1.4, we only care about coverage_before/after; if the
    report doesn't provide both, we treat current as "after" and
    leave "before" = after until historical coverage store is available.

    Args:
        report: Coverage report JSON structure (coverage.py format)

    Returns:
        Map of file paths to CoverageFileDelta objects

    Example coverage.py JSON format:
        {
          "files": {
            "src/auth/login.py": {
              "summary": {
                "percent_covered": 78.0,
                "covered_lines": 78,
                "missing_lines": 22,
                "num_statements": 100
              }
            }
          }
        }
    """
    files = report.get("files")
    if not isinstance(files, dict):
        return {}

    result: CoverageDeltaMap = {}
    for file_path, info in files.items():
        if not isinstance(info, dict):
            continue

        summary = info.get("summary") or {}
        if not isinstance(summary, dict):
            continue

        after = float(summary.get("percent_covered") or 0.0)
        covered = int(summary.get("covered_lines") or 0)
        missing = int(summary.get("missing_lines") or 0)

        # For now we treat baseline as equal to after until you have
        # a richer historical coverage store:
        before = after

        result[file_path] = CoverageFileDelta(
            lines_added=covered,
            lines_removed=missing,
            coverage_before=before,
            coverage_after=after,
        )

    return result
