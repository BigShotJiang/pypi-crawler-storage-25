# branchpy/report_writer.py
"""
Centralized report writing functionality for BranchPy dashboard integration.
Handles writing standardized latest_report.json files and emitting events.
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .contract import VERSION
from .emit import emit_event


def write_latest_report_atomic(obj: Dict[str, Any], path: Path) -> None:
    """
    Atomically write a report JSON to avoid partial reads.
    Uses temp file + rename for atomic operation on NTFS.
    """
    tmp_path = path.with_suffix(".tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        tmp_path.replace(path)  # Atomic on NTFS
    except Exception:
        # Cleanup temp file on error
        if tmp_path.exists():
            tmp_path.unlink()
        raise


def write_report_and_emit(
    report_dict: Dict[str, Any],
    project_root: str,
    emit: bool = True,
    out: str | None = None,
) -> None:
    """
    Write a standardized report to .branchpy/out/ with operation-specific naming and emit update event.

    Reports are named: [OPERATION]-[PROJECT]-[TIMESTAMP].json
    Also maintains latest_report.json symlink/copy for backward compatibility.

    Args:
        report_dict: The report data following the dashboard schema
        project_root: Path to the project root directory
        emit: Whether to emit JSONL event (default: True)
        out: Optional explicit output path (overrides default location)
    """
    # Generate unique report ID and metadata
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    operation = report_dict.get("kind", "unknown")
    project_name = os.path.basename(os.path.abspath(project_root))
    report_id = f"{timestamp}-{operation}"

    # Create full report payload with versioning
    payload = {
        "schema_version": "1",
        "version": VERSION,
        "report_id": report_id,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "report": report_dict,
    }

    # Determine output path
    if out:
        # Use explicit output path if provided
        report_path = Path(out)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        write_latest_report_atomic(payload, report_path)

        # For backward compatibility, also write to default location if different
        default_out_dir = Path(project_root) / ".branchpy" / "out"
        if not str(report_path).startswith(str(default_out_dir)):
            default_out_dir.mkdir(parents=True, exist_ok=True)
            report_filename = f"{operation}-{project_name}-{timestamp}.json"
            default_path = default_out_dir / report_filename
            write_latest_report_atomic(payload, default_path)
    else:
        # Default behavior: write to .branchpy/out/
        out_dir = Path(project_root) / ".branchpy" / "out"
        out_dir.mkdir(parents=True, exist_ok=True)

        # Operation-specific filename: analyze-MyProject-20251017_143022.json
        report_filename = f"{operation}-{project_name}-{timestamp}.json"
        report_path = out_dir / report_filename
        write_latest_report_atomic(payload, report_path)

    # Also write to latest_report.json for backward compatibility
    latest_dir = Path(project_root) / ".branchpy" / "out"
    latest_dir.mkdir(parents=True, exist_ok=True)
    latest_path = latest_dir / "latest_report.json"
    write_latest_report_atomic(payload, latest_path)

    # Emit normalized event if requested
    if emit:
        emit_event(
            "report.updated",
            {
                "path": str(report_path),
                "latest_path": str(latest_path),
                "project": project_root,
                "kind": operation,
                "report_id": report_id,
                "filename": report_path.name,
            },
        )


def create_media_report(
    kind: str,
    title: str,
    project_name: str,
    missing_count: int = 0,
    ok_count: int = 0,
    unused_count: int = 0,
    total_count: int = 0,
    duration_ms: int = 0,
    items: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """
    Create a standardized media report dictionary.

    Args:
        kind: Report kind (e.g., "media-missing", "media-all", "media-unused")
        title: Human-readable report title
        project_name: Name of the project
        missing_count: Number of missing files
        ok_count: Number of OK files
        unused_count: Number of unused files
        total_count: Total number of files checked
        duration_ms: Command execution duration in milliseconds
        items: List of media items with type, path, status, ref fields

    Returns:
        Dictionary following the dashboard report schema
    """
    return {
        "kind": kind,
        "title": title,
        "project": project_name,
        "summary": {
            "counts": {
                "missing": missing_count,
                "ok": ok_count,
                "unused": unused_count,
                "total": total_count,
            },
            "duration_ms": duration_ms,
        },
        "items": items or [],
    }


def create_stats_report(
    project_name: str, stats_data: Dict[str, Any], duration_ms: int = 0
) -> Dict[str, Any]:
    """
    Create a standardized stats report dictionary.

    Args:
        project_name: Name of the project
        stats_data: Statistics data from stats command
        duration_ms: Command execution duration in milliseconds

    Returns:
        Dictionary following the dashboard report schema
    """
    # Extract key metrics from stats_data
    counts = {}
    items = []

    if "files" in stats_data:
        counts["files"] = len(stats_data["files"])
    if "lines" in stats_data:
        counts["lines"] = stats_data["lines"]
    if "characters" in stats_data:
        counts["characters"] = stats_data["characters"]

    # Convert file stats to items
    if "files" in stats_data:
        for file_info in stats_data["files"]:
            items.append(
                {
                    "type": "file",
                    "path": file_info.get("path", ""),
                    "status": "ok",
                    "ref": f"{file_info.get('lines', 0)} lines",
                }
            )

    return {
        "kind": "stats",
        "title": "Project Statistics",
        "project": project_name,
        "summary": {"counts": counts, "duration_ms": duration_ms},
        "items": items,
    }


def create_analysis_report(
    project_name: str, analysis_data: Dict[str, Any], duration_ms: int = 0
) -> Dict[str, Any]:
    """
    Create a standardized analysis report dictionary.

    Args:
        project_name: Name of the project
        analysis_data: Analysis data from analyze command
        duration_ms: Command execution duration in milliseconds

    Returns:
        Dictionary following the dashboard report schema
    """
    # Extract counts and items from analysis data
    counts = {}
    items = []

    if "issues" in analysis_data:
        issues = analysis_data["issues"]
        counts = {
            "total": len(issues),
            "errors": len([i for i in issues if i.get("severity") == "error"]),
            "warnings": len([i for i in issues if i.get("severity") == "warning"]),
            "info": len([i for i in issues if i.get("severity") == "info"]),
        }

        # Convert issues to items
        for issue in issues:
            items.append(
                {
                    "type": "issue",
                    "path": issue.get("file", ""),
                    "status": issue.get("severity", "info"),
                    "ref": f"Line {issue.get('line', '?')}: {issue.get('message', '')}",
                }
            )

    return {
        "kind": "analysis",
        "title": "Code Analysis",
        "project": project_name,
        "summary": {"counts": counts, "duration_ms": duration_ms},
        "items": items,
    }


def should_emit_from_args(args) -> bool:
    """
    Determine if events should be emitted based on command arguments.

    Args:
        args: Parsed command line arguments

    Returns:
        True if events should be emitted, False otherwise
    """
    # Check if explicitly disabled
    if hasattr(args, "no_emit") and args.no_emit:
        return False

    # Check environment variable
    return os.getenv("BRANCHPY_EMIT_EVENTS", "false").lower() == "true"
