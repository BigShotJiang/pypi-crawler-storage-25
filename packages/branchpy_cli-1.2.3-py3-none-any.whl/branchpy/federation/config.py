"""
branchpy.federation.config — Federation configuration loader.

Loads federation.toml from:
1. Project directory (./branchpy_federation.toml)
2. User-wide (~/.branchpy/federation.toml)
3. Default embedded config

Config format:
```toml
[signing]
hmac_secret = "your-secret-key-here"  # Change in production!
algorithm = "sha256"

[export]
default_expiration_hours = 168  # 7 days
archive_dir = "~/.branchpy/hub/shared"

[import]
auto_trust = false  # Require manual confirmation
verify_signatures = true
```

Performance: Config load <5ms (cached).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    import tomllib  # Python 3.11+ stdlib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class FederationConfig:
    """Federation configuration."""

    # Signing config
    hmac_secret: str = "branchpy-demo-secret-change-in-production"
    algorithm: str = "sha256"

    # Export config
    default_expiration_hours: int = 168  # 7 days
    archive_dir: Path = field(
        default_factory=lambda: Path.home() / ".branchpy" / "hub" / "shared"
    )

    # Import config
    auto_trust: bool = False
    verify_signatures: bool = True

    @classmethod
    def default(cls) -> FederationConfig:
        """Get default configuration."""
        config = cls()
        config.archive_dir.mkdir(parents=True, exist_ok=True)
        return config


def _find_config_file() -> Optional[Path]:
    """
    Find federation.toml in order of precedence:
    1. ./branchpy_federation.toml (project-specific)
    2. ~/.branchpy/federation.toml (user-wide)
    3. None (use default)
    """
    # Check project directory
    project_config = Path.cwd() / "branchpy_federation.toml"
    if project_config.exists():
        return project_config

    # Check user directory
    user_config = Path.home() / ".branchpy" / "federation.toml"
    if user_config.exists():
        return user_config

    return None


def load_federation_config(config_path: Optional[Path] = None) -> FederationConfig:
    """
    Load federation configuration from TOML file.

    Args:
        config_path: Explicit config path (default: auto-detect)

    Returns:
        FederationConfig

    Raises:
        ValueError: If config is invalid
    """
    if config_path is None:
        config_path = _find_config_file()

    if config_path is None:
        # Use default config
        return FederationConfig.default()

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)

        signing_config = data.get("signing", {})
        export_config = data.get("export", {})
        import_config = data.get("import", {})

        config = FederationConfig(
            hmac_secret=signing_config.get(
                "hmac_secret", FederationConfig.default().hmac_secret
            ),
            algorithm=signing_config.get("algorithm", "sha256"),
            default_expiration_hours=export_config.get("default_expiration_hours", 168),
            archive_dir=Path(
                export_config.get("archive_dir", "~/.branchpy/hub/shared")
            ).expanduser(),
            auto_trust=import_config.get("auto_trust", False),
            verify_signatures=import_config.get("verify_signatures", True),
        )

        # Create archive directory if needed
        config.archive_dir.mkdir(parents=True, exist_ok=True)

        return config

    except Exception as e:
        raise ValueError(f"Failed to load federation config from {config_path}: {e}")


def create_default_config_file(output_path: Optional[Path] = None) -> Path:
    """
    Create default federation.toml file.

    Args:
        output_path: Output path (default: ~/.branchpy/federation.toml)

    Returns:
        Path to created config file
    """
    if output_path is None:
        output_path = Path.home() / ".branchpy" / "federation.toml"

    output_path.parent.mkdir(parents=True, exist_ok=True)

    content = """\
# BranchPy Federation Configuration
# v0.9.3 — Federation & Cloud Collaboration (local-only foundation)

[signing]
# HMAC secret for share link signing
# ⚠️ CHANGE THIS IN PRODUCTION! This is a demo-only default.
hmac_secret = "branchpy-demo-secret-change-in-production"
algorithm = "sha256"

[export]
# Default expiration for share links (hours)
default_expiration_hours = 168  # 7 days

# Directory for exported share archives
archive_dir = "~/.branchpy/hub/shared"

[import]
# Auto-trust imported resources (not recommended for production)
auto_trust = false

# Verify HMAC signatures on share links
verify_signatures = true
"""

    output_path.write_text(content, encoding="utf-8")
    return output_path
