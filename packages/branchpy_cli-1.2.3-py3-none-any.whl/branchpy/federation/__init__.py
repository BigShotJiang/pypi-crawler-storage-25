"""
branchpy.federation — Federation & share link system (local-only v0.9.3).

This module provides:
- Share link creation with HMAC-SHA256 signing
- Share link resolution and payload validation
- Local export/import workflow (no network transport)
- Cryptographic verification of share tokens

Share link format:
    branchpy-share://v1/<base64_payload>#sig=<hmac_sha256>

v0.9.3 — Federation & Cloud Collaboration (local-only foundation)
"""

from .config import FederationConfig, load_federation_config
from .importer import (
    ShareImportResult,
    create_share_link_with_export,
    export_resource_archive,
    import_share_link,
    resolve_share_link_local,
)
from .serializer import (
    deserialize_resource,
    pack_share_payload,
    serialize_resource,
    unpack_share_payload,
)
from .signed_links import (
    InvalidShareTokenError,
    ShareTokenPayload,
    create_share_token,
    parse_share_token,
    verify_share_token,
)

__all__ = [
    # Signed links
    "create_share_token",
    "verify_share_token",
    "parse_share_token",
    "ShareTokenPayload",
    "InvalidShareTokenError",
    # Serialization
    "serialize_resource",
    "deserialize_resource",
    "pack_share_payload",
    "unpack_share_payload",
    # Import/Export
    "import_share_link",
    "resolve_share_link_local",
    "export_resource_archive",
    "create_share_link_with_export",
    "ShareImportResult",
    # Config
    "FederationConfig",
    "load_federation_config",
]

__version__ = "0.9.3"
