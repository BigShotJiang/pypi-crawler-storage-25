from __future__ import annotations

import os
from pathlib import Path


def get_branchpy_base() -> Path:
    """Return the canonical BranchPy local state directory.

    Matches the TypeScript ``getBranchPyBase()`` in ``branchpyPaths.ts``:
    - Windows: ``%LOCALAPPDATA%/BranchPy``
    - macOS/Linux: ``~/.branchpy``
    """
    if os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / "BranchPy"
    return Path.home() / ".branchpy"


def get_project_root(project_arg: str | None) -> Path:
    # If user passes --project, resolve it; else use cwd
    base = Path(project_arg or ".").resolve()
    # Normalize to the folder that actually contains "game" for Ren'Py projects if needed
    # (optional: only if you already detect this elsewhere)
    return base


def get_project_patches_dir(project_arg: str | None) -> Path:
    root = get_project_root(project_arg)
    patches_dir = root / ".branchpy" / "patches"
    patches_dir.mkdir(parents=True, exist_ok=True)
    return patches_dir


def normalize_path_separators(path_str: str) -> str:
    """
    Normalize path separators to forward slashes for cross-platform consistency.

    Converts Windows-style backslashes to forward slashes and collapses
    multiple separators. Useful for path comparison and logging.

    Args:
        path_str: Path string with any separator style

    Returns:
        str: Path with forward slashes only

    Examples:
        >>> normalize_path_separators("foo\\\\bar\\\\baz.txt")
        'foo/bar/baz.txt'
        >>> normalize_path_separators("a\\\\b/c\\\\d")
        'a/b/c/d'
        >>> normalize_path_separators("path//with///many/slashes")
        'path/with/many/slashes'
    """
    # Replace backslashes with forward slashes
    normalized = path_str.replace("\\", "/")

    # Collapse multiple slashes (optional, for cleanliness)
    while "//" in normalized:
        normalized = normalized.replace("//", "/")

    return normalized
