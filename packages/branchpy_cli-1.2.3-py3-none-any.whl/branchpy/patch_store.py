# branchpy/patch_store.py
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from .config_store import ConfigStore
from .project_resolver import resolve_project

_SLUG_RE = re.compile(r"[^a-z0-9\-]+")


def _slugify(name: str) -> str:
    s = name.strip().lower().replace(" ", "-")
    s = _SLUG_RE.sub("-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or "proj"


def _short_hash(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:6]


def _looks_like_renpy_project(p: Path) -> bool:
    """Check if a path looks like a valid Ren'Py project."""
    if not p.exists():
        return False
    # Must have a 'game' directory or .rpy files
    if (p / "game").is_dir():
        return True
    if any(p.glob("*.rpy")):
        return True
    if (p / "game").exists() and any((p / "game").glob("*.rpy")):
        return True
    return False


def ensure_project_registered(project_arg: str | None) -> tuple[str, Path, bool]:
    """
    Resolve a project path; if not registered under a friendly name,
    auto-generate one and save it (only if it's a valid Ren'Py project).
    Returns: (friendly_name, abs_path, was_auto_added)
    """
    store = ConfigStore()
    cfg = store.cfg

    # 1) Resolve to a real path (handles names or paths, defaults, auto-detect)
    project_path = resolve_project(project_arg)

    # 2) If already registered, return existing name
    for name, path in cfg.projects.items():
        if Path(path).resolve() == project_path:
            return name, project_path, False

    # 3) Validate that this is actually a Ren'Py project before auto-registering
    if not _looks_like_renpy_project(project_path):
        # Don't auto-register non-Ren'Py directories
        # Return a temporary name but don't save it
        base = _slugify(project_path.name)
        temp_name = f"{base}-{_short_hash(str(project_path))}"
        return temp_name, project_path, False

    # 4) Auto-generate unique friendly name and save
    base = _slugify(project_path.name)
    candidate = f"{base}-{_short_hash(str(project_path))}"
    # ensure uniqueness
    while candidate in cfg.projects:
        candidate = f"{base}-{_short_hash(candidate + str(project_path))}"

    cfg.set_project(candidate, str(project_path))
    store.save()
    return candidate, project_path, True


def get_project_patches_dir(friendly_name: str) -> Path:
    r"""
    Compute ~/.branchpy/patches/<friendly_name>/ (or %LOCALAPPDATA%\BranchPy\patches on Win)
    and ensure it exists.
    """
    store = ConfigStore()
    base = Path(store.logs_path).parent  # sibling of logs = base app dir
    patches_root = base / "patches"
    patches_root.mkdir(parents=True, exist_ok=True)
    project_dir = patches_root / friendly_name
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir
