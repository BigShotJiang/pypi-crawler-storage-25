# branchpy/analyze/media_phase_c_contract.py
"""
Media Intelligence Phase C Adapter Contract (v1)

This module defines the stable, engine-agnostic contract for Phase C media analysis:
- Logical media tag discovery
- Usage location tracking
- Forward-compatible physical file resolution
- JSON wire format for VS Code extension integration

Version: phaseC-v1
Status: Developer Preview in v0.9.7; Enhanced in v0.9.8+

Governance:
- Module: branchpy.analyze.media_phase_c
- Policy: MEDIA_PHASE_C_CONTRACT_V1
- Compatibility: Forward-compatible with v0.9.8+ resolved_files enhancement

BQS Compliance:
- Engine Agnostic: Pure protocol design, no engine-specific logic
- Cross-Platform: Path handling via pathlib.Path, normalized strings
- Security: Immutable frozen dataclasses prevent tampering
- Performance: Lazy evaluation, no eager file I/O in contract types
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Protocol


class MediaKind(str, Enum):
    """
    Logical kind of media asset referenced by a script.

    These categories are engine-agnostic and map to common media types
    across Ren'Py, Unity, Godot, Unreal, and other supported engines.
    """

    IMAGE = "IMAGE"
    AUDIO = "AUDIO"
    VIDEO = "VIDEO"
    OTHER = "OTHER"


@dataclass(frozen=True)
class MediaUsageLocation:
    """
    One place in the project where a logical media tag is used.

    Fields:
        file: path relative to project root (forward slashes, normalized)
        line: 1-based line number
        label: optional script label / function name / scene identifier
        action: optional verb describing the usage ("show", "play", "queue", etc.)

    Examples:
        Ren'Py: MediaUsageLocation(file="game/script.rpy", line=42, label="intro", action="show")
        Unity: MediaUsageLocation(file="Assets/Scripts/DialogueManager.cs", line=156, label="StartDialogue", action="load")
        Godot: MediaUsageLocation(file="scenes/main.gd", line=23, label="_ready", action="preload")

    Immutability: frozen=True prevents accidental mutation during analysis passes.
    """

    file: str
    line: int
    label: Optional[str] = None
    action: Optional[str] = None


@dataclass
class MediaTagRecord:
    """
    Phase C record for a *logical* media tag.

    NOTE: This is intentionally engine-agnostic. The `tag` field represents
    a logical identifier that may or may not directly map to a filesystem path.

    Engine-specific examples:
        Ren'Py: tag = "eileen happy" (image name, not path)
        Unity: tag = "a1b2c3d4-guid" (asset GUID)
        Godot: tag = "res://sprites/character.png" (resource path)
        Unreal: tag = "/Game/Characters/Hero" (asset reference)

    Fields:
        tag: logical identifier (NOT necessarily a filesystem path)
        kind: media type (IMAGE, AUDIO, VIDEO, OTHER)
        exists: whether *any* backing file appears to exist (optional, v0.9.7+)
        resolved_files: list of resolved physical file paths (optional, v0.9.7; mandatory v0.9.8+)
        used_by: list of usage locations
        extra: engine-specific extension data (must be JSON-serializable)

    Backward Compatibility:
        v0.9.7: resolved_files and exists may be None
        v0.9.8+: resolved_files SHOULD be populated; exists SHOULD match resolved_files state

    Forward Compatibility:
        - New fields added to `extra` do not break the contract
        - Consumers must tolerate unknown `extra` keys
    """

    tag: str
    kind: MediaKind
    exists: Optional[bool] = None
    resolved_files: Optional[List[str]] = None
    used_by: List[MediaUsageLocation] = field(default_factory=list)
    extra: Dict[str, object] = field(default_factory=dict)


@dataclass
class MediaPhaseCResult:
    """
    Top-level result for Phase C media analysis.

    This object is what adapters return *and* what gets serialized to JSON
    for the VS Code extension. It must remain JSON-serializable.

    Fields:
        schema_version: MUST be "phaseC-v1" for this contract version
        engine_type: stable engine identifier ("renpy", "unity", "godot", "generic", etc.)
        project_root: absolute path to project root, normalized to forward slashes
        files: list of discovered media tag records
        warnings: list of human-readable warning messages

    Backward Compatibility Rules:
        - schema_version MUST be "phaseC-v1" for this contract
        - resolved_files may be None/missing in v0.9.7 (extension falls back to heuristics)
        - In v0.9.8+, resolved_files SHOULD be populated where possible
        - New fields can be added to `extra` without breaking consumers

    JSON Export:
        Use `to_json_dict()` to convert to a plain dict suitable for json.dump().
        The output format is the Phase C wire schema consumed by VS Code.

    Governance:
        - All Phase C results must emit a governance event with:
          * governance_id: generated correlation ID
          * module: "branchpy.analyze.media_phase_c"
          * event_type: "phase_c_analysis_complete"
          * metadata: {engine_type, project_root, file_count, warning_count}
    """

    schema_version: str
    engine_type: str
    project_root: str
    files: List[MediaTagRecord] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_json_dict(self) -> Dict[str, object]:
        """
        Convert to a plain dict suitable for JSON dumping.

        This is the canonical Phase C wire format consumed by:
        - VS Code extension (Media Validation panel)
        - CLI export commands
        - Future SDK consumers
        - Telemetry/governance event payloads

        Returns:
            dict matching the Phase C JSON schema (see docs for full spec)

        Example output:
            {
                "schema_version": "phaseC-v1",
                "engine_type": "renpy",
                "project_root": "C:/projects/game",
                "files": [
                    {
                        "tag": "eileen happy",
                        "kind": "IMAGE",
                        "exists": True,
                        "resolved_files": ["game/images/eileen_happy.png"],
                        "used_by": [{"file": "game/script.rpy", "line": 42, "label": "intro", "action": "show"}],
                        "extra": {"renpy_image_name": "eileen happy"}
                    }
                ],
                "warnings": ["Phase C: 3 tags could not be resolved to physical files."]
            }
        """
        return {
            "schema_version": self.schema_version,
            "engine_type": self.engine_type,
            "project_root": self.project_root,
            "files": [
                {
                    "tag": f.tag,
                    "kind": f.kind.value,
                    "exists": f.exists,
                    "resolved_files": f.resolved_files,
                    "used_by": [
                        {
                            "file": u.file,
                            "line": u.line,
                            "label": u.label,
                            "action": u.action,
                        }
                        for u in f.used_by
                    ],
                    "extra": f.extra or {},
                }
                for f in self.files
            ],
            "warnings": list(self.warnings),
        }


class MediaPhaseCAdapter(Protocol):
    """
    Adapter contract for engine-specific Phase C media analysis.

    Implementations should be pure and side-effect-free: given a project root,
    they inspect files and return a MediaPhaseCResult.

    Design Principles:
        - Engine Agnostic: Adapters hide engine-specific details behind this protocol
        - Stateless: No instance state; all inputs via method parameters
        - Pure: No side effects (file writes, network calls, etc.)
        - Fast Detection: supports_project() should be O(1) or O(log n) file checks

    Adapter IDs:
        - Must be stable and unique across all adapters
        - Format: "{engine}-phasec-{version}" (e.g., "renpy-phasec-v1")
        - Used for telemetry, governance tracking, and adapter registry lookups

    Implementation Guidance:
        1. Check for engine markers in supports_project() (config files, directory structure)
        2. Scan project files to discover logical tags and usage locations
        3. (v0.9.8+) Resolve tags to physical files using engine-specific resolution rules
        4. Return MediaPhaseCResult with schema_version="phaseC-v1"
        5. Populate warnings for any issues encountered (missing files, ambiguous tags, etc.)

    Examples:
        - RenpyPhaseCAdapter: scans .rpy files for image/audio statements
        - UnityPhaseCAdapter: parses .unity scenes and .cs scripts for asset references
        - GodotPhaseCAdapter: scans .tscn and .gd files for preload() calls
        - GenericPhaseCAdapter: regex-based fallback for unknown engines
    """

    @property
    def adapter_id(self) -> str:
        """
        Stable adapter identifier.

        Format: "{engine}-phasec-{version}"
        Examples: "renpy-phasec-v1", "unity-phasec-v1", "godot-phasec-v1"

        This ID is used for:
        - Telemetry event tagging (adapter_id field)
        - Governance policy routing
        - Adapter registry lookups
        - User-facing diagnostics and warnings
        """
        ...

    def supports_project(self, project_root: Path) -> bool:
        """
        Return True if this adapter can handle the given project.

        Implementation should perform minimal file system checks to avoid
        unnecessary overhead during adapter discovery. Typical checks:

        Ren'Py:
            - (project_root / "game").is_dir()
            - any .rpy files in game/

        Unity:
            - (project_root / "Assets").is_dir()
            - (project_root / "ProjectSettings").is_dir()

        Godot:
            - (project_root / "project.godot").is_file()

        Unreal:
            - any .uproject file in project_root

        Generic:
            - always returns True (fallback adapter)

        Args:
            project_root: absolute path to project root directory

        Returns:
            True if this adapter can analyze the project; False otherwise

        Performance: Should complete in <10ms for typical projects.
        """
        ...

    def collect_phase_c(self, project_root: Path) -> MediaPhaseCResult:
        """
        Perform Phase C media analysis for the given project root.

        Requirements:
            - MUST set schema_version = "phaseC-v1"
            - engine_type must be one of the known engines
              (e.g. 'renpy', 'unity', 'godot', 'unreal', 'generic')
            - project_root must be a normalized string path (forward slashes)
            - MUST NOT write files or make network calls (pure analysis)

        Version Compatibility:
            v0.9.7 (Developer Preview):
                - resolved_files may be None
                - exists may be None
                - Focus on tag discovery and usage tracking

            v0.9.8+ (Enhanced):
                - resolved_files SHOULD be populated where feasible
                - exists SHOULD be consistent with resolved_files state
                - Full physical file resolution for all engines

        Error Handling:
            - Do NOT raise exceptions for missing files or parse errors
            - Add warnings to MediaPhaseCResult.warnings instead
            - Return partial results on best-effort basis

        Performance Expectations:
            - Small projects (<1000 files): <500ms
            - Medium projects (1000-5000 files): <2s
            - Large projects (>5000 files): <10s

        Telemetry:
            Adapters SHOULD emit governance events:
                - governance_id: unique correlation ID for this analysis
                - module: "branchpy.analyze.media_phase_c.{engine}"
                - event_type: "adapter_collect_complete"
                - metadata: {adapter_id, file_count, warning_count, duration_ms}

        Args:
            project_root: absolute path to project root directory

        Returns:
            MediaPhaseCResult with all discovered tags, usages, and optional resolutions

        Raises:
            Should NOT raise exceptions; return partial results with warnings instead
        """
        ...


def create_empty_phase_c_result(
    engine_type: str, project_root: Path
) -> MediaPhaseCResult:
    """
    Convenience helper for adapters: construct an empty Phase C result.

    Use this as a starting point for building up a MediaPhaseCResult
    during adapter analysis. Ensures correct schema_version and
    normalized project_root path.

    Args:
        engine_type: stable engine identifier ("renpy", "unity", etc.)
        project_root: absolute path to project root

    Returns:
        Empty MediaPhaseCResult with schema_version="phaseC-v1"

    Example:
        >>> result = create_empty_phase_c_result("renpy", Path("/path/to/game"))
        >>> result.files.append(MediaTagRecord(...))
        >>> return result
    """
    return MediaPhaseCResult(
        schema_version="phaseC-v1",
        engine_type=engine_type,
        project_root=str(project_root).replace(
            "\\", "/"
        ),  # Normalize to forward slashes
        files=[],
        warnings=[],
    )
