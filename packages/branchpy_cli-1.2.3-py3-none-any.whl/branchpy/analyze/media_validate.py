"""BranchPy Media Intelligence — Validation Module (v0.9.0.2+)

File existence validation for media references.
Adds 'validation' field to MediaRef with exists: bool | None.

WS-M1: Enhanced with remote environment support (WSL, SSH, containers, CI).
WS-M1.4: Added SLO & latency tracking.

Ticket: VAL-231 (PRODUCTION IMPLEMENTATION)
Phase D feature + Axis 5 (Remote) support.
Governance: AXIS5-V0.9.2-REMOTE-BQS (WS-M1 / WS-M1.4)
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterable, List, Optional, Tuple

if TYPE_CHECKING:
    from branchpy.media.remote_context import RemoteMediaContext


# ============================================================================
# VALIDATION CONFIG
# ============================================================================


@dataclass
class ValidationConfig:
    """
    Configuration for media validation.

    Attributes:
        enabled: Whether to run validation at all
        check_existence: Whether to check if files exist on disk
        base_paths: List of base directories to search for media files (None = use project root only)
        smart_fallback: Try common folders (images/, game/, assets/) automatically

    Example:
        >>> config = ValidationConfig(
        ...     enabled=True,
        ...     check_existence=True,
        ...     base_paths=["game", "images"],
        ...     smart_fallback=True
        ... )
    """

    enabled: bool = True
    check_existence: bool = True
    base_paths: Optional[List[str]] = None
    smart_fallback: bool = True


# ============================================================================
# VALIDATION LOGIC
# ============================================================================

FALLBACK_DIRS = ["images", "game", "assets"]


def _try_paths(
    project_root: Path, rel: str, base_paths: Optional[List[str]], smart: bool
) -> Tuple[bool, List[str]]:
    """
    Try to find a media file by checking multiple paths.

    Args:
        project_root: Project root directory
        rel: Relative path to media file
        base_paths: List of base directories to try (None = project root only)
        smart: Enable smart fallback to common folders

    Returns:
        Tuple of (found: bool, tried_paths: List[str])
    """
    tried = []

    # Try project root + configured base paths
    roots = [project_root]
    if base_paths:
        roots.extend([project_root / b for b in base_paths])

    for root in roots:
        p = root / rel
        tried.append(str(p))
        if p.exists():
            return True, tried

    # Smart fallback: try common folders
    if smart:
        for fb in FALLBACK_DIRS:
            p = project_root / fb / rel
            tried.append(str(p))
            if p.exists():
                return True, tried

    return False, tried


def _fire_and_forget_event(coro):
    """
    Fire-and-forget helper for async telemetry events in sync functions.

    Safely schedules async events without awaiting, avoiding RuntimeWarning.
    """
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(coro)
    except RuntimeError:
        # No running loop - close coroutine to prevent "was never awaited" warning
        try:
            coro.close()
        except Exception:
            pass


def validate_media_refs(
    refs: Iterable[Dict[str, Any]],
    project_root: Path,
    cfg: ValidationConfig,
    media_ctx: Optional["RemoteMediaContext"] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Validate media references by checking file existence.

    WS-M1.2: Now uses remote-aware path normalization for all media paths.
    WS-M1.4: Added latency tracking and SLO compliance detection.

    All paths are normalized to canonical POSIX format before storage and comparison.

    Adds 'validation' field to each ref with:
        - exists: bool | None (True if found, False if missing, None if no path)
        - path_tried: List[str] (paths searched, in normalized format)

    Args:
        refs: Iterable of MediaRef dicts
        project_root: Project root directory
        cfg: Validation configuration
        media_ctx: Optional remote media context (WS-M1)

    Returns:
        Tuple of (updated_refs: List[dict], summary: dict)
        Summary contains:
            - checked: int (files checked)
            - exists: int (files found)
            - missing: int (files missing)
            - duration_ms: float (total validation time, WS-M1.4)
            - slow_total: bool (exceeded max_total_ms, WS-M1.4)
            - warn_total: bool (exceeded warn_total_ms, WS-M1.4)

    Example:
        >>> refs = [{"resolved_path": "bg.png"}, {"template_path": "{name}.png"}]
        >>> updated, summary = validate_media_refs(refs, Path("/project"), cfg)
        >>> summary
        {"checked": 1, "exists": 0, "missing": 1, "duration_ms": 15.5, "slow_total": False, "warn_total": False}

        >>> # WS-M1.2: Remote mode with path normalization
        >>> from branchpy.media.remote_context import RemoteMediaContext
        >>> from branchpy.remote import detect_environment
        >>> ctx = detect_environment()
        >>> media_ctx = RemoteMediaContext(remote=ctx)
        >>> updated, summary = validate_media_refs(refs, Path("/mnt/c/project"), cfg, media_ctx)
        >>> # All paths normalized: /mnt/c/... → C:/...
    """
    # WS-M1.4: Start timing
    start_total = time.perf_counter()

    # WS-M1.5: Emit MediaValidationStartedEvent
    try:
        from branchpy.media.remote_context import extract_remote_telemetry_fields
        from branchpy.telemetry.validation_events import emit_validation_event

        # Count expected files for started event (lightweight check)
        num_expected = sum(1 for r in refs if r.get("resolved_path"))

        _fire_and_forget_event(
            emit_validation_event(
                event_type="validation.start",
                module="media",
                target_path=str(project_root),
                metadata={
                    "num_expected_files": num_expected,
                    "cache_enabled": False,  # Media has no cache (unlike image validation)
                    "smart_fallback": cfg.smart_fallback,
                    **extract_remote_telemetry_fields(media_ctx),
                },
            )
        )
    except Exception:
        # Non-blocking: telemetry emission must never break validation
        pass

    if not cfg.enabled or not cfg.check_existence:
        duration_total_ms = (time.perf_counter() - start_total) * 1000
        return list(refs), {
            "checked": 0,
            "exists": 0,
            "missing": 0,
            "duration_ms": duration_total_ms,
            "slow_total": False,
            "warn_total": False,
        }

    # WS-M1.2: Extract remote context for path normalization
    # WS-M1.4: Get SLO thresholds
    from branchpy.media.media_slo import (
        get_media_slo,
        is_slow_file,
        is_slow_total,
        is_warn_file,
        is_warn_total,
    )
    from branchpy.media.remote_paths import normalize_media_path

    slo = get_media_slo()

    remote = media_ctx.remote if media_ctx else None

    # Normalize project root
    normalized_root = Path(normalize_media_path(str(project_root), remote))

    updated, checked, exists, missing = [], 0, 0, 0

    for r in refs:
        rr = dict(r)
        rp = rr.get("resolved_path")
        rr.setdefault("validation", {})

        if rp:
            checked += 1

            # WS-M1.5: Start per-file timing
            start_file = time.perf_counter()

            # WS-M1.2: For validation, use the resolved_path directly
            # (it's already relative to project_root or base_paths)
            # Only normalize the root and tried paths for storage
            found, tried = _try_paths(
                normalized_root,
                rp,  # Keep as-is - it's relative
                cfg.base_paths or [],
                cfg.smart_fallback,
            )

            # WS-M1.5: Calculate per-file duration
            duration_file_ms = (time.perf_counter() - start_file) * 1000

            rr["validation"]["exists"] = bool(found)
            # WS-M1.2: Normalize the tried paths for canonical storage
            rr["validation"]["path_tried"] = [
                normalize_media_path(str(p), remote) for p in tried
            ]

            # WS-M1.5: Emit per-file validation event
            try:
                from branchpy.media.remote_context import (
                    extract_remote_telemetry_fields,
                )
                from branchpy.telemetry.validation_events import emit_validation_event

                _fire_and_forget_event(
                    emit_validation_event(
                        event_type="validation.complete",  # Per-file is also "complete"
                        module="media",
                        target_path=str(normalized_root / rp),
                        issues_found=0 if found else 1,
                        duration_ms=duration_file_ms,
                        metadata={
                            "file_path": rp,
                            "exists": found,
                            "slow_file": is_slow_file(duration_file_ms, slo),
                            "warn_file": is_warn_file(duration_file_ms, slo),
                            "paths_tried": len(tried),
                            **extract_remote_telemetry_fields(media_ctx),
                        },
                    )
                )
            except Exception:
                # Non-blocking: telemetry emission must never break validation
                pass

            if found:
                exists += 1
            else:
                missing += 1
        else:
            # No resolved_path (likely template/dynamic) - mark as None
            rr["validation"]["exists"] = None

        updated.append(rr)

    # WS-M1.4: Calculate total duration and SLO compliance
    duration_total_ms = (time.perf_counter() - start_total) * 1000
    slow = is_slow_total(duration_total_ms, slo)
    warn = is_warn_total(duration_total_ms, slo)

    # WS-M1.5: Emit MediaValidationCompletedEvent
    try:
        from branchpy.media.remote_context import extract_remote_telemetry_fields
        from branchpy.telemetry.validation_events import emit_validation_event

        _fire_and_forget_event(
            emit_validation_event(
                event_type="validation.complete",
                module="media",
                target_path=str(project_root),
                issues_found=missing,
                duration_ms=duration_total_ms,
                metadata={
                    "num_files": checked,
                    "exists": exists,
                    "missing": missing,
                    "slow_total": slow,
                    "warn_total": warn,
                    **extract_remote_telemetry_fields(media_ctx),
                },
            )
        )
    except Exception:
        # Non-blocking: telemetry emission must never break validation
        pass

    return updated, {
        "checked": checked,
        "exists": exists,
        "missing": missing,
        "duration_ms": duration_total_ms,
        "slow_total": slow,
        "warn_total": warn,
    }
