"""
PFI Inference for Media Intelligence — Wrapper Function Detection

Ticket: PFI-201
Module: branchpy.analyze.pfi.stat_effect_analyzer
Version: v0.9.0.2

This module extends the existing PFI (Program Flow Inference) system to propagate
MEDIA_* effects through the call graph, enabling detection of media references
hidden behind wrapper functions.

Example:
    # Game code
    def show_char(name, emotion="neutral"):
        renpy.show(f"characters/{name}_{emotion}.png")

    # Callsite
    show_char("alice", "happy")  # ← Emits MediaRef with via_function="show_char"

TODOs (Implementation):
    - [ ] Add MEDIA_* effect enums to StatEffect
    - [ ] Map Ren'Py API calls to MEDIA_* effects
    - [ ] Emit MediaRef at callsites with via_function and confidence="inferred"
    - [ ] Deduplicate inferred refs against exact/dynamic
    - [ ] Add golden test: tests/golden/media/pfi/wrappers.json
"""

from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional, Set

from branchpy.media_analyzer import MediaRef

# ============================================================================
# MEDIA EFFECTS (Extension to existing StatEffect system)
# ============================================================================


class MediaEffect(Enum):
    """Media-related side effects for PFI propagation."""

    MEDIA_SHOW = auto()  # renpy.show(...), scene ..., show ...
    MEDIA_PLAY = auto()  # renpy.music.play(...), play music/sound/voice
    MEDIA_STOP = auto()  # renpy.music.stop(...), stop music/sound
    MEDIA_HIDE = auto()  # hide ..., renpy.hide(...)
    MEDIA_DEFINE = auto()  # define ..., image ... = ...
    MEDIA_LOAD = auto()  # Resources.Load (Unity), preload (Godot)
    MEDIA_ASSIGN = auto()  # sprite = ..., texture = ...


# TODO: Integrate these into existing branchpy/analyze/pfi/stat_effect_analyzer.py
# Current StatEffect enums: UI_SHOW, UI_HIDE, VAR_WRITE, VAR_READ, JUMP, CALL, etc.
# Add MEDIA_* to the same enum class.


# ============================================================================
# MEDIA EFFECT MAPPER (Ren'Py API → MEDIA_*)
# ============================================================================

RENPY_API_TO_MEDIA_EFFECT = {
    # Scene/Show statements (images)
    "renpy.show": MediaEffect.MEDIA_SHOW,
    "renpy.scene": MediaEffect.MEDIA_SHOW,
    "renpy.hide": MediaEffect.MEDIA_HIDE,
    # Audio API
    "renpy.music.play": MediaEffect.MEDIA_PLAY,
    "renpy.music.queue": MediaEffect.MEDIA_PLAY,
    "renpy.music.stop": MediaEffect.MEDIA_STOP,
    "renpy.sound.play": MediaEffect.MEDIA_PLAY,
    "renpy.sound.queue": MediaEffect.MEDIA_PLAY,
    "renpy.sound.stop": MediaEffect.MEDIA_STOP,
    "renpy.audio.play": MediaEffect.MEDIA_PLAY,
    # Video API
    "renpy.movie_cutscene": MediaEffect.MEDIA_PLAY,
    # Image definitions
    "renpy.image": MediaEffect.MEDIA_DEFINE,
}


# ============================================================================
# CALLSITE INFERENCE LOGIC
# ============================================================================


@dataclass
class InferredMediaRef:
    """
    Minimal representation of an inferred MediaRef.
    Full MediaRef will be constructed by media_renpy.py extractor.
    """

    via_function: str
    confidence: str = "inferred"
    target: Optional[str] = None  # Best-guess from args (if literal)
    source_file: Optional[str] = None
    source_line: Optional[int] = None

    # Populated by downstream extractor
    kind: Optional[str] = None  # IMAGE, AUDIO, VIDEO (inferred from context)
    action: Optional[str] = None  # "show", "play", etc.


def infer_media_from_callsite(
    function_name: str,
    args: List[str],
    kwargs: dict,
    effects: Set[MediaEffect],
    source_file: str,
    source_line: int,
) -> Optional[InferredMediaRef]:
    """
    Infer a MediaRef when a callsite invokes a function with MEDIA_* effects.

    Args:
        function_name: Name of the called function (e.g., "show_char")
        args: Positional arguments (as strings, may be literals or variable names)
        kwargs: Keyword arguments
        effects: Set of MediaEffect enums assigned to the function
        source_file: Path to the file containing the callsite
        source_line: Line number of the callsite

    Returns:
        InferredMediaRef if media effect detected, else None

    Example:
        >>> infer_media_from_callsite(
        ...     "show_char", ["alice", "happy"], {},
        ...     {MediaEffect.MEDIA_SHOW}, "script.rpy", 42
        ... )
        InferredMediaRef(via_function="show_char", target="alice", ...)
    """
    # TODO: Implementation steps
    # 1. Check if any MEDIA_* in effects
    if not any(e in effects for e in MediaEffect):
        return None

    # 2. Extract best-guess target from args
    target = None
    if args and _is_literal(args[0]):
        target = args[0].strip("\"'")

    # 3. Map effect to kind/action
    kind = None
    action = None
    if MediaEffect.MEDIA_SHOW in effects:
        kind = "IMAGE"
        action = "show"
    elif MediaEffect.MEDIA_PLAY in effects:
        # Ambiguous: could be AUDIO or VIDEO
        # Use extension heuristic if target available
        if target and target.endswith((".ogg", ".mp3", ".wav")):
            kind = "AUDIO"
        elif target and target.endswith((".mp4", ".webm", ".ogv")):
            kind = "VIDEO"
        else:
            kind = "AUDIO"  # Default assumption
        action = "play"

    # 4. Construct InferredMediaRef
    return InferredMediaRef(
        via_function=function_name,
        confidence="inferred",
        target=target,
        source_file=source_file,
        source_line=source_line,
        kind=kind,
        action=action,
    )


def _is_literal(arg: str) -> bool:
    """Check if argument is a string literal (quoted)."""
    return (arg.startswith('"') and arg.endswith('"')) or (
        arg.startswith("'") and arg.endswith("'")
    )


# ============================================================================
# DEDUPLICATION LOGIC (exact > dynamic > inferred)
# ============================================================================


def deduplicate_media_refs(
    exact_refs: List["MediaRef"],
    dynamic_refs: List["MediaRef"],
    inferred_refs: List[InferredMediaRef],
) -> List["MediaRef"]:
    """
    Merge and deduplicate media refs, preferring higher confidence.

    Rules:
        1. Exact overrides dynamic and inferred (same target + line)
        2. Dynamic overrides inferred (same template + line)
        3. Inferred kept only if no exact/dynamic at same location

    Args:
        exact_refs: MediaRefs with confidence="exact"
        dynamic_refs: MediaRefs with confidence="dynamic"
        inferred_refs: InferredMediaRef objects (converted to MediaRef)

    Returns:
        Deduplicated list of MediaRef objects

    TODO: Implement deduplication key logic (target + source_line)
    """
    # Placeholder: Convert InferredMediaRef → MediaRef
    # Full implementation requires media_analyzer.MediaRef import
    pass


# ============================================================================
# INTEGRATION POINTS
# ============================================================================

"""
Integration with existing PFI system:

1. In `stat_effect_analyzer.py`:
   - Extend `StatEffect` enum with MEDIA_* values
   - Add MEDIA_* detection in `analyze_function()` when encountering Ren'Py API calls
   - Store MEDIA_* effects in function signature metadata

2. In `call_graph.py`:
   - Ensure callee → caller edges are exposed
   - Propagate MEDIA_* effects from callee to callsite

3. In `media_renpy.py` (RenpyMediaExtractor):
   - After extracting exact/dynamic refs, query PFI for callsites with MEDIA_* effects
   - Call `infer_media_from_callsite()` for each callsite
   - Convert InferredMediaRef → MediaRef
   - Pass to `deduplicate_media_refs()`

4. In `renpy_engine.py`:
   - Emit governance event: `media.infer.start`
   - Call PFI inference after Phase 4.5 media extraction
   - Emit governance event: `media.infer.done` with `inferred_count`

Example workflow:
    # Step 1: PFI detects wrapper function
    def show_char(name):
        renpy.show(f"char_{name}.png")  # ← Marked with MEDIA_SHOW effect
    
    # Step 2: At callsite, PFI emits inference
    label start:
        show_char("alice")  # ← Callsite analyzed; emits InferredMediaRef
    
    # Step 3: Deduplication
    # If same line also has `show character alice`, prefer exact over inferred
"""


# ============================================================================
# TESTING STRATEGY
# ============================================================================

"""
Golden test fixture: tests/golden/media/pfi/wrappers.json

Input (wrappers.rpy):
    ```renpy
    # Wrapper function
    init python:
        def show_bg(location):
            renpy.scene(f"backgrounds/bg_{location}.png")
        
        def play_bgm(track):
            renpy.music.play(f"audio/music/{track}.ogg", channel="music")
    
    # Callsites
    label cafe:
        $ show_bg("cafe")  # ← Should emit inferred MediaRef
        $ play_bgm("calm_afternoon")
    ```

Expected output (wrappers.json):
    ```json
    {
      "media": {
        "by_label": {
          "cafe": [
            {
              "id": "media_cafe_2_inferred_0",
              "engine": "renpy",
              "kind": "IMAGE",
              "action": "scene",
              "target": null,
              "resolved_path": null,
              "template_path": "backgrounds/bg_{location}.png",
              "confidence": "inferred",
              "via_function": "show_bg",
              "source_file": "wrappers.rpy",
              "source_line": 10,
              "label": "cafe"
            },
            {
              "id": "media_cafe_3_inferred_1",
              "engine": "renpy",
              "kind": "AUDIO",
              "action": "play",
              "channel": "music",
              "target": null,
              "template_path": "audio/music/{track}.ogg",
              "confidence": "inferred",
              "via_function": "play_bgm",
              "source_file": "wrappers.rpy",
              "source_line": 11,
              "label": "cafe"
            }
          ]
        }
      }
    }
    ```

Test cases:
    1. Wrapper with literal arg → target populated
    2. Wrapper with variable arg → target=null, template_path populated
    3. Nested wrappers (show_char → show_bg → renpy.scene)
    4. Deduplication: callsite has both explicit `scene bg_cafe.png` and `show_bg("cafe")`
       → Prefer explicit (exact) over inferred
"""


# ============================================================================
# GOVERNANCE EVENTS
# ============================================================================

"""
Event schema (emitted in renpy_engine.py):

media.infer.start:
    {
      "event": "media.infer.start",
      "media_intelligence_version": "v0.9.0.2",
      "timestamp": "2025-11-10T14:23:01.123Z",
      "payload": {
        "pfi_enabled": true,
        "call_graph_nodes": 47
      }
    }

media.infer.done:
    {
      "event": "media.infer.done",
      "media_intelligence_version": "v0.9.0.2",
      "timestamp": "2025-11-10T14:23:01.456Z",
      "payload": {
        "inferred_count": 12,
        "callsites_analyzed": 35,
        "elapsed_ms": 333
      }
    }
"""


# ============================================================================
# CONFIGURATION
# ============================================================================

"""
No new config needed—PFI inference enabled automatically when:
    - options.get('enable_media', True)
    - PFI already enabled (from Wave 4)

To disable:
    CLI: --no-media-inference (TODO: add flag)
    TOML: [media] inference_enabled = false (TODO: add key)
"""


if __name__ == "__main__":
    # TODO: Add unit tests
    # Example test
    result = infer_media_from_callsite(
        function_name="show_char",
        args=['"alice"', '"happy"'],
        kwargs={},
        effects={MediaEffect.MEDIA_SHOW},
        source_file="script.rpy",
        source_line=42,
    )
    print(result)
    # Expected: InferredMediaRef(via_function="show_char", target="alice", ...)
