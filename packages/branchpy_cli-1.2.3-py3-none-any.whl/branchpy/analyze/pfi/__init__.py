"""
BranchPy PFI (Propagated Flow Inference) Module

Infers media references through call graph analysis.
"""

from .media_inference import MEDIA_WRAPPERS, infer_media_from_wrapper

__all__ = ["infer_media_from_wrapper", "MEDIA_WRAPPERS"]
