"""
BranchPy PFI Media Inference (v0.9.0.2)

Infers media references through call graph wrapper detection.
Assigns confidence scores and via_function tracking.
"""

import re
from typing import Any, Dict, List, Optional, Tuple

# ============================================================================
# MEDIA WRAPPER PATTERNS
# ============================================================================

# Common Ren'Py wrapper patterns with (action, confidence, reason_template)
MEDIA_WRAPPERS: Dict[str, Tuple[str, float, str]] = {
    # Direct Ren'Py API calls (high confidence)
    r"\brenpy\.show\(": ("show", 1.0, "literal_api=renpy.show"),
    r"\brenpy\.hide\(": ("hide", 1.0, "literal_api=renpy.hide"),
    r"\brenpy\.music\.play\(": ("play", 1.0, "literal_api=renpy.music.play"),
    r"\brenpy\.music\.stop\(": ("stop", 1.0, "literal_api=renpy.music.stop"),
    r"\brenpy\.sound\.play\(": ("play", 1.0, "literal_api=renpy.sound.play"),
    # Common wrapper function names (medium confidence)
    r"\bshow_character\(": ("show", 0.75, "pfi_wrapper=show_character"),
    r"\bdisplay_sprite\(": ("show", 0.70, "pfi_wrapper=display_sprite"),
    r"\bplay_music\(": ("play", 0.75, "pfi_wrapper=play_music"),
    r"\bplay_sound\(": ("play", 0.75, "pfi_wrapper=play_sound"),
    r"\bshow_bg\(": ("show", 0.70, "pfi_wrapper=show_bg"),
    r"\bshow_background\(": ("show", 0.70, "pfi_wrapper=show_background"),
    # Image loading patterns (medium-low confidence)
    r"\bImage\(": ("load", 0.60, "pfi_wrapper=Image"),
    r"\bim\.": ("show", 0.55, "pfi_wrapper=im_composite"),
}


# ============================================================================
# INFERENCE FUNCTIONS
# ============================================================================


def infer_media_from_wrapper(
    function_name: str, source_code: str, callsite_args: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Infer media references from a wrapper function.

    Args:
        function_name: Name of the wrapper function being analyzed
        source_code: Source code of the function body
        callsite_args: Optional list of argument values from callsite

    Returns:
        List of inferred MediaRef dicts with via_function, confidence, confidence_reason

    Example:
        >>> infer_media_from_wrapper("show_character", "renpy.show('sprite.png')")
        [{'action': 'show', 'via_function': 'show_character', 'confidence': 'inferred',
          'confidence_reason': 'literal_api=renpy.show', 'confidence_score': 1.0}]
    """
    results = []

    for pattern, (action, score, reason) in MEDIA_WRAPPERS.items():
        if re.search(pattern, source_code):
            # Extract literal strings from the matched context
            # Simple heuristic: look for quoted strings near the pattern
            context_start = max(0, source_code.find(pattern) - 50)
            context_end = min(len(source_code), source_code.find(pattern) + 100)
            context = source_code[context_start:context_end]

            # Find quoted strings (simplified - doesn't handle escapes)
            literals = re.findall(r'["\']([^"\']+)["\']', context)

            for lit in literals:
                # Filter likely media paths (has extension)
                if any(
                    lit.endswith(ext)
                    for ext in [
                        ".png",
                        ".jpg",
                        ".webp",
                        ".ogg",
                        ".mp3",
                        ".wav",
                        ".webm",
                        ".mp4",
                    ]
                ):
                    results.append(
                        {
                            "action": action,
                            "via_function": function_name,
                            "confidence": "inferred",
                            "confidence_reason": reason,
                            "confidence_score": score,
                            "resolved_path": lit,
                            "template_path": None,
                            "variables": [],
                        }
                    )

    return results


def score_confidence(
    action: str, source_pattern: str, has_literal_path: bool, has_variables: bool
) -> Tuple[str, float, str]:
    """
    Score confidence level for a media reference.

    Args:
        action: Media action (show, play, etc.)
        source_pattern: Pattern that matched (e.g., "renpy.show(")
        has_literal_path: Whether path is a literal string
        has_variables: Whether path contains variables/f-strings

    Returns:
        Tuple of (confidence: str, score: float, reason: str)

    Example:
        >>> score_confidence('show', 'renpy.show(', True, False)
        ('exact', 1.0, 'literal_string')
    """
    if has_literal_path and not has_variables:
        return ("exact", 1.0, "literal_string")

    if has_variables:
        return ("dynamic", 0.7, f"fstring_vars={has_variables}")

    # Inferred from wrapper
    if source_pattern in MEDIA_WRAPPERS:
        _, score, reason = MEDIA_WRAPPERS[source_pattern]
        return ("inferred", score, reason)

    # Default fallback
    return ("inferred", 0.4, "unknown_pattern")


def extract_variables_from_fstring(template: str) -> List[str]:
    """
    Extract variable names from f-string or .format() template.

    Args:
        template: Template string (e.g., "bg_{location}.png")

    Returns:
        List of variable names

    Example:
        >>> extract_variables_from_fstring("char_{name}_{mood}.png")
        ['name', 'mood']
    """
    # Match {variable_name} patterns
    return re.findall(r"\{(\w+)\}", template)


# ============================================================================
# INTEGRATION HOOKS
# ============================================================================


def enrich_media_ref_with_pfi(
    ref: Dict[str, Any], wrapper_name: str, wrapper_source: str
) -> Dict[str, Any]:
    """
    Enrich a media reference with PFI metadata.

    Args:
        ref: MediaRef dict from extractor
        wrapper_name: Name of wrapper function
        wrapper_source: Source code of wrapper

    Returns:
        Enhanced MediaRef dict with via_function, confidence_reason, confidence_score
    """
    # Detect if this ref came from a wrapper
    for pattern, (action, score, reason) in MEDIA_WRAPPERS.items():
        if re.search(pattern, wrapper_source):
            ref["via_function"] = wrapper_name
            ref["confidence_reason"] = reason
            ref["confidence_score"] = score

            # Downgrade confidence to 'inferred' if from wrapper
            if ref.get("confidence") == "exact":
                ref["confidence"] = "inferred"

            break

    return ref


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Test wrapper detection
    test_code = """
def show_character(name, emotion):
    renpy.show(f"char_{name}_{emotion}.png", at_list=[center])
"""

    results = infer_media_from_wrapper("show_character", test_code)
    print(f"Inferred {len(results)} media refs from show_character")

    # Test confidence scoring
    conf, score, reason = score_confidence("show", "renpy.show(", True, False)
    print(f"Confidence: {conf} (score={score}, reason={reason})")

    # Test variable extraction
    vars = extract_variables_from_fstring("bg_{location}_{time}.png")
    print(f"Variables: {vars}")
