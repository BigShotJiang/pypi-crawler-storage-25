"""
Media Adapter Registry — Engine-Specific Extractor Mapping

Ticket: ENG-221/222/223 (shared registry)
Module: branchpy.analyze.media_adapters
Version: v0.9.0.2

Central registry for engine-specific media extractors. Allows dynamic
selection of extractor based on `engine` config in .branchpy.toml.

Usage:
    ```python
    from branchpy.analyze.media_adapters import get_media_extractor

    # In .branchpy.toml: engine = "unity"
    extractor = get_media_extractor(engine="unity", project_root=".")
    refs = extractor.extract("Assets/Scripts/UIManager.cs")
    ```

Supported engines:
    - renpy: Ren'Py visual novel engine (Phase A complete)
    - unity: Unity game engine (C# scripts)
    - godot: Godot game engine (GDScript)
    - generic: Fallback for custom/unknown engines

TODOs:
    - [ ] Register all extractors in ADAPTER_REGISTRY
    - [ ] Implement get_media_extractor() factory
    - [ ] Add config validation (warn if unsupported engine)
    - [ ] Add engine auto-detection (scan for project files)
"""

from pathlib import Path
from typing import Dict, Optional, Protocol, Type

# ============================================================================
# EXTRACTOR PROTOCOL (Interface for all engine adapters)
# ============================================================================


class MediaExtractor(Protocol):
    """
    Protocol (interface) that all engine-specific extractors must implement.

    Methods:
        extract(script_path: str) -> List[MediaRef]:
            Extract media references from a script file.

    Attributes:
        project_root: Path to project root directory
        config: MediaConfig dict from .branchpy.toml
    """

    def __init__(self, project_root: str = ".", config: Optional[dict] = None):
        """Initialize extractor with project root and config."""
        ...

    def extract(self, script_path: str):
        """
        Extract media references from script file.

        Args:
            script_path: Path to script file (relative to project_root or absolute)

        Returns:
            List of engine-specific MediaRef objects
        """
        ...


# ============================================================================
# ADAPTER REGISTRY
# ============================================================================

from branchpy.analyze.engines.generic_media import GenericMediaExtractor

# Import adapter implementations
from branchpy.analyze.engines.renpy_media import RenpyMediaExtractor

# Registry mapping engine name → extractor class
ADAPTER_REGISTRY: Dict[str, Type[MediaExtractor]] = {
    "renpy": RenpyMediaExtractor,
    "generic": GenericMediaExtractor,
    # "unity": UnityMediaExtractor,  # From unity_media.py (TODO: WP-28)
    # "godot": GodotMediaExtractor,  # From godot_media.py (TODO: WP-27)
}


# ============================================================================
# FACTORY FUNCTION
# ============================================================================


def get_media_extractor(
    engine: str, project_root: str = ".", config: Optional[dict] = None
) -> MediaExtractor:
    """
    Factory function to get the appropriate media extractor for an engine.

    Args:
        engine: Engine name ("renpy", "unity", "godot", "generic")
        project_root: Path to project root directory
        config: MediaConfig dict from .branchpy.toml [media] section

    Returns:
        Instance of the appropriate MediaExtractor subclass

    Raises:
        ValueError: If engine is not supported

    Examples:
        >>> # From .branchpy.toml: engine = "unity"
        >>> extractor = get_media_extractor("unity", project_root="C:/UnityGame")
        >>> refs = extractor.extract("Assets/Scripts/UIManager.cs")

        >>> # Auto-fallback to generic
        >>> extractor = get_media_extractor("custom_engine", project_root=".")
        >>> # Logs warning, returns GenericMediaExtractor
    """
    # Normalize engine name
    engine_lower = engine.lower()

    # Check registry
    if engine_lower not in ADAPTER_REGISTRY:
        # Log warning and fallback to generic
        print(f"WARNING: Unsupported engine '{engine}', falling back to 'generic'")
        engine_lower = "generic"

    # Instantiate extractor
    extractor_class = ADAPTER_REGISTRY[engine_lower]
    return extractor_class(project_root=project_root, config=config)


# ============================================================================
# ENGINE AUTO-DETECTION
# ============================================================================


def detect_engine(project_root: str | Path) -> Optional[str]:
    """
    Auto-detect game engine from project structure.

    Detection heuristics:
        - project.godot → "godot"
        - Assets/ + ProjectSettings/ → "unity"
        - script.rpy or game/ → "renpy"
        - None of above → "generic"

    Args:
        project_root: Path to project root directory

    Returns:
        Engine name ("renpy", "unity", "godot", "generic") or None

    Example:
        >>> detect_engine("C:/MyGame")
        'renpy'
    """
    root = Path(project_root)

    # Check for Godot
    if (root / "project.godot").exists():
        return "godot"

    # Check for Unity
    if (root / "Assets").is_dir() and (root / "ProjectSettings").is_dir():
        return "unity"

    # Check for Ren'Py
    if (root / "game").is_dir() or list(root.glob("**/*.rpy")):
        return "renpy"

    # Fallback to generic
    return "generic"


# ============================================================================
# CONFIGURATION HELPERS
# ============================================================================


def validate_engine_config(engine: str, config: dict) -> bool:
    """
    Validate engine-specific configuration.

    Args:
        engine: Engine name
        config: MediaConfig dict

    Returns:
        True if config is valid, False otherwise

    Warnings:
        - If engine="renpy" but screens_enabled missing → default to True
        - If engine="unity" but project_root not Unity project → warn
    """
    # TODO: Implement validation rules
    # Example checks:
    # - Ren'Py: warn if max_media_per_node > 100 (performance)
    # - Unity: warn if project_root missing Assets/ folder
    # - Godot: warn if project_root missing project.godot
    pass


# ============================================================================
# INTEGRATION WITH EXISTING CODE
# ============================================================================

"""
Integration points:

1. In renpy_engine.py (Phase 4.5):
    ```python
    from branchpy.analyze.media_adapters import get_media_extractor
    
    # Replace hardcoded RenpyMediaExtractor with:
    media_config = load_media_config(options)
    engine = media_config.get('engine', 'renpy')  # Default to renpy
    extractor = get_media_extractor(engine, project_root, media_config)
    media_refs = extractor.extract(script_path)
    ```

2. In .branchpy.toml:
    ```toml
    [media]
    engine = "renpy"  # or "unity", "godot", "generic"
    enabled = true
    # ... other config ...
    ```

3. In CLI (branchpy/cli.py):
    ```bash
    # Auto-detect engine
    branchpy analyze --auto-detect-engine
    
    # Override engine
    branchpy analyze --engine unity
    ```

4. In tests:
    ```python
    # Test registry
    def test_get_extractor_renpy():
        ext = get_media_extractor("renpy")
        assert isinstance(ext, RenpyMediaExtractor)
    
    # Test auto-detection
    def test_detect_engine_unity():
        engine = detect_engine("tests/fixtures/unity_project")
        assert engine == "unity"
    ```
"""


# ============================================================================
# TODO: ACTUAL IMPORTS (Once modules integrated)
# ============================================================================

"""
# Uncomment when ready to integrate:

from branchpy.analyze.media_renpy import RenpyMediaExtractor
from branchpy.analyze.engines.unity_media import UnityMediaExtractor
from branchpy.analyze.engines.godot_media import GodotMediaExtractor
from branchpy.analyze.engines.generic_media import GenericMediaExtractor

ADAPTER_REGISTRY = {
    "renpy": RenpyMediaExtractor,
    "unity": UnityMediaExtractor,
    "godot": GodotMediaExtractor,
    "generic": GenericMediaExtractor,
}
"""


if __name__ == "__main__":
    # Example usage (TODO: replace with real tests)

    # Auto-detect engine
    detected = detect_engine(".")
    print(f"Detected engine: {detected}")

    # Get extractor
    # extractor = get_media_extractor(detected or "generic", project_root=".")
    # refs = extractor.extract("script.rpy")  # or .cs, .gd, etc.
    # print(f"Found {len(refs)} media references")
