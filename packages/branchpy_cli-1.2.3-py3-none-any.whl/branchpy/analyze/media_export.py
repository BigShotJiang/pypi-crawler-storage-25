"""
Media Export Helper — CSV/JSON Generation for Media Summary

Ticket: UI-304
Module: branchpy.analyze.media_export
Version: v0.9.0.2

Provides utility functions to export media.summary and media.by_label to:
- CSV format (for Excel/spreadsheet analysis)
- JSON format (for external tooling)

Usage (Python):
    ```python
    from branchpy.analyze.media_export import export_media_csv, export_media_json

    # After analysis
    unified_report = {...}

    # Export CSV
    export_media_csv(
        unified_report['media'],
        output_path='media_summary.csv'
    )

    # Export JSON
    export_media_json(
        unified_report['media'],
        output_path='media_summary.json'
    )
    ```

TODOs:
    - [ ] Implement CSV export with configurable columns
    - [ ] Implement JSON export (flattened by_label)
    - [ ] Add streaming for large datasets (> 10,000 refs)
    - [ ] Support Excel formatting (openpyxl optional)
"""

import csv
import json
from typing import Any, Dict, List, Optional, TextIO

# ============================================================================
# CSV EXPORT
# ============================================================================

# Column definitions
CSV_COLUMNS = [
    "label",
    "kind",
    "action",
    "channel",
    "target",
    "resolved_path",
    "template_path",
    "confidence",
    "via_function",
    "source_file",
    "source_line",
    "variables",
]


def export_media_csv(
    media_data: Dict[str, Any], output_path: str, columns: Optional[List[str]] = None
) -> int:
    """
    Export media summary to CSV file.

    Args:
        media_data: media dict from unified_report.json
        output_path: Path to output CSV file
        columns: Optional list of column names (default: CSV_COLUMNS)

    Returns:
        Number of rows written (excluding header)

    Example:
        >>> count = export_media_csv(report['media'], 'media.csv')
        >>> print(f"Exported {count} media references")
    """
    columns = columns or CSV_COLUMNS
    by_label = media_data.get("by_label", {})

    # Flatten by_label to rows
    rows = []
    for label, refs in by_label.items():
        for ref in refs:
            row = {col: ref.get(col, "") for col in columns}
            row["label"] = label  # Ensure label is populated
            rows.append(row)

    # Write CSV
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

    return len(rows)


def stream_media_csv(
    media_data: Dict[str, Any], file_handle: TextIO, columns: Optional[List[str]] = None
):
    """
    Stream media refs to CSV (for large datasets).

    Args:
        media_data: media dict from unified_report.json
        file_handle: Open file handle (text mode, writable)
        columns: Optional list of column names

    Example:
        >>> with open('media.csv', 'w', encoding='utf-8') as f:
        ...     stream_media_csv(report['media'], f)
    """
    columns = columns or CSV_COLUMNS
    by_label = media_data.get("by_label", {})

    writer = csv.DictWriter(file_handle, fieldnames=columns)
    writer.writeheader()

    for label, refs in by_label.items():
        for ref in refs:
            row = {col: ref.get(col, "") for col in columns}
            row["label"] = label
            writer.writerow(row)


# ============================================================================
# JSON EXPORT
# ============================================================================


def export_media_json(
    media_data: Dict[str, Any], output_path: str, flatten: bool = True, indent: int = 2
) -> int:
    """
    Export media summary to JSON file.

    Args:
        media_data: media dict from unified_report.json
        output_path: Path to output JSON file
        flatten: If True, flatten by_label to single array; if False, keep structure
        indent: JSON indentation (default: 2, use 0 for compact)

    Returns:
        Number of refs exported

    Example:
        >>> # Flattened array
        >>> export_media_json(report['media'], 'media.json', flatten=True)

        >>> # Keep by_label structure
        >>> export_media_json(report['media'], 'media.json', flatten=False)
    """
    if flatten:
        # Flatten to single array
        refs = []
        by_label = media_data.get("by_label", {})
        for label, label_refs in by_label.items():
            for ref in label_refs:
                ref_copy = ref.copy()
                ref_copy["label"] = label  # Ensure label is included
                refs.append(ref_copy)

        output = {
            "summary": media_data.get("summary", {}),
            "refs": refs,
        }
    else:
        # Keep original structure
        output = media_data

    # Write JSON
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=indent if indent > 0 else None)

    # Count refs
    by_label = media_data.get("by_label", {})
    total = sum(len(refs) for refs in by_label.values())
    return total


# ============================================================================
# EXCEL EXPORT (Optional — requires openpyxl)
# ============================================================================


def export_media_excel(
    media_data: Dict[str, Any], output_path: str, sheet_name: str = "Media Summary"
):
    """
    Export media summary to Excel file with formatting.

    Requires: openpyxl (pip install openpyxl)

    Args:
        media_data: media dict from unified_report.json
        output_path: Path to output .xlsx file
        sheet_name: Name of worksheet

    Features:
        - Auto-filter on header row
        - Freeze first row
        - Color-code confidence (green/yellow/orange)
        - Hyperlink source_file (if local)

    Example:
        >>> export_media_excel(report['media'], 'media.xlsx')
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        raise ImportError(
            "openpyxl is required for Excel export. "
            "Install with: pip install openpyxl"
        )

    # Create workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_name

    # Write header
    columns = CSV_COLUMNS
    ws.append(columns)

    # Style header
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill(
            start_color="CCCCCC", end_color="CCCCCC", fill_type="solid"
        )

    # Write data
    by_label = media_data.get("by_label", {})
    row_num = 2

    for label, refs in by_label.items():
        for ref in refs:
            row = [ref.get(col, "") for col in columns]
            row[0] = label  # label column
            ws.append(row)

            # Color-code confidence
            confidence = ref.get("confidence", "")
            confidence_col = columns.index("confidence") + 1
            cell = ws.cell(row=row_num, column=confidence_col)

            if confidence == "exact":
                cell.fill = PatternFill(
                    start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"
                )
            elif confidence == "dynamic":
                cell.fill = PatternFill(
                    start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"
                )
            elif confidence == "inferred":
                cell.fill = PatternFill(
                    start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"
                )

            row_num += 1

    # Auto-filter
    ws.auto_filter.ref = ws.dimensions

    # Freeze top row
    ws.freeze_panes = "A2"

    # Save
    wb.save(output_path)


# ============================================================================
# SUMMARY STATS EXPORT
# ============================================================================


def export_summary_stats(
    media_data: Dict[str, Any], output_path: str, format: str = "json"
):
    """
    Export only summary statistics (no refs).

    Args:
        media_data: media dict from unified_report.json
        output_path: Path to output file
        format: 'json' or 'csv'

    Output (JSON):
        {
          "total_media_refs": 150,
          "distinct_targets": 47,
          "missing": 3,
          "by_kind": {"IMAGE": 100, "AUDIO": 40, "VIDEO": 10},
          "by_confidence": {"exact": 120, "dynamic": 25, "inferred": 5}
        }

    Output (CSV):
        metric,value
        total_media_refs,150
        distinct_targets,47
        missing,3
        ...
    """
    summary = media_data.get("summary", {})

    if format == "json":
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

    elif format == "csv":
        # Flatten summary to rows
        rows = []
        for key, value in summary.items():
            if isinstance(value, dict):
                # Nested dict (e.g., by_kind, by_confidence)
                for sub_key, sub_value in value.items():
                    rows.append({"metric": f"{key}.{sub_key}", "value": sub_value})
            else:
                rows.append({"metric": key, "value": value})

        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["metric", "value"])
            writer.writeheader()
            writer.writerows(rows)


# ============================================================================
# CLI INTEGRATION
# ============================================================================

"""
CLI usage (branchpy/cli.py):

```bash
# Export media summary to CSV
branchpy export-media --format csv --output media.csv

# Export to Excel (with formatting)
branchpy export-media --format excel --output media.xlsx

# Export only summary stats
branchpy export-media --format json --output summary.json --summary-only
```

Implementation:
```python
import argparse
from branchpy.analyze.media_export import export_media_csv, export_media_json

def export_media_command(args):
    # Load unified_report.json
    with open('unified_report.json') as f:
        report = json.load(f)
    
    media_data = report.get('media', {})
    
    if args.format == 'csv':
        count = export_media_csv(media_data, args.output)
        print(f"Exported {count} media references to {args.output}")
    
    elif args.format == 'json':
        count = export_media_json(media_data, args.output)
        print(f"Exported {count} media references to {args.output}")
    
    elif args.format == 'excel':
        export_media_excel(media_data, args.output)
        print(f"Exported media summary to {args.output}")
```
"""


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Example usage

    # Mock media data
    sample_media = {
        "summary": {
            "total_media_refs": 3,
            "distinct_targets": 3,
            "missing": 1,
            "by_kind": {"IMAGE": 2, "AUDIO": 1},
            "by_confidence": {"exact": 2, "dynamic": 1},
        },
        "by_label": {
            "start": [
                {
                    "id": "media_1",
                    "kind": "IMAGE",
                    "action": "scene",
                    "target": "bg_cafe.png",
                    "resolved_path": "game/images/bg_cafe.png",
                    "confidence": "exact",
                    "source_file": "script.rpy",
                    "source_line": 10,
                },
                {
                    "id": "media_2",
                    "kind": "AUDIO",
                    "action": "play",
                    "channel": "music",
                    "target": "bgm.ogg",
                    "template_path": "audio/music/bgm.ogg",
                    "confidence": "dynamic",
                    "source_file": "script.rpy",
                    "source_line": 20,
                },
            ],
            "cafe": [
                {
                    "id": "media_3",
                    "kind": "IMAGE",
                    "action": "show",
                    "target": "char_alice.png",
                    "resolved_path": "game/images/characters/char_alice.png",
                    "confidence": "exact",
                    "source_file": "cafe.rpy",
                    "source_line": 5,
                }
            ],
        },
    }

    # Test CSV export
    # export_media_csv(sample_media, 'test_media.csv')

    # Test JSON export
    # export_media_json(sample_media, 'test_media.json', flatten=True)

    # Test summary export
    # export_summary_stats(sample_media, 'test_summary.json', format='json')

    print("Media export helpers ready. Run tests to generate output files.")
