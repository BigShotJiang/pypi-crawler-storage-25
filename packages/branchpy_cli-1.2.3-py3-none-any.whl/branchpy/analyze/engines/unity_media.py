"""
Unity Media Extractor — C# Media Detection

Ticket: ENG-221
Module: branchpy.analyze.engines.unity_media
Version: v0.9.0.2

Detects media references in Unity C# scripts using pattern matching for:
- Resources.Load<Sprite|Texture2D|AudioClip|VideoClip>
- AudioSource API (Play, PlayOneShot, clip assignment)
- VideoPlayer API (url, clip assignment)
- UI Image.sprite assignments
- Renderer.material.mainTexture assignments

Example input (PlayerController.cs):
    ```csharp
    public class PlayerController : MonoBehaviour {
        void Start() {
            Sprite icon = Resources.Load<Sprite>("UI/player_icon");
            AudioSource.PlayOneShot(Resources.Load<AudioClip>("SFX/jump"));
            VideoPlayer vp = GetComponent<VideoPlayer>();
            vp.url = "Videos/intro.mp4";
        }
    }
    ```

Expected output:
    [
        MediaRef(kind=IMAGE, action="load", target="UI/player_icon", ...),
        MediaRef(kind=AUDIO, action="play", target="SFX/jump", ...),
        MediaRef(kind=VIDEO, action="assign", target="Videos/intro.mp4", ...)
    ]

TODOs:
    - [ ] Implement C# regex patterns for Resources.Load variants
    - [ ] Detect AudioSource.Play/PlayOneShot
    - [ ] Detect VideoPlayer.url/clip assignments
    - [ ] Detect UI Image.sprite assignments
    - [ ] Normalize paths to Unity resource paths (no extensions)
    - [ ] Add golden test: tests/golden/media/unity/sample.json
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Pattern

from branchpy.media_analyzer import MediaRef

# TODO: Import from media_analyzer once integrated
# from branchpy.analyze.media_analyzer import MediaRef, MediaExtractor, MediaKind, MediaAction


# ============================================================================
# REGEX PATTERNS (C# Media API Detection)
# ============================================================================

# Resources.Load<T>("path")
RESOURCES_LOAD_RE: Pattern = re.compile(
    r'Resources\.Load<(?P<type>Sprite|Texture2D|AudioClip|VideoClip)>\s*\(\s*"(?P<path>[^"]+)"\s*\)',
    re.IGNORECASE,
)

# AudioSource.PlayOneShot(clip)
AUDIO_PLAYONESHOT_RE: Pattern = re.compile(
    r"AudioSource\.PlayOneShot\s*\(\s*(?P<clip>[^)]+)\s*\)", re.IGNORECASE
)

# AudioSource.Play()
AUDIO_PLAY_RE: Pattern = re.compile(r"AudioSource\.Play\s*\(\s*\)", re.IGNORECASE)

# AudioSource.clip = ...
AUDIO_CLIP_ASSIGN_RE: Pattern = re.compile(
    r"(?P<var>\w+)\.clip\s*=\s*(?P<rhs>[^;]+)", re.IGNORECASE
)

# VideoPlayer.url = "..."
VIDEO_URL_ASSIGN_RE: Pattern = re.compile(
    r'(?P<var>\w+)\.url\s*=\s*"(?P<url>[^"]+)"', re.IGNORECASE
)

# VideoPlayer.clip = ...
VIDEO_CLIP_ASSIGN_RE: Pattern = re.compile(
    r"(?P<var>\w+)\.clip\s*=\s*(?P<rhs>[^;]+)", re.IGNORECASE
)

# Image.sprite = ...
IMAGE_SPRITE_ASSIGN_RE: Pattern = re.compile(
    r"(?P<var>\w+)\.sprite\s*=\s*(?P<rhs>[^;]+)", re.IGNORECASE
)

# Renderer.material.mainTexture = ...
RENDERER_TEXTURE_ASSIGN_RE: Pattern = re.compile(
    r"(?P<var>\w+)\.material\.mainTexture\s*=\s*(?P<rhs>[^;]+)", re.IGNORECASE
)


# ============================================================================
# TYPE MAPPING (Unity Types → MediaKind)
# ============================================================================

UNITY_TYPE_TO_MEDIA_KIND = {
    "Sprite": "IMAGE",
    "Texture2D": "IMAGE",
    "AudioClip": "AUDIO",
    "VideoClip": "VIDEO",
}


# ============================================================================
# UNITY MEDIA EXTRACTOR
# ============================================================================


@dataclass
class UnityMediaRef:
    """Temporary structure before converting to MediaRef."""

    kind: str  # IMAGE, AUDIO, VIDEO
    action: str  # load, play, assign
    target: Optional[str]  # Resource path or URL
    source_file: str
    source_line: int
    confidence: str = "exact"  # Unity paths are usually exact
    template_path: Optional[str] = None


class UnityMediaExtractor:
    """
    Extract media references from Unity C# scripts.

    This extractor uses regex patterns to detect Unity-specific API calls
    without requiring a full C# AST parser. It normalizes Unity resource
    paths to match the MediaRef schema.

    Attributes:
        project_root: Path to Unity project root (contains Assets/ folder)
        config: MediaConfig (from .branchpy.toml [media] section)

    Example:
        >>> extractor = UnityMediaExtractor(project_root="C:/UnityGame")
        >>> refs = extractor.extract("Assets/Scripts/UIManager.cs")
        >>> refs[0].target
        'UI/button_icon'
    """

    def __init__(self, project_root: str = ".", config: Optional[dict] = None):
        """
        Initialize Unity media extractor.

        Args:
            project_root: Path to Unity project root
            config: MediaConfig dict (optional, for extension filtering)
        """
        self.project_root = Path(project_root)
        self.config = config or {}
        self.enabled_extensions = self.config.get(
            "extensions",
            {
                "IMAGE": [".png", ".jpg", ".jpeg", ".tga", ".psd"],
                "AUDIO": [".mp3", ".ogg", ".wav", ".aif"],
                "VIDEO": [".mp4", ".webm", ".mov", ".avi"],
            },
        )

    def extract(self, script_path: str) -> List[UnityMediaRef]:
        """
        Extract media references from a Unity C# script.

        Args:
            script_path: Path to .cs file (relative to project_root or absolute)

        Returns:
            List of UnityMediaRef objects (convert to MediaRef downstream)

        Raises:
            FileNotFoundError: If script_path does not exist

        Example:
            >>> refs = extractor.extract("Assets/Scripts/PlayerController.cs")
            >>> len(refs)
            3
        """
        refs: List[UnityMediaRef] = []

        # Resolve path
        script_full_path = self.project_root / script_path
        if not script_full_path.exists():
            raise FileNotFoundError(f"Unity script not found: {script_full_path}")

        # Read script
        with open(script_full_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        # Extract media refs line-by-line
        for line_num, line in enumerate(lines, start=1):
            # Resources.Load<T>
            refs.extend(self._extract_resources_load(line, script_path, line_num))

            # AudioSource API
            refs.extend(self._extract_audio_source(line, script_path, line_num))

            # VideoPlayer API
            refs.extend(self._extract_video_player(line, script_path, line_num))

            # UI Image API
            refs.extend(self._extract_image_sprite(line, script_path, line_num))

            # Renderer API
            refs.extend(self._extract_renderer_texture(line, script_path, line_num))

        return refs

    def _extract_resources_load(
        self, line: str, file: str, line_num: int
    ) -> List[UnityMediaRef]:
        """Extract Resources.Load<T>("path") patterns."""
        refs = []
        for match in RESOURCES_LOAD_RE.finditer(line):
            unity_type = match.group("type")
            resource_path = match.group("path")

            kind = UNITY_TYPE_TO_MEDIA_KIND.get(unity_type, "OTHER")
            refs.append(
                UnityMediaRef(
                    kind=kind,
                    action="load",
                    target=resource_path,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact",
                )
            )
        return refs

    def _extract_audio_source(
        self, line: str, file: str, line_num: int
    ) -> List[UnityMediaRef]:
        """Extract AudioSource.Play/PlayOneShot patterns."""
        refs = []

        # PlayOneShot(clip)
        for match in AUDIO_PLAYONESHOT_RE.finditer(line):
            clip_arg = match.group("clip")
            target = self._extract_literal_from_arg(clip_arg)

            refs.append(
                UnityMediaRef(
                    kind="AUDIO",
                    action="play",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                )
            )

        # AudioSource.clip = ...
        for match in AUDIO_CLIP_ASSIGN_RE.finditer(line):
            rhs = match.group("rhs")
            target = self._extract_literal_from_arg(rhs)

            refs.append(
                UnityMediaRef(
                    kind="AUDIO",
                    action="assign",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                )
            )

        return refs

    def _extract_video_player(
        self, line: str, file: str, line_num: int
    ) -> List[UnityMediaRef]:
        """Extract VideoPlayer.url/clip patterns."""
        refs = []

        # VideoPlayer.url = "..."
        for match in VIDEO_URL_ASSIGN_RE.finditer(line):
            url = match.group("url")
            refs.append(
                UnityMediaRef(
                    kind="VIDEO",
                    action="assign",
                    target=url,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact",
                )
            )

        # VideoPlayer.clip = ...
        for match in VIDEO_CLIP_ASSIGN_RE.finditer(line):
            rhs = match.group("rhs")
            target = self._extract_literal_from_arg(rhs)

            refs.append(
                UnityMediaRef(
                    kind="VIDEO",
                    action="assign",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                )
            )

        return refs

    def _extract_image_sprite(
        self, line: str, file: str, line_num: int
    ) -> List[UnityMediaRef]:
        """Extract Image.sprite = ... patterns."""
        refs = []
        for match in IMAGE_SPRITE_ASSIGN_RE.finditer(line):
            rhs = match.group("rhs")
            target = self._extract_literal_from_arg(rhs)

            refs.append(
                UnityMediaRef(
                    kind="IMAGE",
                    action="assign",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                )
            )
        return refs

    def _extract_renderer_texture(
        self, line: str, file: str, line_num: int
    ) -> List[UnityMediaRef]:
        """Extract Renderer.material.mainTexture = ... patterns."""
        refs = []
        for match in RENDERER_TEXTURE_ASSIGN_RE.finditer(line):
            rhs = match.group("rhs")
            target = self._extract_literal_from_arg(rhs)

            refs.append(
                UnityMediaRef(
                    kind="IMAGE",
                    action="assign",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                )
            )
        return refs

    def _extract_literal_from_arg(self, arg: str) -> Optional[str]:
        """
        Extract string literal from C# argument.

        Examples:
            "path/to/file" → "path/to/file"
            Resources.Load<Sprite>("ui/icon") → "ui/icon"
            variable → None
        """
        # Strip whitespace
        arg = arg.strip()

        # String literal
        if (arg.startswith('"') and arg.endswith('"')) or (
            arg.startswith("'") and arg.endswith("'")
        ):
            return arg[1:-1]

        # Nested Resources.Load
        nested_match = RESOURCES_LOAD_RE.search(arg)
        if nested_match:
            return nested_match.group("path")

        # Variable/expression → dynamic
        return None


# ============================================================================
# CONVERSION TO MEDIAREF
# ============================================================================


def unity_to_media_ref(unity_ref: UnityMediaRef) -> "MediaRef":
    """
    Convert UnityMediaRef to standard MediaRef schema.

    TODO: Implement once MediaRef imported

    Args:
        unity_ref: Unity-specific media ref

    Returns:
        MediaRef with engine="unity"
    """
    # Placeholder
    # return MediaRef(
    #     id=f"media_{unity_ref.source_line}_{hash(unity_ref.target)}",
    #     engine="unity",
    #     kind=unity_ref.kind,
    #     action=unity_ref.action,
    #     target=unity_ref.target,
    #     source_file=unity_ref.source_file,
    #     source_line=unity_ref.source_line,
    #     confidence=unity_ref.confidence,
    #     resolved_path=_resolve_unity_path(unity_ref.target),
    #     ...
    # )
    pass


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Example usage
    extractor = UnityMediaExtractor(project_root=".")

    # Mock C# content
    sample_cs = """
    using UnityEngine;
    
    public class UIManager : MonoBehaviour {
        void Start() {
            Sprite icon = Resources.Load<Sprite>("UI/Icons/player");
            AudioSource.PlayOneShot(Resources.Load<AudioClip>("SFX/button_click"));
            
            VideoPlayer vp = GetComponent<VideoPlayer>();
            vp.url = "Videos/intro.mp4";
            
            Image img = GetComponent<Image>();
            img.sprite = Resources.Load<Sprite>("Backgrounds/main_menu");
        }
    }
    """

    # TODO: Add proper unit tests with golden files
    # Expected: 4 UnityMediaRef objects
    # - IMAGE load "UI/Icons/player"
    # - AUDIO play "SFX/button_click"
    # - VIDEO assign "Videos/intro.mp4"
    # - IMAGE assign "Backgrounds/main_menu"
