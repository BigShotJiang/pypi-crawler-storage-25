"""
Generic Media Extractor — Extension-Based Detection

Ticket: GEN-223
Module: branchpy.analyze.engines.generic_media
Version: v0.9.0.2

Provides a fallback media extractor for engines without specific parsers.
Uses simple heuristics:
- Scan for string literals matching known media extensions
- Detect "assign + use" triplets (variable = "file.png"; show(variable))
- No AST parsing required—works with any text-based scripting language

Ideal for:
- Custom game engines
- Proprietary scripting languages
- Rapid prototyping without full parser
- Fallback when Unity/Godot/Ren'Py detection fails

Example input (custom_game.script):
    ```
    bg_image = "backgrounds/cafe.png"
    show_image(bg_image)

    play_sound("sfx/door_open.wav")

    video_path = "cutscenes/intro.mp4"
    play_video(video_path)
    ```

Expected output:
    [
        MediaRef(kind=IMAGE, confidence="dynamic", target="backgrounds/cafe.png", ...),
        MediaRef(kind=AUDIO, confidence="dynamic", target="sfx/door_open.wav", ...),
        MediaRef(kind=VIDEO, confidence="dynamic", target="cutscenes/intro.mp4", ...)
    ]

TODOs:
    - [ ] Implement literal scanning with extension matching
    - [ ] Detect assign+use patterns (optional, best-effort)
    - [ ] Support configurable extension lists from .branchpy.toml
    - [ ] Always mark confidence="dynamic" (generic has no static guarantees)
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

from branchpy.media_analyzer import MediaRef

# ============================================================================
# DEFAULT EXTENSION MAPPING
# ============================================================================

DEFAULT_EXTENSIONS = {
    "IMAGE": {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tga", ".svg"},
    "AUDIO": {".mp3", ".ogg", ".wav", ".flac", ".aac", ".m4a", ".wma"},
    "VIDEO": {".mp4", ".webm", ".avi", ".mov", ".mkv", ".ogv", ".flv"},
}


# ============================================================================
# REGEX PATTERNS
# ============================================================================

# String literal: "path/to/file.ext" or 'path/to/file.ext'
STRING_LITERAL_RE = re.compile(
    r'["\']([^"\']+\.(?:png|jpg|jpeg|gif|webp|bmp|tga|svg|mp3|ogg|wav|flac|aac|m4a|wma|mp4|webm|avi|mov|mkv|ogv|flv))["\']',
    re.IGNORECASE,
)

# Variable assignment: var_name = "file.ext"
ASSIGN_RE = re.compile(
    r'(?P<var>\w+)\s*=\s*["\'](?P<path>[^"\']+\.(?:png|jpg|jpeg|gif|webp|bmp|tga|svg|mp3|ogg|wav|flac|aac|m4a|wma|mp4|webm|avi|mov|mkv|ogv|flv))["\']',
    re.IGNORECASE,
)

# Function call with variable: func(var_name)
FUNC_CALL_RE = re.compile(r"\b(?P<func>\w+)\s*\(\s*(?P<arg>\w+)\s*\)", re.IGNORECASE)


# ============================================================================
# GENERIC MEDIA EXTRACTOR
# ============================================================================


@dataclass
class GenericMediaRef:
    """Temporary structure before converting to MediaRef."""

    kind: str  # IMAGE, AUDIO, VIDEO, OTHER
    action: str = "load"  # Generic always uses "load"
    target: Optional[str] = None
    source_file: str = ""
    source_line: int = 0
    confidence: str = "dynamic"  # Generic never has exact confidence
    variable: Optional[str] = None  # If detected via assign+use


class GenericMediaExtractor:
    """
    Extract media references using extension-based heuristics.

    This extractor is engine-agnostic and works with any text file by:
    1. Scanning for string literals with media extensions
    2. Optionally tracking variable assignments and uses
    3. Inferring MediaKind from file extension

    Always marks refs as confidence="dynamic" because generic detection
    cannot guarantee static analysis guarantees.

    Attributes:
        project_root: Path to project root
        config: MediaConfig (from .branchpy.toml [media] section)
        extensions: Mapping of kind → set of extensions

    Example:
        >>> extractor = GenericMediaExtractor()
        >>> refs = extractor.extract("game.script")
        >>> refs[0].target
        'backgrounds/cafe.png'
    """

    def __init__(self, project_root: str = ".", config: Optional[dict] = None):
        """
        Initialize generic media extractor.

        Args:
            project_root: Path to project root
            config: MediaConfig dict (optional, for custom extensions)
        """
        self.project_root = Path(project_root)
        self.config = config or {}

        # Load extensions from config or use defaults
        self.extensions = self.config.get("extensions", DEFAULT_EXTENSIONS)

        # Flatten extensions for quick lookup
        self.ext_to_kind = {}
        for kind, exts in self.extensions.items():
            for ext in exts:
                self.ext_to_kind[ext.lower()] = kind

    def extract(
        self, script_path: str, enable_assign_tracking: bool = False
    ) -> List[GenericMediaRef]:
        """
        Extract media references from a generic script file.

        Args:
            script_path: Path to script file (any extension)
            enable_assign_tracking: Track variable assignments (slower, more accurate)

        Returns:
            List of GenericMediaRef objects

        Example:
            >>> refs = extractor.extract("game.txt")
            >>> len(refs)
            3
        """
        refs: List[GenericMediaRef] = []

        # Resolve path
        script_full_path = self.project_root / script_path
        if not script_full_path.exists():
            raise FileNotFoundError(f"Script not found: {script_full_path}")

        # Read script
        with open(script_full_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        # Track variable assignments (if enabled)
        var_to_path: Dict[str, str] = {}

        # Extract media refs line-by-line
        for line_num, line in enumerate(lines, start=1):
            # 1. Scan for string literals
            refs.extend(self._extract_literals(line, script_path, line_num))

            # 2. Track assignments (if enabled)
            if enable_assign_tracking:
                self._track_assignments(line, var_to_path)
                refs.extend(
                    self._extract_variable_uses(
                        line, var_to_path, script_path, line_num
                    )
                )

        return refs

    def _extract_literals(
        self, line: str, file: str, line_num: int
    ) -> List[GenericMediaRef]:
        """Extract string literals with media extensions."""
        refs = []

        for match in STRING_LITERAL_RE.finditer(line):
            path = match.group(1)
            kind = self._infer_kind(path)

            refs.append(
                GenericMediaRef(
                    kind=kind,
                    action="load",
                    target=path,
                    source_file=file,
                    source_line=line_num,
                    confidence="dynamic",
                )
            )

        return refs

    def _track_assignments(self, line: str, var_to_path: Dict[str, str]):
        """Track variable = "path.ext" assignments."""
        for match in ASSIGN_RE.finditer(line):
            var_name = match.group("var")
            path = match.group("path")
            var_to_path[var_name] = path

    def _extract_variable_uses(
        self, line: str, var_to_path: Dict[str, str], file: str, line_num: int
    ) -> List[GenericMediaRef]:
        """Extract function calls using tracked variables."""
        refs = []

        for match in FUNC_CALL_RE.finditer(line):
            func = match.group("func")
            arg = match.group("arg")

            # Check if arg is a tracked variable
            if arg in var_to_path:
                path = var_to_path[arg]
                kind = self._infer_kind(path)

                # Infer action from function name
                action = self._infer_action(func)

                refs.append(
                    GenericMediaRef(
                        kind=kind,
                        action=action,
                        target=path,
                        source_file=file,
                        source_line=line_num,
                        confidence="dynamic",
                        variable=arg,
                    )
                )

        return refs

    def _infer_kind(self, path: str) -> str:
        """Infer MediaKind from file extension."""
        ext = Path(path).suffix.lower()
        return self.ext_to_kind.get(ext, "OTHER")

    def _infer_action(self, func_name: str) -> str:
        """
        Infer action from function name (best-effort heuristic).

        Examples:
            show_image → "show"
            play_sound → "play"
            load_texture → "load"
            Unknown → "load" (default)
        """
        func_lower = func_name.lower()

        if "show" in func_lower or "display" in func_lower:
            return "show"
        elif "play" in func_lower:
            return "play"
        elif "stop" in func_lower:
            return "stop"
        elif "hide" in func_lower:
            return "hide"
        else:
            return "load"  # Default


# ============================================================================
# CONVERSION TO MEDIAREF
# ============================================================================


def generic_to_media_ref(generic_ref: GenericMediaRef) -> "MediaRef":
    """
    Convert GenericMediaRef to standard MediaRef schema.

    TODO: Implement once MediaRef imported

    Args:
        generic_ref: Generic-specific media ref

    Returns:
        MediaRef with engine="generic"
    """
    # Placeholder
    # return MediaRef(
    #     id=f"media_{generic_ref.source_line}_{hash(generic_ref.target)}",
    #     engine="generic",
    #     kind=generic_ref.kind,
    #     action=generic_ref.action,
    #     target=generic_ref.target,
    #     source_file=generic_ref.source_file,
    #     source_line=generic_ref.source_line,
    #     confidence="dynamic",  # Always dynamic for generic
    #     resolved_path=generic_ref.target,
    #     ...
    # )
    pass


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Example usage
    extractor = GenericMediaExtractor()

    # Mock script content
    sample_script = """
    # Load background image
    bg = "backgrounds/cafe.png"
    show_image(bg)
    
    # Play sound effect
    play_sound("sfx/door_open.wav")
    
    # Play video cutscene
    video = "cutscenes/intro.mp4"
    play_video(video)
    """

    # TODO: Add proper unit tests
    # Expected (without assign tracking): 2 refs
    # - "backgrounds/cafe.png" (literal)
    # - "sfx/door_open.wav" (literal)
    # - "cutscenes/intro.mp4" (literal)

    # Expected (with assign tracking): 5 refs
    # - Same 3 literals above
    # - show_image(bg) → "backgrounds/cafe.png" (via variable)
    # - play_video(video) → "cutscenes/intro.mp4" (via variable)
