"""
Godot Media Extractor — GDScript Media Detection

Ticket: ENG-222
Module: branchpy.analyze.engines.godot_media
Version: v0.9.0.2

Detects media references in Godot GDScript files using pattern matching for:
- preload("res://...")
- load("res://...")
- Sprite2D/Sprite.texture assignments
- AudioStreamPlayer.stream assignments + .play()
- VideoStreamPlayer.stream assignments
- TextureRect.texture assignments

Example input (Player.gd):
    ```gdscript
    extends Node2D

    func _ready():
        var icon = preload("res://sprites/player_icon.png")
        $Sprite2D.texture = load("res://sprites/hero.png")
        $AudioStreamPlayer.stream = preload("res://audio/jump.ogg")
        $AudioStreamPlayer.play()
        $VideoPlayer.stream = load("res://videos/intro.ogv")
    ```

Expected output:
    [
        MediaRef(kind=IMAGE, action="preload", target="res://sprites/player_icon.png", ...),
        MediaRef(kind=IMAGE, action="load", target="res://sprites/hero.png", ...),
        MediaRef(kind=AUDIO, action="preload", target="res://audio/jump.ogg", ...),
        MediaRef(kind=AUDIO, action="play", ...),
        MediaRef(kind=VIDEO, action="load", target="res://videos/intro.ogv", ...)
    ]

TODOs:
    - [ ] Implement GDScript regex patterns for preload/load
    - [ ] Detect texture assignments (Sprite2D, TextureRect)
    - [ ] Detect AudioStreamPlayer.stream + .play()
    - [ ] Detect VideoStreamPlayer.stream
    - [ ] Normalize res:// paths
    - [ ] Add golden test: tests/golden/media/godot/sample.json
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Pattern

from branchpy.media_analyzer import MediaRef

# ============================================================================
# REGEX PATTERNS (GDScript Media API Detection)
# ============================================================================

# preload("res://path")
PRELOAD_RE: Pattern = re.compile(
    r'preload\s*\(\s*"(?P<path>res://[^"]+)"\s*\)', re.IGNORECASE
)

# load("res://path")
LOAD_RE: Pattern = re.compile(
    r'\bload\s*\(\s*"(?P<path>res://[^"]+)"\s*\)', re.IGNORECASE
)

# $NodeName.texture = ...
TEXTURE_ASSIGN_RE: Pattern = re.compile(
    r"(?P<node>[\$\w]+)\.texture\s*=\s*(?P<rhs>[^\n]+)", re.IGNORECASE
)

# $AudioStreamPlayer.stream = ...
AUDIO_STREAM_ASSIGN_RE: Pattern = re.compile(
    r"(?P<node>[\$\w]+)\.stream\s*=\s*(?P<rhs>[^\n]+)", re.IGNORECASE
)

# $AudioStreamPlayer.play()
AUDIO_PLAY_RE: Pattern = re.compile(r"(?P<node>[\$\w]+)\.play\s*\(\s*\)", re.IGNORECASE)

# $VideoStreamPlayer.stream = ...
VIDEO_STREAM_ASSIGN_RE: Pattern = re.compile(
    r"(?P<node>[\$\w]+VideoPlayer[\w]*)\.stream\s*=\s*(?P<rhs>[^\n]+)", re.IGNORECASE
)


# ============================================================================
# EXTENSION MAPPING (Godot Extensions → MediaKind)
# ============================================================================

GODOT_EXTENSION_TO_KIND = {
    # Images
    ".png": "IMAGE",
    ".jpg": "IMAGE",
    ".jpeg": "IMAGE",
    ".webp": "IMAGE",
    ".svg": "IMAGE",
    ".bmp": "IMAGE",
    # Audio
    ".ogg": "AUDIO",
    ".mp3": "AUDIO",
    ".wav": "AUDIO",
    # Video
    ".ogv": "VIDEO",
    ".webm": "VIDEO",
}


# ============================================================================
# GODOT MEDIA EXTRACTOR
# ============================================================================


@dataclass
class GodotMediaRef:
    """Temporary structure before converting to MediaRef."""

    kind: str  # IMAGE, AUDIO, VIDEO
    action: str  # preload, load, assign, play
    target: Optional[str]  # res:// path
    source_file: str
    source_line: int
    confidence: str = "exact"
    node_name: Optional[str] = None  # $Sprite2D, $AudioStreamPlayer, etc.


class GodotMediaExtractor:
    """
    Extract media references from Godot GDScript files.

    This extractor uses regex patterns to detect Godot-specific API calls
    (preload, load, texture/stream assignments) without requiring a full
    GDScript AST parser.

    Attributes:
        project_root: Path to Godot project root (contains project.godot)
        config: MediaConfig (from .branchpy.toml [media] section)

    Example:
        >>> extractor = GodotMediaExtractor(project_root="C:/GodotGame")
        >>> refs = extractor.extract("scenes/Player.gd")
        >>> refs[0].target
        'res://sprites/hero.png'
    """

    def __init__(self, project_root: str = ".", config: Optional[dict] = None):
        """
        Initialize Godot media extractor.

        Args:
            project_root: Path to Godot project root
            config: MediaConfig dict (optional, for extension filtering)
        """
        self.project_root = Path(project_root)
        self.config = config or {}
        self.enabled_extensions = self.config.get("extensions", GODOT_EXTENSION_TO_KIND)

    def extract(self, script_path: str) -> List[GodotMediaRef]:
        """
        Extract media references from a Godot GDScript file.

        Args:
            script_path: Path to .gd file (relative to project_root or absolute)

        Returns:
            List of GodotMediaRef objects (convert to MediaRef downstream)

        Raises:
            FileNotFoundError: If script_path does not exist

        Example:
            >>> refs = extractor.extract("scenes/Player.gd")
            >>> len(refs)
            5
        """
        refs: List[GodotMediaRef] = []

        # Resolve path
        script_full_path = self.project_root / script_path
        if not script_full_path.exists():
            raise FileNotFoundError(f"Godot script not found: {script_full_path}")

        # Read script
        with open(script_full_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        # Extract media refs line-by-line
        for line_num, line in enumerate(lines, start=1):
            # preload("res://...")
            refs.extend(self._extract_preload(line, script_path, line_num))

            # load("res://...")
            refs.extend(self._extract_load(line, script_path, line_num))

            # .texture = ...
            refs.extend(self._extract_texture_assign(line, script_path, line_num))

            # AudioStreamPlayer.stream = ...
            refs.extend(self._extract_audio_stream(line, script_path, line_num))

            # AudioStreamPlayer.play()
            refs.extend(self._extract_audio_play(line, script_path, line_num))

            # VideoStreamPlayer.stream = ...
            refs.extend(self._extract_video_stream(line, script_path, line_num))

        return refs

    def _extract_preload(
        self, line: str, file: str, line_num: int
    ) -> List[GodotMediaRef]:
        """Extract preload("res://...") patterns."""
        refs = []
        for match in PRELOAD_RE.finditer(line):
            path = match.group("path")
            kind = self._infer_kind_from_path(path)

            refs.append(
                GodotMediaRef(
                    kind=kind,
                    action="preload",
                    target=path,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact",
                )
            )
        return refs

    def _extract_load(self, line: str, file: str, line_num: int) -> List[GodotMediaRef]:
        """Extract load("res://...") patterns."""
        refs = []
        for match in LOAD_RE.finditer(line):
            path = match.group("path")
            kind = self._infer_kind_from_path(path)

            refs.append(
                GodotMediaRef(
                    kind=kind,
                    action="load",
                    target=path,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact",
                )
            )
        return refs

    def _extract_texture_assign(
        self, line: str, file: str, line_num: int
    ) -> List[GodotMediaRef]:
        """Extract .texture = ... patterns."""
        refs = []
        for match in TEXTURE_ASSIGN_RE.finditer(line):
            node = match.group("node")
            rhs = match.group("rhs")
            target = self._extract_path_from_rhs(rhs)

            refs.append(
                GodotMediaRef(
                    kind="IMAGE",
                    action="assign",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                    node_name=node,
                )
            )
        return refs

    def _extract_audio_stream(
        self, line: str, file: str, line_num: int
    ) -> List[GodotMediaRef]:
        """Extract AudioStreamPlayer.stream = ... patterns."""
        refs = []
        for match in AUDIO_STREAM_ASSIGN_RE.finditer(line):
            node = match.group("node")
            rhs = match.group("rhs")
            target = self._extract_path_from_rhs(rhs)

            # Only process if node name suggests audio
            if "audio" in node.lower():
                refs.append(
                    GodotMediaRef(
                        kind="AUDIO",
                        action="assign",
                        target=target,
                        source_file=file,
                        source_line=line_num,
                        confidence="exact" if target else "dynamic",
                        node_name=node,
                    )
                )
        return refs

    def _extract_audio_play(
        self, line: str, file: str, line_num: int
    ) -> List[GodotMediaRef]:
        """Extract AudioStreamPlayer.play() patterns."""
        refs = []
        for match in AUDIO_PLAY_RE.finditer(line):
            node = match.group("node")

            # Only emit play ref if node name suggests audio
            if "audio" in node.lower():
                refs.append(
                    GodotMediaRef(
                        kind="AUDIO",
                        action="play",
                        target=None,  # play() has no args; target must be inferred from .stream assignment
                        source_file=file,
                        source_line=line_num,
                        confidence="dynamic",
                        node_name=node,
                    )
                )
        return refs

    def _extract_video_stream(
        self, line: str, file: str, line_num: int
    ) -> List[GodotMediaRef]:
        """Extract VideoStreamPlayer.stream = ... patterns."""
        refs = []
        for match in VIDEO_STREAM_ASSIGN_RE.finditer(line):
            node = match.group("node")
            rhs = match.group("rhs")
            target = self._extract_path_from_rhs(rhs)

            refs.append(
                GodotMediaRef(
                    kind="VIDEO",
                    action="assign",
                    target=target,
                    source_file=file,
                    source_line=line_num,
                    confidence="exact" if target else "dynamic",
                    node_name=node,
                )
            )
        return refs

    def _extract_path_from_rhs(self, rhs: str) -> Optional[str]:
        """
        Extract res:// path from right-hand side of assignment.

        Examples:
            preload("res://sprites/hero.png") → "res://sprites/hero.png"
            load("res://audio/bgm.ogg") → "res://audio/bgm.ogg"
            my_texture → None (dynamic)
        """
        # Check for preload/load in RHS
        preload_match = PRELOAD_RE.search(rhs)
        if preload_match:
            return preload_match.group("path")

        load_match = LOAD_RE.search(rhs)
        if load_match:
            return load_match.group("path")

        # Check for string literal
        if '"res://' in rhs:
            # Extract quoted string
            start = rhs.find('"res://')
            end = rhs.find('"', start + 1)
            if end != -1:
                return rhs[start + 1 : end]

        # Variable/expression → dynamic
        return None

    def _infer_kind_from_path(self, path: str) -> str:
        """
        Infer MediaKind from file extension.

        Examples:
            res://sprites/hero.png → IMAGE
            res://audio/bgm.ogg → AUDIO
            res://videos/intro.ogv → VIDEO
            res://shaders/blur.gdshader → OTHER
        """
        ext = Path(path).suffix.lower()
        return GODOT_EXTENSION_TO_KIND.get(ext, "OTHER")


# ============================================================================
# CONVERSION TO MEDIAREF
# ============================================================================


def godot_to_media_ref(godot_ref: GodotMediaRef) -> "MediaRef":
    """
    Convert GodotMediaRef to standard MediaRef schema.

    TODO: Implement once MediaRef imported

    Args:
        godot_ref: Godot-specific media ref

    Returns:
        MediaRef with engine="godot"
    """
    # Placeholder
    # return MediaRef(
    #     id=f"media_{godot_ref.source_line}_{hash(godot_ref.target)}",
    #     engine="godot",
    #     kind=godot_ref.kind,
    #     action=godot_ref.action,
    #     target=godot_ref.target,
    #     source_file=godot_ref.source_file,
    #     source_line=godot_ref.source_line,
    #     confidence=godot_ref.confidence,
    #     resolved_path=godot_ref.target,  # res:// is already normalized
    #     ...
    # )
    pass


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Example usage
    extractor = GodotMediaExtractor(project_root=".")

    # Mock GDScript content
    sample_gd = """
    extends Node2D
    
    func _ready():
        # Image preload
        var icon = preload("res://sprites/player_icon.png")
        
        # Image load
        $Sprite2D.texture = load("res://sprites/hero.png")
        
        # Audio stream + play
        $AudioStreamPlayer.stream = preload("res://audio/music/bgm.ogg")
        $AudioStreamPlayer.play()
        
        # Video stream
        $VideoStreamPlayer.stream = load("res://videos/intro.ogv")
    """

    # TODO: Add proper unit tests with golden files
    # Expected: 5 GodotMediaRef objects
    # - IMAGE preload "res://sprites/player_icon.png"
    # - IMAGE load "res://sprites/hero.png"
    # - AUDIO assign "res://audio/music/bgm.ogg"
    # - AUDIO play (no target)
    # - VIDEO assign "res://videos/intro.ogv"
