"""
Generic Media Extractor (v0.9.0.2)

Fallback extractor for engines without dedicated parsers.
Uses extension-based detection in strings.
"""

import re
from pathlib import Path
from typing import Any, Dict, List


class GenericMediaExtractor:
    """Generic media extractor using extension patterns."""

    # Media file extensions by category
    EXTENSIONS = {
        "image": [".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".bmp"],
        "audio": [".mp3", ".ogg", ".wav", ".m4a", ".flac", ".aac"],
        "video": [".mp4", ".webm", ".ogv", ".avi", ".mov"],
    }

    def extract(
        self, project_root: Path, file_patterns: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Extract media references from generic project files.

        Args:
            project_root: Path to project root
            file_patterns: List of glob patterns (default: ['*.py', '*.js', '*.lua'])

        Returns:
            List of MediaRef dicts
        """
        if file_patterns is None:
            file_patterns = ["**/*.py", "**/*.js", "**/*.lua", "**/*.gd", "**/*.cs"]

        refs = []

        for pattern in file_patterns:
            for source_file in project_root.glob(pattern):
                if source_file.is_file():
                    try:
                        source = source_file.read_text(encoding="utf-8")
                        file_refs = self._extract_from_source(
                            source, str(source_file.relative_to(project_root))
                        )
                        refs.extend(file_refs)
                    except Exception:
                        continue

        return refs

    def _extract_from_source(
        self, source: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract media refs using extension patterns."""
        refs = []

        # Build regex for all extensions
        all_exts = []
        for exts in self.EXTENSIONS.values():
            all_exts.extend(exts)
        ext_pattern = "|".join(re.escape(ext) for ext in all_exts)

        # Find strings containing media extensions
        pattern = r'["\']([^"\']*?(?:' + ext_pattern + r'))["\']'

        for match in re.finditer(pattern, source):
            line_num = source[: match.start()].count("\n") + 1
            path = match.group(1)

            kind = self._infer_kind(path)

            refs.append(
                {
                    "id": f"generic_{source_file}_{line_num}_{path}",
                    "engine": "generic",
                    "kind": kind,
                    "action": "reference",
                    "channel": None,
                    "target": None,
                    "source_file": source_file,
                    "source_line": line_num,
                    "label": None,
                    "resolved_path": path,
                    "template_path": None,
                    "variables": [],
                    "via_function": None,
                    "confidence": "inferred",
                }
            )

        return refs

    def _infer_kind(self, path: str) -> str:
        """Infer media kind from extension."""
        path_lower = path.lower()

        for kind, exts in self.EXTENSIONS.items():
            if any(path_lower.endswith(ext) for ext in exts):
                return kind

        return "other"


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    test_code = """
def load_assets():
    bg_image = "assets/backgrounds/cafe.png"
    sound_fx = "sounds/click.ogg"
    video = "cutscenes/intro.mp4"
    data = "config.json"
"""

    extractor = GenericMediaExtractor()
    refs = extractor._extract_from_source(test_code, "utils.py")
    print(f"Found {len(refs)} generic media refs")
    for ref in refs:
        print(f"  {ref['kind']}: {ref['resolved_path']}")
