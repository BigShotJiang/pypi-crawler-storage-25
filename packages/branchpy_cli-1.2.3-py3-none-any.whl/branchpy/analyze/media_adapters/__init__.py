"""
Media Adapter Registry (v0.9.7 - Phase C)

Central registry for media extractors with auto-detection.
Includes Phase C Ren'Py adapter using ScriptGraph + PFI.
"""

from pathlib import Path
from typing import Any, List, Optional, Type

# Phase C: Ren'Py adapter using ScriptGraph
from branchpy.analyze.engines.renpy_media import RenpyMediaExtractor
from branchpy.analyze.media_adapters.renpy_phase_c_adapter import RenpyPhaseCAdapter

from .generic_media import GenericMediaExtractor
from .godot_media import GodotMediaExtractor
from .unity_media import UnityMediaExtractor

# ============================================================================
# ADAPTER REGISTRY
# ============================================================================

ADAPTERS = {
    "renpy": RenpyPhaseCAdapter,  # Phase C v0.9.7 — proper MediaTagRecord contract
    "unity": UnityMediaExtractor,
    "godot": GodotMediaExtractor,
    "generic": GenericMediaExtractor,
}


def get_adapter(engine: str) -> Optional[Type]:
    """
    Get media extractor adapter for specified engine.

    Args:
        engine: Engine name ('unity', 'godot', 'generic', etc.)

    Returns:
        Extractor class or None if not found
    """
    return ADAPTERS.get(engine.lower())


def detect_engine(project_root: Path | str) -> str:
    """
    Auto-detect engine from project structure.

    Args:
        project_root: Path to project root

    Returns:
        Detected engine name ('renpy', 'unity', 'godot', or 'generic')
    """
    root = Path(project_root) if isinstance(project_root, str) else project_root

    # Ren'Py detection (Phase C v0.9.7)
    if (root / "game").exists() or list(root.glob("**/*.rpy")):
        return "renpy"

    # Unity detection
    if (root / "Assets").exists() and (root / "ProjectSettings").exists():
        return "unity"

    # Godot detection
    if (root / "project.godot").exists():
        return "godot"

    # Default to generic
    return "generic"


def get_media_extractor(
    engine: str, project_root: str | Path, config: Optional[dict] = None
) -> Any:
    """
    Get media extractor instance for specified engine.

    Args:
        engine: Engine name ('renpy', 'unity', 'godot', 'generic')
        project_root: Path to project root
        config: Optional configuration dict

    Returns:
        Extractor instance

    Raises:
        ValueError: If engine not supported
    """
    adapter_class = get_adapter(engine)
    if adapter_class is None:
        raise ValueError(f"Unsupported engine: {engine}")

    return adapter_class(project_root=project_root, config=config)


def get_phase_c_adapter(
    engine: str, project_root: str | Path, config: Optional[dict] = None
) -> Any:
    """
    Get Phase C media adapter instance for specified engine.

    Phase C adapters follow the MediaPhaseCAdapter protocol — they take no
    constructor arguments; the project root is passed to collect_phase_c().

    Args:
        engine: Engine name ('renpy', 'unity', 'godot', 'generic')
        project_root: Path to project root (ignored at construction time)
        config: Optional configuration dict (ignored for Phase C adapters)

    Returns:
        Phase C adapter instance

    Raises:
        ValueError: If engine not supported
    """
    adapter_class = get_adapter(engine)
    if adapter_class is None:
        raise ValueError(f"Unsupported engine: {engine}")
    return adapter_class()


def extract_all_engines(project_root: Path, engines: Optional[List[str]] = None):
    """
    Extract media from multiple engines.

    Args:
        project_root: Path to project root
        engines: List of engine names (default: auto-detect)

    Returns:
        Dict mapping engine names to lists of MediaRef dicts
    """
    if engines is None:
        detected = detect_engine(project_root)
        engines = [detected]

    results = {}

    for engine_name in engines:
        adapter_class = get_adapter(engine_name)
        if adapter_class:
            extractor = adapter_class()
            refs = extractor.extract(project_root)
            results[engine_name] = refs

    return results


# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    "RenpyMediaExtractor",  # Phase C v0.9.7
    "UnityMediaExtractor",
    "GodotMediaExtractor",
    "GenericMediaExtractor",
    "ADAPTERS",
    "get_adapter",
    "get_media_extractor",  # New in v0.9.7
    "get_phase_c_adapter",  # Phase C compatibility
    "detect_engine",
    "extract_all_engines",
]
