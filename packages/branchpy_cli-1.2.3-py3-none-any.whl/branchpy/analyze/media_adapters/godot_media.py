"""
Godot Media Extractor (v0.9.0.2)

Extracts media references from Godot GDScript files.
Detects: preload/load, Sprite2D, AudioStreamPlayer, VideoStreamPlayer.
"""

import re
from pathlib import Path
from typing import Any, Dict, List


class GodotMediaExtractor:
    """Extract media references from Godot GDScript code."""

    # GDScript patterns
    PATTERNS = {
        # preload/load
        r'preload\s*\(\s*["\']([^"\']+)["\']': ("load", "preload"),
        r'load\s*\(\s*["\']([^"\']+)["\']': ("load", "load"),
        # Sprite2D/Sprite3D texture assignment
        r'\.texture\s*=\s*preload\s*\(\s*["\']([^"\']+)["\']': (
            "assign",
            "Sprite.texture",
        ),
        r'\.texture\s*=\s*load\s*\(\s*["\']([^"\']+)["\']': (
            "assign",
            "Sprite.texture",
        ),
        # AudioStreamPlayer
        r'AudioStreamPlayer[23D]*\.new\(\).*?\.stream\s*=\s*preload\s*\(\s*["\']([^"\']+)["\']': (
            "load",
            "AudioStreamPlayer",
        ),
        r'\.stream\s*=\s*preload\s*\(\s*["\']([^"\']+)["\']': ("assign", "AudioStream"),
        # VideoStreamPlayer
        r'\.stream\s*=\s*load\s*\(\s*["\']([^"\']+\.(?:webm|ogv))["\']': (
            "assign",
            "VideoStream",
        ),
    }

    def extract(self, project_root: Path) -> List[Dict[str, Any]]:
        """
        Extract media references from Godot project.

        Args:
            project_root: Path to Godot project root

        Returns:
            List of MediaRef dicts
        """
        refs = []

        # Find all .gd files
        for gd_file in project_root.rglob("*.gd"):
            try:
                source = gd_file.read_text(encoding="utf-8")
                file_refs = self._extract_from_source(
                    source, str(gd_file.relative_to(project_root))
                )
                refs.extend(file_refs)
            except Exception:
                continue

        return refs

    def _extract_from_source(
        self, source: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract media refs from GDScript source."""
        refs = []

        for pattern, (action, api) in self.PATTERNS.items():
            for match in re.finditer(pattern, source, re.DOTALL):
                line_num = source[: match.start()].count("\n") + 1
                path = match.group(1)

                kind = self._infer_kind(path, api)

                refs.append(
                    {
                        "id": f"godot_{source_file}_{line_num}_{path}",
                        "engine": "godot",
                        "kind": kind,
                        "action": action,
                        "channel": None,
                        "target": api,
                        "source_file": source_file,
                        "source_line": line_num,
                        "label": None,
                        "resolved_path": path,
                        "template_path": None,
                        "variables": [],
                        "via_function": None,
                        "confidence": "exact",
                    }
                )

        return refs

    def _infer_kind(self, path: str, api: str) -> str:
        """Infer media kind from path or API."""
        path_lower = path.lower()

        if any(path_lower.endswith(ext) for ext in [".png", ".jpg", ".svg", ".webp"]):
            return "image"
        if any(path_lower.endswith(ext) for ext in [".ogg", ".mp3", ".wav"]):
            return "audio"
        if any(path_lower.endswith(ext) for ext in [".webm", ".ogv"]):
            return "video"

        if "Audio" in api:
            return "audio"
        if "Video" in api:
            return "video"
        if "Sprite" in api or "texture" in api:
            return "image"

        return "other"


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    test_gd = """
extends Node2D

func _ready():
    var bg = preload("res://assets/backgrounds/cafe.png")
    $Sprite2D.texture = load("res://sprites/player.png")
    $AudioStreamPlayer.stream = preload("res://audio/bgm.ogg")
"""

    extractor = GodotMediaExtractor()
    refs = extractor._extract_from_source(test_gd, "Main.gd")
    print(f"Found {len(refs)} Godot media refs")
    for ref in refs:
        print(f"  {ref['kind']}: {ref['resolved_path']} (action={ref['action']})")
