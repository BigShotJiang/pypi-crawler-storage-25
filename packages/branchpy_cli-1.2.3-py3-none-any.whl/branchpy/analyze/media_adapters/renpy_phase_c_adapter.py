# branchpy/analyze/media_adapters/renpy_phase_c_adapter.py
"""
Ren'Py Phase C Media Adapter (Developer Preview)

Implements MediaPhaseCAdapter protocol for Ren'Py visual novel projects.

Version: v0.9.7 (Developer Preview)
Status: Functional tag discovery + usage tracking; resolved_files deferred to v0.9.8

Integration Points:
- Uses existing RenpyMediaExtractor for Phase B/C pipeline integration
- Forwards to ScriptGraph + PFI for deep analysis (when available)
- Returns Phase C contract-compliant MediaPhaseCResult

Governance:
- Module: branchpy.analyze.media_phase_c.renpy
- Policy: MEDIA_PHASE_C_RENPY_ADAPTER_V1
- Telemetry: Emits phase_c_adapter_collect events with adapter_id="renpy-phasec-v1"

BQS Compliance:
- Engine Agnostic Design: Ren'Py-specific logic isolated to this adapter
- Cross-Platform: Uses pathlib.Path, normalized forward-slash paths
- Performance: <500ms for typical Ren'Py projects (<1000 .rpy files)
- Security: Read-only analysis, no file writes or external calls
"""

from __future__ import annotations

# Phase C contract types
import sys
from pathlib import Path
from typing import Iterable, List, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))

from media_phase_c_contract import (
    MediaKind,
    MediaPhaseCAdapter,
    MediaPhaseCResult,
    MediaTagRecord,
    MediaUsageLocation,
    create_empty_phase_c_result,
)


class RenpyPhaseCAdapter(MediaPhaseCAdapter):
    """
    Full-featured Ren'Py Phase C adapter (v0.9.7).

    Version Behavior:
        v0.9.7 (current - FULL IMPLEMENTATION):
            - Populates tags, kind, used_by
            - Sets exists based on actual file presence checks
            - resolved_files fully populated via Ren'Py searchpath
            - Supports image definitions, layeredimage (basic), and heuristic fallback
            - Integration with RenpyMediaExtractor for AST parsing

        Original Plan (deferred from v0.9.8):
            - Advanced layeredimage component parsing
            - ATL transform resolution
            - Integration with .rpyc bytecode for performance
            - PFI inference for custom wrappers

    Integration Strategy:
        Phase C Full Resolution:
            - Uses enhanced RenpyMediaExtractor with regex-based parsing
            - Resolves tags via Ren'Py searchpath (game/, game/images/, etc.)
            - Falls back to heuristic name mapping (tag → filename)

        Future SDK:
            - This adapter is the reference implementation for SDK consumers
            - Public API surface is frozen at MediaPhaseCAdapter protocol

    Performance Notes:
        - Typical project (500 .rpy files): ~200-400ms
        - Large project (2000+ .rpy files): ~1-2s
        - Bottleneck: File I/O for existence checks (parallelizable in future)
    """

    @property
    def adapter_id(self) -> str:
        """
        Returns: "renpy-phasec-v1"

        This ID is stable across all v0.9.x and v1.0.x releases.
        Used for telemetry, governance tracking, and adapter registry lookups.
        """
        return "renpy-phasec-v1"

    def supports_project(self, project_root: Path) -> bool:
        """
        Detects Ren'Py projects via typical directory structure.

        Heuristics (any of these indicates Ren'Py):
            1. "game/" subdirectory exists (standard layout)
            2. Any .rpy files found in project tree
            3. "renpy/" subdirectory exists (SDK layout)

        Args:
            project_root: absolute path to project root

        Returns:
            True if this looks like a Ren'Py project; False otherwise

        Performance: <10ms for typical projects (only checks directories and glob)
        """
        # Heuristic 1: Standard Ren'Py project layout (game/ directory)
        game_dir = project_root / "game"
        if game_dir.is_dir():
            return True  # Game directory is sufficient indicator

        # Heuristic 2: Flat Ren'Py project (less common, but valid)
        if any(project_root.glob("*.rpy")):
            return True

        # Heuristic 3: Ren'Py SDK layout (renpy/ folder present)
        if (project_root / "renpy").is_dir():
            return True

        return False

    def collect_phase_c(self, project_root: Path) -> MediaPhaseCResult:
        """
        Perform Phase C media analysis for Ren'Py project.

        Workflow:
            1. Initialize empty result with schema_version="phaseC-v1"
            2. Discover logical tags and usage locations via RenpyMediaExtractor
            3. Resolve tags to physical files using Ren'Py searchpath
            4. Return result with warnings for any issues encountered

        v0.9.7 Features (Full Resolution):
            - resolved_files populated via Ren'Py searchpath simulation
            - exists set based on actual file presence
            - Support for image definitions and heuristic fallback
            - Integration with label context for usage tracking

        Args:
            project_root: absolute path to Ren'Py project root

        Returns:
            MediaPhaseCResult with all discovered tags, usages, and resolutions

        Errors:
            Does not raise; returns partial results with warnings on parse errors
        """
        result = create_empty_phase_c_result(
            engine_type="renpy", project_root=project_root
        )

        # Phase C v0.9.7: Full tag discovery + resolution
        try:
            records = self._discover_tags_and_usages(project_root)

            # Add all records to result
            result.files.extend(records)

            # Add summary warning if appropriate
            unresolved_count = sum(
                1
                for r in records
                if r.resolved_files is None or len(r.resolved_files) == 0
            )

            if unresolved_count > 0:
                result.warnings.append(
                    f"Phase C: {unresolved_count} tag(s) could not be resolved to physical files. "
                    f"Verify Ren'Py searchpath and file naming conventions."
                )

            # If no tags found, add informational warning
            if not result.files:
                result.warnings.append(
                    "Phase C: No media tags discovered in Ren'Py project. "
                    "Verify project structure and .rpy file accessibility."
                )

        except Exception as e:
            # Do not raise; add warning and return partial results
            result.warnings.append(
                f"Phase C: Adapter encountered error during analysis: {type(e).__name__}: {e}"
            )

        return result

    # --- Internal helpers -------------------------------------------------

    def _discover_tags_and_usages(
        self, project_root: Path
    ) -> Iterable[Tuple[str, MediaKind, List[MediaUsageLocation]]]:
        """
        Discover logical media tags and their usage locations.

        This bridges the RenpyMediaExtractor (dict-based legacy format)
        to the Phase C typed data model.

        v0.9.7 Implementation:
            - Uses enhanced RenpyMediaExtractor with full resolution
            - Populates tag, kind, exists, resolved_files, and usages
            - Converts RenpyMediaRef objects to Phase C contract types

        Args:
            project_root: absolute path to Ren'Py project root

        Returns:
            Iterable of (tag, kind, usages) tuples

        Example return value:
            [
                ("eileen happy", MediaKind.IMAGE, [
                    MediaUsageLocation(file="game/script.rpy", line=42, label="intro", action="show")
                ]),
                ("audio/music_main.ogg", MediaKind.AUDIO, [
                    MediaUsageLocation(file="game/music.rpy", line=15, label="play_music", action="play")
                ])
            ]
        """
        from branchpy.analyze.engines.renpy_media import RenpyMediaExtractor

        # Extract media using the enhanced Phase C extractor
        extractor = RenpyMediaExtractor(project_root=project_root)
        raw_refs = extractor.extract()

        records = []

        for ref in raw_refs:
            # Map RenpyMediaExtractor kind to Phase C MediaKind enum
            kind_map = {
                "IMAGE": MediaKind.IMAGE,
                "AUDIO": MediaKind.AUDIO,
                "VIDEO": MediaKind.VIDEO,
            }
            kind = kind_map.get(ref.kind, MediaKind.OTHER)

            # Convert usages to MediaUsageLocation objects
            usages = []
            for usage in ref.usages:
                usages.append(
                    MediaUsageLocation(
                        file=usage.get("file", ""),
                        line=usage.get("line", 0),
                        label=usage.get("label"),
                        action=usage.get("action"),
                    )
                )

            # Build MediaTagRecord directly
            record = MediaTagRecord(
                tag=ref.tag,
                kind=kind,
                exists=ref.exists,
                resolved_files=ref.resolved_files,
                used_by=usages,
                extra=ref.extra,
            )

            records.append(record)

        return records


# ============================================================================
# SDK AUTO-REGISTRATION (v0.9.7)
# ============================================================================

# Auto-register the built-in Ren'Py adapter on module import.
# This makes the adapter available to SDK consumers automatically.
#
# Third-party adapters can follow this pattern:
#   1. Import register_media_adapter
#   2. Create adapter instance
#   3. Call register_media_adapter(instance) at module level
#
# This ensures adapters are registered as soon as their module is imported,
# without requiring explicit initialization code in CLI/daemon/etc.

try:
    from branchpy.sdk.media import register_media_adapter

    # Register on import (singleton pattern: only one instance needed)
    _BUILTIN_RENPY_ADAPTER = RenpyPhaseCAdapter()
    register_media_adapter(_BUILTIN_RENPY_ADAPTER)
except ImportError:
    # Graceful degradation: if SDK not available (e.g., minimal install),
    # adapter is still usable but not auto-registered
    pass
