"""
Unity Media Extractor (v0.9.0.2)

Extracts media references from Unity C# scripts.
Detects: Resources.Load, Addressables, AudioSource, VideoPlayer, UI.Image.
"""

import re
from pathlib import Path
from typing import Any, Dict, List


class UnityMediaExtractor:
    """Extract media references from Unity C# code."""

    # C# patterns for media loading
    PATTERNS = {
        # Resources.Load variants
        r'Resources\.Load<([^>]+)>\s*\(\s*["\']([^"\']+)["\']': (
            "load",
            "Resources.Load",
        ),
        r'Resources\.LoadAsync\s*\(\s*["\']([^"\']+)["\']': (
            "load",
            "Resources.LoadAsync",
        ),
        # Addressables
        r'Addressables\.LoadAssetAsync<([^>]+)>\s*\(\s*["\']([^"\']+)["\']': (
            "load",
            "Addressables",
        ),
        # AudioSource
        r'AudioSource\.PlayClipAtPoint\s*\(\s*[^,]+,\s*["\']([^"\']+)["\']': (
            "play",
            "AudioSource.PlayClipAtPoint",
        ),
        r'\.PlayOneShot\s*\(\s*[^,]+,\s*["\']([^"\']+)["\']': (
            "play",
            "AudioSource.PlayOneShot",
        ),
        # UI.Image sprite assignment
        r'\.sprite\s*=\s*Resources\.Load<Sprite>\s*\(\s*["\']([^"\']+)["\']': (
            "assign",
            "UI.Image.sprite",
        ),
        # VideoPlayer
        r'\.url\s*=\s*["\']([^"\']+)["\']': ("load", "VideoPlayer.url"),
    }

    def extract(self, project_root: Path) -> List[Dict[str, Any]]:
        """
        Extract media references from Unity project.

        Args:
            project_root: Path to Unity project root

        Returns:
            List of MediaRef dicts
        """
        refs = []

        # Find all .cs files in Assets/
        assets_dir = project_root / "Assets"
        if not assets_dir.exists():
            return refs

        for cs_file in assets_dir.rglob("*.cs"):
            try:
                source = cs_file.read_text(encoding="utf-8")
                file_refs = self._extract_from_source(
                    source, str(cs_file.relative_to(project_root))
                )
                refs.extend(file_refs)
            except Exception:
                continue

        return refs

    def _extract_from_source(
        self, source: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract media refs from C# source code."""
        refs = []

        for pattern, (action, api) in self.PATTERNS.items():
            for match in re.finditer(pattern, source):
                # Get line number
                line_num = source[: match.start()].count("\n") + 1

                # Extract path from match groups
                groups = match.groups()
                path = groups[-1]  # Last group is usually the path

                # Determine kind from extension or API
                kind = self._infer_kind(path, api)

                refs.append(
                    {
                        "id": f"unity_{source_file}_{line_num}_{path}",
                        "engine": "unity",
                        "kind": kind,
                        "action": action,
                        "channel": None,
                        "target": api,
                        "source_file": source_file,
                        "source_line": line_num,
                        "label": None,  # C# doesn't have Ren'Py-style labels
                        "resolved_path": path,
                        "template_path": None,
                        "variables": [],
                        "via_function": None,
                        "confidence": "exact",
                    }
                )

        return refs

    def _infer_kind(self, path: str, api: str) -> str:
        """Infer media kind from path extension or API."""
        path_lower = path.lower()

        if any(path_lower.endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".webp"]):
            return "image"
        if any(path_lower.endswith(ext) for ext in [".ogg", ".mp3", ".wav"]):
            return "audio"
        if any(path_lower.endswith(ext) for ext in [".mp4", ".webm"]):
            return "video"

        # Infer from API
        if "Audio" in api:
            return "audio"
        if "Video" in api:
            return "video"
        if "Sprite" in api or "Image" in api:
            return "image"

        return "other"


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    test_cs = """
public class GameManager : MonoBehaviour {
    void Start() {
        var bg = Resources.Load<Sprite>("Backgrounds/cafe");
        AudioSource.PlayClipAtPoint(null, "Sounds/bgm.ogg");
        image.sprite = Resources.Load<Sprite>("Characters/alice_happy.png");
    }
}
"""

    extractor = UnityMediaExtractor()
    refs = extractor._extract_from_source(test_cs, "GameManager.cs")
    print(f"Found {len(refs)} Unity media refs")
    for ref in refs:
        print(f"  {ref['kind']}: {ref['resolved_path']} (action={ref['action']})")
