import logging
import time
from enum import StrEnum
from typing import Optional

import jose
from jose import jwt

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import RedirectResponse

from ..base import BaseParams

logger = logging.getLogger(__name__)


class DecodedToken:
    def __init__(self, token: str):
        logger.debug(f"Start decode token: {token[:10]}")
        decoded = jwt.decode(token, options={"verify_signature": False}, key='')
        
        self.subject: dict[str, str | int] = decoded['subject']
        self.user_id: int = self.subject['user_id']
        self.exp: int = decoded['exp']
    
    def is_expired(self) -> bool:
        token_expired = self.exp
        now = time.time()
        
        if token_expired and token_expired < now:
            logger.warning(f"Токен просрочен. Exp: {token_expired}, Now: {now}")
            return True
        else:
            logger.debug("Токен действителен")
            return False


class Style(StrEnum):
    AUTH_REQUIRED = 'auth_required'
    TOKEN_EXPIRED = 'token_expired'


class RedirectPath(StrEnum):
    LOGIN = 'login'
    FORBIDDEN = 'forbidden'


class RedirectUrlToAuthWebClient:
    
    def __init__(self, token: Optional[str], to: RedirectPath, redirect_from: str, redirect_to: str):
        self.token = token
        
        self.redirect_from = redirect_from
        self.redirect_to = redirect_to
        
        if token:
            self.url = self.redirect_url(self.check_token(token), to)
        else:
            logger.debug(f"Token is None. Redirect to {redirect_to}/{to}")
            self.url = self.redirect_url(Style.AUTH_REQUIRED, to)
    
    def redirect_url(self, style_str: Style, to: RedirectPath) -> str:
        redirect_url = f'{self.redirect_to}/{to}?redirect_to={self.redirect_from}&style={style_str}'
        
        logger.debug(f"Generated redirect URL: {redirect_url}")
        return redirect_url
    
    @staticmethod
    def check_token(token: str) -> Style:
        logger.debug("Проверяем токен")
        try:
            decoded_token = DecodedToken(token)
        except jose.exceptions.ExpiredSignatureError:
            logger.warning("Токен просрочен")
            return Style.TOKEN_EXPIRED
        except jose.exceptions.JWTError:
            logger.warning("Невалидный токен")
            return Style.AUTH_REQUIRED
        
        if decoded_token.is_expired():
            logger.warning("Токен просрочен")
            return Style.TOKEN_EXPIRED
        
        logger.warning("Токен действителен, но AUTH_REQUIRED, так как, скорее всего, клиент не авторизован")
        return Style.AUTH_REQUIRED


class AuthMiddleware(BaseHTTPMiddleware, BaseParams):
    """This middleware restricts access to all NiceGUI pages.

    It redirects the user to the login page if they are not authenticated.
    """
    
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        
        except tuple(self.unauthorized_exception_classes):
            logger.info(
                f"Ошибка авторизации на запросе: {request.method} {request.url.path}"
            )
            # token = storage.redis(db=self.redis).token.access.get()
            token = None # TODO: без токена будет всегда выводится сообщение, о том, что "Требуется авторизация", не важно, закончился ли он или нет
            return RedirectResponse(
                url=RedirectUrlToAuthWebClient(
                    token=token,
                    to=RedirectPath.LOGIN,
                    redirect_from=self.redirect_from,
                    redirect_to=self.redirect_to,
                ).url
            )
        
        except tuple(self.forbidden_exception_classes):
            return RedirectResponse(
                url=RedirectUrlToAuthWebClient(
                    token=None,
                    to=RedirectPath.FORBIDDEN,
                    redirect_from=self.redirect_from,
                    redirect_to=self.redirect_to,
                ).url
            )