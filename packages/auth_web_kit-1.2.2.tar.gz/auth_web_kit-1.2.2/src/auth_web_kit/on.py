from nicegui import ui

from .auth.middleware import RedirectUrlToAuthWebClient, RedirectPath
from .base import BaseParams


class On(BaseParams):
    
    @classmethod
    def unknown_error(cls, exception: Exception):
        if isinstance(exception, Exception):
            ui.notify("Что-то пошло не так", type="negative")
    
    @classmethod
    def unauthorized(cls, exception: Exception):
        if isinstance(exception, *cls.unauthorized_exception_classes):
            if exception.status == 401:
                try:
                    # token = storage.redis(db=self.redis).token.access.get()
                    token = None  # TODO: без токена будет всегда выводится сообщение, о том, что "Требуется авторизация", не важно, закончился ли он или нет
                    ui.navigate.to(RedirectUrlToAuthWebClient(
                        token=token,
                        to=RedirectPath.LOGIN,
                        redirect_from=cls.redirect_from,
                        redirect_to=cls.redirect_to,
                    ).url)
                except RuntimeError:
                    pass
        if isinstance(exception, *cls.forbidden_exception_classes):
            try:
                ui.navigate.to(RedirectPath.FORBIDDEN)
            except RuntimeError:
                pass