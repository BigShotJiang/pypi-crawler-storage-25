from typing import Optional, TypeVar, Generic

import redis as redis_lib

T = TypeVar('T')

class RedisStringSchema(Generic[T]):
    def __init__(self, key: str, redis: redis_lib.Redis, browser_id: str):
        self.key = f'{browser_id}:{key}'
        self.redis = redis
    
    def set(self, value: T) -> None:
        self.redis.set(self.key, value)
    
    def get(self) -> Optional[T]:
        return self.redis.get(self.key)
    
    def delete(self) -> None:
        self.redis.delete(self.key)


class RedisListSchema(Generic[T]):
    def __init__(self, key: str, redis: redis_lib.Redis, browser_id: str):
        self.key = f'{browser_id}:{key}'
        self.redis = redis
    
    def add(self, value: T) -> None:
        self.redis.rpush(self.key, value)
    
    def extend(self, values: list[T]) -> None:
        self.redis.rpush(self.key, *values)
    
    def get(self) -> list[T]:
        return self.redis.lrange(self.key, 0, -1)
    
    def delete(self) -> None:
        self.redis.delete(self.key)