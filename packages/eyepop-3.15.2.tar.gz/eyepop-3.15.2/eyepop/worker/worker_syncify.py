import logging
import typing

from eyepop.data.types.asset import Area
from eyepop.syncify import SyncEndpoint, run_coro_thread_save
from eyepop.worker.worker_jobs import WorkerJob
from eyepop.worker.worker_types import ComponentParams, MotionDetectConfig, Pop, VideoMode

if typing.TYPE_CHECKING:
    from eyepop.worker.worker_endpoint import WorkerEndpoint

log = logging.getLogger(__name__)


class SyncWorkerJob:
    def __init__(self, job: WorkerJob, event_loop):
        self.job = job
        self.event_loop = event_loop

    def predict(self) -> dict:
        prediction = run_coro_thread_save(self.event_loop, self.job.predict())
        return prediction

    def cancel(self):
        run_coro_thread_save(self.event_loop, self.job.cancel())


class SyncWorkerEndpoint(SyncEndpoint):
    def __init__(self, endpoint: "WorkerEndpoint"):
        super().__init__(endpoint)

    def upload(
            self,
            location: str,
            video_mode: VideoMode | None = None,
            params: list[ComponentParams] | None = None,
            motion_detect: MotionDetectConfig | None = None,
            roi: Area | None = None,
            fps: str | None = None,
            media_cache_seconds: int | None = None,
            on_ready: typing.Callable[[WorkerJob], None] | None = None
    ) -> SyncWorkerJob:
        if on_ready is not None:
            raise TypeError(
                "'on_ready' callback not supported for sync endpoints. "
                "Use 'EyePopSdk.workerEndpoint(is_async=True)` to create an async endpoint with callback support")
        job = run_coro_thread_save(self.event_loop, self.endpoint.upload(
            location=location,
            video_mode=video_mode,
            params=params,
            motion_detect=motion_detect,
            roi=roi,
            fps=fps,
            media_cache_seconds=media_cache_seconds,
            on_ready=None
        ))
        return SyncWorkerJob(job, self.event_loop)

    def upload_stream(
            self,
            stream: typing.BinaryIO,
            mime_type: str,
            video_mode: VideoMode | None = None,
            params: list[ComponentParams] | None = None,
            motion_detect: MotionDetectConfig | None = None,
            roi: Area | None = None,
            fps: str | None = None,
            media_cache_seconds: int | None = None,
            on_ready: typing.Callable[[WorkerJob], None] | None = None
    ) -> SyncWorkerJob:
        if on_ready is not None:
            raise TypeError(
                "'on_ready' callback not supported for sync endpoints. "
                "Use 'EyePopSdk.workerEndpoint(is_async=True)` to create an async endpoint with callback support")
        job = run_coro_thread_save(self.event_loop, self.endpoint.upload_stream(
            stream=stream,
            mime_type=mime_type,
            video_mode=video_mode,
            params=params,
            motion_detect=motion_detect,
            roi=roi,
            fps=fps,
            media_cache_seconds=media_cache_seconds,
            on_ready=None
        ))
        return SyncWorkerJob(job, self.event_loop)

    def load_from(
            self,
            location: str,
            params: list[ComponentParams] | None = None,
            motion_detect: MotionDetectConfig | None = None,
            roi: Area | None = None,
            fps: str | None = None,
            media_cache_seconds: int | None = None,
            on_ready: typing.Callable[[WorkerJob], None] | None = None
    ) -> SyncWorkerJob:
        if on_ready is not None:
            raise TypeError(
                "'on_ready' callback not supported for sync endpoints. "
                "Use 'EyePopSdk.workerEndpoint(is_async=True)` to create an async endpoint with callback support")
        job = run_coro_thread_save(self.event_loop, self.endpoint.load_from(
            location=location,
            params=params,
            motion_detect=motion_detect,
            roi=roi,
            fps=fps,
            media_cache_seconds=media_cache_seconds,
            on_ready=None
        ))
        return SyncWorkerJob(job, self.event_loop)

    def load_asset(
            self,
            asset_uuid: str,
            params: list[ComponentParams] | None = None,
            motion_detect: MotionDetectConfig | None = None,
            roi: Area | None = None,
            fps: str | None = None,
            media_cache_seconds: int | None = None,
            on_ready: typing.Callable[[WorkerJob], None] | None = None
    ) -> SyncWorkerJob:
        if on_ready is not None:
            raise TypeError(
                "'on_ready' callback not supported for sync endpoints. "
                "Use 'EyePopSdk.workerEndpoint(is_async=True)` to create an async endpoint with callback support")
        job = run_coro_thread_save(self.event_loop, self.endpoint.load_asset(
            asset_uuid=asset_uuid,
            params=params,
            motion_detect=motion_detect,
            roi=roi,
            fps=fps,
            media_cache_seconds=media_cache_seconds,
            on_ready=None
        ))
        return SyncWorkerJob(job, self.event_loop)

    def get_pop(self) -> Pop | None:
        return run_coro_thread_save(self.event_loop, self.endpoint.get_pop())

    def set_pop(self, pop: Pop) -> dict:
        return run_coro_thread_save(self.event_loop, self.endpoint.set_pop(pop))


