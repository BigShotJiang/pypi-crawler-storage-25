"""Tests for parser/LLM registries, plugins, backend options, and provider detection."""
import asyncio
import os
import textwrap
from pathlib import Path
from unittest.mock import (
    MagicMock, patch,
)

import pytest

from petey import extract_text_pages

FIXTURES = Path(__file__).parent / "fixtures"
MCI_PDF = FIXTURES / "mci_page1.pdf"


class TestRegistries:
    """Verify all expected backends appear in the registries."""

    def test_parser_registry_has_local_backends(self):
        from petey.extract import PARSERS
        for name in ["pymupdf", "pdfplumber"]:
            assert name in PARSERS, f"Missing parser: {name}"

    def test_parser_registry_has_api_backends(self):
        from petey.extract import PARSERS
        assert "datalab" in PARSERS

    def test_parser_registry_has_plugin_backends(self):
        from petey.extract import PARSERS
        assert "docling" in PARSERS

    def test_llm_registry_has_builtins(self):
        from petey.extract import LLM_BACKENDS
        for name in [
            "openai", "azure_openai", "anthropic",
            "ollama", "gemini",
            "anthropic_bedrock", "anthropic_vertex", "vertex_ai",
            "litellm",
        ]:
            assert name in LLM_BACKENDS, f"Missing LLM: {name}"

    def test_llm_registry_has_api_backends(self):
        """Config-only OpenAI-compat providers should be live."""
        from petey.extract import LLM_BACKENDS
        for name in [
            "deepseek", "mistral", "together",
            "openrouter", "fireworks", "groq",
        ]:
            assert name in LLM_BACKENDS, f"Missing API backend: {name}"

    def test_api_parsers_config_valid(self):
        from petey.extract import API_PARSERS
        for name, cfg in API_PARSERS.items():
            has_endpoint = "endpoint" in cfg or "endpoint_env" in cfg
            assert has_endpoint, f"{name} missing endpoint/endpoint_env"
            assert "api_key_env" in cfg, f"{name} missing api_key_env"

    def test_api_parsers_are_callable(self):
        from petey.extract import PARSERS
        for name in ["datalab"]:
            assert callable(PARSERS[name])

    def test_local_parsers_are_sync(self):
        from petey.extract import PARSERS
        for name in ["pymupdf", "pdfplumber"]:
            assert not asyncio.iscoroutinefunction(
                PARSERS[name]
            ), f"Parser '{name}' should be sync"

    def test_api_parsers_are_async(self):
        from petey.extract import PARSERS, API_PARSERS
        for name in API_PARSERS:
            assert asyncio.iscoroutinefunction(
                PARSERS[name]
            ), f"Parser '{name}' should be async"

    def test_datalab_uses_correct_endpoint(self):
        from petey.extract import API_PARSERS
        assert "datalab" in API_PARSERS
        assert "datalab.to" in API_PARSERS["datalab"]["endpoint"]

    def test_datalab_has_marker_alias(self):
        """Backwards-compat: 'marker' should still resolve to datalab."""
        from petey.extract import PARSERS
        assert "marker" in PARSERS
        assert PARSERS["marker"] is PARSERS["datalab"]


class TestLLMBackendConfig:
    """Test config-driven LLM backend registration."""

    def test_api_llm_backend_creates_openai_client(self):
        from petey.extract import _make_api_llm_client
        with patch.dict(os.environ, {"TEST_LLM_KEY": "k"}):
            with patch("petey.extract.AsyncOpenAI") as mock_oai:
                with patch("petey.extract.instructor") as mock_inst:
                    mock_inst.from_openai.return_value = "client"
                    result = _make_api_llm_client(
                        client="openai",
                        api_key_env="TEST_LLM_KEY",
                        base_url="https://my-host.com/v1",
                    )
        assert result == "client"
        mock_oai.assert_called_once_with(
            api_key="k", base_url="https://my-host.com/v1")

    def test_api_llm_backend_unknown_client_type(self):
        from petey.extract import _make_api_llm_client
        with pytest.raises(ValueError, match="Unknown LLM client"):
            _make_api_llm_client(client="buttllm")

    def test_api_llm_backends_are_live(self):
        """Mutating API_LLM_BACKENDS at runtime should be visible
        to LLM_BACKENDS lookups (no module reload required)."""
        from petey.extract import API_LLM_BACKENDS, LLM_BACKENDS
        assert "ephemeral-test-backend" not in LLM_BACKENDS
        try:
            API_LLM_BACKENDS["ephemeral-test-backend"] = {
                "client": "openai",
                "api_key_env": "NONEXISTENT_KEY",
            }
            assert "ephemeral-test-backend" in LLM_BACKENDS
            assert LLM_BACKENDS.get(
                "ephemeral-test-backend",
            ) is not None
        finally:
            del API_LLM_BACKENDS["ephemeral-test-backend"]
        assert "ephemeral-test-backend" not in LLM_BACKENDS


class TestModelsRegistryConfig:
    """Models with a ``config`` dict should pass it to the builder."""

    def test_config_from_model_entry_reaches_builder(self):
        from petey.extract import MODELS, _make_client
        MODELS["_t_azure"] = {
            "provider": "azure_openai",
            "config": {
                "api_version": "2024-06-01",
                "azure_endpoint": "https://example.azure.test",
                "api_key_env": "T_AZURE_KEY",
            },
        }
        try:
            with patch.dict(os.environ, {"T_AZURE_KEY": "secret"}):
                with patch(
                    "petey.extract.AsyncAzureOpenAI",
                ) as mock_az:
                    with patch(
                        "petey.extract.instructor",
                    ) as mock_inst:
                        mock_inst.from_openai.return_value = "cli"
                        _make_client("_t_azure")
            mock_az.assert_called_once_with(
                api_key="secret",
                api_version="2024-06-01",
                azure_endpoint="https://example.azure.test",
            )
        finally:
            del MODELS["_t_azure"]

    def test_api_model_alias(self):
        """``model`` field in MODELS entry should override the key
        as the identifier sent to the API."""
        from petey.extract import MODELS, _resolve_api_model
        MODELS["_alias_test"] = {
            "provider": "azure_openai",
            "model": "actual-deployment-name",
            "config": {},
        }
        try:
            assert _resolve_api_model(
                "_alias_test",
            ) == "actual-deployment-name"
            assert _resolve_api_model(
                "unregistered-model",
            ) == "unregistered-model"
            assert _resolve_api_model("gpt-4.1-mini") == "gpt-4.1-mini"
        finally:
            del MODELS["_alias_test"]

    def test_two_tenants_same_provider_coexist(self):
        """Same provider (azure_openai), two different deployments,
        no env mutation between calls."""
        from petey.extract import MODELS, _make_client
        MODELS["_t_a"] = {
            "provider": "azure_openai",
            "config": {
                "api_version": "2024-06-01",
                "azure_endpoint": "https://a.azure.test",
                "api_key_env": "T_A_KEY",
            },
        }
        MODELS["_t_b"] = {
            "provider": "azure_openai",
            "config": {
                "api_version": "2024-10-21",
                "azure_endpoint": "https://b.azure.test",
                "api_key_env": "T_B_KEY",
            },
        }
        try:
            env = {"T_A_KEY": "ka", "T_B_KEY": "kb"}
            with patch.dict(os.environ, env):
                with patch(
                    "petey.extract.AsyncAzureOpenAI",
                ) as mock_az:
                    with patch(
                        "petey.extract.instructor",
                    ) as mock_inst:
                        mock_inst.from_openai.return_value = "cli"
                        _make_client("_t_a")
                        _make_client("_t_b")
            calls = mock_az.call_args_list
            assert calls[0].kwargs["api_key"] == "ka"
            assert calls[0].kwargs["azure_endpoint"] == "https://a.azure.test"
            assert calls[1].kwargs["api_key"] == "kb"
            assert calls[1].kwargs["azure_endpoint"] == "https://b.azure.test"
        finally:
            del MODELS["_t_a"]
            del MODELS["_t_b"]


class TestNewLLMBuilders:
    """Verify the direct-backend builders wire up correctly."""

    def test_ollama_builder_uses_localhost_default(self):
        from petey.extract import _make_client_ollama
        with patch("petey.extract.AsyncOpenAI") as mock_oai:
            with patch("petey.extract.instructor") as mock_inst:
                mock_inst.Mode.JSON = "Mode.JSON"
                mock_inst.from_openai.return_value = "client"
                _make_client_ollama()
        mock_oai.assert_called_once()
        kw = mock_oai.call_args.kwargs
        assert kw["base_url"] == "http://localhost:11434/v1"
        # OpenAI client requires non-empty api_key
        assert kw["api_key"]

    def test_ollama_builder_respects_base_url_kwarg(self):
        from petey.extract import _make_client_ollama
        with patch("petey.extract.AsyncOpenAI") as mock_oai:
            with patch("petey.extract.instructor") as mock_inst:
                mock_inst.from_openai.return_value = "client"
                _make_client_ollama(base_url="http://h:9999/v1")
        assert mock_oai.call_args.kwargs["base_url"] == "http://h:9999/v1"

    def test_qwen_alias_routes_to_ollama(self):
        from petey.extract import _get_provider, _resolve_api_model
        assert _get_provider("qwen3-4b") == "ollama"
        assert _resolve_api_model("qwen3-4b") == "qwen3:4b"

    def test_deepseek_via_api_backend(self):
        from petey.extract import _make_client
        with patch.dict(os.environ, {"DEEPSEEK_API_KEY": "k"}):
            with patch("petey.extract.AsyncOpenAI") as mock_oai:
                with patch("petey.extract.instructor") as mock_inst:
                    mock_inst.from_openai.return_value = "c"
                    _make_client("deepseek/deepseek-chat")
        kw = mock_oai.call_args.kwargs
        assert kw["api_key"] == "k"
        assert kw["base_url"] == "https://api.deepseek.com/v1"

    def test_anthropic_bedrock_builder_passes_aws_creds(self):
        from petey.extract import _make_client_anthropic_bedrock
        env = {
            "AWS_ACCESS_KEY_ID": "akid",
            "AWS_SECRET_ACCESS_KEY": "secret",
            "AWS_REGION": "us-west-2",
        }
        with patch.dict(os.environ, env, clear=False):
            with patch(
                "anthropic.AsyncAnthropicBedrock",
            ) as mock_b:
                with patch("petey.extract.instructor") as mock_inst:
                    mock_inst.from_anthropic.return_value = "c"
                    _make_client_anthropic_bedrock()
        kw = mock_b.call_args.kwargs
        assert kw["aws_access_key"] == "akid"
        assert kw["aws_secret_key"] == "secret"
        assert kw["aws_region"] == "us-west-2"

    def test_anthropic_vertex_builder_requires_project_and_region(self):
        from petey.extract import _make_client_anthropic_vertex
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="project_id"):
                _make_client_anthropic_vertex()


class TestPluginRegistries:
    """Test the PLUGIN_* registries and lazy loader."""

    def test_docling_in_plugin_parsers(self):
        from petey.extract import PLUGIN_PARSERS
        assert "docling" in PLUGIN_PARSERS
        assert "docling" in PLUGIN_PARSERS["docling"]

    def test_plugin_parsers_are_callable(self):
        from petey.extract import PARSERS, PLUGIN_PARSERS
        for name in PLUGIN_PARSERS:
            assert callable(
                PARSERS[name]
            ), f"Plugin parser '{name}' should be callable"


class TestPluginLoader:
    """Test the _make_plugin_loader lazy import mechanism."""

    def test_lazy_import_calls_function(self):
        from petey.extract import _make_plugin_loader
        loader = _make_plugin_loader("json:loads")
        result = loader('{"a": 1}')
        assert result == {"a": 1}

    def test_bad_module_raises_at_build(self):
        from petey.extract import _make_plugin_loader
        with pytest.raises(ModuleNotFoundError):
            _make_plugin_loader("nonexistent_module_xyz:func")

    def test_bad_attr_raises_at_build(self):
        from petey.extract import _make_plugin_loader
        with pytest.raises(AttributeError):
            _make_plugin_loader("json:nonexistent_function_xyz")


class TestBackendOptions:
    """Verify parser_options and ocr_options reach the callable."""

    def test_parser_options_passed(self):
        mock_fn = MagicMock(return_value=["page text"])
        with patch.dict(
            "petey.extract.PARSERS", {"mock": mock_fn},
        ):
            extract_text_pages(
                str(MCI_PDF), parser="mock",
                parser_options={"lang": "fr", "dpi": 300},
            )
        mock_fn.assert_called_once()
        _, kwargs = mock_fn.call_args
        assert kwargs["lang"] == "fr"
        assert kwargs["dpi"] == 300


class TestDirectPrefixRouting:
    """Provider prefixes that route to direct (non-litellm) backends."""

    def test_fireworks_routes_direct(self):
        from petey.extract import _get_provider
        assert _get_provider(
            "fireworks_ai/accounts/fireworks/models/llama-v3p3-70b-instruct"
        ) == "fireworks"

    def test_deepseek_routes_direct(self):
        from petey.extract import _get_provider
        assert _get_provider(
            "deepseek/deepseek-not-yet-registered",
        ) == "deepseek"

    def test_ollama_routes_direct(self):
        from petey.extract import _get_provider
        assert _get_provider("ollama/llama3") == "ollama"

    def test_gemini_routes_direct(self):
        from petey.extract import _get_provider
        assert _get_provider("gemini/gemini-2.0-flash") == "gemini"

    def test_direct_prefix_stripped_from_api_model(self):
        """For unregistered prefixed models, the prefix should be
        stripped before the wire call (the provider doesn't speak the
        Petey-side prefix)."""
        from petey.extract import _resolve_api_model
        assert _resolve_api_model(
            "deepseek/deepseek-not-yet-registered",
        ) == "deepseek-not-yet-registered"
        assert _resolve_api_model("ollama/llama3") == "llama3"


class TestLitellmRouting:
    def test_bedrock_routes_to_litellm(self):
        from petey.extract import _get_provider
        assert _get_provider(
            "bedrock/anthropic.claude-v2",
        ) == "litellm"

    def test_huggingface_routes_to_litellm(self):
        from petey.extract import _get_provider
        assert _get_provider("huggingface/some-model") == "litellm"


class TestProviderDetection:
    def test_openai_model(self):
        from petey.extract import _get_provider
        assert _get_provider("gpt-4.1-mini") == "openai"

    def test_anthropic_model(self):
        from petey.extract import _get_provider
        assert _get_provider("claude-sonnet-4-6") == "anthropic"

    def test_unknown_model_raises(self):
        from petey.extract import _get_provider
        with pytest.raises(ValueError, match="Unknown model"):
            _get_provider("some-other-model")

    def test_unknown_model_with_explicit_backend(self):
        from petey.extract import _get_provider
        assert _get_provider(
            "some-other-model", llm_backend="openai",
        ) == "openai"

    def test_azure_openai_requires_explicit_routing(self):
        from petey.extract import _get_provider
        assert _get_provider(
            "my-azure-deployment", llm_backend="azure_openai",
        ) == "azure_openai"

    def test_explicit_backend_override(self):
        from petey.extract import _get_provider
        assert _get_provider("gpt-4.1-mini", llm_backend="litellm") == "litellm"
        assert _get_provider("claude-sonnet-4-6", llm_backend="openai") == "openai"

    def test_litellm_client_created(self):
        """Long-tail providers still build a litellm client."""
        from petey.extract import _make_client
        client = _make_client("bedrock/anthropic.claude-v2")
        assert client is not None


class TestModelKwargs:
    def test_gpt4_returns_max_tokens_and_temperature(self):
        from petey.extract import _model_kwargs
        kw = _model_kwargs("gpt-4.1-mini")
        assert kw == {"max_tokens": 4096, "temperature": 0}

    def test_gpt5_returns_max_completion_tokens(self):
        from petey.extract import _model_kwargs
        kw = _model_kwargs("gpt-5-mini")
        assert kw == {"max_completion_tokens": 4096}
        assert "temperature" not in kw

    def test_gpt5_full(self):
        from petey.extract import _model_kwargs
        kw = _model_kwargs("gpt-5")
        assert "max_completion_tokens" in kw
        assert "max_tokens" not in kw

    def test_gpt54(self):
        from petey.extract import _model_kwargs
        kw = _model_kwargs("gpt-5.4-mini")
        assert kw == {"max_completion_tokens": 4096}

    def test_non_gpt_model(self):
        from petey.extract import _model_kwargs
        kw = _model_kwargs("claude-sonnet-4-6")
        assert kw == {"max_tokens": 4096, "temperature": 0}


class TestMakeMessages:
    def test_basic_messages(self):
        from petey.extract import _make_messages
        msgs = _make_messages("hello")
        assert len(msgs) == 2
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"
        assert "hello" in msgs[1]["content"]

    def test_instructions_appended(self):
        from petey.extract import _make_messages
        msgs = _make_messages("doc text", instructions="Be precise")
        assert "Be precise" in msgs[0]["content"]
        assert "Additional instructions" in msgs[0]["content"]

    def test_no_instructions(self):
        from petey.extract import _make_messages
        msgs = _make_messages("doc text")
        assert "Additional instructions" not in msgs[0]["content"]


class TestUserModelsConfig:
    """User-config YAML loader merges into MODELS at import time
    and via per-run overrides."""

    def _write_yaml(self, tmp_path, body: str) -> Path:
        p = tmp_path / "models.yaml"
        p.write_text(textwrap.dedent(body))
        return p

    def test_load_models_file_parses_entry(self, tmp_path):
        from petey.registries.models import load_models_file
        p = self._write_yaml(tmp_path, """\
            tenant-a-gpt-4o:
              provider: azure_openai
              model: gpt-4o
              config:
                api_version: "2024-06-01"
                azure_endpoint: https://a.azure.test
                api_key_env: TENANT_A_KEY
        """)
        data = load_models_file(p)
        assert "tenant-a-gpt-4o" in data
        entry = data["tenant-a-gpt-4o"]
        assert entry["provider"] == "azure_openai"
        assert entry["config"]["api_version"] == "2024-06-01"

    def test_load_models_file_rejects_non_mapping(self, tmp_path):
        from petey.registries.models import load_models_file
        p = self._write_yaml(tmp_path, "- just\n- a\n- list\n")
        with pytest.raises(ValueError, match="must be a YAML mapping"):
            load_models_file(p)

    def test_load_models_file_rejects_missing_provider(self, tmp_path):
        from petey.registries.models import load_models_file
        p = self._write_yaml(tmp_path, """\
            broken:
              model: foo
        """)
        with pytest.raises(ValueError, match="must be a dict with"):
            load_models_file(p)

    def test_register_models_overrides_builtin(self):
        from petey.registries.models import (
            MODELS, register_models, model_source,
        )
        original = dict(MODELS["gpt-4o"])
        try:
            register_models(
                {"gpt-4o": {"provider": "anthropic"}},
                source="test-override",
            )
            assert MODELS["gpt-4o"]["provider"] == "anthropic"
            assert model_source("gpt-4o") == "test-override"
        finally:
            MODELS["gpt-4o"] = original
            # Restore the source by re-registering as built-in
            register_models({"gpt-4o": original}, source="built-in")

    def test_register_models_tracks_source(self):
        from petey.registries.models import (
            MODELS, register_models, model_source,
        )
        try:
            register_models(
                {"_test_user_model": {"provider": "openai"}},
                source="/some/path/models.yaml",
            )
            assert "_test_user_model" in MODELS
            assert (
                model_source("_test_user_model")
                == "/some/path/models.yaml"
            )
        finally:
            del MODELS["_test_user_model"]

    def test_default_true_sets_default_model(self, tmp_path):
        import petey.registries.models as reg
        from petey.registries.models import (
            MODELS, load_models_file, register_models, default_model,
        )
        p = self._write_yaml(tmp_path, """\
            umgpt-gpt-4o:
              provider: azure_openai
              default: true
              model: gpt-4o
        """)
        prev = reg._DEFAULT_MODEL
        try:
            register_models(load_models_file(p), source=str(p))
            assert default_model() == "umgpt-gpt-4o"
            # `default` key is stripped from the stored entry
            assert "default" not in MODELS["umgpt-gpt-4o"]
        finally:
            reg._DEFAULT_MODEL = prev
            del MODELS["umgpt-gpt-4o"]

    def test_multiple_defaults_warns_and_keeps_first(self, tmp_path):
        import warnings
        import petey.registries.models as reg
        from petey.registries.models import (
            MODELS, load_models_file, register_models, default_model,
        )
        p = self._write_yaml(tmp_path, """\
            first-model:
              provider: openai
              default: true
            second-model:
              provider: openai
              default: true
        """)
        prev = reg._DEFAULT_MODEL
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                register_models(load_models_file(p), source=str(p))
            assert default_model() == "first-model"
            assert any(
                "multiple entries set 'default: true'" in str(w.message)
                for w in caught
            )
        finally:
            reg._DEFAULT_MODEL = prev
            del MODELS["first-model"]
            del MODELS["second-model"]

    def test_default_must_be_bool(self, tmp_path):
        from petey.registries.models import load_models_file
        p = self._write_yaml(tmp_path, """\
            broken:
              provider: openai
              default: "yes"
        """)
        with pytest.raises(ValueError, match="must be true or false"):
            load_models_file(p)

    def test_default_model_none_when_no_default(self):
        from petey.registries.models import default_model
        import petey.registries.models as reg
        prev = reg._DEFAULT_MODEL
        try:
            reg._DEFAULT_MODEL = None
            assert default_model() is None
        finally:
            reg._DEFAULT_MODEL = prev

    def test_user_models_path_respects_env_var(self, monkeypatch):
        from petey.registries.models import user_models_path
        monkeypatch.setenv("PETEY_MODELS", "/custom/path/m.yaml")
        assert str(user_models_path()) == "/custom/path/m.yaml"

    def test_user_models_path_default(self, monkeypatch):
        from petey.registries.models import (
            user_models_path, DEFAULT_USER_MODELS_PATH,
        )
        monkeypatch.delenv("PETEY_MODELS", raising=False)
        assert user_models_path() == DEFAULT_USER_MODELS_PATH

    def test_user_models_routed_via_make_client(self, tmp_path):
        """End-to-end: a user-config Azure entry should reach the
        Azure builder when _make_client is called by name."""
        from petey.registries.models import (
            MODELS, load_models_file, register_models,
        )
        from petey.extract import _make_client
        p = self._write_yaml(tmp_path, """\
            my-azure-deployment:
              provider: azure_openai
              model: gpt-4o
              config:
                api_version: "2024-06-01"
                azure_endpoint: https://my-tenant.azure.test
                api_key_env: MY_AZURE_KEY
        """)
        register_models(load_models_file(p), source=str(p))
        try:
            with patch.dict(os.environ, {"MY_AZURE_KEY": "k"}):
                with patch(
                    "petey.extract.AsyncAzureOpenAI",
                ) as mock_az:
                    with patch(
                        "petey.extract.instructor",
                    ) as mock_inst:
                        mock_inst.from_openai.return_value = "cli"
                        _make_client("my-azure-deployment")
            mock_az.assert_called_once()
            kw = mock_az.call_args.kwargs
            assert kw["api_key"] == "k"
            assert kw["api_version"] == "2024-06-01"
            assert kw["azure_endpoint"] == "https://my-tenant.azure.test"
        finally:
            del MODELS["my-azure-deployment"]
