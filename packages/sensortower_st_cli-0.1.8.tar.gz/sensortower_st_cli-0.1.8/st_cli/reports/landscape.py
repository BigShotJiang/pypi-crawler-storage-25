"""Render competitive landscape markdown from structured JSON data."""

from __future__ import annotations

import html
import re
from datetime import date, datetime
from typing import Any


def _normalize_text(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _money_compact_usd(v: float | None) -> str:
    if v is None:
        return "N/A"
    n = float(v)
    if n >= 1_000_000_000:
        return f"${n / 1_000_000_000:.2f}B"
    if n >= 1_000_000:
        return f"${n / 1_000_000:.2f}M"
    if n >= 1_000:
        return f"${n / 1_000:.2f}K"
    return f"${n:.0f}"


def _compact_count(v: float | int | None) -> str:
    if v is None:
        return "N/A"
    try:
        n = int(round(float(v)))
    except (TypeError, ValueError):
        return "N/A"
    return f"{n:,}"


def _format_share_percent(v: float | None) -> str:
    """Format market share as a percentage with 2 decimals.

    Backward-compat: some payloads may provide `share_percent` as a ratio (0~1).
    In that case we convert it to percent for display.
    """

    if v is None:
        return "N/A"
    try:
        n = float(v)
    except (TypeError, ValueError):
        return "N/A"

    if n <= 1.0:
        n *= 100.0
    return f"{n:.2f}%"


def _clip_sentence(text: str, max_len: int = 200) -> str:
    s = " ".join(text.split())
    if len(s) <= max_len:
        return s
    return s[: max_len - 1].rstrip() + "…"


def _clean_snippet(text: str) -> str:
    s = html.unescape(_normalize_text(text))
    s = re.sub(r"<[^>]+>", " ", s)
    return _clip_sentence(s, 220)


def _parse_iso_date(v: Any) -> date | None:
    s = _normalize_text(v)
    if not s:
        return None
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s).date()
    except ValueError:
        return None


def _format_date(v: date | None) -> str:
    return v.isoformat() if v else "N/A"


def _sparkline(values: list[float]) -> str:
    if not values:
        return ""
    vmin = min(values)
    vmax = max(values)
    levels = " .:-=+*#%@"
    if vmax == vmin:
        return levels[len(levels) // 2] * len(values)
    span = vmax - vmin
    last_idx = len(levels) - 1
    chars: list[str] = []
    for v in values:
        idx = int((v - vmin) / span * last_idx)
        idx = max(0, min(last_idx, idx))
        chars.append(levels[idx])
    return "".join(chars)


def _ai_powered_label(ai_label: str) -> str:
    if ai_label == "AI-enabled":
        return "Yes"
    if ai_label == "No AI features":
        return "No"
    return "Unclear"


def render_landscape_report_md(*, source: dict[str, Any], competitors: list[dict[str, Any]]) -> str:
    """Render markdown report for `st landscape --out`.

    Args:
        source: `data.source` object from `st landscape` JSON.
        competitors: `data.competitors` array from `st landscape` JSON.
    """
    month = _normalize_text(source.get("month"))
    as_of = _normalize_text(source.get("as_of"))
    regions = source.get("facet_regions", [])
    regions_str = (
        "global"
        if isinstance(regions, list) and len(regions) > 20
        else ", ".join(str(r) for r in (regions or []))
    )

    ranked: list[tuple[float | None, dict[str, Any]]] = []
    for it in competitors:
        st = it.get("st") if isinstance(it, dict) else None
        rev = None
        if isinstance(st, dict):
            v = st.get("revenue_last_month_usd")
            if isinstance(v, (int, float)):
                rev = float(v)
        ranked.append((rev, it))
    ranked.sort(key=lambda x: (x[0] is None, -(x[0] or 0.0)))

    def _key_point(points: list[str]) -> str:
        if not points:
            return "N/A"
        p = points[0]
        for prefix in ("Reddit:", "App store (sample):"):
            if p.startswith(prefix):
                p = p[len(prefix) :].strip()
        return _clip_sentence(p, 120)

    lines: list[str] = []
    lines.append(f"# Competitive Landscape — {month} Mobile Revenue (Global, as-of {as_of})")
    lines.append("")
    lines.append("## Overview")
    lines.append("")
    lines.append(f"- **As-of window**: {month} (as-of {as_of})")
    lines.append(f"- **Regions**: {regions_str}")
    lines.append("")
    lines.append("### Competitive Landscape")
    lines.append("")
    lines.append(
        "| # | Product | B2B/B2C | AI-Powered | "
            f"{month} Revenue | Trailing 12M Revenue | 6M Growth | First Release | Key Strength | Key Weakness |"
    )
    lines.append("|---:|---|---|---|---|---|---|---|---|---|")

    computed: list[dict[str, Any]] = []
    for idx, (rev, it) in enumerate(ranked, start=1):
        name = _normalize_text(it.get("name"))
        st = it.get("st") if isinstance(it.get("st"), dict) else {}
        err = it.get("error")
        selected = st.get("selected") if isinstance(st.get("selected"), dict) else None
        comments = st.get("comments") if isinstance(st.get("comments"), list) else []

        product_cell = name
        if err:
            product_cell = f"{name} (fetch failed)"

        lines.append(
            "| "
            + " | ".join(
                [
                    str(idx),
                    product_cell,
                    _normalize_text(it.get("segment")),
                    _ai_powered_label(_normalize_text(it.get("ai_label"))),
                    _money_compact_usd(rev),
                    _money_compact_usd(
                        float(st.get("revenue_trailing_12_months_usd"))
                        if isinstance(st.get("revenue_trailing_12_months_usd"), (int, float))
                        else None
                    ),
                    _normalize_text(it.get("growth_6m_label")),
                    _format_date(_parse_iso_date(_normalize_text(st.get("first_release_date_us")))),
                    _key_point(it.get("strengths") if isinstance(it.get("strengths"), list) else []),
                    _key_point(it.get("weaknesses") if isinstance(it.get("weaknesses"), list) else []),
                ]
            )
            + " |"
        )

        computed.append(
            {
                "idx": idx,
                "name": name,
                "rev": rev,
                "selected": selected,
                "comments": comments,
                "monthly_estimates": st.get("monthly_estimates", []) if isinstance(st, dict) else [],
                "strengths": it.get("strengths") if isinstance(it.get("strengths"), list) else [],
                "weaknesses": it.get("weaknesses") if isinstance(it.get("weaknesses"), list) else [],
                "ai_label": _normalize_text(it.get("ai_label")),
                "segment": _normalize_text(it.get("segment")),
                "core_review": _normalize_text(it.get("core_review")),
                "caveat": _normalize_text(it.get("caveat")),
                "growth_6m_label": _normalize_text(it.get("growth_6m_label")),
                "error": err,
                "st": st,
            }
        )

    lines.append("")

    for it in computed:
        name = it["name"]
        idx = it["idx"]
        rev = it["rev"]
        ai_label = it["ai_label"]
        segment = it["segment"]
        selected = it["selected"] or {}
        caveat = it["caveat"]
        st = it["st"] or {}

        lines.append(f"## {idx}. {name}")
        if it["error"]:
            lines.append("")
            lines.append(f"Fetch failed: `{_normalize_text(it['error'])[:200]}`")
            lines.append("")
            continue

        lines.append("")
        lines.append(f"- **{month} Revenue (as-of)**: {_money_compact_usd(rev)}")
        trailing_12m = st.get("revenue_trailing_12_months_usd")
        trailing_12m_val: float | None = None
        if isinstance(trailing_12m, (int, float)):
            trailing_12m_val = float(trailing_12m)
        lines.append(
            f"- **Trailing 12M Revenue (as-of {month})**: {_money_compact_usd(trailing_12m_val)}"
        )
        share_obj = (st or {}).get("market_share_as_of_last_month")
        share_percent: float | None = None
        if isinstance(share_obj, dict):
            v = share_obj.get("share_percent")
            if isinstance(v, (int, float)):
                share_percent = float(v)
        downloads_obj = (st or {}).get("downloads_as_of_last_month")
        downloads_absolute: float | None = None
        if isinstance(downloads_obj, dict):
            v = downloads_obj.get("downloads_absolute")
            if isinstance(v, (int, float)):
                downloads_absolute = float(v)
        mau_obj = (st or {}).get("mau_as_of_last_month")
        mau_absolute: float | None = None
        if isinstance(mau_obj, dict):
            v = mau_obj.get("mau_absolute")
            if isinstance(v, (int, float)):
                mau_absolute = float(v)

        lines.append(f"- **Market share**: {_format_share_percent(share_percent)}")
        lines.append(f"- **Downloads**: {_compact_count(downloads_absolute)}")
        lines.append(f"- **MAU**: {_compact_count(mau_absolute)}")
        lines.append(f"- **6M Growth**: {_normalize_text(it.get('growth_6m_label'))}")
        lines.append(f"- **First release**: {_format_date(_parse_iso_date(_normalize_text(st.get('first_release_date_us'))))}")
        lines.append(f"- **Focus**: {segment}")
        lines.append(f"- **AI**: {ai_label}")
        pub = _normalize_text(selected.get("publisher_name"))
        if pub:
            lines.append(f"- **Publisher**: {pub}")
        lines.append("")
        lines.append("**What it does**")
        lines.append("")
        what = _clean_snippet(_normalize_text(it.get("core_review"))) or "N/A"
        lines.append(f"{what}")
        if caveat:
            lines.append("")
            lines.append(f"**Caveat**: {caveat}")

        lines.append("")
        lines.append("**Notes (evidence)**")
        lines.append("")
        title = _normalize_text(selected.get("humanized_name") or selected.get("name"))
        if title:
            lines.append(f"- SensorTower resolved app: {title}")
        monthly = it.get("monthly_estimates", [])
        if isinstance(monthly, list) and monthly:
            pts: list[float] = []
            for row in monthly[:6]:
                if not isinstance(row, dict):
                    continue
                val = row.get("revenue_absolute_usd")
                if isinstance(val, (int, float)):
                    pts.append(float(val))
                    continue
                if val is None:
                    continue
                try:
                    pts.append(float(str(val)))
                except ValueError:
                    continue
            if pts:
                lines.append(f"- Trend (6m sparkline): {_sparkline(pts)}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"

