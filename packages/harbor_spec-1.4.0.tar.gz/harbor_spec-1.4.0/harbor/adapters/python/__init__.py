"""Python language adapter."""

