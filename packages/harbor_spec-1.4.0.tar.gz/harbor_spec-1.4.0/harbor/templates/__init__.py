"""Template resources for Harbor."""
