"""Init wizard template resources."""
