import json
from pathlib import Path

from harbor.core.module_capsule import collect_module_context
from harbor.core.stale import (
    check_l2_readme_stale,
    check_module_derived_views_stale,
    stale_report_to_dict,
)


def _write_index(tmp_path: Path) -> None:
    idx = tmp_path / ".harbor" / "cache" / "l3_index.json"
    idx.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "files": {
            "harbor/core/sync.py": {
                "items": [
                    {
                        "id": "harbor.core.sync.SyncEngine.check_status",
                        "qualified_name": "SyncEngine.check_status",
                        "scope": "public",
                        "strictness": "standard",
                    }
                ]
            }
        }
    }
    idx.write_text(json.dumps(payload), encoding="utf-8")


def _write_l2_export_config(tmp_path: Path, enabled: bool) -> None:
    cfg = tmp_path / ".harbor" / "config" / "harbor.yaml"
    cfg.parent.mkdir(parents=True, exist_ok=True)
    cfg.write_text(
        "l2:\n  export:\n    module_readme:\n      enabled: " + ("true" if enabled else "false") + "\n",
        encoding="utf-8",
    )


def test_l2_readme_stale_when_missing(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    result = check_l2_readme_stale("harbor/core")
    assert result.status == "stale"
    assert result.reason == "canonical README.md not found"
    assert result.suggested_command == "harbor docs --module harbor/core --write"


def test_l2_readme_up_to_date_when_content_matches_except_timestamp(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    readme = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    readme.parent.mkdir(parents=True, exist_ok=True)
    readme.write_text(
        "A\nGenerated At: 2020-01-01T00:00:00Z\nB\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "A\nGenerated At: 2026-01-01T00:00:00Z\nB\n",
    )
    result = check_l2_readme_stale("harbor/core")
    assert result.status == "up_to_date"


def test_l2_readme_stale_when_content_differs(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    readme = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    readme.parent.mkdir(parents=True, exist_ok=True)
    readme.write_text("OLD\n", encoding="utf-8")
    monkeypatch.setattr("harbor.core.stale.L2Generator.generate", lambda self, module: "NEW\n")
    result = check_l2_readme_stale("harbor/core")
    assert result.status == "stale"
    assert result.reason == "README content mismatch"


def test_l2_readme_unknown_when_no_indexed_records(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    result = check_l2_readme_stale("harbor/unknown")
    assert result.status == "unknown"
    assert result.reason == "no indexed records found for module"
    assert result.suggested_command is None


def test_l2_readme_check_does_not_write_file(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    readme = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    readme.parent.mkdir(parents=True, exist_ok=True)
    original = "SAME\nGenerated At: 2020-01-01T00:00:00Z\n"
    readme.write_text(original, encoding="utf-8")
    before = readme.read_text(encoding="utf-8")
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "SAME\nGenerated At: 2026-01-01T00:00:00Z\n",
    )
    _ = check_l2_readme_stale("harbor/core")
    after = readme.read_text(encoding="utf-8")
    assert before == after


def test_check_module_derived_views_stale_returns_both_views(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    monkeypatch.setattr("harbor.core.stale.L2Generator.generate", lambda self, module: "NEW\n")
    summary = check_module_derived_views_stale("harbor/core")
    assert summary.module == "harbor/core"
    assert summary.l2_readme.view == "L2 README"
    assert summary.l2_readme.status == "stale"
    assert summary.l2_readme_export.view == "L2 README Export"
    assert summary.l2_readme_export.status == "unknown"
    assert summary.module_capsule.view == "Module Capsule"
    assert summary.module_capsule.status == "stale"
    assert summary.module_capsule.reason == "module-card.md not found"


def test_check_module_derived_views_stale_unknown_consistency_when_no_indexed_records(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    summary = check_module_derived_views_stale("harbor/unknown")
    assert summary.l2_readme.status == "unknown"
    assert summary.l2_readme_export.status == "unknown"
    assert summary.module_capsule.status == "unknown"
    assert summary.module_capsule.reason == "no indexed records found for module"


def test_l2_export_ok_when_canonical_up_to_date_and_export_matches(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=True)
    canonical = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    exported = tmp_path / "harbor" / "core" / "README.md"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    exported.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text("A\nGenerated At: 2020-01-01T00:00:00Z\nB\n", encoding="utf-8")
    exported.write_text("A\nGenerated At: 2026-01-01T00:00:00Z\nB\n", encoding="utf-8")
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "A\nGenerated At: 2026-01-01T00:00:00Z\nB\n",
    )
    summary = check_module_derived_views_stale("harbor/core")
    assert summary.l2_readme.status == "up_to_date"
    assert summary.l2_readme_export.status == "up_to_date"


def test_l2_export_ok_when_canonical_has_frontmatter_and_export_is_plain_body(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=True)
    canonical = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    exported = tmp_path / "harbor" / "core" / "README.md"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    exported.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text(
        '---\nview_type: "l2_readme"\nsource_fingerprint: "sha256:x"\ncontract_fingerprint: "sha256:y"\ngenerator_fingerprint: "sha256:z"\ngenerated_at: "2026-01-01T00:00:00Z"\n---\n\n# Module: harbor/core\n',
        encoding="utf-8",
    )
    exported.write_text("# Module: harbor/core\n", encoding="utf-8")
    monkeypatch.setattr("harbor.core.stale.L2Generator.generate", lambda self, module: "# Module: harbor/core\n")
    summary = check_module_derived_views_stale("harbor/core")
    assert summary.l2_readme.status == "up_to_date"
    assert summary.l2_readme_export.status == "up_to_date"


def test_l2_export_warn_when_canonical_up_to_date_but_export_missing(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=True)
    canonical = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text("SAME\nGenerated At: 2020-01-01T00:00:00Z\n", encoding="utf-8")
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "SAME\nGenerated At: 2026-01-01T00:00:00Z\n",
    )
    summary = check_module_derived_views_stale("harbor/core")
    assert summary.l2_readme.status == "up_to_date"
    assert summary.l2_readme_export.status == "stale"
    assert summary.l2_readme_export.reason == "module README export missing"


def test_l2_export_warn_when_canonical_up_to_date_but_export_mismatch(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=True)
    canonical = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    exported = tmp_path / "harbor" / "core" / "README.md"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    exported.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text("SAME\nGenerated At: 2020-01-01T00:00:00Z\n", encoding="utf-8")
    exported.write_text("DIFF\nGenerated At: 2026-01-01T00:00:00Z\n", encoding="utf-8")
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "SAME\nGenerated At: 2026-01-01T00:00:00Z\n",
    )
    summary = check_module_derived_views_stale("harbor/core")
    assert summary.l2_readme.status == "up_to_date"
    assert summary.l2_readme_export.status == "stale"
    assert summary.l2_readme_export.reason == "module README export out of sync"


def test_l2_export_disabled_is_explicit_and_not_warn_counter(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=False)
    canonical = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text("SAME\nGenerated At: 2020-01-01T00:00:00Z\n", encoding="utf-8")
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "SAME\nGenerated At: 2026-01-01T00:00:00Z\n",
    )
    summary = check_module_derived_views_stale("harbor/core")
    payload = stale_report_to_dict([summary], scope="module:harbor/core")
    assert summary.l2_readme_export.status == "disabled"
    assert payload["summary"]["disabled_views"] == 1
    assert payload["summary"]["stale_views"] == 1  # module capsule stale only


def test_l2_export_skips_compare_when_canonical_unavailable(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=True)
    exported = tmp_path / "harbor" / "core" / "README.md"
    exported.parent.mkdir(parents=True, exist_ok=True)
    exported.write_text("DIFF\n", encoding="utf-8")
    summary = check_module_derived_views_stale("harbor/core")
    assert summary.l2_readme.status == "stale"
    assert summary.l2_readme_export.status == "unknown"
    assert summary.l2_readme_export.reason == "canonical L2 README unavailable"


def test_stale_json_contains_l2_readme_export_view_name(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_index(tmp_path)
    _write_l2_export_config(tmp_path, enabled=False)
    canonical = tmp_path / ".harbor" / "views" / "l2" / "harbor" / "core" / "README.md"
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_text("SAME\nGenerated At: 2020-01-01T00:00:00Z\n", encoding="utf-8")
    monkeypatch.setattr(
        "harbor.core.stale.L2Generator.generate",
        lambda self, module: "SAME\nGenerated At: 2026-01-01T00:00:00Z\n",
    )
    payload = stale_report_to_dict([check_module_derived_views_stale("harbor/core")], scope="module:harbor/core")
    dumped = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2)
    loaded = json.loads(dumped)
    view_names = [item["view"] for item in loaded["modules"][0]["views"]]
    assert "l2_readme" in view_names
    assert "l2_readme_export" in view_names
    assert "specs/diary" not in dumped
    assert ".harbor/diary" not in dumped
