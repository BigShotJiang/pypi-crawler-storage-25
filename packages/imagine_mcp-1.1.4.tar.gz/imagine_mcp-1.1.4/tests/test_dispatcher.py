from __future__ import annotations

import pytest

from imagine_mcp.dispatcher import dispatch_generate, dispatch_understand
from imagine_mcp.errors import (
    InvalidMediaTypeError,
    InvalidProviderError,
    InvalidTierError,
    InvalidURLError,
    ProviderUnsupportedError,
)


def test_understand_routes_to_gemini_image(monkeypatch: pytest.MonkeyPatch) -> None:
    # Stub provider
    def mock_fn(url: str, prompt: str, tier: str, max_tokens: int = 2048) -> dict:
        return {"text": "a cat", "model": "gemini-x", "provider": "gemini"}

    import imagine_mcp.providers.gemini as gemini_mod

    monkeypatch.setattr(gemini_mod, "understand_image", mock_fn, raising=False)
    monkeypatch.setattr("imagine_mcp.dispatcher.detect_media_type", lambda u: "image")

    result = dispatch_understand(
        media_urls=["https://example.com/cat.png"],
        prompt="describe",
        provider="gemini",
        tier="poor",
    )
    assert result["text"] == "a cat"


def test_understand_invalid_provider() -> None:
    with pytest.raises(InvalidProviderError):
        dispatch_understand(
            media_urls=["https://example.com/x.png"],
            prompt="hi",
            provider="unknown",
            tier="poor",
        )


def test_understand_invalid_tier() -> None:
    with pytest.raises(InvalidTierError):
        dispatch_understand(
            media_urls=["https://example.com/x.png"],
            prompt="hi",
            provider="gemini",
            tier="mega",
        )


def test_understand_unsupported_video_openai(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("imagine_mcp.dispatcher.detect_media_type", lambda u: "video")
    with pytest.raises(ProviderUnsupportedError) as exc_info:
        dispatch_understand(
            media_urls=["https://example.com/x.mp4"],
            prompt="hi",
            provider="openai",
            tier="poor",
        )
    assert "video" in str(exc_info.value).lower()


def test_understand_unsupported_video_grok(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("imagine_mcp.dispatcher.detect_media_type", lambda u: "video")
    with pytest.raises(ProviderUnsupportedError):
        dispatch_understand(
            media_urls=["https://example.com/x.mp4"],
            prompt="hi",
            provider="grok",
            tier="rich",
        )


def test_generate_invalid_media_type() -> None:
    with pytest.raises(InvalidMediaTypeError):
        dispatch_generate(
            media_type="audio",
            prompt="hi",
            provider="gemini",
            tier="poor",
        )


def test_generate_unsupported_video_openai() -> None:
    with pytest.raises(ProviderUnsupportedError) as exc_info:
        dispatch_generate(
            media_type="video",
            prompt="a dog running",
            provider="openai",
            tier="poor",
        )
    assert (
        "sora" in str(exc_info.value).lower()
        or "shutdown" in str(exc_info.value).lower()
    )


@pytest.mark.parametrize(
    "bad_url",
    [
        "file:///etc/passwd",
        "ftp://internal.local/secret",
        "gopher://127.0.0.1:9000/_x",
        "//no-scheme.example.com/a.png",
        "javascript:alert(1)",
        "http://localhost",
        "http://127.0.0.1",
        "https://127.0.0.1",
        "http://169.254.169.254",
        "http://0x7f000001",
        "http://0.0.0.0",
        "http://10.0.0.1",
        "https://192.168.1.5",
        "http://[::ffff:127.0.0.1]/",
        "http://[::ffff:7f00:1]/",
    ],
)
def test_understand_rejects_non_http_url(bad_url: str) -> None:
    with pytest.raises(InvalidURLError):
        dispatch_understand(
            media_urls=[bad_url],
            prompt="hi",
            provider="gemini",
            tier="poor",
        )


def test_understand_rejects_non_http_url_in_second_position() -> None:
    with pytest.raises(InvalidURLError, match=r"media_urls\[1\]"):
        dispatch_understand(
            media_urls=["https://example.com/ok.png", "file:///etc/passwd"],
            prompt="hi",
            provider="gemini",
            tier="poor",
        )


def test_generate_rejects_non_http_reference_image_url() -> None:
    with pytest.raises(InvalidURLError, match="reference_image_url"):
        dispatch_generate(
            media_type="image",
            prompt="cat",
            provider="gemini",
            tier="poor",
            reference_image_url="file:///etc/passwd",
        )


def test_understand_rejects_dns_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    import time

    def mock_getaddrinfo(*args, **kwargs):
        time.sleep(3)
        return []

    monkeypatch.setattr("socket.getaddrinfo", mock_getaddrinfo)

    start = time.time()
    with pytest.raises(InvalidURLError, match=r"timed out for 'slow\.example\.com'"):
        dispatch_understand(
            media_urls=["http://slow.example.com/test.png"],
            prompt="hi",
            provider="gemini",
            tier="poor",
        )
    duration = time.time() - start
    assert duration < 2.5, f"DNS timeout block took too long: {duration}s"
