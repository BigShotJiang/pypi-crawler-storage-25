# Changelog

Todas las versiones notables se documentan aquí. El proyecto sigue [SemVer](https://semver.org/).

## [Unreleased]

## [0.7.4] — 2026-05-16

### Fixed — `require_auth` redirige a `/login` en lugar de devolver 401 JSON para navegadores

Cuando un usuario entraba a la raíz de una app generada sin cookie de sesión, `require_auth` lanzaba `HTTPException(401, detail={"code":"UNAUTHORIZED","message":"invalid-session"})` y FastAPI lo serializaba como JSON. El navegador mostraba un blob `{"detail":{"code":"UNAUTHORIZED",...}}` sin pantalla de login.

Fix en `template/src/api/deps.py`: si el header `Accept` incluye `text/html`, `require_auth` lanza `HTTPException(303)` con `Location: /login`. El navegador redirige al login. Clientes API (curl, fetch sin Accept HTML) siguen recibiendo el 401 JSON para parseo de error.

Propagación a apps existentes: `app-backend/src/control/update_common_pr.py` añade `src/api/deps.py` a `_SYNC_FILES`. El siguiente "Actualizar common" abre un PR con el deps.py al día.

### Fixed — race condition cross-process en `apply_migrations`

`apply_migrations` no protegía la lectura de `_dg_applied_migrations` ni
la ejecución de cada SQL contra ejecuciones paralelas. Cuando el
container de la app generada arrancaba con `--workers 2` (default
anterior del template), los dos procesos uvicorn entraban al lifespan
en paralelo, ambos leían la tabla de control vacía y ambos intentaban
aplicar v1 — el segundo cascaba con
`duplicate key ... pg_type_typname_nsp_index` en `CREATE TYPE app_role`
y dejaba el container en crash loop.

Fix: adquirir `pg_advisory_lock(_MIGRATION_LOCK_KEY)` session-level al
abrir la conexión, antes del bootstrap. El segundo worker queda
bloqueado en la llamada hasta que el primero libera el lock; cuando
entra, ve la tabla de control llena y skip-ea todo.

### Changed — `template/infra/Dockerfile` arranca con `--workers 1`

Defensa en profundidad: aunque el advisory lock resuelve la race, mover
el default a un solo worker elimina el problema de raíz para apps
generadas con versiones del template anteriores al fix. Para la carga
típica de una app generada un worker uvicorn async basta. Subir a >1
worker en una app concreta sigue siendo opt-in editando su
`infra/Dockerfile`.

## [0.7.2] — 2026-05-16

### Added — Auto-migration en startup de la app generada

Nuevo módulo `datagrowth_common.migrations` con
`apply_migrations(migrations_dir, *, db_url=None)`. El template (lifespan
de `src/main.py`) lo invoca al arrancar para aplicar `migrations/*.sql`
automáticamente contra el Postgres del cliente. Idempotente con tracking
en `dg_internal._dg_applied_migrations` (mismo esquema que ya usaba
`app-backend/src/lib/supabase_migrations.py` — apps con tablas ya
creadas saltan los archivos vía la tabla de tracking).

**Por qué**: hasta ahora el control plane (`app-backend`) aplicaba las
migrations contra el Postgres del cliente desde fuera. Eso requería
acceso TCP del backend al Postgres del cliente — viable solo si están
en el mismo VPS y misma red Docker. Mover las migrations al startup del
container generado:

- Habilita despliegues a clientes en Easypanels de **otros VPS**.
- Elimina la necesidad de exponer Postgres públicamente.
- Cada container resuelve `db:5432` en su propia red docker; sin
  conflictos DNS entre múltiples Supabase coexistentes.

### Fixed — Template del compose y Dockerfile alineados con el patrón del backend

- **`template/infra/Dockerfile`**: añadido `COPY migrations/ ./migrations/`.
  Sin esta línea el lifespan invocaba
  `apply_migrations(_MIGRATIONS_DIR)` apuntando a `/app/migrations`
  inexistente y log decía `migrations_dir_missing` silenciosamente.

- **`template/infra/docker-compose.yml`**: añadido `env_file: - ../.env`
  en el primer servicio. Easypanel materializa las env vars del modal
  Environment en `code/.env` (raíz del repo clonado) cuando
  `createDotEnv: True` (default del `services.compose.updateEnv`).
  El compose vive en `infra/`, por eso el path relativo correcto es
  `../.env`. Mismo patrón que `app-backend/infra/docker-compose.yml`
  (que funciona desde siempre). Sin esta línea el container arrancaba
  sin credenciales y el lifespan reventaba con
  `database-url-not-configured`.

### Changed
- `template/src/main.py`: el lifespan llama `apply_migrations` antes de
  `bootstrap_admin_from_env`. Si falla, `raise` para que el container
  entre en crash loop. Easypanel marca el container unhealthy y el
  operador inspecciona logs desde la UI.
- `template/src/db.py`: docstring actualizada — las migrations ya no
  las aplica el operador manualmente.
- `template/pyproject.toml`: pin `datagrowth-common[supabase]>=0.7.0,<0.8`
  (era `>=0.6.2,<0.7`).
- `pyproject.toml`: nueva optional dependency `[postgres]` con
  `psycopg[binary]>=3.2`. El template la trae directamente; las apps
  que solo usan auth/UI no necesitan psycopg.

### Module exports
- `datagrowth_common.apply_migrations` (nuevo, exportado en `__init__`).

### Migración para apps existentes

- Apps con tablas ya creadas: el primer arranque con 0.7.2 ve los
  archivos en `_dg_applied_migrations` y los salta. Sin acción manual
  sobre BD.
- "Actualizar common" en `/packages/<slug>` del control plane bumpea el
  pin + sincroniza archivos de infra (Dockerfile, docker-compose.yml) +
  añade migrations nuevas, **y** parchea `src/main.py` automáticamente
  para añadir el hook `apply_migrations(...)` al lifespan
  (`_patch_main_for_lifespan_migrations`).
- Si el `src/main.py` del package está customizado y el patcher no
  reconoce su estructura, el body del PR incluye el snippet exacto a
  añadir a mano.

**Migración del control plane (`app-backend`)**:
- En el release alineado: el deployer elimina su paso de migrations,
  añade polling al `/healthz` del deploy publicado para detectar
  fallos, normaliza `env_file: - ../.env` en el compose (idempotente
  contra apps generadas pre-0.7.2) y configura el dominio Easypanel
  con `composeService` + `port=8000` para que Traefik enrute al puerto
  correcto.

## [0.6.3] — 2026-05-15

### Changed — Template `infra/docker-compose.yml`: quitar `env_file: .env`

Easypanel inyecta las variables de entorno de los Compose services via
su propio `docker-compose.override.yml` (generado al guardar la pestaña
"Environment" / `services.compose.updateEnv`), no via un archivo `.env`
físico al lado del compose. Con `env_file: .env` declarado en el
template, `docker compose up` fallaba con:

```
env file /etc/easypanel/projects/<proj>/<svc>/code/infra/.env not found
Command failed with exit code 1
```

- **Eliminada** la directiva `env_file: .env` de
  `template/infra/docker-compose.yml`. El servicio sigue recibiendo
  todas sus env vars via el override de Easypanel.
- **Para deployment fuera de Easypanel** (bundle a cliente externo), el
  operador genera `.env` en la raíz y pasa `--env-file=../.env` al
  `docker compose` desde `infra/`.

Apps existentes (`app-*`) heredan este cambio al pulsar "Actualizar
common" en `/packages/<slug>` (ver skill `update-package-common`). Las
instances dev auto-desplegadas reciben además un parche idempotente en
`app-backend/src/control/instance_deployer.py:_patch_compose_env_file_via_api`
que elimina el `env_file:` del compose del repo de la instance en cada
deploy — cubre apps que no hayan corrido todavía el update-common.

## [0.6.2] — 2026-05-14

### Changed — Template `src/api/admin_users.py`: admin bypass + dev fall-through en `require_perm`

Paridad con `app-backend/src/api/admin_users.py:_make_perm_dep`. Hasta
ahora, el template usaba `make_require_permission` upstream directamente
para gatear los endpoints `/admin/users/*`. Eso obligaba a que el admin
estuviera sembrado en `user_role` con rol `admin` para acceder; si el
bootstrap (`bootstrap_admin_from_env`) fallaba por red/Supabase, el
admin recibía 403 hasta el siguiente arranque, y en tests/dev sin
bootstrap todo endpoint admin reventaba con `permissions-lookup-failed`.

- **Factory local `_make_perm_dep(permission)`** sustituye al
  `make_require_permission` upstream para los deps que usa
  `make_users_router`. Política:
  - `AuthUserModel.is_admin = True` → bypass (no consulta BD). El admin
    tiene todo el catálogo por construcción (`SYSTEM_ROLES["admin"]`).
  - `DG_ENV != production` → fall-through (devuelve `actor` sin
    consultar perms). Permite que tests y dev sin sembrar la tabla RBAC
    no revienten.
  - `DG_ENV = production` → query `effective_permissions` y deny con
    403 si falta el permiso o el lookup peta.
- La sección "Administración" del sidebar template
  (`template/src/templates/partials/sidebar_nav.html`) ya estaba gated
  por `user.is_admin` — sin cambios.
- Para forzar denegación en un test específico, override el dep en la
  fixture: `app.dependency_overrides[_require_users_manage] = _deny`.

## [0.6.1] — 2026-05-14

### Changed — Template `infra/docker-compose.yml`

Las apps generadas que se despliegan en Easypanel desde el `app-backend`
(flow auto-deploy del package recién scaffolded) necesitan que el
compose service arranque sin depender de una imagen Docker publicada en
GHCR. El workflow `template/.github/workflows/deploy.yml` solo se
dispara en `release: published`, así que un repo recién scaffolded sin
release todavía no tiene imagen y el compose `image: ghcr.io/...` fallaba.

- **`image: ghcr.io/datagrowth/${APP_SLUG}` → `build: {context: .., dockerfile: infra/Dockerfile}`.**
  Easypanel clona el repo y construye la imagen localmente con
  `docker compose build` antes de `up`. Funciona desde el primer commit
  scaffolded sin necesidad de release previa. El workflow `deploy.yml`
  sigue intacto: al publicar una release, la imagen se sube a GHCR y los
  bundles que entrega el `app-backend` a clientes externos sí la usan.
- **Red `n8n_supabase_default` declarada como `external: true`** y añadida
  al service `app`. Permite que el contenedor resuelva `db:5432` y
  `kong:8000` del Supabase self-hosted por hostname interno. Si el
  cliente usa Supabase Cloud, hay que quitar la red manualmente.
- **Eliminados los labels Traefik y la red `traefik_public`.** Easypanel
  gestiona su propio reverse proxy con el dominio que el deployer manda
  por `services.compose.createService(domains=[...])`. Tener labels Traefik
  manuales producía routing duplicado.
- **Nuevo `.dockerignore`** en la raíz del template para limitar el build
  context (excluye `.git`, `tests/`, `.pytest_cache/`, `.env`, etc.) y
  evitar enviar megabytes innecesarios al daemon Docker.

### Fixed — `__version__` desincronizado

`src/datagrowth_common/__init__.py` declaraba `__version__ = "0.5.0"`
mientras que `pyproject.toml` ya estaba en 0.6.0. Ambos quedan
alineados en 0.6.1.

## [0.6.0] — 2026-05-14

### Added — Fijar contraseña server-side a usuario existente

Regresión funcional respecto al panel viejo (pre-0.5.0): el nuevo panel solo permitía mandar email de reset, no fijar contraseña sin email. Útil cuando el cliente no tiene email accesible o el admin entrega credenciales en mano.

- **Nuevo endpoint** `POST /admin/users/{user_id}/password/set` con body `{password}`. Valida longitud 8-128 + una mayúscula + un dígito (mismo `_check_password` que en `create`).
- **`supabase_admin.set_user_password(user_id, password)`** — wrapper de `client.auth.admin.update_user_by_id({"password": ...})`. Devuelve `Result[None]`.
- **`service.set_user_password(db, *, actor, target_user_id, password, schema)`** — orquesta Supabase + audit log en la misma transacción del caller.
- **Audit action** `password_set` (constante `audit.ACTION_PASSWORD_SET`).
- **UI** — nuevo botón `contraseña` en cada fila de la tabla Usuarios + modal `dg-set-pwd` con input password validado. El handler postea al endpoint y avisa al admin de comunicar la contraseña por canal seguro.

### Added — UI: editor de permisos por rol

- **Modal "Editar permisos"** en `dg/admin/users_panel.html`: aparece en cada fila de la tabla Roles y abre un dialog con checkboxes del catálogo prellenados con los permisos actuales. Llama al endpoint existente `PATCH /admin/users/roles/{slug}/permissions`. Cierra el gap entre la API (que ya soportaba editar permisos desde 0.5.0) y la UI (que solo permitía crear y borrar).
- `renderPermissionPicker(selectedByDialogId)` ahora acepta preselección por dialog, mismo patrón que `renderRolePickers`.

### Changed — UI: refresh de estilos del panel

Hasta ahora los botones de fila (editar/reset/borrar/ver) eran `<button>` crudos sin clases — se renderizaban como texto, no como botones. Mismo problema en los modales (inputs sin estilos, cancel/submit sin variants).

- Tablas (Usuarios / Roles / Audit log) ahora usan los componentes `table-wrapper` / `table-base` / `table-thead` / `table-tr` / `table-td` del paquete, con hover y separadores correctos.
- Botones de fila usan `btn btn-sm btn-ghost` (`btn btn-sm btn-ghost text-semantic-danger` para borrar).
- Modales `<dialog>` reciben clase `.dg-dialog` con un bloque `<style>` local: padding, panel bg, border, sombra modal + `::backdrop` con blur. Antes solo tenían `rounded-xl p-6` y heredaban el bg del navegador.
- Inputs de los modales usan `form-input` / `form-input-mono`. Labels usan `form-label` y hints `form-hint`.
- Submit primary / Cancel ghost en todos los modales — antes solo el submit tenía `font-semibold`.
- Roles del usuario se muestran como `badge badge-brand` en lugar de texto separado por comas.
- Permisos de rol se muestran como chips `code` con fondo `surface-subtle` en lugar de listado separado por comas.
- Tabs con underline animado (clase `.dg-tab`).

### Changed — `template/` ahora usa el panel RBAC nuevo

El skeleton de apps generadas montaba un router custom contra `public.app_role` (single-tenant, email + is_admin). Ahora monta `make_users_router` igual que `app-backend`, dando a cada app gestión multi-rol + permisos + audit log de serie.

- **`template/src/api/admin_users.py`** reescrito: `PermissionCatalog({"users.manage": ...})`, system roles `admin` (todo) + `viewer` (vacío), `bootstrap_admin_from_env` ahora resuelve `APP_ADMIN_EMAIL` → user_id en Supabase Auth → asigna rol `admin` en `user_role` (aditivo, no revoca otros roles).
- **`template/src/db.py`** nuevo: engine SQLAlchemy + `get_session()`. Usa la misma convención de env vars que `app-backend` (`DG_DATABASE_URL` completa, o `POSTGRES_PASSWORD` + `DG_SUPABASE_DB_HOST/PORT/USER/NAME`).
- **`template/migrations/v2_users_rbac.sql`** nuevo: crea `role`, `user_role`, `role_permission`, `user_audit_log` + **backfill automático** desde `app_role` legacy cruzando email con `auth.users`.
- **`template/src/templates/admin/users_panel.html`** nuevo: wrapper que extiende `base.html` e incluye `dg/admin/users_panel.html`. Sin esto el panel se renderiza sin sidebar ni Tailwind.
- **`template/pyproject.toml`**: añadidas deps `sqlalchemy>=2.0` y `psycopg[binary]>=3.2`. Pin de `datagrowth-common[supabase]` movido a `>=0.6.0,<0.7`.
- **`template/infra/.env.example`**: documentadas las nuevas vars `DG_DATABASE_URL` / `POSTGRES_PASSWORD` / `DG_SUPABASE_DB_*` + `APP_ADMIN_EMAIL`.
- **`template/infra/docker-compose.yml`**: comentarios para sumar la red Docker de Supabase self-hosted (`n8n_supabase_default`) cuando el hostname `db` debe resolver desde el contenedor.

### Removed

- `template/src/templates/admin/users.html` y `users_new.html` (panel viejo basado en `app_role`).

### Migration guide — apps cliente que vienen de 0.5.x o anteriores

1. Aplicar `migrations/v2_users_rbac.sql` al Supabase del cliente. El backfill `DO $$` mueve los `is_admin=true` actuales a asignaciones del rol `admin` sin tocar datos manualmente. **Importante**: el bloque de backfill hace `JOIN auth.users`, así que aplícala desde el SQL Editor del Dashboard de Supabase (ejecuta como `postgres`) o vía `psql` con `service_role`. Con un rol normal el JOIN devuelve 0 filas y los admins legacy no migran.
2. Configurar las nuevas env vars de Postgres directo (`DG_DATABASE_URL` o las piezas). Hasta ahora las apps usaban solo REST (`SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY`); el panel nuevo necesita acceso TCP.
3. Rebuild + redeploy con `datagrowth-common>=0.6.0` y el template actualizado.
4. La tabla legacy `public.app_role` queda sin uso. Se puede borrar manualmente tras verificar que `user_role` tiene a los admins esperados.

### Notes

- Bump minor (0.5.0 → 0.6.0): la API pública del paquete sigue siendo compatible; lo que cambia (breaking) es el contrato del `template/` con las apps existentes (nuevas env vars + migración SQL).

## [0.5.0] — 2026-05-12

### Added — Módulo `datagrowth_common.users` (gestión de usuarios + RBAC reutilizable)

Sustituye al router limitado `datagrowth_common.api.users` por un módulo completo que las apps montan con `make_users_router(...)`. Permite que el backend Datagrowth y cualquier app generada compartan la misma sección de "Gestionar usuarios" contra su propio Supabase + tablas locales.

- **`PermissionCatalog`** — catálogo de permisos declarado en código (`{"runs.read": "Ver runs", ...}`). La BD solo guarda asignaciones, no el catálogo. Valida claves con regex `^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$`.
- **`make_users_router(catalog, deps, mount_prefix, schema, templates)`** — factory de `APIRouter` con 13 endpoints: HTML del panel, listado de usuarios con roles, invite + create con password, update roles, password reset, delete, permisos efectivos, CRUD de roles, audit log paginado. Commit/rollback explícito por handler.
- **`make_require_permission(perm, ...)`** — FastAPI dep que resuelve permisos efectivos (`user_role ⋈ role_permission`) con cache por request. Deniega por defecto.
- **`bootstrap_roles(db, system_roles, catalog)`** — idempotente: upserts roles del sistema + poda `role_permission` huérfanos. Refusa borrar si el catalog está vacío (defensa contra bug de import).
- **Audit log** — toda mutación escribe entrada en `user_audit_log` en la misma transacción del caller. Acciones canónicas: `invite`, `create_password`, `role_grant`, `role_revoke`, `password_reset_sent`, `delete`, `role_created`, `role_deleted`, `role_permissions_updated`.
- **Compensación Supabase ↔ BD** — si Supabase crea el usuario pero la BD falla, `_compensate_supabase_create` intenta borrarlo (best-effort, logueado). La operación no es atómica por naturaleza (side-effect externo).
- **Migración** — `datagrowth_common/users/migrations/001_users_rbac.sql` crea tablas `role`, `user_role`, `role_permission`, `user_audit_log` con FKs `ON DELETE CASCADE` e índices.
- **UI** — `dg/admin/users_panel.html` reescrita: 3 pestañas (Usuarios / Roles / Audit), multi-rol con pickers, modal de permisos efectivos, vanilla JS + `fetch` (sin HTMX). Sin innerHTML con interpolación de strings de usuario (defensa XSS por `createElement` + `textContent`).

### Changed

- **`datagrowth_common/api/users.py`** se conserva por compatibilidad pero queda deprecado. Las apps deben migrar a `datagrowth_common.users.make_users_router`.
- Nueva dep obligatoria: `sqlalchemy>=2.0`. El repository usa `text()` con bind params nombrados; compatible con `sqlmodel.Session` y `sqlalchemy.Connection`.

### Security

- Identificadores SQL (schema + tabla) compuestos en `_ident()` se validan con whitelist regex `^[a-z_][a-z0-9_]{0,62}$` antes de interpolar. Toda query usa bind params.
- `password` en `CreatePasswordBody` se valida con `field_validator` (pydantic v2 usa regex Rust, no soporta look-around): longitud 8-128 + al menos una mayúscula + al menos un dígito.

### Notes

- Bump minor (0.4.4 → 0.5.0): API pública nueva, nada se elimina. Apps con pin `>=0.4,<0.5` deben relajar a `>=0.5,<0.6` (o `>=0.4,<0.6` para coexistencia).
- Consumidores típicos:
  - `app-backend`: monta el router en `/admin/users` con schema `"backend"` (ver `migrations/v44.sql` que mapea `dev_role` legacy a la nueva estructura).
  - Apps cliente: aplican `001_users_rbac.sql` sobre su Supabase y montan el router con `schema=""` (default `public`).

## [0.4.4] — 2026-05-12

### Fixed — Componentes Jinja del paquete con texto ilegible en dark

- **`dg/components/page_header.html`**: `h1` era `text-slate-900` (ilegible 1.76:1 sobre `bg-surface` dark). Refactorizado a `text-fg`. Breadcrumb a `text-fg-muted`, last crumb a `text-fg`, subtitle a `text-fg-muted`.
- **`dg/components/modal.html`**: título `text-slate-900` → `text-fg`. Botón cerrar `text-slate-400 hover:text-slate-600` → `text-fg-muted hover:text-fg`.
- **`dg/components/empty_state.html`**: título `text-slate-700` → `text-fg`. Descripción `text-slate-400` → `text-fg-muted`. Icono container `bg-slate-100 text-slate-300` → `bg-surface-subtle text-fg-muted`.
- **`dg/components/data_table.html`**: empty row `text-slate-400` → `text-fg-muted`.
- **`dg/components/paginated_table.html`**: footer `text-slate-500` → `text-fg-muted`, `text-slate-700` → `text-fg`.
- **`dg/components/command_palette.html`**: iconos/placeholders/kbd `text-slate-400` → `text-fg-muted`. Input `text-slate-900` → `text-fg`. Lista `text-slate-700` → `text-fg`.
- **`dg/components/toast.html`**: contenido `text-slate-900` → `text-fg`. Botón cerrar `text-slate-400 hover:text-slate-600` → `text-fg-muted hover:text-fg`.
- **`dg/components/skeleton.html`**: `bg-slate-200` → `bg-border`.
- **`dg/admin/roles_panel.html`**: descripciones y keys a `text-fg-muted`.
- **`dg/components/sidebar_link.html`**: badge active `bg-brand-dark/20 text-brand-dark` → `bg-brand-lime text-brand-dark` (9.74:1 fijo, no depende del tema).

### Notes

- Bump patch (0.4.3 → 0.4.4). El problema afectaba a todo el chrome compartido: títulos de página, modales, toasts, empty states, tablas paginadas — todos heredaban `text-slate-*` hardcodeado. Apps consumidoras que extienden estos componentes recuperan dark mode legible sin tocar nada.

## [0.4.3] — 2026-05-12

### Added — Token `link` (accent text)

- **`--color-link` / `--color-link-hover`** en `tokens.css`: en light usa `brand-secondary` (navy), en dark usa `brand-primary` (lime). Da contraste WCAG AA en ambos temas para anchors, logos y badges con `bg-brand-lime/15`.
- **`link` / `link-hover`** en `tailwind-preset.cjs`: clases `text-link`, `hover:text-link-hover` disponibles para consumidores. Reemplaza el patrón `text-brand-dark hover:underline` que era ilegible (1.57:1) sobre superficies dark.

### Accessibility — Dark mode (continuación)

- **FOUC guard en `dg/layouts/empty.html`**: replica el patrón aplicado en 0.4.2 a `sidebar_shell.html`. Login, signup, password reset y errores también respetan la preferencia guardada antes del primer paint.
- **`text-fg` en body de `empty.html`**: era `text-slate-900` (ilegible en dark, 1.76:1 sobre `bg-surface`).

### Notes

- Bump patch (0.4.2 → 0.4.3): API Python sin cambios, solo CSS/preset/template. Pin `>=0.4,<0.5` lo coge automáticamente. Consumidores deben rebuildear su Tailwind local tras actualizar el wheel para que el preset actualizado (`link`/`link-hover`) se aplique a `app.css`.
- Apps consumidoras que usen `text-brand-dark hover:underline` como patrón de link **deben** migrar a `text-link hover:text-link-hover` para que dark mode sea legible. Sobre `bg-brand-lime` (botones/badges) seguir usando `text-brand-dark` — sigue dando 9.74:1.

## [0.4.2] — 2026-05-12

### Accessibility — Dark mode

- **FOUC eliminado**: script inline en `<head>` de `dg/layouts/sidebar_shell.html` aplica el `data-theme` antes del primer paint. Antes, con `theme.js` cargado en `defer`, los usuarios con preferencia "dark" guardada veían un flash light→dark en cada carga (problemático para fotosensibilidad).
- **`color-scheme` CSS**: declarado `color-scheme: light|dark` en `[data-theme="..."]` para que scrollbars, autofills y form controls nativos del navegador adapten al tema activo.
- **Botón toggle con estado anunciable**: añadido `data-theme-toggle` + `aria-pressed` dinámico. `theme.js` actualiza `aria-pressed` y `aria-label` ("Cambiar a tema claro" / "Cambiar a tema oscuro") en cada toggle. Antes el botón solo tenía `aria-label` estático y screen readers no anunciaban el cambio.
- **Hover del toggle legible sobre header dark**: el botón vive sobre `bg-brand-dark` (header siempre oscuro). `hover:text-slate-600` daba 2.41:1 (FAIL UI ≥3:1) — el icono se oscurecía sobre fondo oscuro. Cambiado a `text-white/60 hover:text-white hover:bg-white/10`.
- **Sync entre pestañas**: `theme.js` escucha `storage` events; cambiar el tema en una pestaña ahora actualiza el resto sin recargar.

### Fixed — Botón light/dark mode sin efecto visual

- **`tailwind-preset.cjs`**: los colores semánticos (`surface`, `panel`, `border`) estaban hardcodeados a hex (`#f8fafc`, `#ffffff`, `#e2e8f0`). Tailwind los compilaba a valores fijos en el CSS, así que `bg-surface`/`bg-panel`/`border-border` no respondían al cambio de `[data-theme="dark"]` aunque `theme.js` actualizara correctamente el atributo y los CSS vars de `tokens.css`. Ahora apuntan a `var(--color-*)`, de modo que la cascada CSS resuelve el valor según el tema activo en runtime.
- **Añadido `fg` y `surface-subtle`** al preset (`text-fg`, `text-fg-muted`, `bg-surface-subtle`) como tokens semánticos para texto y fondos sutiles. Permiten escribir `text-fg` en lugar de `text-slate-900` y obtener auto-switch light/dark.
- **`tokens.css`**: nuevo token `--color-surface-subtle` con valores para light (`#f1f5f9`) y dark (`#1a2e40`).
- **`_tailwind.source.css`**: component classes (`.card-title`, `.card-body`, `.btn-ghost`, `.badge-neutral`, `.table-thead`, `.table-tr:hover`, `.form-*`, `.sidebar-link`) refactorizadas a tokens semánticos (`text-fg`, `text-fg-muted`, `bg-surface-subtle`) en lugar de `text-slate-*`/`bg-slate-*`. Las apps consumidoras ven dark mode funcional sin tocar sus templates.
- **`dg/layouts/sidebar_shell.html`**: el `<body>` usa `text-fg` en vez de `text-slate-900`.

### Notes

- Bump patch (0.4.1 → 0.4.2): API Python sin cambios, solo CSS/preset/template. Pin `>=0.4,<0.5` lo coge automáticamente. Consumidores deben rebuildear su Tailwind local tras actualizar el wheel para que el preset actualizado se aplique a `app.css`.
- Alineado `__version__` con `pyproject.toml` (estaba en 0.3.2 desde antes de 0.4.0).

## [0.4.1] — 2026-05-12

### Changed — preset Tailwind dentro del wheel (PyPI = única fuente de verdad)

- **`src/datagrowth_common/ui/tailwind-preset.cjs`**: el fichero (introducido en 0.4.0 en la raíz del repo) se mueve dentro del paquete Python. Hatchling lo empaqueta en el wheel (verificado: `python -m zipfile -l` lista `datagrowth_common/ui/tailwind-preset.cjs` en el `.whl`). Los consumidores resuelven la ruta del fichero desde la instalación pip (`importlib.resources` o `os.path.dirname(datagrowth_common.ui.__file__)`).
- **Eliminado `package.json` raíz**: el paquete ya no se distribuye via npm. Consumirlo via `github:...#tag` resultaba inconsistente: `datagrowth-common` ya está en PyPI; tener una segunda fuente (GitHub) solo para un fichero JS introducía deps cross-channel innecesarias y requería `git` + reglas SSH→HTTPS dentro de imágenes Alpine.
- **`tailwind.config.js`**: ajustado el require para apuntar a `./src/datagrowth_common/ui/tailwind-preset.cjs`.

### Notes

- Bump patch (0.4.0 → 0.4.1) porque la API Python no cambia, solo la ubicación del asset JS. Consumidores con pin `>=0.4,<0.5` cogerán este release automáticamente.
- Consumir el preset en el frontend-build de Docker (node sin python) requiere un stage Python previo que pip-instale el paquete y `COPY` el `.cjs` al stage de node. Ver `app-backend/infra/Dockerfile` como referencia.

## [0.4.0] — 2026-05-12

### Added — Tailwind preset distribuido (`tailwind-preset.cjs`)

- **`tailwind-preset.cjs`** en la raíz del repo: contiene `theme.extend` (paleta brand, semantic, surfaces, fonts, radii, shadows, spacing) + `safelist` con las variantes responsive (`sm:block`, `sm:inline-flex`, `md:flex`, `md:grid-cols-2`, `md:px-6`, `lg:grid-cols-3`) que usan los layouts `dg/...`. Single source of truth para tokens y para las clases que de otro modo serían pisadas por la cascada CSS de un consumidor con Tailwind local.
- **`package.json`** en la raíz: expone el paquete como `datagrowth-common-ui` (instalable via `npm install github:datagrowth/datagrowth-common#0.4.0`) con `main: tailwind-preset.cjs`. Sin npm registry — los consumidores resuelven la dep desde GitHub.
- **`tailwind.config.js` del paquete**: refactorizado a `presets: [require('./tailwind-preset.cjs')]`. Deduplica el `theme.extend`.

### Fixed — Cascada CSS rota cuando un consumidor compila Tailwind localmente

- **Contexto**: el `app-backend` carga su `app.css` local (Tailwind sobre `src/templates/**`) DESPUÉS del `tailwind.compiled.css` del paquete vía `extra_head` de `backend_shell.html`. Al hacerlo, su `.hidden{display:none}` redefinida sin `.md\:flex` ganaba la cascada por orden de fuente, dejando `<aside class="hidden md:flex …">` permanentemente `display:none`. El preset incluye `safelist` con las responsive variants para que el `app.css` del consumidor también las emita y `md:flex` recupere la victoria a ≥768px.
- Fix puntual aplicado en paralelo en `app-backend/tailwind.config.js`; el preset hace el fix definitivo y reutilizable.

### Notes

- Bump menor (0.3.4 → 0.4.0): añade dist npm pero no rompe contratos Python (`register_ui`, models, auth). El pin `>=0.3.2,<0.4` en consumidores **debe ampliarse** a `>=0.4,<0.5` para coger este release.

## [0.3.4] — 2026-05-11

### Changed — tokens-override URL

- **`template/src/templates/base.html`**: el comentario explicativo del bloque `INSTANCE_TOKENS_OVERRIDE_LINK_*` ahora apunta a `https://backend.dev.datagrowth.es/branddesign/<slug>/tokens-override.css` (URL real del backend Datagrowth, router público separado de la galería admin `/tools/branddesign/`).
- **`docs/UI.md`**: ejemplo de `tokens_override_href` actualizado a la URL real.
- **`src/datagrowth_common/ui/static/css/tokens.css`**: comentario de override apunta a `/branddesign/<slug>/tokens-override.css` (sin `/tools/`).

> Acompaña el split del router en `app-backend` (`src/api/branddesign.py`): el endpoint runtime `tokens-override.css` queda en `/branddesign/{slug}/...` (público sin auth) separado del prefix admin `/tools/branddesign/` (CRUD, preview, comparar, regenerate).

## [0.3.3] — 2026-05-11

### Changed — instalación desde PyPI

- `template/infra/Dockerfile`: reescrito a un build multi-stage minimalista que instala `datagrowth-common[supabase]` desde PyPI en build-time. Sin Node, sin git, sin `GITHUB_TOKEN`.
- `template/infra/entrypoint.sh`: eliminado. Ya no es necesario instalar dependencias en runtime.
- `template/pyproject.toml`: pin `datagrowth-common[supabase]>=0.3.2,<0.4`. Eliminadas dependencias vestigiales (`aiofiles`, `httpx`, `python-multipart` — vienen via `datagrowth-common`).
- `template/infra/.env.example`: removida la variable `GITHUB_TOKEN`.
- `app-backend/templates/skeletons/app-fastapi-supabase/infra/entrypoint.sh`: bumpeado `DG_COMMON_REF` `v0.2.2` → `v0.3.2` (este skeleton aún lo usa el pipeline antiguo del backend; se eliminará cuando se reescriba).

## [0.3.2] — 2026-05-11

### Fixed

- **wheel**: eliminado bloque `force-include` redundante que duplicaba todos los archivos de `ui/static/*` y `ui/templates/*` dentro del wheel.
- **sdist**: anclados los patterns de `include` con `/` para evitar que `README.md` matchee recursivamente (antes arrastraba `template/.claude/memory/README.md` y `template/README.md`).
- **runtime dep**: añadido `python-multipart>=0.0.9` a `dependencies`. Sin él, `auth_router` (que usa `Form()`) lanzaba `RuntimeError` en la primera request.

### Added — repo dual: GitHub template

- **`template/`**: scaffold FastAPI listo para apps Datagrowth, instanciable con `gh repo create --template datagrowth/datagrowth-common`.
  - `src/main.py` que llama `register_ui(app, jinja_env)` y monta `auth_router`, `users_router`, `admin_users` y `dashboard`.
  - `src/jinja_env.py` usando `ChoiceLoader` (compatible con `register_ui`).
  - `src/templates/base.html` extiende `dg/layouts/sidebar_shell.html` con marcadores `INSTANCE_TOKENS_OVERRIDE_LINK_*` para que el deployer inyecte el `<link>` al `tokens-override.css` del cliente.
  - `pyproject.toml` con pin `datagrowth-common[supabase]~=0.3.1`.
  - `tests/test_smoke.py`: arranque `/healthz` + assets `/static/dg-common/css/tokens.css` y `/static/dg-common/js/theme.js`.
  - Governance migrada desde `app-backend`: `.claude/` (agents `architect`/`reviewer`/`security-reviewer`, rules core/api-design/performance/security/scratch-files, skills `boot`/`evolution`/`evolve`/`fix-issue`/`find-skills`/`precommit`, commands incluyendo `/remember`, settings.json, HOOKS.md), `.cursor/` (commands `/start`/`/pr`/`/gc`/`/review`, rules sin atlassian).
  - Documentación de onboarding en `README.md`, `PROJECT_SPEC.md`, `PROJECT_STATE.md`, `ARCHITECTURE.md` esqueletos.
- **`docs/VISUAL_LANGUAGE.md`**: migrado desde `datagrowth-ai-template/.impeccable.md`.
- **`.github/workflows/release.yml`**: compila Tailwind antes de buildear el wheel y añade job `verify-template` que instala el wheel recién publicado contra `template/` y corre los smoke tests.

### Deprecated

- `datagrowth-ai-template` queda obsoleto: su rol se asume aquí (template + governance). Archivar el repo antiguo en GitHub.

### Changed

- `app-backend/src/control/scaffolder.py`: eliminadas las constantes `TEMPLATE_REPO` y `_TEMPLATE_DOCS` que apuntaban a `datagrowth-ai-template`. Nadie las leía.

## [0.3.1] — 2026-05-11

### Added — subpaquete `datagrowth_common.ui`

- **`datagrowth_common.ui`** — subpaquete nuevo que distribuye toda la UI compartida (Jinja2 partials + CSS + JS) dentro del wheel.
- **`register_ui(app, jinja_env, mount_path="/static/dg-common")`** — helper que añade un `PackageLoader` al `ChoiceLoader` del Jinja Environment del host y monta los assets estáticos del paquete. Devuelve `tuple[None, Exception | None]`.
- **Constante `UI_VERSION`** exportada en raíz (alineada con `__version__`).
- **20 templates** con prefijo obligatorio `dg/...`:
  - Layouts: `dg/layouts/sidebar_shell.html`, `dg/layouts/empty.html`.
  - Componentes: `badge`, `button`, `card`, `command_palette`, `data_table`, `empty_state`, `form_field`, `icon` (Lucide SVGs inline), `modal`, `page_header`, `paginated_table`, `sidebar_link`, `skeleton`, `theme_toggle`, `toast`.
  - Admin: `users_panel`, `roles_panel`, `audit_panel`.
- **Static**:
  - `static/css/tokens.css` con tema light/dark via `[data-theme]` y aliases legacy (`--color-brand-lime` → `--color-brand-primary`).
  - `static/css/_tailwind.source.css` con `@layer components` para las clases `btn-*`, `card-*`, `badge-*`, `table-*`, `form-*`, `sidebar-link*`.
  - `static/css/tailwind.compiled.css` build artifact (regenerado con `bash scripts/build_tailwind.sh`).
  - `static/js/theme.js` — toggle light/dark + persistencia en `localStorage["dg-theme"]`.
  - `static/js/toasts.js` — auto-dismiss para `[data-toast]` con listener `htmx:afterSwap`.
  - `static/js/htmx-events.js` — modales (`openModal`/`closeModal`), atajo ⌘K/Ctrl+K para command palette y toast ante `htmx:responseError`.
- **`tailwind.config.js`** en raíz del paquete y **`scripts/build_tailwind.sh`** para compilar el CSS antes de tag.
- **`pyproject.toml`** — añade `jinja2>=3.1` como dependencia core y empaqueta `ui/static` + `ui/templates` en el wheel vía `[tool.hatch.build.targets.wheel.force-include]`.
- **Tests**: 24 nuevos en `tests/ui/test_register_ui.py` (smoke de mount + Jinja loader, error path, parametrizado sobre los 20 templates, smoke de assets servidos).
- **Doc**: `docs/UI.md` con quickstart, catálogo de componentes y guía para inyectar tokens del cliente via `tokens_override_href`.

### Notes

- Subir un MAJOR no aplica: la API pública de auth/core no cambia respecto a v0.3.0. Las apps que ya consumen v0.3.0 pueden migrar a v0.3.1 sin tocar imports existentes.
- Las apps que quieran adoptar el subpaquete UI solo añaden `register_ui(app, jinja_env=templates.env)` tras instanciar `Jinja2Templates`. Los templates `dg/...` se resuelven como fallback cuando el host no define los suyos.

## [0.3.0] — 2026-05-11

### BREAKING

- **Eliminado** `datagrowth_common.authentik` (parser de cabeceras forward-auth `X-authentik-*`). Importarlo ahora lanza `ImportError`. El archivo se conserva como sentinel hasta v0.4.0.
- **Eliminado** `datagrowth_common.auth_fastapi` (deps FastAPI `require_auth`, `require_admin`, `AuthUserDep`, `AdminUserDep` basadas en forward-auth). Importarlo lanza `ImportError`.
- **Renombrado** `datagrowth_common.auth.local` → `datagrowth_common.auth.session_hmac`. Se eliminó toda la integración con Authentik OIDC: `password_login`, `refresh_token`, `userinfo`, `start_oidc`, `oidc_callback`, `register_local`, `magic_link_request`, `password_reset`, `TokenPair`, `OidcStart`. Solo se conserva la cookie HMAC propia (`encode_session`, `decode_session`, `make_session`, `set_session_cookie`, `clear_session_cookie`, `require_session`, `require_group`, `SessionUser`).
- **Removido** del export de `datagrowth_common.testing`: `mock_authentik_responses`.
- **Removido** del export raíz: `AuthUser`, `require_auth`, `require_admin`.

### Compatibilidad

- `datagrowth_common.auth.local` se conserva como alias deprecated que re-exporta desde `auth.session_hmac` y emite `DeprecationWarning` en el import. Se eliminará físicamente en v0.4.0.
- Las apps que generaba el pipeline antiguo (`app-backend/src/agents/prompts/*.md`) seguían referenciando `auth.local`. Esos prompts se reescriben en la Fase I del pivote (apps empaquetadas).

### Migration guide

| Antes (≤ v0.2.x) | Ahora (v0.3.0) |
|---|---|
| `from datagrowth_common.authentik import AuthUser` | `from datagrowth_common.auth.supabase import SupabaseUser` |
| `from datagrowth_common.auth_fastapi import require_auth, require_admin, AuthUserDep, AdminUserDep` | `from datagrowth_common.auth.session import require_session, SessionUserDep` (cookie JWT) o `from datagrowth_common.auth.supabase import require_supabase_jwt, SupabaseUserDep` (`Authorization: Bearer`) |
| `from datagrowth_common.auth.local import SessionUser, require_session, encode_session, decode_session, make_session` | `from datagrowth_common.auth.session_hmac import SessionUser, require_session, encode_session, decode_session, make_session` |
| `from datagrowth_common.auth.local import password_login, oidc_callback, magic_link_request, password_reset, register_local` | Usar `datagrowth_common.auth.router.make_auth_router()` (login email/password + OAuth + magic link + reset via Supabase) |
| `from datagrowth_common.testing import mock_authentik_responses` | Eliminado. Mockear directamente `httpx.AsyncClient` en el test. |

El modelo único de autenticación end-user en v0.3.0 es Supabase Auth:

- `auth.supabase` — `verify_supabase_jwt`, `SupabaseUser`, `require_supabase_jwt`, `SupabaseUserDep`, `require_role(role)`.
- `auth.session` — cookie httpOnly server-rendered con access + refresh JWT (`set_session`, `clear_session`, `refresh_session_tokens`, `require_session`).
- `auth.router` — `make_auth_router()` con endpoints `POST /auth/password`, `POST /auth/register`, `POST /auth/magic-link/request`, `POST /auth/password/reset`, `GET /auth/oauth/{provider}/start|callback`, `POST /auth/refresh`, `POST /logout`, `GET /api/me`.
- `auth.session_hmac` — cookie HMAC propia (fallback para apps internas que no usan Supabase Auth).

### Notas de despliegue

- Apps consumidoras que aún tengan `from datagrowth_common.authentik import ...` o `from datagrowth_common.auth_fastapi import ...` tienen que migrar antes de instalar v0.3.0. El import falla en tiempo de carga del módulo.
- `DG_ADMIN_GROUP` y `DG_USERS_GROUP` (variables de entorno del legacy forward-auth) dejan de leerse. Borrar del `.env` y de la config de Easypanel.

## [0.2.2] — 2026-04-XX

- `auth.supabase_admin` añadidos `create_user_with_password` y `send_password_reset` para flujos de gestión de usuarios end-to-end desde paneles admin (backend interno + apps generadas).

## [0.2.1] — 2026-03-XX

- Añadido `auth.session` (cookie httpOnly server-rendered con refresh).
- Añadido `auth.router` con `auth_router` + `make_auth_router` (login propio + OAuth Microsoft/Google via Supabase + refresh + logout).
- `auth.local` marcado como deprecated.

## [0.2.0] — 2026-02-XX

- Añadido `auth.supabase` (`verify_supabase_jwt`).
- Añadido `auth.supabase_admin` (Admin API: list / invite / delete users).
- Añadido `api.users.users_router`.
- Añadido `get_supabase_admin_client`.

## [0.1.0] — 2026-01-XX

- Primera release pública: `auth.local`, `authentik`, `auth_fastapi`, `result`, `logger`, `supabase`, `shared_models`, `updater`.
