"""Groq driver for prompture.
Requires the `groq` package. Uses GROQ_API_KEY env var.
"""

import logging
import os
from typing import Any

try:
    import groq
except Exception:
    groq = None  # type: ignore[assignment]

from ..infra.cost_mixin import CostMixin
from .base import Driver, _parse_tool_arguments

logger = logging.getLogger(__name__)


class GroqDriver(CostMixin, Driver):
    supports_json_mode = True
    supports_tool_use = True
    supports_vision = True

    # All pricing and model config now resolved from JSON rate files (KB) and
    # models.dev live data.  See prompture/infra/rates/groq.json.
    MODEL_PRICING: dict[str, dict[str, Any]] = {}

    def __init__(self, api_key: str | None = None, model: str = "llama2-70b-4096"):
        """Initialize Groq driver.

        Args:
            api_key: Groq API key (defaults to GROQ_API_KEY env var)
            model: Model to use (defaults to llama2-70b-4096)
        """
        self.api_key = api_key or os.getenv("GROQ_API_KEY")
        self.model = model
        if groq is not None:
            self.client: Any = groq.Client(api_key=self.api_key)
        else:
            self.client = None

    @classmethod
    def list_models(cls, *, api_key: str | None = None, timeout: int = 10, **kw: object) -> list[str] | None:
        """List models available via the Groq API."""
        from .base import _fetch_openai_compatible_models

        key = api_key or os.getenv("GROQ_API_KEY")
        if not key:
            return None
        return _fetch_openai_compatible_models("https://api.groq.com/openai/v1", api_key=key, timeout=timeout)

    supports_messages = True

    def _prepare_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        from .vision_helpers import _prepare_openai_vision_messages

        return _prepare_openai_vision_messages(messages)

    def generate(self, prompt: str, options: dict[str, Any]) -> dict[str, Any]:
        messages = [{"role": "user", "content": prompt}]
        return self._do_generate(messages, options)

    def generate_messages(self, messages: list[dict[str, str]], options: dict[str, Any]) -> dict[str, Any]:
        return self._do_generate(self._prepare_messages(messages), options)

    def _do_generate(self, messages: list[dict[str, str]], options: dict[str, Any]) -> dict[str, Any]:
        if self.client is None:
            raise RuntimeError("groq package is not installed")

        model = options.get("model", self.model)

        # Lookup model-specific config (live models.dev data + hardcoded fallback)
        model_config = self._get_model_config("groq", model)
        tokens_param = model_config["tokens_param"]
        supports_temperature = model_config["supports_temperature"]

        # Base configuration
        opts = {"temperature": 0.7, "max_tokens": 512, **options}

        # Base kwargs for API call
        kwargs = {
            "model": model,
            "messages": messages,
        }

        # Set token limit with correct parameter name
        kwargs[tokens_param] = opts.get("max_tokens", 512)

        # Only include temperature if model supports it
        if supports_temperature and "temperature" in opts:
            kwargs["temperature"] = opts["temperature"]

        # Native JSON mode support
        if options.get("json_mode"):
            kwargs["response_format"] = {"type": "json_object"}

        try:
            resp = self.client.chat.completions.create(**kwargs)
        except Exception:
            # Re-raise any Groq API errors
            raise

        # Extract usage statistics
        from .openai_driver import _extract_openai_cached_tokens

        usage = getattr(resp, "usage", None)
        prompt_tokens = getattr(usage, "prompt_tokens", 0)
        completion_tokens = getattr(usage, "completion_tokens", 0)
        total_tokens = getattr(usage, "total_tokens", 0)
        cached_prompt_tokens = _extract_openai_cached_tokens(usage)

        # Calculate cost via shared mixin (cache hits billed at cache_read rate)
        total_cost = self._calculate_cost(
            "groq",
            model,
            prompt_tokens,
            completion_tokens,
            cached_tokens=cached_prompt_tokens,
        )

        # Standard metadata object
        meta = {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": total_tokens,
            "cached_prompt_tokens": cached_prompt_tokens,
            "cost": round(total_cost, 6),
            "raw_response": resp.model_dump(),
            "model_name": model,
        }

        # Extract generated text
        text = resp.choices[0].message.content or ""
        reasoning_content = getattr(resp.choices[0].message, "reasoning_content", None)

        if not text and reasoning_content:
            text = reasoning_content

        result: dict[str, Any] = {"text": text, "meta": meta}
        if reasoning_content is not None:
            result["reasoning_content"] = reasoning_content
        return result

    # ------------------------------------------------------------------
    # Tool use
    # ------------------------------------------------------------------

    def generate_messages_with_tools(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> dict[str, Any]:
        """Generate a response that may include tool calls."""
        if self.client is None:
            raise RuntimeError("groq package is not installed")

        model = options.get("model", self.model)
        model_config = self._get_model_config("groq", model)
        tokens_param = model_config["tokens_param"]
        supports_temperature = model_config["supports_temperature"]

        self._validate_model_capabilities("groq", model, using_tool_use=True)

        opts = {"temperature": 0.7, "max_tokens": 4096, **options}

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "tools": tools,
        }
        kwargs[tokens_param] = opts.get("max_tokens", 4096)

        if supports_temperature and "temperature" in opts:
            kwargs["temperature"] = opts["temperature"]

        resp = self.client.chat.completions.create(**kwargs)

        from .openai_driver import _extract_openai_cached_tokens

        usage = getattr(resp, "usage", None)
        prompt_tokens = getattr(usage, "prompt_tokens", 0)
        completion_tokens = getattr(usage, "completion_tokens", 0)
        total_tokens = getattr(usage, "total_tokens", 0)
        cached_prompt_tokens = _extract_openai_cached_tokens(usage)
        total_cost = self._calculate_cost(
            "groq",
            model,
            prompt_tokens,
            completion_tokens,
            cached_tokens=cached_prompt_tokens,
        )

        meta = {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": total_tokens,
            "cached_prompt_tokens": cached_prompt_tokens,
            "cost": round(total_cost, 6),
            "raw_response": resp.model_dump(),
            "model_name": model,
        }

        choice = resp.choices[0]
        text = choice.message.content or ""
        stop_reason = choice.finish_reason

        tool_calls_out: list[dict[str, Any]] = []
        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                args = _parse_tool_arguments(tc.function.arguments, tc.function.name, stop_reason)
                tool_calls_out.append(
                    {
                        "id": tc.id,
                        "name": tc.function.name,
                        "arguments": args,
                    }
                )

        result: dict[str, Any] = {
            "text": text,
            "meta": meta,
            "tool_calls": tool_calls_out,
            "stop_reason": stop_reason,
        }
        reasoning_content = getattr(choice.message, "reasoning_content", None)
        if reasoning_content is not None:
            result["reasoning_content"] = reasoning_content
        return result
