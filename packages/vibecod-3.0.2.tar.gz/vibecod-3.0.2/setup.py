from setuptools import setup, find_packages 
 
setup( 
    name="vibecod", 
    version="3.0.2", 
    description="VIBE Language - Python CLI + C++ core", 
    author="VIBE Team", 
    packages=find_packages(), 
    entry_points={ 
        "console_scripts": [ 
            "vibecod = vibecod.__main__:main", 
            "vibe = vibecod.__main__:main" 
        ] 
    }, 
    python_requires=">=3.8", 
) 
