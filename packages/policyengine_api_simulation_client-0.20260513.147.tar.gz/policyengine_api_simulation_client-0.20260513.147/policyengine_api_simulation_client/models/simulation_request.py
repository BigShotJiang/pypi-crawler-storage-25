from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.simulation_request_baseline_type_0 import SimulationRequestBaselineType0
    from ..models.simulation_request_reform_type_0 import SimulationRequestReformType0
    from ..models.telemetry_envelope import TelemetryEnvelope


T = TypeVar("T", bound="SimulationRequest")


@_attrs_define
class SimulationRequest:
    """Request model for simulation submission.

    Attributes:
        country (str):
        version (None | str | Unset):
        telemetry (None | TelemetryEnvelope | Unset):
        scope (None | str | Unset):
        data (None | str | Unset):
        time_period (None | str | Unset):
        reform (None | SimulationRequestReformType0 | Unset):
        baseline (None | SimulationRequestBaselineType0 | Unset):
        region (None | str | Unset):
        subsample (int | None | Unset):
        title (None | str | Unset):
        include_cliffs (bool | None | Unset):
        model_version (None | str | Unset):
        data_version (None | str | Unset):
    """

    country: str
    version: None | str | Unset = UNSET
    telemetry: None | TelemetryEnvelope | Unset = UNSET
    scope: None | str | Unset = UNSET
    data: None | str | Unset = UNSET
    time_period: None | str | Unset = UNSET
    reform: None | SimulationRequestReformType0 | Unset = UNSET
    baseline: None | SimulationRequestBaselineType0 | Unset = UNSET
    region: None | str | Unset = UNSET
    subsample: int | None | Unset = UNSET
    title: None | str | Unset = UNSET
    include_cliffs: bool | None | Unset = UNSET
    model_version: None | str | Unset = UNSET
    data_version: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.simulation_request_baseline_type_0 import SimulationRequestBaselineType0
        from ..models.simulation_request_reform_type_0 import SimulationRequestReformType0
        from ..models.telemetry_envelope import TelemetryEnvelope

        country = self.country

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        telemetry: dict[str, Any] | None | Unset
        if isinstance(self.telemetry, Unset):
            telemetry = UNSET
        elif isinstance(self.telemetry, TelemetryEnvelope):
            telemetry = self.telemetry.to_dict()
        else:
            telemetry = self.telemetry

        scope: None | str | Unset
        if isinstance(self.scope, Unset):
            scope = UNSET
        else:
            scope = self.scope

        data: None | str | Unset
        if isinstance(self.data, Unset):
            data = UNSET
        else:
            data = self.data

        time_period: None | str | Unset
        if isinstance(self.time_period, Unset):
            time_period = UNSET
        else:
            time_period = self.time_period

        reform: dict[str, Any] | None | Unset
        if isinstance(self.reform, Unset):
            reform = UNSET
        elif isinstance(self.reform, SimulationRequestReformType0):
            reform = self.reform.to_dict()
        else:
            reform = self.reform

        baseline: dict[str, Any] | None | Unset
        if isinstance(self.baseline, Unset):
            baseline = UNSET
        elif isinstance(self.baseline, SimulationRequestBaselineType0):
            baseline = self.baseline.to_dict()
        else:
            baseline = self.baseline

        region: None | str | Unset
        if isinstance(self.region, Unset):
            region = UNSET
        else:
            region = self.region

        subsample: int | None | Unset
        if isinstance(self.subsample, Unset):
            subsample = UNSET
        else:
            subsample = self.subsample

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        include_cliffs: bool | None | Unset
        if isinstance(self.include_cliffs, Unset):
            include_cliffs = UNSET
        else:
            include_cliffs = self.include_cliffs

        model_version: None | str | Unset
        if isinstance(self.model_version, Unset):
            model_version = UNSET
        else:
            model_version = self.model_version

        data_version: None | str | Unset
        if isinstance(self.data_version, Unset):
            data_version = UNSET
        else:
            data_version = self.data_version

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "country": country,
            }
        )
        if version is not UNSET:
            field_dict["version"] = version
        if telemetry is not UNSET:
            field_dict["telemetry"] = telemetry
        if scope is not UNSET:
            field_dict["scope"] = scope
        if data is not UNSET:
            field_dict["data"] = data
        if time_period is not UNSET:
            field_dict["time_period"] = time_period
        if reform is not UNSET:
            field_dict["reform"] = reform
        if baseline is not UNSET:
            field_dict["baseline"] = baseline
        if region is not UNSET:
            field_dict["region"] = region
        if subsample is not UNSET:
            field_dict["subsample"] = subsample
        if title is not UNSET:
            field_dict["title"] = title
        if include_cliffs is not UNSET:
            field_dict["include_cliffs"] = include_cliffs
        if model_version is not UNSET:
            field_dict["model_version"] = model_version
        if data_version is not UNSET:
            field_dict["data_version"] = data_version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.simulation_request_baseline_type_0 import SimulationRequestBaselineType0
        from ..models.simulation_request_reform_type_0 import SimulationRequestReformType0
        from ..models.telemetry_envelope import TelemetryEnvelope

        d = dict(src_dict)
        country = d.pop("country")

        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_telemetry(data: object) -> None | TelemetryEnvelope | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                telemetry_type_0 = TelemetryEnvelope.from_dict(data)

                return telemetry_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TelemetryEnvelope | Unset, data)

        telemetry = _parse_telemetry(d.pop("telemetry", UNSET))

        def _parse_scope(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        scope = _parse_scope(d.pop("scope", UNSET))

        def _parse_data(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data = _parse_data(d.pop("data", UNSET))

        def _parse_time_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        time_period = _parse_time_period(d.pop("time_period", UNSET))

        def _parse_reform(data: object) -> None | SimulationRequestReformType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                reform_type_0 = SimulationRequestReformType0.from_dict(data)

                return reform_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SimulationRequestReformType0 | Unset, data)

        reform = _parse_reform(d.pop("reform", UNSET))

        def _parse_baseline(data: object) -> None | SimulationRequestBaselineType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                baseline_type_0 = SimulationRequestBaselineType0.from_dict(data)

                return baseline_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SimulationRequestBaselineType0 | Unset, data)

        baseline = _parse_baseline(d.pop("baseline", UNSET))

        def _parse_region(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        region = _parse_region(d.pop("region", UNSET))

        def _parse_subsample(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        subsample = _parse_subsample(d.pop("subsample", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_include_cliffs(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        include_cliffs = _parse_include_cliffs(d.pop("include_cliffs", UNSET))

        def _parse_model_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_version = _parse_model_version(d.pop("model_version", UNSET))

        def _parse_data_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data_version = _parse_data_version(d.pop("data_version", UNSET))

        simulation_request = cls(
            country=country,
            version=version,
            telemetry=telemetry,
            scope=scope,
            data=data,
            time_period=time_period,
            reform=reform,
            baseline=baseline,
            region=region,
            subsample=subsample,
            title=title,
            include_cliffs=include_cliffs,
            model_version=model_version,
            data_version=data_version,
        )

        return simulation_request
