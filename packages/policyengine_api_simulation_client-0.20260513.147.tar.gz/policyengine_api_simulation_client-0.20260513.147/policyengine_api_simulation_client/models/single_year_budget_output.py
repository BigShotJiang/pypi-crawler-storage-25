from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SingleYearBudgetOutput")


@_attrs_define
class SingleYearBudgetOutput:
    """Budget section for one macro-scoped economy comparison.

    The gateway owns only the stable fields it needs for budget-window
    aggregation. Additional worker-provided budget fields are passed through.

        Attributes:
            budgetary_impact (float):
            tax_revenue_impact (float):
            benefit_spending_impact (float):
            state_tax_revenue_impact (float | Unset):  Default: 0.0.
    """

    budgetary_impact: float
    tax_revenue_impact: float
    benefit_spending_impact: float
    state_tax_revenue_impact: float | Unset = 0.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        budgetary_impact = self.budgetary_impact

        tax_revenue_impact = self.tax_revenue_impact

        benefit_spending_impact = self.benefit_spending_impact

        state_tax_revenue_impact = self.state_tax_revenue_impact

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "budgetary_impact": budgetary_impact,
                "tax_revenue_impact": tax_revenue_impact,
                "benefit_spending_impact": benefit_spending_impact,
            }
        )
        if state_tax_revenue_impact is not UNSET:
            field_dict["state_tax_revenue_impact"] = state_tax_revenue_impact

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        budgetary_impact = d.pop("budgetary_impact")

        tax_revenue_impact = d.pop("tax_revenue_impact")

        benefit_spending_impact = d.pop("benefit_spending_impact")

        state_tax_revenue_impact = d.pop("state_tax_revenue_impact", UNSET)

        single_year_budget_output = cls(
            budgetary_impact=budgetary_impact,
            tax_revenue_impact=tax_revenue_impact,
            benefit_spending_impact=benefit_spending_impact,
            state_tax_revenue_impact=state_tax_revenue_impact,
        )

        single_year_budget_output.additional_properties = d
        return single_year_budget_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
