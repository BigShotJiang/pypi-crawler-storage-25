from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.single_year_budget_output import SingleYearBudgetOutput
    from ..models.single_year_macro_output_cliff_impact_type_0 import SingleYearMacroOutputCliffImpactType0
    from ..models.single_year_macro_output_congressional_district_impact_type_0 import (
        SingleYearMacroOutputCongressionalDistrictImpactType0,
    )
    from ..models.single_year_macro_output_constituency_impact_type_0 import (
        SingleYearMacroOutputConstituencyImpactType0,
    )
    from ..models.single_year_macro_output_decile import SingleYearMacroOutputDecile
    from ..models.single_year_macro_output_detailed_budget_type_0 import SingleYearMacroOutputDetailedBudgetType0
    from ..models.single_year_macro_output_inequality import SingleYearMacroOutputInequality
    from ..models.single_year_macro_output_intra_decile import SingleYearMacroOutputIntraDecile
    from ..models.single_year_macro_output_intra_wealth_decile_type_0 import SingleYearMacroOutputIntraWealthDecileType0
    from ..models.single_year_macro_output_labor_supply_response import SingleYearMacroOutputLaborSupplyResponse
    from ..models.single_year_macro_output_local_authority_impact_type_0 import (
        SingleYearMacroOutputLocalAuthorityImpactType0,
    )
    from ..models.single_year_macro_output_poverty import SingleYearMacroOutputPoverty
    from ..models.single_year_macro_output_poverty_by_gender import SingleYearMacroOutputPovertyByGender
    from ..models.single_year_macro_output_poverty_by_race_type_0 import SingleYearMacroOutputPovertyByRaceType0
    from ..models.single_year_macro_output_wealth_decile_type_0 import SingleYearMacroOutputWealthDecileType0


T = TypeVar("T", bound="SingleYearMacroOutput")


@_attrs_define
class SingleYearMacroOutput:
    """Gateway-owned full output shape for one macro-scoped comparison.

    This intentionally avoids subclassing policyengine's internal
    EconomyComparison model. The gateway validates the stable top-level shape
    and fiscal fields it relies on, while passing nested result sections
    through without coupling to a specific worker package version.

        Attributes:
            budget (SingleYearBudgetOutput): Budget section for one macro-scoped economy comparison.

                The gateway owns only the stable fields it needs for budget-window
                aggregation. Additional worker-provided budget fields are passed through.
            detailed_budget (None | SingleYearMacroOutputDetailedBudgetType0):
            decile (SingleYearMacroOutputDecile):
            inequality (SingleYearMacroOutputInequality):
            poverty (SingleYearMacroOutputPoverty):
            poverty_by_gender (SingleYearMacroOutputPovertyByGender):
            poverty_by_race (None | SingleYearMacroOutputPovertyByRaceType0):
            intra_decile (SingleYearMacroOutputIntraDecile):
            wealth_decile (None | SingleYearMacroOutputWealthDecileType0):
            intra_wealth_decile (None | SingleYearMacroOutputIntraWealthDecileType0):
            labor_supply_response (SingleYearMacroOutputLaborSupplyResponse):
            constituency_impact (None | SingleYearMacroOutputConstituencyImpactType0):
            local_authority_impact (None | SingleYearMacroOutputLocalAuthorityImpactType0):
            congressional_district_impact (None | SingleYearMacroOutputCongressionalDistrictImpactType0):
            cliff_impact (None | SingleYearMacroOutputCliffImpactType0):
            model_version (None | str | Unset):
            data_version (None | str | Unset):
    """

    budget: SingleYearBudgetOutput
    detailed_budget: None | SingleYearMacroOutputDetailedBudgetType0
    decile: SingleYearMacroOutputDecile
    inequality: SingleYearMacroOutputInequality
    poverty: SingleYearMacroOutputPoverty
    poverty_by_gender: SingleYearMacroOutputPovertyByGender
    poverty_by_race: None | SingleYearMacroOutputPovertyByRaceType0
    intra_decile: SingleYearMacroOutputIntraDecile
    wealth_decile: None | SingleYearMacroOutputWealthDecileType0
    intra_wealth_decile: None | SingleYearMacroOutputIntraWealthDecileType0
    labor_supply_response: SingleYearMacroOutputLaborSupplyResponse
    constituency_impact: None | SingleYearMacroOutputConstituencyImpactType0
    local_authority_impact: None | SingleYearMacroOutputLocalAuthorityImpactType0
    congressional_district_impact: None | SingleYearMacroOutputCongressionalDistrictImpactType0
    cliff_impact: None | SingleYearMacroOutputCliffImpactType0
    model_version: None | str | Unset = UNSET
    data_version: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.single_year_macro_output_cliff_impact_type_0 import SingleYearMacroOutputCliffImpactType0
        from ..models.single_year_macro_output_congressional_district_impact_type_0 import (
            SingleYearMacroOutputCongressionalDistrictImpactType0,
        )
        from ..models.single_year_macro_output_constituency_impact_type_0 import (
            SingleYearMacroOutputConstituencyImpactType0,
        )
        from ..models.single_year_macro_output_detailed_budget_type_0 import SingleYearMacroOutputDetailedBudgetType0
        from ..models.single_year_macro_output_intra_wealth_decile_type_0 import (
            SingleYearMacroOutputIntraWealthDecileType0,
        )
        from ..models.single_year_macro_output_local_authority_impact_type_0 import (
            SingleYearMacroOutputLocalAuthorityImpactType0,
        )
        from ..models.single_year_macro_output_poverty_by_race_type_0 import SingleYearMacroOutputPovertyByRaceType0
        from ..models.single_year_macro_output_wealth_decile_type_0 import SingleYearMacroOutputWealthDecileType0

        budget = self.budget.to_dict()

        detailed_budget: dict[str, Any] | None
        if isinstance(self.detailed_budget, SingleYearMacroOutputDetailedBudgetType0):
            detailed_budget = self.detailed_budget.to_dict()
        else:
            detailed_budget = self.detailed_budget

        decile = self.decile.to_dict()

        inequality = self.inequality.to_dict()

        poverty = self.poverty.to_dict()

        poverty_by_gender = self.poverty_by_gender.to_dict()

        poverty_by_race: dict[str, Any] | None
        if isinstance(self.poverty_by_race, SingleYearMacroOutputPovertyByRaceType0):
            poverty_by_race = self.poverty_by_race.to_dict()
        else:
            poverty_by_race = self.poverty_by_race

        intra_decile = self.intra_decile.to_dict()

        wealth_decile: dict[str, Any] | None
        if isinstance(self.wealth_decile, SingleYearMacroOutputWealthDecileType0):
            wealth_decile = self.wealth_decile.to_dict()
        else:
            wealth_decile = self.wealth_decile

        intra_wealth_decile: dict[str, Any] | None
        if isinstance(self.intra_wealth_decile, SingleYearMacroOutputIntraWealthDecileType0):
            intra_wealth_decile = self.intra_wealth_decile.to_dict()
        else:
            intra_wealth_decile = self.intra_wealth_decile

        labor_supply_response = self.labor_supply_response.to_dict()

        constituency_impact: dict[str, Any] | None
        if isinstance(self.constituency_impact, SingleYearMacroOutputConstituencyImpactType0):
            constituency_impact = self.constituency_impact.to_dict()
        else:
            constituency_impact = self.constituency_impact

        local_authority_impact: dict[str, Any] | None
        if isinstance(self.local_authority_impact, SingleYearMacroOutputLocalAuthorityImpactType0):
            local_authority_impact = self.local_authority_impact.to_dict()
        else:
            local_authority_impact = self.local_authority_impact

        congressional_district_impact: dict[str, Any] | None
        if isinstance(self.congressional_district_impact, SingleYearMacroOutputCongressionalDistrictImpactType0):
            congressional_district_impact = self.congressional_district_impact.to_dict()
        else:
            congressional_district_impact = self.congressional_district_impact

        cliff_impact: dict[str, Any] | None
        if isinstance(self.cliff_impact, SingleYearMacroOutputCliffImpactType0):
            cliff_impact = self.cliff_impact.to_dict()
        else:
            cliff_impact = self.cliff_impact

        model_version: None | str | Unset
        if isinstance(self.model_version, Unset):
            model_version = UNSET
        else:
            model_version = self.model_version

        data_version: None | str | Unset
        if isinstance(self.data_version, Unset):
            data_version = UNSET
        else:
            data_version = self.data_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "budget": budget,
                "detailed_budget": detailed_budget,
                "decile": decile,
                "inequality": inequality,
                "poverty": poverty,
                "poverty_by_gender": poverty_by_gender,
                "poverty_by_race": poverty_by_race,
                "intra_decile": intra_decile,
                "wealth_decile": wealth_decile,
                "intra_wealth_decile": intra_wealth_decile,
                "labor_supply_response": labor_supply_response,
                "constituency_impact": constituency_impact,
                "local_authority_impact": local_authority_impact,
                "congressional_district_impact": congressional_district_impact,
                "cliff_impact": cliff_impact,
            }
        )
        if model_version is not UNSET:
            field_dict["model_version"] = model_version
        if data_version is not UNSET:
            field_dict["data_version"] = data_version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.single_year_budget_output import SingleYearBudgetOutput
        from ..models.single_year_macro_output_cliff_impact_type_0 import SingleYearMacroOutputCliffImpactType0
        from ..models.single_year_macro_output_congressional_district_impact_type_0 import (
            SingleYearMacroOutputCongressionalDistrictImpactType0,
        )
        from ..models.single_year_macro_output_constituency_impact_type_0 import (
            SingleYearMacroOutputConstituencyImpactType0,
        )
        from ..models.single_year_macro_output_decile import SingleYearMacroOutputDecile
        from ..models.single_year_macro_output_detailed_budget_type_0 import SingleYearMacroOutputDetailedBudgetType0
        from ..models.single_year_macro_output_inequality import SingleYearMacroOutputInequality
        from ..models.single_year_macro_output_intra_decile import SingleYearMacroOutputIntraDecile
        from ..models.single_year_macro_output_intra_wealth_decile_type_0 import (
            SingleYearMacroOutputIntraWealthDecileType0,
        )
        from ..models.single_year_macro_output_labor_supply_response import SingleYearMacroOutputLaborSupplyResponse
        from ..models.single_year_macro_output_local_authority_impact_type_0 import (
            SingleYearMacroOutputLocalAuthorityImpactType0,
        )
        from ..models.single_year_macro_output_poverty import SingleYearMacroOutputPoverty
        from ..models.single_year_macro_output_poverty_by_gender import SingleYearMacroOutputPovertyByGender
        from ..models.single_year_macro_output_poverty_by_race_type_0 import SingleYearMacroOutputPovertyByRaceType0
        from ..models.single_year_macro_output_wealth_decile_type_0 import SingleYearMacroOutputWealthDecileType0

        d = dict(src_dict)
        budget = SingleYearBudgetOutput.from_dict(d.pop("budget"))

        def _parse_detailed_budget(data: object) -> None | SingleYearMacroOutputDetailedBudgetType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detailed_budget_type_0 = SingleYearMacroOutputDetailedBudgetType0.from_dict(data)

                return detailed_budget_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputDetailedBudgetType0, data)

        detailed_budget = _parse_detailed_budget(d.pop("detailed_budget"))

        decile = SingleYearMacroOutputDecile.from_dict(d.pop("decile"))

        inequality = SingleYearMacroOutputInequality.from_dict(d.pop("inequality"))

        poverty = SingleYearMacroOutputPoverty.from_dict(d.pop("poverty"))

        poverty_by_gender = SingleYearMacroOutputPovertyByGender.from_dict(d.pop("poverty_by_gender"))

        def _parse_poverty_by_race(data: object) -> None | SingleYearMacroOutputPovertyByRaceType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                poverty_by_race_type_0 = SingleYearMacroOutputPovertyByRaceType0.from_dict(data)

                return poverty_by_race_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputPovertyByRaceType0, data)

        poverty_by_race = _parse_poverty_by_race(d.pop("poverty_by_race"))

        intra_decile = SingleYearMacroOutputIntraDecile.from_dict(d.pop("intra_decile"))

        def _parse_wealth_decile(data: object) -> None | SingleYearMacroOutputWealthDecileType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                wealth_decile_type_0 = SingleYearMacroOutputWealthDecileType0.from_dict(data)

                return wealth_decile_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputWealthDecileType0, data)

        wealth_decile = _parse_wealth_decile(d.pop("wealth_decile"))

        def _parse_intra_wealth_decile(data: object) -> None | SingleYearMacroOutputIntraWealthDecileType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                intra_wealth_decile_type_0 = SingleYearMacroOutputIntraWealthDecileType0.from_dict(data)

                return intra_wealth_decile_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputIntraWealthDecileType0, data)

        intra_wealth_decile = _parse_intra_wealth_decile(d.pop("intra_wealth_decile"))

        labor_supply_response = SingleYearMacroOutputLaborSupplyResponse.from_dict(d.pop("labor_supply_response"))

        def _parse_constituency_impact(data: object) -> None | SingleYearMacroOutputConstituencyImpactType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                constituency_impact_type_0 = SingleYearMacroOutputConstituencyImpactType0.from_dict(data)

                return constituency_impact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputConstituencyImpactType0, data)

        constituency_impact = _parse_constituency_impact(d.pop("constituency_impact"))

        def _parse_local_authority_impact(data: object) -> None | SingleYearMacroOutputLocalAuthorityImpactType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                local_authority_impact_type_0 = SingleYearMacroOutputLocalAuthorityImpactType0.from_dict(data)

                return local_authority_impact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputLocalAuthorityImpactType0, data)

        local_authority_impact = _parse_local_authority_impact(d.pop("local_authority_impact"))

        def _parse_congressional_district_impact(
            data: object,
        ) -> None | SingleYearMacroOutputCongressionalDistrictImpactType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                congressional_district_impact_type_0 = SingleYearMacroOutputCongressionalDistrictImpactType0.from_dict(
                    data
                )

                return congressional_district_impact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputCongressionalDistrictImpactType0, data)

        congressional_district_impact = _parse_congressional_district_impact(d.pop("congressional_district_impact"))

        def _parse_cliff_impact(data: object) -> None | SingleYearMacroOutputCliffImpactType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                cliff_impact_type_0 = SingleYearMacroOutputCliffImpactType0.from_dict(data)

                return cliff_impact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleYearMacroOutputCliffImpactType0, data)

        cliff_impact = _parse_cliff_impact(d.pop("cliff_impact"))

        def _parse_model_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_version = _parse_model_version(d.pop("model_version", UNSET))

        def _parse_data_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data_version = _parse_data_version(d.pop("data_version", UNSET))

        single_year_macro_output = cls(
            budget=budget,
            detailed_budget=detailed_budget,
            decile=decile,
            inequality=inequality,
            poverty=poverty,
            poverty_by_gender=poverty_by_gender,
            poverty_by_race=poverty_by_race,
            intra_decile=intra_decile,
            wealth_decile=wealth_decile,
            intra_wealth_decile=intra_wealth_decile,
            labor_supply_response=labor_supply_response,
            constituency_impact=constituency_impact,
            local_authority_impact=local_authority_impact,
            congressional_district_impact=congressional_district_impact,
            cliff_impact=cliff_impact,
            model_version=model_version,
            data_version=data_version,
        )

        single_year_macro_output.additional_properties = d
        return single_year_macro_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
