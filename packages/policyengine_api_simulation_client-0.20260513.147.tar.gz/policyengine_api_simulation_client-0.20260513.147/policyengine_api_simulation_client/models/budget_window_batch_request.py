from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.budget_window_batch_request_baseline_type_0 import BudgetWindowBatchRequestBaselineType0
    from ..models.budget_window_batch_request_reform_type_0 import BudgetWindowBatchRequestReformType0
    from ..models.telemetry_envelope import TelemetryEnvelope


T = TypeVar("T", bound="BudgetWindowBatchRequest")


@_attrs_define
class BudgetWindowBatchRequest:
    """Request model for budget-window batch submission.

    Attributes:
        country (str):
        region (str):
        start_year (str):
        window_size (int):
        version (None | str | Unset):
        telemetry (None | TelemetryEnvelope | Unset):
        scope (None | str | Unset):
        data (None | str | Unset):
        time_period (None | str | Unset):
        reform (BudgetWindowBatchRequestReformType0 | None | Unset):
        baseline (BudgetWindowBatchRequestBaselineType0 | None | Unset):
        subsample (int | None | Unset):
        title (None | str | Unset):
        include_cliffs (bool | None | Unset):
        model_version (None | str | Unset):
        data_version (None | str | Unset):
        max_parallel (int | Unset):  Default: 20.
        target (Literal['general'] | Unset):  Default: 'general'.
    """

    country: str
    region: str
    start_year: str
    window_size: int
    version: None | str | Unset = UNSET
    telemetry: None | TelemetryEnvelope | Unset = UNSET
    scope: None | str | Unset = UNSET
    data: None | str | Unset = UNSET
    time_period: None | str | Unset = UNSET
    reform: BudgetWindowBatchRequestReformType0 | None | Unset = UNSET
    baseline: BudgetWindowBatchRequestBaselineType0 | None | Unset = UNSET
    subsample: int | None | Unset = UNSET
    title: None | str | Unset = UNSET
    include_cliffs: bool | None | Unset = UNSET
    model_version: None | str | Unset = UNSET
    data_version: None | str | Unset = UNSET
    max_parallel: int | Unset = 20
    target: Literal["general"] | Unset = "general"

    def to_dict(self) -> dict[str, Any]:
        from ..models.budget_window_batch_request_baseline_type_0 import BudgetWindowBatchRequestBaselineType0
        from ..models.budget_window_batch_request_reform_type_0 import BudgetWindowBatchRequestReformType0
        from ..models.telemetry_envelope import TelemetryEnvelope

        country = self.country

        region = self.region

        start_year = self.start_year

        window_size = self.window_size

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        telemetry: dict[str, Any] | None | Unset
        if isinstance(self.telemetry, Unset):
            telemetry = UNSET
        elif isinstance(self.telemetry, TelemetryEnvelope):
            telemetry = self.telemetry.to_dict()
        else:
            telemetry = self.telemetry

        scope: None | str | Unset
        if isinstance(self.scope, Unset):
            scope = UNSET
        else:
            scope = self.scope

        data: None | str | Unset
        if isinstance(self.data, Unset):
            data = UNSET
        else:
            data = self.data

        time_period: None | str | Unset
        if isinstance(self.time_period, Unset):
            time_period = UNSET
        else:
            time_period = self.time_period

        reform: dict[str, Any] | None | Unset
        if isinstance(self.reform, Unset):
            reform = UNSET
        elif isinstance(self.reform, BudgetWindowBatchRequestReformType0):
            reform = self.reform.to_dict()
        else:
            reform = self.reform

        baseline: dict[str, Any] | None | Unset
        if isinstance(self.baseline, Unset):
            baseline = UNSET
        elif isinstance(self.baseline, BudgetWindowBatchRequestBaselineType0):
            baseline = self.baseline.to_dict()
        else:
            baseline = self.baseline

        subsample: int | None | Unset
        if isinstance(self.subsample, Unset):
            subsample = UNSET
        else:
            subsample = self.subsample

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        include_cliffs: bool | None | Unset
        if isinstance(self.include_cliffs, Unset):
            include_cliffs = UNSET
        else:
            include_cliffs = self.include_cliffs

        model_version: None | str | Unset
        if isinstance(self.model_version, Unset):
            model_version = UNSET
        else:
            model_version = self.model_version

        data_version: None | str | Unset
        if isinstance(self.data_version, Unset):
            data_version = UNSET
        else:
            data_version = self.data_version

        max_parallel = self.max_parallel

        target = self.target

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "country": country,
                "region": region,
                "start_year": start_year,
                "window_size": window_size,
            }
        )
        if version is not UNSET:
            field_dict["version"] = version
        if telemetry is not UNSET:
            field_dict["telemetry"] = telemetry
        if scope is not UNSET:
            field_dict["scope"] = scope
        if data is not UNSET:
            field_dict["data"] = data
        if time_period is not UNSET:
            field_dict["time_period"] = time_period
        if reform is not UNSET:
            field_dict["reform"] = reform
        if baseline is not UNSET:
            field_dict["baseline"] = baseline
        if subsample is not UNSET:
            field_dict["subsample"] = subsample
        if title is not UNSET:
            field_dict["title"] = title
        if include_cliffs is not UNSET:
            field_dict["include_cliffs"] = include_cliffs
        if model_version is not UNSET:
            field_dict["model_version"] = model_version
        if data_version is not UNSET:
            field_dict["data_version"] = data_version
        if max_parallel is not UNSET:
            field_dict["max_parallel"] = max_parallel
        if target is not UNSET:
            field_dict["target"] = target

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.budget_window_batch_request_baseline_type_0 import BudgetWindowBatchRequestBaselineType0
        from ..models.budget_window_batch_request_reform_type_0 import BudgetWindowBatchRequestReformType0
        from ..models.telemetry_envelope import TelemetryEnvelope

        d = dict(src_dict)
        country = d.pop("country")

        region = d.pop("region")

        start_year = d.pop("start_year")

        window_size = d.pop("window_size")

        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_telemetry(data: object) -> None | TelemetryEnvelope | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                telemetry_type_0 = TelemetryEnvelope.from_dict(data)

                return telemetry_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TelemetryEnvelope | Unset, data)

        telemetry = _parse_telemetry(d.pop("telemetry", UNSET))

        def _parse_scope(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        scope = _parse_scope(d.pop("scope", UNSET))

        def _parse_data(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data = _parse_data(d.pop("data", UNSET))

        def _parse_time_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        time_period = _parse_time_period(d.pop("time_period", UNSET))

        def _parse_reform(data: object) -> BudgetWindowBatchRequestReformType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                reform_type_0 = BudgetWindowBatchRequestReformType0.from_dict(data)

                return reform_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BudgetWindowBatchRequestReformType0 | None | Unset, data)

        reform = _parse_reform(d.pop("reform", UNSET))

        def _parse_baseline(data: object) -> BudgetWindowBatchRequestBaselineType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                baseline_type_0 = BudgetWindowBatchRequestBaselineType0.from_dict(data)

                return baseline_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BudgetWindowBatchRequestBaselineType0 | None | Unset, data)

        baseline = _parse_baseline(d.pop("baseline", UNSET))

        def _parse_subsample(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        subsample = _parse_subsample(d.pop("subsample", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_include_cliffs(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        include_cliffs = _parse_include_cliffs(d.pop("include_cliffs", UNSET))

        def _parse_model_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_version = _parse_model_version(d.pop("model_version", UNSET))

        def _parse_data_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data_version = _parse_data_version(d.pop("data_version", UNSET))

        max_parallel = d.pop("max_parallel", UNSET)

        target = cast(Literal["general"] | Unset, d.pop("target", UNSET))
        if target != "general" and not isinstance(target, Unset):
            raise ValueError(f"target must match const 'general', got '{target}'")

        budget_window_batch_request = cls(
            country=country,
            region=region,
            start_year=start_year,
            window_size=window_size,
            version=version,
            telemetry=telemetry,
            scope=scope,
            data=data,
            time_period=time_period,
            reform=reform,
            baseline=baseline,
            subsample=subsample,
            title=title,
            include_cliffs=include_cliffs,
            model_version=model_version,
            data_version=data_version,
            max_parallel=max_parallel,
            target=target,
        )

        return budget_window_batch_request
