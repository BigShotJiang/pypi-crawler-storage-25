from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policy_engine_bundle import PolicyEngineBundle


T = TypeVar("T", bound="JobStatusResponse")


@_attrs_define
class JobStatusResponse:
    """Response model for job status polling.

    Attributes:
        status (str):
        result (Any | None | Unset):
        error (None | str | Unset):
        resolved_app_name (None | str | Unset):
        policyengine_bundle (None | PolicyEngineBundle | Unset):
        run_id (None | str | Unset):
    """

    status: str
    result: Any | None | Unset = UNSET
    error: None | str | Unset = UNSET
    resolved_app_name: None | str | Unset = UNSET
    policyengine_bundle: None | PolicyEngineBundle | Unset = UNSET
    run_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.policy_engine_bundle import PolicyEngineBundle

        status = self.status

        result: Any | None | Unset
        if isinstance(self.result, Unset):
            result = UNSET
        else:
            result = self.result

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        resolved_app_name: None | str | Unset
        if isinstance(self.resolved_app_name, Unset):
            resolved_app_name = UNSET
        else:
            resolved_app_name = self.resolved_app_name

        policyengine_bundle: dict[str, Any] | None | Unset
        if isinstance(self.policyengine_bundle, Unset):
            policyengine_bundle = UNSET
        elif isinstance(self.policyengine_bundle, PolicyEngineBundle):
            policyengine_bundle = self.policyengine_bundle.to_dict()
        else:
            policyengine_bundle = self.policyengine_bundle

        run_id: None | str | Unset
        if isinstance(self.run_id, Unset):
            run_id = UNSET
        else:
            run_id = self.run_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )
        if result is not UNSET:
            field_dict["result"] = result
        if error is not UNSET:
            field_dict["error"] = error
        if resolved_app_name is not UNSET:
            field_dict["resolved_app_name"] = resolved_app_name
        if policyengine_bundle is not UNSET:
            field_dict["policyengine_bundle"] = policyengine_bundle
        if run_id is not UNSET:
            field_dict["run_id"] = run_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.policy_engine_bundle import PolicyEngineBundle

        d = dict(src_dict)
        status = d.pop("status")

        def _parse_result(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        result = _parse_result(d.pop("result", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_resolved_app_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resolved_app_name = _parse_resolved_app_name(d.pop("resolved_app_name", UNSET))

        def _parse_policyengine_bundle(data: object) -> None | PolicyEngineBundle | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                policyengine_bundle_type_0 = PolicyEngineBundle.from_dict(data)

                return policyengine_bundle_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PolicyEngineBundle | Unset, data)

        policyengine_bundle = _parse_policyengine_bundle(d.pop("policyengine_bundle", UNSET))

        def _parse_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        run_id = _parse_run_id(d.pop("run_id", UNSET))

        job_status_response = cls(
            status=status,
            result=result,
            error=error,
            resolved_app_name=resolved_app_name,
            policyengine_bundle=policyengine_bundle,
            run_id=run_id,
        )

        job_status_response.additional_properties = d
        return job_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
