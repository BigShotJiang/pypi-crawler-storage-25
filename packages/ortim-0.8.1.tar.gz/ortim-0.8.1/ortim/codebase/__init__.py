# SPDX-License-Identifier: FSL-1.1-Apache-2.0
# Copyright (c) 2026 ortim.dev
"""Brownfield codebase reader (M1).

Public surface:

    from ortim.codebase import scan_codebase, CodebaseSummary

The reader walks a workspace, builds a structured summary (files, languages,
frameworks, public symbols), and caches the result for incremental rescans.
"""

from ortim.codebase.baseline import (
    RegressionReport,
    TestBaseline,
    capture as capture_baseline,
    check_regression,
    detect_test_cmd,
    load_baseline,
    parse_test_count,
    write_baseline,
)
from ortim.codebase.exports import ExportSignature, extract_exports
from ortim.codebase.prior_tasks import (
    ModuleExports,
    collect_prior_outputs,
    format_prior_outputs_block,
)
from ortim.codebase.reader import read_related, scan_codebase
from ortim.codebase.schema import (
    CodebaseSummary,
    FileEntry,
    FrameworkHint,
    ModuleSymbols,
    ScanStats,
)

__all__ = [
    "CodebaseSummary",
    "ExportSignature",
    "FileEntry",
    "FrameworkHint",
    "ModuleExports",
    "ModuleSymbols",
    "RegressionReport",
    "ScanStats",
    "TestBaseline",
    "capture_baseline",
    "check_regression",
    "collect_prior_outputs",
    "detect_test_cmd",
    "extract_exports",
    "format_prior_outputs_block",
    "load_baseline",
    "parse_test_count",
    "read_related",
    "scan_codebase",
    "write_baseline",
]
