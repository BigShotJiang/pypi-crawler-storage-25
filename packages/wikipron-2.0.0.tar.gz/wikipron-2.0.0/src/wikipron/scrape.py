import random
import re
import time
import unicodedata
from importlib.metadata import version

from typing import Any

import requests

from wikipron.config import Config
from wikipron.html_utils import HTMLResponse
from wikipron.typing import Iterator, WordPronPair

# Queries for the MediaWiki backend.
# Documentation here: https://www.mediawiki.org/wiki/API:Categorymembers
_CATEGORY_TEMPLATE = "Category:{language} terms with IPA pronunciation"
# Selects the content on the page.
_PAGE_TEMPLATE = "https://en.wiktionary.org/wiki/{word}"
# Http headers for api call
HTTP_HEADERS = {
    "User-Agent": (
        f"WikiPron/{version('wikipron')} "
        "(https://github.com/CUNY-CL/wikipron) "
        f"requests/{requests.__version__}"
    ),
}

# Exponential backoff parameters for retrying after connection errors.
# Formula of delay: min(BASE * 2^retries + random(0, 1), MAX)
_BACKOFF_BASE = 5  # seconds
_BACKOFF_MAX = 300  # seconds


def _skip_word(word: str, skip_spaces: bool) -> bool:
    # Skips reconstructions.
    if word.startswith("*"):
        return True
    # Skips multiword examples.
    if skip_spaces and (" " in word or "\u00a0" in word):
        return True
    # Skips examples containing a dash.
    if "-" in word:
        return True
    # Skips examples containing digits.
    if re.search(r"\d", word):
        return True
    return False


def _skip_date(date_from_word: str, cut_off_date: str) -> bool:
    return date_from_word > cut_off_date


def _iter_page_responses_once(
    data, session: requests.Session, config: Config
) -> "Iterator[tuple[str, HTMLResponse]]":
    for member in data["query"]["categorymembers"]:
        title = member["title"]
        timestamp = member["timestamp"]
        config.restart_key = member["sortkey"]
        if _skip_word(title, config.skip_spaces_word) or _skip_date(
            timestamp, config.cut_off_date
        ):
            continue
        response = session.get(_PAGE_TEMPLATE.format(word=title), timeout=10)
        yield title, HTMLResponse(response)


# All living + dead Chinese varieties whose pronunciations are scraped
# from the unified Chinese-character pages, and whose Wiktionary
# category for scraping is therefore "Chinese terms with IPA
# pronunciation" (the macrolanguage). One walk over that category feeds
# every variety's TSV.
_CHINESE_VARIETY_NAMES = frozenset(
    {
        "Cantonese",
        "Eastern Min",
        "Gan",
        "Hakka",
        "Jin",
        "Leizhou Min",
        "Mandarin",
        "Middle Chinese",
        "Min Nan",
        "Northern Min",
        "Old Chinese",
        "Puxian Min",
        "Southern Pinghua",
        "Wu",
        "Xiang",
    }
)


def _language_name_for_scraping(language):
    """Handle cases where X is under a "macrolanguage" on Wiktionary.

    So far, only the Chinese languages necessitate this helper function.
    We'll keep this function as simple as possible, until it becomes too
    complicated and requires refactoring.
    """
    if language in _CHINESE_VARIETY_NAMES:
        return "Chinese"
    return language


def iter_page_responses(
    config: Config,
) -> "Iterator[tuple[str, HTMLResponse]]":
    """Yield (page_title, HTMLResponse) for each candidate word.

    Handles MediaWiki category pagination, exponential backoff on
    transient errors, per-word skip filters, and ``restart_key``
    bookkeeping. Does NOT run any extractor — callers convert each
    HTMLResponse into (word, pron) pairs themselves (typically by
    calling ``config.extract_word_pron``).

    Only the language/cut-off-date/skip-spaces-word settings
    on ``config`` are consulted; ``narrow``, ``dialect``, and
    ``ipa_regex`` are not.
    """
    category = _CATEGORY_TEMPLATE.format(
        language=_language_name_for_scraping(config.language)
    )
    requests_params: dict[str, Any] = {
        "action": "query",
        "format": "json",
        "list": "categorymembers",
        "cmtitle": category,
        "cmlimit": "500",
        "cmprop": "ids|title|timestamp|sortkey",
    }
    session = requests.Session()
    session.headers.update(HTTP_HEADERS)
    retries = 0
    while True:
        try:
            data = session.get(
                "https://en.wiktionary.org/w/api.php?",
                params=requests_params,
                timeout=30,
            ).json()
            yield from _iter_page_responses_once(data, session, config)
            retries = 0
            if "continue" not in data:
                break
            continue_code = data["continue"]["cmcontinue"]
            # "cmstarthexsortkey" reset so as to avoid competition
            # with "continue_code".
            requests_params.update(
                {"cmcontinue": continue_code, "cmstarthexsortkey": None}
            )
        except (
            requests.exceptions.Timeout,
            requests.exceptions.ConnectionError,
            requests.exceptions.JSONDecodeError,
        ):
            requests_params.update({"cmstarthexsortkey": config.restart_key})
            delay = min(
                _BACKOFF_BASE * (2**retries) + random.uniform(0, 1),
                _BACKOFF_MAX,
            )
            time.sleep(delay)
            retries += 1


def scrape(config: Config) -> Iterator[WordPronPair]:
    """Scrapes with a given configuration."""
    for title, request in iter_page_responses(config):
        for word, pron in config.extract_word_pron(title, request, config):
            # Pronunciation processing is done in NFD-space;
            # we convert back to NFC afterwards.
            yield word, unicodedata.normalize("NFC", pron)
