from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol

import anyio

from lazy.alibabacloud_mcp_proxy.auth.ims_access_token import ImsBearerTokenSource
from lazy.alibabacloud_mcp_proxy.config import TokenSettings


class TokenAcquisitionError(RuntimeError):
    """Raised when the proxy cannot obtain a bearer token."""


@dataclass(slots=True, frozen=True)
class BearerToken:
    value: str
    expires_at: datetime | None = None

    def is_expiring_within(self, seconds: int) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now(UTC) + timedelta(seconds=seconds) >= self.expires_at


class BearerTokenSource(Protocol):
    async def fetch_token(self) -> BearerToken:
        """Return a bearer token for the upstream MCP server."""


class StaticBearerTokenSource:
    def __init__(self, token: str) -> None:
        self._token = token

    async def fetch_token(self) -> BearerToken:
        return BearerToken(value=self._token)


class CommandBearerTokenSource:
    """Fetch a bearer token by executing a local command."""

    def __init__(self, command: str) -> None:
        self._command = command

    async def fetch_token(self) -> BearerToken:
        completed = await anyio.to_thread.run_sync(self._run)
        stdout = completed.stdout.strip()
        if not stdout:
            raise TokenAcquisitionError("Token command completed without output.")

        try:
            payload = json.loads(stdout)
        except json.JSONDecodeError:
            return BearerToken(value=stdout)

        access_token = str(payload.get("access_token") or payload.get("token") or "").strip()
        if not access_token:
            raise TokenAcquisitionError(
                "Token command JSON output must include access_token or token."
            )

        expires_at = _parse_expiry(payload)
        return BearerToken(value=access_token, expires_at=expires_at)

    def _run(self) -> subprocess.CompletedProcess[str]:
        completed = subprocess.run(
            self._command,
            shell=True,
            text=True,
            capture_output=True,
            check=False,
        )
        if completed.returncode != 0:
            stderr = completed.stderr.strip()
            raise TokenAcquisitionError(
                f"Token command failed with exit code {completed.returncode}: {stderr}"
            )
        return completed


class CachedBearerTokenProvider:
    def __init__(self, source: BearerTokenSource, *, refresh_skew_seconds: int = 60) -> None:
        self._source = source
        self._refresh_skew_seconds = refresh_skew_seconds
        self._cached_token: BearerToken | None = None
        self._lock = anyio.Lock()

    async def get_token(self, *, force_refresh: bool = False) -> str:
        async with self._lock:
            if not force_refresh and self._cached_token is not None:
                if not self._cached_token.is_expiring_within(self._refresh_skew_seconds):
                    return self._cached_token.value

            self._cached_token = await self._source.fetch_token()
            return self._cached_token.value


def build_token_provider(settings: TokenSettings) -> CachedBearerTokenProvider:
    if settings.bearer_token:
        source: BearerTokenSource = StaticBearerTokenSource(settings.bearer_token)
    elif settings.token_command:
        source = CommandBearerTokenSource(settings.token_command)
    else:
        source = ImsBearerTokenSource(
            client_id=settings.ims_client_id,
            scope=settings.ims_scope,
            endpoint=settings.ims_endpoint,
        )

    return CachedBearerTokenProvider(source, refresh_skew_seconds=settings.refresh_skew_seconds)


def _parse_expiry(payload: dict[str, object]) -> datetime | None:
    expires_at_raw = payload.get("expires_at")
    if isinstance(expires_at_raw, str) and expires_at_raw.strip():
        normalized = expires_at_raw.strip().replace("Z", "+00:00")
        return datetime.fromisoformat(normalized).astimezone(UTC)

    expires_in_raw = payload.get("expires_in")
    if expires_in_raw is None:
        return None

    try:
        seconds = int(expires_in_raw)
    except (TypeError, ValueError) as exc:
        raise TokenAcquisitionError("expires_in must be an integer number of seconds.") from exc

    return datetime.now(UTC) + timedelta(seconds=seconds)
