#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Setup script for hikcamera package
"""

from setuptools import setup, find_packages
import os

# 读取README文件
def read_file(filename):
    with open(os.path.join(os.path.dirname(__file__), filename), encoding='utf-8') as f:
        return f.read()

setup(
    name="mv-hikcamera",
    use_scm_version=False,
    version="0.1.0",
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    include_package_data=True,
    install_requires=[
        'numpy>=1.24.0',
        'opencv-python>=4.8.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.4.0',
            'black>=23.0.0',
            'flake8>=6.0.0',
            'mypy>=1.0.0',
        ],
        'examples': [
            'matplotlib>=3.7.0',
            'pillow>=10.0.0',
        ],
    },
    python_requires='>=3.9',
    author="Static2D Code",
    author_email="static2d@example.com",
    description="海康威视工业相机Python控制库",
    long_description=read_file('README.md'),
    long_description_content_type='text/markdown',
    url="https://github.com/yourusername/hikcamera",
    project_urls={
        "Homepage": "https://github.com/yourusername/hikcamera",
        "Documentation": "https://github.com/yourusername/hikcamera/blob/main/README.md",
        "Repository": "https://github.com/yourusername/hikcamera.git",
        "Issues": "https://github.com/yourusername/hikcamera/issues",
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Image Recognition",
        "Topic :: Multimedia :: Video :: Capture",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: Microsoft :: Windows",
    ],
    keywords="hikvision camera industrial machine-vision usb gige",
    license="MIT",
)
