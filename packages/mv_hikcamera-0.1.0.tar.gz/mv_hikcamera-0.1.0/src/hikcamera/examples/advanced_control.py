#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
海康威视相机高级控制示例

演示如何控制相机的各种参数
"""

import sys
import os

# 如果直接运行示例，添加父目录到路径
if __name__ == "__main__":
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from hikcamera import HKCamera
import cv2


def display_camera_info(camera):
    """显示相机信息"""
    print("\n相机信息:")
    print("-" * 40)

    try:
        # 获取图像尺寸
        width = camera.get_value("int_value", "Width")
        height = camera.get_value("int_value", "Height")
        print(f"图像尺寸: {width} x {height}")

        # 获取曝光时间
        exposure = camera.get_exposure_time()
        print(f"曝光时间: {exposure} us ({exposure/1000:.1f} ms)")

        # 获取增益
        try:
            gain = camera.get_value("float_value", "Gain")
            print(f"增益: {gain}")
        except:
            print("增益: 不可用")

        # 获取帧率
        try:
            frame_rate = camera.get_value("float_value", "AcquisitionFrameRate")
            print(f"帧率: {frame_rate} fps")
        except:
            print("帧率: 不可用")

        # 获取像素格式
        try:
            pixel_format = camera.get_value("enum_value", "PixelFormat")
            print(f"像素格式: {pixel_format}")
        except:
            print("像素格式: 不可用")

    except Exception as e:
        print(f"获取相机信息失败: {e}")


def test_exposure_control(camera):
    """测试曝光控制"""
    print("\n" + "=" * 60)
    print("测试曝光控制")
    print("=" * 60)

    # 测试不同的曝光时间
    exposure_times = [5000, 10000, 20000]  # 5ms, 10ms, 20ms

    for exp_time in exposure_times:
        print(f"\n设置曝光时间: {exp_time} us ({exp_time/1000:.1f} ms)")
        camera.set_exposure_time(exp_time)

        # 获取实际设置的值
        actual_exp = camera.get_exposure_time()
        print(f"实际曝光时间: {actual_exp} us")

        # 采集一张图像
        image = camera.get_image()
        if image is not None:
            filename = f"exposure_test_{exp_time//1000}ms.png"
            cv2.imwrite(filename, image)
            print(f"已保存测试图像: {filename}")
        else:
            print("图像获取失败")


def test_parameter_ranges(camera):
    """测试参数范围"""
    print("\n" + "=" * 60)
    print("测试参数范围")
    print("=" * 60)

    # 测试曝光时间范围
    try:
        min_exp = camera.get_value("int_value", "ExposureTime.min")
        max_exp = camera.get_value("int_value", "ExposureTime.max")
        print(f"\n曝光时间范围: {min_exp} - {max_exp} us")
    except:
        print("\n曝光时间范围: 不可用")

    # 测试增益范围
    try:
        min_gain = camera.get_value("float_value", "Gain.min")
        max_gain = camera.get_value("float_value", "Gain.max")
        print(f"增益范围: {min_gain} - {max_gain}")
    except:
        print("增益范围: 不可用")


def main():
    """主函数"""
    print("=" * 60)
    print("海康威视相机高级控制示例")
    print("=" * 60)

    try:
        # 创建相机实例
        print("\n正在初始化相机...")
        camera = HKCamera()

        # 启动采集
        print("启动相机采集...")
        camera.start_camera()

        # 显示相机信息
        display_camera_info(camera)

        # 测试曝光控制
        test_exposure_control(camera)

        # 测试参数范围
        test_parameter_ranges(camera)

        print("\n" + "=" * 60)
        print("高级控制示例完成!")
        print("=" * 60)

    except Exception as e:
        error_msg = str(e)
        if "no devices found" in error_msg.lower():
            print("\n[ERROR] 没有发现相机设备")
        else:
            print(f"\n[ERROR] 示例运行失败: {e}")
        return 1

    finally:
        # 清理资源
        if 'camera' in locals():
            del camera

    return 0


if __name__ == "__main__":
    sys.exit(main())
