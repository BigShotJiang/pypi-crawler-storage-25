#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
海康威视相机基本使用示例

演示如何使用HikCamera库进行基本的相机操作
"""

import sys
import os

# 如果直接运行示例，添加父目录到路径
if __name__ == "__main__":
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from hikcamera import HKCamera
import cv2


def main():
    """主函数"""
    print("=" * 60)
    print("海康威视相机基本使用示例")
    print("=" * 60)

    try:
        # 创建相机实例
        print("\n1. 创建相机实例...")
        camera = HKCamera()
        print("   [OK] 相机创建成功")

        # 启动采集
        print("\n2. 启动相机采集...")
        camera.start_camera()
        print("   [OK] 相机启动成功")

        # 设置曝光时间
        print("\n3. 设置曝光时间...")
        camera.set_exposure_time(10000)  # 10ms
        print("   [OK] 曝光时间设置为10000us")

        # 获取几张图像
        print("\n4. 采集图像...")
        for i in range(3):
            image = camera.get_image()
            if image is not None:
                filename = f"example_image_{i+1}.png"
                cv2.imwrite(filename, image)
                print(f"   已保存: {filename} (尺寸: {image.shape})")
            else:
                print(f"   图像 {i+1} 获取失败")

        print("\n" + "=" * 60)
        print("示例运行完成!")
        print("=" * 60)

    except Exception as e:
        error_msg = str(e)
        if "no devices found" in error_msg.lower():
            print("\n[ERROR] 没有发现相机设备")
            print("请检查相机连接和电源")
        else:
            print(f"\n[ERROR] 示例运行失败: {e}")

        return 1

    finally:
        # 清理资源
        if 'camera' in locals():
            del camera

    return 0


if __name__ == "__main__":
    sys.exit(main())
