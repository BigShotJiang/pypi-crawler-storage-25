#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
海康威视相机连续采集示例

演示如何进行连续图像采集和实时显示
"""

import sys
import os

# 如果直接运行示例，添加父目录到路径
if __name__ == "__main__":
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from hikcamera import HKCamera
import cv2


def main():
    """主函数"""
    print("=" * 60)
    print("海康威视相机连续采集示例")
    print("按ESC键退出")
    print("=" * 60)

    try:
        # 创建相机实例
        print("\n正在初始化相机...")
        camera = HKCamera()

        # 启动采集
        print("启动相机采集...")
        camera.start_camera()

        print("\n开始连续采集，按ESC键退出...")
        frame_count = 0

        while True:
            # 获取图像
            image = camera.get_image()
            if image is not None:
                frame_count += 1

                # 显示运行时信息
                camera.show_runtime_info(image)
                cv2.putText(image, f"Frame: {frame_count}",
                           (20, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1)

                # 显示图像
                cv2.imshow('HikCamera Continuous Capture', image)

                # 检查按键
                key = cv2.waitKey(1) & 0xFF
                if key == 27:  # ESC键
                    break
            else:
                print("获取图像失败")
                break

        print(f"\n采集完成，共采集 {frame_count} 帧")

    except Exception as e:
        error_msg = str(e)
        if "no devices found" in error_msg.lower():
            print("\n[ERROR] 没有发现相机设备")
        else:
            print(f"\n[ERROR] 示例运行失败: {e}")
        return 1

    finally:
        # 清理资源
        cv2.destroyAllWindows()
        if 'camera' in locals():
            del camera

    return 0


if __name__ == "__main__":
    sys.exit(main())
