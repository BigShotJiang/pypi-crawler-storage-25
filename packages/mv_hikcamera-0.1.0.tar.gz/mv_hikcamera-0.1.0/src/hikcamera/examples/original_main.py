# 启动一个新的flask服务，需要的接口有
# 获取上次请求到本次请求之间新获取到的二维码列表（去重）

from flask import Flask, request, jsonify
import requests
import json
import time
import cv2
# from run import detect_qrcodes
# from 查看图像 import getImage
app = Flask(__name__)

allarr = []
@app.route('/qrcodes', methods=['GET'])
def get_qrcodes():
    s= allarr.copy()
    allarr.clear()
    return s
def playAlerm():
    from arcade import load_sound,play_sound,stop_sound
 
    sound=load_sound("alerm.mp3")
    play_obj=play_sound(sound)

    import threading

    def delayed_function():
        print("延迟执行的代码")
        stop_sound(play_obj)

    timer = threading.Timer(2, delayed_function)  # 推迟5秒执行
    timer.start()
ser1=None
@app.route('/alerm', methods=['POST',"GET"])
def alerm():
    global ser1
    try:
    # 方式1：调用函数接口打开串口时传入配置参数
        if ser1 is None or not ser1.isOpen():
                
            import serial # pip install pyserial 不要pip install serial
            print(serial)
            print(dir(serial))
            
            ser = serial.Serial("COM5", 9600)    # 打开COM17，将波特率配置为115200，其余参数使用默认值
            if ser.isOpen():                        # 判断串口是否成功打开
                print("打开串口成功。")
                print(ser.name)    # 输出串口号
                ser1=ser
            else:
                print("打开串口失败。")
                return {"success":True}
        

    # 原文链接：https://blog.csdn.net/bryanwang_3099/article/details/120493736
        type="green"
        if request.content_type != 'application/json':
            type=request.args["type"]
        else:
            type=(request.json["type"]) or (request.args["type"])
         

        s='g'
        if type=="red":
            s='r'
        # write_len = ser.write(s.encode('utf-8'))
        write_len = ser1.write(s.encode('utf-8'))
        print("串口发出{}个字节。".format(write_len))
        print('报警类型',type)
        if type=="red":
            playAlerm()
        return {"success":True}
    except Exception as e:
        print(e)
        return {"success":True}    
stoped=False
#启动一个新的线程，用于获取二维码
def get_qrcodes_thread():
    global allarr
    global stoped
    while True:
        # arr, img = ['x1','x2','x3'],None
        # 请求8080端口json
        try:
        
            url = 'http://localhost:8080'
            response = requests.get(url)
           # txt=response.text.replace(',]','').replace('[','').replace('"','').replace('\x00','')
  
            
            arr=response.json()
            print(arr)
        except Exception as e:
            print('请求8080端口失败',e)
            arr = []
        for x in arr:
            allarr.append(x)
        allarr = list(set(allarr))
        if stoped:
            break
        time.sleep(0.1)

import threading
t = threading.Thread(target=get_qrcodes_thread)
t.start()

# 监听ctrl+c 退出线程
import signal
import sys
def signal_handler(sig, frame):
    global stoped
    stoped=True
   
    sys.exit(0)
signal.signal(signal.SIGINT, signal_handler) 

# 启动flask服务
app.run(host='0.0.0.0', port=5700)
 
 
