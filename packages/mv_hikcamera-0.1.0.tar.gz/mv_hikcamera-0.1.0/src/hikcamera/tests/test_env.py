#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
环境测试脚本 - 验证所有依赖是否正确安装
"""

import sys

def test_imports():
    """测试所有必要的导入"""
    print("正在测试Python环境...")
    print("=" * 50)

    # 测试标准库
    print("\n1. 测试标准库...")
    try:
        import ctypes
        print("   [OK] ctypes 导入成功")
    except ImportError as e:
        print(f"   [FAIL] ctypes 导入失败: {e}")
        return False

    # 测试numpy
    print("\n2. 测试NumPy...")
    try:
        import numpy as np
        print(f"   [OK] NumPy 导入成功 (版本: {np.__version__})")
    except ImportError as e:
        print(f"   [FAIL] NumPy 导入失败: {e}")
        return False

    # 测试opencv
    print("\n3. 测试OpenCV...")
    try:
        import cv2
        print(f"   [OK] OpenCV 导入成功 (版本: {cv2.__version__})")
    except ImportError as e:
        print(f"   [FAIL] OpenCV 导入失败: {e}")
        return False

    # 测试海康威视相机模块
    print("\n4. 测试海康威视相机模块...")
    try:
        from hk.HKCamera_class import HKCamera
        print("   [OK] HKCamera模块导入成功")
    except ImportError as e:
        print(f"   [FAIL] HKCamera模块导入失败: {e}")
        print("   提示: 请确保MVS已正确安装")
        return False

    print("\n" + "=" * 50)
    print("[OK] 所有依赖测试通过!")
    print("=" * 50)
    return True


def test_basic_functionality():
    """测试基本功能"""
    print("\n正在测试基本功能...")
    print("=" * 50)

    try:
        import numpy as np
        import cv2
        from hk.HKCamera_class import HKCamera

        # 测试numpy数组创建
        print("\n1. 测试NumPy数组...")
        arr = np.zeros((100, 100, 3), dtype=np.uint8)
        print(f"   [OK] 创建数组: {arr.shape}")

        # 测试OpenCV图像处理
        print("\n2. 测试OpenCV图像处理...")
        test_image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        resized = cv2.resize(test_image, (50, 50))
        print(f"   [OK] 图像调整大小: {test_image.shape} -> {resized.shape}")

        # 测试HKCamera类实例化（不连接实际相机）
        print("\n3. 测试HKCamera类...")
        print("   [OK] HKCamera类可以正常导入")

        print("\n" + "=" * 50)
        print("[OK] 基本功能测试通过!")
        print("=" * 50)
        return True

    except Exception as e:
        print(f"\n✗ 功能测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("=" * 50)
    print("海康威视相机项目环境测试")
    print("=" * 50)

    # 测试导入
    if not test_imports():
        print("\n环境测试失败！请检查依赖安装。")
        sys.exit(1)

    # 测试基本功能
    if not test_basic_functionality():
        print("\n功能测试失败！请检查模块配置。")
        sys.exit(1)

    print("\n" + "=" * 50)
    print("[OK][OK][OK] 环境测试完全通过! [OK][OK][OK]")
    print("可以运行 testhk.py 进行相机测试")
    print("=" * 50)
