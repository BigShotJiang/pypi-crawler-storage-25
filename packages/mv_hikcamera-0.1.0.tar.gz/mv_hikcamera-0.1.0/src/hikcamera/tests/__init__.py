"""
HikCamera 测试模块
"""
