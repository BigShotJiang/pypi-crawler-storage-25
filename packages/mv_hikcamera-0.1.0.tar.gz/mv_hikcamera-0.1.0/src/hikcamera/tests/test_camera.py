#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
HikCamera 库测试模块

测试海康威视相机的基本功能。
"""

import sys
import os

# 添加包路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_import():
    """测试包导入"""
    print("测试包导入...")
    try:
        from hikcamera import HikCamera, HikCameraError
        print("✓ 包导入成功")
        return True
    except ImportError as e:
        print(f"✗ 包导入失败: {e}")
        return False


def test_camera_enumeration():
    """测试相机枚举"""
    print("\n测试相机枚举...")
    try:
        from hikcamera import HikCamera
        print("正在枚举相机设备...")
        camera = HikCamera()
        print("✓ 相机枚举成功")
        del camera
        return True
    except Exception as e:
        print(f"✗ 相机枚举失败: {e}")
        return False


def test_camera_basic_operations():
    """测试相机基本操作"""
    print("\n测试相机基本操作...")
    try:
        from hikcamera import HikCamera
        import cv2

        print("创建相机实例...")
        camera = HikCamera()
        print("✓ 相机创建成功")

        print("启动采集...")
        camera.start_grabbing()
        print("✓ 采集启动成功")

        print("获取图像...")
        image = camera.get_frame()
        if image is not None:
            print(f"✓ 图像获取成功 (尺寸: {image.shape})")
        else:
            print("✗ 图像获取失败")
            return False

        print("测试曝光时间设置...")
        camera.set_exposure_time(10000)
        exp_time = camera.get_exposure_time()
        print(f"✓ 曝光时间设置成功 (当前: {exp_time} us)")

        print("关闭相机...")
        camera.close()
        print("✓ 相机关闭成功")

        return True

    except Exception as e:
        print(f"✗ 相机操作失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主测试函数"""
    print("=" * 60)
    print("HikCamera 库测试")
    print("=" * 60)

    tests = [
        ("包导入测试", test_import),
        ("相机枚举测试", test_camera_enumeration),
        ("基本操作测试", test_camera_basic_operations),
    ]

    results = []
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        print("-" * 60)
        result = test_func()
        results.append((test_name, result))

    # 总结
    print("\n" + "=" * 60)
    print("测试总结:")
    print("=" * 60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        status = "✓ 通过" if result else "✗ 失败"
        print(f"{status} - {test_name}")

    print(f"\n通过率: {passed}/{total} ({passed*100//total}%)")

    return 0 if passed == total else 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
