#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试HKCamera类的初始化问题修复
"""

import sys
import os

# 添加hk目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_camera_instantiation():
    """测试相机实例化"""
    print("=" * 50)
    print("测试HKCamera类初始化修复")
    print("=" * 50)

    try:
        print("\n1. 导入HKCamera类...")
        from hk.HKCamera_class import HKCamera
        print("   [OK] 导入成功")

        print("\n2. 尝试创建相机实例...")
        print("   (如果没有连接相机，会报错，这是正常的)")
        print("   (我们主要测试的是不会出现 'camera' attribute 错误)")

        try:
            # 尝试创建相机实例
            camera = HKCamera(CameraIdx=0)
            print("   [OK] 相机创建成功!")

            # 如果成功创建，尝试访问camera属性
            print("\n3. 测试camera属性...")
            if camera.camera is not None:
                print("   [OK] camera属性存在且不为None")
            else:
                print("   [WARNING] camera属性为None")

            # 清理
            print("\n4. 清理资源...")
            del camera
            print("   [OK] 资源清理成功")

        except Exception as e:
            # 如果是因为没有相机而失败，这是正常的
            error_msg = str(e)
            if "no devices found" in error_msg.lower():
                print(f"   [EXPECTED] 没有发现相机设备: {e}")
                print("   [OK] 这是正常的，如果没有连接相机的话")
            elif "camera not initialized" in error_msg.lower():
                print(f"   [ERROR] 相机未正确初始化: {e}")
                return False
            else:
                print(f"   [ERROR] 其他错误: {e}")
                import traceback
                traceback.print_exc()
                return False

        print("\n" + "=" * 50)
        print("[OK] 初始化测试通过!")
        print("主要修复内容:")
        print("1. 在__init__中初始化self.camera = None")
        print("2. 修复open_camera中的self.camera错误引用")
        print("3. 改进__del__方法的错误处理")
        print("4. 在所有方法中添加camera状态检查")
        print("=" * 50)
        return True

    except Exception as e:
        print(f"\n[ERROR] 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_attribute_error():
    """测试特定的属性错误修复"""
    print("\n" + "=" * 50)
    print("测试 'camera' 属性错误修复")
    print("=" * 50)

    try:
        from hk.HKCamera_class import HKCamera

        print("\n测试1: 检查HKCamera类是否有camera初始化...")
        # 创建一个临时实例来测试
        try:
            camera = HKCamera(CameraIdx=0)
            # 如果成功，检查属性
            if hasattr(camera, 'camera'):
                print("   [OK] HKCamera实例有camera属性")
            else:
                print("   [ERROR] HKCamera实例缺少camera属性")
                return False
        except:
            # 如果没有相机，我们通过类定义来检查
            print("   [INFO] 没有相机连接，检查类定义...")
            import inspect
            init_source = inspect.getsource(HKCamera.__init__)
            if 'self.camera = None' in init_source:
                print("   [OK] __init__方法中包含camera初始化")
            else:
                print("   [ERROR] __init__方法中缺少camera初始化")
                return False

        print("\n测试2: 检查__del__方法的错误处理...")
        del_source = inspect.getsource(HKCamera.__del__)
        if 'try:' in del_source and 'except' in del_source:
            print("   [OK] __del__方法有异常处理")
        else:
            print("   [WARNING] __del__方法可能需要更好的异常处理")

        print("\n测试3: 检查方法的camera状态检查...")
        methods_to_check = ['start_camera', 'get_Value', 'set_Value', 'get_image']
        for method_name in methods_to_check:
            if hasattr(HKCamera, method_name):
                method_source = inspect.getsource(getattr(HKCamera, method_name))
                if 'self.camera is None' in method_source:
                    print(f"   [OK] {method_name}方法有camera状态检查")
                else:
                    print(f"   [WARNING] {method_name}方法可能缺少camera状态检查")

        print("\n" + "=" * 50)
        print("[OK] 属性错误修复验证通过!")
        print("=" * 50)
        return True

    except Exception as e:
        print(f"\n[ERROR] 验证失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("开始测试HKCamera类的修复...")

    # 运行测试
    test1_passed = test_camera_instantiation()
    test2_passed = test_attribute_error()

    # 总结
    print("\n" + "=" * 50)
    print("测试总结:")
    print(f"  相机实例化测试: {'通过' if test1_passed else '失败'}")
    print(f"  属性错误修复验证: {'通过' if test2_passed else '失败'}")

    if test1_passed and test2_passed:
        print("\n[OK] 所有测试通过! HKCamera类修复成功!")
        print("现在可以正常使用HKCamera类了。")
    else:
        print("\n[ERROR] 部分测试失败，请检查问题。")
    print("=" * 50)
