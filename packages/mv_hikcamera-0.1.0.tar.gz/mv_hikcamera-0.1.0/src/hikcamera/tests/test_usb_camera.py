#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试USB相机枚举和连接
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_usb_camera_enumeration():
    """测试USB相机枚举"""
    print("=" * 60)
    print("USB相机枚举测试")
    print("=" * 60)

    try:
        from hk.HKCamera_class import HKCamera
        from hk.CameraParams_const import MV_GIGE_DEVICE, MV_USB_DEVICE, MV_UNKNOW_DEVICE

        print("\n1. 检查设备枚举类型...")
        print("   枚举类型包括:")
        print(f"   - MV_GIGE_DEVICE: {MV_GIGE_DEVICE:#010x}")
        print(f"   - MV_USB_DEVICE: {MV_USB_DEVICE:#010x}")
        print(f"   - MV_UNKNOW_DEVICE: {MV_UNKNOW_DEVICE:#010x}")

        combined_type = MV_GIGE_DEVICE | MV_USB_DEVICE | MV_UNKNOW_DEVICE
        print(f"   - 组合枚举类型: {combined_type:#010x}")

        print("\n2. 开始枚举设备...")
        print("   提示: 如果MVS能找到相机，这里也应该能找到")

        try:
            # 尝试创建相机实例（会触发设备枚举）
            camera = HKCamera(CameraIdx=0)
            print("   [OK] 成功创建相机实例!")

            # 如果成功，显示相机信息
            print("\n3. 相机信息:")
            if camera.camera is not None:
                print("   - 相机对象已初始化")
                print("   - 可以开始使用相机功能")

            # 清理
            del camera
            return True

        except Exception as e:
            error_msg = str(e)
            if "no devices found" in error_msg.lower():
                print("   [ERROR] 没有发现任何相机设备")
                print("\n可能的原因:")
                print("  1. 相机没有正确连接到USB端口")
                print("  2. 相机电源没有打开")
                print("  3. USB驱动程序没有正确安装")
                print("  4. 相机被其他程序占用")
                print("  5. MVS和Python程序的权限级别不同")
                print("\n建议:")
                print("  - 确认MVS能正常找到相机")
                print("  - 尝试以管理员身份运行此程序")
                print("  - 重新插拔USB连接")
                print("  - 重启相机")
            elif "camera not initialized" in error_msg.lower():
                print(f"   [ERROR] 相机初始化失败: {e}")
            else:
                print(f"   [ERROR] 其他错误: {e}")
                import traceback
                traceback.print_exc()
            return False

    except Exception as e:
        print(f"\n[ERROR] 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_mvs_comparison():
    """MVS对比测试"""
    print("\n" + "=" * 60)
    print("MVS环境对比测试")
    print("=" * 60)

    print("\n如果MVS能找到相机但本程序找不到，可能的原因:")
    print("1. 驱动版本不一致")
    print("2. 权限问题 (尝试以管理员身份运行)")
    print("3. Python环境路径问题")
    print("4. MVS SDK版本兼容性问题")

    print("\n建议的排查步骤:")
    print("1. 确认MVS安装在标准路径")
    print("2. 检查MVS版本是否支持USB相机")
    print("3. 以管理员身份运行测试程序")
    print("4. 检查防火墙和安全软件设置")

    print("\n技术支持:")
    print("- MVS版本: 请查看MVS关于对话框")
    print("- Python版本: ", sys.version.split()[0])
    print("- 系统平台: ", sys.platform)


def show_code_examples():
    """显示代码示例"""
    print("\n" + "=" * 60)
    print("USB相机使用代码示例")
    print("=" * 60)

    print("\n基本用法:")
    print("""
from hk.HKCamera_class import HKCamera

# 创建USB相机实例 (会自动枚举所有设备类型)
camera = HKCamera(CameraIdx=0)

# 启动采集
camera.start_camera()

# 获取图像
image = camera.get_image()

# 清理资源
del camera
    """)

    print("\n指定USB相机:")
    print("""
# 如果有多个相机，可以通过设备索引选择
camera = HKCamera(CameraIdx=0)  # 第一个设备
camera = HKCamera(CameraIdx=1)  # 第二个设备
    """)


if __name__ == "__main__":
    print("USB相机测试程序")
    print("本程序专门用于测试USB连接的海康威视相机")

    # 运行测试
    test1_passed = test_usb_camera_enumeration()
    test_mvs_comparison()
    show_code_examples()

    # 总结
    print("\n" + "=" * 60)
    print("测试总结:")
    if test1_passed:
        print("[OK] USB相机枚举和连接成功!")
        print("现在可以正常使用USB相机了。")
    else:
        print("[INFO] USB相机枚举测试完成")
        print("请根据上述提示排查问题。")
    print("=" * 60)
