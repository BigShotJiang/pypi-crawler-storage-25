#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
USB相机完整功能测试 (非交互式)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_usb_camera_basic():
    """测试USB相机基本功能"""
    print("=" * 60)
    print("USB相机基本功能测试")
    print("=" * 60)

    try:
        from hk.HKCamera_class import HKCamera
        import cv2
        import numpy as np

        print("\n1. 创建USB相机实例...")
        camera = HKCamera(CameraIdx=0)
        print("   [OK] USB相机创建成功")

        print("\n2. 启动相机采集...")
        camera.start_camera()
        print("   [OK] 相机启动成功")

        print("\n3. 测试曝光时间控制...")
        try:
            current_exp = camera.get_exposure_time()
            print(f"   当前曝光时间: {current_exp} us")

            # 设置新的曝光时间
            new_exp = 10000  # 10ms
            camera.set_exposure_time(new_exp)
            updated_exp = camera.get_exposure_time()
            print(f"   设置曝光时间为: {new_exp} us")
            print(f"   实际曝光时间: {updated_exp} us")
            print("   [OK] 曝光时间控制正常")
        except Exception as e:
            print(f"   [WARNING] 曝光时间控制失败: {e}")

        print("\n4. 测试图像获取...")
        success_count = 0
        for i in range(5):
            try:
                image = camera.get_image()
                if image is not None:
                    success_count += 1
                    print(f"   图像 {i+1}: 尺寸 {image.shape}, 类型 {image.dtype}")
                else:
                    print(f"   图像 {i+1}: 获取失败")
            except Exception as e:
                print(f"   图像 {i+1}: 获取异常 - {e}")

        if success_count > 0:
            print(f"   [OK] 成功获取 {success_count}/5 张图像")
        else:
            print("   [ERROR] 图像获取全部失败")
            return False

        print("\n5. 测试相机参数...")
        try:
            width = camera.get_Value("int_value", "Width")
            height = camera.get_Value("int_value", "Height")
            print(f"   图像宽度: {width}")
            print(f"   图像高度: {height}")
            print("   [OK] 参数获取成功")
        except Exception as e:
            print(f"   [WARNING] 参数获取失败: {e}")

        print("\n" + "=" * 60)
        print("[OK] USB相机基本功能测试完成!")
        print("=" * 60)

        # 清理资源
        del camera
        return True

    except Exception as e:
        error_msg = str(e)
        if "no devices found" in error_msg.lower():
            print("\n[ERROR] 没有发现USB相机设备")
            print("请检查:")
            print("  1. 相机是否已正确连接到USB端口")
            print("  2. 相机电源是否打开")
            print("  3. 相机是否被其他程序占用")
        else:
            print(f"\n[ERROR] 测试失败: {e}")
            import traceback
            traceback.print_exc()
        return False


def test_usb_camera_save_image():
    """测试USB相机图像保存"""
    print("\n" + "=" * 60)
    print("USB相机图像保存测试")
    print("=" * 60)

    try:
        from hk.HKCamera_class import HKCamera
        import cv2

        print("\n1. 创建相机并启动采集...")
        camera = HKCamera(CameraIdx=0)
        camera.start_camera()

        print("\n2. 采集并保存图像...")
        success_count = 0
        for i in range(3):
            try:
                image = camera.get_image()
                if image is not None:
                    filename = f"usb_camera_test_{i+1}.png"
                    cv2.imwrite(filename, image)
                    print(f"   已保存: {filename} (尺寸: {image.shape})")
                    success_count += 1
                else:
                    print(f"   图像 {i+1}: 获取失败")
            except Exception as e:
                print(f"   图像 {i+1}: 保存失败 - {e}")

        if success_count > 0:
            print(f"\n   [OK] 成功保存 {success_count}/3 张图像")
        else:
            print("\n   [ERROR] 图像保存全部失败")
            return False

        print("\n" + "=" * 60)
        print("[OK] 图像保存测试完成!")
        print("=" * 60)

        # 清理资源
        del camera
        return True

    except Exception as e:
        print(f"\n[ERROR] 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主测试函数"""
    print("=" * 60)
    print("USB海康威视相机完整测试")
    print("=" * 60)
    print("\n此测试将自动运行所有测试功能")

    # 运行所有测试
    results = []

    print("\n开始测试...\n")

    # 测试1: 基本功能测试
    result1 = test_usb_camera_basic()
    results.append(("基本功能测试", result1))

    # 测试2: 图像保存测试
    result2 = test_usb_camera_save_image()
    results.append(("图像保存测试", result2))

    # 测试总结
    print("\n" + "=" * 60)
    print("测试总结:")
    print("=" * 60)

    for test_name, result in results:
        status = "[OK]" if result else "[FAIL]"
        print(f"{status} {test_name}")

    passed = sum(1 for _, result in results if result)
    total = len(results)

    print(f"\n通过: {passed}/{total} 项测试")

    if passed == total:
        print("\n[OK] 所有测试通过! USB相机工作正常!")
        print("可以开始使用相机进行开发了。")
        return 0
    else:
        print("\n[WARNING] 部分测试失败，请检查错误信息")
        return 1


if __name__ == "__main__":
    exit_code = main()
    print("\n" + "=" * 60)
    print(f"测试程序退出 (代码: {exit_code})")
    print("=" * 60)
    sys.exit(exit_code)
