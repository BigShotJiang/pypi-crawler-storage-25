#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
验证HKCamera类'camera'属性错误修复的测试脚本
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_fixes():
    """测试所有修复内容"""
    print("=" * 60)
    print("HKCamera类 'camera' 属性错误修复验证")
    print("=" * 60)

    from hk.HKCamera_class import HKCamera
    import inspect

    # 测试1: 检查__init__方法中的camera初始化
    print("\n测试1: 检查__init__方法中的camera初始化")
    init_source = inspect.getsource(HKCamera.__init__)
    if 'self.camera = None' in init_source:
        print("   [OK] __init__方法中包含 'self.camera = None' 初始化")
    else:
        print("   [FAIL] __init__方法中缺少camera初始化")
        return False

    # 测试2: 检查open_camera方法中的self.camera引用错误
    print("\n测试2: 检查open_camera方法中的self.camera引用修复")
    open_camera_source = inspect.getsource(HKCamera.open_camera)
    if 'self.camera.MV_CC_SetSDKLogPath' in open_camera_source:
        print("   [FAIL] open_camera中仍然存在错误的self.camera引用")
        return False
    elif 'camera.MV_CC_SetSDKLogPath' in open_camera_source:
        print("   [OK] open_camera方法中已修复为正确的 'camera.MV_CC_SetSDKLogPath'")
    else:
        print("   [INFO] open_camera方法中没有日志路径设置代码")

    # 测试3: 检查__del__方法的异常处理
    print("\n测试3: 检查__del__方法的异常处理")
    del_source = inspect.getsource(HKCamera.__del__)
    has_try_except = 'try:' in del_source and 'except' in del_source
    has_attribute_check = 'self.camera is None' in del_source

    if has_try_except:
        print("   [OK] __del__方法包含try-except异常处理")
    else:
        print("   [WARNING] __del__方法可能需要更好的异常处理")

    if has_attribute_check:
        print("   [OK] __del__方法包含camera属性检查")
    else:
        print("   [WARNING] __del__方法可能缺少camera属性检查")

    # 测试4: 检查关键方法的camera状态检查
    print("\n测试4: 检查关键方法的camera状态检查")
    methods_with_checks = []
    methods_to_check = {
        'start_camera': True,
        'get_Value': True,
        'set_Value': True,
        'get_image': True
    }

    for method_name, should_have_check in methods_to_check.items():
        if hasattr(HKCamera, method_name):
            method_source = inspect.getsource(getattr(HKCamera, method_name))
            has_check = 'self.camera is None' in method_source

            if should_have_check and has_check:
                methods_with_checks.append(method_name)
                print(f"   [OK] {method_name}方法有camera状态检查")
            elif not should_have_check and not has_check:
                print(f"   [OK] {method_name}方法不需要camera状态检查")
            else:
                print(f"   [WARNING] {method_name}方法可能缺少camera状态检查")

    if len(methods_with_checks) == len(methods_to_check):
        print("   [OK] 所有关键方法都有camera状态检查")
    else:
        print(f"   [WARNING] 只有 {len(methods_with_checks)}/{len(methods_to_check)} 个方法有camera状态检查")

    # 测试5: 实例化测试（不连接真实相机）
    print("\n测试5: 实例化测试（测试异常处理）")
    try:
        print("   尝试创建HKCamera实例（预期会失败，因为没有连接相机）...")
        camera = HKCamera(CameraIdx=0)
        print("   [WARNING] 意外成功创建了相机实例（可能真的连接了相机）")
        # 如果成功创建，清理它
        try:
            del camera
        except:
            pass
    except Exception as e:
        error_msg = str(e).lower()
        if "no devices found" in error_msg:
            print("   [OK] 正确处理了'没有发现设备'的错误")
        elif "camera" in error_msg and "attribute" in error_msg:
            print(f"   [FAIL] 仍然存在camera属性错误: {e}")
            return False
        else:
            print(f"   [OK] 正确处理了错误: {e}")

    print("\n" + "=" * 60)
    print("[OK] 所有修复验证测试通过!")
    print("=" * 60)
    print("\n修复内容总结:")
    print("1. 在__init__方法中初始化self.camera = None")
    print("2. 修复了open_camera方法中的self.camera引用错误")
    print("3. 增强了__del__方法的异常处理")
    print("4. 在关键方法中添加了camera状态检查")
    print("\n现在HKCamera类应该不会再出现 'camera' 属性错误了!")
    print("=" * 60)

    return True


if __name__ == "__main__":
    try:
        success = test_fixes()
        if success:
            print("\n[OK] HKCamera类修复验证成功!")
            print("现在可以安全地使用HKCamera类，不会再出现camera属性错误。")
            sys.exit(0)
        else:
            print("\n[ERROR] HKCamera类修复验证失败!")
            print("请检查修复代码。")
            sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] 验证过程出现异常: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
