"""
核心相机控制模块

包含海康威视相机的核心控制类和SDK接口。
"""

from .camera import HKCamera
from .mv_camera_control import MvCamera
from .mvlc_error_define import *

# 为了兼容性，提供HikCamera别名
HikCamera = HKCamera

__all__ = [
    "HKCamera",
    "HikCamera",
    "MvCamera",
]
