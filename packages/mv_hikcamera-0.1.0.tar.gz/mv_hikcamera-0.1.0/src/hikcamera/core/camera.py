"""
海康威视相机控制类

提供海康威视工业相机的主要控制功能，包括:
- 设备枚举和连接
- 图像采集
- 参数控制
- 资源管理
"""

from .mv_camera_control import MvCamera
from .camera_params_const import *
from .camera_params_header import *
from .pixel_type_header import *
from .mvlc_error_define import *
from ctypes import *
import numpy as np
import cv2


class HKCamera:
    """海康威视相机控制类"""

    def __init__(self, camera_idx=0, log_path=None, camera_ip=""):
        """
        初始化相机

        Args:
            camera_idx: 相机索引，默认为0（第一个设备）
            log_path: SDK日志路径，None表示不生成日志
            camera_ip: 指定相机IP（GigE）或序列号（USB），为空则使用索引
        """
        self.name = "HKCamera"
        self.camera = None
        self.nDataSize = 0
        self.pData = None
        self.stFrameInfo = None

        # 枚举设备
        device_list = self.enum_devices()
        if device_list is None or device_list.nDeviceNum == 0:
            raise Exception("No camera devices found")

        # 查找目标相机
        target_camera = camera_idx
        for i in range(device_list.nDeviceNum):
            mvcc_dev_info = cast(device_list.pDeviceInfo[i], POINTER(MV_CC_DEVICE_INFO)).contents

            if mvcc_dev_info.nTLayerType == MV_GIGE_DEVICE:
                # GigE网口设备
                nip1 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0xff000000) >> 24
                nip2 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x00ff0000) >> 16
                nip3 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x0000ff00) >> 8
                nip4 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x000000ff)
                dev_ip = "%d.%d.%d.%d" % (nip1, nip2, nip3, nip4)
                print(f"device {i}: GigE, IP: {dev_ip}")
                if camera_ip and dev_ip == camera_ip:
                    target_camera = i

            elif mvcc_dev_info.nTLayerType == MV_USB_DEVICE:
                # USB设备
                usb_info = mvcc_dev_info.SpecialInfo.stUsb3VInfo
                serial_bytes = bytes(usb_info.chSerialNumber)
                serial_number = serial_bytes.decode('ascii', errors='ignore').rstrip('\x00').strip()

                model_bytes = bytes(usb_info.chModelName)
                model_name = model_bytes.decode('ascii', errors='ignore').rstrip('\x00').strip()

                device_number = usb_info.nDeviceNumber
                print(f"device {i}: USB, SN: {serial_number}, Model: {model_name}, DeviceNum: {device_number}")

                if camera_ip and (serial_number == camera_ip or str(device_number) == camera_ip):
                    target_camera = i

        # 打开相机
        self.camera = self.open_camera(device_list, target_camera, log_path)

    def __del__(self):
        """析构函数，确保资源正确释放"""
        try:
            if self.camera is None:
                return

            # 停止取流
            try:
                self.camera.MV_CC_StopGrabbing()
            except:
                pass

            # 关闭设备
            try:
                ret = self.camera.MV_CC_CloseDevice()
                if ret != 0:
                    print(f"Warning: close device failed! ret[0x{ret:x}]")
            except Exception as e:
                print(f"Warning: close device failed with exception: {e}")

            # 销毁句柄
            try:
                ret = self.camera.MV_CC_DestroyHandle()
                if ret != 0:
                    print(f"Warning: destroy handle failed! ret[0x{ret:x}]")
            except Exception as e:
                print(f"Warning: destroy handle failed with exception: {e}")

        except Exception as e:
            print(f"Warning: cleanup failed with exception: {e}")

    @staticmethod
    def enum_devices(device_type=0):
        """
        枚举相机设备

        Args:
            device_type: 设备类型，0=所有设备(GigE+USB)，1=GenTL设备

        Returns:
            MV_CC_DEVICE_INFO_LIST: 设备列表
        """
        print('Enumerating devices...')

        if device_type == 0:
            # 枚举所有设备类型: GigE | USB | Unknown
            camera_type = MV_GIGE_DEVICE | MV_USB_DEVICE | MV_UNKNOW_DEVICE
            device_list = MV_CC_DEVICE_INFO_LIST()

            # 枚举设备
            ret = MvCamera.MV_CC_EnumDevices(camera_type, device_list)
            if ret != 0:
                raise Exception(f"Enum devices failed! ret[0x{ret:x}]")

            return device_list
        else:
            raise NotImplementedError("GenTL device enumeration not implemented")

    def open_camera(self, device_list, camera_idx, log_path):
        """
        打开相机设备

        Args:
            device_list: 设备列表
            camera_idx: 相机索引
            log_path: 日志路径

        Returns:
            MvCamera: 相机对象
        """
        # 创建相机实例
        camera = MvCamera()

        # 选择设备并创建句柄
        st_device_list = cast(device_list.pDeviceInfo[camera_idx], POINTER(MV_CC_DEVICE_INFO)).contents

        if log_path is not None:
            # 设置日志路径
            ret = camera.MV_CC_SetSDKLogPath(log_path)
            if ret != 0:
                raise Exception(f"Set log path failed! ret[0x{ret:x}]")

            # 创建句柄（生成日志）
            ret = camera.MV_CC_CreateHandle(st_device_list)
            if ret != 0:
                raise Exception(f"Create handle failed! ret[0x{ret:x}]")
        else:
            # 创建句柄（不生成日志）
            ret = camera.MV_CC_CreateHandleWithoutLog(st_device_list)
            if ret != 0:
                raise Exception(f"Create handle failed! ret[0x{ret:x}]")

        # 打开相机
        ret = camera.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)
        if ret != 0:
            raise Exception(f"Open device failed! ret[0x{ret:x}]")

        return camera

    def start_camera(self):
        """启动相机采集"""
        if self.camera is None:
            raise Exception("Camera not initialized")

        # 获取PayloadSize
        st_param = MV_CC_INTVALUE()
        memset(byref(st_param), 0, sizeof(MV_CC_INTVALUE))
        ret = self.camera.MV_CC_GetIntValue("PayloadSize", st_param)
        if ret != 0:
            raise Exception(f"Get payload size failed! ret[0x{ret:x}]")

        self.nDataSize = st_param.nCurValue
        self.pData = (c_ubyte * self.nDataSize)()
        self.stFrameInfo = MV_FRAME_OUT_INFO_EX()
        memset(byref(self.stFrameInfo), 0, sizeof(self.stFrameInfo))

        # 开始采集
        ret = self.camera.MV_CC_StartGrabbing()
        if ret != 0:
            raise Exception(f"Start grabbing failed! ret[0x{ret:x}]")

    def get_value(self, param_type, node_name):
        """
        获取相机参数

        Args:
            param_type: 参数类型 (int_value, float_value, enum_value, bool_value, string_value)
            node_name: 参数名称

        Returns:
            参数值
        """
        if self.camera is None:
            raise Exception("Camera not initialized")

        if param_type == "int_value":
            st_param = MV_CC_INTVALUE()
            memset(byref(st_param), 0, sizeof(MV_CC_INTVALUE))
            ret = self.camera.MV_CC_GetIntValue(node_name, st_param)
            if ret != 0:
                raise Exception(f"Get int value {node_name} failed! ret[0x{ret:x}]")
            return st_param.nCurValue

        elif param_type == "float_value":
            st_float_value = MV_CC_FLOATVALUE()
            memset(byref(st_float_value), 0, sizeof(MV_CC_FLOATVALUE))
            ret = self.camera.MV_CC_GetFloatValue(node_name, st_float_value)
            if ret != 0:
                raise Exception(f"Get float value {node_name} failed! ret[0x{ret:x}]")
            return st_float_value.fCurValue

        elif param_type == "enum_value":
            st_enum_value = MV_CC_ENUMVALUE()
            memset(byref(st_enum_value), 0, sizeof(MV_CC_ENUMVALUE))
            ret = self.camera.MV_CC_GetEnumValue(node_name, st_enum_value)
            if ret != 0:
                raise Exception(f"Get enum value {node_name} failed! ret[0x{ret:x}]")
            return st_enum_value.nCurValue

        elif param_type == "bool_value":
            st_bool = c_bool(False)
            ret = self.camera.MV_CC_GetBoolValue(node_name, st_bool)
            if ret != 0:
                raise Exception(f"Get bool value {node_name} failed! ret[0x{ret:x}]")
            return st_bool.value

        elif param_type == "string_value":
            st_string_value = MV_CC_STRINGVALUE()
            memset(byref(st_string_value), 0, sizeof(MV_CC_STRINGVALUE))
            ret = self.camera.MV_CC_GetStringValue(node_name, st_string_value)
            if ret != 0:
                raise Exception(f"Get string value {node_name} failed! ret[0x{ret:x}]")
            return st_string_value.chCurValue

        else:
            return None

    def set_value(self, param_type, node_name, node_value):
        """
        设置相机参数

        Args:
            param_type: 参数类型 (int_value, float_value, enum_value, bool_value, string_value)
            node_name: 参数名称
            node_value: 参数值
        """
        if self.camera is None:
            raise Exception("Camera not initialized")

        if param_type == "int_value":
            ret = self.camera.MV_CC_SetIntValue(node_name, int(node_value))
            if ret != 0:
                raise Exception(f"Set int value {node_name} failed! ret[0x{ret:x}]")

        elif param_type == "float_value":
            ret = self.camera.MV_CC_SetFloatValue(node_name, float(node_value))
            if ret != 0:
                raise Exception(f"Set float value {node_name} failed! ret[0x{ret:x}]")

        elif param_type == "enum_value":
            ret = self.camera.MV_CC_SetEnumValueByString(node_name, node_value)
            if ret != 0:
                raise Exception(f"Set enum value {node_name} failed! ret[0x{ret:x}]")

        elif param_type == "bool_value":
            ret = self.camera.MV_CC_SetBoolValue(node_name, node_value)
            if ret != 0:
                raise Exception(f"Set bool value {node_name} failed! ret[0x{ret:x}]")

        elif param_type == "string_value":
            ret = self.camera.MV_CC_SetStringValue(node_name, str(node_value))
            if ret != 0:
                raise Exception(f"Set string value {node_name} failed! ret[0x{ret:x}]")

    def set_exposure_time(self, exp_time):
        """设置曝光时间（微秒）"""
        self.set_value(param_type="float_value", node_name="ExposureTime", node_value=exp_time)

    def get_exposure_time(self):
        """获取曝光时间（微秒）"""
        return self.get_value(param_type="float_value", node_name="ExposureTime")

    def get_image(self, width=None):
        """
        获取一帧图像

        Args:
            width: 可选的图像宽度（暂未使用）

        Returns:
            numpy.ndarray: 图像数组，失败返回None
        """
        if self.camera is None:
            raise Exception("Camera not initialized")

        ret = self.camera.MV_CC_GetOneFrameTimeout(
            self.pData, self.nDataSize, self.stFrameInfo, 5000)

        if ret == 0:
            image = np.asarray(self.pData).reshape(
                (self.stFrameInfo.nHeight, self.stFrameInfo.nWidth, -1))
            return image
        else:
            return None

    def show_runtime_info(self, image):
        """
        在图像上显示运行时信息

        Args:
            image: 图像数组
        """
        exp_time = self.get_exposure_time()
        cv2.putText(image, f"Exposure time = {exp_time * 0.001:.1f}ms",
                   (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1)
