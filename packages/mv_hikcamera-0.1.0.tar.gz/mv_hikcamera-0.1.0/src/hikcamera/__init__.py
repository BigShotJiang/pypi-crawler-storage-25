"""
HikCamera - 海康威视工业相机Python库

这是一个现代化的海康威视工业相机控制库，支持GigE网口和USB接口相机。
提供简洁的API接口、完整的类型提示和详细的文档。

主要特性:
    - 支持USB和GigE接口相机
    - 简洁易用的API设计
    - 完整的类型提示
    - 详细的错误处理
    - 支持参数调整和图像获取
    - 现代Python代码风格

使用示例:
    >>> from hikcamera import HikCamera
    >>> camera = HikCamera()
    >>> camera.start_grabbing()
    >>> image = camera.get_frame()
    >>> camera.close()

版本: 0.1.0
作者: static2dcode
许可证: MIT
"""

__version__ = "0.1.0"
__author__ = "static2dcode"
__license__ = "MIT"

# 导入主要的类和函数
from .core.camera import HKCamera

# 为了更好的API，提供HikCamera别名
HikCamera = HKCamera

# 导出公共API
__all__ = [
    "HKCamera",
    "HikCamera",
    "__version__",
]

# 包级异常类
class HikCameraError(Exception):
    """海康威视相机异常基类"""
    pass


class CameraNotFoundError(HikCameraError):
    """相机设备未找到异常"""
    pass


class CameraInitError(HikCameraError):
    """相机初始化异常"""
    pass


class CameraOperationError(HikCameraError):
    """相机操作异常"""
    pass


class ImageAcquisitionError(HikCameraError):
    """图像采集异常"""
    pass
