"""
海康威视相机参数定义

整合了相机参数的常量定义和数据结构
"""

# 从原始模块导入所有内容
from .camera_params_const import *
from .camera_params_header import *
from .pixel_type_header import *

# 为了向后兼容，保留原始导出
__all__ = [
    # 常量
    'MV_GIGE_DEVICE', 'MV_USB_DEVICE', 'MV_UNKNOW_DEVICE',
    'MV_ACCESS_Exclusive',
    'MV_MAX_DEVICE_NUM',

    # 数据结构
    'MV_CC_DEVICE_INFO', 'MV_CC_DEVICE_INFO_LIST',
    'MV_CC_INTVALUE', 'MV_CC_FLOATVALUE', 'MV_CC_ENUMVALUE',
    'MV_CC_STRINGVALUE', 'MV_FRAME_OUT_INFO_EX',

    # 像素类型
    'EPixelType',
]
