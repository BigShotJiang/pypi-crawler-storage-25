# HikCamera

海康威视工业相机Python控制库 - 简单易用的海康威视工业相机（包括GigE网口和USB接口）Python控制库。

## 特性

- ✅ **支持多种接口**: 支持GigE网口相机和USB相机
- 🚀 **简单易用**: 提供简洁的Python接口，易于集成
- 🔍 **自动设备枚举**: 自动发现和识别连接的相机设备
- 🎛️ **完整参数控制**: 支持曝光时间、增益、ROI等参数控制
- 🛡️ **异常处理**: 完善的错误处理和资源管理
- 📦 **零依赖冲突**: 只依赖numpy和opencv-python

## 安装

### 从PyPI安装（推荐）

```bash
pip install hikcamera
```

### 从源码安装

```bash
git clone https://github.com/yourusername/hikcamera.git
cd hikcamera
pip install -e .
```

### 系统要求

- Python >= 3.9
- Windows操作系统
- 已安装海康威视MVS SDK
- numpy >= 1.24.0
- opencv-python >= 4.8.0

## 快速开始

### 基本使用

```python
from hikcamera import HKCamera

# 创建相机实例（自动枚举所有设备）
camera = HKCamera()

# 启动采集
camera.start_camera()

# 设置曝光时间（10ms）
camera.set_exposure_time(10000)

# 获取图像
image = camera.get_image()

# 保存图像
import cv2
cv2.imwrite("output.png", image)

# 清理资源
del camera
```

### 指定设备

```python
# 使用第一个发现的设备
camera = HKCamera(camera_idx=0)

# 对于GigE相机，可以通过IP地址指定
camera = HKCamera(camera_ip="192.168.1.100")

# 对于USB相机，可以通过序列号指定
camera = HKCamera(camera_ip="DA2728737")
```

### 连续采集

```python
from hikcamera import HKCamera
import cv2

camera = HKCamera()
camera.start_camera()

while True:
    image = camera.get_image()
    if image is not None:
        cv2.imshow('Camera', image)
        if cv2.waitKey(1) & 0xFF == 27:  # ESC键退出
            break

cv2.destroyAllWindows()
del camera
```

## 高级功能

### 参数控制

```python
# 获取参数
width = camera.get_value("int_value", "Width")
height = camera.get_value("int_value", "Height")
exposure = camera.get_exposure_time()

# 设置参数
camera.set_exposure_time(15000)  # 15ms
camera.set_value("float_value", "Gain", 10.0)
```

### 设备信息

```python
# 枚举所有设备
device_list = HKCamera.enum_devices()
print(f"发现 {device_list.nDeviceNum} 个设备")

# 显示设备信息
for i in range(device_list.nDeviceNum):
    # 设备信息会自动打印
    pass
```

## 示例程序

库包含多个示例程序，展示各种使用场景：

- **basic_usage.py**: 基本的相机操作
- **continuous_capture.py**: 连续采集和实时显示
- **advanced_control.py**: 高级参数控制

运行示例：

```bash
# 基本使用
python -m hikcamera.examples.basic_usage

# 连续采集
python -m hikcamera.examples.continuous_capture

# 高级控制
python -m hikcamera.examples.advanced_control
```

## 支持的相机型号

海康威视MV系列工业相机，包括但不限于：

- MV-CA系列 (千万像素)
- MV-CM系列 (百万像素)
- MV-CS系列 (USB相机)
- 其他兼容MVS SDK的型号

## 故障排除

### 找不到相机

1. 检查相机是否正确连接
2. 确认MVS SDK已正确安装
3. 尝试以管理员身份运行程序
4. 检查防火墙设置

### 依赖问题

```bash
# 重新安装依赖
pip install --upgrade numpy opencv-python
```

### DLL加载错误

确保MVS SDK已正确安装，并且DLL文件在系统PATH中。

## 开发

### 运行测试

```bash
# 运行所有测试
python -m pytest src/hikcamera/tests/

# 运行特定测试
python -m pytest src/hikcamera/tests/test_usb_camera.py
```

### 代码格式化

```bash
# 使用black格式化代码
black src/hikcamera/

# 使用flake8检查代码风格
flake8 src/hikcamera/
```

## 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 贡献

欢迎提交Issue和Pull Request！

## 更新日志

### 0.1.0 (2026-04-09)

- 🎉 首次发布
- ✅ 支持GigE和USB相机
- ✅ 基本的图像采集功能
- ✅ 参数控制功能
- ✅ 完整的示例代码

## 联系方式

- 项目主页: https://github.com/yourusername/hikcamera
- 问题反馈: https://github.com/yourusername/hikcamera/issues
- 邮箱: static2d@example.com

## 致谢

- 海康威视机器 vision (MVS) SDK
- numpy和opencv-python项目

---

**注意**: 本库需要海康威视MVS SDK的支持，请确保在使用前已正确安装。
