# ============================================================================
# General Constants
# ============================================================================

NOT_SET_SENTINEL = <long>(-42)
NOT_FOUND_VAL = <long>(-13)
NOT_FOUND = <long>(-1)
NOT_OWNED = <long>(-1) 

SUCCESS = <long>0
FAILURE = <long>1

FALSE = <bint>0
TRUE = <bint>1

FUNC_SUCCESS = <Py_ssize_t>0
FUNC_FAILURE = <Py_ssize_t>(-1)

THIRTY_ONE = <long>31
PY_ZERO = <Py_ssize_t>0
PY_ONE = <Py_ssize_t>1
PY_TWO = <Py_ssize_t>2
LONG_ZERO = <long>0

# ============================================================================
# LRU Cache Constants
# ============================================================================

EMPTY_KEY = <long>(-1)
SIZE_NOT_SET = <size_t>(-1)
MIN_BUCKETS = <size_t>16
SIZE_ZERO = <size_t>0
LOAD_FACTOR_NUM = <size_t>7    # Rehash when occupied > 7/10 of buckets
LOAD_FACTOR_DEN = <size_t>10
MIN_CAPACITY = <size_t>1
DEFAULT_CAPACITY = <size_t>512
MAX_CAPACITY = <size_t>1000000 # 1 million max capacity
