
from cpython.list cimport PyList_Check, PyList_Size
from cpython.object cimport PyObject, PyObject_IsInstance, PyObject_Hash, PyObject_IsTrue
from cpython.tuple cimport PyTuple_Check
from cpython.bool cimport PyBool_Check
from cpython.long cimport PyLong_Check
from cpython.list cimport PyList_Check
from cpython.dict cimport PyDict_Values, PyDict_Check, PyDict_SetItem, PyDict_DelItem, PyDict_Next
from cpython.unicode cimport PyUnicode_Check
from cpython.bytes cimport PyBytes_Check
from cpython.mapping cimport PyMapping_Check
from cpython.set cimport PySet_Check
from .utils cimport (
    HashableCacheKey,
    HashableValuesList,
    create_hashable,
    compute_cache_key_hash,
    compute_values_hash,
    get_cached_hash,
    BaseHashableStruct,
    CacheKey_EQ,
    CacheKey_NE,
    Get_PyObject_INCREF,
    XOR_Combine,
    Alt_XOR_Combine,
    Py_IsNone,
)
from .common cimport FALSE,  TRUE, PY_ONE, PY_ZERO, PY_TWO

cdef str NULL_STR = "null"

cpdef inline bint check_conditions(tuple conditions, object arg):
    return c_check_conditions(conditions, arg) # type: ignore

cdef inline bint _has_nested_dicts(object obj, int depth = 0):
    if depth > 0 and PyDict_Check(obj):
        return TRUE

    cdef object values, value
    if PyDict_Check(obj):
        values = PyDict_Values(obj)
    elif PyList_Check(obj) or PyTuple_Check(obj):
        values = obj
    else:
        return FALSE

    for item in values:  # type: ignore
        if _has_nested_dicts(item, depth + 1):
            return TRUE
    return FALSE

cpdef bint has_nested_dicts(object obj):
    return _has_nested_dicts(obj)


cdef class BasicHashable:
    def __cinit__(self):
        self.__frozen__ =  TRUE
        self.cacheable =  TRUE

    def clear(self):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")
    def setdefault(self, *args, **kwargs):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")
    def popitem(self, *args, **kwargs):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")
    def update(self, *args, **kwargs):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")
    def pop(self, *args, **kwargs):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")
    def __setitem__(self, k, v):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")
    def __delitem__(self, k):
        raise TypeError(f"Cannot modify immutable type: {self.__class__.__name__}")


cdef class HashableValues(BasicHashable):

    def __cinit__(self, list values = None, object op = None, bint cacheable = FALSE): # type: ignore
        create_hashable(<BaseHashableStruct*>&self.hashable, <void*>compute_values_hash)
        self.cacheable = cacheable
        self.__frozen__ = TRUE
        self.set_value(values, op)

    cdef void set_value(self, list values, object op):
        create_hashable(<BaseHashableStruct*>&self.hashable, <void*>compute_values_hash)
        self.hashable.op = <PyObject*>NULL
        self.hashable.values = <PyObject*>NULL
        cdef Py_ssize_t count = PY_ZERO

        if op is not None:
            self.hashable.op = Get_PyObject_INCREF(op)
            count = PY_ONE

        if values is not None:
            count += PyList_Size(values)
            self.hashable.values = Get_PyObject_INCREF(values)

        self.hashable.data_size = count

    def __init__(self, values = None, op = None, cacheable = FALSE):
        pass

    @classmethod
    def new(cls, item1: HashableValues, item2: HashableValues | None = None, cacheable: bool = False):
        cdef HashableValues result = cls()
        cdef HashableValuesList* r_hash = &result.hashable
        cdef HashableValuesList* h1 = &item1.hashable
        cdef HashableValuesList* h2

        cdef long hash1, hash2

        result.cacheable = <bint>cacheable
        result.__frozen__ = TRUE
        r_hash.get_hash = &get_cached_hash

        if item2 is not None:
            h2 = &item2.hashable
            hash1 = h1.get_hash(<void*>h1)
            hash2 = h2.get_hash(<void*>h2)

            r_hash.cached_hash = hash1 ^ hash2
            r_hash.data_size = h1.data_size + h2.data_size
        else:
            r_hash.cached_hash = h1.get_hash(<void*>h1)
            r_hash.data_size = h1.data_size

        return result

    def combine(self, HashableValues other, **kwargs):
        return HashableValues.new(self, other, **kwargs)

    cdef long get_hash(self):
        return self.hashable.get_hash(<void*>&self.hashable)

    def __hash__(self):
        return self.get_hash()

    def __len__(self):
        return self.hashable.data_size

NOT_CACHEABLE: HashableValues = HashableValues(cacheable=FALSE)

cdef class CacheKey(BasicHashable):
    def __cinit__(self, object v1, object v2):
        create_hashable(<BaseHashableStruct*>&self.hashable, <void*>compute_cache_key_hash)
        self.hashable.value1 = Get_PyObject_INCREF(v1)
        self.hashable.value2 = Get_PyObject_INCREF(v2)
        self.hashable.data_size = PY_TWO

    def __init__(self, object v1, object v2):
        pass

    cdef bint _eq(self, CacheKey other):
        cdef HashableCacheKey* self_ptr
        cdef HashableCacheKey* other_ptr
        if not PyObject_IsInstance(other, <object>CacheKey):
            return FALSE
        self_ptr = <HashableCacheKey*>&self.hashable
        other_ptr = <HashableCacheKey*>&other.hashable # type: ignore
        return CacheKey_EQ(self_ptr, other_ptr)

    cdef bint _ne(self, CacheKey other):
        cdef HashableCacheKey* self_ptr
        cdef HashableCacheKey* other_ptr
        if not PyObject_IsInstance(other, <object>CacheKey):
            return FALSE
        self_ptr = <HashableCacheKey*>&self.hashable
        other_ptr = <HashableCacheKey*>&other.hashable # type: ignore
        return CacheKey_NE(self_ptr, other_ptr)

    def __eq__(self, other):
        return self._eq(other)

    def __ne__(self, other):
        return self._ne(other)

    cdef long get_hash(self):
        return self.hashable.get_hash(<void*>&self.hashable)

    def __hash__(self):
        return self.get_hash()

cpdef CacheKey get_cache_key(object v1, object v2):
    return CacheKey(v1, v2)

# These functions are meant to mutate dictionaries in place
# that is their entire purpose
cdef inline dict _none_to_null(dict data):
    cdef Py_ssize_t pos = PY_ZERO
    cdef object k, v
    cdef PyObject* key_ptr
    cdef PyObject* value_ptr

    while PyDict_Next(data, &pos, &key_ptr, &value_ptr):
        k = <object>key_ptr
        v = <object>value_ptr
        if v is None:
            PyDict_SetItem(data, k, NULL_STR)
        elif PyDict_Check(v):
            PyDict_SetItem(data, k, _none_to_null(<dict>v))
    return data

cpdef dict none_to_null(dict data):
    return _none_to_null(data)


cdef inline dict _null_to_none(dict data):
    cdef Py_ssize_t pos = PY_ZERO
    cdef object k, v
    cdef PyObject* key_ptr
    cdef PyObject* value_ptr

    while PyDict_Next(data, &pos, &key_ptr, &value_ptr):
        k = <object>key_ptr
        v = <object>value_ptr
        if v == NULL_STR:
            PyDict_SetItem(data, k, None)
        elif PyDict_Check(v):
            PyDict_SetItem(data, k, _null_to_none(<dict>v))
    return data

cpdef dict null_to_none(dict data):
    return _null_to_none(data)

cdef inline dict _filter_out_nones(dict data):
    cdef Py_ssize_t pos = PY_ZERO
    cdef object k, v
    cdef PyObject* key_ptr
    cdef PyObject* value_ptr

    while PyDict_Next(data, &pos, &key_ptr, &value_ptr):
        k = <object>key_ptr
        v = <object>value_ptr
        if v is None:
            PyDict_DelItem(data, k)
        elif PyDict_Check(v):
            PyDict_SetItem(data, k, _filter_out_nones(<dict>v))
    return data

cpdef dict filter_out_nones(dict data):
    return _filter_out_nones(data)

cpdef long two_obj_hash(object a, object b, long current):
    return XOR_Combine(PyObject_Hash(a), PyObject_Hash(b), current)

cpdef long py_xor_hash(long a, long b, long current):
    return XOR_Combine(a, b, current)

cpdef long alt_two_obj_hash(object a, object b, long current):
    return Alt_XOR_Combine(PyObject_Hash(a), PyObject_Hash(b), current)

cpdef long alt_py_xor_hash(long a, long b, long current):
    return Alt_XOR_Combine(a, b, current)

cdef inline bint inline_is_truthy(object obj):
    return <bint>(PyObject_IsTrue(obj) == TRUE)

cdef inline bint inline_is_falsy(object obj):
    return <bint>(PyObject_IsTrue(obj)== FALSE)

cdef inline bint inline_is_none(object obj):
    return <bint>(Py_IsNone(<PyObject*>obj) == TRUE)

cdef inline bint inline_is_int(object obj):
    return <bint>(PyLong_Check(obj) == TRUE)

cdef inline bint inline_is_bool(object obj):
    return PyBool_Check(obj)

cdef inline bint inline_is_tuple(object obj):
    return <bint>(PyTuple_Check(obj) == TRUE)

cdef inline bint inline_is_list(object obj):
    return <bint>(PyList_Check(obj) == TRUE)

cdef inline bint inline_is_dict(object obj):
    return <bint>(PyDict_Check(obj) == TRUE)

cdef inline bint inline_is_bytes(object obj):
    return <bint>(PyBytes_Check(obj) == TRUE)

cdef inline bint inline_is_str(object obj):
    return <bint>(PyUnicode_Check(obj) == TRUE)

cdef inline bint inline_is_mapping(object obj):
    return <bint>(PyMapping_Check(obj) == TRUE)

cdef inline bint inline_is_set(object obj):
    return <bint>(PySet_Check(obj) == TRUE)

cpdef bint is_truthy(object obj):
    return inline_is_truthy(obj)

cpdef bint is_falsy(object obj):
    return inline_is_falsy(obj)

cpdef bint is_int(object obj):
    return inline_is_int(obj)

cpdef bint is_none(object obj):
    return inline_is_none(obj)

cpdef bint is_tuple(object obj):
    return inline_is_tuple(obj)

cpdef bint is_list(object obj):
    return inline_is_list(obj)

cpdef bint is_dict(object obj):
    return inline_is_dict(obj)

cpdef bint is_bytes(object obj):
    return inline_is_bytes(obj)

cpdef bint is_str(object obj):
    return inline_is_str(obj)

cpdef bint is_mapping(object obj):
    return inline_is_mapping(obj)

cpdef bint is_set(object obj):
    return inline_is_set(obj)