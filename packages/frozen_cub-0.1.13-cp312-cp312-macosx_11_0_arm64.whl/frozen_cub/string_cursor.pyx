from .common cimport FALSE, PY_ZERO, TRUE, FUNC_FAILURE as PY_NEG_ONE, PY_ONE
from .string_cursor cimport (
    CursorState, init_state, free_state, peek_char, peek_str, current_char,
    current_str, char_equals, is_char, within_bounds, move_cursor, tick, tock,
    set_index, go_head, go_tail, head_char, tail_char, head_equals, tail_equals,
    Py_UCS4
)
from cpython.unicode cimport PyUnicode_GET_LENGTH, PyUnicode_READ_CHAR


cdef class StringCursor:
    def __cinit__(self, str text="", *, bint allow_negative=FALSE):
        self._text = text
        self.state.chars = NULL  # Initialize before anything else!
        cdef CursorState* result = init_state(&self.state, text, allow_negative)
        if result == NULL: # type: ignore
            raise MemoryError("Failed to allocate cursor state")

    def __dealloc__(self):
        if self.state.chars != NULL:
            free_state(&self.state)

    # === Internal cdef methods ===

    cdef Py_UCS4 _peek_char(self, Py_ssize_t offset):
        return peek_char(&self.state, offset)

    cdef str _peek_str(self, Py_ssize_t offset):
        return peek_str(&self.state, offset)

    cdef Py_UCS4 _current_char(self):
        return current_char(&self.state)

    cdef str _current_str(self):
        return current_str(&self.state)

    cdef bint _char_equals(self, Py_ssize_t offset, Py_UCS4 c):
        return char_equals(&self.state, offset, c)

    cdef bint _is_char_code(self, Py_UCS4 c):
        return is_char(&self.state, c)

    cdef bint _within_bounds(self):
        return within_bounds(&self.state)

    cdef void _move(self, Py_ssize_t offset):
        move_cursor(&self.state, offset)

    cdef void _tick(self):
        tick(&self.state)

    cdef void _tock(self):
        tock(&self.state)

    cdef void _set_index(self, Py_ssize_t new_index):
        set_index(&self.state, new_index)

    cdef void _go_head(self):
        go_head(&self.state)

    cdef void _go_tail(self):
        go_tail(&self.state)

    cdef Py_UCS4 _head_char(self):
        return head_char(&self.state)

    cdef Py_UCS4 _tail_char(self):
        return tail_char(&self.state)

    cdef bint _head_equals(self, Py_UCS4 c):
        return head_equals(&self.state, c)

    cdef bint _tail_equals(self, Py_UCS4 c):
        return tail_equals(&self.state, c)

    cdef bint _matches_ahead(self, str s):
        cdef Py_ssize_t i = PY_ZERO, s_len = PyUnicode_GET_LENGTH(s)
        cdef Py_UCS4 c
        if self.state.index + s_len > self.state.length:
            return FALSE
        while i < s_len:
            c = <Py_UCS4>PyUnicode_READ_CHAR(s, i)
            if self.state.chars[self.state.index + i] != c: # type: ignore
                return FALSE
            i += 1
        return TRUE

    # === Public Python API ===

    @property
    def collection(self) -> str:
        """Get the entire text being scanned."""
        return self._text

    @property
    def index(self):
        """Get current cursor index."""
        return self.state.index

    @index.setter
    def index(self, Py_ssize_t value):
        """Set cursor index."""
        self._set_index(value)

    @property
    def size(self):
        """Get the size of the text."""
        return self.state.length

    @property
    def is_empty(self):
        """Check if the text is empty."""
        return self.state.length == PY_ZERO

    @property
    def not_empty(self):
        """Check if the text is not empty."""
        return self.state.length > PY_ZERO

    @property
    def within_bounds(self):
        """Check if cursor is within bounds."""
        return self._within_bounds()

    @property
    def current(self) -> str:
        """Get the current character at the cursor's index."""
        if not self._within_bounds():
            raise IndexError("Cursor index out of bounds")
        return self._current_str()

    @property
    def head_value(self) -> str:
        """Get the first character in the text."""
        cdef Py_UCS4 c = self._head_char()
        if c == <Py_UCS4>0:
            raise IndexError("Empty text has no head")
        return chr(c)

    @property
    def tail_value(self) -> str:
        """Get the last character in the text."""
        cdef Py_UCS4 c = self._tail_char()
        if c == <Py_UCS4>0:
            raise IndexError("Empty text has no tail")
        return chr(c)

    @property
    def allow_neg(self):
        """Check if negative indexing is allowed."""
        return self.state.allow_neg

    def peek(self, Py_ssize_t offset) -> str:
        """Peek at character at offset from current index."""
        return self._peek_str(offset)

    def move(self, Py_ssize_t offset) -> None:
        """Move the cursor by a given offset."""
        self._move(offset)

    def set_index(self, Py_ssize_t new_index) -> None:
        """Set the cursor's index to a new value."""
        self._set_index(new_index)

    def tick(self) -> None:
        """Move the cursor forward by one."""
        self._tick()

    def tock(self) -> None:
        """Move the cursor backward by one."""
        self._tock()

    def head(self) -> None:
        """Set index to the first character in the text."""
        self._go_head()

    def tail(self) -> None:
        """Set index to the last character in the text."""
        self._go_tail()

    def is_char(self, str s):
        """Check if current character equals target character."""
        if not s:
            return FALSE
        cdef Py_UCS4 c = <Py_UCS4>ord(s[0])
        return self._is_char_code(c)

    def prev_char_equals(self, str s):
        """Check if previous character equals target character."""
        if not self.state.allow_neg and self.state.index == PY_ZERO:
            return FALSE
        if not s:
            return FALSE
        cdef Py_UCS4 c = <Py_UCS4>ord(s[0])
        return self._char_equals(PY_NEG_ONE, c)

    def next_char_equals(self, str s):
        """Check if next character equals target character."""
        if not s:
            return FALSE
        cdef Py_UCS4 c = <Py_UCS4>ord(s[0])
        return self._char_equals(PY_ONE, c)

    def n_char_equals(self, Py_ssize_t offset, str s):
        """Check if character at offset equals target character."""
        if not self.state.allow_neg and self.state.index + offset < PY_ZERO:
            return FALSE
        if not s:
            return FALSE
        cdef Py_UCS4 c = <Py_UCS4>ord(s[0])
        return self._char_equals(offset, c)

    def head_equals(self, str s):
        """Check if the first character equals target."""
        if self.state.length == PY_ZERO or not s:
            return FALSE
        cdef Py_UCS4 c = <Py_UCS4>ord(s[0])
        return self._head_equals(c)

    def tail_equals(self, str s):
        """Check if the last character equals target."""
        if self.state.length == PY_ZERO or not s:
            return FALSE
        cdef Py_UCS4 c = <Py_UCS4>ord(s[0])
        return self._tail_equals(c)

    def matches_ahead(self, str s):
        """Check if string ahead matches target."""
        return self._matches_ahead(s)
