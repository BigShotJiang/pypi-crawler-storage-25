# ============================================================================
# General Constants
# ============================================================================

cdef const long NOT_SET_SENTINEL
cdef const long NOT_FOUND_VAL
cdef const long NOT_FOUND
cdef const long NOT_OWNED

cdef const long SUCCESS
cdef const long FAILURE

cdef const bint FALSE
cdef const bint TRUE

cdef const Py_ssize_t FUNC_SUCCESS
cdef const Py_ssize_t FUNC_FAILURE

cdef const long THIRTY_ONE
cdef const Py_ssize_t PY_ZERO
cdef const Py_ssize_t PY_ONE
cdef const Py_ssize_t PY_TWO
cdef const long LONG_ZERO

# ============================================================================
# LRU Cache Constants
# ============================================================================

cdef const long EMPTY_KEY
cdef const size_t SIZE_NOT_SET
cdef const size_t MIN_BUCKETS
cdef const size_t SIZE_ZERO
cdef const size_t LOAD_FACTOR_NUM
cdef const size_t LOAD_FACTOR_DEN
cdef const size_t MIN_CAPACITY
cdef const size_t DEFAULT_CAPACITY
cdef const size_t MAX_CAPACITY
