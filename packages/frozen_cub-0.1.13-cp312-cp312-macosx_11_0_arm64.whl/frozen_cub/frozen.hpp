#pragma once

#include "pybind11/pytypes.h"
#include "refcount.h"
#include "tupleobject.h"
#include <pybind11/pybind11.h>
#include <vector>

namespace py = pybind11;

static inline bool is_int(PyObject* obj) { return PyLong_Check(obj) == true; }
static inline bool is_str(PyObject* obj) { return PyUnicode_Check(obj) == true; }
static inline bool is_list(PyObject* obj) { return PyList_Check(obj) == true; }
static inline bool is_dict(PyObject* obj) { return PyDict_Check(obj) == true; }
static inline bool is_mapping(PyObject* obj) { return PyMapping_Check(obj) == true; }
static inline bool is_bool(PyObject* obj) { return PyBool_Check(obj) == true; }

static inline bool is_primitive(py::object* obj) {
    if (obj->is_none()) {return true; }
    if (py::isinstance<py::bool_>(*obj)) { return true; }
    if (py::isinstance<py::str>(*obj)) { return true; }
    if (py::isinstance<py::bytes>(*obj)) { return true; }
    if (py::isinstance<py::int_>(*obj)) { return true; }
    if (py::isinstance<py::float_>(*obj)) { return true; }
    return false;
}

inline int64_t hash_combine(int64_t a, int64_t b, int64_t current) {
    current ^= (b + 0x9e3779b9 + (a << 6) + (a >> 2)) & 0x7FFFFFFFFFFFFFFF;
    return current;
}

inline int64_t alt_hash_combine(int64_t a, int64_t b, int64_t current) {
    current ^= a ^ ((b << 5) - b);
    return current;
}

struct KeyValuePair {
    py::object key;
    py::object value;
};


struct BasicHashable {
  int64_t hash_cache = 0;
  size_t data_size = 0;
  bool cachable = true;
  int64_t (*get_hash)(void *hashable);
  int64_t (*hasher)(void *hashable);
  py::object data;
};


class FrozenDict : public BasicHashable {
private:
    py::frozenset fast_keys_;            // For O(1) key existence checks
    py::tuple keys_;                     // For fast iteration over keys
    py::tuple values_;                   // For fast iteration over values
    py::tuple items_;                    // For fast iteration over items

public:
  FrozenDict(std::vector<KeyValuePair> obj) { // Tuple of Tuples where each inner tuple is (key, value)
        py::set seen_keys;
        py::list keys;
        py::list values;
        py::list items;
        py::dict temp_dict;

        // Still need to do the hashable part where we recursively freeze the values and create a hashable dict

        for (auto& item : obj) {
            auto key_ptr = item.key;
            auto value_ptr = item.value;
            if (!seen_keys.contains(key_ptr)) {
                seen_keys.add(key_ptr);
                keys.append(key_ptr);
                values.append(value_ptr);
                items.append(py::make_tuple(key_ptr, value_ptr));
                temp_dict[key_ptr] = value_ptr;
            }
        }

        fast_keys_ = py::frozenset(seen_keys);
        keys_ = py::tuple(keys);
        values_ = py::tuple(values);
        items_ = py::tuple(items);

        data_size = temp_dict.size();
    }
    py::object get(py::object key, py::object default_value = py::none()) { if ( fast_keys_.contains(key)) { return data[key]; } else { return default_value; } }
    py::tuple keys() { return keys_; }
    py::tuple values() { return values_; }
    py::tuple items() { return items_; }
    bool contains(py::object key) { return fast_keys_.contains(key); }
    int64_t get_hash() { return hash_cache; }
};

static inline bool already_frozen(py::object obj) { 
    return py::isinstance<FrozenDict>(obj) || py::isinstance<py::tuple>(obj) || py::isinstance<py::frozenset>(obj) || is_primitive(&obj);
}


static inline FrozenDict to_frozen_dict(py::dict obj) {
    Py_ssize_t pos = 0;
    PyObject* key_ptr;
    PyObject* value_ptr;
    std::vector<KeyValuePair> items;
    items.reserve(obj.size());

    while (PyDict_Next(obj.ptr(), &pos, &key_ptr, &value_ptr)) {
        items.push_back({ py::reinterpret_borrow<py::object>(key_ptr), py::reinterpret_borrow<py::object>(value_ptr) });
    }
    return FrozenDict(items);
}

inline py::tuple to_frozen_list(py::list obj) {
    py::tuple items(obj.size());
    for (size_t i = 0; i < obj.size(); ++i) {
        items[i] = obj[i]; // Replace with actual freezing logic
    }
    return items;
}

static inline py::frozenset to_frozen_set(py::set obj) {
    py::tuple items(obj.size());
    size_t i = 0;
    for (auto item : obj) {
        items[i++] = item; // Replace with actual freezing logic
    }
    return py::frozenset(items);
}


static inline py::object freeze(py::object obj) {
    if (py::isinstance<py::list>(obj)) {
        return to_frozen_list(obj.cast<py::list>());
    }
    if (py::isinstance<py::dict>(obj)) {
        // Implement to_frozen_dict logic here
    }
    if (py::isinstance<py::set>(obj)) {
        return to_frozen_set(obj.cast<py::set>());
    }
    return obj; // Return as is if it's already hashable
}


// cdef inline bint already_frozen(object obj):
//     return PyObject_IsInstance(obj, BasicHashable)



// cdef inline tuple to_frozen_list(list obj):
//     cdef Py_ssize_t size = PyList_Size(obj), index = PY_ZERO
//     cdef tuple items = PyTuple_New(size)
//     while index < size:
//         Tuple_Set_INCREF(items, index, c_freeze(<object>PyList_GET_ITEM(obj, index)))
//         index += 1
//     return items

// cdef inline object to_frozen_set(set obj):
//     cdef tuple frozen_items = PyTuple_New(PySet_Size(obj))
//     cdef Py_ssize_t index = PY_ZERO
//     for item in obj:
//         Tuple_Set_INCREF(frozen_items, index, c_freeze(item))
//         index += 1
//     return PyFrozenSet_New(frozen_items)

// cdef inline tuple freeze_tuple_items(tuple obj):
//     cdef Py_ssize_t size = PyTuple_Size(obj), index = PY_ZERO
//     cdef tuple frozen_items = PyTuple_New(size)
//     while index < size:
//         Tuple_Set_INCREF(frozen_items, index, c_freeze(<object>PyTuple_GET_ITEM(obj, index)))
//         index += 1
//     return frozen_items

// cdef inline object inline_freeze(object obj, bint return_tuples = FALSE):
//     if PyTuple_Check(obj):
//         return freeze_tuple_items(<tuple>obj)
//     if PyDict_Check(obj):
//         return to_frozen_dict(<dict>obj, return_tuples)
//     if PyList_Check(obj):
//         return to_frozen_list(<list>obj)
//     if PySet_Check(obj):
//         return to_frozen_set(<set>obj)
//     return obj