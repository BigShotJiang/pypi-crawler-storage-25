from cpython.list cimport PyList_Size, PyList_GET_ITEM
from cpython.tuple cimport PyTuple_Size, PyTuple_GET_ITEM
from cpython.object cimport PyObject
from cpython.ref cimport Py_INCREF, Py_DECREF
from .common cimport PY_ZERO, SIZE_ZERO, SIZE_NOT_SET as NONE_SET
from libc.stdlib cimport malloc, free

cdef const Py_ssize_t PY_FOUR = <Py_ssize_t>4
cdef const size_t MAX_CAPACITY = <size_t>1_000_000

cdef struct QueueNode:
    PyObject* value
    QueueNode* next

cdef struct QueueStorage:
    QueueNode* nodes
    size_t capacity
    size_t size
    size_t next_free
    size_t head
    size_t tail

cdef inline void init_storage(QueueStorage* storage, size_t initial_capacity):
    cdef size_t i = SIZE_ZERO
    storage.nodes = <QueueNode*>malloc(initial_capacity * sizeof(QueueNode))
    storage.size = SIZE_ZERO
    storage.capacity = initial_capacity
    storage.head = NONE_SET
    storage.tail = NONE_SET
    while i < initial_capacity - 1:
        storage.nodes[i].value = NULL  # type: ignore
        storage.nodes[i].next = &storage.nodes[i + 1]  # type: ignore
        i += 1
    storage.nodes[initial_capacity - 1].value = NULL  # type: ignore
    storage.nodes[initial_capacity - 1].next = NULL  # type: ignore
    storage.next_free = SIZE_ZERO

cdef inline void free_storage(QueueStorage* storage):
    cdef size_t i = SIZE_ZERO
    cdef QueueNode* node
    while i < storage.capacity:
        node = &storage.nodes[i]  # type: ignore
        if node.value != NULL:  # type: ignore
            Py_DECREF(<object>node.value)
        i += 1
    free(<void*>storage.nodes)

cdef inline void set_value(QueueNode* node, PyObject* item):
    Py_INCREF(<object>item)
    node.value = item
    node.next = NULL

cdef inline void append_to_storage(QueueStorage* storage, PyObject* item):
    cdef size_t free_idx
    cdef QueueNode* node
    cdef QueueNode* tail_node
    if storage.next_free == NONE_SET:
        add_more_capacity(storage)
    free_idx = storage.next_free
    node = &storage.nodes[free_idx]  # type: ignore
    if node.next != NULL:  # type: ignore
        storage.next_free = <size_t>(node.next - storage.nodes)  # type: ignore
    else:
        storage.next_free = NONE_SET
    set_value(node, item)

    if storage.tail == NONE_SET:
        storage.head = free_idx
        storage.tail = free_idx
    else:
        tail_node = &storage.nodes[storage.tail]  # type: ignore
        tail_node.next = node
        storage.tail = free_idx
    storage.size += 1

cdef inline PyObject* pop_from_storage(QueueStorage* storage):
    cdef size_t head_idx
    cdef QueueNode* head_node
    cdef PyObject* item
    if storage.head == NONE_SET:
        return <PyObject*>NULL
    head_idx = storage.head
    head_node = &storage.nodes[head_idx]  # type: ignore
    item = head_node.value

    if head_node.next != NULL:  # type: ignore
        storage.head = <size_t>(head_node.next - storage.nodes) # type: ignore
    else:
        storage.head = NONE_SET
        storage.tail = NONE_SET

    head_node.value = NULL
    if storage.next_free != NONE_SET:
        head_node.next = &storage.nodes[storage.next_free]  # type: ignore
    else:
        head_node.next = NULL 
    storage.next_free = head_idx
    storage.size -= 1
    return item

cdef inline PyObject* peek_head(QueueStorage* storage):
    if storage.head == NONE_SET:
        return <PyObject*>NULL
    return storage.nodes[storage.head].value  # type: ignore

cdef inline PyObject* peek_tail(QueueStorage* storage):
    if storage.tail == NONE_SET:
        return <PyObject*>NULL
    return storage.nodes[storage.tail].value  # type: ignore

cdef inline void ensure_capacity(QueueStorage* storage, size_t needed):
    while storage.capacity - storage.size < needed:
        add_more_capacity(storage)

cdef inline void extend_storage_list(QueueStorage* storage, list items):
    cdef Py_ssize_t length = PyList_Size(items)
    cdef Py_ssize_t i = PY_ZERO
    if length > 0:
        ensure_capacity(storage, <size_t>length)
    while i < length:
        append_to_storage(storage, PyList_GET_ITEM(items, i))  # type: ignore
        i += 1

cdef inline void extend_storage_tuple(QueueStorage* storage, tuple items):
    cdef Py_ssize_t length = PyTuple_Size(items)
    cdef Py_ssize_t i = PY_ZERO
    if length > 0:
        ensure_capacity(storage, <size_t>length)
    while i < length:
        append_to_storage(storage, PyTuple_GET_ITEM(items, i))  # type: ignore
        i += 1

cdef inline void add_more_capacity(QueueStorage* storage):
    cdef size_t new_capacity = storage.capacity * 2
    cdef size_t old_capacity = storage.capacity
    cdef size_t i = SIZE_ZERO, next_idx
    cdef QueueNode* new_nodes
    cdef QueueNode* old_nodes = storage.nodes
    if storage.capacity == MAX_CAPACITY:
        return # type: ignore
    if new_capacity > MAX_CAPACITY:
        new_capacity = MAX_CAPACITY
    new_nodes = <QueueNode*>malloc(new_capacity * sizeof(QueueNode))

    while i < old_capacity:
        new_nodes[i].value = old_nodes[i].value  # type: ignore
        if old_nodes[i].next != NULL:  # type: ignore
            next_idx = <size_t>(old_nodes[i].next - old_nodes)  # type: ignore
            new_nodes[i].next = &new_nodes[next_idx]  # type: ignore
        else:
            new_nodes[i].next = NULL  # type: ignore
        i += 1

    while i < new_capacity - 1:
        new_nodes[i].value = NULL  # type: ignore
        new_nodes[i].next = &new_nodes[i + 1]  # type: ignore
        i += 1
    new_nodes[new_capacity - 1].value = NULL  # type: ignore
    new_nodes[new_capacity - 1].next = NULL  # type: ignore

    if storage.next_free == NONE_SET:
        storage.next_free = old_capacity
    else:
        i = storage.next_free
        while new_nodes[i].next != NULL:  # type: ignore
            next_idx = <size_t>(new_nodes[i].next - new_nodes)  # type: ignore
            i = next_idx
        new_nodes[i].next = &new_nodes[old_capacity]  # type: ignore
    free(<void*>old_nodes)
    storage.nodes = new_nodes
    storage.capacity = new_capacity

cdef class SimpooQueue:
    cdef QueueStorage storage

    # Private
    cdef void _push(self, object item)
    cdef object _pop(self)
    cdef void _extend(self, iterable)
    cdef object _peek_tail(self)
    cdef object _peek_head(self)
    cdef object _get_iter(self)


    # Public
    cpdef put(self, item)
    cpdef enqueue(self, item)
    cpdef get(self)
    cpdef dequeue(self)
    cpdef peek(self, left=*)
    cpdef extend(self, iterable)
