#pragma once

#include <Python.h>
#include <cstddef>
#include <functional>

namespace frozen_cub {

/* ============================================================================
 * Constants (should match common.pxd)
 * ============================================================================ */

constexpr long FC_NOT_OWNED = -1;
constexpr int FC_PY_ZERO = 0;
constexpr long FC_LONG_ZERO = 0L;
constexpr long FC_NOT_SET_SENTINEL = static_cast<long>(-1);

/* ============================================================================
 * Type Definitions
 * ============================================================================ */

template<typename T> using HashCallable = std::function<long(T*)>;
template <typename T> using CommonCallable = std::function<void(T *)>;
template <typename T> using ListCallable = std::function<PyObject*(T*)>;

/* ============================================================================
 * Structs
 * ============================================================================ */

struct BaseHashableStruct {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable<BaseHashableStruct> get_hash;
    HashCallable<BaseHashableStruct> hasher;
};

struct HashableCacheKey {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable<HashableCacheKey> get_hash;
    HashCallable<HashableCacheKey> hasher;
    PyObject* value1;
    PyObject* value2;
};

struct HashableDict {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable<HashableDict> get_hash;
    HashCallable<HashableDict> hasher;
    PyObject* data;
};

struct HashableValuesList {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable<HashableValuesList> get_hash;
    HashCallable<HashableValuesList> hasher;
    PyObject* values;  /* list of hashable items */
    PyObject* op;      /* optional operation identifier */
};

struct RLock {
    PyThread_type_lock lock;
    long owner;
    int count;
    CommonCallable<RLock> acquire_lock;
    CommonCallable<RLock> release_lock;
};

/* ============================================================================
 * Inline Utility Functions
 * ============================================================================ */

static inline long Hash_Object(PyObject* obj) { return PyObject_Hash(obj); }

static inline PyObject* Get_PyObject_INCREF(PyObject* obj) { Py_INCREF(obj); return obj; }

static inline void Tuple_Set_INCREF(PyObject* tuple_obj, Py_ssize_t index, PyObject* item) {
    Py_INCREF(item);
    PyTuple_SET_ITEM(tuple_obj, index, item);
}

static inline long Alt_XOR_Combine(long a, long b, long current) {
    current ^= (b + 0x9e3779b9L + (a << 6) + (a >> 2)) & 0x7FFFFFFFFFFFFFFFL;
    return current;
}

static inline long XOR_Combine(long a, long b, long current) {
    current ^= a ^ ((b << 5) - b);
    return current;
}

static inline int obj_is_primitive(PyObject* obj) {
    if (Py_IsNone(obj)) return true;
    if (PyBool_Check(obj)) return true;
    if (PyUnicode_Check(obj)) return true;
    if (PyBytes_Check(obj)) return true;
    if (PyLong_Check(obj)) return true;
    if (PyFloat_Check(obj)) return true;
    return false;
}

/* ============================================================================
 * Hash Functions (forward declarations needed for circular refs)
 * ============================================================================ */

static inline long NOT_SET_NOOP(BaseHashableStruct* ptr) { (void)ptr; return FC_NOT_SET_SENTINEL; }
static inline long get_cached_hash(BaseHashableStruct* ptr) { return ptr->cached_hash; }

static inline long get_cached_hash_cond(BaseHashableStruct* ptr) {
    if (ptr->cached_hash == FC_NOT_SET_SENTINEL) {
        ptr->cached_hash = ptr->hasher(ptr);
        ptr->get_hash = get_cached_hash;
    }
    return ptr->cached_hash;
}

static inline void create_hashable(BaseHashableStruct* hashable, HashCallable<BaseHashableStruct> hasher) {
    hashable->cached_hash = FC_NOT_SET_SENTINEL;
    hashable->data_size = FC_PY_ZERO;
    hashable->get_hash = get_cached_hash_cond;
    hashable->hasher = NOT_SET_NOOP;
    if (hasher) {
        hashable->hasher = hasher;
    }
}

static inline long compute_cache_key_hash(HashableCacheKey* hashable) { return PyObject_Hash(hashable->value1) ^ PyObject_Hash(hashable->value2); }

static inline int CacheKey_EQ(HashableCacheKey* key1, HashableCacheKey* key2) {
    if (key1->data_size != key2->data_size) return false;
    return PyObject_RichCompareBool(key1->value1, key2->value1, Py_EQ) &&
           PyObject_RichCompareBool(key1->value2, key2->value2, Py_EQ);
}

static inline int CacheKey_NE(HashableCacheKey* key1, HashableCacheKey* key2) {
    if (key1->data_size != key2->data_size) return true;
    return PyObject_RichCompareBool(key1->value1, key2->value1, Py_NE) ||
           PyObject_RichCompareBool(key1->value2, key2->value2, Py_NE);
}

static inline long compute_dict_hash(HashableDict* hashable) {
    Py_ssize_t pos = 0;
    long result = 0;
    PyObject* key_ptr;
    PyObject* value_ptr;

    if (hashable->data_size == 0) { return PyObject_Hash(PyTuple_New(0)); }

    while (PyDict_Next(hashable->data, &pos, &key_ptr, &value_ptr)) {
      result = XOR_Combine(Hash_Object(key_ptr),
       Hash_Object(value_ptr), result);
    }
    return result;
}

static inline int Dict_EQ(HashableDict* dict1, HashableDict* dict2) {
    if (dict1->data_size != dict2->data_size) return false;
    return PyObject_RichCompareBool(dict1->data, dict2->data, Py_EQ);
}

static inline int Dict_NE(HashableDict* dict1, HashableDict* dict2) {
    if (dict1->data_size != dict2->data_size) return true;
    return PyObject_RichCompareBool(dict1->data, dict2->data, Py_NE);
}

/* ============================================================================
 * RLock Functions
 * ============================================================================ */

/* Forward declarations for circular refs */
static inline void Acquire_RLock(RLock* ptr);
static inline void Release_RLock(RLock* ptr);

static inline void RLock_New(RLock* r_lock, int enabled) {
    r_lock->lock = PyThread_allocate_lock();
    r_lock->owner = FC_NOT_OWNED;
    r_lock->count = 0;
    r_lock->acquire_lock = [](RLock* ptr) {};
    r_lock->release_lock = [](RLock* ptr) {};
    if (enabled) {
        r_lock->acquire_lock = Acquire_RLock;
        r_lock->release_lock = Release_RLock;
    }
}

static inline void RLock_Free(RLock* r_lock) { if (r_lock->lock) PyThread_free_lock(r_lock->lock); }

static inline void Acquire_RLock(RLock* l) {
    long me = PyThread_get_thread_ident();
    if (l->owner == me) {
        l->count += 1;
        return;
    }
    PyThread_acquire_lock(l->lock, 1);
    l->owner = me;
    l->count = 1;
}

static inline void Release_RLock(RLock* l) {
    l->count -= 1;
    if (l->count == 0) {
        l->owner = FC_NOT_OWNED;
        PyThread_release_lock(l->lock);
    }
}

}  // namespace frozen_cub
