from cpython.dict cimport PyDict_Keys, PyDict_Size, PyDict_New, PyDict_SetItem, PyDict_GetItem, PyDict_Items, PyDict_Values, PyDict_Check
from cpython.object cimport PyObject_IsInstance
from cpython.list cimport PyList_Check
from cpython.ref cimport Py_INCREF
from cpython.tuple cimport PyTuple_Check
from cpython.object cimport PyObject
from cpython.set cimport PySet_Contains, PySet_New, PySet_Check, PySet_Add
from frozen_cub.utils cimport BaseHashableStruct, BasicHashable, HashableDict, create_hashable, compute_dict_hash, Dict_EQ, Dict_NE, Get_PyObject_INCREF
from frozen_cub.common cimport FALSE, TRUE
from .frozen cimport already_frozen, freeze_tuple_items, to_frozen_dict, to_frozen_list, to_frozen_set

cdef object c_freeze(object obj, bint return_tuples = FALSE):
    # if is_primitive(<PyObject*>obj):
    #     return obj
    if already_frozen(obj):
        return obj
    if PyTuple_Check(obj):
        return freeze_tuple_items(<tuple>obj)
    if PyDict_Check(obj):
        return to_frozen_dict(<dict>obj, return_tuples)
    if PyList_Check(obj):
        return to_frozen_list(<list>obj)
    if PySet_Check(obj):
        return to_frozen_set(<set>obj)
    return obj

cpdef freeze(object obj):
    """Freeze an object by making it immutable and thus hashable."""
    return c_freeze(obj)


cdef class FrozenDict(BasicHashable):
    def __cinit__(self, object data = None):
        create_hashable(<BaseHashableStruct*>&self.hashable, <void*>compute_dict_hash)
        cdef dict temp_dict = PyDict_New() 
        self._fast_keys = PySet_New(<object>NULL)
        self._keys = None
        self._values = None
        self._items = None

        if data is not None:
            if PyDict_Check(data):
                data = c_freeze(data, TRUE) # Ideally we are tuple[tuple[Any, Any], ...] by now

            for k, v in data: # type: ignore
                PySet_Add(self._fast_keys, k)
                PyDict_SetItem(temp_dict, k, c_freeze(v))

        self.hashable.data_size = PyDict_Size(temp_dict)
        self.hashable.data = Get_PyObject_INCREF(temp_dict)

    def __init__(self, object data = None):
        pass

    cdef object _get(self, object key, object default=None):
        if not PySet_Contains(self._fast_keys, key):
            return default
        value = PyDict_GetItem(<object>self.hashable.data, key)
        if value != NULL: #type: ignore
            return <object>value
        return default

    cpdef object get(self, object key, object default=None):
        return self._get(key, default)

    cpdef object keys(self):
        if self._keys is None:
            self._keys = list(PyDict_Keys(<object>self.hashable.data))
        return self._keys # type: ignore

    cpdef object values(self):
        if self._values is None:
            self._values = list(PyDict_Values(<object>self.hashable.data))
        return self._values # type: ignore

    cpdef object items(self):
        if self._items is None:
            self._items = list(PyDict_Items(<object>self.hashable.data))
        return self._items # type: ignore

    cdef bint _contains(self, object key):
        return PySet_Contains(self._fast_keys, key)

    cpdef long get_hash(self):
        return self.hashable.get_hash(<void*>&self.hashable)

    cdef bint _eq(self, FrozenDict other):
        cdef HashableDict* self_ptr
        cdef HashableDict* other_ptr
        if not PyObject_IsInstance(other, <object>FrozenDict):
            return FALSE
        self_ptr = <HashableDict*>&self.hashable
        other_ptr = <HashableDict*>&other.hashable # type: ignore
        return Dict_EQ(self_ptr, other_ptr)

    cdef bint _ne(self, FrozenDict other):
        cdef HashableDict* self_ptr
        cdef HashableDict* other_ptr
        if not PyObject_IsInstance(other, <object>FrozenDict):
            return FALSE
        self_ptr = <HashableDict*>&self.hashable
        other_ptr = <HashableDict*>&other.hashable # type: ignore
        return Dict_NE(self_ptr, other_ptr)

    def __eq__(self, other):
        return self._eq(other)

    def __ne__(self, other):
        return self._ne(other)

    def __hash__(self):
        return self.get_hash()

    def __contains__(self, key):
        return self._contains(key)

    def __iter__(self):
        return iter(self.keys()) # type: ignore

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({<object>self.hashable.data})"

    def __str__(self) -> str:
        return self.__repr__()

    def __getitem__(self, key):
        if not self._contains(key):
            raise KeyError(key)
        return self._get(key)

    def __len__(self):
        return self.hashable.data_size

NULL_KEY = "__null__"
NULL_TUPLE = (NULL_KEY,)
NONE_TUPLE = (None,)
NONE_ITEMS_TUPLE = ((NULL_KEY, None),)

cdef class NullFrozenDict(FrozenDict):
    def __init__(self):
        create_hashable(<BaseHashableStruct*>&self.hashable, <void*>NULL)
        cdef dict data = PyDict_New()
        self.cacheable = FALSE
        PyDict_SetItem(data, NULL_KEY, None)
        Py_INCREF(data)
        self.hashable.data = <PyObject*>data

    cpdef object keys(self):
        return NULL_TUPLE

    cpdef object values(self):
        return NONE_TUPLE

    cpdef object items(self):
        return NONE_ITEMS_TUPLE

    def __getitem__(self, key):
        return None

    def __hash__(self):
        raise NotImplementedError("NullFrozenDict does not support hashing")

    cpdef long _compute_hash(self) except *:
        raise NotImplementedError("NullFrozenDict does not support hashing")

    def __eq__(self, other) -> bool:
        return isinstance(other, NullFrozenDict)

    def __ne__(self, other) -> bool:
        return not self.__eq__(other)

    def __len__(self) -> int:
        return 0

    def __contains__(self, key) -> bool:
        return False

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"

NULL_FROZEN_DICT = NullFrozenDict()
