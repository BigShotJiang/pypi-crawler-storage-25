from cpython.list cimport PyList_Check, PyList_New, PyList_SET_ITEM
from cpython.tuple cimport PyTuple_Check
from cpython.object cimport PyObject
from cpython.ref cimport Py_INCREF
from .common cimport PY_ZERO, SIZE_ZERO, SIZE_NOT_SET as NONE_SET

cdef size_t DEFAULT_CAPACITY = <size_t>16

from .simple_queue cimport (
    init_storage, free_storage, extend_storage_list, extend_storage_tuple,
    append_to_storage, pop_from_storage, peek_tail, peek_head, QueueNode
)

cdef class SimpooQueue:
    def __cinit__(self, object data=None, size_t capacity=DEFAULT_CAPACITY):  # type: ignore
        init_storage(&self.storage, capacity)
        if data is not None:
            self._extend(data)

    def __dealloc__(self):
        free_storage(&self.storage)

    cdef void _extend(self, iterable):
        if PyList_Check(iterable):
            extend_storage_list(&self.storage, <list>iterable)
        elif PyTuple_Check(iterable):
            extend_storage_tuple(&self.storage, <tuple>iterable)

    cdef void _push(self, object item):
        append_to_storage(&self.storage, <PyObject*>item)

    cdef object _pop(self):
        cdef PyObject* item = pop_from_storage(&self.storage)
        if item == NULL: # type: ignore
            raise IndexError("pop from empty SimpooQueue")
        return <object>item

    cdef object _peek_tail(self):
        cdef PyObject* item = peek_tail(&self.storage)
        if item == NULL: # type: ignore
            raise IndexError("peek from empty SimpooQueue")
        return <object>item

    cdef object _peek_head(self):
        cdef PyObject* item = peek_head(&self.storage)
        if item == NULL: # type: ignore
            raise IndexError("peek from empty SimpooQueue")
        return <object>item

    cdef object _get_iter(self):
        cdef list items = PyList_New(<Py_ssize_t>self.storage.size)
        cdef size_t idx = self.storage.head
        cdef Py_ssize_t insert_idx = PY_ZERO
        cdef QueueNode* node
        cdef object value
        while idx != NONE_SET:
            node = &self.storage.nodes[idx] # type: ignore
            value = <object>node.value
            Py_INCREF(value)
            PyList_SET_ITEM(items, insert_idx, value)  # type: ignore
            insert_idx += 1
            idx = <size_t>(node.next - self.storage.nodes) if node.next != NULL else NONE_SET  # type: ignore
        return iter(items)

    cpdef put(self, item):
        self._push(item)

    cpdef enqueue(self, item):
        self._push(item)

    cpdef get(self):
        return self._pop()

    cpdef dequeue(self):
        return self._pop()

    cpdef extend(self, iterable):
        self._extend(iterable)

    cpdef peek(self, left=True):
        return self._peek_head() if left else self._peek_tail()

    @property
    def empty(self):
        return self.storage.size == SIZE_ZERO

    @property
    def not_empty(self):
        return self.storage.size != SIZE_ZERO 

    @property
    def size(self):
        return self.storage.size

    def __bool__(self):
        return self.not_empty

    def __len__(self):
        return self.size

    def __iter__(self):
        return self

    def __next__(self):
      if self.storage.head == NONE_SET:
          raise StopIteration
      return self._pop()