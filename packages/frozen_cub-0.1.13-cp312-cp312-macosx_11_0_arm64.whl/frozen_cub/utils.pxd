from cpython.object cimport PyObject, PyObject_Hash, PyObject_RichCompareBool, Py_EQ, Py_NE
from cpython.ref cimport Py_INCREF
from cpython.tuple cimport PyTuple_SET_ITEM
from cpython.object cimport PyObject
from cpython.unicode cimport PyUnicode_Check
from cpython.bytes cimport PyBytes_Check
from cpython.dict cimport PyDict_Next
from cpython.long cimport PyLong_Check
from cpython.float cimport PyFloat_Check
from cpython.bool cimport PyBool_Check

from cpython.pythread cimport (
      PyThread_type_lock,
      PyThread_allocate_lock,
      PyThread_free_lock,
      PyThread_acquire_lock,
      PyThread_release_lock,
      PyThread_get_thread_ident,
  )

from frozen_cub.common cimport  FALSE, TRUE, NOT_OWNED, PY_ZERO, LONG_ZERO, NOT_SET_SENTINEL

cdef extern from "object.h":
    int Py_IsNone(PyObject* x)


ctypedef void (*CommonCallable)(void* ptr)

cdef inline void NOOP(void* ptr):
    pass

# ============================================================================
# Utility Functions
# ============================================================================

cdef inline bint c_check_conditions(tuple conditions, object arg):
    cdef object cond
    for cond in conditions:
        if not cond(arg): # type: ignore[call-arg]
            return FALSE
    return TRUE

cdef inline void Tuple_Set_INCREF(tuple obj, Py_ssize_t index, object item):
    Py_INCREF(item)
    PyTuple_SET_ITEM(obj, index, item)

cdef inline long Hash_Object(PyObject* obj):
    return PyObject_Hash(<object>obj)

cdef inline PyObject* Get_PyObject_INCREF(object obj):
    Py_INCREF(obj)
    return <PyObject*>obj

cdef inline long Alt_XOR_Combine(long a, long b, long current):
    current ^= (b + <long>0x9e3779b9 + (a << 6) + (a >> 2)) & 0x7FFFFFFFFFFFFFFF
    return current

cdef inline long XOR_Combine(long a, long b, long current):
    current ^= a ^ ((b << 5) - b)
    return current

cdef inline bint obj_is_primitive(object obj):
    if Py_IsNone(<PyObject*>obj):
        return TRUE
    if PyBool_Check(obj):
        return TRUE
    if PyUnicode_Check(obj):
        return TRUE
    if PyBytes_Check(obj):
        return TRUE
    if PyLong_Check(obj):
        return TRUE
    if PyFloat_Check(obj):
        return TRUE
    return FALSE

# ============================================================================
# BasicHashable Class
# ============================================================================

ctypedef long (*HashCallable)(void* ptr)

cdef inline long NOT_SET_NOOP(void* ptr):
    return NOT_SET_SENTINEL

cdef struct BaseHashableStruct:
    long cached_hash
    Py_ssize_t data_size
    HashCallable get_hash
    HashCallable hasher

cdef struct HashableCacheKey:
    long cached_hash
    Py_ssize_t data_size
    HashCallable get_hash
    HashCallable hasher
    PyObject* value1
    PyObject* value2


cdef struct HashableDict:
    long cached_hash
    Py_ssize_t data_size
    HashCallable get_hash
    HashCallable hasher
    PyObject* data

cdef struct HashableValuesList:
    long cached_hash
    Py_ssize_t data_size
    HashCallable get_hash
    HashCallable hasher
    PyObject* values  # list of hashable items
    PyObject* op      # optional operation identifier

cdef inline long get_cached_hash_cond(void* ptr):
    cdef BaseHashableStruct* hashable = <BaseHashableStruct*>ptr
    if hashable.cached_hash == NOT_SET_SENTINEL:
        hashable.cached_hash = hashable.hasher(ptr)
        hashable.get_hash = &get_cached_hash
    return hashable.cached_hash

cdef inline long get_cached_hash(void* ptr):
    cdef BaseHashableStruct* hashable = <BaseHashableStruct*>ptr
    return hashable.cached_hash

cdef inline void create_hashable(BaseHashableStruct* hashable, void* hasher):
    hashable.cached_hash = NOT_SET_SENTINEL
    hashable.data_size = PY_ZERO
    hashable.get_hash = &get_cached_hash_cond
    hashable.hasher = &NOT_SET_NOOP
    if hasher != NULL: # type: ignore
        hashable.hasher = <HashCallable>hasher


cdef inline long compute_cache_key_hash(void* ptr):
    cdef HashableCacheKey* hashable = <HashableCacheKey*>ptr
    return <long>PyObject_Hash(<object>hashable.value1) ^ <long>PyObject_Hash(<object>hashable.value2)

cdef inline bint CacheKey_EQ(HashableCacheKey* key1, HashableCacheKey* key2):
    if key1.data_size != key2.data_size:
        return FALSE
    return PyObject_RichCompareBool(<object>key1.value1, <object>key2.value1, Py_EQ) and PyObject_RichCompareBool(<object>key1.value2, <object>key2.value2, Py_EQ)

cdef inline bint CacheKey_NE(HashableCacheKey* key1, HashableCacheKey* key2):
    if key1.data_size != key2.data_size:
        return TRUE
    return PyObject_RichCompareBool(<object>key1.value1, <object>key2.value1, Py_NE) or PyObject_RichCompareBool(<object>key1.value2, <object>key2.value2, Py_NE)

cdef inline long compute_dict_hash(void* ptr):
    cdef HashableDict* hashable = <HashableDict*>ptr
    cdef Py_ssize_t pos = PY_ZERO
    cdef long result = LONG_ZERO
    cdef PyObject* key_ptr
    cdef PyObject* value_ptr

    if hashable.data_size == PY_ZERO:
        return <long>PyObject_Hash(())

    while PyDict_Next(<object>hashable.data, &pos, &key_ptr, &value_ptr):
        result = XOR_Combine(Hash_Object(key_ptr), Hash_Object(value_ptr), result)
    return result

cdef inline long compute_values_hash(void* ptr):
    cdef HashableValuesList* hashable = <HashableValuesList*>ptr
    cdef long result = LONG_ZERO
    cdef object item
    cdef list values_list

    if hashable.op != <PyObject*>NULL: # type: ignore
        result = PyObject_Hash(<object>hashable.op)

    if hashable.values != <PyObject*>NULL: # type: ignore
        values_list = <list>hashable.values
        for item in values_list:
            result ^= PyObject_Hash(item)
    return result

cdef inline bint Dict_EQ(HashableDict* dict1, HashableDict* dict2):
    if dict1.data_size != dict2.data_size:
        return FALSE
    return PyObject_RichCompareBool(<object>dict1.data, <object>dict2.data, Py_EQ)

cdef inline bint Dict_NE(HashableDict* dict1, HashableDict* dict2):
    if dict1.data_size != dict2.data_size:
        return TRUE
    return PyObject_RichCompareBool(<object>dict1.data, <object>dict2.data, Py_NE)

cdef class BasicHashable:
    cdef readonly bint __frozen__
    cdef readonly bint cacheable

cdef class HashableValues(BasicHashable):
    cdef HashableValuesList hashable

    cdef long get_hash(self) # type: ignore
    cdef void set_value(self, list values, object op) # type: ignore

cdef class CacheKey(BasicHashable):
    cdef HashableCacheKey hashable

    cdef bint _eq(self, CacheKey other) # type: ignore
    cdef bint _ne(self, CacheKey other) # type: ignore
    cdef long get_hash(self) # type: ignore


# ============================================================================
# RLock Implementation
# ============================================================================

cdef struct RLock:
    PyThread_type_lock lock
    long owner
    int count
    CommonCallable acquire_lock
    CommonCallable release_lock

cdef inline void RLock_New(RLock* r_lock, bint enabled):
    r_lock.lock = PyThread_allocate_lock()
    r_lock.owner = NOT_OWNED
    r_lock.count = 0
    r_lock.acquire_lock = &NOOP
    r_lock.release_lock = &NOOP
    if enabled:
        r_lock.acquire_lock = &Acquire_RLock
        r_lock.release_lock = &Release_RLock

cdef inline void RLock_Free(RLock* r_lock):
    if r_lock.lock:
        PyThread_free_lock(r_lock.lock)

cdef inline void Acquire_RLock(void* ptr):
    cdef RLock* l = <RLock*>ptr
    cdef long me = PyThread_get_thread_ident()
    if l.owner == me:
        l.count += 1
        return # type: ignore
    PyThread_acquire_lock(l.lock, 1)
    l.owner = me
    l.count = 1

cdef inline void Release_RLock(void* ptr):
    cdef RLock* l = <RLock*>ptr
    l.count -= 1
    if l.count == 0:
        l.owner = NOT_OWNED
        PyThread_release_lock(l.lock)

