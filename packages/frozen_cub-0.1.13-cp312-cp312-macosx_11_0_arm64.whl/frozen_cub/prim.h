/* C++ code produced by gperf version 3.3 */
/* Command-line: gperf --output-file=prim.h /Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf  */
/* Computed positions: -k'1-2' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 8 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"

#include <stddef.h>
#include <string.h>
typedef enum {
    TYPE_UNKNOWN = 0,
    TYPE_NONE,
    TYPE_BOOL,
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_STR,
    TYPE_BYTES,
    TYPE_LIST,
    TYPE_DICT,
    TYPE_TUPLE,
    TYPE_SET
} PythonType;
#define MAX_TYPENAME_LENGTH 11
#line 26 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
struct type_info {
    const char *type_name;
    PythonType type_id;
};
/* maximum key range = 17, duplicates = 0 */

class Perfect_Hash
{
private:
  static inline unsigned int hash (const char *str, size_t len);
public:
  static const struct type_info *lookup_type (const char *str, size_t len);
};

inline unsigned int
Perfect_Hash::hash (const char *str, size_t len)
{
  static const unsigned char asso_values[] =
    {
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 10, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20,  5, 20,
      10, 10,  5, 20, 20,  5, 20, 20,  5, 20,
       0,  0, 20, 20, 20,  0,  0,  0, 20, 20,
      20,  0, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
      20, 20, 20, 20, 20, 20
    };
  return len + asso_values[static_cast<unsigned char>(str[1])] + asso_values[static_cast<unsigned char>(str[0])];
}

const struct type_info *
Perfect_Hash::lookup_type (const char *str, size_t len)
{
  enum
    {
      TOTAL_KEYWORDS = 10,
      MIN_WORD_LENGTH = 3,
      MAX_WORD_LENGTH = 8,
      MIN_HASH_VALUE = 3,
      MAX_HASH_VALUE = 19
    };

#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif
  static const struct type_info wordlist[] =
    {
      {""}, {""}, {""},
#line 35 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"str",      TYPE_STR},
      {""},
#line 39 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"tuple",    TYPE_TUPLE},
      {""}, {""},
#line 33 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"int",      TYPE_INT},
#line 32 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"bool",     TYPE_BOOL},
#line 36 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"bytes",    TYPE_BYTES},
      {""}, {""},
#line 40 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"set",      TYPE_SET},
#line 37 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"list",     TYPE_LIST},
#line 34 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"float",    TYPE_FLOAT},
      {""}, {""},
#line 31 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"NoneType", TYPE_NONE},
#line 38 "/Users/chaz/Documents/repos/github/sicksubroutine/frozen-cub/src/frozen_cub/prim.gperf"
      {"dict",     TYPE_DICT}
    };
#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic pop
#endif

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      unsigned int key = hash (str, len);

      if (key <= MAX_HASH_VALUE)
        {
          const char *s = wordlist[key].type_name;

          if (*str == *s && !strncmp (str + 1, s + 1, len - 1) && s[len] == '\0')
            return &wordlist[key];
        }
    }
  return static_cast<struct type_info *> (0);
}
