#ifndef FUNC_STUFFS_H
#define FUNC_STUFFS_H

#include <Python.h>
#include <stdlib.h>

const long TRUE = 1;
const long FALSE = 0;

typedef struct {
    int (*wrapped_func)(PyObject*);
} complement_context;

static inline int complement_call(complement_context* ctx, PyObject* obj) {
    return !(ctx->wrapped_func(obj));
}

static inline complement_context* make_complement(int (*func)(PyObject*)) {
    complement_context* ctx = malloc(sizeof(complement_context));
    ctx->wrapped_func = func;
    return ctx;
}

static inline void free_complement(complement_context* ctx) {
    free(ctx);
}

static inline int inline_is_int(PyObject* obj) {
    return PyLong_Check(obj) == TRUE;
}

static inline int inline_is_str(PyObject* obj) {
    return PyUnicode_Check(obj) == TRUE;
}

static inline int inline_is_list(PyObject* obj) {
    return PyList_Check(obj) == TRUE;
}

static inline int inline_is_dict(PyObject* obj) {
    return PyDict_Check(obj) == TRUE;
}

static inline int inline_is_mapping(PyObject* obj) {
    return PyMapping_Check(obj) == TRUE;
}

static inline int inline_is_bool(PyObject* obj) {
    return PyBool_Check(obj);
}


#endif // FUNC_STUFFS_H