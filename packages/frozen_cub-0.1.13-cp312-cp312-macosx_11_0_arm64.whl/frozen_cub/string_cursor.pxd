from cpython.unicode cimport PyUnicode_GET_LENGTH, PyUnicode_AsUCS4Copy
from cpython.mem cimport PyMem_Free
from libc.stdint cimport uint32_t
from .common cimport PY_ZERO, PY_ONE, FUNC_FAILURE as PY_NEG_ONE

ctypedef uint32_t Py_UCS4

cdef struct CursorState:
    Py_UCS4* chars
    Py_ssize_t index
    Py_ssize_t length
    bint allow_neg


cdef inline CursorState* init_state(CursorState* state, str text, bint allow_neg):
    state.index = PY_ZERO
    state.allow_neg = allow_neg
    state.length = PyUnicode_GET_LENGTH(text)
    state.chars = PyUnicode_AsUCS4Copy(text)
    if state.chars == NULL:
        return NULL # type: ignore
    return state


cdef inline void free_state(CursorState* state):
    if state.chars != NULL:
        PyMem_Free(<void*>state.chars)
        state.chars = NULL


cdef inline Py_UCS4 peek_char(CursorState* state, Py_ssize_t offset):
    """Peek at character at offset from current index. Returns 0 if out of bounds."""
    cdef Py_ssize_t target = state.index + offset
    if 0 <= target < state.length:
        return state.chars[target] # type: ignore
    return <Py_UCS4>0


cdef inline str peek_str(CursorState* state, Py_ssize_t offset):
    """Peek at character at offset, return as string. Empty string if out of bounds."""
    cdef Py_UCS4 c = peek_char(state, offset)
    if c == <Py_UCS4>0:
        return ""
    return chr(c)


cdef inline Py_UCS4 current_char(CursorState* state):
    """Get current character as Py_UCS4. Returns 0 if out of bounds."""
    if 0 <= state.index < state.length:
        return state.chars[state.index] # type: ignore
    return <Py_UCS4>0


cdef inline str current_str(CursorState* state):
    """Get current character as string. Empty string if out of bounds."""
    cdef Py_UCS4 c = current_char(state)
    if c == <Py_UCS4>0:
        return ""
    return chr(c)


cdef inline bint char_equals(CursorState* state, Py_ssize_t offset, Py_UCS4 c):
    """Check if character at offset equals c."""
    return <bint>(peek_char(state, offset) == c)


cdef inline bint is_char(CursorState* state, Py_UCS4 c):
    """Check if current character equals c."""
    return <bint>(current_char(state) == c)


cdef inline bint within_bounds(CursorState* state):
    """Check if cursor is within bounds."""
    if state.allow_neg:
        return <bint>(state.index < state.length)
    return <bint>(0 <= state.index < state.length)


cdef inline void move_cursor(CursorState* state, Py_ssize_t offset):
    """Move cursor by offset, clamping to bounds."""
    cdef Py_ssize_t new_index = state.index + offset
    if not state.allow_neg and new_index < PY_ZERO:
        state.index = PY_ZERO
    elif new_index > state.length:
        state.index = state.length
    else:
        state.index = new_index


cdef inline void tick(CursorState* state):
    """Move cursor forward by one."""
    move_cursor(state, PY_ONE)


cdef inline void tock(CursorState* state):
    """Move cursor backward by one."""
    if not state.allow_neg and state.index == PY_ZERO:
        return # type: ignore   
    move_cursor(state, PY_NEG_ONE)


cdef inline void set_index(CursorState* state, Py_ssize_t new_index):
    """Set cursor index, clamping to bounds."""
    if not state.allow_neg and new_index < PY_ZERO:
        state.index = PY_ZERO
    elif new_index > state.length:
        state.index = state.length
    else:
        state.index = new_index


cdef inline void go_head(CursorState* state):
    """Set cursor to beginning."""
    state.index = PY_ZERO


cdef inline void go_tail(CursorState* state):
    """Set cursor to last character."""
    state.index = state.length - PY_ONE if state.length > PY_ZERO else PY_ZERO


cdef inline Py_UCS4 head_char(CursorState* state):
    """Get first character."""
    if state.length > PY_ZERO:
        return state.chars[PY_ZERO] # type: ignore
    return <Py_UCS4>0


cdef inline Py_UCS4 tail_char(CursorState* state):
    """Get last character."""
    if state.length > PY_ZERO:
        return state.chars[state.length - PY_ONE] # type: ignore
    return <Py_UCS4>0


cdef inline bint head_equals(CursorState* state, Py_UCS4 c):
    """Check if first character equals c."""
    return <bint>(head_char(state) == c)


cdef inline bint tail_equals(CursorState* state, Py_UCS4 c):
    """Check if last character equals c."""
    return <bint>(tail_char(state) == c)


cdef class StringCursor:
    cdef str _text
    cdef CursorState state

    cdef Py_UCS4 _peek_char(self, Py_ssize_t offset)
    cdef str _peek_str(self, Py_ssize_t offset)
    cdef Py_UCS4 _current_char(self)
    cdef str _current_str(self)
    cdef bint _char_equals(self, Py_ssize_t offset, Py_UCS4 c)
    cdef bint _is_char_code(self, Py_UCS4 c)
    cdef bint _within_bounds(self)
    cdef void _move(self, Py_ssize_t offset)
    cdef void _tick(self)
    cdef void _tock(self)
    cdef void _set_index(self, Py_ssize_t new_index)
    cdef void _go_head(self)
    cdef void _go_tail(self)
    cdef Py_UCS4 _head_char(self)
    cdef Py_UCS4 _tail_char(self)
    cdef bint _head_equals(self, Py_UCS4 c)
    cdef bint _tail_equals(self, Py_UCS4 c)
    cdef bint _matches_ahead(self, str s)
