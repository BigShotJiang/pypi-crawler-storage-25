from _typeshed import Incomplete
from typing import Any, Callable, Generator, TypeVar

T = TypeVar('T')

class _GenCacheEntry:
    lock: Incomplete
    items: list[Any]
    gen: Generator[Any, None, None] | None
    done: bool
    exc: BaseException | None
    def __init__(self, gen: Generator[Any, None, None]) -> None: ...

def cache_generator(fn: Callable[..., Generator[T, None, None]]) -> Callable[..., Generator[T, None, None]]: ...
