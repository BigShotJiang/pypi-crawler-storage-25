"""
Xunlei API 模块包

包含云盘和远程下载 API 的实现
"""

from ..utils.callbacks import (
    FileFilterFunc,
    RenameFunc,
    add_prefix,
    add_resolution,
    add_suffix,
    extension_filter,
    name_contains_filter,
    name_excludes_filter,
    regex_replace,
    remove_text,
    replace_text,
    size_range_filter,
)
from .cloud_disk import XunleiCloudDisk
from .downloader import (
    ConsoleProgressTracker,
    Downloader,
    DownloadProgress,
    DownloadResult,
    ShareDownloadOptions,
    ShareTransferResult,
)
from .remote_downloader import XunleiRemoteDownloader
from .strategies import (
    CacheStrategy,
    CapacityExceededStrategy,
    CloudFileExistsStrategy,
    ConcurrencyAdjustmentStrategy,
    ExportFormat,
    FailureStrategy,
    FileTypeFilter,
    RemoteDownloadConflictStrategy,
    ShareAfterTransferStrategy,
    ShareLinkStrategy,
    TaskOrderStrategy,
    TransferOwnShareStrategy,
)
from .upload import (
    TaskScheduler,
    UploadAdvancedOptions,
    UploadCheckpoint,
    UploadDirResult,
    Uploader,
    UploadOptions,
    UploadProgress,
    UploadResult,
)

__all__ = [
    "CacheStrategy",
    "CapacityExceededStrategy",
    "ConcurrencyAdjustmentStrategy",
    "CloudFileExistsStrategy",
    "ConsoleProgressTracker",
    "Downloader",
    "DownloadProgress",
    "DownloadResult",
    "ExportFormat",
    "FailureStrategy",
    "FileFilterFunc",
    "FileTypeFilter",
    "RemoteDownloadConflictStrategy",
    "RenameFunc",
    "ShareAfterTransferStrategy",
    "ShareDownloadOptions",
    "ShareLinkStrategy",
    "ShareTransferResult",
    "TaskOrderStrategy",
    "TaskScheduler",
    "TransferOwnShareStrategy",
    "UploadAdvancedOptions",
    "UploadCheckpoint",
    "UploadDirResult",
    "UploadOptions",
    "UploadProgress",
    "UploadResult",
    "Uploader",
    "XunleiCloudDisk",
    "XunleiRemoteDownloader",
    "add_prefix",
    "add_resolution",
    "add_suffix",
    "extension_filter",
    "name_contains_filter",
    "name_excludes_filter",
    "regex_replace",
    "remove_text",
    "replace_text",
    "size_range_filter",
]
