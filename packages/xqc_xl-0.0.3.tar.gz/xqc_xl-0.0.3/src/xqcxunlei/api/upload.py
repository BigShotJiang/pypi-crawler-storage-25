"""
Xunlei 云盘上传模块

提供云盘文件上传功能:
- 单文件和批量上传
- 目录递归上传
- 冲突处理策略
- 容量检查
- 上传进度追踪
- 断点续传
- 上传完成后自动创建分享链接
"""

from __future__ import annotations

import asyncio
import os
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import aiofiles

from ..client import XunleiBase
from ..utils import format_bytes, get_logger
from .strategies import (
    CapacityExceededStrategy,
    CloudFileExistsStrategy,
    ConcurrencyAdjustmentStrategy,
    FailureStrategy,
    ShareAfterTransferStrategy,
    ShareLinkStrategy,
    TaskOrderStrategy,
)

logger = get_logger(__name__)


@dataclass
class UploadTask:
    """上传任务"""

    local_path: str
    file_name: str
    file_size: int
    target_parent_id: str = ""
    target_parent_path: str = ""
    relative_path: str = ""
    status: str = "pending"
    uploaded_bytes: int = 0
    error: str = ""
    file_id: str = ""
    share_link: str = ""
    pass_code: str = ""


@dataclass
class UploadProgress:
    """上传进度"""

    total_files: int
    completed_files: int = 0
    failed_files: int = 0
    total_bytes: int = 0
    uploaded_bytes: int = 0
    current_file: str = ""
    current_speed: str = "0 B/s"

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式"""
        return {
            "total_files": self.total_files,
            "completed_files": self.completed_files,
            "failed_files": self.failed_files,
            "total_bytes": self.total_bytes,
            "uploaded_bytes": self.uploaded_bytes,
            "total_bytes_formatted": format_bytes(self.total_bytes),
            "uploaded_bytes_formatted": format_bytes(self.uploaded_bytes),
            "current_file": self.current_file,
            "current_speed": self.current_speed,
            "progress_percent": (
                round(self.uploaded_bytes / self.total_bytes * 100, 2)
                if self.total_bytes > 0
                else 0
            ),
        }


class UploadProgressBar:
    """上传进度条管理器"""

    def __init__(self, total_files: int = 1, width: int = 50):
        self.total_files = total_files
        self.width = width
        self._last_line_len = 0

    def print_progress(self, progress: UploadProgress) -> None:
        bar_str = format_progress_bar(progress, self.width)
        clear_str = "\r" + " " * max(0, self._last_line_len) + "\r"
        sys.stdout.write(clear_str + bar_str)
        sys.stdout.flush()
        self._last_line_len = len(bar_str.replace("\r", ""))

    def finish(self) -> None:
        sys.stdout.write("\n")
        sys.stdout.flush()


def format_progress_bar(progress: UploadProgress, width: int = 50) -> str:
    """
    格式化进度条为文本

    Args:
        progress: 上传进度对象
        width: 进度条宽度（字符数）

    Returns:
        格式化的进度条字符串
    """
    if progress.total_bytes == 0:
        percent = 0
    else:
        percent = progress.uploaded_bytes / progress.total_bytes * 100

    filled = (
        int(width * progress.uploaded_bytes / progress.total_bytes)
        if progress.total_bytes > 0
        else 0
    )
    bar = "█" * filled + "░" * (width - filled)

    uploaded_str = format_bytes(progress.uploaded_bytes)
    total_str = format_bytes(progress.total_bytes)

    return (
        f"[{bar}] {percent:5.1f}% | {uploaded_str}/{total_str} | "
        f"{progress.current_speed} | {progress.current_file}"
    )


@dataclass
class UploadResult:
    """上传结果"""

    success: bool
    local_path: str
    file_name: str
    file_size: int
    file_id: str
    target_path: str
    message: str
    share_link: str = ""
    pass_code: str = ""
    error: Optional[str] = None

    def __str__(self) -> str:
        status = "成功" if self.success else "失败"
        size_str = format_bytes(self.file_size)
        path = self.target_path.replace("\\", "/") if self.target_path else ""

        lines = [
            f"文件: {self.file_name}",
            f"状态: {status}",
            f"大小: {size_str}",
            f"路径: {path}",
            f"消息: {self.message}",
        ]
        if self.share_link:
            lines.append(f"分享链接: {self.share_link}")
        if self.error:
            lines.append(f"错误: {self.error}")

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式，路径使用正斜杠"""
        return {
            "success": self.success,
            "local_path": self.local_path.replace("\\", "/") if self.local_path else "",
            "file_name": self.file_name,
            "file_size": self.file_size,
            "file_id": self.file_id,
            "target_path": self.target_path.replace("\\", "/") if self.target_path else "",
            "message": self.message,
            "share_link": self.share_link,
            "pass_code": self.pass_code,
            "error": self.error,
        }


@dataclass
class UploadOptions:
    """上传选项"""

    target_parent_id: str = ""
    target_parent_path: str = ""
    auto_create_parents: bool = True
    conflict_strategy: CloudFileExistsStrategy = CloudFileExistsStrategy.RENAME
    capacity_exceeded_strategy: CapacityExceededStrategy = CapacityExceededStrategy.ABORT
    on_conflict: CloudFileExistsStrategy = CloudFileExistsStrategy.RENAME
    share_after_upload: ShareAfterTransferStrategy = ShareAfterTransferStrategy.NO_CREATE
    share_sync_timeout: float = 30.0
    share_strategy: ShareLinkStrategy = ShareLinkStrategy.SKIP
    overwrite_existing: bool = False
    enable_resume: bool = True
    num_threads: int = 4
    show_progress: bool = True


@dataclass
class UploadAdvancedOptions:
    """高级上传选项（用于并发和重试控制）"""

    max_concurrent: int = 2
    min_concurrent: int = 1
    max_concurrent_limit: int = 5
    chunk_concurrent: int = 4
    failure_strategy: FailureStrategy = FailureStrategy.DEFERRED_RETRY
    max_retries: int = 3
    retry_delay: float = 1.0
    retry_multiplier: float = 2.0
    max_retry_delay: float = 30.0
    concurrency_adjustment: ConcurrencyAdjustmentStrategy = ConcurrencyAdjustmentStrategy.ADAPTIVE
    success_threshold_for_increase: int = 3
    task_order: TaskOrderStrategy = TaskOrderStrategy.NATURAL
    enable_resume: bool = True
    stop_on_first_error: bool = False
    task_timeout: float = 300.0
    enable_progress_bar: bool = True
    auto_downgrade_on_limit: bool = True
    downgrade_retry_delay: float = 5.0


@dataclass
class UploadCheckpoint:
    """上传检查点（用于断点续传）"""

    task_id: str = ""
    file_path: str = ""
    file_name: str = ""
    file_size: int = 0
    uploaded_bytes: int = 0
    etag: str = ""
    upload_id: str = ""
    part_number: int = 0
    target_parent_id: str = ""
    target_parent_path: str = ""
    created_at: float = 0.0


@dataclass
class UploadDirResult:
    """目录上传结果"""

    success: bool
    total_files: int
    transferred_files: list[dict[str, Any]] = field(default_factory=list)
    skipped_files: list[dict[str, Any]] = field(default_factory=list)
    failed_files: list[dict[str, Any]] = field(default_factory=list)
    total_size: int = 0
    transferred_size: int = 0
    target_dir: str = ""
    share_id: str = ""
    share_link: str = ""
    pass_code: str = ""
    message: str = ""
    space_checked: bool = False
    available_space: int = 0
    required_space: int = 0
    space_exceeded: bool = False
    aborted_reason: str = ""

    def __str__(self) -> str:
        return self.message

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式，便于日志和调试"""
        return {
            "success": self.success,
            "target_dir": self.target_dir or "根目录",
            "total_files": self.total_files,
            "transferred_files": self.transferred_files,
            "skipped_files": self.skipped_files,
            "failed_files": self.failed_files,
            "total_size": self.total_size,
            "transferred_size": self.transferred_size,
            "transferred_size_formatted": format_bytes(self.transferred_size),
            "share_id": self.share_id,
            "share_link": self.share_link,
            "pass_code": self.pass_code,
            "message": self.message,
            "space_checked": self.space_checked,
            "available_space": self.available_space,
            "available_space_formatted": format_bytes(self.available_space),
            "required_space": self.required_space,
            "required_space_formatted": format_bytes(self.required_space),
            "space_exceeded": self.space_exceeded,
            "aborted_reason": self.aborted_reason,
        }


class TaskScheduler:
    """
    上传任务调度器

    负责管理上传任务队列、控制并发数量、处理失败重试和动态调整并发策略。
    支持自动检测云盘 API 限制并自动降级并发数。
    """

    TASK_LIMIT_ERROR_CODES = {"task_run_nums_limit", "too_many_requests", "rate_limit"}
    DAILY_UPLOAD_LIMIT_ERROR = "daily_upload_size_exceeded"

    def __init__(
        self,
        advanced_options: UploadAdvancedOptions,
        progress_callback: Callable[[UploadProgress], None] | None = None,
    ) -> None:
        """
        初始化任务调度器

        Args:
            advanced_options: 高级上传选项
            progress_callback: 进度回调函数
        """
        self._options = advanced_options
        self._progress_callback = progress_callback
        self._pending_tasks: list[UploadTask] = []
        self._running_tasks: dict[str, asyncio.Task] = {}
        self._completed_tasks: list[UploadResult] = []
        self._failed_tasks: list[tuple[UploadTask, int]] = []
        self._current_concurrent = advanced_options.max_concurrent
        self._consecutive_successes = 0
        self._consecutive_failures = 0
        self._lock = asyncio.Lock()
        self._all_stopped = False
        self._downgraded = False

    def add_task(self, task: UploadTask) -> None:
        """添加任务到队列"""
        self._pending_tasks.append(task)

    def add_tasks(self, tasks: list[UploadTask]) -> None:
        """批量添加任务到队列"""
        self._pending_tasks.extend(tasks)

    def sort_tasks(self) -> None:
        """根据排序策略对任务进行排序"""
        if self._options.task_order == TaskOrderStrategy.SMALL_FIRST:
            self._pending_tasks.sort(key=lambda t: t.file_size)
        elif self._options.task_order == TaskOrderStrategy.LARGE_FIRST:
            self._pending_tasks.sort(key=lambda t: t.file_size, reverse=True)
        elif self._options.task_order == TaskOrderStrategy.RANDOM:
            import random

            random.shuffle(self._pending_tasks)

    async def _adjust_concurrency(self, success: bool) -> None:
        """根据成功/失败状态调整并发数"""
        strategy = self._options.concurrency_adjustment

        if strategy == ConcurrencyAdjustmentStrategy.MAINTAIN:
            return

        async with self._lock:
            if success:
                self._consecutive_successes += 1
                self._consecutive_failures = 0
                if (
                    self._consecutive_successes >= self._options.success_threshold_for_increase
                    and self._current_concurrent < self._options.max_concurrent_limit
                ):
                    self._current_concurrent = min(
                        self._current_concurrent + 1, self._options.max_concurrent_limit
                    )
                    self._consecutive_successes = 0
            else:
                self._consecutive_failures += 1
                self._consecutive_successes = 0
                if strategy == ConcurrencyAdjustmentStrategy.REDUCE_ON_FAILURE:
                    if self._current_concurrent > self._options.min_concurrent:
                        self._current_concurrent = max(
                            self._current_concurrent - 1, self._options.min_concurrent
                        )
                elif strategy == ConcurrencyAdjustmentStrategy.ADAPTIVE:
                    if self._current_concurrent > self._options.min_concurrent:
                        self._current_concurrent = max(
                            self._current_concurrent // 2, self._options.min_concurrent
                        )

    def _get_retry_delay(self, retry_count: int) -> float:
        """计算重试等待时间（指数退避）"""
        delay = self._options.retry_delay * (self._options.retry_multiplier**retry_count)
        return min(delay, self._options.max_retry_delay)

    def _is_task_limit_error(self, error: str | None) -> bool:
        """检查是否是任务数限制错误"""
        if not error:
            return False
        error_lower = error.lower()
        for code in self.TASK_LIMIT_ERROR_CODES:
            if code in error_lower:
                return True
        return False

    def _is_daily_upload_limit_error(self, error: str | None) -> bool:
        """检查是否是每日上传额度超限错误"""
        if not error:
            return False
        return self.DAILY_UPLOAD_LIMIT_ERROR in error.lower()

    async def _downgrade_concurrency(self) -> bool:
        """
        尝试降低并发数

        Returns:
            True 表示降级成功，可以继续重试；False 表示已降到最低并发数
        """
        if not self._options.auto_downgrade_on_limit:
            print("[自动降级] 功能未启用")
            return False

        async with self._lock:
            if self._current_concurrent <= self._options.min_concurrent:
                print(f"[自动降级] 已达到最低并发数 ({self._current_concurrent})，跳过降级")
                print("[提示] 您的账号可能已达到云盘同时上传任务数限制")
                print("[提示] 通常需要等待24小时后再试")
                return False

            old_concurrent = self._current_concurrent
            self._current_concurrent = max(
                self._current_concurrent - 1, self._options.min_concurrent
            )
            self._downgraded = True

            print(f"[自动降级] 并发数: {old_concurrent} -> {self._current_concurrent}")
            print("[提示] 您的账号可能已达到云盘同时上传任务数限制")
            print("[提示] 通常需要等待24小时后再试")

            if self._options.downgrade_retry_delay > 0:
                await asyncio.sleep(self._options.downgrade_retry_delay)

            return True

    async def _execute_single_task(  # noqa: C901
        self,
        task: UploadTask,
        uploader: Uploader,
        upload_options: UploadOptions,
    ) -> UploadResult:
        """执行单个上传任务"""
        target_parent_id = task.target_parent_id
        target_parent_path = task.target_parent_path

        async def ensure_folder_exists(path: str, parent_id: str = "") -> tuple[str, str]:
            """确保文件夹存在，返回 (folder_id, folder_path)"""
            folder_result = await uploader._cloud.create_folder(path, "", True, False)
            if folder_result and folder_result.get("folder_id"):
                return folder_result.get("folder_id"), path
            if folder_result and folder_result.get("success") == "existed":
                return folder_result.get("folder_id", ""), path
            info = await uploader._cloud.get_file_info(path)
            if info and info.get("kind") == "drive#folder":
                return info.get("id", ""), path
            return parent_id, path

        if task.relative_path:
            rel_parts = task.relative_path.replace("\\", "/").split("/")
            if len(rel_parts) > 1:
                parent_id = target_parent_id
                parent_path = target_parent_path
                for part in rel_parts[:-1]:
                    if part:
                        sub_path = f"{parent_path}/{part}" if parent_path != "/" else f"/{part}"
                        parent_id, parent_path = await ensure_folder_exists(sub_path, parent_id)
                if parent_id or parent_path != "/":
                    target_parent_id = parent_id
                    target_parent_path = parent_path

        if target_parent_id or target_parent_path:
            file_options = UploadOptions(
                target_parent_id=target_parent_id or upload_options.target_parent_id,
                target_parent_path=target_parent_path or upload_options.target_parent_path,
                auto_create_parents=True,
                conflict_strategy=upload_options.on_conflict,
                capacity_exceeded_strategy=CapacityExceededStrategy.ABORT,
                on_conflict=upload_options.on_conflict,
                share_after_upload=upload_options.share_after_upload,
                share_strategy=upload_options.share_strategy,
                overwrite_existing=upload_options.overwrite_existing,
                enable_resume=upload_options.enable_resume,
                num_threads=upload_options.num_threads,
                show_progress=upload_options.show_progress,
            )
        else:
            file_options = upload_options

        def is_parent_not_exists_error(error: str | None) -> bool:
            """检查是否是父目录不存在的错误"""
            if not error:
                return False
            error_lower = error.lower()
            return "parent_not_exists" in error_lower or "parent folder" in error_lower

        for retry_count in range(self._options.max_retries + 1):
            try:
                result = await asyncio.wait_for(
                    uploader.upload_file(task.local_path, file_options),
                    timeout=self._options.task_timeout,
                )
                if result.success:
                    await self._adjust_concurrency(True)
                    return result
                if is_parent_not_exists_error(result.error):
                    await ensure_folder_exists(file_options.target_parent_path)
                    if retry_count < self._options.max_retries:
                        await asyncio.sleep(self._get_retry_delay(retry_count))
                        continue
                if self._options.auto_downgrade_on_limit and self._is_task_limit_error(
                    result.error
                ):
                    if await self._downgrade_concurrency():
                        continue
                if retry_count < self._options.max_retries:
                    await asyncio.sleep(self._get_retry_delay(retry_count))
            except asyncio.TimeoutError:
                task.error = f"任务超时（{self._options.task_timeout}秒）"
            except Exception as e:
                task.error = str(e)
                if self._options.auto_downgrade_on_limit and self._is_task_limit_error(str(e)):
                    if await self._downgrade_concurrency():
                        continue
                if retry_count < self._options.max_retries:
                    await asyncio.sleep(self._get_retry_delay(retry_count))

        await self._adjust_concurrency(False)
        return UploadResult(
            success=False,
            local_path=task.local_path,
            file_name=task.file_name,
            file_size=task.file_size,
            file_id="",
            target_path="",
            message="上传失败",
            error=task.error,
        )

    async def run(  # noqa: C901
        self,
        uploader: Uploader,
        upload_options: UploadOptions,
        total_files: int,
        total_bytes: int,
    ) -> tuple[list[UploadResult], list[tuple[UploadTask, int]]]:
        """
        运行任务调度器

        Args:
            uploader: 上传器实例
            upload_options: 上传选项
            total_files: 总文件数
            total_bytes: 总字节数

        Returns:
            (成功结果列表, 失败任务列表)
        """
        semaphore = asyncio.Semaphore(self._current_concurrent)
        uploaded_bytes = 0
        completed_count = 0
        failed_count = 0

        async def run_with_semaphore(task: UploadTask) -> UploadResult:
            nonlocal uploaded_bytes, completed_count, failed_count
            async with semaphore:
                if self._all_stopped:
                    return UploadResult(
                        success=False,
                        local_path=task.local_path,
                        file_name=task.file_name,
                        file_size=task.file_size,
                        file_id="",
                        target_path="",
                        message="任务已终止",
                        error="用户取消",
                    )

                result = await self._execute_single_task(task, uploader, upload_options)

                async with self._lock:
                    if result.success:
                        self._completed_tasks.append(result)
                        completed_count += 1
                        uploaded_bytes += result.file_size
                    else:
                        self._failed_tasks.append((task, 0))

                    if self._progress_callback:
                        prog = UploadProgress(
                            total_files=total_files,
                            completed_files=completed_count,
                            failed_files=failed_count,
                            total_bytes=total_bytes,
                            uploaded_bytes=uploaded_bytes,
                            current_file=task.file_name,
                        )
                        self._progress_callback(prog)

                return result

        while self._pending_tasks or self._running_tasks:
            if self._all_stopped:
                break

            while len(self._running_tasks) < self._current_concurrent and self._pending_tasks:
                task = self._pending_tasks.pop(0)
                coro = run_with_semaphore(task)
                self._running_tasks[task.local_path] = asyncio.create_task(coro)

            if self._running_tasks:
                done, pending = await asyncio.wait(
                    self._running_tasks.values(), return_when=asyncio.FIRST_COMPLETED
                )
                for d in done:
                    task_path = None
                    for path, t in list(self._running_tasks.items()):
                        if t == d:
                            task_path = path
                            break
                    if task_path:
                        del self._running_tasks[task_path]

                    result = d.result()
                    if not result.success:
                        failed_count += 1
                        if self._is_daily_upload_limit_error(result.error):
                            self._all_stopped = True
                            self._pending_tasks.clear()
                            logger.error(
                                "每日上传额度已超限，停止所有上传任务。请明日再试或升级会员。"
                            )
                        await self._handle_failure(result)

                    if self._options.stop_on_first_error and not result.success:
                        self._all_stopped = True

            if self._options.failure_strategy == FailureStrategy.BLOCKING_RETRY:
                await self._handle_blocking_retry()

        return self._completed_tasks, self._failed_tasks

    async def _handle_failure(self, result: UploadResult) -> None:
        """处理失败任务"""
        strategy = self._options.failure_strategy

        if strategy == FailureStrategy.SKIP:
            pass
        elif strategy == FailureStrategy.DEFERRED_RETRY:
            for task, _ in self._failed_tasks:
                if task.local_path == result.local_path:
                    task.status = "pending"
                    self._pending_tasks.append(task)
                    self._failed_tasks.remove((task, _))
                    break
        elif strategy == FailureStrategy.IMMEDIATE_RETRY:
            for task, _ in self._failed_tasks:
                if task.local_path == result.local_path:
                    self._pending_tasks.insert(0, task)
                    self._failed_tasks.remove((task, _))
                    break
        elif strategy == FailureStrategy.ABORT:
            self._all_stopped = True
            for task, _ in self._failed_tasks:
                self._pending_tasks.clear()
                break

    async def _handle_blocking_retry(self) -> None:
        """处理阻塞式重试"""
        if not self._failed_tasks:
            return

        task, _ = self._failed_tasks.pop(0)
        task.status = "running"

        try:
            await asyncio.sleep(self._get_retry_delay(0))
        except Exception:
            pass

        self._pending_tasks.insert(0, task)

    def stop(self) -> None:
        """停止所有任务"""
        self._all_stopped = True
        for task in self._running_tasks.values():
            task.cancel()

    @property
    def pending_count(self) -> int:
        """待处理任务数量"""
        return len(self._pending_tasks)

    @property
    def running_count(self) -> int:
        """正在运行的任务数量"""
        return len(self._running_tasks)

    @property
    def current_concurrent(self) -> int:
        """当前并发数"""
        return self._current_concurrent

    @property
    def pending_tasks(self) -> list[UploadTask]:
        """待处理任务列表"""
        return self._pending_tasks.copy()

    @property
    def running_tasks(self) -> list[UploadTask]:
        """正在运行的任务列表"""
        return list(self._running_tasks.keys())

    @property
    def completed_tasks(self) -> list[UploadResult]:
        """已完成的任务结果列表"""
        return self._completed_tasks.copy()

    @property
    def failed_tasks(self) -> list[tuple[UploadTask, int]]:
        """失败任务列表（包含重试次数）"""
        return self._failed_tasks.copy()

    def get_task_status(self) -> dict[str, Any]:
        """获取任务状态统计信息"""
        return {
            "pending": len(self._pending_tasks),
            "running": len(self._running_tasks),
            "completed": len(self._completed_tasks),
            "failed": len(self._failed_tasks),
            "total": (
                len(self._pending_tasks)
                + len(self._running_tasks)
                + len(self._completed_tasks)
                + len(self._failed_tasks)
            ),
            "current_concurrent": self._current_concurrent,
            "is_stopped": self._all_stopped,
        }

    def get_task_details(self) -> dict[str, list[dict[str, Any]]]:
        """获取所有任务的详细信息"""
        return {
            "pending": [
                {"path": t.local_path, "name": t.file_name, "size": t.file_size, "status": t.status}
                for t in self._pending_tasks
            ],
            "running": [
                {"path": t.local_path, "name": t.file_name, "size": t.file_size, "status": t.status}
                for t in self._running_tasks.keys()
            ],
            "completed": [
                {
                    "path": r.local_path,
                    "name": r.file_name,
                    "size": r.file_size,
                    "success": r.success,
                }
                for r in self._completed_tasks
            ],
            "failed": [
                {
                    "path": t[0].local_path,
                    "name": t[0].file_name,
                    "size": t[0].file_size,
                    "retries": t[1],
                }
                for t in self._failed_tasks
            ],
        }


class Uploader:
    """
    迅雷云盘上传器

    支持:
    - 单文件和批量上传
    - 目录递归上传
    - 冲突处理策略
    - 容量检查
    - 进度追踪
    - 断点续传
    - 上传完成后自动创建分享链接
    """

    def __init__(
        self,
        cloud_disk: XunleiBase,
        max_concurrent: int = 3,
        chunk_size: int = 1024 * 1024,
        enable_resume: bool = True,
        max_retries: int = 3,
        timeout: int = 60,
        progress_callback: Optional[Callable[[UploadProgress], None]] = None,
    ) -> None:
        """
        初始化上传器

        Args:
            cloud_disk: 云盘客户端实例
            max_concurrent: 最大并发上传数
            chunk_size: 分片大小 (字节)
            enable_resume: 是否启用断点续传
            max_retries: 最大重试次数
            timeout: 上传超时时间（秒）
            progress_callback: 进度回调函数
        """
        self._cloud = cloud_disk
        self._max_concurrent = max_concurrent
        self._chunk_size = chunk_size
        self._enable_resume = enable_resume
        self._max_retries = max_retries
        self._timeout = timeout
        self._progress_callback = progress_callback

    async def _calculate_file_hash(self, file_path: str) -> str:
        """计算文件 SHA1 哈希"""
        import hashlib

        sha1 = hashlib.sha1()
        async with aiofiles.open(file_path, "rb") as f:
            while chunk := await f.read(8192):
                sha1.update(chunk)
        return sha1.hexdigest()

    async def _get_upload_params(
        self,
        file_path: str,
        parent_id: str = "",
    ) -> Optional[dict[str, Any]]:
        """获取上传参数"""
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)
        file_hash = await self._calculate_file_hash(file_path)

        resp = await self._cloud.post(
            self._cloud.config.files_url,
            json={
                "kind": "drive#file",
                "parent_id": parent_id,
                "name": file_name,
                "size": file_size,
                "space": "",
                "hash": file_hash,
                "upload_type": "UPLOAD_TYPE_RESUMABLE"
                if file_size > 1048576
                else "UPLOAD_TYPE_FORM",
            },
        )
        return resp

    async def _upload_form(
        self,
        file_path: str,
        upload_url: str,
        multi_parts: dict[str, str],
    ) -> bool:
        """小文件表单上传"""
        import aiofiles

        file_name = os.path.basename(file_path)

        async with aiofiles.open(file_path, "rb") as f:
            data = await f.read()

        files_data = {k: (None, v) for k, v in multi_parts.items()}
        files_data["file"] = (file_name, data, "application/octet-stream")

        resp = await self._cloud.client.post(upload_url, files=files_data)
        return resp is not None and resp.is_success

    async def _upload_resumable(
        self,
        file_path: str,
        file_size: int,
        params: dict[str, Any],
        progress_callback: Optional[Callable] = None,
        num_threads: int = 4,
        enable_resume: bool = True,
    ) -> bool:
        """
        大文件分片上传 (使用阿里云 OSS)

        Args:
            file_path: 本地文件路径
            file_size: 文件大小
            params: API 返回的上传参数
            progress_callback: 进度回调函数，接收 (已上传字节数, 总字节数)
            num_threads: 并发上传线程数
            enable_resume: 是否启用断点续传

        Returns:
            是否成功
        """
        import io

        import aiofiles
        import oss2

        resumable = params.get("resumable", {})
        oss_params = resumable.get("params", {})

        access_key_id = oss_params.get("access_key_id", "")
        access_key_secret = oss_params.get("access_key_secret", "")
        security_token = oss_params.get("security_token", "")
        bucket_name = oss_params.get("bucket", "")
        endpoint = oss_params.get("endpoint", "")
        object_key = oss_params.get("key", "")

        if not all([access_key_id, access_key_secret, bucket_name, endpoint, object_key]):
            logger.error("OSS 参数不完整")
            return False

        auth = oss2.StsAuth(access_key_id, access_key_secret, security_token)
        bucket = oss2.Bucket(auth, endpoint, bucket_name)

        if enable_resume:
            return await self._upload_with_resume(
                bucket, file_path, object_key, progress_callback, num_threads
            )

        part_size = oss2.determine_part_size(file_size, preferred_size=1048576)
        total_parts = (file_size + part_size - 1) // part_size

        upload_id = bucket.init_multipart_upload(object_key).upload_id

        try:
            uploaded_parts = []

            async with aiofiles.open(file_path, "rb") as f:
                for part_num in range(1, total_parts + 1):
                    size_to_upload = min(part_size, file_size - (part_num - 1) * part_size)
                    chunk_data = await f.read(size_to_upload)

                    part_file = oss2.SizedFileAdapter(io.BytesIO(chunk_data), size_to_upload)
                    result = bucket.upload_part(object_key, upload_id, part_num, part_file)

                    uploaded_parts.append(
                        oss2.models.PartInfo(part_num, result.etag, size=size_to_upload)
                    )

                    uploaded_bytes = min(part_num * part_size, file_size)
                    if progress_callback:
                        progress_callback(uploaded_bytes, file_size)

                    logger.debug(f"已上传分片 {part_num}/{total_parts}")

            bucket.complete_multipart_upload(object_key, upload_id, uploaded_parts)
            logger.info(f"分片上传完成: {file_path}")
            return True

        except Exception as e:
            try:
                bucket.abort_multipart_upload(object_key, upload_id)
            except Exception:
                pass
            logger.error(f"分片上传失败: {e}")
            raise

    async def _upload_with_resume(
        self,
        bucket,
        file_path: str,
        object_key: str,
        progress_callback: Optional[Callable] = None,
        num_threads: int = 4,
    ) -> bool:
        """
        使用 oss2.resumable_upload 进行并发上传和断点续传

        Args:
            bucket: OSS Bucket 对象
            file_path: 本地文件路径
            object_key: OSS 对象 key
            progress_callback: 进度回调
            num_threads: 并发线程数

        Returns:
            是否成功
        """
        import oss2

        def _progress_wrapper(bytes_consumed: int, total_bytes: int) -> None:
            if progress_callback:
                progress_callback(bytes_consumed, total_bytes)

        try:
            oss2.resumable_upload(
                bucket,
                object_key,
                file_path,
                store=None,
                part_size=1048576,
                num_threads=num_threads,
                progress_callback=_progress_wrapper,
            )
            logger.info(f"并发分片上传完成 (线程数: {num_threads}): {file_path}")
            return True
        except Exception as e:
            logger.error(f"并发分片上传失败: {e}")
            raise

    async def upload_file(  # noqa: C901
        self,
        local_path: str,
        options: Optional[UploadOptions] = None,
        progress_callback: Optional[Callable[[UploadProgress], None]] = None,
        advanced_options: Optional[UploadAdvancedOptions] = None,
    ) -> UploadResult:
        """
        上传单个文件

        Args:
            local_path: 本地文件路径
            options: 上传选项
            progress_callback: 进度回调函数

        Returns:
            UploadResult: 上传结果
        """
        options = options or UploadOptions()
        file_name = os.path.basename(local_path)
        file_size = os.path.getsize(local_path)

        try:
            if not os.path.isfile(local_path):
                return UploadResult(
                    success=False,
                    local_path=local_path,
                    file_name=file_name,
                    file_size=0,
                    file_id="",
                    target_path="",
                    message="文件不存在",
                    error=f"文件不存在: {local_path}",
                )

            space_info = await self._cloud.get_space_info()
            if space_info:
                free_space = space_info.get("free_space", 0)
                if file_size > free_space:
                    err_msg = (
                        f"云盘空间不足: 需要 {format_bytes(file_size)}, "
                        f"可用 {format_bytes(free_space)}"
                    )
                    return UploadResult(
                        success=False,
                        local_path=local_path,
                        file_name=file_name,
                        file_size=file_size,
                        file_id="",
                        target_path="",
                        message="云盘空间不足",
                        error=err_msg,
                    )

            target_parent_id = options.target_parent_id
            if not target_parent_id and options.target_parent_path:
                target_parent_id = await self._cloud.get_file_info(options.target_parent_path)
                if target_parent_id:
                    target_parent_id = target_parent_id.get("id", "")
                else:
                    target_parent_id = ""

            if options.auto_create_parents and options.target_parent_path:
                folder_result = await self._cloud.create_folder(
                    options.target_parent_path, "", True, False
                )
                if folder_result.get("success") == "existed":
                    target_parent_id = folder_result.get("folder_id", "")
                elif folder_result.get("success"):
                    target_parent_id = folder_result.get("folder_id", "")

            existing = None
            if target_parent_id:
                existing = await self._cloud._find_first(file_name, target_parent_id, True, False)

            if existing:
                if options.on_conflict == CloudFileExistsStrategy.SKIP:
                    return UploadResult(
                        success=False,
                        local_path=local_path,
                        file_name=file_name,
                        file_size=file_size,
                        file_id=existing.get("id", ""),
                        target_path=options.target_parent_path or "/",
                        message="文件已存在，已跳过",
                    )
                elif options.on_conflict == CloudFileExistsStrategy.OVERWRITE:
                    pass
                elif options.on_conflict == CloudFileExistsStrategy.RENAME:
                    base_name, ext = os.path.splitext(file_name)
                    counter = 1
                    while True:
                        new_name = f"{base_name}_{counter}{ext}"
                        check = await self._cloud._find_first(
                            new_name, target_parent_id, True, False
                        )
                        if not check:
                            file_name = new_name
                            break
                        counter += 1

            params = await self._get_upload_params(local_path, target_parent_id)
            if not params:
                return UploadResult(
                    success=False,
                    local_path=local_path,
                    file_name=file_name,
                    file_size=file_size,
                    file_id="",
                    target_path=options.target_parent_path or "/",
                    message="获取上传参数失败",
                    error="获取上传参数失败",
                )

            upload_type = params.get("upload_type", "")

            def _progress_wrapper(uploaded_bytes: int, total_bytes: int) -> None:
                if progress_callback:
                    prog = UploadProgress(
                        total_files=1,
                        completed_files=0,
                        total_bytes=total_bytes,
                        uploaded_bytes=uploaded_bytes,
                        current_file=file_name,
                    )
                    progress_callback(prog)

            success = False
            if upload_type == "UPLOAD_TYPE_FORM":
                form = params.get("form", {})
                upload_url = form.get("url")
                multi_parts = form.get("multi_parts", {})
                success = await self._upload_form(local_path, upload_url, multi_parts)
            elif upload_type == "UPLOAD_TYPE_RESUMABLE":
                success = await self._upload_resumable(
                    local_path,
                    file_size,
                    params,
                    _progress_wrapper,
                    num_threads=options.num_threads,
                    enable_resume=options.enable_resume,
                )
            else:
                return UploadResult(
                    success=False,
                    local_path=local_path,
                    file_name=file_name,
                    file_size=file_size,
                    file_id="",
                    target_path=options.target_parent_path or "/",
                    message=f"未知的上传类型: {upload_type}",
                    error=f"未知的上传类型: {upload_type}",
                )

            if not success:
                return UploadResult(
                    success=False,
                    local_path=local_path,
                    file_name=file_name,
                    file_size=file_size,
                    file_id="",
                    target_path=options.target_parent_path or "/",
                    message="上传失败",
                    error="上传返回失败",
                )

            file_id = params.get("file_id", "") or params.get("file", {}).get("id", "")

            share_link = ""
            pass_code = ""
            effective_timeout = max(1.0, options.share_sync_timeout)
            if (
                options.share_after_upload != ShareAfterTransferStrategy.NO_CREATE
                and file_id
                and effective_timeout > 0
            ):
                share_start_time = asyncio.get_event_loop().time()
                while True:
                    file_info = await self._cloud.get_file_info_by_id(file_id)
                    if file_info and file_info.get("kind") == "drive#file":
                        share_result = await self._cloud.create_share_link(file_id=file_id)
                        if share_result and share_result.get("success"):
                            share_links = share_result.get("share_links", [])
                            share_link = share_links[0] if share_links else ""
                            pass_code = ""
                            break
                    elapsed = asyncio.get_event_loop().time() - share_start_time
                    if elapsed >= effective_timeout:
                        logger.warning(
                            f"创建分享链接超时（{effective_timeout}秒），" f"文件可能还在处理中"
                        )
                        break
                    await asyncio.sleep(0.5)

            target_path = options.target_parent_path or "/"
            if target_parent_id:
                parent_info = await self._cloud.get_file_info_by_id(target_parent_id)
                if parent_info:
                    target_path = parent_info.get("path", options.target_parent_path or "/")

            return UploadResult(
                success=True,
                local_path=local_path,
                file_name=file_name,
                file_size=file_size,
                file_id=file_id,
                target_path=f"{target_path}/{file_name}" if target_path != "/" else f"/{file_name}",
                message="上传成功",
                share_link=share_link,
                pass_code=pass_code,
            )

        except Exception as e:
            logger.error(f"上传文件时发生错误: {str(e)}")
            return UploadResult(
                success=False,
                local_path=local_path,
                file_name=file_name,
                file_size=file_size,
                file_id="",
                target_path=options.target_parent_path or "/",
                message=f"上传失败: {str(e)}",
                error=str(e),
            )

    async def upload_files(  # noqa: C901
        self,
        local_paths: list[str],
        options: Optional[UploadOptions] = None,
        progress_callback: Optional[Callable[[UploadProgress], None]] = None,
        advanced_options: Optional[UploadAdvancedOptions] = None,
    ) -> list[UploadResult]:
        """
        批量上传多个文件（支持并发控制）

        Args:
            local_paths: 本地文件路径列表
            options: 上传选项
            progress_callback: 进度回调函数
            advanced_options: 高级上传选项（并发控制等）

        Returns:
            UploadResult 列表
        """
        options = options or UploadOptions()
        advanced_options = advanced_options or UploadAdvancedOptions()

        def expand_paths(paths: list[str]) -> list[tuple[str, str]]:
            """递归展开路径列表中的目录为文件，返回 (绝对路径, 相对路径) 列表"""
            result: list[tuple[str, str]] = []
            for p in paths:
                if os.path.isfile(p):
                    result.append((p, os.path.basename(p)))
                elif os.path.isdir(p):
                    base_dir = os.path.basename(p) or p
                    for root, _, files in os.walk(p):
                        for f in files:
                            abs_path = os.path.join(root, f)
                            rel_path = os.path.join(base_dir, os.path.relpath(abs_path, p))
                            result.append((abs_path, rel_path))
            return result

        expanded_paths = expand_paths(local_paths)
        total_files = len(expanded_paths)
        total_bytes = sum(os.path.getsize(p[0]) for p in expanded_paths)

        space_info = await self._cloud.get_space_info()
        available_space = space_info.get("free_space", 0) if space_info else 0

        if options.capacity_exceeded_strategy == CapacityExceededStrategy.ABORT:
            if total_bytes > available_space:
                return [
                    UploadResult(
                        success=False,
                        local_path=local_paths[0],
                        file_name=os.path.basename(local_paths[0]),
                        file_size=total_bytes,
                        file_id="",
                        target_path="",
                        message="云盘空间不足，已终止上传",
                        error=(
                            f"任务总大小 {format_bytes(total_bytes)} "
                            f"超出云盘可用空间 {format_bytes(available_space)}"
                        ),
                    )
                ]

        if options.capacity_exceeded_strategy == CapacityExceededStrategy.SMALL_FIRST:
            sorted_paths = sorted(expanded_paths, key=lambda x: os.path.getsize(x[0]))
        elif options.capacity_exceeded_strategy == CapacityExceededStrategy.LARGE_FIRST:
            sorted_paths = sorted(
                expanded_paths,
                key=lambda x: os.path.getsize(x[0]),
                reverse=True,
            )
        else:
            sorted_paths = expanded_paths

        tasks: list[UploadTask] = []
        target_parent_path = options.target_parent_path or "/"
        for abs_path, rel_path in sorted_paths:
            file_size = os.path.getsize(abs_path)
            task = UploadTask(
                local_path=abs_path,
                file_name=os.path.basename(abs_path),
                file_size=file_size,
                target_parent_path=target_parent_path,
                relative_path=rel_path,
            )
            tasks.append(task)

        if advanced_options.task_order == TaskOrderStrategy.SMALL_FIRST:
            tasks.sort(key=lambda t: t.file_size)
        elif advanced_options.task_order == TaskOrderStrategy.LARGE_FIRST:
            tasks.sort(key=lambda t: t.file_size, reverse=True)
        elif advanced_options.task_order == TaskOrderStrategy.RANDOM:
            import random

            random.shuffle(tasks)

        scheduler = TaskScheduler(advanced_options, progress_callback)
        scheduler.add_tasks(tasks)

        completed_results, failed_tasks = await scheduler.run(
            self, options, total_files, total_bytes
        )

        for task, _ in failed_tasks:
            result = UploadResult(
                success=False,
                local_path=task.local_path,
                file_name=task.file_name,
                file_size=task.file_size,
                file_id="",
                target_path="",
                message="上传失败",
                error=task.error or "超过最大重试次数",
            )
            completed_results.append(result)

        return completed_results

    async def upload_directory(  # noqa: C901
        self,
        local_dir: str,
        options: Optional[UploadOptions] = None,
        progress_callback: Optional[Callable[[UploadProgress], None]] = None,
        advanced_options: Optional[UploadAdvancedOptions] = None,
    ) -> UploadDirResult:
        """
        上传整个目录（支持并发控制）

        Args:
            local_dir: 本地目录路径
            options: 上传选项
            progress_callback: 进度回调函数
            advanced_options: 高级上传选项（并发控制等）

        Returns:
            UploadDirResult: 目录上传结果
        """
        if not os.path.isdir(local_dir):
            return UploadDirResult(
                success=False,
                total_files=0,
                message=f"目录不存在: {local_dir}",
            )

        options = options or UploadOptions()
        advanced_options = advanced_options or UploadAdvancedOptions()
        dir_name = os.path.basename(local_dir) or "upload"
        target_parent_path = options.target_parent_path or "/"
        target_dir_path = (
            f"{target_parent_path}/{dir_name}" if target_parent_path != "/" else f"/{dir_name}"
        )

        if options.auto_create_parents:
            folder_result = await self._cloud.create_folder(target_dir_path, "", True, False)
            if not folder_result.get("success") and folder_result.get("success") != "existed":
                return UploadDirResult(
                    success=False,
                    total_files=0,
                    message=f"创建目标目录失败: {target_dir_path}",
                )

        target_parent_id = ""
        if folder_result and folder_result.get("folder_id"):
            target_parent_id = folder_result.get("folder_id", "")

        all_files: list[tuple[str, str]] = []
        for root, _, files in os.walk(local_dir):
            for file in files:
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, local_dir)
                all_files.append((file_path, rel_path))

        total_files = len(all_files)
        total_size = sum(os.path.getsize(f[0]) for f in all_files)

        space_info = await self._cloud.get_space_info()
        available_space = space_info.get("free_space", 0) if space_info else 0

        if options.capacity_exceeded_strategy == CapacityExceededStrategy.ABORT:
            if total_size > available_space:
                return UploadDirResult(
                    success=False,
                    total_files=total_files,
                    total_size=total_size,
                    target_dir=target_dir_path,
                    message="云盘空间不足，已终止上传",
                    space_checked=True,
                    available_space=available_space,
                    required_space=total_size,
                    space_exceeded=True,
                    aborted_reason=(
                        f"任务总大小 {format_bytes(total_size)} "
                        f"超出云盘可用空间 {format_bytes(available_space)}"
                    ),
                )

        if options.capacity_exceeded_strategy == CapacityExceededStrategy.SMALL_FIRST:
            sorted_files = sorted(all_files, key=lambda x: os.path.getsize(x[0]))
        elif options.capacity_exceeded_strategy == CapacityExceededStrategy.LARGE_FIRST:
            sorted_files = sorted(all_files, key=lambda x: os.path.getsize(x[0]), reverse=True)
        else:
            sorted_files = all_files

        tasks: list[UploadTask] = []
        for file_path, rel_path in sorted_files:
            file_size = os.path.getsize(file_path)
            task = UploadTask(
                local_path=file_path,
                file_name=os.path.basename(file_path),
                file_size=file_size,
                target_parent_id=target_parent_id,
                target_parent_path=target_dir_path,
            )
            tasks.append(task)

        if advanced_options.task_order == TaskOrderStrategy.SMALL_FIRST:
            tasks.sort(key=lambda t: t.file_size)
        elif advanced_options.task_order == TaskOrderStrategy.LARGE_FIRST:
            tasks.sort(key=lambda t: t.file_size, reverse=True)
        elif advanced_options.task_order == TaskOrderStrategy.RANDOM:
            import random

            random.shuffle(tasks)

        scheduler = TaskScheduler(advanced_options, progress_callback)
        scheduler.add_tasks(tasks)

        completed_results, failed_tasks = await scheduler.run(
            self, options, total_files, total_size
        )

        transferred_files: list[dict[str, Any]] = []
        skipped_files: list[dict[str, Any]] = []
        failed_files: list[dict[str, Any]] = []
        transferred_size = 0
        completed = 0
        failed = 0

        for result in completed_results:
            if result.success:
                completed += 1
                transferred_files.append(
                    {
                        "file_id": result.file_id,
                        "file_name": result.file_name,
                        "file_size": result.file_size,
                        "local_path": result.local_path,
                        "target_path": result.target_path,
                    }
                )
                transferred_size += result.file_size
            elif "已存在" in result.message or "已跳过" in result.message:
                skipped_files.append(
                    {
                        "file_name": result.file_name,
                        "file_size": result.file_size,
                        "reason": result.message,
                    }
                )
            else:
                failed += 1
                failed_files.append(
                    {
                        "file_name": result.file_name,
                        "file_size": result.file_size,
                        "error": result.error or result.message,
                    }
                )

        for task, _ in failed_tasks:
            failed += 1
            failed_files.append(
                {
                    "file_name": task.file_name,
                    "file_size": task.file_size,
                    "error": task.error or "超过最大重试次数",
                }
            )

        share_id = ""
        share_link = ""
        pass_code = ""
        if options.share_after_upload == ShareAfterTransferStrategy.CREATE:
            if target_parent_id:
                effective_timeout = max(1.0, options.share_sync_timeout)
                if effective_timeout > 0:
                    share_start_time = asyncio.get_event_loop().time()
                    while True:
                        folder_info = await self._cloud.get_file_info_by_id(target_parent_id)
                        if folder_info and folder_info.get("kind") == "drive#folder":
                            share_result = await self._cloud.create_share_link(
                                file_id=target_parent_id,
                            )
                            if share_result and share_result.get("success"):
                                share_links = share_result.get("share_links", [])
                                share_link = share_links[0] if share_links else ""
                                share_id = ""
                                pass_code = ""
                                break
                        elapsed = asyncio.get_event_loop().time() - share_start_time
                        if elapsed >= effective_timeout:
                            logger.warning(
                                f"创建分享链接超时（{effective_timeout}秒），"
                                f"目录可能还在处理中: {target_dir_path}"
                            )
                            break
                        await asyncio.sleep(0.5)

        success = failed == 0 and completed > 0
        message = f"上传完成: 成功 {completed}, 跳过 {len(skipped_files)}, 失败 {failed}"

        return UploadDirResult(
            success=success,
            total_files=total_files,
            transferred_files=transferred_files,
            skipped_files=skipped_files,
            failed_files=failed_files,
            total_size=total_size,
            transferred_size=transferred_size,
            target_dir=target_dir_path,
            share_id=share_id,
            share_link=share_link,
            pass_code=pass_code,
            message=message,
            space_checked=True,
            available_space=available_space,
            required_space=total_size,
            space_exceeded=total_size > available_space,
        )

    async def close(self) -> None:
        """关闭上传器"""
        pass
