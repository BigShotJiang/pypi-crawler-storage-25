"""
Xunlei 云盘 API 模块

提供云盘相关功能:
- 文件管理 (列出、创建、删除、重命名、移动)
- 目录管理
- 文件上传/下载
- 离线任务 (云添加)
- 分享链接
- 回收站管理
- 配置管理
- 增强日志功能
- 统一错误处理
"""

from __future__ import annotations

import asyncio
import hashlib
import os
from collections.abc import AsyncGenerator, Callable
from typing import Any, Optional

import aiofiles

from ..client import XunleiBase
from ..config.constants import SIMPLIFIED_FILE_FIELDS
from ..utils import (
    BadRequestError,
    FileNotFoundError,
    FileOperationError,
    Spinner,
    StructuredLogger,
    XunleiError,
    format_sub_file_index,
    get_logger,
    parse_torrent,
    split_path,
    validate_file_path,
    validate_file_size,
)
from .strategies import (
    CloudFileExistsStrategy,
    SearchType,
    ShareLinkStrategy,
)

logger = get_logger(__name__)
structured_logger = StructuredLogger(__name__)


class XunleiCloudDisk(XunleiBase):
    """
    迅雷云盘 API

    支持:
    - 文件/目录管理
    - 云添加 (离线下载)
    - 文件上传
    - 分享链接


    """

    def __init__(
        self,
        username: str,
        password: str,
        cache_file: str | None = None,
        cache_dir: str | None = None,
        auto_save: bool = True,
    ) -> None:
        """
        初始化云盘客户端

        Args:
            username: 迅雷用户名
            password: 迅雷密码
            cache_file: Token 缓存文件路径
            cache_dir: Token 缓存目录 (如果未指定cache_file)
            auto_save: 是否自动保存 Token
        """
        super().__init__(username, password, cache_file, cache_dir, auto_save)

    # ==================== 基础信息 ====================

    async def get_user_info(self) -> Optional[dict[str, Any]]:
        """获取用户信息"""
        resp = await self.get(self.config.user_info_url)
        if resp:
            # 服务器返回的用户ID字段名为"id"，不是"user_id"
            user_id = resp.get("user_id", "") or resp.get("id", "")
            self.cache.update(
                user_id=user_id,
            )
        return resp

    async def get_space_info(self, human_readable: bool = False) -> Optional[dict[str, Any]]:
        """
        获取云盘空间信息

        Args:
            human_readable: 是否返回人类可读的格式（如 MB、GB），默认 False

        Returns:
            云盘空间信息字典:
            {
                "limit": int,              # 总空间（字节）
                "usage": int,              # 已使用空间（字节）
                "usage_in_trash": int,     # 回收站占用空间（字节）
                "free_space": int,         # 剩余空间（字节）
                # 以下为 human_readable=True 时新增
                "limit_formatted": str,    # 总空间（人类可读）
                "usage_formatted": str,    # 已使用空间（人类可读）
                "usage_in_trash_formatted": str,  # 回收站占用空间（人类可读）
                "free_space_formatted": str,  # 剩余空间（人类可读）
            }
        """
        resp = await self.get(self.config.about_url)
        if not resp:
            return None

        quota = resp.get("quota", {})
        limit = int(quota.get("limit", 0))
        usage = int(quota.get("usage", 0))
        usage_in_trash = int(quota.get("usage_in_trash", 0))
        free_space = limit - usage - usage_in_trash

        result: dict[str, Any] = {
            "limit": limit,
            "usage": usage,
            "usage_in_trash": usage_in_trash,
            "free_space": free_space,
        }

        if human_readable:
            result["limit_formatted"] = self._format_bytes(limit)
            result["usage_formatted"] = self._format_bytes(usage)
            result["usage_in_trash_formatted"] = self._format_bytes(usage_in_trash)
            result["free_space_formatted"] = self._format_bytes(free_space)

        return result

    def _format_bytes(self, bytes_count: int) -> str:
        """
        将字节数转换为人类可读的格式

        Args:
            bytes_count: 字节数

        Returns:
            人类可读的字符串，如 "1.5 GB"
        """
        if bytes_count <= 0:
            return "0 B"

        units = ["B", "KB", "MB", "GB", "TB"]
        unit_index = 0
        size = float(bytes_count)

        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1

        if unit_index == 0:
            return f"{int(size)} {units[unit_index]}"
        return f"{size:.2f} {units[unit_index]}"

    async def get_offline_task_limit(self) -> Optional[dict[str, Any]]:
        """获取云添加次数限制"""
        resp = await self.get(
            self.config.about_url, params={"with_quotas": "CREATE_OFFLINE_TASK_LIMIT"}
        )
        if not resp:
            return None

        info = resp.get("quotas", {}).get("CREATE_OFFLINE_TASK_LIMIT", {})
        return {
            "limit": int(info.get("limit", 0)),
            "usage": int(info.get("usage", 0)),
            "remain": int(info.get("limit", 0)) - int(info.get("usage", 0)),
        }

    # ==================== 文件列表 ====================

    async def _get_files_page(
        self,
        parent_id: str = "",
        page_token: str = "",
        limit: int = 50,
        filters: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """获取文件列表 (单页)"""
        params = {
            "parent_id": parent_id,
            "filters": filters or '{"phase":{"eq":"PHASE_TYPE_COMPLETE"},"trashed":{"eq":false}}',
            "with_audit": "true",
            "thumbnail_size": "SIZE_SMALL",
            "limit": str(limit),
        }
        if page_token:
            params["page_token"] = page_token

        return await self.get(self.config.files_url, params=params)

    async def get_files(
        self,
        parent_id: str = "",
        limit: int = 50,
        return_raw: bool = False,
        filters: Optional[str] = None,
    ) -> Optional[list[dict[str, Any]]]:
        """
        获取文件列表

        Args:
            parent_id: 父目录 ID, 空字符串表示根目录
            limit: 每页数量
            return_raw: 是否返回原始数据
            filters: JSON 格式过滤器

        Returns:
            文件列表或 None
        """
        all_files = []
        page_token = ""

        while True:
            resp = await self._get_files_page(parent_id, page_token, limit, filters)
            if not resp:
                return None if not all_files else all_files

            files = resp.get("files", [])
            all_files.extend(files)

            page_token = resp.get("next_page_token", "")
            if not page_token:
                break

        if return_raw:
            return all_files

        return [
            {
                "id": f.get("id"),
                "name": f.get("name"),
                "parent_id": f.get("parent_id"),
                "kind": f.get("kind"),
                "size": f.get("size"),
                "hash": f.get("hash"),
                "folder_type": f.get("folder_type"),
            }
            for f in all_files
        ]

    async def iter_files(
        self,
        parent_id: str = "",
        limit: int = 50,
        filters: Optional[str] = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """
        流式获取文件列表 (生成器模式)

        适用于大目录场景，避免将所有文件加载到内存中。

        Args:
            parent_id: 父目录 ID, 空字符串表示根目录
            limit: 每页数量
            filters: JSON 格式过滤器

        Yields:
            文件信息字典
        """
        page_token = ""

        while True:
            resp = await self._get_files_page(parent_id, page_token, limit, filters)
            if not resp:
                break

            files = resp.get("files", [])
            for file_info in files:
                yield file_info

            page_token = resp.get("next_page_token", "")
            if not page_token:
                break

    async def get_file_info(self, path: str) -> Optional[dict[str, Any]]:
        """
        获取文件/目录信息

        Args:
            path: 文件/目录路径（如 "/我的转存/电影"）或 ID（直接传入 ID 可快速查询）
                 "/" 表示根目录

        Returns:
            文件信息或 None
        """
        if path == "/":
            return await self.get_file_info_by_id("")

        if not path.startswith("/"):
            return await self.get_file_info_by_id(path)

        try:
            parts = split_path(path, change_to_lower=True)
            parent_id = ""

            if not parts:
                return None

            file_id = None
            for part in parts:
                files = await self.get_files(parent_id, limit=100)
                if not files:
                    return None

                matched = next((f for f in files if f.get("name", "").lower() == part), None)
                if not matched:
                    return None

                parent_id = matched.get("id", "")
                file_id = parent_id

            if file_id:
                return await self.get_file_info_by_id(file_id)
            return matched
        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"获取文件信息时发生错误: {type(e).__name__}")
            raise FileOperationError("获取文件信息失败，请稍后重试") from e

    async def get_file_info_by_id(self, file_id: str) -> Optional[dict[str, Any]]:
        """
        根据ID获取文件/目录信息

        Args:
            file_id: 文件/目录 ID

        Returns:
            文件信息或 None（文件不存在或在回收站中时返回 None）
        """
        try:
            url = f"{self.config.files_url}/{file_id}"
            resp = await self.get(url)
            if resp is None:
                return None
            return resp if resp.get("id") else resp.get("file")
        except BadRequestError:
            logger.warning(f"文件不存在或已在回收站中: {file_id}")
            return None
        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"获取文件信息时发生错误: {str(e)}")
            raise FileOperationError(f"获取文件信息失败: {str(e)}") from e

    async def get_file_direct_link_by_id(self, file_id: str) -> Optional[str]:
        """
        根据文件ID获取直链下载链接

        Args:
            file_id: 文件 ID

        Returns:
            直链下载链接或 None
        """
        file_info = await self.get_file_info_by_id(file_id)
        if not file_info:
            return None
        return file_info.get("web_content_link") or None

    async def get_file_details(  # noqa: C901
        self,
        file_id: str = "",
        path: str = "",
        include_share: bool = True,
    ) -> dict[str, Any]:
        """
        获取文件完整详情（统一封装）

        内部流程：
        1. get_file_info_by_id(file_id) 或 get_file_info(path) 获取基本信息
        2. _build_path(parent_id, info) 构建完整路径
        3. get_file_share_info(file_id) 获取分享信息（可选）

        Args:
            file_id: 文件/目录 ID（优先使用）
            path: 文件/目录路径（当 file_id 为空时使用）
            include_share: 是否包含分享信息（默认 True）

        Returns:
            包含完整详情的字典:
            {
                "file_info": dict,      # 原始文件信息
                "path": str,           # 完整路径
                "share_info": dict,   # 分享信息（仅当 include_share=True 时）
                "share_links": list,   # 格式化后的分享链接列表（仅当 include_share=True 时）
            }
            当文件不存在或获取失败时，返回:
            {
                "file_info": None,
                "path": "",
                "share_info": None,
                "share_links": [],
            }
        """
        result: dict[str, Any] = {
            "file_info": None,
            "path": "",
            "share_info": None,
            "share_links": [],
        }

        if file_id:
            file_info = await self.get_file_info_by_id(file_id)
        elif path:
            file_info = await self.get_file_info(path)
        else:
            return result

        if not file_info:
            return result

        result["file_info"] = file_info

        parent_id = file_info.get("parent_id", "")
        file_path = await self._build_path(parent_id, file_info) if parent_id else "/"
        result["path"] = file_path

        if include_share:
            fid = file_info.get("id", "")
            if fid:
                share_info = await self.get_file_share_info(file_id=fid)
                result["share_info"] = share_info

                if share_info and share_info.get("success") and share_info.get("share_links"):
                    share_links = [
                        link.get("share_url_with_passcode", "")
                        for link in share_info.get("share_links", [])
                        if link.get("share_url_with_passcode")
                    ]
                    result["share_links"] = share_links
                else:
                    result["share_links"] = []

        return result

    async def exists(
        self,
        name: str,
        path: str | None = None,
        is_folder: bool | None = None,
    ) -> dict[str, Any]:
        """
        判断文件或目录是否存在

        Args:
            name: 文件/目录名称或绝对路径
                 - 以 "/" 开头: 作为绝对路径处理，直接定位
                   例如: "/我的文档/电影.mp4" 定位到 "电影.mp4" 在 "/我的文档" 下
                 - 不以 "/" 开头: 作为名称处理，在指定目录中搜索
                   例如: "电影.mp4" 在指定 path 中搜索
            path: 目录路径 (可选，仅对非绝对路径的 name 有效)
                 - 默认为 None: 从根目录开始全局搜索
                 - 指定路径: 在该目录及子目录中搜索
                 - 例如: "/我的文档" 或 "电影"
            is_folder: 类型限定 (可选)
                 - True: 仅搜索目录
                 - False: 仅搜索文件
                 - None: 不限定类型

        Returns:
            包含查找结果的字典:
            {
                "exists": bool,              # 是否存在
                "type": str,                 # 类型 ("file", "folder", None)
                "id": str,                   # 文件/目录 ID (存在时)
                "name": str,                 # 文件/目录名称 (存在时)
                "parent_id": str,            # 父目录 ID (存在时)
                "info": dict | None,         # 文件/目录完整信息 (存在时)
                "message": str,              # 结果描述
            }

        Examples:
            # 使用绝对路径定位（name 以 / 开头）
            result = await cloud.exists("/测试目录/子目录1")  # 定位 /测试目录 下的 子目录1

            # 使用名称搜索（name 不以 / 开头）
            result = await cloud.exists("电影.mp4")
            result = await cloud.exists("报告.pdf", path="/我的文档")
            result = await cloud.exists("我的文件夹", is_folder=True)
        """
        try:
            if name.startswith("/"):
                return await self._exists_by_absolute_path(name, is_folder)

            if path and path != "/":
                parent_info = await self.get_file_info(path)
                if not parent_info:
                    return {
                        "exists": False,
                        "type": None,
                        "id": "",
                        "name": name,
                        "parent_id": "",
                        "info": None,
                        "message": f"指定目录不存在: {path}",
                    }
                start_parent_id = parent_info.get("id", "")
            else:
                start_parent_id = ""

            result = await self._find_first(
                name,
                parent_id=start_parent_id,
                exact=True,
                is_folder=is_folder,
            )

            if result:
                item_kind = result.get("kind", "")
                item_type = (
                    "folder" if item_kind == "drive#folder" else "file" if item_kind else None
                )
                return {
                    "exists": True,
                    "type": item_type,
                    "id": result.get("id", ""),
                    "name": result.get("name", ""),
                    "parent_id": result.get("parent_id", ""),
                    "info": result,
                    "message": f"找到 {item_type}: {result.get('name', name)}",
                }

            return {
                "exists": False,
                "type": None,
                "id": "",
                "name": name,
                "parent_id": start_parent_id,
                "info": None,
                "message": f"未找到: {name}" + (f" 在目录 {path}" if path else " (全局搜索)"),
            }

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"检查文件存在性时发生错误: {str(e)}")
            raise FileOperationError(f"检查存在性失败: {str(e)}") from e

    async def _exists_by_absolute_path(
        self,
        path: str,
        is_folder: bool | None = None,
    ) -> dict[str, Any]:
        """
        根据绝对路径检查文件/目录是否存在

        Args:
            path: 绝对路径
            is_folder: 类型限定

        Returns:
            存在性检查结果字典
        """
        file_info = await self.get_file_info(path)
        if not file_info:
            return {
                "exists": False,
                "type": None,
                "id": "",
                "name": path,
                "parent_id": "",
                "info": None,
                "message": f"绝对路径不存在: {path}",
            }

        item_kind = file_info.get("kind", "")
        item_type = "folder" if item_kind == "drive#folder" else "file" if item_kind else None

        if is_folder is True and item_type != "folder":
            return {
                "exists": False,
                "type": item_type,
                "id": file_info.get("id", ""),
                "name": file_info.get("name", ""),
                "parent_id": file_info.get("parent_id", ""),
                "info": file_info,
                "message": f"类型不匹配: 期望目录，实际是 {item_type}",
            }

        if is_folder is False and item_type != "file":
            return {
                "exists": False,
                "type": item_type,
                "id": file_info.get("id", ""),
                "name": file_info.get("name", ""),
                "parent_id": file_info.get("parent_id", ""),
                "info": file_info,
                "message": f"类型不匹配: 期望文件，实际是 {item_type}",
            }

        return {
            "exists": True,
            "type": item_type,
            "id": file_info.get("id", ""),
            "name": file_info.get("name", ""),
            "parent_id": file_info.get("parent_id", ""),
            "info": file_info,
            "message": f"找到 {item_type}: {file_info.get('name', path)}",
        }

    async def _exists_by_name_in_parent(
        self,
        name: str,
        parent_id: str,
        is_folder: bool | None = None,
    ) -> dict[str, Any]:
        """
        根据名称和父目录ID检查是否存在同名文件/目录

        Args:
            name: 文件/目录名称
            parent_id: 父目录ID
            is_folder: 类型限定 (True=仅目录, False=仅文件, None=不限)

        Returns:
            包含查找结果的字典
        """
        try:
            resp = await self.get(
                self.config.files_url,
                params={
                    "space": "",
                    "dir_id": parent_id,
                    "fields": "*",
                    "page_size": 100,
                },
            )

            if not resp:
                return {
                    "exists": False,
                    "type": None,
                    "id": "",
                    "name": name,
                    "parent_id": parent_id,
                    "info": None,
                    "message": f"父目录不存在或无法访问: {parent_id}",
                }

            files = resp.get("files", [])
            for f in files:
                if f.get("name") == name:
                    item_kind = f.get("kind", "")
                    item_type = "folder" if item_kind == "drive#folder" else "file"

                    if is_folder is not None:
                        if is_folder and item_kind != "drive#folder":
                            continue
                        if not is_folder and item_kind == "drive#folder":
                            continue

                    return {
                        "exists": True,
                        "type": item_type,
                        "id": f.get("id", ""),
                        "name": name,
                        "parent_id": parent_id,
                        "info": f,
                        "message": f"找到已存在的 {item_type}: {name}",
                    }

            return {
                "exists": False,
                "type": None,
                "id": "",
                "name": name,
                "parent_id": parent_id,
                "info": None,
                "message": f"未找到同名文件/目录: {name}",
            }

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"检查同名文件时发生错误: {str(e)}")
            return {
                "exists": False,
                "type": None,
                "id": "",
                "name": name,
                "parent_id": parent_id,
                "info": None,
                "message": f"检查同名文件失败: {str(e)}",
            }

    async def _generate_unique_name(
        self,
        original_name: str,
        parent_id: str,
        max_attempts: int = 100,
    ) -> str | None:
        """
        生成唯一的文件名（通过添加序号）

        Args:
            original_name: 原始文件名
            parent_id: 父目录ID
            max_attempts: 最大尝试次数

        Returns:
            唯一的文件名，如果无法生成则返回None
        """
        import os

        name_without_ext, ext = os.path.splitext(original_name)

        for i in range(1, max_attempts + 1):
            new_name = f"{name_without_ext} ({i}){ext}"
            existing = await self._exists_by_name_in_parent(new_name, parent_id)
            if not existing.get("exists"):
                return new_name

        return None

    # ==================== 搜索 ====================

    async def search(  # noqa: C901
        self,
        query: str | None = None,
        callback: Callable[[dict[str, Any]], bool | None] | None = None,
        path: str | None = None,
        exact: bool = False,
        is_folder: bool | None = None,
        max_results: int | None = 100,
        depth: int | None = None,
        return_raw: bool = False,
        show_spinner: bool = True,
        auto_share: bool = False,
        share_exists_strategy: ShareLinkStrategy = ShareLinkStrategy.SKIP,
    ) -> dict[str, Any]:
        """
        搜索文件或目录（纯 API 搜索）

        Args:
            query: 搜索关键词 (可选)
                 - exact=False (默认): 模糊匹配，名称包含关键词即匹配
                 - exact=True: 精确匹配，名称必须完全等于关键词
                 - 可以和 callback 组合使用
            callback: 自定义匹配回调函数 (可选)
                     签名: Callable[[dict], bool | None]
                     - 接收文件信息字典
                     - 返回 True 表示匹配，返回 False 表示不匹配
                     - 返回 None 也视为不匹配
                     - 可以和 query 组合使用，API 搜索 + 本地过滤
            path: 搜索目录路径 (可选)
                 - None: 从根目录开始全局搜索
                 - "/": 根目录
                 - "/子目录": 指定目录
                 - 注意: 需要通过 API 获取目录 ID，可能有额外开销
            exact: 是否精确匹配 (仅对 query 有效，默认: False)
                 - False: 模糊匹配，名称包含关键词即匹配
                 - True: 精确匹配，名称必须完全等于关键词
            is_folder: 类型限定 (可选)
                 - True: 仅搜索目录
                 - False: 仅搜索文件
                 - None: 不限定类型
            max_results: 最大返回数量 (默认: 100, None 表示不限制)
            depth: 递归深度 (可选，已废弃)
                 - 由于 API 不支持深度限制，此参数暂不生效
            return_raw: 是否返回原始数据 (默认 False)
                 - False: 返回精简的字段信息（无额外 API 调用，包含 share_info）
                 - True: 返回完整的原始文件信息（需额外 API 调用获取 path、share_info 等）
            show_spinner: 是否显示转圈动画 (默认 True)
            auto_share: 是否为没有分享链接的文件自动创建分享 (默认 False)
                 - True: 为没有分享链接的文件创建永久有效的分享链接
                 - False: 不创建分享
            share_exists_strategy: 分享链接已存在时的策略 (默认 SKIP)
                 - SKIP: 存在就不重复创建，返回现有的携带提取码的完整分享链接
                 - RECREATE: 创建一个新的，返回新建和现有的所有链接（新建的在第一个位置）
                 - OVERWRITE: 删除现有的所有分享链接，然后创建一个新的

        Returns:
            字典包含 files、file_count、folder_count、total_count
            {
                "files": [...],           # 文件/目录列表
                "file_count": int,       # 文件数量
                "folder_count": int,     # 文件夹数量
                "total_count": int,      # 总数量
                "share_summary": {...},  # 仅当 auto_share=True 时存在
            }

            share_summary (仅 auto_share=True 时):
            {
                "total_files": int,       # 文件总数
                "newly_created": int,     # 新创建分享的文件数
            }

        Examples:
            # 使用 query 模糊搜索
            results = await cloud.search("电影")

            # 搜索指定目录
            results = await cloud.search("电影", path="/我的文档")

            # 使用 query 精确搜索
            results = await cloud.search("电影.mp4", exact=True)

            # 仅搜索文件
            results = await cloud.search("电影", is_folder=False)

            # 仅搜索目录
            results = await cloud.search("文件夹", is_folder=True)

            # 获取完整文件详情
            results = await cloud.search("电影", return_raw=True)

            # 使用 callback 搜索（复杂场景）
            results = await cloud.search(
                callback=lambda f: f.get("size", 0) > 1000000 and "视频" in f.get("name", "")
            )

            # 搜索并为没有分享的文件创建分享
            results = await cloud.search("电影", auto_share=True)

            # 搜索并覆盖已存在的分享
            results = await cloud.search(
                "视频",
                auto_share=True,
                share_exists_strategy=ShareLinkStrategy.OVERWRITE,
            )
        """
        try:
            if query is None and callback is None:
                raise FileOperationError("query 和 callback 必须至少提供一个")

            if depth is not None:
                logger.warning("API 搜索不支持深度限制，depth 参数已废弃，将进行全局搜索")

            parent_id = ""
            if path is not None and path != "/":
                logger.info(f"正在解析目录路径: {path}")
                file_info = await self.get_file_info(path)
                if file_info:
                    parent_id = file_info.get("id", "")
                    logger.info(f"目录 ID: {parent_id}")
                else:
                    logger.warning(f"目录不存在: {path}，将进行全局搜索")
                    parent_id = ""

            spinner = Spinner(f"正在搜索: {query or '...'}")
            if show_spinner:
                spinner.start()

            try:
                if parent_id and (query is None or query == "") and callback is None:
                    results = await self.get_files(parent_id)
                    logger.info(f"使用 get_files 获取目录内容，返回 {len(results)} 个")
                elif parent_id and (query or callback):
                    logger.info("使用 get_files 获取目录内容后本地过滤")
                    raw_results = await self.get_files(parent_id)
                    logger.info(f"get_files 获取到 {len(raw_results)} 个文件")
                    filtered: list[dict[str, Any]] = []
                    for f in raw_results:
                        if self._match_file(f, query, exact, is_folder, callback):
                            filtered.append(f)
                    results = filtered
                    logger.info(f"本地过滤后剩余 {len(results)} 个结果")
                else:
                    results = await self._search_by_api(
                        query=query,
                        exact=exact,
                        is_folder=is_folder,
                        max_results=max_results,
                        callback=callback,
                        parent_id=parent_id,
                    )

                if return_raw and results:
                    logger.info(f"正在获取 {len(results)} 个文件的详细信息...")
                    detailed_results = []
                    for f in results:
                        file_id = f.get("id")
                        if file_id:
                            details = await self.get_file_details(
                                file_id=file_id, include_share=True
                            )
                            file_info = details.get("file_info")
                            if file_info:
                                file_info["path"] = details.get("path", "")
                                file_info["share_info"] = details.get("share_info")
                                file_info["share_links"] = details.get("share_links", [])
                                detailed_results.append(file_info)
                            else:
                                detailed_results.append(f)
                        else:
                            detailed_results.append(f)
                    results = detailed_results
                elif results:
                    logger.info(f"正在获取 {len(results)} 个文件的分享信息和路径...")
                    for f in results:
                        file_id = f.get("id")
                        if file_id:
                            details = await self.get_file_details(
                                file_id=file_id, include_share=True
                            )
                            file_info = details.get("file_info")
                            if file_info:
                                f["path"] = details.get("path", "")
                                if file_info.get("web_content_link"):
                                    f["web_content_link"] = file_info.get("web_content_link")
                                if file_info.get("mime_type"):
                                    f["mime_type"] = file_info.get("mime_type")
                                f["share_links"] = details.get("share_links", [])

                formatted = self._format_search_results(results, return_raw)

                if auto_share and formatted.get("files"):
                    files_need_share = []
                    for f in formatted["files"]:
                        if f.get("kind") == "drive#folder":
                            continue
                        if share_exists_strategy == ShareLinkStrategy.SKIP and f.get("share_links"):
                            continue
                        if f.get("id"):
                            files_need_share.append(f)

                    if not files_need_share:
                        formatted["share_summary"] = {
                            "total_files": len(formatted["files"]),
                            "newly_created": 0,
                        }
                    else:
                        logger.info(f"正在为 {len(files_need_share)} 个文件创建分享...")
                        newly_created = 0
                        for f in files_need_share:
                            file_id = f.get("id")
                            share_result = await self.create_share_link(
                                file_id=file_id,
                                valid_days=-1,
                                extraction_times=-1,
                                with_passcode=True,
                                on_exists=share_exists_strategy,
                            )
                            if share_result.get("success"):
                                f["share_links"] = share_result.get("share_links", [])
                                if share_result.get("newly_created"):
                                    newly_created += 1
                                    f["share_created"] = True
                                else:
                                    f["share_created"] = False
                            else:
                                f["share_created"] = False
                        formatted["share_summary"] = {
                            "total_files": len(formatted["files"]),
                            "newly_created": newly_created,
                        }
                        logger.info(f"分享创建完成，共新创建 {newly_created} 个分享链接")

                if show_spinner:
                    await spinner.stop(success=True)
                return formatted
            except Exception:
                if show_spinner:
                    await spinner.stop(success=False)
                raise

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"搜索文件时发生错误: {str(e)}")
            raise FileOperationError(f"搜索失败: {str(e)}") from e

    async def _search_by_api(  # noqa: C901
        self,
        query: str | None,
        exact: bool,
        is_folder: bool | None,
        max_results: int | None,
        callback: Callable[[dict[str, Any]], bool | None] | None = None,
        parent_id: str = "",
    ) -> list[dict[str, Any]]:
        """
        使用服务器端 API 搜索文件

        Args:
            query: 搜索关键词
            exact: 是否精确匹配
            is_folder: 类型限定 (True=仅文件夹, False=仅文件, None=不限)
            max_results: 最大返回数量
            callback: 自定义匹配回调函数
            parent_id: 父目录 ID (空字符串表示全局搜索)

        Returns:
            匹配的文件列表
        """
        user_id = self.cache.tokens.user_id
        if not user_id:
            return []

        results: list[dict[str, Any]] = []
        page_token = ""
        limit = 100

        search_type: str | None = None
        if is_folder is True:
            search_type = SearchType.FOLDER.value
        elif is_folder is False:
            search_type = SearchType.FILE.value

        while len(results) < (max_results or float("inf")):
            params: dict[str, str] = {
                "keyword": query or "",
                "limit": str(min(limit, max_results or limit)),
                "space": "*",
                "user_id": user_id,
                "parent_id": parent_id,
                "page_token": page_token,
            }
            if search_type:
                params["type"] = search_type

            resp = await self.get(self.config.search_url, params=params)
            if not resp or resp.get("code") != 0:
                break

            data = resp.get("data", {})
            files = data.get("files", [])
            if not files:
                break

            for f in files:
                if self._match_file(f, query, exact, is_folder, callback):
                    results.append(f)
                    if max_results is not None and len(results) >= max_results:
                        break

            page_token = data.get("next_page_token", "")
            if not page_token:
                break

        return results

    def _format_search_results(  # noqa: C901
        self,
        results: list[dict[str, Any]],
        return_raw: bool = False,
    ) -> dict[str, Any]:
        """
        格式化搜索结果

        Args:
            results: 原始搜索结果列表
            return_raw: 是否返回原始数据

        Returns:
            格式化后的结果字典，包含 files、file_count、folder_count、total_count
        """
        if not results:
            return {"files": [], "file_count": 0, "folder_count": 0, "total_count": 0}

        file_count = sum(1 for f in results if f.get("kind") != "drive#folder")
        folder_count = sum(1 for f in results if f.get("kind") == "drive#folder")

        if return_raw:
            simplified = []
            for f in results:
                item = dict(f)
                if "size_human" not in item and f.get("size") is not None:
                    size = f.get("size")
                    try:
                        item["size_human"] = self._format_bytes(int(size))
                    except (ValueError, TypeError):
                        pass
                simplified.append(item)
        else:
            simplified = [self._format_file_info(f) for f in results]

        return {
            "files": simplified,
            "file_count": file_count,
            "folder_count": folder_count,
            "total_count": len(results),
        }

    def _format_file_info(self, file_info: dict[str, Any]) -> dict[str, Any]:
        """
        格式化文件信息为精简字段

        Args:
            file_info: 原始文件信息字典

        Returns:
            包含精简字段的字典
        """
        result: dict[str, Any] = {}
        for key in SIMPLIFIED_FILE_FIELDS:
            if key in file_info:
                result[key] = file_info[key]
            elif key == "size_human" and file_info.get("size") is not None:
                try:
                    result["size_human"] = self._format_bytes(int(file_info.get("size")))
                except (ValueError, TypeError):
                    pass
        return result

    def _match_file(
        self,
        file_info: dict[str, Any],
        query: str | None,
        exact: bool,
        is_folder: bool | None,
        callback: Callable[[dict[str, Any]], bool | None] | None,
    ) -> bool:
        """判断文件是否匹配搜索条件"""
        if callback is not None:
            return self._match_by_callback(file_info, callback)
        return self._is_matched(file_info, query, exact, is_folder)

    def _match_by_callback(
        self,
        file_info: dict[str, Any],
        callback: Callable[[dict[str, Any]], bool | None],
    ) -> bool:
        """使用回调函数判断是否匹配"""
        try:
            result = callback(file_info)
            return result is True
        except Exception:
            return False

    def _is_matched(
        self,
        file_info: dict[str, Any],
        query: str | None,
        exact: bool,
        is_folder: bool | None,
    ) -> bool:
        """判断文件是否匹配搜索条件"""
        f_kind = file_info.get("kind", "")
        is_file_folder = f_kind == "drive#folder"

        if is_folder is True and not is_file_folder:
            return False
        if is_folder is False and is_file_folder:
            return False

        if query is None or query == "":
            return True

        f_name = file_info.get("name", "")
        if exact:
            return f_name == query
        return query.lower() in f_name.lower()

    async def _find_first(
        self,
        name: str,
        parent_id: str = "",
        exact: bool = True,
        is_folder: bool | None = None,
    ) -> Optional[dict[str, Any]]:
        """
        查找第一个匹配的文件/目录（使用 API 搜索）

        Args:
            name: 文件/目录名称
            parent_id: 起始父目录 ID (已废弃，API 不支持)
            exact: 是否精确匹配
            is_folder: 类型限定

        Returns:
            匹配的文件/目录信息或 None
        """
        results = await self._search_by_api(
            query=name,
            exact=exact,
            is_folder=is_folder,
            max_results=10,
            callback=None,
        )

        if not results:
            return None

        for f in results:
            f_name = f.get("name", "")
            if exact:
                if f_name == name:
                    return f
            else:
                if name.lower() in f_name.lower():
                    return f

        return None

    async def _build_path(self, parent_id: str, file_info: dict[str, Any]) -> str:
        """
        构建文件的完整路径

        Args:
            parent_id: 父目录 ID，空字符串表示根目录
            file_info: 文件信息

        Returns:
            文件的完整路径
        """
        if not parent_id:
            return "/" + file_info.get("name", "")

        path_parts = []
        current_id = parent_id

        while current_id:
            try:
                resp = await self.get(f"{self.config.files_url}/{current_id}")
                if resp:
                    parent = resp if resp.get("id") else resp.get("file")
                    if parent:
                        path_parts.append(parent.get("name", ""))
                        current_id = parent.get("parent_id", "")
                    else:
                        break
                else:
                    break
            except Exception:
                break

        path_parts.append(file_info.get("name", ""))
        return "/" + "/".join(path_parts)

    # ==================== 目录管理 ====================

    async def create_folder(
        self,
        name: str,
        parent_id: str = "",
        auto_create_parents: bool = False,
        include_raw: bool = False,
    ) -> dict[str, Any]:
        """
        创建目录（增强版，支持路径和ID两种方式）

        Args:
            name: 目录名或完整路径
            parent_id: 父目录ID (如果为空且name是路径，则按路径创建)
            auto_create_parents: 是否自动创建父目录 (当name为路径时有效)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool | str,   # 操作结果 (True=创建成功, "existed"=已存在, False=失败)
                "folder_id": str,          # 文件夹ID (创建/已存在时)
                "folder_name": str,        # 文件夹名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        if "/" in name or name.startswith("/"):
            return await self.create_folder_by_path(name, auto_create_parents, include_raw)

        existing = await self._find_existing_folder(name, parent_id)
        if existing:
            result = {
                "success": "existed",
                "folder_id": existing.get("id", ""),
                "folder_name": name,
                "parent_id": parent_id,
                "message": f"目录已存在: {name}",
            }
            if include_raw:
                result["raw"] = existing
            return result

        resp = await self.post(
            self.config.files_url,
            json={
                "parent_id": parent_id,
                "name": name,
                "kind": "drive#folder",
                "space": "",
            },
        )
        if resp:
            folder_info = resp.get("file")
            if folder_info:
                await asyncio.sleep(0.2)
                result = {
                    "success": True,
                    "folder_id": folder_info.get("id", ""),
                    "folder_name": name,
                    "parent_id": parent_id,
                    "message": f"成功创建目录: {name}",
                }
                if include_raw:
                    result["raw"] = resp
                return result
            else:
                result = {
                    "success": False,
                    "folder_id": "",
                    "folder_name": name,
                    "parent_id": parent_id,
                    "message": "创建目录失败: 无法获取目录信息",
                }
                if include_raw:
                    result["raw"] = resp
                return result
        else:
            result = {
                "success": False,
                "folder_id": "",
                "folder_name": name,
                "parent_id": parent_id,
                "message": "创建目录失败: HTTP请求失败",
            }
            if include_raw:
                result["raw"] = None
            return result

    async def _find_existing_folder(
        self, folder_name: str, parent_id: str = ""
    ) -> Optional[dict[str, Any]]:
        """
        在指定父目录下查找同名文件夹

        Args:
            folder_name: 文件夹名称
            parent_id: 父目录ID

        Returns:
            文件夹信息或 None
        """
        files = await self.get_files(parent_id, limit=100)
        if not files:
            return None
        return next(
            (f for f in files if f.get("name") == folder_name and f.get("kind") == "drive#folder"),
            None,
        )

    async def create_folder_original(
        self, name: str, parent_id: str = ""
    ) -> Optional[dict[str, Any]]:
        """原始的创建目录方法"""
        resp = await self.post(
            self.config.files_url,
            json={
                "parent_id": parent_id,
                "name": name,
                "kind": "drive#folder",
                "space": "",
            },
        )
        if resp:
            return resp.get("file")
        return None

    async def create_folders_recursive_original(
        self,
        folder_path: str,
        parent_id: str = "",
    ) -> bool:
        """
        递归创建目录（原始版本）

        Args:
            folder_path: 目录路径, 如 "电影/2024/科幻"
            parent_id: 父目录 ID

        Returns:
            是否成功
        """
        parts = split_path(folder_path)
        current_parent_id = parent_id

        for part in parts:
            # 检查是否已存在
            files = await self.get_files(current_parent_id, limit=100)
            if files:
                existing = next((f for f in files if f.get("name") == part), None)
                if existing:
                    current_parent_id = existing.get("id", "")
                    continue

            # 创建
            result = await self.create_folder_original(part, current_parent_id)
            if not result:
                files = await self.get_files(current_parent_id, limit=100)
                if files and any(f.get("name") == part for f in files):
                    continue
                logger.warning(f"创建目录失败（可能已存在）: {part}")
                return False
            await asyncio.sleep(0.2)
            current_parent_id = result.get("id", "")

        return True

    async def create_folder_by_path(
        self, folder_path: str, auto_create_parents: bool = True, include_raw: bool = False
    ) -> dict[str, Any]:
        """
        通过完整路径创建目录（支持绝对路径和相对路径）

        Args:
            folder_path: 完整目录路径, 如 "/我的文件/子目录" 或 "子目录/子子目录"
                        注意: 以 '/' 开头表示从根目录开始的绝对路径
                        不以 '/' 开头表示相对于当前位置的相对路径
            auto_create_parents: 是否自动创建父目录
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool | str,   # 操作结果 (True=创建成功, "existed"=已存在, False=失败)
                "folder_id": str,          # 文件夹ID (创建/已存在时)
                "folder_name": str,        # 文件夹名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        try:
            normalized_path = self._normalize_folder_path(folder_path)
            if not normalized_path:
                return {
                    "success": False,
                    "folder_id": "",
                    "folder_name": "",
                    "parent_id": "",
                    "message": "路径不能为空",
                }

            existing_info = await self.get_file_info(f"/{normalized_path}")
            if existing_info and existing_info.get("kind") == "drive#folder":
                return {
                    "success": "existed",
                    "folder_id": existing_info.get("id", ""),
                    "folder_name": existing_info.get("name", ""),
                    "parent_id": existing_info.get("parent_id", ""),
                    "message": f"目录已存在: {normalized_path}",
                }

            if auto_create_parents:
                return await self._create_folder_by_path_with_parents(normalized_path, include_raw)
            else:
                return await self._create_folder_by_path_single(normalized_path, include_raw)

        except Exception as e:
            logger.error(f"创建目录路径时发生错误: {str(e)}")
            result = {
                "success": False,
                "folder_id": "",
                "folder_name": folder_path,
                "parent_id": "",
                "message": f"创建目录时发生错误: {str(e)}",
            }
            if include_raw:
                result["raw"] = None
            return result

    def _normalize_folder_path(self, folder_path: str) -> str:
        """规范化文件夹路径"""
        if folder_path == "/":
            return ""
        if folder_path.startswith("/"):
            return folder_path[1:]
        return folder_path

    async def _create_folder_by_path_with_parents(
        self, folder_path: str, include_raw: bool = False
    ) -> dict[str, Any]:
        """自动创建父目录时创建文件夹"""
        success = await self.create_folders_recursive_original(folder_path)
        if success:
            new_folder_info = await self.get_file_info(f"/{folder_path}")
            if new_folder_info:
                result = {
                    "success": True,
                    "folder_id": new_folder_info.get("id", ""),
                    "folder_name": new_folder_info.get("name", ""),
                    "parent_id": new_folder_info.get("parent_id", ""),
                    "message": f"成功创建目录: {folder_path}",
                }
                if include_raw:
                    result["raw"] = new_folder_info
                return result
        result = {
            "success": False,
            "folder_id": "",
            "folder_name": folder_path,
            "parent_id": "",
            "message": f"创建目录失败: {folder_path}",
        }
        if include_raw:
            result["raw"] = None
        return result

    async def _create_folder_by_path_single(
        self, folder_path: str, include_raw: bool = False
    ) -> dict[str, Any]:
        """不自动创建父目录时创建单级文件夹"""
        parts = split_path(folder_path)
        if len(parts) == 1:
            result = await self.create_folder_original(parts[0])
            if result:
                resp = {
                    "success": True,
                    "folder_id": result.get("id", ""),
                    "folder_name": parts[0],
                    "parent_id": result.get("parent_id", ""),
                    "message": f"成功创建目录: {parts[0]}",
                }
                if include_raw:
                    resp["raw"] = result
                return resp
            resp = {
                "success": False,
                "folder_id": "",
                "folder_name": parts[0],
                "parent_id": "",
                "message": f"创建目录失败: {parts[0]}",
            }
            if include_raw:
                resp["raw"] = None
            return resp

        parent_path = "/".join(parts[:-1])
        parent_info = await self.get_file_info(f"/{parent_path}")
        if not parent_info:
            resp = {
                "success": False,
                "folder_id": "",
                "folder_name": folder_path,
                "parent_id": "",
                "message": f"父目录不存在: {parent_path}",
            }
            if include_raw:
                resp["raw"] = None
            return resp

        result = await self.create_folder_original(parts[-1], parent_info.get("id", ""))
        if result:
            resp = {
                "success": True,
                "folder_id": result.get("id", ""),
                "folder_name": parts[-1],
                "parent_id": parent_info.get("id", ""),
                "message": f"成功创建目录: {folder_path}",
            }
            if include_raw:
                resp["raw"] = result
            return resp
        resp = {
            "success": False,
            "folder_id": "",
            "folder_name": folder_path,
            "parent_id": "",
            "message": f"创建目录失败: {folder_path}",
        }
        if include_raw:
            resp["raw"] = None
        return resp

    async def create_folders_recursive(
        self,
        folder_path: str,
        parent_id: str = "",
    ) -> dict[str, Any]:
        """
        递归创建目录（用户友好版本）

        Args:
            folder_path: 目录路径, 如 "电影/2024/科幻"
            parent_id: 父目录 ID

        Returns:
            包含操作结果的用户友好字典
        """
        # 调用原版本
        success = await self.create_folders_recursive_original(folder_path, parent_id)

        if success:
            # 获取新创建的目录信息
            new_folder_info = await self.get_file_info(f"/{folder_path}")
            return {
                "success": True,
                "operation": "create_folders_recursive",
                "action": "created",
                "target": folder_path,
                "folder_info": new_folder_info,
                "message": f"成功递归创建目录: {folder_path}",
                "details": {
                    "path": folder_path,
                    "parent_id": parent_id,
                    "created_count": len(split_path(folder_path)),
                },
                "created_path": folder_path,
                "timestamp": __import__("datetime").datetime.now().isoformat(),
            }
        else:
            return {
                "success": False,
                "operation": "create_folders_recursive",
                "action": "failed",
                "target": folder_path,
                "folder_info": None,
                "message": f"递归创建目录失败: {folder_path}",
                "details": {
                    "path": folder_path,
                    "parent_id": parent_id,
                    "error": "部分或全部目录创建失败",
                },
                "created_path": folder_path,
                "timestamp": __import__("datetime").datetime.now().isoformat(),
            }

    async def rename(
        self,
        old: str | Callable[[dict[str, Any]], bool | None],
        new: str | Callable[[dict[str, Any]], str] | None = None,
        path: str | None = None,
        is_folder: bool | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        重命名文件/目录（支持单个和批量操作）

        两种模式：
        1. 单个重命名 (path=None):
           - old: 绝对路径，如 "/文档/旧文件名.txt"
           - new: 新名称，如 "新文件名.txt"
        2. 批量重命名 (path 设定目录):
           - path: "all" 表示整个网盘，"/" 表示根目录，"/目录" 表示指定目录下的文件
           - old: 回调函数
           - new: 回调函数

        Args:
            old: 原文件路径或匹配回调函数
            new: 新名称或名称回调函数（单个模式时必需）
            path: 操作目录 (None=单个模式, "all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (仅批量模式有效)
                      - True: 仅匹配目录
                      - False: 仅匹配文件
                      - None: 不限定类型

        Returns:
            单个模式: 操作结果字典
            {
                "success": bool,
                "type": str,
                "old_name": str,
                "new_name": str,
                "id": str,
                "parent_id": str,
                "message": str,
            }
            批量模式: 操作结果列表

        Examples:
            # 单个重命名
            result = await cloud.rename("/文档/旧文件名.txt", "新文件名.txt")

            # 批量重命名 - 替换文件名中的字符串
            results = await cloud.rename(
                old=lambda f: "旧字符" in f.get("name", ""),
                new=lambda f: f.get("name", "").replace("旧字符", "新字符"),
                path="/文档"
            )

            # 批量重命名 - 仅重命名目录
            results = await cloud.rename(
                old=lambda f: f.get("name", "").startswith("临时_"),
                new=lambda f: f.get("name", "").replace("临时_", ""),
                path="/",
                is_folder=True
            )

            # 批量重命名 - 仅重命名文件
            results = await cloud.rename(
                old=lambda f: ".txt" in f.get("name", ""),
                new=lambda f: f.get("name", "").replace(".txt", ".md"),
                path="/",
                is_folder=False
            )

        回调函数签名说明:

        old 回调函数 (匹配条件):
            签名: Callable[[dict], bool | None]
            接收的文件信息字典字段:
            {
                "id": str,           # 文件/目录 ID
                "name": str,          # 文件/目录名称
                "parent_id": str,     # 父目录 ID
                "kind": str,          # 类型 ("drive#folder"=目录, "drive#file"=文件)
                "size": int,          # 文件大小（字节）
                "path": str,          # 完整路径
                "created_time": str,  # 创建时间
                "modified_time": str, # 修改时间
                "mime_type": str,     # MIME 类型
            }
            返回 True 表示匹配，返回 False 表示不匹配

        new 回调函数 (生成新名称):
            签名: Callable[[dict], str]
            接收同上字典字段
            返回新名称字符串
        """
        try:
            if path is None:
                return await self._rename_single(old, new)
            else:
                return await self._rename_batch(old, new, path, is_folder)

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"重命名时发生错误: {str(e)}")
            return {
                "success": False,
                "type": None,
                "old_name": "",
                "new_name": "",
                "id": "",
                "parent_id": "",
                "message": f"重命名失败: {str(e)}",
            }

    async def _rename_single(
        self,
        old: str,
        new: str,
    ) -> dict[str, Any]:
        """
        单个重命名

        Args:
            old: 绝对路径
            new: 新名称

        Returns:
            操作结果字典
        """
        if not old.startswith("/"):
            return {
                "success": False,
                "type": None,
                "old_name": "",
                "new_name": new,
                "id": "",
                "parent_id": "",
                "message": "单个重命名模式: old 必须是绝对路径，以 / 开头",
            }

        file_info = await self.get_file_info(old)
        if not file_info:
            return {
                "success": False,
                "type": None,
                "old_name": "",
                "new_name": new,
                "id": "",
                "parent_id": "",
                "message": f"文件/目录不存在: {old}",
            }

        item_kind = file_info.get("kind", "")
        item_type = "folder" if item_kind == "drive#folder" else "file"
        old_name = file_info.get("name", "")
        file_id = file_info.get("id", "")

        resp = await self.patch(
            f"{self.config.files_url}/{file_id}",
            json={"name": new, "space": ""},
        )

        if resp is not None:
            return {
                "success": True,
                "type": item_type,
                "old_name": old_name,
                "new_name": new,
                "id": file_id,
                "parent_id": file_info.get("parent_id", ""),
                "message": f"成功重命名 {item_type} '{old_name}' 为 '{new}'",
            }
        else:
            return {
                "success": False,
                "type": item_type,
                "old_name": old_name,
                "new_name": new,
                "id": file_id,
                "parent_id": file_info.get("parent_id", ""),
                "message": "重命名失败",
            }

    async def _rename_batch(
        self,
        old: Callable[[dict[str, Any]], bool | None],
        new: Callable[[dict[str, Any]], str],
        path: str,
        is_folder: bool | None = None,
    ) -> list[dict[str, Any]]:
        """
        批量重命名

        Args:
            old: 匹配回调函数
            new: 生成新名称回调函数
            path: 搜索目录 ("all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (True=仅目录, False=仅文件, None=不限)

        Returns:
            操作结果列表
        """
        search_path = None if path == "all" else path

        files = await self.search(callback=old, path=search_path, is_folder=is_folder, raw=True)
        results: list[dict[str, Any]] = []

        for file_info in files:
            old_name = file_info.get("name", "")
            file_id = file_info.get("id", "")
            item_kind = file_info.get("kind", "")
            item_type = "folder" if item_kind == "drive#folder" else "file"

            try:
                new_name = new(file_info)
            except Exception as e:
                results.append(
                    {
                        "success": False,
                        "type": item_type,
                        "old_name": old_name,
                        "new_name": "",
                        "id": file_id,
                        "parent_id": file_info.get("parent_id", ""),
                        "message": f"生成新名称失败: {str(e)}",
                    }
                )
                continue

            if not new_name or new_name == old_name:
                results.append(
                    {
                        "success": False,
                        "type": item_type,
                        "old_name": old_name,
                        "new_name": new_name,
                        "id": file_id,
                        "parent_id": file_info.get("parent_id", ""),
                        "message": "新名称无效或与原名称相同，跳过",
                    }
                )
                continue

            resp = await self.patch(
                f"{self.config.files_url}/{file_id}",
                json={"name": new_name, "space": ""},
            )

            if resp is not None:
                results.append(
                    {
                        "success": True,
                        "type": item_type,
                        "old_name": old_name,
                        "new_name": new_name,
                        "id": file_id,
                        "parent_id": file_info.get("parent_id", ""),
                        "message": f"成功重命名 {item_type} '{old_name}' 为 '{new_name}'",
                    }
                )
            else:
                results.append(
                    {
                        "success": False,
                        "type": item_type,
                        "old_name": old_name,
                        "new_name": new_name,
                        "id": file_id,
                        "parent_id": file_info.get("parent_id", ""),
                        "message": "重命名失败",
                    }
                )

        return results

    async def copy(
        self,
        source: str | Callable[[dict[str, Any]], bool | None],
        target_parent: str | list[str],
        path: str | None = None,
        is_folder: bool | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        复制文件/目录（支持单个和批量操作）

        两种模式：
        1. 单个复制 (path=None):
           - source: 源文件绝对路径，如 "/文档/源文件.txt"
           - target_parent: 目标目录的绝对路径或ID
        2. 批量复制 (path 设定目录):
           - path: "all" 表示整个网盘，"/" 表示根目录，"/目录" 表示指定目录
           - source: 匹配回调函数
           - target_parent: 目标目录的绝对路径或ID，或多个目录的列表

        Args:
            source: 源文件路径或匹配回调函数
            target_parent: 目标父目录（绝对路径或ID），批量模式支持列表
            path: 操作目录 (None=单个模式, "all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (仅批量模式有效)
                      - True: 仅匹配目录
                      - False: 仅匹配文件
                      - None: 不限定类型
            on_exists: 同名文件冲突处理策略 (默认 SKIP)
                      - CloudFileExistsStrategy.SKIP: 跳过（不处理）
                      - CloudFileExistsStrategy.RENAME: 重命名（如 xxx (1).txt）
                      - CloudFileExistsStrategy.OVERWRITE: 覆盖
                      - CloudFileExistsStrategy.ABORT_ALL: 预检查，有冲突则全部不执行
                      - CloudFileExistsStrategy.ABORT_LOCAL: 有冲突则只跳过该项
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            单个模式: 操作结果字典
            {
                "success": bool,
                "type": str,
                "name": str,
                "id": str,
                "source_parent_id": str,
                "target_parent_id": str,
                "target_path": str,
                "message": str,
            }
            批量模式: 操作结果列表

        Examples:
            # 单个复制
            result = await cloud.copy("/文档/源文件.txt", "/备份")

            # 单个复制 - 获取真实路径
            result = await cloud.copy("/文档/源文件.txt", "/备份", get_actual_path=True)

            # 批量复制 - 复制所有txt文件到指定目录
            results = await cloud.copy(
                source=lambda f: f.get("name", "").endswith(".txt"),
                target_parent="/备份",
                path="/文档"
            )

            # 批量复制 - 复制整个网盘中的目录到指定位置
            results = await cloud.copy(
                source=lambda f: f.get("kind", "") == "drive#folder",
                target_parent="/备份",
                path="all",
                is_folder=True
            )
        """
        try:
            if path is None and not isinstance(target_parent, list):
                return await self._copy_single(source, target_parent, on_exists, get_actual_path)
            elif isinstance(target_parent, list) and isinstance(source, str):
                source_info = await self.get_file_info(source)
                if not source_info:
                    return {
                        "success": False,
                        "type": None,
                        "name": source,
                        "id": "",
                        "source_parent_id": "",
                        "target_parent_id": "",
                        "message": f"源文件不存在: {source}",
                    }
                return await self._copy_batch(
                    lambda f: f.get("id") == source_info.get("id"),
                    target_parent,
                    "/",
                    None,
                    on_exists,
                    get_actual_path,
                )
            else:
                return await self._copy_batch(
                    source, target_parent, path, is_folder, on_exists, get_actual_path
                )

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"复制时发生错误: {str(e)}")
            return {
                "success": False,
                "type": None,
                "name": "",
                "id": "",
                "source_parent_id": "",
                "target_parent_id": "",
                "message": f"复制失败: {str(e)}",
            }

    async def _copy_single(  # noqa: C901
        self,
        source: str,
        target_parent: str,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> dict[str, Any]:
        """
        单个复制

        Args:
            source: 源文件绝对路径
            target_parent: 目标父目录路径或ID
            on_exists: 同名文件冲突处理策略
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            操作结果字典
        """
        if not source.startswith("/"):
            return {
                "success": False,
                "type": None,
                "name": "",
                "id": "",
                "source_parent_id": "",
                "target_parent_id": "",
                "message": "单个复制模式: source 必须是绝对路径，以 / 开头",
            }

        source_info = await self.get_file_info(source)
        if not source_info:
            return {
                "success": False,
                "type": None,
                "name": "",
                "id": "",
                "source_parent_id": "",
                "target_parent_id": "",
                "message": f"源文件/目录不存在: {source}",
            }

        source_id = source_info.get("id", "")
        item_kind = source_info.get("kind", "")
        item_type = "folder" if item_kind == "drive#folder" else "file"
        source_name = source_info.get("name", "")
        source_parent_id = source_info.get("parent_id", "")

        target_parent_id = await self._resolve_target_parent_id(target_parent)
        if target_parent_id is None:
            return {
                "success": False,
                "type": item_type,
                "name": source_name,
                "id": source_id,
                "source_parent_id": source_parent_id,
                "target_parent_id": "",
                "message": f"目标目录不存在: {target_parent}",
            }

        target_path = target_parent if target_parent != "/" else "/"
        exists_result = await self.exists(
            source_name, path=target_path, is_folder=item_type == "folder"
        )
        duplicate_exists = exists_result.get("exists", False)

        if duplicate_exists:
            if on_exists == CloudFileExistsStrategy.SKIP:
                return {
                    "success": "skip",
                    "type": item_type,
                    "name": source_name,
                    "id": source_id,
                    "source_parent_id": source_parent_id,
                    "target_parent_id": target_parent_id,
                    "target_path": target_parent.rstrip("/") + "/" + source_name
                    if target_parent != "/"
                    else "/" + source_name,
                    "message": f"目标目录已存在同名{item_type}: '{source_name}'，已跳过",
                }
            elif on_exists == CloudFileExistsStrategy.RENAME:
                pass
            elif on_exists == CloudFileExistsStrategy.OVERWRITE:
                pass

        resp = await self.post(
            f"{self.config.files_url}:batchCopy",
            json={
                "ids": [source_id],
                "to": {"parent_id": target_parent_id, "space": ""},
                "space": "",
            },
        )

        if resp is not None:
            actual_name = source_name
            if duplicate_exists and on_exists in (
                CloudFileExistsStrategy.RENAME,
                CloudFileExistsStrategy.OVERWRITE,
            ):
                target_files = await self.get_files(target_parent_id)
                for tf in target_files:
                    if tf.get("parent_id") == target_parent_id and source_name.split(".")[
                        0
                    ] in tf.get("name", ""):
                        actual_name = tf.get("name", "")
                        break
            if get_actual_path:
                copied_file = await self.get_file_info_by_id(source_id)
                if copied_file:
                    actual_name = copied_file.get("name", actual_name)
                    target_path = await self._build_path(target_parent_id, copied_file)
                else:
                    target_path = (
                        "/" + actual_name
                        if target_parent == "/"
                        else target_parent.rstrip("/") + "/" + actual_name
                    )
            else:
                target_path = (
                    "/" + actual_name
                    if target_parent == "/"
                    else target_parent.rstrip("/") + "/" + actual_name
                )
            return {
                "success": True,
                "type": item_type,
                "name": actual_name,
                "id": source_id,
                "source_parent_id": source_parent_id,
                "target_parent_id": target_parent_id,
                "target_path": target_path,
                "message": f"成功复制 {item_type} '{actual_name}' 到 '{target_path}'",
            }
        else:
            return {
                "success": False,
                "type": item_type,
                "name": source_name,
                "id": source_id,
                "source_parent_id": source_parent_id,
                "target_parent_id": target_parent_id,
                "target_path": "",
                "message": "复制失败",
            }

    async def _copy_batch(  # noqa: C901
        self,
        source: Callable[[dict[str, Any]], bool | None],
        target_parent: str | list[str],
        path: str,
        is_folder: bool | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> list[dict[str, Any]]:
        """
        批量复制（支持多个目标目录）

        Args:
            source: 匹配回调函数
            target_parent: 目标父目录路径或ID，或其列表
            path: 搜索目录 ("all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (True=仅目录, False=仅文件, None=不限)
            on_exists: 同名文件冲突处理策略
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            操作结果列表
        """
        search_path = None if path == "all" else path

        target_parent_ids = await self._resolve_target_parent_ids(target_parent)
        if not target_parent_ids:
            return [
                {
                    "success": False,
                    "type": None,
                    "name": "",
                    "id": "",
                    "source_parent_id": "",
                    "target_parent_id": "",
                    "message": f"目标目录不存在: {target_parent}",
                }
            ]

        files = await self.search(callback=source, path=search_path, is_folder=is_folder, raw=True)
        results: list[dict[str, Any]] = []

        if on_exists == CloudFileExistsStrategy.ABORT_ALL:
            conflicts: list[str] = []
            for file_info in files:
                file_name = file_info.get("name", "")
                item_kind = file_info.get("kind", "")
                item_type = "folder" if item_kind == "drive#folder" else "file"
                for target_id in target_parent_ids:
                    target_path = (
                        target_parent
                        if isinstance(target_parent, str)
                        else target_parent[target_parent_ids.index(target_id)]
                        if target_id in target_parent_ids
                        else target_id
                    )
                    check_path = target_path if target_path != "/" else "/"
                    exists_result = await self.exists(
                        file_name, path=check_path, is_folder=item_type == "folder"
                    )
                    if exists_result.get("exists", False):
                        conflicts.append(f"{item_type} '{file_name}' -> '{target_path}'")
            if conflicts:
                conflict_msg = "; ".join(conflicts[:5])
                if len(conflicts) > 5:
                    conflict_msg += f"... 等 {len(conflicts)} 个冲突"
                return [
                    {
                        "success": False,
                        "type": None,
                        "name": "",
                        "id": "",
                        "source_parent_id": "",
                        "target_parent_id": "",
                        "message": (
                            f"存在 {len(conflicts)} 个冲突文件，"
                            f"ABORT_ALL 中止全部操作: {conflict_msg}"
                        ),
                    }
                ]

        for file_info in files:
            file_id = file_info.get("id", "")
            item_kind = file_info.get("kind", "")
            item_type = "folder" if item_kind == "drive#folder" else "file"
            file_name = file_info.get("name", "")
            file_source_parent_id = file_info.get("parent_id", "")

            for target_id in target_parent_ids:
                target_path = (
                    target_parent
                    if isinstance(target_parent, str)
                    else target_parent[target_parent_ids.index(target_id)]
                    if target_id in target_parent_ids
                    else target_id
                )
                check_path = target_path if target_path != "/" else "/"
                exists_result = await self.exists(
                    file_name, path=check_path, is_folder=item_type == "folder"
                )
                duplicate_exists = exists_result.get("exists", False)

                if duplicate_exists:
                    if on_exists == CloudFileExistsStrategy.SKIP:
                        results.append(
                            {
                                "success": "skip",
                                "type": item_type,
                                "name": file_name,
                                "id": file_id,
                                "source_parent_id": file_source_parent_id,
                                "target_parent_id": target_id,
                                "target_path": target_path.rstrip("/") + "/" + file_name
                                if target_path != "/"
                                else "/" + file_name,
                                "message": f"目标目录已存在同名{item_type}: '{file_name}'，已跳过",
                            }
                        )
                        continue
                    elif on_exists == CloudFileExistsStrategy.ABORT_LOCAL:
                        results.append(
                            {
                                "success": "abort_local",
                                "type": item_type,
                                "name": file_name,
                                "id": file_id,
                                "source_parent_id": file_source_parent_id,
                                "target_parent_id": target_id,
                                "target_path": target_path.rstrip("/") + "/" + file_name
                                if target_path != "/"
                                else "/" + file_name,
                                "message": (
                                    f"目标目录已存在同名{item_type}: "
                                    f"'{file_name}'，ABORT_LOCAL 中止此操作"
                                ),
                            }
                        )
                        continue
                    elif on_exists == CloudFileExistsStrategy.RENAME:
                        pass
                    elif on_exists == CloudFileExistsStrategy.OVERWRITE:
                        pass

                resp = await self.post(
                    f"{self.config.files_url}:batchCopy",
                    json={
                        "ids": [file_id],
                        "to": {"parent_id": target_id, "space": ""},
                        "space": "",
                    },
                )

                target_path = (
                    target_parent
                    if isinstance(target_parent, str)
                    else target_parent[target_parent_ids.index(target_id)]
                    if target_id in target_parent_ids
                    else target_id
                )

                if resp is not None:
                    actual_name = file_name
                    if duplicate_exists and on_exists in (
                        CloudFileExistsStrategy.RENAME,
                        CloudFileExistsStrategy.OVERWRITE,
                    ):
                        target_files = await self.get_files(target_id)
                        name_prefix = file_name.split(".")[0] if "." in file_name else file_name
                        for tf in target_files:
                            if tf.get("parent_id") == target_id and name_prefix in tf.get(
                                "name", ""
                            ):
                                actual_name = tf.get("name", "")
                                break
                    if get_actual_path:
                        copied_file = await self.get_file_info_by_id(file_id)
                        if copied_file:
                            actual_name = copied_file.get("name", actual_name)
                            full_path = await self._build_path(target_id, copied_file)
                        else:
                            full_path = (
                                target_path.rstrip("/") + "/" + actual_name
                                if target_path != "/"
                                else "/" + actual_name
                            )
                    else:
                        full_path = (
                            target_path.rstrip("/") + "/" + actual_name
                            if target_path != "/"
                            else "/" + actual_name
                        )
                    results.append(
                        {
                            "success": True,
                            "type": item_type,
                            "name": actual_name,
                            "id": file_id,
                            "source_parent_id": file_source_parent_id,
                            "target_parent_id": target_id,
                            "target_path": full_path,
                            "message": f"成功复制 {item_type} '{actual_name}' 到 '{full_path}'",
                        }
                    )
                else:
                    results.append(
                        {
                            "success": False,
                            "type": item_type,
                            "name": file_name,
                            "id": file_id,
                            "source_parent_id": file_source_parent_id,
                            "target_parent_id": target_id,
                            "target_path": "",
                            "message": f"复制 {item_type} '{file_name}' 失败",
                        }
                    )

        return results

    async def _resolve_target_parent_id(self, target_parent: str) -> str | None:
        """
        解析单个目标父目录ID

        Args:
            target_parent: 目标父目录路径或ID

        Returns:
            目标父目录ID，如果不存在则返回None
        """
        if not target_parent:
            return None

        if target_parent == "/":
            return ""

        if target_parent.startswith("/"):
            parent_info = await self.get_file_info(target_parent)
            if parent_info:
                return parent_info.get("id")
            return None

        return target_parent

    async def _resolve_target_parent_ids(self, target_parent: str | list[str]) -> list[str]:
        """
        解析目标父目录ID（支持单个或多个目录）

        Args:
            target_parent: 目标父目录路径或ID，或其列表

        Returns:
            目标父目录ID列表
        """
        if isinstance(target_parent, str):
            target_parent = [target_parent]

        result: list[str] = []
        for tp in target_parent:
            if not tp:
                continue

            if tp == "/":
                result.append("")
                continue

            if tp.startswith("/"):
                parent_info = await self.get_file_info(tp)
                if parent_info:
                    result.append(parent_info.get("id", ""))
            else:
                result.append(tp)

        return result

    async def move(
        self,
        source: str | Callable[[dict[str, Any]], bool | None],
        target_parent: str,
        path: str | None = None,
        is_folder: bool | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        移动文件/目录（支持单个和批量操作）

        两种模式：
        1. 单个移动 (path=None):
           - source: 源文件绝对路径，如 "/文档/源文件.txt"
           - target_parent: 目标目录的绝对路径或ID
        2. 批量移动 (path 设定目录):
           - path: "all" 表示整个网盘，"/" 表示根目录，"/目录" 表示指定目录
           - source: 匹配回调函数
           - target_parent: 目标目录的绝对路径或ID

        Args:
            source: 源文件路径或匹配回调函数
            target_parent: 目标父目录（绝对路径或ID）
            path: 操作目录 (None=单个模式, "all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (仅批量模式有效)
                      - True: 仅匹配目录
                      - False: 仅匹配文件
                      - None: 不限定类型
            on_exists: 同名文件冲突处理策略 (默认 SKIP)
                      - CloudFileExistsStrategy.SKIP: 跳过（不处理）
                      - CloudFileExistsStrategy.RENAME: 重命名（如 xxx (1).txt）
                      - CloudFileExistsStrategy.OVERWRITE: 覆盖
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            单个模式: 操作结果字典
            {
                "success": bool,
                "type": str,
                "name": str,
                "id": str,
                "old_parent_id": str,
                "new_parent_id": str,
                "target_path": str,
                "message": str,
            }
            批量模式: 操作结果列表

        Examples:
            # 单个移动
            result = await cloud.move("/文档/文件.txt", "/备份")

            # 单个移动 - 获取真实路径
            result = await cloud.move("/文档/文件.txt", "/备份", get_actual_path=True)

            # 批量移动 - 移动所有txt文件到指定目录
            results = await cloud.move(
                source=lambda f: f.get("name", "").endswith(".txt"),
                target_parent="/备份",
                path="/文档"
            )

            # 批量移动 - 移动整个网盘中的目录到指定位置
            results = await cloud.move(
                source=lambda f: f.get("kind", "") == "drive#folder",
                target_parent="/备份",
                path="all",
                is_folder=True
            )
        """
        try:
            if path is None:
                return await self._move_single(source, target_parent, on_exists, get_actual_path)
            else:
                return await self._move_batch(
                    source, target_parent, path, is_folder, on_exists, get_actual_path
                )

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"移动时发生错误: {str(e)}")
            return {
                "success": False,
                "type": None,
                "name": "",
                "id": "",
                "old_parent_id": "",
                "new_parent_id": "",
                "message": f"移动失败: {str(e)}",
            }

    async def _move_single(  # noqa: C901
        self,
        source: str,
        target_parent: str,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> dict[str, Any]:
        """
        单个移动

        Args:
            source: 源文件绝对路径
            target_parent: 目标父目录路径或ID
            on_exists: 同名文件冲突处理策略
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            操作结果字典
        """
        if not source.startswith("/"):
            return {
                "success": False,
                "type": None,
                "name": "",
                "id": "",
                "old_parent_id": "",
                "new_parent_id": "",
                "message": "单个移动模式: source 必须是绝对路径，以 / 开头",
            }

        source_info = await self.get_file_info(source)
        if not source_info:
            return {
                "success": False,
                "type": None,
                "name": "",
                "id": "",
                "old_parent_id": "",
                "new_parent_id": "",
                "message": f"源文件/目录不存在: {source}",
            }

        source_id = source_info.get("id", "")
        item_kind = source_info.get("kind", "")
        item_type = "folder" if item_kind == "drive#folder" else "file"
        source_name = source_info.get("name", "")
        old_parent_id = source_info.get("parent_id", "")

        target_parent_id = await self._resolve_target_parent_id(target_parent)
        if target_parent_id is None:
            return {
                "success": False,
                "type": item_type,
                "name": source_name,
                "id": source_id,
                "old_parent_id": old_parent_id,
                "new_parent_id": "",
                "message": f"目标目录不存在: {target_parent}",
            }

        target_path = target_parent if target_parent != "/" else "/"
        exists_result = await self.exists(
            source_name, path=target_path, is_folder=item_type == "folder"
        )
        duplicate_exists = exists_result.get("exists", False)

        if duplicate_exists:
            if on_exists == CloudFileExistsStrategy.SKIP:
                return {
                    "success": "skip",
                    "type": item_type,
                    "name": source_name,
                    "id": source_id,
                    "old_parent_id": old_parent_id,
                    "new_parent_id": target_parent_id,
                    "target_path": target_parent.rstrip("/") + "/" + source_name
                    if target_parent != "/"
                    else "/" + source_name,
                    "message": f"目标目录已存在同名{item_type}: '{source_name}'，已跳过",
                }
            elif on_exists == CloudFileExistsStrategy.RENAME:
                pass
            elif on_exists == CloudFileExistsStrategy.OVERWRITE:
                pass

        resp = await self.post(
            f"{self.config.files_url}:batchMove",
            json={
                "ids": [source_id],
                "to": {"parent_id": target_parent_id, "space": ""},
                "space": "",
            },
        )

        if resp is not None:
            actual_name = source_name
            if duplicate_exists and on_exists in (
                CloudFileExistsStrategy.RENAME,
                CloudFileExistsStrategy.OVERWRITE,
            ):
                target_files = await self.get_files(target_parent_id)
                for tf in target_files:
                    if tf.get("parent_id") == target_parent_id and source_name.split(".")[
                        0
                    ] in tf.get("name", ""):
                        actual_name = tf.get("name", "")
                        break
            if get_actual_path:
                moved_file = await self.get_file_info_by_id(source_id)
                if moved_file:
                    actual_name = moved_file.get("name", actual_name)
                    target_path = await self._build_path(target_parent_id, moved_file)
                else:
                    if target_parent == "/":
                        target_path = "/" + actual_name
                    else:
                        target_path = target_parent.rstrip("/") + "/" + actual_name
            else:
                if target_parent == "/":
                    target_path = "/" + actual_name
                else:
                    target_path = target_parent.rstrip("/") + "/" + actual_name
            return {
                "success": True,
                "type": item_type,
                "name": actual_name,
                "id": source_id,
                "old_parent_id": old_parent_id,
                "new_parent_id": target_parent_id,
                "target_path": target_path,
                "message": f"成功移动 {item_type} '{actual_name}' 到 '{target_path}'",
            }
        else:
            return {
                "success": False,
                "type": item_type,
                "name": source_name,
                "id": source_id,
                "old_parent_id": old_parent_id,
                "new_parent_id": target_parent_id,
                "target_path": "",
                "message": "移动失败",
            }

    async def _move_batch(  # noqa: C901
        self,
        source: Callable[[dict[str, Any]], bool | None],
        target_parent: str,
        path: str,
        is_folder: bool | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> list[dict[str, Any]]:
        """
        批量移动

        Args:
            source: 匹配回调函数
            target_parent: 目标父目录路径或ID
            path: 搜索目录 ("all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (True=仅目录, False=仅文件, None=不限)
            on_exists: 同名文件冲突处理策略
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            操作结果列表
        """
        search_path = None if path == "all" else path

        target_parent_id = await self._resolve_target_parent_id(target_parent)
        if target_parent_id is None:
            return [
                {
                    "success": False,
                    "type": None,
                    "name": "",
                    "id": "",
                    "old_parent_id": "",
                    "new_parent_id": "",
                    "message": f"目标目录不存在: {target_parent}",
                }
            ]

        files = await self.search(callback=source, path=search_path, is_folder=is_folder, raw=True)
        results: list[dict[str, Any]] = []

        if on_exists == CloudFileExistsStrategy.ABORT_ALL:
            conflicts: list[str] = []
            for file_info in files:
                file_name = file_info.get("name", "")
                item_kind = file_info.get("kind", "")
                item_type = "folder" if item_kind == "drive#folder" else "file"
                check_path = target_parent if target_parent != "/" else "/"
                exists_result = await self.exists(
                    file_name, path=check_path, is_folder=item_type == "folder"
                )
                if exists_result.get("exists", False):
                    conflicts.append(f"{item_type} '{file_name}' -> '{target_parent}'")
            if conflicts:
                conflict_msg = "; ".join(conflicts[:5])
                if len(conflicts) > 5:
                    conflict_msg += f"... 等 {len(conflicts)} 个冲突"
                return [
                    {
                        "success": False,
                        "type": None,
                        "name": "",
                        "id": "",
                        "old_parent_id": "",
                        "new_parent_id": "",
                        "message": (
                            f"存在 {len(conflicts)} 个冲突文件，"
                            f"ABORT_ALL 中止全部操作: {conflict_msg}"
                        ),
                    }
                ]

        for file_info in files:
            file_id = file_info.get("id", "")
            item_kind = file_info.get("kind", "")
            item_type = "folder" if item_kind == "drive#folder" else "file"
            file_name = file_info.get("name", "")
            old_parent_id = file_info.get("parent_id", "")

            check_path = target_parent if target_parent != "/" else "/"
            exists_result = await self.exists(
                file_name, path=check_path, is_folder=item_type == "folder"
            )
            duplicate_exists = exists_result.get("exists", False)

            if duplicate_exists:
                if on_exists == CloudFileExistsStrategy.SKIP:
                    results.append(
                        {
                            "success": "skip",
                            "type": item_type,
                            "name": file_name,
                            "id": file_id,
                            "old_parent_id": old_parent_id,
                            "new_parent_id": target_parent_id,
                            "target_path": target_parent.rstrip("/") + "/" + file_name
                            if target_parent != "/"
                            else "/" + file_name,
                            "message": f"目标目录已存在同名{item_type}: '{file_name}'，已跳过",
                        }
                    )
                    continue
                elif on_exists == CloudFileExistsStrategy.ABORT_LOCAL:
                    results.append(
                        {
                            "success": "abort_local",
                            "type": item_type,
                            "name": file_name,
                            "id": file_id,
                            "old_parent_id": old_parent_id,
                            "new_parent_id": target_parent_id,
                            "target_path": target_parent.rstrip("/") + "/" + file_name
                            if target_parent != "/"
                            else "/" + file_name,
                            "message": (
                                f"目标目录已存在同名{item_type}: "
                                f"'{file_name}'，ABORT_LOCAL 中止此操作"
                            ),
                        }
                    )
                    continue
                elif on_exists == CloudFileExistsStrategy.RENAME:
                    pass
                elif on_exists == CloudFileExistsStrategy.OVERWRITE:
                    pass

            resp = await self.post(
                f"{self.config.files_url}:batchMove",
                json={
                    "ids": [file_id],
                    "to": {"parent_id": target_parent_id, "space": ""},
                    "space": "",
                },
            )

            if resp is not None:
                actual_name = file_name
                if duplicate_exists and on_exists in (
                    CloudFileExistsStrategy.RENAME,
                    CloudFileExistsStrategy.OVERWRITE,
                ):
                    target_files = await self.get_files(target_parent_id)
                    name_prefix = file_name.split(".")[0] if "." in file_name else file_name
                    for tf in target_files:
                        if tf.get("parent_id") == target_parent_id and name_prefix in tf.get(
                            "name", ""
                        ):
                            actual_name = tf.get("name", "")
                            break
                if get_actual_path:
                    moved_file = await self.get_file_info_by_id(file_id)
                    if moved_file:
                        actual_name = moved_file.get("name", actual_name)
                        full_path = await self._build_path(target_parent_id, moved_file)
                    else:
                        full_path = (
                            target_parent.rstrip("/") + "/" + actual_name
                            if target_parent != "/"
                            else "/" + actual_name
                        )
                else:
                    full_path = (
                        target_parent.rstrip("/") + "/" + actual_name
                        if target_parent != "/"
                        else "/" + actual_name
                    )
                results.append(
                    {
                        "success": True,
                        "type": item_type,
                        "name": actual_name,
                        "id": file_id,
                        "old_parent_id": old_parent_id,
                        "new_parent_id": target_parent_id,
                        "target_path": full_path,
                        "message": f"成功移动 {item_type} '{actual_name}' 到 '{full_path}'",
                    }
                )
            else:
                results.append(
                    {
                        "success": False,
                        "type": item_type,
                        "name": file_name,
                        "id": file_id,
                        "old_parent_id": old_parent_id,
                        "new_parent_id": target_parent_id,
                        "target_path": "",
                        "message": f"移动 {item_type} '{file_name}' 失败",
                    }
                )

        return results

    async def _delete_by_id(self, file_id: str, permanent: bool = False) -> bool:
        """
        根据ID删除文件/目录（内部方法）

        Args:
            file_id: 文件/目录 ID
            permanent: 是否永久删除

        Returns:
            是否成功
        """
        if permanent:
            resp = await self.post(
                f"{self.config.files_url}:batchDelete",
                json={"ids": [file_id], "space": ""},
            )
        else:
            resp = await self.patch(
                f"{self.config.files_url}/{file_id}/trash",
                json={},
            )
        return resp is not None

    async def delete_folder(
        self, target: str, permanent: bool = False, include_raw: bool = False
    ) -> dict[str, Any]:
        """
        删除目录（支持ID和路径两种方式）

        Args:
            target: 目录ID或完整路径 (例如: '/我的文档/旧项目' 或 '目录ID')
            permanent: 是否永久删除 (默认: False)
                              False = 移到回收站 (安全删除)
                              True = 永久删除 (不可恢复)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool,           # 操作是否成功
                "folder_id": str,          # 被删除的文件夹ID
                "folder_name": str,        # 被删除的文件夹名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        if "/" in target or target.startswith("/"):
            return await self.delete_folder_by_path(target, permanent, include_raw)

        folder_info = await self.get_file_info_by_id(target)
        if not folder_info:
            result = {
                "success": False,
                "folder_id": target,
                "folder_name": "",
                "parent_id": "",
                "message": f"目录不存在: {target}",
            }
            if include_raw:
                result["raw"] = None
            return result

        if folder_info.get("kind") != "drive#folder":
            result = {
                "success": False,
                "folder_id": target,
                "folder_name": folder_info.get("name", ""),
                "parent_id": folder_info.get("parent_id", ""),
                "message": f"路径不是一个目录: {target}",
            }
            if include_raw:
                result["raw"] = folder_info
            return result

        delete_success = await self._delete_by_id(target, permanent=permanent)
        if delete_success:
            action = "永久删除" if permanent else "移到回收站"
            result = {
                "success": True,
                "folder_id": folder_info.get("id", target),
                "folder_name": folder_info.get("name", ""),
                "parent_id": folder_info.get("parent_id", ""),
                "message": f"成功{action}目录: {folder_info.get('name', target)}",
            }
            if include_raw:
                result["raw"] = folder_info
            return result
        else:
            result = {
                "success": False,
                "folder_id": target,
                "folder_name": folder_info.get("name", ""),
                "parent_id": folder_info.get("parent_id", ""),
                "message": f"删除目录失败: {folder_info.get('name', target)}",
            }
            if include_raw:
                result["raw"] = folder_info
            return result

    async def delete_folder_by_path(
        self, folder_path: str, permanent: bool = False, include_raw: bool = False
    ) -> dict[str, Any]:
        """
        通过完整路径删除目录

        Args:
            folder_path: 完整目录路径, 如 "/我的文件/子目录"
                        注意: 以 '/' 开头表示从根目录开始的绝对路径
                        不以 '/' 开头表示相对于当前位置的相对路径
            permanent: 是否永久删除 (False=移到回收站, True=永久删除)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool,           # 操作是否成功
                "folder_id": str,          # 被删除的文件夹ID
                "folder_name": str,        # 被删除的文件夹名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        try:
            validation = await self._validate_folder_for_deletion(folder_path)
            if not validation["valid"]:
                result = {
                    "success": False,
                    "folder_id": "",
                    "folder_name": "",
                    "parent_id": "",
                    "message": validation["message"],
                }
                if include_raw:
                    result["raw"] = validation.get("raw")
                return result

            folder_info = validation["folder_info"]
            delete_success = await self._delete_by_id(folder_info["id"], permanent=permanent)
            action = "永久删除" if permanent else "移到回收站"

            if delete_success:
                result = {
                    "success": True,
                    "folder_id": folder_info["id"],
                    "folder_name": folder_info.get("name", ""),
                    "parent_id": folder_info.get("parent_id", ""),
                    "message": f"成功{action}目录: {folder_info.get('name', folder_path)}",
                }
            else:
                result = {
                    "success": False,
                    "folder_id": folder_info["id"],
                    "folder_name": folder_info.get("name", ""),
                    "parent_id": folder_info.get("parent_id", ""),
                    "message": f"删除目录失败: {folder_info.get('name', folder_path)}",
                }

            if include_raw:
                result["raw"] = folder_info
            return result

        except Exception as e:
            logger.error(f"删除目录路径时发生错误: {str(e)}")
            result = {
                "success": False,
                "folder_id": "",
                "folder_name": "",
                "parent_id": "",
                "message": f"删除目录时发生错误: {str(e)}",
            }
            if include_raw:
                result["raw"] = None
            return result

    async def _validate_folder_for_deletion(self, folder_path: str) -> dict[str, Any]:
        """验证文件夹路径并返回文件夹信息"""
        if folder_path == "/":
            return {"valid": False, "message": "无法删除根目录"}

        if folder_path.startswith("/"):
            folder_path = folder_path[1:]

        if not folder_path:
            return {"valid": False, "message": "路径不能为空"}

        folder_info = await self.get_file_info(f"/{folder_path}")
        if not folder_info:
            return {"valid": False, "message": f"目录不存在: {folder_path}"}

        if folder_info.get("kind") != "drive#folder":
            return {
                "valid": False,
                "message": f"路径不是一个目录: {folder_path}",
                "folder_info": folder_info,
            }

        if not folder_info.get("id"):
            return {
                "valid": False,
                "message": f"无法获取目录ID: {folder_path}",
                "folder_info": folder_info,
            }

        return {"valid": True, "folder_info": folder_info}

    async def delete_file(
        self, target: str, permanent: bool = False, include_raw: bool = False
    ) -> dict[str, Any]:
        """
        删除文件（支持ID和路径两种方式）

        Args:
            target: 文件ID或完整路径 (例如: '/我的文档/文件.txt' 或 '文件ID')
            permanent: 是否永久删除 (默认: False)
                              False = 移到回收站 (安全删除)
                              True = 永久删除 (不可恢复)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool,           # 操作是否成功
                "file_id": str,            # 被删除的文件ID
                "file_name": str,          # 被删除的文件名称
                "parent_id": str,          # 父目录ID
                "message": str,             # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        if "/" in target or target.startswith("/"):
            return await self.delete_file_by_path(target, permanent, include_raw)

        file_info = await self.get_file_info_by_id(target)
        if not file_info:
            result = {
                "success": False,
                "file_id": target,
                "file_name": "",
                "parent_id": "",
                "message": f"文件不存在: {target}",
            }
            if include_raw:
                result["raw"] = None
            return result

        if file_info.get("kind") == "drive#folder":
            result = {
                "success": False,
                "file_id": target,
                "file_name": file_info.get("name", ""),
                "parent_id": file_info.get("parent_id", ""),
                "message": f"路径是一个目录而非文件: {target}",
            }
            if include_raw:
                result["raw"] = file_info
            return result

        delete_success = await self._delete_by_id(target, permanent=permanent)
        if delete_success:
            action = "永久删除" if permanent else "移到回收站"
            result = {
                "success": True,
                "file_id": file_info.get("id", target),
                "file_name": file_info.get("name", ""),
                "parent_id": file_info.get("parent_id", ""),
                "message": f"成功{action}文件: {file_info.get('name', target)}",
            }
            if include_raw:
                result["raw"] = file_info
            return result
        else:
            result = {
                "success": False,
                "file_id": target,
                "file_name": file_info.get("name", ""),
                "parent_id": file_info.get("parent_id", ""),
                "message": f"删除文件失败: {file_info.get('name', target)}",
            }
            if include_raw:
                result["raw"] = file_info
            return result

    async def delete_file_by_path(
        self, file_path: str, permanent: bool = False, include_raw: bool = False
    ) -> dict[str, Any]:
        """
        通过完整路径删除文件

        Args:
            file_path: 完整文件路径, 如 "/我的文件/文档.txt"
                        注意: 以 '/' 开头表示从根目录开始的绝对路径
                        不以 '/' 开头表示相对于当前位置的相对路径
            permanent: 是否永久删除 (False=移到回收站, True=永久删除)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool,           # 操作是否成功
                "file_id": str,            # 被删除的文件ID
                "file_name": str,          # 被删除的文件名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        try:
            validation = await self._validate_file_for_deletion(file_path)
            if not validation["valid"]:
                result = {
                    "success": False,
                    "file_id": "",
                    "file_name": "",
                    "parent_id": "",
                    "message": validation["message"],
                }
                if include_raw:
                    result["raw"] = validation.get("raw")
                return result

            file_info = validation["file_info"]
            delete_success = await self._delete_by_id(file_info["id"], permanent=permanent)
            action = "永久删除" if permanent else "移到回收站"

            if delete_success:
                result = {
                    "success": True,
                    "file_id": file_info["id"],
                    "file_name": file_info.get("name", ""),
                    "parent_id": file_info.get("parent_id", ""),
                    "message": f"成功{action}文件: {file_info.get('name', file_path)}",
                }
            else:
                result = {
                    "success": False,
                    "file_id": file_info["id"],
                    "file_name": file_info.get("name", ""),
                    "parent_id": file_info.get("parent_id", ""),
                    "message": f"删除文件失败: {file_info.get('name', file_path)}",
                }

            if include_raw:
                result["raw"] = file_info
            return result

        except Exception as e:
            logger.error(f"删除文件路径时发生错误: {str(e)}")
            result = {
                "success": False,
                "file_id": "",
                "file_name": "",
                "parent_id": "",
                "message": f"删除文件时发生错误: {str(e)}",
            }
            if include_raw:
                result["raw"] = None
            return result

    async def delete(
        self, target: str, permanent: bool = False, include_raw: bool = False
    ) -> dict[str, Any]:
        """
        删除文件或目录（自动识别类型）

        Args:
            target: 文件/目录ID或完整路径 (例如: '/我的文档/文件.txt' 或 '目录ID')
            permanent: 是否永久删除 (默认: False)
                              False = 移到回收站 (安全删除)
                              True = 永久删除 (不可恢复)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool | str,   # 操作结果 (True=成功, "not_found"=不存在, False=失败)
                "type": str,               # 操作对象的类型 ("file" 或 "folder")
                "id": str,                 # 被删除的文件/目录ID
                "name": str,               # 被删除的文件/目录名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        is_path = "/" in target or target.startswith("/")

        if is_path:
            file_info = await self.get_file_info(f"/{target.lstrip('/')}")
        else:
            file_info = await self.get_file_info_by_id(target)

        if not file_info:
            result = {
                "success": "not_found",
                "type": "",
                "id": target,
                "name": "",
                "parent_id": "",
                "message": f"路径不存在: {target}",
            }
            if include_raw:
                result["raw"] = None
            return result

        item_id = file_info.get("id", target)
        name = file_info.get("name", "")
        parent_id = file_info.get("parent_id", "")
        kind = file_info.get("kind", "")

        if kind == "drive#folder":
            delete_success = await self._delete_by_id(item_id, permanent=permanent)
            action = "永久删除" if permanent else "移到回收站"
            if delete_success:
                result = {
                    "success": True,
                    "type": "folder",
                    "id": item_id,
                    "name": name,
                    "parent_id": parent_id,
                    "message": f"成功{action}目录: {name}",
                }
            else:
                result = {
                    "success": False,
                    "type": "folder",
                    "id": item_id,
                    "name": name,
                    "parent_id": parent_id,
                    "message": f"删除目录失败: {name}",
                }
        else:
            delete_success = await self._delete_by_id(item_id, permanent=permanent)
            action = "永久删除" if permanent else "移到回收站"
            if delete_success:
                result = {
                    "success": True,
                    "type": "file",
                    "id": item_id,
                    "name": name,
                    "parent_id": parent_id,
                    "message": f"成功{action}文件: {name}",
                }
            else:
                result = {
                    "success": False,
                    "type": "file",
                    "id": item_id,
                    "name": name,
                    "parent_id": parent_id,
                    "message": f"删除文件失败: {name}",
                }

        if include_raw:
            result["raw"] = file_info
        return result

    async def _validate_file_for_deletion(self, file_path: str) -> dict[str, Any]:
        """验证文件路径并返回文件信息"""
        if file_path.startswith("/"):
            file_path = file_path[1:]

        if not file_path:
            return {"valid": False, "message": "路径不能为空"}

        file_info = await self.get_file_info(f"/{file_path}")
        if not file_info:
            return {"valid": False, "message": f"文件不存在: {file_path}"}

        if file_info.get("kind") == "drive#folder":
            return {
                "valid": False,
                "message": f"路径是一个目录而非文件: {file_path}",
                "file_info": file_info,
            }

        if not file_info.get("id"):
            return {
                "valid": False,
                "message": f"无法获取文件ID: {file_path}",
                "file_info": file_info,
            }

        return {"valid": True, "file_info": file_info}

    async def copy_file(
        self,
        file_id: str,
        target_parent_id: str,
    ) -> bool:
        """
        复制文件/目录

        Args:
            file_id: 文件/目录 ID
            target_parent_id: 目标父目录 ID

        Returns:
            是否成功
        """
        resp = await self.post(
            f"{self.config.files_url}:batchCopy",
            json={
                "ids": [file_id],
                "to": {"parent_id": target_parent_id, "space": ""},
                "space": "",
            },
        )
        return resp is not None

    # ==================== 离线任务 ====================

    async def get_offline_tasks(
        self,
        limit: int = 100,
    ) -> Optional[list[dict[str, Any]]]:
        """获取离线任务列表"""
        resp = await self.get(
            self.config.tasks_url,
            params={
                "limit": str(limit),
                "phaseCheck": "false",
                "page_token": "",
                "type": "offline",
            },
        )
        if resp:
            return resp.get("tasks", [])
        return None

    async def create_offline_task(
        self,
        download_url: str,
        target_parent_id: str = "",
        name: Optional[str] = None,
    ) -> bool:
        """
        创建云添加任务

        Args:
            download_url: 下载链接 (HTTP/Magnet/BT)
            target_parent_id: 保存目标目录 ID
            name: 保存名称

        Returns:
            是否成功
        """
        # 解析种子文件
        if download_url.endswith(".torrent"):
            download_url, _ = await parse_torrent(download_url)

        # 获取 URL 信息
        url_info = await self.get_download_url_info(download_url)
        if not url_info:
            return False

        task_name = name or url_info.get("task_name")
        file_count = int(url_info.get("file_count", 1))
        indices = format_sub_file_index(list(range(file_count)))

        resp = await self.post(
            self.config.files_url,
            json={
                "upload_type": "UPLOAD_TYPE_URL",
                "kind": "drive#file",
                "parent_id": target_parent_id,
                "name": task_name,
                "url": {"url": download_url, "files": indices.split(",")},
            },
        )
        return resp is not None

    async def get_download_url_info(self, url: str) -> Optional[dict[str, Any]]:
        """获取下载链接信息"""
        resp = await self.post(
            self.config.resource_list_url,
            json={"urls": url, "page_size": 2000},
        )
        if not resp:
            return None

        try:
            resources = resp.get("list", {}).get("resources", [{}])[0]
            meta = resources.get("meta", {})
            files = resources.get("dir", {}).get("resources", [])
            return {
                "task_name": resources.get("name"),
                "task_size": resources.get("file_size"),
                "file_count": resources.get("file_count"),
                "files": files,
                "task_url": meta.get("url"),
            }
        except (KeyError, IndexError):
            return None

    # ==================== 文件上传 ====================

    async def _calculate_file_hash(self, file_path: str) -> str:
        """计算文件 SHA1 哈希"""
        sha1 = hashlib.sha1()
        async with aiofiles.open(file_path, "rb") as f:
            while chunk := await f.read(8192):
                sha1.update(chunk)
        return sha1.hexdigest()

    async def _get_upload_params(
        self,
        file_path: str,
        parent_id: str = "",
    ) -> Optional[dict[str, Any]]:
        """获取上传参数"""
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)
        file_hash = await self._calculate_file_hash(file_path)

        resp = await self.post(
            self.config.files_url,
            json={
                "kind": "drive#file",
                "parent_id": parent_id,
                "name": file_name,
                "size": file_size,
                "space": "",
                "hash": file_hash,
                "upload_type": "UPLOAD_TYPE_RESUMABLE"
                if file_size > 1048576
                else "UPLOAD_TYPE_FORM",
            },
        )
        return resp

    async def _upload_form(
        self,
        file_path: str,
        upload_url: str,
        multi_parts: dict[str, str],
    ) -> bool:
        """小文件表单上传"""
        file_name = os.path.basename(file_path)

        async with aiofiles.open(file_path, "rb") as f:
            data = await f.read()

        files_data = {k: (None, v) for k, v in multi_parts.items()}
        files_data["file"] = (file_name, data, "application/octet-stream")

        resp = await self.client.post(upload_url, files=files_data)
        return resp is not None and resp.is_success

    async def _upload_resumable(
        self,
        file_path: str,
        file_size: int,
        params: dict[str, Any],
        progress_callback: Optional[Callable] = None,
        num_threads: int = 4,
        enable_resume: bool = True,
    ) -> bool:
        """
        大文件分片上传 (使用阿里云 OSS)

        Args:
            file_path: 本地文件路径
            file_size: 文件大小
            params: API 返回的上传参数
            progress_callback: 进度回调函数，接收 (已上传字节数, 总字节数)
            num_threads: 并发上传线程数
            enable_resume: 是否启用断点续传

        Returns:
            是否成功
        """
        import io

        import oss2

        resumable = params.get("resumable", {})
        oss_params = resumable.get("params", {})

        # 提取 OSS 配置
        access_key_id = oss_params.get("access_key_id", "")
        access_key_secret = oss_params.get("access_key_secret", "")
        security_token = oss_params.get("security_token", "")
        bucket_name = oss_params.get("bucket", "")
        endpoint = oss_params.get("endpoint", "")
        object_key = oss_params.get("key", "")

        if not all([access_key_id, access_key_secret, bucket_name, endpoint, object_key]):
            logger.error("OSS 参数不完整")
            return False

        # 使用 STS Token 创建认证
        auth = oss2.StsAuth(access_key_id, access_key_secret, security_token)
        bucket = oss2.Bucket(auth, endpoint, bucket_name)

        # 如果启用断点续传，使用 resumable_upload
        if enable_resume:
            return await self._upload_with_resume(
                bucket, file_path, object_key, progress_callback, num_threads
            )

        # 否则使用普通分片上传
        part_size = oss2.determine_part_size(file_size, preferred_size=1048576)
        total_parts = (file_size + part_size - 1) // part_size

        upload_id = bucket.init_multipart_upload(object_key).upload_id

        try:
            uploaded_parts = []

            async with aiofiles.open(file_path, "rb") as f:
                for part_num in range(1, total_parts + 1):
                    size_to_upload = min(part_size, file_size - (part_num - 1) * part_size)
                    chunk_data = await f.read(size_to_upload)

                    part_file = oss2.SizedFileAdapter(io.BytesIO(chunk_data), size_to_upload)
                    result = bucket.upload_part(object_key, upload_id, part_num, part_file)

                    uploaded_parts.append(
                        oss2.models.PartInfo(part_num, result.etag, size=size_to_upload)
                    )

                    uploaded_bytes = min(part_num * part_size, file_size)
                    if progress_callback:
                        progress_callback(uploaded_bytes, file_size)

                    logger.debug(f"已上传分片 {part_num}/{total_parts}")

            bucket.complete_multipart_upload(object_key, upload_id, uploaded_parts)
            logger.info(f"分片上传完成: {file_path}")
            return True

        except Exception as e:
            try:
                bucket.abort_multipart_upload(object_key, upload_id)
            except Exception:
                pass
            logger.error(f"分片上传失败: {e}")
            raise

    async def _upload_with_resume(
        self,
        bucket,
        file_path: str,
        object_key: str,
        progress_callback: Optional[Callable] = None,
        num_threads: int = 4,
    ) -> bool:
        """
        使用 oss2.resumable_upload 进行并发上传和断点续传

        Args:
            bucket: OSS Bucket 对象
            file_path: 本地文件路径
            object_key: OSS 对象 key
            progress_callback: 进度回调
            num_threads: 并发线程数

        Returns:
            是否成功
        """
        import oss2

        # 定义进度回调包装器
        def _progress_wrapper(bytes_consumed, total_bytes):
            if progress_callback:
                progress_callback(bytes_consumed, total_bytes)

        try:
            # 使用 resumable_upload 自动处理并发和断点续传
            # store=None 会使用默认的本地文件系统存储断点
            oss2.resumable_upload(
                bucket,
                object_key,
                file_path,
                store=None,  # 默认使用 ~/.ossutil/cache 存储断点
                part_size=1048576,  # 1MB 分片
                num_threads=num_threads,  # 并发线程数
                progress_callback=_progress_wrapper,
            )
            logger.info(f"并发分片上传完成 (线程数: {num_threads}): {file_path}")
            return True
        except Exception as e:
            logger.error(f"并发分片上传失败: {e}")
            raise

    async def upload_file(
        self,
        file_path: str,
        parent_id: str = "",
        progress_callback: Optional[Callable] = None,
        num_threads: int = 4,
        enable_resume: bool = True,
    ) -> bool:
        """
        上传文件

        Args:
            file_path: 本地文件路径
            parent_id: 云盘目标目录 ID
            progress_callback: 进度回调函数，接收 (uploaded_bytes, total_bytes)
            num_threads: 并发上传线程数 (仅对大文件有效)
            enable_resume: 是否启用断点续传 (仅对大文件有效)

        Returns:
            是否成功
        """
        try:
            # 验证文件路径
            validate_file_path(file_path)

            if not os.path.isfile(file_path):
                raise FileNotFoundError(file_path)

            # 验证文件大小
            validate_file_size(file_path)

            file_size = os.path.getsize(file_path)
            file_name = os.path.basename(file_path)

            params = await self._get_upload_params(file_path, parent_id)
            if not params:
                logger.error("获取上传参数失败")
                return False

            upload_type = params.get("upload_type", "")

            if upload_type == "UPLOAD_TYPE_FORM":
                # 小文件表单上传
                form = params.get("form", {})
                upload_url = form.get("url")
                multi_parts = form.get("multi_parts", {})

                success = await self._upload_form(file_path, upload_url, multi_parts)
                if success:
                    logger.info(f"上传成功: {file_name}")
                return success

            elif upload_type == "UPLOAD_TYPE_RESUMABLE":
                # 大文件分片上传（支持并发和断点续传）
                success = await self._upload_resumable(
                    file_path,
                    file_size,
                    params,
                    progress_callback,
                    num_threads=num_threads,
                    enable_resume=enable_resume,
                )
                return success

            else:
                logger.error(f"未知的上传类型: {upload_type}")
                return False

        except XunleiError:
            raise
        except FileNotFoundError:
            raise
        except Exception as e:
            logger.error(f"上传文件时发生错误: {str(e)}")
            raise FileOperationError(f"文件上传失败: {str(e)}") from e

        return False

    # ==================== 分享链接 ====================

    async def get_file_share_info(  # noqa C901
        self,
        share_id: str = "",
        file_id: str = "",
        path: str = "",
    ) -> dict[str, Any]:
        """
        查询文件/目录的分享信息（支持 share_id、file_id 或 path 查询）

        Args:
            share_id: 分享 ID（直接查询分享详情，使用 share_url API 获取完整信息）
            file_id: 文件/目录 ID（通过分享列表查找）
            path: 文件/目录路径（通过分享列表查找）

        Returns:
            分享信息字典:
            {
                "success": bool,          # 是否成功
                "has_share": bool,        # 是否已分享
                "share_links": [          # 分享链接列表
                    {
                        "share_id": str,         # 分享ID
                        "share_url": str,        # 分享链接
                        "share_url_with_passcode": str,  # 带提取码的链接
                        "pass_code": str,        # 提取码
                        "is_valid": bool,        # 是否有效
                        "expire_time": str,      # 过期时间
                        "remaining_count": int,  # 剩余提取次数
                    }
                ],
                "share_count": int,       # 分享链接数量
                "file_id": str,           # 文件/目录ID
                "file_name": str,         # 文件/目录名称
                "message": str,           # 结果描述
            }
        """
        if share_id:
            resp = await self.get_share_info(share_id, "")
            if resp:
                share_status = resp.get("share_status", "")
                if share_status == "PASS_CODE_EMPTY":
                    share_url = resp.get("share_url", "")
                    pass_code = resp.get("pass_code", "")
                    full_url = f"{share_url}?pwd={pass_code}" if pass_code else share_url
                    return {
                        "success": True,
                        "has_share": True,
                        "share_links": [
                            {
                                "share_id": share_id,
                                "share_url": share_url,
                                "share_url_with_passcode": full_url,
                                "pass_code": pass_code,
                                "is_valid": True,
                                "expire_time": resp.get("expiration_at", ""),
                                "remaining_count": int(resp.get("restore_count_left", -1) or -1),
                            }
                        ],
                        "share_count": 1,
                        "file_id": resp.get("file_id", ""),
                        "file_name": resp.get("title", ""),
                        "is_own_share": resp.get("is_own_share", False),
                        "owner_user_id": resp.get("owner_user_id", ""),
                        "owner_nickname": resp.get("owner_nickname", ""),
                        "message": "查询成功",
                    }
                return {
                    "success": True,
                    "has_share": False,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": "",
                    "file_name": "",
                    "is_own_share": False,
                    "owner_user_id": "",
                    "owner_nickname": "",
                    "message": "分享不存在或已失效",
                }

        if file_id:
            file_info = None
            file_name = ""
        elif path:
            file_info = await self.get_file_info(path)
            if not file_info:
                return {
                    "success": False,
                    "has_share": False,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": "",
                    "file_name": "",
                    "is_own_share": False,
                    "owner_user_id": "",
                    "owner_nickname": "",
                    "message": f"文件/目录不存在: {path}",
                }
            file_id = file_info.get("id", "")
            file_name = file_info.get("name", "")
            file_info = None
        else:
            return {
                "success": False,
                "has_share": False,
                "share_links": [],
                "share_count": 0,
                "file_id": "",
                "file_name": "",
                "is_own_share": False,
                "owner_user_id": "",
                "owner_nickname": "",
                "message": "share_id、file_id 和 path 不能同时为空",
            }

        if not file_info:
            file_info = await self.get_file_info_by_id(file_id)
        if file_info:
            file_name = file_info.get("name", file_name)

        share_list_result = await self.get_share_list(limit=100)
        if not share_list_result:
            return {
                "success": True,
                "has_share": False,
                "share_links": [],
                "share_count": 0,
                "file_id": file_id,
                "file_name": file_name,
                "is_own_share": False,
                "owner_user_id": "",
                "owner_nickname": "",
                "message": "文件未分享",
            }

        share_list = share_list_result.get("share_list", [])
        matching_shares = [s for s in share_list if s.get("file_id") == file_id]
        if not matching_shares:
            return {
                "success": True,
                "has_share": False,
                "share_links": [],
                "share_count": 0,
                "file_id": file_id,
                "file_name": file_name,
                "is_own_share": False,
                "owner_user_id": "",
                "owner_nickname": "",
                "message": "文件未分享",
            }

        share_links: list[dict[str, Any]] = []
        for share_item in matching_shares:
            share_status = share_item.get("share_status", "")
            is_valid = share_status == "OK"
            share_url = share_item.get("share_url", "")
            pass_code = share_item.get("pass_code", "")
            expiration_at = share_item.get("expiration_at", "")
            restore_limit = share_item.get("restore_limit", -1)
            restore_count = share_item.get("restore_count", 0)
            remaining = int(restore_limit) - int(restore_count) if restore_limit != "-1" else -1

            full_url = share_url
            if pass_code and share_url:
                if "?" in share_url:
                    full_url = f"{share_url}&pwd={pass_code}"
                else:
                    full_url = f"{share_url}?pwd={pass_code}"

            share_links.append(
                {
                    "share_id": share_item.get("share_id", ""),
                    "share_url": share_url,
                    "share_url_with_passcode": full_url,
                    "pass_code": pass_code,
                    "is_valid": is_valid,
                    "expire_time": expiration_at,
                    "remaining_count": remaining,
                }
            )

        return {
            "success": True,
            "has_share": True,
            "share_links": share_links,
            "share_count": len(share_links),
            "file_id": file_id,
            "file_name": file_name or matching_shares[0].get("title", ""),
            "message": "查询成功",
        }

    async def create_share_link(  # noqa C901
        self,
        file_id: str = "",
        path: str = "",
        valid_days: int = -1,
        extraction_times: int = -1,
        with_passcode: bool = True,
        on_exists: ShareLinkStrategy = ShareLinkStrategy.SKIP,
    ) -> dict[str, Any]:
        """
        创建分享链接

        Args:
            file_id: 文件/目录 ID（与 path 二选一）
            path: 文件/目录路径（与 file_id 二选一）
            valid_days: 有效天数 (-1 永久)
            extraction_times: 提取次数 (-1 无限制)
            with_passcode: 是否需要提取码
            on_exists: 分享链接已存在时的策略
                      - SKIP: 存在就不重复创建，返回现有的携带提取码的完整分享链接
                      - RECREATE: 创建一个新的，返回新建和现有的所有链接（新建的在第一个位置）
                      - OVERWRITE: 删除现有的所有分享链接，然后创建一个新的

        Returns:
            分享链接信息字典:
            {
                "success": bool,          # 是否成功
                "share_links": list,     # 所有分享链接列表（携带提取码的完整链接）
                "newly_created": bool,    # 是否新创建的
                "file_id": str,          # 文件/目录ID
                "file_name": str,        # 文件/目录名称
                "message": str,          # 结果描述
            }
        """
        if not file_id and not path:
            return {
                "success": False,
                "share_links": [],
                "newly_created": False,
                "file_id": "",
                "file_name": "",
                "message": "file_id 和 path 不能同时为空",
            }

        if path and not file_id:
            file_info = await self.get_file_info(path)
            if not file_info:
                return {
                    "success": False,
                    "share_links": [],
                    "newly_created": False,
                    "file_id": "",
                    "file_name": "",
                    "message": f"文件/目录不存在: {path}",
                }
            file_id = file_info.get("id", "")
            file_name = file_info.get("name", "")
        else:
            file_name = ""

        if not isinstance(valid_days, int) or not (valid_days == -1 or 1 <= valid_days <= 7):
            valid_days = -1

        if not isinstance(extraction_times, int) or not (
            extraction_times == -1 or 1 <= extraction_times <= 20
        ):
            extraction_times = -1

        existing_share_info = await self.get_file_share_info(file_id=file_id)
        existing_links: list[str] = []
        if existing_share_info.get("success") and existing_share_info.get("share_links"):
            for link in existing_share_info.get("share_links", []):
                full_url = link.get("share_url_with_passcode", "")
                if full_url:
                    existing_links.append(full_url)

        if on_exists == ShareLinkStrategy.SKIP and existing_links:
            return {
                "success": True,
                "share_links": existing_links,
                "newly_created": False,
                "file_id": file_id,
                "file_name": file_name,
                "message": "文件已存在分享链接，返回现有链接",
            }

        if on_exists == ShareLinkStrategy.OVERWRITE and existing_links:
            share_count = len(existing_share_info.get("share_links", []))
            logger.info(f"OVERWRITE 策略：准备删除 {share_count} 个现有分享链接")
            for link in existing_share_info.get("share_links", []):
                share_id = link.get("share_id", "")
                logger.info(f"OVERWRITE 策略：准备删除分享链接 share_id={share_id}")
                if share_id:
                    result = await self.cancel_share_link(share_id)
                    logger.info(f"OVERWRITE 策略：删除结果 success={result}")
            existing_links = []

        resp = await self.post(
            self.config.share_url,
            json={
                "file_ids": [file_id],
                "share_to": "copy",
                "params": {
                    "subscribe_push": "false",
                    "WithPassCodeInLink": str(with_passcode).lower(),
                },
                "title": "云盘资源分享",
                "restore_limit": str(extraction_times),
                "expiration_days": str(valid_days),
            },
        )

        if resp:
            share_url = resp.get("share_url", "")
            pass_code = resp.get("pass_code", "")
            new_link = f"{share_url}?pwd={pass_code}" if share_url else ""

            if new_link:
                if on_exists == ShareLinkStrategy.RECREATE:
                    all_links = [new_link] + existing_links
                else:
                    all_links = [new_link] if new_link else existing_links
            else:
                all_links = existing_links

            return {
                "success": True,
                "share_links": all_links,
                "newly_created": bool(new_link),
                "file_id": file_id,
                "file_name": file_name,
                "message": "成功创建分享链接",
            }
        return {
            "success": False,
            "share_links": existing_links,
            "newly_created": False,
            "file_id": file_id,
            "file_name": file_name,
            "message": "创建分享链接失败",
        }

    async def get_share_info(
        self,
        share_id: str,
        pass_code: str = "",
    ) -> Optional[dict[str, Any]]:
        """
        获取分享链接详情

        Returns:
            包含分享信息的字典，API 原始字段包括:
            - share_id: str - 分享ID
            - share_status: str - 分享状态（如 PASS_CODE_EMPTY 表示有分享）
            - share_url: str - 分享链接
            - pass_code: str - 提取码
            - title: str - 分享标题
            - file_id: str - 文件ID（顶级文件或目录的ID）
            - user_info: dict - 用户信息（包含 user_id, nickname 等）
            - expiration_at: str - 过期时间
            - restore_limit: str - 提取次数限制
            - restore_count: str - 已提取次数
            - restore_count_left: int - 剩余提取次数
            - files: list - 文件列表（包含所有文件/目录的详细信息）
              每个文件对象包含:
              - id: str - 文件ID
              - name: str - 文件名
              - size: int - 文件大小（字节），目录为 0
              - kind: str - 类型（如 "drive#file", "drive#folder"）
              - mime_type: str - MIME类型
              - created_time: str - 创建时间
              - modified_time: str - 修改时间
              - parent_id: str - 父目录ID
            - sub_folders: list - 子文件夹列表（如果分享包含目录）

            已添加以下扩展字段:
            - is_own_share: bool - 是否为当前用户的分享
            - owner_user_id: str - 分享者用户ID
            - owner_nickname: str - 分享者昵称
            - total_size: int - 所有文件的总大小（字节），通过遍历 files 计算
            - total_files: int - 文件总数（不含目录）
        """
        resp = await self.get(
            self.config.share_url,
            params={
                "share_id": share_id,
                "pass_code": pass_code,
                "limit": "100",
                "page_token": "",
            },
        )
        if resp:
            user_info = resp.get("user_info", {})
            owner_user_id = user_info.get("user_id", "")
            current_user_id = self.cache.tokens.user_id
            resp["is_own_share"] = owner_user_id == current_user_id
            resp["owner_user_id"] = owner_user_id
            resp["owner_nickname"] = user_info.get("nickname", "")

            files = resp.get("files", [])
            if files:
                resp["total_size"] = sum(int(f.get("size", 0) or 0) for f in files)
                resp["total_files"] = sum(1 for f in files if f.get("kind") == "drive#file")
            else:
                resp["total_size"] = 0
                resp["total_files"] = 0

        return resp

    async def get_share_file_direct_link(
        self,
        share_id: str,
        file_id: str,
        pass_code: str = "",
    ) -> Optional[str]:
        """
        获取分享文件的直链下载链接

        Args:
            share_id: 分享 ID
            file_id: 文件 ID
            pass_code: 提取码

        Returns:
            直链下载链接或 None
        """
        share_info = await self.get_share_info(share_id, pass_code)
        if not share_info:
            logger.warning(f"获取分享信息失败: {share_id}")
            return None

        files = share_info.get("files", [])
        file_info = next((f for f in files if f.get("id") == file_id), None)
        if not file_info:
            logger.warning(f"分享中未找到文件: {file_id}")
            return None

        web_content_link = file_info.get("web_content_link", "")
        if web_content_link:
            return web_content_link

        params_obj = file_info.get("params", {})
        task_id = params_obj.get("task_id", "")
        if not task_id:
            logger.warning(f"分享文件缺少 task_id: {file_id}")
            return None

        resp = await self.get(
            self.config.share_url,
            params={
                "share_id": share_id,
                "pass_code": pass_code,
                "file_ids": file_id,
            },
        )
        if not resp:
            return None

        resp_files = resp.get("files", [])
        if resp_files:
            return resp_files[0].get("web_content_link") or None

        return None

    async def get_share_sub_files(  # noqa: C901
        self,
        share_id: str,
        file_id: str,
        pass_code: str = "",
        pass_code_token: str = "",
        recursive: bool = True,
    ) -> list[dict[str, Any]]:
        """
        获取分享链接中目录的子文件列表

        Args:
            share_id: 分享 ID
            file_id: 目录文件 ID
            pass_code: 提取码
            pass_code_token: 提取码 token（优先使用）
            recursive: 是否递归获取子目录内容，默认 True

        Returns:
            子文件列表，每项包含:
            {
                "id": str,           # 文件ID
                "name": str,         # 文件名
                "size": int,         # 文件大小
                "kind": str,         # 类型 (drive#file, drive#folder)
                "mime_type": str,    # MIME类型
                "parent_id": str,    # 父目录ID
                "path": str,         # 完整路径 (如 "电影/动作/拳皇.mp4")
            }
            如果不是目录则返回空列表
        """
        all_files: list[dict[str, Any]] = []

        token = pass_code_token or pass_code
        resp = await self.get(
            self.config.share_detail_url,
            params={
                "share_id": share_id,
                "parent_id": file_id,
                "pass_code_token": token,
                "limit": 100,
                "page_token": "",
                "thumbnail_size": "SIZE_SMALL",
            },
        )

        if not resp:
            return []

        resp_files = resp.get("files", [])
        if not resp_files:
            return []

        root_folder = resp_files[0]
        if root_folder.get("kind") != "drive#folder":
            return []

        sub_folders = resp.get("sub_folders", [])
        folder_id_map: dict[str, str] = {}
        for sf in sub_folders:
            parent_id = sf.get("parent_id", "")
            folder_id_map[sf.get("id", "")] = parent_id

        folder_id_map[file_id] = ""

        root_folder_name = root_folder.get("name", "")

        def build_path(f: dict[str, Any]) -> str:
            parts: list[str] = [f.get("name", "")]
            pid = f.get("parent_id", "")
            while pid and pid in folder_id_map:
                if pid == file_id:
                    break
                for sf in sub_folders:
                    if sf.get("id") == pid:
                        parts.insert(0, sf.get("name", ""))
                        pid = sf.get("parent_id", "")
                        break
                else:
                    break
            if root_folder_name and parts[-1] != root_folder_name:
                parts.insert(0, root_folder_name)
            return "/".join(parts)

        if recursive:
            for sf in sub_folders:
                sf["path"] = build_path(sf)
                all_files.append(sf)

            for f in resp_files:
                if f.get("parent_id") == file_id:
                    f["path"] = build_path(f)
                    all_files.append(f)
        else:
            direct_children = [f for f in resp_files if f.get("parent_id") == file_id]
            for f in direct_children:
                f["path"] = build_path(f)
                all_files.append(f)

        return all_files

    async def transfer_share(
        self,
        share_id: str,
        pass_code: str,
        target_parent_id: str = "",
        file_ids: Optional[list[str]] = None,
    ) -> bool:
        """
        转存分享链接

        Args:
            share_id: 分享 ID
            pass_code: 提取码
            target_parent_id: 目标目录 ID
            file_ids: 要转存的文件 ID 列表, None 表示全部

        Returns:
            是否成功
        """
        share_info = await self.get_share_info(share_id, pass_code)
        if not share_info:
            return False

        if file_ids is None:
            files = share_info.get("files", [])
            file_ids = [f.get("id") for f in files if f.get("id")]

        if not file_ids:
            return True

        resp = await self.post(
            self.config.share_restore_url,
            json={
                "parent_id": target_parent_id,
                "share_id": share_id,
                "pass_code_token": share_info.get("pass_code_token", ""),
                "ancestor_ids": [],
                "file_ids": file_ids,
                "specify_parent_id": True,
            },
        )
        return resp is not None

    async def get_share_list(
        self,
        limit: int = 50,
        page_token: str = "",
    ) -> Optional[dict[str, Any]]:
        """
        获取当前用户的分享列表

        Args:
            limit: 每页数量，默认 50
            page_token: 分页令牌

        Returns:
            分享列表信息字典:
            {
                "share_list": [...],     # 分享列表
                "next_page_token": str, # 下一页令牌
                "total_count": int,     # 总数量
            }
            失败返回 None
        """
        resp = await self.get(
            self.config.share_list_url,
            params={
                "limit": str(limit),
                "page_token": page_token,
            },
        )
        if resp:
            share_list = resp.get("data", [])
            next_token = resp.get("next_page_token", "")
            total_count = resp.get("total_count", len(share_list))
            return {
                "share_list": share_list,
                "next_page_token": next_token,
                "total_count": total_count,
            }
        return None

    async def get_share_list_full(  # noqa C901
        self,
        limit: int = 50,
        anchor_share_id: Optional[str] = None,
    ) -> tuple[Optional[list[dict[str, Any]]], Optional[dict[str, Any]]]:
        """
        获取完整的分享列表（支持增量获取）

        设计说明:
            数据按时间倒序排列（最新在前）
            首次调用：不传 anchor_share_id，获取所有数据
            增量调用：传入 anchor_share_id，只获取比锚点新的数据

        Args:
            limit: 每页数量，默认 50
            anchor_share_id: 锚点分享ID
                              - 不传：获取完整列表
                              - 传入：只获取比锚点新的（锚点之后的）

        Returns:
            (分享列表, 锚点信息)
            分享列表：第一项为所有分享，第二项为新增分享（增量模式）
            锚点信息：包含 first_page_last_id, total_count 等
        """
        all_shares: list[dict[str, Any]] = []
        new_shares: list[dict[str, Any]] = []
        page_token = ""
        first_page_first_id = ""
        anchor_found = anchor_share_id is None

        while True:
            result = await self.get_share_list(limit=limit, page_token=page_token)
            if not result:
                break

            shares = result.get("share_list", [])
            if not shares:
                break

            for idx, share in enumerate(shares):
                sid = share.get("share_id", "")

                if page_token == "" and idx == 0:
                    first_page_first_id = sid

                if not anchor_found and sid == anchor_share_id:
                    anchor_found = True
                    if page_token == "" and idx == 0:
                        first_page_first_id = sid
                    all_shares.append(share)
                    continue

                if not anchor_found:
                    if page_token == "" and idx == 0:
                        first_page_first_id = sid
                    continue

                if sid != anchor_share_id:
                    new_shares.append(share)

                if sid not in [s.get("share_id") for s in all_shares]:
                    all_shares.append(share)

            page_token = result.get("next_page_token", "")
            if not page_token:
                break

        last_share_id = all_shares[-1].get("share_id", "") if all_shares else ""

        anchor_info = {
            "first_page_first_id": first_page_first_id,
            "last_share_id": last_share_id,
            "total_count": len(all_shares),
            "new_count": len(new_shares),
            "has_more": bool(page_token),
            "is_incremental": anchor_share_id is not None,
            "anchor_share_id": anchor_share_id,
        }

        return all_shares if anchor_found or anchor_share_id is None else None, anchor_info

    async def find_share_by_id(
        self,
        target_share_id: str,
        limit: int = 50,
    ) -> tuple[Optional[dict[str, Any]], Optional[dict[str, Any]]]:
        """
        查找特定分享ID的信息（边获取边匹配，找到后提前终止）

        设计说明:
            数据按时间倒序排列（最新在前）
            当 return_all=False 且需要查找特定 share_id 时使用此方法
            每获取一页就检查是否找到目标，找到后立即返回，避免获取不必要的数据

        Args:
            target_share_id: 要查找的分享ID
            limit: 每页数量，默认 50

        Returns:
            (找到的分享信息, 锚点信息)
            如果找到返回分享信息字典，否则返回 None
        """
        page_token = ""

        while True:
            result = await self.get_share_list(limit=limit, page_token=page_token)
            if not result:
                break

            shares = result.get("share_list", [])
            if not shares:
                break

            for share in shares:
                sid = share.get("share_id", "")
                if sid == target_share_id:
                    anchor_info = {
                        "found": True,
                        "target_share_id": target_share_id,
                        "total_checked": len(shares),
                    }
                    return share, anchor_info

            page_token = result.get("next_page_token", "")
            if not page_token:
                break

        return None, {"found": False, "target_share_id": target_share_id}

    async def cancel_share_link(
        self,
        share_id: str,
    ) -> bool:
        """
        取消分享链接

        Args:
            share_id: 分享 ID

        Returns:
            是否成功
        """
        resp = await self.post(
            self.config.share_delete_url,
            json={"space": "", "share_id": share_id},
        )
        if resp is None:
            return False
        result = resp.json() if hasattr(resp, "json") else resp
        if isinstance(result, dict) and result.get("error"):
            return False
        return True

    async def _batch_get_share_info_from_list(  # noqa C901
        self,
        file_ids: Optional[list[str]] = None,
        paths: Optional[list[str]] = None,
    ) -> list[dict[str, Any]]:
        """
        批量获取分享信息（通过分享列表查找）

        Args:
            file_ids: 文件 ID 列表
            paths: 文件路径列表

        Returns:
            分享信息列表
        """
        share_list_result = await self.get_share_list(limit=200)
        if not share_list_result:
            return []

        share_list = share_list_result.get("share_list", [])

        results = []
        target_ids = set()

        if file_ids:
            for fid in file_ids:
                if fid:
                    target_ids.add(fid)

        if paths:
            for p in paths:
                if p:
                    info = await self.get_file_info(p)
                    if info:
                        fid = info.get("id", "")
                        if fid:
                            target_ids.add(fid)

        for fid in target_ids:
            share_item = next((s for s in share_list if s.get("file_id") == fid), None)
            if share_item:
                results.append(
                    {
                        "success": True,
                        "has_share": True,
                        "share_id": share_item.get("share_id", ""),
                        "share_link": share_item.get("share_url", ""),
                        "pass_code": share_item.get("pass_code", ""),
                        "is_valid": share_item.get("is_valid", True),
                        "expire_time": share_item.get("expiration_at", ""),
                        "remaining_count": -1,
                        "file_id": fid,
                        "file_name": share_item.get("title", ""),
                        "message": "查询成功",
                    }
                )
            else:
                results.append(
                    {
                        "success": True,
                        "has_share": False,
                        "share_id": "",
                        "share_link": "",
                        "pass_code": "",
                        "is_valid": False,
                        "expire_time": "",
                        "remaining_count": -1,
                        "file_id": fid,
                        "file_name": "",
                        "message": "文件未分享",
                    }
                )

        return results

    # ==================== 回收站 ====================

    async def get_recycle_bin_info(self) -> Optional[list[dict[str, Any]]]:
        """获取回收站文件列表"""
        return await self.get_files("", filters='{"trashed":{"eq":true}}')

    async def restore(
        self,
        file_id: str | list[str] | None = None,
        target_parent: str | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        从回收站恢复文件

        Args:
            file_id: 文件ID、文件名、文件ID列表、文件名列表，或 None（整个回收站）
                    - str: 单个文件ID或文件名
                    - list: 多个文件ID或文件名混合列表
                    - None: 恢复整个回收站所有文件
            target_parent: 目标父目录路径或ID，None/""/"/"表示根目录
            on_exists: 同名文件冲突处理策略 (默认 SKIP)
                      - CloudFileExistsStrategy.SKIP: 跳过
                      - CloudFileExistsStrategy.RENAME: 重命名
                      - CloudFileExistsStrategy.OVERWRITE: 覆盖
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            单个文件: 操作结果字典
            多个文件: 操作结果列表
            {
                "success": bool,      # 操作是否成功
                "file_id": str,       # 文件ID
                "file_name": str,     # 文件名称
                "parent_id": str,     # 恢复到的父目录ID
                "original_parent_id": str,  # 原位置父目录ID
                "path": str,         # 恢复后的完整路径
                "message": str,       # 结果描述
            }
        """
        if file_id is None:
            files = await self.get_recycle_bin_info()
            if not files:
                return [
                    {
                        "success": True,
                        "file_id": "",
                        "file_name": "",
                        "parent_id": "",
                        "original_parent_id": "",
                        "message": "回收站为空",
                    }
                ]
            file_ids = [f.get("id") for f in files if f.get("id")]
            results = []
            for fid in file_ids:
                result = await self._restore_single(fid, target_parent, on_exists, get_actual_path)
                results.append(result)
            return results

        if isinstance(file_id, str):
            return await self._restore_single(file_id, target_parent, on_exists, get_actual_path)

        if isinstance(file_id, list):
            results = []
            for fid in file_id:
                result = await self._restore_single(fid, target_parent, on_exists, get_actual_path)
                results.append(result)
            return results

    async def _restore_single(
        self,
        file_id: str,
        target_parent: str | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ) -> dict[str, Any]:
        """恢复单个文件

        Args:
            file_id: 文件ID或文件名
            target_parent: 目标父目录路径或ID，None/""/"/"表示根目录
            on_exists: 同名文件冲突处理策略
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            恢复结果字典
        """
        files = await self.get_recycle_bin_info()
        matched_file = next(
            (f for f in files if f.get("id") == file_id or f.get("name") == file_id), None
        )

        if not matched_file:
            return self._restore_result(
                False, file_id, "", "", "", "", f"回收站中未找到文件: {file_id}"
            )

        file_id = matched_file.get("id", "")
        original_parent_id = matched_file.get("parent_id", "")
        file_name = matched_file.get("name", "")

        resp = await self.patch(f"{self.config.files_url}/{file_id}/untrash", json={})
        if not resp:
            return self._restore_result(
                False, file_id, file_name, "", original_parent_id, "", "恢复失败"
            )

        await asyncio.sleep(0.5)

        if target_parent is None or target_parent in ("", "/"):
            return self._restore_result(
                True, file_id, file_name, "", original_parent_id, f"/{file_name}", "已恢复到根目录"
            )

        parent_id = await self._resolve_parent_id(target_parent)
        if parent_id is None:
            return self._restore_result(
                False,
                file_id,
                file_name,
                "",
                original_parent_id,
                "",
                f"目标目录不存在: {target_parent}",
            )

        source_path = f"/{file_name}"
        move_result = await self.move(
            source_path, target_parent, on_exists=on_exists, get_actual_path=get_actual_path
        )
        if isinstance(move_result, dict) and move_result.get("success"):
            actual_name = move_result.get("name", file_name)
            actual_path = move_result.get("target_path", f"/{actual_name}")
            return self._restore_result(
                True,
                file_id,
                actual_name,
                parent_id,
                original_parent_id,
                actual_path,
                f"已恢复到: {actual_path}",
            )
        return self._restore_result(
            False,
            file_id,
            file_name,
            parent_id,
            original_parent_id,
            "",
            "恢复成功但移动到目标目录失败",
        )

    def _restore_result(
        self,
        success: bool,
        file_id: str,
        file_name: str,
        parent_id: str,
        original_parent_id: str,
        path: str,
        message: str,
    ) -> dict[str, Any]:
        """构建恢复结果字典"""
        return {
            "success": success,
            "file_id": file_id,
            "file_name": file_name,
            "parent_id": parent_id,
            "original_parent_id": original_parent_id,
            "path": path,
            "message": message,
        }

    async def _resolve_parent_id(self, target_parent: str | None) -> str | None:
        """解析目标父目录ID"""
        if target_parent is None:
            return None
        if isinstance(target_parent, str) and target_parent.isdigit():
            return target_parent
        parent_info = await self.get_file_info(target_parent)
        return parent_info.get("id") if parent_info else None

    async def empty_recycle_bin(self) -> bool:
        """清空回收站"""
        files = await self.get_recycle_bin_info()
        if not files:
            return True

        file_ids = [f.get("id") for f in files if f.get("id")]
        if not file_ids:
            return True

        resp = await self.post(
            f"{self.config.files_url}:batchDelete",
            json={"ids": file_ids, "space": ""},
        )
        return resp is not None
