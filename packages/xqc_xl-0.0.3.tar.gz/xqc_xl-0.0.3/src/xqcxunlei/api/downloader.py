"""
Xunlei 直链下载模块

提供云盘文件直链获取和下载功能:
- 单文件和目录直链获取
- 批量下载支持
- 异步并发下载
- 进度条显示
- 断点续传

底层使用 DrissionGet 实现高性能下载。
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from typing import Any, Callable, Optional

import DrissionGet

from ..client import XunleiBase
from ..utils import format_bytes, get_logger
from ..utils.callbacks import ShareFileFilter
from .strategies import CapacityExceededStrategy

logger = get_logger(__name__)


@dataclass
class DownloadTask:
    """下载任务"""

    file_id: str
    file_name: str
    file_size: int
    web_content_link: str
    parent_path: str = ""
    status: str = "pending"
    downloaded_bytes: int = 0
    error: str = ""


@dataclass
class DownloadProgress:
    """下载进度"""

    total_files: int
    completed_files: int = 0
    failed_files: int = 0
    total_bytes: int = 0
    downloaded_bytes: int = 0
    current_file: str = ""
    current_speed: str = "0 B/s"


@dataclass
class DownloadResult:
    """下载结果"""

    success: bool
    file_id: str
    file_name: str
    local_path: str
    file_size: int
    downloaded_bytes: int
    message: str
    task: str = ""
    error: Optional[str] = None

    def __str__(self) -> str:
        status = "成功" if self.success else "失败"
        size_str = format_bytes(self.file_size)
        downloaded_str = format_bytes(self.downloaded_bytes)
        path = self.local_path.replace("\\", "/") if self.local_path else ""

        lines = [
            f"任务: {self.task}",
            f"文件: {self.file_name}",
            f"状态: {status}",
            f"大小: {downloaded_str} / {size_str}",
            f"路径: {path}",
            f"消息: {self.message}",
        ]
        if self.error:
            lines.append(f"错误: {self.error}")

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式，路径使用正斜杠"""
        return {
            "success": self.success,
            "file_id": self.file_id,
            "file_name": self.file_name,
            "local_path": self.local_path.replace("\\", "/") if self.local_path else "",
            "file_size": self.file_size,
            "downloaded_bytes": self.downloaded_bytes,
            "message": self.message,
            "task": self.task,
            "error": self.error,
        }


@dataclass
class ShareDownloadOptions:
    """分享链接下载选项"""

    transfer_dir: str = ""
    auto_delete: bool = True
    delete_after_completed: bool = True
    max_concurrent: int = 3
    chunk_size: int = 1024 * 1024
    enable_resume: bool = True
    show_progress: bool = True
    skip_directory: bool = True


@dataclass
class ShareTransferResult:
    """分享转存结果

    transferred_files 中每个条目包含:
        - file_id: 文件ID
        - file_name: 文件名
        - file_size: 文件大小
        - original_path: 原路径（第三方分享链接为空）
        - current_path: 当前路径
        - share_url: 创建的分享链接（携带提取码的完整URL，当 on_share_after_transfer 参数启用时）
    """

    success: bool
    share_id: str
    pass_code: str
    task: str
    transferred_files: list[dict[str, Any]] = None
    skipped_files: list[dict[str, Any]] = None
    total_files: int = 0
    total_size: int = 0
    transferred_size: int = 0
    target_dir: str = ""
    message: str = ""

    def __post_init__(self) -> None:
        if self.transferred_files is None:
            self.transferred_files = []
        if self.skipped_files is None:
            self.skipped_files = []

    def __str__(self) -> str:
        return self.message

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式，便于日志和调试"""
        return {
            "success": self.success,
            "share_id": self.share_id,
            "pass_code": self.pass_code,
            "task": self.task,
            "target_dir": self.target_dir or "根目录",
            "total_files": self.total_files,
            "total_size": self.total_size,
            "transferred_files": self.transferred_files,
            "skipped_files": self.skipped_files,
            "transferred_size": self.transferred_size,
            "message": self.message,
        }


@dataclass
class ShareTransferOptions:
    """分享链接转存选项"""

    target_dir: str = ""
    file_ids: Optional[list[str]] = None
    file_filter: Optional[ShareFileFilter] = None
    auto_create_dir: bool = True
    on_capacity_exceeded: CapacityExceededStrategy = CapacityExceededStrategy.SKIP
    max_concurrent: int = 3
    show_progress: bool = True


class Downloader:
    """
    迅雷云盘直链下载器

    支持:
    - 单文件和目录直链获取
    - 批量下载
    - 异步并发下载
    - 进度条显示
    - 断点续传

    底层使用 DrissionGet 实现高性能下载。
    """

    def __init__(
        self,
        cloud_disk: XunleiBase,
        max_concurrent: int = 3,
        chunk_size: int = 1024 * 1024,
        enable_resume: bool = True,
        max_retries: int = 3,
        timeout: int = 60,
        resume_fallback_to_new: bool = True,
        progress_callback: Optional[Callable[[DownloadProgress], None]] = None,
        cookies: Optional[dict[str, str]] = None,
    ) -> None:
        """
        初始化下载器

        Args:
            cloud_disk: 云盘客户端实例
            max_concurrent: 最大并发下载数
            chunk_size: 每次下载的块大小 (字节)
            enable_resume: 是否启用断点续传
            max_retries: 最大重试次数
            timeout: 下载超时时间（秒）
            resume_fallback_to_new: 断点续传失败时是否重新下载
            progress_callback: 进度回调函数
            cookies: 下载用的认证 cookies (可选)
                    如果传入，则 DrissionGet 会使用这些 cookies 进行下载
        """
        self._cloud = cloud_disk
        self._max_concurrent = max_concurrent
        self._chunk_size = chunk_size
        self._enable_resume = enable_resume
        self._max_retries = max_retries
        self._timeout = timeout
        self._resume_fallback_to_new = resume_fallback_to_new
        self._progress_callback = progress_callback
        self._cookies = cookies
        self._drission: Optional[DrissionGet.DrissionGet] = None

    def _get_drission(self) -> DrissionGet.DrissionGet:
        """获取或创建 DrissionGet 下载器"""
        if self._drission is None:
            if self._cookies:
                import requests

                session = requests.Session()
                session.cookies.update(self._cookies)
                self._drission = DrissionGet.DrissionGet(
                    driver=session,
                    save_path=".",
                    roads=self._max_concurrent,
                )
            else:
                self._drission = DrissionGet.DrissionGet(
                    save_path=".",
                    roads=self._max_concurrent,
                )
            self._drission.set.retry(self._max_retries)
            self._drission.set.timeout(self._timeout)
            self._drission.set.if_file_exists("rename" if self._enable_resume else "overwrite")
        return self._drission

    async def _sync_download(
        self,
        url: str,
        save_path: str,
        file_name: str,
    ) -> tuple[bool, str, str]:
        """
        同步执行下载（在线程池中运行 DrissionGet）

        Returns:
            (success, message, file_path)
        """
        loop = asyncio.get_event_loop()
        drission = self._get_drission()

        def do_download() -> tuple[str, str, str]:
            drission.set.save_path(save_path)
            drission.set.show_msg(False)
            drission.set.split(False)
            try:
                result, info = drission.download(url, rename=file_name)
                if result == "success":
                    return "success", info or file_name, info or file_name
                elif result == "skipped":
                    return "success", "文件已存在，已跳过", info or file_name
                elif result == "canceled":
                    return "canceled", "下载被取消", ""
                else:
                    return "failed", str(info) if info else "下载失败", ""
            except Exception as e:
                return "failed", str(e), ""

        try:
            result, message, file_path = await loop.run_in_executor(None, do_download)
            return result in ("success", "skipped"), message, file_path
        except Exception as e:
            return False, str(e), ""

    async def close(self) -> None:
        """关闭下载器"""
        self._drission = None

    async def get_file_direct_link(self, file_id: str) -> Optional[str]:
        """
        获取单文件的直链下载链接

        Args:
            file_id: 文件 ID

        Returns:
            直链 URL 或 None
        """
        file_info = await self._cloud.get_file_info_by_id(file_id)
        if not file_info:
            logger.warning(f"文件不存在或已在回收站中: {file_id}")
            return None

        kind = file_info.get("kind", "")
        if kind == "drive#folder":
            logger.warning(f"这是一个目录而非文件: {file_id}")
            return None

        web_content_link = file_info.get("web_content_link", "")
        if not web_content_link:
            logger.warning(f"文件直链为空: {file_id}")
            return None

        return web_content_link

    async def get_directory_files(
        self,
        directory_id: str,
        skip_directory: bool = False,
    ) -> list[dict[str, Any]]:
        """
        获取目录下的所有文件信息

        Args:
            directory_id: 目录 ID
            skip_directory: 是否跳过子目录（True=只获取当前层，False=递归获取子目录）

        Returns:
            文件信息列表
        """
        all_files = []

        async def fetch_files(parent_id: str, parent_path: str = "") -> None:
            files = await self._cloud.get_files(parent_id, limit=200)
            if not files:
                return

            for file_info in files:
                file_id = file_info.get("id", "")
                file_name = file_info.get("name", "")
                file_kind = file_info.get("kind", "")
                file_size = file_info.get("size", 0)
                current_path = f"{parent_path}/{file_name}" if parent_path else file_name

                if file_kind == "drive#folder":
                    if not skip_directory:
                        await fetch_files(file_id, current_path)
                else:
                    all_files.append(
                        {
                            "id": file_id,
                            "name": file_name,
                            "size": file_size,
                            "parent_path": parent_path,
                            "path": current_path,
                        }
                    )

        await fetch_files(directory_id, "")
        return all_files

    async def get_directory_direct_links(
        self,
        directory_id: str,
        skip_directory: bool = False,
        show_progress: bool = True,
    ) -> list[dict[str, Any]]:
        """
        获取目录下所有文件的直链

        Args:
            directory_id: 目录 ID
            skip_directory: 是否跳过子目录（True=只获取当前层，False=递归获取子目录）
            show_progress: 是否显示进度

        Returns:
            文件直链信息列表，每项包含 id、name、size、path、web_content_link
        """
        files = await self.get_directory_files(directory_id, skip_directory)
        if not files:
            return []

        results = []
        total = len(files)

        for index, file_info in enumerate(files):
            file_id = file_info.get("id", "")
            if show_progress:
                logger.info(f"正在获取直链 [{index + 1}/{total}]: {file_info.get('path', '')}")

            web_content_link = await self.get_file_direct_link(file_id)
            file_info["web_content_link"] = web_content_link
            results.append(file_info)

            if show_progress and (index + 1) % 10 == 0:
                logger.info(f"进度: {index + 1}/{total}")

        return results

    async def download_file(
        self,
        file_id: str,
        file_name: str,
        web_content_link: str,
        local_path: str,
        file_size: int = 0,
        task: str = "",
    ) -> DownloadResult:
        """
        下载单个文件

        Args:
            file_id: 文件 ID
            file_name: 文件名
            web_content_link: 直链 URL
            local_path: 本地保存路径
            file_size: 文件大小
            task: 原始任务标识

        Returns:
            下载结果
        """
        os.makedirs(local_path, exist_ok=True)
        local_path = os.path.abspath(local_path)
        file_size = int(file_size or 0)
        full_path = os.path.join(local_path, file_name)

        if not web_content_link:
            return DownloadResult(
                success=False,
                file_id=file_id,
                file_name=file_name,
                local_path=full_path,
                file_size=file_size,
                downloaded_bytes=0,
                message="直链为空",
                task=task,
                error="web_content_link为空",
            )

        logger.info(f"开始下载: {file_name}")

        success, message, file_path = await self._sync_download(
            url=web_content_link,
            save_path=local_path,
            file_name=file_name,
        )

        if success:
            downloaded = os.path.getsize(file_path) if os.path.exists(file_path) else file_size
            if os.path.normpath(file_path) != full_path and os.path.exists(file_path):
                try:
                    if os.path.exists(full_path):
                        os.remove(full_path)
                    os.rename(file_path, full_path)
                    file_path = full_path
                    logger.info(f"文件名修正: {file_name}")
                except OSError:
                    pass
            logger.info(f"下载完成: {file_name}, 路径: {file_path}")
            return DownloadResult(
                success=True,
                file_id=file_id,
                file_name=file_name,
                local_path=file_path,
                file_size=file_size,
                downloaded_bytes=downloaded,
                message="下载完成",
                task=task,
            )
        else:
            logger.error(f"下载失败 [{file_name}]: {message}")
            return DownloadResult(
                success=False,
                file_id=file_id,
                file_name=file_name,
                local_path=full_path,
                file_size=file_size,
                downloaded_bytes=0,
                message=f"下载失败: {message}",
                task=task,
                error=message,
            )

    async def download_multiple(  # noqa C901
        self,
        files: list[dict[str, Any]],
        local_dir: str,
        show_progress: bool = True,
    ) -> list[DownloadResult]:
        """
        批量下载文件

        Args:
            files: 文件列表，每项包含 id、name、size、web_content_link、path
            local_dir: 本地保存目录
            show_progress: 是否显示进度

        Returns:
            下载结果列表
        """
        if not files:
            return []

        total_files = len(files)
        total_bytes = sum(int(f.get("size", 0) or 0) for f in files)
        completed_files = 0
        failed_files = 0
        results = []
        semaphore = asyncio.Semaphore(self._max_concurrent)

        def update_progress(
            current_file: str, downloaded: int, is_completed: bool = False, is_failed: bool = False
        ) -> None:
            nonlocal completed_files, failed_files
            if is_completed:
                completed_files += 1
            if is_failed:
                failed_files += 1

            if self._progress_callback:
                progress = DownloadProgress(
                    total_files=total_files,
                    completed_files=completed_files,
                    failed_files=failed_files,
                    total_bytes=total_bytes,
                    downloaded_bytes=downloaded,
                    current_file=current_file,
                    current_speed="0 B/s",
                )
                self._progress_callback(progress)

        async def download_one(file_info: dict[str, Any]) -> DownloadResult:
            async with semaphore:
                file_id = file_info.get("id", "")
                file_name = file_info.get("name", "")
                file_size = file_info.get("size", 0)
                web_content_link = file_info.get("web_content_link", "")
                parent_path = file_info.get("parent_path", "")

                if not web_content_link:
                    if show_progress:
                        logger.warning(f"直链为空，跳过: {file_name}")
                    update_progress(file_name, 0, is_failed=True)
                    return DownloadResult(
                        success=False,
                        file_id=file_id,
                        file_name=file_name,
                        local_path="",
                        file_size=file_size,
                        downloaded_bytes=0,
                        message="直链为空",
                        error="web_content_link为空",
                    )

                target_dir = local_dir
                if parent_path:
                    target_dir = os.path.join(local_dir, parent_path.lstrip("/"))
                    target_dir = target_dir.replace("/", os.sep)

                result = await self.download_file(
                    file_id=file_id,
                    file_name=file_name,
                    web_content_link=web_content_link,
                    local_path=target_dir,
                    file_size=file_size,
                    task=file_info.get("task", ""),
                )

                if show_progress:
                    if result.success:
                        logger.info(f"下载成功: {file_name}")
                    else:
                        logger.error(f"下载失败: {file_name} - {result.message}")

                update_progress(
                    file_name,
                    result.downloaded_bytes,
                    is_completed=result.success,
                    is_failed=not result.success,
                )
                return result

        tasks = [download_one(f) for f in files]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed_results = []
        for r in results:
            if isinstance(r, Exception):
                processed_results.append(
                    DownloadResult(
                        success=False,
                        file_id="",
                        file_name="未知",
                        local_path="",
                        file_size=0,
                        downloaded_bytes=0,
                        message=str(r),
                        error=str(r),
                    )
                )
            else:
                processed_results.append(r)

        if show_progress:
            logger.info(f"批量下载完成: 成功 {completed_files}, 失败 {failed_files}")

        return processed_results

    async def download_share_link(  # noqa C901
        self,
        share_id: str,
        pass_code: str,
        local_dir: str,
        options: Optional[ShareDownloadOptions] = None,
    ) -> list[DownloadResult]:
        """
        下载分享链接中的文件（先转存到云盘，再下载）

        Args:
            share_id: 分享 ID
            pass_code: 提取码
            local_dir: 本地保存目录
            options: 下载选项

        Returns:
            下载结果列表
        """
        if options is None:
            options = ShareDownloadOptions()

        share_info = await self._cloud.get_share_info(share_id, pass_code)
        if not share_info:
            logger.error(f"获取分享信息失败: {share_id}")
            return []

        share_file_list = share_info.get("file_list", []) or share_info.get("files", [])
        if not share_file_list:
            logger.error(f"分享文件中没有内容: {share_id}")
            return []

        file_list = []
        for item in share_file_list:
            if item.get("kind") == "drive#folder":
                continue
            file_list.append(
                {
                    "id": item.get("id", ""),
                    "name": item.get("name", ""),
                    "size": item.get("size", 0),
                    "parent_path": "",
                }
            )

        if not file_list:
            logger.warning(f"分享中没有文件: {share_id}")
            return []

        target_dir = options.transfer_dir or ""
        file_ids = [f.get("id", "") for f in file_list if f.get("id")]

        logger.info(f"转存分享文件到云盘: {share_id}")
        success = await self._cloud.transfer_share(
            share_id=share_id,
            pass_code=pass_code,
            target_parent_id=target_dir,
            file_ids=file_ids,
        )
        if not success:
            logger.error(f"转存分享失败: {share_id}")
            return []

        logger.info("转存成功，查找转存后的文件...")

        all_cloud_files = await self._cloud.get_files(parent_id=target_dir)
        name_to_file: dict[str, dict[str, Any]] = {}
        for f in all_cloud_files:
            name_to_file[f.get("name", "")] = f

        transferred_files: list[dict[str, Any]] = []
        for file_info in file_list:
            file_name = file_info.get("name", "")
            file_size = int(file_info.get("size", 0) or 0)

            cloud_file = name_to_file.get(file_name)
            if cloud_file:
                f_size = int(cloud_file.get("size", 0) or 0)
                if f_size == file_size:
                    cloud_file["original_name"] = file_name
                    cloud_file["original_size"] = file_size
                    transferred_files.append(cloud_file)
                else:
                    logger.warning(f"转存后文件大小不匹配: {file_name}")
            else:
                logger.warning(f"转存后在云盘中未找到文件: {file_name}")

        if not transferred_files:
            logger.error(f"转存后未找到任何文件: {share_id}")
            return []

        logger.info(f"找到 {len(transferred_files)} 个转存后的文件，开始下载")

        file_urls = []
        for transferred in transferred_files:
            file_id = transferred.get("id", "")
            direct_link = await self._cloud.get_file_direct_link_by_id(file_id)
            if direct_link:
                transferred["web_content_link"] = direct_link
                file_urls.append(transferred)
            else:
                logger.warning(f"获取直链失败: {transferred.get('name', '')}")

        if not file_urls:
            logger.error(f"没有可用的直链: {share_id}")
            return []

        results = await self.download_multiple(
            file_urls, local_dir, show_progress=options.show_progress
        )
        return results

    async def download_directory(
        self,
        directory_id: str,
        local_dir: str,
        skip_directory: bool = False,
        show_progress: bool = True,
    ) -> list[DownloadResult]:
        """
        下载整个目录

        Args:
            directory_id: 目录 ID
            local_dir: 本地保存目录
            skip_directory: 是否跳过子目录
            show_progress: 是否显示进度

        Returns:
            下载结果列表
        """
        files = await self.get_directory_direct_links(directory_id, skip_directory, show_progress)
        if not files:
            logger.warning(f"目录为空或不存在: {directory_id}")
            return []

        results = await self.download_multiple(files, local_dir, show_progress=show_progress)
        return results

    async def download(
        self,
        target: str,
        local_dir: str,
        skip_directory: bool = False,
        max_concurrent: int = 3,
        chunk_size: int = 1024 * 1024,
        enable_resume: bool = True,
        max_retries: int = 3,
        timeout: int = 60,
        resume_fallback_to_new: bool = True,
        show_progress: bool = True,
        progress_callback: Callable[[DownloadProgress], None] | None = None,
    ) -> list[DownloadResult]:
        """
        统一的下载接口

        Args:
            target: 文件/目录 ID 或分享链接
            local_dir: 本地保存目录
            skip_directory: 是否跳过子目录（下载目录时有效）
            max_concurrent: 最大并发数
            chunk_size: 块大小
            enable_resume: 是否启用断点续传
            max_retries: 最大重试次数
            timeout: 超时时间（秒）
            resume_fallback_to_new: 断点续传失败时是否重新下载
            show_progress: 是否显示进度
            progress_callback: 进度回调函数

        Returns:
            下载结果列表
        """
        downloader = _create_downloader(
            cloud_disk=self._cloud,
            max_concurrent=max_concurrent,
            chunk_size=chunk_size,
            enable_resume=enable_resume,
            max_retries=max_retries,
            timeout=timeout,
            resume_fallback_to_new=resume_fallback_to_new,
            show_progress=show_progress,
            progress_callback=progress_callback,
        )

        if target.startswith("http"):
            share_id, pass_code = self._cloud.parse_share_link(target)
            if share_id:
                options = ShareDownloadOptions(
                    max_concurrent=max_concurrent,
                    show_progress=show_progress,
                    skip_directory=skip_directory,
                )
                return await downloader.download_share_link(
                    share_id=share_id,
                    pass_code=pass_code or "",
                    local_dir=local_dir,
                    options=options,
                )

        if "/" in target or target.startswith("."):
            return await downloader.download_directory(
                directory_id=target,
                local_dir=local_dir,
                skip_directory=skip_directory,
                show_progress=show_progress,
            )

        web_content_link = await downloader.get_file_direct_link(target)
        if not web_content_link:
            return [
                DownloadResult(
                    success=False,
                    file_id=target,
                    file_name="",
                    local_path=local_dir,
                    file_size=0,
                    downloaded_bytes=0,
                    message="无法获取直链",
                    error="直链为空",
                )
            ]

        file_info = await self._cloud.get_file_info_by_id(target)
        file_name = file_info.get("name", "unknown") if file_info else "unknown"
        file_size = file_info.get("size", 0) if file_info else 0

        result = await downloader.download_file(
            file_id=target,
            file_name=file_name,
            web_content_link=web_content_link,
            local_path=local_dir,
            file_size=file_size,
        )

        return [result]


def _create_downloader(
    cloud_disk: XunleiBase,
    max_concurrent: int = 3,
    chunk_size: int = 1024 * 1024,
    enable_resume: bool = True,
    max_retries: int = 3,
    timeout: int = 60,
    resume_fallback_to_new: bool = True,
    show_progress: bool = True,
    progress_callback: Callable[[DownloadProgress], None] | None = None,
) -> Downloader:
    """
    创建下载器实例（内部使用）

    Args:
        cloud_disk: 云盘客户端
        max_concurrent: 最大并发数
        chunk_size: 块大小
        enable_resume: 是否启用断点续传
        max_retries: 最大重试次数
        timeout: 超时时间
        resume_fallback_to_new: 断点续传失败时是否重新下载
        show_progress: 是否显示进度
        progress_callback: 进度回调函数

    Returns:
        下载器实例
    """
    return Downloader(
        cloud_disk=cloud_disk,
        max_concurrent=max_concurrent,
        chunk_size=chunk_size,
        enable_resume=enable_resume,
        max_retries=max_retries,
        timeout=timeout,
        resume_fallback_to_new=resume_fallback_to_new,
        progress_callback=progress_callback,
    )


class ConsoleProgressTracker:
    """控制台进度跟踪器"""

    def __init__(self, total_files: int, total_bytes: int = 0) -> None:
        self.total_files = total_files
        self.total_bytes = total_bytes
        self.completed_files = 0
        self.failed_files = 0
        self.downloaded_bytes = 0
        self.last_update_time = 0.0

    def __call__(
        self,
        progress: DownloadProgress,
    ) -> None:
        """作为回调函数被调用"""
        self.update(
            current_file=progress.current_file,
            downloaded_bytes=progress.downloaded_bytes,
            is_completed=progress.completed_files > self.completed_files,
            is_failed=progress.failed_files > self.failed_files,
        )

    def update(
        self,
        current_file: str = "",
        downloaded_bytes: int = 0,
        is_completed: bool = False,
        is_failed: bool = False,
    ) -> None:
        if is_completed:
            self.completed_files += 1
        if is_failed:
            self.failed_files += 1
        if downloaded_bytes > 0:
            self.downloaded_bytes += downloaded_bytes

        completed = self.completed_files + self.failed_files
        total = self.total_files
        percent = (completed / total * 100) if total > 0 else 0

        print(
            f"\r进度: {completed}/{total} ({percent:.1f}%) "
            f"| 成功: {self.completed_files} | 失败: {self.failed_files} | "
            f"{format_bytes(self.downloaded_bytes)}",
            end="",
        )

        if is_completed or is_failed:
            print()

    def finish(self) -> None:
        print(f"\n下载完成: 成功 {self.completed_files}, 失败 {self.failed_files}")
