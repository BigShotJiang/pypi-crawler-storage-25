"""
Xunlei 远程下载 API 模块

提供远程下载设备管理功能:
- 设备列表
- 设备状态
- 下载任务管理
- 远程文件操作
- 配置管理
- 增强日志功能
- 统一错误处理
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, Callable, Optional

from ..client import XunleiBase
from ..utils import (
    StructuredLogger,
    format_sub_file_index,
    get_logger,
    parse_torrent,
    split_path,
)

logger = get_logger(__name__)
structured_logger = StructuredLogger(__name__)


class XunleiRemoteDownloader(XunleiBase):
    """
    迅雷远程下载 API

    用于管理远程下载设备和任务
    """

    def __init__(
        self,
        username: str,
        password: str,
        cache_file: str | None = None,
        cache_dir: str | None = None,
        auto_save: bool = True,
    ) -> None:
        """
        初始化远程下载客户端

        Args:
            username: 迅雷用户名
            password: 迅雷密码
            cache_file: Token 缓存文件路径
            cache_dir: Token 缓存目录
            auto_save: 是否自动保存 Token
        """
        super().__init__(username, password, cache_file, cache_dir, auto_save)

    # ==================== 设备管理 ====================

    async def get_devices(self) -> Optional[list[dict[str, Any]]]:
        """
        获取远程设备列表

        Returns:
            设备列表或 None
        """
        resp = await self.get(self.config.tasks_url, params={"type": "user#runner", "space": ""})
        if not resp:
            return None

        devices = []
        for task in resp.get("tasks", []):
            devices.append(
                {
                    "id": task.get("id"),
                    "name": task.get("name"),
                    "device_id": task.get("params", {}).get("target"),
                }
            )
        return devices

    async def get_device_info(self, device_name: str) -> Optional[dict[str, Any]]:
        """获取指定设备信息"""
        devices = await self.get_devices()
        if not devices:
            return None
        return next((d for d in devices if d.get("name") == device_name), None)

    async def is_device_online(self, device_name: str) -> bool:
        """检查设备是否在线"""
        info = await self.get_device_info(device_name)
        return info is not None

    # ==================== 设备任务 ====================

    async def get_device_tasks(
        self,
        device_name: str,
        return_raw: bool = False,
    ) -> Optional[list[dict[str, Any]]]:
        """
        获取指定设备的下载任务

        Args:
            device_name: 设备名称
            return_raw: 是否返回原始数据

        Returns:
            任务列表或 None
        """
        devices = await self.get_devices()
        if not devices:
            return None

        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return None

        resp = await self.get(
            self.config.tasks_url,
            params={"space": device.get("device_id")},
        )
        if not resp:
            return None

        if return_raw:
            return resp.get("tasks", [])

        tasks = []
        for task in resp.get("tasks", []):
            tasks.append(
                {
                    "id": task.get("id"),
                    "name": task.get("name"),
                    "url": task.get("params", {}).get("url"),
                    "progress": task.get("progress"),
                    "message": task.get("message"),
                    "size": task.get("size"),
                }
            )
        return tasks

    async def get_all_tasks(self) -> Optional[dict[str, list[dict[str, Any]]]]:
        """
        获取所有设备的任务

        Returns:
            {设备名: 任务列表} 的字典
        """
        devices = await self.get_devices()
        if not devices:
            return None

        async def get_tasks(device: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
            name = device.get("name", "")
            tasks = await self.get_device_tasks(name) or []
            return name, tasks

        results = await asyncio.gather(*[get_tasks(d) for d in devices])
        return dict(results)

    # ==================== 任务控制 ====================

    async def _control_task(
        self,
        device_name: str,
        action: str,
        task_id: Optional[str] = None,
    ) -> bool:
        """
        控制任务 (暂停/开始/删除)

        Args:
            device_name: 设备名称
            action: 操作 (pause/running/delete)
            task_id: 任务 ID, None 表示所有任务

        Returns:
            是否成功
        """
        devices = await self.get_devices()
        if not devices:
            return False

        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return False

        tasks = await self.get_device_tasks(device_name, return_raw=True)
        if not tasks:
            return True

        if task_id:
            tasks = [t for t in tasks if t.get("id") == task_id]

        for task in tasks:
            task_space = task.get("space") or f"device_id#{device.get('device_id', '')}"
            task_params = {
                "space": task_space,
                "type": task.get("type"),
                "id": task.get("id"),
                "set_params": {"spec": json.dumps({"phase": action})},
            }
            resp = await self.request(
                "PUT", f"{self.config.tasks_url.rstrip('s')}", json=task_params
            )
            if resp is None:
                return False

        return True

    async def pause_task(self, device_name: str, task_id: Optional[str] = None) -> bool:
        """暂停任务"""
        return await self._control_task(device_name, "pause", task_id)

    async def resume_task(self, device_name: str, task_id: Optional[str] = None) -> bool:
        """恢复任务"""
        return await self._control_task(device_name, "running", task_id)

    async def delete_task(self, device_name: str, task_id: Optional[str] = None) -> bool:
        """删除任务"""
        return await self._control_task(device_name, "delete", task_id)

    async def delete_task_only(self, device_name: str, task_id: Optional[str] = None) -> bool:
        """
        删除任务（仅删除任务，不删除设备文件）

        Args:
            device_name: 设备名称
            task_id: 任务ID，None 时删除所有任务

        Returns:
            是否成功
        """
        if task_id is None:
            tasks = await self.get_device_tasks(device_name, return_raw=True)
            if not tasks:
                return True
            task_ids = [t.get("id") for t in tasks if t.get("id")]
        else:
            task_ids = [task_id]

        devices = await self.get_devices()
        if not devices:
            return False
        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return False

        device_id = device.get("device_id", "")
        params: dict[str, Any] = {"space": f"device_id#{device_id}"}
        for tid in task_ids:
            params.setdefault("task_ids", []).append(tid)

        resp = await self.request("DELETE", self.config.tasks_url, params=params)
        return resp is not None

    async def get_download_url_info(self, url: str) -> Optional[dict[str, Any]]:
        """获取下载链接信息"""
        resp = await self.post(
            self.config.resource_list_url,
            json={"urls": url, "page_size": 2000},
        )
        if not resp:
            return None

        try:
            resources = resp.get("list", {}).get("resources", [{}])[0]
            meta = resources.get("meta", {})
            dir_info = resources.get("dir") or {}
            files = dir_info.get("resources", []) if isinstance(dir_info, dict) else []
            return {
                "task_name": resources.get("name"),
                "task_size": resources.get("file_size"),
                "file_count": resources.get("file_count"),
                "files": files,
                "task_url": meta.get("url"),
            }
        except (KeyError, IndexError, AttributeError):
            return None

    async def get_magnet_files(  # noqa C901
        self,
        magnet_url: str,
        file_types: list[str] | None = None,
        extensions: list[str] | None = None,
        filters: list[Callable[[dict[str, Any]], bool]] | None = None,
    ) -> list[dict[str, Any]] | None:
        """
        获取磁力链接的文件列表

        Args:
            magnet_url: 磁力链接
            file_types: 按 MIME 类型筛选，支持 FileTypeFilter 枚举或字符串列表
                       例如 [FileTypeFilter.VIDEO] 或 ["video/", "application/"]
            extensions: 按文件扩展名筛选，如 [".mp4", ".mkv"]
                       传入 [".mp4"] 只返回 mp4 文件（不区分大小写）
                       也可使用 FileTypeFilter.video_extensions() 获取对应扩展名列表
            filters: 自定义筛选函数列表，每个函数接收文件信息 dict，返回 True 保留文件
                    可使用预设函数如 name_contains_filter, size_range_filter 等

        Returns:
            文件列表，每个文件包含 index, name, size, mime_type 等信息。
            如果获取失败返回 None。
        """
        from .strategies import FileTypeFilter

        url_info = await self.get_download_url_info(magnet_url)
        if not url_info:
            return None

        mime_filters: list[str] = []
        ext_filters: list[str] = []

        if file_types:
            for ft in file_types:
                if isinstance(ft, FileTypeFilter):
                    mime_filters.append(ft.value)
                    ext_filters.extend(ft.get_extensions())
                else:
                    mime_filters.append(ft)

        if extensions:
            ext_filters.extend(extensions)

        files = url_info.get("files", [])
        result = []
        for i, f in enumerate(files):
            file_info = {
                "index": i + 1,
                "name": f.get("name", ""),
                "size": f.get("size", 0),
                "size_human": f.get("size_human", ""),
                "mime_type": f.get("mime_type", ""),
            }

            mime_type = f.get("mime_type", "")
            name = f.get("name", "").lower()

            # MIME 类型筛选（OR 逻辑 - 匹配任一类型即可）
            if mime_filters:
                if mime_type:
                    if not any(mime_type.startswith(m) for m in mime_filters):
                        continue
                else:
                    if ext_filters and not any(name.endswith(e.lower()) for e in ext_filters):
                        continue
            elif ext_filters:
                if not any(name.endswith(e.lower()) for e in ext_filters):
                    continue

            # 自定义筛选器（AND 逻辑 - 所有回调都必须返回 True）
            if filters:
                for filter_func in filters:
                    if not filter_func(file_info):
                        break
                else:
                    result.append(file_info)
            else:
                result.append(file_info)

        for i, f in enumerate(result):
            f["index"] = i + 1
        return result

    # ==================== 创建设置任务 ====================

    async def create_download_task(
        self,
        url: str,
        device_name: str,
        target_folder: str = "",
        rename: Optional[str] = None,
        parent_folder_id: str = "",
        select_files: list[int] | None = None,
    ) -> dict[str, Any] | bool:
        """
        创建远程下载任务

        Args:
            url: 下载链接 (HTTP/Magnet/BT)
            device_name: 设备名称
            target_folder: 目标文件夹路径
            rename: 下载后重命名
            parent_folder_id: 目标文件夹ID
            select_files: 指定下载的文件索引列表，None 表示下载全部

        Returns:
            返回 API 响应 dict 或 False（获取信息失败时）
        """
        if url.endswith(".torrent"):
            url, _ = await parse_torrent(url)

        devices = await self.get_devices()
        if not devices:
            return False

        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return False

        url_info = await self.get_download_url_info(url)
        if url_info:
            task_name = rename or url_info.get("task_name", "untitled")
            if select_files:
                indices = format_sub_file_index(select_files)
            else:
                file_count = int(url_info.get("file_count", 1))
                indices = format_sub_file_index(list(range(file_count)))
            task_size = str(url_info.get("task_size", 0) or 0)
        else:
            task_name = rename or url.rsplit("/", 1)[-1] or "untitled"
            indices = ""
            task_size = "0"

        resp = await self.post(
            self.config.tasks_url.rstrip("s"),
            json={
                "file_name": task_name,
                "file_size": task_size,
                "space": device.get("device_id"),
                "type": "user#download-url",
                "params": {
                    "target": device.get("device_id"),
                    "url": url,
                    "sub_file_index": indices,
                    "parent_folder_id": parent_folder_id or "",
                    "platform": "fnos_community",
                },
            },
        )
        return resp if resp else False

    async def set_download_speed(
        self,
        device_name: str,
        speed_mbps: float = -1,
    ) -> bool:
        """
        设置下载速度限制

        Args:
            device_name: 设备名称
            speed_mbps: 速度限制 (Mbps), -1 表示不限速

        Returns:
            是否成功
        """
        devices = await self.get_devices()
        if not devices:
            return False

        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return False

        # 转换为字节
        speed_bytes = (
            -1 if speed_mbps == -1 else int(max(0.06, min(speed_mbps, 131.3)) * 1024 * 1024)
        )

        resp = await self.patch(
            self.config.tasks_url,
            json={
                "type": "user#runner",
                "id": device.get("id"),
                "set_params": {"set_device_config": f'{{"speed_limit":{speed_bytes}}}'},
            },
        )
        return resp is not None

    async def set_concurrent_downloads(
        self,
        device_name: str,
        num: int = 3,
    ) -> bool:
        """
        设置同时下载任务数

        Args:
            device_name: 设备名称
            num: 同时下载数 (1-5)

        Returns:
            是否成功
        """
        devices = await self.get_devices()
        if not devices:
            return False

        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return False

        num = max(1, min(5, num))

        resp = await self.patch(
            self.config.tasks_url,
            json={
                "type": "user#runner",
                "id": device.get("id"),
                "set_params": {"set_device_config": f'{{"runner_count":{num}}}'},
            },
        )
        return resp is not None

    # ==================== 云盘资源下载 ====================

    async def download_from_yunpan(
        self,
        device_name: str,
        yunpan_path: str,
        target_folder: str = "",
    ) -> bool:
        """
        从云盘下载资源到远程设备

        Args:
            device_name: 设备名称
            yunpan_path: 云盘资源路径
            target_folder: 远程设备目标文件夹

        Returns:
            是否成功
        """
        from .cloud_disk import XunleiCloudDisk

        # 获取云盘文件信息
        cloud = XunleiCloudDisk(self.username, self.password)
        cloud.cache = self.cache

        file_info = await cloud.get_file_info(yunpan_path)
        if not file_info:
            return False

        # 获取设备
        devices = await self.get_devices()
        if not devices:
            return False

        device = next((d for d in devices if d.get("name") == device_name), None)
        if not device:
            return False

        # 构建任务参数
        resp = await self.post(
            self.config.tasks_url,
            json={
                "space": device.get("device_id"),
                "type": "user#download",
                "file_name": file_info.get("name"),
                "file_size": file_info.get("size", 0),
                "params": {
                    "target": device.get("device_id"),
                    "file_id": file_info.get("id"),
                },
            },
        )
        return resp is not None

    # ==================== 远程文件夹 ====================

    async def create_remote_folder(
        self,
        device_name: str,
        folder_path: str,
    ) -> bool:
        """
        在远程设备创建文件夹

        Args:
            device_name: 设备名称
            folder_path: 文件夹路径

        Returns:
            是否成功
        """
        parts = split_path(folder_path)
        parent_id = ""

        for part in parts:
            resp = await self.post(
                self.config.files_url,
                json={
                    "kind": "drive#folder",
                    "name": part,
                    "parent_id": parent_id,
                    "space": device_name,
                },
            )
            if not resp:
                return False
            parent_id = resp.get("file", {}).get("id", "")

        return True
