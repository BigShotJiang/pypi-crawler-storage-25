from enum import Enum


class CacheStrategy(Enum):
    """缓存策略枚举"""

    DISABLED = "disabled"
    SESSION = "session"
    PERSISTENT = "persistent"


class SearchType(str, Enum):
    """搜索类型枚举"""

    FILE = "file"
    FOLDER = "folder"


class CapacityExceededStrategy(Enum):
    """容量超限时的处理策略

    说明:
        - ABORT: 终止模式 - 检测到任何文件超出可用空间则终止全部上传任务
        - SMALL_FIRST: 小文件优先 - 先上传能够容纳的小文件，忽略大文件
        - LARGE_FIRST: 大文件优先 - 先上传大文件，如果空间不足则尝试上传小文件
        - SKIP: 逐个转存，超出容量时跳过该文件
    """

    ABORT = "abort"
    SMALL_FIRST = "small_first"
    LARGE_FIRST = "large_first"
    SKIP = "skip"


class CloudFileExistsStrategy(Enum):
    """云盘文件存在时处理策略"""

    SKIP = "skip"
    RENAME = "rename"
    OVERWRITE = "overwrite"
    ABORT_ALL = "abort_all"
    ABORT_LOCAL = "abort_local"


class RemoteDownloadConflictStrategy(Enum):
    """远程下载任务重名处理策略"""

    SKIP = "skip"
    RECREATE = "recreate"


class ExportFormat(Enum):
    """导出文件格式枚举"""

    JSON = "json"
    CSV = "csv"


class ShareLinkStrategy(Enum):
    """分享链接已存在时的处理策略

    说明:
        - SKIP: 存在就不重复创建，返回现有的携带提取码的完整分享链接
        - RECREATE: 创建一个新的，返回新建和现有的所有链接（新建的在第一个位置）
        - OVERWRITE: 删除现有的所有分享链接，然后创建一个新的
    """

    SKIP = "skip"
    RECREATE = "recreate"
    OVERWRITE = "overwrite"


class TransferOwnShareStrategy(Enum):
    """转存自己分享链接时的处理策略"""

    SKIP = "skip"
    COPY = "copy"
    MOVE = "move"


class ShareAfterTransferStrategy(Enum):
    """转存后创建分享链接的策略"""

    NO_CREATE = "no_create"
    CREATE = "create"
    CREATE_ALL = "create_all"


class FailureStrategy(Enum):
    """任务失败时的处理策略

    说明:
        - SKIP: 跳过失败任务，继续处理其他任务
        - DEFERRED_RETRY: 失败任务放到队列末尾，稍后重试（推荐）
        - IMMEDIATE_RETRY: 立即重试当前失败任务
        - BLOCKING_RETRY: 暂停其他任务，先重试失败任务
        - ABORT: 遇到失败就终止所有任务
    """

    SKIP = "skip"
    DEFERRED_RETRY = "deferred_retry"
    IMMEDIATE_RETRY = "immediate_retry"
    BLOCKING_RETRY = "blocking_retry"
    ABORT = "abort"


class ConcurrencyAdjustmentStrategy(Enum):
    """并发数动态调整策略

    说明:
        - MAINTAIN: 保持不变
        - REDUCE_ON_FAILURE: 失败时减少并发数
        - INCREASE_ON_SUCCESS: 连续成功后增加并发数
        - ADAPTIVE: 智能自适应，失败减半，成功加1（推荐）
    """

    MAINTAIN = "maintain"
    REDUCE_ON_FAILURE = "reduce_on_failure"
    INCREASE_ON_SUCCESS = "increase_on_success"
    ADAPTIVE = "adaptive"


class TaskOrderStrategy(Enum):
    """任务排序策略

    说明:
        - NATURAL: 按原始顺序
        - SMALL_FIRST: 小文件优先（空间不足时上传更多文件）
        - LARGE_FIRST: 大文件优先
        - RANDOM: 随机顺序
    """

    NATURAL = "natural"
    SMALL_FIRST = "small_first"
    LARGE_FIRST = "large_first"
    RANDOM = "random"


class FileTypeFilter(str, Enum):
    """文件类型过滤器枚举

    用于按文件类型筛选文件，如视频、音频、图片等。

    使用方式:
        - 直接使用枚举值: [FileTypeFilter.VIDEO]
        - 获取扩展名列表: FileTypeFilter.VIDEO.get_extensions()
        - 获取MIME类型: FileTypeFilter.VIDEO.value
    """

    VIDEO = "video/"
    AUDIO = "audio/"
    IMAGE = "image/"
    DOCUMENT = "document/"
    ARCHIVE = "archive/"

    @staticmethod
    def _get_extensions_list(ext_tuple: tuple[str, ...]) -> list[str]:
        """将扩展名元组转换为列表"""
        return list(ext_tuple)

    def get_extensions(self) -> list[str]:
        """获取该类型对应的文件扩展名列表"""
        if self == FileTypeFilter.VIDEO:
            return self._get_extensions_list(VIDEO_EXTENSIONS)
        elif self == FileTypeFilter.AUDIO:
            return self._get_extensions_list(AUDIO_EXTENSIONS)
        elif self == FileTypeFilter.IMAGE:
            return self._get_extensions_list(IMAGE_EXTENSIONS)
        elif self == FileTypeFilter.DOCUMENT:
            return self._get_extensions_list(DOCUMENT_EXTENSIONS)
        elif self == FileTypeFilter.ARCHIVE:
            return self._get_extensions_list(ARCHIVE_EXTENSIONS)
        return []

    @classmethod
    def video_extensions(cls) -> list[str]:
        """获取视频文件扩展名列表"""
        return list(cls.VIDEO_EXTENSIONS)

    @classmethod
    def audio_extensions(cls) -> list[str]:
        """获取音频文件扩展名列表"""
        return list(cls.AUDIO_EXTENSIONS)

    @classmethod
    def image_extensions(cls) -> list[str]:
        """获取图片文件扩展名列表"""
        return list(cls.IMAGE_EXTENSIONS)

    @classmethod
    def document_extensions(cls) -> list[str]:
        """获取文档文件扩展名列表"""
        return list(cls.DOCUMENT_EXTENSIONS)

    @classmethod
    def archive_extensions(cls) -> list[str]:
        """获取压缩文件扩展名列表"""
        return list(cls.ARCHIVE_EXTENSIONS)


VIDEO_EXTENSIONS = (
    ".mp4",
    ".mkv",
    ".avi",
    ".mov",
    ".wmv",
    ".flv",
    ".webm",
    ".m4v",
    ".mpg",
    ".mpeg",
    ".3gp",
    ".ogv",
)
AUDIO_EXTENSIONS = (
    ".mp3",
    ".wav",
    ".flac",
    ".aac",
    ".m4a",
    ".ogg",
    ".wma",
    ".opus",
    ".ape",
    ".ac3",
)
IMAGE_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".bmp",
    ".webp",
    ".svg",
    ".ico",
    ".tiff",
    ".tif",
    ".psd",
    ".raw",
)
DOCUMENT_EXTENSIONS = (
    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    ".txt",
    ".md",
    ".rtf",
    ".odt",
    ".ods",
    ".odp",
)
ARCHIVE_EXTENSIONS = (
    ".zip",
    ".rar",
    ".7z",
    ".tar",
    ".gz",
    ".bz2",
    ".xz",
    ".iso",
    ".dmg",
)
