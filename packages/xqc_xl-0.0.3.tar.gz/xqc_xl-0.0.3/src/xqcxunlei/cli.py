"""
Xunlei CLI 命令行工具

提供命令行接口来操作迅雷云盘

用法:
    xqcxunlei [选项] 命令 [参数]

示例:
    # 登录并获取用户信息
    xqcxunlei login -u phone-number -p secret

    # 查看云盘空间
    xqcxunlei space

    # 列出根目录文件
    xqcxunlei ls

    # 搜索文件
    xqcxunlei search 电影

    # 创建文件夹
    xqcxunlei mkdir /test/新建目录

    # 上传文件
    xqcxunlei upload 本地文件.txt /test/

    # 下载文件
    xqcxunlei download /test/文件.txt

    # 创建分享链接
    xqcxunlei share /test/文件.txt

    # 远程下载
    xqcxunlei remote-add "magnet:?xt=urn:btih:..." --device 设备名

    # 获取帮助
    xqcxunlei --help
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any

from xqcxunlei import Xunlei
from xqcxunlei.utils import MessageType, send_message

_manual_credentials: tuple[str, str] | None = None


def get_xunlei_client() -> Xunlei:
    """
    获取 Xunlei 客户端实例

    优先级：
    1. 手动登录的账号（通过 xqcxunlei login 设置）
    2. .env 或环境变量中的账号
    """
    if _manual_credentials:
        username, password = _manual_credentials
        return Xunlei(username=username, password=password)
    return Xunlei()


def format_size(size_bytes: int) -> str:
    """格式化文件大小"""
    if size_bytes == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(size_bytes)
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    return f"{size:.2f} {units[i]}"


def format_file_info(file_info: dict[str, Any], show_path: bool = False) -> str:
    """格式化文件信息为可读字符串"""
    name = file_info.get("name", "")
    kind = file_info.get("kind", "")
    is_folder = kind == "drive#folder"

    if is_folder:
        output = f"📁 {name}/"
    else:
        size = file_info.get("size", 0)
        output = f"📄 {name} ({format_size(size)})"

    if show_path:
        path = file_info.get("path", "")
        if path:
            output += f"\n   路径: {path}"

    return output


async def cmd_login(args: argparse.Namespace) -> int:
    """登录命令"""
    global _manual_credentials
    username = args.username
    password = args.password

    if not username or not password:
        print("错误: 用户名和密码都是必需的")
        return 1

    async with Xunlei(username, password) as xunlei:
        if xunlei.is_login:
            user_info = await xunlei.get_user_info()
            if user_info:
                _manual_credentials = (username, password)
                print("✓ 登录成功!")
                print(f"  用户名: {username}")
                print(f"  用户ID: {user_info.get('user_id', 'N/A')}")
                print("  后续命令将自动使用此账号")
                return 0
        print("✗ 登录失败")
        return 1


async def cmd_space(args: argparse.Namespace) -> int:
    """查看云盘空间命令"""
    async with get_xunlei_client() as xunlei:
        info = await xunlei.get_space_info(human_readable=True)
        if info:
            print("云盘空间信息:")
            print(f"  总空间: {info.get('limit_formatted', 'N/A')}")
            print(f"  已使用: {info.get('usage_formatted', 'N/A')}")
            print(f"  回收站: {info.get('usage_in_trash_formatted', 'N/A')}")
            print(f"  剩余空间: {info.get('free_space_formatted', 'N/A')}")
            return 0
        print("✗ 获取空间信息失败")
        return 1


async def cmd_ls(args: argparse.Namespace) -> int:
    """列出文件命令"""
    path = args.path or "/"
    async with get_xunlei_client() as xunlei:
        try:
            info = await xunlei.get_file_info(path)
            if not info:
                print(f"✗ 路径不存在: {path}")
                return 1

            if info.get("kind") == "drive#folder":
                files = await xunlei.cloud.get_files(parent_id=info.get("id", ""))
                if files:
                    print(f"{path} 目录内容:")
                    for f in files:
                        print(f"  {format_file_info(f)}")
                else:
                    print("目录为空")
            else:
                print(format_file_info(info, show_path=True))
            return 0
        except Exception as e:
            print(f"✗ 列出文件失败: {e}")
            return 1


async def cmd_search(args: argparse.Namespace) -> int:
    """搜索文件命令"""
    query = args.query
    if not query:
        print("错误: 搜索关键词是必需的")
        return 1

    path = args.path
    max_results = args.max_results or 100
    auto_share = args.auto_share

    async with get_xunlei_client() as xunlei:
        try:
            result = await xunlei.search(
                query=query,
                path=path if path != "/" else None,
                max_results=max_results,
                auto_share=auto_share,
            )

            files = result.get("files", [])
            if not files:
                print(f"未找到包含 '{query}' 的文件")
                return 0

            print(f"找到 {len(files)} 个结果:")
            for f in files:
                output = format_file_info(f, show_path=True)
                share_links = f.get("share_links", [])
                if share_links:
                    output += "\n   分享链接:"
                    for link in share_links:
                        output += f"\n     {link}"
                if auto_share and "share_created" in f:
                    output += "\n     (已创建分享)" if f.get("share_created") else ""
                print(f"  {output}")

            if auto_share and "share_summary" in result:
                summary = result["share_summary"]
                print(f"\n分享汇总: 共 {summary.get('newly_created', 0)} 个新创建分享")
            return 0
        except Exception as e:
            print(f"✗ 搜索失败: {e}")
            return 1


async def cmd_mkdir(args: argparse.Namespace) -> int:
    """创建文件夹命令"""
    path = args.path
    if not path:
        print("错误: 路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            result = await xunlei.create_folder(path)
            if result.get("success"):
                print(f"✓ 文件夹创建成功: {path}")
                return 0
            else:
                print(f"✗ 创建失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 创建文件夹失败: {e}")
            return 1


async def cmd_upload(args: argparse.Namespace) -> int:
    """上传文件命令"""
    local_path = args.local_path
    target_path = args.target_path or "/"

    if not local_path:
        print("错误: 本地文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在上传: {local_path} -> {target_path}")
            result = await xunlei.upload(local_path, target_path)
            if result.success:
                print("✓ 上传成功!")
                print(f"  文件ID: {result.file_id}")
                print(f"  路径: {result.target_path}")
                return 0
            else:
                print(f"✗ 上传失败: {result.error or result.message}")
                return 1
        except Exception as e:
            print(f"✗ 上传失败: {e}")
            return 1


async def cmd_download(args: argparse.Namespace) -> int:
    """下载文件命令"""
    path = args.path
    local_path = args.local_path

    if not path:
        print("错误: 云盘文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在获取下载链接: {path}")
            result = await xunlei.download(path, local_path)
            if result.success:
                print(f"✓ 下载成功: {result.local_path}")
                return 0
            else:
                print(f"✗ 下载失败: {result.error or result.message}")
                return 1
        except Exception as e:
            print(f"✗ 下载失败: {e}")
            return 1


async def cmd_share(args: argparse.Namespace) -> int:
    """创建分享链接命令"""
    path = args.path
    if not path:
        print("错误: 文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在创建分享链接: {path}")
            result = await xunlei.create_share_link(path)
            if result.get("success"):
                share_links = result.get("share_links", [])
                share_link = share_links[0] if share_links else ""
                print("✓ 分享链接创建成功!")
                print(f"  链接: {share_link}")
                return 0
            else:
                print(f"✗ 创建失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 创建分享链接失败: {e}")
            return 1


async def cmd_transfer(args: argparse.Namespace) -> int:
    """转存分享链接命令"""
    share_link = args.share_link
    pass_code = args.pass_code
    target_path = args.target_path or "/"

    if not share_link:
        print("错误: 分享链接是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在转存: {share_link}")
            result = await xunlei.transfer_share(share_link, pass_code, target_path)
            if result.success:
                print("✓ 转存成功!")
                print(f"  转存文件数: {result.total_files}")
                return 0
            else:
                print(f"✗ 转存失败: {result.message}")
                return 1
        except Exception as e:
            print(f"✗ 转存失败: {e}")
            return 1


async def cmd_remote_devices(args: argparse.Namespace) -> int:
    """列出远程设备命令"""
    async with get_xunlei_client() as xunlei:
        try:
            devices = await xunlei.get_remote_devices(include_offline=True)
            if not devices:
                print("未找到远程设备")
                print("提示: 请确保已在 https://pan.xunlei.com/yc 开启远程下载功能")
                return 0

            print(f"找到 {len(devices)} 个设备:")
            for d in devices:
                status = "🟢 在线" if d.get("online") else "🔴 离线"
                print(f"  {status} {d.get('name', '未知设备')}")
            return 0
        except Exception as e:
            print(f"✗ 获取设备列表失败: {e}")
            return 1


async def cmd_remote_add(args: argparse.Namespace) -> int:
    """添加远程下载任务命令"""
    url = args.url
    device_name = args.device

    if not url:
        print("错误: 下载链接是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            device = (
                await xunlei.get_remote_device(device_name)
                if device_name
                else await xunlei.get_remote_device()
            )
            if not device:
                print("✗ 未找到可用设备")
                return 1

            print(f"正在添加任务到设备: {device.get('name')}")
            result = await xunlei.create_download_task(url, device.get("name"))
            if result.get("success"):
                print("✓ 任务添加成功!")
                print(f"  任务ID: {result.get('task_id')}")
                return 0
            else:
                print(f"✗ 添加失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 添加远程任务失败: {e}")
            return 1


async def cmd_remote_tasks(args: argparse.Namespace) -> int:
    """列出远程任务命令"""
    device_name = args.device

    async with get_xunlei_client() as xunlei:
        try:
            device = (
                await xunlei.get_remote_device(device_name)
                if device_name
                else await xunlei.get_remote_device()
            )
            if not device:
                print("✗ 未找到可用设备")
                return 1

            tasks = await xunlei.get_remote_tasks(device.get("name"))
            if not tasks:
                print("设备上没有任务")
                return 0

            print(f"设备 '{device.get('name')}' 的任务:")
            for t in tasks:
                status = t.get("phase", "").replace("PHASE_TYPE_", "")
                name = t.get("name", "未知任务")
                progress = t.get("progress", 0)
                print(f"  [{status}] {name} ({progress}%)")
            return 0
        except Exception as e:
            print(f"✗ 获取任务列表失败: {e}")
            return 1


async def cmd_delete(args: argparse.Namespace) -> int:
    """删除文件命令"""
    path = args.path
    permanent = args.permanent

    if not path:
        print("错误: 文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            action = "永久删除" if permanent else "移到回收站"
            print(f"正在 {action}: {path}")
            result = await xunlei.delete(path, permanent=permanent)
            if result.get("success"):
                print("✓ 删除成功")
                return 0
            else:
                print(f"✗ 删除失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 删除失败: {e}")
            return 1


async def cmd_copy(args: argparse.Namespace) -> int:
    """复制文件命令"""
    source = args.source
    target = args.target

    if not source or not target:
        print("错误: 源路径和目标路径都是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在复制: {source} -> {target}")
            result = await xunlei.copy(source, target)
            if result.get("success"):
                print("✓ 复制成功")
                return 0
            else:
                print(f"✗ 复制失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 复制失败: {e}")
            return 1


async def cmd_move(args: argparse.Namespace) -> int:
    """移动文件命令"""
    source = args.source
    target = args.target

    if not source or not target:
        print("错误: 源路径和目标路径都是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在移动: {source} -> {target}")
            result = await xunlei.move(source, target)
            if result.get("success"):
                print("✓ 移动成功")
                return 0
            else:
                print(f"✗ 移动失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 移动失败: {e}")
            return 1


async def cmd_rename(args: argparse.Namespace) -> int:
    """重命名文件命令"""
    old_path = args.old
    new_name = args.new

    if not old_path or not new_name:
        print("错误: 原路径和新名称都是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            print(f"正在重命名: {old_path} -> {new_name}")
            result = await xunlei.rename(old_path, new_name)
            if result.get("success"):
                print("✓ 重命名成功")
                return 0
            else:
                print(f"✗ 重命名失败: {result.get('message', '未知错误')}")
                return 1
        except Exception as e:
            print(f"✗ 重命名失败: {e}")
            return 1


async def cmd_info(args: argparse.Namespace) -> int:
    """获取文件详情命令"""
    path = args.path

    if not path:
        print("错误: 文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            info = await xunlei.get_file_info(path)
            if not info:
                print(f"✗ 文件不存在: {path}")
                return 1

            print(f"文件信息: {path}")
            print(f"  名称: {info.get('name', 'N/A')}")
            print(f"  类型: {'文件夹' if info.get('kind') == 'drive#folder' else '文件'}")
            if info.get("size"):
                print(f"  大小: {format_size(info.get('size', 0))}")
            if info.get("mime_type"):
                print(f"  MIME类型: {info.get('mime_type')}")
            if info.get("path"):
                print(f"  路径: {info.get('path')}")
            share_links = info.get("share_links", [])
            if share_links:
                print("  分享链接:")
                for link in share_links:
                    print(f"    - {link}")
            return 0
        except Exception as e:
            print(f"✗ 获取文件信息失败: {e}")
            return 1


async def cmd_recycle_ls(args: argparse.Namespace) -> int:
    """列出回收站文件命令"""
    async with get_xunlei_client() as xunlei:
        try:
            info = await xunlei.get_recycle_bin_info()
            if info:
                files = info.get("files", [])
                if files:
                    print(f"回收站文件列表 (共 {len(files)} 个):")
                    for f in files:
                        name = f.get("name", "")
                        size = f.get("size", 0)
                        deleted_time = f.get("deleted_time", "N/A")
                        print(f"  📄 {name} ({format_size(size)}) - 删除时间: {deleted_time}")
                else:
                    print("回收站为空")
                return 0
            print("✗ 获取回收站信息失败")
            return 1
        except Exception as e:
            print(f"✗ 获取回收站信息失败: {e}")
            return 1


async def cmd_recycle_restore(args: argparse.Namespace) -> int:
    """恢复回收站文件命令"""
    file_path = args.path
    target = args.target or "/"

    if not file_path:
        print("错误: 文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            result = await xunlei.restore(file_id=file_path, target_parent=target)
            if result:
                print(f"✓ 文件已恢复到: {target}")
                return 0
            print("✗ 恢复文件失败")
            return 1
        except Exception as e:
            print(f"✗ 恢复文件失败: {e}")
            return 1


async def cmd_recycle_empty(args: argparse.Namespace) -> int:
    """清空回收站命令"""
    async with get_xunlei_client() as xunlei:
        try:
            success = await xunlei.empty_recycle_bin()
            if success:
                print("✓ 回收站已清空")
                return 0
            print("✗ 清空回收站失败")
            return 1
        except Exception as e:
            print(f"✗ 清空回收站失败: {e}")
            return 1


async def cmd_logout(args: argparse.Namespace) -> int:
    """登出命令"""
    async with get_xunlei_client() as xunlei:
        try:
            await xunlei.logout()
            print("✓ 已成功登出")
            return 0
        except Exception as e:
            print(f"✗ 登出失败: {e}")
            return 1


async def cmd_pause(args: argparse.Namespace) -> int:
    """暂停远程任务命令"""
    task_id = args.task_id
    device = args.device

    if not task_id:
        print("错误: 任务ID是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            await xunlei.pause_remote_task(task_id=task_id, device_name=device)
            print(f"✓ 任务已暂停: {task_id}")
            return 0
        except Exception as e:
            print(f"✗ 暂停任务失败: {e}")
            return 1


async def cmd_resume(args: argparse.Namespace) -> int:
    """恢复远程任务命令"""
    task_id = args.task_id
    device = args.device

    if not task_id:
        print("错误: 任务ID是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            await xunlei.resume_remote_task(task_id=task_id, device_name=device)
            print(f"✓ 任务已恢复: {task_id}")
            return 0
        except Exception as e:
            print(f"✗ 恢复任务失败: {e}")
            return 1


async def cmd_exists(args: argparse.Namespace) -> int:
    """检查文件是否存在命令"""
    path = args.path

    if not path:
        print("错误: 文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            exists = await xunlei.exists(path)
            if exists:
                print(f"✓ 文件存在: {path}")
                return 0
            else:
                print(f"✗ 文件不存在: {path}")
                return 1
        except Exception as e:
            print(f"✗ 检查失败: {e}")
            return 1


async def cmd_share_info(args: argparse.Namespace) -> int:
    """查看分享信息命令"""
    share_link = args.share_link
    pass_code = args.pass_code

    if not share_link:
        print("错误: 分享链接是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            info = await xunlei.get_share_info(targets=share_link)
            if not info:
                print("✗ 获取分享信息失败")
                return 1

            if isinstance(info, dict):
                print("分享信息:")
                print(f"  标题: {info.get('title', 'N/A')}")
                print(f"  创建时间: {info.get('create_time', 'N/A')}")
                print(f"  类型: {'目录' if info.get('file_count', 0) > 1 else '单文件'}")
                print(f"  文件数: {info.get('file_count', 'N/A')}")
                print(f"  大小: {format_size(info.get('total_size', 0))}")
                share_url = info.get("share_url", "")
                if share_url:
                    full_url = f"{share_url}?pwd={pass_code}" if pass_code else share_url
                    print(f"  链接: {full_url}")
                return 0
            print("✗ 获取分享信息失败")
            return 1
        except Exception as e:
            print(f"✗ 获取分享信息失败: {e}")
            return 1


async def cmd_cancel_share(args: argparse.Namespace) -> int:
    """取消分享命令"""
    paths = args.paths

    if not paths:
        print("错误: 文件路径是必需的")
        return 1

    async with get_xunlei_client() as xunlei:
        try:
            result = await xunlei.cancel_share_link(targets=paths)
            if isinstance(result, dict):
                if result.get("success"):
                    print("✓ 取消分享成功")
                    return 0
                else:
                    print(f"✗ 取消分享失败: {result.get('message', '未知错误')}")
                    return 1
            elif isinstance(result, list):
                success_count = sum(1 for r in result if r.get("success"))
                print(f"✓ 成功取消 {success_count}/{len(result)} 个分享")
                return 0
            print("✗ 取消分享失败")
            return 1
        except Exception as e:
            print(f"✗ 取消分享失败: {e}")
            return 1


async def cmd_notify(args: argparse.Namespace) -> int:
    """发送通知命令"""
    content = args.content
    title = args.title
    msg_type = args.type

    message_type_map = {
        "text": MessageType.TEXT,
        "markdown": MessageType.MARKDOWN,
        "html": MessageType.HTML,
    }
    message_type = message_type_map.get(msg_type, MessageType.TEXT)

    server_url = args.server_url
    token = args.token

    if server_url or token:
        result = await send_message(
            content=content,
            title=title,
            message_type=message_type,
            server_url=server_url,
            token=token,
        )
    else:
        result = await send_message(
            content=content,
            title=title,
            message_type=message_type,
        )

    if result.success:
        print(f"✓ 通知发送成功: {result.message}")
        return 0
    else:
        print(f"✗ 通知发送失败: {result.message}")
        return 1


async def cmd_skill_install(args: argparse.Namespace) -> int:
    """安装 skill 命令"""
    import shutil
    from pathlib import Path

    target_dir = args.target_dir
    skill_name = args.name or "xqcxunlei-skill"

    target_path = Path(target_dir) / skill_name

    try:
        skill_source = Path(__file__).parent / "xqcxunlei-skill"
        if not skill_source.exists():
            print(f"✗ Skill 源目录不存在: {skill_source}")
            return 1

        if target_path.exists():
            if args.force:
                shutil.rmtree(target_path)
                print(f"已删除已存在的目录: {target_path}")
            else:
                print(f"✗ Skill 目录已存在: {target_path}")
                print("  使用 --force 强制覆盖")
                return 1

        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(skill_source, target_path)

        print("✓ Skill 安装成功!")
        print(f"  目标路径: {target_path}")
        print("  使用方式: 在 AI 助手中加载此 skill 即可使用 xqcxunlei 相关功能")
        return 0
    except Exception as e:
        print(f"✗ Skill 安装失败: {e}")
        return 1


def create_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        prog="xqcxunlei",
        description="迅雷云盘 Python SDK CLI 工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  xqcxunlei login -u phone-number -p secret
  xqcxunlei space
  xqcxunlei ls /test
  xqcxunlei search 电影
  xqcxunlei mkdir /test/新建目录
  xqcxunlei upload 本地文件.txt /test/
  xqcxunlei download /test/文件.txt
  xqcxunlei share /test/文件.txt
  xqcxunlei transfer "https://pan.xunlei.com/s/xxx" 1234
  xqcxunlei remote-devices
  xqcxunlei remote-add "magnet:?xt=..." --device 我的设备
  xqcxunlei remote-tasks
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    login_parser = subparsers.add_parser("login", help="登录账号")
    login_parser.add_argument("-u", "--username", required=True, help="迅雷用户名")
    login_parser.add_argument("-p", "--password", required=True, help="迅雷密码")

    subparsers.add_parser("space", help="查看云盘空间")

    ls_parser = subparsers.add_parser("ls", help="列出目录文件")
    ls_parser.add_argument("path", nargs="?", default="/", help="目录路径")

    search_parser = subparsers.add_parser("search", help="搜索文件")
    search_parser.add_argument("query", help="搜索关键词")
    search_parser.add_argument("--path", "-p", default=None, help="搜索目录")
    search_parser.add_argument("-n", "--max-results", type=int, default=100, help="最大结果数")
    search_parser.add_argument(
        "--auto-share", action="store_true", default=False, help="为没有分享的文件自动创建分享链接"
    )

    mkdir_parser = subparsers.add_parser("mkdir", help="创建文件夹")
    mkdir_parser.add_argument("path", help="文件夹路径")

    subparsers.add_parser("logout", help="登出账号")

    exists_parser = subparsers.add_parser("exists", help="检查文件是否存在")
    exists_parser.add_argument("path", help="文件路径")

    upload_parser = subparsers.add_parser("upload", help="上传文件")
    upload_parser.add_argument("local_path", help="本地文件路径")
    upload_parser.add_argument("target_path", nargs="?", default="/", help="云盘目标路径")

    download_parser = subparsers.add_parser("download", help="下载文件")
    download_parser.add_argument("path", help="云盘文件路径")
    download_parser.add_argument("-o", "--local-path", default=None, help="本地保存路径")

    share_parser = subparsers.add_parser("share", help="创建分享链接")
    share_parser.add_argument("path", help="文件路径")

    transfer_parser = subparsers.add_parser("transfer", help="转存分享链接")
    transfer_parser.add_argument("share_link", help="分享链接")
    transfer_parser.add_argument("pass_code", nargs="?", default="", help="提取码")
    transfer_parser.add_argument("-t", "--target-path", default="/", help="目标路径")

    subparsers.add_parser("remote-devices", help="列出远程设备")

    remote_add_parser = subparsers.add_parser("remote-add", help="添加远程下载任务")
    remote_add_parser.add_argument("url", help="下载链接(Magnet/HTTP)")
    remote_add_parser.add_argument("--device", "-d", default=None, help="设备名称")

    remote_tasks_parser = subparsers.add_parser("remote-tasks", help="列出远程任务")
    remote_tasks_parser.add_argument("--device", "-d", default=None, help="设备名称")

    pause_parser = subparsers.add_parser("pause", help="暂停远程任务")
    pause_parser.add_argument("task_id", help="任务ID")
    pause_parser.add_argument("--device", "-d", default=None, help="设备名称")

    resume_parser = subparsers.add_parser("resume", help="恢复远程任务")
    resume_parser.add_argument("task_id", help="任务ID")
    resume_parser.add_argument("--device", "-d", default=None, help="设备名称")

    delete_parser = subparsers.add_parser("delete", help="删除文件")
    delete_parser.add_argument("path", help="文件路径")
    delete_parser.add_argument("--permanent", "-P", action="store_true", help="永久删除")

    copy_parser = subparsers.add_parser("copy", help="复制文件")
    copy_parser.add_argument("source", help="源路径")
    copy_parser.add_argument("target", help="目标路径")

    move_parser = subparsers.add_parser("move", help="移动文件")
    move_parser.add_argument("source", help="源路径")
    move_parser.add_argument("target", help="目标路径")

    rename_parser = subparsers.add_parser("rename", help="重命名文件")
    rename_parser.add_argument("old", help="原路径")
    rename_parser.add_argument("new", help="新名称")

    info_parser = subparsers.add_parser("info", help="获取文件详情")
    info_parser.add_argument("path", help="文件路径")

    share_info_parser = subparsers.add_parser("share-info", help="查看分享信息")
    share_info_parser.add_argument("share_link", help="分享链接")
    share_info_parser.add_argument("--pass-code", "-p", default="", help="提取码")

    cancel_share_parser = subparsers.add_parser("cancel-share", help="取消分享链接")
    cancel_share_parser.add_argument("paths", nargs="+", help="文件路径列表")

    recycle_parser = subparsers.add_parser("recycle", help="回收站管理")
    recycle_subparsers = recycle_parser.add_subparsers(dest="subcommand", help="回收站子命令")
    recycle_subparsers.add_parser("ls", help="列出回收站文件")
    recycle_subparsers.add_parser("list", help="列出回收站文件", aliases=["la"])

    recycle_restore_parser = recycle_subparsers.add_parser("restore", help="恢复回收站文件")
    recycle_restore_parser.add_argument("path", help="文件ID或路径")
    recycle_restore_parser.add_argument("--target", "-t", default="/", help="目标路径")

    recycle_subparsers.add_parser("empty", help="清空回收站")
    recycle_subparsers.add_parser("clear", help="清空回收站")

    notify_parser = subparsers.add_parser("notify", help="发送通知消息")
    notify_parser.add_argument("content", help="通知内容")
    notify_parser.add_argument("--title", "-t", default=None, help="通知标题")
    notify_parser.add_argument(
        "--type",
        "-T",
        default="text",
        choices=["text", "markdown", "html"],
        help="消息类型",
    )
    notify_parser.add_argument("--server-url", "-s", default=None, help="MagicPush 服务器地址")
    notify_parser.add_argument("--token", "-k", default=None, help="MagicPush 访问令牌")

    skill_parser = subparsers.add_parser("skill-install", help="安装 skill 到指定目录")
    skill_parser.add_argument(
        "target_dir",
        nargs="?",
        default="skills",
        help="目标目录 (默认: skills)",
    )
    skill_parser.add_argument(
        "--name",
        "-n",
        default=None,
        help="Skill 名称 (默认: xqcxunlei-skill)",
    )
    skill_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="强制覆盖已存在的 skill 目录",
    )

    return parser


async def async_main() -> int:
    """异步主函数"""
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    cmd_map: dict[str, Any] = {
        "login": cmd_login,
        "space": cmd_space,
        "ls": cmd_ls,
        "search": cmd_search,
        "mkdir": cmd_mkdir,
        "logout": cmd_logout,
        "exists": cmd_exists,
        "upload": cmd_upload,
        "download": cmd_download,
        "share": cmd_share,
        "transfer": cmd_transfer,
        "remote-devices": cmd_remote_devices,
        "remote-add": cmd_remote_add,
        "remote-tasks": cmd_remote_tasks,
        "pause": cmd_pause,
        "resume": cmd_resume,
        "delete": cmd_delete,
        "copy": cmd_copy,
        "move": cmd_move,
        "rename": cmd_rename,
        "info": cmd_info,
        "share-info": cmd_share_info,
        "cancel-share": cmd_cancel_share,
        "notify": cmd_notify,
        "skill-install": cmd_skill_install,
    }

    cmd_func = cmd_map.get(args.command)
    if cmd_func and asyncio.iscoroutinefunction(cmd_func):
        return await cmd_func(args)

    if args.command == "recycle":
        subcommand = getattr(args, "subcommand", None)
        if subcommand in ("ls", "list", "la"):
            return await cmd_recycle_ls(args)
        elif subcommand in ("restore",):
            return await cmd_recycle_restore(args)
        elif subcommand in ("empty", "clear"):
            return await cmd_recycle_empty(args)
        else:
            parser.print_help()
            return 1

    print(f"错误: 未知命令 '{args.command}'")
    return 1


def main() -> int:
    """主入口函数"""
    try:
        return asyncio.run(async_main())
    except KeyboardInterrupt:
        print("\n操作已取消")
        return 130
    except Exception as e:
        print(f"错误: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
