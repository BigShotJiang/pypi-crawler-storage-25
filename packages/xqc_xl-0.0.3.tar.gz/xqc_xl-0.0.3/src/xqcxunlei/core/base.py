"""
Xunlei API 核心基类

提供统一的同步/异步双兼容架构:
- 自动识别运行环境
- 提供统一的调用接口
- 支持同步和异步操作
- 统一错误处理
- 令牌管理和自动刷新
"""

from __future__ import annotations

import asyncio
import hashlib
from typing import Any, Dict, Optional

from ..auth import TokenCache
from ..auth.captcha_sign import get_pub_key_sign
from ..client import RetryClient
from ..config import get_config
from ..utils.exceptions import (
    AuthenticationError,
    LoginRequiredError,
    NetworkError,
    PermissionDeniedError,
    RateLimitError,
    ServiceUnavailableError,
    XunleiError,
    get_logger,
    handle_http_error,
)

logger = get_logger(__name__)


class BaseAPI:
    """
    Xunlei API 基础类

    提供统一的同步/异步接口:
    - 自动识别运行环境
    - 同步和异步方法
    - 统一错误处理
    - Token 管理
    """

    def __init__(
        self,
        username: str,
        password: str,
        cache_dir: Optional[str] = None,
    ) -> None:
        """
        初始化基础类

        Args:
            username: 迅雷用户名
            password: 迅雷密码
            cache_dir: Token 缓存目录
        """
        self.username = username
        self.password = password

        self.config = get_config()

        resolved_cache_dir = cache_dir or self.config.cache_dir

        self.cache = TokenCache(
            username,
            cache_dir=resolved_cache_dir,
        )

        self._client: Optional[RetryClient] = None
        self._is_initialized = False

    async def __aenter__(self) -> "BaseAPI":
        await self.open()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    async def open(self) -> None:
        """打开客户端"""
        if self._client is None:
            self._client = RetryClient()
            await self._client.open()

        # 尝试加载缓存
        await self.cache.load_async()
        self._is_initialized = True

    async def close(self) -> None:
        """关闭客户端"""
        if self._client is not None:
            await self._client.close()
            self._client = None

        await self.cache.close()
        self._is_initialized = False

    @property
    def client(self) -> RetryClient:
        """获取 HTTP 客户端"""
        if self._client is None:
            raise RuntimeError("Client not opened. Use 'async with' or call open()")
        return self._client

    @property
    def is_login(self) -> bool:
        """是否已登录"""
        return self.cache.is_login and self.cache.is_access_token_valid

    # ==================== 登录流程 ====================

    async def _get_device_id(self) -> Optional[str]:
        """获取设备 ID"""
        resp = await self.client.post(
            self.config.risk_url,
            params={"cmd": "report"},
            json={
                "xl_fp_raw": "53793f98c0f944f0837946d9d694c55b",
                "xl_fp": "dfe57c652a6400764d825dcfb9ea1e17",
                "version": 2,
                "xl_fp_sign": "c8f4a425a1cfd1d8029b0151735d3d7a",
            },
        )

        if resp and resp.is_success:
            data = resp.json()
            device_sign = data.get("deviceid", "")
            if device_sign:
                device_id = device_sign.split(".")[-1][:32]
                self.cache.update(device_id=device_id)
                return device_id

        return None

    async def _get_captcha_token_for_login(self) -> Optional[str]:
        """获取登录用的 captcha_token"""
        device_id = await self._get_device_id()
        if not device_id:
            return None

        resp = await self.client.post(
            self.config.captcha_init_url,
            json={
                "client_id": self.config.login_client_id,
                "action": "POST:/v1/auth/signin",
                "device_id": device_id,
                "meta": {"username": self.username},
            },
        )

        if resp and resp.is_success:
            return resp.json().get("captcha_token")
        return None

    async def _do_login(self) -> bool:
        """执行登录"""
        captcha_token = await self._get_captcha_token_for_login()
        if not captcha_token:
            logger.error("获取登录 captcha_token 失败")
            return False

        # MD5 加密密码
        encrypted_password = hashlib.md5(self.password.encode()).hexdigest()

        resp = await self.client.post(
            self.config.signin_url,
            headers={"x-captcha-token": captcha_token},
            json={
                "username": self.username,
                "password": encrypted_password,
                "client_id": self.config.login_client_id,
            },
        )

        if resp and resp.is_success:
            data = resp.json()
            if data.get("access_token"):
                self.cache.set_login(
                    access_token=data["access_token"],
                    user_id=data.get("user_id", ""),
                    expires_in=data.get("expires_in", self.config.access_token_expires),
                )
                logger.info(f"登录成功: {self.username}")
                return True

        logger.error(f"登录失败: {resp.text if resp else 'No response'}")
        return False

    async def _get_token_code(self) -> Optional[str]:
        """获取刷新 Token 用的 code"""
        if not self.cache.tokens.access_token:
            return None

        resp = await self.client.post(
            self.config.authorize_url,
            headers={"Authorization": f"Bearer {self.cache.tokens.access_token}"},
            json={
                "client_id": self.config.token_client_id,
                "response_type": "code",
                "redirect_uri": self.config.redirect_uri,
                "state": self.config.state,
                "scope": self.config.scope,
                "code_challenge": self.config.code_challenge,
                "code_challenge_method": self.config.code_challenge_method,
                "sign_out_uri": "https://pan.xunlei.com/remote/signout/?sso_sign_out=",
            },
        )

        if resp and resp.is_success:
            return resp.json().get("code")
        return None

    async def _refresh_access_token(self) -> bool:
        """刷新 access_token"""
        code = await self._get_token_code()
        if not code:
            return False

        resp = await self.client.post(
            self.config.token_url,
            json={
                "code": code,
                "grant_type": "authorization_code",
                "code_verifier": self.config.code_verifier,
                "redirect_uri": self.config.redirect_uri,
                "client_id": self.config.token_client_id,
            },
        )

        if resp and resp.is_success:
            data = resp.json()
            if data.get("access_token"):
                self.cache.set_access_token(
                    data["access_token"],
                    expires_in=data.get("expires_in", self.config.access_token_expires),
                )
                logger.debug("access_token 已刷新")
                return True

        return False

    async def _refresh_captcha_token(self) -> bool:
        """刷新 captcha_token"""
        device_id = self.cache.tokens.device_id
        if not device_id:
            logger.warning("没有 device_id, 无法刷新 captcha_token")
            return False

        import time

        timestamp = str(int(time.time() * 1000))
        captcha_sign = await get_pub_key_sign(device_id, timestamp)

        resp = await self.client.post(
            self.config.captcha_init_url,
            json={
                "client_id": self.config.token_client_id,
                "action": "GET:CAPTCHA_TOKEN",
                "device_id": device_id,
                "meta": {
                    "user_id": self.cache.tokens.user_id,
                    "user_name": self.username,
                    "client_version": self.config.client_version,
                    "package_name": self.config.package_name,
                    "timestamp": timestamp,
                    "captcha_sign": captcha_sign,
                },
            },
        )

        if resp and resp.is_success:
            token = resp.json().get("captcha_token")
            if token:
                self.cache.set_captcha_token(
                    token,
                    expires_in=self.config.captcha_token_expires,
                )
                logger.debug("captcha_token 已刷新")
                return True

        return False

    async def login(self) -> bool:
        """
        登录

        如果缓存有效则跳过登录, 否则执行完整登录流程
        """
        try:
            # 检查是否已登录且 Token 有效
            if self.cache.is_login and self.cache.is_access_token_valid:
                # 检查是否需要刷新 captcha_token
                if self.cache.is_captcha_token_valid and not self.cache.tokens.needs_refresh:
                    logger.debug("使用缓存登录")
                    return True

                # 刷新 captcha_token
                if await self._refresh_captcha_token():
                    return True

                # Token 过期, 尝试刷新
                if await self._refresh_access_token():
                    return await self._refresh_captcha_token()

                return False

            # 执行登录
            if not await self._do_login():
                return False

            # 刷新 Token (获取云盘可用 Token)
            if not await self._refresh_access_token():
                logger.warning("刷新 access_token 失败, 继续使用登录 Token")

            # 获取 captcha_token
            await self._refresh_captcha_token()

            return True
        except XunleiError:
            # 重新抛出已知的 Xunlei 异常
            raise
        except Exception as e:
            logger.error(f"登录过程中发生未知错误: {str(e)}")
            return False

    async def logout(self) -> None:
        """登出"""
        self.cache.clear()
        logger.info("已登出")

    # ==================== HTTP 请求封装 ====================

    def _check_http_status(self, resp) -> None:
        """检查 HTTP 状态码并抛出相应异常"""
        if resp.status_code == 401:
            raise AuthenticationError(f"认证失败: {resp.text}")
        elif resp.status_code == 403:
            raise PermissionDeniedError(f"权限不足: {resp.text}")
        elif resp.status_code == 429:
            raise RateLimitError(f"请求频率过高: {resp.text}")
        elif resp.status_code in (500, 502, 503, 504):
            raise ServiceUnavailableError(f"服务暂时不可用 (状态码: {resp.status_code})")

    async def _handle_token_expired(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]],
        params: Optional[Dict[str, Any]],
        json: Optional[Dict[str, Any]],
        data: Optional[Dict[str, Any]],
        timeout: Optional[int],
    ) -> Optional[Dict[str, Any]]:
        """处理 Token 过期，重试请求"""
        logger.debug("Token 过期, 尝试刷新...")

        if await self._refresh_access_token():
            if await self._refresh_captcha_token():
                final_headers = self.cache.get_headers()
                if headers:
                    final_headers.update(headers)

                retry_resp = await self.client.request(
                    method, url, final_headers, params, json, data, timeout
                )

                if retry_resp and retry_resp.status_code == 200:
                    return retry_resp.json()
                elif retry_resp:
                    raise handle_http_error(retry_resp.status_code, retry_resp.text)
        return None

    async def api_request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        发送 HTTP 请求

        自动处理:
        - 登录状态检查
        - Token 刷新
        - 重试
        """
        try:
            if not self.cache.is_login:
                if not await self.login():
                    raise LoginRequiredError("登录失败，无法继续请求")

            final_headers = self.cache.get_headers()
            if headers:
                final_headers.update(headers)

            resp = await self.client.request_with_retry(
                method=method,
                url=url,
                headers=final_headers,
                params=params,
                json=json,
                data=data,
                timeout=timeout,
            )

            if resp is None:
                logger.warning(f"请求失败: {method} {url} - 无响应")
                return None

            if resp.status_code == 200:
                return resp.json()

            self._check_http_status(resp)

            if resp.status_code == 400:
                response_data = resp.json()
                if response_data and response_data.get("error") in (
                    "captcha_invalid",
                    "access_denied",
                ):
                    return await self._handle_token_expired(
                        method, url, headers, params, json, data, timeout
                    )

            logger.warning(f"请求失败: {resp.status_code} {resp.text}")
            return None

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"请求过程中发生未知错误: {str(e)}")
            raise NetworkError(f"网络请求异常: {str(e)}") from e

    async def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """GET 请求"""
        return await self.api_request("GET", url, headers=headers, params=params, timeout=timeout)

    async def post(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """POST 请求"""
        return await self.api_request(
            "POST", url, headers=headers, json=json, data=data, timeout=timeout
        )

    async def patch(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """PATCH 请求"""
        return await self.api_request("PATCH", url, headers=headers, json=json, timeout=timeout)

    # ==================== 工具方法 ====================

    # 注意: 工具函数 (如 split_path, format_sub_file_index, parse_torrent)
    # 已在 utils 模块中定义，此处不再重复定义


class SyncAsyncAPI:
    """
    同步/异步双兼容基类

    自动识别运行环境并选择合适的接口:
    - 在异步环境中返回协程对象
    - 在同步环境中直接执行并返回结果
    """

    def __init__(self, async_api: BaseAPI):
        """
        初始化双兼容接口

        Args:
            async_api: 异步API实例
        """
        self._async_api = async_api

    def _is_running_in_async(self) -> bool:
        """
        检查是否在异步环境中运行

        Returns:
            是否在异步环境中
        """
        try:
            asyncio.get_running_loop()
            return True
        except RuntimeError:
            # 没有运行中的事件循环，说明在同步环境中
            return False

    def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ):
        """
        GET 请求 - 同步/异步双兼容

        Args:
            url: 请求 URL
            headers: 请求头
            params: 查询参数
            timeout: 超时时间

        Returns:
            响应数据或协程对象
        """
        if self._is_running_in_async():
            # 在异步环境中，返回协程
            return self._async_api.get(url, headers=headers, params=params, timeout=timeout)
        else:
            # 在同步环境中，执行并返回结果
            return asyncio.run(
                self._async_api.get(url, headers=headers, params=params, timeout=timeout)
            )

    def post(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ):
        """
        POST 请求 - 同步/异步双兼容

        Args:
            url: 请求 URL
            headers: 请求头
            json: JSON 数据
            data: 表单数据
            timeout: 超时时间

        Returns:
            响应数据或协程对象
        """
        if self._is_running_in_async():
            # 在异步环境中，返回协程
            return self._async_api.post(url, headers=headers, json=json, data=data, timeout=timeout)
        else:
            # 在同步环境中，执行并返回结果
            return asyncio.run(
                self._async_api.post(url, headers=headers, json=json, data=data, timeout=timeout)
            )

    def patch(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ):
        """
        PATCH 请求 - 同步/异步双兼容

        Args:
            url: 请求 URL
            headers: 请求头
            json: JSON 数据
            timeout: 超时时间

        Returns:
            响应数据或协程对象
        """
        if self._is_running_in_async():
            # 在异步环境中，返回协程
            return self._async_api.patch(url, headers=headers, json=json, timeout=timeout)
        else:
            # 在同步环境中，执行并返回结果
            return asyncio.run(
                self._async_api.patch(url, headers=headers, json=json, timeout=timeout)
            )

    def login(self):
        """
        登录 - 同步/异步双兼容

        Returns:
            登录结果或协程对象
        """
        if self._is_running_in_async():
            # 在异步环境中，返回协程
            return self._async_api.login()
        else:
            # 在同步环境中，执行并返回结果
            return asyncio.run(self._async_api.login())

    def logout(self):
        """
        登出 - 同步/异步双兼容

        Returns:
            协程对象或无返回值
        """
        if self._is_running_in_async():
            # 在异步环境中，返回协程
            return self._async_api.logout()
        else:
            # 在同步环境中，执行并返回结果
            return asyncio.run(self._async_api.logout())

    @property
    def is_login(self) -> bool:
        """
        检查登录状态 - 同步/异步双兼容

        Returns:
            是否已登录
        """
        # 登录状态检查是同步操作
        return self._async_api.is_login

    def api_request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ):
        """
        API 请求 - 同步/异步双兼容

        Args:
            method: HTTP 方法
            url: 请求 URL
            headers: 请求头
            params: 查询参数
            json: JSON 数据
            data: 表单数据
            timeout: 超时时间

        Returns:
            响应数据或协程对象
        """
        if self._is_running_in_async():
            # 在异步环境中，返回协程
            return self._async_api.api_request(
                method, url, headers=headers, params=params, json=json, data=data, timeout=timeout
            )
        else:
            # 在同步环境中，执行并返回结果
            return asyncio.run(
                self._async_api.api_request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json,
                    data=data,
                    timeout=timeout,
                )
            )


def create_sync_async_api(
    username: str,
    password: str,
    cache_dir: Optional[str] = None,
) -> SyncAsyncAPI:
    """
    创建同步/异步双兼容API实例

    Args:
        username: 迅雷用户名
        password: 迅雷密码
        cache_dir: Token 缓存目录

    Returns:
        同步/异步双兼容API实例
    """
    async_api = BaseAPI(username, password, cache_dir)
    return SyncAsyncAPI(async_api)
