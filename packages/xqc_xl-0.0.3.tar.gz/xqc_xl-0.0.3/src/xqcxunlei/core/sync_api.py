"""
Xunlei API 同步版本

提供同步版本的API接口，与异步版本保持一致的功能:
- 云盘管理
- 远程下载
- 配置管理
- Token 管理
- 统一错误处理
- 增强日志功能
"""

from __future__ import annotations

import hashlib
import time
from typing import Any, Dict, Optional

import requests

from ..auth import TokenCache
from ..config import get_config
from ..utils import get_logger
from ..utils.exceptions import (
    AuthenticationError,
    LoginRequiredError,
    NetworkError,
    PermissionDeniedError,
    RateLimitError,
    ServiceUnavailableError,
    XunleiError,
)

logger = get_logger(__name__)


class SyncXunleiAPI:
    """
    Xunlei API 同步版本

    提供同步的API接口:
    - 同步方法
    - 统一错误处理
    - Token 管理
    """

    def __init__(
        self,
        username: str,
        password: str,
        cache_dir: Optional[str] = None,
    ) -> None:
        """
        初始化同步API类

        Args:
            username: 迅雷用户名
            password: 迅雷密码
            cache_dir: Token 缓存目录
        """
        self.username = username
        self.password = password

        self.config = get_config()

        resolved_cache_dir = cache_dir or self.config.cache_dir

        self.cache = TokenCache(
            username,
            cache_dir=resolved_cache_dir,
        )

        self._session: Optional[requests.Session] = None
        self._is_initialized = False

    def __enter__(self) -> "SyncXunleiAPI":
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def open(self) -> None:
        """打开客户端"""
        if self._session is None:
            self._session = requests.Session()

        # 尝试加载缓存
        self.cache.load()
        self._is_initialized = True

    def close(self) -> None:
        """关闭客户端"""
        if self._session is not None:
            self._session.close()
            self._session = None

        self.cache.close()
        self._is_initialized = False

    @property
    def session(self) -> requests.Session:
        """获取 HTTP 会话"""
        if self._session is None:
            raise RuntimeError("Session not opened. Use 'with' or call open()")
        return self._session

    @property
    def is_login(self) -> bool:
        """是否已登录"""
        return self.cache.is_login and self.cache.is_access_token_valid

    # ==================== 登录流程 ====================

    def _get_device_id(self) -> Optional[str]:
        """获取设备 ID"""
        resp = self.session.post(
            self.config.risk_url,
            params={"cmd": "report"},
            json={
                "xl_fp_raw": "53793f98c0f944f0837946d9d694c55b",
                "xl_fp": "dfe57c652a6400764d825dcfb9ea1e17",
                "version": 2,
                "xl_fp_sign": "c8f4a425a1cfd1d8029b0151735d3d7a",
            },
        )

        if resp and resp.status_code == 200:
            data = resp.json()
            device_sign = data.get("deviceid", "")
            if device_sign:
                device_id = device_sign.split(".")[-1][:32]
                self.cache.update(device_id=device_id)
                return device_id

        return None

    def _get_captcha_token_for_login(self) -> Optional[str]:
        """获取登录用的 captcha_token"""
        device_id = self._get_device_id()
        if not device_id:
            return None

        resp = self.session.post(
            self.config.captcha_init_url,
            json={
                "client_id": self.config.login_client_id,
                "action": "POST:/v1/auth/signin",
                "device_id": device_id,
                "meta": {"username": self.username},
            },
        )

        if resp and resp.status_code == 200:
            return resp.json().get("captcha_token")
        return None

    def _do_login(self) -> bool:
        """执行登录"""
        captcha_token = self._get_captcha_token_for_login()
        if not captcha_token:
            logger.error("获取登录 captcha_token 失败")
            return False

        # MD5 加密密码
        encrypted_password = hashlib.md5(self.password.encode()).hexdigest()

        resp = self.session.post(
            self.config.signin_url,
            headers={"x-captcha-token": captcha_token},
            json={
                "username": self.username,
                "password": encrypted_password,
                "client_id": self.config.login_client_id,
            },
        )

        if resp and resp.status_code == 200:
            data = resp.json()
            if data.get("access_token"):
                self.cache.set_login(
                    access_token=data["access_token"],
                    user_id=data.get("user_id", ""),
                    expires_in=data.get("expires_in", self.config.access_token_expires),
                )
                logger.info(f"登录成功: {self.username}")
                return True

        logger.error(f"登录失败: {resp.text if resp else 'No response'}")
        return False

    def _get_token_code(self) -> Optional[str]:
        """获取刷新 Token 用的 code"""
        if not self.cache.tokens.access_token:
            return None

        resp = self.session.post(
            self.config.authorize_url,
            headers={"Authorization": f"Bearer {self.cache.tokens.access_token}"},
            json={
                "client_id": self.config.token_client_id,
                "response_type": "code",
                "redirect_uri": self.config.redirect_uri,
                "state": self.config.state,
                "scope": self.config.scope,
                "code_challenge": self.config.code_challenge,
                "code_challenge_method": self.config.code_challenge_method,
                "sign_out_uri": "https://pan.xunlei.com/remote/signout/?sso_sign_out=",
            },
        )

        if resp and resp.status_code == 200:
            return resp.json().get("code")
        return None

    def _refresh_access_token(self) -> bool:
        """刷新 access_token"""
        code = self._get_token_code()
        if not code:
            return False

        resp = self.session.post(
            self.config.token_url,
            json={
                "code": code,
                "grant_type": "authorization_code",
                "code_verifier": self.config.code_verifier,
                "redirect_uri": self.config.redirect_uri,
                "client_id": self.config.token_client_id,
            },
        )

        if resp and resp.status_code == 200:
            data = resp.json()
            if data.get("access_token"):
                self.cache.set_access_token(
                    data["access_token"],
                    expires_in=data.get("expires_in", self.config.access_token_expires),
                )
                logger.debug("access_token 已刷新")
                return True

        return False

    def _refresh_captcha_token(self) -> bool:
        """刷新 captcha_token"""
        device_id = self.cache.tokens.device_id
        if not device_id:
            logger.warning("没有 device_id, 无法刷新 captcha_token")
            return False

        from ..auth.captcha_sign import get_pub_key_sign_sync

        timestamp = str(int(time.time() * 1000))
        captcha_sign = get_pub_key_sign_sync(device_id, timestamp)

        resp = self.session.post(
            self.config.captcha_init_url,
            json={
                "client_id": self.config.token_client_id,
                "action": "GET:CAPTCHA_TOKEN",
                "device_id": device_id,
                "meta": {
                    "user_id": self.cache.tokens.user_id,
                    "user_name": self.username,
                    "client_version": self.config.client_version,
                    "package_name": self.config.package_name,
                    "timestamp": timestamp,
                    "captcha_sign": captcha_sign,
                },
            },
        )

        if resp and resp.status_code == 200:
            token = resp.json().get("captcha_token")
            if token:
                self.cache.set_captcha_token(
                    token,
                    expires_in=self.config.captcha_token_expires,
                )
                logger.debug("captcha_token 已刷新")
                return True

        return False

    def login(self) -> bool:
        """
        登录

        如果缓存有效则跳过登录, 否则执行完整登录流程
        """
        try:
            # 检查是否已登录且 Token 有效
            if self.cache.is_login and self.cache.is_access_token_valid:
                # 检查是否需要刷新 captcha_token
                if self.cache.is_captcha_token_valid and not self.cache.tokens.needs_refresh:
                    logger.debug("使用缓存登录")
                    return True

                # 刷新 captcha_token
                if self._refresh_captcha_token():
                    return True

                # Token 过期, 尝试刷新
                if self._refresh_access_token():
                    return self._refresh_captcha_token()

                return False

            # 执行登录
            if not self._do_login():
                return False

            # 刷新 Token (获取云盘可用 Token)
            if not self._refresh_access_token():
                logger.warning("刷新 access_token 失败, 继续使用登录 Token")

            # 获取 captcha_token
            self._refresh_captcha_token()

            return True
        except XunleiError:
            # 重新抛出已知的 Xunlei 异常
            raise
        except Exception as e:
            logger.error(f"登录过程中发生未知错误: {str(e)}")
            return False

    def logout(self) -> None:
        """登出"""
        self.cache.clear()
        logger.info("已登出")

    # ==================== HTTP 请求封装 ====================

    def _check_http_status(self, resp) -> None:
        """检查 HTTP 状态码并抛出相应异常"""
        if resp.status_code == 401:
            raise AuthenticationError(f"认证失败: {resp.text}")
        elif resp.status_code == 403:
            raise PermissionDeniedError(f"权限不足: {resp.text}")
        elif resp.status_code == 429:
            raise RateLimitError(f"请求频率过高: {resp.text}")
        elif resp.status_code in (500, 502, 503, 504):
            raise ServiceUnavailableError(f"服务暂时不可用 (状态码: {resp.status_code})")

    def _handle_token_expired(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]],
        params: Optional[Dict[str, Any]],
        json: Optional[Dict[str, Any]],
        data: Optional[Dict[str, Any]],
        timeout: Optional[int],
    ) -> Optional[Dict[str, Any]]:
        """处理 Token 过期，重试请求"""
        logger.debug("Token 过期, 尝试刷新...")

        if self._refresh_access_token():
            if self._refresh_captcha_token():
                final_headers = self.cache.get_headers()
                if headers:
                    final_headers.update(headers)

                retry_resp = self.session.request(
                    method,
                    url,
                    headers=final_headers,
                    params=params,
                    json=json,
                    data=data,
                    timeout=timeout,
                )

                if retry_resp and retry_resp.status_code == 200:
                    return retry_resp.json()
                elif retry_resp:
                    from ..utils import handle_http_error

                    raise handle_http_error(retry_resp.status_code, retry_resp.text)
        return None

    def api_request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        发送 HTTP 请求

        自动处理:
        - 登录状态检查
        - Token 刷新
        """
        try:
            if not self.is_login:
                if not self.login():
                    raise LoginRequiredError("登录失败，无法继续请求")

            final_headers = self.cache.get_headers()
            if headers:
                final_headers.update(headers)

            resp = self.session.request(
                method=method,
                url=url,
                headers=final_headers,
                params=params,
                json=json,
                data=data,
                timeout=timeout or 30,
            )

            if resp is None:
                logger.warning(f"请求失败: {method} {url} - 无响应")
                return None

            if resp.status_code == 200:
                return resp.json()

            self._check_http_status(resp)

            if resp.status_code == 400:
                response_data = resp.json()
                if response_data and response_data.get("error") in (
                    "captcha_invalid",
                    "access_denied",
                ):
                    return self._handle_token_expired(
                        method, url, headers, params, json, data, timeout
                    )

            logger.warning(f"请求失败: {resp.status_code} {resp.text}")
            return None

        except XunleiError:
            raise
        except Exception as e:
            logger.error(f"请求过程中发生未知错误: {str(e)}")
            raise NetworkError(f"网络请求异常: {str(e)}") from e

    def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """GET 请求"""
        return self.api_request("GET", url, headers=headers, params=params, timeout=timeout)

    def post(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """POST 请求"""
        return self.api_request("POST", url, headers=headers, json=json, data=data, timeout=timeout)

    def patch(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """PATCH 请求"""
        return self.api_request("PATCH", url, headers=headers, json=json, timeout=timeout)

    # ==================== 工具方法 ====================

    # 注意: 工具函数 (如 split_path, format_sub_file_index, parse_torrent)
    # 已在 utils 模块中定义，此处不再重复定义
