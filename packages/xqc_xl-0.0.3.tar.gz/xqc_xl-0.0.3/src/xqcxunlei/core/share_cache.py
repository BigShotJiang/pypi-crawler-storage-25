"""
分享信息缓存模块

设计原则：
- 极简策略：只保留 3 种核心策略
- 内存安全：支持最大缓存数量限制，防止内存溢出
- 增量感知：记录数据时间戳，支持增量获取
- 文件持久化：支持缓存持久化到磁盘

策略说明：
- disabled: 完全不使用缓存，每次从服务器获取
- session: 会话级缓存，仅在当前请求周期内有效，内存占用有限
- persistent: 持久化缓存，存入文件，支持增量更新

增量获取说明：
- 首次获取完整数据并记录时间戳
- 后续获取时比较时间戳，只取更新的部分
- 旧分享链接的有效性变化需要主动检测和处理
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import aiofiles

from ..utils import get_logger

logger = get_logger(__name__)


@dataclass
class ShareCacheEntry:
    """分享缓存条目"""

    file_id: str = ""
    path: str = ""
    share_links: list[dict[str, Any]] = field(default_factory=list)
    share_count: int = 0
    is_valid: bool = False
    expire_time: str = ""
    remaining_count: int = -1
    file_name: str = ""
    success: bool = False
    message: str = ""
    cached_at: float = 0
    access_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "file_id": self.file_id,
            "path": self.path,
            "share_links": self.share_links,
            "share_count": self.share_count,
            "is_valid": self.is_valid,
            "expire_time": self.expire_time,
            "remaining_count": self.remaining_count,
            "file_name": self.file_name,
            "success": self.success,
            "message": self.message,
            "cached_at": self.cached_at,
            "access_count": self.access_count,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ShareCacheEntry":
        """从字典创建"""
        return cls(
            file_id=data.get("file_id", ""),
            path=data.get("path", ""),
            share_links=data.get("share_links", []),
            share_count=data.get("share_count", 0),
            is_valid=data.get("is_valid", False),
            expire_time=data.get("expire_time", ""),
            remaining_count=data.get("remaining_count", -1),
            file_name=data.get("file_name", ""),
            success=data.get("success", False),
            message=data.get("message", ""),
            cached_at=data.get("cached_at", 0),
            access_count=data.get("access_count", 0),
        )


@dataclass
class ShareListAnchor:
    """分享列表锚点信息（用于增量获取）"""

    first_page_first_id: str = ""
    last_share_id: str = ""
    total_count: int = 0
    cached_at: float = 0
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "first_page_first_id": self.first_page_first_id,
            "last_share_id": self.last_share_id,
            "total_count": self.total_count,
            "cached_at": self.cached_at,
            "version": self.version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ShareListAnchor":
        """从字典创建"""
        return cls(
            first_page_first_id=data.get("first_page_first_id", ""),
            last_share_id=data.get("last_share_id", ""),
            total_count=data.get("total_count", 0),
            cached_at=data.get("cached_at", 0),
            version=data.get("version", 1),
        )


class ShareCache:
    """
    分享缓存管理器

    三种核心策略：
    1. disabled - 不使用缓存，每次都从服务器获取
    2. session - 会话级缓存，仅在当前请求周期内有效，支持内存限制
    3. persistent - 持久化缓存，存入文件，支持增量更新

    内存管理：
    - session 策略支持 max_entries 参数限制内存占用
    - 超出限制时使用 LRU 淘汰策略
    - persistent 策略不占用内存，只读写文件
    """

    DEFAULT_CACHE_DIR = ".xqcxunlei_cache"
    DEFAULT_CACHE_FILE = "share_cache.json"
    DEFAULT_MAX_ENTRIES = 1000
    SAVE_DEBOUNCE_DELAY = 1.0

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        strategy: str = "session",
        max_entries: int = 1000,
        ttl: int = 300,
        auto_save: bool = True,
    ) -> None:
        self.cache_dir = cache_dir or self.DEFAULT_CACHE_DIR
        self.strategy = strategy
        self.max_entries = max_entries
        self.ttl = ttl
        self.auto_save = auto_save

        self._memory_cache: dict[str, ShareCacheEntry] = {}
        self._memory_order: list[str] = []
        self._file_cache_loaded: bool = False
        self._dirty: bool = False
        self._save_task: Optional[asyncio.Task] = None
        self._save_lock = asyncio.Lock()

        self._ensure_cache_dir()

    def _ensure_cache_dir(self) -> None:
        """确保缓存目录存在"""
        cache_path = Path(self.cache_dir)
        if not cache_path.exists():
            cache_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"创建缓存目录: {self.cache_dir}")

    @property
    def cache_file_path(self) -> str:
        """获取缓存文件路径"""
        return str(Path(self.cache_dir) / self.DEFAULT_CACHE_FILE)

    @property
    def anchor_file_path(self) -> str:
        """获取锚点文件路径"""
        return str(Path(self.cache_dir) / "share_anchor.json")

    def _is_disabled(self) -> bool:
        """是否禁用缓存"""
        return self.strategy == "disabled"

    def _is_session(self) -> bool:
        """是否会话级缓存"""
        return self.strategy == "session"

    def _is_persistent(self) -> bool:
        """是否持久化缓存"""
        return self.strategy == "persistent"

    async def get_anchor_async(self) -> Optional[ShareListAnchor]:
        """异步获取锚点信息"""
        if self._is_disabled():
            return None

        anchor_path = Path(self.anchor_file_path)
        if not anchor_path.exists():
            return None

        try:
            async with aiofiles.open(anchor_path, "r", encoding="utf-8") as f:
                content = await f.read()
                data = json.loads(content)
                return ShareListAnchor.from_dict(data)
        except Exception as e:
            logger.warning(f"读取锚点文件失败: {e}")
            return None

    async def set_anchor_async(self, anchor: ShareListAnchor) -> None:
        """异步保存锚点信息"""
        if self._is_disabled():
            return

        try:
            async with aiofiles.open(self.anchor_file_path, "w", encoding="utf-8") as f:
                await f.write(json.dumps(anchor.to_dict(), ensure_ascii=False, indent=2))
        except Exception as e:
            logger.warning(f"保存锚点文件失败: {e}")

    def get_anchor(self) -> Optional[ShareListAnchor]:
        """同步获取锚点信息"""
        if self._is_disabled():
            return None

        anchor_path = Path(self.anchor_file_path)
        if not anchor_path.exists():
            return None

        try:
            with open(anchor_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return ShareListAnchor.from_dict(data)
        except Exception as e:
            logger.warning(f"读取锚点文件失败: {e}")
            return None

    def set_anchor(self, anchor: ShareListAnchor) -> None:
        """同步保存锚点信息"""
        if self._is_disabled():
            return

        try:
            with open(self.anchor_file_path, "w", encoding="utf-8") as f:
                json.dump(anchor.to_dict(), f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"保存锚点文件失败: {e}")

    def _evict_if_needed(self) -> None:
        """如果缓存超过最大条目，淘汰最旧的条目"""
        if self._is_session() and len(self._memory_cache) >= self.max_entries:
            if self._memory_order:
                oldest_key = self._memory_order.pop(0)
                if oldest_key in self._memory_cache:
                    del self._memory_cache[oldest_key]
                logger.debug(f"LRU 淘汰缓存条目: {oldest_key}")

    def _touch_entry(self, key: str) -> None:
        """更新访问顺序（LRU）"""
        if key in self._memory_order:
            self._memory_order.remove(key)
        self._memory_order.append(key)

    async def get_async(self, key: str) -> Optional[ShareCacheEntry]:
        """
        异步获取缓存条目

        Args:
            key: 缓存键

        Returns:
            缓存条目，如果不存在或已过期返回 None
        """
        if self._is_disabled():
            return None

        if self._is_session():
            entry = self._memory_cache.get(key)
            if entry:
                if entry.is_expired(self.ttl):
                    del self._memory_cache[key]
                    if key in self._memory_order:
                        self._memory_order.remove(key)
                    return None
                self._touch_entry(key)
                entry.access_count += 1
                return entry
            return None

        if self._is_persistent():
            if not self._file_cache_loaded:
                await self._load_from_file_async()
            entry = self._memory_cache.get(key)
            if entry:
                if entry.is_expired(self.ttl):
                    del self._memory_cache[key]
                    self._dirty = True
                    await self._schedule_save_async()
                    return None
                self._touch_entry(key)
                entry.access_count += 1
                return entry
            return None

        return None

    def get(self, key: str) -> Optional[ShareCacheEntry]:
        """同步获取缓存条目"""
        if self._is_disabled():
            return None

        if self._is_session():
            entry = self._memory_cache.get(key)
            if entry:
                if entry.is_expired(self.ttl):
                    del self._memory_cache[key]
                    if key in self._memory_order:
                        self._memory_order.remove(key)
                    return None
                self._touch_entry(key)
                entry.access_count += 1
                return entry
            return None

        if self._is_persistent():
            if not self._file_cache_loaded:
                self._load_from_file()
            entry = self._memory_cache.get(key)
            if entry:
                if entry.is_expired(self.ttl):
                    del self._memory_cache[key]
                    self._dirty = True
                    self._schedule_save()
                    return None
                self._touch_entry(key)
                entry.access_count += 1
                return entry
            return None

        return None

    async def set_async(self, key: str, entry: ShareCacheEntry) -> None:
        """
        异步设置缓存条目

        Args:
            key: 缓存键
            entry: 缓存条目
        """
        if self._is_disabled():
            return

        if self._is_persistent():
            if not self._file_cache_loaded:
                await self._load_from_file_async()

        entry.cached_at = time.time()
        self._memory_cache[key] = entry
        self._touch_entry(key)
        self._evict_if_needed()
        self._dirty = True

        if self.auto_save and (self._is_persistent() or self._is_session()):
            await self._schedule_save_async()

    def set(self, key: str, entry: ShareCacheEntry) -> None:
        """同步设置缓存条目"""
        if self._is_disabled():
            return

        if self._is_persistent() and not self._file_cache_loaded:
            self._load_from_file()

        entry.cached_at = time.time()
        self._memory_cache[key] = entry
        self._touch_entry(key)
        self._evict_if_needed()
        self._dirty = True

        if self.auto_save and (self._is_persistent() or self._is_session()):
            self._schedule_save()

    def _is_expired(self, entry: ShareCacheEntry) -> bool:
        """检查缓存条目是否过期"""
        return time.time() - entry.cached_at > self.ttl

    def _load_from_file(self) -> None:
        """同步从文件加载缓存"""
        try:
            cache_file = Path(self.cache_file_path)
            if not cache_file.exists():
                return

            with open(cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            entries = data.get("entries", {})
            for k, v in entries.items():
                entry = ShareCacheEntry.from_dict(v)
                if not self._is_expired(entry):
                    self._memory_cache[k] = entry

            self._file_cache_loaded = True
            logger.debug(f"已加载文件缓存: {len(self._memory_cache)} 条目")

        except Exception as e:
            logger.error(f"加载缓存文件失败: {str(e)}")
            self._file_cache_loaded = True

    async def _load_from_file_async(self) -> None:
        """异步从文件加载缓存"""
        try:
            cache_file = Path(self.cache_file_path)
            if not cache_file.exists():
                self._file_cache_loaded = True
                return

            async with aiofiles.open(cache_file, "r", encoding="utf-8") as f:
                content = await f.read()
                data = json.loads(content)

            entries = data.get("entries", {})
            for k, v in entries.items():
                entry = ShareCacheEntry.from_dict(v)
                if not self._is_expired(entry):
                    self._memory_cache[k] = entry

            self._file_cache_loaded = True
            logger.debug(f"已加载文件缓存: {len(self._memory_cache)} 条目")

        except Exception as e:
            logger.error(f"加载缓存文件失败: {str(e)}")
            self._file_cache_loaded = True

    def _schedule_save(self) -> None:
        """安排延迟保存"""
        if self._save_task and not self._save_task.done():
            return
        self._save_task = asyncio.create_task(self._delayed_save())

    async def _schedule_save_async(self) -> None:
        """异步安排延迟保存"""
        if self._save_task and not self._save_task.done():
            return
        self._save_task = asyncio.create_task(self._delayed_save_async())

    async def _delayed_save_async(self) -> None:
        """延迟保存到文件"""
        await asyncio.sleep(self.SAVE_DEBOUNCE_DELAY)
        async with self._save_lock:
            if self._dirty:
                await self._save_to_file_async()
                self._dirty = False

    def _delayed_save(self) -> None:
        """延迟保存到文件（同步）"""
        import time as time_module

        time_module.sleep(self.SAVE_DEBOUNCE_DELAY)
        with self._save_lock:
            if self._dirty:
                self._save_to_file()
                self._dirty = False

    def _save_to_file(self) -> None:
        """保存到文件"""
        try:
            entries = {}
            for k, v in self._memory_cache.items():
                if not self._is_expired(v):
                    entries[k] = v.to_dict()

            data = {
                "version": 1,
                "strategy": self.strategy,
                "updated_at": time.time(),
                "entries": entries,
            }

            cache_file = Path(self.cache_file_path)
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            logger.debug(f"已保存缓存到文件: {len(entries)} 条目")

        except Exception as e:
            logger.error(f"保存缓存文件失败: {str(e)}")

    async def _save_to_file_async(self) -> None:
        """异步保存到文件"""
        try:
            entries = {}
            for k, v in self._memory_cache.items():
                if not self._is_expired(v):
                    entries[k] = v.to_dict()

            data = {
                "version": 1,
                "strategy": self.strategy,
                "updated_at": time.time(),
                "entries": entries,
            }

            cache_file = Path(self.cache_file_path)
            async with aiofiles.open(cache_file, "w", encoding="utf-8") as f:
                await f.write(json.dumps(data, ensure_ascii=False, indent=2))

            logger.debug(f"已保存缓存到文件: {len(entries)} 条目")

        except Exception as e:
            logger.error(f"保存缓存文件失败: {str(e)}")

    async def save_async(self) -> None:
        """立即异步保存"""
        async with self._save_lock:
            await self._save_to_file_async()
            self._dirty = False

    def save(self) -> None:
        """立即同步保存"""
        with self._save_lock:
            self._save_to_file()
            self._dirty = False

    async def clear_async(self) -> None:
        """异步清除所有缓存"""
        self._memory_cache.clear()
        self._memory_order.clear()
        self._dirty = True
        if self._is_persistent():
            await self._save_to_file_async()
        logger.debug("已清除所有缓存")

    def clear(self) -> None:
        """同步清除所有缓存"""
        self._memory_cache.clear()
        self._memory_order.clear()
        self._dirty = True
        if self._is_persistent():
            self._save_to_file()
        logger.debug("已清除所有缓存")

    def get_cache_info(self) -> dict[str, Any]:
        """获取缓存信息"""
        return {
            "strategy": self.strategy,
            "ttl": self.ttl,
            "max_entries": self.max_entries,
            "memory_count": len(self._memory_cache),
            "dirty": self._dirty,
            "cache_file": self.cache_file_path if self._is_persistent() else None,
        }

    async def cleanup_expired_async(self) -> int:
        """异步清理过期缓存"""
        if self._memory_cache:
            expired_keys = [k for k, v in self._memory_cache.items() if self._is_expired(v)]
            for k in expired_keys:
                del self._memory_cache[k]
                if k in self._memory_order:
                    self._memory_order.remove(k)

            if expired_keys and self._is_persistent():
                self._dirty = True
                await self._schedule_save_async()

            logger.debug(f"已清理 {len(expired_keys)} 个过期缓存条目")
            return len(expired_keys)
        return 0

    def cleanup_expired(self) -> int:
        """同步清理过期缓存"""
        if self._memory_cache:
            expired_keys = [k for k, v in self._memory_cache.items() if self._is_expired(v)]
            for k in expired_keys:
                del self._memory_cache[k]
                if k in self._memory_order:
                    self._memory_order.remove(k)

            if expired_keys and self._is_persistent():
                self._dirty = True
                self._schedule_save()

            logger.debug(f"已清理 {len(expired_keys)} 个过期缓存条目")
            return len(expired_keys)
        return 0


def is_expired(cached_at: float, ttl: int) -> bool:
    """检查是否过期（独立函数）"""
    return time.time() - cached_at > ttl
