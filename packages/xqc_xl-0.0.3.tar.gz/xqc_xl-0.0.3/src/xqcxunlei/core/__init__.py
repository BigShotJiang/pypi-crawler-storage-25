"""
Xunlei API 核心模块

提供核心功能和架构:
- 同步与异步双兼容架构
- 基础API类
- 客户端管理
- 配置管理
- 统一错误处理
- 日志系统
"""

from __future__ import annotations

from ..auth import TokenCache
from ..client import RetryClient
from ..config import get_config
from ..utils import get_logger
from ..utils.exceptions import (
    AuthenticationError,
    LoginRequiredError,
    NetworkError,
    PermissionDeniedError,
    RateLimitError,
    ServiceUnavailableError,
    XunleiError,
)
from .base import BaseAPI, SyncAsyncAPI, create_sync_async_api
from .share_cache import ShareCache, ShareCacheEntry

# 导出核心类和函数
__all__ = [
    "BaseAPI",
    "SyncAsyncAPI",
    "create_sync_async_api",
    "ShareCache",
    "ShareCacheEntry",
    "TokenCache",
    "RetryClient",
    "get_config",
    "get_logger",
    "XunleiError",
    "AuthenticationError",
    "LoginRequiredError",
    "NetworkError",
    "PermissionDeniedError",
    "RateLimitError",
    "ServiceUnavailableError",
]
