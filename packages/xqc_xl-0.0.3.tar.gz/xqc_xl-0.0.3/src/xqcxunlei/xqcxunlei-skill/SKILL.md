---
name: xqcxunlei
description: |
  迅雷云盘 Python SDK。当用户询问关于迅雷云盘文件操作、远程下载、分享链接、转存等功能时触发此技能。支持上传下载文件、创建和管理分享链接、添加磁力/HTTP下载任务、转存分享内容等操作。即使用户没有明确提及"迅雷"或"xqcxunlei"，但只要涉及迅雷云盘文件管理、迅雷远程下载任务等需求，都应触发此技能。
---

# xqcxunlei 迅雷云盘 Python SDK

本技能提供迅雷云盘的完整 Python SDK 功能，支持文件管理、远程下载、分享链接等操作。

> **快速开始**：环境配置、基本使用、常用示例请查看 [references/quickstart.md](references/quickstart.md)。

## 文档索引

| 功能     | 文档                                                           | 说明                           |
| -------- | -------------------------------------------------------------- | ------------------------------ |
| 快速开始 | [references/quickstart.md](references/quickstart.md)           | 环境配置、基本使用、CLI 命令   |
| 文件上传 | [references/upload.md](references/upload.md)                   | 单文件上传、目录上传、进度回调 |
| 远程下载 | [references/remote_download.md](references/remote_download.md) | 磁力链、HTTP下载、设备管理     |
| 分享链接 | [references/share.md](references/share.md)                     | 创建分享、查询、导出、取消     |
| 转存功能 | [references/transfer.md](references/transfer.md)               | 转存分享链接、下载分享内容     |

## 快速开始 CLI（推荐）

**优先使用 CLI 命令进行操作，效率更高、更稳定。**

### 登录

```bash
# 登录账号（登录后后续命令自动使用此账号）
xqcxunlei login -u 你的用户名 -p 你的密码

# 查看云盘空间
xqcxunlei space

# 列出文件
xqcxunlei ls /test
```

### 文件操作

```bash
xqcxunlei mkdir /test/新目录           # 创建目录
xqcxunlei upload 本地文件.txt /test/  # 上传文件
xqcxunlei download /test/文件.txt -o ./  # 下载文件
xqcxunlei search 电影                   # 搜索文件
xqcxunlei info /test/文件.txt          # 查看文件信息
xqcxunlei rename /test/旧.txt 新.txt   # 重命名
xqcxunlei copy /test/文件.txt /备份/   # 复制
xqcxunlei move /test/文件.txt /移动/   # 移动
xqcxunlei delete /test/文件.txt        # 删除（到回收站）
xqcxunlei delete /test/文件.txt -p    # 永久删除
```

### 分享操作

```bash
xqcxunlei share /test/文件.txt                    # 创建分享链接
xqcxunlei share /test/文件.txt -v 7               # 7天有效期
xqcxunlei share-info /test/文件.txt               # 查询分享信息
xqcxunlei cancel-share /test/文件.txt             # 取消分享
xqcxunlei export-shares -f json                   # 导出所有分享
```

### 转存操作

```bash
xqcxunlei transfer "https://pan.xunlei.com/s/xxx" "提取码"
xqcxunlei transfer "链接" "提取码" -t /目标目录   # 指定目标目录
xqcxunlei download-share "链接" "提取码" -o ./    # 下载分享内容
```

### 远程下载

```bash
xqcxunlei remote-devices                     # 列出设备
xqcxunlei remote-add "magnet:?xt=urn:btih:..." --device 设备名
xqcxunlei remote-tasks                       # 列出任务
xqcxunlei remote-tasks --device 设备名        # 指定设备
xqcxunlei remote-pause <task_id>             # 暂停任务
xqcxunlei remote-resume <task_id>            # 恢复任务
xqcxunlei remote-delete <task_id>            # 删除任务
xqcxunlei remote-speed 10.0                  # 设置速度限制
```

> **提示**：更多 CLI 命令，运行 `xqcxunlei --help` 查看。

## 环境配置

使用本模块前，请配置 `.env` 文件（从 `.env.example` 复制）：

```bash
cp .env.example .env
```

### 账号配置优先级

| 优先级 | 来源            | 说明                                      |
| ------ | --------------- | ----------------------------------------- |
| 1      | CLI 手动登录    | 通过 `xqcxunlei login -u xxx -p xxx` 登录 |
| 2      | .env 或环境变量 | 未手动登录时自动使用                      |

> **说明**：CLI 手动登录后，后续命令会自动使用该账号；未手动登录则自动读取 `.env` 或环境变量中的账号配置。

### 必填配置

| 变量              | 说明       |
| ----------------- | ---------- |
| `XUNLEI_USERNAME` | 迅雷用户名 |
| `XUNLEI_PASSWORD` | 迅雷密码   |

### 可选配置

| 变量                     | 默认值       | 说明                     |
| ------------------------ | ------------ | ------------------------ |
| `XUNLEI_CACHE_DIR`       | 系统临时目录 | Token 缓存目录           |
| `XUNLEI_AUTO_SAVE`       | `true`       | 是否自动保存 Token       |
| `XUNLEI_REQUEST_TIMEOUT` | `30`         | 请求超时时间（秒）       |
| `XUNLEI_MAX_RETRIES`     | `2`          | 最大重试次数             |
| `XUNLEI_LOG_LEVEL`       | `INFO`       | 日志级别                 |
| `MAGICPUSH_SERVER_URL`   | -            | MagicPush 推送服务器地址 |
| `MAGICPUSH_TOKEN`        | -            | MagicPush 访问令牌       |

### 完整配置项

```bash
# 迅雷账号认证
XUNLEI_USERNAME=你的用户名
XUNLEI_PASSWORD=你的密码

# 缓存配置
XUNLEI_CACHE_FILE=
XUNLEI_CACHE_DIR=
XUNLEI_AUTO_SAVE=true

# HTTP 客户端配置
XUNLEI_REQUEST_TIMEOUT=30
XUNLEI_MAX_RETRIES=2

# 日志配置
XUNLEI_LOG_LEVEL=INFO
XUNLEI_LOG_FORMAT=%(asctime)s - %(name)s - %(levelname)s - %(message)s

# MagicPush 推送配置（可选）
MAGICPUSH_SERVER_URL=
MAGICPUSH_TOKEN=
```

## 核心组件

### 主客户端 Xunlei

```python
from xqcxunlei import Xunlei

async with Xunlei(username, password) as xunlei:
    user = await xunlei.get_user_info()
    files = await xunlei.list_directory("/test")
```

### API 分类

| 组件              | 用途                                                       |
| ----------------- | ---------------------------------------------------------- |
| `xunlei.cloud`    | 云盘文件操作 (list_directory, upload, download, search 等) |
| `xunlei.remote`   | 远程下载管理 (add_remote_download, get_remote_tasks 等)    |
| `xunlei.uploader` | 文件上传器                                                 |

## 常用操作

### 1. 文件管理

```python
# 列出目录
files = await xunlei.list_directory("/test", depth=2)

# 搜索文件
results = await xunlei.search(query="电影", path="/视频")

# 创建目录
await xunlei.create_folder("/test/新建目录")

# 重命名
await xunlei.rename(old="/test/旧.txt", new="新.txt")

# 复制/移动
await xunlei.copy(source="/test/文件.txt", target_parent="/备份")
await xunlei.move(source="/test/文件.txt", target_parent="/移动")

# 删除
await xunlei.delete("/test/文件.txt", permanent=False)
```

### 2. 上传下载

```python
# 上传文件
result = await xunlei.upload("./本地文件.txt", "/test/")

# 下载文件
results = await xunlei.download("/test/文件.txt", local_dir="./下载")

# 获取直链
links = await xunlei.get_direct_link("/test/文件.txt")
```

### 3. 分享链接

```python
# 创建分享
result = await xunlei.create_share_link("/test/文件.txt", valid_days=7)

# 转存分享
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/xxx",
    pass_code="1234",
    target_parent="/转存"
)

# 取消分享
await xunlei.cancel_share_link("/test/文件.txt")
```

### 4. 远程下载

```python
# 获取设备
devices = await xunlei.get_remote_devices()

# 添加远程任务
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:...",
    device_name=devices[0].get("name")
)

# 管理任务
await xunlei.pause_remote_task(task_id="xxx")
await xunlei.resume_remote_task(task_id="xxx")
await xunlei.delete_remote_task(task_id="xxx")
```

## 上传功能详解

### upload 单文件上传

```python
result = await xunlei.upload(
    local_path="./本地文件.txt",
    target_parent="/test",
    file_name=None,
    auto_create_parents=True,
    overwrite_existing=False,
    show_progress=True,
    enable_resume=True,
    num_threads=4,
)
```

**参数说明**:

| 参数                  | 类型          | 默认值  | 说明           |
| --------------------- | ------------- | ------- | -------------- |
| `local_path`          | `str`         | 必填    | 本地文件路径   |
| `target_parent`       | `str`         | `"/"`   | 云盘目标目录   |
| `file_name`           | `str \| None` | `None`  | 指定云盘文件名 |
| `auto_create_parents` | `bool`        | `True`  | 自动创建父目录 |
| `overwrite_existing`  | `bool`        | `False` | 覆盖已存在文件 |
| `show_progress`       | `bool`        | `True`  | 显示进度条     |
| `enable_resume`       | `bool`        | `True`  | 启用断点续传   |
| `num_threads`         | `int`         | `4`     | 上传线程数     |

### upload_directory 目录上传

```python
result = await xunlei.upload_directory(
    local_dir="./本地目录",
    target_parent="/test",
    conflict_strategy=CloudFileExistsStrategy.RENAME,
    max_concurrent=2,
    show_progress=True,
    task_order=TaskOrderStrategy.NATURAL,
    failure_strategy=FailureStrategy.DEFERRED_RETRY,
    max_retries=3,
)
```

**参数说明**:

| 参数                | 类型                      | 默认值           | 说明         |
| ------------------- | ------------------------- | ---------------- | ------------ |
| `local_dir`         | `str`                     | 必填             | 本地目录路径 |
| `target_parent`     | `str`                     | `"/"`            | 云盘目标目录 |
| `conflict_strategy` | `CloudFileExistsStrategy` | `RENAME`         | 文件冲突策略 |
| `max_concurrent`    | `int`                     | `2`              | 最大并发数   |
| `show_progress`     | `bool`                    | `True`           | 显示进度条   |
| `task_order`        | `TaskOrderStrategy`       | `NATURAL`        | 任务排序策略 |
| `failure_strategy`  | `FailureStrategy`         | `DEFERRED_RETRY` | 失败策略     |
| `max_retries`       | `int`                     | `3`              | 最大重试次数 |

## 远程下载功能详解

### add_remote_download 添加下载任务

```python
result = await xunlei.add_remote_download(
    url="magnet:?xt=urn:btih:...",
    device_name=None,
    target_folder=None,
    rename=None,
    select_files=None,
    auto_create_folder=True,
    on_exists=RemoteDownloadConflictStrategy.SKIP,
    return_raw=False,
)
```

**url 支持格式**:

| 类型            | 示例                           |
| --------------- | ------------------------------ |
| HTTP/HTTPS 直链 | `https://example.com/file.zip` |
| Magnet 磁力链接 | `magnet:?xt=urn:btih:...`      |
| BT 种子文件     | `.torrent` 文件路径            |
| 迅雷分享链接    | `https://pan.xunlei.com/s/xxx` |
| 云盘资源路径    | `/我的资源/电影.mp4`           |

**select_files 参数**:

| 类型             | 说明         | 示例                                  |
| ---------------- | ------------ | ------------------------------------- |
| `list[int]`      | 指定索引     | `[1, 3, 5]` 下载第1、3、5个文件       |
| `FileTypeFilter` | 文件类型过滤 | `[FileTypeFilter.VIDEO]` 只下载视频   |
| `Callable`       | 自定义回调   | `lambda f: f.get("size") > 1024*1024` |

**rename 预设回调**:

```python
from xqcxunlei import add_prefix, add_suffix, replace_text, remove_text

rename = add_prefix("【高清】")       # 添加前缀
rename = add_suffix("_720p")          # 添加后缀
rename = replace_text("高清", "HD")   # 替换文本
rename = remove_text(["[广告]"])     # 移除文本
```

### get_remote_tasks 获取任务列表

```python
tasks = await xunlei.get_remote_tasks(
    device_name=None,
    task_id=None,
    status_filter="running",
    return_raw=False,
)
```

**status_filter 可选值**: `running`、`paused`、`complete`、`failed`

### set_remote_speed_limit 设置速度限制

```python
result = await xunlei.set_remote_speed_limit(
    speed_mbps=10.0,
    device_name=None,
)
```

> ⚠️ 有效范围：0.06-131.3 Mbps，`-1` 表示不限速

### get_magnet_files 获取磁力文件列表

```python
files = await xunlei.get_magnet_files(
    url="magnet:?xt=urn:btih:...",
    file_types=[FileTypeFilter.VIDEO],
    extensions=[".mp4", ".mkv"],
    filters=None,
)
```

## 分享链接功能详解

### create_share_link 创建分享

```python
result = await xunlei.create_share_link(
    targets="/test/文件.txt",
    valid_days=-1,
    extraction_times=-1,
    with_passcode=True,
    on_exists=ShareLinkStrategy.SKIP,
    scope="/",
)
```

**参数说明**:

| 参数               | 类型                      | 默认值 | 说明               |
| ------------------ | ------------------------- | ------ | ------------------ |
| `targets`          | `str \| list \| Callable` | 必填   | 文件路径或回调     |
| `valid_days`       | `int`                     | `-1`   | 有效天数 (-1=永久) |
| `extraction_times` | `int`                     | `-1`   | 提取次数 (-1=不限) |
| `with_passcode`    | `bool`                    | `True` | 需要提取码         |
| `on_exists`        | `ShareLinkStrategy`       | `SKIP` | 存在时的策略       |
| `scope`            | `str \| list`             | `"/"`  | 筛选范围           |

**on_exists 策略**:

| 策略        | 说明               |
| ----------- | ------------------ |
| `SKIP`      | 跳过，返回现有的   |
| `RECREATE`  | 创建新的           |
| `OVERWRITE` | 删除旧的，创建新的 |

### get_share_info 查询分享信息

```python
info = await xunlei.get_share_info(
    targets="/test/文件.txt",
    share_link=None,
    pass_code=None,
)
```

### export_share_links 导出分享链接

```python
content = await xunlei.export_share_links(
    format=ExportFormat.JSON,
    output_file=None,
)
```

**format 可选值**: `ExportFormat.JSON`、`ExportFormat.CSV`、`ExportFormat.MARKDOWN`

## 转存功能详解

### transfer_share 转存分享链接

```python
result = await xunlei.transfer_share(
    share_link="https://pan.xunlei.com/s/xxx",
    pass_code="1234",
    target_parent="/转存目录",
    select_files=None,
    conflict_strategy=RemoteDownloadConflictStrategy.SKIP,
    on_share_after_transfer=None,
    share_expire_days=7,
    return_raw=False,
)
```

**参数说明**:

| 参数                      | 类型                                 | 默认值 | 说明           |
| ------------------------- | ------------------------------------ | ------ | -------------- |
| `share_link`              | `str`                                | 必填   | 分享链接       |
| `pass_code`               | `str`                                | `""`   | 提取码         |
| `target_parent`           | `str`                                | `"/"`  | 目标目录       |
| `select_files`            | `list[int] \| Callable \| None`      | `None` | 选择文件       |
| `conflict_strategy`       | `RemoteDownloadConflictStrategy`     | `SKIP` | 冲突策略       |
| `on_share_after_transfer` | `ShareAfterTransferStrategy \| None` | `None` | 转存后创建分享 |
| `share_expire_days`       | `int`                                | `7`    | 分享有效期     |

**select_files 示例**:

```python
# 选择特定索引的文件
select_files=[0, 2, 4]

# 使用回调函数选择
select_files=lambda f: f.get("size", 0) > 100 * 1024 * 1024

# 使用文件类型过滤
from xqcxunlei import FileTypeFilter
select_files=[FileTypeFilter.VIDEO, FileTypeFilter.AUDIO]
```

### download_share 下载分享链接

```python
result = await xunlei.download_share(
    share_link="https://pan.xunlei.com/s/xxx",
    pass_code="1234",
    local_dir="./下载",
    select_subfiles=None,
    transfer_dir="/临时目录",
    max_concurrent=3,
    show_progress=True,
)
```

## 回调函数与过滤器

### 文件过滤

```python
from xqcxunlei import name_contains_filter, extension_filter, FileTypeFilter

# 文件名过滤
results = await xunlei.search(
    query=None,
    callback=name_contains_filter(["高清", "1080p"])
)

# 扩展名过滤
results = await xunlei.search(
    callback=extension_filter([".mp4", ".mkv"])
)

# 文件类型过滤
results = await xunlei.search(
    callback=FileTypeFilter.VIDEO.get_filter()
)
```

### 重命名回调

```python
from xqcxunlei import add_prefix, add_suffix, replace_text

await xunlei.add_remote_download(
    "magnet:...",
    rename=add_prefix("【下载】")
)
```

## CLI 命令

```bash
# 登录
xqcxunlei login -u 用户名 -p 密码

# 文件操作
xqcxunlei ls /test
xqcxunlei search 电影
xqcxunlei mkdir /test/新目录
xqcxunlei upload 本地文件.txt /test/

# 分享操作
xqcxunlei share /test/文件.txt
xqcxunlei transfer "链接" "提取码"
xqcxunlei cancel-share /test/文件.txt

# 远程下载
xqcxunlei remote-devices
xqcxunlei remote-add "magnet:..." --device 设备名
```

## 错误处理

```python
from xqcxunlei.exceptions import XunleiAPIError, XunleiAuthError

try:
    await xunlei.get_user_info()
except XunleiAuthError:
    print("登录失败，请检查账号密码")
except XunleiAPIError as e:
    print(f"API错误: {e.code} - {e.message}")
```

## 枚举类速查

| 枚举类                           | 用途                                              |
| -------------------------------- | ------------------------------------------------- |
| `CacheStrategy`                  | 缓存策略 (DISABLED/SESSION/PERSISTENT)            |
| `CloudFileExistsStrategy`        | 文件存在策略 (SKIP/RENAME/OVERWRITE/ABORT)        |
| `RemoteDownloadConflictStrategy` | 远程下载冲突策略                                  |
| `FailureStrategy`                | 失败重试策略                                      |
| `FileTypeFilter`                 | 文件类型过滤 (VIDEO/AUDIO/IMAGE/DOCUMENT/ARCHIVE) |
| `ShareLinkStrategy`              | 分享链接策略                                      |
