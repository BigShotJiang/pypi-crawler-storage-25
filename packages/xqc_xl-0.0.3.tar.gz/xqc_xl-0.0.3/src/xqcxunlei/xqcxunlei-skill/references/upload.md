# 文件上传

## upload 单文件上传

上传本地文件到云盘指定目录。

```python
result = await xunlei.upload(
    local_path="./本地文件.txt",
    target_parent="/test",
    file_name=None,
    auto_create_parents=True,
    overwrite_existing=False,
    show_progress=True,
    enable_resume=True,
    num_threads=4,
)
```

### 参数说明

| 参数                  | 类型          | 默认值  | 说明                                   |
| --------------------- | ------------- | ------- | -------------------------------------- |
| `local_path`          | `str`         | 必填    | 本地文件路径                           |
| `target_parent`       | `str`         | `"/"`   | 云盘目标目录                           |
| `file_name`           | `str \| None` | `None`  | 指定云盘文件名，为 None 则使用原文件名 |
| `auto_create_parents` | `bool`        | `True`  | 自动创建父目录                         |
| `overwrite_existing`  | `bool`        | `False` | 覆盖已存在文件                         |
| `show_progress`       | `bool`        | `True`  | 显示上传进度条                         |
| `enable_resume`       | `bool`        | `True`  | 启用断点续传                           |
| `num_threads`         | `int`         | `4`     | 上传线程数                             |

### 返回值

```python
{
    "task_id": "xxx",           # 任务ID
    "file_id": "xxx",           # 文件ID
    "file_name": "文件.txt",     # 文件名
    "file_path": "/test/文件.txt", # 云盘路径
    "file_size": 1024,          # 文件大小(字节)
    "status": "success",        # 上传状态
}
```

### 示例

```python
# 基本上传
result = await xunlei.upload("./本地文件.txt", "/test/")

# 指定文件名
result = await xunlei.upload("./本地文件.txt", "/test/", file_name="新文件名.txt")

# 覆盖已存在的文件
result = await xunlei.upload("./本地文件.txt", "/test/", overwrite_existing=True)

# 不显示进度
result = await xunlei.upload("./本地文件.txt", "/test/", show_progress=False)

# 禁用断点续传
result = await xunlei.upload("./本地文件.txt", "/test/", enable_resume=False)
```

## upload_directory 目录上传

上传整个本地目录到云盘。

```python
result = await xunlei.upload_directory(
    local_dir="./本地目录",
    target_parent="/test",
    conflict_strategy=CloudFileExistsStrategy.RENAME,
    max_concurrent=2,
    show_progress=True,
    task_order=TaskOrderStrategy.NATURAL,
    failure_strategy=FailureStrategy.DEFERRED_RETRY,
    max_retries=3,
)
```

### 参数说明

| 参数                | 类型                      | 默认值           | 说明           |
| ------------------- | ------------------------- | ---------------- | -------------- |
| `local_dir`         | `str`                     | 必填             | 本地目录路径   |
| `target_parent`     | `str`                     | `"/"`            | 云盘目标目录   |
| `conflict_strategy` | `CloudFileExistsStrategy` | `RENAME`         | 文件冲突策略   |
| `max_concurrent`    | `int`                     | `2`              | 最大并发上传数 |
| `show_progress`     | `bool`                    | `True`           | 显示进度条     |
| `task_order`        | `TaskOrderStrategy`       | `NATURAL`        | 任务排序策略   |
| `failure_strategy`  | `FailureStrategy`         | `DEFERRED_RETRY` | 失败重试策略   |
| `max_retries`       | `int`                     | `3`              | 最大重试次数   |

### CloudFileExistsStrategy 冲突策略

| 策略        | 说明                 |
| ----------- | -------------------- |
| `SKIP`      | 跳过已存在的文件     |
| `RENAME`    | 重命名新文件（默认） |
| `OVERWRITE` | 覆盖已存在的文件     |
| `ABORT`     | 中止整个上传任务     |

### TaskOrderStrategy 任务排序

| 策略              | 说明                           |
| ----------------- | ------------------------------ |
| `NATURAL`         | 自然顺序（按文件路径字母顺序） |
| `SMALLEST_FIRST`  | 小文件优先                     |
| `LARGEST_FIRST`   | 大文件优先                     |
| `SUBFOLDER_FIRST` | 子目录优先                     |

### FailureStrategy 失败策略

| 策略             | 说明               |
| ---------------- | ------------------ |
| `ABORT`          | 立即中止所有任务   |
| `DEFERRED_RETRY` | 延迟后重试（默认） |
| `CONTINUE`       | 继续处理其他文件   |

### 返回值

```python
{
    "total_files": 10,           # 总文件数
    "success_count": 9,          # 成功数
    "failed_count": 1,          # 失败数
    "skipped_count": 0,         # 跳过数
    "results": [                # 详细结果
        {
            "local_path": "./本地目录/文件1.txt",
            "cloud_path": "/test/本地目录/文件1.txt",
            "status": "success",
        },
        # ...
    ],
}
```

### 示例

```python
# 基本目录上传
result = await xunlei.upload_directory("./本地目录", "/test/")

# 设置最大并发数为3
result = await xunlei.upload_directory(
    "./本地目录",
    "/test/",
    max_concurrent=3,
)

# 覆盖已存在的文件
result = await xunlei.upload_directory(
    "./本地目录",
    "/test/",
    conflict_strategy=CloudFileExistsStrategy.OVERWRITE,
)

# 小文件优先上传
result = await xunlei.upload_directory(
    "./本地目录",
    "/test/",
    task_order=TaskOrderStrategy.SMALLEST_FIRST,
)

# 失败后继续处理其他文件
result = await xunlei.upload_directory(
    "./本地目录",
    "/test/",
    failure_strategy=FailureStrategy.CONTINUE,
)
```

## upload_with_callback 带回调上传

使用自定义回调函数处理上传进度。

```python
def progress_callback(uploaded: int, total: int, file_name: str):
    percent = (uploaded / total) * 100
    print(f"{file_name}: {percent:.1f}%")

result = await xunlei.upload(
    "./本地文件.txt",
    "/test/",
    progress_callback=progress_callback,
)
```

## CLI 命令

```bash
# 上传单个文件
xqcxunlei upload 本地文件.txt /test/

# 上传并指定云盘文件名
xqcxunlei upload 本地文件.txt /test/ -n 新文件名.txt

# 上传整个目录
xqcxunlei upload-dir ./本地目录 /test/

# 覆盖已存在文件
xqcxunlei upload 本地文件.txt /test/ --overwrite

# 上传时显示进度
xqcxunlei upload 本地文件.txt /test/ -v
```

## 注意事项

1. **上传限制**：单个文件大小限制请参考 `references/upload_limit.md`
2. **断点续传**：启用断点续传后，中断的上传可以恢复
3. **并发上传**：目录上传时，合理设置 `max_concurrent` 避免过快触发限流
4. **路径格式**：云盘路径必须以 `/` 开头
