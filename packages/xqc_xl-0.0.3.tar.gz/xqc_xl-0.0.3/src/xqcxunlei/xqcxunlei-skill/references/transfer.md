# 转存功能

转存功能允许用户将分享链接中的内容保存到自己的云盘中。

## transfer_share 转存分享链接

将分享链接中的文件转存到自己的云盘。

```python
result = await xunlei.transfer_share(
    share_link="https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    target_parent="/转存目录",
    select_files=None,
    conflict_strategy=RemoteDownloadConflictStrategy.SKIP,
    on_share_after_transfer=None,
    share_expire_days=7,
    return_raw=False,
)
```

### 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `share_link` | `str` | 必填 | 分享链接 |
| `pass_code` | `str` | `""` | 提取码，无提取码时为空字符串 |
| `target_parent` | `str` | `"/"` | 云盘目标目录 |
| `select_files` | `list[int] \| Callable \| FileTypeFilter \| None` | `None` | 选择文件 |
| `conflict_strategy` | `RemoteDownloadConflictStrategy` | `SKIP` | 文件冲突策略 |
| `on_share_after_transfer` | `ShareAfterTransferStrategy \| None` | `None` | 转存后创建分享 |
| `share_expire_days` | `int` | `7` | 转存后创建的分享有效期 |
| `return_raw` | `bool` | `False` | 返回原始数据 |

### RemoteDownloadConflictStrategy 冲突策略

| 策略 | 说明 |
|------|------|
| `SKIP` | 跳过已存在的文件（默认） |
| `RENAME` | 重命名新文件 |
| `OVERWRITE` | 覆盖已存在的文件 |
| `ABORT` | 中止操作 |

### select_files 文件选择

**索引列表**：
```python
# 转存第1、3、5个文件
select_files=[0, 2, 4]
```

**文件类型过滤**：
```python
from xqcxunlei import FileTypeFilter

# 只转存视频
select_files=[FileTypeFilter.VIDEO]

# 转存视频和音频
select_files=[FileTypeFilter.VIDEO, FileTypeFilter.AUDIO]
```

**自定义回调**：
```python
# 转存大于 100MB 的文件
select_files=lambda f: f.get("size", 0) > 100 * 1024 * 1024

# 转存特定文件
select_files=lambda f: f.get("name", "").startswith("电影")

# 组合条件
select_files=lambda f: (
    f.get("size", 0) > 50 * 1024 * 1024
    and f.get("type") == "video"
)
```

### on_share_after_transfer 转存后创建分享

| 策略 | 说明 |
|------|------|
| `SKIP` | 不创建分享（默认） |
| `CREATE` | 转存后自动创建分享 |
| `CREATE_IF_NOT_EXISTS` | 仅当文件没有分享链接时创建 |

### 返回值

```python
{
    "task_id": "xxx",           # 转存任务ID
    "status": "success",        # 转存状态
    "transferred_count": 5,     # 转存文件数
    "skipped_count": 2,         # 跳过文件数
    "share_link": "https://pan.xunlei.com/s/VOxxx...",  # 新创建的分享链接
    "pass_code": "1234",        # 提取码
    "results": [                # 详细结果
        {
            "name": "文件1.mp4",
            "path": "/转存目录/文件1.mp4",
            "status": "success",
        },
    ],
}
```

### 示例

```python
# 基本转存
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
)

# 转存到指定目录
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    target_parent="/电影",
)

# 只转存前3个文件
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    select_files=[0, 1, 2],
)

# 只转存视频文件
from xqcxunlei import FileTypeFilter
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    select_files=[FileTypeFilter.VIDEO],
)

# 转存并自动创建分享
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    on_share_after_transfer=ShareAfterTransferStrategy.CREATE,
)

# 转存并设置分享有效期
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    on_share_after_transfer=ShareAfterTransferStrategy.CREATE,
    share_expire_days=30,
)

# 覆盖已存在的文件
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    conflict_strategy=RemoteDownloadConflictStrategy.OVERWRITE,
)

# 无提取码的分享
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="",  # 空字符串
)
```

## download_share 下载分享链接

直接下载分享链接中的文件到本地。

```python
result = await xunlei.download_share(
    share_link="https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    local_dir="./下载",
    select_subfiles=None,
    transfer_dir="/临时目录",
    max_concurrent=3,
    show_progress=True,
)
```

### 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `share_link` | `str` | 必填 | 分享链接 |
| `pass_code` | `str` | `""` | 提取码 |
| `local_dir` | `str` | 必填 | 本地保存目录 |
| `select_subfiles` | `list[int] \| None` | `None` | 选择子文件 |
| `transfer_dir` | `str \| None` | `None` | 临时转存目录 |
| `max_concurrent` | `int` | `3` | 最大并发数 |
| `show_progress` | `bool` | `True` | 显示进度条 |

### 返回值

```python
{
    "total_files": 10,           # 总文件数
    "success_count": 9,          # 成功数
    "failed_count": 1,          # 失败数
    "results": [                # 详细结果
        {
            "name": "文件1.mp4",
            "local_path": "./下载/文件1.mp4",
            "status": "success",
        },
    ],
}
```

### 示例

```python
# 基本下载
result = await xunlei.download_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    local_dir="./下载",
)

# 指定只下载前5个文件
result = await xunlei.download_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    local_dir="./下载",
    select_subfiles=[0, 1, 2, 3, 4],
)

# 更高的并发下载
result = await xunlei.download_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    local_dir="./下载",
    max_concurrent=5,
)

# 不显示进度
result = await xunlei.download_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    local_dir="./下载",
    show_progress=False,
)
```

## CLI 命令

```bash
# 转存分享链接
xqcxunlei transfer "https://pan.xunlei.com/s/VOxxx..." "1234"

# 转存到指定目录
xqcxunlei transfer "链接" "提取码" -t /电影

# 只转存前3个文件
xqcxunlei transfer "链接" "提取码" --select 0,1,2

# 转存并创建分享
xqcxunlei transfer "链接" "提取码" --share

# 下载分享内容到本地
xqcxunlei download-share "链接" "提取码" -o ./下载

# 只下载前5个文件
xqcxunlei download-share "链接" "提取码" -o ./下载 --select 0,1,2,3,4
```

## 完整示例

```python
import asyncio
from xqcxunlei import Xunlei, FileTypeFilter

async def main():
    async with Xunlei(username="账号", password="密码") as xunlei:
        # 1. 转存分享链接
        print("开始转存...")
        result = await xunlei.transfer_share(
            "https://pan.xunlei.com/s/VOxxx...",
            pass_code="1234",
            target_parent="/电影",
            select_files=[FileTypeFilter.VIDEO],
            on_share_after_transfer=ShareAfterTransferStrategy.CREATE,
            share_expire_days=7,
        )
        print(f"转存成功: {result.get('transferred_count')} 个文件")
        if result.get("share_link"):
            print(f"新分享链接: {result.get('share_link')}")

        # 2. 直接下载分享内容
        print("\n开始下载...")
        result = await xunlei.download_share(
            "https://pan.xunlei.com/s/VOxxx...",
            pass_code="1234",
            local_dir="./下载",
            max_concurrent=3,
        )
        print(f"下载完成: {result.get('success_count')}/{result.get('total_files')}")

asyncio.run(main())
```

## 注意事项

1. **提取码**：如果分享链接需要提取码，必须提供 `pass_code` 参数
2. **文件选择**：使用 `select_files` 前可以先查看分享内容结构
3. **临时目录**：`transfer_dir` 用于大文件的临时存储，转存完成后会移动到目标目录
4. **并发控制**：合理设置 `max_concurrent`，过高可能触发限流
5. **分享有效期**：转存后创建的分享默认7天有效，可通过 `share_expire_days` 调整
