# 快速开始

本指南帮助你快速上手使用 xqcxunlei 迅雷云盘 Python SDK。

## 环境配置

### 1. 复制配置模板

```bash
cp .env.example .env
```

### 2. 编辑 .env 文件

```ini
# 必填配置
XUNLEI_USERNAME=你的用户名
XUNLEI_PASSWORD=你的密码

# 可选配置（使用默认值）
XUNLEI_CACHE_DIR=
XUNLEI_AUTO_SAVE=true
XUNLEI_REQUEST_TIMEOUT=30
XUNLEI_MAX_RETRIES=2
XUNLEI_LOG_LEVEL=INFO
```

### 3. 账号配置优先级

| 优先级 | 来源               | 说明                                         |
| ------ | ------------------ | -------------------------------------------- |
| 1      | CLI 手动登录       | 通过 `xqcxunlei login -u xxx -p xxx` 登录    |
| 2      | .env 或环境变量    | 未手动登录时自动使用                         |

> **说明**：CLI 手动登录后，后续命令会自动使用该账号；未手动登录则自动读取 `.env` 或环境变量中的账号配置。

## 安装 SDK

```bash
# 使用 pip
pip install xqc-xl

# 或使用 Poetry
poetry add xqc-xl
```

## 基本使用

### 异步上下文管理器（推荐）

```python
import asyncio
from xqcxunlei import Xunlei

async def main():
    async with Xunlei(username="账号", password="密码") as xunlei:
        # 获取用户信息
        user = await xunlei.get_user_info()
        print(f"用户名: {user.get('nickname')}")

        # 获取云盘空间
        space = await xunlei.get_space_info(human_readable=True)
        print(f"已用空间: {space.get('usage_formatted')}")

        # 列出文件
        files = await xunlei.list_directory("/test")
        print(f"文件数量: {files.get('file_count')}")

asyncio.run(main())
```

### 同步调用

```python
from xqcxunlei import sync

# 同步调用
with Xunlei(username="账号", password="密码") as xunlei:
    user = xunlei.get_user_info_sync()
    print(f"用户名: {user.get('nickname')}")
```

## 常用操作示例

### 文件管理

```python
# 列出目录
files = await xunlei.list_directory("/test", depth=1)

# 搜索文件
results = await xunlei.search(query="电影", path="/视频")

# 创建目录
await xunlei.create_folder("/test/新建目录")

# 重命名
await xunlei.rename(old="/test/旧.txt", new="新.txt")

# 复制
await xunlei.copy(source="/test/文件.txt", target_parent="/备份")

# 移动
await xunlei.move(source="/test/文件.txt", target_parent="/移动")

# 删除（到回收站）
await xunlei.delete("/test/文件.txt")

# 永久删除
await xunlei.delete("/test/文件.txt", permanent=True)
```

### 上传下载

```python
# 上传文件
result = await xunlei.upload("./本地文件.txt", "/test/")

# 上传目录
result = await xunlei.upload_directory("./本地目录", "/test/")

# 下载文件
result = await xunlei.download("/test/文件.txt", local_dir="./下载")

# 获取直链
links = await xunlei.get_direct_link("/test/文件.txt")
```

详细说明：[references/upload.md](references/upload.md)

### 分享链接

```python
# 创建分享
result = await xunlei.create_share_link("/test/文件.txt", valid_days=7)

# 查询分享
info = await xunlei.get_share_info("/test/文件.txt")

# 取消分享
await xunlei.cancel_share_link("/test/文件.txt")

# 导出分享
content = await xunlei.export_share_links(format=ExportFormat.JSON)
```

详细说明：[references/share.md](references/share.md)

### 远程下载

```python
# 获取设备
devices = await xunlei.get_remote_devices()

# 添加磁力下载
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:...",
    device_name=devices[0].get("name"),
)

# 管理任务
tasks = await xunlei.get_remote_tasks(status_filter="running")
await xunlei.pause_remote_task(task_id="xxx")
await xunlei.resume_remote_task(task_id="xxx")
await xunlei.delete_remote_task(task_id="xxx")
```

详细说明：[references/remote_download.md](references/remote_download.md)

### 转存功能

```python
# 转存分享链接
result = await xunlei.transfer_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    target_parent="/转存目录",
)

# 下载分享内容
result = await xunlei.download_share(
    "https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
    local_dir="./下载",
)
```

详细说明：[references/transfer.md](references/transfer.md)

## CLI 命令行

```bash
# 登录
xqcxunlei login -u 用户名 -p 密码

# 文件操作
xqcxunlei ls /test
xqcxunlei search 电影
xqcxunlei mkdir /test/新目录
xqcxunlei upload 本地文件.txt /test/
xqcxunlei download /test/文件.txt -o ./

# 分享操作
xqcxunlei share /test/文件.txt
xqcxunlei share-info /test/文件.txt
xqcxunlei cancel-share /test/文件.txt
xqcxunlei export-shares -f json

# 转存操作
xqcxunlei transfer "链接" "提取码"
xqcxunlei transfer "链接" "提取码" -t /目标目录
xqcxunlei download-share "链接" "提取码" -o ./

# 远程下载
xqcxunlei remote-devices
xqcxunlei remote-add "magnet:..." --device 设备名
xqcxunlei remote-tasks
xqcxunlei remote-pause <task_id>
xqcxunlei remote-resume <task_id>
xqcxunlei remote-delete <task_id>
xqcxunlei remote-speed 10.0
```

## 回调函数与过滤器

### 文件过滤

```python
from xqcxunlei import (
    name_contains_filter,
    extension_filter,
    FileTypeFilter,
)

# 搜索文件名包含"高清"或"1080p"的文件
results = await xunlei.search(
    query=None,
    callback=name_contains_filter(["高清", "1080p"])
)

# 搜索扩展名为 .mp4 或 .mkv 的文件
results = await xunlei.search(
    callback=extension_filter([".mp4", ".mkv"])
)

# 搜索所有视频文件
results = await xunlei.search(
    callback=FileTypeFilter.VIDEO.get_filter()
)
```

### 重命名回调

```python
from xqcxunlei import add_prefix, add_suffix, replace_text, remove_text

# 远程下载时重命名
await xunlei.add_remote_download(
    "magnet:...",
    rename=add_prefix("【下载】")
)

# 添加后缀
await xunlei.add_remote_download(
    "magnet:...",
    rename=add_suffix("_720p")
)

# 替换文本
await xunlei.add_remote_download(
    "magnet:...",
    rename=replace_text("高清", "HD")
)

# 移除文本
await xunlei.add_remote_download(
    "magnet:...",
    rename=remove_text(["[广告]", "[xxx]"])
)
```

## 错误处理

```python
from xqcxunlei.exceptions import (
    XunleiAPIError,
    XunleiAuthError,
    XunleiFileNotFoundError,
)

try:
    await xunlei.get_user_info()
except XunleiAuthError:
    print("登录失败，请检查账号密码")
except XunleiFileNotFoundError:
    print("文件不存在")
except XunleiAPIError as e:
    print(f"API错误: {e.code} - {e.message}")
```

## 枚举类速查

| 枚举类                           | 用途             | 值                                                              |
| -------------------------------- | ---------------- | --------------------------------------------------------------- |
| `CacheStrategy`                  | 缓存策略         | `DISABLED`, `SESSION`, `PERSISTENT`                             |
| `CloudFileExistsStrategy`        | 文件存在策略     | `SKIP`, `RENAME`, `OVERWRITE`, `ABORT`                          |
| `RemoteDownloadConflictStrategy` | 远程下载冲突策略 | `SKIP`, `OVERWRITE`, `RENAME`, `ABORT`                          |
| `FailureStrategy`                | 失败重试策略     | `ABORT`, `DEFERRED_RETRY`, `CONTINUE`                           |
| `FileTypeFilter`                 | 文件类型过滤     | `VIDEO`, `AUDIO`, `IMAGE`, `DOCUMENT`, `ARCHIVE`                |
| `ShareLinkStrategy`              | 分享链接策略     | `SKIP`, `RECREATE`, `OVERWRITE`                                 |
| `TaskOrderStrategy`              | 任务排序策略     | `NATURAL`, `SMALLEST_FIRST`, `LARGEST_FIRST`, `SUBFOLDER_FIRST` |
| `ExportFormat`                   | 导出格式         | `JSON`, `CSV`, `MARKDOWN`                                       |

## 环境变量完整列表

```ini
# 必填
XUNLEI_USERNAME=你的用户名
XUNLEI_PASSWORD=你的密码

# 缓存配置
XUNLEI_CACHE_FILE=
XUNLEI_CACHE_DIR=
XUNLEI_AUTO_SAVE=true

# HTTP 客户端配置
XUNLEI_REQUEST_TIMEOUT=30
XUNLEI_MAX_RETRIES=2
XUNLEI_RETRY_DELAY=1.0

# API 配置（通常不需要修改）
XUNLEI_RISK_URL=https://xluser-ssl.xunlei.com/risk
XUNLEI_SIGNIN_URL=https://xluser-ssl.xunlei.com/v1/auth/signin
XUNLEI_TOKEN_URL=https://xluser-ssl.xunlei.com/v1/auth/token
XUNLEI_FILES_URL=https://api-pan.xunlei.com/drive/v1/files
XUNLEI_TASKS_URL=https://api-pan.xunlei.com/drive/v1/tasks
XUNLEI_SHARE_URL=https://api-pan.xunlei.com/drive/v1/share

# Token 过期时间配置
XUNLEI_ACCESS_TOKEN_EXPIRES=43200
XUNLEI_CAPTCHA_TOKEN_EXPIRES=300

# 日志配置
XUNLEI_LOG_LEVEL=INFO
XUNLEI_LOG_FORMAT=%(asctime)s - %(name)s - %(levelname)s - %(message)s

# MagicPush 推送配置（可选）
MAGICPUSH_SERVER_URL=
MAGICPUSH_TOKEN=
MAGICPUSH_TIMEOUT=30
```

## 相关文档

| 文档                                                           | 说明         |
| -------------------------------------------------------------- | ------------ |
| [references/upload.md](references/upload.md)                   | 文件上传详解 |
| [references/remote_download.md](references/remote_download.md) | 远程下载详解 |
| [references/share.md](references/share.md)                     | 分享链接详解 |
| [references/transfer.md](references/transfer.md)               | 转存功能详解 |
