# 远程下载

远程下载允许用户添加磁力链接、HTTP/HTTPS 直链、BT 种子文件等下载任务，任务会在云端执行。

## add_remote_download 添加下载任务

添加远程下载任务，支持多种 URL 格式。

```python
result = await xunlei.add_remote_download(
    url="magnet:?xt=urn:btih:...",
    device_name=None,
    target_folder=None,
    rename=None,
    select_files=None,
    auto_create_folder=True,
    on_exists=RemoteDownloadConflictStrategy.SKIP,
    return_raw=False,
)
```

### 支持的 URL 格式

| 类型            | 示例                                   | 说明             |
| --------------- | -------------------------------------- | ---------------- |
| HTTP/HTTPS 直链 | `https://example.com/file.zip`         | 直接下载链接     |
| Magnet 磁力链接 | `magnet:?xt=urn:btih:5f7d8b9c...`      | BT 磁力链        |
| BT 种子文件     | `./downloaded.torrent`                 | 本地种子文件路径 |
| 迅雷分享链接    | `https://pan.xunlei.com/s/VOsomeID...` | 云盘分享链接     |
| 云盘资源路径    | `/我的资源/电影.mp4`                   | 云盘内文件路径   |

### 参数说明

| 参数                 | 类型                                         | 默认值  | 说明                           |
| -------------------- | -------------------------------------------- | ------- | ------------------------------ |
| `url`                | `str`                                        | 必填    | 下载链接                       |
| `device_name`        | `str \| None`                                | `None`  | 设备名称，不填则使用第一个设备 |
| `target_folder`      | `str \| None`                                | `None`  | 目标文件夹路径                 |
| `rename`             | `Callable \| None`                           | `None`  | 重命名回调函数                 |
| `select_files`       | `list \| FileTypeFilter \| Callable \| None` | `None`  | 文件选择条件                   |
| `auto_create_folder` | `bool`                                       | `True`  | 自动创建文件夹                 |
| `on_exists`          | `RemoteDownloadConflictStrategy`             | `SKIP`  | 冲突策略                       |
| `return_raw`         | `bool`                                       | `False` | 返回原始数据                   |

### RemoteDownloadConflictStrategy 冲突策略

| 策略        | 说明                     |
| ----------- | ------------------------ |
| `SKIP`      | 跳过已存在的任务（默认） |
| `OVERWRITE` | 覆盖已存在的任务         |
| `RENAME`    | 重命名新任务             |
| `ABORT`     | 中止操作                 |

### select_files 文件选择

**索引列表**：

```python
# 只下载第1、3、5个文件（从0开始计数）
select_files=[0, 2, 4]
```

**文件类型过滤**：

```python
from xqcxunlei import FileTypeFilter

# 只下载视频文件
select_files=[FileTypeFilter.VIDEO]

# 只下载视频和音频
select_files=[FileTypeFilter.VIDEO, FileTypeFilter.AUDIO]
```

**自定义回调**：

```python
# 下载大于100MB的文件
select_files=lambda f: f.get("size", 0) > 100 * 1024 * 1024

# 下载文件名为"高清"的文件
select_files=lambda f: "高清" in f.get("name", "")

# 组合条件：大于100MB的视频文件
select_files=lambda f: (
    f.get("size", 0) > 100 * 1024 * 1024
    and f.get("type") == "video"
)
```

### rename 重命名回调

预设回调函数：

```python
from xqcxunlei import add_prefix, add_suffix, replace_text, remove_text

# 添加前缀
rename = add_prefix("【下载】")

# 添加后缀
rename = add_suffix("_720p")

# 替换文本
rename = replace_text("高清", "HD")

# 移除文本
rename = remove_text(["[广告]", "[xxx]"])
```

自定义回调：

```python
# 移除文件扩展名
rename = lambda name: name.rsplit(".", 1)[0]

# 转小写
rename = lambda name: name.lower()
```

### 返回值

```python
{
    "task_id": "xxx",           # 任务ID
    "status": "running",        # 任务状态
    "name": "文件名.mp4",       # 文件名
    "size": 1024000,           # 文件大小
    "progress": 0,             # 下载进度 0-100
    "device_name": "设备名",    # 设备名称
}
```

### 示例

```python
# 基本磁力下载
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:5f7d8b9c...",
)

# 指定设备和目标文件夹
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:5f7d8b9c...",
    device_name="我的电脑",
    target_folder="/下载视频",
)

# 只下载视频文件
from xqcxunlei import FileTypeFilter
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:5f7d8b9c...",
    select_files=[FileTypeFilter.VIDEO],
)

# 使用重命名
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:5f7d8b9c...",
    rename=add_prefix("【新片】"),
)

# 下载 HTTP 直链
result = await xunlei.add_remote_download(
    "https://example.com/movie.mp4",
    target_folder="/视频",
)

# 下载 BT 种子
result = await xunlei.add_remote_download(
    "./movie.torrent",
    select_files=[0],  # 下载第一个文件
)

# 下载分享链接内容
result = await xunlei.add_remote_download(
    "https://pan.xunlei.com/s/VOsomeID...",
    pass_code="1234",
)

# 强制覆盖已存在的任务
result = await xunlei.add_remote_download(
    "magnet:?xt=urn:btih:5f7d8b9c...",
    on_exists=RemoteDownloadConflictStrategy.OVERWRITE,
)
```

## get_remote_devices 获取设备列表

获取已绑定的远程下载设备。

```python
devices = await xunlei.get_remote_devices()
```

### 返回值

```python
[
    {
        "id": "device_id_xxx",
        "name": "我的电脑",
        "status": "online",
        "platform": "windows",
        "space_total": 1000000000000,
        "space_used": 500000000000,
    },
]
```

### 示例

```python
devices = await xunlei.get_remote_devices()

if devices:
    device = devices[0]
    print(f"设备: {device.get('name')}")
    print(f"状态: {device.get('status')}")
else:
    print("没有找到已绑定的设备")
```

## get_remote_tasks 获取任务列表

获取远程下载任务列表。

```python
tasks = await xunlei.get_remote_tasks(
    device_name=None,
    task_id=None,
    status_filter=None,
    return_raw=False,
)
```

### 参数说明

| 参数            | 类型          | 默认值  | 说明             |
| --------------- | ------------- | ------- | ---------------- |
| `device_name`   | `str \| None` | `None`  | 设备名称         |
| `task_id`       | `str \| None` | `None`  | 任务ID，精确匹配 |
| `status_filter` | `str \| None` | `None`  | 状态过滤         |
| `return_raw`    | `bool`        | `False` | 返回原始数据     |

### status_filter 状态值

| 值         | 说明         |
| ---------- | ------------ |
| `running`  | 下载中的任务 |
| `paused`   | 暂停的任务   |
| `complete` | 已完成的任务 |
| `failed`   | 失败的任务   |

### 返回值

```python
[
    {
        "task_id": "xxx",
        "name": "文件名.mp4",
        "status": "running",
        "progress": 45,
        "size": 1024000,
        "downloaded": 460800,
        "speed": 102400,
        "create_time": "2024-01-01 10:00:00",
        "complete_time": None,
        "error_msg": None,
    },
]
```

### 示例

```python
# 获取所有任务
tasks = await xunlei.get_remote_tasks()

# 获取指定设备的任务
tasks = await xunlei.get_remote_tasks(device_name="我的电脑")

# 获取下载中的任务
running_tasks = await xunlei.get_remote_tasks(status_filter="running")

# 获取已完成的任务
completed_tasks = await xunlei.get_remote_tasks(status_filter="complete")

# 获取指定任务
task = await xunlei.get_remote_tasks(task_id="xxx")
```

## pause_remote_task 暂停任务

```python
await xunlei.pause_remote_task(task_id="xxx")
```

## resume_remote_task 恢复任务

```python
await xunlei.resume_remote_task(task_id="xxx")
```

## delete_remote_task 删除任务

```python
await xunlei.delete_remote_task(task_id="xxx")
```

## set_remote_speed_limit 设置速度限制

设置远程下载的速度限制。

```python
result = await xunlei.set_remote_speed_limit(
    speed_mbps=10.0,
    device_name=None,
)
```

### 参数说明

| 参数          | 类型          | 默认值 | 说明             |
| ------------- | ------------- | ------ | ---------------- |
| `speed_mbps`  | `float`       | 必填   | 速度限制（Mbps） |
| `device_name` | `str \| None` | `None` | 设备名称         |

### speed_mbps 取值范围

- `-1`：不限速
- `0.06` ~ `131.3`：有效范围
- 其他值：无效

### 示例

```python
# 限制为 10Mbps
await xunlei.set_remote_speed_limit(speed_mbps=10.0)

# 限制为 5Mbps
await xunlei.set_remote_speed_limit(speed_mbps=5.0)

# 不限速
await xunlei.set_remote_speed_limit(speed_mbps=-1)

# 指定设备
await xunlei.set_remote_speed_limit(speed_mbps=10.0, device_name="我的电脑")
```

## get_magnet_files 获取磁力文件列表

获取磁力链接的文件列表信息（在添加任务前查看）。

```python
files = await xunlei.get_magnet_files(
    url="magnet:?xt=urn:btih:...",
    file_types=None,
    extensions=None,
    filters=None,
)
```

### 参数说明

| 参数         | 类型               | 默认值 | 说明           |
| ------------ | ------------------ | ------ | -------------- |
| `url`        | `str`              | 必填   | 磁力链接       |
| `file_types` | `list \| None`     | `None` | 文件类型过滤   |
| `extensions` | `list \| None`     | `None` | 扩展名过滤     |
| `filters`    | `Callable \| None` | `None` | 自定义过滤函数 |

### 返回值

```python
[
    {
        "index": 0,
        "name": "电影.mp4",
        "size": 1024000,
        "type": "video",
        "extension": ".mp4",
    },
    {
        "index": 1,
        "name": "字幕.srt",
        "size": 1024,
        "type": "document",
        "extension": ".srt",
    },
]
```

### 示例

```python
# 获取所有文件
files = await xunlei.get_magnet_files("magnet:?xt=urn:btih:...")

# 只获取视频文件
files = await xunlei.get_magnet_files(
    "magnet:?xt=urn:btih:...",
    file_types=[FileTypeFilter.VIDEO],
)

# 只获取 mp4 和 mkv
files = await xunlei.get_magnet_files(
    "magnet:?xt=urn:btih:...",
    extensions=[".mp4", ".mkv"],
)

# 自定义过滤：大于 100MB 的视频
files = await xunlei.get_magnet_files(
    "magnet:?xt=urn:btih:...",
    filters=lambda f: f.get("size", 0) > 100 * 1024 * 1024,
)
```

## CLI 命令

```bash
# 查看设备列表
xqcxunlei remote-devices

# 添加磁力下载任务
xqcxunlei remote-add "magnet:?xt=urn:btih:..."

# 添加 HTTP 下载任务
xqcxunlei remote-add "https://example.com/file.zip"

# 指定设备
xqcxunlei remote-add "magnet:?xt=urn:btih:..." --device 我的电脑

# 指定目标文件夹
xqcxunlei remote-add "magnet:?xt=urn:btih:..." --folder /下载视频

# 查看任务列表
xqcxunlei remote-tasks

# 查看指定设备的任务
xqcxunlei remote-tasks --device 我的电脑

# 暂停任务
xqcxunlei remote-pause <task_id>

# 恢复任务
xqcxunlei remote-resume <task_id>

# 删除任务
xqcxunlei remote-delete <task_id>

# 设置速度限制（10Mbps）
xqcxunlei remote-speed 10.0

# 不限速
xqcxunlei remote-speed -1
```

## 完整使用流程

```python
import asyncio
from xqcxunlei import Xunlei, FileTypeFilter, add_prefix

async def main():
    async with Xunlei(username="账号", password="密码") as xunlei:
        # 1. 获取设备
        devices = await xunlei.get_remote_devices()
        if not devices:
            print("没有可用的设备")
            return

        # 2. 查看磁力文件列表
        files = await xunlei.get_magnet_files("magnet:?xt=urn:btih:...")
        print(f"共 {len(files)} 个文件")

        # 3. 添加下载任务
        result = await xunlei.add_remote_download(
            "magnet:?xt=urn:btih:...",
            device_name=devices[0].get("name"),
            select_files=[FileTypeFilter.VIDEO],  # 只下载视频
            rename=add_prefix("【新片】"),  # 添加前缀
        )
        print(f"任务已添加: {result.get('task_id')}")

        # 4. 查看任务状态
        tasks = await xunlei.get_remote_tasks(status_filter="running")
        for task in tasks:
            print(f"{task['name']}: {task['progress']}%")

asyncio.run(main())
```
