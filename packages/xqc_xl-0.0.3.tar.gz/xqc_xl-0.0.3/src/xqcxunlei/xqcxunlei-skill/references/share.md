# 分享链接

分享链接允许用户将云盘文件分享给其他人访问。

## create_share_link 创建分享链接

为文件或目录创建分享链接。

```python
result = await xunlei.create_share_link(
    targets="/test/文件.txt",
    valid_days=-1,
    extraction_times=-1,
    with_passcode=True,
    on_exists=ShareLinkStrategy.SKIP,
    scope="/",
)
```

### 参数说明

| 参数               | 类型                      | 默认值 | 说明                           |
| ------------------ | ------------------------- | ------ | ------------------------------ |
| `targets`          | `str \| list \| Callable` | 必填   | 文件路径，支持单个、列表或回调 |
| `valid_days`       | `int`                     | `-1`   | 有效天数，`-1` 表示永久有效    |
| `extraction_times` | `int`                     | `-1`   | 允许提取次数，`-1` 表示不限制  |
| `with_passcode`    | `bool`                    | `True` | 是否需要提取码                 |
| `on_exists`        | `ShareLinkStrategy`       | `SKIP` | 已存在时的策略                 |
| `scope`            | `str \| list`             | `"/"`  | 筛选范围                       |

### ShareLinkStrategy 策略

| 策略        | 说明                             |
| ----------- | -------------------------------- |
| `SKIP`      | 跳过，返回现有的分享链接（默认） |
| `RECREATE`  | 创建新的分享链接                 |
| `OVERWRITE` | 删除旧的，创建新的               |

### valid_days 有效天数

| 值   | 说明             |
| ---- | ---------------- |
| `-1` | 永久有效（默认） |
| `1`  | 1天后过期        |
| `7`  | 7天后过期        |
| `30` | 30天后过期       |

### extraction_times 提取次数

| 值   | 说明                   |
| ---- | ---------------------- |
| `-1` | 不限制提取次数（默认） |
| `1`  | 仅可提取1次            |
| `10` | 可提取10次             |

### 返回值

```python
{
    "share_id": "xxx",
    "share_link": "https://pan.xunlei.com/s/VOxxx...",
    "pass_code": "1234",      # 提取码（如果有）
    "share_url": "https://pan.xunlei.com/s/VOxxx...?pwd=1234",
    "targets": ["/test/文件.txt"],
    "valid_days": -1,
    "extraction_times": -1,
    "create_time": "2024-01-01 10:00:00",
}
```

### 示例

```python
# 基本分享
result = await xunlei.create_share_link("/test/文件.txt")

# 分享并设置有效期
result = await xunlei.create_share_link(
    "/test/文件.txt",
    valid_days=7,  # 7天后过期
)

# 分享并设置提取次数
result = await xunlei.create_share_link(
    "/test/文件.txt",
    extraction_times=10,  # 可提取10次
)

# 分享整个目录
result = await xunlei.create_share_link("/test/目录")

# 分享多个文件
result = await xunlei.create_share_link([
    "/test/文件1.txt",
    "/test/文件2.txt",
])

# 分享时不需要提取码
result = await xunlei.create_share_link(
    "/test/文件.txt",
    with_passcode=False,
)

# 已存在时重新创建
result = await xunlei.create_share_link(
    "/test/文件.txt",
    on_exists=ShareLinkStrategy.RECREATE,
)
```

### 使用回调函数选择文件

```python
# 分享所有 mp4 文件
result = await xunlei.create_share_link(
    targets=lambda: [
        f"/test/{name}"
        for name in ["电影1.mp4", "电影2.mp4", "音乐.mp3"]
    ],
    scope="/test",
)

# 配合文件搜索回调
from xqcxunlei import name_contains_filter

result = await xunlei.create_share_link(
    targets=lambda: xunlei.search(callback=name_contains_filter([".mp4"])),
    valid_days=30,
)
```

## get_share_info 查询分享信息

获取分享链接的详细信息。

```python
info = await xunlei.get_share_info(
    targets="/test/文件.txt",
    share_link=None,
    pass_code=None,
)
```

### 参数说明

| 参数         | 类型          | 默认值 | 说明     |
| ------------ | ------------- | ------ | -------- |
| `targets`    | `str`         | 必填   | 文件路径 |
| `share_link` | `str \| None` | `None` | 分享链接 |
| `pass_code`  | `str \| None` | `None` | 提取码   |

### 返回值

```python
{
    "share_id": "xxx",
    "share_link": "https://pan.xunlei.com/s/VOxxx...",
    "pass_code": "1234",
    "file_count": 10,
    "total_size": 1024000,
    "create_time": "2024-01-01 10:00:00",
    "valid_days": -1,
    "extraction_times": -1,
    "files": [
        {
            "name": "文件.txt",
            "path": "/test/文件.txt",
            "size": 1024,
        },
    ],
}
```

### 示例

```python
# 通过文件路径查询
info = await xunlei.get_share_info("/test/文件.txt")

# 通过分享链接查询
info = await xunlei.get_share_info(
    targets=None,
    share_link="https://pan.xunlei.com/s/VOxxx...",
    pass_code="1234",
)
```

## cancel_share_link 取消分享

取消文件的分享链接。

```python
await xunlei.cancel_share_link(targets="/test/文件.txt")
```

### 参数说明

| 参数      | 类型          | 默认值 | 说明                     |
| --------- | ------------- | ------ | ------------------------ |
| `targets` | `str \| list` | 必填   | 文件路径，支持单个或列表 |

### 示例

```python
# 取消单个文件分享
await xunlei.cancel_share_link("/test/文件.txt")

# 取消多个文件分享
await xunlei.cancel_share_link([
    "/test/文件1.txt",
    "/test/文件2.txt",
])
```

## export_share_links 导出分享链接

导出分享链接到文件。

```python
content = await xunlei.export_share_links(
    format=ExportFormat.JSON,
    output_file=None,
)
```

### ExportFormat 格式

| 格式                    | 说明          |
| ----------------------- | ------------- |
| `ExportFormat.JSON`     | JSON 格式     |
| `ExportFormat.CSV`      | CSV 表格格式  |
| `ExportFormat.MARKDOWN` | Markdown 格式 |

### 参数说明

| 参数          | 类型           | 默认值 | 说明                               |
| ------------- | -------------- | ------ | ---------------------------------- |
| `format`      | `ExportFormat` | 必填   | 导出格式                           |
| `output_file` | `str \| None`  | `None` | 输出文件路径，为 None 则返回字符串 |

### 示例

```python
# 导出为 JSON 字符串
json_content = await xunlei.export_share_links(format=ExportFormat.JSON)

# 导出为 CSV 并保存文件
await xunlei.export_share_links(
    format=ExportFormat.CSV,
    output_file="./分享链接.csv",
)

# 导出为 Markdown
md_content = await xunlei.export_share_links(format=ExportFormat.MARKDOWN)
```

### 输出示例

**JSON 格式**：

```json
{
  "share_links": [
    {
      "share_link": "https://pan.xunlei.com/s/VOxxx...",
      "pass_code": "1234",
      "targets": ["/test/文件.txt"],
      "valid_days": -1
    }
  ]
}
```

**Markdown 格式**：

```markdown
# 分享链接列表

| 文件     | 分享链接                          | 提取码 | 有效期 |
| -------- | --------------------------------- | ------ | ------ |
| 文件.txt | https://pan.xunlei.com/s/VOxxx... | 1234   | 永久   |
```

## CLI 命令

```bash
# 创建分享链接
xqcxunlei share /test/文件.txt

# 创建7天有效期的分享
xqcxunlei share /test/文件.txt --valid-days 7

# 创建不需要提取码的分享
xqcxunlei share /test/文件.txt --no-passcode

# 查看分享信息
xqcxunlei share-info /test/文件.txt

# 取消分享
xqcxunlei cancel-share /test/文件.txt

# 导出分享链接
xqcxunlei export-shares -f json

# 导出到文件
xqcxunlei export-shares -f csv -o ./shares.csv
```

## 完整示例

```python
import asyncio
from xqcxunlei import Xunlei

async def main():
    async with Xunlei(username="账号", password="密码") as xunlei:
        # 1. 创建分享链接
        result = await xunlei.create_share_link(
            "/test/文件.txt",
            valid_days=7,
            with_passcode=True,
        )
        print(f"分享链接: {result.get('share_url')}")

        # 2. 查询分享信息
        info = await xunlei.get_share_info("/test/文件.txt")
        print(f"文件数量: {info.get('file_count')}")

        # 3. 导出所有分享链接
        csv_content = await xunlei.export_share_links(
            format=ExportFormat.CSV,
        )
        print(csv_content)

asyncio.run(main())
```
