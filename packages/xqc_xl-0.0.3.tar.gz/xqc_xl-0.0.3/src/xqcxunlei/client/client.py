"""
HTTP 客户端封装模块

提供统一的 HTTP 请求接口:
- 自动重试
- 错误处理
- 请求/响应日志
- 超时控制
- 配置管理
- 增强日志功能
- 统一错误处理
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional

import httpx

from ..config import HTTP_STATUS_SERVER_ERRORS_START, get_config
from ..utils import NetworkError, RequestTimeoutError, XunleiError, get_logger

logger = get_logger(__name__)


class XunleiResponse:
    """响应封装"""

    def __init__(self, response: httpx.Response) -> None:
        self._response = response

    @property
    def status_code(self) -> int:
        return self._response.status_code

    @property
    def headers(self) -> httpx.Headers:
        return self._response.headers

    @property
    def text(self) -> str:
        return self._response.text

    def json(self) -> Optional[dict[str, Any]]:
        """解析 JSON 响应"""
        try:
            return self._response.json()
        except Exception:
            return None

    @property
    def is_success(self) -> bool:
        return 200 <= self._response.status_code < 300

    @property
    def is_error(self) -> bool:
        return self._response.status_code >= HTTP_STATUS_SERVER_ERRORS_START


class XunleiClient:
    """
    Xunlei API HTTP 客户端

    特性:
    - 自动管理连接
    - 请求重试
    - 统一错误处理
    - 日志记录
    """

    DEFAULT_UA = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/126.0.0.0 Safari/537.36"
    )

    def __init__(
        self,
        timeout: int = 30,
        max_retries: int = 2,
    ) -> None:
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "XunleiClient":
        await self.open()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object | None,
    ) -> None:
        await self.close()

    async def open(self) -> None:
        """打开客户端"""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=self.timeout,
                follow_redirects=True,
                headers={"User-Agent": self.DEFAULT_UA},
                limits=httpx.Limits(
                    max_keepalive_connections=20,
                    max_connections=100,
                    keepalive_expiry=30.0,
                ),
            )

    async def close(self) -> None:
        """关闭客户端"""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """确保客户端已打开"""
        if self._client is None:
            raise RuntimeError("Client not opened. Use 'async with' or call open()")
        return self._client

    async def request(
        self,
        method: str,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        files: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """
        发送 HTTP 请求

        Args:
            method: 请求方法 (GET, POST, PATCH, PUT, DELETE)
            url: 请求 URL
            headers: 请求头
            params: URL 参数
            json: JSON 请求体
            data: 表单数据
            files: 文件上传数据
            timeout: 超时时间 (秒)

        Returns:
            XunleiResponse 对象, 失败返回 None
        """
        client = self._ensure_client()
        config = get_config()
        timeout = timeout or config.request_timeout

        try:
            response = await client.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                json=json,
                data=data,
                files=files,
                timeout=timeout,
            )
            return XunleiResponse(response)
        except httpx.TimeoutException:
            logger.warning(f"请求超时: {method} {url}")
            raise RequestTimeoutError(
                timeout or config.request_timeout, f"请求超时: {method} {url}"
            ) from None
        except httpx.RequestError as e:
            logger.warning(f"请求错误: {method} {url} - {e}")
            raise NetworkError(f"网络请求失败: {str(e)}") from e
        except Exception as e:
            logger.error(f"未知错误: {method} {url} - {e}")
            raise NetworkError(f"网络请求异常: {str(e)}") from e

    async def get(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """GET 请求"""
        return await self.request("GET", url, headers=headers, params=params, timeout=timeout)

    async def post(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        files: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """POST 请求"""
        return await self.request(
            "POST",
            url,
            headers=headers,
            params=params,
            json=json,
            data=data,
            files=files,
            timeout=timeout,
        )

    async def patch(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """PATCH 请求"""
        return await self.request(
            "PATCH", url, headers=headers, params=params, json=json, timeout=timeout
        )

    async def put(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[bytes] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """PUT 请求"""
        return await self.request(
            "PUT", url, headers=headers, json=json, data=data, timeout=timeout
        )

    async def delete(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """DELETE 请求"""
        return await self.request("DELETE", url, headers=headers, timeout=timeout)


class RetryClient(XunleiClient):
    """
    带重试机制的 HTTP 客户端

    特性:
    - 自动重试失败请求
    - 可配置重试次数
    - 指数退避
    """

    def __init__(
        self,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
        retry_delay: Optional[float] = None,
    ) -> None:
        config = get_config()
        super().__init__(
            timeout=timeout or config.request_timeout,
            max_retries=max_retries or config.max_retries,
        )
        self.retry_delay = retry_delay or config.retry_delay

    async def request_with_retry(
        self,
        method: str,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[XunleiResponse]:
        """带重试的请求"""
        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = await self.request(method, url, headers, params, json, data, timeout)

                if response is not None:
                    if response.is_success:
                        return response

                    # 非网络错误, 不重试
                    if response.status_code < HTTP_STATUS_SERVER_ERRORS_START:
                        return response

            except XunleiError:
                # 如果是预定义的 Xunlei 异常，不重试，直接抛出
                raise
            except Exception as e:
                last_error = e
                if attempt < self.max_retries:
                    delay = self.retry_delay * (2**attempt)
                    logger.debug(
                        f"请求失败, {delay}秒后重试 (attempt {attempt + 1}): {type(e).__name__}"
                    )
                    await asyncio.sleep(delay)
                    continue

            if attempt < self.max_retries:
                delay = self.retry_delay * (2**attempt)
                logger.debug(f"请求失败, {delay}秒后重试 (attempt {attempt + 1})")
                await asyncio.sleep(delay)

        logger.warning(f"请求失败, 已重试 {self.max_retries} 次: {method} {url}")
        if last_error:
            logger.error(f"最后一次错误: {str(last_error)}")
        return None
