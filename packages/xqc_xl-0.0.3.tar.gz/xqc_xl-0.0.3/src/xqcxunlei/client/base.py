"""
Xunlei API 基础类

提供核心功能:
- 登录/登出
- Token 管理
- 自动刷新
- HTTP 请求封装
- 配置管理
- 增强日志功能
- 统一错误处理
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Optional, Union

import aiofiles
import bencodepy

from ..auth import TokenCache
from ..auth.captcha_sign import get_pub_key_sign
from ..config import (
    HTTP_STATUS_BAD_GATEWAY,
    HTTP_STATUS_FORBIDDEN,
    HTTP_STATUS_GATEWAY_TIMEOUT,
    HTTP_STATUS_INTERNAL_SERVER_ERROR,
    HTTP_STATUS_OK,
    HTTP_STATUS_SERVICE_UNAVAILABLE,
    HTTP_STATUS_TOO_MANY_REQUESTS,
    HTTP_STATUS_UNAUTHORIZED,
    get_config,
)
from ..utils import (
    AuthenticationError,
    LoginRequiredError,
    NetworkError,
    PermissionDeniedError,
    RateLimitError,
    ServiceUnavailableError,
    StructuredLogger,
    XunleiError,
    get_logger,
    handle_http_error,
)
from .client import RetryClient

logger = get_logger(__name__)
structured_logger = StructuredLogger(__name__)


class XunleiBase:
    """
    Xunlei API 基础类

    所有 API 类的基类, 提供:
    - 统一的 HTTP 客户端
    - Token 缓存管理
    - 登录流程
    - 自动刷新机制
    """

    def __init__(
        self,
        username: str,
        password: str,
        cache_file: Optional[str] = None,
        cache_dir: Optional[str] = None,
        auto_save: bool = True,
    ) -> None:
        """
        初始化基础类

        Args:
            username: 迅雷用户名
            password: 迅雷密码
            cache_file: Token 缓存文件路径
            cache_dir: Token 缓存目录 (如果未指定cache_file)
            auto_save: 是否自动保存 Token
        """
        self.username = username
        self.password = password

        # 获取配置
        self.config = get_config()

        # 初始化缓存 - 优先使用传入参数，然后是配置，最后是默认值
        resolved_cache_file = cache_file or self.config.cache_file
        resolved_cache_dir = cache_dir or self.config.cache_dir
        resolved_auto_save = auto_save

        self.cache = TokenCache(
            username,
            cache_file=resolved_cache_file,
            cache_dir=resolved_cache_dir,
            auto_save=resolved_auto_save,
        )

        # HTTP 客户端
        self._client: Optional[RetryClient] = None

        # 运行时状态
        self._is_initialized = False

    async def __aenter__(self) -> "XunleiBase":
        await self.open()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    async def open(self) -> None:
        """打开客户端"""
        if self._client is None:
            self._client = RetryClient()
            await self._client.open()

        # 尝试加载缓存
        await self.cache.load_async()
        self._is_initialized = True

    async def close(self) -> None:
        """关闭客户端"""
        if self._client is not None:
            await self._client.close()
            self._client = None

        await self.cache.close()
        self._is_initialized = False

    @property
    def client(self) -> RetryClient:
        """获取 HTTP 客户端"""
        if self._client is None:
            raise RuntimeError("Client not opened. Use 'async with' or call open()")
        return self._client

    @property
    def is_login(self) -> bool:
        """是否已登录"""
        return self.cache.is_login and self.cache.is_access_token_valid

    # ==================== 登录流程 ====================

    async def _get_device_id(self) -> Optional[str]:
        """获取设备 ID"""
        resp = await self.client.post(
            self.config.risk_url,
            params={"cmd": "report"},
            json={
                "xl_fp_raw": "53793f98c0f944f0837946d9d694c55b",
                "xl_fp": "dfe57c652a6400764d825dcfb9ea1e17",
                "version": 2,
                "xl_fp_sign": "c8f4a425a1cfd1d8029b0151735d3d7a",
            },
        )

        if resp and resp.is_success:
            data = resp.json()
            device_sign = data.get("deviceid", "")
            if device_sign:
                device_id = device_sign.split(".")[-1][:32]
                self.cache.update(device_id=device_id)
                return device_id

        return None

    async def _get_captcha_token_for_login(self) -> Optional[str]:
        """获取登录用的 captcha_token"""
        device_id = await self._get_device_id()
        if not device_id:
            return None

        resp = await self.client.post(
            self.config.captcha_init_url,
            json={
                "client_id": self.config.login_client_id,
                "action": "POST:/v1/auth/signin",
                "device_id": device_id,
                "meta": {"username": self.username},
            },
        )

        if resp and resp.is_success:
            return resp.json().get("captcha_token")
        return None

    async def _do_login(self) -> bool:
        """执行登录"""
        captcha_token = await self._get_captcha_token_for_login()
        if not captcha_token:
            logger.error("获取登录 captcha_token 失败")
            return False

        # MD5 加密密码
        encrypted_password = hashlib.md5(self.password.encode()).hexdigest()

        resp = await self.client.post(
            self.config.signin_url,
            headers={"x-captcha-token": captcha_token},
            json={
                "username": self.username,
                "password": encrypted_password,
                "client_id": self.config.login_client_id,
            },
        )

        if resp and resp.is_success:
            data = resp.json()
            if data.get("access_token"):
                self.cache.set_login(
                    access_token=data["access_token"],
                    user_id=data.get("user_id", ""),
                    expires_in=data.get("expires_in", self.config.access_token_expires),
                )
                logger.info(f"登录成功: {self.username}")
                return True

        logger.error(f"登录失败: {resp.text if resp else 'No response'}")
        return False

    async def _get_token_code(self) -> Optional[str]:
        """获取刷新 Token 用的 code"""
        if not self.cache.tokens.access_token:
            return None

        resp = await self.client.post(
            self.config.authorize_url,
            headers={"Authorization": f"Bearer {self.cache.tokens.access_token}"},
            json={
                "client_id": self.config.token_client_id,
                "response_type": "code",
                "redirect_uri": self.config.redirect_uri,
                "state": self.config.state,
                "scope": self.config.scope,
                "code_challenge": self.config.code_challenge,
                "code_challenge_method": self.config.code_challenge_method,
                "sign_out_uri": "https://pan.xunlei.com/remote/signout/?sso_sign_out=",
            },
        )

        if resp and resp.is_success:
            return resp.json().get("code")
        return None

    async def _refresh_access_token(self) -> bool:
        """刷新 access_token"""
        code = await self._get_token_code()
        if not code:
            return False

        resp = await self.client.post(
            self.config.token_url,
            json={
                "code": code,
                "grant_type": "authorization_code",
                "code_verifier": self.config.code_verifier,
                "redirect_uri": self.config.redirect_uri,
                "client_id": self.config.token_client_id,
            },
        )

        if resp and resp.is_success:
            data = resp.json()
            if data.get("access_token"):
                self.cache.set_access_token(
                    data["access_token"],
                    expires_in=data.get("expires_in", self.config.access_token_expires),
                )
                logger.debug("access_token 已刷新")
                return True

        return False

    async def _refresh_captcha_token(self) -> bool:
        """刷新 captcha_token"""
        device_id = self.cache.tokens.device_id
        if not device_id:
            logger.warning("没有 device_id, 无法刷新 captcha_token")
            return False

        import time

        timestamp = str(int(time.time() * 1000))
        captcha_sign = await get_pub_key_sign(device_id, timestamp)

        resp = await self.client.post(
            self.config.captcha_init_url,
            json={
                "client_id": self.config.token_client_id,
                "action": "GET:CAPTCHA_TOKEN",
                "device_id": device_id,
                "meta": {
                    "user_id": self.cache.tokens.user_id,
                    "user_name": self.username,
                    "client_version": self.config.client_version,
                    "package_name": self.config.package_name,
                    "timestamp": timestamp,
                    "captcha_sign": captcha_sign,
                },
            },
        )

        if resp and resp.is_success:
            token = resp.json().get("captcha_token")
            if token:
                self.cache.set_captcha_token(
                    token,
                    expires_in=self.config.captcha_token_expires,
                )
                logger.debug("captcha_token 已刷新")
                return True

        return False

    async def login(self) -> bool:
        """
        登录

        如果缓存有效则跳过登录, 否则执行完整登录流程
        """
        try:
            # 检查是否已登录且 Token 有效
            if self.cache.is_login and self.cache.is_access_token_valid:
                # 检查是否需要刷新 captcha_token
                if self.cache.is_captcha_token_valid and not self.cache.tokens.needs_refresh:
                    logger.debug("使用缓存登录")
                    return True

                # 刷新 captcha_token
                if await self._refresh_captcha_token():
                    return True

                # Token 过期, 尝试刷新
                if await self._refresh_access_token():
                    return await self._refresh_captcha_token()

                return False

            # 执行登录
            if not await self._do_login():
                return False

            # 刷新 Token (获取云盘可用 Token)
            if not await self._refresh_access_token():
                logger.warning("刷新 access_token 失败, 继续使用登录 Token")

            # 获取 captcha_token
            await self._refresh_captcha_token()

            return True
        except XunleiError:
            # 重新抛出已知的 Xunlei 异常
            raise
        except Exception as e:
            logger.error(f"登录过程中发生未知错误: {str(e)}")
            return False

    async def logout(self) -> None:
        """登出"""
        self.cache.clear()
        logger.info("已登出")

    # ==================== HTTP 请求封装 ====================

    async def request(  # noqa: C901
        self,
        method: str,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """
        发送 HTTP 请求

        自动处理:
        - 登录状态检查
        - Token 刷新
        - 重试
        """
        try:
            # 确保已登录
            if not self.is_login:
                if not await self.login():
                    raise LoginRequiredError("登录失败，无法继续请求")

            # 获取请求头
            final_headers = self.cache.get_headers()
            if headers:
                final_headers.update(headers)

            # 发送请求
            resp = await self.client.request_with_retry(
                method=method,
                url=url,
                headers=final_headers,
                params=params,
                json=json,
                data=data,
                timeout=timeout,
            )

            if resp is None:
                logger.warning(f"请求失败: {method} {url} - 无响应")
                return None

            # 检查响应
            if resp.status_code == HTTP_STATUS_OK:
                return resp.json()

            # 特殊错误处理
            if resp.status_code == HTTP_STATUS_UNAUTHORIZED:
                raise AuthenticationError(f"认证失败: {resp.text}")
            elif resp.status_code == HTTP_STATUS_FORBIDDEN:
                resp_data = resp.json() if resp.text else {}
                if resp_data.get("error_code") is not None:
                    return resp_data
                raise PermissionDeniedError(f"权限不足: {resp.text}")
            elif resp.status_code == HTTP_STATUS_TOO_MANY_REQUESTS:
                raise RateLimitError(f"请求频率过高: {resp.text}")
            elif resp.status_code in [
                HTTP_STATUS_INTERNAL_SERVER_ERROR,
                HTTP_STATUS_BAD_GATEWAY,
                HTTP_STATUS_SERVICE_UNAVAILABLE,
                HTTP_STATUS_GATEWAY_TIMEOUT,
            ]:
                raise ServiceUnavailableError(f"服务暂时不可用 (状态码: {resp.status_code})")

            # Token 过期处理
            if resp.status_code == 400:
                resp_data = resp.json()
                if resp_data and resp_data.get("error") in ("captcha_invalid", "access_denied"):
                    logger.debug("Token 过期，尝试刷新...")

                    # 尝试刷新
                    if await self._refresh_access_token():
                        if await self._refresh_captcha_token():
                            # 重试请求
                            final_headers = self.cache.get_headers()
                            if headers:
                                final_headers.update(headers)

                            retry_resp = await self.client.request(
                                method, url, final_headers, params, json, data, timeout
                            )

                            if retry_resp and retry_resp.status_code == HTTP_STATUS_OK:
                                return retry_resp.json()
                            elif retry_resp:
                                # 如果重试仍然失败，抛出具体错误
                                raise handle_http_error(retry_resp.status_code, retry_resp.text)

            logger.warning(f"请求失败: {resp.status_code} {resp.text}")
            return None

        except XunleiError:
            # 重新抛出已知的 Xunlei 异常
            raise
        except Exception as e:
            # 处理其他未预期的异常
            logger.error(f"请求过程中发生未知错误：{str(e)}")
            raise NetworkError(f"网络请求异常：{str(e)}") from e

    async def _process_response(
        self,
        resp: Any,
        method: str,
        url: str,
        headers: Optional[dict[str, str]],
        params: Optional[dict[str, Any]],
        json: Optional[dict[str, Any]],
        data: Optional[dict[str, Any]],
        timeout: Optional[int],
    ) -> Optional[dict[str, Any]]:
        """处理 HTTP 响应"""
        # 检查响应
        if resp.status_code == HTTP_STATUS_OK:
            return resp.json()

        # 特殊错误处理
        if resp.status_code == HTTP_STATUS_UNAUTHORIZED:
            raise AuthenticationError(f"认证失败：{resp.text}")
        elif resp.status_code == HTTP_STATUS_FORBIDDEN:
            raise PermissionDeniedError(f"权限不足：{resp.text}")
        elif resp.status_code == HTTP_STATUS_TOO_MANY_REQUESTS:
            raise RateLimitError(f"请求频率过高：{resp.text}")
        elif resp.status_code in [
            HTTP_STATUS_INTERNAL_SERVER_ERROR,
            HTTP_STATUS_BAD_GATEWAY,
            HTTP_STATUS_SERVICE_UNAVAILABLE,
            HTTP_STATUS_GATEWAY_TIMEOUT,
        ]:
            raise ServiceUnavailableError(f"服务暂时不可用 (状态码：{resp.status_code})")

        # Token 过期处理
        if resp.status_code == 400:
            return await self._handle_token_expired(
                resp, method, url, headers, params, json, data, timeout
            )

        logger.warning(f"请求失败：{resp.status_code} {resp.text}")
        return None

    async def _handle_token_expired(
        self,
        resp: Any,
        method: str,
        url: str,
        headers: Optional[dict[str, str]],
        params: Optional[dict[str, Any]],
        json: Optional[dict[str, Any]],
        data: Optional[dict[str, Any]],
        timeout: Optional[int],
    ) -> Optional[dict[str, Any]]:
        """处理 Token 过期情况"""
        resp_data = resp.json()
        if resp_data and resp_data.get("error") in ("captcha_invalid", "access_denied"):
            logger.debug("Token 过期，尝试刷新...")

            # 尝试刷新
            if await self._refresh_access_token():
                if await self._refresh_captcha_token():
                    # 重试请求
                    final_headers = self.cache.get_headers()
                    if headers:
                        final_headers.update(headers)

                    retry_resp = await self.client.request(
                        method, url, final_headers, params, json, data, timeout
                    )

                    if retry_resp and retry_resp.status_code == HTTP_STATUS_OK:
                        return retry_resp.json()
                    elif retry_resp:
                        # 如果重试仍然失败，抛出具体错误
                        raise handle_http_error(retry_resp.status_code, retry_resp.text)

        logger.warning(f"请求失败：{resp.status_code} {resp.text}")
        return None

    async def get(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        params: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """GET 请求"""
        return await self.request("GET", url, headers=headers, params=params, timeout=timeout)

    async def post(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """POST 请求"""
        return await self.request(
            "POST", url, headers=headers, json=json, data=data, timeout=timeout
        )

    async def patch(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        json: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """PATCH 请求"""
        return await self.request("PATCH", url, headers=headers, json=json, timeout=timeout)

    # ==================== 工具方法 ====================

    @staticmethod
    def split_path(path: str, change_to_lower: bool = False) -> list[str]:
        """拆分路径"""
        p = Path(path)
        parts = [str(part) for part in p.parts]
        parts = [part for part in parts if part and part not in ("/", "\\", "\\\\")]
        if change_to_lower:
            parts = [part.lower() for part in parts]
        return parts

    @staticmethod
    def format_sub_file_index(indices: list[Union[int, str]]) -> str:
        """格式化子文件索引"""
        if not indices:
            return ""

        nums = sorted(int(i) - 1 for i in indices)
        ranges = []
        start = end = nums[0]

        for i in range(1, len(nums)):
            if nums[i] == end + 1:
                end = nums[i]
            else:
                ranges.append(f"{start}-{end}" if start != end else str(start))
                start = end = nums[i]

        ranges.append(f"{start}-{end}" if start != end else str(start))
        return ",".join(ranges)

    @staticmethod
    async def parse_torrent(file_path: str) -> tuple[str, str]:
        """解析种子文件"""
        async with aiofiles.open(file_path, "rb") as f:
            data = await f.read()

        torrent = bencodepy.decode(data)
        info = bencodepy.encode(torrent[b"info"])
        info_hash = hashlib.sha1(info).hexdigest()
        name = torrent[b"info"][b"name"].decode("utf-8")
        magnet = f"magnet:?xt=urn:btih:{info_hash}"

        return magnet, name
