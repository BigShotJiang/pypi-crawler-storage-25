"""
MagicPush 通知模块

基于 MagicPush 服务的消息推送工具，支持通过预先部署的 MagicPush 服务发送通知

使用方式:
1. 部署 MagicPush 服务: https://github.com/magiccode1412/magicpush
2. 获取访问令牌
3. 配置服务端点和令牌
4. 使用本模块发送通知

配置方式（按优先级从高到低）:
1. 直接传参: MagicPushNotifier(server_url="...", token="...")
2. 环境变量: MAGICPUSH_SERVER_URL, MAGICPUSH_TOKEN
3. .env 文件: MAGICPUSH_SERVER_URL=http://localhost:3000, MAGICPUSH_TOKEN=your_token
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from enum import Enum
from typing import Coroutine

import httpx

from ..config import DEFAULT_TIMEOUT
from .exceptions import XunleiError
from .logger import get_logger

logger = get_logger(__name__)


class MessageType(Enum):
    """消息类型枚举"""

    TEXT = "text"
    MARKDOWN = "markdown"
    HTML = "html"


class PushError(XunleiError):
    """推送相关异常"""

    def __init__(self, message: str = "推送失败", details: dict | None = None):
        super().__init__(message, "PUSH_ERROR", details)


class PushServerError(PushError):
    """推送服务器错误"""

    def __init__(self, message: str = "推送服务器错误", status_code: int | None = None):
        details = {"status_code": status_code} if status_code else None
        super().__init__(message, details)


class PushAuthError(PushError):
    """推送认证错误"""

    def __init__(self, message: str = "推送认证失败"):
        super().__init__(message, {"reason": "auth_failed"})


@dataclass
class PushResult:
    """推送结果"""

    success: bool
    message: str
    error_code: str | None = None
    details: dict | None = None


class MagicPushNotifier:
    """
    MagicPush 通知器

    用于通过 MagicPush 服务发送通知消息

    配置优先级（从高到低）:
    1. 构造函数直接传参
    2. 环境变量 MAGICPUSH_SERVER_URL, MAGICPUSH_TOKEN
    3. .env 文件中的配置
    """

    def __init__(
        self,
        server_url: str | None = None,
        token: str | None = None,
        timeout: int | None = None,
    ):
        """
        初始化 MagicPush 通知器

        Args:
            server_url: MagicPush 服务地址，必填。默认从环境变量 MAGICPUSH_SERVER_URL 获取
            token: 访问令牌，必填。默认从环境变量 MAGICPUSH_TOKEN 获取
            timeout: 请求超时时间（秒），默认从环境变量 MAGICPUSH_TIMEOUT 获取

        Raises:
            ValueError: 当 server_url 或 token 未设置时抛出
        """
        env_server_url = os.getenv("MAGICPUSH_SERVER_URL")
        env_token = os.getenv("MAGICPUSH_TOKEN")

        if not server_url and not env_server_url:
            raise ValueError(
                "MagicPush server_url 未设置。" "请通过参数传入或设置环境变量 MAGICPUSH_SERVER_URL"
            )

        if not token and not env_token:
            raise ValueError("MagicPush token 未设置。请通过参数传入或设置环境变量 MAGICPUSH_TOKEN")

        self.server_url = (server_url or env_server_url).rstrip("/")
        self.token = token or env_token
        self.timeout = timeout or int(os.getenv("MAGICPUSH_TIMEOUT", str(DEFAULT_TIMEOUT)))

        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        """获取或创建 HTTP 客户端"""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """关闭 HTTP 客户端"""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "MagicPushNotifier":
        """异步上下文管理器入口"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """异步上下文管理器出口"""
        await self.close()

    def _build_headers(self) -> dict:
        """构建请求头"""
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    @property
    def is_configured(self) -> bool:
        """检查是否已配置 token"""
        return bool(self.token)

    async def send(
        self,
        content: str,
        title: str | None = None,
        message_type: MessageType = MessageType.TEXT,
    ) -> PushResult:
        """
        发送通知消息

        Args:
            content: 消息内容
            title: 消息标题（可选）
            message_type: 消息类型（text/markdown/html）

        Returns:
            推送结果
        """
        payload = {
            "content": content,
            "type": message_type.value,
        }
        if title:
            payload["title"] = title

        try:
            client = self._get_client()
            response = await client.post(
                f"{self.server_url}/api/push",
                json=payload,
                headers=self._build_headers(),
            )

            if response.status_code == 200:
                result = response.json()
                if result.get("code") == 0 or result.get("success"):
                    logger.info(f"通知发送成功: {title or '无标题'}")
                    return PushResult(
                        success=True,
                        message=result.get("msg", "发送成功"),
                        details=result,
                    )
                else:
                    error_msg = result.get("msg", "发送失败")
                    logger.error(f"通知发送失败: {error_msg}")
                    return PushResult(
                        success=False,
                        message=error_msg,
                        error_code="PUSH_FAILED",
                        details=result,
                    )
            elif response.status_code == 401:
                logger.error("MagicPush 认证失败，请检查 token")
                return PushResult(
                    success=False,
                    message="认证失败",
                    error_code="AUTH_ERROR",
                )
            elif response.status_code == 429:
                logger.warning("通知发送被限流")
                return PushResult(
                    success=False,
                    message="请求过于频繁，请稍后重试",
                    error_code="RATE_LIMIT",
                )
            else:
                logger.error(f"通知发送失败，状态码: {response.status_code}")
                return PushResult(
                    success=False,
                    message=f"服务器错误: {response.status_code}",
                    error_code="SERVER_ERROR",
                )

        except httpx.TimeoutException:
            logger.error(f"通知发送超时（{self.timeout}秒）")
            return PushResult(
                success=False,
                message="请求超时",
                error_code="TIMEOUT",
            )
        except httpx.RequestError as e:
            logger.error(f"通知发送请求失败: {e}")
            return PushResult(
                success=False,
                message=f"网络错误: {e}",
                error_code="NETWORK_ERROR",
            )
        except Exception as e:
            logger.error(f"通知发送异常: {e}")
            return PushResult(
                success=False,
                message=f"未知错误: {e}",
                error_code="UNKNOWN",
            )

    async def send_text(
        self,
        content: str,
        title: str | None = None,
    ) -> PushResult:
        """
        发送文本消息

        :param content: 消息内容
        :param title: 消息标题
        :return: 推送结果
        """
        return await self.send(content, title, MessageType.TEXT)

    async def send_markdown(
        self,
        content: str,
        title: str | None = None,
    ) -> PushResult:
        """
        发送 Markdown 消息

        :param content: Markdown 格式的消息内容
        :param title: 消息标题
        :return: 推送结果
        """
        return await self.send(content, title, MessageType.MARKDOWN)

    async def send_html(
        self,
        content: str,
        title: str | None = None,
    ) -> PushResult:
        """
        发送 HTML 消息

        :param content: HTML 格式的消息内容
        :param title: 消息标题
        :return: 推送结果
        """
        return await self.send(content, title, MessageType.HTML)


async def create_notifier(
    server_url: str | None = None,
    token: str | None = None,
    timeout: int | None = None,
) -> MagicPushNotifier:
    """
    创建通知器实例的便捷函数

    Args:
        server_url: MagicPush 服务地址，默认从环境变量获取
        token: 访问令牌，默认从环境变量获取
        timeout: 请求超时时间（秒），默认从环境变量获取

    Returns:
        MagicPushNotifier 实例
    """
    return MagicPushNotifier(server_url=server_url, token=token, timeout=timeout)


def send_message(
    content: str,
    title: str | None = None,
    message_type: MessageType = MessageType.TEXT,
    timeout: int | None = None,
    server_url: str | None = None,
    token: str | None = None,
) -> PushResult | Coroutine[PushResult, None, None]:
    """
    发送通知消息的便捷函数（自动适应同步/异步调用）

    配置方式（按优先级从高到低）:
    1. 直接传参: server_url, token
    2. 环境变量: MAGICPUSH_SERVER_URL, MAGICPUSH_TOKEN
    3. .env 文件中的配置

    Args:
        content: 消息内容
        title: 消息标题（可选）
        message_type: 消息类型，默认 Text
        timeout: 请求超时时间（秒）
        server_url: MagicPush 服务地址（可选）
        token: 访问令牌（可选）

    Returns:
        在异步上下文中调用时返回协程对象，需使用 await
        在同步上下文中调用时直接返回 PushResult

    Raises:
        ValueError: 当 server_url 或 token 未设置时抛出

    Example:
        ```python
        from xqcxunlei.utils import send_message, MessageType

        # 异步调用（推荐在 async 代码中使用）
        await send_message("任务完成！")

        # 同步调用（推荐在普通代码中使用）
        result = send_message("任务完成！")

        # 发送 Markdown 消息
        await send_message("**任务完成**", message_type=MessageType.MARKDOWN)

        # 发送带标题的消息
        await send_message("详情内容", "任务完成")

        # 手动指定服务器和令牌
        await send_message("测试消息", server_url="http://localhost:3000", token="xxx")
        ```
    """
    try:
        asyncio.get_running_loop()
        return _send_message_async(content, title, message_type, timeout, server_url, token)
    except RuntimeError:
        return _send_message_sync(content, title, message_type, timeout, server_url, token)


async def _send_message_async(
    content: str,
    title: str | None = None,
    message_type: MessageType = MessageType.TEXT,
    timeout: int | None = None,
    server_url: str | None = None,
    token: str | None = None,
) -> PushResult:
    """
    异步发送通知消息

    Args:
        content: 消息内容
        title: 消息标题（可选）
        message_type: 消息类型
        timeout: 请求超时时间（秒）
        server_url: MagicPush 服务地址
        token: 访问令牌

    Returns:
        推送结果
    """
    notifier = MagicPushNotifier(server_url=server_url, token=token, timeout=timeout)
    return await notifier.send(content, title, message_type)


def _send_message_sync(
    content: str,
    title: str | None = None,
    message_type: MessageType = MessageType.TEXT,
    timeout: int | None = None,
    server_url: str | None = None,
    token: str | None = None,
) -> PushResult:
    """
    同步发送通知消息

    Args:
        content: 消息内容
        title: 消息标题（可选）
        message_type: 消息类型
        timeout: 请求超时时间（秒）
        server_url: MagicPush 服务地址
        token: 访问令牌

    Returns:
        推送结果
    """
    return asyncio.run(
        _send_message_async(content, title, message_type, timeout, server_url, token)
    )


__all__ = [
    "MagicPushNotifier",
    "MessageType",
    "PushResult",
    "PushError",
    "PushServerError",
    "PushAuthError",
    "create_notifier",
    "send_message",
]
