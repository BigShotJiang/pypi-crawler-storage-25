"""
Xunlei API 通用工具模块

提供常用的工具函数:
- 路径处理
- 文件索引格式化
- 种子文件解析
- 其他通用工具函数
- 增强日志功能
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import List, Union

import aiofiles

from ..config import MAX_FILENAME_LENGTH, MIN_ASCII_VISIBLE


def split_path(path: str, change_to_lower: bool = False) -> list[str]:
    """
    拆分路径为组件列表

    :param path: 要拆分的路径字符串
    :param change_to_lower: 是否将路径组件转换为小写
    :return: 路径组件列表
    """
    p = Path(path)
    parts = [str(part) for part in p.parts]
    parts = [part for part in parts if part and part not in ("/", "\\", "\\\\")]
    if change_to_lower:
        parts = [part.lower() for part in parts]

    return parts


def format_sub_file_index(indices: List[Union[int, str]]) -> str:
    """
    格式化子文件索引

    :param indices: 索引列表
    :return: 格式化的索引字符串
    """
    if not indices:
        return ""

    nums = sorted(int(i) - 1 for i in indices)
    ranges = []
    start = end = nums[0]

    for i in range(1, len(nums)):
        if nums[i] == end + 1:
            end = nums[i]
        else:
            ranges.append(f"{start}-{end}" if start != end else str(start))
            start = end = nums[i]

    ranges.append(f"{start}-{end}" if start != end else str(start))
    return ",".join(ranges)


async def parse_torrent(file_path: str) -> tuple[str, str]:
    """解析种子文件"""
    import bencodepy

    async with aiofiles.open(file_path, "rb") as f:
        data = await f.read()

    torrent = bencodepy.decode(data)
    info = bencodepy.encode(torrent[b"info"])
    info_hash = hashlib.sha1(info).hexdigest()
    name = torrent[b"info"][b"name"].decode("utf-8")
    magnet = f"magnet:?xt=urn:btih:{info_hash}"

    return magnet, name


def calculate_file_hash(file_path: str) -> str:
    """计算文件 SHA1 哈希"""
    sha1 = hashlib.sha1()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            sha1.update(chunk)
    return sha1.hexdigest()


async def calculate_file_hash_async(file_path: str) -> str:
    """异步计算文件 SHA1 哈希"""
    sha1 = hashlib.sha1()
    async with aiofiles.open(file_path, "rb") as f:
        while chunk := await f.read(8192):
            sha1.update(chunk)
    return sha1.hexdigest()


def format_bytes(size_bytes: int) -> str:
    """格式化字节数为人类可读格式"""
    if size_bytes == 0:
        return "0 B"

    size_names = ["B", "KB", "MB", "GB", "TB"]
    import math

    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_names[i]}"


def sanitize_filename(filename: str) -> str:
    """清理文件名，移除非法字符"""
    # 替换非法字符
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, "_")

    # 移除控制字符 (ASCII 0-31)
    filename = "".join(c for c in filename if ord(c) >= MIN_ASCII_VISIBLE)

    # 限制长度
    if len(filename) > MAX_FILENAME_LENGTH:
        name, ext = os.path.splitext(filename)
        filename = name[: MAX_FILENAME_LENGTH - len(ext)] + ext

    return filename


def is_valid_url(url: str) -> bool:
    """简单验证 URL 格式"""
    import re

    url_pattern = re.compile(
        r"^https?://"  # http:// or https://
        r"(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}"  # domain
        r"(?:/[^\s]*)?$"  # optional path
    )
    return bool(url_pattern.match(url))


def is_magnet_link(url: str) -> bool:
    """检查是否为磁力链接"""
    return url.startswith("magnet:?")


def is_torrent_file(url_or_path: str) -> bool:
    """检查是否为种子文件"""
    return url_or_path.endswith(".torrent") or is_magnet_link(url_or_path)


def normalize_path(path: str) -> str:
    """标准化路径格式"""
    # 将反斜杠替换为正斜杠
    normalized = path.replace("\\", "/")
    # 处理连续的斜杠
    import re

    normalized = re.sub(r"/+", "/", normalized)
    # 移除末尾的斜杠（除非是根目录）
    if len(normalized) > 1:
        normalized = normalized.rstrip("/")
    return normalized


def generate_unique_name(base_name: str, existing_names: list[str], max_attempts: int = 100) -> str:
    """生成唯一的文件/目录名称"""
    if base_name not in existing_names:
        return base_name

    name, ext = os.path.splitext(base_name)
    for i in range(1, max_attempts + 1):
        candidate = f"{name}_{i}{ext}"
        if candidate not in existing_names:
            return candidate

    # 如果尝试了足够多次仍未找到唯一名称，则使用哈希
    import hashlib

    hash_suffix = hashlib.md5(base_name.encode()).hexdigest()[:8]
    return f"{name}_{hash_suffix}{ext}"
