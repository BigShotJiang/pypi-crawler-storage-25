"""
Xunlei API 统一日志系统

提供统一的日志功能:
- 结构化日志输出
- 敏感信息过滤
- 日志级别动态调整
- 多格式支持
- 异步日志记录
- 性能优化
"""

from __future__ import annotations

import asyncio
import logging
import re
import sys
import time
from functools import wraps
from typing import Any, Optional

from ..config import get_config


class SensitiveDataFilter(logging.Filter):
    """
    敏感数据过滤器，用于过滤日志中的敏感信息
    """

    def __init__(self, patterns: Optional[list[str]] = None):
        super().__init__()
        self.patterns = patterns or [
            r"(?i)(password|token|key|secret|auth|bearer|captcha|access_token|refresh_token|device_id|user_id)[\s\S]*?[\"\'\s:=][^\"\'\s,;]*[\"\'\s,;]",
            r'"access_token"[^}]*?"[^"]*"',
            r'"captcha_token"[^}]*?"[^"]*"',
            r'"refresh_token"[^}]*?"[^"]*"',
            r'"device_id"[^}]*?"[^"]*"',
            r'"user_id"[^}]*?"[^"]*"',
            r'"authorization"[^}]*?"[^"]*"',
            r'"x-captcha-token"[^}]*?"[^"]*"',
        ]

    def filter(self, record: logging.LogRecord) -> bool:
        """
        过滤日志记录中的敏感信息
        """
        replacement = '"***HIDDEN***"'

        if hasattr(record, "msg") and isinstance(record.msg, str):
            for pattern in self.patterns:
                try:
                    record.msg = re.sub(pattern, replacement, record.msg)
                except re.error:
                    pass

        if hasattr(record, "args") and record.args:
            filtered_args = []
            for arg in record.args:
                if isinstance(arg, str):
                    filtered_arg = arg
                    for pattern in self.patterns:
                        try:
                            filtered_arg = re.sub(pattern, replacement, filtered_arg)
                        except re.error:
                            pass
                    filtered_args.append(filtered_arg)
                else:
                    filtered_args.append(arg)
            record.args = tuple(filtered_args)

        return True


class ColoredFormatter(logging.Formatter):
    """
    彩色日志格式化器
    """

    COLORS = {
        "DEBUG": "\033[36m",  # 青色
        "INFO": "\033[32m",  # 绿色
        "WARNING": "\033[33m",  # 黄色
        "ERROR": "\033[31m",  # 红色
        "CRITICAL": "\033[35m",  # 紫色
    }
    RESET = "\033[0m"

    def __init__(self, fmt: Optional[str] = None, datefmt: Optional[str] = None, style: str = "%"):
        super().__init__(fmt, datefmt, style)

    def format(self, record: logging.LogRecord) -> str:
        log_color = self.COLORS.get(record.levelname, "")
        record.levelname = f"{log_color}{record.levelname}{self.RESET}"
        record.msg = f"{log_color}{record.msg}{self.RESET}"
        return super().format(record)


def setup_logging(log_level: Optional[str] = None, log_format: Optional[str] = None) -> None:
    """
    根据配置设置日志系统

    Args:
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_format: 日志格式
    """
    config = get_config()

    # 使用传入参数或配置中的值
    level = getattr(logging, (log_level or config.log_level).upper())
    format_str = log_format or config.log_format

    # 获取根日志记录器
    root_logger = logging.getLogger()

    # 清除现有的处理器
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # 设置日志级别
    root_logger.setLevel(level)

    # 创建处理器
    console_handler = logging.StreamHandler(sys.stdout)

    # 设置格式化器
    if sys.stdout.isatty():  # 如果是终端输出，使用彩色格式
        formatter = ColoredFormatter(format_str)
    else:
        formatter = logging.Formatter(format_str)

    console_handler.setFormatter(formatter)
    console_handler.addFilter(SensitiveDataFilter())
    root_logger.addHandler(console_handler)


def get_logger(name: str, level: Optional[str] = None) -> logging.Logger:
    """
    获取配置好的日志记录器

    Args:
        name: 日志记录器名称
        level: 日志级别

    Returns:
        配置好的日志记录器
    """
    logger = logging.getLogger(name)
    config = get_config()
    logger.setLevel(getattr(logging, (level or config.log_level).upper()))
    return logger


class StructuredLogger:
    """
    结构化日志记录器
    """

    def __init__(self, name: str, level: Optional[str] = None):
        self.logger = get_logger(name, level)

    def info_structured(self, message: str, **kwargs: Any) -> None:
        """
        记录结构化信息日志

        Args:
            message: 日志消息
            **kwargs: 结构化数据
        """
        extra_info = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.info(f"{message} | {extra_info}" if extra_info else message)

    def debug_structured(self, message: str, **kwargs: Any) -> None:
        """
        记录结构化调试日志

        Args:
            message: 日志消息
            **kwargs: 结构化数据
        """
        extra_info = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.debug(f"{message} | {extra_info}" if extra_info else message)

    def warning_structured(self, message: str, **kwargs: Any) -> None:
        """
        记录结构化警告日志

        Args:
            message: 日志消息
            **kwargs: 结构化数据
        """
        extra_info = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.warning(f"{message} | {extra_info}" if extra_info else message)

    def error_structured(self, message: str, **kwargs: Any) -> None:
        """
        记录结构化错误日志

        Args:
            message: 日志消息
            **kwargs: 结构化数据
        """
        extra_info = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.error(f"{message} | {extra_info}" if extra_info else message)

    def critical_structured(self, message: str, **kwargs: Any) -> None:
        """
        记录结构化严重错误日志

        Args:
            message: 日志消息
            **kwargs: 结构化数据
        """
        extra_info = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.critical(f"{message} | {extra_info}" if extra_info else message)


def log_function_calls(sync: bool = True, async_: bool = True):
    """
    装饰器：记录函数调用

    Args:
        sync: 是否记录同步函数调用
        async_: 是否记录异步函数调用
    """

    def decorator(func):
        logger = get_logger(func.__module__)
        func_name = func.__name__

        if asyncio.iscoroutinefunction(func) or async_:
            # 异步函数处理
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                logger.debug(f"调用函数: {func_name}({', '.join(map(str, args[1:]))}, {kwargs})")

                try:
                    result = await func(*args, **kwargs)
                    elapsed_time = time.time() - start_time
                    logger.debug(f"函数 {func_name} 执行成功, 耗时: {elapsed_time:.2f}s")
                    return result
                except Exception as e:
                    elapsed_time = time.time() - start_time
                    logger.error(
                        f"函数 {func_name} 执行失败, 耗时: {elapsed_time:.2f}s, 错误: {str(e)}"
                    )
                    raise

            return async_wrapper
        elif sync:

            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.time()
                logger.debug(f"调用函数: {func_name}({', '.join(map(str, args[1:]))}, {kwargs})")

                try:
                    result = func(*args, **kwargs)
                    elapsed_time = time.time() - start_time
                    logger.debug(f"函数 {func_name} 执行成功, 耗时: {elapsed_time:.2f}s")
                    return result
                except Exception as e:
                    elapsed_time = time.time() - start_time
                    logger.error(
                        f"函数 {func_name} 执行失败, 耗时: {elapsed_time:.2f}s, 错误: {str(e)}"
                    )
                    raise

            return sync_wrapper
        else:
            return func

    return decorator


# 初始化日志系统
setup_logging()
