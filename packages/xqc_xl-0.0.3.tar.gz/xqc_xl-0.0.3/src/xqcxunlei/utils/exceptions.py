"""
Xunlei API 异常处理模块

定义项目专用的异常类，提供统一的错误处理机制
"""

from typing import Any, Dict, Optional

from ..config import (
    HTTP_STATUS_BAD_GATEWAY,
    HTTP_STATUS_FORBIDDEN,
    HTTP_STATUS_GATEWAY_TIMEOUT,
    HTTP_STATUS_INTERNAL_SERVER_ERROR,
    HTTP_STATUS_SERVICE_UNAVAILABLE,
    HTTP_STATUS_TOO_MANY_REQUESTS,
    HTTP_STATUS_UNAUTHORIZED,
    MAX_PATH_LENGTH,
)

__all__ = [
    # 异常类
    "XunleiError",
    "AuthenticationError",
    "TokenExpiredError",
    "LoginRequiredError",
    "NetworkError",
    "RequestTimeoutError",
    "RateLimitError",
    "ValidationError",
    "FileOperationError",
    "FileNotFoundError",
    "InsufficientStorageError",
    "QuotaExceededError",
    "ServiceUnavailableError",
    "BadRequestError",
    "PermissionDeniedError",
    "UnknownError",
    # 异常处理函数
    "handle_http_error",
    "validate_response",
    "validate_file_path",
    "validate_user_credentials",
    "validate_file_size",
]


class XunleiError(Exception):
    """迅雷 API 基础异常类"""

    def __init__(
        self, message: str, error_code: str | None = None, details: Dict[str, Any] | None = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}

    def __str__(self):
        if self.error_code:
            return f"[{self.error_code}] {self.message}"
        return self.message


class AuthenticationError(XunleiError):
    """认证相关异常"""

    def __init__(self, message: str = "认证失败", details: Dict[str, Any] | None = None):
        super().__init__(message, "AUTH_ERROR", details)


class TokenExpiredError(AuthenticationError):
    """Token 过期异常"""

    def __init__(self, message: str = "Token 已过期"):
        super().__init__(message, {"reason": "token_expired"})


class LoginRequiredError(AuthenticationError):
    """需要登录异常"""

    def __init__(self, message: str = "请先登录"):
        super().__init__(message, {"reason": "login_required"})


class NetworkError(XunleiError):
    """网络相关异常"""

    def __init__(self, message: str = "网络请求失败", details: Dict[str, Any] | None = None):
        super().__init__(message, "NETWORK_ERROR", details)


class RequestTimeoutError(NetworkError):
    """请求超时异常"""

    def __init__(self, timeout: int, message: Optional[str] = None):
        if message is None:
            message = f"请求超时 ({timeout}秒)"
        super().__init__(message, {"timeout": timeout, "reason": "request_timeout"})


class RateLimitError(XunleiError):
    """频率限制异常"""

    def __init__(
        self, message: str = "请求过于频繁，请稍后再试", details: Dict[str, Any] | None = None
    ):
        super().__init__(message, "RATE_LIMIT", details)


class ValidationError(XunleiError):
    """数据验证异常"""

    def __init__(
        self, message: str, field: Optional[str] = None, details: Dict[str, Any] | None = None
    ):
        details = details or {}
        if field:
            details["field"] = field
        super().__init__(message, "VALIDATION_ERROR", details)


class FileOperationError(XunleiError):
    """文件操作异常"""

    def __init__(self, message: str = "文件操作失败", details: Dict[str, Any] | None = None):
        super().__init__(message, "FILE_ERROR", details)


class FileNotFoundError(FileOperationError):
    """文件未找到异常"""

    def __init__(self, filepath: str):
        super().__init__(
            f"文件不存在: {filepath}", {"filepath": filepath, "reason": "file_not_found"}
        )


class InsufficientStorageError(XunleiError):
    """存储空间不足异常"""

    def __init__(self, message: str = "存储空间不足"):
        super().__init__(message, "INSUFFICIENT_STORAGE")


class QuotaExceededError(XunleiError):
    """配额超出异常"""

    def __init__(self, message: str = "操作配额已用完", details: Dict[str, Any] | None = None):
        super().__init__(message, "QUOTA_EXCEEDED", details)


class ServiceUnavailableError(XunleiError):
    """服务不可用异常"""

    def __init__(self, message: str = "服务暂时不可用", details: Dict[str, Any] | None = None):
        super().__init__(message, "SERVICE_UNAVAILABLE", details)


class BadRequestError(XunleiError):
    """请求错误异常"""

    def __init__(self, message: str = "请求参数错误", details: Dict[str, Any] | None = None):
        super().__init__(message, "BAD_REQUEST", details)


class PermissionDeniedError(XunleiError):
    """权限不足异常"""

    def __init__(self, message: str = "权限不足", details: Dict[str, Any] | None = None):
        super().__init__(message, "PERMISSION_DENIED", details)


class UnknownError(XunleiError):
    """未知错误异常"""

    def __init__(self, message: str = "发生未知错误", details: Dict[str, Any] | None = None):
        super().__init__(message, "UNKNOWN_ERROR", details)


# 异常映射字典，用于将 HTTP 状态码或其他错误映射到相应的异常类
EXCEPTION_MAPPING = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: FileNotFoundError,
    429: RateLimitError,
    500: ServiceUnavailableError,
    502: ServiceUnavailableError,
    503: ServiceUnavailableError,
    504: RequestTimeoutError,
}


def handle_http_error(
    status_code: int, response_text: str = "", details: Dict[str, Any] | None = None
) -> XunleiError:
    """
    根据 HTTP 状态码处理错误

    Args:
        status_code: HTTP 状态码
        response_text: 响应内容
        details: 附加详情

    Returns:
        对应的异常实例
    """
    details = details or {}
    details["status_code"] = status_code
    details["response_text"] = response_text

    exception_class = EXCEPTION_MAPPING.get(status_code, UnknownError)

    # 特定错误消息
    if status_code == HTTP_STATUS_UNAUTHORIZED:
        return AuthenticationError("认证失败，请检查用户名密码或Token", details)
    elif status_code == HTTP_STATUS_FORBIDDEN:
        return PermissionDeniedError("权限不足，无法执行此操作", details)
    elif status_code == HTTP_STATUS_TOO_MANY_REQUESTS:
        return RateLimitError("请求过于频繁，请稍后再试", details)
    elif status_code in [
        HTTP_STATUS_INTERNAL_SERVER_ERROR,
        HTTP_STATUS_BAD_GATEWAY,
        HTTP_STATUS_SERVICE_UNAVAILABLE,
        HTTP_STATUS_GATEWAY_TIMEOUT,
    ]:
        return ServiceUnavailableError(f"服务暂时不可用 (状态码: {status_code})", details)
    else:
        return exception_class(f"请求失败 (状态码: {status_code})", details)


def validate_response(
    response_data: Optional[Dict[str, Any]], required_fields: Optional[list] = None
) -> bool:
    """
    验证 API 响应数据

    Args:
        response_data: 响应数据
        required_fields: 必需字段列表

    Returns:
        验证是否通过
    """
    if response_data is None:
        raise ValidationError("响应数据为空")

    if required_fields:
        missing_fields = [field for field in required_fields if field not in response_data]
        if missing_fields:
            raise ValidationError(f"缺少必需字段: {', '.join(missing_fields)}", "required_fields")

    return True


def validate_file_path(file_path: str) -> None:
    """
    验证文件路径

    Args:
        file_path: 文件路径
    """

    if not file_path:
        raise ValidationError("文件路径不能为空", "file_path")

    if not isinstance(file_path, str):
        raise ValidationError("文件路径必须是字符串", "file_path")

    # 检查路径长度
    if len(file_path) > MAX_PATH_LENGTH:
        raise ValidationError("文件路径过长", "file_path")

    # 检查是否存在危险字符
    dangerous_chars = ["../", "..\\", "/..", "\\..", "../..", "..\\.."]
    if any(dc in file_path for dc in dangerous_chars):
        raise ValidationError("文件路径包含危险字符", "file_path")


def validate_user_credentials(username: str, password: str) -> None:
    """
    验证用户凭据

    Args:
        username: 用户名
        password: 密码
    """
    if not username:
        raise ValidationError("用户名不能为空", "username")

    if not password:
        raise ValidationError("密码不能为空", "password")

    if not isinstance(username, str):
        raise ValidationError("用户名必须是字符串", "username")

    if not isinstance(password, str):
        raise ValidationError("密码必须是字符串", "password")

    # 长度检查
    if len(username) < 1:
        raise ValidationError("用户名长度不能少于1个字符", "username")

    if len(password) < 1:
        raise ValidationError("密码长度不能少于1个字符", "password")


def validate_file_size(
    file_path: str, max_size: int = 10 * 1024 * 1024 * 1024
) -> None:  # 10GB default
    """
    验证文件大小

    Args:
        file_path: 文件路径
        max_size: 最大大小（字节）
    """
    import os

    if not os.path.exists(file_path):
        raise FileNotFoundError(file_path)

    file_size = os.path.getsize(file_path)
    if file_size > max_size:
        raise FileOperationError(f"文件过大: {file_size} 字节，超过最大限制 {max_size} 字节")
