"""
Xunlei API 交互反馈模块

提供用户友好的交互反馈功能:
- Spinner 转圈动画
- 进度显示
"""

from __future__ import annotations

import asyncio
import itertools
import sys
from typing import Callable


class Spinner:
    """控制台转圈动画，用于长时间任务的用户反馈"""

    def __init__(
        self,
        message: str = "处理中",
        frames: list[str] | None = None,
        interval: float = 0.1,
    ) -> None:
        """
        初始化 Spinner

        :param message: 显示的消息
        :param frames: 动画帧列表，默认使用Braille字符动画
        :param interval: 每帧间隔时间（秒）
        """
        self.message = message
        self.frames = frames or ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self.interval = interval
        self._running = False
        self._task: asyncio.Task | None = None

    async def _spin(self) -> None:
        """异步转圈任务"""
        for frame in itertools.cycle(self.frames):
            if not self._running:
                break
            sys.stdout.write(f"\r{frame} {self.message}...")
            sys.stdout.flush()
            await asyncio.sleep(self.interval)
        self._clear_line()

    def _clear_line(self) -> None:
        """清除当前行"""
        spaces = " " * (len(self.message) + len(self.frames[0]) + 5)
        sys.stdout.write(f"\r{spaces}\r")
        sys.stdout.flush()

    def start(self) -> None:
        """开始转圈动画"""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._spin())

    async def stop(self, success: bool = True, message: str | None = None) -> None:
        """
        停止转圈动画

        :param success: 是否成功
        :param message: 自定义消息，为 None 时使用默认消息
        """
        self._running = False
        if self._task:
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._clear_line()

        if success:
            symbol = "✓"
            default_msg = "完成"
        else:
            symbol = "✗"
            default_msg = "失败"

        final_msg = message or default_msg
        sys.stdout.write(f"\r{symbol} {final_msg}\n")
        sys.stdout.flush()

    async def __aenter__(self) -> "Spinner":
        """异步上下文管理器入口"""
        self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """异步上下文管理器退出"""
        if exc_type is not None:
            await self.stop(success=False, message=str(exc_val) if exc_val else "发生错误")
        else:
            await self.stop(success=True)


class ProgressTracker:
    """带消息的进度跟踪器"""

    def __init__(self, total: int, message: str = "处理中") -> None:
        """
        初始化进度跟踪器

        :param total: 总任务数
        :param message: 显示的消息
        """
        self.total = total
        self.current = 0
        self.message = message

    def update(self, increment: int = 1, custom_message: str | None = None) -> None:
        """
        更新进度

        :param increment: 增量，默认为 1
        :param custom_message: 自定义消息
        """
        self.current += increment
        percent = (self.current / self.total * 100) if self.total > 0 else 0
        msg = custom_message or self.message
        bar_width = 30
        filled = int(bar_width * self.current / self.total) if self.total > 0 else 0
        bar = "█" * filled + "░" * (bar_width - filled)
        sys.stdout.write(f"\r[{bar}] {percent:5.1f}% | {self.current}/{self.total} | {msg}")
        sys.stdout.flush()

    def finish(self, message: str | None = None) -> None:
        """完成进度条"""
        spaces = " " * 80
        sys.stdout.write(f"\r{spaces}\r")
        sys.stdout.flush()
        final_msg = message or f"完成 {self.total} 个任务"
        sys.stdout.write(f"✓ {final_msg}\n")
        sys.stdout.flush()


async def with_spinner(
    coro: Callable,
    message: str = "处理中",
    success_message: str | None = None,
    error_message: str | None = None,
) -> any:
    """
    使用 spinner 包装异步操作

    :param coro: 协程函数或可等待对象
    :param message: 进行中的消息
    :param success_message: 成功时的消息，为 None 时不显示
    :param error_message: 失败时的消息，为 None 时显示默认错误
    :return: 协程的返回值

    Examples:
        result = await with_spinner(xl.search("123"), message="正在搜索")
    """
    spinner = Spinner(message)
    spinner.start()
    try:
        if asyncio.iscoroutine(coro):
            result = await coro
        else:
            result = await coro
        await spinner.stop(success=True, message=success_message)
        return result
    except Exception as e:
        await spinner.stop(success=False, message=error_message or str(e))
        raise
