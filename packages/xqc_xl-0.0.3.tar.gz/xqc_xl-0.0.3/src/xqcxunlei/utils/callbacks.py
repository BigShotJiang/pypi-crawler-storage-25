"""
常用回调函数集合

提供便捷的回调函数用于文件批量操作，如重命名、搜索等。

分类：
- 匹配回调：用于过滤文件
- 名称回调：用于生成新名称
- 条件回调：用于复合条件组合

==================== 带前缀标识的回调函数 ====================
前缀标识说明:
  match_    - 匹配回调，返回 True/False 表示是否匹配
  replace_  - 替换回调，返回替换后的字符串
"""

from __future__ import annotations

import fnmatch
import re
from datetime import datetime
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Literal, Optional

# ==================== 字段常量定义 ====================
# 统一管理文件信息字典中的字段名，便于维护和扩展


class Field:
    """文件信息字段常量"""

    NAME = "name"
    PATH = "path"
    SIZE = "size"
    KIND = "kind"
    MIME_TYPE = "mime_type"
    ID = "id"
    PARENT_ID = "parent_id"
    CREATED_TIME = "created_time"
    MODIFIED_TIME = "modified_time"
    EXTENSION = "_ext"


FieldType = Literal[
    "name", "path", "size", "kind", "mime_type", "id", "parent_id", "created_time", "modified_time"
]


def get_field_value(file_info: dict[str, Any], field: str, default: Any = None) -> Any:
    """
    获取文件信息中指定字段的值

    Args:
        file_info: 文件信息字典
        field: 字段名或 Field 常量
        default: 默认值

    Returns:
        字段值，如果字段不存在则返回默认值
    """
    if field == Field.EXTENSION:
        name = file_info.get(Field.NAME, "")
        if "." in name:
            return name.rsplit(".", 1)[-1].lower()
        return ""

    if field == "_name_lower":
        return file_info.get(Field.NAME, "").lower()

    if field == "_path_lower":
        return file_info.get(Field.PATH, "").lower()

    return file_info.get(field, default)


def make_field_getter(
    field: str,
    default: Any = "",
    transform: Callable[[Any], Any] | None = None,
) -> Callable[[dict[str, Any]], Any]:
    """
    创建字段获取器

    Args:
        field: 字段名
        default: 默认值
        transform: 可选的转换函数

    Returns:
        字段获取函数
    """

    def getter(file_info: dict[str, Any]) -> Any:
        value = get_field_value(file_info, field, default)
        if transform:
            return transform(value)
        return value

    return getter


class FilterBuilder:
    """
    筛选器构建器

    支持链式调用来组合多个筛选条件

    Examples:
        >>> # 筛选文件名包含 "电影" 或 "视频" 的文件
        >>> fb = FilterBuilder()
        >>> fb.add_condition(field=Field.NAME, operator="contains", value="电影")
        >>> fb.add_condition(field=Field.NAME, operator="contains", value="视频", logic="or")
        >>> filter_func = fb.build()

        >>> # 组合使用
        >>> await xl.transfer_share(
        ...     link,
        ...     select_subfiles=FilterBuilder()
        ...         .add_condition(Field.PATH, "contains", "动作")
        ...         .add_condition(Field.SIZE, ">=", 1024*1024, logic="and")
        ...         .build()
        ... )
    """

    def __init__(self):
        self._conditions: list[dict[str, Any]] = []

    def add_condition(
        self,
        field: str,
        operator: str,
        value: Any,
        logic: str = "and",
    ) -> "FilterBuilder":
        """
        添加筛选条件

        Args:
            field: 字段名（支持 Field 常量或字符串）
            operator: 操作符，支持:
                - "contains": 包含（字符串）
                - "starts_with": 开头
                - "ends_with": 结尾
                - "equals": 等于
                - "matches": 匹配（支持 * 和 ? 通配符）
                - "regex": 正则匹配
                - "=": 等于
                - "!=": 不等于
                - ">": 大于
                - ">=": 大于等于
                - "<": 小于
                - "<=": 小于等于
            value: 比较值
            logic: 逻辑运算符，"and" 或 "or"

        Returns:
            self，支持链式调用
        """
        self._conditions.append(
            {
                "field": field,
                "operator": operator,
                "value": value,
                "logic": logic,
            }
        )
        return self

    def add_name_condition(self, operator: str, value: Any, logic: str = "and") -> "FilterBuilder":
        """快捷方法：添加名称字段条件"""
        return self.add_condition(Field.NAME, operator, value, logic)

    def add_path_condition(self, operator: str, value: Any, logic: str = "and") -> "FilterBuilder":
        """快捷方法：添加路径字段条件"""
        return self.add_condition(Field.PATH, operator, value, logic)

    def add_size_condition(self, operator: str, value: Any, logic: str = "and") -> "FilterBuilder":
        """快捷方法：添加大小字段条件"""
        return self.add_condition(Field.SIZE, operator, value, logic)

    def _string_operator(self, op: str, field_value: Any, compare_value: Any) -> bool:
        """字符串比较操作"""
        fv, cv = str(field_value).lower(), str(compare_value).lower()
        if op == "contains":
            return cv in fv
        if op == "starts_with":
            return fv.startswith(cv)
        if op == "ends_with":
            return fv.endswith(cv)
        if op in ("equals", "="):
            return cv == fv
        if op == "matches":
            return fnmatch.fnmatch(fv, cv)
        if op == "regex":
            return bool(re.search(cv, fv))
        return False

    def _numeric_operator(self, op: str, field_value: Any, compare_value: Any) -> bool:
        """数值比较操作"""
        try:
            fv, cv = float(field_value), float(compare_value)
            if op in (">", "gt"):
                return fv > cv
            if op in (">=", "ge"):
                return fv >= cv
            if op in ("<", "lt"):
                return fv < cv
            if op in ("<=", "le"):
                return fv <= cv
        except (ValueError, TypeError):
            pass
        return False

    def _apply_operator(self, field_value: Any, operator: str, compare_value: Any) -> bool:
        """应用操作符进行比较"""
        if operator in ("contains", "starts_with", "ends_with", "equals"):
            return self._string_operator(operator, field_value, compare_value)
        if operator in (">", ">=", "<", "<=", "gt", "ge", "lt", "le"):
            return self._numeric_operator(operator, field_value, compare_value)
        if operator in ("=", "=="):
            return field_value == compare_value
        if operator == "!=":
            return field_value != compare_value
        if operator == "matches":
            return fnmatch.fnmatch(str(field_value), str(compare_value))
        if operator == "regex":
            return bool(re.search(str(compare_value), str(field_value)))
        return False

    def build(self) -> Callable[[dict[str, Any]], bool]:
        """
        构建筛选函数

        Returns:
            筛选函数
        """

        def filter_func(file_info: dict[str, Any]) -> bool:
            if not self._conditions:
                return True

            results: list[bool] = []
            for i, cond in enumerate(self._conditions):
                field_value = get_field_value(file_info, cond["field"], "")
                result = self._apply_operator(field_value, cond["operator"], cond["value"])
                results.append(result)

            final_result = results[0]
            for i, result in enumerate(results[1:], 1):
                logic = self._conditions[i]["logic"]
                if logic == "and":
                    final_result = final_result and result
                else:
                    final_result = final_result or result

            return final_result

        return filter_func


def make_filter(
    field: str = Field.NAME,
    operator: str = "contains",
    value: Any = "",
) -> Callable[[dict[str, Any]], bool]:
    """
    通用筛选器工厂函数

    支持灵活指定字段和操作符来创建筛选函数

    Args:
        field: 字段名，支持 Field 常量或字符串
        operator: 操作符，支持:
            - "contains": 包含（字符串）
            - "starts_with": 开头
            - "ends_with": 结尾
            - "equals": 等于
            - "matches": 匹配（支持 * 和 ? 通配符）
            - "regex": 正则匹配
            - ">": 大于
            - "<": 小于
            - ">=": 大于等于
            - "<=": 小于等于
        value: 比较值

    Returns:
        筛选函数

    Examples:
        >>> # 文件名包含 "高清"
        >>> make_filter(Field.NAME, "contains", "高清")
        >>> # 路径包含 "电影/动作"
        >>> make_filter(Field.PATH, "contains", "电影/动作")
        >>> # 大小大于 1MB
        >>> make_filter(Field.SIZE, ">", 1024*1024)
        >>> # 扩展名为 mp4
        >>> make_filter(Field.NAME, "ends_with", ".mp4")
    """
    builder = FilterBuilder()
    builder.add_condition(field, operator, value)
    return builder.build()


# ==================== 匹配回调函数类型别名 ====================
# 用于 rename, search 等函数的 old/callback 参数的类型
# 支持返回 bool 或 None，None 视为 False

MatchCallback = Callable[[dict[str, Any]], bool | None]


def match_name_contains(substr: str) -> MatchCallback:
    """
    匹配名称包含指定字符串的文件

    Args:
        substr: 要包含的字符串

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("旧字符"),
        ...     new=replace_with("新字符"),
        ...     path="/文档"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return substr in file_info.get("name", "")

    return matcher


def match_name_starts_with(prefix: str) -> MatchCallback:
    """
    匹配名称以指定字符串开头的文件

    Args:
        prefix: 名称前缀

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_starts_with("临时_"),
        ...     new=replace_with(""),
        ...     path="/"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return file_info.get("name", "").startswith(prefix)

    return matcher


def match_name_ends_with(suffix: str) -> MatchCallback:
    """
    匹配名称以指定字符串结尾的文件

    Args:
        suffix: 名称后缀

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_ends_with(".bak"),
        ...     new=replace_with(""),
        ...     path="/"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return file_info.get("name", "").endswith(suffix)

    return matcher


def match_name_exactly(name: str) -> MatchCallback:
    """
    匹配名称完全等于指定值的文件

    Args:
        name: 精确名称

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_exactly("旧文件名.txt"),
        ...     new=replace_with("新文件名.txt"),
        ...     path="/文档"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return file_info.get("name", "") == name

    return matcher


def match_extension_is(ext: str) -> MatchCallback:
    """
    匹配指定扩展名的文件

    Args:
        ext: 文件扩展名（可带或不带点）

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_extension_is(".txt"),
        ...     new=replace_with(".md"),
        ...     path="/"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        ext_to_check = ext if ext.startswith(".") else "." + ext
        return name.endswith(ext_to_check)

    return matcher


def match_extensions_are(*extensions: str) -> MatchCallback:
    """
    匹配指定扩展名列表中的文件

    Args:
        *extensions: 文件扩展名列表（可带或不带点）

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_extensions_are(".txt", ".md", ".doc"),
        ...     new=replace_with(".txt"),
        ...     path="/"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        for ext in extensions:
            ext_to_check = ext if ext.startswith(".") else "." + ext
            if name.endswith(ext_to_check):
                return True
        return False

    return matcher


def match_is_folder(file_info: dict[str, Any]) -> bool | None:
    """
    匹配目录

    Examples:
        >>> await xunlei.search(callback=match_is_folder)
    """
    return file_info.get("kind", "") == "drive#folder"


def match_is_file(file_info: dict[str, Any]) -> bool | None:
    """
    匹配文件（非目录）

    Examples:
        >>> await xunlei.search(callback=match_is_file)
    """
    return file_info.get("kind", "") != "drive#folder"


def match_size_greater_than(size: int) -> MatchCallback:
    """
    匹配文件大小大于指定字节数的文件

    Args:
        size: 大小阈值（字节）

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.search(
        ...     callback=match_size_greater_than(1024 * 1024),
        ...     is_folder=False
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return file_info.get("size", 0) > size

    return matcher


def match_size_less_than(size: int) -> MatchCallback:
    """
    匹配文件大小小于指定字节数的文件

    Args:
        size: 大小阈值（字节）

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.search(
        ...     callback=match_size_less_than(1024 * 1024),
        ...     is_folder=False
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return file_info.get("size", 0) < size

    return matcher


def match_size_between(min_size: int, max_size: int) -> MatchCallback:
    """
    匹配文件大小在指定范围内的文件

    Args:
        min_size: 最小大小（字节）
        max_size: 最大大小（字节）

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.search(
        ...     callback=match_size_between(1024, 1024 * 1024),
        ...     is_folder=False
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        size = file_info.get("size", 0)
        return min_size <= size <= max_size

    return matcher


def match_created_after(date: datetime | str) -> MatchCallback:
    """
    匹配创建时间晚于指定时间的文件

    Args:
        date: 日期时间或 ISO 格式字符串

    Returns:
        匹配回调函数

    Examples:
        >>> from datetime import datetime
        >>> await xunlei.search(
        ...     callback=match_created_after(datetime(2024, 1, 1))
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        created_str = file_info.get("created_time", "")
        if not created_str:
            return False
        try:
            created = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
            if isinstance(date, str):
                target = datetime.fromisoformat(date.replace("Z", "+00:00"))
            else:
                target = date
            return created > target
        except (ValueError, TypeError):
            return False

    return matcher


def match_created_before(date: datetime | str) -> MatchCallback:
    """
    匹配创建时间早于指定时间的文件

    Args:
        date: 日期时间或 ISO 格式字符串

    Returns:
        匹配回调函数

    Examples:
        >>> from datetime import datetime
        >>> await xunlei.search(
        ...     callback=match_created_before(datetime(2024, 1, 1))
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        created_str = file_info.get("created_time", "")
        if not created_str:
            return False
        try:
            created = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
            if isinstance(date, str):
                target = datetime.fromisoformat(date.replace("Z", "+00:00"))
            else:
                target = date
            return created < target
        except (ValueError, TypeError):
            return False

    return matcher


def match_modified_after(date: datetime | str) -> MatchCallback:
    """
    匹配修改时间晚于指定时间的文件

    Args:
        date: 日期时间或 ISO 格式字符串

    Returns:
        匹配回调函数

    Examples:
        >>> from datetime import datetime
        >>> await xunlei.search(
        ...     callback=match_modified_after(datetime(2024, 1, 1))
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        modified_str = file_info.get("modified_time", "")
        if not modified_str:
            return False
        try:
            modified = datetime.fromisoformat(modified_str.replace("Z", "+00:00"))
            if isinstance(date, str):
                target = datetime.fromisoformat(date.replace("Z", "+00:00"))
            else:
                target = date
            return modified > target
        except (ValueError, TypeError):
            return False

    return matcher


def match_modified_before(date: datetime | str) -> MatchCallback:
    """
    匹配修改时间早于指定时间的文件

    Args:
        date: 日期时间或 ISO 格式字符串

    Returns:
        匹配回调函数

    Examples:
        >>> from datetime import datetime
        >>> await xunlei.search(
        ...     callback=match_modified_before(datetime(2024, 1, 1))
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        modified_str = file_info.get("modified_time", "")
        if not modified_str:
            return False
        try:
            modified = datetime.fromisoformat(modified_str.replace("Z", "+00:00"))
            if isinstance(date, str):
                target = datetime.fromisoformat(date.replace("Z", "+00:00"))
            else:
                target = date
            return modified < target
        except (ValueError, TypeError):
            return False

    return matcher


def match_path_contains(substr: str) -> MatchCallback:
    """
    匹配完整路径包含指定字符串的文件

    Args:
        substr: 路径中要包含的字符串

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.search(callback=match_path_contains("电影"))
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return substr in file_info.get("path", "")

    return matcher


def match_is_backup(file_info: dict[str, Any]) -> bool | None:
    """
    匹配备份文件（以 ~ 或 .bak 结尾）

    Examples:
        >>> await xunlei.search(callback=match_is_backup)
    """
    name = file_info.get("name", "")
    return name.endswith("~") or name.endswith(".bak")


def match_is_hidden(file_info: dict[str, Any]) -> bool | None:
    """
    匹配隐藏文件（Unix 风格，以 . 开头）

    Examples:
        >>> await xunlei.search(callback=match_is_hidden)
    """
    name = file_info.get("name", "")
    return name.startswith(".") and "." in name[1:]


def match_combine(*callbacks: MatchCallback) -> MatchCallback:
    """
    组合多个回调函数（AND 逻辑）

    Args:
        *callbacks: 要组合的回调函数

    Returns:
        组合后的回调函数，所有条件都满足才返回 True

    Examples:
        >>> # 匹配大于1MB的txt文件
        >>> await xunlei.search(
        ...     callback=match_combine(
        ...         match_extension_is(".txt"),
        ...         match_size_greater_than(1024 * 1024)
        ...     )
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return all(cb(file_info) for cb in callbacks)

    return matcher


def match_any_of(*callbacks: MatchCallback) -> MatchCallback:
    """
    组合多个回调函数（OR 逻辑）

    Args:
        *callbacks: 要组合的回调函数

    Returns:
        组合后的回调函数，任一条件满足就返回 True

    Examples:
        >>> # 匹配txt或md文件
        >>> await xunlei.search(
        ...     callback=match_any_of(
        ...         match_extension_is(".txt"),
        ...         match_extension_is(".md")
        ...     )
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        return any(cb(file_info) for cb in callbacks)

    return matcher


def match_negate(callback: MatchCallback) -> MatchCallback:
    """
    取反回调函数的结果

    Args:
        callback: 要取反的回调函数

    Returns:
        取反后的回调函数

    Examples:
        >>> # 匹配非目录
        >>> await xunlei.search(callback=match_negate(match_is_folder))
    """

    def matcher(file_info: dict[str, Any]) -> bool | None:
        result = callback(file_info)
        return not result if result is not None else None

    return matcher


# ==================== 替换回调函数类型别名 ====================
# 用于 rename 等函数的 new 参数的类型

ReplaceCallback = Callable[[dict[str, Any]], str]


def replace_with(new_substr: str, old_substr: str | None = None) -> ReplaceCallback:
    """
    将名称中的指定字符串替换为新字符串

    Args:
        new_substr: 替换后的字符串
        old_substr: 要替换的字符串（可选，不指定时用于配合匹配回调）

    Returns:
        替换回调函数

    Examples:
        >>> # 替换文件名中的字符串
        >>> await xunlei.rename(
        ...     old=match_name_contains("旧字符"),
        ...     new=replace_with("新字符"),
        ...     path="/文档"
        ... )

        >>> # 直接替换指定字符串
        >>> await xunlei.rename(
        ...     old=lambda f: True,
        ...     new=replace_with("新名称", old_substr="旧名称"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if old_substr is not None:
            return name.replace(old_substr, new_substr)
        return name

    return renamer


def replace_add_prefix(prefix: str) -> ReplaceCallback:
    """
    为文件名添加前缀

    Args:
        prefix: 要添加的前缀

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("测试"),
        ...     new=replace_add_prefix("【正式】"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        return prefix + file_info.get("name", "")

    return renamer


def replace_add_suffix(suffix: str) -> ReplaceCallback:
    """
    为文件名添加后缀（在扩展名之前）

    Args:
        suffix: 要添加的后缀

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("图片"),
        ...     new=replace_add_suffix("_备份"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if "." in name:
            idx = name.rfind(".")
            return name[:idx] + suffix + name[idx:]
        return name + suffix

    return renamer


def replace_remove_prefix(prefix: str) -> ReplaceCallback:
    """
    移除文件名开头的前缀

    Args:
        prefix: 要移除的前缀

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_starts_with("【正式】"),
        ...     new=replace_remove_prefix("【正式】"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if name.startswith(prefix):
            return name[len(prefix) :]
        return name

    return renamer


def replace_remove_suffix(suffix: str) -> ReplaceCallback:
    """
    移除文件名结尾的后缀（在扩展名之前）

    Args:
        suffix: 要移除的后缀

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_ends_with("_备份"),
        ...     new=replace_remove_suffix("_备份"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if "." in name:
            idx = name.rfind(".")
            name_without_ext = name[:idx]
            ext = name[idx:]
            if name_without_ext.endswith(suffix):
                return name_without_ext[: -len(suffix)] + ext
        if name.endswith(suffix):
            return name[: -len(suffix)]
        return name

    return renamer


def replace_to_lowercase() -> ReplaceCallback:
    """
    将文件名转换为小写

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_extension_is(".TXT"),
        ...     new=replace_to_lowercase(),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        return file_info.get("name", "").lower()

    return renamer


def replace_to_uppercase() -> ReplaceCallback:
    """
    将文件名转换为大写

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("test"),
        ...     new=replace_to_uppercase(),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        return file_info.get("name", "").upper()

    return renamer


def replace_change_extension(new_ext: str) -> ReplaceCallback:
    """
    更改文件扩展名

    Args:
        new_ext: 新的扩展名（可带或不带点）

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_extension_is(".txt"),
        ...     new=replace_change_extension(".md"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if "." in name:
            idx = name.rfind(".")
            return name[:idx] + (new_ext if new_ext.startswith(".") else "." + new_ext)
        return name + (new_ext if new_ext.startswith(".") else "." + new_ext)

    return renamer


def replace_remove_extension() -> ReplaceCallback:
    """
    移除文件扩展名

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_extension_is(".bak"),
        ...     new=replace_remove_extension(),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if "." in name:
            idx = name.rfind(".")
            return name[:idx]
        return name

    return renamer


def replace_insert_at(position: int, text: str) -> ReplaceCallback:
    """
    在文件名指定位置插入文字

    Args:
        position: 插入位置（负数表示从末尾倒数）
        text: 要插入的文字

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("文件"),
        ...     new=replace_insert_at(0, "【】"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if position < 0:
            position = max(0, len(name) + position)
        else:
            position = min(position, len(name))
        return name[:position] + text + name[position:]

    return renamer


def replace_remove_matching(pattern: str, replacement: str = "") -> ReplaceCallback:
    """
    移除名称中匹配正则表达式的部分

    Args:
        pattern: 正则表达式模式
        replacement: 替换为的字符串（默认空字符串，即删除）

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_matches(r"\\[\\d+\\]"),
        ...     new=replace_remove_matching(r"\\[\\d+\\]"),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        return re.sub(pattern, replacement, name)

    return renamer


def replace_sequential(start: int = 1, padding: int = 0) -> ReplaceCallback:
    """
    生成顺序编号名称

    Args:
        start: 起始编号（默认 1）
        padding: 编号位数，不足时补零（默认 0 不补零）

    Returns:
        替换回调函数

    Examples:
        >>> # 为文件添加序号前缀
        >>> results = await xunlei.rename(
        ...     old=match_name_contains("文件"),
        ...     new=replace_sequential(padding=3),
        ...     path="/"
        ... )
    """
    counter = [start]

    def renamer(file_info: dict[str, Any]) -> str:
        nonlocal counter
        num = counter[0]
        counter[0] += 1
        if padding > 0:
            return str(num).zfill(padding)
        return str(num)

    return renamer


def replace_date_prefix(fmt: str | None = "%Y%m%d") -> ReplaceCallback:
    """
    添加日期前缀

    Args:
        fmt: 日期格式（默认 %Y%m%d），None 则使用当前 ISO 日期

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("文档"),
        ...     new=replace_date_prefix(),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        date_str = datetime.now().strftime(fmt) if fmt else datetime.now().date().isoformat()
        return date_str + "_" + file_info.get("name", "")

    return renamer


def replace_date_suffix(fmt: str | None = "%Y%m%d") -> ReplaceCallback:
    """
    添加日期后缀（在扩展名之前）

    Args:
        fmt: 日期格式（默认 %Y%m%d），None 则使用当前 ISO 日期

    Returns:
        替换回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_name_contains("文档"),
        ...     new=replace_date_suffix(),
        ...     path="/"
        ... )
    """

    def renamer(file_info: dict[str, Any]) -> str:
        date_str = datetime.now().strftime(fmt) if fmt else datetime.now().date().isoformat()
        name = file_info.get("name", "")
        if "." in name:
            idx = name.rfind(".")
            return name[:idx] + "_" + date_str + name[idx:]
        return name + "_" + date_str

    return renamer


def match_regex(pattern: str, flags: int = 0) -> MatchCallback:
    """
    正则表达式匹配

    Args:
        pattern: 正则表达式模式
        flags: 正则标志 (如 re.IGNORECASE)

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_regex(r"\\d+集"),
        ...     new=replace_regex(r"\\d+集", "第$&话"),
        ...     path="/"
        ... )
    """

    def matcher(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        return bool(re.search(pattern, name, flags))

    return matcher


def match_glob(pattern: str) -> MatchCallback:
    """
    Glob 通配符匹配

    Args:
        pattern: glob 模式 (如 "*.txt", "电影*")

    Returns:
        匹配回调函数

    Examples:
        >>> await xunlei.rename(
        ...     old=match_glob("*.txt"),
        ...     new=replace_template("{name}.md"),
        ...     path="/"
        ... )
    """
    import fnmatch

    def matcher(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        return fnmatch.fnmatch(name, pattern)

    return matcher


def replace_regex(pattern: str, replacement: str, flags: int = 0) -> ReplaceCallback:
    """
    正则表达式替换

    Args:
        pattern: 正则表达式模式
        replacement: 替换字符串 (支持捕获组 \\1, \\2 等)
        flags: 正则标志

    Returns:
        替换回调函数

    Examples:
        >>> # 将 "第X集" 替换为 "第X话"
        >>> await xunlei.rename(
        ...     old=match_regex(r"第\\d+集"),
        ...     new=replace_regex(r"第(\\d+)集", "第\\1话"),
        ...     path="/"
        ... )

        >>> # 移除名称中的数字
        >>> await xunlei.rename(
        ...     old=match_regex(r"\\d+"),
        ...     new=replace_regex(r"\\d+", ""),
        ...     path="/"
        ... )
    """

    def replacer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        return re.sub(pattern, replacement, name, flags=flags)

    return replacer


def replace_template(template: str) -> ReplaceCallback:
    """
    模板替换

    Args:
        template: 模板字符串，支持以下占位符:
                  {name} - 原文件名 (不含扩展名)
                  {ext} - 文件扩展名 (含点，如 ".txt")
                  {parent} - 父目录名称
                  {path} - 完整路径
                  {size} - 文件大小
                  {id} - 文件 ID
                  {kind} - 文件类型 (drive#folder/drive#file)

    Returns:
        替换回调函数

    Examples:
        >>> # 为文件名添加备份后缀
        >>> await xunlei.rename(
        ...     old=match_glob("*.txt"),
        ...     new=replace_template("{name}_备份{ext}"),
        ...     path="/"
        ... )

        >>> # 添加父目录名作为前缀
        >>> await xunlei.rename(
        ...     old=match_regex(r".+"),
        ...     new=replace_template("【{parent}】{name}{ext}"),
        ...     path="/"
        ... )

        >>> # 序号重命名
        >>> await xunlei.rename(
        ...     old=match_glob("*"),
        ...     new=replace_template("{name}_{size}{ext}"),
        ...     path="/"
        ... )
    """
    import os

    def replacer(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        path = file_info.get("path", "")

        name_without_ext, ext = os.path.splitext(name)
        parent_name = ""
        if path:
            parent_path = os.path.dirname(path)
            parent_name = (
                os.path.basename(parent_path) if parent_path and parent_path != "/" else ""
            )

        result = template
        result = result.replace("{name}", name_without_ext)
        result = result.replace("{ext}", ext)
        result = result.replace("{parent}", parent_name)
        result = result.replace("{path}", path)
        result = result.replace("{size}", str(file_info.get("size", 0)))
        result = result.replace("{id}", file_info.get("id", ""))
        result = result.replace("{kind}", file_info.get("kind", ""))

        return result

    return replacer


# ==================== 分享转存过滤器 ====================
# 以下函数用于 transfer_share 的 file_filter 参数

ShareFileFilter = Callable[[dict[str, Any]], bool]
"""
分享文件过滤器回调函数类型

Args:
    file_info: 分享文件信息，包含:
        - id: 文件ID (str)
        - name: 文件名 (str)
        - size: 文件大小字节 (int)
        - kind: 文件类型，如 "drive#file" 或 "drive#folder" (str)
        - mime_type: MIME类型，如 "image/jpeg" (str)
        - created_time: 创建时间 (str)
        - modified_time: 修改时间 (str)
        - parent_id: 父目录ID (str)

Returns:
    bool: True 表示转存该文件，False 表示跳过该文件
"""


def filter_only_files(file_info: dict[str, Any]) -> bool:
    """
    预置过滤器：只转存文件，跳过目录

    示例:
        >>> await xunlei.transfer_share(link, file_filter=filter_only_files)
    """
    return file_info.get("kind", "") != "drive#folder"


def filter_only_directories(file_info: dict[str, Any]) -> bool:
    """
    预置过滤器：只转存目录，跳过文件

    示例:
        >>> await xunlei.transfer_share(link, file_filter=filter_only_directories)
    """
    return file_info.get("kind", "") == "drive#folder"


def filter_by_extension(extensions: list[str]) -> ShareFileFilter:
    """
    预置过滤器工厂：按文件扩展名过滤

    Args:
        extensions: 扩展名列表，如 ["jpg", "png", "mp4"]（可带或不带点）

    示例:
        >>> # 只转存图片
        >>> filter_by_extension([".jpg", "png"])
        >>> # 只转存视频
        >>> filter_by_extension(["mp4", ".mkv"])
    """
    ext_set = {ext.lower().strip().lstrip(".") for ext in extensions}

    def filter_func(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        if "." not in name:
            return False
        ext = name.rsplit(".", 1)[-1].lower()
        return ext in ext_set

    return filter_func


def filter_by_size(min_size: int = 0, max_size: int | None = None) -> ShareFileFilter:
    """
    预置过滤器工厂：按文件大小过滤

    Args:
        min_size: 最小文件大小（字节），默认 0 表示不限制
        max_size: 最大文件大小（字节），默认 None 表示不限制

    示例:
        >>> # 只转存大于 1MB 的文件
        >>> filter_by_size(min_size=1024 * 1024)
        >>> # 只转存 100MB 到 1GB 之间的文件
        >>> filter_by_size(min_size=100 * 1024 * 1024, max_size=1024 * 1024 * 1024)
    """
    max_size_val = max_size

    def filter_func(file_info: dict[str, Any]) -> bool:
        size = int(file_info.get("size", 0) or 0)
        if size < min_size:
            return False
        if max_size_val is not None and size > max_size_val:
            return False
        return True

    return filter_func


def filter_by_name_pattern(pattern: str) -> ShareFileFilter:
    """
    预置过滤器工厂：按文件名模式匹配（支持通配符 * 和 ?）

    Args:
        pattern: 文件名模式，如 "*.jpg" 或 "test_*.mp4"

    示例:
        >>> # 只转存以 "新建" 开头的文件
        >>> filter_by_name_pattern("新建*")
        >>> # 只转存 .txt 文件
        >>> filter_by_name_pattern("*.txt")
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        return fnmatch.fnmatch(name, pattern)

    return filter_func


def filter_exclude_by_name_pattern(pattern: str) -> ShareFileFilter:
    """
    预置过滤器工厂：排除匹配文件名模式的文件

    Args:
        pattern: 要排除的文件名模式，如 "*.tmp" 或 "__MACOSX*"

    示例:
        >>> # 排除所有临时文件
        >>> filter_exclude_by_name_pattern("*.tmp")
        >>> # 排除 macOS 系统文件
        >>> filter_exclude_by_name_pattern("__MACOSX*")
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        name = file_info.get("name", "")
        return not fnmatch.fnmatch(name, pattern)

    return filter_func


def filter_combine(*filters: ShareFileFilter) -> ShareFileFilter:
    """
    预置过滤器工厂：组合多个过滤器（AND 逻辑）

    所有过滤器都返回 True 时才转存

    示例:
        >>> # 只转存大于 1MB 的图片文件
        >>> await xunlei.transfer_share(
        ...     link,
        ...     file_filter=filter_combine(
        ...         filter_only_files,
        ...         filter_by_extension(["jpg", "png"]),
        ...         filter_by_size(min_size=1024 * 1024)
        ...     )
        ... )
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        return all(f(file_info) for f in filters)

    return filter_func


def filter_any_of(*filters: ShareFileFilter) -> ShareFileFilter:
    """
    预置过滤器工厂：组合多个过滤器（OR 逻辑）

    任一过滤器返回 True 就转存

    示例:
        >>> # 只转存 .jpg 或 .png 文件
        >>> filter_any_of(
        ...     filter_by_extension([".jpg"]),
        ...     filter_by_extension([".png"])
        ... )
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        return any(f(file_info) for f in filters)

    return filter_func


def filter_negate(filter_func: ShareFileFilter) -> ShareFileFilter:
    """
    预置过滤器工厂：取反过滤器结果

    示例:
        >>> # 转存非目录（即只转存文件）
        >>> filter_negate(filter_only_directories)
    """

    def negated(file_info: dict[str, Any]) -> bool:
        return not filter_func(file_info)

    return negated


# ==================== 分享链接回调函数 ====================
# 用于 create_share_link, get_share_info, cancel_share_link 等函数的回调参数

ShareLinkCallback = Callable[[dict[str, Any]], Optional[dict[str, Any]]]


def share_link_callback_skip_failed(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：跳过失败的操作

    Args:
        result: 操作结果字典，应包含 success 字段

    Returns:
        None 表示跳过（失败的结果），原样返回（成功的结果）

    Examples:
        >>> await xunlei.create_share_link(
        ...     batch=items,
        ...     callback=share_link_callback_skip_failed
        ... )
    """
    if not result.get("success", False):
        return None
    return result


def share_link_callback_only_existing(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：只保留已存在的分享链接

    Args:
        result: 操作结果字典，应包含 newly_created 字段

    Returns:
        None 表示跳过（新创建的），原样返回（已存在的）

    Examples:
        >>> await xunlei.create_share_link(
        ...     batch=items,
        ...     callback=share_link_callback_only_existing
        ... )
    """
    if result.get("newly_created", False):
        return None
    return result


def share_link_callback_only_new(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：只保留新创建的分享链接

    Args:
        result: 操作结果字典，应包含 newly_created 字段

    Returns:
        None 表示跳过（已存在的），原样返回（新创建的）

    Examples:
        >>> await xunlei.create_share_link(
        ...     batch=items,
        ...     callback=share_link_callback_only_new
        ... )
    """
    if not result.get("newly_created", False):
        return None
    return result


def share_link_callback_only_shared(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：只保留已分享的文件（has_share=True）

    Args:
        result: 查询结果字典，应包含 has_share 字段

    Returns:
        None 表示跳过（未分享的），原样返回（已分享的）

    Examples:
        >>> await xunlei.get_share_info(
        ...     targets=items,
        ...     callback=share_link_callback_only_shared
        ... )
    """
    if not result.get("has_share", False):
        return None
    return result


def share_link_callback_with_passcode_only(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：只保留有提取码的分享链接

    Args:
        result: 操作结果字典，应包含 pass_code 字段

    Returns:
        None 表示跳过（无提取码的），原样返回（有提取码的）

    Examples:
        >>> await xunlei.get_share_info(
        ...     targets=items,
        ...     callback=share_link_callback_with_passcode_only
        ... )
    """
    pass_code = result.get("pass_code", "")
    if not pass_code:
        return None
    return result


def share_link_callback_format_markdown(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：将结果格式化为 Markdown 表格行

    Args:
        result: 操作结果字典

    Returns:
        格式化后的字典，包含 markdown 字段

    Examples:
        >>> await xunlei.get_share_info(
        ...     targets=items,
        ...     callback=share_link_callback_format_markdown
        ... )
    """
    return {
        **result,
        "markdown": (
            f"| {result.get('file_name', '')} | {result.get('share_link', '')} "
            f"| {result.get('pass_code', 'N/A')} | {result.get('message', '')} |"
        ),
    }


def share_link_callback_cancel_failed(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：取消分享链接时跳过失败的操作

    Args:
        result: 操作结果字典，应包含 success 字段

    Returns:
        None 表示跳过（失败的结果），原样返回（成功的结果）

    Examples:
        >>> await xunlei.cancel_share_link(
        ...     batch=items,
        ...     callback=share_link_callback_cancel_failed
        ... )
    """
    if not result.get("success", False):
        return None
    return result


def share_link_callback_only_valid(result: dict[str, Any]) -> Optional[dict[str, Any]]:
    """
    预设回调函数：只保留有效的分享链接（is_valid=True）

    Args:
        result: 查询结果字典，应包含 is_valid 字段

    Returns:
        None 表示跳过（无效的），原样返回（有效的）

    Examples:
        >>> await xunlei.get_share_info(
        ...     targets=items,
        ...     callback=share_link_callback_only_valid
        ... )
    """
    if not result.get("is_valid", True):
        return None
    return result


# ==================== 分享链接过滤回调函数 ====================
# 用于 get_share_info, export_share_links 等函数的 filter_callback 参数

ShareFilterCallback = Callable[[dict[str, Any]], bool]


def filter_share_is_valid(share_info: dict[str, Any]) -> bool:
    """
    过滤回调：只保留有效的分享链接

    Args:
        share_info: 分享信息字典，应包含 is_valid 字段

    Returns:
        True 保留，False 过滤掉

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_is_valid
        ... )
    """
    return share_info.get("is_valid", False)


def filter_share_is_invalid(share_info: dict[str, Any]) -> bool:
    """
    过滤回调：只保留无效的分享链接

    Args:
        share_info: 分享信息字典，应包含 is_valid 字段

    Returns:
        True 保留，False 过滤掉

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_is_invalid
        ... )
    """
    return not share_info.get("is_valid", True)


def filter_share_has_passcode(share_info: dict[str, Any]) -> bool:
    """
    过滤回调：只保留有提取码的分享链接

    Args:
        share_info: 分享信息字典，应包含 pass_code 字段

    Returns:
        True 保留，False 过滤掉

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_has_passcode
        ... )
    """
    return bool(share_info.get("pass_code", ""))


def filter_share_no_passcode(share_info: dict[str, Any]) -> bool:
    """
    过滤回调：只保留没有提取码的分享链接

    Args:
        share_info: 分享信息字典，应包含 pass_code 字段

    Returns:
        True 保留，False 过滤掉

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_no_passcode
        ... )
    """
    return not bool(share_info.get("pass_code", ""))


def filter_share_name_contains(substr: str) -> ShareFilterCallback:
    """
    过滤回调：只保留文件名包含指定字符串的分享链接

    Args:
        substr: 要包含的字符串

    Returns:
        过滤回调函数

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_name_contains("电影")
        ... )
    """

    def filter_func(share_info: dict[str, Any]) -> bool:
        return substr in share_info.get("file_name", "")

    return filter_func


def filter_share_name_matches(pattern: str) -> ShareFilterCallback:
    """
    过滤回调：只保留文件名匹配指定模式的分享链接

    Args:
        pattern: 文件名模式（支持通配符 * 和 ?）

    Returns:
        过滤回调函数

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_name_matches("*.mp4")
        ... )
    """

    def filter_func(share_info: dict[str, Any]) -> bool:
        name = share_info.get("file_name", "")
        return fnmatch.fnmatch(name, pattern)

    return filter_func


def filter_share_remaining_count_greater_than(count: int) -> ShareFilterCallback:
    """
    过滤回调：只保留剩余提取次数大于指定值的分享链接

    Args:
        count: 最小剩余次数

    Returns:
        过滤回调函数

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_remaining_count_greater_than(5)
        ... )
    """

    def filter_func(share_info: dict[str, Any]) -> bool:
        remaining = share_info.get("remaining_count", -1)
        return remaining > count or remaining == -1

    return filter_func


def filter_share_combine(*filters: ShareFilterCallback) -> ShareFilterCallback:
    """
    组合多个过滤回调（AND 逻辑）

    Args:
        *filters: 要组合的过滤回调函数

    Returns:
        组合后的过滤回调函数，所有条件都满足才返回 True

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_combine(
        ...         filter_share_is_valid,
        ...         filter_share_has_passcode
        ...     )
        ... )
    """

    def filter_func(share_info: dict[str, Any]) -> bool:
        return all(f(share_info) for f in filters)

    return filter_func


# ==================== 文件筛选器函数 ====================
# 用于 transfer_share 等函数的 select_files/select_subfiles 参数

FileFilterFunc = Callable[[dict[str, Any]], bool]


def path_contains_filter(keywords: list[str]) -> FileFilterFunc:
    """
    路径包含关键词筛选器（用于 transfer_share 的 select_subfiles 参数）

    筛选完整路径中包含指定关键词的文件。
    重要：此筛选器检查的是文件的完整路径（path 字段），而不是文件名（name 字段）。
    这在需要按路径中的目录名筛选文件时非常有用。

    Args:
        keywords: 关键词列表，例如 ["动作", "高清"]

    Returns:
        筛选函数，返回 True 表示保留该文件

    Examples:
        >>> # 转存路径包含 "动作" 关键词的文件
        >>> await xl.transfer_share(
        ...     link,
        ...     "/目标目录",
        ...     select_subfiles=path_contains_filter(["动作"])
        ... )

        >>> # 转存路径包含 "高清" 或 "1080p" 的文件
        >>> await xl.transfer_share(
        ...     link,
        ...     "/目标目录",
        ...     select_subfiles=path_contains_filter(["高清", "1080p"])
        ... )
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        path = file_info.get("path", "").lower()
        return any(kw.lower() in path for kw in keywords)

    return filter_func


def name_contains_filter(
    keywords: list[str],
    match_field: str = Field.NAME,
) -> FileFilterFunc:
    """
    文件名字段包含关键词筛选器

    可指定匹配字段，默认为 name（文件名），也可指定为 path（完整路径）

    Args:
        keywords: 关键词列表，例如 ["高清", "1080p"]
        match_field: 要匹配的字段，支持 Field.NAME（文件名）或 Field.PATH（完整路径）

    Returns:
        筛选函数，返回 True 表示保留该文件

    Examples:
        >>> # 匹配文件名包含 "高清"
        >>> name_contains_filter(["高清"])
        >>> # 匹配完整路径包含 "电影"（等同于 path_contains_filter）
        >>> name_contains_filter(["电影"], match_field=Field.PATH)
    """
    if match_field == Field.PATH:
        return path_contains_filter(keywords)

    def filter_func(file_info: dict[str, Any]) -> bool:
        name = file_info.get(Field.NAME, "").lower()
        return any(kw.lower() in name for kw in keywords)

    return filter_func


def name_excludes_filter(
    keywords: list[str],
    match_field: str = Field.NAME,
) -> FileFilterFunc:
    """
    文件名字段不包含关键词筛选器

    可指定匹配字段，默认为 name（文件名），也可指定为 path（完整路径）

    Args:
        keywords: 排除的关键词列表，例如 ["预览", "sample"]
        match_field: 要匹配的字段，支持 Field.NAME（文件名）或 Field.PATH（完整路径）

    Returns:
        筛选函数，返回 True 表示保留该文件

    Examples:
        >>> # 排除文件名包含 "预览" 的文件
        >>> name_excludes_filter(["预览"])
        >>> # 排除完整路径包含 "预告片" 的文件
        >>> name_excludes_filter(["预告片"], match_field=Field.PATH)
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        if match_field == Field.PATH:
            target = file_info.get(Field.PATH, "").lower()
        else:
            target = file_info.get(Field.NAME, "").lower()
        return not any(kw.lower() in target for kw in keywords)

    return filter_func


def size_range_filter(min_size: int | None = None, max_size: int | None = None) -> FileFilterFunc:
    """
    文件大小范围筛选器

    使用 make_filter 统一实现

    Args:
        min_size: 最小文件大小（字节），None 表示不限制
        max_size: 最大文件大小（字节），None 表示不限制

    Returns:
        筛选函数，返回 True 表示保留该文件
    """

    def filter_func(file_info: dict[str, Any]) -> bool:
        size = int(file_info.get(Field.SIZE, 0) or 0)
        if min_size is not None and size < min_size:
            return False
        if max_size is not None and size > max_size:
            return False
        return True

    return filter_func


def extension_filter(extensions: list[str]) -> FileFilterFunc:
    """
    文件扩展名筛选器

    使用 make_filter 统一实现

    Args:
        extensions: 扩展名列表，例如 [".mp4", ".mkv"]

    Returns:
        筛选函数，返回 True 表示保留该文件
    """
    ext_set = {ext.lower().strip().lstrip(".") for ext in extensions}

    def filter_func(file_info: dict[str, Any]) -> bool:
        name = file_info.get(Field.NAME, "")
        if "." not in name:
            return False
        ext = name.rsplit(".", 1)[-1].lower()
        return ext in ext_set

    return filter_func


# ==================== 文件重命名回调函数 ====================
# 用于 rename, rename_subfiles 等参数

RenameFunc = Callable[[dict[str, Any]], str]


def add_prefix(prefix: str | list[str]) -> RenameFunc:
    """
    文件名添加前缀

    Args:
        prefix: 要添加的前缀（字符串或列表），例如 "【高清】" 或 ["【", "高清", "】"]

    Returns:
        重命名函数，接收文件信息 dict，返回新文件名
    """

    def rename_func(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if isinstance(prefix, list):
            return "".join(prefix) + name
        return prefix + name

    return rename_func


def add_suffix(suffix: str | list[str]) -> RenameFunc:
    """
    文件名添加后缀（在扩展名之前）

    Args:
        suffix: 要添加的后缀（字符串或列表），例如 "_高清" 或 ["_", "高", "清"]

    Returns:
        重命名函数，接收文件信息 dict，返回新文件名
    """

    def rename_func(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        suffix_str = "".join(suffix) if isinstance(suffix, list) else suffix
        if "." in name:
            parts = name.rsplit(".", 1)
            return parts[0] + suffix_str + "." + parts[1]
        return name + suffix_str

    return rename_func


def replace_text(
    old: str | list[str] | tuple[str, str] | list[tuple[str, str]],
    new: str | list[str] | None = None,
) -> RenameFunc:
    """
    文件名替换文本

    Args:
        old: 要替换的旧文本，支持:
             - str: 单个字符串
             - list[str]: 多个字符串，替换为同一个 new 值
             - tuple[str, str]: (old, new) 形式的单个替换
             - list[tuple[str, str]]: 多个 (old, new) 替换对
        new: 替换后的新文本，当 old 为 str 或 list[str] 时必须指定

    Returns:
        重命名函数，接收文件信息 dict，返回新文件名
    """

    def rename_func(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if isinstance(old, tuple) and new is None:
            name = name.replace(old[0], old[1])
        elif isinstance(old, list):
            if all(isinstance(o, tuple) for o in old):
                for o, n in old:
                    name = name.replace(o, n)
            else:
                for o in old:
                    name = name.replace(o, new if isinstance(new, str) else "")
        else:
            name = name.replace(old, new if isinstance(new, str) else "")
        return name

    return rename_func


def remove_text(text: str | list[str]) -> RenameFunc:
    """
    文件名移除指定文本

    Args:
        text: 要移除的文本（字符串或列表），例如 "[广告]" 或 ["[广告]", "[预告片]", "(1)"]

    Returns:
        重命名函数，接收文件信息 dict，返回新文件名
    """

    def rename_func(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        if isinstance(text, list):
            for t in text:
                name = name.replace(t, "")
        else:
            name = name.replace(text, "")
        return name

    return rename_func


def regex_replace(pattern: str, replacement: str) -> RenameFunc:
    """
    文件名正则替换

    Args:
        pattern: 正则表达式模式
        replacement: 替换文本，支持组引用如 r"\\1"

    Returns:
        重命名函数，接收文件信息 dict，返回新文件名
    """

    def rename_func(file_info: dict[str, Any]) -> str:
        import re

        name = file_info.get("name", "")
        return re.sub(pattern, replacement, name)

    return rename_func


def add_resolution(resolution: str = "") -> RenameFunc:
    """
    文件名添加分辨率标识

    Args:
        resolution: 分辨率标识，如 "1080p"、"720p"、"4K"。
                   如果为空字符串，则根据文件信息中的大小自动判断。

    Returns:
        重命名函数，接收文件信息 dict，返回新文件名
    """

    def rename_func(file_info: dict[str, Any]) -> str:
        name = file_info.get("name", "")
        res = resolution
        if not res:
            size = file_info.get("size", 0) or 0
            if size > 10 * 1024 * 1024 * 1024:
                res = "4K"
            elif size > 3 * 1024 * 1024 * 1024:
                res = "1080p"
            elif size > 1 * 1024 * 1024 * 1024:
                res = "720p"
            else:
                res = "480p"
        if res not in name:
            if "." in name:
                parts = name.rsplit(".", 1)
                return parts[0] + "." + res + "." + parts[1]
        return name

    return rename_func


# ==================== 分享链接筛选器函数 ====================


def filter_share_any_of(*filters: ShareFilterCallback) -> ShareFilterCallback:
    """
    组合多个过滤回调（OR 逻辑）

    Args:
        *filters: 要组合的过滤回调函数

    Returns:
        组合后的过滤回调函数，任一条件满足就返回 True

    Examples:
        >>> await xunlei.export_share_links(
        ...     targets="/我的资源",
        ...     filter_callback=filter_share_any_of(
        ...         filter_share_name_contains("电影"),
        ...         filter_share_name_contains("音乐")
        ...     )
        ... )
    """

    def filter_func(share_info: dict[str, Any]) -> bool:
        return any(f(share_info) for f in filters)

    return filter_func


# ==================== 通知回调函数 ====================
# 用于各类操作的完成通知，支持 MagicPush 推送

if TYPE_CHECKING:
    from .magicpush import MagicPushNotifier


OperationNotifyCallback = Callable[[dict[str, Any]], Optional[dict[str, Any]]]
"""操作通知回调类型，接收操作结果字典，返回处理后的字典（用于链式处理）"""

PushNotifyCallback = Callable[[dict[str, Any]], Awaitable[None]]
"""推送通知回调类型，接收操作结果字典，发送通知后返回（不修改结果）"""


def make_push_notify_callback(
    notifier: "MagicPushNotifier",
    *,
    title_template: str | None = None,
    content_template: str | None = None,
    message_type: str = "text",
    on_success_only: bool = True,
) -> PushNotifyCallback:
    """
    创建推送通知回调函数

    将 MagicPush 通知器包装成回调函数，用于在操作完成时发送通知。

    Args:
        notifier: MagicPushNotifier 实例
        title_template: 标题模板，支持 {success}、{operation} 等占位符
        content_template: 内容模板，支持 {name}、{path}、{success}、{error} 等占位符
        message_type: 消息类型，可选 text/markdown/html
        on_success_only: 是否仅在成功时发送通知

    Returns:
        推送通知回调函数

    Examples:
        >>> # 基础用法
        >>> notifier = MagicPushNotifier(token="your_token")
        >>> callback = make_push_notify_callback(notifier)
        >>> await xunlei.create_share_link(batch=files, callback=callback)

        >>> # 自定义消息
        >>> callback = make_push_notify_callback(
        ...     notifier,
        ...     title_template="分享链接创建{success}",
        ...     content_template="文件: {name}\\n状态: {success_text}",
        ... )

        >>> # Markdown 格式
        >>> callback = make_push_notify_callback(
        ...     notifier,
        ...     message_type="markdown",
        ...     content_template="**{name}**\\n\\n- 状态: {success_text}\\n- 路径: {path}"
        ... )
    """

    async def notify_callback(result: dict[str, Any]) -> None:
        success = result.get("success", False)

        if on_success_only and not success:
            return

        title = "操作完成"
        if title_template:
            success_text = "成功" if success else "失败"
            title = title_template.format(
                success=success_text,
                success_text=success_text,
                operation=result.get("operation", "未知操作"),
            )

        content = str(result)
        if content_template:
            success_text = "成功" if success else "失败"
            error_msg = result.get("error", result.get("message", ""))
            name = result.get("name", result.get("file_name", ""))
            path = result.get("path", "")
            content = content_template.format(
                name=name,
                path=path,
                success=success,
                success_text=success_text,
                error=error_msg,
                **result,
            )

        msg_type = message_type.lower()
        if msg_type == "markdown":
            await notifier.send_markdown(content, title)
        elif msg_type == "html":
            await notifier.send_html(content, title)
        else:
            await notifier.send_text(content, title)

    return notify_callback


def make_operation_notify_callback(
    notify_callback: PushNotifyCallback,
) -> OperationNotifyCallback:
    """
    将推送通知回调包装成操作回调（保持结果传递）

    用于需要在发送通知的同时保持结果链式传递的场景。

    Args:
        notify_callback: 推送通知回调函数

    Returns:
        操作通知回调函数

    Examples:
        >>> notifier = MagicPushNotifier(token="your_token")
        >>> push_cb = make_push_notify_callback(notifier)
        >>> op_cb = make_operation_notify_callback(push_cb)
        >>> await xunlei.create_share_link(batch=files, callback=op_cb)
    """

    async def wrapper(result: dict[str, Any]) -> dict[str, Any]:
        await notify_callback(result)
        return result

    return wrapper


def notify_on_success(notifier: "MagicPushNotifier", **kwargs) -> PushNotifyCallback:
    """
    创建仅在成功时发送通知的回调（快捷函数）

    Examples:
        >>> notifier = MagicPushNotifier(token="your_token")
        >>> callback = notify_on_success(notifier)
        >>> await xunlei.create_share_link(batch=files, callback=callback)
    """
    return make_push_notify_callback(notifier, on_success_only=True, **kwargs)


def notify_always(notifier: "MagicPushNotifier", **kwargs) -> PushNotifyCallback:
    """
    创建无论成功失败都发送通知的回调（快捷函数）

    Examples:
        >>> notifier = MagicPushNotifier(token="your_token")
        >>> callback = notify_always(notifier)
        >>> await xunlei.create_share_link(batch=files, callback=callback)
    """
    return make_push_notify_callback(notifier, on_success_only=False, **kwargs)
