"""
Xunlei API 上下文管理器模块

提供便捷的上下文管理器功能，使用 contextlib 装饰器简化代码
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator, Generator
from contextlib import asynccontextmanager, contextmanager
from typing import TYPE_CHECKING, Any, Coroutine

if TYPE_CHECKING:
    from .. import Xunlei
    from ..api.cloud_disk import XunleiCloudDisk
    from ..api.remote_downloader import XunleiRemoteDownloader


@asynccontextmanager
async def xunlei_client(
    username: str,
    password: str,
    cache_dir: str | None = None,
) -> AsyncGenerator[Xunlei, None]:
    """
    Xunlei 客户端的异步上下文管理器

    使用示例:
        async with xunlei_client("username", "password") as client:
            files = await client.cloud.get_files()
            print(files)
    """
    from .. import Xunlei

    client = Xunlei(
        username=username,
        password=password,
        cache_dir=cache_dir,
    )
    try:
        await client.open()
        yield client
    finally:
        await client.close()


@asynccontextmanager
async def xunlei_cloud_disk(
    username: str,
    password: str,
    cache_dir: str | None = None,
) -> AsyncGenerator[XunleiCloudDisk, None]:
    """
    Xunlei 云盘的异步上下文管理器

    使用示例:
        async with xunlei_cloud_disk("username", "password") as cloud:
            files = await cloud.get_files()
            print(files)
    """
    from .. import Xunlei

    client = Xunlei(
        username=username,
        password=password,
        cache_dir=cache_dir,
    )
    try:
        await client.open()
        yield client.cloud
    finally:
        await client.close()


@asynccontextmanager
async def xunlei_remote_downloader(
    username: str,
    password: str,
    cache_dir: str | None = None,
) -> AsyncGenerator[XunleiRemoteDownloader, None]:
    """
    Xunlei 远程下载的异步上下文管理器

    使用示例:
        async with xunlei_remote_downloader("username", "password") as remote:
            devices = await remote.get_devices()
            print(devices)
    """
    from .. import Xunlei

    client = Xunlei(
        username=username,
        password=password,
        cache_dir=cache_dir,
    )
    try:
        await client.open()
        yield client.remote
    finally:
        await client.close()


@contextmanager
def temporary_config_change(obj: object, **changes) -> Generator[object, None, None]:
    """
    临时修改对象配置的上下文管理器

    使用示例:
        with temporary_config_change(client.config, log_level="DEBUG"):
            await client.some_operation()
        # 配置会自动恢复
    """
    original_values = {}
    for attr, new_value in changes.items():
        if hasattr(obj, attr):
            original_values[attr] = getattr(obj, attr)
            setattr(obj, attr, new_value)
        else:
            setattr(obj, attr, new_value)
            original_values[attr] = "__DELETE__"

    try:
        yield obj
    finally:
        for attr, original_value in original_values.items():
            if original_value == "__DELETE__":
                if hasattr(obj, attr):
                    delattr(obj, attr)
            else:
                setattr(obj, attr, original_value)


async def batch_operations(
    operations: list[Coroutine[Any, Any, Any]],
    max_concurrent: int = 5,
) -> list[Any]:
    """
    批量执行异步操作，限制并发数

    Args:
        operations: 异步操作列表
        max_concurrent: 最大并发数

    Returns:
        操作结果列表
    """
    semaphore = asyncio.Semaphore(max_concurrent)

    async def bounded_operation(op: Coroutine[Any, Any, Any]) -> Any:
        async with semaphore:
            return await op

    tasks = [bounded_operation(op) for op in operations]
    return await asyncio.gather(*tasks)
