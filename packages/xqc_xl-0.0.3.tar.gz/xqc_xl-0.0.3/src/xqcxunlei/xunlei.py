"""
Xunlei API 统一客户端

提供云盘和远程下载的统一接口
"""

from __future__ import annotations

import asyncio
import os
from typing import Any, Callable, Optional

from .api import (
    CacheStrategy,
    CapacityExceededStrategy,
    CloudFileExistsStrategy,
    ConcurrencyAdjustmentStrategy,
    ConsoleProgressTracker,
    Downloader,
    DownloadProgress,
    DownloadResult,
    ExportFormat,
    FailureStrategy,
    FileFilterFunc,
    RemoteDownloadConflictStrategy,
    ShareAfterTransferStrategy,
    ShareDownloadOptions,
    ShareLinkStrategy,
    ShareTransferResult,
    TransferOwnShareStrategy,
    UploadAdvancedOptions,
    UploadDirResult,
    Uploader,
    UploadOptions,
    UploadProgress,
    UploadResult,
    XunleiCloudDisk,
    XunleiRemoteDownloader,
)
from .config.constants import DEFAULT_CACHE_DIR, DEFAULT_CACHE_TTL
from .utils import format_bytes, get_logger

logger = get_logger(__name__)


class Xunlei:
    """
    迅雷 API 统一客户端

    提供云盘和远程下载的统一接口
    """

    def __init__(
        self,
        username: str = "",
        password: str = "",
        cache_file: str | None = None,
        cache_dir: str | None = None,
        auto_save: bool = True,
        config_file: str | None = None,
        enable_logging: bool = True,
        log_level: str | None = None,
    ) -> None:
        """
        初始化客户端

        Args:
            username: 迅雷用户名 (优先级: 参数 > 环境变量)
            password: 迅雷密码 (优先级: 参数 > 环境变量)
            cache_file: Token 缓存文件路径
            cache_dir: Token 缓存目录 (如果未指定cache_file)
            auto_save: 是否自动保存 Token
            config_file: 配置文件路径 (.env 文件)
            enable_logging: 是否启用日志功能
            log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)，用于控制详细程度
        """
        # 初始化配置管理器
        from .config import ConfigManager

        self.config_manager = ConfigManager(config_file=config_file)
        self.config = self.config_manager.get_config()

        # 使用参数覆盖配置中的值 (参数优先级更高)
        self.username = username or self.config.username
        self.password = password or self.config.password

        # 设置缓存配置
        self.cache_file = cache_file or self.config.cache_file
        self.cache_dir = cache_dir or self.config.cache_dir
        self.auto_save = auto_save

        # 设置日志功能
        if enable_logging:
            import logging

            # 使用传入的log_level或配置中的值
            effective_log_level = log_level or self.config.log_level
            logging.basicConfig(level=getattr(logging, effective_log_level.upper()))

            # 控制httpx日志级别，避免过多的HTTP请求日志
            httpx_logger = logging.getLogger("httpx")
            httpx_logger.setLevel(
                logging.WARNING if effective_log_level.upper() != "DEBUG" else logging.DEBUG
            )

            # 同样处理其他可能产生冗余日志的库
            httpcore_logger = logging.getLogger("httpcore")
            httpcore_logger.setLevel(
                logging.WARNING if effective_log_level.upper() != "DEBUG" else logging.DEBUG
            )
        from .utils import get_logger

        self.logger = get_logger(__name__)

        # 云盘
        self._cloud: XunleiCloudDisk | None = None
        # 远程下载
        self._remote: XunleiRemoteDownloader | None = None
        # 上传器
        self._uploader: Uploader | None = None

    async def __aenter__(self) -> "Xunlei":
        await self.open()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    async def open(self) -> None:
        """打开客户端"""
        from .api import Uploader, XunleiCloudDisk, XunleiRemoteDownloader

        self._cloud = XunleiCloudDisk(
            self.username,
            self.password,
            self.cache_file,
            self.cache_dir,
            self.auto_save,
        )
        self._remote = XunleiRemoteDownloader(
            self.username,
            self.password,
            self.cache_file,
            self.cache_dir,
            self.auto_save,
        )
        await self._cloud.open()
        # 共享客户端实例
        self._remote._client = self._cloud._client

        # 初始化上传器
        self._uploader = Uploader(self._cloud)

        # 自动登录（如果尚未登录）
        if not self.is_login:
            await self.login()

    async def close(self) -> None:
        """关闭客户端"""
        if self._cloud:
            await self._cloud.close()
        if self._remote:
            await self._remote.close()

    @property
    def cloud(self) -> XunleiCloudDisk:
        """云盘 API"""
        if self._cloud is None:
            raise RuntimeError("Client not opened. Use 'async with' or call open()")
        return self._cloud

    @property
    def remote(self) -> XunleiRemoteDownloader:
        """远程下载 API"""
        if self._remote is None:
            raise RuntimeError("Client not opened. Use 'async with' or call open()")
        return self._remote

    @property
    def uploader(self) -> Uploader:
        """上传器 API"""
        if self._uploader is None:
            raise RuntimeError("Client not opened. Use 'async with' or call open()")
        return self._uploader

    # ==================== 远程下载核心接口 ====================
    # 注意：远程设备需先在 https://pan.xunlei.com/yc 开启远程下载功能
    # 开启方法：登录网页端/手机端app,我的-远程遥控下载/远程设备——开启
    # Windows：迅雷版本 > 11.4.1，登录相同账号后在设置中开启
    # NAS：登录 NAS 迅雷即可
    # ==================== ==================== ====================

    async def get_remote_devices(self, include_offline: bool = False) -> list[dict[str, Any]]:
        """
        获取远程下载设备列表

        Args:
            include_offline: 是否包含离线设备，默认 False

        Returns:
            设备列表:
            [
                {
                    "id": str,           # 任务ID
                    "name": str,        # 设备名称
                    "device_id": str,   # 设备唯一标识
                    "online": bool,     # 是否在线
                }
            ]
        """
        devices = await self.remote.get_devices()
        if not devices:
            return []
        if include_offline:
            return [{"online": True, **d} for d in devices]
        return [
            {"online": await self.remote.is_device_online(d.get("name", "")), **d} for d in devices
        ]

    async def get_remote_device(self, device_name: str | None = None) -> dict[str, Any] | None:
        """
        获取指定远程设备信息

        Args:
            device_name: 设备名称，None 时返回第一个在线设备

        Returns:
            设备信息字典，不存在时返回 None:
            {
                "id": str,           # 任务ID
                "name": str,        # 设备名称
                "device_id": str,   # 设备唯一标识
                "online": bool,     # 是否在线
            }
        """
        if device_name is None:
            devices = await self.get_remote_devices(include_offline=True)
            for d in devices:
                if d.get("online"):
                    return d
            return devices[0] if devices else None
        return await self.remote.get_device_info(device_name)

    async def get_remote_tasks(
        self,
        device_name: str | None = None,
        task_id: str | None = None,
        status_filter: str | None = None,
        return_raw: bool = False,
    ) -> list[dict[str, Any]]:
        """
        获取远程下载任务列表

        Args:
            device_name: 设备名称，None 时自动选择在线设备
            task_id: 任务ID，None 时返回所有任务
            status_filter: 状态过滤
              (PHASE_TYPE_RUNNING/PHASE_TYPE_PAUSED/PHASE_TYPE_COMPLETE)，None 时不过滤
            return_raw: 是否返回原始数据，默认 False

        Returns:
            return_raw=True 时返回 API 原始响应列表
            return_raw=False 时返回结构化结果:
            [
                {
                    "success": bool,
                    "task_id": str,
                    "file_id": str,
                    "file_name": str,
                    "file_size": int,
                    "status_size": int,
                    "phase": str,
                    "progress": int,
                    "created_time": str,
                    "updated_time": str,
                }
            ]
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return []
            device_name = device.get("name", "")

        if task_id:
            tasks = await self.remote.get_device_tasks(device_name, return_raw=True)
            if not tasks:
                return []
            task = next((t for t in tasks if t.get("id") == task_id), None)
            if not task:
                return []
            tasks = [task]
        else:
            tasks = await self.remote.get_device_tasks(device_name, return_raw=True)
            if not tasks:
                return []

        if status_filter:
            tasks = [t for t in tasks if t.get("phase") == status_filter]

        if return_raw:
            return tasks

        result = []
        for task in tasks:
            params = task.get("params", {}) or {}
            result.append(
                {
                    "success": True,
                    "task_id": task.get("id", ""),
                    "file_id": params.get("file_id", ""),
                    "file_name": task.get("name", ""),
                    "file_size": int(task.get("file_size", 0) or 0),
                    "status_size": int(task.get("status_size", 0) or 0),
                    "phase": task.get("phase", ""),
                    "progress": task.get("progress", 0),
                    "created_time": task.get("created_time", ""),
                    "updated_time": task.get("updated_time", ""),
                }
            )
        return result

    async def get_all_remote_tasks(self) -> dict[str, list[dict[str, Any]]]:
        """
        获取所有远程设备的下载任务

        Returns:
            {设备名称: 任务列表} 的字典
        """
        return await self.remote.get_all_tasks() or {}

    async def pause_remote_task(
        self,
        device_name: str | None = None,
        task_id: str | None = None,
    ) -> bool:
        """
        暂停远程下载任务

        Args:
            device_name: 设备名称，None 时自动选择在线设备
            task_id: 任务ID，None 时暂停所有任务

        Returns:
            是否成功
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return False
            device_name = device.get("name", "")
        return await self.remote.pause_task(device_name, task_id)

    async def resume_remote_task(
        self,
        device_name: str | None = None,
        task_id: str | None = None,
    ) -> bool:
        """
        恢复远程下载任务

        Args:
            device_name: 设备名称，None 时自动选择在线设备
            task_id: 任务ID，None 时恢复所有任务

        Returns:
            是否成功
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return False
            device_name = device.get("name", "")
        return await self.remote.resume_task(device_name, task_id)

    async def delete_remote_task(  # noqa: C901
        self,
        device_name: str | None = None,
        task_id: str | list[str] | None = None,
        task_name: str | list[str] | None = None,
        status: str | list[str] | None = None,
        delete_file: bool = False,
    ) -> dict[str, Any]:
        """
        删除远程下载任务（支持多种匹配条件）

        Args:
            device_name: 设备名称，None 时自动选择在线设备
            task_id: 任务ID，支持单个字符串或多个任务ID列表
                    例如 "task_id_1" 或 ["task_id_1", "task_id_2"]
            task_name: 任务名称，支持精确匹配、模糊匹配或列表
                    - 字符串：模糊匹配（包含该名称的任务）
                    - 列表：精确匹配列表中的每个名称
                    例如 "电影" 或 ["电影1.mp4", "电影2.mp4"]
            status: 任务状态，支持单个或多个状态
                    可选值: "running", "paused", "complete", "failed"
                    例如 "complete" 或 ["complete", "failed"]
            delete_file: 是否同时删除设备上的文件，默认 False（只删除任务）
                        True = 删除任务并删除设备上已下载的文件
                        False = 仅删除任务，保留文件

        Returns:
            操作结果:
            {
                "success": bool,           # 是否成功
                "deleted": int,            # 删除的任务数
                "failed": int,             # 删除失败的任务数
                "task_ids": list[str],     # 被删除的任务ID列表
                "message": str,            # 结果描述
            }

        Examples:
            # 删除指定任务ID
            await xl.delete_remote_task("设备名", task_id="xxx")

            # 删除多个指定任务ID
            await xl.delete_remote_task("设备名", task_id=["id1", "id2"])

            # 删除名称包含"电影"的所有任务
            await xl.delete_remote_task("设备名", task_name="电影")

            # 删除指定名称的任务
            await xl.delete_remote_task("设备名", task_name=["电影1.mp4", "电影2.mp4"])

            # 删除所有已完成任务
            await xl.delete_remote_task("设备名", status="complete")

            # 删除多个状态的任务
            await xl.delete_remote_task("设备名", status=["complete", "failed"])

            # 组合条件：删除已完成且名称包含"电影"的任务
            tasks = await xl.get_remote_tasks("设备名", status_filter="complete")
            for task in tasks:
                if "电影" in task.get("name", ""):
                    await xl.delete_remote_task("设备名", task_id=task.get("id"))
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "success": False,
                    "deleted": 0,
                    "failed": 0,
                    "task_ids": [],
                    "message": "未找到可用设备",
                }
            device_name = device.get("name", "")

        tasks = await self.get_remote_tasks(device_name, return_raw=True)
        if not tasks:
            return {
                "success": True,
                "deleted": 0,
                "failed": 0,
                "task_ids": [],
                "message": "没有任务",
            }

        matched_tasks = []

        for task in tasks:
            task_id_str = task.get("id", "")
            task_name_str = task.get("name", "")
            task_phase = task.get("phase", "")

            should_delete = False

            if task_id is not None:
                if isinstance(task_id, str):
                    if task_id_str == task_id:
                        should_delete = True
                elif isinstance(task_id, list):
                    if task_id_str in task_id:
                        should_delete = True

            if not should_delete and task_name is not None:
                if isinstance(task_name, str):
                    if task_name in task_name_str:
                        should_delete = True
                elif isinstance(task_name, list):
                    if task_name_str in task_name:
                        should_delete = True

            if not should_delete and status is not None:
                if isinstance(status, str):
                    if status.lower() in task_phase.lower():
                        should_delete = True
                elif isinstance(status, list):
                    for s in status:
                        if s.lower() in task_phase.lower():
                            should_delete = True
                            break

            if should_delete:
                matched_tasks.append(task)

        if not matched_tasks:
            return {
                "success": True,
                "deleted": 0,
                "failed": 0,
                "task_ids": [],
                "message": "没有匹配的任务",
            }

        deleted = 0
        failed = 0
        deleted_ids = []

        for task in matched_tasks:
            tid = task.get("id")
            if delete_file:
                success = await self.remote.delete_task(device_name, tid)
            else:
                success = await self.remote.delete_task_only(device_name, tid)

            if success:
                deleted += 1
                deleted_ids.append(tid)
            else:
                failed += 1

        return {
            "success": failed == 0,
            "deleted": deleted,
            "failed": failed,
            "task_ids": deleted_ids,
            "message": f"已删除 {deleted} 个任务，失败 {failed} 个",
        }

    async def clean_remote_completed_tasks(
        self,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """
        清理远程设备已完成的任务（便捷方法）

        Args:
            device_name: 设备名称，None 时自动选择

        Returns:
            操作结果:
            {
                "success": bool,      # 是否成功
                "deleted": int,       # 删除的任务数
                "failed": int,        # 删除失败的任务数
                "task_ids": list[str],  # 被删除的任务ID列表
                "message": str,       # 结果描述
            }
        """
        return await self.delete_remote_task(device_name=device_name, status="complete")

    async def get_magnet_files(
        self,
        url: str,
        file_types: list[str] | None = None,
        extensions: list[str] | None = None,
        filters: list[Callable[[dict[str, Any]], bool]] | None = None,
    ) -> list[dict[str, Any]] | None:
        """
        获取磁力链接的文件列表

        Args:
            url: 磁力链接
            file_types: 按文件类型筛选，支持 FileTypeFilter 枚举或 MIME 类型字符串列表
                       例如 [FileTypeFilter.VIDEO] 或 ["video/", "application/"]
                       也可传入多个类型如 [FileTypeFilter.VIDEO, FileTypeFilter.AUDIO]
            extensions: 按文件扩展名筛选，如 [".mp4", ".mkv"]（不区分大小写）
            filters: 自定义筛选函数列表，每个函数接收文件信息 dict，返回 True 保留文件
                    可使用预设函数:
                    - name_contains_filter(["高清", "1080p"]): 文件名包含关键词
                    - name_excludes_filter(["预览", "sample"]): 文件名不包含关键词
                    - size_range_filter(min_size, max_size): 文件大小范围
                    - extension_filter([".mp4", ".mkv"]): 指定扩展名

        Returns:
            文件列表，每个文件包含:
                - index: 文件索引（从 1 开始，下载时使用）
                - name: 文件名
                - size: 文件大小（字节）
                - size_human: 人类可读大小
                - mime_type: MIME 类型
            获取失败返回 None
        """
        return await self.remote.get_magnet_files(url, file_types, extensions, filters)

    async def add_remote_download(  # noqa: C901
        self,
        url: str,
        device_name: str | None = None,
        target_folder: str | None = None,
        rename: str | Callable[[dict[str, Any]], str] | None = None,
        select_files: list[int | str | Callable[[dict[str, Any]], bool]] | None = None,
        auto_create_folder: bool = True,
        on_exists: RemoteDownloadConflictStrategy = RemoteDownloadConflictStrategy.SKIP,
        return_raw: bool = False,
    ) -> dict[str, Any]:
        """
        添加远程下载任务（支持 HTTP/Magnet/BT/云盘资源）

        Args:
            url: 下载链接，支持以下格式:
                 - HTTP/HTTPS 直链
                 - Magnet 磁力链接
                 - BT 种子文件 (.torrent)
                 - 云盘资源路径（以 / 开头，如 "/电影/变形金刚.mp4"）
            device_name: 设备名称，None 时自动选择在线设备
            target_folder: 远程设备上的目标文件夹路径（相对于设备根目录）。
                          PC端的根目录是：设置——下载设置——下载目录 的路径
                          飞牛NAS的根目录是：应用文件——xunlei——downloads
                          例如 "/downloads" 或 "电影/2024"。
                          None 或 "/" 表示下载到设备根目录。
            rename: 下载后重命名，支持:
                    - str: 直接使用该字符串作为新文件名
                    - RenameFunc: 回调函数，接收文件信息 dict，返回新文件名
                    - None: 不重命名
                    预设回调函数:
                    - add_prefix(prefix): 添加前缀，支持列表如 add_prefix(["【", "高清", "】"])
                    - add_suffix(suffix): 添加后缀，支持列表如 add_suffix(["_", "720p"])
                    - replace_text(old, new): 替换文本，支持:
                       - 单个替换: replace_text("高清", "HD")
                       - 批量替换: replace_text(["高清", "标清"], ["HD", "4K"])
                       - 元组形式: replace_text(("高清", "HD"))
                    - remove_text(text): 移除文本，支持列表如
                      remove_text(["[广告]", "[预告片]", "(1)"])
                    - regex_replace(pattern, repl): 正则替换如 regex_replace(r"\\[\\d+\\]", "")
                    - add_resolution(): 自动添加分辨率标识
            select_files: BT/Magnet 下载时选择文件的方式，支持多种类型混用:
                         1. 索引列表: [1, 3, 5] 表示下载索引为 1、3、5 的文件
                         2. 文件类型: [FileTypeFilter.VIDEO] 或 ["video/"] 选择视频文件
                            多个类型时为并集（OR），如 [VIDEO, AUDIO] 表示视频或音频
                         3. 筛选函数: [name_contains_filter(["高清"])] 按条件筛选
                            多个筛选函数时为交集（AND），如
                            [name_contains_filter(["高清"]), size_range_filter(...)]
                            表示文件名包含"高清"且大小符合范围
                         支持混用，如 [FileTypeFilter.VIDEO, name_excludes_filter(["预览"])]
                         表示：视频文件 且 不包含"预览"
                         None 表示下载全部文件。
                         例如: select_files=[1, 3, 5] 或 select_files=[FileTypeFilter.VIDEO]
                              或 select_files=[FileTypeFilter.VIDEO, name_contains_filter(["高清"])]
            auto_create_folder: 当目标文件夹不存在时是否自动递归创建（默认 True）。
            conflict_strategy: 任务重名处理策略，默认 SKIP（跳过）:
                               - SKIP: 跳过已存在的任务（包括已完成的任务，不会重新下载）
                               - RECREATE: 删除旧任务（含已经下载的设备上的文件），重新创建
            return_raw: 是否返回原始 API 响应，默认 False

        Returns:
            return_raw=True 时返回 API 原始响应
            return_raw=False 时返回结构化结果:
            {
                "success": bool,
                "task_id": str,
                "file_id": str,
                "file_name": str,
                "file_size": int,
                "status_size": int,
                "phase": str,
                "progress": int,
                "created_time": str,
                "updated_time": str,
                "message": str,
            }
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "success": False,
                    "task_id": "",
                    "file_id": "",
                    "file_name": "",
                    "file_size": 0,
                    "status_size": 0,
                    "phase": "",
                    "progress": 0,
                    "created_time": "",
                    "updated_time": "",
                    "message": "未找到可用设备",
                }
            device_name = device.get("name", "")

        task_name = ""
        if url.startswith("/"):
            file_info = await self.cloud.get_file_info(url)
            if file_info:
                if callable(rename):
                    task_name = rename(file_info) or file_info.get("name", "")
                else:
                    task_name = rename if rename else file_info.get("name", "")
            else:
                task_name = rename if isinstance(rename, str) else ""
        else:
            if callable(rename):
                task_name = rename(
                    {"name": url.rsplit("/", 1)[-1] if not url.startswith("/") else ""}
                )
            else:
                task_name = rename or (url.rsplit("/", 1)[-1] if not url.startswith("/") else "")

        existing_tasks = await self.get_remote_tasks(device_name, return_raw=True)
        matched_task = next((t for t in existing_tasks if t.get("name", "") == task_name), None)
        if matched_task:
            if on_exists == RemoteDownloadConflictStrategy.SKIP:
                if return_raw:
                    return matched_task
                params = matched_task.get("params", {}) or {}
                return {
                    "success": True,
                    "task_id": matched_task.get("id", ""),
                    "file_id": params.get("file_id", ""),
                    "file_name": matched_task.get("name", ""),
                    "file_size": int(matched_task.get("file_size", 0) or 0),
                    "status_size": int(matched_task.get("status_size", 0) or 0),
                    "phase": matched_task.get("phase", ""),
                    "progress": matched_task.get("progress", 0),
                    "created_time": matched_task.get("created_time", ""),
                    "updated_time": matched_task.get("updated_time", ""),
                    "message": "任务已存在，已跳过",
                }
            if on_exists == RemoteDownloadConflictStrategy.RECREATE:
                await self.remote.delete_task(device_name, matched_task.get("id"))

        parent_folder_id = ""
        if auto_create_folder and target_folder and target_folder != "/":
            folder_result = await self.create_remote_folder(target_folder, device_name)
            if folder_result.get("success"):
                parent_folder_id = folder_result.get("folder_id", "")
            elif "已存在" not in folder_result.get("message", ""):
                pass

        if url.startswith("/"):
            file_info = await self.cloud.get_file_info(url)
            if not file_info:
                return {
                    "success": False,
                    "task_id": "",
                    "file_id": "",
                    "file_name": url.rsplit("/", 1)[-1],
                    "file_size": 0,
                    "status_size": 0,
                    "phase": "",
                    "progress": 0,
                    "created_time": "",
                    "updated_time": "",
                    "message": "云盘文件不存在",
                }

            if callable(rename):
                file_name_for_task = rename(file_info)
            else:
                file_name_for_task = rename if rename else file_info.get("name", "")
            devices = await self.remote.get_devices()
            if not devices:
                return {
                    "success": False,
                    "task_id": "",
                    "file_id": "",
                    "file_name": "",
                    "file_size": 0,
                    "status_size": 0,
                    "phase": "",
                    "progress": 0,
                    "created_time": "",
                    "updated_time": "",
                    "message": "未找到可用设备",
                }
            device = next((d for d in devices if d.get("name") == device_name), None)
            if not device:
                return {
                    "success": False,
                    "task_id": "",
                    "file_id": "",
                    "file_name": "",
                    "file_size": 0,
                    "status_size": 0,
                    "phase": "",
                    "progress": 0,
                    "created_time": "",
                    "updated_time": "",
                    "message": f"设备 {device_name} 不存在",
                }
            device_id = device.get("device_id", "")
            resp = await self.remote.post(
                self.remote.config.tasks_url.rstrip("s"),
                json={
                    "space": device_id,
                    "type": "user#download",
                    "file_name": file_name_for_task,
                    "file_size": str(file_info.get("size", 0) or 0),
                    "params": {
                        "target": device_id,
                        "file_id": file_info.get("id"),
                        "parent_folder_id": parent_folder_id,
                        "platform": "fnos_community",
                    },
                },
            )
            if return_raw:
                return resp if resp else {}
            if resp and resp.get("error"):
                return {
                    "success": False,
                    "task_id": "",
                    "file_id": file_info.get("id", ""),
                    "file_name": file_name_for_task,
                    "file_size": 0,
                    "status_size": 0,
                    "phase": "",
                    "progress": 0,
                    "created_time": "",
                    "updated_time": "",
                    "message": resp.get("error_description") or resp.get("error"),
                }
            tasks = await self.get_remote_tasks(device_name, return_raw=True)
            new_task = next((t for t in reversed(tasks) if t.get("name") == file_name_for_task), {})
            if return_raw:
                return new_task if new_task else resp
            return {
                "success": True,
                "task_id": new_task.get("id", "") if new_task else resp.get("task_id", ""),
                "file_id": file_info.get("id", ""),
                "file_name": file_name_for_task,
                "file_size": int(new_task.get("file_size", 0) or 0) if new_task else 0,
                "status_size": int(new_task.get("status_size", 0) or 0) if new_task else 0,
                "phase": new_task.get("phase", "") if new_task else "",
                "progress": new_task.get("progress", 0) if new_task else 0,
                "created_time": new_task.get("created_time", "") if new_task else "",
                "updated_time": new_task.get("updated_time", "") if new_task else "",
                "message": "已提交云盘下载任务",
            }

        if url.endswith(".torrent"):
            from .utils import parse_torrent

            url, _ = await parse_torrent(url)

        file_indices: list[int] | None = None
        resolved_rename: str | None = None
        if select_files:
            first_item = select_files[0]
            if isinstance(first_item, int):
                file_indices = select_files
            else:
                from .api import FileTypeFilter

                file_types: list[str] | None = None
                filter_funcs: list[FileFilterFunc] = []
                for item in select_files:
                    if isinstance(item, FileTypeFilter):
                        if not file_types:
                            file_types = []
                        file_types.append(item.value)
                    elif isinstance(item, str):
                        if not file_types:
                            file_types = []
                        file_types.append(item)
                    elif callable(item):
                        filter_funcs.append(item)
                files = await self.get_magnet_files(
                    url, file_types=file_types, filters=filter_funcs if filter_funcs else None
                )
                if files:
                    file_indices = [f["index"] for f in files]

                    if callable(rename):
                        resolved_rename = rename(files[0])
                    else:
                        resolved_rename = rename
                else:
                    resolved_rename = rename if isinstance(rename, str) else None
        else:
            resolved_rename = rename if isinstance(rename, str) else None

        result = await self.remote.create_download_task(
            url, device_name, target_folder, resolved_rename, parent_folder_id, file_indices
        )
        if not result:
            return {
                "success": False,
                "task_id": "",
                "file_id": "",
                "file_name": resolved_rename or "",
                "file_size": 0,
                "status_size": 0,
                "phase": "",
                "progress": 0,
                "created_time": "",
                "updated_time": "",
                "message": "创建下载任务失败",
            }
        if isinstance(result, dict) and result.get("error"):
            return {
                "success": False,
                "task_id": "",
                "file_id": "",
                "file_name": resolved_rename or "",
                "file_size": 0,
                "status_size": 0,
                "phase": "",
                "progress": 0,
                "created_time": "",
                "updated_time": "",
                "message": result.get("error_description") or result.get("error"),
            }

        tasks = await self.get_remote_tasks(device_name, return_raw=True)
        task = tasks[-1] if tasks else {}
        if return_raw:
            return task
        task_params = task.get("params", {}) or {}
        return {
            "success": True,
            "task_id": task.get("id", ""),
            "file_id": task_params.get("file_id", ""),
            "file_name": task.get("name", rename or ""),
            "file_size": int(task.get("file_size", 0) or 0),
            "status_size": int(task.get("status_size", 0) or 0),
            "phase": task.get("phase", ""),
            "progress": task.get("progress", 0),
            "created_time": task.get("created_time", ""),
            "updated_time": task.get("updated_time", ""),
            "message": "下载任务已创建",
        }

    async def set_remote_speed_limit(
        self,
        speed_mbps: float = -1,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """
        设置远程设备下载速度限制

        Args:
            speed_mbps: 速度限制 (Mbps)，-1 表示不限速，有效范围 0.06-131.3
            device_name: 设备名称，None 时自动选择在线设备

        Returns:
            操作结果:
            {
                "success": bool,           # 是否成功
                "speed_limit": float,      # 设置的速度限制
                "device_name": str,        # 设备名称
                "message": str,            # 结果描述
            }
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "success": False,
                    "speed_limit": -1,
                    "device_name": "",
                    "message": "未找到可用设备",
                }
            device_name = device.get("name", "")

        result = await self.remote.set_download_speed(device_name, speed_mbps)
        return {
            "success": result,
            "speed_limit": speed_mbps,
            "device_name": device_name,
            "message": f"速度限制已设置为 {'不限速' if speed_mbps == -1 else f'{speed_mbps} Mbps'}",
        }

    async def set_remote_concurrent(
        self,
        num: int = 3,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """
        设置远程设备并发下载数

        Args:
            num: 并发下载数，有效范围 1-5
            device_name: 设备名称，None 时自动选择在线设备

        Returns:
            操作结果:
            {
                "success": bool,           # 是否成功
                "concurrent": int,         # 设置的并发数
                "device_name": str,        # 设备名称
                "message": str,            # 结果描述
            }
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "success": False,
                    "concurrent": 0,
                    "device_name": "",
                    "message": "未找到可用设备",
                }
            device_name = device.get("name", "")

        result = await self.remote.set_concurrent_downloads(device_name, num)
        return {
            "success": result,
            "concurrent": num,
            "device_name": device_name,
            "message": f"并发下载数已设置为 {num}",
        }

    async def create_remote_folder(
        self,
        folder_path: str,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """
        在远程设备创建文件夹

        Args:
            folder_path: 文件夹路径（相对于远程设备根目录），支持多级创建。
                        注意：这是远程设备上的路径，不是本地路径。
                        示例：
                        - "/downloads" - 远程设备根目录下创建 downloads 文件夹
                        - "/电影/2024" - 多级路径，会依次创建
                        - "my_folder" - 相对路径，效果等同于 "/my_folder"
            device_name: 设备名称，None 时自动选择在线设备

        Returns:
            操作结果:
            {
                "success": bool,           # 是否成功
                "folder_path": str,        # 创建的文件夹路径
                "folder_id": str,          # 文件夹 ID
                "device_name": str,        # 设备名称
                "message": str,            # 结果描述
            }
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "success": False,
                    "folder_path": folder_path,
                    "device_name": "",
                    "message": "未找到可用设备",
                }
            device_name = device.get("name", "")
            device_id = device.get("device_id", "")
        else:
            device = await self.remote.get_device_info(device_name)
            if not device:
                return {
                    "success": False,
                    "folder_path": folder_path,
                    "device_name": device_name,
                    "message": f"设备 {device_name} 不存在",
                }
            device_id = device.get("device_id", "")

        from .utils import split_path

        parts = split_path(folder_path)
        parent_id = ""

        for part in parts:
            resp = await self.remote.post(
                self.remote.config.files_url,
                json={
                    "kind": "drive#folder",
                    "name": part,
                    "parent_id": parent_id,
                    "space": device_id,
                },
            )
            if not resp:
                return {
                    "success": False,
                    "folder_path": folder_path,
                    "device_name": device_name,
                    "message": f"创建文件夹 {part} 失败",
                }
            parent_id = resp.get("file", {}).get("id", "")

        return {
            "success": True,
            "folder_path": folder_path,
            "folder_id": parent_id,
            "device_name": device_name,
            "message": "文件夹创建成功",
        }

    async def get_remote_download_status(
        self,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """
        获取远程设备下载状态统计

        Args:
            device_name: 设备名称，None 时自动选择

        Returns:
            状态统计:
            {
                "device_name": str,         # 设备名称
                "online": bool,            # 是否在线
                "total_tasks": int,        # 总任务数
                "running_tasks": int,       # 正在下载
                "paused_tasks": int,       # 已暂停
                "completed_tasks": int,     # 已完成
                "failed_tasks": int,       # 失败任务
                "total_size": int,         # 总大小（字节）
                "total_size_human": str,   # 人类可读总大小
            }
        """
        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "device_name": "",
                    "online": False,
                    "total_tasks": 0,
                    "running_tasks": 0,
                    "paused_tasks": 0,
                    "completed_tasks": 0,
                    "failed_tasks": 0,
                    "total_size": 0,
                    "total_size_human": "0 B",
                }
            device_name = device.get("name", "")

        device = await self.get_remote_device(device_name)
        online = device.get("online", False) if device else False
        tasks = await self.get_remote_tasks(device_name, return_raw=True)

        running = paused = completed = failed = 0
        total_size = 0

        for task in tasks:
            phase = task.get("phase", "")
            if phase == "running":
                running += 1
            elif phase == "pause":
                paused += 1
            elif phase == "complete":
                completed += 1
            elif phase == "delete":
                failed += 1
            total_size += task.get("size", 0) or 0

        return {
            "device_name": device_name,
            "online": online,
            "total_tasks": len(tasks),
            "running_tasks": running,
            "paused_tasks": paused,
            "completed_tasks": completed,
            "failed_tasks": failed,
            "total_size": total_size,
            "total_size_human": format_bytes(total_size),
        }

    async def wait_remote_task_complete(
        self,
        task_id: str,
        device_name: str | None = None,
        timeout: float = 3600.0,
        poll_interval: float = 5.0,
    ) -> dict[str, Any]:
        """
        等待远程下载任务完成

        Args:
            task_id: 任务ID
            device_name: 设备名称，None 时自动选择
            timeout: 超时时间（秒），默认 3600 秒
            poll_interval: 轮询间隔（秒），默认 5 秒

        Returns:
            结果:
            {
                "success": bool,           # 是否成功完成
                "task_id": str,            # 任务ID
                "task_name": str,          # 任务名称
                "final_status": str,       # 最终状态
                "elapsed_time": float,     # 耗时（秒）
                "message": str,            # 结果描述
            }
        """
        import time

        if device_name is None:
            device = await self.get_remote_device()
            if not device:
                return {
                    "success": False,
                    "task_id": task_id,
                    "task_name": "",
                    "final_status": "",
                    "elapsed_time": 0,
                    "message": "未找到可用设备",
                }
            device_name = device.get("name", "")

        start_time = time.time()
        task_name = ""

        while time.time() - start_time < timeout:
            tasks = await self.get_remote_tasks(device_name, task_id=task_id, return_raw=True)
            if not tasks:
                return {
                    "success": False,
                    "task_id": task_id,
                    "task_name": task_name,
                    "final_status": "not_found",
                    "elapsed_time": time.time() - start_time,
                    "message": "任务不存在",
                }

            task = tasks[0]
            task_name = task.get("name", "")
            phase = task.get("phase", "")

            if phase == "complete":
                return {
                    "success": True,
                    "task_id": task_id,
                    "task_name": task_name,
                    "final_status": "complete",
                    "elapsed_time": time.time() - start_time,
                    "message": "任务已完成",
                }
            elif phase == "delete":
                return {
                    "success": False,
                    "task_id": task_id,
                    "task_name": task_name,
                    "final_status": "failed",
                    "elapsed_time": time.time() - start_time,
                    "message": "任务失败",
                }

            await asyncio.sleep(poll_interval)

        return {
            "success": False,
            "task_id": task_id,
            "task_name": task_name,
            "final_status": "timeout",
            "elapsed_time": time.time() - start_time,
            "message": f"等待超时 ({timeout}秒)",
        }

    # ==================== 快捷方法 ====================

    async def login(self) -> bool:
        """登录"""
        return await self.cloud.login()

    async def logout(self) -> None:
        """登出"""
        await self.cloud.logout()

    @property
    def is_login(self) -> bool:
        """是否已登录"""
        return self.cloud.is_login

    async def get_user_info(self):
        """获取用户信息"""
        return await self.cloud.get_user_info()

    async def get_space_info(self, human_readable: bool = False):
        """
        获取云盘空间信息

        Args:
            human_readable: 是否返回人类可读的格式（如 MB、GB），默认 False

        Returns:
            云盘空间信息字典:
            {
                "limit": int,              # 总空间（字节）
                "usage": int,              # 已使用空间（字节）
                "usage_in_trash": int,     # 回收站占用空间（字节）
                "free_space": int,         # 剩余空间（字节）
                # 以下为 human_readable=True 时新增
                "limit_formatted": str,    # 总空间（人类可读）
                "usage_formatted": str,    # 已使用空间（人类可读）
                "usage_in_trash_formatted": str,  # 回收站占用空间（人类可读）
                "free_space_formatted": str,  # 剩余空间（人类可读）
            }
        """
        return await self.cloud.get_space_info(human_readable)

    async def get_offline_task_count(self):
        """
        获取离线下载任务数量限制信息

        Returns:
            任务配额字典:
            {
                "limit": int,   # 总配额次数
                "usage": int,   # 已使用次数
                "remain": int,  # 剩余次数
            }
        """
        return await self.cloud.get_offline_task_limit()

    async def get_file_info(self, path: str, return_raw: bool = False):  # noqa: C901
        """
        获取文件或文件夹详情

        Args:
            path: 文件/目录路径（如 "/我的转存/电影.mp4"）或 ID（直接传入 ID 可快速查询）
            return_raw: 是否返回原始数据 (默认 False)
                         - False: 返回精简字段（id, name, path, parent_id, kind,
                           mime_type, file_extension, size, size_human, web_content_link,
                           share_links）
                         - True: 返回完整的原始文件信息

        Returns:
            文件/文件夹信息字典
            return_raw=False 时返回精简字段:
                {
                    "id": str,           # 文件ID
                    "name": str,         # 文件名
                    "path": str,         # 完整路径
                    "parent_id": str,    # 父目录ID
                    "kind": str,         # 类型 (drive#file 或 drive#folder)
                    "mime_type": str,    # MIME类型
                    "file_extension": str,  # 文件扩展名
                    "size": int,         # 大小(字节)
                    "size_human": str,   # 人类可读大小
                    "web_content_link": str,  # 内容链接
                    "share_links": list[str],  # 分享链接列表
                }
            return_raw=True 时返回完整原始数据
            当不存在或在回收站时，返回 None
        """
        if not path.startswith("/"):
            details = await self.cloud.get_file_details(file_id=path, include_share=True)
        else:
            details = await self.cloud.get_file_details(path=path, include_share=True)

        file_info = details.get("file_info")
        if not file_info:
            return None

        file_info["path"] = details.get("path", "")
        file_info["share_info"] = details.get("share_info")
        file_info["share_links"] = details.get("share_links", [])

        if return_raw:
            return file_info

        return self.cloud._format_file_info(file_info)

    async def get_recycle_bin_info(self):
        """获取回收站文件列表"""
        return await self.cloud.get_recycle_bin_info()

    async def empty_recycle_bin(self) -> bool:
        """清空回收站"""
        return await self.cloud.empty_recycle_bin()

    async def restore(
        self,
        file_id: str | list[str] | None = None,
        target_parent: str | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        get_actual_path: bool = False,
    ):
        """
        从回收站恢复文件，只能恢复到指定的目录，无法恢复到原路径

        Args:
            file_id: 文件ID、文件名、文件ID列表、文件名列表，或 None（整个回收站）
                    - str: 单个文件ID或文件名
                    - list: 多个文件ID或文件名混合列表
                    - None: 恢复整个回收站所有文件
            target_parent: 目标父目录路径或ID，None/""/"/"表示根目录
            on_exists: 同名文件冲突处理策略 (默认 SKIP)
                      - CloudFileExistsStrategy.SKIP: 跳过
                      - CloudFileExistsStrategy.RENAME: 重命名
                      - CloudFileExistsStrategy.OVERWRITE: 覆盖
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            单个文件: 操作结果字典
            多个文件: 操作结果列表
            {
                "success": bool,      # 操作是否成功
                "file_id": str,       # 文件ID
                "file_name": str,     # 文件名称
                "parent_id": str,     # 恢复到的父目录ID
                "original_parent_id": str,  # 原位置父目录ID
                "path": str,         # 恢复后的完整路径
                "message": str,       # 结果描述
            }
        """
        return await self.cloud.restore(file_id, target_parent, on_exists, get_actual_path)

    async def list_directory(
        self,
        path: str = "/",
        depth: int = 2,
        max_results: int | None = None,
        raw: bool = False,
    ):
        """
        获取指定目录下的文件列表（支持递归深度控制）

        Args:
            path: 目录路径，默认为根目录 "/"
            depth: 递归深度，默认 2（即遍历指定目录及其子目录）
                  - 1: 仅当前目录
                  - 2: 当前目录 + 一级子目录（默认）
                  - None: 不限制深度，遍历所有层级
            max_results: 最大返回数量，None 表示不限制
            raw: 是否返回原始数据（默认 False）
                 - True: 返回完整原始 API 响应
                 - False: 返回精简字段，并添加 size_human、统计信息

        Returns:
            raw=False: 返回字典包含 files、file_count、folder_count、total_count
            raw=True: 返回原始文件列表
        """
        return await self.cloud.search(
            callback=lambda f: True,
            path=path,
            max_results=max_results,
            depth=depth,
            raw=raw,
        )

    async def exists(
        self,
        name: str,
        path: str | None = None,
        is_folder: bool | None = None,
    ):
        """
        判断文件或目录是否存在

        Args:
            name: 文件/目录名称或绝对路径
                 - 以 "/" 开头: 作为绝对路径处理，直接定位
                   例如: "/我的文档/电影.mp4" 定位到 "电影.mp4" 在 "/我的文档" 下
                 - 不以 "/" 开头: 作为名称处理，在指定目录中搜索
                   例如: "电影.mp4" 在指定 path 中搜索
            path: 目录路径 (可选，仅对非绝对路径的 name 有效)
                 - 默认为 None: 从根目录开始全局搜索
                 - 指定路径: 在该目录及子目录中搜索
                 - 例如: "/我的文档" 或 "电影"
            is_folder: 类型限定 (可选)
                 - True: 仅搜索目录
                 - False: 仅搜索文件
                 - None: 不限定类型

        Returns:
            包含查找结果的字典:
            {
                "exists": bool,              # 是否存在
                "type": str,                 # 类型 ("file", "folder", None)
                "id": str,                   # 文件/目录 ID (存在时)
                "name": str,                 # 文件/目录名称 (存在时)
                "parent_id": str,            # 父目录 ID (存在时)
                "info": dict | None,         # 文件/目录完整信息 (存在时)
                "message": str,              # 结果描述
            }

        Examples:
            # 使用绝对路径定位（name 以 / 开头）
            result = await xunlei.exists("/测试目录/子目录1")

            # 使用名称搜索（name 不以 / 开头）
            result = await xunlei.exists("电影.mp4")
            result = await xunlei.exists("报告.pdf", path="/我的文档")
            result = await xunlei.exists("我的文件夹", is_folder=True)
        """
        return await self.cloud.exists(name, path, is_folder)

    async def search(
        self,
        query: str | None = None,
        callback: Callable[[dict[str, Any]], bool | None] | None = None,
        path: str | None = None,
        exact: bool = False,
        is_folder: bool | None = None,
        max_results: int = 100,
        return_raw: bool = False,
        show_spinner: bool = True,
        auto_share: bool = False,
        share_exists_strategy: ShareLinkStrategy = ShareLinkStrategy.SKIP,
    ):
        """
        搜索文件或目录

        Args:
            query: 搜索关键词 (可选)
                 - exact=False (默认): 模糊匹配，名称包含关键词即匹配
                 - exact=True: 精确匹配，名称必须完全等于关键词
                 - 可以和 callback 组合使用
            callback: 自定义匹配回调函数 (可选)
                     签名: Callable[[dict], bool | None]
                     - 接收文件信息字典
                     - 返回 True 表示匹配，返回 False 表示不匹配
                     - 返回 None 也视为不匹配
                     - 可以和 query 组合使用，API 搜索 + 本地过滤

                     回调接收的字典示例:
                         {
                             "id": "60f8b8a3b8d3c00123abc123",      # 文件/目录 ID
                             "name": "电影.mp4",                     # 文件/目录名称
                             "parent_id": "60f8b8a3b8d3c00123...",  # 父目录 ID
                             "kind": "drive#folder",           # 类型 (drive#folder=目录，其他=文件)
                             "size": 1048576,                       # 文件大小 (字节，目录为 0)
                             "created_time": "2024-01-15T10:30:00Z",  # 创建时间
                             "modified_time": "2024-01-15T10:30:00Z",  # 修改时间
                             "path": "/我的文档/电影.mp4"           # 完整路径 (仅搜索结果中包含)
                         }
            path: 搜索目录路径 (可选)
                 - None: 从根目录开始全局搜索
                 - "/": 根目录
                 - "/子目录": 指定目录
            exact: 是否精确匹配 (仅对 query 有效，默认: False)
                 - False: 模糊匹配，名称包含关键词即匹配
                 - True: 精确匹配，名称必须完全等于关键词
            is_folder: 类型限定 (可选)
                 - True: 仅搜索目录
                 - False: 仅搜索文件
                 - None: 不限定类型
            max_results: 最大返回数量 (默认: 100)
            return_raw: 是否返回原始数据 (默认 False)
                 - False: 返回精简的字段信息（无额外 API 调用，包含 share_info）
                 - True: 返回完整的原始文件信息（需额外 API 调用获取 path、share_info 等）
            show_spinner: 是否显示转圈动画 (默认 True)
            auto_share: 是否为没有分享链接的文件自动创建分享 (默认 False)
                 - True: 为没有分享链接的文件创建永久有效的分享链接
                 - False: 不创建分享
            share_exists_strategy: 分享链接已存在时的策略 (默认 SKIP)
                 - SKIP: 存在就不重复创建，返回现有的携带提取码的完整分享链接
                 - RECREATE: 创建一个新的，返回新建和现有的所有链接（新建的在第一个位置）
                 - OVERWRITE: 删除现有的所有分享链接，然后创建一个新的

        Returns:
            字典包含 files、file_count、folder_count、total_count
            {
                "files": [...],           # 文件/目录列表
                "file_count": int,       # 文件数量
                "folder_count": int,     # 文件夹数量
                "total_count": int,      # 总数量
                "share_summary": {...},  # 仅当 auto_share=True 时存在
            }

        Examples:
            # 使用 query 模糊搜索
            results = await xunlei.search("电影")

            # 搜索指定目录
            results = await xunlei.search("电影", path="/我的文档")

            # 使用 query 精确搜索
            results = await xunlei.search("电影.mp4", exact=True)

            # 仅搜索目录
            results = await xunlei.search(callback=lambda f: f.get("kind") == "drive#folder")

            # 仅搜索文件
            results = await xunlei.search(callback=lambda f: f.get("kind") != "drive#folder")

            # 获取完整文件详情
            results = await xunlei.search("电影", return_raw=True)

            # 使用 callback 搜索（复杂场景）
            results = await xunlei.search(
                callback=lambda f: f.get("size", 0) > 1000000 and "视频" in f.get("name", "")
            )

            # 搜索并为没有分享的文件创建分享
            results = await xunlei.search("电影", auto_share=True)

            # 搜索并覆盖已存在的分享
            results = await xunlei.search(
                "视频",
                auto_share=True,
                share_exists_strategy=ShareLinkStrategy.OVERWRITE,
            )
        """
        return await self.cloud.search(
            query,
            callback,
            path,
            exact,
            is_folder,
            max_results,
            return_raw=return_raw,
            show_spinner=show_spinner,
            auto_share=auto_share,
            share_exists_strategy=share_exists_strategy,
        )

    async def create_folder(
        self, folder_path: str, auto_create_parents: bool = True, include_raw: bool = False
    ):
        """
        创建目录（用户友好的路径方式）

        Args:
            folder_path: 完整目录路径 (例如: '/我的文档/项目/2024' 或 '项目/子目录')
                      注意: 以 '/' 开头表示从根目录开始的绝对路径
            auto_create_parents: 是否自动创建父目录 (默认: True)
                               当设置为 True 时，会自动创建所有不存在的父目录
                               当设置为 False 时，只创建最后一级目录
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool | str,   # 操作结果 (True=创建成功, "existed"=已存在, False=失败)
                "folder_id": str,          # 文件夹ID (创建/已存在时)
                "folder_name": str,        # 文件夹名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        return await self.cloud.create_folder(folder_path, "", auto_create_parents, include_raw)

    async def delete_folder(self, target: str, permanent: bool = False, include_raw: bool = False):
        """
        删除目录（支持ID和路径两种方式）

        Args:
            target: 目录ID或完整路径 (例如: '/我的文档/旧项目' 或 '目录ID')
            permanent: 是否永久删除 (默认: False)
                              False = 移到回收站 (安全删除)
                              True = 永久删除 (不可恢复)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool,           # 操作是否成功
                "folder_id": str,          # 被删除的文件夹ID
                "folder_name": str,        # 被删除的文件夹名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        return await self.cloud.delete_folder(target, permanent, include_raw)

    async def delete_file(self, target: str, permanent: bool = False, include_raw: bool = False):
        """
        删除文件（支持ID和路径两种方式）

        Args:
            target: 文件ID或完整路径 (例如: '/我的文档/旧文件.txt' 或 '文件ID')
            permanent: 是否永久删除 (默认: False)
                              False = 移到回收站 (安全删除)
                              True = 永久删除 (不可恢复)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool,           # 操作是否成功
                "file_id": str,            # 被删除的文件ID
                "file_name": str,          # 被删除的文件名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        return await self.cloud.delete_file(target, permanent, include_raw)

    async def delete(self, target: str, permanent: bool = False, include_raw: bool = False):
        """
        删除文件或目录（自动识别类型）

        Args:
            target: 文件/目录ID或完整路径 (例如: '/我的文档/旧文件.txt' 或 '文件ID/目录ID')
            permanent: 是否永久删除 (默认: False)
                              False = 移到回收站 (安全删除)
                              True = 永久删除 (不可恢复)
            include_raw: 是否包含原始返回信息 (默认: False)

        Returns:
            包含操作结果的字典:
            {
                "success": bool | str,   # 操作结果 (True=成功, "not_found"=不存在, False=失败)
                "type": str,               # 操作对象的类型 ("file" 或 "folder")
                "id": str,                 # 被删除的文件/目录ID
                "name": str,               # 被删除的文件/目录名称
                "parent_id": str,          # 父目录ID
                "message": str,            # 操作结果描述
                "raw": dict | None         # 原始返回信息 (仅当 include_raw=True 时)
            }
        """
        return await self.cloud.delete(target, permanent, include_raw)

    async def rename(
        self,
        old: str | Callable[[dict[str, Any]], bool | None],
        new: str | Callable[[dict[str, Any]], str] | None = None,
        path: str | None = None,
        is_folder: bool | None = None,
    ):
        """
        重命名文件/目录（支持单个和批量操作）

        两种模式：
        1. 单个重命名 (path=None):
           - old: 绝对路径，如 "/文档/旧文件名.txt"
           - new: 新名称，如 "新文件名.txt"
        2. 批量重命名 (path 设定目录):
           - path: "all" 表示整个网盘，"/" 表示根目录，"/目录" 表示指定目录下的文件
           - old: 回调函数
           - new: 回调函数

        Args:
            old: 原文件路径或匹配回调函数
            new: 新名称或名称回调函数（单个模式时必需）
            path: 操作目录 (None=单个模式, "all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (仅批量模式有效)
                      - True: 仅匹配目录
                      - False: 仅匹配文件
                      - None: 不限定类型

        Returns:
            单个模式: 操作结果字典
            批量模式: 操作结果列表

        Examples:
            # 单个重命名
            result = await xunlei.rename("/文档/旧文件名.txt", "新文件名.txt")

            # 批量重命名 - 替换文件名中的字符串
            results = await xunlei.rename(
                old=lambda f: "旧字符" in f.get("name", ""),
                new=lambda f: f.get("name", "").replace("旧字符", "新字符"),
                path="/文档"
            )

            # 批量重命名 - 仅重命名目录
            results = await xunlei.rename(
                old=lambda f: f.get("name", "").startswith("临时_"),
                new=lambda f: f.get("name", "").replace("临时_", ""),
                path="/",
                is_folder=True
            )

            # 批量重命名 - 仅重命名文件
            results = await xunlei.rename(
                old=lambda f: ".txt" in f.get("name", ""),
                new=lambda f: f.get("name", "").replace(".txt", ".md"),
                path="/",
                is_folder=False
            )

        回调函数签名说明:

        old 回调函数 (匹配条件):
            签名: Callable[[dict], bool | None]
            接收的文件信息字典字段:
            {
                "id": str,           # 文件/目录 ID
                "name": str,          # 文件/目录名称
                "parent_id": str,     # 父目录 ID
                "kind": str,          # 类型 ("drive#folder"=目录, "drive#file"=文件)
                "size": int,          # 文件大小（字节）
                "path": str,          # 完整路径
                "created_time": str,  # 创建时间
                "modified_time": str, # 修改时间
                "mime_type": str,     # MIME 类型
            }
            返回 True 表示匹配，返回 False 表示不匹配

        new 回调函数 (生成新名称):
            签名: Callable[[dict], str]
            接收同上字典字段
            返回新名称字符串
        """
        return await self.cloud.rename(old, new, path, is_folder)

    async def upload(  # noqa: C901
        self,
        path: str | list[str],
        target: str,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.RENAME,
        auto_create_parents: bool = True,
        capacity_exceeded_strategy: CapacityExceededStrategy = CapacityExceededStrategy.ABORT,
        share_after_upload: ShareAfterTransferStrategy = ShareAfterTransferStrategy.NO_CREATE,
        share_sync_timeout: float = 30.0,
        share_strategy: ShareLinkStrategy = ShareLinkStrategy.SKIP,
        progress_callback: Callable[[UploadProgress], None] | None = None,
        show_progress_bar: bool = True,
        max_concurrent: int = 2,
        min_concurrent: int = 1,
        max_concurrent_limit: int = 5,
        chunk_concurrent: int = 4,
        concurrency_adjustment: ConcurrencyAdjustmentStrategy = (
            ConcurrencyAdjustmentStrategy.ADAPTIVE
        ),
        failure_strategy: FailureStrategy = FailureStrategy.DEFERRED_RETRY,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_multiplier: float = 2.0,
        max_retry_delay: float = 30.0,
        stop_on_first_error: bool = False,
        enable_resume: bool = True,
        task_timeout: float = 300.0,
        auto_downgrade_on_limit: bool = True,
        downgrade_retry_delay: float = 5.0,
    ) -> UploadResult | list[UploadResult] | UploadDirResult:
        """
        统一的上传接口（智能识别文件或目录）

        Args:
            path: 本地文件/目录路径，或路径列表
                 - str: 单个文件路径，如 "C:/test.mp4"
                 - str: 单个目录路径，如 "C:/视频"（自动识别为目录）
                 - list: 多个文件路径列表，如 ["C:/file1.mp4", "C:/file2.jpg"]
            target: 云盘目标目录路径（必填）
            on_exists: 同名文件冲突处理策略 (默认 RENAME)
                        - CloudFileExistsStrategy.SKIP: 跳过
                        - CloudFileExistsStrategy.RENAME: 重命名
                        - CloudFileExistsStrategy.OVERWRITE: 覆盖
            auto_create_parents: 是否自动创建父目录 (默认 True)
            capacity_exceeded_strategy: 云盘空间不足时的处理策略 (默认 ABORT)
                                      - ABORT: 终止模式，检测到任何文件超出可用空间则终止全部任务
                                      - SMALL_FIRST: 小文件优先，能容纳的小文件优先上传
                                      - LARGE_FIRST: 大文件优先，空间不足时尝试上传小文件
            注意：上传流量限制请查看 https://vip.xunlei.com/pages/2023/vip-privilege-intro/pc/
                  普通用户：1GB/天，10GB/月；超级会员：120GB/天，500GB/月
            share_after_upload: 上传完成后是否自动创建分享链接 (默认 NO_CREATE)
                               - NO_CREATE: 不创建
                               - CREATE: 创建（单文件/多文件时为每个文件创建，目录时为整个目录创建）
            share_sync_timeout: 创建分享链接前等待文件同步的最大时间，秒 (默认 30.0，最小 1.0)
            share_strategy: 分享链接已存在时的处理策略 (默认 SKIP)
                           - SKIP: 跳过
                           - RECREATE: 重新创建
                           - OVERWRITE: 覆盖
            progress_callback: 进度回调函数，接收 UploadProgress
            show_progress_bar: 是否显示进度条 (默认 True)

            ===== 高级并发控制参数 =====

            max_concurrent: 最大并发任务数 (默认 2)
            min_concurrent: 最小并发任务数 (默认 1)
            max_concurrent_limit: 并发数上限 (默认 5)
            chunk_concurrent: 单文件内部分片并发数 (默认 4)
            concurrency_adjustment: 并发数动态调整策略 (默认 ADAPTIVE)
                                   - MAINTAIN: 保持不变
                                   - REDUCE_ON_FAILURE: 失败时减少并发
                                   - INCREASE_ON_SUCCESS: 连续成功后增加并发
                                   - ADAPTIVE: 智能自适应（推荐）
            failure_strategy: 任务失败时的处理策略 (默认 DEFERRED_RETRY)
                            - SKIP: 跳过失败任务，继续处理其他任务
                            - DEFERRED_RETRY: 失败任务放到队列末尾，稍后重试（推荐）
                            - IMMEDIATE_RETRY: 立即重试当前失败任务
                            - BLOCKING_RETRY: 暂停其他任务，先重试失败任务
                            - ABORT: 遇到失败就终止所有任务
            max_retries: 单任务最大重试次数 (默认 3)
            retry_delay: 初始重试等待时间，秒 (默认 1.0)
            retry_multiplier: 重试等待时间乘数 (默认 2.0，指数退避)
            max_retry_delay: 最大重试等待时间，秒 (默认 30.0)
            stop_on_first_error: 遇到第一个错误是否终止 (默认 False)
            enable_resume: 是否启用断点续传 (默认 True)
            task_timeout: 单任务超时时间，秒 (默认 300.0)
            auto_downgrade_on_limit: 检测到任务数限制时是否自动降级并发 (默认 True)
            downgrade_retry_delay: 自动降级后的等待时间，秒 (默认 5.0)

        Returns:
            单个文件: UploadResult
            多个文件: list[UploadResult]
            目录: UploadDirResult

        Examples:
            # 上传单个文件到指定目录
            result = await xunlei.upload("C:/Users/test.mp4", target="/视频")

            # 上传多个文件
            results = await xunlei.upload(["file1.mp4", "file2.jpg"], target="/备份")

            # 上传目录
            result = await xunlei.upload("C:/Users/视频", target="/备份")

            # 上传并自动创建分享链接
            result = await xunlei.upload(
                "C:/Users/test.mp4",
                target="/视频",
                share_after_upload=ShareAfterTransferStrategy.CREATE
            )

            # 小文件优先上传（空间不足时只上传小文件）
            result = await xunlei.upload(
                "C:/Users/视频",
                target="/备份",
                capacity_exceeded_strategy=CapacityExceededStrategy.SMALL_FIRST
            )

            # 大文件优先上传（空间不足时尝试上传其他小文件）
            result = await xunlei.upload(
                "C:/Users/视频",
                target="/备份",
                capacity_exceeded_strategy=CapacityExceededStrategy.LARGE_FIRST
            )

            # 速度优先模式：跳过失败文件，保持高速上传
            result = await xunlei.upload(
                "C:/视频",
                target="/备份",
                max_concurrent=5,
                failure_strategy=FailureStrategy.SKIP,
                concurrency_adjustment=ConcurrencyAdjustmentStrategy.INCREASE_ON_SUCCESS,
            )

            # 稳定优先模式：失败后减少并发，慢慢重试
            result = await xunlei.upload(
                "C:/重要文件",
                target="/备份",
                max_concurrent=3,
                failure_strategy=FailureStrategy.DEFERRED_RETRY,
                concurrency_adjustment=ConcurrencyAdjustmentStrategy.REDUCE_ON_FAILURE,
                max_retries=5,
            )

            # 智能模式：动态调整，自动适应（推荐默认）
            result = await xunlei.upload(
                "C:/混合文件",
                target="/备份",
                max_concurrent=4,
                failure_strategy=FailureStrategy.DEFERRED_RETRY,
                concurrency_adjustment=ConcurrencyAdjustmentStrategy.ADAPTIVE,
                enable_resume=True,
            )
        """

        def calculate_total_size(paths: list[str]) -> int:
            """计算文件/目录列表的总大小"""
            total = 0
            for p in paths:
                if os.path.isfile(p):
                    total += os.path.getsize(p)
                elif os.path.isdir(p):
                    for root, _, files in os.walk(p):
                        for f in files:
                            total += os.path.getsize(os.path.join(root, f))
            return total

        advanced_options = UploadAdvancedOptions(
            max_concurrent=max_concurrent,
            min_concurrent=min_concurrent,
            max_concurrent_limit=max_concurrent_limit,
            chunk_concurrent=chunk_concurrent,
            failure_strategy=failure_strategy,
            max_retries=max_retries,
            retry_delay=retry_delay,
            retry_multiplier=retry_multiplier,
            max_retry_delay=max_retry_delay,
            concurrency_adjustment=concurrency_adjustment,
            enable_resume=enable_resume,
            stop_on_first_error=stop_on_first_error,
            task_timeout=task_timeout,
            auto_downgrade_on_limit=auto_downgrade_on_limit,
            downgrade_retry_delay=downgrade_retry_delay,
        )

        options = UploadOptions(
            target_parent_path=target,
            auto_create_parents=auto_create_parents,
            on_conflict=on_exists,
            capacity_exceeded_strategy=capacity_exceeded_strategy,
            share_after_upload=share_after_upload,
            share_sync_timeout=share_sync_timeout,
            share_strategy=share_strategy,
            enable_resume=enable_resume,
        )

        if auto_create_parents and target != "/":
            folder_info = await self.cloud.get_file_info(target)
            if not folder_info:
                create_result = await self.cloud.create_folder(target, "", True)
                if not create_result or create_result.get("success") is False:
                    return UploadResult(
                        success=False,
                        local_path=path[0] if isinstance(path, list) else path,
                        file_name="",
                        file_size=0,
                        file_id="",
                        target_path=target,
                        message=f"无法创建目标目录: {target}",
                        error=create_result.get("message") if create_result else "创建目录失败",
                    )

        if isinstance(path, list):
            total_size = calculate_total_size(path)
            space_info = await self.cloud.get_space_info()
            available_space = space_info.get("free_space", 0) if space_info else 0

            if capacity_exceeded_strategy == CapacityExceededStrategy.ABORT:
                if total_size > available_space:
                    return [
                        UploadResult(
                            success=False,
                            local_path=path[0],
                            file_name=os.path.basename(path[0]),
                            file_size=total_size,
                            file_id="",
                            target_path="",
                            message="云盘空间不足，已终止上传",
                            error=(
                                f"任务总大小 {format_bytes(total_size)} "
                                f"超出云盘可用空间 {format_bytes(available_space)}"
                            ),
                        )
                    ]
            if show_progress_bar and progress_callback is None:
                from .api.upload import UploadProgressBar

                pb = UploadProgressBar(total_files=len(path))
                progress_callback = pb.print_progress
            return await self.uploader.upload_files(
                path, options, progress_callback, advanced_options
            )
        elif os.path.isdir(path):
            total_size = calculate_total_size([path])
            space_info = await self.cloud.get_space_info()
            available_space = space_info.get("free_space", 0) if space_info else 0

            if capacity_exceeded_strategy == CapacityExceededStrategy.ABORT:
                if total_size > available_space:
                    return UploadDirResult(
                        success=False,
                        total_files=0,
                        total_size=total_size,
                        target_dir=target,
                        message="云盘空间不足，已终止上传",
                        space_checked=True,
                        available_space=available_space,
                        required_space=total_size,
                        space_exceeded=True,
                        aborted_reason=(
                            f"任务总大小 {format_bytes(total_size)} "
                            f"超出云盘可用空间 {format_bytes(available_space)}"
                        ),
                    )
            if show_progress_bar and progress_callback is None:
                from .api.upload import UploadProgressBar

                pb = UploadProgressBar(total_files=len(path))
                progress_callback = pb.print_progress
            return await self.uploader.upload_directory(
                path, options, progress_callback, advanced_options
            )
        else:
            file_size = os.path.getsize(path)
            space_info = await self.cloud.get_space_info()
            available_space = space_info.get("free_space", 0) if space_info else 0

            if capacity_exceeded_strategy == CapacityExceededStrategy.ABORT:
                if file_size > available_space:
                    return UploadResult(
                        success=False,
                        local_path=path,
                        file_name=os.path.basename(path),
                        file_size=file_size,
                        file_id="",
                        target_path="",
                        message="云盘空间不足，已终止上传",
                        error=(
                            f"文件大小 {format_bytes(file_size)} "
                            f"超出云盘可用空间 {format_bytes(available_space)}"
                        ),
                    )
            if show_progress_bar and progress_callback is None:
                from .api.upload import UploadProgressBar

                pb = UploadProgressBar(total_files=1)
                progress_callback = pb.print_progress
            return await self.uploader.upload_file(
                path, options, progress_callback, advanced_options
            )

    async def copy(
        self,
        source: str | Callable[[dict[str, Any]], bool | None],
        target_parent: str | list[str],
        path: str | None = None,
        is_folder: bool | None = None,
        on_exists: Any = None,
        get_actual_path: bool = False,
    ):
        """
        复制文件/目录（支持单个和批量操作）

        两种模式：
        1. 单个复制 (path=None):
           - source: 源文件绝对路径，如 "/文档/源文件.txt"
           - target_parent: 目标目录的绝对路径或ID
        2. 批量复制 (path 设定目录):
           - path: "all" 表示整个网盘，"/" 表示根目录，"/目录" 表示指定目录
           - source: 匹配回调函数
           - target_parent: 目标目录的绝对路径或ID，或多个目录的列表

        Args:
            source: 源文件路径或匹配回调函数
            target_parent: 目标父目录（绝对路径或ID）
            path: 操作目录 (None=单个模式, "all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (仅批量模式有效)
                      - True: 仅匹配目录
                      - False: 仅匹配文件
                      - None: 不限定类型
            on_exists: 同名文件冲突处理策略 (默认 SKIP)
                      - CloudFileExistsStrategy.SKIP: 跳过（不处理）
                      - CloudFileExistsStrategy.RENAME: 重命名（如 xxx (1).txt）
                      - CloudFileExistsStrategy.OVERWRITE: 覆盖
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            单个模式: 操作结果字典
            批量模式: 操作结果列表

        Examples:
            # 单个复制
            result = await xunlei.copy("/文档/源文件.txt", "/备份")

            # 单个复制 - 获取真实路径
            result = await xunlei.copy("/文档/源文件.txt", "/备份", get_actual_path=True)

            # 批量复制 - 复制所有txt文件到指定目录
            results = await xunlei.copy(
                source=lambda f: f.get("name", "").endswith(".txt"),
                target_parent="/备份",
                path="/文档"
            )

            # 批量复制 - 复制整个网盘中的目录到指定位置
            results = await xunlei.copy(
                source=lambda f: f.get("kind", "") == "drive#folder",
                target_parent="/备份",
                path="all",
                is_folder=True
            )
        """
        return await self.cloud.copy(
            source, target_parent, path, is_folder, on_exists, get_actual_path
        )

    async def move(
        self,
        source: str | Callable[[dict[str, Any]], bool | None],
        target_parent: str,
        path: str | None = None,
        is_folder: bool | None = None,
        on_exists: Any = None,
        get_actual_path: bool = False,
    ):
        """
        移动文件/目录（支持单个和批量操作）

        两种模式：
        1. 单个移动 (path=None):
           - source: 源文件绝对路径，如 "/文档/源文件.txt"
           - target_parent: 目标目录的绝对路径或ID
        2. 批量移动 (path 设定目录):
           - path: "all" 表示整个网盘，"/" 表示根目录，"/目录" 表示指定目录
           - source: 匹配回调函数
           - target_parent: 目标目录的绝对路径或ID

        Args:
            source: 源文件路径或匹配回调函数
            target_parent: 目标父目录（绝对路径或ID）
            path: 操作目录 (None=单个模式, "all"=整个网盘, "/"=根目录, "/目录"=指定目录)
            is_folder: 类型限定 (仅批量模式有效)
                      - True: 仅匹配目录
                      - False: 仅匹配文件
                      - None: 不限定类型
            on_exists: 同名文件冲突处理策略 (默认 SKIP)
                      - CloudFileExistsStrategy.SKIP: 跳过（不处理）
                      - CloudFileExistsStrategy.RENAME: 重命名（如 xxx (1).txt）
                      - CloudFileExistsStrategy.OVERWRITE: 覆盖
            get_actual_path: 是否通过 API 获取真实路径（默认 False 使用拼接方式）

        Returns:
            单个模式: 操作结果字典
            批量模式: 操作结果列表

        Examples:
            # 单个移动
            result = await xunlei.move("/文档/文件.txt", "/备份")

            # 单个移动 - 获取真实路径
            result = await xunlei.move("/文档/文件.txt", "/备份", get_actual_path=True)

            # 批量移动 - 移动所有txt文件到指定目录
            results = await xunlei.move(
                source=lambda f: f.get("name", "").endswith(".txt"),
                target_parent="/备份",
                path="/文档"
            )

            # 批量移动 - 移动整个网盘中的目录到指定位置
            results = await xunlei.move(
                source=lambda f: f.get("kind", "") == "drive#folder",
                target_parent="/备份",
                path="all",
                is_folder=True
            )
        """
        return await self.cloud.move(
            source, target_parent, path, is_folder, on_exists, get_actual_path
        )

    async def create_offline_task(self, url: str, parent_id: str = ""):
        """创建云添加任务"""
        return await self.cloud.create_offline_task(url, parent_id)

    async def add_cloud_offline_task(  # noqa: C901
        self,
        url: str,
        target_folder: str | None,
        select_files: list[int | str | Callable[[dict[str, Any]], bool]] | None = None,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.SKIP,
        rename: str | Callable[[dict[str, Any]], str] | None = None,
        rename_subfiles: str | Callable[[dict[str, Any]], str] | None = None,
        rename_subfiles_timeout: float = 60.0,
        capacity_exceeded_strategy: CapacityExceededStrategy = CapacityExceededStrategy.ABORT,
        share_after_upload: ShareAfterTransferStrategy = ShareAfterTransferStrategy.NO_CREATE,
        share_sync_timeout: float = 30.0,
        share_strategy: ShareLinkStrategy = ShareLinkStrategy.SKIP,
        return_raw: bool = False,
    ) -> dict[str, Any]:
        """
        添加云盘离线下载任务（将磁力链接/HTTP链接直接下载到云盘）

        Args:
            url: 下载链接，支持:
                 - Magnet 磁力链接
                 - HTTP/HTTPS 直链
                 - BT 种子文件 (.torrent)
            target_folder: 云盘目标文件夹路径。
                          None 或 "/" 表示根目录。
                          例如 "/电影" 或 "/downloads/2024"。
                          目录不存在时自动递归创建。
            select_files: 选择性下载，支持多种方式:
                         1. 索引列表: [1, 3, 5] 表示下载索引为 1、3、5 的文件
                         2. 文件类型: [FileTypeFilter.VIDEO] 或 ["video/"] 选择视频文件
                            多个类型时为并集（OR），如 [VIDEO, AUDIO] 表示视频或音频
                         3. 筛选函数: [name_contains_filter(["高清"])] 按条件筛选
                            多个筛选函数时为交集（AND）
                         支持混用，如 [FileTypeFilter.VIDEO, name_excludes_filter(["预览"])]
                         None 表示下载全部文件。
            on_exists: 同名文件冲突处理策略，默认 SKIP（跳过）:
                               - SKIP: 跳过已存在的文件，不重复上传
                               - RENAME: 重命名新文件（自动添加序号）
                               - OVERWRITE: 覆盖已有文件
                               - ABORT_ALL: 终止全部操作
                               - ABORT_LOCAL: 终止本地操作，跳过剩余文件
            rename: 下载后重命名，支持:
                    - str: 直接使用该字符串作为新文件名
                    - RenameFunc: 回调函数，接收文件信息 dict，返回新文件名
                    - None: 不重命名
                    预设回调函数:
                    - add_prefix(prefix): 添加前缀，支持列表如 add_prefix(["【", "高清", "】"])
                    - add_suffix(suffix): 添加后缀，支持列表如 add_suffix(["_", "720p"])
                    - replace_text(old, new): 替换文本，支持:
                       - 单个替换: replace_text("高清", "HD")
                       - 批量替换: replace_text(["高清", "标清"], ["HD", "4K"])
                       - 元组形式: replace_text(("高清", "HD"))
                    - remove_text(text): 移除文本，支持列表如
                      remove_text(["[广告]", "[预告片]", "(1)"])
                    - regex_replace(pattern, repl): 正则替换如 regex_replace(r"\\[\\d+\\]", "")
                    - add_resolution(): 自动添加分辨率标识
            rename_subfiles: 目录内子文件的重命名规则（仅当下载项为目录时生效）。
                          下载完成后对目录内的子文件执行重命名。
                          如果不设置，则不对子文件进行重命名。
                          格式同 rename 参数。
            rename_subfiles_timeout: 子文件重命名等待超时时间（秒），默认 60.0。
                                    仅当 rename_subfiles 设置时生效。
            capacity_exceeded_strategy: 容量超出策略，默认 ABORT（中止）:
                                        - ABORT: 终止全部操作
                                        - SKIP: 跳过超出容量的文件
                                        - OVERWRITE: 删除旧文件后上传
            share_after_upload: 上传后分享策略，默认 NO_CREATE（不创建分享）:
                                        - NO_CREATE: 不创建分享链接
                                        - CREATE: 创建分享链接
                                        - SYNC: 同步创建分享链接
            share_sync_timeout: 分享同步超时时间（秒），默认 30.0
            share_strategy: 分享链接冲突策略，默认 SKIP（跳过）:
                                        - SKIP: 跳过已存在的分享
                                        - RECREATE: 删除后重新创建
                                        - OVERWRITE: 覆盖已有分享
            return_raw: 是否返回原始 API 响应，默认 False

        Returns:
            return_raw=True 时返回 API 原始响应
            return_raw=False 时返回结构化结果:
            {
                "success": bool,
                "file_id": str,       # 云盘文件 ID
                "file_name": str,     # 文件名
                "file_size": int,     # 文件大小（字节）
                "file_count": int,    # 文件数量
                "message": str,       # 状态消息
            }
        """
        from .api import FileTypeFilter

        # 解析种子文件
        if url.endswith(".torrent"):
            from .utils import parse_torrent

            url, _ = await parse_torrent(url)

        # 获取 URL 信息（用于获取文件列表和筛选）
        url_info = await self.cloud.get_download_url_info(url)
        if not url_info:
            return {
                "success": False,
                "file_id": "",
                "file_name": rename or "",
                "file_size": 0,
                "file_count": 0,
                "message": "获取链接信息失败",
            }

        file_count = int(url_info.get("file_count", 1))
        files = url_info.get("files", [])

        # 处理选择性下载
        indices: list[int] | None = None
        first_file_info: dict[str, Any] | None = None
        if select_files:
            first_item = select_files[0]
            if isinstance(first_item, int):
                indices = select_files
            else:
                file_types: list[str] | None = None
                filter_funcs: list[FileFilterFunc] = []
                for item in select_files:
                    if isinstance(item, FileTypeFilter):
                        if not file_types:
                            file_types = []
                        file_types.append(item.value)
                    elif isinstance(item, str):
                        if not file_types:
                            file_types = []
                        file_types.append(item)
                    elif callable(item):
                        filter_funcs.append(item)

                filtered_files = self._filter_magnet_files(files, file_types, filter_funcs)
                indices = [f["index"] for f in filtered_files] if filtered_files else []
                if filtered_files:
                    first_file_info = filtered_files[0]
        else:
            indices = list(range(1, file_count + 1))
            if files:
                first_file_info = files[0]

        # 处理 rename 回调函数
        if callable(rename):
            file_info_for_rename = first_file_info or {"name": url_info.get("task_name", "")}
            task_name = rename(file_info_for_rename) or url_info.get("task_name", "")
        else:
            task_name = rename if rename else url_info.get("task_name", "")

        if not indices:
            return {
                "success": False,
                "file_id": "",
                "file_name": task_name,
                "file_size": 0,
                "file_count": 0,
                "message": "没有符合条件的文件",
            }

        # 解析目标文件夹路径，获取 parent_id
        parent_id = ""
        if target_folder and target_folder != "/":
            folder_info = await self.cloud.create_folders_recursive(target_folder)
            if folder_info.get("success"):
                parent_id = folder_info.get("folder_id", "")
            else:
                return {
                    "success": False,
                    "file_id": "",
                    "file_name": task_name,
                    "file_size": 0,
                    "file_count": 0,
                    "message": f"创建目标文件夹失败: {folder_info.get('message', '')}",
                }

        # 检查云盘容量
        if capacity_exceeded_strategy == CapacityExceededStrategy.ABORT:
            space_info = await self.cloud.get_space_info()
            available_space = space_info.get("free_space", 0) if space_info else 0
            total_size = sum(
                int(f.get("size", 0) or 0) for f in files if int(f.get("index", 0) in indices)
            )
            if total_size > available_space:
                return {
                    "success": False,
                    "file_id": "",
                    "file_name": task_name,
                    "file_size": 0,
                    "file_count": len(indices),
                    "message": "云盘空间不足，"
                    + f"可用空间 {available_space} 字节，需要 {total_size} 字节",
                }

        # 检查是否存在同名文件
        search_result = await self.cloud.search(task_name, parent_id=parent_id, recurse=False)
        existing_files = search_result.get("files", []) if search_result else []
        existing_file = next((f for f in existing_files if f.get("name") == task_name), None)

        if existing_file:
            from .api import CloudFileExistsStrategy

            if on_exists == CloudFileExistsStrategy.SKIP:
                return {
                    "success": True,
                    "file_id": existing_file.get("id", ""),
                    "file_name": task_name,
                    "file_size": int(existing_file.get("size", 0) or 0),
                    "file_count": 0,
                    "message": "文件已存在，已跳过",
                }
            elif on_exists == CloudFileExistsStrategy.RENAME:
                counter = 1
                base_name = task_name
                ext = ""
                if "." in task_name:
                    base_name, ext = task_name.rsplit(".", 1)
                    ext = "." + ext
                new_name = f"{base_name} ({counter}){ext}"
                while any(f.get("name") == new_name for f in existing_files):
                    counter += 1
                    new_name = f"{base_name} ({counter}){ext}"
                task_name = new_name
            elif on_exists == CloudFileExistsStrategy.OVERWRITE:
                await self.cloud.delete(existing_file.get("id", ""))
            elif on_exists == CloudFileExistsStrategy.ABORT_ALL:
                return {
                    "success": False,
                    "file_id": "",
                    "file_name": task_name,
                    "file_size": 0,
                    "file_count": 0,
                    "message": "操作已取消：文件已存在",
                }

        # 调用云盘离线下载接口
        resp = await self.cloud.post(
            self.cloud.config.files_url,
            json={
                "upload_type": "UPLOAD_TYPE_URL",
                "kind": "drive#file",
                "parent_id": parent_id,
                "name": task_name,
                "url": {
                    "url": url,
                    "files": [str(i) for i in indices],
                },
            },
        )

        if return_raw:
            return resp if resp else {}

        if not resp:
            return {
                "success": False,
                "file_id": "",
                "file_name": task_name,
                "file_size": 0,
                "file_count": len(indices),
                "message": "创建离线任务失败",
            }

        if resp.get("error"):
            return {
                "success": False,
                "file_id": "",
                "file_name": task_name,
                "file_size": 0,
                "file_count": len(indices),
                "message": resp.get("error_description") or resp.get("error"),
            }

        # 从响应中提取文件信息
        file_id = resp.get("file", {}).get("id", "") if resp.get("file") else ""

        # 子文件重命名处理
        if rename_subfiles is not None and file_id:
            file_info = await self.cloud.get_file_info_by_id(file_id)
            if file_info and file_info.get("kind") == "drive#folder":

                def apply_subfile_rename(file_info: dict[str, Any], rename_func) -> str:
                    if isinstance(rename_func, str):
                        return rename_func
                    return rename_func(file_info)

                sub_timeout = rename_subfiles_timeout
                start_time = asyncio.get_event_loop().time()
                sub_files_collected = False
                while asyncio.get_event_loop().time() - start_time < sub_timeout:
                    sub_files = await self.cloud.get_files(parent_id=file_id)
                    if sub_files:
                        sub_files_collected = True
                        break
                    await asyncio.sleep(1)
                if sub_files_collected:
                    for sf in sub_files:
                        sf_id = sf.get("id", "")
                        sf_name = sf.get("name", "")
                        if not sf_id or not sf_name:
                            continue
                        try:
                            new_name = apply_subfile_rename(sf, rename_subfiles)
                            if new_name != sf_name:
                                rename_result = await self.cloud.rename(
                                    sf_name, new_name, file_info.get("path", ""), False
                                )
                                if rename_result:
                                    logger.info(f"子文件重命名: {sf_name} -> {new_name}")
                        except Exception as e:
                            logger.warning(f"子文件重命名失败: {sf_name}, 错误: {e}")

        # 上传后分享处理
        if share_after_upload != ShareAfterTransferStrategy.NO_CREATE and file_id:
            share_url = ""
            share_timeout = share_sync_timeout
            start_time = asyncio.get_event_loop().time()
            file_info = None
            while asyncio.get_event_loop().time() - start_time < share_timeout:
                file_info = await self.cloud.get_file_info_by_id(file_id)
                if file_info:
                    break
                await asyncio.sleep(1)
            if file_info:
                share_result = await self.cloud.create_share_link(
                    file_id=file_id,
                    on_exists=share_strategy,
                )
                if share_result.get("success", False):
                    share_links = share_result.get("share_links", [])
                    share_url = share_links[0] if share_links else ""
                    logger.info(f"已创建分享链接: {task_name} -> {share_url}")

        return {
            "success": True,
            "file_id": file_id,
            "file_name": task_name,
            "file_size": int(resp.get("file", {}).get("size", 0) or 0) if resp.get("file") else 0,
            "file_count": len(indices),
            "message": "已提交云盘离线下载任务",
        }

    def _filter_magnet_files(  # noqa: C901
        self,
        files: list[dict[str, Any]],
        file_types: list[str] | None,
        filters: list[FileFilterFunc] | None,
    ) -> list[dict[str, Any]]:
        """
        筛选磁力链接文件列表

        Args:
            files: 文件列表
            file_types: MIME 类型列表（OR 逻辑）
            filters: 筛选函数列表（AND 逻辑）

        Returns:
            筛选后的文件列表
        """
        from .api.strategies import FileTypeFilter

        mime_filters: list[str] = []
        ext_filters: list[str] = []

        if file_types:
            for ft in file_types:
                if ft in [e.value for e in FileTypeFilter]:
                    mime_filters.append(ft)
                    ext_filters.extend(FileTypeFilter(ft).get_extensions())
                else:
                    mime_filters.append(ft)

        result = []
        for i, f in enumerate(files):
            file_info = {
                "index": i + 1,
                "name": f.get("name", ""),
                "size": f.get("size", 0),
                "size_human": f.get("size_human", ""),
                "mime_type": f.get("mime_type", ""),
            }

            mime_type = f.get("mime_type", "")
            name = f.get("name", "").lower()

            # MIME 类型筛选（OR 逻辑）
            if mime_filters:
                matched = False
                if mime_type:
                    if any(mime_type.startswith(m) for m in mime_filters):
                        matched = True
                if not matched and ext_filters:
                    if any(name.endswith(e.lower()) for e in ext_filters):
                        matched = True
                if not matched:
                    continue
            elif ext_filters:
                if not any(name.endswith(e.lower()) for e in ext_filters):
                    continue

            # 自定义筛选器（AND 逻辑）
            if filters:
                for filter_func in filters:
                    if not filter_func(file_info):
                        break
                else:
                    result.append(file_info)
            else:
                result.append(file_info)

        # 重新设置索引
        for i, f in enumerate(result):
            f["index"] = i + 1

        return result

    async def get_devices(self):
        """获取远程设备"""
        return await self.remote.get_devices()

    async def get_device_tasks(self, device_name: str):
        """获取设备任务"""
        return await self.remote.get_device_tasks(device_name)

    async def create_download_task(self, url: str, device_name: str):
        """创建远程下载任务"""
        return await self.remote.create_download_task(url, device_name)

    def _create_downloader(
        self,
        max_concurrent: int = 3,
        chunk_size: int = 1024 * 1024,
        enable_resume: bool = True,
        max_retries: int = 3,
        timeout: int = 60,
        resume_fallback_to_new: bool = True,
        show_progress: bool = True,
        progress_callback: Callable[[DownloadProgress], None] | None = None,
    ) -> Downloader:
        """
        创建下载器实例

        Args:
            max_concurrent: 最大并发下载数
            chunk_size: 每次下载的块大小 (字节)
            enable_resume: 是否启用断点续传
            max_retries: 最大重试次数
            timeout: 下载超时时间（秒）
            resume_fallback_to_new: 断点续传失败时是否重新下载
            show_progress: 是否显示进度
            progress_callback: 自定义进度回调

        Returns:
            Downloader 实例
        """
        callback = progress_callback
        if show_progress and callback is None:
            callback = ConsoleProgressTracker(1, 0)

        return Downloader(
            cloud_disk=self._cloud,
            max_concurrent=max_concurrent,
            chunk_size=chunk_size,
            enable_resume=enable_resume,
            max_retries=max_retries,
            timeout=timeout,
            resume_fallback_to_new=resume_fallback_to_new,
            progress_callback=callback,
        )

    async def get_direct_link(
        self,
        target: str,
        skip_directory: bool = False,
        show_progress: bool = True,
    ) -> list[dict[str, Any]]:
        """
        获取文件或目录的直链下载链接

        Args:
            target: 文件/目录的路径或 ID
                   - 以 "/" 开头: 作为绝对路径处理
                   - 不以 "/" 开头: 作为 ID 处理
            skip_directory: 是否跳过目录（True=只获取当前层，False=递归获取子目录）
            show_progress: 是否显示进度

        Returns:
            直链信息列表，每项包含:
            {
                "id": str,                # 文件 ID
                "name": str,              # 文件名
                "size": int,              # 文件大小
                "path": str,              # 文件路径
                "parent_path": str,       # 父目录路径
                "web_content_link": str,  # 直链下载链接
            }

        Examples:
            # 获取单文件直链
            links = await xunlei.get_direct_link("/我的文档/电影.mp4")

            # 通过 ID 获取
            links = await xunlei.get_direct_link("file_id_xxx")

            # 获取目录直链（跳过子目录）
            links = await xunlei.get_direct_link("/我的备份", skip_directory=True)

            # 获取目录直链（递归获取所有子目录）
            links = await xunlei.get_direct_link("/我的备份", skip_directory=False)
        """
        is_path = target.startswith("/")

        if is_path:
            file_info = await self._cloud.get_file_info(target)
        else:
            file_info = await self._cloud.get_file_info_by_id(target)

        if not file_info:
            logger.warning(f"文件/目录不存在: {target}")
            return []

        kind = file_info.get("kind", "")
        file_id = file_info.get("id", "")
        file_name = file_info.get("name", "")

        if kind == "drive#folder":
            logger.info(f"正在获取目录直链: {file_name}")
            downloader = self._create_downloader(show_progress=show_progress)
            try:
                results = await downloader.get_directory_direct_links(
                    directory_id=file_id,
                    skip_directory=skip_directory,
                    show_progress=show_progress,
                )
                return results
            finally:
                await downloader.close()
        else:
            web_content_link = file_info.get("web_content_link", "")
            if not web_content_link:
                logger.warning(f"文件直链为空: {file_name}")
                return []

            return [
                {
                    "id": file_id,
                    "name": file_name,
                    "size": file_info.get("size", 0),
                    "path": target if is_path else file_name,
                    "parent_path": "",
                    "web_content_link": web_content_link,
                }
            ]

    async def download(
        self,
        target: str | list[str],
        local_dir: str,
        skip_directory: bool = False,
        max_concurrent: int = 3,
        chunk_size: int = 1024 * 1024,
        enable_resume: bool = True,
        max_retries: int = 3,
        timeout: int = 60,
        resume_fallback_to_new: bool = True,
        show_progress: bool = True,
        progress_callback: Callable[[DownloadProgress], None] | None = None,
    ) -> list[DownloadResult]:
        """
         下载文件或目录到本地

         Args:
             target: 文件/目录的路径、ID 或路径/ID列表
                    - 单个字符串: 作为绝对路径或 ID 处理
                    - 字符串列表: 批量下载多个文件/目录
                    - 以 "/" 开头: 作为绝对路径处理
                    - 不以 "/" 开头: 作为 ID 处理
             local_dir: 本地保存目录
             skip_directory: 是否跳过目录（True=只下载当前层，False=递归下载子目录）
             max_concurrent: 最大并发下载数
             chunk_size: 每次下载的块大小 (字节)
             enable_resume: 是否启用断点续传
             max_retries: 最大重试次数
             timeout: 下载超时时间（秒）
             resume_fallback_to_new: 断点续传失败时是否重新下载
             show_progress: 是否显示进度
             progress_callback: 自定义进度回调函数

         Returns:
             DownloadResult 列表，每个文件对应一个结果:
             [{
                 "success": bool,          # 是否成功
                 "file_id": str,           # 文件 ID
                 "file_name": str,         # 文件名
                 "local_path": str,        # 本地保存绝对路径
                 "file_size": int,         # 文件大小
                 "downloaded_bytes": int,  # 已下载字节数
                 "message": str,           # 结果描述
                 "task": str,              # 原始任务（下载的文件/目录路径）
                 "error": str | None,      # 错误信息
             }]

        转换为 JSON 的方式:
             # 方式1: 使用 to_dict() 方法
             results = await xunlei.download("/文档/文件.pdf", local_dir="D:/下载")
             dict_list = [r.to_dict() for r in results]
             json_str = json.dumps(dict_list, ensure_ascii=False, indent=2)

             # 方式2: 直接序列化（dataclass 支持）
             results = await xunlei.download("/文档/文件.pdf", local_dir="D:/下载")
             json_str = json.dumps([r.__dict__ for r in results], ensure_ascii=False, indent=2)

         Examples:
             # 下载单文件
             results = await xunlei.download(
                 "/我的文档/电影.mp4",
                 local_dir="D:/下载"
             )
             for r in results:
                 print(f"{r.file_name}: {r.message}")

             # 批量下载多个文件
             results = await xunlei.download(
                 ["/文档/文件1.pdf", "/文档/文件2.pdf"],
                 local_dir="D:/下载"
             )
             # 转换为 JSON
             import json
             json_data = [r.to_dict() for r in results]
             print(json.dumps(json_data, ensure_ascii=False, indent=2))

             # 下载目录（跳过子目录）
             results = await xunlei.download(
                 "/我的备份",
                 local_dir="D:/备份",
                 skip_directory=True
             )

             # 下载目录（递归下载所有子目录）
             results = await xunlei.download(
                 "/我的备份",
                 local_dir="D:/备份",
                 skip_directory=False
             )

             # 使用自定义进度回调
             def my_progress(progress):
                 print(f"进度: {progress.completed_files}/{progress.total_files}")

             results = await xunlei.download(
                 "/我的文档",
                 local_dir="D:/下载",
                 progress_callback=my_progress
             )
        """
        targets = [target] if isinstance(target, str) else target

        all_links = []
        failed_results: list[dict[str, Any]] = []
        for t in targets:
            links = await self.get_direct_link(
                target=t,
                skip_directory=skip_directory,
                show_progress=show_progress,
            )
            if links:
                for link in links:
                    link["task"] = t
                all_links.extend(links)
            else:
                failed_results.append(
                    DownloadResult(
                        success=False,
                        file_id="",
                        file_name=t.split("/")[-1] or t,
                        local_path="",
                        file_size=0,
                        downloaded_bytes=0,
                        message=f"文件/目录不存在或无法获取直链: {t}",
                        task=t,
                        error="NOT_FOUND",
                    )
                )

        if not all_links and not failed_results:
            logger.warning("没有获取到任何直链")
            return []

        total_files = len(all_links) + len(failed_results)
        total_bytes = sum(int(link.get("size", 0) or 0) for link in all_links)

        tracker = None
        if show_progress and progress_callback is None:
            tracker = ConsoleProgressTracker(total_files, total_bytes)
            progress_callback = tracker

        results: list[DownloadResult] = []
        results.extend(failed_results)

        if all_links:
            downloader = self._create_downloader(
                max_concurrent=max_concurrent,
                chunk_size=chunk_size,
                enable_resume=enable_resume,
                max_retries=max_retries,
                timeout=timeout,
                resume_fallback_to_new=resume_fallback_to_new,
                show_progress=False,
                progress_callback=progress_callback,
            )

            try:
                download_results = await downloader.download_multiple(
                    files=all_links,
                    local_dir=local_dir,
                    show_progress=False,
                )
                results.extend(download_results)
            finally:
                await downloader.close()

        if tracker:
            tracker.finish()

        return results

    def parse_share_link(self, share_link: str) -> tuple[str, str]:
        """
        解析分享链接，提取分享ID和提取码

        Args:
            share_link: 分享链接，格式:
                       - https://pan.xunlei.com/s/XXXXX?pwd=XXXX
                       - XXXXX (仅分享ID)

        Returns:
            (share_id, pass_code) 元组
        """
        import re

        share_id = ""
        pass_code = ""

        patterns = [
            r"pan\.xunlei\.com/s/([A-Za-z0-9_-]+)",
            r"/s/([A-Za-z0-9_-]+)",
        ]

        for pattern in patterns:
            match = re.search(pattern, share_link)
            if match:
                share_id = match.group(1)
                break

        pwd_match = re.search(r"[?&]pwd=([A-Za-z0-9]+)", share_link)
        if pwd_match:
            pass_code = pwd_match.group(1)

        return share_id, pass_code

    async def get_share_direct_links(
        self,
        share_link: str,
        skip_directory: bool = False,
        show_progress: bool = True,
    ) -> list[dict[str, Any]]:
        """
        获取分享链接的直链下载链接（通过中转方式）

        Args:
            share_link: 分享链接，格式:
                       - https://pan.xunlei.com/s/XXXXX?pwd=XXXX
                       - XXXXX (仅分享ID，需另外提供提取码)
            skip_directory: 是否跳过目录（True=只获取当前层，False=递归获取子目录）
            show_progress: 是否显示进度

        Returns:
            文件直链信息列表，每项包含:
            {
                "file_id": str,           # 转存后的文件ID
                "original_id": str,      # 原始分享文件ID
                "name": str,             # 文件名
                "size": int,             # 文件大小
                "web_content_link": str, # 直链下载链接
            }
        """
        share_id, pass_code = self.parse_share_link(share_link)
        if not share_id:
            logger.error(f"无法解析分享链接: {share_link}")
            return []

        if show_progress:
            print(f"正在获取分享链接信息: {share_id}...")

        share_info = await self.cloud.get_share_info(share_id, pass_code)
        if not share_info:
            logger.error("获取分享信息失败")
            return []

        files = share_info.get("files", [])
        if skip_directory:
            files = [f for f in files if f.get("kind") != "drive#folder"]

        if show_progress:
            print(f"分享文件数量: {len(files)}")

        downloader = self._create_downloader(show_progress=show_progress)
        try:
            links = await downloader.get_share_direct_links(
                share_id=share_id,
                pass_code=pass_code,
                skip_directory=skip_directory,
            )
            return links
        finally:
            await downloader.close()

    async def transfer_share(  # noqa: C901
        self,
        share_link: str | list[str],
        target_dir: str | list[str],
        select_files: Optional[Callable[[dict[str, Any]], bool]] = None,
        select_subfiles: Optional[Callable[[dict[str, Any]], bool]] = None,
        auto_create_dir: bool = True,
        on_exists: CloudFileExistsStrategy = CloudFileExistsStrategy.RENAME,
        on_capacity_exceeded: CapacityExceededStrategy = CapacityExceededStrategy.SKIP,
        on_own_share: TransferOwnShareStrategy = TransferOwnShareStrategy.SKIP,
        on_share_after_transfer: ShareAfterTransferStrategy = ShareAfterTransferStrategy.NO_CREATE,
        rename: str | Callable[[dict[str, Any]], str] | None = None,
        rename_subfiles: str | Callable[[dict[str, Any]], str] | None = None,
        rename_subfiles_timeout: float = 60.0,
        share_wait_timeout: float = 10.0,
        show_progress: bool = True,
    ) -> list[ShareTransferResult]:
        """
        转存分享链接文件到云盘指定目录

        Args:
            share_link: 分享链接或链接列表，格式:
                       - https://pan.xunlei.com/s/XXXXX?pwd=XXXX
                       - XXXXX (仅分享ID，需另外提供提取码)
                       - 列表: 批量转存多个分享链接
            target_dir: 目标目录路径或路径列表:
                       - "/" 表示根目录
                       - "/子目录" 表示绝对路径
                       - 文件夹 ID (不以 "/" 开头)
                       - 列表: 将每个分享链接的内容转存到所有目标目录（笛卡尔积）
                       - 不能为空
            select_files: 顶级项筛选器（仅筛选顶级文件/目录），
                         接收文件信息字典，返回 True 表示转存，False 表示跳过。
                        默认 None 表示转存所有顶级项目。
                        回调函数接收的参数示例:
                        {
                            "id": "xxx",
                            "name": "example.txt",
                            "size": 1024,
                            "kind": "drive#file",
                            "mime_type": "text/plain",
                            "created_time": "2024-01-01T00:00:00Z",
                            "modified_time": "2024-01-01T00:00:00Z",
                            "parent_id": "xxx"
                        }
                        预置过滤器 (从 xqcxunlei 导入):
                        - filter_only_files: 只转存文件，跳过目录
                        - filter_only_directories: 只转存目录，跳过文件
                        - filter_by_extension(["jpg", "png"]): 按扩展名过滤
                        - filter_by_size(min_size=1024): 按大小过滤
                        - filter_by_name_pattern("*.txt"): 按文件名模式匹配
                        - filter_exclude_by_name_pattern("*.tmp"): 排除匹配的文件
                        - filter_combine(f1, f2, ...): 组合多个过滤器
            select_subfiles: 子文件深度筛选器（仅当分享项为目录时生效）。
                           如果不设置，则使用 select_files 的筛选结果（如果有）。
                           如果设置，则在转存前递归获取目录内所有子文件，
                           根据此筛选器决定哪些子文件需要被转存。
                           重要：匹配成功的子文件会保留其完整的原始目录结构！
                           例如：目录 "电影" 下有 "动作/拳皇.mp4" 和 "喜剧/喜剧.mp4"，
                           如果设置 select_subfiles 只匹配 "动作" 相关文件，
                           则转存后目标目录会保留 "电影/动作/" 目录结构。
                           回调函数接收文件信息 dict，返回 True 表示转存该文件。
                           预置过滤器:
                           - name_contains_filter(["高清", "1080p"]): 文件名包含关键词
                           - name_excludes_filter(["预告片", "花絮"]): 文件名不包含关键词
                           - extension_filter([".mp4", ".mkv"]): 指定扩展名
                           - size_range_filter(min_size, max_size): 文件大小范围
            auto_create_dir: 当目录不存在时是否自动创建 (默认 True)
            on_exists: 目标目录存在相同文件时如何处理 (默认 CloudFileExistsStrategy.RENAME):
                          - SKIP: 跳过该文件，继续处理其他文件
                          - OVERWRITE: 覆盖已有文件（移到回收站）
                          - RENAME: 自动重命名（如 "文件.txt" → "文件 (1).txt"）
                          - ABORT_ALL: 预检查，有冲突则全部不执行，且中止所有后续转存
                          - ABORT_LOCAL: 预检查，有冲突则只中止当前组
            on_capacity_exceeded: 容量超限时如何处理 (默认 CapacityExceededStrategy.SKIP):
                                  - SKIP: 逐个转存，超出容量时跳过该文件
                                  - ABORT: 预检查总量，超容则中止全部操作
                                  - SMALL_FIRST: 小文件优先，能容纳的小文件优先转存
                                  - LARGE_FIRST: 大文件优先，空间不足时尝试转存小文件
            show_progress: 是否显示进度
            on_own_share: 转存自己的分享链接时如何处理 (默认 TransferOwnShareStrategy.SKIP):
                          - SKIP: 跳过该分享链接
                          - COPY: 使用复制 API 直接复制文件到目标目录
                          - MOVE: 使用移动 API 直接移动文件到目标目录
            on_share_after_transfer: 转存后是否自动创建分享链接
                                    (默认 ShareAfterTransferStrategy.NO_CREATE):
                                    - NO_CREATE: 不创建分享链接
                                    - CREATE: 只为转存后的顶级项创建分享链接
                                    - CREATE_ALL: 为所有项创建分享链接（包括子文件子目录）
            share_wait_timeout: 创建分享链接前等待文件生效的超时时间（秒），默认 10.0。
                                由于服务器同步延迟，转存后需要等待文件被索引才能创建分享链接。
            rename: 文件重命名规则，支持:
                    - str: 直接使用该字符串作为新文件名
                    - RenameFunc: 回调函数，接收文件信息 dict，返回新文件名
                    - None: 不重命名
                    预设回调函数:
                    - add_prefix(prefix): 添加前缀，支持列表如 add_prefix(["【", "高清", "】"])
                    - add_suffix(suffix): 添加后缀，支持列表如 add_suffix(["_", "720p"])
                    - replace_text(old, new): 替换文本，支持:
                       - 单个替换: replace_text("高清", "HD")
                       - 批量替换: replace_text(["高清", "标清"], ["HD", "4K"])
                       - 元组形式: replace_text(("高清", "HD"))
                    - remove_text(text): 移除文本，支持列表如 remove_text(["[广告]", "[预告片]"])
                    - regex_replace(pattern, repl): 正则替换如 regex_replace(r"\\[\\d+\\]", "")
                    - add_resolution(): 自动添加分辨率标识
            rename_subfiles: 目录内子文件的重命名规则（仅当转存项为目录时生效）。
                          转存完成后对目录内的子文件执行重命名。
                          如果不设置，则不对子文件进行重命名。
                          格式同 rename 参数。
            rename_subfiles_timeout: 子文件重命名等待超时时间（秒），默认 60.0。
                                    仅当 rename_subfiles 设置时生效。

        Returns:
            ShareTransferResult 列表，每个分享链接对应一个结果:
            [{
                "success": bool,              # 整体是否成功
                "share_id": str,             # 分享ID
                "pass_code": str,            # 提取码
                "target_dir": str,           # 目标目录
                "total_files": int,         # 总文件数
                "total_size": int,          # 总大小 (字节)
                "transferred_files": list[dict],    # 转存成功的文件详情列表
                    # 每项包含: file_id, file_name, file_size, original_path, current_path
                "skipped_files": list[dict],        # 跳过的文件详情列表
                    # 每项包含: file_id, file_name, file_size, reason
                "transferred_size": int,     # 转存大小
                "share_links": list[dict],  # 转存后创建的分享链接列表
                    # 每项包含: file_id, file_name, share_url, share_path
                "message": str,             # 结果描述
            }]

        转换为 JSON 的方式:
            # 方式1: 使用 to_dict() 方法
            results = await xunlei.transfer_share(share_link, target_dir="/我的文件夹")
            dict_list = [r.to_dict() for r in results]
            json_str = json.dumps(dict_list, ensure_ascii=False, indent=2)

            # 方式2: 直接序列化（dataclass 支持）
            results = await xunlei.transfer_share(share_link, target_dir="/我的文件夹")
            json_str = json.dumps([r.__dict__ for r in results], ensure_ascii=False, indent=2)

        Examples:
            # 转存单个分享链接到根目录
            results = await xunlei.transfer_share(
                "https://pan.xunlei.com/s/VOpr6qI3wDZFBqsf-2MdLYGyA1?pwd=eiyq",
                target_dir="/"
            )
            for r in results:
                print(f"{r.share_id}: {r.message}")

            # 批量转存多个分享链接
            results = await xunlei.transfer_share(
                [
                    "https://pan.xunlei.com/s/VOpr6qI3wDZFBqsf-2MdLYGyA1?pwd=eiyq",
                    "https://pan.xunlei.com/s/VOpAh4lr8Fx3M3N8QUw9b0gXA1?pwd=s43j",
                ],
                target_dir="/批量转存"
            )
            # 转换为 JSON
            import json
            json_data = [r.to_dict() for r in results]
            print(json.dumps(json_data, ensure_ascii=False, indent=2))
        """
        share_links = [share_link] if isinstance(share_link, str) else share_link
        target_dirs = [target_dir] if isinstance(target_dir, str) else target_dir

        results: list[ShareTransferResult] = []

        for link in share_links:
            for target in target_dirs:
                result = await self._transfer_single_share(
                    share_link=link,
                    target_dir=target,
                    select_files=select_files,
                    auto_create_dir=auto_create_dir,
                    on_capacity_exceeded=on_capacity_exceeded,
                    on_exists=on_exists,
                    show_progress=show_progress,
                    on_own_share=on_own_share,
                    on_share_after_transfer=on_share_after_transfer,
                    share_wait_timeout=share_wait_timeout,
                    rename=rename,
                    rename_subfiles=rename_subfiles,
                    rename_subfiles_timeout=rename_subfiles_timeout,
                    select_subfiles=select_subfiles,
                )
                if (
                    on_exists == CloudFileExistsStrategy.ABORT_ALL
                    and not result.success
                    and "中止" in result.message
                ):
                    results.append(result)
                    return results
                if (
                    on_exists == CloudFileExistsStrategy.ABORT_LOCAL
                    and not result.success
                    and "中止" in result.message
                ):
                    results.append(result)
                    continue
                results.append(result)

        return results

    async def _transfer_single_share(  # noqa: C901
        self,
        share_link: str,
        target_dir: str,
        select_files: Optional[Callable[[dict[str, Any]], bool]],
        select_subfiles: Optional[Callable[[dict[str, Any]], bool]],
        auto_create_dir: bool,
        on_exists: CloudFileExistsStrategy,
        on_capacity_exceeded: CapacityExceededStrategy,
        on_own_share: TransferOwnShareStrategy,
        on_share_after_transfer: ShareAfterTransferStrategy,
        rename: str | Callable[[dict[str, Any]], str] | None,
        rename_subfiles: str | Callable[[dict[str, Any]], str] | None,
        rename_subfiles_timeout: float,
        share_wait_timeout: float,
        show_progress: bool,
    ) -> ShareTransferResult:
        share_id, pass_code = self.parse_share_link(share_link)
        if not share_id:
            logger.error(f"无法解析分享链接: {share_link}")
            return ShareTransferResult(
                success=False,
                share_id="",
                pass_code="",
                task=share_link,
                target_dir=target_dir,
                message=f"无法解析分享链接: {share_link}",
            )

        if show_progress:
            print(f"开始处理分享链接: {share_id}")

        share_info = await self.cloud.get_share_info(share_id, pass_code)
        if not share_info:
            logger.error("获取分享信息失败")
            return ShareTransferResult(
                success=False,
                share_id=share_id,
                pass_code=pass_code,
                task=share_link,
                target_dir=target_dir,
                message="获取分享信息失败",
            )

        user_info = share_info.get("user_info", {})
        share_user_id = user_info.get("user_id", "")
        current_user_id = self.cloud.cache.tokens.user_id
        is_own_share = share_user_id == current_user_id

        if is_own_share:
            if on_own_share == TransferOwnShareStrategy.SKIP:
                logger.warning(f"跳过自己的分享链接: {share_id}")
                return ShareTransferResult(
                    success=False,
                    share_id=share_id,
                    pass_code=pass_code,
                    task=share_link,
                    transferred_files=[],
                    skipped_files=[],
                    total_files=0,
                    total_size=0,
                    target_dir=target_dir,
                    message="已跳过自己的分享链接（可设置 on_own_share=COPY/MOVE 处理）",
                )
            action_name = "复制" if on_own_share == TransferOwnShareStrategy.COPY else "移动"
            logger.info(f"检测到自己的分享链接，将使用 {action_name} 方式处理")

        files = share_info.get("files", [])
        if not files:
            return ShareTransferResult(
                success=False,
                share_id=share_id,
                pass_code=pass_code,
                task=share_link,
                transferred_files=[],
                skipped_files=[],
                total_files=0,
                total_size=0,
                target_dir=target_dir,
                message="分享链接无效或已失效",
            )

        all_files = files.copy()

        if select_files:
            filtered_files = []
            for f in all_files:
                try:
                    if select_files(f):
                        filtered_files.append(f)
                except Exception as e:
                    logger.warning(f"过滤器执行失败: {e}, 跳过文件 {f.get('name', '')}")
            all_files = filtered_files

        if select_subfiles:
            pass_code_token = share_info.get("pass_code_token", "")

            async def get_first_level_contents(
                share_id: str,
                folder_id: str,
                pass_code: str,
                pass_code_token: str,
            ) -> list[dict[str, Any]]:
                resp = await self.cloud.get(
                    self.cloud.config.share_detail_url,
                    params={
                        "share_id": share_id,
                        "parent_id": folder_id,
                        "pass_code_token": pass_code_token,
                        "limit": 100,
                        "page_token": "",
                        "thumbnail_size": "SIZE_SMALL",
                    },
                )
                if not resp:
                    return []
                return resp.get("files", [])

            if all_files and all_files[0].get("kind") == "drive#folder":
                root_folder = all_files[0]
                root_folder_id = root_folder.get("id", "")

                contents = await get_first_level_contents(
                    share_id, root_folder_id, pass_code, pass_code_token
                )

                matched_items: list[dict[str, Any]] = []
                for item in contents:
                    try:
                        if select_subfiles(item):
                            matched_items.append(item)
                    except Exception as e:
                        logger.warning(
                            f"子文件筛选器执行失败: {e}, 跳过文件 {item.get('name', '')}"
                        )

                if matched_items:
                    all_files = matched_items

        total_files = len(all_files)
        total_size = sum(int(f.get("size", 0) or 0) for f in all_files)

        if show_progress:
            print(f"分享文件数量: {total_files}, 总大小: {total_size} bytes")

        if total_files == 0:
            return ShareTransferResult(
                success=True,
                share_id=share_id,
                pass_code=pass_code,
                task=share_link,
                transferred_files=[],
                skipped_files=[],
                total_files=0,
                total_size=0,
                target_dir=target_dir,
                message="没有可转存的文件",
            )

        if on_capacity_exceeded != CapacityExceededStrategy.SKIP:
            space_info = await self.cloud.get_space_info()
            if space_info:
                free_space = space_info.get("free_space", 0)
                if total_size > free_space:
                    insufficient = total_size - free_space
                    if show_progress:
                        print(
                            f"容量不足: 需要 {total_size}, 可用 {free_space}, 不足 {insufficient}"
                        )
                    if on_capacity_exceeded == CapacityExceededStrategy.ABORT:
                        return ShareTransferResult(
                            success=False,
                            share_id=share_id,
                            pass_code=pass_code,
                            task=share_link,
                            total_files=total_files,
                            total_size=total_size,
                            target_dir=target_dir,
                            message="容量不足，操作已中止",
                        )

        target_parent_id = ""
        if target_dir and target_dir != "/":
            folder_info = await self.cloud.get_file_info(target_dir)
            if folder_info:
                target_parent_id = folder_info.get("id", "")
            elif auto_create_dir:
                result = await self.create_folder(target_dir, auto_create_parents=True)
                if result and result.get("success"):
                    target_parent_id = result.get("folder_id", "")
                    if show_progress:
                        print(f"已创建目录: {target_dir}")
                else:
                    return ShareTransferResult(
                        success=False,
                        share_id=share_id,
                        pass_code=pass_code,
                        task=share_link,
                        total_files=total_files,
                        total_size=total_size,
                        target_dir=target_dir,
                        message=f"无法创建目录: {target_dir}",
                    )

        transferred_files: list[dict[str, Any]] = []
        skipped_files: list[dict[str, Any]] = []
        transferred_size = 0

        if is_own_share and on_own_share in (
            TransferOwnShareStrategy.COPY,
            TransferOwnShareStrategy.MOVE,
        ):
            if on_exists in (
                CloudFileExistsStrategy.ABORT_ALL,
                CloudFileExistsStrategy.ABORT_LOCAL,
            ):
                existing_files = await self.cloud.get_files(parent_id=target_parent_id or "")
                existing_names = {f.get("name", "") for f in (existing_files or [])}
                duplicate_names = {
                    f.get("name", "") for f in all_files if f.get("name", "") in existing_names
                }
                if duplicate_names:
                    duplicate_list = ", ".join(list(duplicate_names)[:5])
                    if len(duplicate_names) > 5:
                        duplicate_list += f"... 等 {len(duplicate_names)} 个文件"
                    return ShareTransferResult(
                        success=False,
                        share_id=share_id,
                        pass_code=pass_code,
                        task=share_link,
                        total_files=total_files,
                        total_size=total_size,
                        target_dir=target_dir,
                        message=f"存在同名文件，中止操作: {duplicate_list}",
                    )

            for f in all_files:
                file_id = f.get("id", "")
                file_name = f.get("name", "")
                file_size = int(f.get("size", 0) or 0)

                if not file_id or not file_name:
                    continue

                file_info = await self.cloud.get_file_info_by_id(file_id)
                if not file_info:
                    skipped_files.append(
                        {
                            "file_id": file_id,
                            "file_name": file_name,
                            "file_size": file_size,
                            "reason": "无法获取文件信息",
                        }
                    )
                    if show_progress:
                        print(f"跳过 (无法获取文件信息): {file_name}")
                    continue

                parent_id = file_info.get("parent_id", "")
                file_path = await self.cloud._build_path(parent_id, file_info)

                if not file_path:
                    skipped_files.append(
                        {
                            "file_id": file_id,
                            "file_name": file_name,
                            "file_size": file_size,
                            "reason": "无法构建文件路径",
                        }
                    )
                    if show_progress:
                        print(f"跳过 (无法构建路径): {file_name}")
                    continue

                if on_exists == CloudFileExistsStrategy.SKIP:
                    existing_files = await self.cloud.get_files(parent_id=target_parent_id or "")
                    existing_names = {f.get("name", "") for f in (existing_files or [])}
                    if file_name in existing_names:
                        skipped_files.append(
                            {
                                "file_id": file_id,
                                "file_name": file_name,
                                "file_size": file_size,
                                "reason": "文件已存在",
                            }
                        )
                        if show_progress:
                            print(f"跳过 (已存在): {file_name}")
                        continue

                if on_exists == CloudFileExistsStrategy.OVERWRITE:
                    existing_files = await self.cloud.get_files(parent_id=target_parent_id or "")
                    existing_file_map = {f.get("name", ""): f for f in (existing_files or [])}
                    if file_name in existing_file_map:
                        existing_file_id = existing_file_map[file_name].get("id", "")
                        if existing_file_id:
                            await self.cloud.delete(existing_file_id)
                            if show_progress:
                                print(f"已移到回收站: {file_name}")

                copy_func = (
                    self.cloud.move
                    if on_own_share == TransferOwnShareStrategy.MOVE
                    else self.cloud.copy
                )
                action_name = "移动" if on_own_share == TransferOwnShareStrategy.MOVE else "复制"
                result = await copy_func(
                    source=file_path,
                    target_parent=target_parent_id or "/",
                    on_exists=on_exists,
                )

                if result and result.get("success", False):
                    new_file_id = result.get("file_id", "") or result.get("id", "")
                    current_path = (
                        target_dir.rstrip("/") + "/" + file_name
                        if target_dir != "/"
                        else "/" + file_name
                    )
                    if new_file_id == file_id:
                        for _ in range(3):
                            await asyncio.sleep(1)
                            parent_files = await self.cloud.get_files(
                                parent_id=target_parent_id or ""
                            )
                            if parent_files:
                                for pf in parent_files:
                                    if pf.get("name", "") == file_name:
                                        new_file_id = pf.get("id", "")
                                        break
                            if new_file_id != file_id:
                                break
                    if new_file_id == file_id:
                        new_file_id = ""
                    if not new_file_id:
                        new_file_id = file_id
                    transferred_files.append(
                        {
                            "file_id": new_file_id,
                            "file_name": file_name,
                            "file_size": file_size,
                            "original_path": file_path,
                            "current_path": current_path,
                        }
                    )
                    transferred_size += file_size
                    if show_progress:
                        print(f"{action_name}成功: {file_name} ({file_size} bytes)")
                else:
                    skipped_files.append(
                        {
                            "file_id": file_id,
                            "file_name": file_name,
                            "file_size": file_size,
                            "reason": f"{action_name}失败",
                        }
                    )
                    if show_progress:
                        print(f"{action_name}失败: {file_name}")

                await asyncio.sleep(0.2)

            success = len(transferred_files) > 0 and len(skipped_files) == 0

            if (
                on_share_after_transfer != ShareAfterTransferStrategy.NO_CREATE
                and transferred_files
            ):
                for tf in transferred_files:
                    file_id = tf.get("file_id", "")
                    file_name = tf.get("file_name", "")
                    file_info = None
                    wait_start = asyncio.get_event_loop().time()
                    while asyncio.get_event_loop().time() - wait_start < share_wait_timeout:
                        file_info = await self.cloud.get_file_info_by_id(file_id)
                        if file_info:
                            break
                        await asyncio.sleep(1)
                    if file_id and file_info:
                        share_result = await self.cloud.create_share_link(
                            file_id=file_id,
                            on_exists=ShareLinkStrategy.RECREATE,
                        )
                        if share_result.get("success", False):
                            share_links = share_result.get("share_links", [])
                            share_url = share_links[0] if share_links else ""
                            tf["share_url"] = share_url
                            if show_progress:
                                print(f"已创建分享链接: {file_name} -> {share_url}")
                        await asyncio.sleep(0.1)

            return ShareTransferResult(
                success=success,
                share_id=share_id,
                pass_code=pass_code,
                task=share_link,
                transferred_files=transferred_files,
                skipped_files=skipped_files,
                total_files=total_files,
                total_size=total_size,
                transferred_size=transferred_size,
                target_dir=target_dir,
                message=f"{action_name}完成",
            )

        if on_exists in (CloudFileExistsStrategy.ABORT_ALL, CloudFileExistsStrategy.ABORT_LOCAL):
            existing_files = await self.cloud.get_files(parent_id=target_parent_id or "")
            existing_names = {f.get("name", "") for f in (existing_files or [])}
            duplicate_names = {
                f.get("name", "") for f in all_files if f.get("name", "") in existing_names
            }
            if duplicate_names:
                duplicate_list = ", ".join(list(duplicate_names)[:5])
                if len(duplicate_names) > 5:
                    duplicate_list += f"... 等 {len(duplicate_names)} 个文件"
                return ShareTransferResult(
                    success=False,
                    share_id=share_id,
                    pass_code=pass_code,
                    task="transfer_share",
                    total_files=total_files,
                    total_size=total_size,
                    target_dir=target_dir,
                    message=f"存在同名文件，中止操作: {duplicate_list}",
                )

        if not is_own_share:
            file_ids_to_transfer = [f.get("id", "") for f in all_files if f.get("id")]
            if file_ids_to_transfer:
                if show_progress:
                    print(f"批量转存 {len(file_ids_to_transfer)} 个文件...")
                success = await self.cloud.transfer_share(
                    share_id=share_id,
                    pass_code=pass_code,
                    target_parent_id=target_parent_id or "",
                    file_ids=file_ids_to_transfer,
                )
                if success:
                    for f in all_files:
                        file_id = f.get("id", "")
                        file_name = f.get("name", "")
                        file_size = int(f.get("size", 0) or 0)
                        transferred_files.append(
                            {
                                "file_id": file_id,
                                "file_name": file_name,
                                "file_size": file_size,
                                "original_path": "",
                                "current_path": (
                                    target_dir.rstrip("/") + "/" + file_name
                                    if target_dir != "/"
                                    else "/" + file_name
                                ),
                            }
                        )
                        transferred_size += file_size
                        if show_progress:
                            print(f"转存成功: {file_name} ({file_size} bytes)")
                else:
                    if show_progress:
                        print("批量转存失败")

                return ShareTransferResult(
                    success=success,
                    share_id=share_id,
                    pass_code=pass_code,
                    task=share_link,
                    transferred_files=transferred_files,
                    skipped_files=skipped_files,
                    total_files=total_files,
                    total_size=total_size,
                    transferred_size=transferred_size,
                    target_dir=target_dir,
                    message="转存完成" if success else "转存失败",
                )

        def apply_rename(file_info: dict[str, Any], rename_func) -> str:
            if rename_func is None:
                return file_info.get("name", "")
            if isinstance(rename_func, str):
                return rename_func
            return rename_func(file_info)

        folders_to_create: list[tuple[str, str]] = []
        files_to_transfer: list[dict[str, Any]] = []

        for f in all_files:
            if "_parent_folder_name" in f:
                parent_folder_name = f.get("_parent_folder_name", "")
                sub_file_path = f.get("path", "")
                folder_rel_path = ""
                if sub_file_path:
                    parts = sub_file_path.split("/")
                    folder_rel_path = "/".join(parts[:-1]) if len(parts) > 1 else ""
                elif parent_folder_name:
                    folder_rel_path = ""
                if parent_folder_name:
                    folders_to_create.append((parent_folder_name, folder_rel_path))
                files_to_transfer.append(f)
            else:
                files_to_transfer.append(f)

        created_folders: dict[str, str] = {}
        for parent_name, rel_path in folders_to_create:
            if rel_path:
                full_dir_name = f"{parent_name}/{rel_path}"
            else:
                full_dir_name = parent_name
            if full_dir_name not in created_folders:
                parent_id = target_parent_id or ""
                path_parts = rel_path.split("/") if rel_path else []
                if not path_parts:
                    if parent_name not in created_folders:
                        existing = await self.cloud.get_files(parent_id=parent_id)
                        existing_map = {ex.get("name", ""): ex for ex in (existing or [])}
                        if parent_name in existing_map:
                            created_folders[full_dir_name] = existing_map[parent_name].get("id", "")
                        else:
                            new_dir = await self.cloud.create_folder(parent_name, parent_id)
                            if new_dir:
                                created_folders[full_dir_name] = new_dir.get("id", "")
                else:
                    current_parent_id = parent_id
                    for i, part in enumerate(path_parts):
                        current_dir_name = "/".join(path_parts[: i + 1])
                        if current_dir_name not in created_folders:
                            existing = await self.cloud.get_files(parent_id=current_parent_id)
                            existing_map = {ex.get("name", ""): ex for ex in (existing or [])}
                            if part in existing_map:
                                current_parent_id = existing_map[part].get("id", "")
                                created_folders[current_dir_name] = current_parent_id
                            else:
                                new_dir = await self.cloud.create_folder(part, current_parent_id)
                                if new_dir:
                                    current_parent_id = new_dir.get("id", "")
                                    created_folders[current_dir_name] = current_parent_id
                                else:
                                    logger.warning(f"创建目录失败: {part}")
                                    break
                        else:
                            current_parent_id = created_folders[current_dir_name]
                    created_folders[full_dir_name] = current_parent_id

        for f in files_to_transfer:
            file_id = f.get("id", "")
            file_name = f.get("name", "")
            file_size = int(f.get("size", 0) or 0)
            parent_folder_name = f.get("_parent_folder_name", "")

            if rename is not None and not parent_folder_name:
                file_name = apply_rename(f, rename)
                f["name"] = file_name

            if parent_folder_name and rename_subfiles is not None:
                file_name = apply_rename(f, rename_subfiles)
                f["name"] = file_name

            current_target_parent_id = target_parent_id
            if parent_folder_name:
                sub_path = f.get("path", "")
                parts = sub_path.split("/")
                rel_path = "/".join(parts[:-1]) if len(parts) > 1 else ""
                if rel_path:
                    full_dir_name = f"{parent_folder_name}/{rel_path}"
                    current_target_parent_id = created_folders.get(full_dir_name, target_parent_id)
                else:
                    full_dir_name = parent_folder_name
                    current_target_parent_id = created_folders.get(full_dir_name, target_parent_id)

            if not file_id or not file_name:
                continue

            if on_exists == CloudFileExistsStrategy.SKIP:
                existing_files = await self.cloud.get_files(
                    parent_id=current_target_parent_id or ""
                )
                existing_names = {f.get("name", "") for f in (existing_files or [])}
                if file_name in existing_names:
                    skipped_files.append(
                        {
                            "file_id": file_id,
                            "file_name": file_name,
                            "file_size": file_size,
                            "reason": "文件已存在",
                        }
                    )
                    if show_progress:
                        print(f"跳过 (已存在): {file_name}")
                    continue

            if on_exists == CloudFileExistsStrategy.OVERWRITE:
                existing_files = await self.cloud.get_files(
                    parent_id=current_target_parent_id or ""
                )
                existing_file_map = {f.get("name", ""): f for f in (existing_files or [])}
                if file_name in existing_file_map:
                    existing_file_id = existing_file_map[file_name].get("id", "")
                    if existing_file_id:
                        await self.cloud.delete(existing_file_id)
                        if show_progress:
                            print(f"已移到回收站: {file_name}")

            if (
                on_capacity_exceeded == CapacityExceededStrategy.SKIP
                and transferred_size + file_size > 0
            ):
                space_info = await self.cloud.get_space_info()
                if space_info:
                    free_space = space_info.get("free_space", 0)
                    if transferred_size + file_size > free_space:
                        insufficient = transferred_size + file_size - free_space
                        skipped_files.append(
                            {
                                "file_id": file_id,
                                "file_name": file_name,
                                "file_size": file_size,
                                "reason": "容量不足",
                            }
                        )
                        if show_progress:
                            print(f"跳过 (容量不足): {file_name} ({file_size} bytes)")
                        continue

            success = await self.cloud.transfer_share(
                share_id=share_id,
                pass_code=pass_code,
                target_parent_id=current_target_parent_id,
                file_ids=[file_id],
            )

            if success:
                current_path = (
                    target_dir.rstrip("/") + "/" + file_name
                    if target_dir != "/"
                    else "/" + file_name
                )
                new_file_id = file_id
                for retry in range(int(share_wait_timeout)):
                    new_file_info = await self.cloud.get_file_info(current_path)
                    if new_file_info:
                        new_file_id = new_file_info.get("id", file_id)
                        if new_file_id != file_id:
                            break
                    if retry < int(share_wait_timeout) - 1:
                        await asyncio.sleep(1)
                transferred_files.append(
                    {
                        "file_id": new_file_id,
                        "file_name": file_name,
                        "file_size": file_size,
                        "original_path": "",
                        "current_path": current_path,
                    }
                )
                transferred_size += file_size
                if show_progress:
                    print(f"转存成功: {file_name} ({file_size} bytes)")
            else:
                skipped_files.append(
                    {
                        "file_id": file_id,
                        "file_name": file_name,
                        "file_size": file_size,
                        "reason": "转存失败",
                    }
                )
                if show_progress:
                    print(f"转存失败: {file_name}")

            await asyncio.sleep(0.2)

        success = len(transferred_files) > 0 and len(skipped_files) == 0

        if on_share_after_transfer != ShareAfterTransferStrategy.NO_CREATE and transferred_files:
            for tf in transferred_files:
                file_id = tf.get("file_id", "")
                file_name = tf.get("file_name", "")
                file_info = None
                wait_start = asyncio.get_event_loop().time()
                while asyncio.get_event_loop().time() - wait_start < share_wait_timeout:
                    file_info = await self.cloud.get_file_info_by_id(file_id)
                    if file_info:
                        break
                    await asyncio.sleep(1)
                if file_id and file_info:
                    share_result = await self.cloud.create_share_link(
                        file_id=file_id,
                        on_exists=ShareLinkStrategy.RECREATE,
                    )
                    if share_result.get("success", False):
                        share_links = share_result.get("share_links", [])
                        share_url = share_links[0] if share_links else ""
                        tf["share_url"] = share_url
                        if show_progress:
                            print(f"已创建分享链接: {file_name} -> {share_url}")
                    await asyncio.sleep(0.1)

        if rename_subfiles is not None and transferred_files:

            def apply_subfile_rename(file_info: dict[str, Any], rename_func) -> str:
                if isinstance(rename_func, str):
                    return rename_func
                return rename_func(file_info)

            if show_progress:
                print("开始对转存文件应用子文件重命名规则...")
            for tf in transferred_files:
                file_id = tf.get("file_id", "")
                file_name = tf.get("file_name", "")
                current_path = tf.get("current_path", "")
                if not current_path:
                    continue
                file_info = await self.cloud.get_file_info(current_path)
                if not file_info:
                    continue
                kind = file_info.get("kind", "")
                if kind == "drive#folder":
                    if show_progress:
                        print(f"处理目录: {file_name}")
                    sub_timeout = rename_subfiles_timeout
                    start_time = asyncio.get_event_loop().time()
                    sub_files_collected = False
                    while asyncio.get_event_loop().time() - start_time < sub_timeout:
                        sub_files = await self.cloud.get_files(parent_id=file_id)
                        if sub_files:
                            sub_files_collected = True
                            break
                        await asyncio.sleep(1)
                    if not sub_files_collected:
                        if show_progress:
                            print(f"获取子文件超时: {file_name}")
                        continue
                    for sf in sub_files:
                        sf_id = sf.get("id", "")
                        sf_name = sf.get("name", "")
                        if not sf_id or not sf_name:
                            continue
                        try:
                            new_name = apply_subfile_rename(sf, rename_subfiles)
                            if new_name != sf_name:
                                rename_result = await self.cloud.rename(
                                    sf_name, new_name, current_path, False
                                )
                                if rename_result and show_progress:
                                    print(f"重命名: {sf_name} -> {new_name}")
                        except Exception as e:
                            if show_progress:
                                print(f"重命名失败: {sf_name}, 错误: {e}")

        return ShareTransferResult(
            success=success,
            share_id=share_id,
            pass_code=pass_code,
            task=share_link,
            transferred_files=transferred_files,
            skipped_files=skipped_files,
            total_files=total_files,
            total_size=total_size,
            transferred_size=transferred_size,
            target_dir=target_dir,
            message=f"转存完成: {len(transferred_files)}/{total_files} 个文件",
        )

    async def download_share(
        self,
        share_link: str,
        local_dir: str,
        skip_directory: bool = False,
        auto_delete: bool = True,
        max_concurrent: int = 3,
        chunk_size: int = 1024 * 1024,
        enable_resume: bool = True,
        show_progress: bool = True,
        progress_callback: Callable[[DownloadProgress], None] | None = None,
    ) -> list[DownloadResult]:
        """
        下载分享链接文件到本地（通过中转方式）

        Args:
            share_link: 分享链接，格式:
                       - https://pan.xunlei.com/s/XXXXX?pwd=XXXX
                       - XXXXX (仅分享ID，需另外提供提取码)
            local_dir: 本地保存目录
            skip_directory: 是否跳过目录（True=只下载当前层，False=递归下载子目录）
            auto_delete: 下载完成后是否自动删除中转文件
            max_concurrent: 最大并发下载数
            chunk_size: 每次下载的块大小 (字节)
            enable_resume: 是否启用断点续传
            show_progress: 是否显示进度
            progress_callback: 自定义进度回调函数

        Returns:
            下载结果列表，每项包含:
            {
                "success": bool,          # 是否成功
                "file_id": str,           # 文件ID
                "file_name": str,         # 文件名
                "local_path": str,        # 本地保存路径
                "file_size": int,         # 文件大小
                "downloaded_bytes": int,  # 已下载字节数
                "message": str,           # 结果描述
                "error": str | None,      # 错误信息
            }
        """
        share_id, pass_code = self.parse_share_link(share_link)
        if not share_id:
            logger.error(f"无法解析分享链接: {share_link}")
            return [
                DownloadResult(
                    success=False,
                    file_id="",
                    file_name="",
                    local_path=local_dir,
                    file_size=0,
                    downloaded_bytes=0,
                    message="",
                    error=f"无法解析分享链接: {share_link}",
                )
            ]

        if show_progress:
            print(f"开始处理分享链接: {share_id}")

        options = ShareDownloadOptions(
            skip_directory=skip_directory,
            auto_delete=auto_delete,
            delete_after_completed=auto_delete,
            max_concurrent=max_concurrent,
            chunk_size=chunk_size,
            enable_resume=enable_resume,
            show_progress=show_progress,
        )

        tracker = None
        if show_progress and progress_callback is None:
            tracker = ConsoleProgressTracker(0, 0)
            progress_callback = tracker

        downloader = self._create_downloader(
            max_concurrent=max_concurrent,
            chunk_size=chunk_size,
            enable_resume=enable_resume,
            show_progress=False,
            progress_callback=progress_callback,
        )

        try:
            results = await downloader.download_share_link(
                share_id=share_id,
                pass_code=pass_code,
                local_dir=local_dir,
                options=options,
            )
            return results
        finally:
            await downloader.close()
            if tracker:
                tracker.finish()

    async def create_share_link(  # noqa: C901
        self,
        targets: str | list[str] | Callable[[dict[str, Any]], bool],
        valid_days: int = -1,
        extraction_times: int = -1,
        with_passcode: bool = True,
        on_exists: Any = None,
        scope: str | list[str] = "/",
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        创建分享链接（支持单条和批量操作）

        设计说明:
            targets 参数支持多种输入形式（智能自动识别）：
              1. 单个路径字符串：如 "/我的资源/电影.mp4"
              2. 多个路径列表：如 ["/我的资源/电影1.mp4", "/我的资源/电影2.mp4"]
              3. 单个文件 ID 字符串：如 "VNv5Ol2sxliNst19L1IRVi4OA1"
              4. 文件 ID 列表：如 ["id1", "id2"]
              5. 混合列表：如 ["/路径/文件", "VNv5Ol2sxli...", "/另一个路径"]
              6. 回调函数：用于智能筛选要处理的文件，签名为 Callable[[dict], bool]
                  回调函数接收的字典示例：
                  {
                      "id": "VNv5Ol2sxliNst19L1IRVi4OA1",  # 文件/目录ID
                      "name": "电影.mp4",                  # 文件/目录名称
                      "path": "/我的资源/电影.mp4",        # 完整路径
                      "kind": "drive#file",               # 类型（drive#file 或 drive#folder）
                      "size": 1024000,                    # 文件大小（字节）
                      "created_time": "2024-01-01T00:00:00Z",  # 创建时间
                      "modified_time": "2024-01-01T00:00:00Z",  # 修改时间
                  }
            scope 参数用于设定回调函数筛选的范围（当 targets 为回调函数时生效）：
              1. "/"：遍历整个云盘（默认）
              2. 单个目录路径：如 "/我的资源"
              3. 目录路径列表：如 ["/电影", "/音乐"]

        Args:
            targets: 文件/目录路径或 ID（支持路径、ID、路径列表、ID列表、混合列表、或回调函数）
                    当为回调函数时，会在 scope 指定的范围内筛选文件
            valid_days: 有效天数 (-1 永久，1-7 指定天数)
            extraction_times: 提取次数 (-1 无限制，1-20 指定次数)
            with_passcode: 是否需要提取码
            on_exists: 分享链接已存在时的策略
                      - SKIP: 存在就不重复创建，返回现有的携带提取码的完整分享链接
                      - RECREATE: 创建一个新的，返回新建和现有的所有链接（新建的在第一个位置）
                      - OVERWRITE: 删除现有的所有分享链接，然后创建一个新的
                      默认为 SKIP
            scope: 回调函数筛选的范围（当 targets 为回调函数时生效）
                  - "/"：遍历整个云盘（默认）
                  - "/目录1": 在指定目录及其子目录中筛选
                  - ["/目录1", "/目录2"]: 在多个目录及其子目录中筛选

        Returns:
            单条操作返回字典:
            {
                "success": bool,          # 是否成功
                "share_links": list,      # 所有分享链接列表（携带提取码的完整链接）
                "newly_created": bool,    # 是否新创建的
                "file_id": str,          # 文件/目录ID
                "file_name": str,        # 文件/目录名称
                "path": str,             # 文件/目录完整路径
                "message": str,          # 结果描述
            }
            批量操作返回结果列表
        """
        from .api import ShareLinkStrategy

        if on_exists is None:
            on_exists = ShareLinkStrategy.SKIP

        def _is_file_id(s: str) -> bool:
            return s.startswith("VN") or s.startswith("VO") or s.startswith("V")

        def _normalize_scope(s: str | list[str]) -> list[str]:
            if isinstance(s, list):
                return [p if p else "/" for p in s]
            return [s if s else "/"]

        def _get_search_paths(scope_paths: list[str]) -> list[str]:
            paths = []
            for sp in scope_paths:
                if sp == "/" or sp == "":
                    paths.append("")
                else:
                    paths.append(sp.rstrip("/"))
            return paths

        async def _process_single(fid: str, fname: str, fpath: str = "") -> dict[str, Any]:
            result = await self.cloud.create_share_link(
                file_id=fid,
                valid_days=valid_days,
                extraction_times=extraction_times,
                with_passcode=with_passcode,
                on_exists=on_exists,
            )
            result["file_name"] = fname
            result["path"] = fpath
            return result

        async def _create_for_path(p: str) -> dict[str, Any]:
            file_info = await self.get_file_info(p)
            if not file_info:
                return {
                    "success": False,
                    "share_links": [],
                    "newly_created": False,
                    "file_id": "",
                    "file_name": "",
                    "path": p,
                    "message": f"文件/目录不存在: {p}",
                }
            fid = file_info.get("id", "")
            fname = file_info.get("name", "")
            result = await _process_single(fid, fname, p)
            return result

        async def _create_for_file_id(fid: str) -> dict[str, Any]:
            file_info = await self.cloud.get_file_info_by_id(fid)
            fname = file_info.get("name", "") if file_info else ""
            fpath = file_info.get("path", "") if file_info else ""
            result = await _process_single(fid, fname, fpath)
            return result

        if callable(targets) and not isinstance(targets, str):
            scope_paths = _get_search_paths(_normalize_scope(scope))
            all_files: list[dict[str, Any]] = []
            for sp in scope_paths:
                search_result = await self.cloud.search(
                    callback=lambda f: True, path=sp if sp else None
                )
                if isinstance(search_result, list):
                    all_files.extend(search_result)
                else:
                    all_files.extend(search_result.get("files", []))
            filtered_files = [f for f in all_files if targets(f)]
            results = []
            for f in filtered_files:
                p = f.get("path", "")
                fid = f.get("id", "")
                if p:
                    result = await _create_for_path(p)
                elif fid:
                    result = await _create_for_file_id(fid)
                else:
                    continue
                if result.get("success"):
                    results.append(result)
            return results

        if isinstance(targets, list):
            results = []
            for t in targets:
                if _is_file_id(t):
                    result = await _create_for_file_id(t)
                else:
                    result = await _create_for_path(t)
                results.append(result)
            return results

        if isinstance(targets, str) and targets:
            if _is_file_id(targets):
                return await _create_for_file_id(targets)
            return await _create_for_path(targets)

        return {
            "success": False,
            "share_links": [],
            "newly_created": False,
            "file_id": "",
            "file_name": "",
            "path": "",
            "message": "targets 不能为空",
        }

    async def get_share_info(  # noqa: C901
        self,
        targets: str | list[str] | Callable[[dict[str, Any]], bool],
        scope: str | list[str] = "/",
        save_to_file: Optional[str] = None,
        return_all: bool = False,
        auto_create: bool = False,
        cache_strategy: CacheStrategy = CacheStrategy.PERSISTENT,
        cache_ttl: int = DEFAULT_CACHE_TTL,
        cache_dir: Optional[str] = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        查询分享信息（支持单条和批量操作）

        注意：
            - 查询自己创建的分享链接：返回完整信息，包括分享文件列表
              （total_size, total_files, files）
            - 查询他人分享的链接：返回基本信息，通过 file_id 查询获取
              单文件大小，files 为空列表

        设计说明:
            targets 参数支持多种输入形式（智能自动识别）：
              1. 单个路径字符串：如 "/我的资源/电影.mp4"
              2. 多个路径列表：如 ["/我的资源/电影1.mp4", "/我的资源/电影2.mp4"]
              3. 单个文件 ID 字符串：如 "VNv5Ol2sxliNst19L1IRVi4OA1"
              4. 文件 ID 列表：如 ["id1", "id2"]
              5. 单个分享 ID 字符串：如 "VNv5Ol2sxliNst19L1IRVi4OA1"
              6. 分享 ID 列表：如 ["sid1", "sid2"]
              7. 完整分享链接（带或不带提取码）：如 "https://pan.xunlei.com/s/VOxxx?pwd=xxxx"
              8. 混合列表：如 ["/路径/文件", "VNv5Ol2sxli...", "https://pan.xunlei.com/s/VOxxx?pwd=xxxx"]
              9. 回调函数：用于智能筛选要查询的文件，签名为 Callable[[dict], bool]
                  回调函数接收的字典示例：
                  {
                      "id": "VNv5Ol2sxliNst19L1IRVi4OA1",  # 文件/目录ID
                      "name": "电影.mp4",                  # 文件/目录名称
                      "path": "/我的资源/电影.mp4",        # 完整路径
                      "kind": "drive#file",               # 类型（drive#file 或 drive#folder）
                      "size": 1024000,                    # 文件大小（字节）
                      "created_time": "2024-01-01T00:00:00Z",  # 创建时间
                      "modified_time": "2024-01-01T00:00:00Z",  # 修改时间
                  }
            scope 参数用于设定回调函数筛选的范围（当 targets 为回调函数时生效）：
              1. "/"：遍历整个云盘（默认）
              2. 单个目录路径：如 "/我的资源"
              3. 目录路径列表：如 ["/电影", "/音乐"]

            返回结果格式：
            {
                "success": bool,          # 是否成功
                "has_share": bool,       # 是否已分享
                "task": str,             # 原始查询内容
                "share_links": [         # 分享链接列表
                    {
                        "share_url": str,         # 带提取码的完整分享链接
                        "is_valid": bool,         # 是否有效（share_status=="OK"表示正常）
                        "expire_time": str,       # 过期时间
                        "remaining_count": int,   # 剩余提取次数（-1表示无限制）
                        "created_at": str,        # 创建时间
                    }
                ],
                "share_count": int,     # 分享链接数量
                "file_id": str,          # 文件/目录ID
                "file_name": str,        # 文件/目录名称
                "path": str,            # 文件完整路径（仅自己分享时有）
                "is_own_share": bool,    # 是否为当前用户的分享
                "owner_user_id": str,    # 分享者用户ID
                "owner_nickname": str,   # 分享者昵称
                "total_size": int,      # 文件总大小（字节）
                "total_files": int,     # 文件总数（不含目录）
                "files": list,          # 文件详细信息列表
                "message": str,         # 结果描述
            }

        Args:
            targets: 文件/目录路径、ID、分享ID 或完整分享链接
                    （支持路径、ID、分享链接、列表、混合列表、或回调函数）
                    回调函数时在 scope 范围内筛选
            scope: 回调函数筛选的范围（当 targets 为回调函数时生效）
                  - "/"：遍历整个云盘（默认）
                  - "/目录1": 在指定目录及其子目录中筛选
                  - ["/目录1", "/目录2"]: 在多个目录及其子目录中筛选
            save_to_file: 保存到文件（CSV 或 TXT 格式）
            return_all: 是否返回所有分享链接，False 只返回最新一个（默认），True 返回全部
            auto_create: 当文件未分享时是否自动创建，False 不创建（默认），True 自动创建
            cache_strategy: 缓存策略枚举
                  - CacheStrategy.DISABLED: 完全不使用缓存
                  - CacheStrategy.SESSION: 会话级缓存，仅在当前请求周期内有效
                  - CacheStrategy.PERSISTENT: 持久化缓存，存入文件，支持增量更新（默认）
            cache_ttl: 缓存有效期（秒），默认 7200 秒（2小时）
            cache_dir: 缓存文件目录，默认为 ".xqcxunlei_cache_{账号}"

        Returns:
            返回结果见设计说明

        缓存策略说明:
            1. disabled（默认）：不使用缓存，每次都从服务器获取
            2. session：会话级缓存，仅在当前请求周期内有效
               - 程序重启后缓存失效
            3. persistent：持久化缓存，存入文件
               - 支持增量更新
               - 程序重启后缓存仍然有效
               - 不占用内存（按需从文件加载）

            每次调用最多只会触发一次服务器请求。
        """
        import json
        import time
        from dataclasses import asdict, dataclass
        from pathlib import Path

        import aiofiles

        @dataclass
        class InlineShareCacheEntry:
            """简化版缓存条目"""

            file_id: str
            path: str
            share_links: list
            share_count: int
            success: bool
            message: str
            cached_at: float = 0
            anchor_share_id: str = ""

        cache_dir_path = cache_dir or f"{DEFAULT_CACHE_DIR}_{self.username}"
        cache_file_path = Path(cache_dir_path) / "share_cache.json"

        async def _load_cache() -> dict[str, InlineShareCacheEntry]:
            if not cache_file_path.exists():
                return {}
            try:
                async with aiofiles.open(cache_file_path, "r", encoding="utf-8") as f:
                    content = await f.read()
                    data = json.loads(content)
                    result = {}
                    for k, v in data.items():
                        result[k] = InlineShareCacheEntry(**v)
                    return result
            except Exception:
                return {}

        async def _save_cache(cache_data: dict[str, InlineShareCacheEntry]) -> None:
            try:
                cache_file_path.parent.mkdir(parents=True, exist_ok=True)
                data = {k: asdict(v) for k, v in cache_data.items()}
                async with aiofiles.open(cache_file_path, "w", encoding="utf-8") as f:
                    await f.write(json.dumps(data, ensure_ascii=False, indent=2))
            except Exception:
                pass

        def _is_share_id(s: str) -> bool:
            return len(s) > 10 and s.startswith("V")

        def _is_share_link(s: str) -> bool:
            return "pan.xunlei.com/s/" in s

        def _extract_share_id(s: str) -> tuple[str, str]:
            """
            从分享链接中提取分享ID和提取码

            Returns:
                (share_id, pass_code) 元组
            """
            import re

            patterns = [
                r"pan\.xunlei\.com/s/([A-Za-z0-9_-]+)",
                r"/s/([A-Za-z0-9_-]+)",
            ]

            share_id = ""
            pass_code = ""

            for pattern in patterns:
                match = re.search(pattern, s)
                if match:
                    share_id = match.group(1)
                    break

            pwd_match = re.search(r"[?&]pwd=([A-Za-z0-9]+)", s)
            if pwd_match:
                pass_code = pwd_match.group(1)

            return share_id, pass_code

        def _normalize_scope(s: str | list[str]) -> list[str]:
            if isinstance(s, list):
                return [p if p else "/" for p in s]
            return [s if s else "/"]

        def _get_search_paths(scope_paths: list[str]) -> list[str]:
            paths = []
            for sp in scope_paths:
                if sp == "/" or sp == "":
                    paths.append("")
                else:
                    paths.append(sp.rstrip("/"))
            return paths

        def _normalize_result(result: dict[str, Any], fpath: str = "") -> dict[str, Any]:
            result["path"] = fpath
            if "is_own_share" not in result:
                user_info = result.get("user_info", {})
                owner_user_id = user_info.get("user_id", "")
                current_user_id = self.cloud.cache.tokens.user_id
                result["is_own_share"] = owner_user_id == current_user_id
            if "owner_user_id" not in result:
                user_info = result.get("user_info", {})
                result["owner_user_id"] = user_info.get("user_id", "")
            if "owner_nickname" not in result:
                user_info = result.get("user_info", {})
                result["owner_nickname"] = user_info.get("nickname", "")
            return result

        async def _get_file_path(file_id: str) -> str:
            """通过 parent_id 递归获取文件的完整路径"""
            path_parts: list[str] = []
            current_id = file_id
            visited: set[str] = set()
            while current_id:
                if current_id in visited:
                    break
                visited.add(current_id)
                file_info = await self.cloud.get_file_info(current_id)
                if not file_info:
                    break
                name = file_info.get("name", "")
                if name:
                    path_parts.insert(0, name)
                parent_id = file_info.get("parent_id", "")
                if not parent_id or parent_id == current_id:
                    break
                current_id = parent_id
            return "/" + "/".join(path_parts) if path_parts else ""

        def _build_file_lookup(share_list: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
            lookup: dict[str, list[dict[str, Any]]] = {}
            for share in share_list:
                fid = share.get("file_id", "")
                if fid:
                    if fid not in lookup:
                        lookup[fid] = []
                    lookup[fid].append(share)
            return lookup

        _memory_cache: dict[str, InlineShareCacheEntry] = {}

        async def _ensure_share_list() -> tuple[dict[str, Any], dict[str, list[dict[str, Any]]]]:  # noqa: C901
            async def _get_full_list() -> tuple[Optional[list[dict[str, Any]]], dict[str, Any]]:
                return await self.cloud.get_share_list_full(limit=50)

            async def _get_incremental_list(
                anchor_id: str,
            ) -> tuple[Optional[list[dict[str, Any]]], dict[str, Any]]:
                return await self.cloud.get_share_list_full(limit=50, anchor_share_id=anchor_id)

            def _is_valid_cache_entry(entry: InlineShareCacheEntry) -> bool:
                if not entry:
                    return False
                if not isinstance(entry.share_links, list):
                    return False
                if not entry.anchor_share_id and entry.share_links:
                    return False
                return True

            def _merge_shares(
                cached: list[dict[str, Any]], new: list[dict[str, Any]]
            ) -> list[dict[str, Any]]:
                if not new:
                    return cached
                existing_ids = {s.get("share_id") for s in cached}
                merged = list(cached)
                for share in new:
                    sid = share.get("share_id", "")
                    if sid and sid not in existing_ids:
                        merged.append(share)
                        existing_ids.add(sid)
                return merged

            def _get_first_share_id(shares: list[dict[str, Any]]) -> str:
                return shares[0].get("share_id", "") if shares else ""

            current_time = time.time()
            default_ttl = 7200

            if cache_strategy == CacheStrategy.DISABLED:
                share_list, anchor_info = await _get_full_list()
                if share_list is not None:
                    file_lookup = _build_file_lookup(share_list)
                    return {
                        "success": True,
                        "share_list": share_list,
                        "is_incremental": False,
                        "new_count": 0,
                    }, file_lookup
                return {"success": False, "share_list": []}, {}

            elif cache_strategy == CacheStrategy.SESSION:
                cached_entry = _memory_cache.get("_current_session")

                if cached_entry and _is_valid_cache_entry(cached_entry):
                    if current_time - cached_entry.cached_at < (cache_ttl or default_ttl):
                        file_lookup = _build_file_lookup(cached_entry.share_links)

                        if cached_entry.anchor_share_id:
                            incremental_list, _ = await _get_incremental_list(
                                cached_entry.anchor_share_id
                            )
                            if incremental_list is not None:
                                merged = _merge_shares(cached_entry.share_links, incremental_list)
                                new_first_id = _get_first_share_id(merged)
                                cached_entry.share_links = merged
                                cached_entry.share_count = len(merged)
                                cached_entry.cached_at = current_time
                                cached_entry.anchor_share_id = new_first_id
                                file_lookup = _build_file_lookup(merged)
                                return {
                                    "success": True,
                                    "share_list": merged,
                                    "is_incremental": True,
                                    "new_count": len(incremental_list),
                                }, file_lookup

                        return {
                            "success": True,
                            "share_list": cached_entry.share_links,
                            "is_incremental": False,
                            "new_count": 0,
                        }, file_lookup

                share_list, anchor_info = await _get_full_list()
                if share_list is not None:
                    first_id = _get_first_share_id(share_list)

                    entry = InlineShareCacheEntry(
                        file_id="_current_session",
                        path="",
                        share_links=share_list,
                        share_count=len(share_list),
                        success=True,
                        message="完整分享列表缓存",
                        cached_at=current_time,
                        anchor_share_id=first_id,
                    )
                    _memory_cache["_current_session"] = entry

                    file_lookup = _build_file_lookup(share_list)
                    return {
                        "success": True,
                        "share_list": share_list,
                        "is_incremental": False,
                        "new_count": 0,
                    }, file_lookup
                return {"success": False, "share_list": []}, {}

            elif cache_strategy == CacheStrategy.PERSISTENT:
                cache_data = await _load_cache()
                cached_entry = cache_data.get("_current_session")

                if cached_entry and _is_valid_cache_entry(cached_entry):
                    if current_time - cached_entry.cached_at < (cache_ttl or default_ttl):
                        file_lookup = _build_file_lookup(cached_entry.share_links)

                        if cached_entry.anchor_share_id:
                            incremental_list, _ = await _get_incremental_list(
                                cached_entry.anchor_share_id
                            )
                            if incremental_list is not None:
                                merged = _merge_shares(cached_entry.share_links, incremental_list)
                                new_first_id = _get_first_share_id(merged)
                                cached_entry.share_links = merged
                                cached_entry.share_count = len(merged)
                                cached_entry.cached_at = current_time
                                cached_entry.anchor_share_id = new_first_id
                                cache_data["_current_session"] = cached_entry
                                await _save_cache(cache_data)
                                file_lookup = _build_file_lookup(merged)
                                return {
                                    "success": True,
                                    "share_list": merged,
                                    "is_incremental": True,
                                    "new_count": len(incremental_list),
                                }, file_lookup

                        return {
                            "success": True,
                            "share_list": cached_entry.share_links,
                            "is_incremental": False,
                            "new_count": 0,
                        }, file_lookup

                share_list, anchor_info = await _get_full_list()
                if share_list is not None:
                    first_id = _get_first_share_id(share_list)

                    entry = InlineShareCacheEntry(
                        file_id="_current_session",
                        path="",
                        share_links=share_list,
                        share_count=len(share_list),
                        success=True,
                        message="完整分享列表缓存",
                        cached_at=current_time,
                        anchor_share_id=first_id,
                    )

                    cache_data["_current_session"] = entry
                    await _save_cache(cache_data)

                    file_lookup = _build_file_lookup(share_list)
                    return {
                        "success": True,
                        "share_list": share_list,
                        "is_incremental": False,
                        "new_count": 0,
                    }, file_lookup
                return {"success": False, "share_list": []}, {}

        async def _get_by_share_id_fast(
            sid: str, pass_code: str = "", task: str = ""
        ) -> dict[str, Any]:
            share, _ = await self.cloud.find_share_by_id(sid)
            share_info = await self.cloud.get_share_info(sid, pass_code)
            if not share_info:
                if share:
                    result = _build_single_result([share], sid, f"https://pan.xunlei.com/s/{sid}")
                    file_id = share.get("file_id", "")
                    if file_id:
                        file_path = await _get_file_path(file_id)
                        if file_path:
                            result["path"] = file_path
                    if task:
                        result["task"] = task
                    return result
                return {
                    "success": False,
                    "has_share": False,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": "",
                    "file_name": "",
                    "path": "",
                    "is_own_share": False,
                    "owner_user_id": "",
                    "owner_nickname": "",
                    "message": "分享链接不存在或已失效",
                }
            user_info = share_info.get("user_info", {})
            owner_user_id = user_info.get("user_id", "")
            current_user_id = self.cloud.cache.tokens.user_id
            is_own_share = owner_user_id == current_user_id
            share_url = f"https://pan.xunlei.com/s/{sid}"
            pass_code_from_info = share_info.get("pass_code", pass_code)
            share_status = share_info.get("share_status", "")
            invalid_statuses = {"DELETED", "FILE_DELETED", "INVALID"}
            is_valid = share_status not in invalid_statuses
            share_link_item = {
                "share_url": f"{share_url}?pwd={pass_code_from_info}"
                if pass_code_from_info
                else share_url,
                "is_valid": is_valid,
                "expire_time": share_info.get("expiration_at", ""),
                "remaining_count": share_info.get("restore_count_left", -1),
                "created_at": share_info.get("create_time", ""),
            }
            files = share_info.get("files", [])
            first_file = files[0] if files else {}
            file_id = first_file.get("id", "")
            file_path = ""
            total_size = 0
            total_files = 0
            if file_id and is_own_share:
                file_path = await _get_file_path(file_id)
                total_size = share_info.get("total_size", 0)
                total_files = share_info.get("total_files", 0)
            elif file_id:
                file_detail = await self.cloud.get_file_info_by_id(file_id)
                if file_detail:
                    total_size = int(file_detail.get("size", 0) or 0)
                    total_files = 1
                    file_path = file_detail.get("name", "")

            share_info_return = {
                "success": True,
                "has_share": True,
                "task": task if task else f"https://pan.xunlei.com/s/{sid}",
                "share_links": [share_link_item],
                "share_count": 1,
                "file_id": file_id,
                "file_name": share_info.get("title", ""),
                "path": file_path,
                "is_own_share": is_own_share,
                "owner_user_id": owner_user_id,
                "owner_nickname": user_info.get("nickname", ""),
                "total_size": total_size,
                "total_files": total_files,
                "files": files if is_own_share else [],
                "message": "查询成功",
            }
            return share_info_return

        async def _find_shares_for_file_id(fid: str, fname: str, p: str) -> dict[str, Any]:
            """边提取边匹配，查找特定文件ID的分享"""
            page_token = ""
            while True:
                result = await self.cloud.get_share_list(limit=50, page_token=page_token)
                if not result:
                    break
                shares = result.get("share_list", [])
                if not shares:
                    break
                file_shares = [s for s in shares if s.get("file_id") == fid]
                if file_shares:
                    if not return_all:
                        file_shares = [file_shares[0]]
                    return {
                        "success": True,
                        "has_share": True,
                        "task": p,
                        "share_links": [_build_share_link_item(s) for s in file_shares],
                        "share_count": len(file_shares),
                        "file_id": fid,
                        "file_name": fname,
                        "path": p,
                        "message": f"查询成功，共 {len(file_shares)} 个分享链接",
                    }
                page_token = result.get("next_page_token", "")
                if not page_token:
                    break
            return {
                "success": True,
                "has_share": False,
                "task": p,
                "share_links": [],
                "share_count": 0,
                "file_id": fid,
                "file_name": fname,
                "path": p,
                "message": "文件未分享",
            }

        async def _get_by_share_id(
            sid: str, file_lookup: dict[str, list[dict[str, Any]]]
        ) -> dict[str, Any]:
            for shares in file_lookup.values():
                for share in shares:
                    if share.get("share_id") == sid:
                        return _build_single_result([share], sid, f"https://pan.xunlei.com/s/{sid}")
            share_info = await self.cloud.get_file_share_info(share_id=sid)
            if not share_info.get("has_share", False):
                return {
                    "success": False,
                    "has_share": False,
                    "share_links": [],
                    "share_count": 0,
                    "share_id": sid,
                    "file_id": "",
                    "file_name": "",
                    "path": "",
                    "is_own_share": False,
                    "message": "该分享链接为他人分享，无法查询详情（仅支持查询自己创建的分享链接）",
                }
            return _normalize_result(share_info)

        def _build_share_link_item(share_item: dict[str, Any]) -> dict[str, Any]:
            share_status = share_item.get("share_status", "")
            is_valid = share_status == "OK"
            share_url = share_item.get("share_url", "")
            pass_code = share_item.get("pass_code", "")
            expiration_at = share_item.get("expiration_at", "")
            restore_limit = share_item.get("restore_limit", -1)
            restore_count = share_item.get("restore_count", 0)
            remaining = int(restore_limit) - int(restore_count) if restore_limit != "-1" else -1

            full_url = share_url
            if pass_code and share_url:
                full_url = (
                    f"{share_url}?pwd={pass_code}"
                    if "?" not in share_url
                    else f"{share_url}&pwd={pass_code}"
                )

            return {
                "share_url": full_url,
                "is_valid": is_valid,
                "expire_time": expiration_at,
                "remaining_count": remaining,
                "created_at": share_item.get("create_time", ""),
            }

        def _build_single_result(
            shares: list[dict[str, Any]], target_id: str = "", task: str = ""
        ) -> dict[str, Any]:
            if not shares:
                return {
                    "success": True,
                    "has_share": False,
                    "task": task,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": target_id,
                    "file_name": "",
                    "path": "",
                    "is_own_share": False,
                    "owner_user_id": "",
                    "owner_nickname": "",
                    "message": "未找到分享信息",
                }

            first_share = shares[0]
            share_links = [_build_share_link_item(s) for s in shares]
            first_item = share_links[0] if share_links else {}
            user_info = first_share.get("user_info", {})
            owner_user_id = user_info.get("user_id", "")
            current_user_id = self.cloud.cache.tokens.user_id
            is_own_share = owner_user_id == current_user_id

            if return_all:
                return {
                    "success": True,
                    "has_share": True,
                    "task": task,
                    "share_links": share_links,
                    "share_count": len(share_links),
                    "file_id": first_share.get("file_id", ""),
                    "file_name": first_share.get("title", ""),
                    "path": "",
                    "is_own_share": is_own_share,
                    "owner_user_id": owner_user_id,
                    "owner_nickname": user_info.get("nickname", ""),
                    "message": f"查询成功，共 {len(share_links)} 个分享链接",
                }

            return {
                "success": True,
                "has_share": True,
                "task": task,
                "share_links": [first_item],
                "share_count": 1,
                "file_id": first_share.get("file_id", ""),
                "file_name": first_share.get("title", ""),
                "path": "",
                "is_own_share": is_own_share,
                "owner_user_id": owner_user_id,
                "owner_nickname": user_info.get("nickname", ""),
                "message": "查询成功",
            }

        def _build_result_from_shares(
            shares: list[dict[str, Any]], fid: str, fname: str, p: str
        ) -> dict[str, Any]:
            if not shares:
                return {
                    "success": True,
                    "has_share": False,
                    "task": p,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": fid,
                    "file_name": fname,
                    "path": p,
                    "is_own_share": False,
                    "owner_user_id": "",
                    "owner_nickname": "",
                    "message": "文件未分享",
                }

            first_share = shares[0]
            share_links = [_build_share_link_item(s) for s in shares]
            user_info = first_share.get("user_info", {})
            owner_user_id = user_info.get("user_id", "")
            current_user_id = self.cloud.cache.tokens.user_id

            if return_all:
                return {
                    "success": True,
                    "has_share": True,
                    "task": p,
                    "share_links": share_links,
                    "share_count": len(share_links),
                    "file_id": fid,
                    "file_name": fname or first_share.get("title", ""),
                    "path": p,
                    "is_own_share": owner_user_id == current_user_id,
                    "owner_user_id": owner_user_id,
                    "owner_nickname": user_info.get("nickname", ""),
                    "message": f"查询成功，共 {len(share_links)} 个分享链接",
                }

            first_item = share_links[0]
            return {
                "success": True,
                "has_share": True,
                "task": p,
                "share_links": [first_item],
                "share_count": 1,
                "file_id": fid,
                "file_name": fname or first_share.get("title", ""),
                "path": p,
                "is_own_share": owner_user_id == current_user_id,
                "owner_user_id": owner_user_id,
                "owner_nickname": user_info.get("nickname", ""),
                "message": "查询成功",
            }

        if callable(targets) and not isinstance(targets, str):
            scope_paths = _get_search_paths(_normalize_scope(scope))
            all_files: list[dict[str, Any]] = []
            for sp in scope_paths:
                search_result = await self.cloud.search(
                    callback=lambda f: True, path=sp if sp else None
                )
                if isinstance(search_result, list):
                    all_files.extend(search_result)
                else:
                    all_files.extend(search_result.get("files", []))
            filtered_files = [f for f in all_files if targets(f)]
            if not filtered_files:
                return []
            _, file_lookup = await _ensure_share_list()
            results = []
            for f in filtered_files:
                p = f.get("path", "")
                fid = f.get("id", "")
                result = _build_result_from_shares(
                    file_lookup.get(fid, []), fid, f.get("name", ""), p
                )
                results.append(_normalize_result(result, p))
            return results

        if isinstance(targets, list):
            share_link_targets = [t for t in targets if _is_share_link(t)]
            share_ids = [t for t in targets if _is_share_id(t) and not _is_share_link(t)]
            file_targets = [t for t in targets if not _is_share_id(t) and not _is_share_link(t)]
            results = []
            if file_targets:
                if return_all:
                    file_infos: list[dict[str, Any]] = []
                    for ft in file_targets:
                        file_info = await self.cloud.get_file_info(ft)
                        if file_info:
                            file_infos.append(file_info)
                    _, file_lookup = await _ensure_share_list()
                    for fi, ft in zip(file_infos, file_targets):
                        result = _build_result_from_shares(
                            file_lookup.get(fi.get("id", ""), []),
                            fi.get("id", ""),
                            fi.get("name", ""),
                            ft,
                        )
                        results.append(_normalize_result(result, ft))
                else:
                    for ft in file_targets:
                        file_info = await self.cloud.get_file_info(ft)
                        if file_info:
                            fid = file_info.get("id", "")
                            fname = file_info.get("name", "")
                            result = await _find_shares_for_file_id(fid, fname, ft)
                            results.append(result)
                        else:
                            results.append(
                                {
                                    "success": False,
                                    "has_share": False,
                                    "share_links": [],
                                    "share_count": 0,
                                    "file_id": "",
                                    "file_name": "",
                                    "path": ft,
                                    "message": f"文件/目录不存在: {ft}",
                                }
                            )
            if share_ids or share_link_targets:
                if return_all:
                    _, file_lookup = await _ensure_share_list()
                    for sid in share_ids:
                        result = await _get_by_share_id(sid, file_lookup)
                        results.append(result)
                    for link in share_link_targets:
                        sid, pcode = _extract_share_id(link)
                        if sid:
                            result = await _get_by_share_id(sid, file_lookup)
                            results.append(result)
                else:
                    for sid in share_ids:
                        result = await _get_by_share_id_fast(sid)
                        results.append(result)
                    for link in share_link_targets:
                        sid, pcode = _extract_share_id(link)
                        if sid:
                            result = await _get_by_share_id_fast(sid, pcode, link)
                            results.append(result)
            return results

        if isinstance(targets, str) and targets:
            if _is_share_link(targets):
                sid, pcode = _extract_share_id(targets)
                if sid:
                    if return_all:
                        _, file_lookup = await _ensure_share_list()
                        return await _get_by_share_id(sid, file_lookup)
                    return await _get_by_share_id_fast(sid, pcode, targets)
                return {
                    "success": False,
                    "has_share": False,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": "",
                    "file_name": "",
                    "path": targets,
                    "message": f"无法解析分享链接: {targets}",
                }
            if _is_share_id(targets):
                if return_all:
                    _, file_lookup = await _ensure_share_list()
                    return await _get_by_share_id(targets, file_lookup)
                return await _get_by_share_id_fast(targets, "", targets)
            file_info = await self.cloud.get_file_info(targets)
            if not file_info:
                return {
                    "success": False,
                    "has_share": False,
                    "share_links": [],
                    "share_count": 0,
                    "file_id": "",
                    "file_name": "",
                    "path": targets,
                    "message": f"文件/目录不存在: {targets}",
                }
            fid = file_info.get("id", "")
            fname = file_info.get("name", "")
            if return_all:
                _, file_lookup = await _ensure_share_list()
                result = _build_result_from_shares(file_lookup.get(fid, []), fid, fname, targets)
            else:
                result = await _find_shares_for_file_id(fid, fname, targets)
            if auto_create and not result.get("has_share", False):
                create_result = await self.cloud.create_share_link(
                    file_id=fid,
                    valid_days=-1,
                    extraction_times=-1,
                    with_passcode=True,
                )
                if create_result and create_result.get("success"):
                    share_links = create_result.get("share_links", [])
                    share_url = share_links[0] if share_links else ""
                    share_item = {
                        "share_url": share_url,
                        "is_valid": True,
                        "expire_time": "",
                        "remaining_count": -1,
                        "created_at": create_result.get("created_at", ""),
                    }
                    result = {
                        "success": True,
                        "has_share": True,
                        "task": targets,
                        "share_links": [share_item],
                        "share_count": 1,
                        "file_id": fid,
                        "file_name": fname,
                        "path": targets,
                        "message": "自动创建分享成功",
                    }
            return _normalize_result(result, targets)

        if save_to_file:
            try:
                import csv

                ext = save_to_file.lower().split(".")[-1] if "." in save_to_file else "csv"
                if ext == "txt":
                    with open(save_to_file, "w", encoding="utf-8") as f:
                        f.write("")
                else:
                    with open(save_to_file, "w", encoding="utf-8", newline="") as f:
                        writer = csv.DictWriter(
                            f,
                            fieldnames=[
                                "file_name",
                                "file_id",
                                "path",
                                "share_link",
                                "share_id",
                                "is_valid",
                                "has_share",
                                "success",
                            ],
                        )
                        writer.writeheader()
            except Exception as e:
                logger.error(f"保存分享信息到文件失败: {str(e)}")

        return {
            "success": False,
            "has_share": False,
            "share_links": [],
            "share_count": 0,
            "file_id": "",
            "file_name": "",
            "path": "",
            "message": "targets 不能为空",
        }

    async def cancel_share_link(  # noqa: C901
        self,
        targets: str | list[str] | Callable[[dict[str, Any]], bool],
        scope: str | list[str] = "/",
        delete_after_cancel: bool = False,
        permanent_delete: bool = False,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        取消分享链接（支持多种输入方式和批量操作）

        设计说明:
            targets 参数支持多种输入形式（智能自动识别）：
              1. 单个路径字符串：如 "/我的资源/电影.mp4"
              2. 多个路径列表：如 ["/我的资源/电影1.mp4", "/我的资源/电影2.mp4"]
              3. 单个分享 ID 字符串：如 "VNv5Ol2sxliNst19L1IRVi4OA1"
              4. 分享 ID 列表：如 ["id1", "id2"]
              5. 单个完整分享链接（带或不带提取码）：如 "https://pan.xunlei.com/s/VOxxx?pwd=xxxx"
              6. 分享链接列表：如 ["https://pan.xunlei.com/s/VOxxx?pwd=xxxx", "https://pan.xunlei.com/s/VIddd"]
              7. 混合列表：如 ["/路径/文件", "VNv5Ol2sxli...", "https://pan.xunlei.com/s/VOxxx?pwd=xxxx"]
              8. 回调函数：用于智能筛选要取消分享的文件，签名为 Callable[[dict], bool]
                  回调函数接收的字典示例：
                  {
                      "id": "VNv5Ol2sxliNst19L1IRVi4OA1",  # 文件/目录ID
                      "name": "电影.mp4",                  # 文件/目录名称
                      "path": "/我的资源/电影.mp4",        # 完整路径
                      "kind": "drive#file",               # 类型（drive#file 或 drive#folder）
                      "size": 1024000,                    # 文件大小（字节）
                      "created_time": "2024-01-01T00:00:00Z",  # 创建时间
                      "modified_time": "2024-01-01T00:00:00Z",  # 修改时间
                  }
            scope 参数用于设定回调函数筛选的范围（当 targets 为回调函数时生效）：
              1. "/"：遍历整个云盘（默认）
              2. 单个目录路径：如 "/我的资源"
              3. 目录路径列表：如 ["/电影", "/音乐"]

        Args:
            targets: 文件/目录路径、分享ID或完整分享链接
                    （支持路径、ID、分享链接、列表、混合列表、或回调函数）
                    当为回调函数时，会在 scope 指定的范围内筛选文件
            scope: 回调函数筛选的范围（当 targets 为回调函数时生效）
                  - "/"：遍历整个云盘（默认）
                  - "/目录1": 在指定目录及其子目录中筛选
                  - ["/目录1", "/目录2"]: 在多个目录及其子目录中筛选
            delete_after_cancel: 取消分享后是否自动删除文件，False 不删除（默认），True 删除
            permanent_delete: 删除文件的方式，False 放入回收站（默认），True 永久删除
                              只有当 delete_after_cancel=True 时此参数才生效

        Returns:
            单条操作返回字典:
            {
                "success": bool,                    # 是否成功
                "canceled_links": [...],            # 被取消的分享链接列表（带提取码的完整链接）
                "canceled_count": int,              # 被取消的链接数量
                "deleted": bool,                    # 是否已删除文件
                "file_id": str,                     # 文件ID（如果有）
                "file_name": str,                    # 文件名称（如果有）
                "path": str,                         # 文件完整路径（如果有）
                "message": str,                       # 结果描述
            }
            批量操作返回结果列表
        """

        def _is_share_id(s: str) -> bool:
            return s.startswith("VN") or s.startswith("VO") or s.startswith("V")

        def _is_share_link(s: str) -> bool:
            return "pan.xunlei.com/s/" in s

        def _extract_share_id(s: str) -> tuple[str, str]:
            import re

            patterns = [
                r"pan\.xunlei\.com/s/([A-Za-z0-9_-]+)",
                r"/s/([A-Za-z0-9_-]+)",
            ]

            share_id = ""
            pass_code = ""

            for pattern in patterns:
                match = re.search(pattern, s)
                if match:
                    share_id = match.group(1)
                    break

            pwd_pattern = r"pwd=([A-Za-z0-9_-]+)"
            pwd_match = re.search(pwd_pattern, s)
            if pwd_match:
                pass_code = pwd_match.group(1)

            return share_id, pass_code

        def _normalize_scope(s: str | list[str]) -> list[str]:
            if isinstance(s, list):
                return [p if p else "/" for p in s]
            return [s if s else "/"]

        def _get_search_paths(scope_paths: list[str]) -> list[str]:
            paths = []
            for sp in scope_paths:
                if sp == "/" or sp == "":
                    paths.append("")
                else:
                    paths.append(sp.rstrip("/"))
            return paths

        async def _cancel_by_share_id(sid: str) -> dict[str, Any]:
            if not sid:
                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": "",
                    "file_name": "",
                    "path": "",
                    "message": "share_id 不能为空",
                }
            try:
                share_info = await self.cloud.get_file_share_info(share_id=sid)
                if share_info.get("has_share"):
                    file_id = share_info.get("file_id", "")
                    file_name = share_info.get("file_name", "")
                    success = await self.cloud.cancel_share_link(sid)
                    deleted = False
                    if success and file_id and delete_after_cancel:
                        await self.cloud.delete(file_id, permanent=permanent_delete)
                        deleted = True

                    if success:
                        full_url = f"https://pan.xunlei.com/s/{sid}"
                        return {
                            "success": True,
                            "canceled_links": [full_url],
                            "canceled_count": 1,
                            "deleted": deleted,
                            "file_id": file_id,
                            "file_name": file_name,
                            "path": "",
                            "message": f"成功取消分享链接{'并删除文件' if deleted else ''}",
                        }
                    return {
                        "success": False,
                        "canceled_links": [],
                        "canceled_count": 0,
                        "deleted": False,
                        "file_id": file_id,
                        "file_name": file_name,
                        "path": "",
                        "message": "取消分享链接失败",
                    }

                file_info = await self.cloud.get_file_info(sid)
                if file_info:
                    fid = file_info.get("id", "")
                    fname = file_info.get("name", "")
                    p = file_info.get("path", "")
                    if not p:
                        p = file_info.get("name", "")
                    return await _cancel_by_file_id(fid, fname, p)

                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": "",
                    "file_name": "",
                    "path": "",
                    "message": f"无法找到对应的分享链接或文件: {sid}",
                }
            except Exception as e:
                logger.error(f"取消分享链接时发生错误: {str(e)}")
                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": "",
                    "file_name": "",
                    "path": "",
                    "message": f"取消分享链接失败: {str(e)}",
                }

        async def _cancel_by_file_id(fid: str, fname: str, p: str) -> dict[str, Any]:
            share_list_result = await self.cloud.get_share_list(limit=100)
            if not share_list_result:
                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": fid,
                    "file_name": fname,
                    "path": p,
                    "message": "无法获取分享列表",
                }

            share_list = share_list_result.get("share_list", [])
            file_shares = [s for s in share_list if s.get("file_id") == fid]

            if not file_shares:
                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": fid,
                    "file_name": fname,
                    "path": p,
                    "message": "文件未分享，无需取消",
                }

            canceled_links = []
            all_success = True
            for share_item in file_shares:
                sid = share_item.get("share_id", "")
                if sid:
                    success = await self.cloud.cancel_share_link(sid)
                    if success:
                        share_url = share_item.get("share_url", "")
                        pass_code = share_item.get("pass_code", "")
                        full_url = (
                            f"{share_url}?pwd={pass_code}"
                            if share_url
                            else f"https://pan.xunlei.com/s/{sid}"
                        )
                        canceled_links.append(full_url)
                    else:
                        all_success = False

            deleted = False
            if canceled_links and delete_after_cancel:
                await self.cloud.delete(fid, permanent=permanent_delete)
                deleted = True

            if canceled_links:
                msg = f"成功取消 {len(canceled_links)} 个分享链接{'并删除文件' if deleted else ''}"
            else:
                msg = "取消分享链接失败"
            return {
                "success": all_success and len(canceled_links) > 0,
                "canceled_links": canceled_links,
                "canceled_count": len(canceled_links),
                "deleted": deleted,
                "file_id": fid,
                "file_name": fname,
                "path": p,
                "message": msg,
            }

        async def _cancel_by_path(p: str) -> dict[str, Any]:
            file_info = await self.cloud.get_file_info(p)
            if not file_info:
                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": "",
                    "file_name": "",
                    "path": p,
                    "message": f"文件/目录不存在: {p}",
                }
            fid = file_info.get("id", "")
            fname = file_info.get("name", "")
            return await _cancel_by_file_id(fid, fname, p)

        if callable(targets) and not isinstance(targets, str):
            scope_paths = _get_search_paths(_normalize_scope(scope))
            all_files: list[dict[str, Any]] = []
            for sp in scope_paths:
                search_result = await self.cloud.search(
                    callback=lambda f: True, path=sp if sp else None
                )
                if isinstance(search_result, list):
                    all_files.extend(search_result)
                else:
                    all_files.extend(search_result.get("files", []))
            filtered_files = [f for f in all_files if targets(f)]
            results = []
            for f in filtered_files:
                fid = f.get("id", "")
                fname = f.get("name", "")
                p = f.get("path", "")
                if fid:
                    result = await _cancel_by_file_id(fid, fname, p)
                    if result.get("success"):
                        results.append(result)
            return results

        if isinstance(targets, list):
            results = []
            for t in targets:
                if _is_share_link(t):
                    sid, _ = _extract_share_id(t)
                    if sid:
                        result = await _cancel_by_share_id(sid)
                    else:
                        result = {
                            "success": False,
                            "canceled_links": [],
                            "canceled_count": 0,
                            "deleted": False,
                            "file_id": "",
                            "file_name": "",
                            "path": t,
                            "message": f"无法解析分享链接: {t}",
                        }
                    results.append(result)
                elif _is_share_id(t):
                    result = await _cancel_by_share_id(t)
                    results.append(result)
                else:
                    result = await _cancel_by_path(t)
                    results.append(result)
            return results

        if isinstance(targets, str) and targets:
            if _is_share_link(targets):
                sid, _ = _extract_share_id(targets)
                if sid:
                    return await _cancel_by_share_id(sid)
                return {
                    "success": False,
                    "canceled_links": [],
                    "canceled_count": 0,
                    "deleted": False,
                    "file_id": "",
                    "file_name": "",
                    "path": targets,
                    "message": f"无法解析分享链接: {targets}",
                }
            if _is_share_id(targets):
                return await _cancel_by_share_id(targets)
            return await _cancel_by_path(targets)

        return {
            "success": False,
            "canceled_links": [],
            "canceled_count": 0,
            "file_id": "",
            "file_name": "",
            "message": "targets 不能为空",
        }

    async def export_share_links(  # noqa: C901
        self,
        targets: str | list[str] | Callable[[dict[str, Any]], bool] = "",
        scope: str | list[str] = "/",
        auto_create: bool = False,
        valid_days: int = -1,
        extraction_times: int = -1,
        with_passcode: bool = True,
        recursive: bool = False,
        filter_callback: Callable[[dict[str, Any]], bool] | None = None,
        save_dir: Optional[str] = None,
        file_name: Optional[str] = None,
        file_format: ExportFormat = ExportFormat.JSON,
    ) -> dict[str, Any]:
        """
        导出分享链接（支持批量和过滤）

        设计说明:
            targets 参数支持多种输入形式（智能自动识别）：
              1. 空字符串：导出所有分享链接（默认）
              2. 单个路径字符串：如 "/我的资源/电影.mp4"
              3. 多个路径列表：如 ["/我的资源/电影1.mp4", "/我的资源/电影2.mp4"]
              4. 单个文件 ID 字符串：如 "VNv5Ol2sxliNst19L1IRVi4OA1"
              5. 文件 ID 列表：如 ["id1", "id2"]
              6. 混合列表：如 ["/路径/文件", "VNv5Ol2sxli...", "sid123"]
              7. 回调函数：用于智能筛选要导出的文件，签名为 Callable[[dict], bool]
                  回调函数接收的字典示例：
                  {
                      "id": "VNv5Ol2sxliNst19L1IRVi4OA1",  # 文件/目录ID
                      "name": "电影.mp4",                  # 文件/目录名称
                      "path": "/我的资源/电影.mp4",        # 完整路径
                      "kind": "drive#file",               # 类型
                      "size": 1024000,                    # 文件大小（字节）
                      "created_time": "2024-01-01T00:00:00Z",
                      "modified_time": "2024-01-01T00:00:00Z",
                  }
            scope 参数用于设定回调函数筛选的范围（当 targets 为回调函数时生效）：
              1. "/"：遍历整个云盘（默认）
              2. 单个目录路径：如 "/我的资源"
              3. 目录路径列表：如 ["/电影", "/音乐"]

            filter_callback 参数用于过滤分享链接结果：
              - None：不过滤，返回所有（默认）
              - 回调函数：签名为 Callable[[dict], bool]
                  回调函数接收的字典示例：
                  {
                      "share_id": str,                    # 分享ID
                      "share_url": str,                   # 带提取码的完整分享链接
                      "pass_code": str,                    # 提取码
                      "is_valid": bool,                    # 是否有效（share_status=="OK"表示正常）
                      "expire_time": str,                 # 过期时间
                      "remaining_count": int,             # 剩余提取次数（-1表示无限制）
                      "created_at": str,                  # 创建时间
                      "file_id": str,                     # 文件ID
                      "file_name": str,                   # 文件名称
                      "path": str,                        # 文件路径
                      "share_status": str,                # 分享状态
                      "view_count": int,                  # 浏览次数
                  }

        Args:
            targets: 文件/目录路径、ID 或回调函数
                    空字符串导出所有（默认）
                    回调函数时在 scope 范围内筛选
            scope: 回调函数筛选的范围（当 targets 为回调函数时生效）
            auto_create: 当文件未分享时是否自动创建，False 不创建（默认），True 自动创建
            valid_days: 有效天数 (-1 永久，1-7 指定天数)，auto_create 为 True 时生效
            extraction_times: 提取次数 (-1 无限制，1-20 指定次数)，auto_create 为 True 时生效
            with_passcode: 是否需要提取码，auto_create 为 True 时生效
            recursive: 是否递归遍历目录，False 不递归（默认），True 递归遍历目录下所有文件和子目录
            filter_callback: 分享链接过滤回调函数
            save_dir: 保存目录，默认为当前目录
            file_name: 保存文件名（不含扩展名），默认为 "share_links_{账号}_{时间戳}"
                     当设定此参数时，file_format 参数失效
            file_format: 导出文件格式，支持 ExportFormat.JSON 和
                        ExportFormat.CSV，默认为 ExportFormat.JSON
                        当 file_name 包含扩展名时此参数失效

        Returns:
            导出结果字典:
            {
                "success": bool,              # 是否成功
                "total": int,                # 总数
                "exported": int,              # 导出数
                "skipped": int,               # 跳过数（未分享且不自动创建）
                "created": int,               # 新创建数
                "results": [...],             # 结果列表
                "file_path": str,             # 保存的文件路径
                "message": str,               # 结果描述
            }
        """
        from datetime import datetime

        def _is_share_id(s: str) -> bool:
            return s.startswith("VN") or s.startswith("VO") or s.startswith("V")

        def _is_file_id(s: str) -> bool:
            return len(s) > 20 and not _is_share_id(s)

        def _normalize_scope(s: str | list[str]) -> list[str]:
            if isinstance(s, list):
                return [p if p else "/" for p in s]
            return [s if s else "/"]

        def _get_search_paths(scope_paths: list[str]) -> list[str]:
            paths = []
            for sp in scope_paths:
                if sp == "/" or sp == "":
                    paths.append("")
                else:
                    paths.append(sp.rstrip("/"))
            return paths

        def _build_share_item(
            share: dict[str, Any], fid: str, fname: str, fpath: str
        ) -> dict[str, Any]:
            share_url = share.get("share_url", "")
            pass_code = share.get("pass_code", "")
            share_id = share.get("share_id", "")
            full_url = f"{share_url}?pwd={pass_code}" if share_url and pass_code else share_url
            share_status = share.get("share_status", "")
            return {
                "share_id": share_id,
                "share_url": full_url,
                "is_valid": share_status == "OK",
                "expire_time": share.get("expiration_at", ""),
                "remaining_count": (
                    int(share.get("restore_limit", -1)) - int(share.get("restore_count", 0))
                    if share.get("restore_limit", "-1") != "-1"
                    else -1
                ),
                "file_id": fid,
                "file_name": fname or share.get("title", ""),
                "path": fpath,
                "share_status": share_status,
                "create_time": share.get("create_time", ""),
                "view_count": int(share.get("view_count", 0) or 0),
            }

        def _normalize_result(result: dict[str, Any], fpath: str = "") -> dict[str, Any]:
            result["path"] = fpath
            if "is_own_share" not in result:
                user_info = result.get("user_info", {})
                owner_user_id = user_info.get("user_id", "")
                current_user_id = self.cloud.cache.tokens.user_id
                result["is_own_share"] = owner_user_id == current_user_id
            if "owner_user_id" not in result:
                user_info = result.get("user_info", {})
                result["owner_user_id"] = user_info.get("user_id", "")
            if "owner_nickname" not in result:
                user_info = result.get("user_info", {})
                result["owner_nickname"] = user_info.get("nickname", "")
            return result

        async def _get_all_files_recursive(dir_path: str) -> list[dict[str, Any]]:
            """递归获取目录下所有文件和子目录的文件"""
            all_files: list[dict[str, Any]] = []
            file_info = await self.cloud.get_file_info(dir_path)
            if not file_info:
                return all_files
            kind = file_info.get("kind", "")
            if kind == "drive#file":
                all_files.append(file_info)
                return all_files
            items = await self.cloud.get_files(file_info.get("id", ""), return_raw=True)
            if not items:
                return all_files
            for item in items:
                item_path = item.get("path") or (dir_path.rstrip("/") + "/" + item.get("name", ""))
                item_kind = item.get("kind", "")
                if item_kind == "drive#file":
                    item["path"] = item_path
                    all_files.append(item)
                elif item_kind == "drive#folder" and recursive:
                    item["path"] = item_path
                    sub_files = await _get_all_files_recursive(item_path)
                    all_files.extend(sub_files)
            return all_files

        all_shares, anchor_info = await self.cloud.get_share_list_full(limit=50)
        if all_shares is None:
            return {
                "success": False,
                "total": 0,
                "exported": 0,
                "skipped": 0,
                "created": 0,
                "results": [],
                "file_path": "",
                "message": "获取分享列表失败",
            }

        share_lookup: dict[str, list[dict[str, Any]]] = {}
        name_lookup: dict[str, list[dict[str, Any]]] = {}
        for share in all_shares:
            fid = share.get("file_id", "")
            title = share.get("title", "").lower()
            if fid:
                if fid not in share_lookup:
                    share_lookup[fid] = []
                share_lookup[fid].append(share)
            if title:
                if title not in name_lookup:
                    name_lookup[title] = []
                name_lookup[title].append(share)

        def _find_shares(file_id: str, file_name: str) -> list[dict[str, Any]]:
            shares = share_lookup.get(file_id, [])
            if not shares and file_name:
                same_name_shares = name_lookup.get(file_name.lower(), [])
                shares = [s for s in same_name_shares if s.get("file_id") == file_id]
            return shares

        results: list[dict[str, Any]] = []
        exported_count = 0
        skipped_count = 0
        created_count = 0

        if callable(targets) and not isinstance(targets, str):
            scope_paths = _get_search_paths(_normalize_scope(scope))
            all_files: list[dict[str, Any]] = []
            for sp in scope_paths:
                search_result = await self.cloud.search(
                    callback=lambda f: True, path=sp if sp else None
                )
                if isinstance(search_result, list):
                    all_files.extend(search_result)
                else:
                    all_files.extend(search_result.get("files", []))
            filtered_files = [f for f in all_files if targets(f)]

            for f in filtered_files:
                fid = f.get("id", "")
                fpath = f.get("path", "")
                fname = f.get("name", "")
                shares = _find_shares(fid, fname)

                if not shares:
                    if auto_create:
                        create_result = await self.cloud.create_share_link(
                            file_id=fid,
                            valid_days=valid_days,
                            extraction_times=extraction_times,
                            with_passcode=with_passcode,
                        )
                        if create_result and create_result.get("success"):
                            share_links = create_result.get("share_links", [])
                            share_url = share_links[0] if share_links else ""
                            share_id = ""
                            share_item = {
                                "share_id": share_id,
                                "share_url": share_url,
                                "is_valid": True,
                                "expire_time": "",
                                "remaining_count": -1,
                                "file_id": fid,
                                "file_name": fname,
                                "path": fpath,
                                "share_status": "OK",
                                "create_time": "",
                                "view_count": 0,
                            }
                            if filter_callback is None or filter_callback(share_item):
                                results.append(share_item)
                                exported_count += 1
                            created_count += 1
                        else:
                            skipped_count += 1
                    else:
                        skipped_count += 1
                else:
                    for share in shares:
                        share_item = _build_share_item(share, fid, fname, fpath)
                        if filter_callback is None or filter_callback(share_item):
                            results.append(share_item)
                            exported_count += 1

        elif isinstance(targets, list):
            file_targets = [t for t in targets if not _is_share_id(t)]
            share_id_targets = [t for t in targets if _is_share_id(t)]

            for t in file_targets:
                file_info = await self.cloud.get_file_info(t)
                if not file_info:
                    skipped_count += 1
                    continue
                fid = file_info.get("id", "")
                fname = file_info.get("name", "")
                shares = _find_shares(fid, fname)

                if not shares:
                    if auto_create:
                        create_result = await self.cloud.create_share_link(
                            file_id=fid,
                            valid_days=valid_days,
                            extraction_times=extraction_times,
                            with_passcode=with_passcode,
                        )
                        if create_result and create_result.get("success"):
                            share_links = create_result.get("share_links", [])
                            share_url = share_links[0] if share_links else ""
                            share_id = ""
                            share_item = {
                                "share_id": share_id,
                                "share_url": share_url,
                                "is_valid": True,
                                "expire_time": "",
                                "remaining_count": -1,
                                "file_id": fid,
                                "file_name": fname,
                                "path": t,
                                "share_status": "OK",
                                "create_time": "",
                                "view_count": 0,
                            }
                            if filter_callback is None or filter_callback(share_item):
                                results.append(share_item)
                                exported_count += 1
                            created_count += 1
                        else:
                            skipped_count += 1
                    else:
                        skipped_count += 1
                else:
                    for share in shares:
                        share_item = _build_share_item(share, fid, fname, t)
                        if filter_callback is None or filter_callback(share_item):
                            results.append(share_item)
                            exported_count += 1

            for sid in share_id_targets:
                share_item = next((s for s in all_shares if s.get("share_id") == sid), None)
                if share_item:
                    fid = share_item.get("file_id", "")
                    share_item["file_id"] = fid
                    share_item["file_name"] = share_item.get("title", "")
                    share_item["path"] = ""
                    if filter_callback is None or filter_callback(share_item):
                        results.append(
                            _build_share_item(share_item, fid, share_item.get("title", ""), "")
                        )
                        exported_count += 1
                else:
                    skipped_count += 1

        elif isinstance(targets, str) and targets:
            if _is_share_id(targets):
                share_item = next((s for s in all_shares if s.get("share_id") == targets), None)
                if share_item:
                    fid = share_item.get("file_id", "")
                    results.append(
                        _build_share_item(share_item, fid, share_item.get("title", ""), "")
                    )
                    exported_count += 1
                else:
                    skipped_count += 1
            else:
                file_info = await self.cloud.get_file_info(targets)
                if not file_info:
                    return {
                        "success": False,
                        "total": 0,
                        "exported": 0,
                        "skipped": 0,
                        "created": 0,
                        "results": [],
                        "file_path": "",
                        "message": f"文件/目录不存在: {targets}",
                    }
                kind = file_info.get("kind", "")
                if kind == "drive#folder" and recursive:
                    dir_id = file_info.get("id", "")
                    dir_name = file_info.get("name", "")
                    dir_path = targets
                    dir_shares = _find_shares(dir_id, dir_name)
                    if dir_shares:
                        for share in dir_shares:
                            share_item = _build_share_item(share, dir_id, dir_name, dir_path)
                            if filter_callback is None or filter_callback(share_item):
                                results.append(share_item)
                                exported_count += 1
                    elif auto_create:
                        create_result = await self.cloud.create_share_link(
                            file_id=dir_id,
                            valid_days=valid_days,
                            extraction_times=extraction_times,
                            with_passcode=with_passcode,
                        )
                        if create_result and create_result.get("success"):
                            share_links = create_result.get("share_links", [])
                            share_url = share_links[0] if share_links else ""
                            share_id = ""
                            share_item = {
                                "share_id": share_id,
                                "share_url": share_url,
                                "is_valid": True,
                                "expire_time": "",
                                "remaining_count": -1,
                                "file_id": dir_id,
                                "file_name": dir_name,
                                "path": dir_path,
                                "share_status": "OK",
                                "create_time": "",
                                "view_count": 0,
                            }
                            if filter_callback is None or filter_callback(share_item):
                                results.append(share_item)
                                exported_count += 1
                            created_count += 1
                        else:
                            skipped_count += 1
                    else:
                        skipped_count += 1
                    all_files = await _get_all_files_recursive(targets)
                    for f in all_files:
                        fid = f.get("id", "")
                        fname = f.get("name", "")
                        fpath = f.get("path", "")
                        shares = _find_shares(fid, fname)
                        if not shares:
                            if auto_create:
                                create_result = await self.cloud.create_share_link(
                                    file_id=fid,
                                    valid_days=valid_days,
                                    extraction_times=extraction_times,
                                    with_passcode=with_passcode,
                                )
                                if create_result and create_result.get("success"):
                                    share_links = create_result.get("share_links", [])
                                    share_url = share_links[0] if share_links else ""
                                    share_id = ""
                                    share_item = {
                                        "share_id": share_id,
                                        "share_url": share_url,
                                        "is_valid": True,
                                        "expire_time": "",
                                        "remaining_count": -1,
                                        "file_id": fid,
                                        "file_name": fname,
                                        "path": fpath,
                                        "share_status": "OK",
                                        "create_time": "",
                                        "view_count": 0,
                                    }
                                    if filter_callback is None or filter_callback(share_item):
                                        results.append(share_item)
                                        exported_count += 1
                                    created_count += 1
                                else:
                                    skipped_count += 1
                            else:
                                skipped_count += 1
                        else:
                            for share in shares:
                                share_item = _build_share_item(share, fid, fname, fpath)
                                if filter_callback is None or filter_callback(share_item):
                                    results.append(share_item)
                                    exported_count += 1
                else:
                    fid = file_info.get("id", "")
                    fname = file_info.get("name", "")
                    shares = _find_shares(fid, fname)

                    if not shares:
                        if auto_create:
                            create_result = await self.cloud.create_share_link(
                                file_id=fid,
                                valid_days=valid_days,
                                extraction_times=extraction_times,
                                with_passcode=with_passcode,
                            )
                            if create_result and create_result.get("success"):
                                share_links = create_result.get("share_links", [])
                                share_url = share_links[0] if share_links else ""
                                share_id = ""
                                share_item = {
                                    "share_id": share_id,
                                    "share_url": share_url,
                                    "is_valid": True,
                                    "expire_time": "",
                                    "remaining_count": -1,
                                    "file_id": fid,
                                    "file_name": fname,
                                    "path": targets,
                                    "share_status": "OK",
                                    "create_time": "",
                                    "view_count": 0,
                                }
                                if filter_callback is None or filter_callback(share_item):
                                    results.append(share_item)
                                    exported_count += 1
                                created_count += 1
                            else:
                                skipped_count += 1
                        else:
                            skipped_count += 1
                    else:
                        for share in shares:
                            share_item = _build_share_item(share, fid, fname, targets)
                            if filter_callback is None or filter_callback(share_item):
                                results.append(share_item)
                                exported_count += 1

        else:
            for share in all_shares:
                fid = share.get("file_id", "")
                share_item = _build_share_item(share, fid, share.get("title", ""), "")
                if filter_callback is None or filter_callback(share_item):
                    results.append(share_item)
                    exported_count += 1

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        account = self.username or "unknown"
        save_path = save_dir or "."

        def _get_format_and_name() -> tuple[str, str]:
            if file_name:
                if "." in file_name:
                    ext = file_name.rsplit(".", 1)[-1].lower()
                    return ext, file_name
                fmt_value = (
                    file_format.value if isinstance(file_format, ExportFormat) else file_format
                )
                return fmt_value, file_name
            fmt_value = file_format.value if isinstance(file_format, ExportFormat) else file_format
            if "." in fmt_value:
                ext = fmt_value.rsplit(".", 1)[-1].lower()
            else:
                ext = fmt_value
            name = f"share_links_{account}_{timestamp}.{ext}"
            return ext, name

        fmt, final_name = _get_format_and_name()
        full_save_path = f"{save_path}/{final_name}"

        file_path = ""
        if results:
            try:
                import csv
                import json
                import os

                abs_save_path = os.path.abspath(full_save_path)
                os.makedirs(
                    os.path.dirname(abs_save_path) if os.path.dirname(abs_save_path) else ".",
                    exist_ok=True,
                )
                if fmt == "json":
                    with open(abs_save_path, "w", encoding="utf-8") as f:
                        json.dump(
                            {
                                "success": True,
                                "total": len(results),
                                "exported": exported_count,
                                "skipped": skipped_count,
                                "created": created_count,
                                "results": results,
                            },
                            f,
                            ensure_ascii=False,
                            indent=2,
                        )
                else:
                    with open(abs_save_path, "w", encoding="utf-8", newline="") as f:
                        fieldnames = [
                            "file_name",
                            "file_id",
                            "path",
                            "share_id",
                            "share_url",
                            "is_valid",
                            "share_status",
                            "create_time",
                            "expire_time",
                            "view_count",
                            "remaining_count",
                        ]
                        writer = csv.DictWriter(f, fieldnames=fieldnames)
                        writer.writeheader()
                        for r in results:
                            row = {k: v for k, v in r.items() if k in fieldnames}
                            writer.writerow(row)
                file_path = abs_save_path
            except Exception as e:
                logger.error(f"保存分享链接到文件失败: {str(e)}")

        return {
            "success": True,
            "total": len(results),
            "exported": exported_count,
            "skipped": skipped_count,
            "created": created_count,
            "results": results,
            "file_path": file_path,
            "message": f"导出完成: {exported_count} 个, 跳过: {skipped_count}, 新建: {created_count}",  # noqa: E501
        }
