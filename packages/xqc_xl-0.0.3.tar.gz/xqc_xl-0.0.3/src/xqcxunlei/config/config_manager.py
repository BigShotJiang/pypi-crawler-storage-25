"""
Xunlei API 配置管理模块

集中管理系统配置，支持：
- 环境变量读取
- .env 文件加载
- 配置验证和默认值设置
- 动态配置更新
- 增强日志功能
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


def _parse_bool_env(env_var: str, default: bool) -> bool:
    """解析布尔类型的环境变量"""
    value = os.getenv(env_var)
    if value is None:
        return default

    # 转换为小写并去除空格
    value = value.strip().lower()

    # 布尔值的各种可能表示
    if value in ("true", "1", "yes", "on", "y"):
        return True
    elif value in ("false", "0", "no", "off", "n"):
        return False
    else:
        # 如果不能识别，返回默认值并记录警告
        import logging

        logging.warning(
            f"Unrecognized boolean value '{value}' for env var '{env_var}', "
            f"using default: {default}"
        )
        return default


def _parse_int_env(env_var: str, default: int) -> int:
    """解析整型环境变量"""
    value = os.getenv(env_var)
    if value is None:
        return default

    try:
        return int(value)
    except ValueError:
        import logging

        logging.warning(
            f"Invalid integer value '{value}' for env var '{env_var}', using default: {default}"
        )
        return default


def _parse_float_env(env_var: str, default: float) -> float:
    """解析浮点型环境变量"""
    value = os.getenv(env_var)
    if value is None:
        return default

    try:
        return float(value)
    except ValueError:
        import logging

        logging.warning(
            f"Invalid float value '{value}' for env var '{env_var}', using default: {default}"
        )
        return default


@dataclass
class Config:
    """配置类，支持环境变量和默认值"""

    # 认证相关配置
    username: str = field(default_factory=lambda: os.getenv("XUNLEI_USERNAME", ""))
    password: str = field(default_factory=lambda: os.getenv("XUNLEI_PASSWORD", ""))

    # 缓存相关配置
    cache_file: Optional[str] = field(default_factory=lambda: os.getenv("XUNLEI_CACHE_FILE"))
    cache_dir: Optional[str] = field(default_factory=lambda: os.getenv("XUNLEI_CACHE_DIR"))
    auto_save: bool = field(default_factory=lambda: _parse_bool_env("XUNLEI_AUTO_SAVE", True))

    # HTTP 客户端配置
    request_timeout: int = field(
        default_factory=lambda: _parse_int_env("XUNLEI_REQUEST_TIMEOUT", 30)
    )
    max_retries: int = field(default_factory=lambda: _parse_int_env("XUNLEI_MAX_RETRIES", 2))
    retry_delay: float = field(default_factory=lambda: _parse_float_env("XUNLEI_RETRY_DELAY", 1.0))

    # API 相关配置
    risk_url: str = field(
        default_factory=lambda: os.getenv("XUNLEI_RISK_URL", "https://xluser-ssl.xunlei.com/risk")
    )
    captcha_init_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_CAPTCHA_INIT_URL", "https://xluser-ssl.xunlei.com/v1/shield/captcha/init"
        )
    )
    signin_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SIGNIN_URL", "https://xluser-ssl.xunlei.com/v1/auth/signin"
        )
    )
    token_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_TOKEN_URL", "https://xluser-ssl.xunlei.com/v1/auth/token"
        )
    )
    authorize_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_AUTHORIZE_URL", "https://xluser-ssl.xunlei.com/v1/user/authorize"
        )
    )
    user_info_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_USER_INFO_URL", "https://xluser-ssl.xunlei.com/v1/user/me"
        )
    )

    # 云盘 API 配置
    files_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_FILES_URL", "https://api-pan.xunlei.com/drive/v1/files"
        )
    )
    tasks_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_TASKS_URL", "https://api-pan.xunlei.com/drive/v1/tasks"
        )
    )
    about_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_ABOUT_URL", "https://api-pan.xunlei.com/drive/v1/about"
        )
    )
    share_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SHARE_URL", "https://api-pan.xunlei.com/drive/v1/share"
        )
    )
    share_list_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SHARE_LIST_URL", "https://api-pan.xunlei.com/drive/v1/share/list"
        )
    )
    share_detail_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SHARE_DETAIL_URL", "https://api-pan.xunlei.com/drive/v1/share/detail"
        )
    )
    share_restore_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SHARE_RESTORE_URL", "https://api-pan.xunlei.com/drive/v1/share/restore"
        )
    )
    share_delete_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SHARE_DELETE_URL", "https://api-pan.xunlei.com/drive/v1/share/delete"
        )
    )
    resource_list_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_RESOURCE_LIST_URL", "https://api-pan.xunlei.com/drive/v1/resource/list"
        )
    )
    search_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_SEARCH_URL",
            "https://api-gateway-pan.xunlei.com/xlppc.searcher.api/drive_file_search",
        )
    )
    inner_api_url: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_INNER_API_URL", "https://api-pan.xunlei.com/drive/v1/apps/INNER_API"
        )
    )

    # 客户端配置
    login_client_id: str = field(
        default_factory=lambda: os.getenv("XUNLEI_LOGIN_CLIENT_ID", "XW5SkOhLDjnOZP7J")
    )
    token_client_id: str = field(
        default_factory=lambda: os.getenv("XUNLEI_TOKEN_CLIENT_ID", "Yd0uSVGrNJhCC2oE")
    )
    client_version: str = field(default_factory=lambda: os.getenv("XUNLEI_CLIENT_VERSION", "2.9.0"))
    package_name: str = field(
        default_factory=lambda: os.getenv("XUNLEI_PACKAGE_NAME", "pan.xunlei.com")
    )

    # 算法配置
    alg_version: str = field(default_factory=lambda: os.getenv("XUNLEI_ALG_VERSION", "1"))
    sign_key: str = field(default_factory=lambda: os.getenv("XUNLEI_SIGN_KEY", "jY41hOYPM2"))

    # OAuth 配置
    code_challenge: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_CODE_CHALLENGE", "_41Tnnw5MF4X8dlZ1XDul8SkCZbUuWOWwiPFMTHFieM"
        )
    )
    code_challenge_method: str = field(
        default_factory=lambda: os.getenv("XUNLEI_CODE_CHALLENGE_METHOD", "S256")
    )
    code_verifier: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_CODE_VERIFIER", "tsj8U88I1q4tyQOlfUZieLBzuv54EKFk"
        )
    )
    redirect_uri: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_REDIRECT_URI", "https://pan.xunlei.com/remote/self.login"
        )
    )
    scope: str = field(
        default_factory=lambda: os.getenv("XUNLEI_SCOPE", "profile offline pan sso user")
    )
    state: str = field(default_factory=lambda: os.getenv("XUNLEI_STATE", "state-cjho52konov"))

    # 时间配置
    access_token_expires: int = field(
        default_factory=lambda: _parse_int_env("XUNLEI_ACCESS_TOKEN_EXPIRES", 43200)
    )
    captcha_token_expires: int = field(
        default_factory=lambda: _parse_int_env("XUNLEI_CAPTCHA_TOKEN_EXPIRES", 300)
    )

    # 日志配置
    log_level: str = field(default_factory=lambda: os.getenv("XUNLEI_LOG_LEVEL", "INFO"))
    log_format: str = field(
        default_factory=lambda: os.getenv(
            "XUNLEI_LOG_FORMAT", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
    )

    def __post_init__(self):
        """初始化后验证配置"""
        self.validate()

    def validate(self) -> None:
        """验证配置的有效性"""
        # 验证 URL 格式
        urls_to_validate = [
            ("risk_url", self.risk_url),
            ("captcha_init_url", self.captcha_init_url),
            ("signin_url", self.signin_url),
            ("token_url", self.token_url),
            ("authorize_url", self.authorize_url),
            ("user_info_url", self.user_info_url),
            ("files_url", self.files_url),
            ("tasks_url", self.tasks_url),
            ("about_url", self.about_url),
            ("share_url", self.share_url),
            ("share_list_url", self.share_list_url),
            ("share_detail_url", self.share_detail_url),
            ("share_restore_url", self.share_restore_url),
            ("resource_list_url", self.resource_list_url),
            ("inner_api_url", self.inner_api_url),
        ]

        for name, url in urls_to_validate:
            try:
                parsed = urlparse(url)
                if not parsed.scheme or not parsed.netloc:
                    raise ValueError(f"Invalid URL for {name}: {url}")
            except Exception as e:
                raise ValueError(f"Invalid URL for {name}: {url}, error: {str(e)}")

        # 验证数值范围
        if self.request_timeout <= 0:
            raise ValueError(f"Request timeout must be positive, got: {self.request_timeout}")

        if self.max_retries < 0:
            raise ValueError(f"Max retries must be non-negative, got: {self.max_retries}")

        if self.retry_delay < 0:
            raise ValueError(f"Retry delay must be non-negative, got: {self.retry_delay}")

        if self.access_token_expires <= 0:
            raise ValueError(
                f"Access token expires must be positive, got: {self.access_token_expires}"
            )

        if self.captcha_token_expires <= 0:
            raise ValueError(
                f"Captcha token expires must be positive, got: {self.captcha_token_expires}"
            )


def _do_load_dotenv(env_path: Path) -> None:
    """
    加载 .env 文件

    Args:
        env_path: .env 文件路径
    """
    try:
        from dotenv import load_dotenv

        load_dotenv(env_path)
    except ImportError:
        import logging

        logging.warning(
            "python-dotenv not installed. "
            "Install it to use .env file support: pip install python-dotenv"
        )


def _find_env_file(config_file: Optional[str] = None) -> Optional[Path]:
    """
    搜索 .env 文件

    搜索顺序：
    1. 指定的 config_file 路径
    2. 当前工作目录下的 .env
    3. 用户目录 ~/.xqcxunlei/.env
    4. 模块目录下的 .env

    Returns:
        找到的 .env 文件路径，如果未找到则返回 None
    """
    if config_file:
        path = Path(config_file)
        if path.exists():
            return path
        return None

    search_paths = [
        Path.cwd() / ".env",
        Path.home() / ".xqcxunlei" / ".env",
    ]

    # 添加模块目录
    module_dir = Path(__file__).parent.parent
    skill_env = module_dir / "xqcxunlei-skill" / ".env"
    if skill_env.exists():
        search_paths.append(skill_env)
    search_paths.append(module_dir / ".env")

    for path in search_paths:
        if path.exists():
            return path

    return None


class ConfigManager:
    """配置管理器"""

    def __init__(self, config_file: Optional[str] = None, load_dotenv: bool = True):
        """
        初始化配置管理器

        Args:
            config_file: 配置文件路径
            load_dotenv: 是否加载 .env 文件
        """
        self.config_file = config_file

        # 如果需要加载 .env 文件
        if load_dotenv:
            env_path = _find_env_file(config_file)
            if env_path:
                _do_load_dotenv(env_path)
            else:
                import logging

                logging.debug(".env file not found, searched in: cwd, ~/.xqcxunlei/, module dir")

        # 初始化配置
        self.config = Config()

    def get_config(self) -> Config:
        """获取当前配置"""
        return self.config

    def update_config(self, **kwargs) -> None:
        """更新配置项"""
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
            else:
                raise AttributeError(f"'{key}' is not a valid configuration option")

        # 重新验证配置
        self.config.validate()

    def reload(self) -> None:
        """重新加载配置（例如从环境变量或 .env 文件）"""
        # 重新初始化配置对象，它会自动从环境变量读取最新值
        self.config = Config()


# 全局配置实例
_config_manager: Optional[ConfigManager] = None


def get_config_manager(config_file: Optional[str] = None) -> ConfigManager:
    """获取全局配置管理器实例"""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager(config_file)
    return _config_manager


def get_config() -> Config:
    """获取全局配置"""
    return get_config_manager().get_config()


def update_config(**kwargs) -> None:
    """更新全局配置"""
    get_config_manager().update_config(**kwargs)


def reload_config() -> None:
    """重新加载全局配置"""
    get_config_manager().reload()


def create_default_env_file(filepath: str = ".env") -> None:
    """创建默认的 .env 配置文件"""
    content = """# Xunlei API Configuration
# Copy this file to .env and set your values

# Authentication
XUNLEI_USERNAME=your_username_here
XUNLEI_PASSWORD=your_password_here

# Cache settings
XUNLEI_CACHE_FILE=
XUNLEI_CACHE_DIR=
XUNLEI_AUTO_SAVE=true

# HTTP settings
XUNLEI_REQUEST_TIMEOUT=30
XUNLEI_MAX_RETRIES=2
XUNLEI_RETRY_DELAY=1.0

# Log settings
XUNLEI_LOG_LEVEL=INFO
XUNLEI_LOG_FORMAT=%(asctime)s - %(name)s - %(levelname)s - %(message)s

# API URLs (optional, defaults are set)
# XUNLEI_RISK_URL=https://xluser-ssl.xunlei.com/risk
# XUNLEI_FILES_URL=https://api-pan.xunlei.com/drive/v1/files
"""

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"Default .env file created at: {filepath}")
    print("Please update the values in the .env file before using the API.")
