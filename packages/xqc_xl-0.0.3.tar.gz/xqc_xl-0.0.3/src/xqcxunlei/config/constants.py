"""
Xunlei API 常量定义模块

定义项目中使用的各种常量，避免魔法数字
"""

__all__ = [
    # HTTP 状态码
    "HTTP_STATUS_OK",
    "HTTP_STATUS_BAD_REQUEST",
    "HTTP_STATUS_UNAUTHORIZED",
    "HTTP_STATUS_FORBIDDEN",
    "HTTP_STATUS_TOO_MANY_REQUESTS",
    "HTTP_STATUS_SERVER_ERRORS_START",
    "HTTP_STATUS_SERVER_ERRORS_END",
    "HTTP_STATUS_INTERNAL_SERVER_ERROR",
    "HTTP_STATUS_BAD_GATEWAY",
    "HTTP_STATUS_SERVICE_UNAVAILABLE",
    "HTTP_STATUS_GATEWAY_TIMEOUT",
    # 文件大小常量
    "FILE_SIZE_1MB",
    "FILE_SIZE_10MB",
    "FILE_SIZE_1GB",
    # 分片上传阈值
    "UPLOAD_RESUMABLE_THRESHOLD",
    # 数值范围限制
    "MAX_VALID_DAYS",
    "MAX_EXTRACTION_TIMES",
    "MAX_PATH_LENGTH",
    "MAX_FILENAME_LENGTH",
    "MIN_ASCII_VISIBLE",
    # 重试和超时常量
    "DEFAULT_TIMEOUT",
    "MAX_RETRIES",
    "DEFAULT_RETRY_DELAY",
    # Token 过期时间
    "ACCESS_TOKEN_EXPIRES",
    "CAPTCHA_TOKEN_EXPIRES",
    # 算法列表
    "ALGORITHMS",
    # 缓存相关
    "DEFAULT_CACHE_TTL",
    "DEFAULT_CACHE_DIR",
    # 文件字段
    "SIMPLIFIED_FILE_FIELDS",
]

# HTTP 状态码常量
HTTP_STATUS_OK = 200
HTTP_STATUS_BAD_REQUEST = 400
HTTP_STATUS_UNAUTHORIZED = 401
HTTP_STATUS_FORBIDDEN = 403
HTTP_STATUS_TOO_MANY_REQUESTS = 429
HTTP_STATUS_SERVER_ERRORS_START = 500
HTTP_STATUS_SERVER_ERRORS_END = 599
HTTP_STATUS_INTERNAL_SERVER_ERROR = 500
HTTP_STATUS_BAD_GATEWAY = 502
HTTP_STATUS_SERVICE_UNAVAILABLE = 503
HTTP_STATUS_GATEWAY_TIMEOUT = 504

# 文件大小常量
FILE_SIZE_1MB = 1024 * 1024  # 1MB
FILE_SIZE_10MB = 10 * 1024 * 1024  # 10MB
FILE_SIZE_1GB = 1024 * 1024 * 1024  # 1GB

# 分片上传阈值
UPLOAD_RESUMABLE_THRESHOLD = 1048576  # 1MB

# 数值范围限制
MAX_VALID_DAYS = 7
MAX_EXTRACTION_TIMES = 20
MAX_PATH_LENGTH = 4096
MAX_FILENAME_LENGTH = 255
MIN_ASCII_VISIBLE = 32  # ASCII 32 是空格字符，低于此值的是控制字符

# 重试和超时常量
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 2
DEFAULT_RETRY_DELAY = 1.0

# Token 过期时间（秒）
ACCESS_TOKEN_EXPIRES = 43200  # 12小时
CAPTCHA_TOKEN_EXPIRES = 300  # 5分钟

# Algorithms 列表 (用于 CaptchaSign)
ALGORITHMS = [
    {"alg": "md5", "salt": "t24w3VjaHB++4RM"},
    {"alg": "md5", "salt": "pgA9zT3GQqQhXyWwL"},
    {"alg": "md5", "salt": "35Nt1aQOI67"},
    {"alg": "md5", "salt": "lKwoU/SK0AJ3y6vn+l3n"},
    {"alg": "md5", "salt": "h3OGLCTCzmbhJLmb6WTNq8ogHNuI8GnpVUJ"},
    {"alg": "md5", "salt": "v0Br3m00h2g5cXF1Zbpbt4DNh9/8tt8"},
    {"alg": "md5", "salt": "vOSCqn9uXdX02Nt4pQCoRmj0WiY7AvDh6"},
    {"alg": "md5", "salt": "oa2PBcypZ"},
    {"alg": "md5", "salt": "NeNF/rCYnaA1Yp"},
    {"alg": "md5", "salt": "yDCpWLF5b"},
    {"alg": "md5", "salt": "xK9k"},
    {"alg": "md5", "salt": "K0ACI+Yf"},
    {"alg": "md5", "salt": "XDWXowjmmnp1GF"},
    {"alg": "md5", "salt": "cX5DR4LoIKZy2hbC2xmVy"},
    {"alg": "md5", "salt": "VZVfriR9"},
]

# 缓存相关
DEFAULT_CACHE_TTL = 7200
DEFAULT_CACHE_DIR = ".xqcxunlei_cache"


SIMPLIFIED_FILE_FIELDS: tuple[str, ...] = (
    "id",
    "name",
    "path",
    "parent_id",
    "kind",
    "mime_type",
    "file_extension",
    "size",
    "size_human",
    "web_content_link",
    "share_links",
)
