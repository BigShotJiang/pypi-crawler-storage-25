"""
Xunlei API Python SDK

提供迅雷云盘和远程下载的统一接口。

主要功能:
- 纯 HTTP 登录 (无需浏览器)
- 高效 Token 缓存
- 云盘文件管理
- 离线下载任务
- 远程下载设备管理
- 环境变量和 .env 文件支持
- 增强的日志功能
- 统一的错误处理
- 更好的类型提示

快速开始:

    import asyncio
    from xqcxunlei import Xunlei

    async def main():
        async with Xunlei("username", "password") as xunlei:
            # 云盘操作
            files = await xunlei.cloud.get_files()
            print(files)

            # 远程下载
            devices = await xunlei.remote.get_devices()
            print(devices)

    asyncio.run(main())
"""

from __future__ import annotations

from .api import (
    CloudFileExistsStrategy,
    RemoteDownloadConflictStrategy,
    TransferOwnShareStrategy,
    XunleiCloudDisk,
    XunleiRemoteDownloader,
)
from .api.downloader import ConsoleProgressTracker, Downloader, DownloadProgress, DownloadResult
from .auth import TokenCache
from .client import XunleiBase
from .config import (
    ACCESS_TOKEN_EXPIRES,
    CAPTCHA_TOKEN_EXPIRES,
    DEFAULT_RETRY_DELAY,
    DEFAULT_TIMEOUT,
    FILE_SIZE_1GB,
    FILE_SIZE_1MB,
    FILE_SIZE_10MB,
    HTTP_STATUS_BAD_GATEWAY,
    HTTP_STATUS_BAD_REQUEST,
    HTTP_STATUS_FORBIDDEN,
    HTTP_STATUS_GATEWAY_TIMEOUT,
    HTTP_STATUS_INTERNAL_SERVER_ERROR,
    # 常量
    HTTP_STATUS_OK,
    HTTP_STATUS_SERVER_ERRORS_END,
    HTTP_STATUS_SERVER_ERRORS_START,
    HTTP_STATUS_SERVICE_UNAVAILABLE,
    HTTP_STATUS_TOO_MANY_REQUESTS,
    HTTP_STATUS_UNAUTHORIZED,
    MAX_EXTRACTION_TIMES,
    MAX_FILENAME_LENGTH,
    MAX_PATH_LENGTH,
    MAX_RETRIES,
    MAX_VALID_DAYS,
    MIN_ASCII_VISIBLE,
    UPLOAD_RESUMABLE_THRESHOLD,
    Config,
    ConfigManager,
    create_default_env_file,
    get_config,
)
from .utils import (
    AuthenticationError,
    BadRequestError,
    FileNotFoundError,
    FileOperationError,
    InsufficientStorageError,
    LoginRequiredError,
    MatchCallback,
    NetworkError,
    PermissionDeniedError,
    QuotaExceededError,
    RateLimitError,
    ReplaceCallback,
    RequestTimeoutError,
    ServiceUnavailableError,
    ShareFileFilter,
    ShareLinkCallback,
    TokenExpiredError,
    UnknownError,
    ValidationError,
    XunleiError,
    filter_any_of,
    filter_by_extension,
    filter_by_name_pattern,
    filter_by_size,
    filter_combine,
    filter_exclude_by_name_pattern,
    filter_negate,
    filter_only_directories,
    # 分享转存过滤器
    filter_only_files,
    get_logger,
    handle_http_error,
    # 匹配回调函数
    match_any_of,
    match_combine,
    match_created_after,
    match_created_before,
    match_extension_is,
    match_extensions_are,
    match_glob,
    match_is_backup,
    match_is_file,
    match_is_folder,
    match_is_hidden,
    match_modified_after,
    match_modified_before,
    match_name_contains,
    match_name_ends_with,
    match_name_exactly,
    match_name_starts_with,
    match_negate,
    match_path_contains,
    match_regex,
    match_size_between,
    match_size_greater_than,
    match_size_less_than,
    # 替换回调函数
    replace_add_prefix,
    replace_add_suffix,
    replace_change_extension,
    replace_date_prefix,
    replace_date_suffix,
    replace_insert_at,
    replace_regex,
    replace_remove_extension,
    replace_remove_matching,
    replace_remove_prefix,
    replace_remove_suffix,
    replace_sequential,
    replace_template,
    replace_to_lowercase,
    replace_to_uppercase,
    replace_with,
    # 分享链接回调函数
    share_link_callback_cancel_failed,
    share_link_callback_format_markdown,
    share_link_callback_only_existing,
    share_link_callback_only_new,
    share_link_callback_only_shared,
    share_link_callback_only_valid,
    share_link_callback_skip_failed,
    share_link_callback_with_passcode_only,
    validate_file_path,
    validate_file_size,
    validate_response,
    validate_user_credentials,
)
from .xunlei import Xunlei

__version__ = "0.0.3"
__all__ = [
    "Xunlei",
    "XunleiBase",
    "XunleiCloudDisk",
    "XunleiRemoteDownloader",
    "CloudFileExistsStrategy",
    "RemoteDownloadConflictStrategy",
    "TransferOwnShareStrategy",
    "TokenCache",
    "Config",
    "ConfigManager",
    "get_config",
    "create_default_env_file",
    "get_logger",
    # Exceptions
    "XunleiError",
    "AuthenticationError",
    "TokenExpiredError",
    "LoginRequiredError",
    "NetworkError",
    "RequestTimeoutError",
    "RateLimitError",
    "ValidationError",
    "FileOperationError",
    "FileNotFoundError",
    "InsufficientStorageError",
    "QuotaExceededError",
    "ServiceUnavailableError",
    "BadRequestError",
    "PermissionDeniedError",
    "UnknownError",
    "handle_http_error",
    "validate_response",
    "validate_file_path",
    "validate_user_credentials",
    "validate_file_size",
    # 匹配回调函数
    "match_any_of",
    "match_combine",
    "match_created_after",
    "match_created_before",
    "match_extension_is",
    "match_extensions_are",
    "match_glob",
    "match_is_backup",
    "match_is_file",
    "match_is_folder",
    "match_is_hidden",
    "match_modified_after",
    "match_modified_before",
    "match_name_contains",
    "match_name_ends_with",
    "match_name_exactly",
    "match_name_starts_with",
    "match_negate",
    "MatchCallback",
    "ReplaceCallback",
    "match_path_contains",
    "match_regex",
    "match_size_between",
    "match_size_greater_than",
    "match_size_less_than",
    # 替换回调函数
    "replace_add_prefix",
    "replace_add_suffix",
    "replace_change_extension",
    "replace_date_prefix",
    "replace_date_suffix",
    "replace_insert_at",
    "replace_regex",
    "replace_remove_extension",
    "replace_remove_matching",
    "replace_remove_prefix",
    "replace_remove_suffix",
    "replace_sequential",
    "replace_template",
    "replace_to_lowercase",
    "replace_to_uppercase",
    "replace_with",
    # 分享转存过滤器
    "filter_only_files",
    "filter_only_directories",
    "filter_by_extension",
    "filter_by_size",
    "filter_by_name_pattern",
    "filter_exclude_by_name_pattern",
    "filter_combine",
    "filter_any_of",
    "filter_negate",
    "ShareFileFilter",
    # 分享链接回调函数
    "ShareLinkCallback",
    "share_link_callback_cancel_failed",
    "share_link_callback_format_markdown",
    "share_link_callback_only_existing",
    "share_link_callback_only_new",
    "share_link_callback_only_shared",
    "share_link_callback_only_valid",
    "share_link_callback_skip_failed",
    "share_link_callback_with_passcode_only",
    # Constants
    "HTTP_STATUS_OK",
    "HTTP_STATUS_BAD_REQUEST",
    "HTTP_STATUS_UNAUTHORIZED",
    "HTTP_STATUS_FORBIDDEN",
    "HTTP_STATUS_TOO_MANY_REQUESTS",
    "HTTP_STATUS_SERVER_ERRORS_START",
    "HTTP_STATUS_SERVER_ERRORS_END",
    "HTTP_STATUS_INTERNAL_SERVER_ERROR",
    "HTTP_STATUS_BAD_GATEWAY",
    "HTTP_STATUS_SERVICE_UNAVAILABLE",
    "HTTP_STATUS_GATEWAY_TIMEOUT",
    "FILE_SIZE_1MB",
    "FILE_SIZE_10MB",
    "FILE_SIZE_1GB",
    "UPLOAD_RESUMABLE_THRESHOLD",
    "MAX_VALID_DAYS",
    "MAX_EXTRACTION_TIMES",
    "MAX_PATH_LENGTH",
    "MAX_FILENAME_LENGTH",
    "MIN_ASCII_VISIBLE",
    "DEFAULT_TIMEOUT",
    "MAX_RETRIES",
    "DEFAULT_RETRY_DELAY",
    "ACCESS_TOKEN_EXPIRES",
    "CAPTCHA_TOKEN_EXPIRES",
    # Downloader
    "Downloader",
    "DownloadProgress",
    "DownloadResult",
    "ConsoleProgressTracker",
]
