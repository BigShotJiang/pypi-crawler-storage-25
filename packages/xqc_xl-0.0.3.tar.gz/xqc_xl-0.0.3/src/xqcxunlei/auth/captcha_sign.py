"""
CaptchaSign 签名算法模块

实现 Xunlei API 所需的 CaptchaSign 签名生成:
1. MD5 哈希算法
2. 多轮 salt 加密
3. 时间戳精确到毫秒
4. 增强日志功能
"""

from __future__ import annotations

import hashlib
import time
from typing import Optional

from ..config import get_config


def md5_hash(value: str) -> str:
    """计算字符串的 MD5 哈希值"""
    return hashlib.md5(value.encode("utf-8")).hexdigest()


async def get_pub_key_sign(login_device_id: str, timestamp: Optional[str] = None) -> str:
    """
    生成 CaptchaSign 签名

    参考: webpack://src/api/get_pub_key_sign.js

    签名格式:
        captchaSign = client_id + client_version + package_name + device_id + timestamp
        对上述字符串依次进行多轮 MD5 加密 (每轮附加 salt)
        最终返回: "1." + 加密结果

    Args:
        login_device_id: 登录设备 ID
        timestamp: 时间戳 (毫秒), 默认为当前时间

    Returns:
        签名字符串, 格式: "1.xxxxxx"
    """
    config = get_config()

    if timestamp is None:
        timestamp = str(int(time.time() * 1000))

    # 初始化签名字符串
    captcha_sign = (
        f"{config.token_client_id}"
        f"{config.client_version}"
        f"{config.package_name}"
        f"{login_device_id}"
        f"{timestamp}"
    )

    # 依次执行 MD5 加密
    from ..config import ALGORITHMS

    for item in ALGORITHMS:
        captcha_sign = md5_hash(f"{captcha_sign}{item['salt']}")

    # 返回带版本号的签名
    return f"{config.alg_version}.{captcha_sign}"


def get_pub_key_sign_sync(login_device_id: str, timestamp: Optional[str] = None) -> str:
    """
    同步版本的 CaptchaSign 签名生成

    Args:
        login_device_id: 登录设备 ID
        timestamp: 时间戳 (毫秒), 默认为当前时间

    Returns:
        签名字符串, 格式: "1.xxxxxx"
    """
    config = get_config()

    if timestamp is None:
        timestamp = str(int(time.time() * 1000))

    captcha_sign = (
        f"{config.token_client_id}"
        f"{config.client_version}"
        f"{config.package_name}"
        f"{login_device_id}"
        f"{timestamp}"
    )

    from ..config import ALGORITHMS

    for item in ALGORITHMS:
        captcha_sign = md5_hash(f"{captcha_sign}{item['salt']}")

    return f"{config.alg_version}.{captcha_sign}"


def generate_device_id(xl_fp_raw: str = "53793f98c0f944f0837946d9d694c55b") -> str:
    """
    生成虚拟设备 ID

    通过 xl_fp_raw 生成 device_sign, 然后提取 device_id

    Args:
        xl_fp_raw: 设备指纹原始值

    Returns:
        32 位设备 ID
    """
    # 实际 device_sign 来自 API 响应
    # 这里只是示例格式
    import secrets

    return secrets.token_hex(16)
