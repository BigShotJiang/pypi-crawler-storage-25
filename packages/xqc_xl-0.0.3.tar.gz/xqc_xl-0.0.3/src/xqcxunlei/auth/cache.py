"""
Xunlei Token 缓存模块

提供高效的 Token 缓存机制:
- 内存缓存 + 文件持久化
- 自动过期检测
- 缓存文件校验与自动恢复
- 优化的并发控制 (读写锁)
- 增强日志功能
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import aiofiles

from ..utils import get_logger

logger = get_logger(__name__)


@dataclass
class TokenData:
    """Token 数据结构"""

    access_token: str = ""
    captcha_token: str = ""
    refresh_token: str = ""
    device_id: str = ""
    user_id: str = ""
    username: str = ""

    # 过期时间戳
    access_token_expires_at: float = 0
    captcha_token_expires_at: float = 0

    # 状态
    is_login: bool = False

    @property
    def access_token_expired(self) -> bool:
        """检查 access_token 是否过期"""
        return time.time() >= self.access_token_expires_at

    @property
    def captcha_token_expired(self) -> bool:
        """检查 captcha_token 是否过期"""
        return time.time() >= self.captcha_token_expires_at

    @property
    def needs_refresh(self) -> bool:
        """检查是否需要刷新 captcha_token"""
        # 提前1分钟刷新
        return time.time() >= (self.captcha_token_expires_at - 60)

    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "access_token": self.access_token,
            "captcha_token": self.captcha_token,
            "refresh_token": self.refresh_token,
            "device_id": self.device_id,
            "user_id": self.user_id,
            "username": self.username,
            "access_token_expires_at": self.access_token_expires_at,
            "captcha_token_expires_at": self.captcha_token_expires_at,
            "is_login": self.is_login,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TokenData":
        """从字典创建"""
        return cls(
            access_token=data.get("access_token", ""),
            captcha_token=data.get("captcha_token", ""),
            refresh_token=data.get("refresh_token", ""),
            device_id=data.get("device_id", ""),
            user_id=data.get("user_id", ""),
            username=data.get("username", ""),
            access_token_expires_at=data.get("access_token_expires_at", 0),
            captcha_token_expires_at=data.get("captcha_token_expires_at", 0),
            is_login=data.get("is_login", False),
        )


class ReadWriteLock:
    """
    读写锁实现

    读操作可以并发，写操作独占
    """

    def __init__(self):
        self._mutex = asyncio.Lock()  # 保护内部状态的互斥锁
        self._readers = 0  # 当前活跃的读者数量
        self._writers_waiting = 0  # 等待的写者数量
        self._writer_active = False  # 是否有写者在活动
        self._read_ready = asyncio.Condition(self._mutex)  # 用于通知读者可以开始读

    async def acquire_read(self):
        """获取读锁"""
        async with self._mutex:
            # 等待直到没有写者活跃或等待
            while self._writer_active or self._writers_waiting > 0:
                await self._read_ready.wait()
            self._readers += 1

    async def release_read(self):
        """释放读锁"""
        async with self._mutex:
            self._readers -= 1
            if self._readers == 0:
                # 所有读者都已释放，唤醒等待的写者
                self._read_ready.notify_all()

    async def acquire_write(self):
        """获取写锁"""
        async with self._mutex:
            self._writers_waiting += 1
            # 等待直到没有读者和活跃的写者
            while self._readers > 0 or self._writer_active:
                await self._read_ready.wait()
            self._writers_waiting -= 1
            self._writer_active = True

    async def release_write(self):
        """释放写锁"""
        async with self._mutex:
            self._writer_active = False
            # 唤醒所有等待的协程（读者和写者）
            self._read_ready.notify_all()


class TokenCache:
    """
    Token 缓存管理器

    特性:
    - 内存缓存 + 文件持久化
    - 自动过期检测
    - 延迟保存 (减少 IO)
    - 异步操作
    - 默认保存在系统临时目录
    - 缓存文件校验与自动恢复
    - 优化的并发控制 (读写锁)
    """

    DEFAULT_CACHE_DIR = tempfile.gettempdir()
    SAVE_DELAY = 1.0  # 延迟保存时间 (秒)
    MAX_CACHE_SIZE = 10 * 1024 * 1024  # 最大缓存大小 10MB

    def __init__(
        self,
        username: str,
        cache_file: Optional[str] = None,
        cache_dir: Optional[str] = None,
        auto_save: bool = True,
    ) -> None:
        self.username = username
        self.auto_save = auto_save

        # 确定缓存文件路径
        if cache_file:
            self.cache_file = cache_file
        else:
            cache_filename = f"xqcxunlei_{username}.json"
            cache_dir_path = cache_dir or self.DEFAULT_CACHE_DIR
            self.cache_file = str(Path(cache_dir_path) / cache_filename)

        self._tokens: TokenData = TokenData()
        self._dirty: bool = False
        self._save_task: Optional[asyncio.Task] = None

        # 使用读写锁优化并发性能
        self._rw_lock = ReadWriteLock()

        # 用于延迟保存的锁
        self._save_lock = asyncio.Lock()

        # 如果缓存文件存在，尝试加载
        if Path(self.cache_file).exists():
            self.load()

    @property
    def tokens(self) -> TokenData:
        """获取 Token 数据"""
        return self._tokens

    @property
    def is_login(self) -> bool:
        """是否已登录"""
        return self._tokens.is_login and bool(self._tokens.access_token)

    @property
    def is_access_token_valid(self) -> bool:
        """access_token 是否有效"""
        return bool(self._tokens.access_token) and not self._tokens.access_token_expired

    @property
    def is_captcha_token_valid(self) -> bool:
        """captcha_token 是否有效"""
        return bool(self._tokens.captcha_token) and not self._tokens.captcha_token_expired

    def _calculate_checksum(self, data: str) -> str:
        """计算数据校验和"""
        return hashlib.sha256(data.encode("utf-8")).hexdigest()

    def _validate_cache_file(self, file_path: str) -> bool:
        """校验缓存文件完整性"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # 检查文件大小是否超过限制
            if len(content) > self.MAX_CACHE_SIZE:
                logger.warning(f"缓存文件过大: {len(content)} 字节")
                return False

            # 尝试解析JSON格式
            data = json.loads(content)

            # 验证必要的字段是否存在
            required_fields = ["access_token", "username"]
            for field in required_fields:
                if field not in data:
                    logger.warning(f"缓存文件缺少必要字段: {field}")
                    return False

            # 验证用户名是否匹配
            if data.get("username", "") != self.username:
                logger.warning(f"缓存用户不匹配: {data.get('username')} != {self.username}")
                return False

            return True
        except (json.JSONDecodeError, FileNotFoundError, UnicodeDecodeError) as e:
            logger.warning(f"缓存文件校验失败: {e}")
            return False

    def load(self) -> bool:
        """同步加载缓存"""
        try:
            # 检查文件是否存在
            if not Path(self.cache_file).exists():
                logger.debug(f"缓存文件不存在: {self.cache_file}")
                return False

            # 首先校验缓存文件
            if not self._validate_cache_file(self.cache_file):
                logger.warning(f"缓存文件校验失败，尝试恢复: {self.cache_file}")
                return self._recover_from_corrupted_cache()

            with open(self.cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            self._tokens = TokenData.from_dict(data)
            logger.debug(f"已加载 Token 缓存: user_id={self._tokens.user_id}")

            return True
        except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"加载缓存失败: {e}")
            return False

    async def load_async(self) -> bool:
        """异步加载缓存"""
        try:
            # 检查文件是否存在
            if not Path(self.cache_file).exists():
                logger.debug(f"缓存文件不存在: {self.cache_file}")
                return False

            # 获取读锁
            await self._rw_lock.acquire_read()
            try:
                # 首先校验缓存文件
                if not self._validate_cache_file(self.cache_file):
                    logger.warning(f"缓存文件校验失败，尝试恢复: {self.cache_file}")
                    return await self._recover_from_corrupted_cache_async()

                async with aiofiles.open(self.cache_file, "r", encoding="utf-8") as f:
                    content = await f.read()
                    data = json.loads(content)

                cached_username = data.get("username", "")
                if cached_username != self.username:
                    return False

                self._tokens = TokenData.from_dict(data)
                logger.debug(f"已加载 Token 缓存: user_id={self._tokens.user_id}")

                return True
            finally:
                await self._rw_lock.release_read()
        except (FileNotFoundError, json.JSONDecodeError, KeyError):
            return False

    def save(self) -> bool:
        """同步保存缓存"""
        try:
            # 序列化数据
            serialized_data = json.dumps(self._tokens.to_dict(), ensure_ascii=False, indent=2)

            # 保存到文件
            with open(self.cache_file, "w", encoding="utf-8") as f:
                f.write(serialized_data)

            self._dirty = False
            logger.debug("Token 缓存已保存")
            return True
        except IOError as e:
            logger.error(f"保存缓存失败: {e}")
            return False

    async def save_async(self) -> bool:
        """异步保存缓存"""
        try:
            # 获取写锁
            await self._rw_lock.acquire_write()
            try:
                # 序列化数据
                serialized_data = json.dumps(self._tokens.to_dict(), ensure_ascii=False, indent=2)

                # 保存到文件
                async with aiofiles.open(self.cache_file, "w", encoding="utf-8") as f:
                    await f.write(serialized_data)

                self._dirty = False
                logger.debug("Token 缓存已保存")

                return True
            finally:
                await self._rw_lock.release_write()
        except IOError as e:
            logger.error(f"保存缓存失败: {e}")
            return False

    def _schedule_save(self) -> None:
        """调度延迟保存"""
        if not self._dirty or not self.auto_save:
            return

        try:
            asyncio.get_running_loop()
            if self._save_task is not None and not self._save_task.done():
                return
            self._save_task = asyncio.create_task(self._delayed_save())
        except RuntimeError:
            self.save()

    async def _delayed_save(self) -> None:
        """延迟保存"""
        await asyncio.sleep(self.SAVE_DELAY)
        await self.save_async()

    def update(self, **kwargs: Any) -> None:
        """更新 Token 数据"""
        # 如果在事件循环中，创建任务，否则直接执行
        try:
            asyncio.get_running_loop()
            self._update_in_async_environment(kwargs)
        except RuntimeError:
            self._update_in_sync_environment(kwargs)

    def _update_in_async_environment(self, kwargs: dict[str, Any]) -> None:
        """在异步环境中更新"""
        # 立即在同步代码中也更新内存中的值，以确保同步访问能立即看到更改
        for key, value in kwargs.items():
            if hasattr(self._tokens, key):
                setattr(self._tokens, key, value)
            else:
                logger.warning(f"未知的 Token 字段: {key}")

        # 创建异步任务来处理锁和其他异步操作
        async def _update_tokens():
            await self._rw_lock.acquire_write()
            try:
                for key, value in kwargs.items():
                    if hasattr(self._tokens, key):
                        setattr(self._tokens, key, value)
                    else:
                        logger.warning(f"未知的 Token 字段: {key}")

                self._dirty = True
                if self.auto_save:
                    self._schedule_save()
            finally:
                await self._rw_lock.release_write()

        asyncio.create_task(_update_tokens())

    def _update_in_sync_environment(self, kwargs: dict[str, Any]) -> None:
        """在同步环境中更新"""
        for key, value in kwargs.items():
            if hasattr(self._tokens, key):
                setattr(self._tokens, key, value)
            else:
                logger.warning(f"未知的 Token 字段: {key}")

        self._dirty = True
        if self.auto_save:
            self._schedule_save()

    def set_access_token(
        self,
        access_token: str,
        expires_in: int = 43200,  # 12小时
    ) -> None:
        """设置 access_token"""
        self.update(
            access_token=access_token,
            access_token_expires_at=time.time() + expires_in,
        )

    def set_captcha_token(
        self,
        captcha_token: str,
        expires_in: int = 300,  # 5分钟
    ) -> None:
        """设置 captcha_token"""
        self.update(
            captcha_token=captcha_token,
            captcha_token_expires_at=time.time() + expires_in,
        )

    def set_login(
        self,
        access_token: str,
        user_id: str,
        expires_in: int = 43200,  # 12小时
    ) -> None:
        """设置登录状态"""
        self.update(
            is_login=True,
            access_token=access_token,
            user_id=user_id,
            username=self.username,
            access_token_expires_at=time.time() + expires_in,
        )

    def clear(self) -> None:
        """清除缓存"""

        # 获取写锁
        async def _clear_tokens():
            await self._rw_lock.acquire_write()
            try:
                self._tokens = TokenData()
                self._dirty = True
                if self.auto_save:
                    self._schedule_save()

                # 删除缓存文件
                try:
                    Path(self.cache_file).unlink(missing_ok=True)
                except IOError:
                    pass
            finally:
                await self._rw_lock.release_write()

        # 如果在事件循环中，创建任务，否则直接执行
        try:
            asyncio.get_running_loop()
            asyncio.create_task(_clear_tokens())
        except RuntimeError:
            self._tokens = TokenData()
            self._dirty = True
            if self.auto_save:
                self._schedule_save()

            # 删除缓存文件
            try:
                Path(self.cache_file).unlink(missing_ok=True)
            except IOError:
                pass

    async def close(self) -> None:
        """关闭缓存，确保保存"""
        if self._save_task is not None and not self._save_task.done():
            self._save_task.cancel()
            try:
                await self._save_task
            except asyncio.CancelledError:
                pass

        if self._dirty:
            await self.save_async()

    def get_headers(self) -> dict[str, str]:
        """获取 API 请求头"""

        # 获取读锁
        async def _get_headers():
            await self._rw_lock.acquire_read()
            try:
                return {
                    "Authorization": f"Bearer {self._tokens.access_token}",
                    "x-captcha-token": self._tokens.captcha_token,
                    "x-device-id": self._tokens.device_id,
                    "Origin": "https://pan.xunlei.com",
                    "Referer": "https://pan.xunlei.com/",
                }
            finally:
                await self._rw_lock.release_read()

        # 如果在事件循环中，创建任务，否则直接返回
        try:
            asyncio.get_running_loop()
            # 由于需要返回值，我们同步获取当前值
            return {
                "Authorization": f"Bearer {self._tokens.access_token}",
                "x-captcha-token": self._tokens.captcha_token,
                "x-device-id": self._tokens.device_id,
                "Origin": "https://pan.xunlei.com",
                "Referer": "https://pan.xunlei.com/",
            }
        except RuntimeError:
            return {
                "Authorization": f"Bearer {self._tokens.access_token}",
                "x-captcha-token": self._tokens.captcha_token,
                "x-device-id": self._tokens.device_id,
                "Origin": "https://pan.xunlei.com",
                "Referer": "https://pan.xunlei.com/",
            }

    def get_auth_headers(self) -> dict[str, str]:
        """获取认证请求头"""
        # 同样处理读操作
        try:
            asyncio.get_running_loop()
            return {
                "Authorization": f"Bearer {self._tokens.access_token}",
            }
        except RuntimeError:
            return {
                "Authorization": f"Bearer {self._tokens.access_token}",
            }

    def should_auto_login(self) -> bool:
        """判断是否需要自动登录"""
        try:
            asyncio.get_running_loop()
            # 在事件循环中需要异步获取，所以直接返回当前状态
            return not self.is_login or self._tokens.access_token_expired
        except RuntimeError:
            return not self.is_login or self._tokens.access_token_expired

    def should_refresh_captcha(self) -> bool:
        """判断是否需要刷新验证码token"""
        try:
            asyncio.get_running_loop()
            return self.is_login and self._tokens.needs_refresh
        except RuntimeError:
            return self.is_login and self._tokens.needs_refresh

    def _recover_from_corrupted_cache(self) -> bool:
        """从损坏的缓存中恢复 - 简化版：直接清空缓存，强制重新登录"""
        logger.info("检测到缓存文件损坏，清空缓存并触发重新登录...")

        corrupted_file = f"{self.cache_file}.corrupted"

        try:
            # 移动损坏的文件以供后续分析（可选）
            if Path(self.cache_file).exists():
                Path(self.cache_file).rename(corrupted_file)
                logger.warning(f"已将损坏的缓存文件移动到: {corrupted_file}")

            # 直接清空缓存数据
            self._tokens = TokenData()
            self._dirty = False

            logger.info("缓存已清空，下次操作将触发重新登录")
            return True
        except Exception as e:
            logger.error(f"缓存恢复失败: {e}")
            # 确保缓存被清空以触发重新登录
            self._tokens = TokenData()
            return False

    async def _recover_from_corrupted_cache_async(self) -> bool:
        """异步从损坏的缓存中恢复 - 简化版：直接清空缓存，强制重新登录"""
        logger.info("异步检测到缓存文件损坏，清空缓存并触发重新登录...")

        corrupted_file = f"{self.cache_file}.corrupted"

        try:
            # 获取写锁
            await self._rw_lock.acquire_write()
            try:
                # 移动损坏的文件以供后续分析（可选）
                if Path(self.cache_file).exists():
                    Path(self.cache_file).rename(corrupted_file)
                    logger.warning(f"已将损坏的缓存文件移动到: {corrupted_file}")

                # 直接清空缓存数据
                self._tokens = TokenData()
                self._dirty = False

                logger.info("缓存已清空，下次操作将触发重新登录")
                return True
            finally:
                await self._rw_lock.release_write()
        except Exception as e:
            logger.error(f"缓存恢复失败: {e}")
            # 获取写锁进行最终回退
            await self._rw_lock.acquire_write()
            try:
                # 确保缓存被清空以触发重新登录
                self._tokens = TokenData()
                return False
            finally:
                await self._rw_lock.release_write()


class CacheManager:
    """
    多用户缓存管理器

    支持多个用户独立缓存，带有校验和恢复功能
    """

    def __init__(self, cache_dir: Optional[str] = None) -> None:
        self.cache_dir = cache_dir  # 可选的自定义缓存目录
        self._caches: dict[str, TokenCache] = {}
        self._lock = asyncio.Lock()  # 用于管理缓存字典的锁

    def get_cache(
        self,
        username: str,
        cache_file: Optional[str] = None,
        cache_dir: Optional[str] = None,
        auto_save: bool = True,
    ) -> TokenCache:
        """获取用户缓存"""
        if username not in self._caches:
            effective_cache_dir = cache_dir or self.cache_dir
            self._caches[username] = TokenCache(
                username, cache_file=cache_file, cache_dir=effective_cache_dir, auto_save=auto_save
            )
        return self._caches[username]

    async def close_all(self) -> None:
        """关闭所有缓存"""
        for cache in self._caches.values():
            await cache.close()
        self._caches.clear()

    def remove_cache(self, username: str) -> bool:
        """移除特定用户的缓存"""
        if username in self._caches:
            cache = self._caches.pop(username)
            asyncio.create_task(cache.close())
            return True
        return False
