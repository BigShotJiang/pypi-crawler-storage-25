"""Signal handlers for Hangar Ready"""

import logging

from django.contrib.auth.models import Permission, User
from django.contrib.contenttypes.models import ContentType
from django.db.models.signals import post_save
from django.dispatch import receiver

from allianceauth.authentication.models import CharacterOwnership

from .helpers import get_character_token
from .models import CharacterAssets

logger = logging.getLogger(__name__)


@receiver(post_save, sender=User)
def grant_basic_access_to_user(sender, instance, created, **kwargs):
    """
    Automatically grant basic_access permission to all users.

    This ensures all users can access Hangar Ready by default.
    """
    try:
        # Get the basic_access permission
        content_type = ContentType.objects.get_for_model(CharacterAssets)
        permission = Permission.objects.get(
            content_type=content_type,
            codename="basic_access"
        )

        # Add permission to user if they don't have it
        if not instance.user_permissions.filter(pk=permission.pk).exists():
            instance.user_permissions.add(permission)
            logger.debug(f"Granted basic_access permission to user {instance.username}")

    except Permission.DoesNotExist:
        logger.warning("basic_access permission does not exist yet")
    except Exception as e:
        logger.error(f"Error granting basic_access to user {instance.username}: {e}")


@receiver(post_save, sender=CharacterOwnership)
def auto_add_character_to_hangarready(sender, instance, created, **kwargs):
    """
    Automatically add characters to Hangar Ready if they have the required ESI scope.

    This checks if the character has a valid token with esi-assets.read_assets.v1 scope
    and automatically creates a CharacterAssets entry for tracking.
    """
    try:
        # Check if CharacterAssets already exists for this character
        if CharacterAssets.objects.filter(character=instance.character).exists():
            logger.debug(
                f"Character {instance.character.character_name} already tracked in Hangar Ready"
            )
            return

        # Check if character has valid token with required scope
        token = get_character_token(instance)
        if not token:
            logger.debug(
                f"Character {instance.character.character_name} does not have required "
                "esi-assets.read_assets.v1 scope, skipping auto-add"
            )
            return

        # Create CharacterAssets entry
        char_assets = CharacterAssets.objects.create(
            character=instance.character,
            token_character=instance,
            is_active=True,
        )

        logger.info(
            f"Automatically added {instance.character.character_name} to Hangar Ready"
        )

        # Queue initial asset update
        from .tasks import update_character_assets

        update_character_assets.delay(char_assets.pk)
        logger.info(f"Queued initial asset update for {instance.character.character_name}")

    except Exception as e:
        logger.error(
            f"Error auto-adding character {instance.character.character_name} "
            f"to Hangar Ready: {e}"
        )
