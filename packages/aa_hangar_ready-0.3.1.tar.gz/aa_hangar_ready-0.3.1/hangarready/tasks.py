"""Celery tasks for Hangar Ready"""

import logging
from datetime import timedelta

from celery import shared_task
from django.utils.timezone import now
from esi.clients import esi_client_factory
from eveuniverse.models import EveType

from .app_settings import HANGAR_READY_MAX_CACHE_AGE
from .app_settings import ESI_SCOPE_STRUCTURES
from .helpers import (
    chunk_list,
    determine_location_type,
    get_any_token_with_scope,
    get_character_token,
    get_location_name,
    get_type_name,
    is_ship_type,
)
from .models import AssetItem, CharacterAssets, Location

logger = logging.getLogger(__name__)


@shared_task
def update_character_assets(character_assets_pk):
    """
    Fetch and cache character assets from ESI.

    Args:
        character_assets_pk: Primary key of CharacterAssets instance

    Returns:
        str: Status message
    """
    try:
        char_assets = CharacterAssets.objects.get(pk=character_assets_pk)
    except CharacterAssets.DoesNotExist:
        logger.error(f"CharacterAssets with pk={character_assets_pk} not found")
        return f"CharacterAssets {character_assets_pk} not found"

    character = char_assets.character
    logger.info(f"Updating assets for {character.character_name}")

    # Get valid ESI token
    token = get_character_token(char_assets.token_character)
    if not token:
        error_msg = f"No valid token for {character.character_name}"
        logger.warning(error_msg)
        char_assets.update_error = error_msg
        char_assets.save()
        return error_msg

    try:
        # Get ESI client
        client = esi_client_factory(token=token)

        # Fetch all assets
        logger.debug(f"Fetching assets from ESI for {character.character_name}")
        assets_response = client.Assets.get_characters_character_id_assets(
            character_id=character.character_id
        ).results()

        # Filter for items in hangars only
        hangar_flags = [
            "Hangar",
            "ShipHangar",
            "FleetHangar",
            "CorpSAG1",
            "CorpSAG2",
            "CorpSAG3",
            "CorpSAG4",
            "CorpSAG5",
            "CorpSAG6",
            "CorpSAG7",
        ]
        hangar_assets = [
            asset for asset in assets_response if asset.get("location_flag") in hangar_flags
        ]

        logger.info(
            f"Found {len(hangar_assets)} assets in hangars for {character.character_name}"
        )

        # Collect unique type IDs to ensure they're in database
        type_ids = list(set(asset["type_id"] for asset in hangar_assets))
        _ensure_types_loaded(type_ids)

        # Collect unique location IDs for name resolution
        location_ids = list(set(asset["location_id"] for asset in hangar_assets))
        location_names = _resolve_location_names(location_ids, client)

        # Delete old assets for this character
        AssetItem.objects.filter(character_assets=char_assets).delete()

        # Bulk create new assets
        asset_items = []
        for asset in hangar_assets:
            type_id = asset["type_id"]
            location_id = asset["location_id"]

            asset_item = AssetItem(
                character_assets=char_assets,
                item_id=asset["item_id"],
                type_id=type_id,
                type_name=get_type_name(type_id),
                location_id=location_id,
                location_name=location_names.get(location_id, ""),
                location_type=determine_location_type(location_id),
                location_flag=asset.get("location_flag", ""),
                quantity=asset.get("quantity", 1),
                is_singleton=asset.get("is_singleton", True),
                is_ship=is_ship_type(type_id),
            )
            asset_items.append(asset_item)

        # Bulk insert
        AssetItem.objects.bulk_create(asset_items, batch_size=500)

        # Update success timestamp
        char_assets.last_update = now()
        char_assets.update_error = None
        char_assets.save()

        ship_count = sum(1 for item in asset_items if item.is_ship)
        success_msg = (
            f"Updated {len(asset_items)} assets ({ship_count} ships) "
            f"for {character.character_name}"
        )
        logger.info(success_msg)
        return success_msg

    except Exception as e:
        error_msg = f"Error updating assets for {character.character_name}: {str(e)}"
        logger.exception(error_msg)
        char_assets.update_error = str(e)
        char_assets.save()
        return error_msg


@shared_task
def update_all_character_assets():
    """
    Periodic task to update all active character assets.

    Returns:
        str: Status message
    """
    logger.info("Starting periodic asset update for all characters")

    active_characters = CharacterAssets.objects.active()
    total = active_characters.count()

    if total == 0:
        logger.info("No active characters to update")
        return "No active characters to update"

    # Queue update tasks for each character
    for char_assets in active_characters:
        update_character_assets.delay(char_assets.pk)

    logger.info(f"Queued {total} character asset updates")
    return f"Queued {total} character asset updates"


@shared_task
def update_stale_character_assets():
    """
    Update only character assets that are stale (older than max cache age).

    Returns:
        str: Status message
    """
    logger.info("Checking for stale character assets")

    cutoff = now() - timedelta(hours=HANGAR_READY_MAX_CACHE_AGE)
    stale_characters = CharacterAssets.objects.active().filter(last_update__lt=cutoff)
    total = stale_characters.count()

    if total == 0:
        logger.info("No stale character assets found")
        return "No stale character assets found"

    # Queue update tasks
    for char_assets in stale_characters:
        update_character_assets.delay(char_assets.pk)

    logger.info(f"Queued {total} stale character asset updates")
    return f"Queued {total} stale character asset updates"


def _ensure_types_loaded(type_ids):
    """
    Ensure all type IDs are loaded in the database.

    Args:
        type_ids: List of EVE type IDs to check
    """
    # Check which types are missing
    existing_ids = set(EveType.objects.filter(id__in=type_ids).values_list("id", flat=True))
    missing_ids = set(type_ids) - existing_ids

    if not missing_ids:
        return

    logger.info(f"Loading {len(missing_ids)} missing types from ESI")

    # Load missing types using eveuniverse
    for type_id in missing_ids:
        try:
            EveType.objects.get_or_create_esi(id=type_id)
        except Exception as e:
            logger.warning(f"Failed to load type {type_id}: {e}")


def _resolve_location_names(location_ids, esi_client):
    """
    Resolve location IDs to names using ESI and cache them.

    Args:
        location_ids: List of location IDs to resolve
        esi_client: ESI client instance

    Returns:
        dict: Mapping of location_id -> location_name
    """
    location_names = {}

    # Separate stations and structures
    station_ids = [lid for lid in location_ids if 60000000 <= lid < 64000000]
    structure_ids = [lid for lid in location_ids if lid >= 1000000000000]

    # Check cache first for all locations
    cached_locations = Location.objects.filter(location_id__in=location_ids)
    for loc in cached_locations:
        location_names[loc.location_id] = loc.name

    # Get IDs that weren't in cache
    cached_ids = set(location_names.keys())
    uncached_station_ids = [sid for sid in station_ids if sid not in cached_ids]
    uncached_structure_ids = [sid for sid in structure_ids if sid not in cached_ids]

    # Resolve uncached stations in batches (ESI accepts up to 1000 IDs)
    for chunk in chunk_list(uncached_station_ids, 1000):
        try:
            result = esi_client.Universe.post_universe_names(ids=list(chunk)).results()
            for item in result:
                name = item.get("name", "")
                location_names[item["id"]] = name
                # Cache the station
                try:
                    Location.objects.update_or_create(
                        location_id=item["id"],
                        defaults={
                            "name": name,
                            "location_type": "station",
                        },
                    )
                except Exception as e:
                    logger.debug(f"Failed to cache station {item['id']}: {e}")
        except Exception as e:
            logger.warning(f"Failed to resolve station names: {e}")

    # Resolve uncached structures individually (they require authentication)
    # First try with character's token, then with any token that has structure scope
    structure_token = None
    for structure_id in uncached_structure_ids:
        name_resolved = False

        # Try with character's ESI client first
        try:
            result = esi_client.Universe.get_universe_structures_structure_id(
                structure_id=structure_id
            ).results()
            name = result.get("name", "")
            if name:
                location_names[structure_id] = name
                name_resolved = True
                # Cache the structure
                try:
                    Location.objects.update_or_create(
                        location_id=structure_id,
                        defaults={
                            "name": name,
                            "location_type": "structure",
                        },
                    )
                    logger.info(f"Cached structure name: {name} ({structure_id})")
                except Exception as e:
                    logger.debug(f"Failed to cache structure {structure_id}: {e}")
        except Exception as e:
            logger.debug(
                f"Failed to resolve structure {structure_id} with character token: {e}"
            )

        # If that failed, try with a token that has structure scope
        if not name_resolved:
            try:
                # Get a structure token if we don't have one yet
                if structure_token is None:
                    structure_token = get_any_token_with_scope(ESI_SCOPE_STRUCTURES)

                if structure_token:
                    from esi.clients import esi_client_factory

                    structure_client = esi_client_factory(token=structure_token)
                    result = structure_client.Universe.get_universe_structures_structure_id(
                        structure_id=structure_id
                    ).results()
                    name = result.get("name", "")
                    if name:
                        location_names[structure_id] = name
                        name_resolved = True
                        # Cache the structure
                        try:
                            Location.objects.update_or_create(
                                location_id=structure_id,
                                defaults={
                                    "name": name,
                                    "location_type": "structure",
                                },
                            )
                            logger.info(
                                f"Cached structure name (via structure token): {name} ({structure_id})"
                            )
                        except Exception as e:
                            logger.debug(f"Failed to cache structure {structure_id}: {e}")
            except Exception as e:
                logger.debug(
                    f"Failed to resolve structure {structure_id} with structure token: {e}"
                )

        # Last resort: check cache or use fallback
        if not name_resolved:
            try:
                loc = Location.objects.get(location_id=structure_id)
                location_names[structure_id] = loc.name
            except Location.DoesNotExist:
                location_names[structure_id] = f"Structure {structure_id}"

    return location_names
