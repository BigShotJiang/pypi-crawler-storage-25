"""URL configuration for Hangar Ready"""

from django.urls import path

from . import views

app_name = "hangarready"

urlpatterns = [
    # Main views
    path("", views.index, name="index"),
    path("search/", views.search_ships, name="search"),
    # Character management
    path("characters/", views.manage_characters, name="characters"),
    path("characters/add/", views.add_character, name="add_character"),
    path("characters/<int:character_id>/toggle/", views.toggle_character, name="toggle_character"),
    path("characters/<int:character_id>/update/", views.update_character, name="update_character"),
    path("characters/<int:character_id>/remove/", views.remove_character, name="remove_character"),
    path("characters/update-all/", views.update_all_characters, name="update_all_characters"),
    path("characters/bulk-add/", views.bulk_add_characters, name="bulk_add_characters"),
    # Saved searches
    path("saved/", views.saved_searches, name="saved_searches"),
    path("saved/create/", views.create_saved_search, name="create_saved_search"),
    path("saved/<int:search_id>/delete/", views.delete_saved_search, name="delete_saved_search"),
    path("saved/<int:search_id>/run/", views.run_saved_report, name="run_saved_report"),
    # Reports
    path("report/", views.ship_report, name="ship_report"),
    path("report/save/", views.save_report, name="save_report"),
    # Utilities
    path("fetch-structures/", views.fetch_structure_names, name="fetch_structures"),
    path("fetch-structure/<int:structure_id>/", views.fetch_single_structure, name="fetch_single_structure"),
]
