"""Alliance Auth hooks for Hangar Ready"""

from allianceauth import hooks
from allianceauth.services.hooks import MenuItemHook, UrlHook

from . import urls
from .app_settings import ESI_SCOPES_ALL


class HangarReadyMenuItem(MenuItemHook):
    """Menu item hook for Hangar Ready"""

    def __init__(self):
        MenuItemHook.__init__(
            self,
            "Hangar Ready",
            "fa-solid fa-warehouse",
            "hangarready:index",
            navactive=["hangarready:"],
        )

    def render(self, request):
        """Check permissions before rendering"""
        if request.user.has_perm("hangarready.basic_access"):
            return MenuItemHook.render(self, request)
        return ""


@hooks.register("menu_item_hook")
def register_menu():
    """Register menu item"""
    return HangarReadyMenuItem()


@hooks.register("url_hook")
def register_urls():
    """Register URL patterns"""
    return UrlHook(urls, "hangarready", r"^hangarready/")


@hooks.register("secure_group_filters")
def register_secure_group_filters():
    """Register required ESI scopes for secure groups"""
    # This makes the scope available for groups to require
    return []


# Make the required scopes visible to Alliance Auth
def get_required_scopes():
    """Return list of required ESI scopes"""
    return ESI_SCOPES_ALL
