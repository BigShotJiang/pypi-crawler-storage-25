"""Django app configuration for Hangar Ready"""

from django.apps import AppConfig

from . import __version__


class HangarReadyConfig(AppConfig):
    """Django app configuration"""

    name = "hangarready"
    label = "hangarready"
    verbose_name = f"Hangar Ready v{__version__}"

    def ready(self):
        """App initialization"""
        # Import signals to register them
        from . import signals  # noqa: F401
