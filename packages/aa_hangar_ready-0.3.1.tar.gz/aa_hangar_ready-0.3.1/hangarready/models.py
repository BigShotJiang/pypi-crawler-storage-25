"""Database models for Hangar Ready"""

from django.contrib.auth.models import User
from django.db import models
from django.utils.timezone import now

from allianceauth.authentication.models import CharacterOwnership
from allianceauth.eveonline.models import EveCharacter


class CharacterAssetsManager(models.Manager):
    """Manager for CharacterAssets model"""

    def active(self):
        """Get only active character assets"""
        return self.filter(is_active=True)

    def needs_update(self, max_age_hours=24):
        """Get character assets that need updating"""
        from datetime import timedelta

        cutoff = now() - timedelta(hours=max_age_hours)
        return self.active().filter(last_update__lt=cutoff)


class CharacterAssets(models.Model):
    """Cached asset data for a character"""

    character = models.OneToOneField(
        EveCharacter,
        on_delete=models.CASCADE,
        primary_key=True,
        help_text="The EVE character whose assets are tracked",
    )
    token_character = models.ForeignKey(
        CharacterOwnership,
        on_delete=models.CASCADE,
        help_text="The character ownership providing ESI token access",
    )
    last_update = models.DateTimeField(
        default=now,
        help_text="When assets were last fetched from ESI",
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Whether to actively track this character's assets",
    )
    update_error = models.TextField(
        blank=True,
        null=True,
        help_text="Last error encountered during update",
    )

    objects = CharacterAssetsManager()

    class Meta:
        default_permissions = ()
        permissions = [
            ("basic_access", "Can access Hangar Ready tool"),
            ("view_all_characters", "Can view all characters' assets"),
        ]
        verbose_name = "Character Assets"
        verbose_name_plural = "Character Assets"

    def __str__(self):
        return f"{self.character.character_name} Assets"

    @property
    def is_stale(self):
        """Check if asset data is stale and needs update"""
        from datetime import timedelta

        from .app_settings import HANGAR_READY_MAX_CACHE_AGE

        cutoff = now() - timedelta(hours=HANGAR_READY_MAX_CACHE_AGE)
        return self.last_update < cutoff


class AssetItemQuerySet(models.QuerySet):
    """Custom QuerySet for AssetItem model"""

    def ships_only(self):
        """Get only ship assets"""
        return self.filter(is_ship=True)

    def in_hangar(self, location_flag):
        """Get assets in specific hangar"""
        if location_flag == "HangarAll":
            return self.filter(
                location_flag__in=[
                    "Hangar",
                    "ShipHangar",
                    "FleetHangar",
                    "CorpSAG1",
                    "CorpSAG2",
                    "CorpSAG3",
                    "CorpSAG4",
                    "CorpSAG5",
                    "CorpSAG6",
                    "CorpSAG7",
                ]
            )
        return self.filter(location_flag=location_flag)

    def search_ships(self, type_id=None, location_flag=None):
        """Search for ships with optional filters"""
        queryset = self.ships_only()

        if type_id:
            queryset = queryset.filter(type_id=type_id)

        if location_flag:
            queryset = queryset.in_hangar(location_flag)

        return queryset.select_related(
            "character_assets__character",
        )


AssetItemManager = models.Manager.from_queryset(AssetItemQuerySet)


class AssetItem(models.Model):
    """Individual asset in a hangar"""

    character_assets = models.ForeignKey(
        CharacterAssets,
        on_delete=models.CASCADE,
        related_name="items",
        help_text="Parent character assets",
    )
    item_id = models.BigIntegerField(
        help_text="Unique item instance ID from ESI",
    )
    type_id = models.IntegerField(
        help_text="EVE type ID of the item",
    )
    type_name = models.CharField(
        max_length=255,
        help_text="Item type name (cached from EVE SDE)",
    )
    location_id = models.BigIntegerField(
        help_text="Location ID where item is stored",
    )
    location_name = models.CharField(
        max_length=255,
        blank=True,
        help_text="Human-readable location name",
    )
    location_type = models.CharField(
        max_length=50,
        help_text="Type of location (station, structure, etc.)",
    )
    location_flag = models.CharField(
        max_length=50,
        help_text="Specific hangar/bay location",
    )
    quantity = models.IntegerField(
        default=1,
        help_text="Stack quantity",
    )
    is_singleton = models.BooleanField(
        default=True,
        help_text="Whether item is a singleton (ships always are)",
    )
    is_ship = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Whether this item is a ship",
    )

    objects = AssetItemManager()

    class Meta:
        indexes = [
            models.Index(fields=["type_id", "location_flag"]),
            models.Index(fields=["character_assets", "type_id"]),
            models.Index(fields=["is_ship", "location_flag"]),
        ]
        verbose_name = "Asset Item"
        verbose_name_plural = "Asset Items"
        unique_together = [["character_assets", "item_id"]]

    def __str__(self):
        return f"{self.type_name} in {self.location_flag}"


class SavedSearch(models.Model):
    """Saved search query for quick access"""

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="hangar_saved_searches",
    )
    name = models.CharField(
        max_length=100,
        help_text="Display name for this saved search",
    )
    ship_type_ids = models.JSONField(
        default=list,
        help_text="List of ship type IDs to search for",
    )
    ship_group_ids = models.JSONField(
        default=list,
        help_text="List of ship group IDs (classes) to search for",
    )
    location_flags = models.JSONField(
        default=list,
        help_text="List of hangar location flags to search in",
    )
    location_id = models.BigIntegerField(
        null=True,
        blank=True,
        help_text="Specific location ID for reports",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        verbose_name = "Saved Search"
        verbose_name_plural = "Saved Searches"
        ordering = ["name"]

    def __str__(self):
        return f"{self.user.username} - {self.name}"


class Location(models.Model):
    """Cached location information (stations and structures)"""

    location_id = models.BigIntegerField(
        primary_key=True,
        help_text="EVE location ID",
    )
    name = models.CharField(
        max_length=255,
        help_text="Location name",
    )
    location_type = models.CharField(
        max_length=50,
        help_text="Type of location (station, structure, etc.)",
    )
    last_updated = models.DateTimeField(
        auto_now=True,
        help_text="When this location was last updated",
    )

    class Meta:
        verbose_name = "Location"
        verbose_name_plural = "Locations"
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.location_type})"

    @classmethod
    def get_or_fetch_location(cls, location_id, esi_client=None):
        """
        Get location from cache or fetch from ESI.

        Args:
            location_id: EVE location ID
            esi_client: Optional ESI client for fetching

        Returns:
            Location instance or None
        """
        from datetime import timedelta

        from django.utils.timezone import now

        # Try to get from cache
        try:
            location = cls.objects.get(location_id=location_id)
            # Return cached if less than 30 days old
            if location.last_updated > now() - timedelta(days=30):
                return location
        except cls.DoesNotExist:
            location = None

        # Fetch from ESI if we have a client
        if esi_client:
            from .helpers import determine_location_type

            location_type = determine_location_type(location_id)
            name = None

            try:
                if location_type == "structure":
                    result = esi_client.Universe.get_universe_structures_structure_id(
                        structure_id=location_id
                    ).results()
                    name = result.get("name")
                elif location_type == "station":
                    result = esi_client.Universe.get_universe_stations_station_id(
                        station_id=location_id
                    ).results()
                    name = result.get("name")

                if name:
                    # Update or create
                    location, _ = cls.objects.update_or_create(
                        location_id=location_id,
                        defaults={
                            "name": name,
                            "location_type": location_type,
                        },
                    )
                    return location
            except Exception:
                pass

        return location
