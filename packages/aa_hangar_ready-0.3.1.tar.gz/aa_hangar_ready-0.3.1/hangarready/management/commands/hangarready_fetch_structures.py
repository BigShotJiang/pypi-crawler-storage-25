"""Management command to fetch structure names from ESI"""

import logging

from django.core.management.base import BaseCommand
from esi.clients import esi_client_factory

from hangarready.app_settings import ESI_SCOPE_STRUCTURES
from hangarready.helpers import get_any_token_with_scope
from hangarready.models import AssetItem, Location

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = "Fetch structure names from ESI for all unknown structures in assets"

    def add_arguments(self, parser):
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force update even if structure is already cached",
        )
        parser.add_argument(
            "--structure-id",
            type=int,
            help="Fetch a specific structure ID",
        )

    def handle(self, *args, **options):
        force = options.get("force", False)
        specific_structure = options.get("structure_id")

        # Get a token with structure read permissions
        token = get_any_token_with_scope(ESI_SCOPE_STRUCTURES)
        if not token:
            self.stdout.write(
                self.style.ERROR(
                    f"No valid token found with {ESI_SCOPE_STRUCTURES} scope.\n"
                    "Please add at least one character with structure read permissions."
                )
            )
            return

        # Create ESI client
        try:
            client = esi_client_factory(token=token)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Failed to create ESI client: {e}"))
            return

        # Get structure IDs to fetch
        if specific_structure:
            structure_ids = [specific_structure]
            self.stdout.write(f"Fetching structure {specific_structure}...")
        else:
            # Get all structure IDs from assets
            structure_ids = (
                AssetItem.objects.filter(location_id__gte=1000000000000)
                .values_list("location_id", flat=True)
                .distinct()
            )
            structure_ids = list(structure_ids)

            if not force:
                # Filter out already cached structures
                cached_ids = set(
                    Location.objects.filter(
                        location_id__in=structure_ids,
                        location_type="structure",
                    ).values_list("location_id", flat=True)
                )
                structure_ids = [sid for sid in structure_ids if sid not in cached_ids]

            self.stdout.write(
                f"Found {len(structure_ids)} structure(s) to fetch..."
            )

        if not structure_ids:
            self.stdout.write(
                self.style.WARNING("No structures to fetch. Use --force to update all.")
            )
            return

        # Fetch structures
        success_count = 0
        error_count = 0
        forbidden_count = 0

        for structure_id in structure_ids:
            try:
                result = client.Universe.get_universe_structures_structure_id(
                    structure_id=structure_id
                ).results()

                name = result.get("name", "")
                if name:
                    # Save to database
                    Location.objects.update_or_create(
                        location_id=structure_id,
                        defaults={
                            "name": name,
                            "location_type": "structure",
                        },
                    )
                    success_count += 1
                    self.stdout.write(
                        self.style.SUCCESS(
                            f"  ✓ {structure_id}: {name}"
                        )
                    )
                else:
                    error_count += 1
                    self.stdout.write(
                        self.style.ERROR(
                            f"  ✗ {structure_id}: No name in response"
                        )
                    )

            except Exception as e:
                error_str = str(e)
                if "403" in error_str or "Forbidden" in error_str:
                    forbidden_count += 1
                    self.stdout.write(
                        self.style.WARNING(
                            f"  ⊘ {structure_id}: Access forbidden (private structure)"
                        )
                    )
                else:
                    error_count += 1
                    self.stdout.write(
                        self.style.ERROR(
                            f"  ✗ {structure_id}: {error_str}"
                        )
                    )

        # Summary
        self.stdout.write("\n" + "=" * 60)
        self.stdout.write(
            self.style.SUCCESS(f"\nSuccessfully fetched: {success_count} structures")
        )
        if forbidden_count > 0:
            self.stdout.write(
                self.style.WARNING(
                    f"Forbidden (no access): {forbidden_count} structures"
                )
            )
        if error_count > 0:
            self.stdout.write(
                self.style.ERROR(f"Errors: {error_count} structures")
            )
        self.stdout.write("=" * 60 + "\n")

        if forbidden_count > 0:
            self.stdout.write(
                self.style.WARNING(
                    "\nNote: Some structures are private and require specific access.\n"
                    "Characters who have access to those structures can update them."
                )
            )
