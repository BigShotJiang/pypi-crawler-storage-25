"""Management command to add existing characters with assets scope"""

from django.core.management.base import BaseCommand

from allianceauth.authentication.models import CharacterOwnership

from hangarready.helpers import get_character_token
from hangarready.models import CharacterAssets
from hangarready.tasks import update_character_assets


class Command(BaseCommand):
    help = "Automatically add existing characters with esi-assets.read_assets.v1 scope to Hangar Ready"

    def add_arguments(self, parser):
        parser.add_argument(
            "--update",
            action="store_true",
            help="Queue asset updates for newly added characters",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be done without making changes",
        )

    def handle(self, *args, **options):
        update = options.get("update", False)
        dry_run = options.get("dry_run", False)

        if dry_run:
            self.stdout.write(self.style.WARNING("DRY RUN MODE - No changes will be made\n"))

        # Get all character ownerships
        all_characters = CharacterOwnership.objects.all()
        total_characters = all_characters.count()

        self.stdout.write(f"Processing {total_characters} characters...")

        added_count = 0
        skipped_no_scope = 0
        skipped_already_tracked = 0
        errors = 0

        for char_ownership in all_characters:
            character_name = char_ownership.character.character_name

            # Check if already tracked
            if CharacterAssets.objects.filter(character=char_ownership.character).exists():
                skipped_already_tracked += 1
                self.stdout.write(
                    self.style.WARNING(f"  ⊘ {character_name} - already tracked")
                )
                continue

            # Check if has required scope
            token = get_character_token(char_ownership)
            if not token:
                skipped_no_scope += 1
                self.stdout.write(
                    self.style.ERROR(
                        f"  ✗ {character_name} - missing esi-assets.read_assets.v1 scope"
                    )
                )
                continue

            # Add character
            if not dry_run:
                try:
                    char_assets = CharacterAssets.objects.create(
                        character=char_ownership.character,
                        token_character=char_ownership,
                        is_active=True,
                    )
                    added_count += 1
                    self.stdout.write(
                        self.style.SUCCESS(f"  ✓ {character_name} - added to Hangar Ready")
                    )

                    # Queue update if requested
                    if update:
                        update_character_assets.delay(char_assets.pk)
                        self.stdout.write(
                            self.style.SUCCESS(f"    → Queued asset update")
                        )

                except Exception as e:
                    errors += 1
                    self.stdout.write(
                        self.style.ERROR(f"  ✗ {character_name} - error: {e}")
                    )
            else:
                added_count += 1
                self.stdout.write(
                    self.style.SUCCESS(
                        f"  ✓ {character_name} - would be added (dry run)"
                    )
                )

        # Summary
        self.stdout.write("\n" + "=" * 60)
        self.stdout.write(self.style.SUCCESS(f"\nTotal characters: {total_characters}"))
        if dry_run:
            self.stdout.write(
                self.style.WARNING(f"Would add: {added_count} characters")
            )
        else:
            self.stdout.write(
                self.style.SUCCESS(f"Added: {added_count} characters")
            )
        self.stdout.write(
            self.style.WARNING(f"Already tracked: {skipped_already_tracked} characters")
        )
        self.stdout.write(
            self.style.ERROR(f"Missing scope: {skipped_no_scope} characters")
        )
        if errors > 0:
            self.stdout.write(self.style.ERROR(f"Errors: {errors}"))
        self.stdout.write("=" * 60 + "\n")

        if dry_run:
            self.stdout.write(
                self.style.WARNING(
                    "\nThis was a dry run. Run without --dry-run to apply changes."
                )
            )
