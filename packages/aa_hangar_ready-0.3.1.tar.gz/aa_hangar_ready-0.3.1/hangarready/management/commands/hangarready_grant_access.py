"""Management command to grant basic access to all users"""

from django.contrib.auth.models import Permission, User
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand

from hangarready.models import CharacterAssets


class Command(BaseCommand):
    help = "Grant basic_access permission to all users"

    def add_arguments(self, parser):
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force grant even if user already has permission",
        )

    def handle(self, *args, **options):
        force = options.get("force", False)

        try:
            # Get the basic_access permission
            content_type = ContentType.objects.get_for_model(CharacterAssets)
            permission = Permission.objects.get(
                content_type=content_type, codename="basic_access"
            )

            users = User.objects.all()
            total_users = users.count()
            granted_count = 0
            already_had_count = 0

            self.stdout.write(f"Processing {total_users} users...")

            for user in users:
                has_permission = user.user_permissions.filter(pk=permission.pk).exists()

                if has_permission:
                    already_had_count += 1
                    if force:
                        self.stdout.write(
                            self.style.WARNING(
                                f"User {user.username} already has permission (skipping)"
                            )
                        )
                else:
                    user.user_permissions.add(permission)
                    granted_count += 1
                    self.stdout.write(
                        self.style.SUCCESS(f"Granted permission to {user.username}")
                    )

            # Summary
            self.stdout.write("\n" + "=" * 50)
            self.stdout.write(
                self.style.SUCCESS(f"\nTotal users: {total_users}")
            )
            self.stdout.write(
                self.style.SUCCESS(f"Granted permission to: {granted_count} users")
            )
            self.stdout.write(
                self.style.WARNING(f"Already had permission: {already_had_count} users")
            )
            self.stdout.write("=" * 50 + "\n")

        except Permission.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(
                    "Permission 'basic_access' does not exist. "
                    "Run migrations first: python manage.py migrate hangarready"
                )
            )
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error: {e}"))
