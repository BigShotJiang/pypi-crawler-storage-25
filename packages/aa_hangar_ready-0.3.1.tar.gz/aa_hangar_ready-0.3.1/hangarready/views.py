"""Views for Hangar Ready"""

import logging

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.html import format_html
from esi.decorators import token_required
from eveuniverse.models import EveType, EveGroup

from allianceauth.authentication.models import CharacterOwnership
from allianceauth.eveonline.models import EveCharacter

from .app_settings import ESI_SCOPE_ASSETS, HANGAR_FLAGS, ESI_SCOPE_STRUCTURES
from .helpers import get_character_token
from .models import AssetItem, CharacterAssets, Location, SavedSearch
from .tasks import update_character_assets

logger = logging.getLogger(__name__)


@login_required
@permission_required("hangarready.basic_access")
def index(request):
    """Main dashboard view"""
    # Get user's characters with asset tracking
    user_characters = CharacterAssets.objects.filter(
        token_character__user=request.user
    ).select_related("character", "token_character")

    # Get available ship types from user's assets
    if request.user.has_perm("hangarready.view_all_characters"):
        available_ships = (
            AssetItem.objects.ships_only()
            .values("type_id", "type_name")
            .annotate(count=Count("id"))
            .order_by("type_name")
        )
        # Admin: Get all tracked characters across all accounts
        all_characters = CharacterAssets.objects.all().select_related(
            "character", "token_character__user"
        ).order_by("-last_update")
    else:
        available_ships = (
            AssetItem.objects.filter(character_assets__token_character__user=request.user)
            .ships_only()
            .values("type_id", "type_name")
            .annotate(count=Count("id"))
            .order_by("type_name")
        )
        all_characters = None

    context = {
        "user_characters": user_characters,
        "available_ships": available_ships,
        "hangar_flags": HANGAR_FLAGS,
        "total_characters": user_characters.count(),
        "total_ships": available_ships.count(),
        "all_characters": all_characters,
    }

    return render(request, "hangarready/index.html", context)


@login_required
@permission_required("hangarready.basic_access")
def search_ships(request):
    """Search for ships in hangars"""
    type_id = request.GET.get("type_id")
    location_flag = request.GET.get("location_flag", "HangarAll")
    page_number = request.GET.get("page", 1)

    # Base queryset
    if request.user.has_perm("hangarready.view_all_characters"):
        queryset = AssetItem.objects.all()
    else:
        queryset = AssetItem.objects.filter(character_assets__token_character__user=request.user)

    # Apply filters
    if type_id:
        queryset = queryset.filter(type_id=type_id, is_ship=True)
    else:
        queryset = queryset.ships_only()

    if location_flag and location_flag != "HangarAll":
        queryset = queryset.in_hangar(location_flag)
    else:
        queryset = queryset.in_hangar("HangarAll")

    # Order and select related for performance
    queryset = queryset.select_related(
        "character_assets__character",
    ).order_by("type_name", "character_assets__character__character_name")

    # Paginate results
    paginator = Paginator(queryset, 50)
    page_obj = paginator.get_page(page_number)

    # Get ship type name if filtering by type
    ship_type_name = None
    if type_id:
        try:
            eve_type = EveType.objects.get(id=type_id)
            ship_type_name = eve_type.name
        except EveType.DoesNotExist:
            pass

    context = {
        "page_obj": page_obj,
        "ship_type_name": ship_type_name,
        "type_id": type_id,
        "location_flag": location_flag,
        "location_name": HANGAR_FLAGS.get(location_flag, location_flag),
        "hangar_flags": HANGAR_FLAGS,
        "total_results": paginator.count,
    }

    return render(request, "hangarready/search_results.html", context)


@login_required
@permission_required("hangarready.basic_access")
def manage_characters(request):
    """Manage character asset tracking"""
    # Get user's character ownerships
    ownerships = CharacterOwnership.objects.filter(user=request.user).select_related("character")

    # Get existing tracked characters
    tracked_chars = CharacterAssets.objects.filter(
        token_character__user=request.user
    ).select_related("character", "token_character")

    tracked_char_ids = set(tc.character.character_id for tc in tracked_chars)

    # Characters that can be added (have ownership but not tracked)
    available_chars = [
        ownership
        for ownership in ownerships
        if ownership.character.character_id not in tracked_char_ids
    ]

    context = {
        "tracked_characters": tracked_chars,
        "available_characters": available_chars,
    }

    return render(request, "hangarready/manage_characters.html", context)


@login_required
@permission_required("hangarready.basic_access")
@token_required(scopes=[ESI_SCOPE_ASSETS])
def add_character(request, token):
    """Add a character for asset tracking via ESI token"""
    character_id = token.character_id

    try:
        # Get character and ownership
        character = EveCharacter.objects.get(character_id=character_id)
        ownership = CharacterOwnership.objects.get(
            user=request.user, character=character
        )

        # Create or update CharacterAssets
        char_assets, created = CharacterAssets.objects.get_or_create(
            character=character,
            defaults={"token_character": ownership, "is_active": True},
        )

        if not created:
            char_assets.token_character = ownership
            char_assets.is_active = True
            char_assets.save()

        # Queue asset update
        update_character_assets.delay(char_assets.pk)

        if created:
            messages.success(
                request,
                format_html(
                    "Added <strong>{}</strong> for asset tracking. "
                    "Assets will be fetched shortly.",
                    character.character_name,
                ),
            )
        else:
            messages.success(
                request,
                format_html(
                    "Reactivated asset tracking for <strong>{}</strong>. "
                    "Assets will be updated shortly.",
                    character.character_name,
                ),
            )

    except (EveCharacter.DoesNotExist, CharacterOwnership.DoesNotExist):
        messages.error(request, "Character not found or not owned by you.")
        logger.error(f"Character {character_id} not found for user {request.user.username}")

    return redirect("hangarready:characters")


@login_required
@permission_required("hangarready.basic_access")
def toggle_character(request, character_id):
    """Toggle character asset tracking on/off"""
    char_assets = get_object_or_404(
        CharacterAssets,
        character__character_id=character_id,
        token_character__user=request.user,
    )

    char_assets.is_active = not char_assets.is_active
    char_assets.save()

    status = "enabled" if char_assets.is_active else "disabled"
    messages.success(
        request,
        format_html(
            "Asset tracking {} for <strong>{}</strong>.",
            status,
            char_assets.character.character_name,
        ),
    )

    return redirect("hangarready:characters")


@login_required
@permission_required("hangarready.basic_access")
def update_character(request, character_id):
    """Manually trigger character asset update"""
    char_assets = get_object_or_404(
        CharacterAssets,
        character__character_id=character_id,
        token_character__user=request.user,
    )

    # Check if token is still valid
    token = get_character_token(char_assets.token_character)
    if not token:
        messages.error(
            request,
            format_html(
                "No valid ESI token for <strong>{}</strong>. "
                "Please re-add the character.",
                char_assets.character.character_name,
            ),
        )
        return redirect("hangarready:characters")

    # Queue update
    update_character_assets.delay(char_assets.pk)

    messages.success(
        request,
        format_html(
            "Queued asset update for <strong>{}</strong>. "
            "This may take a few moments.",
            char_assets.character.character_name,
        ),
    )

    return redirect("hangarready:characters")


@login_required
@permission_required("hangarready.basic_access")
def update_all_characters(request):
    """Manually trigger update for all user's characters"""
    if request.user.has_perm("hangarready.view_all_characters"):
        # Admin: update all active characters
        user_characters = CharacterAssets.objects.active()
        context_msg = "all characters"
    else:
        # Regular user: update only their characters
        user_characters = CharacterAssets.objects.filter(
            token_character__user=request.user,
            is_active=True,
        )
        context_msg = "your characters"

    if not user_characters.exists():
        messages.warning(request, "No active characters to update.")
        return redirect("hangarready:index")

    # Queue updates for all characters
    count = 0
    for char_assets in user_characters:
        update_character_assets.delay(char_assets.pk)
        count += 1

    messages.success(
        request,
        format_html(
            "Queued asset updates for <strong>{} character(s)</strong>. "
            "This may take a few minutes.",
            count,
        ),
    )

    return redirect("hangarready:index")


@login_required
@permission_required("hangarready.view_all_characters")
def bulk_add_characters(request):
    """Admin-only: Automatically add all characters with required ESI scopes"""
    if request.method != "POST":
        messages.error(request, "Invalid request method.")
        return redirect("hangarready:characters")

    from esi.models import Token

    # Find all tokens that have the required asset scope
    tokens_with_scope = Token.objects.filter(
        scopes__name=ESI_SCOPE_ASSETS
    ).select_related("user")

    added_count = 0
    reactivated_count = 0
    already_tracked_count = 0

    for token in tokens_with_scope:
        try:
            # Get character ownership for this token
            ownership = CharacterOwnership.objects.get(
                user=token.user,
                character__character_id=token.character_id
            )

            # Create or update CharacterAssets
            char_assets, created = CharacterAssets.objects.get_or_create(
                character=ownership.character,
                defaults={"token_character": ownership, "is_active": True},
            )

            if created:
                # Queue asset update for new character
                update_character_assets.delay(char_assets.pk)
                added_count += 1
                logger.info(
                    f"Bulk-added character {ownership.character.character_name} "
                    f"(ID: {ownership.character.character_id})"
                )
            elif not char_assets.is_active:
                # Reactivate inactive character
                char_assets.token_character = ownership
                char_assets.is_active = True
                char_assets.save()
                update_character_assets.delay(char_assets.pk)
                reactivated_count += 1
                logger.info(
                    f"Reactivated character {ownership.character.character_name} "
                    f"(ID: {ownership.character.character_id})"
                )
            else:
                # Already tracked and active
                already_tracked_count += 1

        except CharacterOwnership.DoesNotExist:
            logger.warning(
                f"Token found for character {token.character_id} but no CharacterOwnership exists"
            )
            continue
        except Exception as e:
            logger.error(
                f"Error adding character {token.character_id}: {e}"
            )
            continue

    # Build status message
    message_parts = []
    if added_count > 0:
        message_parts.append(f"<strong>{added_count}</strong> new character(s) added")
    if reactivated_count > 0:
        message_parts.append(f"<strong>{reactivated_count}</strong> character(s) reactivated")
    if already_tracked_count > 0:
        message_parts.append(f"<strong>{already_tracked_count}</strong> already tracked")

    if message_parts:
        messages.success(
            request,
            format_html(
                "Bulk add complete: {}. Asset updates queued for new/reactivated characters.",
                ", ".join(message_parts)
            ),
        )
    else:
        messages.info(request, "No characters with required ESI scopes found.")

    return redirect("hangarready:characters")


@login_required
@permission_required("hangarready.basic_access")
def remove_character(request, character_id):
    """Remove character from asset tracking"""
    if request.method == "POST":
        char_assets = get_object_or_404(
            CharacterAssets,
            character__character_id=character_id,
            token_character__user=request.user,
        )

        character_name = char_assets.character.character_name
        char_assets.delete()

        messages.success(
            request,
            format_html(
                "Removed <strong>{}</strong> from asset tracking.",
                character_name,
            ),
        )

    return redirect("hangarready:characters")


@login_required
@permission_required("hangarready.basic_access")
def saved_searches(request):
    """Manage saved searches"""
    searches = SavedSearch.objects.filter(user=request.user).order_by("name")

    # Calculate character counts for each saved report
    searches_with_counts = []
    for search in searches:
        # Collect all type IDs from individual ships and ship groups
        all_type_ids = list(search.ship_type_ids)

        # Add ships from selected groups
        if search.ship_group_ids:
            group_type_ids = EveType.objects.filter(
                eve_group_id__in=search.ship_group_ids
            ).values_list("id", flat=True)
            all_type_ids.extend(list(group_type_ids))

        # Remove duplicates
        all_type_ids = list(set(all_type_ids))

        # Build query for character count
        if all_type_ids:
            query = AssetItem.objects.ships_only().filter(type_id__in=all_type_ids)

            if search.location_id:
                query = query.filter(location_id=search.location_id)

            # Apply user permissions
            if not request.user.has_perm("hangarready.view_all_characters"):
                query = query.filter(character_assets__token_character__user=request.user)

            # Count unique characters
            character_count = query.values("character_assets__character").distinct().count()
        else:
            character_count = 0

        searches_with_counts.append({
            "search": search,
            "character_count": character_count,
        })

    context = {
        "saved_searches": searches_with_counts,
    }

    return render(request, "hangarready/saved_searches.html", context)


@login_required
@permission_required("hangarready.basic_access")
def create_saved_search(request):
    """Create a new saved search"""
    if request.method == "POST":
        name = request.POST.get("name")
        type_ids = request.POST.getlist("type_ids")
        location_flags = request.POST.getlist("location_flags")

        if name and type_ids:
            SavedSearch.objects.create(
                user=request.user,
                name=name,
                ship_type_ids=type_ids,
                location_flags=location_flags,
            )
            messages.success(request, f'Created saved search "{name}".')
        else:
            messages.error(request, "Name and at least one ship type are required.")

    return redirect("hangarready:saved_searches")


@login_required
@permission_required("hangarready.basic_access")
def delete_saved_search(request, search_id):
    """Delete a saved search"""
    if request.method == "POST":
        search = get_object_or_404(SavedSearch, pk=search_id, user=request.user)
        search_name = search.name
        search.delete()
        messages.success(request, f'Deleted saved search "{search_name}".')

    return redirect("hangarready:saved_searches")


@login_required
@permission_required("hangarready.basic_access")
def save_report(request):
    """Save a report configuration"""
    if request.method == "POST":
        name = request.POST.get("name")
        ship_types_str = request.POST.get("ship_types", "")
        ship_groups_str = request.POST.get("ship_groups", "")
        location_id = request.POST.get("location_id")

        # Parse comma-separated strings to lists
        ship_type_ids = [int(x) for x in ship_types_str.split(",") if x.strip()]
        ship_group_ids = [int(x) for x in ship_groups_str.split(",") if x.strip()]

        if name and (ship_type_ids or ship_group_ids):
            SavedSearch.objects.create(
                user=request.user,
                name=name,
                ship_type_ids=ship_type_ids,
                ship_group_ids=ship_group_ids,
                location_id=int(location_id) if location_id else None,
            )
            messages.success(request, f'Saved report "{name}".')
        else:
            messages.error(request, "Name and at least one ship type or class are required.")

    return redirect("hangarready:saved_searches")


@login_required
@permission_required("hangarready.basic_access")
def run_saved_report(request, search_id):
    """Run a saved report"""
    search = get_object_or_404(SavedSearch, pk=search_id, user=request.user)

    # Create a POST request with the saved parameters
    from django.test import RequestFactory
    factory = RequestFactory()

    post_data = {
        "ship_types": search.ship_type_ids,
        "ship_groups": search.ship_group_ids,
    }

    if search.location_id:
        post_data["location_id"] = search.location_id

    # Forward to ship_report view with the saved parameters
    request.method = "POST"
    request.POST = request.POST.copy()
    for key, value in post_data.items():
        if isinstance(value, list):
            request.POST.setlist(key, [str(v) for v in value])
        else:
            request.POST[key] = str(value)

    return ship_report(request)


@login_required
@permission_required("hangarready.basic_access")
def ship_report(request):
    """Generate report of characters with specific ships at specific locations"""
    # Get available ship types and locations
    if request.user.has_perm("hangarready.view_all_characters"):
        available_ships = (
            AssetItem.objects.ships_only()
            .values("type_id", "type_name")
            .distinct()
            .order_by("type_name")
        )
        all_items = AssetItem.objects.all()
    else:
        available_ships = (
            AssetItem.objects.filter(character_assets__token_character__user=request.user)
            .ships_only()
            .values("type_id", "type_name")
            .distinct()
            .order_by("type_name")
        )
        all_items = AssetItem.objects.filter(
            character_assets__token_character__user=request.user
        )

    # Get unique locations
    locations = (
        all_items.values("location_id", "location_name", "location_type")
        .distinct()
        .order_by("location_name")
    )

    # Get ship groups/classes from eveuniverse
    # Filter for ship groups by getting groups that have ship types in our assets
    ship_type_ids = available_ships.values_list("type_id", flat=True)
    ship_groups = (
        EveGroup.objects.filter(
            eve_types__id__in=ship_type_ids
        )
        .distinct()
        .order_by("name")
        .values("id", "name")
    )

    report_data = None

    if request.method == "POST":
        selected_ship_ids = request.POST.getlist("ship_types")
        selected_group_ids = request.POST.getlist("ship_groups")
        selected_location_id = request.POST.get("location_id")

        # Collect all type IDs from individual ships and ship groups
        all_type_ids = []

        # Add individually selected ships
        if selected_ship_ids:
            all_type_ids.extend([int(sid) for sid in selected_ship_ids])

        # Add ships from selected groups
        if selected_group_ids:
            group_ids = [int(gid) for gid in selected_group_ids]
            group_type_ids = EveType.objects.filter(
                eve_group_id__in=group_ids
            ).values_list("id", flat=True)
            all_type_ids.extend(list(group_type_ids))

        if all_type_ids:
            # Remove duplicates
            all_type_ids = list(set(all_type_ids))

            # Build query
            query = AssetItem.objects.ships_only().filter(type_id__in=all_type_ids)

            if selected_location_id:
                query = query.filter(location_id=int(selected_location_id))

            # Apply user permissions
            if not request.user.has_perm("hangarready.view_all_characters"):
                query = query.filter(character_assets__token_character__user=request.user)

            # Get results grouped by character
            results = (
                query.select_related("character_assets__character")
                .values(
                    "character_assets__character__character_id",
                    "character_assets__character__character_name",
                    "character_assets__character__corporation_name",
                )
                .annotate(
                    ship_count=Count("id"),
                    ships=Count("type_id", distinct=True),
                )
                .order_by("character_assets__character__character_name")
            )

            # Get detailed ship breakdown per character
            character_ships = {}
            for item in query.select_related("character_assets__character"):
                char_id = item.character_assets.character.character_id
                if char_id not in character_ships:
                    character_ships[char_id] = {
                        "character_name": item.character_assets.character.character_name,
                        "character_id": char_id,
                        "corporation_name": item.character_assets.character.corporation_name,
                        "ships": {},
                    }

                ship_name = item.type_name
                if ship_name not in character_ships[char_id]["ships"]:
                    character_ships[char_id]["ships"][ship_name] = 0
                character_ships[char_id]["ships"][ship_name] += 1

            # Get selected ship names for display
            selected_ships = available_ships.filter(type_id__in=all_type_ids)

            # Get selected group names for display
            selected_groups = []
            if selected_group_ids:
                group_ids = [int(gid) for gid in selected_group_ids]
                selected_groups = list(
                    EveGroup.objects.filter(id__in=group_ids).values("id", "name")
                )

            # Get location name if selected
            location_name = "All Locations"
            location_id_for_display = None
            if selected_location_id:
                loc = locations.filter(location_id=int(selected_location_id)).first()
                if loc:
                    location_name = loc["location_name"] or f"Location {selected_location_id}"
                    location_id_for_display = loc["location_id"]

            import json

            report_data = {
                "characters": list(character_ships.values()),
                "selected_ships": list(selected_ships),
                "selected_groups": selected_groups,
                "location_name": location_name,
                "location_id": location_id_for_display,
                "total_characters": len(character_ships),
                "selected_ship_ids": selected_ship_ids,
                "selected_group_ids": selected_group_ids,
                "selected_location_id": selected_location_id,
                "selected_ship_ids_json": json.dumps(selected_ship_ids),
                "selected_group_ids_json": json.dumps(selected_group_ids),
            }

    context = {
        "available_ships": available_ships,
        "ship_groups": ship_groups,
        "locations": locations,
        "report_data": report_data,
    }

    return render(request, "hangarready/ship_report.html", context)


@login_required
@permission_required("hangarready.basic_access")
def fetch_structure_names(request):
    """Fetch structure names from ESI"""
    from esi.clients import esi_client_factory

    from .helpers import get_any_token_with_scope
    from .models import Location

    # Get a token with structure read permissions
    token = get_any_token_with_scope(ESI_SCOPE_STRUCTURES)
    if not token:
        messages.error(
            request,
            format_html(
                "No valid token found with <code>{}</code> scope. "
                "Please add a character with structure read permissions.",
                ESI_SCOPE_STRUCTURES,
            ),
        )
        return redirect("hangarready:index")

    # Get structure IDs that need fetching
    structure_ids = (
        AssetItem.objects.filter(location_id__gte=1000000000000)
        .values_list("location_id", flat=True)
        .distinct()
    )
    structure_ids = list(structure_ids)

    # Filter out already cached structures
    cached_ids = set(
        Location.objects.filter(
            location_id__in=structure_ids,
            location_type="structure",
        ).values_list("location_id", flat=True)
    )
    uncached_structure_ids = [sid for sid in structure_ids if sid not in cached_ids]

    if not uncached_structure_ids:
        messages.info(
            request,
            "All structure names are already cached. Use the management command with --force to update.",
        )
        return redirect("hangarready:index")

    # Create ESI client
    try:
        client = esi_client_factory(token=token)
    except Exception as e:
        messages.error(request, f"Failed to create ESI client: {e}")
        return redirect("hangarready:index")

    # Fetch structures
    success_count = 0
    error_count = 0
    forbidden_count = 0

    for structure_id in uncached_structure_ids[:50]:  # Limit to 50 at a time
        try:
            result = client.Universe.get_universe_structures_structure_id(
                structure_id=structure_id
            ).results()

            name = result.get("name", "")
            if name:
                Location.objects.update_or_create(
                    location_id=structure_id,
                    defaults={
                        "name": name,
                        "location_type": "structure",
                    },
                )
                success_count += 1
                logger.info(f"Fetched structure name: {name} ({structure_id})")
        except Exception as e:
            error_str = str(e)
            if "403" in error_str or "Forbidden" in error_str:
                forbidden_count += 1
                logger.debug(f"Access forbidden for structure {structure_id}")
            else:
                error_count += 1
                logger.warning(f"Failed to fetch structure {structure_id}: {e}")

    # Build success message
    if success_count > 0:
        messages.success(
            request,
            format_html(
                "Successfully fetched <strong>{}</strong> structure name(s).",
                success_count,
            ),
        )
    if forbidden_count > 0:
        messages.warning(
            request,
            format_html(
                "{} structure(s) are private and could not be accessed.",
                forbidden_count,
            ),
        )
    if error_count > 0:
        messages.error(
            request,
            format_html("{} structure(s) failed to fetch.", error_count),
        )

    total_remaining = len(uncached_structure_ids) - 50
    if total_remaining > 0:
        messages.info(
            request,
            format_html(
                "{} more structure(s) remaining. Click again to fetch more, "
                "or use the management command for bulk fetching.",
                total_remaining,
            ),
        )

    return redirect("hangarready:index")


@login_required
@permission_required("hangarready.basic_access")
def fetch_single_structure(request, structure_id):
    """Fetch a single structure name from ESI (AJAX endpoint)"""
    from django.http import JsonResponse
    from esi.clients import esi_client_factory
    from .helpers import get_any_token_with_scope

    # Ensure structure_id is an integer
    structure_id = int(structure_id)
    logger.info(f"Fetching structure {structure_id}")

    # Check if already cached
    try:
        location = Location.objects.get(location_id=structure_id)
        logger.info(f"Structure {structure_id} already cached as '{location.name}'")

        # Still update AssetItems in case they weren't updated before
        updated_count = AssetItem.objects.filter(
            location_id=structure_id
        ).update(location_name=location.name)

        logger.info(f"Updated {updated_count} existing asset items with cached name")
        return JsonResponse({
            "success": True,
            "name": location.name,
            "updated_count": updated_count,
            "from_cache": True
        })
    except Location.DoesNotExist:
        logger.info(f"Structure {structure_id} not in cache, fetching from ESI")
        pass

    # Get token with structure scope
    token = get_any_token_with_scope(ESI_SCOPE_STRUCTURES)
    if not token:
        return JsonResponse(
            {
                "success": False,
                "error": "No valid token found with structure read permissions.",
            },
            status=403,
        )

    # Create ESI client
    try:
        client = esi_client_factory(token=token)
    except Exception as e:
        return JsonResponse(
            {"success": False, "error": f"Failed to create ESI client: {e}"},
            status=500,
        )

    # Fetch structure
    try:
        result = client.Universe.get_universe_structures_structure_id(
            structure_id=structure_id
        ).results()

        name = result.get("name", "")
        if name:
            # Cache in Location table
            Location.objects.update_or_create(
                location_id=structure_id,
                defaults={
                    "name": name,
                    "location_type": "structure",
                },
            )

            # Update all AssetItem records at this location
            logger.info(f"Updating AssetItems with location_id={structure_id}")
            items_to_update = AssetItem.objects.filter(location_id=structure_id)
            count_before = items_to_update.count()
            logger.info(f"Found {count_before} AssetItems to update")

            updated_count = items_to_update.update(location_name=name)
            logger.info(f"Successfully updated {updated_count} AssetItems")

            # Verify the update
            verification = AssetItem.objects.filter(
                location_id=structure_id,
                location_name=name
            ).count()
            logger.info(f"Verification: {verification} items now have location_name='{name}'")

            logger.info(
                f"Fetched structure name: {name} ({structure_id}), "
                f"found {count_before} items, updated {updated_count} asset items"
            )
            return JsonResponse({
                "success": True,
                "name": name,
                "updated_count": updated_count,
                "from_cache": False
            })
        else:
            return JsonResponse(
                {"success": False, "error": "Structure name not found"},
                status=404,
            )
    except Exception as e:
        error_str = str(e)
        if "403" in error_str or "Forbidden" in error_str:
            return JsonResponse(
                {"success": False, "error": "Access forbidden to this structure"},
                status=403,
            )
        else:
            logger.warning(f"Failed to fetch structure {structure_id}: {e}")
            return JsonResponse(
                {"success": False, "error": f"Failed to fetch structure: {e}"},
                status=500,
            )
