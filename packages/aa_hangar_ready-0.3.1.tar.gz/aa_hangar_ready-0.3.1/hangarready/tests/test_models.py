"""Tests for Hangar Ready models"""

from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase
from django.utils.timezone import now

from allianceauth.authentication.models import CharacterOwnership
from allianceauth.eveonline.models import EveCharacter

from ..models import AssetItem, CharacterAssets, SavedSearch


class CharacterAssetsTestCase(TestCase):
    """Test CharacterAssets model"""

    @classmethod
    def setUpTestData(cls):
        """Set up test data"""
        cls.user = User.objects.create_user("test_user", "test@example.com", "password")
        cls.character = EveCharacter.objects.create(
            character_id=123456789,
            character_name="Test Character",
            corporation_id=98000001,
            corporation_name="Test Corp",
        )
        cls.ownership = CharacterOwnership.objects.create(
            user=cls.user, character=cls.character, owner_hash="test_hash"
        )

    def test_create_character_assets(self):
        """Test creating CharacterAssets"""
        char_assets = CharacterAssets.objects.create(
            character=self.character, token_character=self.ownership
        )
        self.assertEqual(char_assets.character, self.character)
        self.assertTrue(char_assets.is_active)
        self.assertIsNone(char_assets.update_error)

    def test_is_stale(self):
        """Test is_stale property"""
        char_assets = CharacterAssets.objects.create(
            character=self.character, token_character=self.ownership
        )

        # Fresh data should not be stale
        self.assertFalse(char_assets.is_stale)

        # Old data should be stale
        char_assets.last_update = now() - timedelta(hours=25)
        char_assets.save()
        self.assertTrue(char_assets.is_stale)

    def test_manager_active(self):
        """Test active manager method"""
        CharacterAssets.objects.create(
            character=self.character, token_character=self.ownership, is_active=True
        )

        # Create inactive character
        char2 = EveCharacter.objects.create(
            character_id=987654321,
            character_name="Inactive Character",
            corporation_id=98000001,
            corporation_name="Test Corp",
        )
        ownership2 = CharacterOwnership.objects.create(
            user=self.user, character=char2, owner_hash="test_hash_2"
        )
        CharacterAssets.objects.create(
            character=char2, token_character=ownership2, is_active=False
        )

        # Only active should be returned
        active = CharacterAssets.objects.active()
        self.assertEqual(active.count(), 1)


class AssetItemTestCase(TestCase):
    """Test AssetItem model"""

    @classmethod
    def setUpTestData(cls):
        """Set up test data"""
        cls.user = User.objects.create_user("test_user", "test@example.com", "password")
        cls.character = EveCharacter.objects.create(
            character_id=123456789,
            character_name="Test Character",
            corporation_id=98000001,
            corporation_name="Test Corp",
        )
        cls.ownership = CharacterOwnership.objects.create(
            user=cls.user, character=cls.character, owner_hash="test_hash"
        )
        cls.char_assets = CharacterAssets.objects.create(
            character=cls.character, token_character=cls.ownership
        )

    def test_create_asset_item(self):
        """Test creating AssetItem"""
        item = AssetItem.objects.create(
            character_assets=self.char_assets,
            item_id=1001,
            type_id=587,  # Rifter
            type_name="Rifter",
            location_id=60003760,
            location_name="Jita IV - Moon 4",
            location_type="station",
            location_flag="Hangar",
            is_ship=True,
        )
        self.assertEqual(item.type_name, "Rifter")
        self.assertTrue(item.is_ship)

    def test_manager_ships_only(self):
        """Test ships_only manager method"""
        # Create ship
        AssetItem.objects.create(
            character_assets=self.char_assets,
            item_id=1001,
            type_id=587,
            type_name="Rifter",
            location_id=60003760,
            location_flag="Hangar",
            is_ship=True,
        )

        # Create non-ship
        AssetItem.objects.create(
            character_assets=self.char_assets,
            item_id=1002,
            type_id=34,  # Tritanium
            type_name="Tritanium",
            location_id=60003760,
            location_flag="Hangar",
            is_ship=False,
        )

        ships = AssetItem.objects.ships_only()
        self.assertEqual(ships.count(), 1)
        self.assertEqual(ships.first().type_name, "Rifter")

    def test_manager_in_hangar(self):
        """Test in_hangar manager method"""
        # Create items in different hangars
        AssetItem.objects.create(
            character_assets=self.char_assets,
            item_id=1001,
            type_id=587,
            type_name="Rifter",
            location_id=60003760,
            location_flag="Hangar",
            is_ship=True,
        )

        AssetItem.objects.create(
            character_assets=self.char_assets,
            item_id=1002,
            type_id=587,
            type_name="Rifter",
            location_id=60003760,
            location_flag="CorpSAG1",
            is_ship=True,
        )

        # Test specific hangar
        hangar = AssetItem.objects.in_hangar("Hangar")
        self.assertEqual(hangar.count(), 1)

        # Test all hangars
        all_hangars = AssetItem.objects.in_hangar("HangarAll")
        self.assertEqual(all_hangars.count(), 2)


class SavedSearchTestCase(TestCase):
    """Test SavedSearch model"""

    @classmethod
    def setUpTestData(cls):
        """Set up test data"""
        cls.user = User.objects.create_user("test_user", "test@example.com", "password")

    def test_create_saved_search(self):
        """Test creating SavedSearch"""
        search = SavedSearch.objects.create(
            user=self.user,
            name="My Ships",
            ship_type_ids=[587, 588],
            location_flags=["Hangar", "CorpSAG1"],
        )
        self.assertEqual(search.name, "My Ships")
        self.assertEqual(len(search.ship_type_ids), 2)
        self.assertEqual(len(search.location_flags), 2)
