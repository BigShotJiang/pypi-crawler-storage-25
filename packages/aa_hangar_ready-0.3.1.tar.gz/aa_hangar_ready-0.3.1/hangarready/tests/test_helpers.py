"""Tests for Hangar Ready helpers"""

from unittest.mock import Mock, patch

from django.test import TestCase

from ..helpers import chunk_list, determine_location_type, is_ship_type


class HelpersTestCase(TestCase):
    """Test helper functions"""

    def test_determine_location_type_structure(self):
        """Test location type for structure"""
        location_type = determine_location_type(1000000000001)
        self.assertEqual(location_type, "structure")

    def test_determine_location_type_station(self):
        """Test location type for station"""
        location_type = determine_location_type(60003760)
        self.assertEqual(location_type, "station")

    def test_determine_location_type_solar_system(self):
        """Test location type for solar system"""
        location_type = determine_location_type(30000142)
        self.assertEqual(location_type, "solar_system")

    def test_determine_location_type_other(self):
        """Test location type for other"""
        location_type = determine_location_type(12345)
        self.assertEqual(location_type, "other")

    def test_chunk_list(self):
        """Test chunk_list function"""
        test_list = list(range(10))
        chunks = list(chunk_list(test_list, 3))
        self.assertEqual(len(chunks), 4)
        self.assertEqual(chunks[0], [0, 1, 2])
        self.assertEqual(chunks[1], [3, 4, 5])
        self.assertEqual(chunks[2], [6, 7, 8])
        self.assertEqual(chunks[3], [9])

    @patch("hangarready.helpers.EveType")
    def test_is_ship_type_true(self, mock_evetype):
        """Test is_ship_type returns True for ships"""
        mock_type = Mock()
        mock_type.eve_group.eve_category_id = 6  # Ship category
        mock_evetype.objects.get.return_value = mock_type

        result = is_ship_type(587)
        self.assertTrue(result)

    @patch("hangarready.helpers.EveType")
    def test_is_ship_type_false(self, mock_evetype):
        """Test is_ship_type returns False for non-ships"""
        mock_type = Mock()
        mock_type.eve_group.eve_category_id = 4  # Material category
        mock_evetype.objects.get.return_value = mock_type

        result = is_ship_type(34)
        self.assertFalse(result)
