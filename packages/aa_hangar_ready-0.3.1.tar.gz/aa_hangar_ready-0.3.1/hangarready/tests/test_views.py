"""Tests for Hangar Ready views"""

from django.contrib.auth.models import Permission, User
from django.test import Client, TestCase
from django.urls import reverse

from allianceauth.authentication.models import CharacterOwnership
from allianceauth.eveonline.models import EveCharacter

from ..models import AssetItem, CharacterAssets


class ViewsTestCase(TestCase):
    """Test views"""

    @classmethod
    def setUpTestData(cls):
        """Set up test data"""
        cls.user = User.objects.create_user("test_user", "test@example.com", "password")
        cls.character = EveCharacter.objects.create(
            character_id=123456789,
            character_name="Test Character",
            corporation_id=98000001,
            corporation_name="Test Corp",
        )
        cls.ownership = CharacterOwnership.objects.create(
            user=cls.user, character=cls.character, owner_hash="test_hash"
        )

        # Grant permission
        permission = Permission.objects.get(codename="basic_access")
        cls.user.user_permissions.add(permission)

    def setUp(self):
        """Set up each test"""
        self.client = Client()
        self.client.login(username="test_user", password="password")

    def test_index_view(self):
        """Test index view"""
        response = self.client.get(reverse("hangarready:index"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Hangar Ready")

    def test_index_requires_permission(self):
        """Test index requires permission"""
        # Remove permission
        permission = Permission.objects.get(codename="basic_access")
        self.user.user_permissions.remove(permission)

        response = self.client.get(reverse("hangarready:index"))
        self.assertEqual(response.status_code, 302)  # Redirect to login

    def test_search_view(self):
        """Test search view"""
        # Create test data
        char_assets = CharacterAssets.objects.create(
            character=self.character, token_character=self.ownership
        )
        AssetItem.objects.create(
            character_assets=char_assets,
            item_id=1001,
            type_id=587,
            type_name="Rifter",
            location_id=60003760,
            location_flag="Hangar",
            is_ship=True,
        )

        response = self.client.get(
            reverse("hangarready:search"), {"type_id": 587, "location_flag": "Hangar"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Rifter")

    def test_manage_characters_view(self):
        """Test manage characters view"""
        response = self.client.get(reverse("hangarready:characters"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Manage Characters")
