"""Tests for Hangar Ready"""
