"""Application settings for Hangar Ready"""

from django.conf import settings

# How often to update character assets (in hours)
HANGAR_READY_UPDATE_INTERVAL = getattr(settings, "HANGAR_READY_UPDATE_INTERVAL", 6)

# Maximum age of cached asset data before requiring refresh (in hours)
HANGAR_READY_MAX_CACHE_AGE = getattr(settings, "HANGAR_READY_MAX_CACHE_AGE", 24)

# Hangar location flags mapping
HANGAR_FLAGS = {
    "Hangar": "Main Hangar",
    "ShipHangar": "Ship Maintenance Bay",
    "FleetHangar": "Fleet Hangar",
    "CorpSAG1": "Corp Hangar 1",
    "CorpSAG2": "Corp Hangar 2",
    "CorpSAG3": "Corp Hangar 3",
    "CorpSAG4": "Corp Hangar 4",
    "CorpSAG5": "Corp Hangar 5",
    "CorpSAG6": "Corp Hangar 6",
    "CorpSAG7": "Corp Hangar 7",
    "HangarAll": "All Hangars",
}

# Ship category ID from EVE SDE
SHIP_CATEGORY_ID = 6

# ESI required scopes
ESI_SCOPE_ASSETS = "esi-assets.read_assets.v1"
ESI_SCOPE_STRUCTURES = "esi-universe.read_structures.v1"

# Combined scopes for full functionality
ESI_SCOPES_ALL = [ESI_SCOPE_ASSETS, ESI_SCOPE_STRUCTURES]
