"""Helper functions for Hangar Ready"""

import logging

from django.core.exceptions import ObjectDoesNotExist
from esi.models import Token
from eveuniverse.models import EveType

from .app_settings import ESI_SCOPE_ASSETS, ESI_SCOPE_STRUCTURES, SHIP_CATEGORY_ID

logger = logging.getLogger(__name__)


def get_character_token(character_ownership, scopes=None):
    """
    Get valid ESI token for a character with specified scopes.

    Args:
        character_ownership: CharacterOwnership instance
        scopes: List of scopes to require, defaults to [ESI_SCOPE_ASSETS]

    Returns:
        Token instance or None if no valid token found
    """
    if scopes is None:
        scopes = [ESI_SCOPE_ASSETS]

    try:
        token = (
            Token.objects.filter(
                user=character_ownership.user,
                character_id=character_ownership.character.character_id,
            )
            .require_scopes(scopes)
            .require_valid()
            .first()
        )
        return token
    except Exception as e:
        logger.warning(
            f"Failed to get token for {character_ownership.character.character_name}: {e}"
        )
        return None


def get_any_token_with_scope(scope):
    """
    Get any valid token with the specified scope.

    Useful for getting structure names which don't require character-specific permissions.

    Args:
        scope: ESI scope to require

    Returns:
        Token instance or None if no valid token found
    """
    try:
        token = (
            Token.objects.filter()
            .require_scopes(scope)
            .require_valid()
            .first()
        )
        return token
    except Exception as e:
        logger.warning(f"Failed to get token with scope {scope}: {e}")
        return None


def is_ship_type(type_id):
    """
    Check if a type ID belongs to a ship.

    Args:
        type_id: EVE type ID to check

    Returns:
        bool: True if type is a ship, False otherwise
    """
    try:
        eve_type = EveType.objects.get(id=type_id)
        return eve_type.eve_group.eve_category_id == SHIP_CATEGORY_ID
    except ObjectDoesNotExist:
        logger.debug(f"Type ID {type_id} not found in database")
        return False


def get_type_name(type_id):
    """
    Get the name of an EVE type by ID.

    Args:
        type_id: EVE type ID

    Returns:
        str: Type name or "Unknown Type (ID: {type_id})"
    """
    try:
        eve_type = EveType.objects.get(id=type_id)
        return eve_type.name
    except ObjectDoesNotExist:
        logger.debug(f"Type ID {type_id} not found in database")
        return f"Unknown Type (ID: {type_id})"


def get_location_name(location_id, esi_client):
    """
    Resolve a location ID to a human-readable name using ESI.

    Args:
        location_id: EVE location ID
        esi_client: ESI client instance

    Returns:
        str: Location name or empty string if not resolved
    """
    try:
        # Try structure name first
        if location_id >= 1000000000000:  # Structure ID range
            result = esi_client.Universe.get_universe_structures_structure_id(
                structure_id=location_id
            ).results()
            return result.get("name", "")
        else:  # Station ID
            result = esi_client.Universe.get_universe_stations_station_id(
                station_id=location_id
            ).results()
            return result.get("name", "")
    except Exception as e:
        logger.debug(f"Failed to resolve location {location_id}: {e}")
        return ""


def determine_location_type(location_id):
    """
    Determine the type of location based on ID.

    Args:
        location_id: EVE location ID

    Returns:
        str: Location type ("station", "structure", "space", "other")
    """
    if location_id >= 1000000000000:
        return "structure"
    elif 60000000 <= location_id < 64000000:
        return "station"
    elif location_id >= 30000000 and location_id < 40000000:
        return "solar_system"
    else:
        return "other"


def chunk_list(lst, chunk_size):
    """
    Split a list into chunks of specified size.

    Args:
        lst: List to chunk
        chunk_size: Size of each chunk

    Yields:
        List chunks
    """
    for i in range(0, len(lst), chunk_size):
        yield lst[i : i + chunk_size]
