"""
AA Hangar Ready - Alliance Auth Plugin

Tracks character assets via ESI to check which characters have specific ships
in specific hangar locations.
"""

default_app_config = "hangarready.apps.HangarReadyConfig"

__version__ = "0.3.1"
__title__ = "Hangar Ready"
__description__ = "Alliance Auth plugin to track character ship assets in hangars via ESI"
