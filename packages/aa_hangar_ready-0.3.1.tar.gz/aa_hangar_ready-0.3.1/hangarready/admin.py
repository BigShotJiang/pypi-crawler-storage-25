"""Django admin configuration for Hangar Ready"""

from django.contrib import admin

from .models import AssetItem, CharacterAssets, Location, SavedSearch


@admin.register(CharacterAssets)
class CharacterAssetsAdmin(admin.ModelAdmin):
    """Admin for CharacterAssets model"""

    list_display = [
        "character",
        "token_character",
        "last_update",
        "is_active",
        "has_error",
    ]
    list_filter = ["is_active", "last_update"]
    search_fields = [
        "character__character_name",
        "token_character__user__username",
    ]
    readonly_fields = ["last_update", "update_error"]
    raw_id_fields = ["character", "token_character"]

    def has_error(self, obj):
        """Check if last update had error"""
        return bool(obj.update_error)

    has_error.boolean = True
    has_error.short_description = "Error"


@admin.register(AssetItem)
class AssetItemAdmin(admin.ModelAdmin):
    """Admin for AssetItem model"""

    list_display = [
        "type_name",
        "character_name",
        "location_flag",
        "location_name",
        "quantity",
        "is_ship",
    ]
    list_filter = ["is_ship", "location_flag", "location_type"]
    search_fields = [
        "type_name",
        "character_assets__character__character_name",
        "location_name",
    ]
    readonly_fields = ["item_id", "type_id", "type_name"]
    raw_id_fields = ["character_assets"]

    def character_name(self, obj):
        """Get character name"""
        return obj.character_assets.character.character_name

    character_name.short_description = "Character"
    character_name.admin_order_field = "character_assets__character__character_name"


@admin.register(SavedSearch)
class SavedSearchAdmin(admin.ModelAdmin):
    """Admin for SavedSearch model"""

    list_display = ["name", "user", "created_at", "updated_at"]
    list_filter = ["created_at", "updated_at"]
    search_fields = ["name", "user__username"]
    readonly_fields = ["created_at", "updated_at"]
    raw_id_fields = ["user"]


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    """Admin for Location model"""

    list_display = ["name", "location_id", "location_type", "last_updated"]
    list_filter = ["location_type", "last_updated"]
    search_fields = ["name", "location_id"]
    readonly_fields = ["last_updated"]

    def has_add_permission(self, request):
        """Locations are auto-populated, disable manual add"""
        return False
