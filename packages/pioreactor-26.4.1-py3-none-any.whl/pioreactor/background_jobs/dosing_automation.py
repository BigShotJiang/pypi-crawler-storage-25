# -*- coding: utf-8 -*-
import time
from contextlib import suppress
from datetime import datetime
from functools import partial
from threading import Event
from typing import Any

import click
from msgspec.json import decode
from pioreactor import bioreactor
from pioreactor import exc
from pioreactor import structs
from pioreactor import types as pt
from pioreactor import whoami
from pioreactor.actions.pump import add_alt_media
from pioreactor.actions.pump import add_media
from pioreactor.actions.pump import remove_waste
from pioreactor.automations import events
from pioreactor.automations.base import AutomationJob
from pioreactor.config import config
from pioreactor.logging import create_logger
from pioreactor.pubsub import QOS
from pioreactor.states import JobState
from pioreactor.utils import is_pio_job_running
from pioreactor.utils import local_persistent_storage
from pioreactor.utils import SummableDict
from pioreactor.utils.timing import current_utc_datetime
from pioreactor.utils.timing import RepeatedTimer


class classproperty(property):
    def __get__(self, obj: object, objtype: type | None = None) -> Any:
        assert self.fget is not None
        return self.fget(objtype)


def brief_pause() -> float:
    d = 5.0
    time.sleep(d)
    return d


def briefer_pause() -> float:
    d = 0.05
    time.sleep(d)
    return d


def pause_between_subdoses() -> float:
    d = float(config.get("dosing_automation.config", "pause_between_subdoses_seconds", fallback=5.0))
    time.sleep(d)
    return d


class ThroughputCalculator:
    """
    Computes the fraction of the vial that is from the alt-media vs the regular media. Useful for knowing how much media
    has been spent, so that triggers can be set up to replace media stock.
    """

    @staticmethod
    def update(
        dosing_event: structs.DosingEvent,
        current_media_throughput: float,
        current_alt_media_throughput: float,
    ) -> tuple[float, float]:
        volume, event = float(dosing_event.volume_change), dosing_event.event
        if event == "add_media":
            current_media_throughput += volume
        elif event == "add_alt_media":
            current_alt_media_throughput += volume
        elif event == "remove_waste":
            pass
        else:
            raise ValueError("Unknown event type")

        return (current_media_throughput, current_alt_media_throughput)


class DosingAutomationJob(AutomationJob):
    """
    This is the super class that automations inherit from. The `run` function will
    execute every `duration` minutes (selected at the start of the program). If `duration` is left
    as None, manually call `run`. This calls the `execute` function, which is what subclasses will define.

    To change setting over MQTT:

    `pioreactor/<unit>/<experiment>/dosing_automation/<setting>/set` value

    """

    automation_name = "dosing_automation_base"  # is overwritten in subclasses
    job_name = "dosing_automation"
    published_settings: dict[str, pt.PublishableSetting] = {}

    latest_event: structs.AutomationEvent | None = None
    _latest_run_at: datetime | None = None
    _last_vial_volume_warning_at: float | None = None
    run_thread: RepeatedTimer
    duration: float | None

    # overwrite to use your own dosing programs.
    # interface must look like types.DosingProgram

    # Runtime dosing state used by the control loop. Throughput is published by this job.
    # Liquid metadata is different: these attributes are only an in-memory mirror of the
    # retained bioreactor state so the automation can react immediately after dosing events.
    # Persistence and retained publishing for liquid metadata are owned by bioreactor.py.
    alt_media_fraction: float  # fraction of the vial that is alt-media (vs regular media).
    media_throughput: float  # amount of media that has been expelled
    alt_media_throughput: float  # amount of alt-media that has been expelled
    current_volume_ml: float  # amount in the vial
    efflux_tube_volume_ml: float  # steady-state volume set by the waste/efflux tube height

    @classproperty
    def MAX_VIAL_VOLUME_TO_STOP(cls) -> float:
        return whoami.get_pioreactor_model().reactor_max_fill_volume_ml

    @classproperty
    def MAX_VIAL_VOLUME_TO_WARN(cls) -> float:
        return 0.95 * cls.MAX_VIAL_VOLUME_TO_STOP

    @classproperty
    def MAX_SUBDOSE(cls) -> float:
        return config.getfloat(
            "dosing_automation.config", "max_subdose", fallback=1.0
        )  # arbitrary, but should be some value that the pump is well calibrated for.

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

        # this registers all subclasses of DosingAutomationJob
        if hasattr(cls, "automation_name") and getattr(cls, "automation_name") != "dosing_automation_base":
            available_dosing_automations[cls.automation_name] = cls

    def __init__(
        self,
        unit: pt.Unit,
        experiment: pt.Experiment,
        duration: float | None = None,
        skip_first_run: bool = False,
        alt_media_fraction: float | None = None,
        current_volume_ml: float | None = None,
        efflux_tube_volume_ml: float | None = None,
        **kwargs: Any,
    ) -> None:
        super(DosingAutomationJob, self).__init__(unit, experiment)

        if "duration" not in self.published_settings:

            self.add_to_published_settings(
                "duration",
                {
                    "datatype": "float",
                    "settable": True,
                    "unit": "min",
                },
            )

        self.skip_first_run = skip_first_run

        self._init_alt_media_fraction(alt_media_fraction)
        self._init_volume_throughput()
        self._init_liquid_volume(current_volume_ml, efflux_tube_volume_ml)
        self._last_vial_volume_warning_at: float | None = None
        self.logger.debug(
            f"Volume settings initialized: current_volume_ml={self.current_volume_ml:.2f} mL, "
            f"efflux_tube_volume_ml={self.efflux_tube_volume_ml:.2f} mL."
        )

        self.set_duration(duration)
        self._continue_pumping_event = Event()

        if not is_pio_job_running("stirring"):
            self.logger.warning(
                "It's recommended to have stirring on to improve mixing during dosing events."
            )

    add_media_to_bioreactor: pt.DosingProgram = staticmethod(
        partial(add_media, duration=None, calibration=None, continuously=False)
    )
    remove_waste_from_bioreactor: pt.DosingProgram = staticmethod(
        partial(remove_waste, duration=None, calibration=None, continuously=False)
    )
    add_alt_media_to_bioreactor: pt.DosingProgram = staticmethod(
        partial(add_alt_media, duration=None, calibration=None, continuously=False)
    )

    def set_duration(self, duration: float | None) -> None:
        if duration:
            self.duration = float(duration)

            with suppress(AttributeError):
                self.run_thread.cancel()

            if self._latest_run_at is not None:
                # what's the correct logic when changing from duration N and duration M?
                # - N=20, and it's been 5m since the last run (or initialization). I change to M=30, I should wait M-5 minutes.
                # - N=60, and it's been 50m since last run. I change to M=30, I should run immediately.
                run_after = max(
                    0,
                    (self.duration * 60) - (current_utc_datetime() - self._latest_run_at).seconds,
                )
            else:
                # there is a race condition here: self.run() will run immediately (see run_immediately), but the state of the job is not READY, since
                # set_duration is run in the __init__ (hence the job is INIT). So we wait 2 seconds for the __init__ to finish, and then run.
                run_after = 2.0

            self.run_thread = RepeatedTimer(
                self.duration * 60,
                self.run,
                job_name=self.job_name,
                run_immediately=(not self.skip_first_run) or (self._latest_run_at is not None),
                run_after=run_after,
                logger=self.logger,
            ).start()

    def run(self, timeout: float = 60.0) -> structs.AutomationEvent | None:
        """
        Parameters
        -----------
        timeout: float
            if the job is not in a READY state after timeout seconds, skip calling `execute` this period.
            Default 60s.

        """
        event: structs.AutomationEvent | None

        self._latest_run_at = current_utc_datetime()

        if self.state == self.DISCONNECTED:
            # NOOP
            # we ended early.
            return None

        elif self.state != self.READY:
            sleep_for = brief_pause()
            # wait a 60s, and if not unpaused, just move on.
            if (timeout - sleep_for) <= 0:
                self.logger.debug("Timed out waiting for READY.")
                return None
            else:
                return self.run(timeout=timeout - sleep_for)
        else:
            # we are in READY
            try:
                event = self.execute()
                if event:
                    self.logger.info(event.display())

            except exc.JobRequiredError as e:
                self.logger.debug(e, exc_info=True)
                self.logger.warning(e)
                event = events.ErrorOccurred(str(e))
            except Exception as e:
                self.logger.debug(e, exc_info=True)
                self.logger.error(e)
                event = events.ErrorOccurred(str(e))

        self.latest_event = event
        return event

    def block_until_not_sleeping(self) -> bool:
        while self.state == self.SLEEPING:
            brief_pause()
        return True

    def stop_active_pumps(self) -> None:
        for pump_job_name in ("add_media", "add_alt_media", "remove_waste"):
            self.pub_client.publish(
                f"pioreactor/{self.unit}/{self.experiment}/{pump_job_name}/$state/set",
                JobState.DISCONNECTED.to_bytes(),
                qos=QOS.AT_LEAST_ONCE,
            )

    def execute_io_action(
        self,
        waste_ml: float = 0.0,
        **all_pumps_ml: float,
    ) -> SummableDict:
        self.latest_event = events.DosingStarted(data={"waste_ml": waste_ml, **all_pumps_ml})
        result = self._execute_io_action(waste_ml, **all_pumps_ml)
        self.latest_event = events.DosingStopped(data=result)
        return result

    def _execute_io_action(
        self,
        waste_ml: float = 0.0,
        **all_pumps_ml: float,
    ) -> SummableDict:
        """
        This function recursively reduces the amount to add so that we don't end up adding 5ml,
        and then removing 5ml (this could cause vial overflow). Instead we add 0.5ml, remove 0.5ml,
        add 0.5ml, remove 0.5ml, and so on. We also want sufficient time to mix, and this procedure
        will slow dosing down.


        Users can call additional pumps by providing them as kwargs. Ex:

        > dc.execute_io_action(waste_ml=2, media_ml=1, salt_media_ml=0.5, media_from_sigma_ml=0.5)

        It's required that a named pump function is present to. In the example above, we would need the following defined:

        > dc.add_salt_media_to_bioreactor(...)
        > dc.add_media_from_sigma_to_bioreactor(...)

        Specifically, if you enter a kwarg `<name>_ml`, you need a function `add_<name>_to_bioreactor`. The pump function
        should have signature equal to pioreactor.types.DosingProgram.



        Note
        ------
        If alt_media_ml and media_ml are non-zero, we keep their ratio equal for each
        sub-call. This keeps the ratio of alt_media to media the same in the vial.

        A problem is if the there is skew in the different mLs, then it's possible that one or more pumps
        must dose a very small amount, where our pumps have poor accuracy.


        Returns
        ---------
        A dict of volumes that were moved, in mL. This may be different than the request mLs, if a error in a pump occurred.

        """
        if not all(other_pump_ml.endswith("_ml") for other_pump_ml in all_pumps_ml.keys()):
            raise ValueError(
                "all kwargs should end in `_ml`. Example: `execute_io_action(salty_media_ml=1.0)`"
            )

        sum_of_volumes = sum(ml for ml in all_pumps_ml.values())
        if not (waste_ml >= sum_of_volumes - 1e-9):
            # why close? account for floating point imprecision, ex: .6299999999999999 != 0.63
            raise ValueError(
                "Not removing enough waste: waste_ml should be greater than or equal to sum of all dosed ml"
            )

        volumes_moved = SummableDict(waste_ml=0.0, **{p: 0.0 for p in all_pumps_ml})
        source_of_event = f"{self.job_name}:{self.automation_name}"

        if sum_of_volumes > self.MAX_SUBDOSE:
            volumes_moved += self._execute_io_action(
                waste_ml=waste_ml / 2,
                **{pump: volume_ml / 2 for pump, volume_ml in all_pumps_ml.items()},
            )
            volumes_moved += self._execute_io_action(
                waste_ml=waste_ml / 2,
                **{pump: volume_ml / 2 for pump, volume_ml in all_pumps_ml.items()},
            )

        else:
            # iterate through pumps, and dose required amount. First *_media, then waste.
            projected_volume_ml = self.current_volume_ml
            for pump, volume_ml in all_pumps_ml.items():
                if (projected_volume_ml + volume_ml) >= self.MAX_VIAL_VOLUME_TO_STOP:
                    self.logger.error(
                        f"Pausing all pumping since {projected_volume_ml:g} + {volume_ml} mL is beyond safety threshold {self.MAX_VIAL_VOLUME_TO_STOP} mL."
                    )
                    self.set_state(self.SLEEPING)
                    return volumes_moved

                if (
                    (volume_ml > 0)
                    and self.block_until_not_sleeping()
                    and (self.state in (self.READY,))
                    and not self._continue_pumping_event.is_set()
                ):
                    pump_function = getattr(self, f"add_{pump.removesuffix('_ml')}_to_bioreactor")

                    volumes_moved[pump] += pump_function(
                        unit=self.unit,
                        experiment=self.experiment,
                        ml=volume_ml,
                        source_of_event=source_of_event,
                        mqtt_client=self.pub_client,
                        logger=self.logger,
                    )
                    projected_volume_ml += volumes_moved[pump]
                    pause_between_subdoses()  # allow time for the addition to mix, and reduce the step response that can cause ringing in the output V.

            # remove waste last.
            if (
                waste_ml > 0
                and self.block_until_not_sleeping()
                and (self.state in (self.READY,))
                and not self._continue_pumping_event.is_set()
            ):
                volumes_moved["waste_ml"] += self.remove_waste_from_bioreactor(
                    unit=self.unit,
                    experiment=self.experiment,
                    ml=waste_ml,
                    source_of_event=source_of_event,
                    mqtt_client=self.pub_client,
                    logger=self.logger,
                )
                briefer_pause()

            # run remove_waste for an additional few seconds to keep volume constant (determined by the length of the waste tube)
            # check exit conditions again!
            extra_waste_ml = waste_ml * config.getfloat(
                "dosing_automation.config", "waste_removal_multiplier", fallback=2.0
            )
            if (
                extra_waste_ml > 0
                and self.block_until_not_sleeping()
                and (self.state in (self.READY,))
                and not self._continue_pumping_event.is_set()
            ):
                self.remove_waste_from_bioreactor(
                    unit=self.unit,
                    experiment=self.experiment,
                    ml=extra_waste_ml,
                    source_of_event=source_of_event,
                    mqtt_client=self.pub_client,
                    logger=self.logger,
                )
                briefer_pause()

        if volumes_moved["waste_ml"] < waste_ml:
            self.logger.warning(
                f"Waste was under-removed. Expected to remove {waste_ml} ml, only removed {volumes_moved['waste_ml']} ml."
            )

        return volumes_moved

    ########## Private & internal methods

    def on_sleeping(self) -> None:
        self.stop_active_pumps()

    def on_disconnected(self) -> None:
        self._continue_pumping_event.set()  # set this early so the pumps exits.
        with suppress(AttributeError):
            self.run_thread.join(
                timeout=10
            )  # thread has N seconds to end. If not, something is wrong, like a while loop in execute that isn't stopping.
            if self.run_thread.is_alive():
                self.logger.debug("run_thread still alive!")

    def _update_throughput_from_dosing_event(self, message: pt.MQTTMessage) -> None:
        dosing_event = decode(message.payload, type=structs.DosingEvent)
        self._update_throughput(dosing_event)

    def _should_warn_about_high_vial_volume(self) -> bool:
        now = time.time()
        if self._last_vial_volume_warning_at is None or (now - self._last_vial_volume_warning_at) >= 10:
            self._last_vial_volume_warning_at = now
            return True
        return False

    def _update_throughput(self, dosing_event: structs.DosingEvent) -> None:
        (
            self.media_throughput,
            self.alt_media_throughput,
        ) = ThroughputCalculator.update(dosing_event, self.media_throughput, self.alt_media_throughput)

        # add to cache
        with local_persistent_storage("alt_media_throughput") as cache:
            cache[self.experiment] = self.alt_media_throughput

        with local_persistent_storage("media_throughput") as cache:
            cache[self.experiment] = self.media_throughput

    def _init_alt_media_fraction(self, alt_media_fraction: float | None) -> None:
        if alt_media_fraction is None:
            resolved_alt_media_fraction = bioreactor.get_bioreactor_value(
                self.experiment,
                "alt_media_fraction",
            )
        else:
            resolved_alt_media_fraction = alt_media_fraction

        # Seed the shared bioreactor state, and initialize the automation's local mirror from
        # the same value.
        self.alt_media_fraction = bioreactor.set_and_publish_bioreactor_value(
            self.pub_client,
            self.unit,
            self.experiment,
            "alt_media_fraction",
            resolved_alt_media_fraction,
        )

    def _init_liquid_volume(
        self, current_volume_ml: float | None, efflux_tube_volume_ml: float | None
    ) -> None:
        if efflux_tube_volume_ml is None:
            resolved_efflux_tube_volume_ml = bioreactor.get_bioreactor_value(
                self.experiment,
                "efflux_tube_volume_ml",
            )
        else:
            resolved_efflux_tube_volume_ml = efflux_tube_volume_ml

        if current_volume_ml is None:
            resolved_current_volume_ml = bioreactor.get_bioreactor_value(self.experiment, "current_volume_ml")
        else:
            resolved_current_volume_ml = current_volume_ml

        # Seed the shared bioreactor state, and initialize the automation's local mirror from
        # the same values.
        self.efflux_tube_volume_ml = bioreactor.set_and_publish_bioreactor_value(
            self.pub_client,
            self.unit,
            self.experiment,
            "efflux_tube_volume_ml",
            resolved_efflux_tube_volume_ml,
        )
        self.current_volume_ml = bioreactor.set_and_publish_bioreactor_value(
            self.pub_client,
            self.unit,
            self.experiment,
            "current_volume_ml",
            resolved_current_volume_ml,
        )

    def _init_volume_throughput(self) -> None:
        self.add_to_published_settings(
            "alt_media_throughput",
            {"datatype": "float", "settable": False, "unit": "mL", "persist": True},
        )
        self.add_to_published_settings(
            "media_throughput",
            {"datatype": "float", "settable": False, "unit": "mL", "persist": True},
        )

        with local_persistent_storage("alt_media_throughput") as cache:
            self.alt_media_throughput = cache.getfloat(self.experiment, fallback=0.0)

        with local_persistent_storage("media_throughput") as cache:
            self.media_throughput = cache.getfloat(self.experiment, fallback=0.0)

        return

    def start_passive_listeners(self) -> None:
        self.subscribe_and_callback(
            self._update_throughput_from_dosing_event,
            f"pioreactor/{self.unit}/{self.experiment}/dosing_events",
        )
        # The shared retained bioreactor topics are the source of truth for liquid metadata.
        # This keeps the automation synchronized with monitor-projected dosing events, manual
        # UI/API edits, retained-state replay on startup/reconnect, and other external updates.
        self.subscribe_and_callback(
            self._set_alt_media_fraction_from_mqtt,
            bioreactor.get_bioreactor_topic(self.unit, self.experiment, "alt_media_fraction"),
        )
        self.subscribe_and_callback(
            self._set_current_volume_ml_from_mqtt,
            bioreactor.get_bioreactor_topic(self.unit, self.experiment, "current_volume_ml"),
        )
        self.subscribe_and_callback(
            self._set_efflux_tube_volume_ml_from_mqtt,
            bioreactor.get_bioreactor_topic(self.unit, self.experiment, "efflux_tube_volume_ml"),
        )

    def _set_alt_media_fraction_from_mqtt(self, message: pt.MQTTMessage) -> None:
        # This updates only the automation's local mirror from shared bioreactor topics. It does
        # not persist or publish anything itself.
        if not message.payload:
            return

        self.alt_media_fraction = bioreactor.validate_bioreactor_value("alt_media_fraction", message.payload)

    def _set_current_volume_ml_from_mqtt(self, message: pt.MQTTMessage) -> None:
        if not message.payload:
            return

        self.current_volume_ml = bioreactor.validate_bioreactor_value("current_volume_ml", message.payload)

        if (
            self.current_volume_ml >= self.MAX_VIAL_VOLUME_TO_WARN
            and self._should_warn_about_high_vial_volume()
        ):
            self.logger.warning(
                f"Vial is calculated to have a volume of {self.current_volume_ml:.2f} mL. Is this expected?"
            )
        elif self.current_volume_ml >= self.MAX_VIAL_VOLUME_TO_STOP:
            pass
            # TODO: this should publish to pumps to stop them.
            # but it is checked elsewhere

    def _set_efflux_tube_volume_ml_from_mqtt(self, message: pt.MQTTMessage) -> None:
        if not message.payload:
            return

        self.efflux_tube_volume_ml = bioreactor.validate_bioreactor_value(
            "efflux_tube_volume_ml", message.payload
        )


class DosingAutomationJobContrib(DosingAutomationJob):
    automation_name: str


def start_dosing_automation(
    automation_name: str,
    skip_first_run: bool = False,
    unit: str | None = None,
    experiment: str | None = None,
    **kwargs: Any,
) -> DosingAutomationJob:
    from pioreactor.automations import dosing  # noqa: F401

    unit = unit or whoami.get_unit_name()
    experiment = experiment or whoami.get_assigned_experiment_name(unit)
    try:
        klass = available_dosing_automations[automation_name]
    except KeyError:
        raise KeyError(
            f"Unable to find {automation_name}. Available automations are {list(available_dosing_automations.keys())}"
        )

    try:
        return klass(
            unit=unit,
            experiment=experiment,
            automation_name=automation_name,
            skip_first_run=skip_first_run,
            **kwargs,
        )

    except exc.JobPresentError:
        raise
    except Exception as e:
        logger = create_logger("dosing_automation")
        logger.error(e)
        logger.debug(e, exc_info=True)
        raise e


available_dosing_automations: dict[str, type[DosingAutomationJob]] = {}


@click.command(
    name="dosing_automation",
    context_settings=dict(ignore_unknown_options=True, allow_extra_args=True),
)
@click.option(
    "--automation-name",
    help="set the automation of the system: silent, etc.",
    show_default=True,
    required=True,
)
@click.option("--duration", default=60.0, help="Time, in minutes, between every execution of the algorithm.")
@click.option(
    "--skip-first-run",
    type=click.IntRange(min=0, max=1),
    help="Normally algo will run immediately. Set this flag to wait <duration>min before executing.",
)
@click.pass_context
def click_dosing_automation(
    ctx: click.Context, automation_name: str, duration: float, skip_first_run: int
) -> None:
    """
    Start a dosing automation
    """

    with start_dosing_automation(
        automation_name=automation_name,
        duration=float(duration),
        skip_first_run=bool(skip_first_run),
        **{ctx.args[i][2:].replace("-", "_"): ctx.args[i + 1] for i in range(0, len(ctx.args), 2)},
    ) as da:
        da.block_until_disconnected()
