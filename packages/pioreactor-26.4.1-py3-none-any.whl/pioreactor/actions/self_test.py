# -*- coding: utf-8 -*-
"""
This action performs internal hardware & software tests of the system to confirm things work as expected.

Functions with prefix `test_` are ran, and any exception thrown means the test failed.

Outputs from each test go into MQTT, and return to the command line.
"""
import signal
from contextlib import contextmanager
from contextlib import nullcontext
from functools import cache
from json import dumps
from time import sleep
from types import FrameType
from typing import Callable
from typing import cast
from typing import Iterator

import click
from pioreactor import plugin_management
from pioreactor.actions.led_intensity import ALL_LED_CHANNELS
from pioreactor.actions.led_intensity import change_leds_intensities_temporarily
from pioreactor.actions.led_intensity import led_intensity
from pioreactor.automations.temperature.only_record_temperature import OnlyRecordTemperature
from pioreactor.background_jobs import stirring
from pioreactor.background_jobs.od_reading import ADCReader
from pioreactor.background_jobs.od_reading import average_over_raw_pd_readings
from pioreactor.background_jobs.od_reading import IR_keyword
from pioreactor.background_jobs.od_reading import REF_keyword
from pioreactor.background_jobs.od_reading import start_od_reading
from pioreactor.config import config
from pioreactor.hardware import get_available_pd_channels
from pioreactor.hardware import is_HAT_present
from pioreactor.hardware import is_heating_pcb_present
from pioreactor.hardware import voltage_in_aux
from pioreactor.logging import create_logger
from pioreactor.logging import CustomLogger
from pioreactor.states import JobState
from pioreactor.types import LedChannel
from pioreactor.types import PdChannel
from pioreactor.utils import is_pio_job_running
from pioreactor.utils import local_persistent_storage
from pioreactor.utils import managed_lifecycle
from pioreactor.utils import SummableDict
from pioreactor.utils.math_helpers import correlation
from pioreactor.utils.math_helpers import mean
from pioreactor.utils.math_helpers import variance
from pioreactor.whoami import get_unit_name
from pioreactor.whoami import is_testing_env
from pioreactor.whoami import UNIVERSAL_EXPERIMENT

if is_testing_env():
    from pioreactor.utils.mock import MockRpmCalculator


SELF_TEST_TIMEOUT_SECONDS = 180.0
ORDERED_SELF_TEST_NAMES: tuple[str, ...] = (
    # order in UI - good for responsiveness.
    "test_pioreactor_HAT_present",
    "test_all_positive_correlations_between_pds_and_leds",
    "test_ambient_light_interference",
    "test_dark_offset_correction_is_effective",
    "test_REF_is_lower_than_0_dot_256_volts",
    "test_REF_is_in_correct_position",
    "test_PD_is_near_0_volts_for_blank",
    "test_detect_heating_pcb",
    "test_positive_correlation_between_temperature_and_heating",
    "test_positive_correlation_between_rpm_and_stirring",
    "test_aux_power_is_not_too_high",
)
type SelfTest = Callable[[managed_lifecycle, CustomLogger, str, str], None]
REGISTERED_SELF_TESTS: list[SelfTest] = []


class SelfTestTimedOut(TimeoutError):
    pass


def register_self_tests(*tests: SelfTest) -> None:
    for test in tests:
        if test not in REGISTERED_SELF_TESTS:
            REGISTERED_SELF_TESTS.append(test)


@cache
def _ensure_plugin_self_tests_registered() -> None:
    plugin_management.load_plugins()


def get_builtin_self_tests() -> list[SelfTest]:
    current_module = globals()
    return [cast(SelfTest, current_module[name]) for name in ORDERED_SELF_TEST_NAMES]


@contextmanager
def timeout_self_test(test_name: str, timeout_seconds: float) -> Iterator[None]:
    previous_handler = signal.getsignal(signal.SIGALRM)
    previous_timer = signal.getitimer(signal.ITIMER_REAL)

    def alarm_handler(_signum: int, _frame: FrameType | None) -> None:
        raise SelfTestTimedOut(f"{test_name} timed out after {SELF_TEST_TIMEOUT_SECONDS}s.")

    signal.signal(signal.SIGALRM, alarm_handler)
    signal.setitimer(signal.ITIMER_REAL, timeout_seconds)

    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        signal.signal(signal.SIGALRM, previous_handler)
        if previous_timer[0] > 0.0 or previous_timer[1] > 0.0:
            signal.setitimer(signal.ITIMER_REAL, previous_timer[0], previous_timer[1])


def test_pioreactor_HAT_present(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_HAT_present(), "HAT is not connected"


def test_REF_is_in_correct_position(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    # Toggle stirring between SLEEPING and READY. The REF channel should have a much smaller
    # ON/OFF effect than signal channels if it is physically in the REF position.
    from statistics import median

    assert is_HAT_present(), "Hat is not detected."

    pd_channels = config["od_config.photodiode_channel"]
    reference_channel = cast(PdChannel, next((k for k, v in pd_channels.items() if v == REF_keyword), None))
    assert reference_channel is not None, "REF required for this self-test"

    signal_channels: list[PdChannel] = [
        cast(PdChannel, channel) for channel, angle in pd_channels.items() if angle != REF_keyword
    ]

    test_channels = {str(channel): "90" for channel, angle in pd_channels.items()}

    all_channels = [cast(PdChannel, channel) for channel in test_channels]
    relative_effect_per_channel: dict[PdChannel, list[float]] = {channel: [] for channel in all_channels}

    with (
        stirring.start_stirring(
            target_rpm=None, duty_cycle=90, unit=unit, experiment=experiment, enable_dodging_od=False
        ) as st,
        start_od_reading(
            channels=test_channels,
            interval=None,
            unit=unit,
            fake_data=is_testing_env(),
            experiment=experiment,
            calibration=False,
            estimator=False,
        ) as od_reader,
    ):
        st.block_until_rpm_is_close_to_target(abs_tolerance=150, timeout=10)

        warmup_samples = 5
        n_cycles = 8
        settle_samples = 1
        window_samples = 2

        # Warm-up: discard a few initial readings to allow signals to stabilize.
        for _ in range(warmup_samples):
            reading = od_reader.record_from_adc()
            assert reading is not None, "Unable to capture OD reading during warmup."

        def collect_phase_medians(target_state: JobState) -> dict[PdChannel, float]:
            st.set_state(target_state)
            sleep(1)
            per_channel_window: dict[PdChannel, list[float]] = {channel: [] for channel in all_channels}

            for sample_i in range(settle_samples + window_samples):
                reading = od_reader.record_from_adc()
                assert reading is not None, "Unable to capture OD reading while collecting phase medians."
                if sample_i < settle_samples:
                    continue
                for channel in all_channels:
                    per_channel_window[channel].append(reading.ods[channel].od)

            return {channel: float(median(values)) for channel, values in per_channel_window.items()}

        for _ in range(n_cycles):
            off_medians = collect_phase_medians(JobState.SLEEPING)
            on_medians = collect_phase_medians(JobState.READY)
            for channel in all_channels:
                EPS = 1e-9
                relative_effect_per_channel[channel].append(
                    abs(on_medians[channel] - off_medians[channel])
                    / max((abs(on_medians[channel]) + abs(off_medians[channel])) / 2, EPS)
                )

    effect_per_channel = {
        channel: float(median(relative_effects))
        for channel, relative_effects in relative_effect_per_channel.items()
    }
    ref_effect = effect_per_channel[reference_channel]
    signal_effects = {channel: effect_per_channel[channel] for channel in signal_channels}
    highest_signal_channel = max(signal_effects, key=signal_effects.__getitem__)
    highest_signal_effect = signal_effects[highest_signal_channel]

    logger.debug(f"{relative_effect_per_channel=}")
    logger.debug(f"{effect_per_channel=}")

    MIN_SIGNAL_EFFECT = 0.002
    MAX_REF_EFFECT = 0.010
    MAX_REF_TO_SIGNAL_RATIO = 0.5

    assert (
        highest_signal_effect >= MIN_SIGNAL_EFFECT
    ), f"Stirring perturbation too small to evaluate REF placement. {effect_per_channel=}"
    assert (
        ref_effect <= MAX_REF_EFFECT
    ), f"REF is too disturbed by stirring. {reference_channel=}, {effect_per_channel=}"
    assert (
        ref_effect <= MAX_REF_TO_SIGNAL_RATIO * highest_signal_effect
    ), f"REF disturbance is too similar to SIGNAL disturbance. {reference_channel=}, {highest_signal_channel=}, {effect_per_channel=}"


def test_all_positive_correlations_between_pds_and_leds(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    """
    This tests that there is a positive correlation between the IR LED channel, and the photodiodes
    as defined in the config.ini. Note: this includes the REF photodiode when configured in
    od_config.photodiode_channel.

    TODO: if this exits early, we should turn off the LEDs
    """
    from pprint import pformat

    assert is_HAT_present(), "HAT is not detected."
    # better to err on the side of MORE samples than less - it's only a few extra seconds...
    # we randomize to reduce effects of temperature
    # upper bound shouldn't be too high, as it could saturate the ADC, and lower bound shouldn't be too low, else we don't detect anything.

    # what's up with this order? We originally did a shuffle() of list(range(x, y, z))
    # so as to reduce the effects of temperature.
    # the problem is that if an LED is directly across from a PD, a high intensity will quickly
    # saturate it and fail the test. So we try low intensities first, and if we exceed some threshold
    # we exit before moving to the high intensities.
    INTENSITIES = [10, 70, 60, 40, 30, 20, 50, 80]

    pd_channels_available = list(get_available_pd_channels())

    results: dict[tuple[LedChannel, PdChannel], float] = {}

    ir_led_channel = cast(LedChannel, config["leds_reverse"][IR_keyword])

    # set all to 0,
    led_intensity(
        {channel: 0 for channel in ALL_LED_CHANNELS},
        unit=unit,
        experiment=experiment,
        verbose=False,
        source_of_event="self_test",
    )

    adc_reader = ADCReader(
        channels=pd_channels_available, dynamic_gain=True, fake_data=is_testing_env(), penalizer=0.0
    )
    adc_reader.add_external_logger(logger)
    tune_state = {channel: 0.0 for channel in ALL_LED_CHANNELS}
    tune_state[ir_led_channel] = max(INTENSITIES)  # tune the ADC to the maximum
    with change_leds_intensities_temporarily(
        tune_state,
        unit=unit,
        experiment=experiment,
        verbose=False,
        source_of_event="self_test",
    ):
        adc_reader.tune_adc_with_ir_on()
    # TODO: should we remove blank? Technically correlation is invariant to location.

    with stirring.start_stirring(
        target_rpm=500, unit=unit, experiment=experiment, enable_dodging_od=False
    ) as st:
        st.block_until_rpm_is_close_to_target(abs_tolerance=150, timeout=10)
        # for led_channel in ALL_LED_CHANNELS: # we use to check all LED channels, but most users don't need to check all, also https://github.com/Pioreactor/pioreactor/issues/445
        for led_channel in [ir_led_channel]:  # fast to just check IR
            try:
                varying_intensity_results: dict[PdChannel, list[float]] = {
                    pd_channel: [] for pd_channel in pd_channels_available
                }
                for intensity in INTENSITIES:
                    # turn on the LED to set intensity
                    led_intensity(
                        {led_channel: intensity},
                        unit=unit,
                        experiment=experiment,
                        verbose=False,
                        source_of_event="self_test",
                    )

                    # record from ADC, we'll average them
                    avg_reading = average_over_raw_pd_readings(
                        adc_reader.take_reading(),
                        adc_reader.take_reading(),
                        adc_reader.take_reading(),
                    )

                    # turn off led to cool it down
                    led_intensity(
                        {led_channel: 0},
                        unit=unit,
                        experiment=experiment,
                        verbose=False,
                        source_of_event="self_test",
                    )
                    sleep(intensity / 100)  # let it cool down in proportion to the intensity

                    # Add to accumulating list
                    for pd_channel in pd_channels_available:
                        varying_intensity_results[pd_channel].append(avg_reading[pd_channel].reading)

                        if avg_reading[pd_channel].reading >= 2.0:
                            # we are probably going to saturate the PD - clearly we are detecting something though!
                            logger.debug(
                                f"Saw {avg_reading[pd_channel].reading:.2f} for pair pd_channel={pd_channel}, led_channel={led_channel}@intensity={intensity}. Saturation possible. No solution implemented yet! See issue #445"
                            )
            finally:
                led_intensity(
                    {led_channel: 0},
                    unit=unit,
                    experiment=experiment,
                    verbose=False,
                    source_of_event="self_test",
                )

        # compute the linear correlation between the intensities and observed PD measurements
        for pd_channel in pd_channels_available:
            measured_correlation = round(correlation(INTENSITIES, varying_intensity_results[pd_channel]), 2)
            results[(led_channel, pd_channel)] = measured_correlation
            logger.debug(f"Corr({led_channel}, {pd_channel}) = {measured_correlation}")
            logger.debug(list(zip(INTENSITIES, varying_intensity_results[pd_channel])))

        # set back to 0
        led_intensity(
            {led_channel: 0},
            unit=unit,
            experiment=experiment,
            verbose=False,
            source_of_event="self_test",
        )
        adc_reader.clear_batched_readings()

    logger.debug(f"Correlations between LEDs and PD:\n{pformat(results)}")
    detected_relationships = []
    for (led_channel, pd_channel), measured_correlation in results.items():
        if measured_correlation > 0.90:
            detected_relationships.append(
                (
                    (config["leds"].get(led_channel) or led_channel),
                    (config["od_config.photodiode_channel"].get(pd_channel) or pd_channel),
                )
            )

    managed_state.publish_setting(
        "correlations_between_pds_and_leds",
        dumps(detected_relationships),
    )

    # we require that the IR photodiodes defined in the config have a
    # correlation with the IR led
    pd_channels_to_test: list[PdChannel] = []
    for channel, angle_or_ref in config["od_config.photodiode_channel"].items():
        channel = cast(PdChannel, channel)
        pd_channels_to_test.append(channel)

    for ir_pd_channel in pd_channels_to_test:
        assert (
            results[(ir_led_channel, ir_pd_channel)] >= 0.90
        ), f"missing {ir_led_channel} ⇝ {ir_pd_channel}, correlation: {results[(ir_led_channel, ir_pd_channel)]:0.2f}"


def test_ambient_light_interference(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    # test ambient light IR interference. With all LEDs off, and the Pioreactor not in a sunny room, we should see near 0 light.
    assert is_HAT_present(), "HAT is not detected."
    pd_channels_available = list(get_available_pd_channels())
    adc_reader = ADCReader(
        channels=pd_channels_available,
        dynamic_gain=True,
        fake_data=is_testing_env(),
    )

    adc_reader.add_external_logger(logger)
    led_intensity(
        {channel: 0 for channel in ALL_LED_CHANNELS},
        unit=unit,
        source_of_event="self_test",
        experiment=experiment,
        verbose=False,
    )

    readings = adc_reader.take_reading()

    assert all(
        [readings[pd_channel].reading < 0.080 for pd_channel in pd_channels_available]
    ), f"Dark signal too high: {readings=}"  # saw a 0.072 blank during testing


def test_dark_offset_correction_is_effective(
    managed_state, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_HAT_present(), "HAT is not detected."
    pd_channels_available = list(get_available_pd_channels())
    assert pd_channels_available, "No photodiodes are configured for this Pioreactor."

    adc_reader = ADCReader(
        channels=pd_channels_available,
        dynamic_gain=True,
        fake_data=is_testing_env(),
        penalizer=0.0,
    )
    adc_reader.add_external_logger(logger)

    ir_led_channel = cast(LedChannel, config["leds_reverse"][IR_keyword])
    corrected_dark_readings_by_channel: dict[PdChannel, list[float]] = {
        pd_channel: [] for pd_channel in pd_channels_available
    }

    led_intensity(
        {channel: 0 for channel in ALL_LED_CHANNELS},
        unit=unit,
        source_of_event="self_test",
        experiment=experiment,
        verbose=False,
    )

    blank_reading = average_over_raw_pd_readings(
        adc_reader.take_reading(),
        adc_reader.take_reading(),
    )
    adc_reader.set_offsets(blank_reading)
    adc_reader.clear_batched_readings()

    with change_leds_intensities_temporarily(
        {ir_led_channel: 35.0},
        unit=unit,
        source_of_event="self_test",
        experiment=experiment,
        verbose=False,
    ):
        sleep(0.75)
        adc_reader.tune_adc_with_ir_on()
        adc_reader.take_reading()

    sleep(0.125)
    adc_reader.clear_batched_readings()

    for _ in range(8):
        reading = adc_reader.take_reading()
        for pd_channel in pd_channels_available:
            corrected_dark_readings_by_channel[pd_channel].append(reading[pd_channel].reading)

    logger.debug(f"{corrected_dark_readings_by_channel=}")

    MAX_CORRECTED_DARK_MEAN = 0.010
    MAX_CORRECTED_DARK_VARIANCE = 5e-5

    for pd_channel, corrected_dark_readings in corrected_dark_readings_by_channel.items():
        corrected_dark_mean = mean(corrected_dark_readings)
        corrected_dark_variance = variance(corrected_dark_readings)
        assert (
            corrected_dark_mean <= MAX_CORRECTED_DARK_MEAN
        ), f"Dark offset correction left pd{pd_channel} too far from baseline: {corrected_dark_readings}"
        assert (
            corrected_dark_variance <= MAX_CORRECTED_DARK_VARIANCE
        ), f"Dark offset correction for pd{pd_channel} is too noisy: {corrected_dark_readings}"


def test_REF_is_lower_than_0_dot_256_volts(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_HAT_present(), "HAT is not detected."
    pd_channels = config["od_config.photodiode_channel"]
    reference_channel = cast(PdChannel, next((k for k, v in pd_channels.items() if v == REF_keyword), None))
    assert reference_channel is not None, "REF required for this self-test"

    ir_channel = cast(LedChannel, config["leds_reverse"][IR_keyword])
    config_ir_intensity = config.get("od_reading.config", "ir_led_intensity")
    if config_ir_intensity == "auto":
        ir_intensity = 70.0  # this has been our historical default, and should generally work.
    else:
        ir_intensity = float(config_ir_intensity)

    adc_reader = ADCReader(
        channels=[reference_channel], dynamic_gain=True, fake_data=is_testing_env(), penalizer=0.0
    )
    adc_reader.add_external_logger(logger)

    with change_leds_intensities_temporarily(
        {"A": 0, "B": 0, "C": 0, "D": 0},
        unit=unit,
        source_of_event="self_test",
        experiment=experiment,
        verbose=False,
    ):
        blank_reading = adc_reader.take_reading()
        adc_reader.set_offsets(blank_reading)  # set dark offset
        adc_reader.clear_batched_readings()

    with change_leds_intensities_temporarily(
        {ir_channel: ir_intensity},
        unit=unit,
        source_of_event="self_test",
        experiment=experiment,
        verbose=False,
    ):
        samples = []

        sleep(1.0)  # let the LED warm up => more stable
        adc_reader.tune_adc_with_ir_on()  # tune under illuminated conditions

        for i in range(6):
            samples.append(adc_reader.take_reading()[reference_channel].reading)

        assert (
            0.02 < mean(samples) < 1.0
        ), f"Recorded {mean(samples):0.3f} in REF, should ideally be between 0.02 and 0.500. Current IR LED: {ir_intensity}%."

        # also check for stability: the std. of the reference should be quite low:
        assert (
            variance(samples) < 1e-2
        ), f"Too much noise in REF channel, observed {variance(samples)}. Data: {samples}."
        logger.debug(f"data: {samples}")


def test_PD_is_near_0_volts_for_blank(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_HAT_present(), "HAT is not detected."

    pd_channels = config["od_config.photodiode_channel"]
    signal_pd_channels = {k: v for k, v in pd_channels.items() if v != REF_keyword}

    for channel, angle in signal_pd_channels.items():
        channel = cast(PdChannel, channel)
        assert angle in ["90", "45", "135"], f"Angle {angle} not valid for this test."

        signals = []

        with start_od_reading(
            channels={channel: angle},
            interval=1.15,
            unit=unit,
            fake_data=is_testing_env(),
            experiment=experiment,
            calibration=False,
            estimator=False,
        ) as od_stream:
            for i, reading in enumerate(od_stream, start=1):
                signals.append(reading.ods[channel].od)

                if i == 6:
                    break

        mean_signal = mean(signals)

        threshold = {"90": 0.035, "45": 0.035, "135": 0.15}[angle]
        assert (
            mean_signal <= threshold
        ), f"Blank signal too high for pd{channel}: {mean_signal=} > {threshold}"


def test_detect_heating_pcb(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_heating_pcb_present(), "Heater PCB is not connected, or i2c is not working."


def test_positive_correlation_between_temperature_and_heating(
    managed_state: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_heating_pcb_present(), "Heater PCB is not connected, or i2c is not working."

    measured_pcb_temps = []
    dcs = list(range(0, 30, 3))

    with OnlyRecordTemperature(unit=unit, experiment=experiment) as tc:
        logger.debug("Varying heating.")
        for dc in dcs:
            tc._update_heater(dc)
            sleep(1.5)
            measured_pcb_temps.append(tc.read_external_temperature())

        tc._update_heater(0)
        measured_correlation = round(correlation(dcs, measured_pcb_temps), 2)
        logger.debug(f"Correlation between temp sensor and heating: {measured_correlation}")
        logger.debug(f"{measured_pcb_temps=}\n{dcs=}")
        assert (
            measured_correlation > 0.9
        ), f"Temp and DC% correlation was not high enough {dcs=}, {measured_pcb_temps=}"


def test_aux_power_is_not_too_high(
    client: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_HAT_present(), "HAT was not detected."
    assert voltage_in_aux() <= 18.0, f"Voltage measured {voltage_in_aux()} > 18.0V"


def test_positive_correlation_between_rpm_and_stirring(
    client: managed_lifecycle, logger: CustomLogger, unit: str, experiment: str
) -> None:
    assert is_HAT_present(), "HAT was not detected."
    assert is_heating_pcb_present(), "Heating PCB was not detected."
    assert voltage_in_aux() <= 18.0, f"Voltage measured {voltage_in_aux()} > 18.0V"

    initial_dc = config.getfloat("stirring.config", "initial_duty_cycle")

    dcs = []
    measured_rpms = []
    n_samples = 8
    start = min(initial_dc * 1.2, 100)
    end = max(initial_dc * 0.8, 5)

    rpm_calc_context = nullcontext(MockRpmCalculator()) if is_testing_env() else stirring.RpmFromFrequency()
    with rpm_calc_context as rpm_calc:
        rpm_calc.setup()
        with stirring.Stirrer(
            target_rpm=None,
            unit=unit,
            experiment=experiment,
            rpm_calculator=None,
            calibration=False,
            enable_dodging_od=False,
        ) as st:
            st.set_duty_cycle(initial_dc)
            sleep(0.75)

            for i in range(n_samples):
                p = i / n_samples
                dc = start * (1 - p) + p * end

                st.set_duty_cycle(dc)
                sleep(0.75)
                measured_rpms.append(rpm_calc.estimate(3.0))
                dcs.append(dc)

        measured_correlation = round(correlation(dcs, measured_rpms), 2)
        logger.debug(f"Correlation between stirring RPM and duty cycle: {measured_correlation}")
        logger.debug(f"{dcs=}, {measured_rpms=}")
        assert measured_correlation > 0.9, f"RPM correlation not high enough: {(dcs, measured_rpms)}"


def run_tests(
    tests_to_run: list[SelfTest],
    managed_state: managed_lifecycle,
    logger: CustomLogger,
    unit: str,
    testing_experiment: str,
) -> SummableDict:
    count_tested = 0
    count_passed = 0
    failed_tests: list[str] = []

    for test in tests_to_run:
        if managed_state.exit_event.is_set():
            logger.info("Self-test interrupted, stopping remaining tests.")
            break

        test_name = test.__name__

        success = True
        logger.debug(f"Starting test {test_name}...")
        try:
            with timeout_self_test(test_name, SELF_TEST_TIMEOUT_SECONDS):
                test(managed_state, logger, unit, testing_experiment)
        except SelfTestTimedOut as e:
            success = False
            logger.warning(str(e))
        except Exception as e:
            success = False
            logger.debug(e, exc_info=True)
            logger.warning(f"{test_name.replace('_', ' ')}: {e}")

        logger.debug(f"{test_name}: {'✅' if success else '❌'}")

        count_tested += 1
        count_passed += int(success)
        if not success:
            failed_tests.append(test_name)

        managed_state.publish_setting(test_name, int(success))

        with local_persistent_storage("self_test_results") as c:
            c[test_name] = int(success)

    return SummableDict(
        {
            "count_tested": count_tested,
            "count_passed": count_passed,
            "failed_tests": failed_tests,
        }
    )


def get_failed_test_names() -> Iterator[str]:
    with local_persistent_storage("self_test_results") as c:
        for name in get_all_test_names():
            if c.get(name) == 0:
                yield name


def get_all_tests() -> list[SelfTest]:
    _ensure_plugin_self_tests_registered()
    return get_builtin_self_tests() + list(REGISTERED_SELF_TESTS)


def get_all_test_names() -> Iterator[str]:
    return (test.__name__ for test in get_all_tests())


@click.command(name="self_test")
@click.option("-k", help="see pytest's -k argument", type=str)
@click.option("--retry-failed", is_flag=True, help="retry only previous failed tests", type=str)
def click_self_test(k: str | None, retry_failed: bool) -> int:
    """
    Test the input/output in the Pioreactor
    """
    unit = get_unit_name()
    testing_experiment = UNIVERSAL_EXPERIMENT
    logger = create_logger("self_test", unit=unit, experiment=testing_experiment)

    with managed_lifecycle(unit, testing_experiment, "self_test") as managed_state:
        if any(
            is_pio_job_running(
                ["od_reading", "temperature_automation", "stirring", "dosing_automation", "led_automation"]
            )
        ):
            logger.error(
                "Make sure Optical Density, any automations, and Stirring are off before running a self test. Exiting."
            )
            raise click.Abort()

        tests_to_run: list[SelfTest]
        if retry_failed:
            failed_test_name_set = set(get_failed_test_names())
            tests_to_run = [test for test in get_all_tests() if test.__name__ in failed_test_name_set]
        else:
            tests_to_run = get_all_tests()

        if k:
            tests_to_run = [test for test in tests_to_run if k in test.__name__]

        logger.info(f"Starting self-test. Running {len(tests_to_run)} tests.")

        # and clear the mqtt cache first
        for test in tests_to_run:
            managed_state.publish_setting(test.__name__, None)

        try:
            results = run_tests(tests_to_run, managed_state, logger, unit, testing_experiment)
        except KeyboardInterrupt:
            logger.info("Self-test interrupted, waiting for cleanup.")
            raise click.Abort()

        if managed_state.exit_event.is_set():
            logger.info("Self-test interrupted.")
            raise click.Abort()

        count_tested, count_passed = results["count_tested"], results["count_passed"]
        count_failures = int(count_tested - count_passed)

        managed_state.publish_setting("all_tests_passed", int(count_failures == 0))

        if count_tested == 0:
            logger.info("No tests ran 🟡")
        elif count_failures == 0:
            logger.info("All tests passed ✅")
        elif count_failures > 0:
            logger.info(f"{count_failures} failed test{'s' if count_failures > 1 else ''} ❌")
            failed_test_names = cast(list[str], results["failed_tests"])
            failed_tests = "\n      ".join(f"{test_name}" for test_name in failed_test_names)
            logger.debug(f"Failed tests:\n      {failed_tests}")

        return int(count_failures > 0)
