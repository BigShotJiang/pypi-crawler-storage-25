"""
cryptofinance.ticker
~~~~~~~~~~~~~~~~~~~~
The Ticker class — a single-asset wrapper that bundles all data
functions into one clean interface, similar to yfinance's Ticker.
"""

import pandas as pd

from .utils.get_price import get_price
from .utils.get_history import get_history
from .utils.get_market_cap import get_market_cap
from .utils.get_volume import get_volume
from .utils.get_info import get_info
from .utils.get_dominance import get_dominance
from .utils.get_funding_rate import get_funding_rate
from .utils.get_open_interest import get_open_interest
from .utils.get_long_short import get_long_short_ratio
from .utils.get_onchain import get_onchain
from .utils.get_news import get_news
from .utils.get_technicals import get_technicals
from .utils.plot_price import plot_price


class Ticker:
    """Single-asset data wrapper for crypto.

    Parameters
    ----------
    symbol : asset pair in ``BASE_QUOTE`` format, e.g. ``'BTC_USD'``, ``'ETH_USDT'``

    Examples
    --------
    >>> from cryptofinance import Ticker
    >>> t = Ticker('BTC_USD')
    >>> t.history(days=30)
    >>> t.info
    >>> t.funding_rate
    >>> t.onchain
    >>> t.plot()
    """

    def __init__(self, symbol: str):
        self._symbol = symbol.strip().lower()
        self._cache: dict = {}

    # ── Internals ─────────────────────────────────────────────────────────

    def _cached(self, key: str, fn):
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    @property
    def symbol(self) -> str:
        return self._symbol

    # ── Price & OHLCV ─────────────────────────────────────────────────────

    @property
    def price(self) -> float:
        """Current spot price."""
        return get_price(self._symbol)

    def history(self, days: int = 30, interval: str = "daily") -> pd.DataFrame:
        """OHLCV history.

        Parameters
        ----------
        days     : lookback (default 30)
        interval : ``'daily'``, ``'hourly'``, ``'4h'``, ``'15m'``, ``'5m'``, ``'1m'``
        """
        return get_history(self._symbol, days=days, interval=interval)

    @property
    def fast_info(self) -> dict:
        """Quick snapshot — price, market cap, 24h change.

        Faster than ``.info`` because it only calls the price endpoint.
        """
        def _build():
            info = get_info(self._symbol)
            return {
                "symbol": self._symbol.upper(),
                "price": info.get("current_price"),
                "market_cap": info.get("market_cap"),
                "volume_24h": info.get("total_volume_24h"),
                "change_24h_pct": info.get("price_change_pct_24h"),
                "change_7d_pct": info.get("price_change_pct_7d"),
                "rank": info.get("rank"),
                "ath": info.get("ath"),
                "ath_change_pct": info.get("ath_change_pct"),
            }
        return self._cached("fast_info", _build)

    # ── Fundamental ───────────────────────────────────────────────────────

    @property
    def info(self) -> dict:
        """Full coin profile: description, links, ATH, social stats, dev activity."""
        return self._cached("info", lambda: get_info(self._symbol))

    @property
    def market_cap(self) -> pd.DataFrame:
        """Historical market cap (30 days by default)."""
        return get_market_cap(self._symbol)

    @property
    def volume(self) -> pd.DataFrame:
        """Historical trading volume (30 days by default)."""
        return get_volume(self._symbol)

    @property
    def dominance(self) -> float | None:
        """This asset's share of the total crypto market cap (%)."""
        d = get_dominance()
        base = self._symbol.split("_")[0].upper()
        return d.get(base)

    # ── Derivatives ───────────────────────────────────────────────────────

    @property
    def funding_rate(self) -> pd.DataFrame:
        """Historical 8-hour funding rates for the perpetual futures contract.

        Requires an active Binance USDT-margined perp for this asset.
        """
        return get_funding_rate(self._symbol)

    @property
    def open_interest(self) -> pd.DataFrame:
        """Historical open interest for the perpetual futures contract."""
        return get_open_interest(self._symbol)

    @property
    def long_short_ratio(self) -> pd.DataFrame:
        """Global long/short account ratio from Binance Futures."""
        return get_long_short_ratio(self._symbol)

    # ── On-chain ──────────────────────────────────────────────────────────

    @property
    def onchain(self) -> pd.DataFrame:
        """On-chain metrics: active addresses, tx count, NVT, hash rate, etc.

        Data from the CoinMetrics Community API (free tier).
        Not available for every asset — see ``get_onchain()`` docs.
        """
        base = self._symbol.split("_")[0]
        return self._cached("onchain", lambda: get_onchain(base))

    # ── Sentiment ─────────────────────────────────────────────────────────

    @property
    def news(self) -> list:
        """Recent news articles for this asset (via Messari)."""
        return get_news(self._symbol)

    # ── Technical Analysis ────────────────────────────────────────────────

    def technicals(self, days: int = 90) -> pd.DataFrame:
        """OHLCV + RSI, MACD, Bollinger Bands, EMA, ATR, OBV.

        Requires ``pip install pandas-ta``.
        """
        return get_technicals(self._symbol, days=days)

    # ── Plotting ──────────────────────────────────────────────────────────

    def plot(self, days: int = 30, interval: str = "daily",
             show_volume: bool = True, show_rsi: bool = True) -> None:
        """Candlestick + volume + RSI chart. Opens in browser or Jupyter."""
        plot_price(self._symbol, days=days, interval=interval,
                   show_volume=show_volume, show_rsi=show_rsi)

    # ── Dunder ────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"Ticker('{self._symbol}')"

    def __str__(self) -> str:
        try:
            p = get_price(self._symbol)
            return f"{self._symbol.upper()}  |  ${p:,.4f}"
        except Exception:
            return f"Ticker('{self._symbol}')"
