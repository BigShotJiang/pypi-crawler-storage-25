import requests
import pandas as pd
from .cache import ttl_cache

_CM_BASE = "https://community-api.coinmetrics.io/v4"

# Mapping from our ticker format to CoinMetrics asset IDs
_CM_ASSET_MAP = {
    "BTC": "btc", "ETH": "eth", "LTC": "ltc", "BCH": "bch",
    "XRP": "xrp", "ADA": "ada", "DOT": "dot", "SOL": "sol",
    "DOGE": "doge", "LINK": "link", "XLM": "xlm", "ATOM": "atom",
    "AVAX": "avax", "MATIC": "matic", "UNI": "uni", "AAVE": "aave",
    "NEAR": "near", "FIL": "fil",
}

# Available in the CoinMetrics community (free) tier
_METRICS = [
    "AdrActCnt",       # Active addresses
    "TxCnt",           # Transaction count
    "TxTfrValAdjUSD",  # Adjusted transfer volume (USD)
    "NVTAdj",          # NVT ratio — network value to transactions (like P/E for crypto)
    "HashRate",        # Hash rate (PoW chains only)
    "FeeMeanNtv",      # Mean transaction fee in native units
    "BlkCnt",          # Block count
]


@ttl_cache(ttl=3600)
def get_onchain(symbol: str, days: int = 90) -> pd.DataFrame:
    """Return on-chain metrics for a crypto asset via the CoinMetrics Community API.

    This is institutional-grade on-chain data, available for free.

    Parameters
    ----------
    symbol : ticker, e.g. ``'BTC'`` or ``'BTC_USD'``
    days   : how many days of history (default 90)

    Returns
    -------
    DataFrame with columns: timestamp, active_addresses, tx_count,
    transfer_volume_usd, nvt_ratio, hash_rate, mean_fee_native, block_count

    Notes
    -----
    Not all metrics are available for every asset. Missing values will be NaN.
    ``nvt_ratio`` is the crypto equivalent of a P/E ratio — high values suggest
    the network's value isn't being justified by actual on-chain activity.
    ``hash_rate`` is only available for proof-of-work chains (BTC, LTC, etc.).
    """
    base = symbol.upper().split("_")[0]
    asset = _CM_ASSET_MAP.get(base, base.lower())

    import datetime
    start = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()

    resp = requests.get(
        f"{_CM_BASE}/timeseries/asset-metrics",
        params={
            "assets": asset,
            "metrics": ",".join(_METRICS),
            "start_time": start,
            "frequency": "1d",
            "page_size": days + 5,
        },
        timeout=15,
    )

    if resp.status_code == 404:
        raise ValueError(f"On-chain data not available for '{symbol}' in the CoinMetrics community tier.")

    resp.raise_for_status()
    data = resp.json().get("data", [])

    if not data:
        raise ValueError(f"No on-chain data returned for '{symbol}'.")

    rows = []
    for entry in data:
        rows.append({
            "timestamp": pd.to_datetime(entry.get("time")),
            "active_addresses": _safe_float(entry.get("AdrActCnt")),
            "tx_count": _safe_float(entry.get("TxCnt")),
            "transfer_volume_usd": _safe_float(entry.get("TxTfrValAdjUSD")),
            "nvt_ratio": _safe_float(entry.get("NVTAdj")),
            "hash_rate": _safe_float(entry.get("HashRate")),
            "mean_fee_native": _safe_float(entry.get("FeeMeanNtv")),
            "block_count": _safe_float(entry.get("BlkCnt")),
        })

    return pd.DataFrame(rows).sort_values("timestamp").reset_index(drop=True)


def _safe_float(val):
    try:
        return float(val)
    except (TypeError, ValueError):
        return float("nan")
