import ccxt
import pandas as pd
from pycoingecko import CoinGeckoAPI

from .coingecko_resolver import resolve_cg_id
from .cache import ttl_cache

_TF_MAP = {"daily": "1d", "hourly": "1h", "4h": "4h", "15m": "15m", "5m": "5m", "1m": "1m"}


def _binance_ohlcv(base: str, quote: str, interval: str, limit: int) -> pd.DataFrame:
    """Fetch real OHLCV from Binance via CCXT."""
    q = "USDT" if quote.upper() == "USD" else quote.upper()
    pair = f"{base.upper()}/{q}"
    tf = _TF_MAP.get(interval, "1d")
    ex = ccxt.binance()
    ohlcv = ex.fetch_ohlcv(pair, timeframe=tf, limit=limit)
    df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
    return df


def _coingecko_ohlcv(base: str, quote: str, days: int, interval: str) -> pd.DataFrame:
    """Fetch OHLCV from CoinGecko's dedicated OHLC endpoint (real candles, not fake)."""
    cg = CoinGeckoAPI()
    cg_id = resolve_cg_id(base.upper())

    # CoinGecko's get_coin_ohlc_by_id returns real open/high/low/close candles.
    # Supported days: 1, 7, 14, 30, 90, 180, 365, max
    supported = [1, 7, 14, 30, 90, 180, 365]
    d = min(supported, key=lambda x: abs(x - days)) if days not in supported else days

    ohlc = cg.get_coin_ohlc_by_id(id=cg_id, vs_currency=quote, days=d)
    df = pd.DataFrame(ohlc, columns=["timestamp", "open", "high", "low", "close"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")

    # CoinGecko OHLC doesn't include volume — pull it separately and merge
    try:
        cg_interval = "hourly" if interval == "hourly" else "daily"
        chart = cg.get_coin_market_chart_by_id(
            id=cg_id, vs_currency=quote, days=days, interval=cg_interval
        )
        vol_df = pd.DataFrame(chart["total_volumes"], columns=["timestamp", "volume"])
        vol_df["timestamp"] = pd.to_datetime(vol_df["timestamp"], unit="ms")
        vol_df["timestamp"] = vol_df["timestamp"].dt.floor("h")
        df["timestamp"] = df["timestamp"].dt.floor("h")
        df = pd.merge_asof(df.sort_values("timestamp"), vol_df.sort_values("timestamp"), on="timestamp")
    except Exception:
        df["volume"] = float("nan")

    return df[["timestamp", "open", "high", "low", "close", "volume"]]


@ttl_cache(ttl=300)
def get_history(symbol: str, days: int = 30, interval: str = "daily") -> pd.DataFrame:
    """Return OHLCV history for a crypto asset.

    Parameters
    ----------
    symbol   : e.g. ``'BTC_USD'``, ``'ETH_USDT'``
    days     : number of days of history to fetch (default 30)
    interval : ``'daily'``, ``'hourly'``, ``'4h'``, ``'15m'``, ``'5m'``, ``'1m'``

    Returns
    -------
    DataFrame with columns: timestamp, open, high, low, close, volume
    """
    base, quote = symbol.lower().split("_")

    # Binance is primary — it has real OHLCV and supports every interval
    try:
        return _binance_ohlcv(base, quote, interval, limit=days)
    except Exception:
        pass

    # CoinGecko fallback — uses their real OHLC endpoint (not fake price-only data)
    try:
        return _coingecko_ohlcv(base, quote, days, interval)
    except Exception:
        pass

    # Last resort: try other CCXT exchanges
    for exchange_cls in (ccxt.coinbase, ccxt.kraken, ccxt.okx):
        try:
            q = "USDT" if quote.upper() == "USD" else quote.upper()
            pair = f"{base.upper()}/{q}"
            tf = _TF_MAP.get(interval, "1d")
            ex = exchange_cls()
            ohlcv = ex.fetch_ohlcv(pair, timeframe=tf, limit=days)
            df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            return df
        except Exception:
            continue

    raise ValueError(
        f"Could not fetch history for '{symbol}'. "
        "Check the symbol format (e.g. 'BTC_USD') and your internet connection."
    )
