import requests
from .cache import ttl_cache


@ttl_cache(ttl=900)
def get_news(symbol: str, limit: int = 10) -> list:
    """Return recent news articles for a crypto asset.

    Uses the Messari free API — no API key required.

    Parameters
    ----------
    symbol : ticker, e.g. ``'BTC'`` or ``'BTC_USD'``
    limit  : number of articles to return (default 10)

    Returns
    -------
    list of dicts, each with: title, published_at, author, url, tags
    """
    base = symbol.lower().split("_")[0]
    url = f"https://data.messari.io/api/v1/news/{base}"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        articles = resp.json().get("data", [])
    except Exception as e:
        raise ValueError(f"News fetch failed for '{symbol}': {e}")

    out = []
    for a in articles[:limit]:
        out.append({
            "title": a.get("title"),
            "published_at": a.get("published_at"),
            "author": a.get("author", {}).get("name"),
            "url": a.get("url"),
            "tags": [t.get("name") for t in a.get("tags", [])],
        })
    return out
