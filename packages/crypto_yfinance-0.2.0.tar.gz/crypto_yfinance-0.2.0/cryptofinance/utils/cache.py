import time
from functools import wraps


_STORE: dict = {}


def ttl_cache(ttl: int = 60):
    """Decorator that caches function results for `ttl` seconds.

    Avoids hammering APIs when the same call is made multiple times
    in one script or notebook session.
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            key = (fn.__qualname__, args, tuple(sorted(kwargs.items())))
            now = time.monotonic()
            if key in _STORE:
                val, ts = _STORE[key]
                if now - ts < ttl:
                    return val
            val = fn(*args, **kwargs)
            _STORE[key] = (val, now)
            return val
        return wrapper
    return decorator


def clear_cache():
    """Wipe the in-memory cache manually if you need fresh data mid-session."""
    _STORE.clear()
