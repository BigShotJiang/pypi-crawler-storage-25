"""Telegram slash-command handlers: /start, /new, /backend, /model, /sessions, /help, /status, /history, /memory, /project."""
import logging
import uuid
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import selectinload
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from opspilot.channels.config import MODELS_BY_AGENT, SYSTEM_PROMPT_PRESETS as SYSTEM_PROMPTS
from opspilot.channels.telegram.handlers.message import _get_default_project_id, get_or_create_topic
from opspilot.channels.telegram.handlers.utils import build_mcp_keyboard, build_mcp_wizard_keyboard, build_memory_wizard_keyboard, build_repo_wizard_keyboard, error_reply
from opspilot.config import settings
from opspilot.database import async_session_factory
from opspilot.models import AgentType, Conversation, ConversationMcpServer, McpServer, MemoryFile, Project, TelegramTopic
from opspilot.models.conversations import ConversationGitRepo, ConversationMessage
from opspilot.models.integrations import GitRepo
from opspilot.services.conversation_service import get_channel_agent_defaults
from opspilot.services.mcp_service import get_default_mcp_ids

logger = logging.getLogger(__name__)

_VALID_AGENT_TYPES = {a.value for a in AgentType}

_AGENT_EMOJI = {
    AgentType.CLAUDE_CODE.value: "🤖",
    AgentType.CODEX.value: "💡",
    AgentType.GEMINI.value: "✨",
}

HELP_TEXT = """
*OpsPilot Bot Commands*

/start — Welcome message
/project — Setup wizard \\(project, agent, model, MCP, memory, repos\\)
/new — Start a new conversation \\(opens setup wizard\\)
/cancel — Stop the currently running agent \\(also: /esc\\)
/backend \\<type\\> — Switch agent backend \\(claude\\-code \\| codex \\| gemini\\)
/model \\[model\\] — Show or set the LLM model for this conversation
/mcp — Toggle MCP servers for this conversation
/memory — Toggle memory files for this conversation
/repos — Toggle git repositories for this conversation
/prompt — Select system prompt preset
/sessions — Browse and resume recent agent sessions
/history \\[N\\] — Show last N messages \\(default 10\\)
/status — Show current conversation info
/help — Show this message
""".strip()


async def _build_telegram_conversation(
    db,
    chat_id: int,
    thread_id: int | None,
    agent_type: AgentType,
    project_id: UUID,
) -> Conversation:
    """Create a Conversation with MCP servers and project git repos attached. Caller owns the DB session/transaction."""
    defaults = await get_channel_agent_defaults(db, project_id)
    effective_prompt = defaults.get("system_prompt") or settings.telegram_default_system_prompt
    agent_settings: dict = {"telegram_chat_id": chat_id}
    if defaults.get("model"):
        agent_settings["model"] = defaults["model"]

    conv = Conversation(
        project_id=project_id,
        title=f"Telegram {chat_id}/{thread_id or 'dm'}",
        agent_type=agent_type,
        system_prompt=effective_prompt,
        agent_settings=agent_settings,
        pre_run_context={"inject_skills": True, "inject_memories": True, "memory_injection_limit": 10},
    )
    db.add(conv)
    await db.flush()

    default_mcp_ids = [UUID(mid) for mid in defaults.get("mcp_server_ids", [])]
    mcp_ids = default_mcp_ids if default_mcp_ids else await get_default_mcp_ids(db)
    for mid in mcp_ids:
        await db.execute(
            pg_insert(ConversationMcpServer)
            .values(conversation_id=conv.id, mcp_server_id=mid)
            .on_conflict_do_nothing()
        )

    default_git_ids = [UUID(rid) for rid in defaults.get("git_repo_ids", [])]
    if default_git_ids:
        for rid in default_git_ids:
            await db.execute(
                pg_insert(ConversationGitRepo)
                .values(conversation_id=conv.id, git_repo_id=rid)
                .on_conflict_do_nothing()
            )
    else:
        project_repos = (await db.execute(
            select(GitRepo).where(GitRepo.project_id == project_id).order_by(GitRepo.name)
        )).scalars().all()
        for repo in project_repos:
            await db.execute(
                pg_insert(ConversationGitRepo)
                .values(conversation_id=conv.id, git_repo_id=repo.id)
                .on_conflict_do_nothing()
            )

    return conv


@error_reply
async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        project_id = await _get_default_project_id(db)
    await get_or_create_topic(chat_id, thread_id, project_id=project_id)

    await update.message.reply_text(
        "👋 *OpsPilot is ready\\!*\n\nSend me a message and I'll get your DevOps task done\\.",
        parse_mode="MarkdownV2",
        message_thread_id=thread_id,
    )


@error_reply
async def new_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start new conversation via the setup wizard (same as /project)."""
    await project_handler(update, context)


@error_reply
async def backend_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Switch agent backend for this topic."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    args = context.args or []
    if not args or args[0] not in _VALID_AGENT_TYPES:
        valid = " | ".join(sorted(_VALID_AGENT_TYPES))
        await update.message.reply_text(
            f"Usage: /backend <type>\nValid types: {valid}",
            message_thread_id=thread_id,
        )
        return

    try:
        new_agent_type = AgentType(args[0])
    except ValueError:
        valid = " | ".join(sorted(_VALID_AGENT_TYPES))
        await update.message.reply_text(
            f"Usage: /backend <type>\nValid types: {valid}",
            message_thread_id=thread_id,
        )
        return

    async with async_session_factory() as db:
        stmt = select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
        result = await db.execute(stmt)
        topic = result.scalar_one_or_none()

        project_id = topic.project_id if topic else await _get_default_project_id(db)

        # Always start a fresh conversation when switching backends —
        # mixing messages from different agents in one thread is confusing.
        new_conv = await _build_telegram_conversation(db, chat_id, thread_id, new_agent_type, project_id)

        if not topic:
            topic = TelegramTopic(
                project_id=project_id,
                chat_id=chat_id,
                topic_id=thread_id,
                conversation_id=new_conv.id,
                agent_type=new_agent_type,
            )
            db.add(topic)
        else:
            topic.agent_type = new_agent_type
            topic.conversation_id = new_conv.id

        await db.commit()
        conv_id = str(new_conv.id)

    logger.info(
        "telegram_backend_switched chat_id=%s thread_id=%s agent_type=%s conversation_id=%s",
        chat_id, thread_id, new_agent_type.value, conv_id,
    )
    await update.message.reply_text(
        f"✅ Backend switched to *{new_agent_type.value}* \\— new conversation started\\.",
        parse_mode="MarkdownV2",
        message_thread_id=thread_id,
    )


@error_reply
async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    thread_id = update.message.message_thread_id
    await update.message.reply_text(HELP_TEXT, parse_mode="MarkdownV2", message_thread_id=thread_id)


@error_reply
async def status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show detailed status for the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(
                selectinload(Conversation.mcp_servers),
                selectinload(Conversation.memory_files),
                selectinload(Conversation.git_repos),
            )
        )).scalar_one_or_none()

        if not conv:
            await update.message.reply_text("Conversation not found.", message_thread_id=thread_id)
            return

        proj = (await db.execute(
            select(Project).where(Project.id == conv.project_id)
        )).scalar_one_or_none()

        msg_count = (await db.execute(
            select(func.count()).select_from(ConversationMessage).where(
                ConversationMessage.conversation_id == conv.id
            )
        )).scalar() or 0

    model = (conv.agent_settings or {}).get("model", "Default") or "Default"
    prompt_preview = (conv.system_prompt or "")[:80]
    if len(conv.system_prompt or "") > 80:
        prompt_preview += "..."
    mcp_names = ", ".join(s.name for s in conv.mcp_servers) if conv.mcp_servers else "None"
    mem_names = ", ".join(mf.name for mf in conv.memory_files) if conv.memory_files else "None"
    repo_names = ", ".join(r.name for r in conv.git_repos) if conv.git_repos else "None"

    status_text = (
        f"Status\n\n"
        f"Project: {proj.name if proj else 'Unknown'}\n"
        f"Agent: {conv.agent_type.value}\n"
        f"Model: {model}\n"
        f'System prompt: "{prompt_preview}"\n'
        f"MCP servers: {mcp_names}\n"
        f"Memory files: {mem_names}\n"
        f"Git repos: {repo_names}\n"
        f"Messages: {msg_count}\n"
        f"Input tokens: {conv.total_input_tokens:,}\n"
        f"Output tokens: {conv.total_output_tokens:,}\n"
        f"Cost: ${conv.total_cost_usd:.4f}"
    )
    await update.message.reply_text(status_text, message_thread_id=thread_id)


@error_reply
async def model_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show or set the LLM model for the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        stmt = select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
        result = await db.execute(stmt)
        topic = result.scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        conv_stmt = select(Conversation).where(Conversation.id == topic.conversation_id)
        conv_result = await db.execute(conv_stmt)
        conv = conv_result.scalar_one_or_none()

        if not conv:
            await update.message.reply_text("Conversation not found.", message_thread_id=thread_id)
            return

        agent_type = conv.agent_type.value
        valid_models = MODELS_BY_AGENT.get(agent_type, [])
        current_model = (conv.agent_settings or {}).get("model", "")

        args = context.args or []
        if args:
            # Direct set: /model <model_id>
            requested = args[0]
            valid_ids = [m for m, _ in valid_models]
            if requested not in valid_ids:
                valid_list = "\n".join(f"• {m}" for m, _ in valid_models)
                await update.message.reply_text(
                    f"Invalid model '{requested}' for {agent_type}.\nValid options:\n{valid_list}",
                    message_thread_id=thread_id,
                )
                return

            settings_dict = dict(conv.agent_settings or {})
            settings_dict["model"] = requested
            conv.agent_settings = settings_dict
            await db.commit()

            logger.info(
                "telegram_model_set chat_id=%s conversation_id=%s model=%s",
                chat_id, conv.id, requested,
            )
            await update.message.reply_text(
                f"✅ Model set to {requested}", message_thread_id=thread_id
            )
            return

    # No args — show inline keyboard
    if not valid_models:
        await update.message.reply_text(
            f"No model options configured for {agent_type}.", message_thread_id=thread_id
        )
        return

    keyboard = []
    for model_id, label in valid_models:
        prefix = "✓ " if model_id == current_model else ""
        keyboard.append([
            InlineKeyboardButton(
                f"{prefix}{model_id} — {label}", callback_data=f"model_sel:{model_id}"
            )
        ])

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        f"Select model for {agent_type}:",
        reply_markup=reply_markup,
        message_thread_id=thread_id,
    )


@error_reply
async def sessions_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Browse and resume recent agent-native sessions."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        topic_stmt = select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
        topic_result = await db.execute(topic_stmt)
        topic = topic_result.scalar_one_or_none()
        current_conv_id = topic.conversation_id if topic else None

        conv_stmt = (
            select(Conversation)
            .where(
                Conversation.agent_native_session_id.isnot(None),
                Conversation.agent_settings["telegram_chat_id"].as_integer() == chat_id,
            )
            .order_by(Conversation.updated_at.desc())
            .limit(10)
        )
        conv_result = await db.execute(conv_stmt)
        conversations = conv_result.scalars().all()

    if not conversations:
        await update.message.reply_text("No resumable sessions yet.", message_thread_id=thread_id)
        return

    keyboard = []
    for conv in conversations:
        emoji = _AGENT_EMOJI.get(conv.agent_type.value, "🔧")
        title = (conv.title or "Untitled")[:28]
        native_id = (conv.agent_native_session_id or "")[:8]
        date_str = conv.updated_at.strftime("%b %d") if conv.updated_at else ""
        is_current = current_conv_id and conv.id == current_conv_id
        prefix = "✓ " if is_current else ""
        label = f"{prefix}{emoji} {title} • {native_id}… • {date_str}"
        keyboard.append([InlineKeyboardButton(label, callback_data=f"session_sel:{conv.id}")])

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "Pick a session to resume (last 10):",
        reply_markup=reply_markup,
        message_thread_id=thread_id,
    )


@error_reply
async def cancel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Stop the currently running agent turn for this conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

    if not topic:
        await update.message.reply_text("No active conversation.", message_thread_id=thread_id)
        return

    from opspilot.channels.telegram.handlers.message import cancel_active_task
    cancelled = cancel_active_task(str(topic.conversation_id))

    if cancelled:
        logger.info(
            "telegram_cancel_requested chat_id=%s conversation_id=%s",
            chat_id, topic.conversation_id,
        )
        await update.message.reply_text("🛑 Stopping agent…", message_thread_id=thread_id)
    else:
        await update.message.reply_text("No agent is currently running.", message_thread_id=thread_id)


@error_reply
async def mcp_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show and toggle MCP servers for the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    keyboard = None
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.mcp_servers))
        )).scalar_one_or_none()

        if not conv:
            await update.message.reply_text(
                "Conversation not found.", message_thread_id=thread_id
            )
            return

        all_servers = (await db.execute(
            select(McpServer).order_by(McpServer.name)
        )).scalars().all()

        if not all_servers:
            await update.message.reply_text(
                "No MCP servers configured.", message_thread_id=thread_id
            )
            return

        attached_ids = {s.id for s in conv.mcp_servers}
        keyboard = build_mcp_keyboard(all_servers, attached_ids)

    await update.message.reply_text(
        "Toggle MCP servers for this conversation:",
        reply_markup=keyboard,
        message_thread_id=thread_id,
    )


@error_reply
async def prompt_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show system prompt preset picker for the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    current_prompt = ""
    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        conv = (await db.execute(
            select(Conversation).where(Conversation.id == topic.conversation_id)
        )).scalar_one_or_none()

        if not conv:
            await update.message.reply_text(
                "Conversation not found.", message_thread_id=thread_id
            )
            return

        current_prompt = conv.system_prompt or ""

    keyboard = []
    for key, label, value in SYSTEM_PROMPTS:
        prefix = "✓ " if current_prompt.strip() == value.strip() else "  "
        keyboard.append([InlineKeyboardButton(f"{prefix}{label}", callback_data=f"prompt_sel:{key}")])

    await update.message.reply_text(
        "Select system prompt:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        message_thread_id=thread_id,
    )


@error_reply
async def memory_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show and toggle memory files for the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.memory_files))
        )).scalar_one_or_none()

        if not conv:
            await update.message.reply_text(
                "Conversation not found.", message_thread_id=thread_id
            )
            return

        all_files = (await db.execute(
            select(MemoryFile).order_by(MemoryFile.name)
        )).scalars().all()

        if not all_files:
            await update.message.reply_text(
                "No memory files defined. Create some at the OpsPilot UI.",
                message_thread_id=thread_id,
            )
            return

        attached_ids = {mf.id for mf in conv.memory_files}
        keyboard = []
        for mf in all_files:
            prefix = "✓ " if mf.id in attached_ids else "  "
            keyboard.append([
                InlineKeyboardButton(
                    f"{prefix}{mf.name} [{mf.destination}]",
                    callback_data=f"memory_tog:{mf.id}",
                )
            ])

    await update.message.reply_text(
        "Toggle memory files for this conversation:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        message_thread_id=thread_id,
    )


@error_reply
async def repos_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show and toggle git repositories for the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        conv = (await db.execute(
            select(Conversation)
            .where(Conversation.id == topic.conversation_id)
            .options(selectinload(Conversation.git_repos))
        )).scalar_one_or_none()

        if not conv:
            await update.message.reply_text("Conversation not found.", message_thread_id=thread_id)
            return

        all_repos = (await db.execute(
            select(GitRepo)
            .where(GitRepo.project_id == conv.project_id)
            .order_by(GitRepo.name)
        )).scalars().all()

        if not all_repos:
            await update.message.reply_text(
                "No git repositories configured for this project.",
                message_thread_id=thread_id,
            )
            return

        attached_ids = {r.id for r in conv.git_repos}
        keyboard = []
        for repo in all_repos:
            prefix = "✓ " if repo.id in attached_ids else "  "
            keyboard.append([
                InlineKeyboardButton(
                    f"{prefix}{repo.name} [{repo.branch}]",
                    callback_data=f"repo_tog:{repo.id}",
                )
            ])

    await update.message.reply_text(
        "Toggle git repositories for this conversation:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        message_thread_id=thread_id,
    )


@error_reply
async def history_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show last N messages from the current conversation."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    args = context.args or []
    limit = min(int(args[0]), 20) if args and args[0].isdigit() else 10

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()

        if not topic:
            await update.message.reply_text(
                "No active conversation. Send a message to start one.",
                message_thread_id=thread_id,
            )
            return

        messages = (await db.execute(
            select(ConversationMessage)
            .where(ConversationMessage.conversation_id == topic.conversation_id)
            .order_by(ConversationMessage.sequence.desc())
            .limit(limit)
        )).scalars().all()

    if not messages:
        await update.message.reply_text("No messages yet.", message_thread_id=thread_id)
        return

    role_icons = {"user": "👤", "assistant": "🤖", "system": "⚙️"}
    lines = []
    for msg in reversed(messages):
        role_str = msg.role.value if hasattr(msg.role, "value") else str(msg.role)
        icon = role_icons.get(role_str, "💬")
        content = msg.content[:200] + "..." if len(msg.content) > 200 else msg.content
        # Replace newlines with spaces for compact display
        content = content.replace("\n", " ")
        lines.append(f"{icon} {content}")

    text = "\n\n".join(lines)
    # Truncate total to fit Telegram's 4096 char limit
    if len(text) > 4000:
        text = text[:4000] + "\n\n... (truncated)"

    await update.message.reply_text(text, message_thread_id=thread_id)


@error_reply
async def project_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show project/agent/model setup wizard — Step 1: pick project."""
    if not update.message or not update.effective_chat:
        return
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return
    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id
    logger.info("telegram_cmd_project chat_id=%s thread_id=%s", chat_id, thread_id)

    async with async_session_factory() as db:
        topic = (await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )).scalar_one_or_none()
        current_project_id = topic.project_id if topic else None

        projects = (await db.execute(
            select(Project).order_by(Project.name)
        )).scalars().all()

    logger.info(
        "telegram_project_picker chat_id=%s thread_id=%s projects=%s current_project_id=%s",
        chat_id, thread_id, [p.name for p in projects], current_project_id,
    )

    if not projects:
        await update.message.reply_text("❌ No projects found.", message_thread_id=thread_id)
        return

    keyboard = []
    row = []
    for proj in projects:
        prefix = "✅ " if current_project_id and proj.id == current_project_id else ""
        btn = InlineKeyboardButton(
            f"{prefix}{proj.name}",
            callback_data=f"setup_proj:{proj.id}",
        )
        row.append(btn)
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)

    logger.info("telegram_project_picker_sending chat_id=%s thread_id=%s", chat_id, thread_id)
    await update.message.reply_text(
        "🚀 OpsPilot Setup — Step 1/6\nSelect a project:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        message_thread_id=thread_id,
    )
    logger.info("telegram_project_picker_sent chat_id=%s thread_id=%s", chat_id, thread_id)


async def _show_agent_picker(query, project_id: str, project_name: str, current_agent: str = "") -> None:
    """Edit message to Step 2: pick agent backend."""
    logger.info("telegram_agent_picker project_id=%s project_name=%s current_agent=%s", project_id, project_name, current_agent)
    agents = [
        (AgentType.CLAUDE_CODE.value, "🤖 Claude Code"),
        (AgentType.CODEX.value, "💡 Codex"),
        (AgentType.GEMINI.value, "✨ Gemini"),
    ]
    keyboard = []
    for agent_val, label in agents:
        prefix = "✅ " if agent_val == current_agent else ""
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{label}",
            callback_data=f"setup_agent:{project_id}:{agent_val}",
        )])
    await query.edit_message_text(
        f"🚀 OpsPilot Setup — Step 2/6\nProject: {project_name}\nSelect agent backend:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )
    logger.info("telegram_agent_picker_sent project_id=%s", project_id)


async def _show_model_picker(
    query, project_id: str, project_name: str, agent_type: str, current_model: str = ""
) -> None:
    """Edit message to Step 3: pick model."""
    logger.info("telegram_model_picker project_id=%s agent_type=%s current_model=%s", project_id, agent_type, current_model)
    models = MODELS_BY_AGENT.get(agent_type, [])
    agent_label = {
        AgentType.CLAUDE_CODE.value: "Claude Code",
        AgentType.CODEX.value: "Codex",
        AgentType.GEMINI.value: "Gemini",
    }.get(agent_type, agent_type)
    keyboard = []
    prefix = "✅ " if not current_model else ""
    keyboard.append([InlineKeyboardButton(
        f"{prefix}Default",
        callback_data=f"setup_model:{project_id}:{agent_type}:default",
    )])
    for idx, (model_id, _label) in enumerate(models):
        prefix = "✅ " if model_id == current_model else ""
        keyboard.append([InlineKeyboardButton(
            f"{prefix}{model_id}",
            callback_data=f"setup_model:{project_id}:{agent_type}:{idx}",
        )])
    await query.edit_message_text(
        f"🚀 OpsPilot Setup — Step 3/6\nProject: {project_name} · Agent: {agent_label}\nSelect model:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )
    logger.info("telegram_model_picker_sent project_id=%s agent_type=%s", project_id, agent_type)


async def _show_mcp_wizard(query, project_name: str, agent_label: str, conv, all_servers, attached_ids: set) -> None:
    """Edit message to Step 4: pick MCP servers."""
    if not all_servers:
        # Skip MCP step — no servers available
        await _show_memory_wizard_for_conv(query, project_name, agent_label, conv)
        return

    keyboard = build_mcp_wizard_keyboard(all_servers, attached_ids)
    await query.edit_message_text(
        f"🚀 OpsPilot Setup — Step 4/6\nProject: {project_name} · Agent: {agent_label}\nToggle MCP servers (tap to toggle):",
        reply_markup=keyboard,
    )


async def _show_memory_wizard_for_conv(query, project_name: str, agent_label: str, conv) -> None:
    """Edit message to Step 5: pick memory files. Fetches files from DB."""
    async with async_session_factory() as db:
        all_files = (await db.execute(
            select(MemoryFile).order_by(MemoryFile.name)
        )).scalars().all()

        conv_obj = (await db.execute(
            select(Conversation)
            .where(Conversation.id == conv.id)
            .options(selectinload(Conversation.memory_files))
        )).scalar_one_or_none()

        attached_ids = {mf.id for mf in conv_obj.memory_files} if conv_obj else set()

    if not all_files:
        # Skip memory step — go to repo step
        await _show_repo_wizard_for_conv(query, project_name, agent_label, conv)
        return

    keyboard = build_memory_wizard_keyboard(all_files, attached_ids)
    await query.edit_message_text(
        f"🚀 OpsPilot Setup — Step 5/6\nProject: {project_name} · Agent: {agent_label}\nToggle memory files (tap to toggle):",
        reply_markup=keyboard,
    )


async def _show_repo_wizard_for_conv(query, project_name: str, agent_label: str, conv) -> None:
    """Edit message to Step 6: pick git repos. Fetches repos from DB."""
    async with async_session_factory() as db:
        all_repos = (await db.execute(
            select(GitRepo).where(GitRepo.project_id == conv.project_id).order_by(GitRepo.name)
        )).scalars().all()

        conv_obj = (await db.execute(
            select(Conversation)
            .where(Conversation.id == conv.id)
            .options(selectinload(Conversation.git_repos))
        )).scalar_one_or_none()

        attached_ids = {r.id for r in conv_obj.git_repos} if conv_obj else set()

    if not all_repos:
        # Skip repo step — show final confirmation
        await _show_wizard_complete(query, conv)
        return

    keyboard = build_repo_wizard_keyboard(all_repos, attached_ids)
    await query.edit_message_text(
        f"🚀 OpsPilot Setup — Step 6/6\nProject: {project_name} · Agent: {agent_label}\nToggle git repositories (tap to toggle):",
        reply_markup=keyboard,
    )


async def _show_wizard_complete(query, conv) -> None:
    """Show wizard final confirmation with summary."""
    async with async_session_factory() as db:
        conv_obj = (await db.execute(
            select(Conversation)
            .where(Conversation.id == conv.id)
            .options(
                selectinload(Conversation.mcp_servers),
                selectinload(Conversation.memory_files),
                selectinload(Conversation.git_repos),
            )
        )).scalar_one_or_none()
        proj = (await db.execute(
            select(Project).where(Project.id == conv_obj.project_id)
        )).scalar_one_or_none() if conv_obj else None

    if not conv_obj or not proj:
        await query.edit_message_text("❌ Conversation not found.")
        return

    agent_label = {
        AgentType.CLAUDE_CODE.value: "Claude Code",
        AgentType.CODEX.value: "Codex",
        AgentType.GEMINI.value: "Gemini",
    }.get(conv_obj.agent_type.value, conv_obj.agent_type.value)
    model = (conv_obj.agent_settings or {}).get("model", "Default") or "Default"
    mcp_names = ", ".join(s.name for s in conv_obj.mcp_servers) if conv_obj.mcp_servers else "None"
    mem_names = ", ".join(mf.name for mf in conv_obj.memory_files) if conv_obj.memory_files else "None"
    repo_names = ", ".join(r.name for r in conv_obj.git_repos) if conv_obj.git_repos else "None"

    await query.edit_message_text(
        f"✅ Ready!\n\n"
        f"Project: {proj.name}\n"
        f"Agent: {agent_label}\n"
        f"Model: {model}\n"
        f"MCP servers: {mcp_names}\n"
        f"Memory files: {mem_names}\n"
        f"Git repos: {repo_names}\n\n"
        f"Send a message to start chatting.",
    )
