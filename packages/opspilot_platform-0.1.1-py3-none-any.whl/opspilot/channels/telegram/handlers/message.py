"""Text message handler and per-conversation queue workers.

Each active conversation gets its own asyncio.Queue + worker Task so that
concurrent messages in the same topic are serialized while multiple topics
can run in parallel.
"""
import asyncio
import json
import logging
import os
import signal
import time
from uuid import UUID

import redis.asyncio as aioredis
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from telegram import Bot, Message, Update
from telegram.ext import ContextTypes

from opspilot.channels.telegram.formatter import format_tool_call, prepare_messages
from opspilot.channels.telegram.handlers.utils import format_error_reply, ref_id
from opspilot.config import settings
from opspilot.context import set_project_id
from opspilot.database import async_session_factory
from opspilot.models import AgentType, Conversation, ConversationMcpServer, TelegramTopic
from opspilot.models.conversations import ConversationGitRepo
from opspilot.models.integrations import GitRepo
from opspilot.models.projects import Project
from opspilot.services.conversation_service import get_channel_agent_defaults
from opspilot.services.mcp_service import get_default_mcp_ids
from opspilot.worker.tasks import _run_chat_turn_async

logger = logging.getLogger(__name__)

# Per-conversation queues and worker tasks keyed by str(conversation_id)
_queues: dict[str, asyncio.Queue] = {}
_workers: dict[str, asyncio.Task] = {}
_queue_lock = asyncio.Lock()

# Running agent tasks keyed by str(conversation_id) — value: (task, message_id, bot, chat_id, thread_id)
_active_tasks: dict[str, tuple] = {}
_active_processes: dict[str, asyncio.subprocess.Process] = {}

# Shared Redis connection pool — lazy init, reused across all turns
_redis_pool: aioredis.Redis | None = None


def _get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


def cancel_active_task(conversation_id: str) -> bool:
    """Cancel the running agent task AND kill subprocess immediately."""
    conv_id = str(conversation_id)
    entry = _active_tasks.get(conv_id)
    if not entry:
        return False
    task, _message_id, _bot, _chat_id, _thread_id = entry
    logger.info(
        "cancel_active_task conversation_id=%s task_found=%s processes_registered=%s",
        conv_id, task is not None, list(_active_processes.keys()),
    )
    if task and not task.done():
        process = _active_processes.get(conv_id)
        if process:
            try:
                pgid = os.getpgid(process.pid)
                logger.info(
                    "cancel_kill_process conversation_id=%s pid=%s pgid=%s",
                    conv_id, process.pid, pgid,
                )
                os.killpg(pgid, signal.SIGKILL)
                logger.info(
                    "cancel_kill_sent conversation_id=%s pid=%s pgid=%s",
                    conv_id, process.pid, pgid,
                )
            except ProcessLookupError:
                logger.info(
                    "cancel_process_already_gone conversation_id=%s pid=%s",
                    conv_id, process.pid,
                )
            except Exception as e:
                logger.warning("cancel_kill_failed conversation_id=%s error=%s", conv_id, e)
        else:
            logger.warning("cancel_no_process_registered conversation_id=%s", conv_id)
        task.cancel()
        return True
    return False


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------


async def _get_default_project_id(db) -> UUID:
    """Return configured default project, falling back to first project in DB."""
    if settings.telegram_project_id:
        return UUID(settings.telegram_project_id)
    result = await db.execute(select(Project.id).order_by(Project.created_at).limit(1))
    project_id = result.scalar_one_or_none()
    if project_id is None:
        raise RuntimeError("No projects in database — cannot create Telegram conversation")
    return project_id


async def get_or_create_topic(
    chat_id: int,
    thread_id: int | None,
    agent_type: AgentType | None = None,
    project_id: UUID | None = None,
) -> TelegramTopic:
    """Return the TelegramTopic for (chat_id, thread_id), creating one if absent."""
    # Defence-in-depth: ensure we only process for the configured chat
    if settings.telegram_chat_id is not None and chat_id != settings.telegram_chat_id:
        raise ValueError(f"Message from unauthorized chat_id={chat_id}")

    async with async_session_factory() as db:
        stmt = select(TelegramTopic).where(
            TelegramTopic.chat_id == chat_id,
            TelegramTopic.topic_id == thread_id,
        )
        result = await db.execute(stmt)
        topic = result.scalar_one_or_none()

        if topic:
            logger.debug(
                "telegram_topic_found chat_id=%s thread_id=%s conversation_id=%s agent=%s",
                chat_id, thread_id, topic.conversation_id, topic.agent_type,
            )
            return topic

        if project_id is None:
            project_id = await _get_default_project_id(db)

        defaults = await get_channel_agent_defaults(db, project_id)
        effective_agent = agent_type or AgentType(defaults.get("agent_type") or settings.telegram_default_agent_type)
        effective_prompt = defaults.get("system_prompt") or settings.telegram_default_system_prompt
        agent_settings: dict = {"telegram_chat_id": chat_id}
        if defaults.get("model"):
            agent_settings["model"] = defaults["model"]

        # Create new Conversation
        conv = Conversation(
            project_id=project_id,
            title=f"Telegram {chat_id}/{thread_id or 'dm'}",
            agent_type=effective_agent,
            system_prompt=effective_prompt,
            agent_settings=agent_settings,
            pre_run_context={"inject_skills": True, "inject_memories": True, "memory_injection_limit": 10},
        )
        db.add(conv)
        await db.flush()

        default_mcp_ids = [UUID(mid) for mid in defaults.get("mcp_server_ids", [])]
        mcp_ids = default_mcp_ids if default_mcp_ids else await get_default_mcp_ids(db)
        for mid in mcp_ids:
            await db.execute(
                pg_insert(ConversationMcpServer)
                .values(conversation_id=conv.id, mcp_server_id=mid)
                .on_conflict_do_nothing()
            )

        default_git_ids = [UUID(rid) for rid in defaults.get("git_repo_ids", [])]
        if default_git_ids:
            for rid in default_git_ids:
                await db.execute(
                    pg_insert(ConversationGitRepo)
                    .values(conversation_id=conv.id, git_repo_id=rid)
                    .on_conflict_do_nothing()
                )
        else:
            project_repos = (await db.execute(
                select(GitRepo).where(GitRepo.project_id == project_id).order_by(GitRepo.name)
            )).scalars().all()
            for repo in project_repos:
                await db.execute(
                    pg_insert(ConversationGitRepo)
                    .values(conversation_id=conv.id, git_repo_id=repo.id)
                    .on_conflict_do_nothing()
                )

        # Upsert TelegramTopic — ON CONFLICT DO NOTHING handles concurrent creation
        await db.execute(
            pg_insert(TelegramTopic)
            .values(
                project_id=project_id,
                chat_id=chat_id,
                topic_id=thread_id,
                conversation_id=conv.id,
                agent_type=effective_agent,
            )
            .on_conflict_do_nothing(constraint="uq_telegram_topics_chat_topic")
        )
        await db.commit()

        # Re-fetch (may have been inserted by a concurrent request)
        result = await db.execute(
            select(TelegramTopic).where(
                TelegramTopic.chat_id == chat_id,
                TelegramTopic.topic_id == thread_id,
            )
        )
        topic = result.scalar_one()
        logger.info(
            "telegram_topic_created chat_id=%s thread_id=%s conversation_id=%s agent=%s",
            chat_id, thread_id, conv.id, effective_agent,
        )
        return topic


# ---------------------------------------------------------------------------
# Queue / worker machinery
# ---------------------------------------------------------------------------


class _WorkerCleanup:
    """Done callback for worker tasks — avoids closure circular reference."""

    def __init__(self, conversation_id: str) -> None:
        self._conversation_id = conversation_id

    def __call__(self, t: asyncio.Task) -> None:
        _queues.pop(self._conversation_id, None)
        _workers.pop(self._conversation_id, None)
        if not t.cancelled() and (exc := t.exception()):
            logger.exception(
                "telegram_worker_died conversation_id=%s",
                self._conversation_id,
                exc_info=exc,
            )


async def _get_or_create_queue(
    conversation_id: str, bot: Bot, chat_id: int, thread_id: int | None
) -> asyncio.Queue:
    """Return the queue for this conversation, creating a worker task if needed."""
    async with _queue_lock:
        # Evict stale entries whose worker has died and queue is empty
        existing_task = _workers.get(conversation_id)
        if existing_task is not None and existing_task.done():
            existing_q = _queues.get(conversation_id)
            if existing_q is None or existing_q.empty():
                _queues.pop(conversation_id, None)
                _workers.pop(conversation_id, None)

        if conversation_id not in _queues:
            q: asyncio.Queue = asyncio.Queue(maxsize=settings.telegram_queue_maxsize)
            _queues[conversation_id] = q
            task = asyncio.create_task(
                _queue_worker(bot, conversation_id, chat_id, thread_id, q),
                name=f"tg-worker-{conversation_id[:8]}",
            )
            _workers[conversation_id] = task
            task.add_done_callback(_WorkerCleanup(conversation_id))

            logger.info(
                "telegram_queue_worker_created conversation_id=%s chat_id=%s thread_id=%s maxsize=%s",
                conversation_id, chat_id, thread_id, settings.telegram_queue_maxsize,
            )

    return _queues[conversation_id]


async def _safe_edit(
    bot: Bot, chat_id: int, message_id: int, text: str, thread_id: int | None = None
) -> None:
    """Edit a message with MarkdownV2, falling back to plain text on parse error."""
    if not text.strip():
        return
    chunks = prepare_messages(text)
    first_chunk, parse_mode = chunks[0]
    timeout = settings.telegram_api_timeout_seconds
    try:
        kwargs: dict = {"chat_id": chat_id, "message_id": message_id, "text": first_chunk}
        if parse_mode:
            kwargs["parse_mode"] = parse_mode
        await asyncio.wait_for(bot.edit_message_text(**kwargs), timeout=timeout)
    except asyncio.TimeoutError:
        logger.warning(
            "telegram_edit_timeout chat_id=%s message_id=%s text_preview=%s",
            chat_id, message_id, text[:80],
        )
    except Exception as e:
        err_str = str(e).lower()
        if "not modified" in err_str:
            return
        logger.warning(
            "telegram_edit_markdownv2_failed chat_id=%s message_id=%s error=%s text_preview=%s",
            chat_id, message_id, e, text[:80],
        )
        try:
            await asyncio.wait_for(
                bot.edit_message_text(
                    chat_id=chat_id, message_id=message_id, text=text[:4096]
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "telegram_edit_plaintext_timeout chat_id=%s message_id=%s text_preview=%s",
                chat_id, message_id, text[:80],
            )
        except Exception as e2:
            if "not modified" not in str(e2).lower():
                logger.warning(
                    "telegram_edit_plaintext_failed chat_id=%s message_id=%s error=%s text_preview=%s",
                    chat_id, message_id, e2, text[:80],
                )


async def _send_overflow(bot: Bot, chat_id: int, text: str, thread_id: int | None) -> None:
    """Send additional chunks when a response exceeds 4096 chars."""
    chunks = prepare_messages(text)
    total = len(chunks)
    timeout = settings.telegram_api_timeout_seconds
    for i, (chunk, parse_mode) in enumerate(chunks[1:], start=2):
        prefix = f"(Part {i}/{total})\n" if total > 1 else ""
        send_text = prefix + chunk
        try:
            kwargs: dict = {
                "chat_id": chat_id,
                "text": send_text,
                "message_thread_id": thread_id,
            }
            if parse_mode:
                kwargs["parse_mode"] = parse_mode
            await asyncio.wait_for(bot.send_message(**kwargs), timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning(
                "telegram_send_overflow_timeout chat_id=%s chunk=%s", chat_id, i
            )
        except Exception:
            try:
                await asyncio.wait_for(
                    bot.send_message(
                        chat_id=chat_id,
                        text=send_text[:4096],
                        message_thread_id=thread_id,
                    ),
                    timeout=timeout,
                )
            except Exception:
                pass


async def _queue_worker(
    bot: Bot,
    conversation_id: str,
    chat_id: int,
    thread_id: int | None,
    queue: asyncio.Queue,
) -> None:
    """Serialize agent turns for one conversation."""
    logger.debug(
        "telegram_worker_started conversation_id=%s chat_id=%s thread_id=%s",
        conversation_id, chat_id, thread_id,
    )
    try:
        while True:
            queue_item = await queue.get()
            if isinstance(queue_item, str):
                user_message = queue_item
                attachments = None
            else:
                user_message = queue_item["text"]
                attachments = queue_item.get("attachments")
            ref = ref_id()
            logger.info(
                "telegram_worker_turn_received ref=%s conversation_id=%s chat_id=%s thread_id=%s queued=%s msg_len=%s attachments=%s",
                ref, conversation_id, chat_id, thread_id, queue.qsize(), len(user_message), len(attachments) if attachments else 0,
            )
            try:
                await _process_turn(bot, conversation_id, chat_id, thread_id, user_message, attachments)
            except Exception as exc:
                logger.exception(
                    "telegram_turn_failed ref=%s conversation_id=%s chat_id=%s thread_id=%s error=%s",
                    ref, conversation_id, chat_id, thread_id, exc,
                )
                try:
                    await bot.send_message(
                        chat_id=chat_id,
                        text=format_error_reply(ref, exc),
                        message_thread_id=thread_id,
                    )
                except Exception:
                    pass
            finally:
                queue.task_done()
    except Exception as exc:
        # Worker crashed — drain and log any remaining queued messages
        logger.exception(
            "telegram_worker_crashed conversation_id=%s error=%s", conversation_id, exc
        )
        drained = 0
        while not queue.empty():
            try:
                msg = queue.get_nowait()
                drained += 1
                logger.warning(
                    "telegram_worker_message_abandoned conversation_id=%s message_preview=%s",
                    conversation_id, (msg or "")[:50],
                )
                queue.task_done()
            except asyncio.QueueEmpty:
                break
        if drained:
            logger.warning(
                "telegram_worker_drained conversation_id=%s count=%s", conversation_id, drained
            )


async def _process_turn(
    bot: Bot,
    conversation_id: str,
    chat_id: int,
    thread_id: int | None,
    user_message: str,
    attachments: list[dict] | None = None,
) -> None:
    """Run one agent turn, streaming events back to the Telegram message."""
    timeout = settings.telegram_api_timeout_seconds

    logger.info(
        "telegram_turn_start conversation_id=%s chat_id=%s thread_id=%s user_len=%s",
        conversation_id, chat_id, thread_id, len(user_message),
    )

    # Send the "Processing" placeholder
    try:
        placeholder: Message = await asyncio.wait_for(
            bot.send_message(
                chat_id=chat_id,
                text="⏳ Processing\\.\\.\\.",
                parse_mode="MarkdownV2",
                message_thread_id=thread_id,
            ),
            timeout=timeout,
        )
        message_id = placeholder.message_id
    except Exception as exc:
        logger.exception(
            "telegram_placeholder_failed conversation_id=%s chat_id=%s thread_id=%s error=%s",
            conversation_id, chat_id, thread_id, exc,
        )
        return

    # Subscribe to Redis BEFORE starting the agent to avoid missing events
    r = _get_redis()
    pubsub = r.pubsub()
    channel = f"chat:{conversation_id}"
    try:
        await pubsub.subscribe(channel)
    except Exception as exc:
        logger.exception(
            "telegram_pubsub_subscribe_failed conversation_id=%s channel=%s error=%s",
            conversation_id, channel, exc,
        )
        await _safe_edit(
            bot, chat_id, message_id, "❌ Internal error subscribing to updates.", thread_id
        )
        return

    # Set project context so the agent task inherits the correct project_id
    async with async_session_factory() as db:
        _conv = (await db.execute(
            select(Conversation).where(Conversation.id == UUID(conversation_id))
        )).scalar_one_or_none()
        if _conv and _conv.project_id:
            set_project_id(_conv.project_id)

    # Kick off the agent turn and register it for /cancel support
    def _on_process_started(process: asyncio.subprocess.Process) -> None:
        _active_processes[conversation_id] = process
        logger.info(
            "cancel_process_registered conversation_id=%s pid=%s", conversation_id, process.pid
        )

    agent_task = asyncio.create_task(
        _run_chat_turn_async(conversation_id, user_message, on_process_started=_on_process_started, attachments=attachments)
    )
    _active_tasks[conversation_id] = (agent_task, message_id, bot, chat_id, thread_id)

    accumulated_text = ""
    last_edit = ""
    last_edit_time = 0.0

    try:
        async for redis_msg in pubsub.listen():
            if redis_msg["type"] != "message":
                continue

            try:
                event = json.loads(redis_msg["data"])
            except (json.JSONDecodeError, KeyError) as exc:
                logger.warning(
                    "telegram_pubsub_event_decode_failed conversation_id=%s error=%s raw=%s",
                    conversation_id, exc, str(redis_msg)[0:200],
                )
                continue

            event_type = event.get("type", "")

            if event_type == "message":
                accumulated_text += event.get("content", "")
                now = time.monotonic()
                if (
                    accumulated_text != last_edit
                    and (now - last_edit_time) >= settings.telegram_edit_debounce_seconds
                ):
                    await _safe_edit(bot, chat_id, message_id, accumulated_text, thread_id)
                    last_edit = accumulated_text
                    last_edit_time = now

            elif event_type == "tool_call_start":
                tool_name = event.get("tool_name", "unknown")
                status_line = format_tool_call(tool_name, "running")
                display = (accumulated_text + "\n\n" + status_line).strip()
                await _safe_edit(bot, chat_id, message_id, display, thread_id)

            elif event_type == "tool_call_end":
                tool_name = event.get("tool_name", "unknown")
                status = "error" if event.get("status") == "error" else "success"
                status_line = format_tool_call(tool_name, status)
                display = (accumulated_text + "\n\n" + status_line).strip()
                await _safe_edit(bot, chat_id, message_id, display, thread_id)

            elif event_type == "turn_end":
                if not accumulated_text and not event.get("success", True):
                    err = event.get("error") or "Agent failed with no output."
                    accumulated_text = "🛑 Stopped." if err == "Cancelled by user" else f"❌ {err}"
                logger.info(
                    "telegram_turn_event_end conversation_id=%s success=%s",
                    conversation_id, event.get("success", True),
                )
                break

            elif event_type == "error":
                if not accumulated_text:
                    accumulated_text = f"❌ {event.get('message', 'Unknown error')}"
                break

    except Exception as exc:
        logger.warning(
            "telegram_pubsub_error conversation_id=%s error=%s", conversation_id, exc
        )

    finally:
        _active_tasks.pop(conversation_id, None)
        _active_processes.pop(conversation_id, None)

        async def _redis_cleanup() -> None:
            await pubsub.unsubscribe(channel)
            await pubsub.aclose()

        try:
            await asyncio.wait_for(_redis_cleanup(), timeout=2.0)
        except Exception as exc:
            logger.warning(
                "telegram_redis_cleanup_failed conversation_id=%s error=%s", conversation_id, exc
            )

    # Ensure agent task is finished; wait with drain timeout then cancel
    try:
        await asyncio.wait_for(agent_task, timeout=settings.telegram_drain_timeout_seconds)
    except asyncio.TimeoutError:
        logger.warning(
            "telegram_agent_task_timeout conversation_id=%s timeout_s=%s",
            conversation_id, settings.telegram_drain_timeout_seconds,
        )
        agent_task.cancel()
        try:
            await agent_task
        except asyncio.CancelledError:
            logger.info("telegram_agent_task_cancelled conversation_id=%s", conversation_id)
    except asyncio.CancelledError:
        logger.info("telegram_agent_task_cancelled conversation_id=%s", conversation_id)

    # Final edit with clean accumulated text (removes any tool status lines)
    final_text = accumulated_text.strip() or "✅ Done."
    await _safe_edit(bot, chat_id, message_id, final_text, thread_id)

    # Send overflow chunks if response exceeded 4096 chars
    await _send_overflow(bot, chat_id, accumulated_text, thread_id)

    logger.info(
        "telegram_turn_complete conversation_id=%s chat_id=%s thread_id=%s accumulated_len=%s",
        conversation_id, chat_id, thread_id, len(accumulated_text),
    )


# ---------------------------------------------------------------------------
# Telegram handler
# ---------------------------------------------------------------------------


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Entry point for all text messages."""
    if not update.message or not update.effective_chat:
        return

    # Only process messages from the configured Telegram chat (DM user)
    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return

    text = (update.message.text or "").strip()
    if not text:
        logger.debug(
            "telegram_text_empty chat_id=%s thread_id=%s message_id=%s",
            update.effective_chat.id,
            update.message.message_thread_id,
            update.message.message_id,
        )
        return

    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id

    topic = await get_or_create_topic(chat_id, thread_id)
    conversation_id = str(topic.conversation_id)

    bot = context.bot
    queue = await _get_or_create_queue(conversation_id, bot, chat_id, thread_id)

    try:
        queue.put_nowait(text)
    except asyncio.QueueFull:
        logger.warning(
            "telegram_queue_full conversation_id=%s chat_id=%s thread_id=%s",
            conversation_id, chat_id, thread_id,
        )
        await bot.send_message(
            chat_id=chat_id,
            text="⚠️ I'm still processing earlier messages\\. Please wait before sending more\\.",
            parse_mode="MarkdownV2",
            message_thread_id=thread_id,
        )
        return

    logger.info(
        "telegram_message_queued chat_id=%s thread_id=%s conversation_id=%s queue_size=%s message_id=%s",
        chat_id, thread_id, conversation_id, queue.qsize(), update.message.message_id,
    )


async def voice_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Entry point for Telegram voice messages — transcribes then queues as text."""
    if not update.message or not update.effective_chat:
        return

    if settings.telegram_chat_id is not None and update.effective_chat.id != settings.telegram_chat_id:
        return

    voice = update.message.voice
    if not voice:
        logger.debug(
            "telegram_voice_empty chat_id=%s thread_id=%s message_id=%s",
            update.effective_chat.id,
            update.message.message_thread_id,
            update.message.message_id,
        )
        return

    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id
    bot = context.bot

    # Send immediate feedback so user knows we're processing
    status_msg = await asyncio.wait_for(
        bot.send_message(
            chat_id=chat_id,
            text="🎤 Transcribing voice message\\.\\.\\.",
            parse_mode="MarkdownV2",
            message_thread_id=thread_id,
        ),
        timeout=settings.telegram_api_timeout_seconds,
    )

    try:
        # Download voice OGG from Telegram
        tg_file = await asyncio.wait_for(
            bot.get_file(voice.file_id),
            timeout=settings.telegram_api_timeout_seconds,
        )
        voice_bytes = bytes(await tg_file.download_as_bytearray())

        # Transcribe using the microservice
        from opspilot.services.transcription import TranscriptionClient
        client = TranscriptionClient()
        result = await client.transcribe(voice_bytes, filename="voice.ogg")
        text = result.text.strip()

    except Exception as exc:
        logger.exception(
            "telegram_voice_transcription_failed chat_id=%s thread_id=%s message_id=%s error=%s",
            chat_id, thread_id, update.message.message_id, exc,
        )
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=status_msg.message_id,
            text="❌ Could not transcribe voice message.",
        )
        return

    if not text:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=status_msg.message_id,
            text="❌ Voice message was empty or could not be transcribed.",
        )
        return

    # Delete the status message and process transcription as a regular text message
    try:
        await bot.delete_message(chat_id=chat_id, message_id=status_msg.message_id)
    except Exception:
        pass  # Non-critical — proceed even if delete fails

    topic = await get_or_create_topic(chat_id, thread_id)
    conversation_id = str(topic.conversation_id)
    queue = await _get_or_create_queue(conversation_id, bot, chat_id, thread_id)

    logger.info(
        "telegram_voice_transcribed chat_id=%s thread_id=%s text_len=%s language=%s message_id=%s",
        chat_id, thread_id, len(text), result.language, update.message.message_id,
    )

    try:
        queue.put_nowait(text)
    except asyncio.QueueFull:
        await bot.send_message(
            chat_id=chat_id,
            text="⚠️ I'm still processing earlier messages\\. Please wait before sending more\\.",
            parse_mode="MarkdownV2",
            message_thread_id=thread_id,
        )


async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming photo messages — downloads, processes, and queues with attachment."""
    if not update.message or not update.effective_chat:
        return

    allowed_chat_id = context.bot_data.get("allowed_chat_id")
    if allowed_chat_id is not None and update.effective_chat.id != allowed_chat_id:
        return

    photos = update.message.photo
    if not photos:
        return

    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id
    bot = context.bot
    caption = (update.message.caption or "").strip() or "Sent a photo"

    try:
        photo = photos[-1]
        tg_file = await asyncio.wait_for(
            bot.get_file(photo.file_id),
            timeout=settings.telegram_api_timeout_seconds,
        )
        photo_bytes = bytes(await tg_file.download_as_bytearray())

        from opspilot.services.media_service import process_media_bytes
        attachment = process_media_bytes(photo_bytes, "photo.jpg", "image/jpeg", source="telegram")

    except Exception as exc:
        logger.exception("telegram_photo_processing_failed chat_id=%s error=%s", chat_id, exc)
        return

    topic = await get_or_create_topic(chat_id, thread_id)
    conversation_id = str(topic.conversation_id)
    queue = await _get_or_create_queue(conversation_id, bot, chat_id, thread_id)

    logger.info("telegram_photo_received chat_id=%s conversation_id=%s size=%s", chat_id, conversation_id, len(photo_bytes))

    try:
        queue.put_nowait({"text": caption, "attachments": [attachment]})
    except asyncio.QueueFull:
        await bot.send_message(
            chat_id=chat_id,
            text="⚠️ I'm still processing earlier messages\\. Please wait before sending more\\.",
            parse_mode="MarkdownV2",
            message_thread_id=thread_id,
        )


async def document_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming document messages — downloads, processes, and queues with attachment."""
    if not update.message or not update.effective_chat:
        return

    allowed_chat_id = context.bot_data.get("allowed_chat_id")
    if allowed_chat_id is not None and update.effective_chat.id != allowed_chat_id:
        return

    doc = update.message.document
    if not doc:
        return

    chat_id = update.effective_chat.id
    thread_id = update.message.message_thread_id
    bot = context.bot
    caption = (update.message.caption or "").strip() or f"Sent a document: {doc.file_name}"

    try:
        tg_file = await asyncio.wait_for(
            bot.get_file(doc.file_id),
            timeout=settings.telegram_api_timeout_seconds,
        )
        doc_bytes = bytes(await tg_file.download_as_bytearray())

        from opspilot.services.media_service import process_media_bytes
        attachment = process_media_bytes(
            doc_bytes,
            doc.file_name or "document",
            doc.mime_type or "application/octet-stream",
            source="telegram",
        )

        if attachment.get("extracted_text"):
            caption += f"\n\n[Document content]:\n{attachment['extracted_text'][:3000]}"

    except Exception as exc:
        logger.exception("telegram_document_processing_failed chat_id=%s error=%s", chat_id, exc)
        return

    topic = await get_or_create_topic(chat_id, thread_id)
    conversation_id = str(topic.conversation_id)
    queue = await _get_or_create_queue(conversation_id, bot, chat_id, thread_id)

    logger.info("telegram_document_received chat_id=%s conversation_id=%s filename=%s size=%s", chat_id, conversation_id, doc.file_name, len(doc_bytes))

    try:
        queue.put_nowait({"text": caption, "attachments": [attachment]})
    except asyncio.QueueFull:
        await bot.send_message(
            chat_id=chat_id,
            text="⚠️ I'm still processing earlier messages\\. Please wait before sending more\\.",
            parse_mode="MarkdownV2",
            message_thread_id=thread_id,
        )
