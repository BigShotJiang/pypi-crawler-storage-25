"""TelegramAdapter — webhook mode, feeds updates into python-telegram-bot via process_update()."""
import asyncio
import logging
import secrets as secrets_lib

import httpx

from opspilot.channels.base import IChannelAdapter
from opspilot.config import settings

logger = logging.getLogger(__name__)


class TelegramAdapter(IChannelAdapter):
    channel_type = "telegram"

    def __init__(self):
        self._app = None

    def is_enabled(self) -> bool:
        return settings.telegram_enabled and bool(settings.telegram_bot_token)

    async def start(self) -> None:
        from opspilot.channels.telegram.bot import build_application

        self._app = build_application(settings.telegram_bot_token)
        await self._app.initialize()
        await self._app.start()
        bot_id = getattr(self._app, "bot", None) and self._app.bot.id
        logger.info("telegram_adapter_webhook_mode_started bot_id=%s", bot_id)

        # Fire-and-forget: don't block app startup while waiting for DNS
        asyncio.create_task(self._register_webhook())

    async def _register_webhook(self) -> None:
        """Read tunnel URL and register Telegram webhook. Non-fatal on failure."""
        base_url = settings.telegram_webhook_base_url

        if not base_url:
            base_url = await self._wait_for_tunnel_url()

        if not base_url:
            logger.warning("telegram_webhook_not_registered no_url_available")
            return

        webhook_url = f"{base_url.rstrip('/')}/api/telegram/webhook"

        secret = settings.telegram_webhook_secret
        if not secret:
            secret = secrets_lib.token_urlsafe(32)
            settings.telegram_webhook_secret = secret
            logger.info("telegram_webhook_secret_generated")

        # Retry with backoff — DNS for quick tunnels can take 3-5 min to propagate
        max_retries = 15
        for attempt in range(1, max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    r = await client.post(
                        f"https://api.telegram.org/bot{settings.telegram_bot_token}/setWebhook",
                        json={
                            "url": webhook_url,
                            "secret_token": secret,
                            "allowed_updates": ["message", "callback_query", "edited_message"],
                            "drop_pending_updates": True,
                        },
                    )
                    data = r.json()

                if data.get("ok"):
                    logger.info("telegram_webhook_registered url=%s attempt=%d", webhook_url, attempt)
                    return

                desc = data.get("description", "")
                if "resolve" in desc.lower() and attempt < max_retries:
                    delay = min(attempt * 10, 30)
                    logger.warning("telegram_webhook_dns_not_ready attempt=%d/%d retrying_in=%ds", attempt, max_retries, delay)
                    await asyncio.sleep(delay)
                    continue

                logger.error("telegram_webhook_registration_failed response=%s", data)
                return
            except Exception:
                if attempt < max_retries:
                    delay = min(attempt * 10, 30)
                    logger.warning("telegram_webhook_registration_error attempt=%d/%d", attempt, max_retries, exc_info=True)
                    await asyncio.sleep(delay)
                else:
                    logger.exception("telegram_webhook_registration_error")

    async def stop(self) -> None:
        if self._app:
            try:
                await self._app.stop()
                await self._app.shutdown()
            except Exception:
                logger.debug("telegram_app_shutdown_error", exc_info=True)
        logger.info("telegram_adapter_stopped")

    async def process_update(self, data: dict) -> None:
        """Feed a raw Telegram update payload to the PTB application."""
        from telegram import Update

        if not self._app:
            logger.warning("telegram_adapter_not_initialized")
            return

        try:
            update = Update.de_json(data, self._app.bot)
        except Exception as exc:
            logger.exception("telegram_update_deserialize_failed error=%s", exc)
            return

        try:
            await self._app.process_update(update)
        except Exception as exc:
            logger.exception("telegram_update_process_failed update_id=%s error=%s", getattr(update, "update_id", None), exc)
