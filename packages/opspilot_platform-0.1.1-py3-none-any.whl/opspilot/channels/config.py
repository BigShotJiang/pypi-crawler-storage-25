"""Shared configuration constants for all channel handlers (Telegram, Slack, etc.)."""
from opspilot.models import AgentType

# Models available per agent type: (model_id, label)
MODELS_BY_AGENT: dict[str, list[tuple[str, str]]] = {
    AgentType.CLAUDE_CODE.value: [
        ("claude-haiku-4-5-20251001", "Haiku 4.5 — fastest"),
        ("claude-sonnet-4-6", "Sonnet 4.6 — balanced"),
        ("claude-opus-4-6", "Opus 4.6 — most capable"),
    ],
    AgentType.CODEX.value: [
        ("gpt-5.3-codex", "GPT-5.3 Codex — latest frontier"),
        ("gpt-5.2-codex", "GPT-5.2 Codex — frontier agentic"),
        ("gpt-5.1-codex-max", "GPT-5.1 Codex Max — flagship reasoning"),
        ("gpt-5.2", "GPT-5.2 — general frontier"),
        ("gpt-5.1-codex-mini", "GPT-5.1 Codex Mini — fast & cheap"),
    ],
    AgentType.GEMINI.value: [
        ("gemini-3.1-pro-preview", "Gemini 3.1 Pro — best for agents"),
        ("gemini-3-flash-preview", "Gemini 3 Flash — fast reasoning"),
        ("gemini-2.5-pro", "Gemini 2.5 Pro"),
        ("gemini-2.5-flash", "Gemini 2.5 Flash"),
        ("gemini-2.5-flash-lite", "Gemini 2.5 Flash Lite"),
    ],
}

# System prompt presets: (key, label, full_prompt_text)
SYSTEM_PROMPT_PRESETS: list[tuple[str, str, str]] = [
    (
        "devops",
        "DevOps Assistant",
        "You are a helpful DevOps assistant with expertise in Kubernetes, cloud infrastructure, and site reliability engineering. You have access to kubectl, monitoring tools, and databases. Help the user diagnose and resolve infrastructure issues.",
    ),
    (
        "infra",
        "Infrastructure Debug",
        "You are an infrastructure debugging specialist. Your goal is to systematically investigate issues using available tools (kubectl, Prometheus metrics, Loki logs), identify root causes, and provide actionable remediation steps.",
    ),
    (
        "cost",
        "Cost Analysis",
        "You are a cloud cost optimization specialist. Analyze resource usage, identify inefficiencies, and provide concrete recommendations to reduce infrastructure costs while maintaining reliability.",
    ),
    (
        "security",
        "Security Auditor",
        "You are a security auditor specializing in cloud infrastructure, Kubernetes, and application security. Identify vulnerabilities and provide remediation guidance.",
    ),
]
