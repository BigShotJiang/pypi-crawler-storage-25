from __future__ import annotations
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict

from opspilot.models import (
    AgentType,
)

if TYPE_CHECKING:
    from opspilot.schemas.integrations import GitRepoOut, McpServerOut
    from opspilot.schemas.knowledge import MemoryFileOut
    from opspilot.schemas.notifications import NotificationChannelOut
    from opspilot.schemas.todos import StoredFileOut


class TaskTemplateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    description: str
    default_cron: str
    default_agent_type: AgentType
    system_prompt: str
    default_mcp_servers: list | None = None
    default_timeout_seconds: int
    icon: str
    color: str
    created_at: datetime


# --- MCP Servers ---



class TaskCreate(BaseModel):
    name: str
    description: str | None = None
    template_id: uuid.UUID | None = None
    cron_schedule: str | None = None
    agent_type: AgentType = AgentType.CLAUDE_CODE
    system_prompt: str | None = None
    prompt: str
    timeout_seconds: int = 600
    max_retries: int = 0
    enabled: bool = True
    auto_archive_artifact: bool = False
    agent_settings: dict = {}
    pre_run_context: dict = {"inject_skills": True}
    task_memory: str | None = None
    mcp_server_ids: list[uuid.UUID] = []
    git_repo_ids: list[uuid.UUID] = []
    notification_channel_ids: list[uuid.UUID] = []
    memory_file_ids: list[uuid.UUID] = []
    file_ids: list[uuid.UUID] = []



class TaskUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    cron_schedule: str | None = None
    agent_type: AgentType | None = None
    system_prompt: str | None = None
    prompt: str | None = None
    timeout_seconds: int | None = None
    max_retries: int | None = None
    enabled: bool | None = None
    auto_archive_artifact: bool | None = None
    agent_settings: dict | None = None
    pre_run_context: dict | None = None
    task_memory: str | None = None
    mcp_server_ids: list[uuid.UUID] | None = None
    git_repo_ids: list[uuid.UUID] | None = None
    notification_channel_ids: list[uuid.UUID] | None = None
    memory_file_ids: list[uuid.UUID] | None = None
    file_ids: list[uuid.UUID] | None = None



class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    template_id: uuid.UUID | None
    cron_schedule: str | None
    agent_type: AgentType
    system_prompt: str | None
    prompt: str
    timeout_seconds: int
    max_retries: int
    enabled: bool
    auto_archive_artifact: bool
    agent_settings: dict = {}
    pre_run_context: dict = {"inject_skills": True}
    task_memory: str | None = None
    last_run_at: datetime | None
    next_run_at: datetime | None
    created_at: datetime
    updated_at: datetime
    mcp_servers: list[McpServerOut] = []
    git_repos: list[GitRepoOut] = []
    notification_channels: list[NotificationChannelOut] = []
    memory_files: list[MemoryFileOut] = []
    files: list[StoredFileOut] = []



class TaskListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    cron_schedule: str | None
    agent_type: AgentType
    enabled: bool
    auto_archive_artifact: bool
    agent_settings: dict = {}
    last_run_at: datetime | None
    next_run_at: datetime | None
    created_at: datetime
    session_count: int = 0



class TaskStatsOut(BaseModel):
    total: int
    enabled: int
    disabled: int
    scheduled: int
    by_agent: dict[str, int]



class TaskTriggerResponse(BaseModel):
    session_id: uuid.UUID
    message: str


class TaskBulkDeleteRequest(BaseModel):
    file_ids: list[uuid.UUID]


class TaskBulkDeleteResponse(BaseModel):
    deleted_count: int
    failed_ids: list[str]


# --- Reports ---



class WebhookConfigOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID
    name: str | None = None
    token: str
    enabled: bool
    description: str | None
    created_at: datetime
    updated_at: datetime



class WebhookConfigCreate(BaseModel):
    name: str | None = None
    description: str | None = None



class WebhookConfigUpdate(BaseModel):
    name: str | None = None
    enabled: bool | None = None
    description: str | None = None
    regenerate_token: bool = False


class WebhookConfigListItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID
    task_name: str
    name: str | None = None
    token: str
    enabled: bool
    description: str | None = None
    total_events: int = 0
    last_event_at: datetime | None = None
    last_event_status: str | None = None
    created_at: datetime
    updated_at: datetime


class WebhookConfigDetailOut(WebhookConfigListItem):
    recent_events: list[WebhookEventOut] = []
    events_24h: int = 0
    success_rate_24h: float | None = None


class WebhookStatsOut(BaseModel):
    total_configs: int
    enabled: int
    disabled: int
    total_events_24h: int
    events_by_status: dict[str, int] = {}


class WebhookEventListItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID
    task_name: str | None = None
    session_id: uuid.UUID | None = None
    source_ip: str | None = None
    received_at: datetime
    processing_status: str
    error_message: str | None = None
    payload_preview: str = ""


class WebhookEventDetailOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID
    task_name: str | None = None
    session_id: uuid.UUID | None = None
    headers: dict
    payload: dict
    source_ip: str | None = None
    received_at: datetime
    processing_status: str
    error_message: str | None = None


class WebhookBulkDeleteRequest(BaseModel):
    ids: list[uuid.UUID]



class WebhookEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID
    session_id: uuid.UUID | None
    headers: dict
    payload: dict
    source_ip: str | None
    received_at: datetime
    processing_status: str
    error_message: str | None



class WebhookTriggerResponse(BaseModel):
    session_id: uuid.UUID | None = None
    message: str
    alert_group_id: uuid.UUID | None = None
    alert_count: int | None = None


# --- Knowledge Base ---


from opspilot.schemas.integrations import McpServerOut, GitRepoOut
from opspilot.schemas.notifications import NotificationChannelOut
from opspilot.schemas.knowledge import MemoryFileOut
from opspilot.schemas.todos import StoredFileOut
TaskOut.model_rebuild()
