from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ArtifactOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID
    source_type: str
    session_id: uuid.UUID | None
    conversation_id: uuid.UUID | None
    trigger: str
    filename: str
    archive_format: str
    file_size_bytes: int
    original_size_bytes: int | None
    s3_url: str
    file_count: int | None
    workspace_path: str | None
    created_at: datetime


class ArtifactListResponse(BaseModel):
    items: list[ArtifactOut]
    total: int
