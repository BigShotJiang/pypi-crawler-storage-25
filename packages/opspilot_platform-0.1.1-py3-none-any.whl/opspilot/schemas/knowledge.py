from __future__ import annotations
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class MemoryFileCreate(BaseModel):
    name: str
    description: str | None = None
    content: str = ""
    destination: str  # e.g. "CLAUDE.md", "AGENTS.md", "GEMINI.md"
    agent_type: str | None = None  # null = all agents; "claude-code" | "codex" | "gemini"



class MemoryFileUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    content: str | None = None
    destination: str | None = None
    agent_type: str | None = None



class MemoryFileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    description: str | None
    content: str
    destination: str
    agent_type: str | None
    created_at: datetime
    updated_at: datetime


# --- Tasks ---



class KnowledgeStats(BaseModel):
    total: int
    by_category: dict[str, int]



class KnowledgeEntryCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    content: str = Field(..., min_length=1, max_length=200_000)
    category: str | None = Field(None, max_length=100)
    tags: list[str] = Field(default=[], max_length=50)
    session_id: uuid.UUID | None = None



class KnowledgeEntryUpdate(BaseModel):
    title: str | None = Field(None, min_length=1, max_length=500)
    content: str | None = Field(None, min_length=1, max_length=200_000)
    category: str | None = Field(None, max_length=100)
    tags: list[str] | None = Field(None, max_length=50)



class KnowledgeEntryListItem(BaseModel):
    """Summary returned by list — content_preview only, no full content."""
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    content_preview: str
    category: str | None
    tags: list[str]
    session_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime



class KnowledgeEntryOut(BaseModel):
    """Full detail returned by GET /{id}."""
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    content: str
    category: str | None
    tags: list[str]
    session_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime
