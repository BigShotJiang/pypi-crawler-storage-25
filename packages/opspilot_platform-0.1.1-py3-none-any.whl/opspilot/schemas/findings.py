from __future__ import annotations
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict

from opspilot.models import (
    FindingType,
    IncidentStatus,
    RunbookStatus,
    Severity,
)


class FindingCreate(BaseModel):
    """Used by the OpsPilot Notify MCP server and standalone POST /findings."""

    finding_type: FindingType
    severity: Severity
    title: str
    summary: str
    affected_components: list | None = None
    evidence: dict | None = None
    recommendation: str | None = None
    session_id: uuid.UUID | None = None



class FindingUpdate(BaseModel):
    finding_type: FindingType | None = None
    severity: Severity | None = None
    title: str | None = None
    summary: str | None = None
    affected_components: list | None = None
    evidence: dict | None = None
    recommendation: str | None = None



class FindingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    session_id: uuid.UUID | None
    finding_type: FindingType
    severity: Severity
    title: str
    summary: str
    affected_components: list | None
    evidence: dict | None
    recommendation: str | None
    acknowledged: bool
    acknowledged_at: datetime | None
    acknowledged_by: str | None
    created_at: datetime



class FindingAcknowledge(BaseModel):
    acknowledged_by: str = "operator"


# --- Notifications Sent ---



class IncidentDetailStats(BaseModel):
    total: int
    by_status: dict[str, int]
    by_severity: dict[str, int]
    mttr_hours: float | None



class SkillStats(BaseModel):
    total: int
    by_domain: dict[str, int]



class ReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID | None
    session_id: uuid.UUID | None
    title: str
    s3_url: str | None = None
    created_at: datetime
    updated_at: datetime



class ReportCreate(BaseModel):
    title: str
    content_md: str | None = None
    content_html: str | None = None
    task_id: uuid.UUID | None = None
    session_id: uuid.UUID | None = None



class ReportListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID | None
    session_id: uuid.UUID | None
    title: str
    s3_url: str | None = None
    task_name: str | None = None
    created_at: datetime


# --- Incidents ---



class IncidentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    session_id: uuid.UUID | None
    severity: Severity
    status: IncidentStatus
    title: str
    summary: str
    root_cause_html: str | None
    impact: str | None
    affected_components: list | None
    timeline: list | None
    resolved_at: datetime | None
    created_at: datetime
    updated_at: datetime



class IncidentUpdate(BaseModel):
    status: IncidentStatus | None = None
    title: str | None = None
    summary: str | None = None
    root_cause_html: str | None = None
    impact: str | None = None
    affected_components: list | None = None
    timeline: list | None = None
    resolved_at: datetime | None = None



class IncidentCreate(BaseModel):
    title: str
    summary: str
    severity: Severity
    status: IncidentStatus | None = None
    session_id: uuid.UUID | None = None
    root_cause_html: str | None = None
    impact: str | None = None
    affected_components: list | None = None
    timeline: list | None = None


# --- Skills ---



class SkillCreate(BaseModel):
    name: str
    slug: str
    description: str
    domain: str
    content: str
    entry_type: str = "skill"



class SkillUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    domain: str | None = None
    content: str | None = None
    entry_type: str | None = None



class SkillOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    description: str
    domain: str
    content: str
    entry_type: str
    session_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


# --- Runbooks ---



class RunbookCreate(BaseModel):
    title: str
    slug: str
    description: str
    content: str
    category: str | None = None
    tags: list[str] | None = None
    status: RunbookStatus = RunbookStatus.DRAFT
    version: str | None = None
    session_id: uuid.UUID | None = None



class RunbookUpdate(BaseModel):
    title: str | None = None
    slug: str | None = None
    description: str | None = None
    content: str | None = None
    category: str | None = None
    tags: list[str] | None = None
    status: RunbookStatus | None = None
    version: str | None = None
    session_id: uuid.UUID | None = None



class RunbookOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    session_id: uuid.UUID | None
    title: str
    slug: str
    description: str
    content: str
    category: str | None
    tags: list[str] | None
    status: RunbookStatus
    version: str | None
    created_at: datetime
    updated_at: datetime


# --- Notification Logs ---

