from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class CustomDashboardCreate(BaseModel):
    title: str
    description: str | None = None
    content_html: str
    task_id: uuid.UUID | None = None
    session_id: uuid.UUID | None = None


class CustomDashboardUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    content_html: str | None = None


class CustomDashboardOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    task_id: uuid.UUID | None
    session_id: uuid.UUID | None
    title: str
    description: str | None
    s3_url: str | None
    thumbnail_url: str | None
    is_favorite: bool
    sort_order: int
    created_at: datetime
    updated_at: datetime


class ReorderItem(BaseModel):
    id: uuid.UUID
    sort_order: int
