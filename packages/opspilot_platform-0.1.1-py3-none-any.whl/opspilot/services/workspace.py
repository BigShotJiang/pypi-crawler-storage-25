import json
import logging
import os
import shutil
import subprocess
from pathlib import Path

from opspilot.config import settings

logger = logging.getLogger(__name__)


_REPO_CACHE_BASE = Path(settings.workspace_base_path).parent / "repo_cache"


class WorkspaceService:
    """Prepares isolated workspace directories for agent sessions."""

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.workspace_path = Path(settings.workspace_base_path) / session_id
        self.repos_path = self.workspace_path / "repos"

    def setup(self) -> Path:
        """Create workspace directory structure."""
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        self.repos_path.mkdir(exist_ok=True)
        logger.debug("workspace_setup session_id=%s path=%s", self.session_id, self.workspace_path)
        return self.workspace_path

    def clone_repo(
        self,
        url: str,
        name: str,
        branch: str = "main",
        shallow: bool = True,
        username: str | None = None,
        token: str | None = None,
        ssh_key: str | None = None,
        auth_type: str = "https_token",
        project_id: str | None = None,
    ) -> Path:
        """Clone a git repository into the workspace with a shared cache.

        On first use: clones the repo into a project-scoped cache directory,
        then makes a fast local copy into the session workspace.
        On subsequent uses: updates the cache via git fetch, then local-copies.

        Supports two auth modes:
        - https_token: credentials injected into HTTPS URL (GitHub PAT, etc.)
        - ssh_key: SSH private key written to a temp file, used via GIT_SSH_COMMAND
        """
        logger.info(
            "clone_repo_start session_id=%s repo=%s branch=%s auth_type=%s",
            self.session_id, name, branch, auth_type,
        )

        # Prepare authentication
        clone_url = url
        git_env: dict[str, str] | None = None
        key_path: Path | None = None

        if auth_type == "ssh_key" and ssh_key:
            # Write SSH key to temp file in workspace dir (cleaned up with workspace)
            key_path = self.workspace_path / f".ssh_key_{name}"
            key_path.write_text(ssh_key)
            key_path.chmod(0o600)
            git_env = {
                **os.environ,
                "GIT_SSH_COMMAND": f"ssh -i {key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null",
            }
        elif token and url.startswith("https://"):
            from urllib.parse import urlparse, urlunparse
            parsed = urlparse(url)
            userinfo = f"{username}:{token}" if username else token
            clone_url = urlunparse(parsed._replace(netloc=f"{userinfo}@{parsed.netloc}"))

        try:
            return self._do_clone(
                url=url, clone_url=clone_url, name=name, branch=branch,
                shallow=shallow, token=token, git_env=git_env, project_id=project_id,
            )
        finally:
            # Clean up SSH key file
            if key_path and key_path.exists():
                key_path.unlink()

    def _do_clone(
        self,
        url: str,
        clone_url: str,
        name: str,
        branch: str,
        shallow: bool,
        token: str | None,
        git_env: dict[str, str] | None,
        project_id: str | None,
    ) -> Path:
        """Internal clone logic shared by both HTTPS and SSH auth paths."""
        dest = self.repos_path / name

        # For persistent workspaces (e.g. conversation turns), update in-place
        if dest.exists() and (dest / ".git").exists():
            logger.info("clone_repo_update_existing session_id=%s repo=%s", self.session_id, name)
            try:
                subprocess.run(
                    ["git", "-C", str(dest), "remote", "set-url", "origin", clone_url],
                    check=True, capture_output=True, timeout=10, env=git_env,
                )
                fetch_cmd = ["git", "-C", str(dest), "fetch", "--prune", "origin", branch]
                self._run_git(fetch_cmd, clone_url, url, token, name, env=git_env)
                subprocess.run(
                    ["git", "-C", str(dest), "reset", "--hard", f"origin/{branch}"],
                    check=True, capture_output=True, timeout=10, env=git_env,
                )
                logger.info("clone_repo_updated session_id=%s repo=%s", self.session_id, name)
                return dest
            except Exception as exc:
                logger.warning("clone_repo_update_failed session_id=%s repo=%s error=%s — re-cloning", self.session_id, name, exc)
                shutil.rmtree(dest)
        elif dest.exists():
            shutil.rmtree(dest)

        # Attempt cached clone when project_id is known
        if project_id:
            cache_path = _REPO_CACHE_BASE / str(project_id) / name
            try:
                if cache_path.exists():
                    self._update_cache(cache_path, clone_url, url, branch, token, env=git_env)
                else:
                    self._populate_cache(cache_path, clone_url, url, branch, token, env=git_env)
                # Local clone from cache into session workspace (uses hardlinks — fast)
                subprocess.run(
                    ["git", "clone", "--local", str(cache_path), str(dest)],
                    check=True, capture_output=True, timeout=30,
                )
                logger.info("clone_repo_from_cache session_id=%s repo=%s", self.session_id, name)
                return dest
            except Exception as exc:
                logger.warning(
                    "clone_repo_cache_failed session_id=%s repo=%s error=%s — falling back to direct clone",
                    self.session_id, name, exc,
                )
                if dest.exists():
                    shutil.rmtree(dest)

        # Direct clone fallback (no cache, or cache failed)
        cmd = ["git", "clone"]
        if shallow:
            cmd.extend(["--depth", "1"])
        cmd.extend(["--branch", branch, clone_url, str(dest)])
        self._run_git(cmd, clone_url, url, token, name, env=git_env)
        logger.info("clone_repo_completed session_id=%s repo=%s path=%s", self.session_id, name, dest)
        return dest

    def _populate_cache(self, cache_path: Path, clone_url: str, url: str, branch: str, token: str | None, env: dict | None = None) -> None:
        """Full clone into the shared cache (no --depth so local copies work cleanly)."""
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        logger.info("repo_cache_populating path=%s branch=%s", cache_path, branch)
        self._run_git(
            ["git", "clone", "--branch", branch, clone_url, str(cache_path)],
            clone_url, url, token, cache_path.name, env=env,
        )
        logger.info("repo_cache_populated path=%s", cache_path)

    def _update_cache(self, cache_path: Path, clone_url: str, url: str, branch: str, token: str | None, env: dict | None = None) -> None:
        """Fetch latest changes into the existing cache directory."""
        logger.info("repo_cache_updating path=%s branch=%s", cache_path, branch)
        subprocess.run(
            ["git", "-C", str(cache_path), "remote", "set-url", "origin", clone_url],
            check=True, capture_output=True, timeout=10, env=env,
        )
        fetch_cmd = ["git", "-C", str(cache_path), "fetch", "--prune", "origin", branch]
        self._run_git(fetch_cmd, clone_url, url, token, cache_path.name, env=env)
        subprocess.run(
            ["git", "-C", str(cache_path), "reset", "--hard", f"origin/{branch}"],
            check=True, capture_output=True, timeout=10, env=env,
        )
        logger.info("repo_cache_updated path=%s", cache_path)

    def _run_git(self, cmd: list[str], clone_url: str, url: str, token: str | None, repo_name: str, env: dict | None = None) -> None:
        """Run a git command, redacting credentials from errors before logging."""
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=120, env=env)
        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr.decode("utf-8", errors="replace") if exc.stderr else ""
            if token and clone_url != url:
                stderr = stderr.replace(clone_url, url)
            logger.error(
                "git_cmd_failed repo=%s return_code=%s error=%s",
                repo_name, exc.returncode, stderr[:500],
            )
            raise RuntimeError(stderr[:500]) from exc
        except Exception:
            logger.exception("git_cmd_failed_unexpected repo=%s", repo_name)
            raise

    def _to_internal_url(self, url: str) -> str:
        """Replace external API base URL with internal Docker service URL.

        Agent CLI subprocesses run inside containers and can't reach the external
        HTTPS URL. This replaces the external base URL with the internal service URL
        so all agent types (Claude Code, Gemini, Codex) can reach MCP servers.
        """
        external = settings.api_base_url.rstrip("/")
        internal = settings.internal_api_url.rstrip("/")
        if external and internal and external != internal and url and url.startswith(external + "/"):
            return internal + url[len(external):]
        return url

    def write_mcp_config(self, mcp_servers: list[dict]) -> Path:
        """Generate .mcp.json for the agent session."""
        mcp_config = {"mcpServers": {}}

        for server in mcp_servers:
            slug = server["slug"]
            if server.get("transport") in ("http", "streamable-http"):
                http_cfg = {
                    "type": "http",
                    "url": self._to_internal_url(server["url"]),
                }
                if server.get("project_id"):
                    http_cfg["headers"] = {"X-Project-ID": str(server["project_id"])}
                mcp_config["mcpServers"][slug] = http_cfg
            else:
                server_config = {
                    "command": server["command"],
                    "args": server.get("args", []),
                }
                env = server.get("env", {})
                if env:
                    server_config["env"] = env
                mcp_config["mcpServers"][slug] = server_config

        config_path = self.workspace_path / ".mcp.json"
        config_path.write_text(json.dumps(mcp_config, indent=2))

        # Also write Gemini-compatible MCP config (.gemini/settings.json)
        gemini_mcp = {}
        for name, cfg in mcp_config["mcpServers"].items():
            if cfg.get("type") in ("http", "streamable-http"):
                gemini_mcp[name] = {"httpUrl": cfg["url"]}
                if cfg.get("headers"):
                    gemini_mcp[name]["headers"] = cfg["headers"]
            else:
                gemini_mcp[name] = {
                    "command": cfg.get("command", ""),
                    "args": cfg.get("args", []),
                    "env": cfg.get("env", {}),
                }
        gemini_dir = self.workspace_path / ".gemini"
        gemini_dir.mkdir(exist_ok=True)
        gemini_settings = {"mcpServers": gemini_mcp}
        (gemini_dir / "settings.json").write_text(json.dumps(gemini_settings, indent=2))

        # Also write Codex-compatible MCP config (.codex/config.toml)
        # Codex reads project-scoped config from .codex/config.toml in CWD.
        # This is the only source of MCP servers for Codex — no global definitions.
        codex_lines = []
        for name, cfg in mcp_config["mcpServers"].items():
            codex_lines.append(f"[mcp_servers.{name}]")
            if cfg.get("type") in ("http", "streamable-http", "sse"):
                url = cfg["url"]
                # Codex doesn't support custom HTTP headers — embed project_id as
                # a query param instead so the MCP middleware can read it.
                project_id = (cfg.get("headers") or {}).get("X-Project-ID")
                if project_id:
                    url = f"{url}?project_id={project_id}"
                codex_lines.append(f'url = "{url}"')
            else:
                codex_lines.append(f'command = "{cfg["command"]}"')
                if cfg.get("args"):
                    args_toml = ", ".join(f'"{a}"' for a in cfg["args"])
                    codex_lines.append(f"args = [{args_toml}]")
                if cfg.get("env"):
                    env_pairs = ", ".join(f'{k} = "{v}"' for k, v in cfg["env"].items())
                    codex_lines.append(f"env = {{{env_pairs}}}")
            codex_lines.append("")
        codex_dir = self.workspace_path / ".codex"
        codex_dir.mkdir(exist_ok=True)
        (codex_dir / "config.toml").write_text("\n".join(codex_lines))

        logger.debug("mcp_config_written session_id=%s path=%s servers=%s", self.session_id, config_path, len(mcp_servers))
        return config_path

    def write_system_prompt_file(self, prompt: str) -> Path:
        """Write the effective system prompt to system_prompt.md in workspace.

        Used by Codex (experimental_instructions_file) and Gemini (GEMINI_SYSTEM_MD).
        Claude Code uses --append-system-prompt directly without a file.
        """
        path = self.workspace_path / "system_prompt.md"
        path.write_text(prompt)
        logger.debug("system_prompt_file_written session_id=%s path=%s", self.session_id, path)
        return path

    def cleanup(self):
        """Remove workspace directory."""
        if self.workspace_path.exists():
            shutil.rmtree(self.workspace_path, ignore_errors=True)
            logger.debug("workspace_cleaned session_id=%s path=%s", self.session_id, self.workspace_path)

    def get_raw_output_path(self) -> Path:
        """Path for raw agent output."""
        path = self.workspace_path / "raw_output.jsonl"
        return path
