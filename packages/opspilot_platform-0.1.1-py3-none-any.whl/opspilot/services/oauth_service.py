import base64
import hashlib
import json
import logging
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.config import settings
from opspilot.models import ConnectedAccount, NotificationChannel, NotificationChannelType, OAuthState
from opspilot.schemas import OAuthInitiateResponse

logger = logging.getLogger(__name__)

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_REVOKE_URL = "https://oauth2.googleapis.com/revoke"

JIRA_AUTH_URL = "https://auth.atlassian.com/authorize"
JIRA_TOKEN_URL = "https://auth.atlassian.com/oauth/token"
JIRA_RESOURCES_URL = "https://api.atlassian.com/oauth/token/accessible-resources"

JIRA_SCOPES = [
    "read:jira-work",
    "write:jira-work",
    "read:jira-user",
    "offline_access",
]

# Confluence uses the same Atlassian OAuth endpoints and credentials as Jira
CONFLUENCE_SCOPES = [
    "read:confluence-space.summary",
    "read:confluence-content.all",
    "write:confluence-content",
    "read:confluence-user",
    "offline_access",
]

MICROSOFT_TOKEN_URL_TEMPLATE = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
MICROSOFT_AUTH_URL_TEMPLATE = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
MICROSOFT_GRAPH_ME_URL = "https://graph.microsoft.com/v1.0/me"

MICROSOFT_SCOPES = [
    "openid",
    "profile",
    "email",
    "offline_access",
    "User.Read",
    "Mail.Read",
    "Calendars.ReadWrite",
    "Files.ReadWrite.All",
]

SLACK_AUTH_URL = "https://slack.com/oauth/v2/authorize"
SLACK_TOKEN_URL = "https://slack.com/api/oauth.v2.access"
SLACK_REVOKE_URL = "https://slack.com/api/auth.revoke"

SLACK_BOT_SCOPES = [
    "channels:read", "channels:history",
    "groups:read", "groups:history",
    "im:read", "im:history",
    "mpim:read", "mpim:history",
    "users:read",
    "chat:write", "app_mentions:read", "assistant:write",
]

# User scopes — issued as xoxp- token, used for silent reads on behalf of the user
SLACK_USER_SCOPES = [
    "channels:history",
    "groups:history",
    "im:history",
    "mpim:history",
    "channels:read",
    "groups:read",
    "users:read",
    "search:read",
]

GOOGLE_SCOPES_GMAIL = [
    "https://www.googleapis.com/auth/gmail.readonly",
]

GOOGLE_SCOPES_CALENDAR = [
    "https://www.googleapis.com/auth/calendar",
]

GOOGLE_SCOPES_DRIVE = [
    "https://www.googleapis.com/auth/drive",
]

GOOGLE_SCOPES = [
    "openid",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/drive",
]

_STATE_TTL_MINUTES = 10
_TOKEN_REFRESH_BUFFER_MINUTES = 5


# --- Token Encryption ---


def _fernet():
    from cryptography.fernet import Fernet

    key = settings.oauth_encryption_key
    if not key:
        raise ValueError("OPSPILOT_OAUTH_ENCRYPTION_KEY is not set")
    return Fernet(key.encode() if isinstance(key, str) else key)


def encrypt_token(token: str) -> str:
    return _fernet().encrypt(token.encode()).decode()


def decrypt_token(encrypted: str) -> str:
    return _fernet().decrypt(encrypted.encode()).decode()


# --- PKCE (RFC 7636) ---


def generate_pkce() -> tuple[str, str]:
    """Return (code_verifier, code_challenge)."""
    verifier = base64.urlsafe_b64encode(os.urandom(64)).rstrip(b"=").decode()
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
    return verifier, challenge


# --- JWT decode (no signature verification — response is trusted from Google) ---


def _decode_id_token_claims(id_token: str) -> dict:
    parts = id_token.split(".")
    if len(parts) < 2:
        return {}
    payload = parts[1]
    # Add padding
    payload += "=" * (4 - len(payload) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(payload))
    except Exception:
        return {}


# --- Google OAuth Flow ---


def _google_redirect_uri() -> str:
    base = settings.oauth_callback_base_url or settings.api_base_url
    return f"{base}/api/oauth/callback/google"


async def initiate_google_oauth(db: AsyncSession, project_id: uuid.UUID, redirect_to: str) -> OAuthInitiateResponse:
    state = secrets.token_urlsafe(32)
    verifier, challenge = generate_pkce()

    oauth_state = OAuthState(
        state=state,
        provider="google",
        project_id=project_id,
        code_verifier=verifier,
        redirect_to=redirect_to,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=_STATE_TTL_MINUTES),
    )
    db.add(oauth_state)
    await db.commit()

    params = {
        "client_id": settings.google_oauth_client_id,
        "redirect_uri": _google_redirect_uri(),
        "response_type": "code",
        "scope": " ".join(GOOGLE_SCOPES),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "access_type": "offline",
        "prompt": "consent",
    }
    authorization_url = f"{GOOGLE_AUTH_URL}?{urlencode(params)}"
    logger.info("oauth_initiate_google state=%s redirect_to=%s", state, redirect_to)
    return OAuthInitiateResponse(authorization_url=authorization_url, state=state)


async def handle_google_callback(db: AsyncSession, code: str, state: str) -> ConnectedAccount:
    # Load and validate state
    result = await db.execute(select(OAuthState).where(OAuthState.state == state))
    oauth_state = result.scalar_one_or_none()
    if not oauth_state:
        raise ValueError("Invalid or expired OAuth state")
    if oauth_state.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        await db.delete(oauth_state)
        await db.commit()
        raise ValueError("OAuth state has expired — please try again")

    # Exchange code for tokens
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            GOOGLE_TOKEN_URL,
            data={
                "code": code,
                "client_id": settings.google_oauth_client_id,
                "client_secret": settings.google_oauth_client_secret,
                "redirect_uri": _google_redirect_uri(),
                "code_verifier": oauth_state.code_verifier,
                "grant_type": "authorization_code",
            },
            timeout=15,
        )
        resp.raise_for_status()
        token_data = resp.json()

    access_token = token_data["access_token"]
    refresh_token = token_data.get("refresh_token")
    expires_in = token_data.get("expires_in", 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
    granted_scopes = token_data.get("scope", "").split()

    # Extract email from id_token
    claims = _decode_id_token_claims(token_data.get("id_token", ""))
    provider_email = claims.get("email", "")
    provider_account_id = claims.get("sub", "")

    if not provider_email:
        raise ValueError("Could not extract email from Google id_token")

    # Upsert: update if account already connected for this project, else insert
    project_id = oauth_state.project_id
    existing = await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.project_id == project_id,
            ConnectedAccount.provider == "google",
            ConnectedAccount.provider_email == provider_email,
        )
    )
    account = existing.scalar_one_or_none()

    if account:
        account.access_token = encrypt_token(access_token)
        if refresh_token:
            account.refresh_token = encrypt_token(refresh_token)
        account.expires_at = expires_at
        account.scopes = granted_scopes
        account.status = "active"
        account.error_message = None
        account.provider_account_id = provider_account_id
    else:
        account = ConnectedAccount(
            project_id=project_id,
            provider="google",
            provider_email=provider_email,
            provider_account_id=provider_account_id,
            scopes=granted_scopes,
            access_token=encrypt_token(access_token),
            refresh_token=encrypt_token(refresh_token) if refresh_token else None,
            expires_at=expires_at,
            status="active",
        )
        db.add(account)

    await db.delete(oauth_state)
    await db.commit()
    await db.refresh(account)
    logger.info("oauth_callback_success provider=google email=%s", provider_email)
    return account


# --- Jira (Atlassian) OAuth Flow ---


def _jira_redirect_uri() -> str:
    base = settings.oauth_callback_base_url or settings.api_base_url
    return f"{base}/api/oauth/callback/jira"


async def initiate_jira_oauth(db: AsyncSession, project_id: uuid.UUID, redirect_to: str) -> OAuthInitiateResponse:
    state = secrets.token_urlsafe(32)
    verifier, challenge = generate_pkce()

    oauth_state = OAuthState(
        state=state,
        provider="jira",
        project_id=project_id,
        code_verifier=verifier,
        redirect_to=redirect_to,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=_STATE_TTL_MINUTES),
    )
    db.add(oauth_state)
    await db.commit()

    params = {
        "client_id": settings.jira_client_id,
        "redirect_uri": _jira_redirect_uri(),
        "response_type": "code",
        "scope": " ".join(JIRA_SCOPES),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "audience": "api.atlassian.com",
        "prompt": "consent",
    }
    authorization_url = f"{JIRA_AUTH_URL}?{urlencode(params)}"
    logger.info("oauth_initiate_jira state=%s redirect_to=%s", state, redirect_to)
    return OAuthInitiateResponse(authorization_url=authorization_url, state=state)


async def handle_jira_callback(db: AsyncSession, code: str, state: str) -> ConnectedAccount:
    # Load and validate state
    result = await db.execute(select(OAuthState).where(OAuthState.state == state))
    oauth_state = result.scalar_one_or_none()
    if not oauth_state:
        raise ValueError("Invalid or expired OAuth state")
    if oauth_state.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        await db.delete(oauth_state)
        await db.commit()
        raise ValueError("OAuth state has expired — please try again")

    # Exchange code for tokens (Atlassian expects JSON body)
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            JIRA_TOKEN_URL,
            json={
                "grant_type": "authorization_code",
                "client_id": settings.jira_client_id,
                "client_secret": settings.jira_client_secret,
                "code": code,
                "redirect_uri": _jira_redirect_uri(),
                "code_verifier": oauth_state.code_verifier,
            },
            timeout=15,
        )
        resp.raise_for_status()
        token_data = resp.json()

    access_token = token_data["access_token"]
    refresh_token = token_data.get("refresh_token")
    expires_in = token_data.get("expires_in", 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
    granted_scopes = token_data.get("scope", "").split()

    # Fetch accessible resources to get cloud_id and site info
    async with httpx.AsyncClient() as client:
        res_resp = await client.get(
            JIRA_RESOURCES_URL,
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=15,
        )
        res_resp.raise_for_status()
        resources = res_resp.json()

    if not resources:
        raise ValueError("No accessible Jira sites found for this Atlassian account")

    # Use the first accessible site
    site = resources[0]
    cloud_id = site["id"]
    site_name = site.get("name", "Jira")
    site_url = site.get("url", "")

    # Upsert: update if same project + jira + cloud_id, else insert
    project_id = oauth_state.project_id
    existing = await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.project_id == project_id,
            ConnectedAccount.provider == "jira",
            ConnectedAccount.provider_account_id == cloud_id,
        )
    )
    account = existing.scalar_one_or_none()

    metadata = {"cloud_id": cloud_id, "site_url": site_url}

    if account:
        account.access_token = encrypt_token(access_token)
        if refresh_token:
            account.refresh_token = encrypt_token(refresh_token)
        account.expires_at = expires_at
        account.scopes = granted_scopes
        account.status = "active"
        account.error_message = None
        account.provider_email = site_name
        account.provider_metadata = metadata
    else:
        account = ConnectedAccount(
            project_id=project_id,
            provider="jira",
            provider_email=site_name,
            provider_account_id=cloud_id,
            scopes=granted_scopes,
            access_token=encrypt_token(access_token),
            refresh_token=encrypt_token(refresh_token) if refresh_token else None,
            expires_at=expires_at,
            status="active",
            provider_metadata=metadata,
        )
        db.add(account)

    await db.delete(oauth_state)
    await db.commit()
    await db.refresh(account)
    logger.info("oauth_callback_success provider=jira site=%s cloud_id=%s", site_name, cloud_id)
    return account


# --- Confluence (Atlassian) OAuth Flow ---


def _confluence_redirect_uri() -> str:
    base = settings.oauth_callback_base_url or settings.api_base_url
    return f"{base}/api/oauth/callback/confluence"


async def initiate_confluence_oauth(db: AsyncSession, project_id: uuid.UUID, redirect_to: str) -> OAuthInitiateResponse:
    state = secrets.token_urlsafe(32)
    verifier, challenge = generate_pkce()

    oauth_state = OAuthState(
        state=state,
        provider="confluence",
        project_id=project_id,
        code_verifier=verifier,
        redirect_to=redirect_to,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=_STATE_TTL_MINUTES),
    )
    db.add(oauth_state)
    await db.commit()

    params = {
        "client_id": settings.jira_client_id,
        "redirect_uri": _confluence_redirect_uri(),
        "response_type": "code",
        "scope": " ".join(CONFLUENCE_SCOPES),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "audience": "api.atlassian.com",
        "prompt": "consent",
    }
    authorization_url = f"{JIRA_AUTH_URL}?{urlencode(params)}"
    logger.info("oauth_initiate_confluence state=%s redirect_to=%s", state, redirect_to)
    return OAuthInitiateResponse(authorization_url=authorization_url, state=state)


async def handle_confluence_callback(db: AsyncSession, code: str, state: str) -> ConnectedAccount:
    result = await db.execute(select(OAuthState).where(OAuthState.state == state))
    oauth_state = result.scalar_one_or_none()
    if not oauth_state:
        raise ValueError("Invalid or expired OAuth state")
    if oauth_state.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        await db.delete(oauth_state)
        await db.commit()
        raise ValueError("OAuth state has expired — please try again")

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            JIRA_TOKEN_URL,
            json={
                "grant_type": "authorization_code",
                "client_id": settings.jira_client_id,
                "client_secret": settings.jira_client_secret,
                "code": code,
                "redirect_uri": _confluence_redirect_uri(),
                "code_verifier": oauth_state.code_verifier,
            },
            timeout=15,
        )
        resp.raise_for_status()
        token_data = resp.json()

    access_token = token_data["access_token"]
    refresh_token = token_data.get("refresh_token")
    expires_in = token_data.get("expires_in", 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
    granted_scopes = token_data.get("scope", "").split()

    async with httpx.AsyncClient() as client:
        res_resp = await client.get(
            JIRA_RESOURCES_URL,
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=15,
        )
        res_resp.raise_for_status()
        resources = res_resp.json()

    if not resources:
        raise ValueError("No accessible Atlassian sites found for this account")

    site = resources[0]
    cloud_id = site["id"]
    site_name = site.get("name", "Confluence")
    site_url = site.get("url", "")

    project_id = oauth_state.project_id
    existing = await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.project_id == project_id,
            ConnectedAccount.provider == "confluence",
            ConnectedAccount.provider_account_id == cloud_id,
        )
    )
    account = existing.scalar_one_or_none()

    metadata = {"cloud_id": cloud_id, "site_url": site_url}

    if account:
        account.access_token = encrypt_token(access_token)
        if refresh_token:
            account.refresh_token = encrypt_token(refresh_token)
        account.expires_at = expires_at
        account.scopes = granted_scopes
        account.status = "active"
        account.error_message = None
        account.provider_email = site_name
        account.provider_metadata = metadata
    else:
        account = ConnectedAccount(
            project_id=project_id,
            provider="confluence",
            provider_email=site_name,
            provider_account_id=cloud_id,
            scopes=granted_scopes,
            access_token=encrypt_token(access_token),
            refresh_token=encrypt_token(refresh_token) if refresh_token else None,
            expires_at=expires_at,
            status="active",
            provider_metadata=metadata,
        )
        db.add(account)

    await db.delete(oauth_state)
    await db.commit()
    await db.refresh(account)
    logger.info("oauth_callback_success provider=confluence site=%s cloud_id=%s", site_name, cloud_id)
    return account


# --- Microsoft (Entra ID) OAuth Flow ---


def _microsoft_redirect_uri() -> str:
    base = settings.oauth_callback_base_url or settings.api_base_url
    return f"{base}/api/oauth/callback/microsoft"


def _microsoft_auth_url() -> str:
    tenant = settings.microsoft_oauth_tenant or "common"
    return MICROSOFT_AUTH_URL_TEMPLATE.format(tenant=tenant)


def _microsoft_token_url() -> str:
    tenant = settings.microsoft_oauth_tenant or "common"
    return MICROSOFT_TOKEN_URL_TEMPLATE.format(tenant=tenant)


async def initiate_microsoft_oauth(db: AsyncSession, project_id: uuid.UUID, redirect_to: str) -> OAuthInitiateResponse:
    state = secrets.token_urlsafe(32)
    verifier, challenge = generate_pkce()

    oauth_state = OAuthState(
        state=state,
        provider="microsoft",
        project_id=project_id,
        code_verifier=verifier,
        redirect_to=redirect_to,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=_STATE_TTL_MINUTES),
    )
    db.add(oauth_state)
    await db.commit()

    params = {
        "client_id": settings.microsoft_oauth_client_id,
        "redirect_uri": _microsoft_redirect_uri(),
        "response_type": "code",
        "scope": " ".join(MICROSOFT_SCOPES),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "response_mode": "query",
        "prompt": "consent",
    }
    authorization_url = f"{_microsoft_auth_url()}?{urlencode(params)}"
    logger.info("oauth_initiate_microsoft state=%s redirect_to=%s", state, redirect_to)
    return OAuthInitiateResponse(authorization_url=authorization_url, state=state)


async def handle_microsoft_callback(db: AsyncSession, code: str, state: str) -> ConnectedAccount:
    # Load and validate state
    result = await db.execute(select(OAuthState).where(OAuthState.state == state))
    oauth_state = result.scalar_one_or_none()
    if not oauth_state:
        raise ValueError("Invalid or expired OAuth state")
    if oauth_state.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        await db.delete(oauth_state)
        await db.commit()
        raise ValueError("OAuth state has expired — please try again")

    # Exchange code for tokens
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            _microsoft_token_url(),
            data={
                "code": code,
                "client_id": settings.microsoft_oauth_client_id,
                "client_secret": settings.microsoft_oauth_client_secret,
                "redirect_uri": _microsoft_redirect_uri(),
                "code_verifier": oauth_state.code_verifier,
                "grant_type": "authorization_code",
            },
            timeout=15,
        )
        resp.raise_for_status()
        token_data = resp.json()

    access_token = token_data["access_token"]
    refresh_token = token_data.get("refresh_token")
    expires_in = token_data.get("expires_in", 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
    granted_scopes = token_data.get("scope", "").split()

    # Get user email from Microsoft Graph /me endpoint
    async with httpx.AsyncClient() as client:
        me_resp = await client.get(
            MICROSOFT_GRAPH_ME_URL,
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=15,
        )
        me_resp.raise_for_status()
        me_data = me_resp.json()

    provider_email = me_data.get("mail") or me_data.get("userPrincipalName", "")
    provider_account_id = me_data.get("id", "")

    if not provider_email:
        raise ValueError("Could not extract email from Microsoft Graph /me")

    # Upsert: update if account already connected for this project, else insert
    project_id = oauth_state.project_id
    existing = await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.project_id == project_id,
            ConnectedAccount.provider == "microsoft",
            ConnectedAccount.provider_email == provider_email,
        )
    )
    account = existing.scalar_one_or_none()

    if account:
        account.access_token = encrypt_token(access_token)
        if refresh_token:
            account.refresh_token = encrypt_token(refresh_token)
        account.expires_at = expires_at
        account.scopes = granted_scopes
        account.status = "active"
        account.error_message = None
        account.provider_account_id = provider_account_id
    else:
        account = ConnectedAccount(
            project_id=project_id,
            provider="microsoft",
            provider_email=provider_email,
            provider_account_id=provider_account_id,
            scopes=granted_scopes,
            access_token=encrypt_token(access_token),
            refresh_token=encrypt_token(refresh_token) if refresh_token else None,
            expires_at=expires_at,
            status="active",
        )
        db.add(account)

    await db.delete(oauth_state)
    await db.commit()
    await db.refresh(account)
    logger.info("oauth_callback_success provider=microsoft email=%s", provider_email)
    return account


# --- Slack OAuth Flow ---


def _slack_redirect_uri() -> str:
    base = settings.oauth_callback_base_url or settings.api_base_url
    return f"{base}/api/oauth/callback/slack"


async def initiate_slack_oauth(db: AsyncSession, project_id: uuid.UUID, redirect_to: str) -> OAuthInitiateResponse:
    state = secrets.token_urlsafe(32)

    oauth_state = OAuthState(
        state=state,
        provider="slack",
        project_id=project_id,
        code_verifier="n/a",  # Slack doesn't use PKCE
        redirect_to=redirect_to,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=_STATE_TTL_MINUTES),
    )
    db.add(oauth_state)
    await db.commit()

    params = {
        "client_id": settings.slack_client_id,
        "scope": ",".join(SLACK_BOT_SCOPES),
        "user_scope": ",".join(SLACK_USER_SCOPES),
        "redirect_uri": _slack_redirect_uri(),
        "state": state,
    }
    authorization_url = f"{SLACK_AUTH_URL}?{urlencode(params)}"
    logger.info("oauth_initiate_slack state=%s redirect_to=%s", state, redirect_to)
    return OAuthInitiateResponse(authorization_url=authorization_url, state=state)


async def handle_slack_callback(db: AsyncSession, code: str, state: str) -> ConnectedAccount:
    # Load and validate state
    result = await db.execute(select(OAuthState).where(OAuthState.state == state))
    oauth_state = result.scalar_one_or_none()
    if not oauth_state:
        raise ValueError("Invalid or expired OAuth state")
    if oauth_state.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        await db.delete(oauth_state)
        await db.commit()
        raise ValueError("OAuth state has expired — please try again")

    # Exchange code for bot token
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            SLACK_TOKEN_URL,
            data={
                "code": code,
                "client_id": settings.slack_client_id,
                "client_secret": settings.slack_client_secret,
                "redirect_uri": _slack_redirect_uri(),
            },
            timeout=15,
        )
        resp.raise_for_status()
        token_data = resp.json()

    if not token_data.get("ok"):
        error = token_data.get("error", "unknown_error")
        raise ValueError(f"Slack OAuth failed: {error}")

    access_token = token_data["access_token"]  # bot token (xoxb-)
    granted_scopes = token_data.get("scope", "").split(",")
    team = token_data.get("team", {})
    team_name = team.get("name", "Unknown Workspace")
    team_id = team.get("id", "")

    # User token (xoxp-) — present when user_scope was requested in the authorization URL
    authed_user = token_data.get("authed_user", {})
    user_token = authed_user.get("access_token")
    logger.info("oauth_slack_user_token_received has_user_token=%s", bool(user_token))

    # Upsert: update if same project + slack + team, else insert
    project_id = oauth_state.project_id
    existing = await db.execute(
        select(ConnectedAccount).where(
            ConnectedAccount.project_id == project_id,
            ConnectedAccount.provider == "slack",
            ConnectedAccount.provider_account_id == team_id,
        )
    )
    account = existing.scalar_one_or_none()

    if account:
        account.access_token = encrypt_token(access_token)
        account.user_access_token = encrypt_token(user_token) if user_token else None
        account.scopes = granted_scopes
        account.status = "active"
        account.error_message = None
        account.provider_email = team_name
    else:
        account = ConnectedAccount(
            project_id=project_id,
            provider="slack",
            provider_email=team_name,  # workspace name
            provider_account_id=team_id,
            scopes=granted_scopes,
            access_token=encrypt_token(access_token),
            user_access_token=encrypt_token(user_token) if user_token else None,
            refresh_token=None,  # bot tokens don't expire
            expires_at=None,
            status="active",
        )
        db.add(account)

    await db.delete(oauth_state)
    await db.commit()
    await db.refresh(account)
    logger.info("oauth_callback_success provider=slack workspace=%s team_id=%s", team_name, team_id)
    return account


async def get_valid_access_token(db: AsyncSession, account_id: uuid.UUID) -> str:
    result = await db.execute(select(ConnectedAccount).where(ConnectedAccount.id == account_id))
    account = result.scalar_one_or_none()
    if not account:
        raise ValueError(f"Connected account {account_id} not found")
    if account.status != "active":
        raise ValueError(f"Connected account is {account.status} — please reconnect")

    # Check if refresh needed (5 min buffer)
    needs_refresh = (
        account.expires_at is None
        or account.expires_at.replace(tzinfo=timezone.utc) - datetime.now(timezone.utc)
        < timedelta(minutes=_TOKEN_REFRESH_BUFFER_MINUTES)
    )

    if needs_refresh and account.refresh_token:
        try:
            refresh_payload = {
                "refresh_token": decrypt_token(account.refresh_token),
                "grant_type": "refresh_token",
            }
            if account.provider in ("jira", "confluence"):
                token_url = JIRA_TOKEN_URL
                refresh_payload["client_id"] = settings.jira_client_id
                refresh_payload["client_secret"] = settings.jira_client_secret
            elif account.provider == "microsoft":
                tenant = settings.microsoft_oauth_tenant or "common"
                token_url = MICROSOFT_TOKEN_URL_TEMPLATE.format(tenant=tenant)
                refresh_payload["client_id"] = settings.microsoft_oauth_client_id
                refresh_payload["client_secret"] = settings.microsoft_oauth_client_secret
            else:
                token_url = GOOGLE_TOKEN_URL
                refresh_payload["client_id"] = settings.google_oauth_client_id
                refresh_payload["client_secret"] = settings.google_oauth_client_secret

            async with httpx.AsyncClient() as client:
                if account.provider in ("jira", "confluence"):
                    resp = await client.post(token_url, json=refresh_payload, timeout=15)
                else:
                    resp = await client.post(token_url, data=refresh_payload, timeout=15)
                resp.raise_for_status()
                token_data = resp.json()

            account.access_token = encrypt_token(token_data["access_token"])
            expires_in = token_data.get("expires_in", 3600)
            account.expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
            if token_data.get("refresh_token"):
                account.refresh_token = encrypt_token(token_data["refresh_token"])
            account.status = "active"
            await db.commit()
            logger.info("oauth_token_refreshed account_id=%s", account_id)
        except Exception as e:
            account.status = "error"
            account.error_message = f"Token refresh failed: {str(e)[:200]}"
            await db.commit()
            raise ValueError(f"Token refresh failed for account {account_id}: {e}") from e

    return decrypt_token(account.access_token)


async def revoke_account(db: AsyncSession, account_id: uuid.UUID) -> None:
    result = await db.execute(select(ConnectedAccount).where(ConnectedAccount.id == account_id))
    account = result.scalar_one_or_none()
    if not account:
        return

    # Best-effort revoke at provider
    if account.provider == "whatsapp":
        # No remote token to revoke — neonize session cleanup handled by adapter.
        # Delete the associated notification channel (keyed by JID).
        jid = account.provider_account_id
        if jid:
            user_part = jid.split("@")[0].split(":")[0]
            server_part = jid.split("@")[1] if "@" in jid else "s.whatsapp.net"
            clean_jid = f"{user_part}@{server_part}"
            from sqlalchemy import delete as sa_delete
            await db.execute(
                sa_delete(NotificationChannel).where(
                    NotificationChannel.project_id == account.project_id,
                    NotificationChannel.channel_type == NotificationChannelType.WHATSAPP,
                    NotificationChannel.config["jid"].astext == clean_jid,
                )
            )
    elif account.provider in ("jira", "confluence"):
        pass  # Atlassian has no token revocation endpoint
    elif account.provider == "microsoft":
        pass  # Microsoft has no simple token revocation endpoint
    else:
        try:
            token = decrypt_token(account.access_token)
            async with httpx.AsyncClient() as client:
                if account.provider == "slack":
                    await client.get(
                        SLACK_REVOKE_URL,
                        headers={"Authorization": f"Bearer {token}"},
                        timeout=10,
                    )
                else:
                    await client.post(GOOGLE_REVOKE_URL, params={"token": token}, timeout=10)
        except Exception as e:
            logger.warning("oauth_revoke_failed account_id=%s provider=%s error=%s", account_id, account.provider, e)

    await db.delete(account)
    await db.commit()
    logger.info("oauth_account_deleted account_id=%s provider=%s", account_id, account.provider)


async def get_first_active_account(
    db: AsyncSession, project_id: uuid.UUID, provider: str = "google",
) -> ConnectedAccount | None:
    result = await db.execute(
        select(ConnectedAccount)
        .where(
            ConnectedAccount.project_id == project_id,
            ConnectedAccount.provider == provider,
            ConnectedAccount.status == "active",
        )
        .order_by(ConnectedAccount.created_at)
        .limit(1)
    )
    return result.scalar_one_or_none()
