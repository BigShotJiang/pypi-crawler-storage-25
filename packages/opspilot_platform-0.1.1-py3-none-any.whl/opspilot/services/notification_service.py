import asyncio
import functools
import uuid
import logging

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.config import settings
from opspilot.models import NotificationChannel, NotificationChannelType, NotificationLog, ProjectSettings
from opspilot.services.notification import (
    send_email_notification as _send_email,
    send_pushover_notification,
    send_telegram_notification,
    send_whatsapp_notification,
)

logger = logging.getLogger(__name__)


async def _get_project_settings(db: AsyncSession, project_id: uuid.UUID) -> ProjectSettings | None:
    """Get the ProjectSettings ORM object for a project."""
    result = await db.execute(
        select(ProjectSettings).where(ProjectSettings.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def list_notification_logs(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    session_id: uuid.UUID | None = None,
    channel_type: NotificationChannelType | None = None,
    status: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[NotificationLog]:
    """List notification logs scoped to a project."""
    stmt = (
        select(NotificationLog)
        .where(NotificationLog.project_id == project_id)
        .order_by(NotificationLog.sent_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if session_id:
        stmt = stmt.where(NotificationLog.session_id == session_id)
    if channel_type:
        stmt = stmt.where(NotificationLog.channel_type == channel_type)
    if status:
        stmt = stmt.where(NotificationLog.status == status)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def send_slack(
    db: AsyncSession,
    project_id: uuid.UUID,
    title: str,
    description: str,
    *,
    session_id: uuid.UUID | None = None,
) -> dict:
    """Send a Slack notification to all enabled Slack channels.

    Returns a dict with status, title, sent count, and failed count.
    """
    result = await db.execute(
        select(NotificationChannel).where(
            NotificationChannel.project_id == project_id,
            NotificationChannel.channel_type == NotificationChannelType.SLACK,
            NotificationChannel.enabled == True,  # noqa: E712
        )
    )
    channels = result.scalars().all()
    if not channels:
        return {"error": "No enabled Slack channel configured in notification channels"}

    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": title, "emoji": True}},
        {"type": "section", "text": {"type": "mrkdwn", "text": description[:3000]}},
    ]
    payload = {"blocks": blocks}

    sent, failed = 0, 0
    async with httpx.AsyncClient() as client:
        for channel in channels:
            webhook_url = (channel.config or {}).get("webhook_url")
            if not webhook_url:
                continue

            log = NotificationLog(
                project_id=project_id,
                session_id=session_id,
                channel_type=NotificationChannelType.SLACK,
                title=title,
                content=description[:5000],
                recipient=channel.name[:100],
            )
            try:
                resp = await client.post(webhook_url, json=payload, timeout=10)
                resp.raise_for_status()
                log.status = "sent"
                sent += 1
                logger.info("slack_notification_sent channel=%s title=%s", channel.name, title)
            except Exception as e:
                log.status = "failed"
                log.error_message = str(e)[:1000]
                failed += 1
                logger.error("slack_notification_failed channel=%s error=%s", channel.name, str(e))
            db.add(log)

    return {"status": "sent" if sent > 0 else "failed", "title": title, "sent": sent, "failed": failed}


async def send_email(
    db: AsyncSession,
    project_id: uuid.UUID,
    subject: str,
    body_html: str,
    *,
    session_id: uuid.UUID | None = None,
) -> dict:
    """Send an email notification to configured recipients.

    Returns a dict with status, subject, and recipient count.
    """
    ps = await _get_project_settings(db, project_id)

    recipients_str = (ps.email_recipients if ps else None) or settings.smtp_from_email
    if not recipients_str:
        return {"error": "No email_recipients configured"}

    recipients = [r.strip() for r in recipients_str.split(",") if r.strip()]
    if not recipients:
        return {"error": "No valid email recipients found"}

    smtp_config = {
        "smtp_host":       (ps.smtp_host if ps else None) or settings.smtp_host,
        "smtp_port":       (ps.smtp_port if ps else None) or settings.smtp_port,
        "smtp_username":   (ps.smtp_username if ps else None) or settings.smtp_username,
        "smtp_password":   (ps.smtp_password if ps else None) or settings.smtp_password,
        "smtp_from_email": (ps.smtp_from_email if ps else None) or settings.smtp_from_email,
        "smtp_use_tls":    ps.smtp_use_tls if ps else settings.smtp_use_tls,
    }

    logger.info(
        "smtp_config_prepared host=%s user=%s port=%s",
        smtp_config["smtp_host"], smtp_config["smtp_username"], smtp_config["smtp_port"],
    )

    log = NotificationLog(
        project_id=project_id,
        session_id=session_id,
        channel_type=NotificationChannelType.EMAIL,
        title=subject,
        content=body_html[:5000],
        recipient=", ".join(recipients[:5]),
    )

    finding_dict = {"title": subject, "summary": body_html, "severity": "info", "finding_type": "recommendation"}
    loop = asyncio.get_event_loop()
    success, error_msg = await loop.run_in_executor(
        None,
        functools.partial(
            _send_email,
            recipients=recipients,
            finding=finding_dict,
            session_id=str(session_id) if session_id else None,
            task_name="OpsPilot Agent",
            smtp_config=smtp_config,
        ),
    )

    log.status = "sent" if success else "failed"
    if not success:
        log.error_message = error_msg or "SMTP send failed -- check server configuration"

    db.add(log)
    logger.info("email_notification_%s subject=%s", log.status, subject)

    response: dict = {"status": log.status, "subject": subject, "recipients": len(recipients)}
    if error_msg:
        response["error"] = error_msg
    return response


async def send_pushover(
    db: AsyncSession,
    project_id: uuid.UUID,
    title: str,
    message: str,
    *,
    session_id: uuid.UUID | None = None,
) -> dict:
    """Send a Pushover push notification.

    Returns a dict with status and title.
    """
    ps = await _get_project_settings(db, project_id)
    token = ps.pushover_token if ps else None
    user = ps.pushover_user if ps else None
    if not token or not user:
        return {"error": "pushover_token and pushover_user must be configured in Settings"}

    log = NotificationLog(
        project_id=project_id,
        session_id=session_id,
        channel_type=NotificationChannelType.PUSHOVER,
        title=title,
        content=message[:5000],
        recipient=user[:100],
    )

    success, error_msg = await send_pushover_notification(token=token, user=user, title=title, message=message)
    log.status = "sent" if success else "failed"
    if not success:
        log.error_message = error_msg or "Pushover API request failed"

    db.add(log)
    logger.info("pushover_notification_%s title=%s", log.status, title)

    response: dict = {"status": log.status, "title": title}
    if error_msg:
        response["error"] = error_msg
    return response


async def send_telegram(
    db: AsyncSession,
    project_id: uuid.UUID,
    title: str,
    message: str,
    *,
    session_id: uuid.UUID | None = None,
    reply_markup: dict | None = None,
) -> dict:
    """Send a Telegram notification to all enabled Telegram channels.

    Returns a dict with status, title, sent count, and failed count.
    """
    ps = await _get_project_settings(db, project_id)
    bot_token = ps.telegram_bot_token if ps else None
    if not bot_token:
        return {"error": "telegram_bot_token must be configured in Settings"}

    result = await db.execute(
        select(NotificationChannel).where(
            NotificationChannel.project_id == project_id,
            NotificationChannel.channel_type == NotificationChannelType.TELEGRAM,
            NotificationChannel.enabled == True,  # noqa: E712
        )
    )
    channels = result.scalars().all()
    if not channels:
        return {"error": "No enabled Telegram channel configured in notification channels"}

    text = f"<b>{title}</b>\n\n{message}"

    sent, failed = 0, 0
    for channel in channels:
        chat_id = (channel.config or {}).get("chat_id")
        if not chat_id:
            continue

        log = NotificationLog(
            project_id=project_id,
            session_id=session_id,
            channel_type=NotificationChannelType.TELEGRAM,
            title=title,
            content=message[:5000],
            recipient=str(chat_id),
        )

        success, error_msg, _ = await send_telegram_notification(
            bot_token=bot_token, chat_id=str(chat_id), text=text, reply_markup=reply_markup,
        )
        log.status = "sent" if success else "failed"
        if not success:
            log.error_message = error_msg or "Telegram API request failed"
            failed += 1
        else:
            sent += 1

        db.add(log)
        logger.info("telegram_notification_%s channel=%s title=%s", log.status, channel.name, title)

    return {"status": "sent" if sent > 0 else "failed", "title": title, "sent": sent, "failed": failed}


async def send_whatsapp(
    db: AsyncSession,
    project_id: uuid.UUID,
    title: str,
    message: str,
    *,
    session_id: uuid.UUID | None = None,
) -> dict:
    """Send a WhatsApp notification to all enabled WhatsApp channels.

    Returns a dict with status, title, sent count, and failed count.
    """
    result = await db.execute(
        select(NotificationChannel).where(
            NotificationChannel.project_id == project_id,
            NotificationChannel.channel_type == NotificationChannelType.WHATSAPP,
            NotificationChannel.enabled == True,  # noqa: E712
        )
    )
    channels = result.scalars().all()
    if not channels:
        return {"error": "No enabled WhatsApp channel configured in notification channels"}

    text = f"*{title}*\n\n{message}"

    sent, failed = 0, 0
    for channel in channels:
        jid = (channel.config or {}).get("jid")
        if not jid:
            continue

        log = NotificationLog(
            project_id=project_id,
            session_id=session_id,
            channel_type=NotificationChannelType.WHATSAPP,
            title=title,
            content=message[:5000],
            recipient=jid,
        )

        success, error_msg = await send_whatsapp_notification(jid=jid, text=text)
        log.status = "sent" if success else "failed"
        if not success:
            log.error_message = error_msg or "WhatsApp send failed"
            failed += 1
        else:
            sent += 1

        db.add(log)
        logger.info("whatsapp_notification_%s channel=%s title=%s", log.status, channel.name, title)

    return {"status": "sent" if sent > 0 else "failed", "title": title, "sent": sent, "failed": failed}
