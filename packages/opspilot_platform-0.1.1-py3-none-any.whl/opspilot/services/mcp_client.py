"""Lightweight MCP stdio client for pre-run tool execution.

Implements the minimum MCP JSON-RPC handshake required to:
  - list_tools: discover tools exposed by a server
  - call_tool:  execute a tool and capture its text output

Only stdio transport is supported (command + args + env).
The internal OpsPilot HTTP server is excluded from pre-run calls
because it requires an active session context.
"""

import asyncio
import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_LIST_TIMEOUT = 20.0   # seconds to wait for tools/list
_CALL_TIMEOUT = 30.0   # seconds to wait for tools/call result


async def _jsonrpc_session(
    command: str,
    args: list[str],
    env: dict[str, str] | None,
    method: str,
    params: dict,
    timeout: float,
) -> dict:
    """Minimal JSON-RPC MCP stdio session: initialize → call → return result.

    Sends three messages in one write:
      1. initialize  (id=1)
      2. notifications/initialized  (no id, fire-and-forget)
      3. actual request  (id=2)

    Reads stdout until id=2 response arrives, then terminates the process.
    """
    merged_env = {**os.environ, **(env or {})}

    try:
        proc = await asyncio.create_subprocess_exec(
            command,
            *(args or []),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
            env=merged_env,
        )
    except (FileNotFoundError, PermissionError, OSError) as exc:
        raise RuntimeError(f"Cannot start MCP server '{command}': {exc}") from exc

    try:
        msgs = [
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "opspilot-pre-run", "version": "1.0"},
                },
            },
            # Notification — no id field
            {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}},
            {"jsonrpc": "2.0", "id": 2, "method": method, "params": params},
        ]
        payload = "\n".join(json.dumps(m) for m in msgs) + "\n"
        proc.stdin.write(payload.encode())
        await proc.stdin.drain()
        proc.stdin.close()

        responses: dict[int, dict] = {}

        async def _read() -> None:
            async for raw in proc.stdout:
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                    msg_id = msg.get("id")
                    if isinstance(msg_id, int):
                        responses[msg_id] = msg
                    if 2 in responses:
                        return
                except json.JSONDecodeError:
                    pass

        await asyncio.wait_for(_read(), timeout=timeout)

    finally:
        try:
            proc.terminate()
            await asyncio.wait_for(proc.wait(), timeout=2.0)
        except Exception:
            pass

    resp = responses.get(2)
    if resp is None:
        raise RuntimeError("MCP server did not respond within timeout")
    if "error" in resp:
        err = resp["error"]
        raise RuntimeError(f"MCP error {err.get('code')}: {err.get('message', 'unknown')}")
    return resp.get("result", {})


async def list_tools(
    command: str,
    args: list[str] | None,
    env: dict[str, str] | None,
) -> list[dict]:
    """Return the tools/list result from an MCP stdio server.

    Each tool dict has: name, description, inputSchema.
    Returns [] on any error so callers can handle gracefully.
    """
    result = await _jsonrpc_session(
        command, args or [], env,
        "tools/list", {},
        timeout=_LIST_TIMEOUT,
    )
    return result.get("tools", [])


async def call_tool(
    command: str,
    args: list[str] | None,
    env: dict[str, str] | None,
    tool_name: str,
    tool_params: dict[str, Any] | None,
    timeout: float = _CALL_TIMEOUT,
) -> str:
    """Call a tool on an MCP stdio server and return concatenated text output."""
    result = await _jsonrpc_session(
        command, args or [], env,
        "tools/call",
        {"name": tool_name, "arguments": tool_params or {}},
        timeout=timeout,
    )
    content = result.get("content", [])
    texts = [
        item["text"]
        for item in content
        if isinstance(item, dict) and item.get("type") == "text"
    ]
    return "\n".join(texts) if texts else "(no output)"
