"""Report service — CRUD, HTML building, and S3 upload for reports.

Extracted from api/reports.py to follow clean-architecture layering.
"""
import html
import logging
import uuid

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from opspilot.models import Report
from opspilot.services.embeddings import delete_entity_embedding
from opspilot.services.storage import upload_file

logger = logging.getLogger(__name__)


async def create_report(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    title: str,
    content_md: str | None = None,
    content_html: str | None = None,
    task_id: uuid.UUID | None = None,
    session_id: uuid.UUID | None = None,
) -> Report:
    """Build HTML, upload to S3, and create the DB record.

    Returns the flushed Report (caller should commit).
    """
    html_bytes = _build_report_html(title, content_md, content_html)
    report = Report(
        title=title,
        project_id=project_id,
        task_id=task_id,
        session_id=session_id,
    )
    db.add(report)
    await db.flush()

    upload_result = upload_file(html_bytes, f"report-{report.id}.html", "text/html")
    report.s3_url = upload_result["s3_url"]

    await db.refresh(report)
    logger.info("report_created id=%s url=%s", report.id, report.s3_url)
    return report


async def list_reports(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    task_id: uuid.UUID | None = None,
    session_id: uuid.UUID | None = None,
    limit: int = 25,
    offset: int = 0,
) -> tuple[list[Report], int]:
    """List reports with pagination. Returns (items, total_count)."""
    filters = [Report.project_id == project_id]
    if task_id:
        filters.append(Report.task_id == task_id)
    if session_id:
        filters.append(Report.session_id == session_id)

    count_stmt = select(func.count()).select_from(Report)
    stmt = select(Report).options(selectinload(Report.task)).order_by(Report.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        count_stmt = count_stmt.where(f)
        stmt = stmt.where(f)

    total = await db.scalar(count_stmt)
    result = await db.execute(stmt)
    return list(result.scalars().all()), total or 0


async def get_report(
    db: AsyncSession,
    project_id: uuid.UUID,
    report_id: uuid.UUID,
) -> Report | None:
    """Fetch a single report by ID, scoped to project."""
    stmt = select(Report).where(Report.id == report_id).where(Report.project_id == project_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def delete_report(
    db: AsyncSession,
    project_id: uuid.UUID,
    report_id: uuid.UUID,
) -> bool:
    """Delete a report and its embedding. Returns True if found and deleted."""
    stmt = select(Report).where(Report.id == report_id).where(Report.project_id == project_id)
    result = await db.execute(stmt)
    report = result.scalar_one_or_none()
    if not report:
        return False
    await db.delete(report)
    await delete_entity_embedding(db, "report", report_id)
    return True


# ──────────────────────────────────────────────────────────────────────────
# HTML building helpers
# ──────────────────────────────────────────────────────────────────────────

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    max-width: 960px; margin: 48px auto; padding: 0 24px;
    color: #1a202c; background: #fff; line-height: 1.75; font-size: 16px;
  }}
  h1 {{ font-size: 2em; color: #1a202c; border-bottom: 3px solid #4299e1; padding-bottom: .4em; margin-bottom: .6em; }}
  h2 {{ font-size: 1.5em; color: #2d3748; border-bottom: 1px solid #e2e8f0; padding-bottom: .3em; margin-top: 2em; }}
  h3 {{ font-size: 1.2em; color: #4a5568; margin-top: 1.5em; }}
  h4, h5, h6 {{ color: #718096; margin-top: 1.2em; }}
  a {{ color: #4299e1; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  code {{
    background: #edf2f7; color: #c53030; padding: 2px 6px;
    border-radius: 4px; font-size: .875em; font-family: "SFMono-Regular", Consolas, monospace;
  }}
  pre {{
    background: #1a202c; color: #e2e8f0; padding: 1.2em 1.4em;
    border-radius: 8px; overflow-x: auto; margin: 1.2em 0;
    white-space: pre-wrap; word-wrap: break-word; word-break: break-all;
  }}
  pre code {{ background: transparent; color: inherit; padding: 0; font-size: .9em; white-space: pre-wrap; }}
  table {{ border-collapse: collapse; width: 100%; margin: 1.2em 0; font-size: .95em; }}
  th {{
    background: #4299e1; color: #fff; padding: 10px 14px;
    text-align: left; font-weight: 600;
  }}
  td {{ border: 1px solid #e2e8f0; padding: 9px 14px; }}
  tr:nth-child(even) td {{ background: #f7fafc; }}
  blockquote {{
    border-left: 4px solid #4299e1; margin: 1em 0; padding: .8em 1.2em;
    background: #ebf8ff; color: #2c5282; border-radius: 0 6px 6px 0;
  }}
  blockquote p {{ margin: 0; }}
  ul, ol {{ padding-left: 1.6em; }}
  li {{ margin: .3em 0; }}
  hr {{ border: none; border-top: 2px solid #e2e8f0; margin: 2em 0; }}
  img {{ max-width: 100%; border-radius: 6px; }}
  .report-header {{
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff; padding: 32px 36px; border-radius: 12px; margin-bottom: 2em;
  }}
  .report-header h1 {{ color: #fff; border-bottom-color: rgba(255,255,255,.4); }}
  .report-header p {{ margin: 0; opacity: .85; font-size: .95em; }}
</style>
</head>
<body>
<div class="report-header">
  <h1>{title}</h1>
</div>
{body}
</body>
</html>"""


def _build_report_html(title: str, content_md: str | None, content_html: str | None) -> bytes:
    if content_html and (
        content_html.lstrip().lower().startswith("<!doctype")
        or content_html.lstrip().lower().startswith("<html")
    ):
        return content_html.encode("utf-8")

    if content_html:
        body = content_html
    elif content_md:
        body = _markdown_to_html_body(content_md)
    else:
        body = "<p><em>No content provided.</em></p>"

    doc = _HTML_TEMPLATE.format(title=html.escape(title), body=body)
    return doc.encode("utf-8")


def _markdown_to_html_body(md: str) -> str:
    try:
        import markdown  # type: ignore
        return markdown.markdown(md, extensions=["extra", "tables", "fenced_code"])
    except Exception:
        return f"<pre>{html.escape(md)}</pre>"


def markdown_to_styled_html(md: str, title: str = "Export") -> str:
    """Convert markdown to a full styled HTML document suitable for PDF rendering."""
    body = _markdown_to_html_body(md)
    return _HTML_TEMPLATE.format(title=html.escape(title), body=body)
