"""Service layer for webhook-centric queries (list, stats, detail, events)."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import Task, WebhookConfig, WebhookEvent


def _mask_token(token: str) -> str:
    """Show first 8 and last 4 chars, mask the rest."""
    if len(token) <= 12:
        return token[:4] + "…"
    return token[:8] + "…" + token[-4:]


async def list_configs(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    enabled: bool | None = None,
    task_id: uuid.UUID | None = None,
    q: str | None = None,
    limit: int = 25,
    offset: int = 0,
) -> list[dict]:
    # Combined subquery: count + last_event_at per task (single table scan)
    event_agg_sq = (
        select(
            WebhookEvent.task_id,
            func.count().label("total_events"),
            func.max(WebhookEvent.received_at).label("last_event_at"),
        )
        .where(WebhookEvent.project_id == project_id)
        .group_by(WebhookEvent.task_id)
        .subquery()
    )

    # Last event status via DISTINCT ON (PostgreSQL-specific, cannot be combined with aggregate)
    last_status_sq = (
        select(
            WebhookEvent.task_id,
            WebhookEvent.processing_status.label("last_event_status"),
        )
        .where(WebhookEvent.project_id == project_id)
        .distinct(WebhookEvent.task_id)
        .order_by(WebhookEvent.task_id, WebhookEvent.received_at.desc())
        .subquery()
    )

    stmt = (
        select(
            WebhookConfig,
            Task.name.label("task_name"),
            func.coalesce(event_agg_sq.c.total_events, 0).label("total_events"),
            event_agg_sq.c.last_event_at,
            last_status_sq.c.last_event_status,
        )
        .join(Task, WebhookConfig.task_id == Task.id)
        .outerjoin(event_agg_sq, event_agg_sq.c.task_id == WebhookConfig.task_id)
        .outerjoin(last_status_sq, last_status_sq.c.task_id == WebhookConfig.task_id)
        .where(WebhookConfig.project_id == project_id)
        .order_by(WebhookConfig.created_at.desc())
        .limit(limit)
        .offset(offset)
    )

    if enabled is not None:
        stmt = stmt.where(WebhookConfig.enabled == enabled)
    if task_id is not None:
        stmt = stmt.where(WebhookConfig.task_id == task_id)
    if q:
        pattern = f"%{q}%"
        stmt = stmt.where(
            (WebhookConfig.name.ilike(pattern))
            | (WebhookConfig.description.ilike(pattern))
            | (Task.name.ilike(pattern))
        )

    rows = (await db.execute(stmt)).all()
    results = []
    for cfg, task_name, total_events, last_event_at, last_event_status in rows:
        results.append({
            "id": cfg.id,
            "task_id": cfg.task_id,
            "task_name": task_name,
            "name": cfg.name,
            "token": _mask_token(cfg.token),
            "enabled": cfg.enabled,
            "description": cfg.description,
            "total_events": total_events,
            "last_event_at": last_event_at,
            "last_event_status": last_event_status,
            "created_at": cfg.created_at,
            "updated_at": cfg.updated_at,
        })
    return results


async def count_configs(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    enabled: bool | None = None,
    task_id: uuid.UUID | None = None,
    q: str | None = None,
) -> int:
    stmt = (
        select(func.count())
        .select_from(WebhookConfig)
        .join(Task, WebhookConfig.task_id == Task.id)
        .where(WebhookConfig.project_id == project_id)
    )
    if enabled is not None:
        stmt = stmt.where(WebhookConfig.enabled == enabled)
    if task_id is not None:
        stmt = stmt.where(WebhookConfig.task_id == task_id)
    if q:
        pattern = f"%{q}%"
        stmt = stmt.where(
            (WebhookConfig.name.ilike(pattern))
            | (WebhookConfig.description.ilike(pattern))
            | (Task.name.ilike(pattern))
        )
    return (await db.execute(stmt)).scalar_one()


async def get_config_detail(
    db: AsyncSession,
    project_id: uuid.UUID,
    webhook_id: uuid.UUID,
) -> dict | None:
    stmt = (
        select(WebhookConfig, Task.name.label("task_name"))
        .join(Task, WebhookConfig.task_id == Task.id)
        .where(WebhookConfig.project_id == project_id, WebhookConfig.id == webhook_id)
    )
    row = (await db.execute(stmt)).one_or_none()
    if not row:
        return None

    cfg, task_name = row

    now = datetime.now(timezone.utc)
    since_24h = now - timedelta(hours=24)

    # Total event count (all time)
    total_count_stmt = (
        select(func.count())
        .select_from(WebhookEvent)
        .where(WebhookEvent.task_id == cfg.task_id, WebhookEvent.project_id == project_id)
    )
    total_events = (await db.execute(total_count_stmt)).scalar_one()

    # Recent events (last 20)
    events_stmt = (
        select(WebhookEvent)
        .where(WebhookEvent.task_id == cfg.task_id, WebhookEvent.project_id == project_id)
        .order_by(WebhookEvent.received_at.desc())
        .limit(20)
    )
    recent_events = list((await db.execute(events_stmt)).scalars().all())

    # 24h stats
    stats_stmt = (
        select(
            func.count().label("total"),
            func.count().filter(WebhookEvent.error_message.is_(None)).label("success"),
        )
        .where(
            WebhookEvent.task_id == cfg.task_id,
            WebhookEvent.project_id == project_id,
            WebhookEvent.received_at >= since_24h,
        )
    )
    stats_row = (await db.execute(stats_stmt)).one()
    events_24h = stats_row.total
    success_rate = (stats_row.success / stats_row.total * 100) if stats_row.total > 0 else None

    return {
        "id": cfg.id,
        "task_id": cfg.task_id,
        "task_name": task_name,
        "name": cfg.name,
        "token": _mask_token(cfg.token),
        "enabled": cfg.enabled,
        "description": cfg.description,
        "total_events": total_events,
        "last_event_at": recent_events[0].received_at if recent_events else None,
        "last_event_status": recent_events[0].processing_status if recent_events else None,
        "created_at": cfg.created_at,
        "updated_at": cfg.updated_at,
        "recent_events": recent_events,
        "events_24h": events_24h,
        "success_rate_24h": success_rate,
    }


async def get_stats(
    db: AsyncSession,
    project_id: uuid.UUID,
) -> dict:
    # Config counts
    config_stmt = (
        select(
            func.count().label("total"),
            func.count().filter(WebhookConfig.enabled.is_(True)).label("enabled"),
            func.count().filter(WebhookConfig.enabled.is_(False)).label("disabled"),
        )
        .where(WebhookConfig.project_id == project_id)
    )
    cfg_row = (await db.execute(config_stmt)).one()

    # Event counts last 24h
    since_24h = datetime.now(timezone.utc) - timedelta(hours=24)
    event_stmt = (
        select(
            WebhookEvent.processing_status,
            func.count().label("cnt"),
        )
        .where(
            WebhookEvent.project_id == project_id,
            WebhookEvent.received_at >= since_24h,
        )
        .group_by(WebhookEvent.processing_status)
    )
    event_rows = (await db.execute(event_stmt)).all()
    events_by_status = {row.processing_status: row.cnt for row in event_rows}
    total_events_24h = sum(events_by_status.values())

    return {
        "total_configs": cfg_row.total,
        "enabled": cfg_row.enabled,
        "disabled": cfg_row.disabled,
        "total_events_24h": total_events_24h,
        "events_by_status": events_by_status,
    }


async def list_events(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    task_id: uuid.UUID | None = None,
    status: str | None = None,
    since: datetime | None = None,
    until: datetime | None = None,
    limit: int = 25,
    offset: int = 0,
) -> list[dict]:
    stmt = (
        select(WebhookEvent, Task.name.label("task_name"))
        .outerjoin(Task, WebhookEvent.task_id == Task.id)
        .where(WebhookEvent.project_id == project_id)
        .order_by(WebhookEvent.received_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if task_id is not None:
        stmt = stmt.where(WebhookEvent.task_id == task_id)
    if status:
        stmt = stmt.where(WebhookEvent.processing_status == status)
    if since:
        stmt = stmt.where(WebhookEvent.received_at >= since)
    if until:
        stmt = stmt.where(WebhookEvent.received_at <= until)

    rows = (await db.execute(stmt)).all()
    results = []
    for event, task_name in rows:
        payload_str = json.dumps(event.payload) if event.payload else ""
        results.append({
            "id": event.id,
            "task_id": event.task_id,
            "task_name": task_name,
            "session_id": event.session_id,
            "source_ip": event.source_ip,
            "received_at": event.received_at,
            "processing_status": event.processing_status,
            "error_message": event.error_message,
            "payload_preview": payload_str[:200],
        })
    return results


async def count_events(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    task_id: uuid.UUID | None = None,
    status: str | None = None,
    since: datetime | None = None,
    until: datetime | None = None,
) -> int:
    stmt = (
        select(func.count())
        .select_from(WebhookEvent)
        .where(WebhookEvent.project_id == project_id)
    )
    if task_id is not None:
        stmt = stmt.where(WebhookEvent.task_id == task_id)
    if status:
        stmt = stmt.where(WebhookEvent.processing_status == status)
    if since:
        stmt = stmt.where(WebhookEvent.received_at >= since)
    if until:
        stmt = stmt.where(WebhookEvent.received_at <= until)
    return (await db.execute(stmt)).scalar_one()


async def get_event_detail(
    db: AsyncSession,
    project_id: uuid.UUID,
    event_id: uuid.UUID,
) -> dict | None:
    stmt = (
        select(WebhookEvent, Task.name.label("task_name"))
        .outerjoin(Task, WebhookEvent.task_id == Task.id)
        .where(WebhookEvent.project_id == project_id, WebhookEvent.id == event_id)
    )
    row = (await db.execute(stmt)).one_or_none()
    if not row:
        return None
    event, task_name = row
    return {
        "id": event.id,
        "task_id": event.task_id,
        "task_name": task_name,
        "session_id": event.session_id,
        "headers": event.headers,
        "payload": event.payload,
        "source_ip": event.source_ip,
        "received_at": event.received_at,
        "processing_status": event.processing_status,
        "error_message": event.error_message,
    }


async def bulk_delete_configs(
    db: AsyncSession,
    project_id: uuid.UUID,
    ids: list[uuid.UUID],
) -> int:
    stmt = (
        delete(WebhookConfig)
        .where(WebhookConfig.project_id == project_id, WebhookConfig.id.in_(ids))
        .returning(WebhookConfig.id)
    )
    result = await db.execute(stmt)
    deleted = len(result.all())
    await db.commit()
    return deleted
