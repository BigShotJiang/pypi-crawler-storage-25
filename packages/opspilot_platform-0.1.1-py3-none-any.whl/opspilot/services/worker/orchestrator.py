import logging
import time
import uuid
import json
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from opspilot.models import Task, Session, Message, ToolCall, Finding
from opspilot.models import SessionStatus, ToolCallStatus
from opspilot.models.artifacts import ArtifactSourceType, ArtifactTrigger
from opspilot.agents.domain_events import (
    DomainEvent,
    TextDelta,
    ThinkingDelta,
    ToolInvocationStarted,
    ToolInvocationCompleted,
    AgentCompleted,
    AgentError,
)
from opspilot.services.workspace import WorkspaceService
from opspilot.services.worker.context_builder import ContextBuilder
from opspilot.services.worker.agent_executor import AgentExecutor
from opspilot.services.worker.outcome_persister import OutcomePersister
from opspilot.services.worker.notifier import Notifier
from opspilot.agents import get_adapter

logger = logging.getLogger(__name__)

class SessionOrchestrator:
    """Coordinates distinct domain services to run an agent session."""

    def __init__(self, db, redis_client):
        self.db = db
        self.workspace = None
        self.context_builder = ContextBuilder(db)
        self.agent_executor = AgentExecutor()
        self.outcome_persister = OutcomePersister(db)
        self.notifier = Notifier(redis_client)

    async def run_session(
        self,
        task_id: str,
        session_id: str,
        trigger_source: str = "manual",
        webhook_event_id: str | None = None,
        webhook_payload: dict | None = None,
        idempotency_key: str | None = None,
    ):
        """Main entry point for running a session."""
        # 1. Load Task
        stmt = (
            select(Task)
            .where(Task.id == uuid.UUID(task_id))
            .options(
                selectinload(Task.mcp_servers),
                selectinload(Task.git_repos),
                selectinload(Task.notification_channels),
                selectinload(Task.memory_files),
                selectinload(Task.files),
            )
        )
        result = await self.db.execute(stmt)
        task = result.scalar_one_or_none()
        if not task:
            logger.error("task_not_found task_id=%s", task_id)
            return
        logger.info("task_loaded task_id=%s task.project_id=%s task.name=%s", task.id, task.project_id, task.name)

        # 2. Get or Create Session (Idempotency)
        session = await self.outcome_persister.get_or_create_session(
            task, session_id, trigger_source, webhook_event_id, idempotency_key
        )
        if session.status not in (SessionStatus.PENDING, SessionStatus.FAILED):
            logger.info("session_not_runnable status=%s", session.status)
            return

        self.workspace = WorkspaceService(session_id)
        self.notifier.publish_session_event(session_id, "session_start", {"status": "pending"})

        try:
            # 3. Setup Workspace
            self.workspace.setup()
            clone_results = await self._clone_repos(task)
            session.git_clone_results = clone_results
            await self.db.commit()

            # 4. Prepare Context
            mcp_source = task.mcp_servers
            if not mcp_source:
                # Fallback: load all enabled internal MCP servers for the project
                from opspilot.models import McpServer
                stmt_mcp = select(McpServer).where(
                    McpServer.project_id == task.project_id,
                    McpServer.enabled == True,
                    McpServer.is_internal == True,
                )
                result_mcp = await self.db.execute(stmt_mcp)
                mcp_source = list(result_mcp.scalars().all())
                logger.info("mcp_fallback_to_project servers=%d project_id=%s", len(mcp_source), task.project_id)
            mcp_servers = [
                {
                    "slug": s.slug, "command": s.command, "args": s.args or [],
                    "env": s.env or {}, "transport": s.transport, "url": s.url,
                    "project_id": str(s.project_id) if s.project_id else None,
                }
                for s in mcp_source
                if s.enabled
            ]
            mcp_config_path = self.workspace.write_mcp_config(mcp_servers)
            
            system_prompt = await self.context_builder.build_system_prompt(
                task, session_id, str(self.workspace.workspace_path), clone_results, webhook_payload
            )
            self.workspace.write_system_prompt_file(system_prompt)
            self._write_memory_files(task)
            self._copy_task_files(task)

            session.system_prompt_snapshot = system_prompt
            await self.db.commit()

            # 5. Agent Run
            adapter = get_adapter(task.agent_type.value)
            cmd = adapter.build_command(
                workspace_path=str(self.workspace.workspace_path),
                system_prompt=system_prompt,
                prompt=task.prompt,
                mcp_config_path=str(mcp_config_path),
                timeout_seconds=task.timeout_seconds,
                agent_settings=task.agent_settings or {},
            )
            
            await self.outcome_persister.update_session_status(session, SessionStatus.RUNNING)
            await self.db.commit()
            self.notifier.publish_session_event(session_id, "status_change", {"status": "running"})
            
            start_time = time.time()
            events_list = []
            event_seq = 0
            tc_by_tool_id = {}
            raw_output_path = self.workspace.get_raw_output_path()
            stderr_text = ""
            return_code = 0

            with open(raw_output_path, "w") as raw_file:
                async for event in self.agent_executor.run_agent(
                    adapter, cmd, str(self.workspace.workspace_path), task.timeout_seconds
                ):
                    if isinstance(event, AgentCompleted):
                        return_code = event.usage.get("return_code", 0)
                        stderr_text = event.usage.get("stderr", "")
                        if event.usage.get("error") == "timeout":
                            session.status = SessionStatus.TIMEOUT
                        # If this was emitted by executor after completion, we stop list append
                        if "return_code" in event.usage:
                            continue
                    
                    events_list.append(event)
                    # For raw file, we need a serializable dict. 
                    # For now just log types, but ideally we'd have a serializer.
                    # raw_file.write(json.dumps({"type": event.__class__.__name__, "data": vars(event)}) + "\n")
                    
                    # Handle specific event types
                    if isinstance(event, TextDelta):
                        await self.outcome_persister.save_message(
                            session.id, "assistant",
                            event.text, event_seq
                        )
                        event_seq += 1
                        self.notifier.publish_session_event(session_id, "message", {"role": "assistant", "content": event.text})

                    elif isinstance(event, ToolInvocationStarted):
                        tc = await self.outcome_persister.save_tool_call_start(
                            session.id, event.tool_name,
                            event.tool_server, event.input, event_seq
                        )
                        tool_id = event.tool_use_id or f"{event.tool_name}_{event_seq}"
                        tc_by_tool_id[tool_id] = tc
                        event_seq += 1
                        self.notifier.publish_session_event(session_id, "tool_call_start", {
                            "tool_name": event.tool_name, "tool_server": event.tool_server, "input_params": event.input, "tool_id": event.tool_use_id
                        })
                        
                    elif isinstance(event, ToolInvocationCompleted):
                        tool_id = event.tool_use_id or event.tool_name
                        tc = tc_by_tool_id.pop(tool_id, None)
                        if tc:
                            await self.outcome_persister.save_tool_call_end(
                                tc, event.status,
                                str(event.result), event.duration_ms
                            )
                        self.notifier.publish_session_event(session_id, "tool_call_end", {
                            "tool_name": event.tool_name, "status": event.status, "output_result": str(event.result), "tool_id": event.tool_use_id
                        })
                    
                    await self.db.flush()

            # 6. Finalize
            agent_result = adapter.extract_result(events_list, return_code)
            elapsed = int((time.time() - start_time) * 1000)
            
            await self.outcome_persister.finalize_session(
                session, agent_result, elapsed, str(raw_output_path), str(self.workspace.workspace_path)
            )
            
            if session.status == SessionStatus.TIMEOUT:
                session.error_message = f"Agent timed out after {task.timeout_seconds}s"
                session.error_details = f"Timeout.\n\nStderr:\n{stderr_text}" if stderr_text else "Timeout."
            elif not agent_result.success:
                 session.error_details = f"Exit code: {return_code}\n\nStderr:\n{stderr_text}"

            task.last_run_at = datetime.now(timezone.utc)
            await self.db.commit()

            # Auto-archive workspace artifact (non-fatal)
            if task.auto_archive_artifact and session.status == SessionStatus.COMPLETED:
                try:
                    from opspilot.services import artifact_service
                    await artifact_service.create_artifact_from_workspace(
                        self.db, task.project_id, str(self.workspace.workspace_path),
                        source_type=ArtifactSourceType.SESSION,
                        session_id=session.id,
                        trigger=ArtifactTrigger.AUTO,
                    )
                    await self.db.commit()
                    logger.info("auto_archive_created session_id=%s", session_id)
                except Exception:
                    logger.exception("auto_archive_failed session_id=%s", session_id)

            self.notifier.publish_session_event(session_id, "session_end", {
                "status": session.status.value,
                "duration_ms": session.duration_ms,
                "findings_count": session.findings_count,
            })

        except Exception as e:
            logger.exception("session_failed session_id=%s", session_id)
            session.status = SessionStatus.FAILED
            session.error_message = str(e)[:5000]
            session.error_details = traceback.format_exc()[:10000]
            session.finished_at = datetime.now(timezone.utc)
            await self.db.commit()
            
            self.notifier.publish_session_event(session_id, "session_end", {
                "status": "failed", "error": str(e)[:1000],
            })

    async def _clone_repos(self, task) -> list[dict]:
        results = []
        project_id = str(task.project_id)
        for repo in task.git_repos:
            res = {"repo": repo.name, "branch": repo.branch, "status": "failed", "path": None, "error": None, "context": repo.context}
            try:
                token = None
                ssh_key = None
                if repo.token_encrypted:
                    from opspilot.services.oauth_service import decrypt_token
                    token = decrypt_token(repo.token_encrypted)
                if repo.ssh_key_encrypted:
                    from opspilot.services.oauth_service import decrypt_token
                    ssh_key = decrypt_token(repo.ssh_key_encrypted)
                self.workspace.clone_repo(
                    url=repo.url, name=repo.name, branch=repo.branch,
                    shallow=repo.shallow, username=repo.username, token=token,
                    ssh_key=ssh_key, auth_type=repo.auth_type or "https_token",
                    project_id=project_id,
                )
                res["status"] = "success"
                res["path"] = f"repos/{repo.name}"
            except Exception as e:
                res["error"] = str(e)[:400]
            results.append(res)
        return results

    def _write_memory_files(self, task):
        for mf in task.memory_files:
            dest_path = self.workspace.workspace_path / mf.destination
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_text(mf.content, encoding="utf-8")

    def _copy_task_files(self, task):
        """Copy task-attached files from S3 to workspace/files/."""
        if not task.files:
            return
        from opspilot.services.storage import download_file_bytes
        files_dir = self.workspace.workspace_path / "files"
        files_dir.mkdir(parents=True, exist_ok=True)
        for sf in task.files:
            file_bytes = download_file_bytes(sf.s3_key)
            if not file_bytes:
                logger.warning("task_file_download_failed file_id=%s s3_key=%s", sf.id, sf.s3_key)
                continue
            dest = files_dir / sf.original_filename
            dest.write_bytes(file_bytes)
            logger.debug("task_file_copied file_id=%s dest=%s", sf.id, dest)
