import logging
import re
import shutil
import uuid
import json
import os
import asyncio
from collections.abc import AsyncIterator
from datetime import datetime, timezone

from sqlalchemy import select, func as sa_func
from sqlalchemy.orm import selectinload

from opspilot.models import (
    Conversation, ConversationMessage, ConversationToolCall, Setting
)
from opspilot.models import MessageRole, ToolCallStatus
from opspilot.agents import get_adapter
from opspilot.agents.domain_events import (
    DomainEvent,
    AgentStarted,
    TextDelta,
    ThinkingDelta,
    ToolInvocationStarted,
    ToolInvocationCompleted,
    AgentCompleted,
    AgentError,
)
from opspilot.services.workspace import WorkspaceService
from opspilot.services.worker.notifier import Notifier
from opspilot.services.worker.context_builder import ContextBuilder
from opspilot.config import settings

logger = logging.getLogger(__name__)

# Registry of active agent subprocesses keyed by conversation_id string.
# Used by the cancel endpoint to kill the process on demand.
# Safe for single-worker uvicorn (all requests share the same process).
_active_processes: dict[str, asyncio.subprocess.Process] = {}


def _strip_markdown(text: str) -> str:
    """Strip common markdown formatting for use as a plain-text conversation title."""
    text = re.sub(r"[#*`_~\[\]>]", "", text)
    return text.strip()[:80]

class ChatOrchestrator:
    """Orchestrates chat turns."""

    def __init__(self, db, redis_client=None):
        self.db = db
        # Redis client is optional now for direct streaming, but kept for background compatibility
        self.notifier = Notifier(redis_client) if redis_client else None
        self.context_builder = ContextBuilder(db)

    async def run_chat_turn(
        self, conversation_id: str, user_message: str, on_process_started=None,
        attachments: list[dict] | None = None,
    ) -> AsyncIterator[DomainEvent]:
        """
        Execute a chat turn and yield events.
        Does NOT persist the assistant response or tool calls.
        The caller is responsible for calling finalize_turn.
        """
        workspace = WorkspaceService(f"chat-{conversation_id}")

        # 1. Load conversation
        stmt = (
            select(Conversation)
            .where(Conversation.id == uuid.UUID(conversation_id))
            .options(
                selectinload(Conversation.mcp_servers),
                selectinload(Conversation.memory_files),
                selectinload(Conversation.git_repos),
            )
        )
        result = await self.db.execute(stmt)
        conversation = result.scalar_one_or_none()
        if not conversation:
            logger.error("conversation_not_found conversation_id=%s", conversation_id)
            return

        # 2. Determine turn sequence based on max existing turn_sequence.
        # Using MAX+1 (not count of user messages) ensures no collision when
        # the conversation was seeded from a session (all session messages sit
        # at turn_sequence=0 but have no user messages, so count-of-users would
        # incorrectly return 0 again for the first real chat turn).
        turn_seq_result = await self.db.execute(
            select(sa_func.coalesce(sa_func.max(ConversationMessage.turn_sequence), -1))
            .where(ConversationMessage.conversation_id == conversation.id)
        )
        # COALESCE guarantees a non-None result (-1 when no messages exist),
        # so we can add 1 directly. Do NOT use `or -1` — that would treat 0 as falsy.
        turn_seq = turn_seq_result.scalar() + 1

        # 3. Determine next message sequence.
        # Use MAX+1 (not COUNT) — session-seeded messages have non-contiguous
        # sequence values, so COUNT would land in the middle of them.
        msg_seq_result = await self.db.execute(
            select(sa_func.coalesce(sa_func.max(ConversationMessage.sequence), -1))
            .where(ConversationMessage.conversation_id == conversation.id)
        )
        msg_seq = msg_seq_result.scalar() + 1

        # 4. Store user message immediately
        user_msg = ConversationMessage(
            conversation_id=conversation.id,
            role=MessageRole.USER,
            content=user_message,
            attachments=attachments if attachments else None,
            sequence=msg_seq,
            turn_sequence=turn_seq,
        )
        self.db.add(user_msg)
        await self.db.commit()

        yield AgentStarted(sequence=0, agent_type=conversation.agent_type.value, session_id=str(conversation.id))
        
        if self.notifier:
            self.notifier.publish_chat_event(conversation_id, "started", {
                "agent_type": conversation.agent_type.value,
                "session_id": str(conversation.id),
            })

        try:
            workspace.setup()

            # Clone configured repos BEFORE building prompt or running agent
            clone_results = await self._clone_repos(workspace, conversation)

            # Always persist clone results so the UI shows current state.
            # An empty list means all repos were removed — that's a valid update.
            conversation.git_clone_results = clone_results
            await self.db.commit()

            mcp_servers = [
                {
                    "slug": s.slug, "command": s.command, "args": s.args or [],
                    "env": s.env or {}, "transport": s.transport, "url": s.url,
                    "project_id": str(s.project_id) if s.project_id else None,
                }
                for s in conversation.mcp_servers
                if s.enabled
            ]
            mcp_config_path = workspace.write_mcp_config(mcp_servers)

            # Build effective system prompt
            effective_system_prompt = conversation.system_prompt
            if not conversation.agent_native_session_id:
                global_prefix = await self.context_builder._fetch_global_system_prompt()
                conversation_context = (
                    f"## Session Context\n"
                    f"You are running in a chat session. Your conversation_id is: {conversation_id}\n"
                    f"There is no task session_id in chat mode — session_id is optional for all OpsPilot MCP tools.\n\n"
                )
                # Workspace block (if repos were cloned)
                workspace_block = ""
                if clone_results:
                    workspace_block = self.context_builder._build_workspace_block(
                        str(workspace.workspace_path), clone_results
                    ) + "\n"
                effective_system_prompt = global_prefix + conversation_context + workspace_block + effective_system_prompt

                # Pre-run injections
                prc = conversation.pre_run_context or {"inject_skills": True, "injections": []}
                suffix = await self.context_builder._build_pre_run_suffix(prc, mcp_servers, conversation=conversation)
                if suffix:
                    effective_system_prompt += suffix

            adapter = get_adapter(conversation.agent_type.value)

            if not conversation.agent_native_session_id:
                workspace.write_system_prompt_file(effective_system_prompt)
                for mf in conversation.memory_files:
                    dest_path = workspace.workspace_path / mf.destination
                    dest_path.parent.mkdir(parents=True, exist_ok=True)
                    dest_path.write_text(mf.content, encoding="utf-8")

            # Copy attachments to workspace and build context
            effective_user_message = user_message
            if attachments:
                from opspilot.services.media_service import copy_attachments_to_workspace, build_attachment_context
                updated_attachments = copy_attachments_to_workspace(attachments, str(workspace.workspace_path))
                attachment_context = build_attachment_context(updated_attachments)
                if attachment_context:
                    effective_user_message = f"{user_message}\n\n{attachment_context}"

            cmd = adapter.build_command(
                workspace_path=str(workspace.workspace_path),
                system_prompt=effective_system_prompt,
                prompt=effective_user_message,
                mcp_config_path=str(mcp_config_path),
                timeout_seconds=settings.agent_timeout_seconds,
                resume_session_id=conversation.agent_native_session_id,
                is_chat=True,
                agent_settings=conversation.agent_settings or {},
            )

            def _on_process_started(proc):
                _active_processes[conversation_id] = proc
                if on_process_started:
                    on_process_started(proc)

            from opspilot.services.worker.agent_executor import AgentExecutor
            agent_executor = AgentExecutor()

            completed_emitted = False
            try:
                async for event in agent_executor.run_agent(
                    adapter=adapter,
                    cmd=cmd,
                    workspace_path=str(workspace.workspace_path),
                    timeout_seconds=settings.agent_timeout_seconds,
                    on_process_started=_on_process_started,
                ):
                    # AgentExecutor yields a synthetic AgentCompleted event at the end
                    if isinstance(event, AgentCompleted) and "return_code" in event.usage:
                        if not event.success and not completed_emitted:
                            error_msg = f"Agent exited with code {event.usage.get('return_code')}"
                            yield AgentError(message=error_msg, error_type="ProcessError")
                            if self.notifier:
                                self.notifier.publish_chat_event(conversation_id, "error", {"message": error_msg})
                        continue

                    yield event

                    if isinstance(event, AgentCompleted):
                        completed_emitted = True

                    # Publish to Redis for Telegram and other Redis-based subscribers.
                    # Uses Telegram-compatible event names.
                    if self.notifier:
                        event_name = "unknown"
                        event_data = {}
                        if isinstance(event, TextDelta):
                            event_name = "message"
                            event_data = {"content": event.text}
                        elif isinstance(event, ToolInvocationStarted):
                            event_name = "tool_call_start"
                            event_data = {"tool_name": event.tool_name, "tool_use_id": event.tool_use_id, "input": event.input}
                        elif isinstance(event, ToolInvocationCompleted):
                            event_name = "tool_call_end"
                            event_data = {"tool_name": event.tool_name, "tool_use_id": event.tool_use_id, "status": event.status, "output_result": str(event.result), "duration_ms": event.duration_ms}
                        elif isinstance(event, AgentCompleted):
                            event_name = "turn_end"
                            event_data = {"success": event.success, "usage": event.usage}
                        elif isinstance(event, AgentError):
                            event_name = "error"
                            event_data = {"message": event.message}

                        if event_name != "unknown":
                            self.notifier.publish_chat_event(conversation_id, event_name, event_data)

            finally:
                _active_processes.pop(conversation_id, None)

        except Exception as e:
            logger.exception("chat_turn_failed")
            yield AgentError(message=str(e))
            if self.notifier:
                self.notifier.publish_chat_event(conversation_id, "error", {"message": str(e)})

    async def _clone_repos(self, workspace: WorkspaceService, conversation) -> list[dict]:
        """Clone git repos configured for this conversation before the agent starts.

        For persistent conversation workspaces, repos cloned in a previous turn
        are updated in-place via fetch+reset. New repos are cloned from cache.
        Returns clone_results list (same format as task sessions).
        """
        results = []
        project_id = str(conversation.project_id)

        # Remove clones for repos no longer selected in this conversation.
        active_names = {repo.name for repo in conversation.git_repos}
        if workspace.repos_path.exists():
            for repo_dir in workspace.repos_path.iterdir():
                if repo_dir.is_dir() and repo_dir.name not in active_names:
                    shutil.rmtree(repo_dir, ignore_errors=True)
                    logger.info("chat_stale_repo_removed name=%s conversation_id=%s", repo_dir.name, conversation.id)

        if not conversation.git_repos:
            return results

        for repo in conversation.git_repos:
            res = {"repo": repo.name, "branch": repo.branch, "status": "failed", "path": None, "error": None, "context": repo.context}
            try:
                token = None
                ssh_key = None
                if repo.token_encrypted:
                    from opspilot.services.oauth_service import decrypt_token
                    token = decrypt_token(repo.token_encrypted)
                if repo.ssh_key_encrypted:
                    from opspilot.services.oauth_service import decrypt_token
                    ssh_key = decrypt_token(repo.ssh_key_encrypted)
                workspace.clone_repo(
                    url=repo.url, name=repo.name, branch=repo.branch,
                    shallow=repo.shallow, username=repo.username, token=token,
                    ssh_key=ssh_key, auth_type=repo.auth_type or "https_token",
                    project_id=project_id,
                )
                res["status"] = "success"
                res["path"] = f"repos/{repo.name}"
            except Exception as e:
                res["error"] = str(e)[:400]
            results.append(res)
        return results

    async def finalize_turn(
        self,
        conversation_id: str,
        events_ordered: list[dict],
        agent_native_session_id: str | None,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        error_message: str | None = None,
        error_type: str | None = None,
    ):
        """Atomically persist the results of a chat turn.

        events_ordered preserves arrival order: each item is either
          {"kind": "text", "content": str}
        or
          {"kind": "tool", "tool_id": str, "tool_name": str, ...}.
        Saves messages and tool calls with a shared sequence counter so
        they can be interleaved correctly when reloaded from the DB.
        """
        async with self.db.begin_nested():
            # 1. Load conversation with lock
            stmt = (
                select(Conversation)
                .where(Conversation.id == uuid.UUID(conversation_id))
                .with_for_update()
            )
            result = await self.db.execute(stmt)
            conversation = result.scalar_one()

            # 2. Determine turn sequence from the last user message (set by run_chat_turn).
            last_user_result = await self.db.execute(
                select(ConversationMessage.turn_sequence)
                .where(
                    ConversationMessage.conversation_id == conversation.id,
                    ConversationMessage.role == MessageRole.USER,
                )
                .order_by(ConversationMessage.turn_sequence.desc())
                .limit(1)
            )
            turn_seq = last_user_result.scalar_one_or_none() or 0

            # 3. Compute a single shared sequence counter spanning both
            # messages and tool calls so they can be interleaved on reload.
            msg_max_result = await self.db.execute(
                select(sa_func.coalesce(sa_func.max(ConversationMessage.sequence), -1))
                .where(ConversationMessage.conversation_id == conversation.id)
            )
            tc_max_result = await self.db.execute(
                select(sa_func.coalesce(sa_func.max(ConversationToolCall.sequence), -1))
                .where(ConversationToolCall.conversation_id == conversation.id)
            )
            next_seq = max(msg_max_result.scalar(), tc_max_result.scalar()) + 1

            # 4. If error and no events, save a single error message.
            if error_message and not events_ordered:
                conv_msg = ConversationMessage(
                    conversation_id=conversation.id,
                    role=MessageRole.ASSISTANT,
                    content="",
                    sequence=next_seq,
                    turn_sequence=turn_seq,
                    error_message=error_message,
                    error_type=error_type,
                    status="failed",
                )
                self.db.add(conv_msg)
                next_seq += 1

            # 5. Save events in arrival order using the shared sequence counter.
            for ev in events_ordered:
                if ev["kind"] == "text":
                    conv_msg = ConversationMessage(
                        conversation_id=conversation.id,
                        role=MessageRole.ASSISTANT,
                        content=ev["content"],
                        sequence=next_seq,
                        turn_sequence=turn_seq,
                        status="success",
                    )
                    self.db.add(conv_msg)
                elif ev["kind"] == "tool":
                    tc = ConversationToolCall(
                        conversation_id=conversation.id,
                        turn_sequence=turn_seq,
                        tool_name=ev.get("tool_name", "unknown"),
                        tool_server=ev.get("tool_server"),
                        input_params=ev.get("input_params"),
                        output_result=ev.get("output_result"),
                        status=ToolCallStatus.ERROR if ev.get("is_error") else ToolCallStatus.SUCCESS,
                        duration_ms=ev.get("duration_ms"),
                        sequence=next_seq,
                    )
                    self.db.add(tc)
                next_seq += 1

            # 6. Update conversation metadata.
            if turn_seq == 0 and (not conversation.title or conversation.title == "New Chat"):
                first_text = next(
                    (ev["content"] for ev in events_ordered if ev["kind"] == "text"), None
                )
                if first_text:
                    conversation.title = _strip_markdown(first_text)

            if agent_native_session_id:
                conversation.agent_native_session_id = agent_native_session_id

            conversation.total_input_tokens += input_tokens
            conversation.total_output_tokens += output_tokens
            conversation.total_cost_usd += cost_usd

        await self.db.commit()
        logger.info("chat_turn_finalized conversation_id=%s", conversation_id)
