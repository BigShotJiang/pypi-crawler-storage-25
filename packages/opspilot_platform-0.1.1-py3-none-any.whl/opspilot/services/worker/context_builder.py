import json
import logging
from sqlalchemy import select
from opspilot.models import Setting, Task
from opspilot.models.findings import Memory
from opspilot.services import mcp_client

MEMORY_INJECTION_LIMIT = 20

logger = logging.getLogger(__name__)

class ContextBuilder:
    """Builds effective system prompts and pre-run context injections."""

    def __init__(self, db_session):
        self.db = db_session

    async def build_system_prompt(
        self,
        task: Task,
        session_id: str,
        workspace_path: str,
        clone_results: list[dict],
        webhook_payload: dict | None = None,
    ) -> str:
        """Assemble the full effective system prompt."""
        # 1. Global prefix
        global_prefix = await self._fetch_global_system_prompt()

        # 2. Workspace block
        workspace_block = self._build_workspace_block(workspace_path, clone_results)

        # 3. Session context
        session_context = (
            f"## Session Context\n"
            f"Your session_id is: {session_id}\n"
            f"Your task_id is: {task.id}\n"
            f"Use this session_id when calling OpsPilot MCP tools that require it.\n\n"
            + workspace_block + "\n"
        )

        # 4. Base system prompt
        system_prompt = global_prefix + session_context + (task.system_prompt or "")

        # 5. Webhook payload
        if webhook_payload is not None:
            webhook_block = (
                "\n\n## Webhook Trigger Context\n"
                "This session was triggered by an external webhook. "
                "Analyze the following payload as the primary input for your task:\n\n"
                f"```json\n{json.dumps(webhook_payload, indent=2)}\n```"
            )
            system_prompt += webhook_block

        # 5.5 Runbook injection — search for matching operational runbooks
        if (task.pre_run_context or {}).get("inject_runbooks", True):
            runbook_query = self._extract_runbook_search_query(webhook_payload, task)
            if runbook_query.strip():
                try:
                    runbook_block, found_runbooks = await self._build_runbook_block(
                        runbook_query, task.project_id,
                    )
                    if runbook_block:
                        system_prompt += runbook_block
                    if not found_runbooks and webhook_payload:
                        system_prompt += (
                            "\n\n## Runbook Creation Instruction\n"
                            "No existing runbook matched this alert. After completing your investigation, "
                            "create a runbook documenting the diagnosis steps, root cause, and resolution "
                            "using the `runbook` MCP tool (action: create, status: draft).\n"
                        )
                except Exception:
                    logger.warning("runbook_injection_failed", exc_info=True)

        # 6. Task memory from previous sessions
        if task.task_memory and task.task_memory.strip():
            system_prompt += (
                "\n\n## Task Memory\n"
                "The following is a persistent scratchpad written by previous runs of this task. "
                "Its purpose is to carry forward only what future sessions need to know — "
                "unresolved items, decisions already made, duplicates to avoid, and patterns spotted across runs. "
                "It is NOT a log or audit trail; keep it concise and actionable.\n\n"
                "**IMPORTANT — update_memory REPLACES the entire memory, it does NOT append.** "
                "At the end of your session you MUST call "
                f"`task(action=\"update_memory\", task_id=\"{task.id}\", memory=\"...\")`. "
                "Before saving, read the existing content below, merge it with what you learned this session, "
                "and drop anything that is no longer relevant or has been resolved. "
                "The result should be the single source of truth for the next agent run.\n\n"
                + task.task_memory.strip() + "\n"
            )

        # 6.5. Task attached files
        if hasattr(task, "files") and task.files:
            file_lines = ["\n\n## Attached Files", "The following files are attached to this task and available in your workspace under `files/`:\n"]
            for sf in task.files:
                file_lines.append(f"- `files/{sf.original_filename}` ({sf.content_type}, {sf.file_size_bytes} bytes)")
            system_prompt += "\n".join(file_lines) + "\n"

        # 7. Pre-run injections (skills + memories)
        prc = task.pre_run_context or {"inject_skills": True, "injections": []}
        mcp_servers = [
            {"slug": s.slug, "command": s.command, "args": s.args or [], "env": s.env or {}, "transport": s.transport, "url": s.url}
            for s in task.mcp_servers
            if s.enabled
        ]
        suffix = await self._build_pre_run_suffix(prc, mcp_servers, task=task)
        if suffix:
            system_prompt += suffix

        return system_prompt

    async def _fetch_global_system_prompt(self) -> str:
        result = await self.db.execute(select(Setting).where(Setting.key == "global_system_prompt"))
        row = result.scalar_one_or_none()
        if row and row.value.strip():
            return row.value.strip() + "\n\n"
        return ""

    def _build_workspace_block(self, workspace_path: str, clone_results: list[dict]) -> str:
        successful_repos = [r for r in clone_results if r["status"] == "success"]
        failed_repos = [r for r in clone_results if r["status"] == "failed"]

        block = f"## Workspace\nYour workspace path: `{workspace_path}`\n"
        if successful_repos:
            block += "Cloned repositories:\n"
            for r in successful_repos:
                block += f"- **{r['repo']}** (`{workspace_path}/{r['path']}`, branch: {r['branch']})\n"
                if r.get("context"):
                    block += f"  > {r['context']}\n"
        if failed_repos:
            block += "Failed to clone (not available):\n"
            for r in failed_repos:
                block += f"- **{r['repo']}** (branch: {r['branch']}): clone failed — {r['error']}\n"
                if r.get("context"):
                    block += f"  > {r['context']}\n"
        return block

    async def build_chat_repo_context_block(self, project_id) -> str:
        """Build a block describing all project git repos (context only — no cloning in chat)."""
        from opspilot.models.integrations import GitRepo
        result = await self.db.execute(
            select(GitRepo).where(GitRepo.project_id == project_id).order_by(GitRepo.name)
        )
        repos = result.scalars().all()
        if not repos:
            return ""
        lines = ["## Repository Context", "The following repositories are configured for this project:"]
        for repo in repos:
            line = f"- **{repo.name}** (branch: `{repo.branch}`)"
            if repo.context:
                line += f": {repo.context}"
            lines.append(line)
        return "\n".join(lines) + "\n"

    @staticmethod
    def _extract_runbook_search_query(webhook_payload: dict | None, task: Task) -> str:
        """Extract search terms from webhook payload or task prompt for runbook matching."""
        if webhook_payload:
            alerts = webhook_payload.get("alerts", [webhook_payload])
            parts: list[str] = []
            name_keys = ("alertname", "name", "title", "alert", "alert_name", "rule_name")
            label_keys = ("labels", "tags", "commonLabels", "dimensions")
            for a in alerts[:5]:
                if not isinstance(a, dict):
                    continue
                for key in name_keys:
                    if key in a and isinstance(a[key], str):
                        parts.append(a[key])
                        break
                for key in label_keys:
                    val = a.get(key)
                    if isinstance(val, dict):
                        parts.extend(str(v) for v in val.values() if isinstance(v, str))
                        break
            query = " ".join(filter(None, parts))[:500]
            if query.strip():
                return query
        return (task.prompt or task.name or "")[:500]

    async def _build_runbook_block(
        self, search_query: str, project_id, limit: int = 3,
    ) -> tuple[str, bool]:
        """Search for matching active runbooks. Returns (markdown_block, found_any)."""
        from opspilot.services import runbook_service
        from opspilot.models.findings import RunbookStatus

        runbooks = await runbook_service.list_runbooks(
            self.db, project_id, query=search_query, status=RunbookStatus.ACTIVE, limit=limit,
        )
        if not runbooks:
            return "", False

        lines = [
            "\n\n## Matching Runbooks",
            "The following runbooks match the current alert context. "
            "Follow these procedures where applicable:\n",
        ]
        for rb in runbooks:
            lines.append(f"### {rb.title} (v{rb.version or '1.0'})")
            if rb.category:
                lines.append(f"Category: {rb.category}")
            lines.append(rb.content)
            lines.append("")
        return "\n".join(lines), True

    async def _build_memory_block(self, task_prompt: str | None, limit: int, project_id=None) -> str:
        """Load relevant memories for the session.

        If task_prompt is provided, uses hybrid search to surface semantically
        relevant memories. Falls back to latest N by recency otherwise.
        """
        try:
            base_filter = [Memory.project_id == project_id] if project_id else []
            if task_prompt and task_prompt.strip():
                from opspilot.services.search import hybrid_search
                matching_ids = await hybrid_search("memory", task_prompt.strip(), limit=limit)
                if matching_ids:
                    result = await self.db.execute(
                        select(Memory).where(Memory.id.in_(matching_ids), *base_filter)
                    )
                    mem_map = {m.id: m for m in result.scalars().all()}
                    memories = [mem_map[mid] for mid in matching_ids if mid in mem_map]
                else:
                    memories = []
            else:
                result = await self.db.execute(
                    select(Memory).where(*base_filter).order_by(Memory.updated_at.desc()).limit(limit)
                )
                memories = list(result.scalars().all())

            if not memories:
                return ""

            lines = []
            for m in memories:
                label = f"{m.entity_type}/{m.entity_key}/{m.key}"
                text = m.value or (json.dumps(m.value_json) if m.value_json else "")
                meta_parts = []
                if m.confidence is not None:
                    meta_parts.append(f"confidence: {m.confidence:.2f}")
                if m.tags:
                    meta_parts.append(f"tags: {', '.join(m.tags)}")
                meta = f"  ({', '.join(meta_parts)})" if meta_parts else ""
                lines.append(f"- [{label}] {text}{meta}")
            return "\n\n## Agent Memories\n" + "\n".join(lines) + "\n"
        except Exception:
            logger.warning("memory_block_build_failed", exc_info=True)
            return ""

    async def _build_pre_run_suffix(self, prc: dict, mcp_servers: list[dict], *, task: Task | None = None, conversation=None) -> str:
        suffix = ""

        project_id = (task.project_id if task else conversation.project_id if conversation else None)

        # Memory injection
        if prc.get("inject_memories", True):
            mem_limit = int(prc.get("memory_injection_limit", MEMORY_INJECTION_LIMIT))
            search_query = (
                (task.prompt or task.name or "") if task
                else (conversation.title or "") if conversation
                else ""
            )
            memory_block = await self._build_memory_block(search_query or None, mem_limit, project_id=project_id)
            if memory_block:
                suffix += memory_block

        # Skill injection — pinned skills + auto-search
        if project_id:
            try:
                import uuid as uuid_lib
                from opspilot.services import skill_service

                skills_to_inject: list = []
                pinned_ids = prc.get("skill_ids", [])

                # 1. Fetch pinned skills by ID (always, regardless of inject_skills toggle)
                for sid in pinned_ids:
                    try:
                        s = await skill_service.get_skill_by_id(self.db, project_id, uuid_lib.UUID(sid))
                        if s:
                            skills_to_inject.append(s)
                    except (ValueError, Exception):
                        pass

                # 2. Auto-search if inject_skills=True
                if prc.get("inject_skills", True):
                    search_query = ((task.prompt or task.name or "") if task else (conversation.title or ""))[:500]
                    if search_query.strip():
                        pinned_set = {s.id for s in skills_to_inject}
                        auto_skills = await skill_service.list_skills(
                            self.db, project_id,
                            query=search_query,
                            entry_type="skill",
                            limit=5,
                        )
                        remaining = max(0, 5 - len(skills_to_inject))
                        for s in auto_skills:
                            if s.id not in pinned_set and remaining > 0:
                                skills_to_inject.append(s)
                                remaining -= 1

                if skills_to_inject:
                    suffix += "\n\n## Relevant Skills from Past Experience\n"
                    suffix += "These skills were matched from previous sessions. To use one, call the `skill` MCP tool with action `get` and the skill's `skill_id` to retrieve its full content.\n"
                    for s in skills_to_inject:
                        desc = f": {s.description}" if s.description else ""
                        suffix += f"\n- **{s.name}** (skill_id: `{s.id}`){desc}\n"
            except Exception:
                logger.warning("skill_injection_failed", exc_info=True)

        return suffix
