import logging
import uuid

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models.findings import Memory
from opspilot.schemas.memories import MemoryCreate, MemoryUpdate
from opspilot.services.embeddings import delete_entity_embedding, schedule_indexing
from opspilot.services.search import RERANK_MIN_CANDIDATES, bm25_search, hybrid_search

logger = logging.getLogger(__name__)


def _index_text(m: Memory) -> str:
    return f"{m.entity_type} {m.entity_key} {m.key}\n\n{m.value or ''}"


async def get_memory(db: AsyncSession, project_id: uuid.UUID, memory_id: uuid.UUID) -> Memory | None:
    result = await db.execute(
        select(Memory)
        .where(Memory.id == memory_id)
        .where(Memory.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def create_memory(db: AsyncSession, project_id: uuid.UUID, data: MemoryCreate) -> Memory:
    """Upsert: if (entity_type, entity_key, key) already exists, update value/value_json/tags/confidence."""
    stmt = (
        insert(Memory)
        .values(
            entity_type=data.entity_type,
            entity_key=data.entity_key,
            key=data.key,
            value=data.value,
            value_json=data.value_json,
            tags=data.tags or [],
            confidence=data.confidence,
            created_by=data.created_by,
            source_session_id=data.source_session_id,
            source_task_id=data.source_task_id,
            project_id=project_id,
        )
        .on_conflict_do_update(
            constraint="uq_memories_entity_key",
            set_={
                "value": data.value,
                "value_json": data.value_json,
                "tags": data.tags or [],
                "confidence": data.confidence,
                "updated_at": func.now(),
            },
        )
        .returning(Memory.id)
    )
    result = await db.execute(stmt)
    memory_id = result.scalar_one()
    await db.flush()
    memory = await get_memory(db, project_id, memory_id)
    logger.info("memory_upserted id=%s key=%s/%s/%s", memory_id, data.entity_type, data.entity_key, data.key)
    schedule_indexing("memory", memory_id, _index_text(memory))
    return memory


async def list_memories(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    entity_type: str | None = None,
    entity_key: str | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 20,
    offset: int = 0,
    rerank: bool = False,
) -> list[Memory]:
    filters = [Memory.project_id == project_id]
    if entity_type:
        filters.append(Memory.entity_type == entity_type)
    if entity_key:
        filters.append(Memory.entity_key == entity_key)

    if query:
        matching_ids = await hybrid_search("memory", query, limit=limit)
        if not matching_ids:
            return []
        if rerank and len(matching_ids) > RERANK_MIN_CANDIDATES:
            from opspilot.services.search import rerank as rerank_fn
            matching_ids = await rerank_fn(query, matching_ids, "memory", limit=limit)
        stmt = select(Memory).where(Memory.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        mem_map = {m.id: m for m in result.scalars().all()}
        return [mem_map[mid] for mid in matching_ids if mid in mem_map]

    if keyword:
        matching_ids = await bm25_search("memory", keyword, limit=limit)
        if not matching_ids:
            return []
        stmt = select(Memory).where(Memory.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        mem_map = {m.id: m for m in result.scalars().all()}
        return [mem_map[mid] for mid in matching_ids if mid in mem_map]

    stmt = select(Memory).order_by(Memory.updated_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_memories(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    entity_type: str | None = None,
    entity_key: str | None = None,
) -> int:
    stmt = select(func.count()).select_from(Memory)
    stmt = stmt.where(Memory.project_id == project_id)
    if entity_type:
        stmt = stmt.where(Memory.entity_type == entity_type)
    if entity_key:
        stmt = stmt.where(Memory.entity_key == entity_key)
    return await db.scalar(stmt)


async def update_memory(
    db: AsyncSession, project_id: uuid.UUID, memory_id: uuid.UUID, data: MemoryUpdate
) -> Memory | None:
    memory = await get_memory(db, project_id, memory_id)
    if not memory:
        return None
    updated = data.model_dump(exclude_unset=True)
    reindex = False
    for field, value in updated.items():
        setattr(memory, field, value)
        if field == "value":
            reindex = True
    await db.flush()
    await db.refresh(memory)
    logger.info("memory_updated id=%s", memory_id)
    if reindex:
        schedule_indexing("memory", memory.id, _index_text(memory))
    return memory


async def delete_memory(db: AsyncSession, project_id: uuid.UUID, memory_id: uuid.UUID) -> bool:
    memory = await get_memory(db, project_id, memory_id)
    if not memory:
        return False
    await db.delete(memory)
    await delete_entity_embedding(db, "memory", memory_id)
    logger.info("memory_deleted id=%s", memory_id)
    return True
