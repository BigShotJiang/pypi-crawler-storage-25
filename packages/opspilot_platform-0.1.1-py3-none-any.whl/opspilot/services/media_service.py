"""Media processing service for chat attachments.

Handles: download → S3 upload → text extraction → workspace copy → prompt building.
"""
from __future__ import annotations

import io
import logging
import mimetypes
import os
import uuid

from opspilot.services.storage import (
    download_file_bytes,
    generate_thumbnail,
    is_image,
    optimize_image,
    upload_file as s3_upload_file,
)

logger = logging.getLogger(__name__)

_TEXT_EXTRACTABLE = {
    "application/pdf",
    "text/plain", "text/csv", "text/markdown", "text/html",
    "application/json", "application/xml", "text/xml",
}

_IMAGE_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp"}

_MAX_EXTRACTED_TEXT = 10_000


def process_media_bytes(
    file_bytes: bytes,
    filename: str,
    content_type: str | None = None,
    source: str = "unknown",
) -> dict:
    if not content_type:
        content_type, _ = mimetypes.guess_type(filename)
        content_type = content_type or "application/octet-stream"

    attachment_id = str(uuid.uuid4())

    upload_bytes = file_bytes
    if is_image(content_type):
        upload_bytes = optimize_image(file_bytes)
        content_type = "image/jpeg"

    upload_result = s3_upload_file(upload_bytes, filename, content_type=content_type)

    thumbnail_url = None
    if is_image(content_type):
        thumb_bytes = generate_thumbnail(upload_bytes)
        if thumb_bytes:
            thumb_result = s3_upload_file(
                thumb_bytes, f"thumb_{filename}", content_type="image/jpeg", is_thumbnail=True,
            )
            thumbnail_url = thumb_result["s3_url"]

    extracted_text = None
    if content_type in _TEXT_EXTRACTABLE:
        extracted_text = _extract_text(file_bytes, content_type, filename)

    return {
        "id": attachment_id,
        "filename": upload_result["s3_key"].rsplit("/", 1)[-1],
        "original_filename": filename,
        "content_type": content_type,
        "size_bytes": len(file_bytes),
        "s3_key": upload_result["s3_key"],
        "s3_url": upload_result["s3_url"],
        "thumbnail_url": thumbnail_url,
        "extracted_text": extracted_text,
        "source": source,
    }


def copy_attachments_to_workspace(
    attachments: list[dict],
    workspace_path: str,
) -> list[dict]:
    attachments_dir = os.path.join(workspace_path, "attachments")
    os.makedirs(attachments_dir, exist_ok=True)

    updated = []
    for att in attachments:
        s3_key = att.get("s3_key")
        if not s3_key:
            updated.append(att)
            continue

        file_bytes = download_file_bytes(s3_key)
        if not file_bytes:
            logger.warning("media_download_failed s3_key=%s", s3_key)
            updated.append(att)
            continue

        local_filename = att.get("original_filename") or att.get("filename", "file")
        local_path = os.path.join(attachments_dir, local_filename)

        if os.path.exists(local_path):
            base, ext = os.path.splitext(local_filename)
            local_path = os.path.join(attachments_dir, f"{base}_{att['id'][:8]}{ext}")

        with open(local_path, "wb") as f:
            f.write(file_bytes)

        updated.append({**att, "local_path": local_path})

    return updated


def build_attachment_context(attachments: list[dict]) -> str:
    if not attachments:
        return ""

    lines = [
        "\n## Attached Files",
        "The user attached files to their message. They are available in your workspace:\n",
    ]

    for att in attachments:
        local_path = att.get("local_path", att.get("original_filename", "file"))
        ct = att.get("content_type", "unknown")
        size_str = _format_size(att.get("size_bytes", 0))

        if ct in _IMAGE_TYPES or ct == "image/jpeg":
            lines.append(f"- **{local_path}** ({ct}, {size_str}) — Use the Read tool to view this image.")
        elif att.get("extracted_text"):
            lines.append(f"- **{local_path}** ({ct}, {size_str}) — Content extracted below.")
        else:
            lines.append(f"- **{local_path}** ({ct}, {size_str})")

    for att in attachments:
        if att.get("extracted_text"):
            name = att.get("original_filename", "document")
            lines.append(f"\n### Document Content — {name}\n")
            lines.append(f"```\n{att['extracted_text']}\n```")

    return "\n".join(lines)


def _extract_text(file_bytes: bytes, content_type: str, filename: str) -> str | None:
    try:
        if content_type == "application/pdf":
            return _extract_pdf_text(file_bytes)
        elif content_type in ("text/plain", "text/csv", "text/markdown", "text/html",
                              "application/json", "application/xml", "text/xml"):
            return file_bytes.decode("utf-8", errors="replace")[:_MAX_EXTRACTED_TEXT]
    except Exception:
        logger.warning("text_extraction_failed filename=%s content_type=%s", filename, content_type)
    return None


def _extract_pdf_text(file_bytes: bytes) -> str | None:
    try:
        import PyPDF2
    except ImportError:
        logger.warning("PyPDF2 not installed — PDF text extraction unavailable")
        return None
    try:
        reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
        pages = []
        total_chars = 0
        for page in reader.pages:
            text = page.extract_text() or ""
            pages.append(text)
            total_chars += len(text)
            if total_chars >= _MAX_EXTRACTED_TEXT:
                break
        return "\n\n".join(pages)[:_MAX_EXTRACTED_TEXT]
    except Exception:
        logger.warning("pdf_extraction_failed")
        return None


def _format_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f}KB"
    return f"{size_bytes / (1024 * 1024):.1f}MB"
