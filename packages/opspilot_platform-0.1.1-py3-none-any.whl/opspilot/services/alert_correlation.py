import hashlib
import json
import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models.alert_groups import AlertGroup, AlertGroupStatus

logger = logging.getLogger(__name__)

CORRELATION_WINDOW_SECONDS = 300  # 5 minutes

# Labels excluded from fingerprinting — volatile per-instance values
_VOLATILE_LABELS = frozenset({
    "instance", "pod", "replica", "pod_name", "container_id",
    "host", "hostname", "node", "timestamp", "ts",
})

# Keys tried (in order) to extract the alert name from a payload
_NAME_KEYS = ("alertname", "alert", "name", "title", "alert_name", "rule_name")

# Keys tried (in order) to extract labels/tags from a payload
_LABEL_KEYS = ("labels", "commonLabels", "tags", "dimensions", "metadata")


def compute_fingerprint(payload: dict) -> str:
    """Compute a deterministic fingerprint from an alert payload.

    Works with AlertManager, Datadog, PagerDuty, Grafana, and custom webhooks.
    Strategy:
      1. Extract alert name from well-known keys
      2. Extract labels dict from well-known keys
      3. Sort labels, exclude volatile keys
      4. SHA256(alertname + sorted_labels)[:32]
      5. Fallback: SHA256 of sorted top-level string values
    """
    # 1. Extract alert name
    alertname = ""
    for key in _NAME_KEYS:
        if key in payload and isinstance(payload[key], str):
            alertname = payload[key]
            break

    # 2. Extract labels
    labels: dict = {}
    for key in _LABEL_KEYS:
        val = payload.get(key)
        if isinstance(val, dict):
            labels = val
            break
        if isinstance(val, list) and val and isinstance(val[0], str):
            # Tags as list of strings (e.g. Datadog: ["env:prod", "service:api"])
            labels = {}
            for tag in val:
                if ":" in tag:
                    k, v = tag.split(":", 1)
                    labels[k] = v
            break

    # 3. Stable labels (exclude volatile)
    stable = {k: str(v) for k, v in sorted(labels.items()) if k.lower() not in _VOLATILE_LABELS}

    # 4. Build fingerprint
    if alertname or stable:
        raw = f"{alertname}:{json.dumps(stable, sort_keys=True)}"
    else:
        # Fallback: hash all top-level string values
        parts = sorted(f"{k}={v}" for k, v in payload.items() if isinstance(v, (str, int, float)))
        raw = "|".join(parts) if parts else json.dumps(payload, sort_keys=True)

    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def _extract_alert_summary(payload: dict) -> str:
    """Extract a human-readable summary from the alert payload."""
    for key in ("message", "description", "summary", "text", "body"):
        val = payload.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()[:500]

    for key in _NAME_KEYS:
        val = payload.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    return "alert"


async def find_or_create_group(
    db: AsyncSession,
    project_id: uuid.UUID,
    task_id: uuid.UUID,
    webhook_event_id: uuid.UUID,
    payload: dict,
) -> tuple[AlertGroup, bool]:
    """Find an active COLLECTING group matching the fingerprint, or create a new one.

    Uses SELECT FOR UPDATE to prevent race conditions when multiple webhooks
    arrive simultaneously.

    Returns (group, is_new_group).
    """
    fingerprint = compute_fingerprint(payload)
    now = datetime.now(timezone.utc)

    # Find active collecting group with same fingerprint
    stmt = (
        select(AlertGroup)
        .where(
            AlertGroup.project_id == project_id,
            AlertGroup.task_id == task_id,
            AlertGroup.fingerprint == fingerprint,
            AlertGroup.status == AlertGroupStatus.COLLECTING,
            AlertGroup.window_expires_at > now,
        )
        .with_for_update()
        .limit(1)
    )
    result = await db.execute(stmt)
    group = result.scalar_one_or_none()

    alert_entry = {
        "event_id": str(webhook_event_id),
        "alertname": _extract_alert_summary(payload),
        "received_at": now.isoformat(),
    }

    if group:
        # Append to existing group — copy list to trigger JSONB mutation detection
        group.alerts = [*group.alerts, alert_entry]
        group.alert_count = len(group.alerts)
        logger.info(
            "alert_correlated group_id=%s fingerprint=%s count=%s",
            group.id, fingerprint, group.alert_count,
        )
        return group, False

    # Create new group
    window_expires = now + timedelta(seconds=CORRELATION_WINDOW_SECONDS)
    group = AlertGroup(
        project_id=project_id,
        task_id=task_id,
        fingerprint=fingerprint,
        status=AlertGroupStatus.COLLECTING,
        alerts=[alert_entry],
        alert_count=1,
        window_expires_at=window_expires,
    )
    db.add(group)
    await db.flush()
    logger.info(
        "alert_group_created group_id=%s fingerprint=%s expires_at=%s",
        group.id, fingerprint, window_expires.isoformat(),
    )
    return group, True


async def dispatch_group(db: AsyncSession, group_id: uuid.UUID) -> AlertGroup | None:
    """Transition a group from COLLECTING to DISPATCHED.

    Returns the group if dispatched, or None if already dispatched (idempotent).
    """
    stmt = (
        select(AlertGroup)
        .where(
            AlertGroup.id == group_id,
            AlertGroup.status == AlertGroupStatus.COLLECTING,
        )
        .with_for_update()
    )
    result = await db.execute(stmt)
    group = result.scalar_one_or_none()

    if not group:
        logger.info("alert_group_already_dispatched group_id=%s", group_id)
        return None

    group.status = AlertGroupStatus.DISPATCHED
    group.dispatched_at = datetime.now(timezone.utc)
    logger.info(
        "alert_group_dispatched group_id=%s alert_count=%s",
        group.id, group.alert_count,
    )
    return group


def build_aggregated_payload(group: AlertGroup) -> dict:
    """Build a single payload dict from the group's collected alerts."""
    received_times = []
    for a in group.alerts:
        ts = a.get("received_at")
        if ts:
            received_times.append(ts)

    return {
        "alert_group_id": str(group.id),
        "fingerprint": group.fingerprint,
        "alert_count": group.alert_count,
        "alerts": group.alerts,
        "first_received_at": min(received_times) if received_times else None,
        "last_received_at": max(received_times) if received_times else None,
        "summary": f"{group.alert_count} correlated alert(s) with fingerprint {group.fingerprint[:12]}...",
    }


async def find_stale_collecting_groups(db: AsyncSession) -> list[AlertGroup]:
    """Find COLLECTING groups whose window has expired — safety net for lost countdown tasks."""
    now = datetime.now(timezone.utc)
    stmt = (
        select(AlertGroup)
        .where(
            AlertGroup.status == AlertGroupStatus.COLLECTING,
            AlertGroup.window_expires_at <= now,
        )
        .limit(50)
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())
