import uuid
import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models.knowledge import KnowledgeEntry
from opspilot.schemas.knowledge import KnowledgeEntryCreate, KnowledgeEntryUpdate
from opspilot.services.embeddings import delete_entity_embedding, schedule_indexing
from opspilot.services.search import RERANK_MIN_CANDIDATES, bm25_search, hybrid_search

logger = logging.getLogger(__name__)


async def get_knowledge(db: AsyncSession, project_id: uuid.UUID, knowledge_id: uuid.UUID) -> KnowledgeEntry | None:
    result = await db.execute(
        select(KnowledgeEntry)
        .where(KnowledgeEntry.id == knowledge_id)
        .where(KnowledgeEntry.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def create_knowledge(db: AsyncSession, project_id: uuid.UUID, data: KnowledgeEntryCreate) -> KnowledgeEntry:
    entry = KnowledgeEntry(
        title=data.title,
        content=data.content,
        category=data.category,
        tags=data.tags or [],
        session_id=data.session_id,
        project_id=project_id,
    )
    db.add(entry)
    await db.flush()
    await db.refresh(entry)
    logger.info("knowledge_created id=%s title=%s", entry.id, entry.title)
    schedule_indexing("knowledge", entry.id, f"{entry.title}\n\n{entry.content}")
    return entry


async def list_knowledge(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    category: str | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 20,
    offset: int = 0,
    rerank: bool = False,
) -> list[KnowledgeEntry]:
    filters = [KnowledgeEntry.project_id == project_id]
    if category:
        filters.append(KnowledgeEntry.category == category)

    if query:
        matching_ids = await hybrid_search("knowledge", query, limit=limit)
        if not matching_ids:
            return []
        if rerank and len(matching_ids) > RERANK_MIN_CANDIDATES:
            from opspilot.services.search import rerank as rerank_fn
            matching_ids = await rerank_fn(query, matching_ids, "knowledge", limit=limit)
        stmt = select(KnowledgeEntry).where(KnowledgeEntry.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        entries_map = {e.id: e for e in result.scalars().all()}
        return [entries_map[mid] for mid in matching_ids if mid in entries_map]

    if keyword:
        matching_ids = await bm25_search("knowledge", keyword, limit=limit)
        if not matching_ids:
            return []
        stmt = select(KnowledgeEntry).where(KnowledgeEntry.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        entries_map = {e.id: e for e in result.scalars().all()}
        return [entries_map[mid] for mid in matching_ids if mid in entries_map]

    stmt = select(KnowledgeEntry).order_by(KnowledgeEntry.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_knowledge(db: AsyncSession, project_id: uuid.UUID, *, category: str | None = None) -> int:
    stmt = select(func.count()).select_from(KnowledgeEntry)
    stmt = stmt.where(KnowledgeEntry.project_id == project_id)
    if category:
        stmt = stmt.where(KnowledgeEntry.category == category)
    return await db.scalar(stmt)


async def update_knowledge(
    db: AsyncSession, project_id: uuid.UUID, knowledge_id: uuid.UUID, data: KnowledgeEntryUpdate
) -> KnowledgeEntry | None:
    entry = await get_knowledge(db, project_id, knowledge_id)
    if not entry:
        return None
    updated = data.model_dump(exclude_unset=True)
    reindex = False
    for field, value in updated.items():
        setattr(entry, field, value)
        if field in ("title", "content"):
            reindex = True
    await db.refresh(entry)
    logger.info("knowledge_updated id=%s", knowledge_id)
    if reindex:
        schedule_indexing("knowledge", entry.id, f"{entry.title}\n\n{entry.content}")
    return entry


async def delete_knowledge(db: AsyncSession, project_id: uuid.UUID, knowledge_id: uuid.UUID) -> bool:
    entry = await get_knowledge(db, project_id, knowledge_id)
    if not entry:
        return False
    await db.delete(entry)
    await delete_entity_embedding(db, "knowledge", knowledge_id)
    logger.info("knowledge_deleted id=%s", knowledge_id)
    return True
