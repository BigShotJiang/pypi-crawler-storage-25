import uuid
import logging
import mimetypes

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import StoredFile
from opspilot.services.storage import (
    delete_file as s3_delete_file,
    generate_thumbnail,
    is_image,
    optimize_image,
    upload_file as s3_upload_file,
    validate_file_extension,
    validate_file_size,
)

logger = logging.getLogger(__name__)


async def upload_file(
    db: AsyncSession,
    project_id: uuid.UUID,
    file_path: str,
    *,
    folder: str | None = None,
    session_id: uuid.UUID | None = None,
) -> StoredFile:
    """Read a local file, validate, upload to S3, and persist the DB record.

    Raises FileNotFoundError or OSError if the file cannot be read.
    Raises ValueError if the file extension or size is invalid.
    """
    with open(file_path, "rb") as f:
        content = f.read()

    original_filename = file_path.rsplit("/", 1)[-1]

    if not validate_file_extension(original_filename):
        raise ValueError(f"File type not allowed: {original_filename.rsplit('.', 1)[-1]!r}")
    if not validate_file_size(len(content)):
        raise ValueError("File exceeds maximum allowed size")

    content_type, _ = mimetypes.guess_type(original_filename)
    content_type = content_type or "application/octet-stream"

    is_optimized = False
    if is_image(content_type):
        content = optimize_image(content)
        is_optimized = True
        content_type = "image/jpeg"

    upload_result = s3_upload_file(content, original_filename, content_type=content_type)

    thumbnail_s3_key = None
    thumbnail_url = None
    if is_image(content_type):
        thumb_bytes = generate_thumbnail(content)
        if thumb_bytes:
            thumb_result = s3_upload_file(
                thumb_bytes,
                f"thumb_{original_filename}",
                content_type="image/jpeg",
                is_thumbnail=True,
            )
            thumbnail_s3_key = thumb_result["s3_key"]
            thumbnail_url = thumb_result["s3_url"]

    item = StoredFile(
        filename=upload_result["s3_key"].rsplit("/", 1)[-1],
        original_filename=original_filename,
        content_type=upload_result["content_type"],
        file_size_bytes=upload_result["file_size_bytes"],
        s3_key=upload_result["s3_key"],
        s3_url=upload_result["s3_url"],
        folder=folder,
        thumbnail_s3_key=thumbnail_s3_key,
        thumbnail_url=thumbnail_url,
        is_optimized=is_optimized,
        session_id=session_id,
        project_id=project_id,
    )
    db.add(item)
    await db.flush()

    logger.info(
        "file_uploaded id=%s original=%r url=%s",
        item.id, original_filename, upload_result["s3_url"],
    )
    return item


async def list_files(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    folder: str | None = None,
    search: str | None = None,
    content_type: str | None = None,
    sort_by: str = "uploaded_at",
    sort_order: str = "desc",
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[StoredFile], int]:
    """List stored files with filtering, sorting, and pagination.

    Returns (items, total_count).
    """
    from sqlalchemy import func

    _SORTABLE_COLS = {"uploaded_at", "original_filename", "file_size_bytes"}
    col_name = sort_by if sort_by in _SORTABLE_COLS else "uploaded_at"
    sort_col = getattr(StoredFile, col_name)
    sort_expr = sort_col.desc() if sort_order == "desc" else sort_col.asc()

    base_stmt = select(StoredFile).where(StoredFile.project_id == project_id)
    if folder is not None:
        base_stmt = base_stmt.where(StoredFile.folder == folder)
    if search:
        base_stmt = base_stmt.where(StoredFile.original_filename.ilike(f"%{search}%"))
    if content_type:
        base_stmt = base_stmt.where(StoredFile.content_type.ilike(f"{content_type}%"))

    count_result = await db.execute(select(func.count()).select_from(base_stmt.subquery()))
    total = count_result.scalar_one()

    result = await db.execute(base_stmt.order_by(sort_expr).limit(limit).offset(offset))
    return list(result.scalars().all()), total


async def get_file(
    db: AsyncSession,
    project_id: uuid.UUID,
    file_id: uuid.UUID,
) -> StoredFile | None:
    """Get a single stored file by ID, scoped to the project."""
    result = await db.execute(
        select(StoredFile)
        .where(StoredFile.id == file_id)
        .where(StoredFile.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def get_quota(
    db: AsyncSession,
    project_id: uuid.UUID,
) -> dict:
    """Return storage quota usage: used_bytes and file_count."""
    from sqlalchemy import func

    result = await db.execute(
        select(
            func.coalesce(func.sum(StoredFile.file_size_bytes), 0),
            func.count(StoredFile.id),
        ).where(StoredFile.project_id == project_id)
    )
    used_bytes, file_count = result.one()
    return {"used_bytes": used_bytes, "file_count": file_count}


async def bulk_delete_files(
    db: AsyncSession,
    project_id: uuid.UUID,
    file_ids: list[uuid.UUID],
) -> tuple[int, list[str]]:
    """Delete multiple files. Returns (deleted_count, failed_ids)."""
    deleted_count = 0
    failed_ids: list[str] = []
    for fid in file_ids:
        result = await db.execute(
            select(StoredFile)
            .where(StoredFile.id == fid)
            .where(StoredFile.project_id == project_id)
        )
        item = result.scalar_one_or_none()
        if not item:
            failed_ids.append(str(fid))
            continue
        s3_delete_file(item.s3_key)
        if item.thumbnail_s3_key:
            s3_delete_file(item.thumbnail_s3_key)
        await db.delete(item)
        deleted_count += 1
    logger.info("bulk_delete_files count=%d failed=%d", deleted_count, len(failed_ids))
    return deleted_count, failed_ids


async def delete_file(
    db: AsyncSession,
    project_id: uuid.UUID,
    file_id: uuid.UUID,
) -> bool:
    """Delete a stored file from S3 and the database. Returns True if deleted."""
    result = await db.execute(
        select(StoredFile)
        .where(StoredFile.id == file_id)
        .where(StoredFile.project_id == project_id)
    )
    item = result.scalar_one_or_none()
    if not item:
        return False

    s3_delete_file(item.s3_key)
    if item.thumbnail_s3_key:
        s3_delete_file(item.thumbnail_s3_key)
    await db.delete(item)

    logger.info("file_deleted id=%s original=%r", file_id, item.original_filename)
    return True
