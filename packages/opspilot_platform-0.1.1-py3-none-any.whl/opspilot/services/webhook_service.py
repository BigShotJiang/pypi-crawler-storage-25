import logging
import uuid
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import Task, WebhookEvent
from opspilot.services import alert_correlation

logger = logging.getLogger(__name__)


@dataclass
class WebhookResult:
    """Result of processing a webhook event."""
    session_id: uuid.UUID | None = None
    alert_group_id: uuid.UUID | None = None
    alert_count: int | None = None
    message: str = ""


async def process_webhook_event(
    db: AsyncSession,
    task: Task,
    event: WebhookEvent,
    payload: dict,
) -> WebhookResult:
    """Process a webhook event — either via alert correlation or direct dispatch.

    Decides based on task.pre_run_context.alert_correlation whether to buffer
    alerts into groups or dispatch immediately.
    """
    use_correlation = (task.pre_run_context or {}).get("alert_correlation", False)

    if use_correlation:
        return await _process_correlated(db, task, event, payload)

    return await _process_direct(db, task, event, payload)


async def _process_correlated(
    db: AsyncSession,
    task: Task,
    event: WebhookEvent,
    payload: dict,
) -> WebhookResult:
    """Buffer alert into an AlertGroup. Schedule dispatch after correlation window."""
    group, is_new = await alert_correlation.find_or_create_group(
        db, task.project_id, task.id, event.id, payload,
    )
    event.processing_status = "correlated"
    await db.flush()

    if is_new:
        from opspilot.worker.tasks import dispatch_alert_group
        dispatch_alert_group.apply_async(
            args=[str(group.id)],
            countdown=alert_correlation.CORRELATION_WINDOW_SECONDS,
        )

    logger.info(
        "webhook_correlated task_id=%s group_id=%s count=%s event_id=%s",
        task.id, group.id, group.alert_count, event.id,
    )
    return WebhookResult(
        alert_group_id=group.id,
        alert_count=group.alert_count,
        message=f"Alert correlated into group {group.id} ({group.alert_count} alert(s))",
    )


async def _process_direct(
    db: AsyncSession,
    task: Task,
    event: WebhookEvent,
    payload: dict,
) -> WebhookResult:
    """Dispatch a single agent session immediately (no correlation)."""
    session_id = uuid.uuid4()

    from opspilot.worker.tasks import run_agent_session
    run_agent_session.delay(
        str(task.id),
        str(session_id),
        trigger_source="webhook",
        webhook_event_id=str(event.id),
        webhook_payload=payload,
    )

    event.processing_status = "queued"
    await db.flush()

    logger.info("webhook_triggered task_id=%s session_id=%s event_id=%s", task.id, session_id, event.id)
    return WebhookResult(
        session_id=session_id,
        message=f"Session {session_id} queued via webhook",
    )
