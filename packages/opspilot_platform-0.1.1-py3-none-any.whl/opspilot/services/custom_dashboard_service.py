"""Custom dashboard service — CRUD and screenshot for agent-created dashboards."""
import logging
import uuid

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import CustomDashboard
from opspilot.schemas.custom_dashboards import CustomDashboardUpdate
from opspilot.services.storage import upload_file

logger = logging.getLogger(__name__)


async def create_custom_dashboard(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    title: str,
    description: str | None = None,
    content_html: str,
    task_id: uuid.UUID | None = None,
    session_id: uuid.UUID | None = None,
) -> CustomDashboard:
    html_bytes = content_html.encode("utf-8")
    dashboard = CustomDashboard(
        project_id=project_id,
        task_id=task_id,
        session_id=session_id,
        title=title,
        description=description,
    )
    db.add(dashboard)
    await db.flush()

    upload_result = upload_file(html_bytes, f"dashboard-{dashboard.id}.html", "text/html")
    dashboard.s3_url = upload_result["s3_url"]
    await db.flush()

    logger.info("custom_dashboard_created id=%s url=%s", dashboard.id, dashboard.s3_url)
    return dashboard


async def list_custom_dashboards(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    search: str | None = None,
    limit: int = 25,
    offset: int = 0,
) -> tuple[list[CustomDashboard], int]:
    filters = [CustomDashboard.project_id == project_id]
    if search:
        pattern = f"%{search}%"
        filters.append(
            CustomDashboard.title.ilike(pattern) | CustomDashboard.description.ilike(pattern)
        )

    count_stmt = select(func.count()).select_from(CustomDashboard)
    stmt = (
        select(CustomDashboard)
        .order_by(
            CustomDashboard.is_favorite.desc(),
            CustomDashboard.sort_order.asc(),
            CustomDashboard.updated_at.desc(),
        )
        .limit(limit)
        .offset(offset)
    )
    for f in filters:
        count_stmt = count_stmt.where(f)
        stmt = stmt.where(f)

    total = await db.scalar(count_stmt)
    result = await db.execute(stmt)
    return list(result.scalars().all()), total or 0


async def get_custom_dashboard(
    db: AsyncSession,
    project_id: uuid.UUID,
    dashboard_id: uuid.UUID,
) -> CustomDashboard | None:
    stmt = (
        select(CustomDashboard)
        .where(CustomDashboard.id == dashboard_id)
        .where(CustomDashboard.project_id == project_id)
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def update_custom_dashboard(
    db: AsyncSession,
    project_id: uuid.UUID,
    dashboard_id: uuid.UUID,
    data: CustomDashboardUpdate,
) -> CustomDashboard | None:
    dashboard = await get_custom_dashboard(db, project_id, dashboard_id)
    if not dashboard:
        return None

    updates = data.model_dump(exclude_unset=True)
    content_html = updates.pop("content_html", None)

    for key, value in updates.items():
        setattr(dashboard, key, value)

    if content_html is not None:
        html_bytes = content_html.encode("utf-8")
        upload_result = upload_file(html_bytes, f"dashboard-{dashboard.id}.html", "text/html")
        dashboard.s3_url = upload_result["s3_url"]

    await db.flush()
    await db.refresh(dashboard)
    logger.info("custom_dashboard_updated id=%s", dashboard.id)
    return dashboard


async def toggle_favorite(
    db: AsyncSession,
    project_id: uuid.UUID,
    dashboard_id: uuid.UUID,
) -> CustomDashboard | None:
    dashboard = await get_custom_dashboard(db, project_id, dashboard_id)
    if not dashboard:
        return None
    dashboard.is_favorite = not dashboard.is_favorite
    if not dashboard.is_favorite:
        dashboard.sort_order = 0
    await db.flush()
    logger.info("custom_dashboard_toggle_favorite id=%s favorite=%s", dashboard.id, dashboard.is_favorite)
    return dashboard


async def reorder_favorites(
    db: AsyncSession,
    project_id: uuid.UUID,
    items: list[dict],
) -> None:
    """Update sort_order for a list of dashboard IDs. items = [{"id": uuid, "sort_order": int}, ...]"""
    for item in items:
        dashboard = await get_custom_dashboard(db, project_id, item["id"])
        if dashboard and dashboard.is_favorite:
            dashboard.sort_order = item["sort_order"]
    await db.flush()
    logger.info("custom_dashboard_reorder count=%d", len(items))


async def delete_custom_dashboard(
    db: AsyncSession,
    project_id: uuid.UUID,
    dashboard_id: uuid.UUID,
) -> bool:
    dashboard = await get_custom_dashboard(db, project_id, dashboard_id)
    if not dashboard:
        return False
    await db.delete(dashboard)
    logger.info("custom_dashboard_deleted id=%s", dashboard_id)
    return True


async def screenshot_custom_dashboard(
    db: AsyncSession,
    project_id: uuid.UUID,
    dashboard_id: uuid.UUID,
) -> CustomDashboard | None:
    dashboard = await get_custom_dashboard(db, project_id, dashboard_id)
    if not dashboard or not dashboard.s3_url:
        return None

    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ValueError("Playwright is not installed. Install with: uv add playwright && playwright install chromium")

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1280, "height": 800})
        await page.goto(dashboard.s3_url, wait_until="networkidle")
        png_bytes = await page.screenshot(full_page=True, type="png")
        await browser.close()

    upload_result = upload_file(png_bytes, f"dashboard-{dashboard.id}-thumb.png", "image/png")
    dashboard.thumbnail_url = upload_result["s3_url"]

    await db.flush()
    await db.refresh(dashboard)
    logger.info("custom_dashboard_screenshot id=%s thumb=%s", dashboard.id, dashboard.thumbnail_url)
    return dashboard
