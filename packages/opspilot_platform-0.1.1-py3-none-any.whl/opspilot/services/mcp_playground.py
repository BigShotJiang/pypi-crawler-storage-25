"""MCP Playground service — transport-agnostic tool discovery and invocation.

Routes list_tools / call_tool calls to the correct MCP client based on the
server's transport type:

  is_internal=True  → in-process FastMCP Client (fastest, no network hop)
  transport=stdio   → JSON-RPC subprocess via mcp_client module
  transport=http | streamable-http → FastMCP Client over HTTP/SSE

Raises:
    ValueError: for tool-level errors returned by the server (bad input / not found).
    RuntimeError: for connectivity or timeout failures.
"""

import json
import logging
from typing import TYPE_CHECKING, Any

from fastmcp import Client
from fastmcp.exceptions import ToolError

from opspilot.services import mcp_client

if TYPE_CHECKING:
    from opspilot.models import McpServer

logger = logging.getLogger(__name__)


def _get_mcp_instance(slug: str):
    """Return the in-process FastMCP server instance for a given slug."""
    from opspilot.main import (  # noqa: PLC0415
        mcp_core,
        mcp_google,
        mcp_jira,
        mcp_notify,
        mcp_slack,
        mcp_tasks,
    )

    registry = {
        "opspilot": mcp_core,
        "opspilot-notify": mcp_notify,
        "opspilot-google": mcp_google,
        "opspilot-slack": mcp_slack,
        "opspilot-jira": mcp_jira,
        "opspilot-tasks": mcp_tasks,
    }
    instance = registry.get(slug)
    if instance is None:
        raise RuntimeError(f"Unknown internal MCP server slug: '{slug}'")
    return instance


def _parse_fastmcp_result(result) -> Any:
    """Extract and JSON-parse text content from a FastMCP CallToolResult."""
    content = getattr(result, "content", result) or []
    if not isinstance(content, list):
        content = [content]
    text_parts = [c.text for c in content if hasattr(c, "text")]
    raw = "\n".join(text_parts)
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw


# ─── Public API ───────────────────────────────────────────────────────────────

async def list_tools(server: "McpServer") -> list[dict]:
    """Return all tools exposed by the server as {name, description, inputSchema} dicts."""
    if server.is_internal:
        return await _list_internal(server.slug)
    if server.transport in ("http", "streamable-http"):
        return await _list_http(server.url)
    return await _list_stdio(server.command, server.args, server.env)


async def call_tool(server: "McpServer", tool_name: str, params: dict) -> Any:
    """Invoke a tool on the server and return the parsed result.

    Raises:
        ValueError: if the server returns a tool-level error.
        RuntimeError: for connectivity / timeout failures.
    """
    if server.is_internal:
        return await _call_internal(server.slug, tool_name, params)
    if server.transport in ("http", "streamable-http"):
        return await _call_http(server.url, tool_name, params)
    return await _call_stdio(server.command, server.args, server.env, tool_name, params)


# ─── Internal (in-process FastMCP) ────────────────────────────────────────────

async def _list_internal(slug: str) -> list[dict]:
    async with Client(_get_mcp_instance(slug)) as client:
        tools = await client.list_tools()
    return [
        {"name": t.name, "description": t.description, "inputSchema": t.inputSchema}
        for t in tools
    ]


async def _call_internal(slug: str, tool_name: str, params: dict) -> Any:
    try:
        async with Client(_get_mcp_instance(slug)) as client:
            result = await client.call_tool(tool_name, params)
    except ToolError as exc:
        raise ValueError(str(exc)) from exc
    return _parse_fastmcp_result(result)


# ─── HTTP / SSE ───────────────────────────────────────────────────────────────

async def _list_http(url: str) -> list[dict]:
    async with Client(url) as client:
        tools = await client.list_tools()
    return [
        {"name": t.name, "description": t.description, "inputSchema": t.inputSchema}
        for t in tools
    ]


async def _call_http(url: str, tool_name: str, params: dict) -> Any:
    try:
        async with Client(url) as client:
            result = await client.call_tool(tool_name, params)
    except ToolError as exc:
        raise ValueError(str(exc)) from exc
    return _parse_fastmcp_result(result)


# ─── Stdio ────────────────────────────────────────────────────────────────────

async def _list_stdio(
    command: str,
    args: list[str] | None,
    env: dict[str, str] | None,
) -> list[dict]:
    return await mcp_client.list_tools(command, args, env)


async def _call_stdio(
    command: str,
    args: list[str] | None,
    env: dict[str, str] | None,
    tool_name: str,
    params: dict,
) -> Any:
    raw = await mcp_client.call_tool(command, args, env, tool_name, params)
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw
