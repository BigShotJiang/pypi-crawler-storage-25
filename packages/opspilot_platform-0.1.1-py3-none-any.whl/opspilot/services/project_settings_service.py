"""Service layer for ProjectSettings - project-scoped branding, theme, and notifications config."""

import logging
import uuid
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import ProjectSettings
from opspilot.schemas.integrations import ProjectSettingOut, ProjectSettingUpdate

logger = logging.getLogger(__name__)


async def get_project_settings(db: AsyncSession, project_id: uuid.UUID) -> ProjectSettingOut | None:
    """Get project settings by project_id.

    Returns None if no settings exist for this project.
    """
    stmt = select(ProjectSettings).where(ProjectSettings.project_id == project_id)
    result = await db.execute(stmt)
    settings = result.scalar_one_or_none()
    return ProjectSettingOut.model_validate(settings) if settings else None


async def get_or_create_default_settings(
    db: AsyncSession, project_id: uuid.UUID
) -> ProjectSettingOut:
    """Get project settings, or create with defaults if they don't exist.

    Default values:
    - brand_name: "OpsPilot"
    - theme_preset: "darkGold"
    - theme_mode: "dark"
    - Other theme colors: darkGold palette
    """
    settings = await get_project_settings(db, project_id)
    if settings:
        return settings

    # Create default settings
    logger.info("Creating default ProjectSettings for project_id=%s", project_id)

    new_settings = ProjectSettings(
        id=uuid.uuid4(),
        project_id=project_id,
        brand_name="OpsPilot",
        brand_tagline="Agentic Operations Platform",
        theme_preset="darkGold",
        theme_mode="dark",
        theme_primary="#d4af37",
        theme_primary_foreground="#000000",
        theme_background="#050505",
        theme_foreground="#f5f5f5",
        theme_card="#0f0f17",
        theme_card_foreground="#f5f5f5",
        theme_secondary="#6366f1",
        theme_secondary_foreground="#ffffff",
        theme_accent="#0f0f17",
        theme_accent_foreground="#d4af37",
        theme_muted="#11131a",
        theme_muted_foreground="#a0aec0",
        theme_border="#1f1f28",
        smtp_use_tls=True,
    )
    db.add(new_settings)
    await db.flush()
    logger.info("Created default ProjectSettings id=%s for project_id=%s", new_settings.id, project_id)
    return ProjectSettingOut.model_validate(new_settings)


async def update_project_settings(
    db: AsyncSession, project_id: uuid.UUID, data: ProjectSettingUpdate
) -> ProjectSettingOut:
    """Update project settings with provided fields.

    Creates with defaults if settings don't exist.
    """
    # Get or create
    stmt = select(ProjectSettings).where(ProjectSettings.project_id == project_id)
    result = await db.execute(stmt)
    settings = result.scalar_one_or_none()

    if not settings:
        # Create with defaults first, then update with provided data
        default_settings = await get_or_create_default_settings(db, project_id)
        stmt = select(ProjectSettings).where(ProjectSettings.project_id == project_id)
        result = await db.execute(stmt)
        settings = result.scalar_one_or_none()

    # Update fields
    update_data = data.model_dump(exclude_unset=True, exclude_none=True)
    for key, value in update_data.items():
        setattr(settings, key, value)

    await db.flush()
    logger.info(
        "Updated ProjectSettings for project_id=%s with keys=%s",
        project_id,
        list(update_data.keys()),
    )

    await db.refresh(settings)
    return ProjectSettingOut.model_validate(settings)


async def delete_project_settings(db: AsyncSession, project_id: uuid.UUID) -> None:
    """Delete project settings (used for project deletion cascade)."""
    stmt = select(ProjectSettings).where(ProjectSettings.project_id == project_id)
    result = await db.execute(stmt)
    settings = result.scalar_one_or_none()

    if settings:
        await db.delete(settings)
        logger.info("Deleted ProjectSettings for project_id=%s", project_id)
