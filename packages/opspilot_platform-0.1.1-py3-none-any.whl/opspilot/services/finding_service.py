import uuid
from datetime import datetime, timezone
import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import Finding
from opspilot.models.conversations import Session
from opspilot.models.findings import FindingType
from opspilot.models.common import Severity
from opspilot.schemas.findings import FindingCreate, FindingUpdate
from opspilot.services.embeddings import schedule_indexing
from opspilot.services.search import RERANK_MIN_CANDIDATES, bm25_search, hybrid_search

logger = logging.getLogger(__name__)


async def get_finding(db: AsyncSession, project_id: uuid.UUID, finding_id: uuid.UUID) -> Finding | None:
    result = await db.execute(
        select(Finding)
        .where(Finding.id == finding_id)
        .where(Finding.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def create_finding(db: AsyncSession, project_id: uuid.UUID, data: FindingCreate) -> Finding:
    finding = Finding(
        finding_type=data.finding_type,
        severity=data.severity,
        title=data.title,
        summary=data.summary,
        affected_components=data.affected_components,
        evidence=data.evidence,
        recommendation=data.recommendation,
        session_id=data.session_id,
        project_id=project_id,
    )
    db.add(finding)
    await db.flush()
    if data.session_id:
        session_row = await db.get(Session, data.session_id)
        if session_row:
            session_row.findings_count = (session_row.findings_count or 0) + 1
    logger.info("finding_created id=%s severity=%s type=%s", finding.id, data.severity, data.finding_type)
    schedule_indexing(
        "finding", finding.id,
        f"{finding.title}\n\n{finding.summary or ''}\n\n{finding.recommendation or ''}".strip(),
    )
    return finding


async def list_findings(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    session_id: uuid.UUID | None = None,
    severity: Severity | None = None,
    finding_type: FindingType | None = None,
    acknowledged: bool | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 50,
    offset: int = 0,
    rerank: bool = False,
) -> list[Finding]:
    filters = [Finding.project_id == project_id]
    if session_id:
        filters.append(Finding.session_id == session_id)
    if severity:
        filters.append(Finding.severity == severity)
    if finding_type:
        filters.append(Finding.finding_type == finding_type)
    if acknowledged is not None:
        filters.append(Finding.acknowledged == acknowledged)

    if query:
        matching_ids = await hybrid_search("finding", query, limit=limit)
        if not matching_ids:
            return []
        if rerank and len(matching_ids) > RERANK_MIN_CANDIDATES:
            from opspilot.services.search import rerank as rerank_fn
            matching_ids = await rerank_fn(query, matching_ids, "finding", limit=limit)
        stmt = select(Finding).where(Finding.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        f_map = {f.id: f for f in result.scalars().all()}
        return [f_map[mid] for mid in matching_ids if mid in f_map]

    if keyword:
        matching_ids = await bm25_search("finding", keyword, limit=limit)
        if not matching_ids:
            return []
        stmt = select(Finding).where(Finding.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        f_map = {f.id: f for f in result.scalars().all()}
        return [f_map[mid] for mid in matching_ids if mid in f_map]

    stmt = select(Finding).order_by(Finding.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_findings(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    acknowledged: bool | None = None,
    severity: Severity | None = None,
) -> int:
    stmt = select(func.count(Finding.id))
    stmt = stmt.where(Finding.project_id == project_id)
    if acknowledged is not None:
        stmt = stmt.where(Finding.acknowledged == acknowledged)
    if severity:
        stmt = stmt.where(Finding.severity == severity)
    result = await db.execute(stmt)
    return result.scalar()


async def update_finding(db: AsyncSession, project_id: uuid.UUID, finding_id: uuid.UUID, data: FindingUpdate) -> Finding | None:
    finding = await get_finding(db, project_id, finding_id)
    if not finding:
        return None
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(finding, field, value)
    return finding


async def delete_finding(db: AsyncSession, project_id: uuid.UUID, finding_id: uuid.UUID) -> bool:
    finding = await get_finding(db, project_id, finding_id)
    if not finding:
        return False
    await db.delete(finding)
    return True


async def acknowledge_finding(
    db: AsyncSession, project_id: uuid.UUID, finding_id: uuid.UUID, acknowledged_by: str | None
) -> Finding | None:
    finding = await get_finding(db, project_id, finding_id)
    if not finding:
        return None
    finding.acknowledged = True
    finding.acknowledged_at = datetime.now(timezone.utc)
    finding.acknowledged_by = acknowledged_by
    return finding
