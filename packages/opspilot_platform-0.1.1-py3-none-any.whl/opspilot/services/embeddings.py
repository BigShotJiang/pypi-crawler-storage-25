import asyncio
import logging
import os
import uuid

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.database import async_session_factory

logger = logging.getLogger(__name__)

# Set cache path before fastembed import so it finds the mounted model
os.environ.setdefault("FASTEMBED_CACHE_PATH", "/tmp/fastembed_cache")

_QUERY_PREFIX = "Represent this sentence for searching relevant passages: "
_embedder = None


def get_embedder():
    """Lazy-load fastembed model once. Thread-safe via module-level singleton."""
    global _embedder
    if _embedder is None:
        from fastembed import TextEmbedding  # noqa: PLC0415
        logger.info("loading_embedder model=mixedbread-ai/mxbai-embed-large-v1")
        _embedder = TextEmbedding(
            model_name="mixedbread-ai/mxbai-embed-large-v1",
            cache_dir="/tmp/fastembed_cache",
        )
    return _embedder


def _embed_texts(texts: list[str]) -> list[list[float]]:
    embedder = get_embedder()
    return [list(v) for v in embedder.embed(texts)]


async def embed_document_async(text_: str) -> list[float]:
    loop = asyncio.get_event_loop()
    results = await loop.run_in_executor(None, _embed_texts, [text_])
    return results[0]


async def embed_query_async(query: str) -> list[float]:
    loop = asyncio.get_event_loop()
    results = await loop.run_in_executor(None, _embed_texts, [_QUERY_PREFIX + query])
    return results[0]


async def upsert_chunks(entity_type: str, entity_id: uuid.UUID, chunks: list[str]) -> None:
    """Delete all existing chunks for entity, then embed all chunks and bulk-insert."""
    # Skip disabled entity types that shouldn't be embedded
    if entity_type in {"skill", "todo"}:
        logger.info("embedding_skipped entity_type=%s entity_id=%s", entity_type, entity_id)
        return
    loop = asyncio.get_event_loop()
    vecs = await loop.run_in_executor(None, _embed_texts, chunks)
    async with async_session_factory() as db:
        # Delete old chunks (handles chunk count reduction on updates)
        await db.execute(
            text("DELETE FROM entity_embeddings WHERE entity_type=:et AND entity_id=:eid"),
            {"et": entity_type, "eid": str(entity_id)},
        )
        # Insert all new chunks
        for chunk_index, vec in enumerate(vecs):
            vec_str = f"[{','.join(str(x) for x in vec)}]"
            await db.execute(
                text("""
                    INSERT INTO entity_embeddings
                        (entity_type, entity_id, chunk_index, embedding, updated_at)
                    VALUES (:et, :eid, :ci, CAST(:vec AS vector), now())
                    ON CONFLICT (entity_type, entity_id, chunk_index)
                    DO UPDATE SET embedding=EXCLUDED.embedding, updated_at=now()
                """),
                {"et": entity_type, "eid": str(entity_id), "ci": chunk_index, "vec": vec_str},
            )
        await db.commit()
    logger.info("upsert_chunks_done entity_type=%s entity_id=%s chunks=%d", entity_type, entity_id, len(chunks))


async def _index_entity_bg(entity_type: str, entity_id: uuid.UUID, text_to_embed: str) -> None:
    """Asyncio fallback: chunk, embed and upsert. Runs as background task — never raises."""
    try:
        from opspilot.services.chunking import chunk_text  # noqa: PLC0415
        chunks = chunk_text(text_to_embed)
        await upsert_chunks(entity_type, entity_id, chunks)
        logger.info("entity_indexed entity_type=%s entity_id=%s", entity_type, entity_id)
    except Exception:
        logger.exception("embed_failed entity_type=%s entity_id=%s", entity_type, entity_id)


def _log_task_exception(task: asyncio.Task, entity_type: str, entity_id: uuid.UUID) -> None:
    if not task.cancelled() and task.exception():
        logger.error(
            "embed_task_unhandled entity_type=%s entity_id=%s error=%s",
            entity_type, entity_id, task.exception(),
        )


def schedule_indexing(entity_type: str, entity_id: uuid.UUID, text_to_embed: str) -> None:
    """Schedule background embedding via Celery (falls back to asyncio on dispatch failure)."""
    if entity_type in {"skill", "todo"}:
        logger.info("indexing_skipped entity_type=%s entity_id=%s", entity_type, entity_id)
        return
    if not text_to_embed.strip():
        return
    try:
        from opspilot.worker.tasks import index_entity  # local import — breaks circular dep
        index_entity.delay(entity_type, str(entity_id), text_to_embed)
    except Exception:
        logger.warning("celery_dispatch_failed falling_back_to_asyncio entity_type=%s", entity_type, exc_info=True)
        task = asyncio.create_task(_index_entity_bg(entity_type, entity_id, text_to_embed))
        task.add_done_callback(lambda t: _log_task_exception(t, entity_type, entity_id))


async def delete_entity_embedding(db: AsyncSession, entity_type: str, entity_id: uuid.UUID) -> None:
    """Delete all embedding chunks for a deleted entity. Call within active DB session."""
    try:
        await db.execute(
            text("DELETE FROM entity_embeddings WHERE entity_type = :et AND entity_id = :eid"),
            {"et": entity_type, "eid": str(entity_id)},
        )
        logger.debug("entity_embedding_deleted entity_type=%s entity_id=%s", entity_type, entity_id)
    except Exception:
        logger.warning(
            "delete_embedding_failed entity_type=%s entity_id=%s",
            entity_type, entity_id, exc_info=True,
        )
