import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from opspilot.models.conversations import (
    Conversation,
    ConversationMcpServer,
    ConversationMemoryFile,
    ConversationMessage,
    ConversationToolCall,
    Session,
)
from opspilot.models.tasks import Task

logger = logging.getLogger(__name__)


async def create_conversation_from_session(
    db: AsyncSession,
    project_id: uuid.UUID,
    session_id: uuid.UUID,
    *,
    title: str | None = None,
) -> Conversation:
    """Bridge a completed Session into a new Conversation for --resume continuation."""

    stmt = (
        select(Session)
        .where(Session.id == session_id, Session.project_id == project_id)
        .options(
            selectinload(Session.messages),
            selectinload(Session.tool_calls),
            selectinload(Session.task).selectinload(Task.mcp_servers),
            selectinload(Session.task).selectinload(Task.memory_files),
        )
    )
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()

    if session is None:
        raise KeyError(f"Session {session_id} not found in project {project_id}")

    if session.agent_native_session_id is None:
        raise ValueError(
            f"Session {session_id} has no agent_native_session_id — cannot resume"
        )

    # Build conversation title
    if title:
        conv_title = title
    elif session.task:
        conv_title = f"Continue: {session.task.name}"
    else:
        conv_title = "Continue Session"

    conversation = Conversation(
        project_id=session.project_id,
        agent_type=session.agent_type,
        title=conv_title,
        agent_native_session_id=session.agent_native_session_id,
        system_prompt=session.system_prompt_snapshot
        or (session.task.system_prompt if session.task else None)
        or "You are a helpful DevOps assistant.",
        agent_settings=session.task.agent_settings if session.task else {},
        pre_run_context=session.task.pre_run_context
        if session.task
        else {"inject_skills": True, "injections": []},
    )
    db.add(conversation)
    await db.flush()

    # Clone messages
    conv_messages = [
        ConversationMessage(
            conversation_id=conversation.id,
            role=msg.role,
            content=msg.content,
            sequence=msg.sequence,
            turn_sequence=0,
            status="success",
            created_at=msg.created_at,
        )
        for msg in session.messages
    ]
    if conv_messages:
        db.add_all(conv_messages)

    # Clone tool calls
    conv_tool_calls = [
        ConversationToolCall(
            conversation_id=conversation.id,
            tool_name=tc.tool_name,
            tool_server=tc.tool_server,
            input_params=tc.input_params,
            output_result=tc.output_result,
            status=tc.status,
            duration_ms=tc.duration_ms,
            sequence=tc.sequence,
            turn_sequence=0,
            created_at=tc.created_at,
        )
        for tc in session.tool_calls
    ]
    if conv_tool_calls:
        db.add_all(conv_tool_calls)

    # Copy MCP server associations
    if session.task and session.task.mcp_servers:
        mcp_assocs = [
            ConversationMcpServer(
                conversation_id=conversation.id,
                mcp_server_id=server.id,
            )
            for server in session.task.mcp_servers
        ]
        db.add_all(mcp_assocs)

    # Copy memory file associations
    if session.task and session.task.memory_files:
        mem_assocs = [
            ConversationMemoryFile(
                conversation_id=conversation.id,
                memory_file_id=mf.id,
            )
            for mf in session.task.memory_files
        ]
        db.add_all(mem_assocs)

    await db.flush()
    return conversation
