import uuid
import logging
from datetime import datetime

from sqlalchemy import delete as sql_delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models.conversations import Message, MessageRole, Session, SessionStatus

logger = logging.getLogger(__name__)


async def list_sessions(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    status: SessionStatus | None = None,
    created_after: datetime | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[Session]:
    stmt = (
        select(Session)
        .where(Session.project_id == project_id)
        .order_by(Session.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if status:
        stmt = stmt.where(Session.status == status)
    if created_after:
        stmt = stmt.where(Session.created_at > created_after)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_session_with_messages(
    db: AsyncSession,
    project_id: uuid.UUID,
    session_id: uuid.UUID,
) -> dict | None:
    """Fetch a session with its user/assistant messages.

    Returns a dict with session metadata and messages list,
    or None if the session is not found.
    """
    result = await db.execute(
        select(Session)
        .where(Session.id == session_id)
        .where(Session.project_id == project_id)
    )
    s = result.scalar_one_or_none()
    if not s:
        return None

    msgs_stmt = (
        select(Message)
        .where(Message.session_id == s.id)
        .where(Message.role.in_([MessageRole.USER, MessageRole.ASSISTANT]))
        .order_by(Message.sequence)
    )
    msgs = (await db.execute(msgs_stmt)).scalars().all()

    return {
        "id": str(s.id),
        "status": s.status.value if hasattr(s.status, "value") else str(s.status),
        "trigger_source": str(s.trigger_source),
        "task_id": str(s.task_id) if s.task_id else None,
        "summary": s.summary,
        "created_at": s.created_at.isoformat(),
        "finished_at": s.finished_at.isoformat() if s.finished_at else None,
        "messages": [
            {"role": m.role.value, "content": m.content, "sequence": m.sequence}
            for m in msgs
        ],
    }


async def get_session_stats(
    db: AsyncSession,
    project_id: uuid.UUID,
) -> dict:
    """Return aggregate session statistics: total, by_status, by_agent, by_trigger."""
    row = (await db.execute(
        select(
            func.count().label("total"),
            func.count().filter(Session.status == "pending").label("pending"),
            func.count().filter(Session.status == "running").label("running"),
            func.count().filter(Session.status == "completed").label("completed"),
            func.count().filter(Session.status == "failed").label("failed"),
            func.count().filter(Session.status == "cancelled").label("cancelled"),
            func.count().filter(Session.status == "timeout").label("timeout"),
        ).select_from(Session).where(Session.project_id == project_id)
    )).one()

    by_agent_rows = (await db.execute(
        select(Session.agent_type, func.count().label("cnt"))
        .where(Session.project_id == project_id)
        .group_by(Session.agent_type)
    )).fetchall()

    by_trigger_rows = (await db.execute(
        select(Session.trigger_source, func.count().label("cnt"))
        .where(Session.project_id == project_id)
        .group_by(Session.trigger_source)
    )).fetchall()

    return {
        "total": row.total,
        "by_status": {
            "pending": row.pending,
            "running": row.running,
            "completed": row.completed,
            "failed": row.failed,
            "cancelled": row.cancelled,
            "timeout": row.timeout,
        },
        "by_agent": {
            (r.agent_type.value if hasattr(r.agent_type, "value") else str(r.agent_type)): r.cnt
            for r in by_agent_rows
        },
        "by_trigger": {str(r.trigger_source): r.cnt for r in by_trigger_rows},
    }


async def count_sessions(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    task_id: uuid.UUID | None = None,
    status: SessionStatus | None = None,
) -> int:
    """Count sessions matching the given filters."""
    stmt = select(func.count(Session.id)).where(Session.project_id == project_id)
    if task_id:
        stmt = stmt.where(Session.task_id == task_id)
    if status:
        stmt = stmt.where(Session.status == status)
    result = await db.execute(stmt)
    return result.scalar() or 0


async def bulk_delete_sessions(
    db: AsyncSession,
    project_id: uuid.UUID,
    session_ids: list[uuid.UUID],
) -> int:
    """Delete sessions by IDs, scoped to project. Returns number deleted."""
    result = await db.execute(
        sql_delete(Session)
        .where(Session.id.in_(session_ids))
        .where(Session.project_id == project_id)
    )
    deleted = result.rowcount
    logger.info("bulk_delete_sessions deleted=%d project_id=%s", deleted, project_id)
    return deleted
