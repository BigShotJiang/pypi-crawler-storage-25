import uuid
from datetime import datetime, timezone
import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models.findings import Incident, IncidentStatus
from opspilot.models.common import Severity
from opspilot.schemas.findings import IncidentCreate, IncidentUpdate
from opspilot.services.embeddings import delete_entity_embedding, schedule_indexing
from opspilot.services.search import RERANK_MIN_CANDIDATES, bm25_search, hybrid_search

logger = logging.getLogger(__name__)


async def get_incident(db: AsyncSession, project_id: uuid.UUID, incident_id: uuid.UUID) -> Incident | None:
    result = await db.execute(
        select(Incident)
        .where(Incident.id == incident_id)
        .where(Incident.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def create_incident(db: AsyncSession, project_id: uuid.UUID, data: IncidentCreate) -> Incident:
    incident = Incident(
        title=data.title,
        summary=data.summary,
        severity=data.severity,
        status=data.status or IncidentStatus.OPEN,
        session_id=data.session_id,
        root_cause_html=data.root_cause_html,
        impact=data.impact,
        affected_components=data.affected_components,
        timeline=data.timeline,
        project_id=project_id,
    )
    db.add(incident)
    await db.flush()
    logger.info("incident_created id=%s severity=%s", incident.id, data.severity)
    schedule_indexing(
        "incident", incident.id,
        f"{incident.title}\n\n{incident.summary or ''}\n\n{incident.root_cause_html or ''}".strip(),
    )
    return incident


async def list_incidents(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    severity: Severity | None = None,
    status: IncidentStatus | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 50,
    offset: int = 0,
    rerank: bool = False,
) -> list[Incident]:
    filters = [Incident.project_id == project_id]
    if severity:
        filters.append(Incident.severity == severity)
    if status:
        filters.append(Incident.status == status)

    if query:
        matching_ids = await hybrid_search("incident", query, limit=limit)
        if not matching_ids:
            return []
        if rerank and len(matching_ids) > RERANK_MIN_CANDIDATES:
            from opspilot.services.search import rerank as rerank_fn
            matching_ids = await rerank_fn(query, matching_ids, "incident", limit=limit)
        stmt = select(Incident).where(Incident.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        inc_map = {i.id: i for i in result.scalars().all()}
        return [inc_map[mid] for mid in matching_ids if mid in inc_map]

    if keyword:
        matching_ids = await bm25_search("incident", keyword, limit=limit)
        if not matching_ids:
            return []
        stmt = select(Incident).where(Incident.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        inc_map = {i.id: i for i in result.scalars().all()}
        return [inc_map[mid] for mid in matching_ids if mid in inc_map]

    stmt = select(Incident).order_by(Incident.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_incidents(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    severity: Severity | None = None,
    status: IncidentStatus | None = None,
) -> int:
    stmt = select(func.count()).select_from(Incident)
    stmt = stmt.where(Incident.project_id == project_id)
    if severity:
        stmt = stmt.where(Incident.severity == severity)
    if status:
        stmt = stmt.where(Incident.status == status)
    return await db.scalar(stmt)


async def update_incident(
    db: AsyncSession, project_id: uuid.UUID, incident_id: uuid.UUID, data: IncidentUpdate
) -> Incident | None:
    incident = await get_incident(db, project_id, incident_id)
    if not incident:
        return None
    updated = data.model_dump(exclude_unset=True)
    reindex = False
    for field, value in updated.items():
        setattr(incident, field, value)
        if field in ("title", "summary", "root_cause_html"):
            reindex = True
    if data.status == IncidentStatus.RESOLVED and "resolved_at" not in updated:
        incident.resolved_at = datetime.now(timezone.utc)
    if reindex:
        schedule_indexing(
            "incident", incident.id,
            f"{incident.title}\n\n{incident.summary or ''}\n\n{incident.root_cause_html or ''}".strip(),
        )
    return incident


async def delete_incident(db: AsyncSession, project_id: uuid.UUID, incident_id: uuid.UUID) -> bool:
    incident = await get_incident(db, project_id, incident_id)
    if not incident:
        return False
    await delete_entity_embedding(db, "incident", incident_id)
    await db.delete(incident)
    return True
