"""Dashboard statistics service.

Computes all aggregated metrics for the dashboard endpoint.
Extracted from api/dashboard.py to follow clean-architecture layering.
"""
import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import Date, Integer, and_, cast, extract, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models import (
    Conversation, Finding, Incident, KnowledgeEntry, NotificationLog,
    Reminder, Session, Skill, StoredFile, Task, TodoItem, ToolCall, WebhookEvent,
)
from opspilot.models import IncidentStatus, SessionStatus, ToolCallStatus
from opspilot.schemas import DashboardStats
from opspilot.schemas import (
    ConversationStats, IncidentDetailStats, KnowledgeStats, NotificationDeliveryStats,
    ReminderStats, SkillStats, StorageStats, TodoStats, WebhookStats,
)

logger = logging.getLogger(__name__)


async def get_dashboard_stats(db: AsyncSession, project_id: uuid.UUID) -> DashboardStats:
    """Compute all dashboard statistics for the given project."""
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    seven_days_ago = today_start - timedelta(days=6)

    # ── Tasks ──────────────────────────────────────────────────────────────
    total_tasks = (await db.execute(select(func.count(Task.id)).where(Task.project_id == project_id))).scalar() or 0
    enabled_tasks = (await db.execute(select(func.count(Task.id)).where(and_(Task.project_id == project_id, Task.enabled.is_(True))))).scalar() or 0

    # ── Sessions (today) ───────────────────────────────────────────────────
    sessions_today = (
        await db.execute(select(func.count(Session.id)).where(and_(Session.project_id == project_id, Session.created_at >= today_start)))
    ).scalar() or 0

    # ── Findings (today + unacknowledged) ──────────────────────────────────
    findings_today = (
        await db.execute(select(func.count(Finding.id)).where(and_(Finding.project_id == project_id, Finding.created_at >= today_start)))
    ).scalar() or 0
    unack = (
        await db.execute(select(func.count(Finding.id)).where(and_(Finding.project_id == project_id, Finding.acknowledged.is_(False))))
    ).scalar() or 0

    # ── Incidents (open count) ─────────────────────────────────────────────
    open_incidents = (
        await db.execute(
            select(func.count(Incident.id)).where(
                and_(Incident.project_id == project_id, Incident.status.in_([IncidentStatus.OPEN, IncidentStatus.INVESTIGATING, IncidentStatus.MITIGATED]))
            )
        )
    ).scalar() or 0

    # ── Sessions by status (today) ─────────────────────────────────────────
    status_rows = (
        await db.execute(
            select(Session.status, func.count(Session.id))
            .where(and_(Session.project_id == project_id, Session.created_at >= today_start))
            .group_by(Session.status)
        )
    ).all()
    sessions_by_status = {str(row[0].value): row[1] for row in status_rows}

    # ── Findings by severity (unacknowledged) ──────────────────────────────
    severity_rows = (
        await db.execute(
            select(Finding.severity, func.count(Finding.id))
            .where(and_(Finding.project_id == project_id, Finding.acknowledged.is_(False)))
            .group_by(Finding.severity)
        )
    ).all()
    findings_by_severity = {str(row[0].value): row[1] for row in severity_rows}

    # ── Reliability ────────────────────────────────────────────────────────
    session_failures_today = sessions_by_status.get("failed", 0)

    tool_call_total_today = (
        await db.execute(select(func.count(ToolCall.id)).where(and_(ToolCall.session_id.isnot(None), ToolCall.created_at >= today_start)))
    ).scalar() or 0

    tool_call_failures_today = (
        await db.execute(
            select(func.count(ToolCall.id)).where(
                and_(ToolCall.session_id.isnot(None), ToolCall.created_at >= today_start, ToolCall.status == ToolCallStatus.ERROR)
            )
        )
    ).scalar() or 0

    # ── Performance ────────────────────────────────────────────────────────
    avg_dur_scalar = (
        await db.execute(
            select(func.avg(Session.duration_ms)).where(
                and_(Session.project_id == project_id, Session.created_at >= today_start, Session.status == SessionStatus.COMPLETED)
            )
        )
    ).scalar()
    avg_session_duration_ms = float(avg_dur_scalar) if avg_dur_scalar is not None else None

    cost_tokens_row = (
        await db.execute(
            select(func.sum(Session.cost_usd), func.sum(Session.total_tokens))
            .where(and_(Session.project_id == project_id, Session.created_at >= today_start))
        )
    ).one()
    total_cost_today = float(cost_tokens_row[0] or 0)
    total_tokens_today = int(cost_tokens_row[1] or 0)

    # ── Sessions last 7 days ───────────────────────────────────────────────
    daily_rows = (
        await db.execute(
            select(
                cast(Session.created_at, Date).label("day"),
                func.count(Session.id).label("total"),
                func.sum(cast(Session.status == SessionStatus.FAILED, Integer)).label("failed"),
            )
            .where(and_(Session.project_id == project_id, Session.created_at >= seven_days_ago))
            .group_by("day")
            .order_by("day")
        )
    ).all()
    daily_map = {
        str(r.day): {"date": str(r.day), "total": r.total, "failed": int(r.failed or 0)}
        for r in daily_rows
    }
    sessions_last_7_days = [
        daily_map.get(
            str((today_start - timedelta(days=i)).date()),
            {"date": str((today_start - timedelta(days=i)).date()), "total": 0, "failed": 0},
        )
        for i in range(6, -1, -1)
    ]

    # ── Top failing tools (today, top 5) ──────────────────────────────────
    tool_rows = (
        await db.execute(
            select(
                ToolCall.tool_name,
                func.count(ToolCall.id).label("total"),
                func.sum(cast(ToolCall.status == ToolCallStatus.ERROR, Integer)).label("failures"),
            )
            .where(and_(ToolCall.session_id.isnot(None), ToolCall.created_at >= today_start))
            .group_by(ToolCall.tool_name)
            .having(func.sum(cast(ToolCall.status == ToolCallStatus.ERROR, Integer)) > 0)
            .order_by(func.sum(cast(ToolCall.status == ToolCallStatus.ERROR, Integer)).desc())
            .limit(5)
        )
    ).all()
    top_failing_tools = [
        {"tool_name": r.tool_name, "failures": int(r.failures or 0), "total": r.total}
        for r in tool_rows
    ]

    # ── Findings by type (unacknowledged) ─────────────────────────────────
    type_rows = (
        await db.execute(
            select(Finding.finding_type, func.count(Finding.id))
            .where(and_(Finding.project_id == project_id, Finding.acknowledged.is_(False)))
            .group_by(Finding.finding_type)
        )
    ).all()
    findings_by_type = {str(r[0].value): r[1] for r in type_rows}

    # ── Sessions by agent (today) ──────────────────────────────────────────
    agent_rows = (
        await db.execute(
            select(Session.agent_type, func.count(Session.id))
            .where(and_(Session.project_id == project_id, Session.created_at >= today_start))
            .group_by(Session.agent_type)
        )
    ).all()
    sessions_by_agent = {str(r[0].value): r[1] for r in agent_rows}

    # ══════════════════════════════════════════════════════════════════════
    # ENTITY STATS
    # ══════════════════════════════════════════════════════════════════════

    reminder_stats = await _reminder_stats(db, project_id)
    todo_stats = await _todo_stats(db, project_id, now)
    conversation_stats = await _conversation_stats(db, project_id)
    notification_stats = await _notification_stats(db, project_id)
    incident_detail_stats = await _incident_detail_stats(db, project_id)
    webhook_stats = await _webhook_stats(db, project_id)
    knowledge_stats = await _knowledge_stats(db, project_id)
    skill_stats = await _skill_stats(db, project_id)
    storage_stats = await _storage_stats(db, project_id)

    stats = DashboardStats(
        total_tasks=total_tasks,
        enabled_tasks=enabled_tasks,
        total_sessions_today=sessions_today,
        total_findings_today=findings_today,
        unacknowledged_findings=unack,
        open_incidents=open_incidents,
        sessions_by_status=sessions_by_status,
        findings_by_severity=findings_by_severity,
        session_failures_today=session_failures_today,
        tool_call_total_today=tool_call_total_today,
        tool_call_failures_today=tool_call_failures_today,
        avg_session_duration_ms=avg_session_duration_ms,
        total_cost_today=total_cost_today,
        total_tokens_today=total_tokens_today,
        sessions_last_7_days=sessions_last_7_days,
        top_failing_tools=top_failing_tools,
        findings_by_type=findings_by_type,
        sessions_by_agent=sessions_by_agent,
        reminders=reminder_stats,
        todos=todo_stats,
        conversations=conversation_stats,
        notifications=notification_stats,
        incident_stats=incident_detail_stats,
        webhooks=webhook_stats,
        knowledge=knowledge_stats,
        skills=skill_stats,
        storage=storage_stats,
    )
    logger.debug("dashboard_stats_computed sessions_today=%s findings_today=%s", sessions_today, findings_today)
    return stats


# ══════════════════════════════════════════════════════════════════════════
# Private helpers — one per entity-stat block
# ══════════════════════════════════════════════════════════════════════════


async def _reminder_stats(db: AsyncSession, project_id: uuid.UUID) -> ReminderStats:
    rem_status_rows = (
        await db.execute(select(Reminder.status, func.count(Reminder.id)).where(Reminder.project_id == project_id).group_by(Reminder.status))
    ).all()
    rem_by_status = {r[0]: r[1] for r in rem_status_rows}
    rem_sent = rem_by_status.get("sent", 0)
    rem_failed = rem_by_status.get("failed", 0)
    rem_failure_rate = (rem_failed / (rem_sent + rem_failed) * 100) if (rem_sent + rem_failed) > 0 else 0.0
    chan_rows = (await db.execute(text(f"SELECT unnest(channels) AS ch, count(*) FROM reminders WHERE project_id = '{project_id}' GROUP BY ch"))).all()
    rem_by_channel = {r[0]: int(r[1]) for r in chan_rows}
    return ReminderStats(
        total=sum(rem_by_status.values()),
        by_status=rem_by_status,
        by_channel=rem_by_channel,
        failure_rate=round(rem_failure_rate, 1),
    )


async def _todo_stats(db: AsyncSession, project_id: uuid.UUID, now: datetime) -> TodoStats:
    todo_status_rows = (
        await db.execute(select(TodoItem.status, func.count(TodoItem.id)).where(TodoItem.project_id == project_id).group_by(TodoItem.status))
    ).all()
    todo_by_status = {r[0]: r[1] for r in todo_status_rows}

    todo_priority_rows = (
        await db.execute(select(TodoItem.priority, func.count(TodoItem.id)).where(TodoItem.project_id == project_id).group_by(TodoItem.priority))
    ).all()
    todo_by_priority = {r[0]: r[1] for r in todo_priority_rows}

    todo_overdue = (
        await db.execute(
            select(func.count(TodoItem.id)).where(
                and_(
                    TodoItem.project_id == project_id,
                    TodoItem.status.in_(["todo", "in_progress"]),
                    TodoItem.due_date.isnot(None),
                    TodoItem.due_date < now,
                )
            )
        )
    ).scalar() or 0

    todo_done = todo_by_status.get("done", 0)
    todo_active = sum(todo_by_status.get(s, 0) for s in ["todo", "in_progress", "done"])
    todo_completion_rate = round(todo_done / todo_active * 100, 1) if todo_active > 0 else 0.0
    return TodoStats(
        total=sum(todo_by_status.values()),
        by_status=todo_by_status,
        by_priority=todo_by_priority,
        overdue=todo_overdue,
        completion_rate=todo_completion_rate,
    )


async def _conversation_stats(db: AsyncSession, project_id: uuid.UUID) -> ConversationStats:
    conv_rows = (
        await db.execute(
            select(
                Conversation.agent_type,
                func.count(Conversation.id),
                func.sum(Conversation.total_cost_usd),
                func.sum(Conversation.total_input_tokens + Conversation.total_output_tokens),
            ).where(Conversation.project_id == project_id).group_by(Conversation.agent_type)
        )
    ).all()
    conv_by_agent: dict[str, int] = {}
    conv_total = 0
    conv_cost = 0.0
    conv_tokens = 0
    for r in conv_rows:
        agent_val = r[0].value if hasattr(r[0], "value") else str(r[0])
        conv_by_agent[agent_val] = r[1]
        conv_total += r[1]
        conv_cost += float(r[2] or 0)
        conv_tokens += int(r[3] or 0)
    return ConversationStats(
        total=conv_total,
        by_agent=conv_by_agent,
        total_cost_usd=round(conv_cost, 6),
        total_tokens=conv_tokens,
    )


async def _notification_stats(db: AsyncSession, project_id: uuid.UUID) -> NotificationDeliveryStats:
    notif_rows = (
        await db.execute(
            select(NotificationLog.channel_type, NotificationLog.status, func.count(NotificationLog.id))
            .where(NotificationLog.project_id == project_id)
            .group_by(NotificationLog.channel_type, NotificationLog.status)
        )
    ).all()
    notif_by_channel: dict[str, int] = {}
    notif_sent = 0
    notif_failed = 0
    for r in notif_rows:
        ch = r[0].value if hasattr(r[0], "value") else str(r[0])
        notif_by_channel[ch] = notif_by_channel.get(ch, 0) + r[2]
        if r[1] == "sent":
            notif_sent += r[2]
        else:
            notif_failed += r[2]
    notif_total = notif_sent + notif_failed
    notif_failure_rate = round(notif_failed / notif_total * 100, 1) if notif_total > 0 else 0.0
    return NotificationDeliveryStats(
        total=notif_total,
        sent=notif_sent,
        failed=notif_failed,
        failure_rate=notif_failure_rate,
        by_channel=notif_by_channel,
    )


async def _incident_detail_stats(db: AsyncSession, project_id: uuid.UUID) -> IncidentDetailStats:
    inc_status_rows = (
        await db.execute(select(Incident.status, func.count(Incident.id)).where(Incident.project_id == project_id).group_by(Incident.status))
    ).all()
    inc_by_status = {r[0].value: r[1] for r in inc_status_rows}

    inc_sev_rows = (
        await db.execute(select(Incident.severity, func.count(Incident.id)).where(Incident.project_id == project_id).group_by(Incident.severity))
    ).all()
    inc_by_severity = {r[0].value: r[1] for r in inc_sev_rows}

    mttr_scalar = (
        await db.execute(
            select(
                func.avg(
                    extract("epoch", Incident.resolved_at) - extract("epoch", Incident.created_at)
                ) / 3600
            ).where(
                and_(
                    Incident.project_id == project_id,
                    Incident.resolved_at.isnot(None),
                    Incident.status.in_([IncidentStatus.RESOLVED, IncidentStatus.CLOSED]),
                )
            )
        )
    ).scalar()
    return IncidentDetailStats(
        total=sum(inc_by_status.values()),
        by_status=inc_by_status,
        by_severity=inc_by_severity,
        mttr_hours=round(float(mttr_scalar), 1) if mttr_scalar is not None else None,
    )


async def _webhook_stats(db: AsyncSession, project_id: uuid.UUID) -> WebhookStats:
    wh_rows = (
        await db.execute(
            select(WebhookEvent.processing_status, func.count(WebhookEvent.id))
            .where(WebhookEvent.project_id == project_id)
            .group_by(WebhookEvent.processing_status)
        )
    ).all()
    wh_by_status = {r[0]: r[1] for r in wh_rows}
    return WebhookStats(
        total_events=sum(wh_by_status.values()),
        by_status=wh_by_status,
    )


async def _knowledge_stats(db: AsyncSession, project_id: uuid.UUID) -> KnowledgeStats:
    kb_rows = (
        await db.execute(
            select(KnowledgeEntry.category, func.count(KnowledgeEntry.id))
            .where(KnowledgeEntry.project_id == project_id)
            .group_by(KnowledgeEntry.category)
        )
    ).all()
    kb_by_category = {(r[0] or "uncategorized"): r[1] for r in kb_rows}
    return KnowledgeStats(
        total=sum(kb_by_category.values()),
        by_category=kb_by_category,
    )


async def _skill_stats(db: AsyncSession, project_id: uuid.UUID) -> SkillStats:
    skill_rows = (
        await db.execute(select(Skill.domain, func.count(Skill.id)).where(Skill.project_id == project_id).group_by(Skill.domain))
    ).all()
    skills_by_domain = {r[0]: r[1] for r in skill_rows}
    return SkillStats(
        total=sum(skills_by_domain.values()),
        by_domain=skills_by_domain,
    )


async def _storage_stats(db: AsyncSession, project_id: uuid.UUID) -> StorageStats:
    storage_rows = (
        await db.execute(
            select(
                StoredFile.folder,
                func.count(StoredFile.id),
                func.sum(StoredFile.file_size_bytes),
            ).where(StoredFile.project_id == project_id).group_by(StoredFile.folder)
        )
    ).all()
    storage_by_folder = {(r[0] or "root"): r[1] for r in storage_rows}
    return StorageStats(
        total_files=sum(r[1] for r in storage_rows),
        total_size_bytes=sum(int(r[2] or 0) for r in storage_rows),
        by_folder=storage_by_folder,
    )
