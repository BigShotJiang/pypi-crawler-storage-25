"""
S3 storage service for OpsPilot.

Mirrors the implementation from eduwise (app/core/s3.py + file_utils.py).
All objects are namespaced under the s3_key_prefix (default: "opspilot/")
within the shared S3 bucket.

Key patterns:
  {prefix}/files/{uuid}.{ext}
  {prefix}/thumbnails/{uuid}.jpg
"""
import io
import logging
import mimetypes
import socket
import uuid
from typing import BinaryIO

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import (
    BotoCoreError,
    ClientError,
    ConnectionError,
    EndpointConnectionError,
    ReadTimeoutError,
)
from PIL import Image

from opspilot.config import settings

logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
IMAGE_MAX_DIMENSION = 2048
IMAGE_QUALITY = 85
THUMBNAIL_SIZE = (300, 300)

ALLOWED_EXTENSIONS = {
    "jpg", "jpeg", "png", "gif", "webp",
    "mp4", "webm", "mov", "avi",
    "mp3", "wav", "ogg", "m4a",
    "pdf", "doc", "docx", "ppt", "pptx",
    "txt", "html", "css", "js",
    "json", "yaml", "yml", "md", "csv",
    "zip", "tar", "gz",
}

MIME_TYPE_MAPPING = {
    "jpg": ["image/jpeg"], "jpeg": ["image/jpeg"], "png": ["image/png"],
    "gif": ["image/gif"], "webp": ["image/webp"],
    "mp4": ["video/mp4"], "webm": ["video/webm"], "mov": ["video/quicktime"],
    "avi": ["video/x-msvideo", "video/avi"],
    "mp3": ["audio/mpeg", "audio/mp3"], "wav": ["audio/wav", "audio/x-wav"],
    "ogg": ["audio/ogg"], "m4a": ["audio/mp4", "audio/x-m4a"],
    "pdf": ["application/pdf"], "doc": ["application/msword"],
    "docx": ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
    "ppt": ["application/vnd.ms-powerpoint"],
    "pptx": ["application/vnd.openxmlformats-officedocument.presentationml.presentation"],
    "txt": ["text/plain"], "html": ["text/html"], "css": ["text/css"],
    "js": ["text/javascript", "application/javascript"],
    "json": ["application/json"], "csv": ["text/csv"],
}


# =============================================================================
# S3 Client
# =============================================================================


def get_s3_client():
    """Create and return an S3 client with timeout and retry configuration."""
    config = BotoConfig(
        region_name=settings.aws_region,
        signature_version="s3v4",
        connect_timeout=5,
        read_timeout=30,
        retries={"max_attempts": 3, "mode": "adaptive"},
    )
    kwargs: dict = {"service_name": "s3", "config": config}
    if settings.aws_access_key_id and settings.aws_secret_access_key:
        kwargs["aws_access_key_id"] = settings.aws_access_key_id
        kwargs["aws_secret_access_key"] = settings.aws_secret_access_key
    if settings.s3_endpoint_url:
        kwargs["endpoint_url"] = settings.s3_endpoint_url
    return boto3.client(**kwargs)


# =============================================================================
# Key / URL Helpers
# =============================================================================


def get_file_extension(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def generate_s3_key(filename: str, is_thumbnail: bool = False) -> str:
    """Generate a UUID-based S3 key namespaced under settings.s3_key_prefix."""
    file_uuid = str(uuid.uuid4())
    prefix = settings.s3_key_prefix.rstrip("/")
    ext = get_file_extension(filename)
    if is_thumbnail:
        return f"{prefix}/thumbnails/{file_uuid}.jpg"
    return f"{prefix}/files/{file_uuid}.{ext}" if ext else f"{prefix}/files/{file_uuid}"


def get_public_url(s3_key: str) -> str:
    """Return the CloudFront (or fallback S3) public URL for a key."""
    if settings.s3_public_url_base:
        return f"{settings.s3_public_url_base.rstrip('/')}/{s3_key}"
    if settings.s3_endpoint_url:
        return f"{settings.s3_endpoint_url.rstrip('/')}/{settings.s3_bucket_name}/{s3_key}"
    return f"https://{settings.s3_bucket_name}.s3.{settings.aws_region}.amazonaws.com/{s3_key}"


# =============================================================================
# File Validation
# =============================================================================


def validate_file_extension(filename: str) -> bool:
    return get_file_extension(filename) in ALLOWED_EXTENSIONS


def validate_file_size(content_length: int) -> bool:
    return content_length <= settings.max_upload_size_mb * 1024 * 1024


def validate_file_content(content: bytes, filename: str) -> tuple[bool, str]:
    try:
        import magic
        detected_mime = magic.from_buffer(content[:8192], mime=True)
    except Exception:
        return True, mimetypes.guess_type(filename)[0] or "application/octet-stream"
    ext = get_file_extension(filename)
    if ext not in MIME_TYPE_MAPPING:
        return bool(detected_mime), detected_mime
    allowed_mimes = MIME_TYPE_MAPPING.get(ext, [])
    is_valid = any(detected_mime.startswith(m.split("/")[0]) for m in allowed_mimes)
    return is_valid, detected_mime


def is_image(content_type: str | None) -> bool:
    return content_type is not None and content_type.startswith("image/")


# =============================================================================
# Image Processing
# =============================================================================


def optimize_image(content: bytes, max_dimension: int = IMAGE_MAX_DIMENSION) -> bytes:
    try:
        img = Image.open(io.BytesIO(content))
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")
        if img.width > max_dimension or img.height > max_dimension:
            img.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        img.save(output, format="JPEG", optimize=True, quality=IMAGE_QUALITY)
        return output.getvalue()
    except Exception:
        return content


def generate_thumbnail(content: bytes, size: tuple[int, int] = THUMBNAIL_SIZE) -> bytes | None:
    try:
        img = Image.open(io.BytesIO(content))
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")
        img.thumbnail(size, Image.Resampling.LANCZOS)
        output = io.BytesIO()
        img.save(output, format="JPEG", optimize=True, quality=80)
        return output.getvalue()
    except Exception:
        return None


# =============================================================================
# Streaming Read
# =============================================================================


def read_file_with_limit(file: BinaryIO, max_size: int | None = None) -> bytes:
    if max_size is None:
        max_size = settings.max_upload_size_mb * 1024 * 1024
    chunks = []
    total_size = 0
    chunk_size = 64 * 1024
    while True:
        chunk = file.read(chunk_size)
        if not chunk:
            break
        total_size += len(chunk)
        if total_size > max_size:
            raise ValueError(f"File exceeds maximum size of {max_size // (1024 * 1024)} MB")
        chunks.append(chunk)
    return b"".join(chunks)


def format_file_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    if size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


# =============================================================================
# S3 Operations
# =============================================================================


def upload_file(
    file_content: bytes,
    filename: str,
    content_type: str | None = None,
    is_thumbnail: bool = False,
    *,
    s3_key: str | None = None,
) -> dict:
    """Upload bytes to S3. Returns {s3_key, s3_url, file_size_bytes, content_type}.

    Pass ``s3_key`` to use a custom key instead of the auto-generated one.
    """
    s3 = get_s3_client()
    s3_key = s3_key or generate_s3_key(filename, is_thumbnail=is_thumbnail)
    if not content_type:
        content_type, _ = mimetypes.guess_type(filename)
        content_type = content_type or "application/octet-stream"
    s3.put_object(
        Bucket=settings.s3_bucket_name,
        Key=s3_key,
        Body=file_content,
        ContentType=content_type,
    )
    return {
        "s3_key": s3_key,
        "s3_url": get_public_url(s3_key),
        "file_size_bytes": len(file_content),
        "content_type": content_type,
    }


def delete_file(s3_key: str) -> bool:
    """Delete a file from S3. Returns True if successful."""
    try:
        s3 = get_s3_client()
        s3.delete_object(Bucket=settings.s3_bucket_name, Key=s3_key)
        return True
    except ClientError:
        return False


def generate_presigned_upload_url(
    filename: str,
    content_type: str | None = None,
    expires_in: int = 3600,
) -> dict:
    """Generate a presigned PUT URL for direct browser upload."""
    s3 = get_s3_client()
    s3_key = generate_s3_key(filename)
    if not content_type:
        content_type, _ = mimetypes.guess_type(filename)
        content_type = content_type or "application/octet-stream"
    presigned_url = s3.generate_presigned_url(
        "put_object",
        Params={"Bucket": settings.s3_bucket_name, "Key": s3_key, "ContentType": content_type},
        ExpiresIn=expires_in,
    )
    return {
        "s3_key": s3_key,
        "upload_url": presigned_url,
        "public_url": get_public_url(s3_key),
        "expires_in": expires_in,
        "content_type": content_type,
    }


def download_file_bytes(s3_key: str) -> bytes | None:
    """Download a file from S3 as raw bytes."""
    s3 = get_s3_client()
    try:
        response = s3.get_object(Bucket=settings.s3_bucket_name, Key=s3_key)
        return response["Body"].read()
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        if code == "NoSuchKey":
            logger.info("File not found in S3: %s", s3_key)
        else:
            logger.error("S3 ClientError downloading %s: %s", s3_key, code)
        return None
    except (ReadTimeoutError, ConnectionError, EndpointConnectionError, socket.timeout) as e:
        logger.error("Network error downloading from S3 %s: %s", s3_key, e)
        return None
    except BotoCoreError as e:
        logger.error("BotoCore error downloading %s: %s", s3_key, e)
        return None


def check_s3_connection() -> bool:
    """Return True if S3 bucket is reachable."""
    if not settings.aws_access_key_id:
        return False
    try:
        get_s3_client().head_bucket(Bucket=settings.s3_bucket_name)
        return True
    except ClientError:
        return False


# =============================================================================
# File Ingestion Pipeline
# =============================================================================


async def ingest_file(
    content: bytes,
    original_filename: str,
    content_type: str | None,
    *,
    folder: str | None = None,
    session_id: "uuid.UUID | None" = None,
    conversation_id: "uuid.UUID | None" = None,
    expires_at=None,
    db,
) -> "StoredFile":  # type: ignore[name-defined]
    """
    Full ingestion pipeline:
      1. Validate extension + size
      2. Optimize if image
      3. Upload to S3
      4. Generate + upload thumbnail if image
      5. Create StoredFile DB record → flush → return
    """
    from opspilot.models import StoredFile  # avoid circular import at module load

    if not validate_file_extension(original_filename):
        raise ValueError(f"File type not allowed: {get_file_extension(original_filename)!r}")
    if not validate_file_size(len(content)):
        raise ValueError(f"File exceeds maximum size of {settings.max_upload_size_mb} MB")

    if not content_type:
        content_type, _ = mimetypes.guess_type(original_filename)
        content_type = content_type or "application/octet-stream"

    is_optimized = False
    if is_image(content_type):
        content = optimize_image(content)
        is_optimized = True

    upload_result = upload_file(content, original_filename, content_type=content_type)

    thumbnail_s3_key = None
    thumbnail_url = None
    if is_image(content_type):
        thumb_bytes = generate_thumbnail(content)
        if thumb_bytes:
            thumb_result = upload_file(
                thumb_bytes,
                f"thumbnail_{original_filename}",
                content_type="image/jpeg",
                is_thumbnail=True,
            )
            thumbnail_s3_key = thumb_result["s3_key"]
            thumbnail_url = thumb_result["s3_url"]

    item = StoredFile(
        filename=upload_result["s3_key"].rsplit("/", 1)[-1],
        original_filename=original_filename,
        content_type=upload_result["content_type"],
        file_size_bytes=upload_result["file_size_bytes"],
        s3_key=upload_result["s3_key"],
        s3_url=upload_result["s3_url"],
        folder=folder,
        thumbnail_s3_key=thumbnail_s3_key,
        thumbnail_url=thumbnail_url,
        is_optimized=is_optimized,
        session_id=session_id,
        conversation_id=conversation_id,
        expires_at=expires_at,
    )
    db.add(item)
    await db.flush()
    return item
