import uuid
import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.models.findings import Runbook, RunbookStatus
from opspilot.schemas.findings import RunbookCreate, RunbookUpdate
from opspilot.services.embeddings import delete_entity_embedding, schedule_indexing
from opspilot.services.search import RERANK_MIN_CANDIDATES, bm25_search, hybrid_search

logger = logging.getLogger(__name__)

_EMBED_TEXT = lambda rb: f"{rb.title}\n\n{rb.description}\n\n{rb.content}".strip()  # noqa: E731


async def get_runbook(db: AsyncSession, project_id: uuid.UUID, runbook_id: uuid.UUID) -> Runbook | None:
    result = await db.execute(
        select(Runbook)
        .where(Runbook.id == runbook_id)
        .where(Runbook.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def get_runbook_by_slug(db: AsyncSession, project_id: uuid.UUID, slug: str) -> Runbook | None:
    result = await db.execute(
        select(Runbook)
        .where(Runbook.slug == slug)
        .where(Runbook.project_id == project_id)
    )
    return result.scalar_one_or_none()


async def create_runbook(db: AsyncSession, project_id: uuid.UUID, data: RunbookCreate) -> Runbook:
    rb = Runbook(
        project_id=project_id,
        session_id=data.session_id,
        title=data.title,
        slug=data.slug,
        description=data.description,
        content=data.content,
        category=data.category,
        tags=data.tags or [],
        status=data.status,
        version=data.version,
    )
    db.add(rb)
    await db.flush()
    logger.info("runbook_created id=%s slug=%s", rb.id, rb.slug)
    schedule_indexing("runbook", rb.id, _EMBED_TEXT(rb))
    return rb


async def list_runbooks(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    status: RunbookStatus | None = None,
    category: str | None = None,
    query: str | None = None,
    keyword: str | None = None,
    limit: int = 50,
    offset: int = 0,
    rerank: bool = False,
) -> list[Runbook]:
    filters = [Runbook.project_id == project_id]
    if status:
        filters.append(Runbook.status == status)
    if category:
        filters.append(Runbook.category == category)

    if query:
        matching_ids = await hybrid_search("runbook", query, limit=limit)
        if not matching_ids:
            return []
        if rerank and len(matching_ids) > RERANK_MIN_CANDIDATES:
            from opspilot.services.search import rerank as rerank_fn
            matching_ids = await rerank_fn(query, matching_ids, "runbook", limit=limit)
        stmt = select(Runbook).where(Runbook.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        rb_map = {r.id: r for r in result.scalars().all()}
        return [rb_map[mid] for mid in matching_ids if mid in rb_map]

    if keyword:
        matching_ids = await bm25_search("runbook", keyword, limit=limit)
        if not matching_ids:
            return []
        stmt = select(Runbook).where(Runbook.id.in_(matching_ids))
        for f in filters:
            stmt = stmt.where(f)
        result = await db.execute(stmt)
        rb_map = {r.id: r for r in result.scalars().all()}
        return [rb_map[mid] for mid in matching_ids if mid in rb_map]

    stmt = select(Runbook).order_by(Runbook.created_at.desc()).limit(limit).offset(offset)
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_runbooks(
    db: AsyncSession,
    project_id: uuid.UUID,
    *,
    status: RunbookStatus | None = None,
    category: str | None = None,
) -> int:
    stmt = select(func.count()).select_from(Runbook).where(Runbook.project_id == project_id)
    if status:
        stmt = stmt.where(Runbook.status == status)
    if category:
        stmt = stmt.where(Runbook.category == category)
    return await db.scalar(stmt)


async def update_runbook(
    db: AsyncSession, project_id: uuid.UUID, runbook_id: uuid.UUID, data: RunbookUpdate
) -> Runbook | None:
    rb = await get_runbook(db, project_id, runbook_id)
    if not rb:
        return None
    updated = data.model_dump(exclude_unset=True)
    reindex = False
    for field, value in updated.items():
        setattr(rb, field, value)
        if field in ("title", "description", "content"):
            reindex = True
    if reindex:
        schedule_indexing("runbook", rb.id, _EMBED_TEXT(rb))
    return rb


async def delete_runbook(db: AsyncSession, project_id: uuid.UUID, runbook_id: uuid.UUID) -> bool:
    rb = await get_runbook(db, project_id, runbook_id)
    if not rb:
        return False
    await delete_entity_embedding(db, "runbook", runbook_id)
    await db.delete(rb)
    return True
