import asyncio
import logging
import uuid
from datetime import datetime, timezone

import redis
from sqlalchemy import select

from opspilot.config import settings
from opspilot.database import async_session_factory
from opspilot.services.worker.orchestrator import SessionOrchestrator
from opspilot.services.worker.chat_orchestrator import ChatOrchestrator
from opspilot.worker.celery_app import celery_app

logger = logging.getLogger(__name__)


def _get_redis():
    logger.debug("redis_client_create url=%s", settings.redis_url)
    return redis.from_url(settings.redis_url)


@celery_app.task(
    bind=True, 
    max_retries=3, 
    time_limit=900, 
    soft_time_limit=800,
    acks_late=True,
    autoretry_for=(Exception,), # We'll filter in the body
    retry_backoff=True,
    retry_backoff_max=600,
    retry_jitter=True,
)
def run_agent_session(
    self,
    task_id: str,
    session_id: str,
    trigger_source: str = "manual",
    webhook_event_id: str | None = None,
    webhook_payload: dict | None = None,
    idempotency_key: str | None = None,
):
    """Main Celery task: prepare workspace, run agent, parse output, store results."""
    logger.info("run_agent_session_start task_id=%s session_id=%s trigger_source=%s idempotency_key=%s", 
                task_id, session_id, trigger_source, idempotency_key)

    async def _main():
        redis_client = _get_redis()
        async with async_session_factory() as db:
            orchestrator = SessionOrchestrator(db, redis_client)
            
            # Fetch task to get max_retries
            from opspilot.models import Task
            task_result = await db.execute(select(Task).where(Task.id == uuid.UUID(task_id)))
            task = task_result.scalar_one_or_none()
            max_retries = task.max_retries if task else 3

            try:
                await orchestrator.run_session(
                    task_id, session_id, trigger_source, webhook_event_id, webhook_payload, idempotency_key
                )
                # Update webhook event status to reflect session completion
                if webhook_event_id:
                    from opspilot.models import WebhookEvent
                    evt_result = await db.execute(
                        select(WebhookEvent).where(WebhookEvent.id == uuid.UUID(webhook_event_id))
                    )
                    evt = evt_result.scalar_one_or_none()
                    if evt:
                        evt.processing_status = "dispatched"
                        evt.session_id = uuid.UUID(session_id)
                        await db.commit()
            except Exception as exc:
                logger.warning("run_agent_session_failed task_id=%s session_id=%s attempt=%d error=%s", 
                               task_id, session_id, self.request.retries, exc)
                # Retry only if we haven't reached the task-specific limit
                raise self.retry(exc=exc, max_retries=max_retries)
        redis_client.close()

    try:
        asyncio.run(_main())
    except Exception as exc:
        # This re-raises the retry exception for Celery to catch
        raise
    finally:
        logger.info("run_agent_session_end task_id=%s session_id=%s", task_id, session_id)


@celery_app.task(bind=True, max_retries=0, time_limit=900, soft_time_limit=800)
def run_chat_turn(self, conversation_id: str, user_message: str):
    """Celery task stub — kept for backwards compatibility. Chat turns now run via FastAPI BackgroundTasks."""
    logger.info("run_chat_turn_start conversation_id=%s", conversation_id)

    async def _main():
        await _run_chat_turn_async(conversation_id, user_message)

    try:
        asyncio.run(_main())
    finally:
        logger.info("run_chat_turn_end conversation_id=%s", conversation_id)


async def _run_chat_turn_async(conversation_id: str, user_message: str, on_process_started=None, attachments: list[dict] | None = None):
    from opspilot.agents import get_adapter
    from opspilot.agents.domain_events import (
        AgentStarted, TextDelta, ToolInvocationStarted, ToolInvocationCompleted,
        AgentCompleted, AgentError,
    )
    from sqlalchemy import select
    from opspilot.models import Conversation

    redis_client = _get_redis()
    async with async_session_factory() as db:
        orchestrator = ChatOrchestrator(db, redis_client)

        assistant_message = ""
        tool_calls: list[dict] = []
        logger.info(
            "chat_turn_start conversation_id=%s user_len=%s",
            conversation_id,
            len(user_message),
        )

        # We need agent_type to get adapter for result extraction
        stmt = select(Conversation.agent_type).where(Conversation.id == uuid.UUID(conversation_id))
        res = await db.execute(stmt)
        agent_type = res.scalar_one()
        adapter = get_adapter(agent_type.value)

        events = []
        try:
            async for event in orchestrator.run_chat_turn(conversation_id, user_message, on_process_started, attachments=attachments):
                events.append(event)

                if isinstance(event, TextDelta):
                    assistant_message += event.text
                elif isinstance(event, ToolInvocationStarted):
                    tool_calls.append({
                        "tool_id": event.tool_use_id,
                        "tool_name": event.tool_name,
                        "tool_server": event.tool_server,
                        "input_params": event.input,
                        "status": "running",
                    })
                elif isinstance(event, ToolInvocationCompleted):
                    for tc in tool_calls:
                        if tc["tool_id"] == event.tool_use_id:
                            tc["status"] = event.status
                            tc["is_error"] = event.is_error
                            tc["output_result"] = str(event.result)
                            tc["duration_ms"] = event.duration_ms
                            break

            # run_chat_turn publishes turn_end via the notifier on AgentCompleted;
            # just persist the result to DB.
            agent_result = adapter.extract_result(events, 0)

            await orchestrator.finalize_turn(
                conversation_id=conversation_id,
                assistant_message=assistant_message,
                tool_calls_data=tool_calls,
                agent_native_session_id=agent_result.agent_native_session_id,
                input_tokens=agent_result.input_tokens,
                output_tokens=agent_result.output_tokens,
                cost_usd=agent_result.cost_usd,
            )

            logger.info(
                "chat_turn_complete conversation_id=%s text_len=%s tool_calls=%s input_tokens=%s output_tokens=%s cost_usd=%s",
                conversation_id,
                len(assistant_message),
                len(tool_calls),
                getattr(agent_result, "input_tokens", None),
                getattr(agent_result, "output_tokens", None),
                getattr(agent_result, "cost_usd", None),
            )

        except Exception as e:
            logger.exception("chat_turn_failed_in_worker conversation_id=%s", conversation_id)
            if orchestrator.notifier:
                orchestrator.notifier.publish_chat_event(conversation_id, "error", {"message": str(e)})
        finally:
            logger.debug(
                "chat_turn_events_summary conversation_id=%s events=%s",
                conversation_id,
                [type(ev).__name__ for ev in events],
            )

    redis_client.close()


@celery_app.task(bind=True, max_retries=0, name="opspilot.worker.tasks.send_reminder")
def send_reminder(self, reminder_id: str):
    """Deliver a reminder via all configured channels."""
    from opspilot.models import Reminder
    from opspilot.services.reminder_service import deliver_reminder

    async def _main():
        async with async_session_factory() as db:
            reminder = await db.get(Reminder, uuid.UUID(reminder_id))
            if not reminder or reminder.status != "pending":
                return

            success, error_msg = await deliver_reminder(db, reminder)

            # If there are remaining scheduled times, reschedule instead of marking sent.
            extra = list(reminder.extra_schedules or [])
            if extra:
                next_time_str = extra.pop(0)
                try:
                    next_dt = datetime.fromisoformat(next_time_str.replace("Z", "+00:00"))
                    if next_dt.tzinfo is None:
                        next_dt = next_dt.replace(tzinfo=timezone.utc)
                    reminder.scheduled_at = next_dt
                    reminder.extra_schedules = extra if extra else None
                    # keep status="pending" so the scheduler picks it up again
                    logger.info(
                        "reminder_rescheduled id=%s next=%s remaining=%d",
                        reminder.id, next_time_str, len(extra),
                    )
                except ValueError:
                    logger.warning("reminder_bad_extra_schedule id=%s value=%r", reminder.id, next_time_str)
                    reminder.status = "sent" if success else "failed"
                    reminder.sent_at = datetime.now(timezone.utc)
                    reminder.error_message = error_msg
            else:
                reminder.status = "sent" if success else "failed"
                reminder.sent_at = datetime.now(timezone.utc)
                reminder.error_message = error_msg

            await db.commit()

    asyncio.run(_main())


@celery_app.task(
    bind=True,
    max_retries=2,
    default_retry_delay=10,
    name="opspilot.worker.tasks.dispatch_alert_group",
)
def dispatch_alert_group(self, group_id: str):
    """Fires after the correlation window expires. Dispatches the alert group as a single agent session."""
    logger.info("dispatch_alert_group_start group_id=%s", group_id)

    async def _main():
        from opspilot.services import alert_correlation
        from opspilot.models.alert_groups import AlertGroup

        async with async_session_factory() as db:
            group = await alert_correlation.dispatch_group(db, uuid.UUID(group_id))
            if not group:
                logger.info("dispatch_alert_group_skip_already_dispatched group_id=%s", group_id)
                return

            aggregated = alert_correlation.build_aggregated_payload(group)
            task_id = group.task_id
            group_db_id = group.id
            alert_count = group.alert_count

            # Commit DISPATCHED status first (without session_id — the session
            # row doesn't exist yet, so the FK would fail).
            await db.commit()

            session_id = uuid.uuid4()
            run_agent_session.delay(
                str(task_id),
                str(session_id),
                trigger_source="webhook",
                webhook_payload=aggregated,
                idempotency_key=f"alert_group:{group_db_id}",
            )

            # Link session_id back to the group after dispatching.
            # run_agent_session creates the session row asynchronously, so we
            # use a deferred UPDATE that tolerates the FK not yet existing by
            # making the column nullable (it already is).  We do this in a
            # separate transaction so the dispatch isn't blocked.
            try:
                async with async_session_factory() as db2:
                    from sqlalchemy import update
                    await db2.execute(
                        update(AlertGroup)
                        .where(AlertGroup.id == group_db_id)
                        .values(session_id=session_id)
                    )
                    await db2.commit()
            except Exception:
                # Non-critical — the session will still run, we just lose the
                # back-reference on the alert_group row.  The stale-group
                # checker won't re-dispatch because status is already DISPATCHED.
                logger.warning(
                    "dispatch_alert_group_session_link_failed group_id=%s session_id=%s",
                    group_db_id, session_id,
                )

            logger.info(
                "dispatch_alert_group_dispatched group_id=%s session_id=%s alert_count=%s",
                group_id, session_id, alert_count,
            )

    try:
        asyncio.run(_main())
    except Exception as exc:
        logger.warning("dispatch_alert_group_failed group_id=%s error=%s", group_id, exc)
        raise self.retry(exc=exc)


@celery_app.task(
    bind=True,
    max_retries=3,
    default_retry_delay=30,
    name="opspilot.worker.tasks.index_entity",
)
def index_entity(self, entity_type: str, entity_id_str: str, text_to_embed: str):
    """Chunk, embed, and upsert entity into entity_embeddings."""
    async def _main():
        from opspilot.services.chunking import chunk_text
        from opspilot.services.embeddings import upsert_chunks
        chunks = chunk_text(text_to_embed)
        await upsert_chunks(entity_type, uuid.UUID(entity_id_str), chunks)

    try:
        asyncio.run(_main())
    except Exception as exc:
        raise self.retry(exc=exc)
