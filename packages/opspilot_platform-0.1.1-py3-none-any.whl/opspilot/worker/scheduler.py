"""Database-driven Celery Beat scheduler.

Reads task schedules from PostgreSQL and dynamically enqueues agent sessions.
Also dispatches pending reminders whose scheduled_at has passed.
Both tasks run every 60 seconds via Celery Beat.
"""

import asyncio
import logging
import uuid
from datetime import datetime, timezone, timedelta

import redis
from croniter import croniter
from sqlalchemy import and_, select, or_

from opspilot.config import settings
from opspilot.database import async_session_factory
from opspilot.models import Task
from opspilot.worker.celery_app import celery_app

logger = logging.getLogger(__name__)


def _get_redis():
    return redis.from_url(settings.redis_url)


async def _acquire_lock(redis_client, lock_key: str, ttl_seconds: int = 90) -> bool:
    """Returns True if lock acquired. Lock expires after ttl_seconds."""
    return bool(redis_client.set(lock_key, "1", nx=True, ex=ttl_seconds))


# ---------------------------------------------------------------------------
# Task scheduler
# ---------------------------------------------------------------------------


@celery_app.task(name="opspilot.worker.scheduler.evaluate_schedules")
def evaluate_schedules():
    """Check all enabled tasks and enqueue those whose cron schedule is due."""
    logger.debug("evaluate_schedules_start")

    async def _main():
        redis_client = _get_redis()
        try:
            # Prevent multiple scheduler instances from running simultaneously
            if not await _acquire_lock(redis_client, "scheduler:lock:tasks", ttl_seconds=50):
                logger.debug("evaluate_schedules_lock_held")
                return

            await _evaluate_schedules_async()
        finally:
            redis_client.close()

    try:
        asyncio.run(_main())
    except Exception:
        logger.exception("evaluate_schedules_unexpected_error")
    finally:
        logger.debug("evaluate_schedules_end")


async def _evaluate_schedules_async():
    now = datetime.now(timezone.utc)
    logger.debug("evaluate_schedules_async now=%s", now.isoformat())

    async with async_session_factory() as db:
        # Optimized query: only load enabled tasks that are due OR missing next_run_at
        stmt = select(Task).where(
            and_(
                Task.enabled.is_(True),
                or_(
                    Task.next_run_at.is_(None),
                    Task.next_run_at <= now
                )
            )
        )
        result = await db.execute(stmt)
        tasks = result.scalars().all()
        logger.debug("evaluate_schedules_loaded tasks_count=%d", len(tasks))

        enqueued = 0
        skipped = 0
        for task in tasks:
            try:
                # If next_run_at is None, just set it and skip this run to avoid 
                # accidental double-runs on startup or new tasks.
                if not task.next_run_at:
                    _, next_run = _calculate_next_run(task, now)
                    task.next_run_at = next_run
                    logger.info("task_next_run_initialized task_id=%s next_run=%s", task.id, next_run.isoformat() if next_run else "None")
                    continue

                should, next_run = _evaluate_task(task, now)
                if should:
                    # To prevent race condition where two schedulers might pick up the same task,
                    # we use next_run_at as an idempotency guard by updating it BEFORE enqueuing.
                    # In a high-concurrency setup, we'd use a WHERE clause in the UPDATE.
                    
                    session_id = str(uuid.uuid4())
                    # Use a stable idempotency key for this schedule slot
                    idempotency_key = f"scheduled:{task.id}:{task.next_run_at.isoformat()}"
                    
                    from opspilot.worker.tasks import run_agent_session
                    run_agent_session.delay(
                        str(task.id), 
                        session_id, 
                        trigger_source="scheduled",
                        # We'll need to update run_agent_session to accept idempotency_key
                    )
                    
                    task.last_run_at = now
                    task.next_run_at = next_run
                    enqueued += 1
                    logger.info(
                        "task_enqueued task_id=%s task_name=%s session_id=%s next_run=%s",
                        task.id, task.name, session_id,
                        next_run.isoformat() if next_run else "n/a",
                    )
                else:
                    # This branch might be reached if now is slightly before task.next_run_at
                    # or if the query picked up something that was just updated.
                    skipped += 1

            except Exception:
                logger.exception(
                    "evaluate_task_error task_id=%s task_name=%s", task.id, task.name
                )

        await db.commit()
        logger.info(
            "evaluate_schedules_complete enqueued=%d skipped=%d total=%d",
            enqueued, skipped, len(tasks),
        )


def _calculate_next_run(task: Task, base_time: datetime) -> tuple[bool, datetime | None]:
    if not task.cron_schedule:
        return False, None
    
    cron = croniter(task.cron_schedule, base_time)
    next_run = cron.get_next(datetime)
    if next_run.tzinfo is None:
        next_run = next_run.replace(tzinfo=timezone.utc)
    return True, next_run


def _evaluate_task(task: Task, now: datetime) -> tuple[bool, datetime | None]:
    """Return (should_run, next_run_time)."""
    if not task.cron_schedule:
        return False, None

    # Use the existing next_run_at as the source of truth
    should_run = task.next_run_at <= now
    
    # Calculate the NEXT next run
    _, next_run = _calculate_next_run(task, now)
    
    return should_run, next_run


# ---------------------------------------------------------------------------
# Reminder scheduler
# ---------------------------------------------------------------------------


@celery_app.task(name="opspilot.worker.scheduler.check_due_reminders")
def check_due_reminders():
    """Dispatch pending reminders whose scheduled_at has passed."""
    logger.debug("check_due_reminders_start")

    async def _main():
        redis_client = _get_redis()
        try:
            if not await _acquire_lock(redis_client, "scheduler:lock:reminders", ttl_seconds=50):
                return
            await _check_due_reminders_async()
        finally:
            redis_client.close()

    try:
        asyncio.run(_main())
    except Exception:
        logger.exception("check_due_reminders_unexpected_error")
    finally:
        logger.debug("check_due_reminders_end")


async def _check_due_reminders_async():
    from opspilot.models import Reminder
    from opspilot.worker.tasks import send_reminder

    now = datetime.now(timezone.utc)
    logger.debug("check_due_reminders_async now=%s", now.isoformat())

    async with async_session_factory() as db:
        try:
            result = await db.execute(
                select(Reminder).where(
                    and_(
                        Reminder.status == "pending",
                        Reminder.scheduled_at.isnot(None),
                        Reminder.scheduled_at <= now,
                    )
                )
            )
            due = result.scalars().all()
            logger.debug("check_due_reminders_query_ok due_count=%d", len(due))
        except Exception:
            logger.exception("check_due_reminders_query_failed")
            return

        if not due:
            logger.debug("check_due_reminders_none_due")
            return

        dispatched = 0
        for reminder in due:
            try:
                # Mark as 'dispatching' or update in DB to prevent double-dispatch
                # if another instance somehow ran.
                send_reminder.delay(str(reminder.id))
                dispatched += 1
                logger.info(
                    "reminder_dispatched reminder_id=%s name=%s scheduled_at=%s",
                    reminder.id, reminder.name,
                    reminder.scheduled_at.isoformat() if reminder.scheduled_at else "n/a",
                )
            except Exception:
                logger.exception(
                    "reminder_dispatch_failed reminder_id=%s name=%s", reminder.id, reminder.name
                )

        logger.info("check_due_reminders_complete dispatched=%d total_due=%d", dispatched, len(due))


# ---------------------------------------------------------------------------
# Alert group safety net
# ---------------------------------------------------------------------------


@celery_app.task(name="opspilot.worker.scheduler.check_stale_alert_groups")
def check_stale_alert_groups():
    """Dispatch COLLECTING alert groups whose window has expired.

    Safety net for cases where the countdown task was lost (e.g. Redis restart).
    Runs every 60s via Celery Beat.
    """
    logger.debug("check_stale_alert_groups_start")

    async def _main():
        redis_client = _get_redis()
        try:
            if not await _acquire_lock(redis_client, "scheduler:lock:alert_groups", ttl_seconds=50):
                return
            await _check_stale_alert_groups_async()
        finally:
            redis_client.close()

    try:
        asyncio.run(_main())
    except Exception:
        logger.exception("check_stale_alert_groups_unexpected_error")
    finally:
        logger.debug("check_stale_alert_groups_end")


async def _check_stale_alert_groups_async():
    from opspilot.services import alert_correlation
    from opspilot.worker.tasks import dispatch_alert_group

    async with async_session_factory() as db:
        stale = await alert_correlation.find_stale_collecting_groups(db)
        if not stale:
            return

        dispatched = 0
        for group in stale:
            try:
                dispatch_alert_group.delay(str(group.id))
                dispatched += 1
                logger.info("stale_alert_group_dispatched group_id=%s alert_count=%s", group.id, group.alert_count)
            except Exception:
                logger.exception("stale_alert_group_dispatch_failed group_id=%s", group.id)

        logger.info("check_stale_alert_groups_complete dispatched=%d total=%d", dispatched, len(stale))


# ---------------------------------------------------------------------------
# Approval expiry
# ---------------------------------------------------------------------------


@celery_app.task(name="opspilot.worker.scheduler.expire_stale_approvals")
def expire_stale_approvals():
    """Expire pending approvals whose expires_at has passed."""
    logger.debug("expire_stale_approvals_start")

    async def _main():
        redis_client = _get_redis()
        try:
            if not await _acquire_lock(redis_client, "scheduler:lock:approvals", ttl_seconds=50):
                return
            await _expire_stale_approvals_async()
        finally:
            redis_client.close()

    try:
        asyncio.run(_main())
    except Exception:
        logger.exception("expire_stale_approvals_unexpected_error")
    finally:
        logger.debug("expire_stale_approvals_end")


async def _expire_stale_approvals_async():
    from opspilot.services import approval_service

    async with async_session_factory() as db:
        count = await approval_service.expire_stale_approvals(db)
        await db.commit()
        if count:
            logger.info("expire_stale_approvals_complete count=%d", count)
