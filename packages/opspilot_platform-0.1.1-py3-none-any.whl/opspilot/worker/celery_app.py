import logging

from celery import Celery
from celery.signals import before_task_publish, task_prerun, task_postrun

from opspilot.config import settings
from opspilot.logging_setup import configure_logging, trace_id_var

configure_logging()
logger = logging.getLogger(__name__)

@before_task_publish.connect
def add_trace_id_header(headers=None, **kwargs):
    if headers is not None:
        trace_id = trace_id_var.get()
        if trace_id:
            headers['trace_id'] = trace_id

_task_trace_tokens = {}

@task_prerun.connect
def set_trace_id(task_id, task, *args, **kwargs):
    headers = getattr(task.request, 'headers', None) or getattr(task.request, 'properties', {})
    trace_id = headers.get('trace_id')
    if not trace_id:
        trace_id = task_id
    
    token = trace_id_var.set(trace_id)
    _task_trace_tokens[task_id] = token

@task_postrun.connect
def clear_trace_id(task_id, **kwargs):
    token = _task_trace_tokens.pop(task_id, None)
    if token:
        trace_id_var.reset(token)

celery_app = Celery(
    "opspilot",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=50,
    beat_schedule_filename="/tmp/celerybeat-schedule",
    # Task routing & DLQ
    task_default_queue="default",
    task_queues={
        "default": {},
        "agent": {},
        "agent.dlq": {},
    },
    task_routes={
        "opspilot.worker.tasks.run_agent_session": {"queue": "agent"},
    },
)

# Explicitly include both task modules (autodiscover only finds tasks.py, not scheduler.py)
celery_app.conf.include = [
    "opspilot.worker.tasks",
    "opspilot.worker.scheduler",
]

# Beat schedule — defined here so beat loads it on startup (autodiscover is lazy)
celery_app.conf.beat_schedule = {
    "evaluate-task-schedules": {
        "task": "opspilot.worker.scheduler.evaluate_schedules",
        "schedule": 60.0,
    },
    "check-due-reminders": {
        "task": "opspilot.worker.scheduler.check_due_reminders",
        "schedule": 60.0,
    },
    "check-stale-alert-groups": {
        "task": "opspilot.worker.scheduler.check_stale_alert_groups",
        "schedule": 60.0,
    },
    "expire-stale-approvals": {
        "task": "opspilot.worker.scheduler.expire_stale_approvals",
        "schedule": 60.0,
    },
}

logger.debug(
    "celery_configured broker=%s backend=%s",
    settings.celery_broker_url,
    settings.celery_result_backend,
)
