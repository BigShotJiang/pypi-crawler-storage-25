import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import FindingType, Severity
from opspilot.schemas import FindingAcknowledge, FindingCreate, FindingOut, FindingUpdate, PaginatedResponse
from opspilot.services import finding_service

router = APIRouter(prefix="/findings", tags=["findings"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[FindingOut])
async def list_findings(
    q: str | None = None,
    keyword: str | None = None,
    session_id: uuid.UUID | None = None,
    severity: Severity | None = None,
    finding_type: FindingType | None = None,
    acknowledged: bool | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug(
        "list_findings q=%s keyword=%s session_id=%s severity=%s finding_type=%s acknowledged=%s limit=%s offset=%s",
        q, keyword, session_id, severity, finding_type, acknowledged, limit, offset,
    )
    if q or keyword:
        items = await finding_service.list_findings(
            db, project_id, session_id=session_id, severity=severity, finding_type=finding_type,
            acknowledged=acknowledged, query=q, keyword=keyword, limit=limit, offset=offset,
        )
        return {"items": items, "total": len(items)}
    total = await finding_service.count_findings(db, project_id, acknowledged=acknowledged, severity=severity)
    items = await finding_service.list_findings(
        db, project_id, session_id=session_id, severity=severity, finding_type=finding_type,
        acknowledged=acknowledged, limit=limit, offset=offset,
    )
    return {"items": items, "total": total}


@router.get("/count")
async def count_findings(
    acknowledged: bool | None = None,
    severity: Severity | None = None,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("count_findings acknowledged=%s severity=%s", acknowledged, severity)
    count = await finding_service.count_findings(db, project_id, acknowledged=acknowledged, severity=severity)
    return {"count": count}


@router.get("/{finding_id}", response_model=FindingOut)
async def get_finding(
    finding_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("get_finding finding_id=%s", finding_id)
    finding = await finding_service.get_finding(db, project_id, finding_id)
    if not finding:
        logger.info("finding_not_found finding_id=%s", finding_id)
        raise HTTPException(404, "Finding not found")
    return finding


@router.post("", response_model=FindingOut, status_code=201)
async def create_finding(
    data: FindingCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_finding title=%s severity=%s", data.title, data.severity)
    return await finding_service.create_finding(db, project_id, data)


@router.patch("/{finding_id}", response_model=FindingOut)
async def update_finding(
    finding_id: uuid.UUID,
    data: FindingUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("update_finding finding_id=%s", finding_id)
    finding = await finding_service.update_finding(db, project_id, finding_id, data)
    if not finding:
        logger.info("finding_not_found finding_id=%s", finding_id)
        raise HTTPException(404, "Finding not found")
    return finding


@router.delete("/{finding_id}", status_code=204)
async def delete_finding(
    finding_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("delete_finding finding_id=%s", finding_id)
    if not await finding_service.delete_finding(db, project_id, finding_id):
        raise HTTPException(404, "Finding not found")


@router.post("/{finding_id}/acknowledge", response_model=FindingOut)
async def acknowledge_finding(
    finding_id: uuid.UUID,
    data: FindingAcknowledge,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("acknowledge_finding finding_id=%s acknowledged_by=%s", finding_id, data.acknowledged_by)
    finding = await finding_service.acknowledge_finding(db, project_id, finding_id, data.acknowledged_by)
    if not finding:
        logger.info("finding_not_found finding_id=%s", finding_id)
        raise HTTPException(404, "Finding not found")
    logger.debug("finding_acknowledged finding_id=%s", finding_id)
    return finding
