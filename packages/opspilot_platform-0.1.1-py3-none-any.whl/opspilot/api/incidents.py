import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import IncidentStatus, Severity
from opspilot.schemas import IncidentOut, IncidentUpdate, IncidentCreate, PaginatedResponse
from opspilot.services import incident_service

router = APIRouter(prefix="/incidents", tags=["incidents"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[IncidentOut])
async def list_incidents(
    q: str | None = None,
    keyword: str | None = None,
    severity: Severity | None = None,
    status: IncidentStatus | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("list_incidents q=%s keyword=%s severity=%s status=%s limit=%s offset=%s", q, keyword, severity, status, limit, offset)
    if q or keyword:
        items = await incident_service.list_incidents(
            db, project_id, severity=severity, status=status, query=q, keyword=keyword, limit=limit, offset=offset,
        )
        return {"items": items, "total": len(items)}
    total = await incident_service.count_incidents(db, project_id, severity=severity, status=status)
    items = await incident_service.list_incidents(
        db, project_id, severity=severity, status=status, limit=limit, offset=offset,
    )
    return {"items": items, "total": total}


@router.get("/{incident_id}", response_model=IncidentOut)
async def get_incident(
    incident_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("get_incident incident_id=%s", incident_id)
    incident = await incident_service.get_incident(db, project_id, incident_id)
    if not incident:
        raise HTTPException(404, "Incident not found")
    return incident


@router.post("", response_model=IncidentOut, status_code=201)
async def create_incident(
    data: IncidentCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_incident title=%s severity=%s", data.title, data.severity)
    return await incident_service.create_incident(db, project_id, data)


@router.patch("/{incident_id}", response_model=IncidentOut)
async def update_incident(
    incident_id: uuid.UUID,
    data: IncidentUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("update_incident incident_id=%s", incident_id)
    incident = await incident_service.update_incident(db, project_id, incident_id, data)
    if not incident:
        raise HTTPException(404, "Incident not found")
    return incident


@router.delete("/{incident_id}", status_code=204)
async def delete_incident(
    incident_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("delete_incident incident_id=%s", incident_id)
    if not await incident_service.delete_incident(db, project_id, incident_id):
        raise HTTPException(404, "Incident not found")
