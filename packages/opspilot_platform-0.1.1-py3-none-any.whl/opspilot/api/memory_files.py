import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import MemoryFile
from opspilot.schemas import MemoryFileCreate, MemoryFileOut, MemoryFileUpdate, PaginatedResponse

router = APIRouter(prefix="/memory-files", tags=["memory-files"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[MemoryFileOut])
async def list_memory_files(
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    total = await db.scalar(select(func.count()).select_from(MemoryFile).where(MemoryFile.project_id == project_id))
    result = await db.execute(select(MemoryFile).where(MemoryFile.project_id == project_id).order_by(MemoryFile.name).limit(limit).offset(offset))
    return {"items": result.scalars().all(), "total": total}


@router.get("/{memory_file_id}", response_model=MemoryFileOut)
async def get_memory_file(memory_file_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    mf = await _get_or_404(memory_file_id, db)
    return mf


@router.post("", response_model=MemoryFileOut, status_code=201)
async def create_memory_file(
    data: MemoryFileCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_memory_file name=%s destination=%s", data.name, data.destination)
    mf = MemoryFile(
        name=data.name,
        description=data.description,
        content=data.content,
        destination=data.destination,
        agent_type=data.agent_type,
        project_id=project_id,
    )
    db.add(mf)
    await db.flush()
    await db.refresh(mf)
    logger.info("memory_file_created id=%s", mf.id)
    return mf


@router.patch("/{memory_file_id}", response_model=MemoryFileOut)
async def update_memory_file(memory_file_id: uuid.UUID, data: MemoryFileUpdate, db: AsyncSession = Depends(get_db)):
    logger.info("update_memory_file id=%s", memory_file_id)
    mf = await _get_or_404(memory_file_id, db)
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(mf, key, value)
    await db.flush()
    await db.refresh(mf)
    return mf


@router.delete("/{memory_file_id}", status_code=204)
async def delete_memory_file(memory_file_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    logger.info("delete_memory_file id=%s", memory_file_id)
    mf = await _get_or_404(memory_file_id, db)
    await db.delete(mf)


async def _get_or_404(memory_file_id: uuid.UUID, db: AsyncSession) -> MemoryFile:
    result = await db.execute(select(MemoryFile).where(MemoryFile.id == memory_file_id))
    mf = result.scalar_one_or_none()
    if not mf:
        raise HTTPException(404, "Memory file not found")
    return mf
