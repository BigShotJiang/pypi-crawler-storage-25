import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas.artifacts import ArtifactListResponse, ArtifactOut
from opspilot.services import artifact_service

router = APIRouter(prefix="/artifacts", tags=["artifacts"])


@router.get("", response_model=ArtifactListResponse)
async def list_artifacts(
    session_id: uuid.UUID | None = None,
    conversation_id: uuid.UUID | None = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    items, total = await artifact_service.list_artifacts(
        db, project_id, session_id=session_id, conversation_id=conversation_id, limit=limit, offset=offset
    )
    return {"items": items, "total": total}


@router.get("/{artifact_id}", response_model=ArtifactOut)
async def get_artifact(
    artifact_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    artifact = await artifact_service.get_artifact(db, project_id, artifact_id)
    if not artifact:
        raise HTTPException(404, "Artifact not found")
    return artifact


@router.delete("/{artifact_id}", status_code=204)
async def delete_artifact(
    artifact_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    deleted = await artifact_service.delete_artifact(db, project_id, artifact_id)
    if not deleted:
        raise HTTPException(404, "Artifact not found")
    await db.commit()
