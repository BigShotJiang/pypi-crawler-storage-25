"""WhatsApp pairing API — QR-based device linking from the integrations page."""
import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.services import whatsapp_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/whatsapp", tags=["whatsapp"])


class PairResponse(BaseModel):
    pair_id: str


class PairStatusResponse(BaseModel):
    status: str
    qr_data: str | None = None
    jid: str | None = None
    error: str | None = None


class CancelRequest(BaseModel):
    pair_id: str


@router.post("/pair", response_model=PairResponse)
async def start_pairing(
    request: Request,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Start a new WhatsApp QR pairing session."""
    pair_id = await whatsapp_service.start_pairing(project_id)

    # Tell the adapter to start a neonize client for this pairing
    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager:
        adapter = channel_manager.get_adapter("whatsapp")
        if adapter:
            await adapter.start_pairing(project_id, pair_id)
        else:
            raise HTTPException(status_code=503, detail="WhatsApp adapter not available")
    else:
        raise HTTPException(status_code=503, detail="Channel manager not initialized")

    return PairResponse(pair_id=pair_id)


@router.get("/pair/status", response_model=PairStatusResponse)
async def get_pair_status(
    pair_id: str,
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Poll the current state of a WhatsApp pairing session."""
    # Validate the pair_id belongs to the authenticated project
    owner_project_id = await whatsapp_service.get_pair_project_id(pair_id)
    if owner_project_id is None:
        raise HTTPException(status_code=404, detail="Pairing session not found or expired")
    if owner_project_id != project_id:
        raise HTTPException(status_code=403, detail="Pairing session does not belong to this project")

    result = await whatsapp_service.get_pair_status(pair_id)
    return PairStatusResponse(**result)


@router.post("/pair/cancel", status_code=204)
async def cancel_pairing(
    body: CancelRequest,
    request: Request,
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Cancel an in-progress WhatsApp pairing session."""
    # Tell adapter to stop the temp client
    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager:
        adapter = channel_manager.get_adapter("whatsapp")
        if adapter:
            await adapter.stop_pairing(body.pair_id)

    await whatsapp_service.cancel_pairing(body.pair_id)
