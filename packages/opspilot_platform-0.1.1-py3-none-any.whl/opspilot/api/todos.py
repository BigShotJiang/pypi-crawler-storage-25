import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import TodoCreate, TodoOut, TodoUpdate, PaginatedResponse
from opspilot.schemas import VALID_TODO_PRIORITIES, VALID_TODO_STATUSES
from opspilot.services import todo_service

router = APIRouter(prefix="/todos", tags=["todos"])
logger = logging.getLogger(__name__)

_PRIORITY_ORDER = {"urgent": 4, "high": 3, "medium": 2, "low": 1}


def _sort_key(item):
    is_done = item.status in ("done", "cancelled")
    prio = _PRIORITY_ORDER.get(item.priority, 0)
    due = item.due_date.timestamp() if item.due_date else float("inf")
    return (is_done, -prio, due)


@router.get("", response_model=PaginatedResponse[TodoOut])
async def list_todos(
    status: str | None = None,
    priority: str | None = None,
    context: str | None = None,
    search: str | None = None,
    limit: int = Query(25, le=500),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    total = await todo_service.count_todos(db, project_id, status=status)
    items = await todo_service.list_todos(
        db, project_id, status=status, priority=priority, context=context, search=search,
        limit=limit, offset=offset,
    )
    items.sort(key=_sort_key)
    return {"items": items, "total": total}


@router.get("/{todo_id}", response_model=TodoOut)
async def get_todo(
    todo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    item = await todo_service.get_todo(db, project_id, todo_id)
    if not item:
        raise HTTPException(404, "Todo item not found")
    return item


@router.post("", response_model=TodoOut, status_code=201)
async def create_todo(
    data: TodoCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if data.status and data.status not in VALID_TODO_STATUSES:
        raise HTTPException(400, f"Invalid status: {data.status!r}. Allowed: {sorted(VALID_TODO_STATUSES)}")
    if data.priority and data.priority not in VALID_TODO_PRIORITIES:
        raise HTTPException(400, f"Invalid priority: {data.priority!r}. Allowed: {sorted(VALID_TODO_PRIORITIES)}")
    return await todo_service.create_todo(db, project_id, data)


@router.patch("/{todo_id}", response_model=TodoOut)
async def update_todo(
    todo_id: uuid.UUID,
    data: TodoUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    updates = data.model_dump(exclude_unset=True)
    if "status" in updates and updates["status"] not in VALID_TODO_STATUSES:
        raise HTTPException(400, f"Invalid status: {updates['status']!r}. Allowed: {sorted(VALID_TODO_STATUSES)}")
    if "priority" in updates and updates["priority"] not in VALID_TODO_PRIORITIES:
        raise HTTPException(400, f"Invalid priority: {updates['priority']!r}. Allowed: {sorted(VALID_TODO_PRIORITIES)}")
    item = await todo_service.update_todo(db, project_id, todo_id, data)
    if not item:
        raise HTTPException(404, "Todo item not found")
    return item


@router.delete("/{todo_id}", status_code=204)
async def delete_todo(
    todo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if not await todo_service.delete_todo(db, project_id, todo_id):
        raise HTTPException(404, "Todo item not found")


@router.post("/{todo_id}/complete", response_model=TodoOut)
async def complete_todo(
    todo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    item = await todo_service.complete_todo(db, project_id, todo_id)
    if not item:
        raise HTTPException(404, "Todo item not found")
    return item
