import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import SkillCreate, SkillOut, SkillUpdate, PaginatedResponse
from opspilot.services import skill_service

router = APIRouter(prefix="/skills", tags=["skills"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[SkillOut])
async def list_skills(
    q: str | None = None,
    keyword: str | None = None,
    domain: str | None = None,
    entry_type: str | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("list_skills q=%s keyword=%s domain=%s entry_type=%s limit=%s offset=%s", q, keyword, domain, entry_type, limit, offset)
    items = await skill_service.list_skills(db, project_id, domain=domain, entry_type=entry_type, query=q, keyword=keyword, limit=limit, offset=offset)
    if q or keyword:
        return {"items": items, "total": len(items)}
    total = await skill_service.count_skills(db, project_id, domain=domain)
    return {"items": items, "total": total}


@router.get("/{skill_id}", response_model=SkillOut)
async def get_skill(
    skill_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("get_skill skill_id=%s", skill_id)
    skill = await skill_service.get_skill_by_id(db, project_id, skill_id)
    if not skill:
        raise HTTPException(404, "Skill not found")
    return skill


@router.post("", response_model=SkillOut, status_code=201)
async def create_skill(
    data: SkillCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_skill name=%s slug=%s domain=%s", data.name, data.slug, data.domain)
    return await skill_service.create_skill(
        db,
        project_id,
        name=data.name,
        slug=data.slug,
        description=data.description,
        domain=data.domain,
        content=data.content,
        entry_type=data.entry_type,
    )


@router.patch("/{skill_id}", response_model=SkillOut)
async def update_skill(
    skill_id: uuid.UUID,
    data: SkillUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("update_skill skill_id=%s", skill_id)
    skill = await skill_service.update_skill(db, project_id, skill_id, **data.model_dump(exclude_unset=True))
    if not skill:
        raise HTTPException(404, "Skill not found")
    return skill


@router.delete("/{skill_id}", status_code=204)
async def delete_skill(
    skill_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("delete_skill skill_id=%s", skill_id)
    deleted = await skill_service.delete_skill(db, project_id, skill_id)
    if not deleted:
        raise HTTPException(404, "Skill not found")
