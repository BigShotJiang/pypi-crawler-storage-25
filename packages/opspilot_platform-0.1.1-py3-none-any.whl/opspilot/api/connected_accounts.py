import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import ConnectedAccount
from opspilot.schemas import ConnectedAccountOut, ConnectedAccountUpdate
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/connected-accounts", tags=["connected-accounts"])


@router.get("", response_model=list[ConnectedAccountOut])
async def list_connected_accounts(
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.project_id == project_id).order_by(ConnectedAccount.created_at.desc())
    )
    return result.scalars().all()


@router.get("/{account_id}", response_model=ConnectedAccountOut)
async def get_connected_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.project_id == project_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")
    return account


@router.patch("/{account_id}", response_model=ConnectedAccountOut)
async def update_connected_account(
    account_id: uuid.UUID,
    body: ConnectedAccountUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.project_id == project_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")

    if body.label is not None:
        account.label = body.label or None
    if body.provider_metadata is not None:
        account.provider_metadata = {**account.provider_metadata, **body.provider_metadata}

    await db.commit()
    await db.refresh(account)
    return account


@router.delete("/{account_id}", status_code=204)
async def delete_connected_account(
    account_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.project_id == project_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")

    provider = account.provider  # capture before delete
    await oauth_service.revoke_account(db, account_id)

    if provider == "whatsapp":
        channel_manager = getattr(request.app.state, "channel_manager", None)
        if channel_manager:
            adapter = channel_manager.get_adapter("whatsapp")
            if adapter:
                await adapter.stop_client(str(account_id))


@router.post("/{account_id}/refresh", response_model=ConnectedAccountOut)
async def refresh_connected_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(
        select(ConnectedAccount).where(ConnectedAccount.id == account_id, ConnectedAccount.project_id == project_id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Connected account not found")
    try:
        await oauth_service.get_valid_access_token(db, account_id)
        await db.refresh(account)
        return account
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
