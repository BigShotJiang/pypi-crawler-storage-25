import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import (
    KnowledgeEntryCreate,
    KnowledgeEntryListItem,
    KnowledgeEntryOut,
    KnowledgeEntryUpdate,
    PaginatedResponse,
)
from opspilot.services import knowledge_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/knowledge", tags=["knowledge"])


@router.get("", response_model=PaginatedResponse[KnowledgeEntryListItem])
async def list_knowledge(
    q: str | None = None,
    keyword: str | None = None,
    category: str | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if q or keyword:
        items = await knowledge_service.list_knowledge(
            db, project_id, category=category, query=q, keyword=keyword, limit=limit, offset=offset,
        )
        return {"items": items, "total": len(items)}
    total = await knowledge_service.count_knowledge(db, project_id, category=category)
    items = await knowledge_service.list_knowledge(db, project_id, category=category, limit=limit, offset=offset)
    return {"items": items, "total": total}


@router.get("/{knowledge_id}", response_model=KnowledgeEntryOut)
async def get_knowledge(
    knowledge_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    entry = await knowledge_service.get_knowledge(db, project_id, knowledge_id)
    if not entry:
        raise HTTPException(404, "Knowledge entry not found")
    return entry


@router.post("", response_model=KnowledgeEntryOut, status_code=201)
async def create_knowledge(
    data: KnowledgeEntryCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    return await knowledge_service.create_knowledge(db, project_id, data)


@router.patch("/{knowledge_id}", response_model=KnowledgeEntryOut)
async def update_knowledge(
    knowledge_id: uuid.UUID,
    data: KnowledgeEntryUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    entry = await knowledge_service.update_knowledge(db, project_id, knowledge_id, data)
    if not entry:
        raise HTTPException(404, "Knowledge entry not found")
    return entry


@router.delete("/{knowledge_id}", status_code=204)
async def delete_knowledge(
    knowledge_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if not await knowledge_service.delete_knowledge(db, project_id, knowledge_id):
        raise HTTPException(404, "Knowledge entry not found")
