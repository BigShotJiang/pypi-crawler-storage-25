import asyncio
import json
import logging

import redis.asyncio as aioredis
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from opspilot.config import settings

router = APIRouter(tags=["websocket"])
logger = logging.getLogger(__name__)


@router.websocket("/ws/sessions/{session_id}")
async def session_stream(websocket: WebSocket, session_id: str):
    logger.info("websocket_connect session_id=%s", session_id)
    await websocket.accept()
    r = aioredis.from_url(settings.redis_url, decode_responses=False)
    pubsub = r.pubsub()
    channel = f"session:{session_id}"
    await pubsub.subscribe(channel)
    logger.debug("websocket_subscribed channel=%s", channel)

    try:
        while True:
            message = await pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
            if message and message["type"] == "message":
                data = message["data"]
                if isinstance(data, bytes):
                    data = data.decode("utf-8")
                await websocket.send_text(data)

                # Check if session completed
                try:
                    parsed = json.loads(data)
                    if parsed.get("type") == "session_end":
                        break
                except (json.JSONDecodeError, KeyError):
                    pass

            await asyncio.sleep(0.1)
    except WebSocketDisconnect:
        logger.info("websocket_disconnected session_id=%s", session_id)
    except Exception:
        logger.exception("websocket_stream_failed session_id=%s", session_id)
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.close()
        await r.close()
        logger.info("websocket_closed session_id=%s", session_id)
