import json
import logging
import secrets
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import Task, WebhookConfig, WebhookEvent
from opspilot.schemas import (
    PaginatedResponse,
    WebhookBulkDeleteRequest,
    WebhookConfigCreate,
    WebhookConfigDetailOut,
    WebhookConfigListItem,
    WebhookConfigOut,
    WebhookConfigUpdate,
    WebhookEventDetailOut,
    WebhookEventListItem,
    WebhookStatsOut,
    WebhookTriggerResponse,
)
from opspilot.services import webhook_config_service
from opspilot.services.idempotency_service import IdempotencyService
from opspilot.config import settings
import redis

router = APIRouter(tags=["webhooks"])
logger = logging.getLogger(__name__)

MAX_PAYLOAD_BYTES = 1_000_000  # 1 MB
_STRIP_HEADERS = {"x-webhook-token", "authorization", "cookie"}


def _sanitize_headers(headers: dict) -> dict:
    return {k: v for k, v in headers.items() if k.lower() not in _STRIP_HEADERS}


@router.post("/webhooks/{task_id}", response_model=WebhookTriggerResponse, status_code=202)
async def trigger_via_webhook(
    task_id: uuid.UUID,
    request: Request,
    token: str | None = Query(default=None),
    x_webhook_token: str | None = Header(default=None),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    db: AsyncSession = Depends(get_db),
):
    """External webhook trigger — called by AlertManager, Prometheus, or any other service."""
    task_result = await db.execute(select(Task).where(Task.id == task_id))
    task = task_result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Task not found")

    config_result = await db.execute(select(WebhookConfig).where(WebhookConfig.task_id == task_id))
    config = config_result.scalar_one_or_none()
    if not config:
        raise HTTPException(404, "Webhook not configured for this task")
    if not config.enabled:
        raise HTTPException(403, "Webhook is disabled for this task")

    provided_token = x_webhook_token or token
    if not provided_token or not secrets.compare_digest(provided_token, config.token):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid webhook token")

    if not task.enabled:
        raise HTTPException(422, "Task is disabled")

    # Idempotency: if caller provides a key, check for duplicate delivery
    idemp: IdempotencyService | None = None
    if idempotency_key:
        idemp = IdempotencyService(redis.from_url(settings.redis_url))
        is_dup, cached = await idemp.get_cached_response(idempotency_key)
        if is_dup and cached is not None:
            return WebhookTriggerResponse(**cached)

    body_bytes = await request.body()
    if len(body_bytes) > MAX_PAYLOAD_BYTES:
        raise HTTPException(413, "Payload too large (max 1 MB)")
    try:
        payload = json.loads(body_bytes) if body_bytes else {}
    except Exception:
        payload = {}

    source_ip = request.client.host if request.client else None
    sanitized_headers = _sanitize_headers(dict(request.headers))

    event = WebhookEvent(
        project_id=task.project_id,
        task_id=task_id,
        session_id=None,
        headers=sanitized_headers,
        payload=payload,
        source_ip=source_ip,
        processing_status="received",
    )
    db.add(event)
    await db.flush()

    from opspilot.services import webhook_service
    result = await webhook_service.process_webhook_event(db, task, event, payload)
    await db.commit()

    response = WebhookTriggerResponse(
        session_id=result.session_id,
        message=result.message,
        alert_group_id=result.alert_group_id,
        alert_count=result.alert_count,
    )

    # Cache response for idempotency
    if idempotency_key and idemp:
        await idemp.cache_response(idempotency_key, response.model_dump(mode="json"))

    return response


async def _get_task_scoped(
    db: AsyncSession, task_id: uuid.UUID, project_id: uuid.UUID,
) -> Task:
    """Fetch a task ensuring it belongs to the given project."""
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.project_id == project_id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Task not found")
    return task


async def _get_webhook_config_scoped(
    db: AsyncSession, task_id: uuid.UUID, project_id: uuid.UUID,
) -> WebhookConfig:
    """Fetch a webhook config ensuring it belongs to the given project."""
    result = await db.execute(
        select(WebhookConfig).where(
            WebhookConfig.task_id == task_id, WebhookConfig.project_id == project_id,
        )
    )
    config = result.scalar_one_or_none()
    if not config:
        raise HTTPException(404, "No webhook configured for this task")
    return config


@router.get("/tasks/{task_id}/webhook", response_model=WebhookConfigOut)
async def get_webhook_config(
    task_id: uuid.UUID,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    await _get_task_scoped(db, task_id, project_id)
    return await _get_webhook_config_scoped(db, task_id, project_id)


@router.post("/tasks/{task_id}/webhook", response_model=WebhookConfigOut, status_code=201)
async def create_webhook_config(
    task_id: uuid.UUID,
    data: WebhookConfigCreate,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    task = await _get_task_scoped(db, task_id, project_id)

    existing_result = await db.execute(
        select(WebhookConfig).where(WebhookConfig.task_id == task_id)
    )
    if existing_result.scalar_one_or_none():
        raise HTTPException(409, "Webhook config already exists for this task")

    config = WebhookConfig(
        project_id=task.project_id,
        task_id=task_id,
        name=data.name,
        token=secrets.token_urlsafe(32),
        enabled=True,
        description=data.description,
    )
    db.add(config)
    await db.commit()
    await db.refresh(config)
    logger.info("webhook_config_created task_id=%s config_id=%s", task_id, config.id)
    return config


@router.patch("/tasks/{task_id}/webhook", response_model=WebhookConfigOut)
async def update_webhook_config(
    task_id: uuid.UUID,
    data: WebhookConfigUpdate,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    config = await _get_webhook_config_scoped(db, task_id, project_id)

    if data.name is not None:
        config.name = data.name
    if data.enabled is not None:
        config.enabled = data.enabled
    if data.description is not None:
        config.description = data.description
    if data.regenerate_token:
        config.token = secrets.token_urlsafe(32)

    await db.commit()
    await db.refresh(config)
    return config


@router.delete("/tasks/{task_id}/webhook", status_code=204)
async def delete_webhook_config(
    task_id: uuid.UUID,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    config = await _get_webhook_config_scoped(db, task_id, project_id)
    await db.delete(config)
    await db.commit()
    logger.info("webhook_config_deleted task_id=%s", task_id)


# ---------------------------------------------------------------------------
# Webhook-centric endpoints (for the dedicated Webhooks management page)
# ---------------------------------------------------------------------------


@router.get("/webhook-configs/stats", response_model=WebhookStatsOut)
async def webhook_stats(
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    return await webhook_config_service.get_stats(db, project_id)


@router.get("/webhook-configs", response_model=PaginatedResponse[WebhookConfigListItem])
async def list_webhook_configs(
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
    enabled: bool | None = Query(default=None),
    task_id: uuid.UUID | None = Query(default=None),
    q: str | None = Query(default=None),
    limit: int = Query(default=25, le=200),
    offset: int = Query(default=0, ge=0),
):
    items = await webhook_config_service.list_configs(
        db, project_id, enabled=enabled, task_id=task_id, q=q, limit=limit, offset=offset,
    )
    total = await webhook_config_service.count_configs(
        db, project_id, enabled=enabled, task_id=task_id, q=q,
    )
    return {"items": items, "total": total}


@router.get("/webhook-configs/{webhook_id}", response_model=WebhookConfigDetailOut)
async def get_webhook_config_detail(
    webhook_id: uuid.UUID,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    detail = await webhook_config_service.get_config_detail(db, project_id, webhook_id)
    if not detail:
        raise HTTPException(404, "Webhook config not found")
    return detail


@router.post("/webhook-configs/{webhook_id}/test", response_model=WebhookTriggerResponse, status_code=202)
async def test_webhook_by_config_id(
    webhook_id: uuid.UUID,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    """Test-trigger a webhook using its config ID (no token needed, authenticated via project)."""
    config_result = await db.execute(
        select(WebhookConfig).where(WebhookConfig.id == webhook_id, WebhookConfig.project_id == project_id)
    )
    config = config_result.scalar_one_or_none()
    if not config:
        raise HTTPException(404, "Webhook config not found")

    task_result = await db.execute(select(Task).where(Task.id == config.task_id))
    task = task_result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Associated task not found")

    test_payload = {"source": "opspilot_test", "webhook_config_id": str(webhook_id), "test": True}

    event = WebhookEvent(
        project_id=project_id,
        task_id=task.id,
        session_id=None,
        headers={"x-opspilot-test": "true"},
        payload=test_payload,
        source_ip="127.0.0.1",
        processing_status="received",
    )
    db.add(event)
    await db.flush()

    from opspilot.services import webhook_service
    result = await webhook_service.process_webhook_event(db, task, event, test_payload)
    await db.commit()

    return WebhookTriggerResponse(
        session_id=result.session_id,
        message=result.message,
        alert_group_id=result.alert_group_id,
        alert_count=result.alert_count,
    )


@router.delete("/webhook-configs/bulk", status_code=200)
async def bulk_delete_webhook_configs(
    data: WebhookBulkDeleteRequest,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    deleted = await webhook_config_service.bulk_delete_configs(db, project_id, data.ids)
    return {"deleted_count": deleted}


@router.get("/webhook-events", response_model=PaginatedResponse[WebhookEventListItem])
async def list_webhook_events(
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
    task_id: uuid.UUID | None = Query(default=None),
    status_filter: str | None = Query(default=None, alias="status"),
    since: datetime | None = Query(default=None),
    until: datetime | None = Query(default=None),
    limit: int = Query(default=25, le=200),
    offset: int = Query(default=0, ge=0),
):
    items = await webhook_config_service.list_events(
        db, project_id, task_id=task_id, status=status_filter, since=since, until=until,
        limit=limit, offset=offset,
    )
    total = await webhook_config_service.count_events(
        db, project_id, task_id=task_id, status=status_filter, since=since, until=until,
    )
    return {"items": items, "total": total}


@router.get("/webhook-events/{event_id}", response_model=WebhookEventDetailOut)
async def get_webhook_event_detail(
    event_id: uuid.UUID,
    project_id: uuid.UUID = Depends(get_project_id_dep),
    db: AsyncSession = Depends(get_db),
):
    detail = await webhook_config_service.get_event_detail(db, project_id, event_id)
    if not detail:
        raise HTTPException(404, "Webhook event not found")
    return detail
