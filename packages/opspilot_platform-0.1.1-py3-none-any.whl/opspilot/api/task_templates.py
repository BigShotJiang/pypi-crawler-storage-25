import logging
import uuid

from fastapi import APIRouter, Depends
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import TaskTemplate
from opspilot.schemas import TaskTemplateOut

router = APIRouter(prefix="/task-templates", tags=["task-templates"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[TaskTemplateOut])
async def list_templates(
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("list_task_templates")
    stmt = (
        select(TaskTemplate)
        .where(or_(TaskTemplate.project_id == project_id, TaskTemplate.project_id.is_(None)))
        .order_by(TaskTemplate.name)
    )
    result = await db.execute(stmt)
    return result.scalars().all()
