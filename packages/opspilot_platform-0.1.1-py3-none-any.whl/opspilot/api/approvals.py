import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models.approvals import ApprovalStatus
from opspilot.schemas.approvals import (
    ApprovalCommentCreate,
    ApprovalCommentOut,
    ApprovalDecision,
    ApprovalOut,
)
from opspilot.schemas.common import PaginatedResponse
from opspilot.services import approval_service

router = APIRouter(prefix="/approvals", tags=["approvals"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[ApprovalOut])
async def list_approvals(
    status: str | None = Query(default=None),
    approval_type: str | None = Query(default=None),
    limit: int = Query(default=25, le=100),
    offset: int = Query(default=0),
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    status_enum = ApprovalStatus(status) if status else None
    items = await approval_service.list_approvals(
        db, project_id, status=status_enum, approval_type=approval_type, limit=limit, offset=offset,
    )
    total = await approval_service.count_approvals(
        db, project_id, status=status_enum, approval_type=approval_type,
    )
    return PaginatedResponse(items=items, total=total, limit=limit, offset=offset)


@router.get("/{approval_id}", response_model=ApprovalOut)
async def get_approval(
    approval_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
):
    """Get approval details. No X-Project-ID required — approval links from notifications."""
    approval = await approval_service.get_approval_any_project(db, approval_id)
    if not approval:
        raise HTTPException(404, "Approval not found")
    return approval


async def _handle_decision(
    db: AsyncSession,
    approval_id: uuid.UUID,
    action: str,
    data: ApprovalDecision,
) -> ApprovalOut:
    """Shared handler for approve/reject/request-revision."""
    approval = await approval_service.get_approval_any_project(db, approval_id)
    if not approval:
        raise HTTPException(404, "Approval not found")
    try:
        approval = await approval_service.decide(
            db, approval.project_id, approval_id, action,
            data.decided_by, data.decision_note,
        )
    except KeyError as e:
        raise HTTPException(404, str(e))
    except ValueError as e:
        raise HTTPException(409, str(e))
    await db.commit()
    return approval


@router.post("/{approval_id}/approve", response_model=ApprovalOut)
async def approve_approval(
    approval_id: uuid.UUID,
    data: ApprovalDecision,
    db: AsyncSession = Depends(get_db),
):
    return await _handle_decision(db, approval_id, "approve", data)


@router.post("/{approval_id}/reject", response_model=ApprovalOut)
async def reject_approval(
    approval_id: uuid.UUID,
    data: ApprovalDecision,
    db: AsyncSession = Depends(get_db),
):
    return await _handle_decision(db, approval_id, "reject", data)


@router.post("/{approval_id}/request-revision", response_model=ApprovalOut)
async def request_revision(
    approval_id: uuid.UUID,
    data: ApprovalDecision,
    db: AsyncSession = Depends(get_db),
):
    return await _handle_decision(db, approval_id, "request_revision", data)


@router.get("/{approval_id}/comments", response_model=list[ApprovalCommentOut])
async def list_comments(
    approval_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
):
    """List all comments on an approval. No X-Project-ID required."""
    return await approval_service.list_comments(db, approval_id)


@router.post("/{approval_id}/comments", response_model=ApprovalCommentOut)
async def add_comment(
    approval_id: uuid.UUID,
    data: ApprovalCommentCreate,
    db: AsyncSession = Depends(get_db),
):
    """Add a comment to an approval. No X-Project-ID required."""
    try:
        comment = await approval_service.add_comment(
            db, approval_id, data.author_type, data.author_id, data.body,
        )
    except KeyError as e:
        raise HTTPException(404, str(e))
    await db.commit()
    return comment
