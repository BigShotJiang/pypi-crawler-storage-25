import io
import logging
import uuid

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from weasyprint import HTML

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import ReportOut, ReportListOut, ReportCreate, PaginatedResponse
from opspilot.services import report_service

router = APIRouter(prefix="/reports", tags=["reports"])
logger = logging.getLogger(__name__)

# Re-export for use by chat.py export endpoint (pre-existing cross-module reference).
_markdown_to_html = report_service._markdown_to_html_body


@router.get("", response_model=PaginatedResponse[ReportListOut])
async def list_reports(
    task_id: uuid.UUID | None = None,
    session_id: uuid.UUID | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("list_reports task_id=%s session_id=%s limit=%s offset=%s", task_id, session_id, limit, offset)
    reports, total = await report_service.list_reports(
        db, project_id, task_id=task_id, session_id=session_id, limit=limit, offset=offset,
    )
    items = []
    for r in reports:
        r_out = ReportListOut.model_validate(r)
        if r.task:
            r_out.task_name = r.task.name
        items.append(r_out)
    return {"items": items, "total": total}


@router.post("", response_model=ReportOut, status_code=201)
async def create_report(
    data: ReportCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_report title=%s", data.title)
    report = await report_service.create_report(
        db, project_id,
        title=data.title,
        content_md=data.content_md,
        content_html=data.content_html,
        task_id=data.task_id,
        session_id=data.session_id,
    )
    return report


@router.get("/{report_id}", response_model=ReportOut)
async def get_report(
    report_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("get_report report_id=%s", report_id)
    report = await report_service.get_report(db, project_id, report_id)
    if not report:
        raise HTTPException(404, "Report not found")
    return report


@router.get("/{report_id}/pdf")
async def get_report_pdf(
    report_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("get_report_pdf report_id=%s", report_id)
    report = await report_service.get_report(db, project_id, report_id)
    if not report:
        raise HTTPException(404, "Report not found")
    if not report.s3_url:
        raise HTTPException(404, "Report has no content stored")

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(report.s3_url)
        resp.raise_for_status()
        html_content = resp.text

    pdf_bytes = HTML(string=html_content, base_url=report.s3_url).write_pdf()
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=report-{report.id}.pdf"},
    )


@router.delete("/{report_id}", status_code=204)
async def delete_report(
    report_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("delete_report report_id=%s", report_id)
    deleted = await report_service.delete_report(db, project_id, report_id)
    if not deleted:
        raise HTTPException(404, "Report not found")
