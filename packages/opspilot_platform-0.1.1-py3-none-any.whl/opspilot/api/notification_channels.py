import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import NotificationChannel
from opspilot.schemas import NotificationChannelCreate, NotificationChannelOut, NotificationChannelUpdate

router = APIRouter(prefix="/notification-channels", tags=["notification-channels"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[NotificationChannelOut])
async def list_channels(
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("list_notification_channels")
    stmt = select(NotificationChannel).where(NotificationChannel.project_id == project_id).order_by(NotificationChannel.name)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{channel_id}", response_model=NotificationChannelOut)
async def get_channel(channel_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    logger.debug("get_notification_channel channel_id=%s", channel_id)
    stmt = select(NotificationChannel).where(NotificationChannel.id == channel_id)
    result = await db.execute(stmt)
    channel = result.scalar_one_or_none()
    if not channel:
        logger.info("notification_channel_not_found channel_id=%s", channel_id)
        raise HTTPException(404, "Notification channel not found")
    return channel


@router.post("", response_model=NotificationChannelOut, status_code=201)
async def create_channel(
    data: NotificationChannelCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_notification_channel name=%s channel_type=%s", data.name, data.channel_type)
    channel = NotificationChannel(**data.model_dump(), project_id=project_id)
    db.add(channel)
    await db.flush()
    logger.info("notification_channel_created channel_id=%s", channel.id)
    return channel


@router.patch("/{channel_id}", response_model=NotificationChannelOut)
async def update_channel(channel_id: uuid.UUID, data: NotificationChannelUpdate, db: AsyncSession = Depends(get_db)):
    logger.info("update_notification_channel channel_id=%s", channel_id)
    stmt = select(NotificationChannel).where(NotificationChannel.id == channel_id)
    result = await db.execute(stmt)
    channel = result.scalar_one_or_none()
    if not channel:
        logger.info("notification_channel_not_found channel_id=%s", channel_id)
        raise HTTPException(404, "Notification channel not found")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(channel, key, value)
    logger.debug("notification_channel_updated channel_id=%s", channel_id)
    return channel


@router.delete("/{channel_id}", status_code=204)
async def delete_channel(channel_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    logger.info("delete_notification_channel channel_id=%s", channel_id)
    stmt = select(NotificationChannel).where(NotificationChannel.id == channel_id)
    result = await db.execute(stmt)
    channel = result.scalar_one_or_none()
    if not channel:
        logger.info("notification_channel_not_found channel_id=%s", channel_id)
        raise HTTPException(404, "Notification channel not found")
    await db.delete(channel)
    logger.info("notification_channel_deleted channel_id=%s", channel_id)
