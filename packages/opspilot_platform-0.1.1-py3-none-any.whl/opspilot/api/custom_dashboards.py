import logging
import uuid

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import CustomDashboardCreate, CustomDashboardOut, CustomDashboardUpdate, PaginatedResponse
from opspilot.services import custom_dashboard_service

router = APIRouter(prefix="/custom-dashboards", tags=["custom-dashboards"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[CustomDashboardOut])
async def list_custom_dashboards(
    search: str | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    items, total = await custom_dashboard_service.list_custom_dashboards(
        db, project_id, search=search, limit=limit, offset=offset
    )
    return {"items": items, "total": total}


@router.post("/reorder", response_model=list[CustomDashboardOut])
async def reorder_dashboards(
    items: list[dict],
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    await custom_dashboard_service.reorder_favorites(db, project_id, items)
    await db.commit()
    dashboards, _ = await custom_dashboard_service.list_custom_dashboards(db, project_id, limit=200, offset=0)
    return dashboards


@router.post("", response_model=CustomDashboardOut, status_code=201)
async def create_custom_dashboard(
    data: CustomDashboardCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_custom_dashboard title=%s", data.title)
    dashboard = await custom_dashboard_service.create_custom_dashboard(
        db,
        project_id,
        title=data.title,
        description=data.description,
        content_html=data.content_html,
        task_id=data.task_id,
        session_id=data.session_id,
    )
    await db.commit()
    await db.refresh(dashboard)
    return dashboard


@router.get("/{dashboard_id}/render", response_class=HTMLResponse)
async def render_custom_dashboard(
    dashboard_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Serve the dashboard HTML through OpsPilot (proxy from S3)."""
    dashboard = await custom_dashboard_service.get_custom_dashboard(db, project_id, dashboard_id)
    if not dashboard or not dashboard.s3_url:
        raise HTTPException(404, "Dashboard not found or has no content")
    async with httpx.AsyncClient() as client:
        resp = await client.get(dashboard.s3_url, timeout=15.0)
        if resp.status_code != 200:
            raise HTTPException(502, "Failed to fetch dashboard content from storage")
    return HTMLResponse(content=resp.content, media_type="text/html")


@router.get("/{dashboard_id}", response_model=CustomDashboardOut)
async def get_custom_dashboard(
    dashboard_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    dashboard = await custom_dashboard_service.get_custom_dashboard(db, project_id, dashboard_id)
    if not dashboard:
        raise HTTPException(404, "Dashboard not found")
    return dashboard


@router.patch("/{dashboard_id}", response_model=CustomDashboardOut)
async def update_custom_dashboard(
    dashboard_id: uuid.UUID,
    data: CustomDashboardUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    dashboard = await custom_dashboard_service.update_custom_dashboard(db, project_id, dashboard_id, data)
    if not dashboard:
        raise HTTPException(404, "Dashboard not found")
    await db.commit()
    await db.refresh(dashboard)
    return dashboard


@router.delete("/{dashboard_id}", status_code=204)
async def delete_custom_dashboard(
    dashboard_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if not await custom_dashboard_service.delete_custom_dashboard(db, project_id, dashboard_id):
        raise HTTPException(404, "Dashboard not found")
    await db.commit()


@router.post("/{dashboard_id}/favorite", response_model=CustomDashboardOut)
async def toggle_dashboard_favorite(
    dashboard_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    dashboard = await custom_dashboard_service.toggle_favorite(db, project_id, dashboard_id)
    if not dashboard:
        raise HTTPException(404, "Dashboard not found")
    await db.commit()
    await db.refresh(dashboard)
    return dashboard


@router.post("/{dashboard_id}/screenshot", response_model=CustomDashboardOut)
async def screenshot_custom_dashboard(
    dashboard_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    try:
        dashboard = await custom_dashboard_service.screenshot_custom_dashboard(db, project_id, dashboard_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not dashboard:
        raise HTTPException(404, "Dashboard not found or has no content URL")
    await db.commit()
    await db.refresh(dashboard)
    return dashboard
