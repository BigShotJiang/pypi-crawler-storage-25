import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import GitRepo
from opspilot.schemas import GitRepoCreate, GitRepoOut, GitRepoUpdate

router = APIRouter(prefix="/git-repos", tags=["git-repos"])
logger = logging.getLogger(__name__)


def _repo_to_out(repo: GitRepo) -> GitRepoOut:
    """Build GitRepoOut — derives has_token/has_ssh_key, never exposes secrets."""
    return GitRepoOut(
        id=repo.id,
        name=repo.name,
        url=repo.url,
        branch=repo.branch,
        username=repo.username,
        has_token=repo.token_encrypted is not None,
        auth_type=repo.auth_type or "https_token",
        has_ssh_key=repo.ssh_key_encrypted is not None,
        shallow=repo.shallow,
        context=repo.context,
        created_at=repo.created_at,
        updated_at=repo.updated_at,
    )


def _try_encrypt(token: str | None) -> str | None:
    """Encrypt a token using Fernet. Returns None if token is empty/None."""
    if not token:
        return None
    from opspilot.services.oauth_service import encrypt_token
    return encrypt_token(token)


@router.get("", response_model=list[GitRepoOut])
async def list_git_repos(
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(select(GitRepo).where(GitRepo.project_id == project_id).order_by(GitRepo.name))
    return [_repo_to_out(r) for r in result.scalars().all()]


@router.get("/{repo_id}", response_model=GitRepoOut)
async def get_git_repo(
    repo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    result = await db.execute(select(GitRepo).where(GitRepo.id == repo_id, GitRepo.project_id == project_id))
    repo = result.scalar_one_or_none()
    if not repo:
        raise HTTPException(404, "Git repo not found")
    return _repo_to_out(repo)


@router.post("", response_model=GitRepoOut, status_code=201)
async def create_git_repo(
    data: GitRepoCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_git_repo name=%s url=%s auth_type=%s", data.name, data.url, data.auth_type)
    repo = GitRepo(
        name=data.name,
        url=data.url,
        branch=data.branch,
        username=data.username or None,
        token_encrypted=_try_encrypt(data.token),
        auth_type=data.auth_type,
        ssh_key_encrypted=_try_encrypt(data.ssh_key),
        shallow=data.shallow,
        context=data.context or None,
        project_id=project_id,
    )
    db.add(repo)
    await db.flush()
    logger.info("git_repo_created repo_id=%s name=%s", repo.id, repo.name)
    return _repo_to_out(repo)


@router.patch("/{repo_id}", response_model=GitRepoOut)
async def update_git_repo(
    repo_id: uuid.UUID,
    data: GitRepoUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("update_git_repo repo_id=%s", repo_id)
    result = await db.execute(select(GitRepo).where(GitRepo.id == repo_id, GitRepo.project_id == project_id))
    repo = result.scalar_one_or_none()
    if not repo:
        raise HTTPException(404, "Git repo not found")

    update_fields = data.model_dump(exclude_unset=True, exclude={"token", "ssh_key"})
    for key, value in update_fields.items():
        setattr(repo, key, value)

    # Handle token separately: present in payload -> update/clear; absent -> keep existing
    if "token" in data.model_fields_set:
        repo.token_encrypted = _try_encrypt(data.token)

    # Handle ssh_key separately (same pattern as token)
    if "ssh_key" in data.model_fields_set:
        repo.ssh_key_encrypted = _try_encrypt(data.ssh_key)

    # When switching auth_type, clear the other credential
    if "auth_type" in data.model_fields_set and data.auth_type:
        if data.auth_type == "ssh_key":
            repo.token_encrypted = None
            repo.username = None
        elif data.auth_type == "https_token":
            repo.ssh_key_encrypted = None

    logger.info("git_repo_updated repo_id=%s", repo_id)
    return _repo_to_out(repo)


@router.delete("/{repo_id}", status_code=204)
async def delete_git_repo(
    repo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("delete_git_repo repo_id=%s", repo_id)
    result = await db.execute(select(GitRepo).where(GitRepo.id == repo_id, GitRepo.project_id == project_id))
    repo = result.scalar_one_or_none()
    if not repo:
        raise HTTPException(404, "Git repo not found")
    await db.delete(repo)
    logger.info("git_repo_deleted repo_id=%s", repo_id)


@router.post("/{repo_id}/test")
async def test_git_repo(
    repo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Verify repository connectivity by running git ls-remote."""
    import os
    import subprocess
    import tempfile
    from urllib.parse import urlparse, urlunparse

    result = await db.execute(select(GitRepo).where(GitRepo.id == repo_id, GitRepo.project_id == project_id))
    repo = result.scalar_one_or_none()
    if not repo:
        raise HTTPException(404, "Git repo not found")

    clone_url = repo.url
    env: dict | None = None

    if repo.auth_type == "ssh_key" and repo.ssh_key_encrypted:
        from opspilot.services.oauth_service import decrypt_token
        ssh_key = decrypt_token(repo.ssh_key_encrypted)
        key_file = tempfile.NamedTemporaryFile(mode="w", suffix="_key", delete=False)
        try:
            key_file.write(ssh_key)
            key_file.close()
            os.chmod(key_file.name, 0o600)
            env = {**os.environ, "GIT_SSH_COMMAND": f"ssh -i {key_file.name} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"}
        except Exception:
            os.unlink(key_file.name)
            raise
    elif repo.token_encrypted and repo.url.startswith("https://"):
        from opspilot.services.oauth_service import decrypt_token
        token = decrypt_token(repo.token_encrypted)
        parsed = urlparse(repo.url)
        userinfo = f"{repo.username}:{token}" if repo.username else token
        clone_url = urlunparse(parsed._replace(netloc=f"{userinfo}@{parsed.netloc}"))

    try:
        proc = subprocess.run(
            ["git", "ls-remote", "--heads", clone_url],
            capture_output=True, timeout=30, env=env,
        )
        if proc.returncode != 0:
            stderr = proc.stderr.decode("utf-8", errors="replace")
            if clone_url != repo.url:
                stderr = stderr.replace(clone_url, repo.url)
            return {"success": False, "message": stderr.strip()[:300] or "Connection failed"}
        return {"success": True, "message": "Connection successful"}
    except subprocess.TimeoutExpired:
        return {"success": False, "message": "Connection timed out after 30 seconds"}
    except Exception as exc:
        return {"success": False, "message": str(exc)[:300]}
    finally:
        if env and key_file:
            os.unlink(key_file.name)
