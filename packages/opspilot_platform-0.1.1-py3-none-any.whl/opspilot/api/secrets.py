import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import PaginatedResponse
from opspilot.schemas.secrets import SecretCreate, SecretListOut, SecretOut, SecretUpdate
from opspilot.services import secret_service

router = APIRouter(prefix="/secrets", tags=["secrets"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[SecretListOut])
async def list_secrets(
    name: str | None = None,
    provider: str | None = None,
    environment: str | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    total = await secret_service.count_secrets(db, project_id, provider=provider, environment=environment)
    items = await secret_service.list_secrets(
        db, project_id, provider=provider, environment=environment, name=name, limit=limit, offset=offset,
    )
    return {"items": items, "total": total}


@router.get("/count")
async def count_secrets(
    provider: str | None = None,
    environment: str | None = None,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    count = await secret_service.count_secrets(db, project_id, provider=provider, environment=environment)
    return {"count": count}


@router.get("/{secret_id}", response_model=SecretOut)
async def get_secret(
    secret_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    secret = await secret_service.get_secret(db, project_id, secret_id)
    if not secret:
        raise HTTPException(404, "Secret not found")
    return secret_service.secret_to_out_dict(secret)


@router.post("", response_model=SecretOut, status_code=201)
async def create_secret(
    data: SecretCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    try:
        secret = await secret_service.create_secret(db, project_id, data)
        return secret_service.secret_to_out_dict(secret)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.patch("/{secret_id}", response_model=SecretOut)
async def update_secret(
    secret_id: uuid.UUID,
    data: SecretUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    try:
        secret = await secret_service.update_secret(db, project_id, secret_id, data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not secret:
        raise HTTPException(404, "Secret not found")
    return secret_service.secret_to_out_dict(secret)


@router.delete("/{secret_id}", status_code=204)
async def delete_secret(
    secret_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if not await secret_service.delete_secret(db, project_id, secret_id):
        raise HTTPException(404, "Secret not found")
