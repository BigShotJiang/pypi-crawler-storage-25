import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models.findings import RunbookStatus
from opspilot.schemas import PaginatedResponse, RunbookCreate, RunbookOut, RunbookUpdate
from opspilot.services import runbook_service

router = APIRouter(prefix="/runbooks", tags=["runbooks"])
logger = logging.getLogger(__name__)


@router.get("", response_model=PaginatedResponse[RunbookOut])
async def list_runbooks(
    q: str | None = None,
    keyword: str | None = None,
    status: RunbookStatus | None = None,
    category: str | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if q or keyword:
        items = await runbook_service.list_runbooks(
            db, project_id, status=status, category=category, query=q, keyword=keyword, limit=limit, offset=offset,
        )
        return {"items": items, "total": len(items)}
    total = await runbook_service.count_runbooks(db, project_id, status=status, category=category)
    items = await runbook_service.list_runbooks(
        db, project_id, status=status, category=category, limit=limit, offset=offset,
    )
    return {"items": items, "total": total}


@router.get("/{runbook_id}", response_model=RunbookOut)
async def get_runbook(
    runbook_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    rb = await runbook_service.get_runbook(db, project_id, runbook_id)
    if not rb:
        raise HTTPException(404, "Runbook not found")
    return rb


@router.post("", response_model=RunbookOut, status_code=201)
async def create_runbook(
    data: RunbookCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("create_runbook slug=%s", data.slug)
    return await runbook_service.create_runbook(db, project_id, data)


@router.patch("/{runbook_id}", response_model=RunbookOut)
async def update_runbook(
    runbook_id: uuid.UUID,
    data: RunbookUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    rb = await runbook_service.update_runbook(db, project_id, runbook_id, data)
    if not rb:
        raise HTTPException(404, "Runbook not found")
    return rb


@router.delete("/{runbook_id}", status_code=204)
async def delete_runbook(
    runbook_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if not await runbook_service.delete_runbook(db, project_id, runbook_id):
        raise HTTPException(404, "Runbook not found")
