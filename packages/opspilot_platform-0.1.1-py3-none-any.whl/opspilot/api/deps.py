"""Shared FastAPI dependencies."""
import uuid
from fastapi import HTTPException
from opspilot.context import get_project_id


def get_project_id_dep() -> uuid.UUID:
    """Extract project_id from request context. Raises 400 if missing."""
    pid = get_project_id()
    if not pid:
        raise HTTPException(status_code=400, detail="Missing X-Project-ID header")
    return pid
