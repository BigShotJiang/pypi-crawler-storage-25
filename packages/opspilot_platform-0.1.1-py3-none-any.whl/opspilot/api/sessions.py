import io
import json
import uuid
import logging
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response, StreamingResponse
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from opspilot.api.deps import get_project_id_dep
from opspilot.api.tasks import get_tasks_service
from opspilot.application.tasks_service import TasksService
from opspilot.database import get_db
from opspilot.models import Message, MessageRole, Session, ToolCall, ToolCallStatus
from opspilot.models import SessionStatus
from opspilot.schemas import FindingCreate, FindingOut, PaginatedResponse, SessionBulkDeleteRequest, SessionBulkDeleteResponse, SessionDetailOut, SessionOut, SessionStatsOut, TaskTriggerResponse
from opspilot.schemas.artifacts import ArtifactOut
from opspilot.services import artifact_service
from opspilot.services import finding_service
from opspilot.services import session_bridge
from opspilot.services import session_read_service
from opspilot.models.artifacts import ArtifactSourceType, ArtifactTrigger

router = APIRouter(prefix="/sessions", tags=["sessions"])
logger = logging.getLogger(__name__)


@router.get("/stats", response_model=SessionStatsOut)
async def get_session_stats(
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("get_session_stats")
    return await session_read_service.get_session_stats(db, project_id)


@router.get("", response_model=PaginatedResponse[SessionOut])
async def list_sessions(
    task_id: uuid.UUID | None = None,
    status: SessionStatus | None = None,
    agent_type: str | None = None,
    trigger_source: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("list_sessions task_id=%s status=%s agent_type=%s limit=%s offset=%s", task_id, status, agent_type, limit, offset)

    filters = [Session.project_id == project_id]
    if task_id:
        filters.append(Session.task_id == task_id)
    if status:
        filters.append(Session.status == status)
    if agent_type:
        filters.append(Session.agent_type == agent_type)
    if trigger_source:
        filters.append(Session.trigger_source == trigger_source)
    if created_after:
        filters.append(Session.created_at >= created_after)
    if created_before:
        filters.append(Session.created_at <= created_before)

    count_stmt = select(func.count()).select_from(Session)
    for f in filters:
        count_stmt = count_stmt.where(f)
    total = await db.scalar(count_stmt) or 0

    total_tc_sq = (
        select(func.count())
        .where(ToolCall.session_id == Session.id)
        .correlate(Session)
        .scalar_subquery()
    )
    success_tc_sq = (
        select(func.count())
        .where(ToolCall.session_id == Session.id)
        .where(ToolCall.status == ToolCallStatus.SUCCESS)
        .correlate(Session)
        .scalar_subquery()
    )
    failed_tc_sq = (
        select(func.count())
        .where(ToolCall.session_id == Session.id)
        .where(ToolCall.status == ToolCallStatus.ERROR)
        .correlate(Session)
        .scalar_subquery()
    )
    msg_sq = (
        select(func.count())
        .where(Message.session_id == Session.id)
        .where(Message.role != MessageRole.SYSTEM)
        .correlate(Session)
        .scalar_subquery()
    )

    stmt = (
        select(Session, total_tc_sq.label("total_tc"), success_tc_sq.label("success_tc"), failed_tc_sq.label("failed_tc"), msg_sq.label("msg_count"))
        .options(selectinload(Session.task))
        .order_by(Session.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    for f in filters:
        stmt = stmt.where(f)
    result = await db.execute(stmt)
    rows = result.all()

    items = []
    for row in rows:
        s, total_tc, success_tc, failed_tc, msg_count = row
        s_out = SessionOut.model_validate(s)
        if s.task:
            s_out.task_name = s.task.name
        s_out.total_tool_calls_count = total_tc or 0
        s_out.success_tool_calls_count = success_tc or 0
        s_out.failed_tool_calls_count = failed_tc or 0
        s_out.total_messages_count = msg_count or 0
        items.append(s_out)

    return {"items": items, "total": total}


@router.get("/count")
async def count_sessions(
    task_id: uuid.UUID | None = None,
    status: SessionStatus | None = None,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug("count_sessions task_id=%s status=%s", task_id, status)
    count = await session_read_service.count_sessions(db, project_id, task_id=task_id, status=status)
    return {"count": count}


@router.post("/bulk-delete", response_model=SessionBulkDeleteResponse)
async def bulk_delete_sessions(
    data: SessionBulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.info("bulk_delete_sessions count=%s", len(data.file_ids))
    deleted = await session_read_service.bulk_delete_sessions(db, project_id, data.file_ids)
    logger.info("bulk_delete_sessions_done deleted=%s", deleted)
    return {"deleted_count": deleted, "failed_ids": []}


@router.post("/{session_id}/retry", response_model=TaskTriggerResponse, status_code=202)
async def retry_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
    service: TasksService = Depends(get_tasks_service),
):
    """Create a fresh new session for the same task, starting from scratch (no resume)."""
    result = await db.execute(
        select(Session)
        .where(Session.id == session_id, Session.project_id == project_id)
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(404, "Session not found")
    if not session.task_id:
        raise HTTPException(400, "Session has no parent task and cannot be retried")

    try:
        response = await service.trigger_task(session.task_id, trigger_source="manual")
    except KeyError as e:
        raise HTTPException(404, str(e))

    await db.commit()
    logger.info("session_retried original_session_id=%s new_session_id=%s task_id=%s", session_id, response.session_id, session.task_id)
    return response


@router.post("/{session_id}/continue")
async def continue_session_as_chat(
    session_id: str,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    try:
        conversation = await session_bridge.create_conversation_from_session(
            db, project_id, uuid.UUID(session_id)
        )
        await db.commit()
        return {"conversation_id": str(conversation.id)}
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{session_id}", response_model=SessionDetailOut)
async def get_session(session_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    logger.debug("get_session session_id=%s", session_id)
    stmt = (
        select(Session)
        .where(Session.id == session_id)
        .options(
            selectinload(Session.messages),
            selectinload(Session.tool_calls),
            selectinload(Session.findings),
            selectinload(Session.reports),
            selectinload(Session.incidents),
            selectinload(Session.skills),
            selectinload(Session.notification_logs),
        )
    )
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        logger.info("session_not_found session_id=%s", session_id)
        raise HTTPException(404, "Session not found")
    return session


@router.post("/{session_id}/cancel", response_model=SessionOut)
async def cancel_session(session_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    logger.info("cancel_session session_id=%s", session_id)
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        logger.info("session_not_found session_id=%s", session_id)
        raise HTTPException(404, "Session not found")
    if session.status not in (SessionStatus.PENDING, SessionStatus.RUNNING):
        logger.info("cancel_session_invalid_state session_id=%s status=%s", session_id, session.status)
        raise HTTPException(400, f"Cannot cancel session in {session.status} state")
    session.status = SessionStatus.CANCELLED
    logger.info("session_cancelled session_id=%s", session_id)
    return session


@router.post("/{session_id}/findings", response_model=FindingOut, status_code=201)
async def create_session_finding(
    session_id: uuid.UUID,
    data: FindingCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Endpoint called by OpsPilot Notify MCP server to report findings."""
    logger.info("create_session_finding session_id=%s severity=%s type=%s", session_id, data.severity, data.finding_type)
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        logger.info("session_not_found session_id=%s", session_id)
        raise HTTPException(404, "Session not found")

    finding = await finding_service.create_finding(db, project_id, data.model_copy(update={"session_id": session.id}))
    logger.info("finding_created finding_id=%s session_id=%s", finding.id, session_id)
    return finding


@router.post("/{session_id}/artifacts", response_model=ArtifactOut, status_code=201)
async def create_session_artifact(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Export the session workspace directory as a downloadable tar.gz artifact."""
    result = await db.execute(
        select(Session).where(Session.id == session_id, Session.project_id == project_id)
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(404, "Session not found")
    if not session.workspace_path:
        raise HTTPException(409, "Session has no workspace path recorded")

    try:
        artifact = await artifact_service.create_artifact_from_workspace(
            db, project_id, session.workspace_path,
            source_type=ArtifactSourceType.SESSION,
            session_id=session.id,
            trigger=ArtifactTrigger.MANUAL,
        )
        await db.commit()
        logger.info("session_artifact_created session_id=%s artifact_id=%s", session_id, artifact.id)
        return artifact
    except ValueError as e:
        raise HTTPException(409, str(e))


@router.get("/{session_id}/export")
async def export_session(
    session_id: uuid.UUID,
    format: str = Query("md", pattern="^(md|pdf)$"),
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Export session timeline as Markdown or PDF."""
    stmt = (
        select(Session)
        .where(Session.id == session_id, Session.project_id == project_id)
        .options(
            selectinload(Session.messages),
            selectinload(Session.tool_calls),
            selectinload(Session.findings),
            selectinload(Session.task),
        )
    )
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(404, "Session not found")

    md = _render_session_md(session)

    if format == "pdf":
        from weasyprint import HTML
        from opspilot.services.report_service import markdown_to_styled_html
        task_name = session.task.name if session.task else "Session Export"
        html_doc = markdown_to_styled_html(md, title=task_name)
        pdf_bytes = HTML(string=html_doc, base_url="").write_pdf()
        filename = f"session-{session_id}.pdf"
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    filename = f"session-{session_id}.md"
    return Response(
        content=md,
        media_type="text/markdown",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


def _render_session_md(session: Session) -> str:
    """Render a session timeline to Markdown for export.

    Order matches the Timeline tab: system prompt → task prompt → interleaved
    messages, tool calls, and findings sorted by sequence.
    """
    task_name = session.task.name if session.task else "Ad-hoc Session"
    lines = [
        f"# Session: {task_name}",
        "",
        f"**Agent**: {session.agent_type.value}  ",
        f"**Status**: {session.status.value}  ",
        f"**Trigger**: {session.trigger_source}  ",
    ]
    if session.started_at:
        lines.append(f"**Started**: {session.started_at.strftime('%Y-%m-%d %H:%M UTC')}  ")
    if session.finished_at:
        lines.append(f"**Ended**: {session.finished_at.strftime('%Y-%m-%d %H:%M UTC')}  ")
    if session.duration_ms:
        secs = session.duration_ms / 1000
        lines.append(f"**Duration**: {secs:.1f}s  ")
    lines += [
        f"**Tokens**: {session.input_tokens:,} in / {session.output_tokens:,} out  ",
        f"**Cost**: ${session.cost_usd:.4f}",
        "",
        "---",
        "",
    ]

    # System prompt
    if session.system_prompt_snapshot:
        lines += [
            "## System Prompt",
            "",
            "```",
            session.system_prompt_snapshot.strip(),
            "```",
            "",
            "---",
            "",
        ]

    # Task prompt
    if session.prompt_snapshot:
        lines += [
            "## Task Prompt",
            "",
            session.prompt_snapshot.strip(),
            "",
            "---",
            "",
        ]

    # Build interleaved timeline sorted by sequence (same as frontend Timeline tab)
    timeline: list[tuple[int, str, object]] = []
    for m in session.messages:
        if m.role == MessageRole.SYSTEM:
            continue
        seq = m.sequence if m.sequence is not None else 0
        timeline.append((seq, "message", m))
    for tc in session.tool_calls:
        seq = tc.sequence if tc.sequence is not None else 0
        timeline.append((seq, "tool_call", tc))
    for f in session.findings:
        seq = 999_999  # findings don't have sequence — push to end
        timeline.append((seq, "finding", f))
    timeline.sort(key=lambda x: x[0])

    lines.append("## Timeline")
    lines.append("")

    for _seq, kind, item in timeline:
        if kind == "message":
            role_label = "User" if item.role == MessageRole.USER else "Assistant"
            lines += [f"### {role_label}", "", item.content, ""]
        elif kind == "tool_call":
            status_icon = "\u2705" if item.status == ToolCallStatus.SUCCESS else "\u274c"
            server = f" ({item.tool_server})" if item.tool_server else ""
            duration = f" — {item.duration_ms}ms" if item.duration_ms else ""
            lines.append(f"#### {status_icon} `{item.tool_name}`{server}{duration}")
            lines.append("")
            if item.input_params:
                try:
                    input_str = json.dumps(item.input_params, indent=2, default=str)
                except (TypeError, ValueError):
                    input_str = str(item.input_params)
                lines += ["**Input:**", "", "```json", input_str, "```", ""]
            if item.output_result:
                try:
                    output_str = json.dumps(item.output_result, indent=2, default=str)
                except (TypeError, ValueError):
                    output_str = str(item.output_result)
                lines += ["**Output:**", "", "```json", output_str, "```", ""]
        elif kind == "finding":
            lines.append(f"#### Finding: {item.title}")
            lines.append(f"**Severity**: {item.severity.value}  **Type**: {item.finding_type.value}")
            if item.description:
                lines += ["", item.description]
            lines.append("")

    # Error details
    if session.error_message:
        lines += [
            "---",
            "",
            "## Error",
            "",
            f"**Message**: {session.error_message}",
        ]
        if session.error_details:
            lines += ["", "```", session.error_details, "```"]
        lines.append("")

    return "\n".join(lines)
