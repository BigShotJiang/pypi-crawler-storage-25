import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.schemas import MemoryCreate, MemoryOut, MemoryUpdate, PaginatedResponse
from opspilot.services import memory_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/memories", tags=["memories"])


@router.get("", response_model=PaginatedResponse[MemoryOut])
async def list_memories(
    q: str | None = None,
    keyword: str | None = None,
    entity_type: str | None = None,
    entity_key: str | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if q or keyword:
        items = await memory_service.list_memories(
            db, project_id, entity_type=entity_type, entity_key=entity_key,
            query=q, keyword=keyword, limit=limit, offset=offset,
        )
        return {"items": items, "total": len(items)}
    total = await memory_service.count_memories(db, project_id, entity_type=entity_type, entity_key=entity_key)
    items = await memory_service.list_memories(
        db, project_id, entity_type=entity_type, entity_key=entity_key, limit=limit, offset=offset,
    )
    return {"items": items, "total": total}


@router.get("/{memory_id}", response_model=MemoryOut)
async def get_memory(
    memory_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    memory = await memory_service.get_memory(db, project_id, memory_id)
    if not memory:
        raise HTTPException(404, "Memory not found")
    return memory


@router.post("", response_model=MemoryOut, status_code=201)
async def create_memory(
    data: MemoryCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    memory = await memory_service.create_memory(db, project_id, data)
    await db.commit()
    return memory


@router.patch("/{memory_id}", response_model=MemoryOut)
async def update_memory(
    memory_id: uuid.UUID,
    data: MemoryUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    memory = await memory_service.update_memory(db, project_id, memory_id, data)
    if not memory:
        raise HTTPException(404, "Memory not found")
    await db.commit()
    return memory


@router.delete("/{memory_id}", status_code=204)
async def delete_memory(
    memory_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    if not await memory_service.delete_memory(db, project_id, memory_id):
        raise HTTPException(404, "Memory not found")
    await db.commit()
