"""Voice transcription API endpoint.

Accepts an audio upload and returns a Server-Sent Events stream with the
transcribed text. Used by the chat frontend for voice-to-text input.
"""

import json
import logging

from fastapi import APIRouter, Form, UploadFile
from fastapi.responses import StreamingResponse

from opspilot.services.transcription import TranscriptionClient

router = APIRouter(prefix="/voice", tags=["voice"])
logger = logging.getLogger(__name__)


@router.post("/transcribe/stream")
async def transcribe_stream(
    audio: UploadFile | None = None,
    language: str | None = Form(default=None),
) -> StreamingResponse:
    """Transcribe an audio file and stream the result as SSE.

    Accepts multipart audio (webm, ogg, mp3, wav, etc.).
    Returns an SSE stream with transcription_chunk events.

    SSE events:
      event: transcription_chunk
      data: {"text": "..."}

      event: done
      data: {"status": "complete"}

      event: error
      data: {"type": "transcription_error", "message": "..."}
    """
    if audio is None:
        async def _error_gen():
            yield f"event: error\ndata: {json.dumps({'type': 'transcription_error', 'message': 'No audio file provided'})}\n\n"
        return StreamingResponse(
            _error_gen(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    audio_bytes = await audio.read()
    filename = audio.filename or "audio.webm"

    async def event_generator():
        try:
            client = TranscriptionClient()
            result = await client.transcribe(audio_bytes, language, filename)

            if result.text.strip():
                yield f"event: transcription_chunk\ndata: {json.dumps({'text': result.text})}\n\n"

            yield f"event: done\ndata: {json.dumps({'status': 'complete'})}\n\n"

        except Exception as e:
            logger.error("transcription_stream_error filename=%s error=%s", filename, e)
            yield f"event: error\ndata: {json.dumps({'type': 'transcription_error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )
