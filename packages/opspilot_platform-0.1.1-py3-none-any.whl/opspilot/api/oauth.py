import logging
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.config import settings
from opspilot.database import get_db
from opspilot.schemas import OAuthInitiateRequest, OAuthInitiateResponse
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/oauth", tags=["oauth"])


@router.post("/initiate", response_model=OAuthInitiateResponse)
async def initiate_oauth(
    body: OAuthInitiateRequest,
    db: AsyncSession = Depends(get_db),
    project_id: UUID = Depends(get_project_id_dep),
):
    if body.provider == "google":
        if not settings.google_oauth_client_id or not settings.google_oauth_client_secret:
            raise HTTPException(
                status_code=400,
                detail="Google OAuth not configured — set OPSPILOT_GOOGLE_OAUTH_CLIENT_ID and OPSPILOT_GOOGLE_OAUTH_CLIENT_SECRET",
            )
        return await oauth_service.initiate_google_oauth(db, project_id, body.redirect_to)
    elif body.provider == "slack":
        if not settings.slack_client_id or not settings.slack_client_secret:
            raise HTTPException(
                status_code=400,
                detail="Slack OAuth not configured — set OPSPILOT_SLACK_CLIENT_ID and OPSPILOT_SLACK_CLIENT_SECRET",
            )
        return await oauth_service.initiate_slack_oauth(db, project_id, body.redirect_to)
    elif body.provider == "jira":
        if not settings.jira_client_id or not settings.jira_client_secret:
            raise HTTPException(
                status_code=400,
                detail="Jira OAuth not configured — set OPSPILOT_JIRA_CLIENT_ID and OPSPILOT_JIRA_CLIENT_SECRET",
            )
        return await oauth_service.initiate_jira_oauth(db, project_id, body.redirect_to)
    elif body.provider == "confluence":
        if not settings.jira_client_id or not settings.jira_client_secret:
            raise HTTPException(
                status_code=400,
                detail="Confluence OAuth not configured — set OPSPILOT_JIRA_CLIENT_ID and OPSPILOT_JIRA_CLIENT_SECRET",
            )
        return await oauth_service.initiate_confluence_oauth(db, project_id, body.redirect_to)
    elif body.provider == "microsoft":
        if not settings.microsoft_oauth_client_id or not settings.microsoft_oauth_client_secret:
            raise HTTPException(
                status_code=400,
                detail="Microsoft OAuth not configured — set OPSPILOT_MICROSOFT_OAUTH_CLIENT_ID and OPSPILOT_MICROSOFT_OAUTH_CLIENT_SECRET",
            )
        return await oauth_service.initiate_microsoft_oauth(db, project_id, body.redirect_to)
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported provider: {body.provider}")


@router.get("/callback/google")
async def google_oauth_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Google OAuth callback — called by Google after user consent. No auth required."""
    frontend_integrations = f"{settings.frontend_url}/integrations"

    if error or not code or not state:
        reason = error or "missing_code"
        logger.warning("oauth_callback_denied reason=%s", reason)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_denied&detail={reason}")

    try:
        account = await oauth_service.handle_google_callback(db, code, state)
        return RedirectResponse(
            url=f"{frontend_integrations}?connected=google&email={account.provider_email}"
        )
    except ValueError as e:
        logger.warning("oauth_callback_failed error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")
    except Exception as e:
        logger.error("oauth_callback_error error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")


@router.get("/callback/slack")
async def slack_oauth_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Slack OAuth callback — called by Slack after user consent. No auth required."""
    frontend_integrations = f"{settings.frontend_url}/integrations"

    if error or not code or not state:
        reason = error or "missing_code"
        logger.warning("slack_oauth_callback_denied reason=%s", reason)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_denied&detail={reason}")

    try:
        account = await oauth_service.handle_slack_callback(db, code, state)
        return RedirectResponse(
            url=f"{frontend_integrations}?connected=slack&email={account.provider_email}"
        )
    except ValueError as e:
        logger.warning("slack_oauth_callback_failed error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")
    except Exception as e:
        logger.error("slack_oauth_callback_error error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")


@router.get("/callback/jira")
async def jira_oauth_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Jira OAuth callback — called by Atlassian after user consent. No auth required."""
    frontend_integrations = f"{settings.frontend_url}/integrations"

    if error or not code or not state:
        reason = error or "missing_code"
        logger.warning("jira_oauth_callback_denied reason=%s", reason)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_denied&detail={reason}")

    try:
        account = await oauth_service.handle_jira_callback(db, code, state)
        return RedirectResponse(
            url=f"{frontend_integrations}?connected=jira&email={account.provider_email}"
        )
    except ValueError as e:
        logger.warning("jira_oauth_callback_failed error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")
    except Exception as e:
        logger.error("jira_oauth_callback_error error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")


@router.get("/callback/confluence")
async def confluence_oauth_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Confluence OAuth callback — called by Atlassian after user consent. No auth required."""
    frontend_integrations = f"{settings.frontend_url}/integrations"

    if error or not code or not state:
        reason = error or "missing_code"
        logger.warning("confluence_oauth_callback_denied reason=%s", reason)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_denied&detail={reason}")

    try:
        account = await oauth_service.handle_confluence_callback(db, code, state)
        return RedirectResponse(
            url=f"{frontend_integrations}?connected=confluence&email={account.provider_email}"
        )
    except ValueError as e:
        logger.warning("confluence_oauth_callback_failed error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")
    except Exception as e:
        logger.error("confluence_oauth_callback_error error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")


@router.get("/callback/microsoft")
async def microsoft_oauth_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Microsoft OAuth callback — called by Microsoft Entra ID after user consent. No auth required."""
    frontend_integrations = f"{settings.frontend_url}/integrations"

    if error or not code or not state:
        reason = error or "missing_code"
        logger.warning("microsoft_oauth_callback_denied reason=%s description=%s", reason, error_description)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_denied&detail={reason}")

    try:
        account = await oauth_service.handle_microsoft_callback(db, code, state)
        return RedirectResponse(
            url=f"{frontend_integrations}?connected=microsoft&email={account.provider_email}"
        )
    except ValueError as e:
        logger.warning("microsoft_oauth_callback_failed error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")
    except Exception as e:
        logger.error("microsoft_oauth_callback_error error=%s", e)
        return RedirectResponse(url=f"{frontend_integrations}?error=oauth_failed")
