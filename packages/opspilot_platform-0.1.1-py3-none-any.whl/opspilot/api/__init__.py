from fastapi import APIRouter

from opspilot.api.chat import router as chat_router
from opspilot.api.files import router as files_router
from opspilot.api.memory_files import router as memory_files_router
from opspilot.api.connected_accounts import router as connected_accounts_router
from opspilot.api.reminders import router as reminders_router
from opspilot.api.todos import router as todos_router
from opspilot.api.dashboard import router as dashboard_router
from opspilot.api.findings import router as findings_router
from opspilot.api.git_repos import router as git_repos_router
from opspilot.api.incidents import router as incidents_router
from opspilot.api.mcp_servers import router as mcp_servers_router
from opspilot.api.notification_channels import router as notification_channels_router
from opspilot.api.notification_logs import router as notification_logs_router
from opspilot.api.oauth import router as oauth_router
from opspilot.api.reports import router as reports_router
from opspilot.api.sessions import router as sessions_router
from opspilot.api.settings import router as settings_router
from opspilot.api.skills import router as skills_router
from opspilot.api.task_templates import router as task_templates_router
from opspilot.api.tasks import router as tasks_router
from opspilot.api.knowledge import router as knowledge_router
from opspilot.api.memories import router as memories_router
from opspilot.api.telegram import router as telegram_router
from opspilot.api.slack import router as slack_router
from opspilot.api.voice import router as voice_router
from opspilot.api.projects import router as projects_router
from opspilot.api.approvals import router as approvals_router
from opspilot.api.artifacts import router as artifacts_router
from opspilot.api.secrets import router as secrets_router
from opspilot.api.webhooks import router as webhooks_router
from opspilot.api.whatsapp import router as whatsapp_router
from opspilot.api.runbooks import router as runbooks_router
from opspilot.api.custom_dashboards import router as custom_dashboards_router
from opspilot.api.ws import router as ws_router

api_router = APIRouter(prefix="/api")

api_router.include_router(projects_router)
api_router.include_router(dashboard_router)
api_router.include_router(task_templates_router)
api_router.include_router(tasks_router)
api_router.include_router(sessions_router)
api_router.include_router(findings_router)
api_router.include_router(reports_router)
api_router.include_router(incidents_router)
api_router.include_router(skills_router)
api_router.include_router(notification_logs_router)
api_router.include_router(mcp_servers_router)
api_router.include_router(git_repos_router)
api_router.include_router(notification_channels_router)
api_router.include_router(settings_router)
api_router.include_router(ws_router)
api_router.include_router(chat_router)
api_router.include_router(oauth_router)
api_router.include_router(connected_accounts_router)
api_router.include_router(reminders_router)
api_router.include_router(todos_router)
api_router.include_router(files_router)
api_router.include_router(memory_files_router)
api_router.include_router(knowledge_router)
api_router.include_router(memories_router)
api_router.include_router(voice_router)
api_router.include_router(telegram_router)
api_router.include_router(slack_router)
api_router.include_router(artifacts_router)
api_router.include_router(secrets_router)
api_router.include_router(whatsapp_router)
api_router.include_router(runbooks_router)
api_router.include_router(webhooks_router)
api_router.include_router(approvals_router)
api_router.include_router(custom_dashboards_router)
