import uuid
import logging
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, Header
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
import redis

from opspilot.application.tasks_service import CeleryTaskRunner, TasksService
from opspilot.database import get_db
from opspilot.infrastructure.repos.task_repo import SqlaTaskRepository
from opspilot.models import Session
from opspilot.schemas import TaskCreate, TaskListOut, TaskOut, TaskStatsOut, TaskTriggerResponse, TaskUpdate, PaginatedResponse
from opspilot.schemas.tasks import TaskBulkDeleteRequest, TaskBulkDeleteResponse
from opspilot.services.idempotency_service import IdempotencyService
from opspilot.config import settings

router = APIRouter(prefix="/tasks", tags=["tasks"])
logger = logging.getLogger(__name__)


def get_tasks_service(db: AsyncSession = Depends(get_db)) -> TasksService:
    """FastAPI dependency that wires the service with its SQLAlchemy repo and Celery runner."""
    return TasksService(repo=SqlaTaskRepository(db), runner=CeleryTaskRunner())


def get_idempotency_service() -> IdempotencyService:
    """Provides an IdempotencyService instance."""
    client = redis.from_url(settings.redis_url)
    return IdempotencyService(client)


@router.get("/stats", response_model=TaskStatsOut)
async def get_task_stats(service: TasksService = Depends(get_tasks_service)):
    logger.debug("get_task_stats")
    return await service.get_stats()


@router.get("", response_model=PaginatedResponse[TaskListOut])
async def list_tasks(
    search: str | None = None,
    agent_type: str | None = None,
    enabled: bool | None = None,
    sort: str = "created_desc",
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    limit: int = Query(25, le=200),
    offset: int = 0,
    service: TasksService = Depends(get_tasks_service),
    db: AsyncSession = Depends(get_db),
):
    logger.debug("list_tasks search=%s agent_type=%s enabled=%s sort=%s limit=%s offset=%s", search, agent_type, enabled, sort, limit, offset)
    tasks, total = await service.list_tasks(
        enabled=enabled, agent_type=agent_type, search=search,
        sort=sort, created_after=created_after, created_before=created_before,
        limit=limit, offset=offset,
    )

    # Batch-fetch session counts for all returned tasks
    count_map: dict[uuid.UUID, int] = {}
    if tasks:
        task_ids = [t.id for t in tasks]
        counts_result = await db.execute(
            select(Session.task_id, func.count(Session.id).label("cnt"))
            .where(Session.task_id.in_(task_ids))
            .group_by(Session.task_id)
        )
        count_map = {row.task_id: row.cnt for row in counts_result.fetchall()}

    items = [
        TaskListOut.model_validate(t).model_copy(update={"session_count": count_map.get(t.id, 0)})
        for t in tasks
    ]
    return {"items": items, "total": total}


@router.post("/bulk-delete", response_model=TaskBulkDeleteResponse)
async def bulk_delete_tasks(data: TaskBulkDeleteRequest, service: TasksService = Depends(get_tasks_service)):
    logger.info("bulk_delete_tasks count=%s", len(data.file_ids))
    deleted, failed = await service.bulk_delete_tasks(data.file_ids)
    return {"deleted_count": deleted, "failed_ids": failed}


@router.get("/{task_id}", response_model=TaskOut)
async def get_task(task_id: uuid.UUID, service: TasksService = Depends(get_tasks_service)):
    logger.debug("get_task task_id=%s", task_id)
    try:
        return await service.get_task(task_id)
    except KeyError:
        logger.info("task_not_found task_id=%s", task_id)
        raise HTTPException(404, "Task not found")


@router.post("", response_model=TaskOut, status_code=201)
async def create_task(data: TaskCreate, service: TasksService = Depends(get_tasks_service)):
    logger.info("create_task name=%s agent_type=%s enabled=%s", data.name, data.agent_type, data.enabled)
    return await service.create_task(data)


@router.patch("/{task_id}", response_model=TaskOut)
async def update_task(
    task_id: uuid.UUID,
    data: TaskUpdate,
    service: TasksService = Depends(get_tasks_service),
):
    logger.info("update_task task_id=%s", task_id)
    try:
        return await service.update_task(task_id, data)
    except KeyError:
        logger.info("task_not_found task_id=%s", task_id)
        raise HTTPException(404, "Task not found")


@router.delete("/{task_id}", status_code=204)
async def delete_task(task_id: uuid.UUID, service: TasksService = Depends(get_tasks_service)):
    logger.info("delete_task task_id=%s", task_id)
    try:
        await service.delete_task(task_id)
    except KeyError:
        logger.info("task_not_found task_id=%s", task_id)
        raise HTTPException(404, "Task not found")


@router.post("/{task_id}/clone", response_model=TaskOut, status_code=201)
async def clone_task(task_id: uuid.UUID, service: TasksService = Depends(get_tasks_service)):
    logger.info("clone_task task_id=%s", task_id)
    try:
        return await service.clone_task(task_id)
    except KeyError:
        logger.info("task_not_found task_id=%s", task_id)
        raise HTTPException(404, "Task not found")


@router.post("/{task_id}/trigger", response_model=TaskTriggerResponse, status_code=202)
async def trigger_task(
    task_id: uuid.UUID, 
    service: TasksService = Depends(get_tasks_service),
    idempotency_key: str | None = Header(None, alias="Idempotency-Key"),
    idem_service: IdempotencyService = Depends(get_idempotency_service),
):
    logger.info("trigger_task task_id=%s idempotency_key=%s", task_id, idempotency_key)
    
    if idempotency_key:
        # 1. Check for cached response
        is_dup, cached = await idem_service.get_cached_response(idempotency_key)
        if is_dup:
            return cached
        
        # 2. Try to reserve the key (prevent concurrent identical requests)
        if not await idem_service.reserve_key(idempotency_key):
            # Another request is already processing this key
            raise HTTPException(status_code=409, detail="Request already in progress with this idempotency key")

    try:
        result = await service.trigger_task(task_id, idempotency_key=idempotency_key)
        
        # 3. Cache the successful result
        if idempotency_key:
            # We must convert TaskTriggerResponse to dict for caching
            result_dict = {
                "session_id": str(result.session_id),
                "message": result.message
            }
            await idem_service.cache_response(idempotency_key, result_dict)
            
        return result
    except KeyError:
        logger.info("task_not_found task_id=%s", task_id)
        if idempotency_key:
            await idem_service.release_reservation(idempotency_key)
        raise HTTPException(404, "Task not found")
    except Exception as e:
        if idempotency_key:
            await idem_service.release_reservation(idempotency_key)
        raise e
