import io
import json
import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.requests import Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from sse_starlette.sse import EventSourceResponse

from opspilot.api.deps import get_project_id_dep
from opspilot.config import settings
from opspilot.database import get_db, async_session_factory
from opspilot.models import AgentType, Conversation, ConversationMessage, ConversationToolCall, MessageRole, ToolCallStatus
from opspilot.models.artifacts import ArtifactSourceType, ArtifactTrigger
from opspilot.schemas import BulkDeleteRequest, BulkDeleteResponse, ConversationCreate, ConversationUpdate
from opspilot.schemas.artifacts import ArtifactOut
from opspilot.services import artifact_service, conversation_service
from opspilot.services.worker.chat_orchestrator import ChatOrchestrator

from opspilot.agents.domain_events import (
    AgentCompleted,
    AgentError,
    AgentStarted,
    DomainEvent,
    TextDelta,
    ThinkingDelta,
    ToolInvocationCompleted,
    ToolInvocationStarted,
)

router = APIRouter(prefix="/conversations", tags=["chat"])
logger = logging.getLogger(__name__)


def domain_event_to_sse(event: DomainEvent) -> dict:
    """Serialize DomainEvent to SSE payload."""
    if isinstance(event, AgentStarted):
        return {"event": "started", "data": json.dumps({"session_id": event.session_id, "agent_type": event.agent_type})}
    if isinstance(event, TextDelta):
        return {"event": "text_delta", "data": json.dumps({"text": event.text})}
    if isinstance(event, ThinkingDelta):
        return {"event": "thinking", "data": json.dumps({"thinking": event.thinking})}
    if isinstance(event, ToolInvocationStarted):
        return {"event": "tool_use_start", "data": json.dumps({"tool_name": event.tool_name, "tool_use_id": event.tool_use_id, "tool_server": event.tool_server, "input": event.input})}
    if isinstance(event, ToolInvocationCompleted):
        return {"event": "tool_result", "data": json.dumps({"tool_use_id": event.tool_use_id, "result": event.result, "is_error": event.is_error})}
    if isinstance(event, AgentCompleted):
        return {"event": "completed", "data": json.dumps({"usage": event.usage, "success": event.success})}
    if isinstance(event, AgentError):
        return {"event": "error", "data": json.dumps({"message": event.message, "error_type": event.error_type})}
    return {"event": "unknown", "data": json.dumps({})}


# --- Schemas ---


class MessageCreate(BaseModel):
    content: str


# --- Endpoints ---


def _conv_dict(c, message_count: int = 0, tool_call_count: int = 0) -> dict:
    return {
        "id": str(c.id),
        "title": c.title,
        "agent_type": c.agent_type.value,
        "system_prompt": c.system_prompt,
        "agent_settings": c.agent_settings,
        "pre_run_context": c.pre_run_context,
        "total_input_tokens": c.total_input_tokens,
        "total_output_tokens": c.total_output_tokens,
        "total_cost_usd": c.total_cost_usd,
        "mcp_server_ids": [str(s.id) for s in c.mcp_servers],
        "memory_file_ids": [str(mf.id) for mf in c.memory_files],
        "git_repo_ids": [str(r.id) for r in c.git_repos],
        "git_clone_results": c.git_clone_results,
        "message_count": message_count,
        "tool_call_count": tool_call_count,
        "created_at": c.created_at.isoformat(),
        "updated_at": c.updated_at.isoformat(),
    }


def _conv_opts():
    return [
        selectinload(Conversation.mcp_servers),
        selectinload(Conversation.memory_files),
        selectinload(Conversation.git_repos),
    ]


@router.get("")
async def list_conversations(
    limit: int = Query(25, le=200),
    offset: int = 0,
    agent_type: str | None = None,
    q: str | None = None,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    base_stmt = select(Conversation).where(Conversation.project_id == project_id)
    if agent_type:
        try:
            at = AgentType(agent_type)
            base_stmt = base_stmt.where(Conversation.agent_type == at)
        except ValueError:
            pass
    if q:
        base_stmt = base_stmt.where(Conversation.title.ilike(f"%{q}%"))

    count_result = await db.execute(select(func.count()).select_from(base_stmt.subquery()))
    total = count_result.scalar_one()

    msg_count_sq = (
        select(func.count())
        .where(ConversationMessage.conversation_id == Conversation.id)
        .correlate(Conversation)
        .scalar_subquery()
    )
    tool_count_sq = (
        select(func.count())
        .where(ConversationToolCall.conversation_id == Conversation.id)
        .correlate(Conversation)
        .scalar_subquery()
    )

    stmt = (
        base_stmt
        .add_columns(msg_count_sq.label("message_count"), tool_count_sq.label("tool_call_count"))
        .order_by(Conversation.updated_at.desc())
        .limit(limit)
        .offset(offset)
        .options(*_conv_opts())
    )
    result = await db.execute(stmt)
    items = [_conv_dict(c, msg_count or 0, tool_count or 0) for c, msg_count, tool_count in result.all()]
    return {"items": items, "total": total}


@router.post("", status_code=201)
async def create_conversation(
    body: ConversationCreate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    try:
        conversation = await conversation_service.create_conversation(db, project_id, body)
    except ValueError as e:
        raise HTTPException(400, str(e))

    await db.commit()

    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation.id)
        .options(*_conv_opts())
    )
    result = await db.execute(stmt)
    return _conv_dict(result.scalar_one())


@router.get("/{conversation_id}")
async def get_conversation(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.project_id == project_id)
        .options(
            selectinload(Conversation.messages),
            selectinload(Conversation.tool_calls),
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.memory_files),
            selectinload(Conversation.git_repos),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    return {
        "id": str(conversation.id),
        "title": conversation.title,
        "agent_type": conversation.agent_type.value,
        "system_prompt": conversation.system_prompt,
        "agent_settings": conversation.agent_settings,
        "pre_run_context": conversation.pre_run_context,
        "total_input_tokens": conversation.total_input_tokens,
        "total_output_tokens": conversation.total_output_tokens,
        "total_cost_usd": conversation.total_cost_usd,
        "mcp_server_ids": [str(s.id) for s in conversation.mcp_servers],
        "memory_file_ids": [str(mf.id) for mf in conversation.memory_files],
        "git_repo_ids": [str(r.id) for r in conversation.git_repos],
        "git_clone_results": conversation.git_clone_results,
        "created_at": conversation.created_at.isoformat(),
        "updated_at": conversation.updated_at.isoformat(),
        "messages": [
            {
                "id": str(m.id),
                "role": m.role.value,
                "content": m.content,
                "sequence": m.sequence,
                "turn_sequence": m.turn_sequence,
                "error_message": m.error_message,
                "error_type": m.error_type,
                "status": m.status,
                "agent_type": conversation.agent_type.value if m.role == MessageRole.ASSISTANT else None,
                "created_at": m.created_at.isoformat(),
            }
            for m in sorted(conversation.messages, key=lambda m: m.sequence)
        ],
        "tool_calls": [
            {
                "id": str(tc.id),
                "turn_sequence": tc.turn_sequence,
                "tool_name": tc.tool_name,
                "tool_server": tc.tool_server,
                "input_params": tc.input_params,
                "output_result": tc.output_result,
                "status": tc.status.value,
                "duration_ms": tc.duration_ms,
                "sequence": tc.sequence,
                "created_at": tc.created_at.isoformat(),
            }
            for tc in sorted(conversation.tool_calls, key=lambda tc: tc.sequence)
        ],
    }


@router.get("/{conversation_id}/effective-system-prompt")
async def get_effective_system_prompt(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Build and return the full effective system prompt for a conversation."""
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.project_id == project_id)
        .options(selectinload(Conversation.mcp_servers), selectinload(Conversation.git_repos))
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    effective = await _build_effective_prompt(db, conversation)
    return {"effective_system_prompt": effective}


@router.patch("/{conversation_id}")
async def update_conversation(
    conversation_id: uuid.UUID,
    body: ConversationUpdate,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    conversation = await conversation_service.update_conversation(
        db, project_id, conversation_id,
        title=body.title,
        system_prompt=body.system_prompt,
        agent_settings=body.agent_settings,
        pre_run_context=body.pre_run_context,
        mcp_server_ids=body.mcp_server_ids,
        git_repo_ids=body.git_repo_ids,
    )
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    await db.commit()
    # Refresh to get updated state
    stmt = select(Conversation).where(Conversation.id == conversation_id).options(*_conv_opts())
    res = await db.execute(stmt)
    conversation = res.scalar_one()

    return _conv_dict(conversation)


@router.delete("/{conversation_id}", status_code=204)
async def delete_conversation(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    deleted = await conversation_service.delete_conversation(db, project_id, conversation_id)
    if not deleted:
        raise HTTPException(404, "Conversation not found")
    await db.commit()


@router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_conversations(
    body: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    deleted_count = 0
    failed_ids = []
    for conv_id in body.file_ids:
        result = await db.execute(
            select(Conversation)
            .where(Conversation.id == conv_id)
            .where(Conversation.project_id == project_id)
        )
        item = result.scalar_one_or_none()
        if not item:
            failed_ids.append(str(conv_id))
            continue
        await db.delete(item)
        deleted_count += 1
    await db.commit()
    logger.info("conversations_bulk_deleted count=%d", deleted_count)
    return BulkDeleteResponse(deleted_count=deleted_count, failed_ids=failed_ids)


@router.post("/{conversation_id}/messages")
async def send_message(
    conversation_id: uuid.UUID,
    body: MessageCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """
    Send a message and receive streaming agent response.
    Following best practices from eduwise: direct streaming + atomic persistence.
    """
    if not body.content.strip():
        raise HTTPException(400, "Message content cannot be empty")
    stmt = select(Conversation).where(Conversation.id == conversation_id).where(Conversation.project_id == project_id)
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    async def event_generator():
        # Ordered list of events preserving arrival sequence.
        # Each item: {"kind": "text", "content": str}
        #          | {"kind": "tool", "tool_id": str, "tool_name": str, ...}
        events_ordered: list[dict] = []
        usage_data = {}
        agent_native_session_id = None
        error_message = None
        error_type = None
        turn_finalized = False

        async with async_session_factory() as gen_db:
            orchestrator = ChatOrchestrator(gen_db)

            try:
                async for event in orchestrator.run_chat_turn(str(conversation_id), body.content.strip()):
                    if isinstance(event, AgentStarted):
                        # The adapter emits a second AgentStarted with the native session ID.
                        # Capture it but don't forward to the frontend — a duplicate "started"
                        # resets liveTurn on the client, wiping any accumulated tool calls.
                        if event.session_id and event.session_id != str(conversation_id):
                            agent_native_session_id = event.session_id
                            continue
                    elif isinstance(event, TextDelta):
                        # Extend the last text segment or start a new one
                        if events_ordered and events_ordered[-1]["kind"] == "text":
                            events_ordered[-1]["content"] += event.text
                        else:
                            events_ordered.append({"kind": "text", "content": event.text})
                    elif isinstance(event, ToolInvocationStarted):
                        events_ordered.append({
                            "kind": "tool",
                            "tool_id": event.tool_use_id,
                            "tool_name": event.tool_name,
                            "tool_server": event.tool_server,
                            "input_params": event.input,
                            "status": "running",
                        })
                    elif isinstance(event, ToolInvocationCompleted):
                        for ev in events_ordered:
                            if ev.get("kind") == "tool" and ev.get("tool_id") == event.tool_use_id:
                                ev["is_error"] = event.is_error
                                ev["status"] = event.status
                                ev["output_result"] = str(event.result)
                                ev["duration_ms"] = event.duration_ms
                                break
                    elif isinstance(event, AgentError):
                        error_message = event.message
                        error_type = event.error_type
                    elif isinstance(event, AgentCompleted):
                        usage_data = event.usage

                    yield domain_event_to_sse(event)

                # Finalize turn: handle both successful completion and error cases
                await orchestrator.finalize_turn(
                    conversation_id=str(conversation_id),
                    events_ordered=events_ordered,
                    agent_native_session_id=agent_native_session_id,
                    input_tokens=usage_data.get("input_tokens", 0),
                    output_tokens=usage_data.get("output_tokens", 0),
                    cost_usd=usage_data.get("cost_usd", 0.0),
                    error_message=error_message,
                    error_type=error_type,
                )
                turn_finalized = True

            except Exception as e:
                logger.exception("chat_turn_generator_failed")
                # If turn not finalized yet (error occurred before AgentCompleted/AgentError), persist the error
                if not turn_finalized:
                    try:
                        await orchestrator.finalize_turn(
                            conversation_id=str(conversation_id),
                            events_ordered=events_ordered,
                            agent_native_session_id=agent_native_session_id,
                            input_tokens=0,
                            output_tokens=0,
                            cost_usd=0.0,
                            error_message=str(e),
                            error_type="SystemError",
                        )
                    except Exception:
                        logger.exception("failed_to_finalize_error_turn")
                yield {"event": "error", "data": json.dumps({"message": str(e)})}

    return EventSourceResponse(event_generator(), ping=15)


@router.post("/{conversation_id}/cancel", status_code=204)
async def cancel_turn(conversation_id: uuid.UUID):
    """Kill the currently running agent subprocess for this conversation."""
    from opspilot.services.worker.chat_orchestrator import _active_processes
    process = _active_processes.get(str(conversation_id))
    if process and process.returncode is None:
        process.kill()
        logger.info("chat_turn_cancelled conversation_id=%s", conversation_id)


@router.post("/{conversation_id}/artifacts", response_model=ArtifactOut, status_code=201)
async def create_conversation_artifact(
    conversation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Export the conversation workspace directory as a downloadable tar.gz artifact."""
    result = await db.execute(
        select(Conversation).where(Conversation.id == conversation_id, Conversation.project_id == project_id)
    )
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    workspace_path = f"{settings.workspace_base_path}/chat-{conversation_id}"
    try:
        artifact = await artifact_service.create_artifact_from_workspace(
            db, project_id, workspace_path,
            source_type=ArtifactSourceType.CONVERSATION,
            conversation_id=conversation.id,
            trigger=ArtifactTrigger.MANUAL,
        )
        await db.commit()
        logger.info("conversation_artifact_created conversation_id=%s artifact_id=%s", conversation_id, artifact.id)
        return artifact
    except ValueError as e:
        raise HTTPException(409, str(e))


@router.get("/{conversation_id}/export")
async def export_conversation(
    conversation_id: uuid.UUID,
    format: str = Query("md", pattern="^(md|pdf)$"),
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Export conversation as Markdown or PDF."""
    stmt = (
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .where(Conversation.project_id == project_id)
        .options(
            selectinload(Conversation.messages),
            selectinload(Conversation.tool_calls),
            selectinload(Conversation.mcp_servers),
            selectinload(Conversation.git_repos),
        )
    )
    result = await db.execute(stmt)
    conversation = result.scalar_one_or_none()
    if not conversation:
        raise HTTPException(404, "Conversation not found")

    # Build effective system prompt for export
    effective_prompt = await _build_effective_prompt(db, conversation)
    md = _render_conversation_md(conversation, effective_system_prompt=effective_prompt)

    if format == "pdf":
        from weasyprint import HTML
        from opspilot.services.report_service import markdown_to_styled_html
        html_doc = markdown_to_styled_html(md, title=conversation.title or "Conversation Export")
        pdf_bytes = HTML(string=html_doc, base_url="").write_pdf()
        filename = f"conversation-{conversation_id}.pdf"
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    filename = f"conversation-{conversation_id}.md"
    return Response(
        content=md,
        media_type="text/markdown",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


async def _build_effective_prompt(db, conversation: Conversation) -> str:
    """Build the effective system prompt for export (same logic as chat_orchestrator)."""
    from opspilot.services.worker.context_builder import ContextBuilder

    ctx = ContextBuilder(db)
    global_prefix = await ctx._fetch_global_system_prompt()
    conversation_context = (
        f"## Session Context\n"
        f"You are running in a chat session. Your conversation_id is: {conversation.id}\n"
        f"There is no task session_id in chat mode — session_id is optional for all OpsPilot MCP tools.\n\n"
    )
    workspace_block = ""
    if conversation.git_clone_results:
        workspace_path = f"/tmp/opspilot/workspaces/chat-{conversation.id}"
        workspace_block = ctx._build_workspace_block(workspace_path, conversation.git_clone_results) + "\n"

    mcp_servers = [
        {"slug": s.slug, "command": s.command, "args": s.args or [], "env": s.env or {},
         "transport": s.transport, "url": s.url,
         "project_id": str(s.project_id) if s.project_id else None}
        for s in conversation.mcp_servers if s.enabled
    ]
    prc = conversation.pre_run_context or {"inject_skills": True, "injections": []}
    suffix = await ctx._build_pre_run_suffix(prc, mcp_servers, conversation=conversation)

    return global_prefix + conversation_context + workspace_block + (conversation.system_prompt or "") + suffix


def _render_conversation_md(conversation: Conversation, *, effective_system_prompt: str = "") -> str:
    """Render a conversation to Markdown for export."""
    from datetime import datetime
    lines = [
        f"# {conversation.title}",
        f"",
        f"**Agent**: {conversation.agent_type.value}  ",
        f"**Date**: {conversation.created_at.strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Tokens**: {conversation.total_input_tokens:,} in / {conversation.total_output_tokens:,} out",
        f"",
        "---",
        "",
    ]

    if effective_system_prompt:
        lines += [
            "## System Prompt",
            "",
            "```",
            effective_system_prompt.strip(),
            "```",
            "",
            "---",
            "",
        ]

    import json

    # Build interleaved timeline sorted by sequence (same approach as session export)
    timeline: list[tuple[int, str, object]] = []
    for m in conversation.messages:
        if m.role == MessageRole.SYSTEM:
            continue
        timeline.append((m.sequence, "message", m))
    for tc in conversation.tool_calls:
        timeline.append((tc.sequence, "tool_call", tc))
    timeline.sort(key=lambda x: x[0])

    for _seq, kind, item in timeline:
        if kind == "message":
            role_label = "User" if item.role == MessageRole.USER else "Assistant"
            lines += ["", f"**{role_label}**", "", item.content, ""]
        elif kind == "tool_call":
            status_icon = "\u2705" if item.status.value == "success" else "\u274c"
            server = f" ({item.tool_server})" if item.tool_server else ""
            duration = f" — {item.duration_ms}ms" if item.duration_ms else ""
            lines.append(f"#### {status_icon} `{item.tool_name}`{server}{duration}")
            lines.append("")
            if item.input_params:
                try:
                    input_str = json.dumps(item.input_params, indent=2, default=str)
                except (TypeError, ValueError):
                    input_str = str(item.input_params)
                lines += ["**Input:**", "", "```json", input_str, "```", ""]
            if item.output_result:
                lines += ["**Output:**", "", "```", item.output_result, "```", ""]

    return "\n".join(lines)
