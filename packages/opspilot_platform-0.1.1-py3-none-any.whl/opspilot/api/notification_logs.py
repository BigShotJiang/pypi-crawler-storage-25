import uuid
import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from opspilot.api.deps import get_project_id_dep
from opspilot.database import get_db
from opspilot.models import NotificationLog, ProjectSettings
from opspilot.models import NotificationChannelType
from opspilot.schemas import NotificationLogOut
from opspilot.services.notification import send_email_notification, send_pushover_notification, send_telegram_notification, send_whatsapp_notification
from opspilot.services import notification_service

router = APIRouter(prefix="/notification-logs", tags=["notification-logs"])
logger = logging.getLogger(__name__)


@router.get("", response_model=list[NotificationLogOut])
async def list_notification_logs(
    session_id: uuid.UUID | None = None,
    channel_type: NotificationChannelType | None = None,
    status: str | None = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    logger.debug(
        "list_notification_logs session_id=%s channel_type=%s status=%s limit=%s offset=%s",
        session_id, channel_type, status, limit, offset,
    )
    return await notification_service.list_notification_logs(
        db, project_id,
        session_id=session_id, channel_type=channel_type, status=status,
        limit=limit, offset=offset,
    )


class NotificationSendRequest(BaseModel):
    channel_type: str  # "slack" or "email"
    title: str
    content: str


@router.post("/send", status_code=201, response_model=NotificationLogOut)
async def send_notification_manual(
    body: NotificationSendRequest,
    db: AsyncSession = Depends(get_db),
    project_id: uuid.UUID = Depends(get_project_id_dep),
):
    """Manually send a Slack or email notification from the portal."""
    # Load project settings once for all channel types
    ps_result = await db.execute(
        select(ProjectSettings).where(ProjectSettings.project_id == project_id)
    )
    ps = ps_result.scalar_one_or_none()

    if body.channel_type == "slack":
        webhook_url = ps.slack_webhook_url if ps else None
        if not webhook_url:
            raise HTTPException(400, "No slack_webhook_url configured in Settings")

        blocks = [
            {"type": "header", "text": {"type": "plain_text", "text": body.title, "emoji": True}},
            {"type": "section", "text": {"type": "mrkdwn", "text": body.content[:3000]}},
        ]

        log = NotificationLog(
            project_id=project_id,
            session_id=None,
            channel_type=NotificationChannelType.SLACK,
            title=body.title,
            content=body.content[:5000],
            recipient=webhook_url[:100],
        )

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(webhook_url, json={"blocks": blocks}, timeout=10)
                resp.raise_for_status()
            log.status = "sent"
            logger.info("manual_slack_notification_sent title=%s", body.title)
        except Exception as e:
            log.status = "failed"
            log.error_message = str(e)[:1000]
            logger.error("manual_slack_notification_failed error=%s", str(e))

    elif body.channel_type == "email":
        recipients_str = ps.email_recipients if ps else None
        if not recipients_str:
            raise HTTPException(400, "No email_recipients configured in Settings")

        recipients = [r.strip() for r in recipients_str.split(",") if r.strip()]
        if not recipients:
            raise HTTPException(400, "No valid email recipients found in Settings")

        log = NotificationLog(
            project_id=project_id,
            session_id=None,
            channel_type=NotificationChannelType.EMAIL,
            title=body.title,
            content=body.content[:5000],
            recipient=", ".join(recipients[:5]),
        )

        smtp_config = {
            "smtp_host": ps.smtp_host if ps else None,
            "smtp_port": ps.smtp_port if ps else None,
            "smtp_username": ps.smtp_username if ps else None,
            "smtp_password": ps.smtp_password if ps else None,
            "smtp_from_email": ps.smtp_from_email if ps else None,
            "smtp_use_tls": ps.smtp_use_tls if ps else True,
        }
        finding_dict = {
            "title": body.title,
            "summary": body.content,
            "severity": "info",
            "finding_type": "recommendation",
        }
        success = send_email_notification(
            recipients=recipients,
            finding=finding_dict,
            session_id=None,
            task_name="Manual",
            smtp_config=smtp_config,
        )
        log.status = "sent" if success else "failed"
        if not success:
            log.error_message = "SMTP send failed -- check server configuration"
        logger.info("manual_email_notification_%s title=%s", log.status, body.title)

    elif body.channel_type == "pushover":
        token = ps.pushover_token if ps else None
        user = ps.pushover_user if ps else None
        if not token or not user:
            raise HTTPException(400, "pushover_token and pushover_user must be configured in Settings")

        log = NotificationLog(
            project_id=project_id,
            session_id=None,
            channel_type=NotificationChannelType.PUSHOVER,
            title=body.title,
            content=body.content[:5000],
            recipient=user[:100],
        )

        success = await send_pushover_notification(token=token, user=user, title=body.title, message=body.content)
        log.status = "sent" if success else "failed"
        if not success:
            log.error_message = "Pushover API request failed"
        logger.info("manual_pushover_notification_%s title=%s", log.status, body.title)

    elif body.channel_type == "telegram":
        bot_token = ps.telegram_bot_token if ps else None
        if not bot_token:
            raise HTTPException(400, "telegram_bot_token must be configured in Settings")

        from opspilot.models import NotificationChannel
        ch_result = await db.execute(
            select(NotificationChannel).where(
                NotificationChannel.project_id == project_id,
                NotificationChannel.channel_type == NotificationChannelType.TELEGRAM,
                NotificationChannel.enabled == True,  # noqa: E712
            ).limit(1)
        )
        channel = ch_result.scalar_one_or_none()
        if not channel:
            raise HTTPException(400, "No enabled Telegram channel configured")

        chat_id = (channel.config or {}).get("chat_id")
        if not chat_id:
            raise HTTPException(400, "Telegram channel has no chat_id in config")

        log = NotificationLog(
            project_id=project_id,
            session_id=None,
            channel_type=NotificationChannelType.TELEGRAM,
            title=body.title,
            content=body.content[:5000],
            recipient=str(chat_id),
        )

        text = f"<b>{body.title}</b>\n\n{body.content}"
        success, error_msg, _ = await send_telegram_notification(
            bot_token=bot_token, chat_id=str(chat_id), text=text,
        )
        log.status = "sent" if success else "failed"
        if not success:
            log.error_message = error_msg or "Telegram API request failed"
        logger.info("manual_telegram_notification_%s title=%s", log.status, body.title)

    elif body.channel_type == "whatsapp":
        from opspilot.models import NotificationChannel
        ch_result = await db.execute(
            select(NotificationChannel).where(
                NotificationChannel.project_id == project_id,
                NotificationChannel.channel_type == NotificationChannelType.WHATSAPP,
                NotificationChannel.enabled == True,  # noqa: E712
            ).limit(1)
        )
        channel = ch_result.scalar_one_or_none()
        if not channel:
            raise HTTPException(400, "No enabled WhatsApp channel configured")

        jid = (channel.config or {}).get("jid")
        if not jid:
            raise HTTPException(400, "WhatsApp channel has no JID in config")

        log = NotificationLog(
            project_id=project_id,
            session_id=None,
            channel_type=NotificationChannelType.WHATSAPP,
            title=body.title,
            content=body.content[:5000],
            recipient=jid,
        )

        text = f"*{body.title}*\n\n{body.content}"
        success, error_msg = await send_whatsapp_notification(jid=jid, text=text)
        log.status = "sent" if success else "failed"
        if not success:
            log.error_message = error_msg or "WhatsApp send failed"
        logger.info("manual_whatsapp_notification_%s title=%s jid=%s", log.status, body.title, jid)

    else:
        raise HTTPException(400, f"Unsupported channel_type: {body.channel_type}")

    db.add(log)
    await db.commit()
    await db.refresh(log)
    return log
