"""CLI entry point for OpsPilot server."""

import sys


def main() -> None:
    """Start the OpsPilot API server."""
    import uvicorn

    from opspilot.config import settings

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8001
    uvicorn.run("opspilot.main:app", host="0.0.0.0", port=port, log_level="info")


if __name__ == "__main__":
    main()
