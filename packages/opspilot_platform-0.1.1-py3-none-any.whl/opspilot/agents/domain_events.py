from dataclasses import dataclass, field
from typing import Any, Optional

@dataclass
class DomainEvent:
    """Base class for all agent domain events."""
    sequence: int = 0

@dataclass
class AgentStarted(DomainEvent):
    agent_type: str = ""
    session_id: str = ""

@dataclass
class TextDelta(DomainEvent):
    text: str = ""

@dataclass
class ThinkingDelta(DomainEvent):
    thinking: str = ""

@dataclass
class ToolInvocationStarted(DomainEvent):
    tool_name: str = ""
    tool_use_id: str = ""
    tool_server: Optional[str] = None
    input: dict = field(default_factory=dict)

@dataclass
class ToolInvocationCompleted(DomainEvent):
    tool_name: str = ""
    tool_use_id: str = ""
    result: Any = None
    status: str = "success"
    is_error: bool = False
    duration_ms: Optional[int] = None

@dataclass
class AgentCompleted(DomainEvent):
    usage: dict = field(default_factory=dict)
    success: bool = True

@dataclass
class AgentError(DomainEvent):
    message: str = ""
    error_type: str = "GeneralError"
