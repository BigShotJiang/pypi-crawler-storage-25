import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator

from opspilot.agents.base import AgentAdapter, AgentResult
from opspilot.agents.tool_result_analyzer import analyze_tool_result, extract_error_details
from .domain_events import (
    AgentCompleted,
    AgentError,
    AgentStarted,
    DomainEvent,
    TextDelta,
    ThinkingDelta,
    ToolInvocationCompleted,
    ToolInvocationStarted,
)

logger = logging.getLogger(__name__)


class ClaudeCodeAdapter(AgentAdapter):
    agent_type = "claude-code"

    def build_command(
        self,
        workspace_path: str,
        system_prompt: str | None,
        prompt: str,
        mcp_config_path: str | None,
        timeout_seconds: int,
        resume_session_id: str | None = None,
        is_chat: bool = False,
        agent_settings: dict | None = None,
    ) -> list[str]:
        cfg = agent_settings or {}
        model = cfg.get("model") or "claude-haiku-4-5-20251001"
        max_turns = str(cfg.get("max_turns") or 50)
        effort = cfg.get("effort")
        max_budget_usd = cfg.get("max_budget_usd")
        fallback_model = cfg.get("fallback_model")

        cmd = [
            "claude",
            "--print",
            "--output-format", "stream-json",
            "--model", model,
            "--max-turns", max_turns,
            "--verbose",
            "--dangerously-skip-permissions",
            "--strict-mcp-config",
        ]
        if effort:
            cmd.extend(["--effort", str(effort)])
        if max_budget_usd:
            cmd.extend(["--max-budget-usd", str(max_budget_usd)])
        if fallback_model:
            cmd.extend(["--fallback-model", str(fallback_model)])

        if resume_session_id:
            cmd.extend(["--resume", resume_session_id])

        if mcp_config_path:
            cmd.extend(["--mcp-config", mcp_config_path])

        # Inject system prompt on first turn only (resume already has it in history)
        if system_prompt and not resume_session_id:
            cmd.extend(["--append-system-prompt", system_prompt])

        cmd.extend(["-p", prompt])
        return cmd

    async def stream_output(self, process: asyncio.subprocess.Process) -> AsyncIterator[DomainEvent]:
        """Parse Claude Code's stream-json output format (JSONL)."""
        seq = 0

        async for raw in process.stdout:
            line = raw.decode("utf-8", errors="replace").strip()
            if not line:
                continue

            logger.debug("claude_raw pid=%s line=%s", process.pid, line)

            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            event_type = event.get("type", "")
            seq += 1

            if event_type == "system" and event.get("subtype") == "init":
                yield AgentStarted(
                    sequence=seq,
                    agent_type=self.agent_type,
                    session_id=event.get("session_id", ""),
                )

            elif event_type == "assistant":
                # Claude streams entire message state, we need to handle incremental updates
                # but for simplicity in this refactor, we'll map to deltas if we had previous state.
                # Actually, standard Claude CLI stream-json provides the full content block in each event.
                message = event.get("message", {})
                
                # Check for thinking blocks
                for block in message.get("content", []):
                    if block.get("type") == "thinking":
                        # In stream-json, thinking is often provided as a whole.
                        # We yield it as a delta for UI.
                        yield ThinkingDelta(sequence=seq, thinking=block.get("thinking", ""))

                content = self._extract_text_content(message)
                if content:
                    yield TextDelta(sequence=seq, text=content)

                # Check for tool use blocks
                for block in message.get("content", []):
                    if block.get("type") == "tool_use":
                        tool_name = block.get("name", "unknown")
                        tool_server = None
                        if tool_name.startswith("mcp__"):
                            parts = tool_name.split("__", 2)
                            if len(parts) >= 3:
                                tool_server = parts[1]

                        yield ToolInvocationStarted(
                            sequence=seq,
                            tool_name=tool_name,
                            tool_use_id=block.get("id", ""),
                            tool_server=tool_server,
                            input=block.get("input", {}),
                        )

            elif event_type == "user":
                # Tool result
                message = event.get("message", {})
                msg_content = message.get("content", []) if isinstance(message, dict) else []
                cli_result = event.get("tool_use_result", {})

                result_blocks = [
                    b for b in msg_content
                    if isinstance(b, dict) and b.get("type") == "tool_result"
                ]

                for block in (result_blocks or [{}]):
                    tool_id = block.get("tool_use_id", "") or event.get("parent_tool_use_id", "") or ""
                    is_error = block.get("is_error", False)
                    content = block.get("content", "")

                    if not content and cli_result:
                        content = cli_result.get("stdout", "")
                        if cli_result.get("stderr"):
                            content += f"\n[stderr] {cli_result.get('stderr')}"

                    output_str = ""
                    if isinstance(content, list):
                        output_str = "\n".join(item.get("text", "") for item in content if item.get("type") == "text")
                    else:
                        output_str = str(content)

                    # Check if the tool result indicates a failure even if no exception occurred
                    tool_name = event.get("tool_name", "unknown")
                    result_indicates_failure, failure_reason = analyze_tool_result(output_str, tool_name)
                    if result_indicates_failure:
                        is_error = True
                        # Prepend error details to the result so agent knows what went wrong
                        if failure_reason:
                            output_str = f"[ERROR] {failure_reason}\n\nOriginal response:\n{output_str}"

                    yield ToolInvocationCompleted(
                        sequence=seq,
                        tool_name=tool_name,
                        tool_use_id=tool_id,
                        result=output_str,
                        is_error=is_error,
                    )

            elif event_type == "result":
                usage = event.get("usage", {})
                yield AgentCompleted(
                    sequence=seq,
                    success=not event.get("is_error", False),
                    usage={
                        "input_tokens": usage.get("input_tokens", 0),
                        "output_tokens": usage.get("output_tokens", 0),
                        "cost_usd": event.get("total_cost_usd", 0.0),
                        "agent_native_session_id": event.get("session_id"),
                    }
                )

            elif event_type == "error":
                yield AgentError(
                    sequence=seq,
                    message=event.get("message", "Unknown error"),
                    error_type="ClaudeError"
                )

    def extract_result(self, events: list[DomainEvent], return_code: int) -> AgentResult:
        success = return_code == 0
        summary = ""
        input_tokens = 0
        output_tokens = 0
        cost_usd = 0.0
        agent_native_session_id = None

        for event in events:
            if isinstance(event, AgentStarted):
                agent_native_session_id = event.session_id
            elif isinstance(event, AgentCompleted):
                success = event.success
                u = event.usage
                input_tokens = u.get("input_tokens", 0)
                output_tokens = u.get("output_tokens", 0)
                cost_usd = u.get("cost_usd", 0.0)
                if u.get("agent_native_session_id"):
                    agent_native_session_id = u.get("agent_native_session_id")
            elif isinstance(event, TextDelta):
                summary = event.text # Claude stream-json yields full text usually

        return AgentResult(
            success=success,
            summary=summary[:2000],
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            cost_usd=cost_usd,
            agent_native_session_id=agent_native_session_id,
        )

    @staticmethod
    def _extract_text_content(message: dict) -> str:
        """Extract text from a Claude API message object."""
        content = message.get("content", [])
        if isinstance(content, str):
            return content
        texts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))
        return "\n".join(texts)
