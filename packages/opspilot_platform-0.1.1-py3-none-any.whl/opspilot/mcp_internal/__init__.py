import logging

from fastmcp import FastMCP

logger = logging.getLogger(__name__)

_CORE_INSTRUCTIONS = """OpsPilot Core MCP Server.

Use these tools to interact with the OpsPilot platform during your session:

**Reports**
- **create_report**: Generate a Markdown report summarizing your work for this session

**Incidents**
- **create_incident**: Create a new incident report with RCA tracking
- **search_incidents**: Search/list incidents (semantic search, keyword, severity/status filters)
- **get_incident**: Get full incident details including timeline and impact
- **update_incident**: Update an incident (status, RCA, severity, etc.)
- **delete_incident**: Delete an incident

**Findings**
- **create_finding**: Report a finding (vulnerability, anomaly, cost spike, recommendation)
- **search_findings**: Search/list findings with filters
- **get_finding**: Get full finding details

**Secrets**
- **create_secret**: Store a new encrypted secret (API key, token, credential)
- **search_secrets**: List secrets filtered by provider/environment
- **get_secret**: Get secret details by ID (includes decrypted value)
- **get_secret_by_name**: Get secret details by name
- **update_secret**: Update a secret
- **delete_secret**: Delete a secret

**Skills**
- **create_skill**: Create or update a reusable skill/runbook (upserts by name)
- **search_skills**: Search skills and runbooks
- **get_skill**: Get skill details by ID or name
- **update_skill**: Update a skill
- **delete_skill**: Delete a skill

**Todos**
- **create_todo**: Create a new todo item
- **search_todos**: Search/list todos with filters
- **get_todo**: Get full todo details
- **update_todo**: Update a todo
- **delete_todo**: Delete a todo
- **complete_todo**: Mark a todo as completed

**Storage**
- **upload_file**: Upload a local file to S3 and get its public URL
- **delete_file**: Delete a stored file by ID

**Knowledge Base**
- **create_knowledge**: Create a knowledge base entry
- **search_knowledge**: Search the knowledge base (semantic + BM25)
- **get_knowledge**: Get full knowledge entry details
- **update_knowledge**: Update a knowledge entry
- **delete_knowledge**: Delete a knowledge entry

**Agent Memories**
- **create_memory**: Store a structured fact keyed to an entity (upserts)
- **search_memories**: Search agent memories (semantic + BM25)
- **get_memory**: Get memory details
- **update_memory**: Update a memory
- **delete_memory**: Delete a memory

**Runbooks**
- **create_runbook**: Create a versioned operational runbook
- **search_runbooks**: Search runbooks (semantic + BM25)
- **get_runbook**: Get full runbook content
- **update_runbook**: Update a runbook
- **delete_runbook**: Delete a runbook

**Sessions & Conversations**
- **search_sessions**: Search agent sessions with filters
- **get_session**: Get session details and message history
- **search_conversations**: Search chat conversations
- **get_conversation**: Get conversation details and messages

**Approvals**
- **create_approval**: Request human approval before a risky action (then STOP and wait)
- **get_approval**: Check the status/decision of an approval request

**Custom Dashboards**
- **create_dashboard**: Build a custom HTML dashboard
- **search_dashboards**: List dashboards
- **get_dashboard**: Get dashboard details
- **update_dashboard**: Update dashboard content
- **delete_dashboard**: Delete a dashboard
- **screenshot_dashboard**: Capture a PNG screenshot of a dashboard

Your session_id is embedded in the connection URL and used automatically.
"""

_NOTIFY_INSTRUCTIONS = """OpsPilot Notify MCP Server.

Use these tools to send notifications and manage reminders during your session:

**Notifications**
- **send_slack_notification**: Send a Slack notification to the configured channel
- **send_email_notification**: Send an email notification to configured recipients
- **send_pushover_push**: Send a Pushover push notification
- **send_telegram_notification**: Send a Telegram notification to configured channels
- **send_whatsapp_notification**: Send a WhatsApp notification to configured numbers

**Reminders**
- **create_reminder**: Create a new reminder (immediate or scheduled, via email/slack/pushover)
- **search_reminders**: List reminders with status/date filters
- **get_reminder**: Get full reminder details
- **update_reminder**: Update a pending reminder
- **cancel_reminder**: Cancel a pending reminder
- **send_reminder_now**: Send a pending reminder immediately

Your session_id is embedded in the connection URL and used automatically.
"""

_TASKS_INSTRUCTIONS = """OpsPilot Task Automation MCP Server.

Use these tools to manage automation tasks from a chat conversation or external channel:

- **create_task**: Create a new automation task (name + prompt required; optionally set agent_type, cron_schedule, system_prompt)
- **search_tasks**: List all tasks with their status and schedule
- **get_task**: Get full details of a specific task
- **update_task**: Update any field of an existing task
- **delete_task**: Delete a task permanently
- **trigger_task**: Manually run a task immediately (returns a session_id to track progress)
- **update_task_memory**: Replace the task's accumulated memory content
"""

_GOOGLE_INSTRUCTIONS = """OpsPilot Google MCP Server.

Use these tools to interact with Google Workspace during your session:

- **gmail_list_accounts**: List all connected Gmail accounts (call this first to discover available accounts)
- **gmail_list_emails**: List emails from a connected Gmail account (supports Gmail search queries)
- **gmail_read_email**: Read the full content of a Gmail message by ID
- **gmail_get_thread**: Read all messages in a Gmail thread by thread ID
- **calendar_list_calendars**: List all calendars for connected Google account
- **calendar_list_events**: List events in a calendar with optional date filtering
- **calendar_create_event**: Create a new event in a calendar
- **calendar_update_event**: Update an existing event
- **calendar_delete_event**: Delete an event
- **calendar_get_event**: Get full details of a specific event
- **drive_list_files**: List files/folders in Google Drive
- **drive_get_file**: Get file metadata
- **drive_download_file**: Download/read file content
- **drive_create_file**: Create a new file in Google Drive from string content or a local file_path (use share_publicly=True to get a public URL)
- **drive_upload_file**: Update file content in Google Drive
- **drive_delete_file**: Delete a file from Google Drive
- **drive_share_file**: Make an existing file publicly accessible and get a shareable URL
Your session_id is embedded in the connection URL and used automatically.
"""


_CONFLUENCE_INSTRUCTIONS = """OpsPilot Confluence MCP Server.

Use these tools to interact with connected Confluence sites during your session:

- **confluence_list_accounts**: List connected Confluence sites (call this first to discover available sites)
- **confluence_list_spaces**: List spaces on the connected Confluence site
- **confluence_search**: Search content using CQL (Confluence Query Language)
- **confluence_get_page**: Get full content of a Confluence page by ID
Your session_id is embedded in the connection URL and used automatically.
"""

_JIRA_INSTRUCTIONS = """OpsPilot Jira MCP Server.

Use these tools to interact with connected Jira (Atlassian) sites during your session:

- **jira_list_accounts**: List connected Jira sites (call this first to discover available sites)
- **jira_list_projects**: List projects on the connected Jira site
- **jira_search_issues**: Search issues using JQL (Jira Query Language) queries
- **jira_get_issue**: Get full details of a Jira issue by key (e.g. "PROJ-123")
- **jira_create_issue**: Create a new Jira issue (project_key, summary, issue_type, description)
- **jira_update_issue**: Update fields on an existing Jira issue
- **jira_add_comment**: Add a comment to a Jira issue
- **jira_transition_issue**: Move an issue to a different status (e.g. "In Progress", "Done")
Your session_id is embedded in the connection URL and used automatically.
"""


def create_core_server() -> FastMCP:
    mcp = FastMCP("opspilot", instructions=_CORE_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import (
        approvals, conversations, custom_dashboards, files, findings, incidents, knowledge, memory, reports, runbook, secrets, sessions, skills, todos
    )

    reports.register(mcp)
    incidents.register(mcp)
    findings.register(mcp)
    secrets.register(mcp)
    skills.register(mcp)
    todos.register(mcp)
    files.register(mcp)
    knowledge.register(mcp)
    memory.register(mcp)
    runbook.register(mcp)
    sessions.register(mcp)
    conversations.register(mcp)
    approvals.register(mcp)
    custom_dashboards.register(mcp)

    logger.info("mcp_core_server_created")
    return mcp


def create_notify_server() -> FastMCP:
    mcp = FastMCP("opspilot-notify", instructions=_NOTIFY_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import notifications, reminders

    notifications.register(mcp)
    reminders.register(mcp)

    logger.info("mcp_notify_server_created")
    return mcp


_SLACK_INSTRUCTIONS = """OpsPilot Slack MCP Server.

Use these tools to interact with connected Slack workspaces during your session:

- **slack_list_workspaces**: List all connected Slack workspaces (call this first to discover available workspaces)
- **slack_list_channels**: List channels the bot can see in a workspace
- **slack_read_channel_history**: Read message history from a Slack channel
- **slack_read_thread**: Read all replies in a Slack thread
- **slack_get_user_info**: Get profile information for a Slack user by their ID
Your session_id is embedded in the connection URL and used automatically.
"""

_WHATSAPP_INSTRUCTIONS = """OpsPilot WhatsApp MCP Server.

Use these tools to read from the connected WhatsApp account:

- **list_whatsapp_groups**: List all groups the paired device has joined (JID, name, participant count)
- **list_whatsapp_contacts**: List contacts/groups that have messaged the bot (from stored conversations)
- **read_whatsapp_messages**: Read stored message history for a contact or group by JID
Your session_id is embedded in the connection URL and used automatically.
"""


def create_slack_server() -> FastMCP:
    mcp = FastMCP("opspilot-slack", instructions=_SLACK_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import slack

    slack.register(mcp)

    logger.info("mcp_slack_server_created")
    return mcp


def create_google_server() -> FastMCP:
    mcp = FastMCP("opspilot-google", instructions=_GOOGLE_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import calendar, drive, gmail

    gmail.register(mcp)
    calendar.register(mcp)
    drive.register(mcp)

    logger.info("mcp_google_server_created")
    return mcp


def create_whatsapp_server() -> FastMCP:
    mcp = FastMCP("opspilot-whatsapp", instructions=_WHATSAPP_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import whatsapp

    whatsapp.register(mcp)

    logger.info("mcp_whatsapp_server_created")
    return mcp


def create_confluence_server() -> FastMCP:
    mcp = FastMCP("opspilot-confluence", instructions=_CONFLUENCE_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import confluence

    confluence.register(mcp)

    logger.info("mcp_confluence_server_created")
    return mcp


def create_jira_server() -> FastMCP:
    mcp = FastMCP("opspilot-jira", instructions=_JIRA_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import jira

    jira.register(mcp)

    logger.info("mcp_jira_server_created")
    return mcp


_MICROSOFT_INSTRUCTIONS = """OpsPilot Microsoft MCP Server.

Use these tools to interact with Microsoft 365 (Outlook, Calendar, OneDrive) during your session:

- **outlook_list_accounts**: List all connected Microsoft accounts (call this first to discover available accounts)
- **outlook_list_emails**: List emails from a connected Outlook account (supports OData search queries)
- **outlook_read_email**: Read the full content of an Outlook email by ID
- **outlook_get_thread**: Read all messages in an Outlook conversation thread by conversation ID
- **ms_calendar_list_calendars**: List all calendars for connected Microsoft account
- **ms_calendar_list_events**: List events in a calendar with optional date filtering
- **ms_calendar_create_event**: Create a new event in a calendar
- **ms_calendar_update_event**: Update an existing event
- **ms_calendar_delete_event**: Delete an event
- **ms_calendar_get_event**: Get full details of a specific event
- **onedrive_list_files**: List files/folders in OneDrive (supports search)
- **onedrive_get_file**: Get file metadata
- **onedrive_download_file**: Download/read file content
- **onedrive_create_file**: Create a new file in OneDrive from string content or a local file_path
- **onedrive_delete_file**: Delete a file from OneDrive
Your session_id is embedded in the connection URL and used automatically.
"""


def create_microsoft_server() -> FastMCP:
    mcp = FastMCP("opspilot-microsoft", instructions=_MICROSOFT_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import ms_calendar, onedrive, outlook

    outlook.register(mcp)
    ms_calendar.register(mcp)
    onedrive.register(mcp)

    logger.info("mcp_microsoft_server_created")
    return mcp


def create_tasks_server() -> FastMCP:
    mcp = FastMCP("opspilot-tasks", instructions=_TASKS_INSTRUCTIONS)

    from opspilot.mcp_internal.tools import task_automation

    task_automation.register(mcp)

    logger.info("mcp_tasks_server_created")
    return mcp


def create_mcp_server() -> FastMCP:
    mcp = create_core_server()

    from opspilot.mcp_internal.tools import calendar, drive, gmail, notifications, reminders

    notifications.register(mcp)
    reminders.register(mcp)
    gmail.register(mcp)
    calendar.register(mcp)
    drive.register(mcp)

    logger.info("mcp_internal_server_created tools=33")
    return mcp
