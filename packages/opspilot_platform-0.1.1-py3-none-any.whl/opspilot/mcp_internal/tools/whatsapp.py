"""WhatsApp MCP tools — list groups, contacts, and read message history."""

import json
import logging

from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import WhatsAppConversation
from opspilot.models.conversations import ConversationMessage

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def list_whatsapp_groups() -> str:
        """List all WhatsApp groups the connected device has joined.

        Returns group JID, name, and participant count.
        Use the JID with read_whatsapp_messages to read messages from a group.
        """
        from neonize.utils.jid import Jid2String
        from opspilot.services import whatsapp_service

        adapter = whatsapp_service.get_adapter()
        if not adapter or not adapter.client:
            return json.dumps({"error": "WhatsApp adapter not running or no active session — pair a device first"})

        try:
            groups = await adapter.client.get_joined_groups()
            result = []
            for g in groups:
                result.append({
                    "jid": Jid2String(g.JID),
                    "name": g.GroupName.Name,
                    "participant_count": len(g.Participants),
                    "owner_jid": Jid2String(g.OwnerJID) if g.OwnerJID.User else None,
                })
            result.sort(key=lambda x: x["name"])
            return json.dumps({"groups": result, "count": len(result)})
        except Exception as e:
            logger.exception("list_whatsapp_groups_failed")
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def list_whatsapp_contacts() -> str:
        """List WhatsApp contacts and groups that have messaged the bot.

        Returns JID, display name, and conversation_id for each known contact.
        Use the JID with read_whatsapp_messages to read their message history.
        """
        project_id = get_project_id()
        async with async_session_factory() as db:
            rows = (await db.execute(
                select(WhatsAppConversation)
                .where(WhatsAppConversation.project_id == project_id)
                .order_by(WhatsAppConversation.created_at.desc())
            )).scalars().all()

            return json.dumps({
                "contacts": [
                    {
                        "jid": c.jid,
                        "name": c.push_name or c.jid,
                        "conversation_id": str(c.conversation_id),
                        "is_group": c.jid.endswith("@g.us"),
                    }
                    for c in rows
                ],
                "count": len(rows),
            })

    @mcp.tool()
    async def read_whatsapp_messages(
        jid: str,
        limit: int = 50,
    ) -> str:
        """Read stored message history for a WhatsApp contact or group.

        Args:
            jid: WhatsApp JID (e.g. "1234567890@s.whatsapp.net" or "group-id@g.us").
                 Get JIDs from list_whatsapp_contacts or list_whatsapp_groups.
            limit: Maximum number of messages to return (default 50, max 200).
        """
        limit = min(limit, 200)
        project_id = get_project_id()
        async with async_session_factory() as db:
            wa_conv = (await db.execute(
                select(WhatsAppConversation).where(
                    WhatsAppConversation.project_id == project_id,
                    WhatsAppConversation.jid == jid,
                )
            )).scalar_one_or_none()

            if not wa_conv:
                return json.dumps({"error": f"No conversation found for JID: {jid}. Has this contact messaged the bot?"})

            messages = (await db.execute(
                select(ConversationMessage)
                .where(ConversationMessage.conversation_id == wa_conv.conversation_id)
                .order_by(ConversationMessage.created_at.desc())
                .limit(limit)
            )).scalars().all()

            return json.dumps({
                "jid": jid,
                "name": wa_conv.push_name or jid,
                "is_group": jid.endswith("@g.us"),
                "messages": [
                    {
                        "role": m.role.value,
                        "content": m.content[:2000],
                        "created_at": m.created_at.isoformat(),
                    }
                    for m in reversed(messages)
                ],
                "count": len(messages),
            })
