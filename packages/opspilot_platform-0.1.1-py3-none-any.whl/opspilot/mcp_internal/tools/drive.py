import asyncio
import base64
import json
import logging
import uuid
from functools import partial

from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)


def _build_drive_service(access_token: str):
    """Build a Google Drive API service from a raw access token."""
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

    creds = Credentials(token=access_token)
    return build("drive", "v3", credentials=creds, cache_discovery=False)


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given account_id or first active account.

    Enforces project isolation: only accounts belonging to the current project are accessible.
    """
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            # Verify account belongs to this project
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            email_addr = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "google")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            email_addr = account.provider_email
    return token, email_addr


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def drive_list_files(
        query: str = "",
        max_results: int = 10,
        account_id: str | None = None,
    ) -> str:
        """List files/folders in Google Drive.

        Args:
            query: Drive search query (e.g. "name contains 'report'")
            max_results: Max files to return (1-100)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected. Connect one at /integrations."})

            max_results = max(1, min(100, max_results))

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            list_fn = partial(
                drive.files()
                .list(
                    q=query,
                    spaces="drive",
                    fields="files(id, name, mimeType, size, createdTime, modifiedTime, webViewLink)",
                    pageSize=max_results,
                )
                .execute
            )
            result = await loop.run_in_executor(None, list_fn)

            files = []
            for file in result.get("files", []):
                files.append({
                    "id": file.get("id"),
                    "name": file.get("name"),
                    "mime_type": file.get("mimeType"),
                    "size": file.get("size"),
                    "created_time": file.get("createdTime"),
                    "modified_time": file.get("modifiedTime"),
                    "web_link": file.get("webViewLink"),
                })

            logger.info("drive_list_files account=%s query=%s count=%d", email_addr, query or "all", len(files))
            return json.dumps({"account": email_addr, "files": files, "total": len(files)})

        except Exception as e:
            logger.error("drive_list_files_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def drive_get_file(
        file_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get Drive file metadata.

        Args:
            file_id: File ID
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            get_fn = partial(
                drive.files()
                .get(
                    fileId=file_id,
                    fields="id, name, mimeType, size, createdTime, modifiedTime, webViewLink, owners, permissions",
                )
                .execute
            )
            file = await loop.run_in_executor(None, get_fn)

            result = {
                "account": email_addr,
                "id": file.get("id"),
                "name": file.get("name"),
                "mime_type": file.get("mimeType"),
                "size": file.get("size"),
                "created_time": file.get("createdTime"),
                "modified_time": file.get("modifiedTime"),
                "web_link": file.get("webViewLink"),
                "owners": file.get("owners", []),
            }

            logger.info("drive_get_file account=%s file=%s", email_addr, file_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("drive_get_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def drive_download_file(
        file_id: str,
        account_id: str | None = None,
    ) -> str:
        """Download Drive file content. Text files as raw text; binary as base64. Max 10MB.

        Args:
            file_id: File ID
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            # Get file metadata first
            get_fn = partial(
                drive.files().get(fileId=file_id, fields="id, name, mimeType, size").execute
            )
            file_meta = await loop.run_in_executor(None, get_fn)

            # Download file
            export_fn = partial(drive.files().get_media(fileId=file_id).execute)
            content = await loop.run_in_executor(None, export_fn)

            mime_type = file_meta.get("mimeType", "")
            file_size = int(file_meta.get("size") or 0)

            # Limit file size (10 MB)
            if file_size and file_size > 10 * 1024 * 1024:
                return json.dumps({
                    "error": f"File too large ({file_size} bytes, max 10MB)",
                    "file_id": file_id,
                    "file_name": file_meta.get("name"),
                })

            # Base64 encode binary, raw text otherwise
            if mime_type.startswith("text/") or mime_type in ["application/json", "application/xml"]:
                content_str = content.decode("utf-8", errors="replace")
            else:
                content_str = base64.b64encode(content).decode()

            result = {
                "account": email_addr,
                "file_id": file_id,
                "file_name": file_meta.get("name"),
                "mime_type": mime_type,
                "size": file_size,
                "content": content_str[:50000],  # Cap to 50k chars to avoid huge responses
                "truncated": len(content_str) > 50000,
            }

            logger.info("drive_download_file account=%s file=%s size=%d", email_addr, file_id, file_size or 0)
            return json.dumps(result)

        except Exception as e:
            logger.error("drive_download_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def drive_create_file(
        name: str,
        mime_type: str = "text/plain",
        content: str = "",
        file_path: str | None = None,
        parent_id: str | None = None,
        share_publicly: bool = False,
        account_id: str | None = None,
    ) -> str:
        """Create a new file in Google Drive.

        Args:
            name: File name
            mime_type: MIME type (e.g. "text/plain", "text/html", "text/csv")
            content: File content string (for text files)
            file_path: Local path to upload (overrides content; use for binary/large files)
            parent_id: Folder ID (optional)
            share_publicly: If true, makes publicly accessible and returns public_url
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            import os
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            file_metadata = {
                "name": name,
                "mimeType": mime_type,
            }
            if parent_id:
                file_metadata["parents"] = [parent_id]

            # Read from local path or use provided content string
            if file_path:
                if not os.path.exists(file_path):
                    return json.dumps({"error": f"File not found: {file_path}"})
                with open(file_path, "rb") as f:
                    content_bytes = f.read()
                # Auto-detect mime type if not overridden
                if mime_type == "text/plain":
                    import mimetypes
                    detected, _ = mimetypes.guess_type(file_path)
                    if detected:
                        mime_type = detected
                        file_metadata["mimeType"] = mime_type
            else:
                content_bytes = content.encode("utf-8") if isinstance(content, str) else content

            from io import BytesIO
            from googleapiclient.http import MediaIoBaseUpload

            media = MediaIoBaseUpload(BytesIO(content_bytes), mimetype=mime_type)

            create_fn = partial(
                drive.files()
                .create(body=file_metadata, media_body=media, fields="id, name, webViewLink")
                .execute
            )
            result = await loop.run_in_executor(None, create_fn)
            file_id = result.get("id")

            public_url = None
            if share_publicly and file_id:
                perm_fn = partial(
                    drive.permissions()
                    .create(fileId=file_id, body={"type": "anyone", "role": "reader"})
                    .execute
                )
                await loop.run_in_executor(None, perm_fn)
                public_url = f"https://drive.google.com/file/d/{file_id}/view?usp=sharing"

            logger.info("drive_create_file account=%s file=%s public=%s", email_addr, file_id, share_publicly)
            response = {
                "account": email_addr,
                "file_id": file_id,
                "name": result.get("name"),
                "web_link": result.get("webViewLink"),
                "status": "created",
            }
            if public_url:
                response["public_url"] = public_url
                response["shared"] = True
            return json.dumps(response)

        except Exception as e:
            logger.error("drive_create_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def drive_upload_file(
        file_id: str,
        name: str | None = None,
        content: str = "",
        account_id: str | None = None,
    ) -> str:
        """Update content of an existing Drive file.

        Args:
            file_id: File ID to update
            name: New file name (optional)
            content: New file content
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            file_metadata = {}
            if name:
                file_metadata["name"] = name

            # Convert content to bytes
            if isinstance(content, str):
                content_bytes = content.encode("utf-8")
            else:
                content_bytes = content

            from io import BytesIO
            from googleapiclient.http import MediaIoBaseUpload

            # Get MIME type from existing file if not updating metadata
            get_meta_fn = partial(drive.files().get(fileId=file_id, fields="mimeType").execute)
            existing_meta = await loop.run_in_executor(None, get_meta_fn)
            upload_mime = existing_meta.get("mimeType", "text/plain")

            media = MediaIoBaseUpload(BytesIO(content_bytes), mimetype=upload_mime)

            update_fn = partial(
                drive.files()
                .update(fileId=file_id, body=file_metadata, media_body=media, fields="id, name, webViewLink")
                .execute
            )
            result = await loop.run_in_executor(None, update_fn)

            logger.info("drive_upload_file account=%s file=%s", email_addr, file_id)
            return json.dumps({
                "account": email_addr,
                "file_id": result.get("id"),
                "name": result.get("name"),
                "web_link": result.get("webViewLink"),
                "status": "updated",
            })

        except Exception as e:
            logger.error("drive_upload_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def drive_delete_file(
        file_id: str,
        account_id: str | None = None,
    ) -> str:
        """Delete a Drive file.

        Args:
            file_id: File ID to delete
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            delete_fn = partial(drive.files().delete(fileId=file_id).execute)
            await loop.run_in_executor(None, delete_fn)

            logger.info("drive_delete_file account=%s file=%s", email_addr, file_id)
            return json.dumps({
                "account": email_addr,
                "file_id": file_id,
                "status": "deleted",
            })

        except Exception as e:
            logger.error("drive_delete_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def drive_share_file(
        file_id: str,
        role: str = "reader",
        account_id: str | None = None,
    ) -> str:
        """Make a Drive file publicly accessible and return a shareable URL.

        Args:
            file_id: File ID to share
            role: "reader" (view only) or "writer" (edit)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Google account connected."})

            if role not in ("reader", "writer"):
                return json.dumps({"error": "role must be 'reader' or 'writer'"})

            loop = asyncio.get_event_loop()
            drive = _build_drive_service(access_token)

            # Get file name for response
            get_fn = partial(drive.files().get(fileId=file_id, fields="id, name, mimeType").execute)
            file_meta = await loop.run_in_executor(None, get_fn)

            # Set public permission
            perm_fn = partial(
                drive.permissions()
                .create(fileId=file_id, body={"type": "anyone", "role": role})
                .execute
            )
            await loop.run_in_executor(None, perm_fn)

            public_url = f"https://drive.google.com/file/d/{file_id}/view?usp=sharing"

            logger.info("drive_share_file account=%s file=%s role=%s", email_addr, file_id, role)
            return json.dumps({
                "account": email_addr,
                "file_id": file_id,
                "name": file_meta.get("name"),
                "role": role,
                "public_url": public_url,
                "status": "shared",
            })

        except Exception as e:
            logger.error("drive_share_file_error: %s", e)
            return json.dumps({"error": str(e)})
