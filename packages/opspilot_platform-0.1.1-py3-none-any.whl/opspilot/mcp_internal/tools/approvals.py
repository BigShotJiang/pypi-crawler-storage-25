import json
import logging
import uuid
from datetime import datetime

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.config import settings
from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.services import approval_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP):

    @mcp.tool()
    async def create_approval(
        title: str,
        description: str,
        session_id: str,
        approval_type: str = "remediation",
        entity_type: str | None = None,
        entity_id: str | None = None,
        payload: str | None = None,
        expires_at: str | None = None,
    ) -> str:
        """Request human approval before executing a risky action.

        Use this when you need to perform a potentially risky action (restart, scale,
        deploy, rollback, data mutation, config change). Create an approval request,
        then STOP and wait — do not proceed until the request is approved.

        Args:
            title: Short summary of what needs approval
            description: Full details — what you want to do, why, the risk, and the steps
            session_id: Current session ID
            approval_type: Type of approval (remediation, config_change, task_trigger, agent_hire, budget_override, custom)
            entity_type: Related entity type (e.g. "task", "incident", "finding")
            entity_id: Related entity UUID
            payload: Optional JSON string with structured data about the approval
            expires_at: Optional ISO datetime after which the approval auto-expires
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                sid = uuid.UUID(session_id)

                # Idempotency: check for existing pending approval
                existing = await approval_service.find_pending_for_session(
                    db, project_id, sid, title,
                )
                if existing:
                    approval_url = f"{settings.frontend_url}/approvals/{existing.id}"
                    return json.dumps({
                        "id": str(existing.id),
                        "status": "pending",
                        "approval_url": approval_url,
                        "message": "An identical approval request already exists. STOP HERE — do not proceed until approved.",
                    })

                parsed_entity_id = uuid.UUID(entity_id) if entity_id else None
                parsed_payload = json.loads(payload) if payload else None
                parsed_expires = datetime.fromisoformat(expires_at) if expires_at else None

                approval = await approval_service.create_and_notify(
                    db, project_id, sid, title, description,
                    approval_type=approval_type,
                    requested_by_agent_id=sid,
                    entity_type=entity_type,
                    entity_id=parsed_entity_id,
                    payload=parsed_payload,
                    expires_at=parsed_expires,
                    frontend_url=settings.frontend_url,
                )
                await db.commit()

                approval_url = f"{settings.frontend_url}/approvals/{approval.id}"
                return json.dumps({
                    "id": str(approval.id),
                    "status": "pending",
                    "approval_type": approval_type,
                    "approval_url": approval_url,
                    "message": "Approval request created and notifications sent. STOP HERE — do not proceed until approved.",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.exception("create_approval_failed")
            raise ToolError(str(e))

    @mcp.tool()
    async def get_approval(approval_id: str) -> str:
        """Check the status and decision of an approval request.

        Args:
            approval_id: UUID of the approval request to check
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                approval = await approval_service.get_approval(
                    db, project_id, uuid.UUID(approval_id),
                )
                if not approval:
                    return json.dumps({"error": "Approval not found"})

                return json.dumps({
                    "id": str(approval.id),
                    "title": approval.title,
                    "approval_type": approval.approval_type,
                    "status": approval.status.value,
                    "decided_by": approval.decided_by,
                    "decided_at": approval.decided_at.isoformat() if approval.decided_at else None,
                    "decision_note": approval.decision_note,
                    "entity_type": approval.entity_type,
                    "entity_id": str(approval.entity_id) if approval.entity_id else None,
                    "expires_at": approval.expires_at.isoformat() if approval.expires_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.exception("get_approval_failed")
            raise ToolError(str(e))
