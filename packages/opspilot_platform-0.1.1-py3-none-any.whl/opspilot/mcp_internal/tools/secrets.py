import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.schemas.secrets import SecretCreate, SecretUpdate
from opspilot.services import secret_service

logger = logging.getLogger(__name__)


def _format_secret_out(s) -> dict:
    """Format a secret model into a JSON-safe dict."""
    out = secret_service.secret_to_out_dict(s)
    out["id"] = str(out["id"])
    out["created_at"] = out["created_at"].isoformat() if out["created_at"] else None
    out["updated_at"] = out["updated_at"].isoformat() if out["updated_at"] else None
    return out


def register(mcp: FastMCP):

    @mcp.tool()
    async def create_secret(
        name: str,
        value: str,
        description: str | None = None,
        provider: str | None = None,
        environment: str | None = None,
    ) -> str:
        """Create a new encrypted project secret (API key, token, credential).

        Args:
            name: Secret name (unique within project)
            value: Secret value in plaintext (will be encrypted at rest)
            description: Optional description
            provider: Provider tag (e.g. aws, gcp, github)
            environment: Environment tag (e.g. production, staging)
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                data = SecretCreate(
                    name=name,
                    value=value,
                    description=description,
                    provider=provider,
                    environment=environment,
                )
                s = await secret_service.create_secret(db, project_id, data)
                await db.commit()
                logger.info("secret_created id=%s name=%s", s.id, s.name)
                return json.dumps({"id": str(s.id), "name": s.name})

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_secret_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_secrets(
        provider: str | None = None,
        environment: str | None = None,
        name: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> str:
        """Search project secrets. Filter by provider, environment, or name.

        Args:
            provider: Filter by provider (e.g. aws, gcp, github)
            environment: Filter by environment (e.g. production, staging)
            name: Filter by name (partial match)
            limit: Max results (default 50)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                secrets = await secret_service.list_secrets(
                    db, project_id, provider=provider, environment=environment,
                    name=name, limit=limit, offset=offset,
                )
                return json.dumps([{
                    "id": str(s.id),
                    "name": s.name,
                    "provider": s.provider,
                    "environment": s.environment,
                    "description": s.description,
                    "created_at": s.created_at.isoformat() if s.created_at else None,
                } for s in secrets])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_secrets_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_secret(secret_id: str) -> str:
        """Get full details of a secret by ID (includes decrypted value).

        Args:
            secret_id: UUID of the secret
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                s = await secret_service.get_secret(db, project_id, uuid.UUID(secret_id))
                if not s:
                    return json.dumps({"error": f"Secret {secret_id} not found"})
                return json.dumps(_format_secret_out(s))

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_secret_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_secret_by_name(name: str) -> str:
        """Get full details of a secret by name (includes decrypted value).

        Args:
            name: Secret name to look up
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                s = await secret_service.get_secret_by_name(db, project_id, name)
                if not s:
                    return json.dumps({"error": f"Secret '{name}' not found"})
                return json.dumps(_format_secret_out(s))

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_secret_by_name_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_secret(
        secret_id: str,
        name: str | None = None,
        value: str | None = None,
        description: str | None = None,
        provider: str | None = None,
        environment: str | None = None,
    ) -> str:
        """Update an existing project secret.

        Args:
            secret_id: UUID of the secret to update
            name: New name
            value: New value (will be re-encrypted)
            description: New description
            provider: New provider tag
            environment: New environment tag
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                update_fields = {}
                if name is not None:
                    update_fields["name"] = name
                if value is not None:
                    update_fields["value"] = value
                if description is not None:
                    update_fields["description"] = description
                if provider is not None:
                    update_fields["provider"] = provider
                if environment is not None:
                    update_fields["environment"] = environment
                data = SecretUpdate(**update_fields)
                s = await secret_service.update_secret(db, project_id, uuid.UUID(secret_id), data)
                if not s:
                    return json.dumps({"error": f"Secret {secret_id} not found"})
                await db.commit()
                return json.dumps({"id": str(s.id), "name": s.name, "updated": True})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_secret_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_secret(secret_id: str) -> str:
        """Delete a project secret.

        Args:
            secret_id: UUID of the secret to delete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                deleted = await secret_service.delete_secret(db, project_id, uuid.UUID(secret_id))
                if not deleted:
                    return json.dumps({"error": f"Secret {secret_id} not found"})
                await db.commit()
                return json.dumps({"deleted": True, "id": secret_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_secret_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
