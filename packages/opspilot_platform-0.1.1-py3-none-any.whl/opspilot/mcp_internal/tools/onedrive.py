import base64
import json
import logging
import uuid

import httpx
from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given account or first active Microsoft account."""
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            email_addr = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "microsoft")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            email_addr = account.provider_email
    return token, email_addr


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def onedrive_list_files(
        path: str = "/",
        query: str = "",
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """List files and folders in OneDrive.

        Args:
            path: Folder path (e.g. "/" for root, "/Documents")
            query: Search query to find files by name
            max_results: Max files to return (1-100)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected. Connect one at /integrations."})

            max_results = max(1, min(100, max_results))

            if query:
                url = f"{GRAPH_BASE}/me/drive/root/search(q='{query}')"
                params: dict[str, str | int] = {"$top": max_results}
            elif path == "/":
                url = f"{GRAPH_BASE}/me/drive/root/children"
                params = {"$top": max_results}
            else:
                clean_path = path.strip("/")
                url = f"{GRAPH_BASE}/me/drive/root:/{clean_path}:/children"
                params = {"$top": max_results}

            params["$select"] = "id,name,size,createdDateTime,lastModifiedDateTime,webUrl,file,folder"

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    url,
                    headers={"Authorization": f"Bearer {access_token}"},
                    params=params,
                    timeout=15,
                )
                resp.raise_for_status()
                data = resp.json()

            files = []
            for item in data.get("value", []):
                file_info = item.get("file", {})
                folder_info = item.get("folder")
                files.append({
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "type": "folder" if folder_info is not None else "file",
                    "mime_type": file_info.get("mimeType", ""),
                    "size": item.get("size"),
                    "created_time": item.get("createdDateTime"),
                    "modified_time": item.get("lastModifiedDateTime"),
                    "web_link": item.get("webUrl"),
                    "child_count": folder_info.get("childCount") if folder_info else None,
                })

            logger.info("onedrive_list_files account=%s path=%s count=%d", email_addr, path, len(files))
            return json.dumps({"account": email_addr, "files": files, "total": len(files)})

        except Exception as e:
            logger.error("onedrive_list_files_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_get_file(
        file_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get OneDrive file metadata.

        Args:
            file_id: File/item ID
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{GRAPH_BASE}/me/drive/items/{file_id}",
                    headers={"Authorization": f"Bearer {access_token}"},
                    params={"$select": "id,name,size,createdDateTime,lastModifiedDateTime,webUrl,file,folder,createdBy,lastModifiedBy"},
                    timeout=15,
                )
                resp.raise_for_status()
                item = resp.json()

            file_info = item.get("file", {})
            folder_info = item.get("folder")
            created_by = item.get("createdBy", {}).get("user", {})

            result = {
                "account": email_addr,
                "id": item.get("id"),
                "name": item.get("name"),
                "type": "folder" if folder_info is not None else "file",
                "mime_type": file_info.get("mimeType", ""),
                "size": item.get("size"),
                "created_time": item.get("createdDateTime"),
                "modified_time": item.get("lastModifiedDateTime"),
                "web_link": item.get("webUrl"),
                "created_by": created_by.get("displayName", ""),
            }

            logger.info("onedrive_get_file account=%s file=%s", email_addr, file_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("onedrive_get_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_download_file(
        file_id: str,
        account_id: str | None = None,
    ) -> str:
        """Download OneDrive file content. Text files as raw text; binary as base64. Max 10MB.

        Args:
            file_id: File ID
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            # Get metadata first
            async with httpx.AsyncClient() as client:
                meta_resp = await client.get(
                    f"{GRAPH_BASE}/me/drive/items/{file_id}",
                    headers={"Authorization": f"Bearer {access_token}"},
                    params={"$select": "id,name,size,file"},
                    timeout=15,
                )
                meta_resp.raise_for_status()
                meta = meta_resp.json()

            file_size = meta.get("size", 0)
            if file_size > 10 * 1024 * 1024:
                return json.dumps({
                    "error": f"File too large ({file_size} bytes, max 10MB)",
                    "file_id": file_id,
                    "file_name": meta.get("name"),
                })

            mime_type = meta.get("file", {}).get("mimeType", "")

            # Download content
            async with httpx.AsyncClient() as client:
                dl_resp = await client.get(
                    f"{GRAPH_BASE}/me/drive/items/{file_id}/content",
                    headers={"Authorization": f"Bearer {access_token}"},
                    timeout=30,
                    follow_redirects=True,
                )
                dl_resp.raise_for_status()
                content = dl_resp.content

            if mime_type.startswith("text/") or mime_type in ("application/json", "application/xml"):
                content_str = content.decode("utf-8", errors="replace")
            else:
                content_str = base64.b64encode(content).decode()

            result = {
                "account": email_addr,
                "file_id": file_id,
                "file_name": meta.get("name"),
                "mime_type": mime_type,
                "size": file_size,
                "content": content_str[:50000],
                "truncated": len(content_str) > 50000,
            }

            logger.info("onedrive_download_file account=%s file=%s size=%d", email_addr, file_id, file_size)
            return json.dumps(result)

        except Exception as e:
            logger.error("onedrive_download_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_create_file(
        name: str,
        content: str = "",
        file_path: str | None = None,
        parent_path: str = "/",
        account_id: str | None = None,
    ) -> str:
        """Create a new file in OneDrive.

        Args:
            name: File name (e.g. "report.txt")
            content: File content string (for text files)
            file_path: Local path to upload (overrides content; use for binary/large files)
            parent_path: Parent folder path (e.g. "/" for root, "/Documents")
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            import os

            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            if file_path:
                if not os.path.exists(file_path):
                    return json.dumps({"error": f"File not found: {file_path}"})
                with open(file_path, "rb") as f:
                    content_bytes = f.read()
            else:
                content_bytes = content.encode("utf-8")

            # Build upload path
            clean_parent = parent_path.strip("/")
            if clean_parent:
                url = f"{GRAPH_BASE}/me/drive/root:/{clean_parent}/{name}:/content"
            else:
                url = f"{GRAPH_BASE}/me/drive/root:/{name}:/content"

            async with httpx.AsyncClient() as client:
                resp = await client.put(
                    url,
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/octet-stream",
                    },
                    content=content_bytes,
                    timeout=30,
                )
                resp.raise_for_status()
                result = resp.json()

            logger.info("onedrive_create_file account=%s file=%s", email_addr, result.get("id"))
            return json.dumps({
                "account": email_addr,
                "file_id": result.get("id"),
                "name": result.get("name"),
                "web_link": result.get("webUrl"),
                "size": result.get("size"),
                "status": "created",
            })

        except Exception as e:
            logger.error("onedrive_create_file_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def onedrive_delete_file(
        file_id: str,
        account_id: str | None = None,
    ) -> str:
        """Delete a file from OneDrive.

        Args:
            file_id: File ID to delete
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            async with httpx.AsyncClient() as client:
                resp = await client.delete(
                    f"{GRAPH_BASE}/me/drive/items/{file_id}",
                    headers={"Authorization": f"Bearer {access_token}"},
                    timeout=15,
                )
                resp.raise_for_status()

            logger.info("onedrive_delete_file account=%s file=%s", email_addr, file_id)
            return json.dumps({
                "account": email_addr,
                "file_id": file_id,
                "status": "deleted",
            })

        except Exception as e:
            logger.error("onedrive_delete_file_error: %s", e)
            return json.dumps({"error": str(e)})
