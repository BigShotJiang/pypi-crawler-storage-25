import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.schemas.findings import RunbookCreate, RunbookUpdate
from opspilot.services import runbook_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_runbook(
        title: str,
        slug: str,
        description: str,
        content: str,
        category: str | None = None,
        tags: list[str] | None = None,
        status: str = "draft",
        version: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new operational runbook — a structured, versioned step-by-step procedure.

        Args:
            title: Runbook title
            slug: URL-safe unique identifier per project (e.g. "disk-cleanup-postgres")
            description: Short summary / when to use this runbook
            content: Full markdown procedure content
            category: Category label (e.g. "infrastructure", "monitoring", "security")
            tags: Free-form tags (e.g. ["postgres", "disk", "cleanup"])
            status: "draft" | "active" | "deprecated" (default: "draft")
            version: Version string (e.g. "1.0.0")
            session_id: Current session UUID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                data = RunbookCreate(
                    title=title,
                    slug=slug,
                    description=description,
                    content=content,
                    category=category,
                    tags=tags or [],
                    status=status,
                    version=version,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                rb = await runbook_service.create_runbook(db, project_id, data)
                await db.commit()
                logger.info("runbook_created id=%s slug=%s", rb.id, rb.slug)
                return json.dumps({
                    "id": str(rb.id),
                    "title": rb.title,
                    "slug": rb.slug,
                    "status": rb.status.value,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_runbook_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_runbooks(
        status: str | None = None,
        category: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        limit: int = 20,
        offset: int = 0,
        rerank: bool = False,
    ) -> str:
        """Search operational runbooks. Supports semantic search, keyword search, and filtering.

        Args:
            status: Filter by status — "draft" | "active" | "deprecated"
            category: Filter by category (e.g. "infrastructure", "monitoring")
            query: Semantic search query
            keyword: BM25 keyword search
            limit: Max results (default 20)
            offset: Pagination offset
            rerank: Cross-encoder reranking (default false)
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                entries = await runbook_service.list_runbooks(
                    db, project_id,
                    status=status,
                    category=category,
                    query=query,
                    keyword=keyword,
                    limit=limit,
                    offset=offset,
                    rerank=rerank,
                )
                return json.dumps([
                    {
                        "id": str(rb.id),
                        "title": rb.title,
                        "slug": rb.slug,
                        "description": rb.description,
                        "category": rb.category,
                        "tags": list(rb.tags or []),
                        "status": rb.status.value,
                        "version": rb.version,
                        "updated_at": rb.updated_at.isoformat(),
                    }
                    for rb in entries
                ])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_runbooks_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_runbook(runbook_id: str) -> str:
        """Get full details and content of an operational runbook.

        Args:
            runbook_id: UUID of the runbook
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                rb = await runbook_service.get_runbook(db, project_id, uuid.UUID(runbook_id))
                if not rb:
                    return json.dumps({"error": f"Runbook not found: {runbook_id}"})
                return json.dumps({
                    "id": str(rb.id),
                    "title": rb.title,
                    "slug": rb.slug,
                    "description": rb.description,
                    "content": rb.content,
                    "category": rb.category,
                    "tags": list(rb.tags or []),
                    "status": rb.status.value,
                    "version": rb.version,
                    "session_id": str(rb.session_id) if rb.session_id else None,
                    "created_at": rb.created_at.isoformat(),
                    "updated_at": rb.updated_at.isoformat(),
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_runbook_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_runbook(
        runbook_id: str,
        title: str | None = None,
        slug: str | None = None,
        description: str | None = None,
        content: str | None = None,
        category: str | None = None,
        tags: list[str] | None = None,
        status: str | None = None,
        version: str | None = None,
    ) -> str:
        """Update an existing operational runbook.

        Args:
            runbook_id: UUID of the runbook to update
            title: New title
            slug: New slug
            description: New description
            content: New markdown content
            category: New category
            tags: New tags
            status: New status — "draft" | "active" | "deprecated"
            version: New version string
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                update_kwargs: dict = {}
                for field, val in [
                    ("title", title), ("slug", slug), ("description", description),
                    ("content", content), ("category", category), ("tags", tags),
                    ("status", status), ("version", version),
                ]:
                    if val is not None:
                        update_kwargs[field] = val
                rb = await runbook_service.update_runbook(
                    db, project_id, uuid.UUID(runbook_id), RunbookUpdate(**update_kwargs)
                )
                if not rb:
                    return json.dumps({"error": f"Runbook not found: {runbook_id}"})
                await db.commit()
                return json.dumps({"id": runbook_id, "updated_at": rb.updated_at.isoformat()})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_runbook_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_runbook(runbook_id: str) -> str:
        """Delete an operational runbook.

        Args:
            runbook_id: UUID of the runbook to delete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                deleted = await runbook_service.delete_runbook(db, project_id, uuid.UUID(runbook_id))
                if not deleted:
                    return json.dumps({"error": f"Runbook not found: {runbook_id}"})
                await db.commit()
                return json.dumps({"deleted": runbook_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_runbook_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
