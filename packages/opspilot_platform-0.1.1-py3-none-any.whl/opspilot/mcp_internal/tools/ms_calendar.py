import json
import logging
import uuid
from datetime import datetime, timedelta

import httpx
from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given account or first active Microsoft account."""
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            email_addr = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "microsoft")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            email_addr = account.provider_email
    return token, email_addr


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def ms_calendar_list_calendars(account_id: str | None = None) -> str:
        """List all calendars for the Microsoft account.

        Args:
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected. Connect one at /integrations."})

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{GRAPH_BASE}/me/calendars",
                    headers={"Authorization": f"Bearer {access_token}"},
                    params={"$select": "id,name,color,isDefaultCalendar,canEdit,owner"},
                    timeout=15,
                )
                resp.raise_for_status()
                data = resp.json()

            calendars = []
            for cal in data.get("value", []):
                owner = cal.get("owner", {})
                calendars.append({
                    "id": cal.get("id"),
                    "name": cal.get("name"),
                    "color": cal.get("color"),
                    "is_default": cal.get("isDefaultCalendar", False),
                    "can_edit": cal.get("canEdit", False),
                    "owner": owner.get("address", ""),
                })

            logger.info("ms_calendar_list_calendars account=%s count=%d", email_addr, len(calendars))
            return json.dumps({"account": email_addr, "calendars": calendars, "total": len(calendars)})

        except Exception as e:
            logger.error("ms_calendar_list_calendars_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def ms_calendar_list_events(
        calendar_id: str = "default",
        start_date: str | None = None,
        end_date: str | None = None,
        max_results: int = 10,
        account_id: str | None = None,
    ) -> str:
        """List events in a Microsoft calendar. Dates must be YYYY-MM-DD format.

        Args:
            calendar_id: Calendar ID or "default" for primary calendar
            start_date: Start date YYYY-MM-DD (defaults to today)
            end_date: End date YYYY-MM-DD (defaults to 30 days from start)
            max_results: Max events (1-250)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            max_results = max(1, min(250, max_results))

            if not start_date:
                start_date = datetime.now().date().isoformat()
            if not end_date:
                end_date = (datetime.now() + timedelta(days=30)).date().isoformat()

            # Use calendarView for expanded recurring events
            if calendar_id == "default":
                url = f"{GRAPH_BASE}/me/calendarView"
            else:
                url = f"{GRAPH_BASE}/me/calendars/{calendar_id}/calendarView"

            params = {
                "startDateTime": f"{start_date}T00:00:00Z",
                "endDateTime": f"{end_date}T23:59:59Z",
                "$top": max_results,
                "$select": "id,subject,start,end,location,attendees,bodyPreview,isAllDay,organizer",
                "$orderby": "start/dateTime",
            }

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    url,
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Prefer": 'outlook.timezone="UTC"',
                    },
                    params=params,
                    timeout=15,
                )
                resp.raise_for_status()
                data = resp.json()

            events = []
            for event in data.get("value", []):
                start = event.get("start", {})
                end = event.get("end", {})
                location = event.get("location", {})
                events.append({
                    "id": event.get("id"),
                    "summary": event.get("subject", "(no title)"),
                    "start": start.get("dateTime"),
                    "end": end.get("dateTime"),
                    "is_all_day": event.get("isAllDay", False),
                    "location": location.get("displayName", ""),
                    "attendees": [
                        {
                            "email": att.get("emailAddress", {}).get("address", ""),
                            "status": att.get("status", {}).get("response", ""),
                        }
                        for att in event.get("attendees", [])
                    ],
                    "description": event.get("bodyPreview", ""),
                })

            logger.info("ms_calendar_list_events account=%s count=%d", email_addr, len(events))
            return json.dumps({"account": email_addr, "calendar_id": calendar_id, "events": events, "total": len(events)})

        except Exception as e:
            logger.error("ms_calendar_list_events_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def ms_calendar_create_event(
        summary: str,
        start_time: str,
        end_time: str,
        description: str = "",
        location: str = "",
        attendees: list[str] | None = None,
        calendar_id: str = "default",
        account_id: str | None = None,
    ) -> str:
        """Create a new event in a Microsoft calendar.

        Args:
            summary: Event title
            start_time: Start time in RFC3339 (e.g. "2026-03-01T10:00:00Z")
            end_time: End time in RFC3339
            description: Event description
            location: Event location
            attendees: Attendee email addresses
            calendar_id: Calendar ID or "default" for primary calendar
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            event_body: dict = {
                "subject": summary,
                "start": {"dateTime": start_time, "timeZone": "UTC"},
                "end": {"dateTime": end_time, "timeZone": "UTC"},
            }
            if description:
                event_body["body"] = {"contentType": "text", "content": description}
            if location:
                event_body["location"] = {"displayName": location}
            if attendees:
                event_body["attendees"] = [
                    {"emailAddress": {"address": email}, "type": "required"}
                    for email in attendees
                ]

            if calendar_id == "default":
                url = f"{GRAPH_BASE}/me/events"
            else:
                url = f"{GRAPH_BASE}/me/calendars/{calendar_id}/events"

            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    url,
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/json",
                    },
                    json=event_body,
                    timeout=15,
                )
                resp.raise_for_status()
                result = resp.json()

            logger.info("ms_calendar_create_event account=%s event=%s", email_addr, result.get("id"))
            return json.dumps({
                "account": email_addr,
                "event_id": result.get("id"),
                "summary": result.get("subject"),
                "start": result.get("start", {}).get("dateTime"),
                "end": result.get("end", {}).get("dateTime"),
                "status": "created",
            })

        except Exception as e:
            logger.error("ms_calendar_create_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def ms_calendar_update_event(
        event_id: str,
        summary: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        description: str | None = None,
        location: str | None = None,
        account_id: str | None = None,
    ) -> str:
        """Update an existing Microsoft calendar event.

        Args:
            event_id: Event ID to update
            summary: New title
            start_time: New start time in RFC3339
            end_time: New end time in RFC3339
            description: New description
            location: New location
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            patch_body: dict = {}
            if summary is not None:
                patch_body["subject"] = summary
            if start_time is not None:
                patch_body["start"] = {"dateTime": start_time, "timeZone": "UTC"}
            if end_time is not None:
                patch_body["end"] = {"dateTime": end_time, "timeZone": "UTC"}
            if description is not None:
                patch_body["body"] = {"contentType": "text", "content": description}
            if location is not None:
                patch_body["location"] = {"displayName": location}

            async with httpx.AsyncClient() as client:
                resp = await client.patch(
                    f"{GRAPH_BASE}/me/events/{event_id}",
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/json",
                    },
                    json=patch_body,
                    timeout=15,
                )
                resp.raise_for_status()
                result = resp.json()

            logger.info("ms_calendar_update_event account=%s event=%s", email_addr, event_id)
            return json.dumps({
                "account": email_addr,
                "event_id": result.get("id"),
                "summary": result.get("subject"),
                "status": "updated",
            })

        except Exception as e:
            logger.error("ms_calendar_update_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def ms_calendar_delete_event(
        event_id: str,
        account_id: str | None = None,
    ) -> str:
        """Delete a Microsoft calendar event.

        Args:
            event_id: Event ID to delete
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            async with httpx.AsyncClient() as client:
                resp = await client.delete(
                    f"{GRAPH_BASE}/me/events/{event_id}",
                    headers={"Authorization": f"Bearer {access_token}"},
                    timeout=15,
                )
                resp.raise_for_status()

            logger.info("ms_calendar_delete_event account=%s event=%s", email_addr, event_id)
            return json.dumps({
                "account": email_addr,
                "event_id": event_id,
                "status": "deleted",
            })

        except Exception as e:
            logger.error("ms_calendar_delete_event_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def ms_calendar_get_event(
        event_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get full details of a Microsoft calendar event.

        Args:
            event_id: Event ID
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{GRAPH_BASE}/me/events/{event_id}",
                    headers={"Authorization": f"Bearer {access_token}"},
                    params={"$select": "id,subject,body,start,end,location,attendees,organizer,isAllDay,createdDateTime,lastModifiedDateTime"},
                    timeout=15,
                )
                resp.raise_for_status()
                event = resp.json()

            start = event.get("start", {})
            end = event.get("end", {})
            location = event.get("location", {})
            body = event.get("body", {})

            result = {
                "account": email_addr,
                "event_id": event.get("id"),
                "summary": event.get("subject", "(no title)"),
                "description": body.get("content", "")[:32000],
                "start": start.get("dateTime"),
                "end": end.get("dateTime"),
                "is_all_day": event.get("isAllDay", False),
                "location": location.get("displayName", ""),
                "attendees": [
                    {
                        "email": att.get("emailAddress", {}).get("address", ""),
                        "status": att.get("status", {}).get("response", ""),
                    }
                    for att in event.get("attendees", [])
                ],
                "organizer": event.get("organizer", {}).get("emailAddress", {}).get("address", ""),
                "created": event.get("createdDateTime"),
                "updated": event.get("lastModifiedDateTime"),
            }

            logger.info("ms_calendar_get_event account=%s event=%s", email_addr, event_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("ms_calendar_get_event_error: %s", e)
            return json.dumps({"error": str(e)})
