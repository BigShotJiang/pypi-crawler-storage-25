import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.services import notification_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP):
    @mcp.tool()
    async def send_slack_notification(title: str, description: str, session_id: str | None = None) -> str:
        """Send a Slack notification to the configured webhook (Block Kit: header + body).

        Args:
            title: Notification title
            description: Message body (supports Slack mrkdwn)
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                result = await notification_service.send_slack(
                    db, project_id, title, description,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                await db.commit()
                return json.dumps(result)
        except Exception as e:
            logger.error("send_slack_notification_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def send_email_notification(subject: str, body_html: str, session_id: str | None = None) -> str:
        """Send an email to configured recipients.

        Args:
            subject: Email subject
            body_html: HTML body
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                result = await notification_service.send_email(
                    db, project_id, subject, body_html,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                await db.commit()
                return json.dumps(result)
        except Exception as e:
            logger.error("send_email_notification_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def send_pushover_push(title: str, message: str, session_id: str | None = None) -> str:
        """Send a Pushover push notification to the configured device.

        Args:
            title: Notification title
            message: Message body
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                result = await notification_service.send_pushover(
                    db, project_id, title, message,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                await db.commit()
                return json.dumps(result)
        except Exception as e:
            logger.error("send_pushover_push_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def send_telegram_notification(title: str, message: str, session_id: str | None = None) -> str:
        """Send a Telegram notification. With session_id, adds a "Continue Session" inline button.

        Args:
            title: Notification title
            message: Message body
            session_id: Current session ID (enables inline resume button)
        """
        try:
            reply_markup = None
            if session_id:
                reply_markup = {
                    "inline_keyboard": [[
                        {"text": "Continue Session", "callback_data": f"continue_session:{session_id}"}
                    ]]
                }
            async with async_session_factory() as db:
                project_id = get_project_id()
                result = await notification_service.send_telegram(
                    db, project_id, title, message,
                    session_id=uuid.UUID(session_id) if session_id else None,
                    reply_markup=reply_markup,
                )
                await db.commit()
                return json.dumps(result)
        except Exception as e:
            logger.error("send_telegram_notification_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def send_whatsapp_notification(title: str, message: str, session_id: str | None = None) -> str:
        """Send a WhatsApp notification to all enabled WhatsApp notification channels.

        Args:
            title: Notification title
            message: Message body
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                result = await notification_service.send_whatsapp(
                    db, project_id, title, message,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                await db.commit()
                return json.dumps(result)
        except Exception as e:
            logger.error("send_whatsapp_notification_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
