import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.schemas.custom_dashboards import CustomDashboardUpdate
from opspilot.services import custom_dashboard_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP):

    @mcp.tool()
    async def create_dashboard(
        title: str,
        content_html: str,
        description: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new custom HTML dashboard — a fully custom status page or visualization.

        Args:
            title: Dashboard title
            content_html: Complete HTML document with inline CSS/JS
            description: What this dashboard monitors or displays
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                sid = uuid.UUID(session_id) if session_id else None
                dashboard = await custom_dashboard_service.create_custom_dashboard(
                    db, project_id,
                    title=title,
                    description=description,
                    content_html=content_html,
                    session_id=sid,
                )
                await db.commit()
                return json.dumps({
                    "id": str(dashboard.id),
                    "title": dashboard.title,
                    "public_url": dashboard.s3_url,
                    "status": "created",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_dashboard_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_dashboards(
        limit: int = 25,
        offset: int = 0,
    ) -> str:
        """List all custom dashboards for the current project.

        Args:
            limit: Max results (default 25)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                items, total = await custom_dashboard_service.list_custom_dashboards(
                    db, project_id, limit=limit, offset=offset
                )
                return json.dumps({
                    "total": total,
                    "items": [
                        {
                            "id": str(d.id),
                            "title": d.title,
                            "description": d.description,
                            "s3_url": d.s3_url,
                            "thumbnail_url": d.thumbnail_url,
                            "updated_at": d.updated_at.isoformat() if d.updated_at else None,
                        }
                        for d in items
                    ],
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_dashboards_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_dashboard(dashboard_id: str) -> str:
        """Get full details of a custom dashboard.

        Args:
            dashboard_id: UUID of the dashboard
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                dashboard = await custom_dashboard_service.get_custom_dashboard(
                    db, project_id, uuid.UUID(dashboard_id)
                )
                if not dashboard:
                    raise ToolError(f"Dashboard {dashboard_id} not found")
                return json.dumps({
                    "id": str(dashboard.id),
                    "title": dashboard.title,
                    "description": dashboard.description,
                    "s3_url": dashboard.s3_url,
                    "thumbnail_url": dashboard.thumbnail_url,
                    "created_at": dashboard.created_at.isoformat() if dashboard.created_at else None,
                    "updated_at": dashboard.updated_at.isoformat() if dashboard.updated_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_dashboard_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_dashboard(
        dashboard_id: str,
        title: str | None = None,
        description: str | None = None,
        content_html: str | None = None,
    ) -> str:
        """Update an existing custom dashboard.

        Args:
            dashboard_id: UUID of the dashboard to update
            title: New title
            description: New description
            content_html: New HTML content
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                data = CustomDashboardUpdate(
                    title=title,
                    description=description,
                    content_html=content_html,
                )
                dashboard = await custom_dashboard_service.update_custom_dashboard(
                    db, project_id, uuid.UUID(dashboard_id), data
                )
                if not dashboard:
                    raise ToolError(f"Dashboard {dashboard_id} not found")
                await db.commit()
                return json.dumps({
                    "id": str(dashboard.id),
                    "title": dashboard.title,
                    "public_url": dashboard.s3_url,
                    "status": "updated",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_dashboard_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_dashboard(dashboard_id: str) -> str:
        """Delete a custom dashboard.

        Args:
            dashboard_id: UUID of the dashboard to delete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                deleted = await custom_dashboard_service.delete_custom_dashboard(
                    db, project_id, uuid.UUID(dashboard_id)
                )
                if not deleted:
                    raise ToolError(f"Dashboard {dashboard_id} not found")
                await db.commit()
                return json.dumps({"status": "deleted", "id": dashboard_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_dashboard_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def screenshot_dashboard(dashboard_id: str) -> str:
        """Capture a PNG screenshot of a custom dashboard and store as thumbnail.

        Args:
            dashboard_id: UUID of the dashboard to screenshot
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                dashboard = await custom_dashboard_service.screenshot_custom_dashboard(
                    db, project_id, uuid.UUID(dashboard_id)
                )
                if not dashboard:
                    raise ToolError(f"Dashboard {dashboard_id} not found or has no content URL")
                await db.commit()
                return json.dumps({
                    "id": str(dashboard.id),
                    "thumbnail_url": dashboard.thumbnail_url,
                    "status": "screenshot_captured",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("screenshot_dashboard_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
