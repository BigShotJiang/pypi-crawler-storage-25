import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models.findings import IncidentStatus
from opspilot.models.common import Severity
from opspilot.schemas.findings import IncidentCreate, IncidentUpdate
from opspilot.services import incident_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP):

    @mcp.tool()
    async def create_incident(
        title: str,
        severity: str,
        summary: str,
        status: str | None = None,
        root_cause_html: str | None = None,
        impact: str | None = None,
        affected_components: list[str] | None = None,
        timeline: list[dict] | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new incident report with root cause analysis tracking.

        Args:
            title: Incident title
            severity: info/low/medium/high/critical
            summary: Detailed summary of the incident
            status: open/investigating/mitigated/resolved/closed (default: open)
            root_cause_html: Root cause analysis as HTML
            impact: Business/service impact description
            affected_components: Affected services/resources
            timeline: List of {"time": "...", "event": "..."} entries
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                data = IncidentCreate(
                    session_id=uuid.UUID(session_id) if session_id else None,
                    title=title,
                    summary=summary,
                    severity=Severity(severity),
                    status=IncidentStatus(status) if status else None,
                    root_cause_html=root_cause_html,
                    impact=impact,
                    affected_components=affected_components,
                    timeline=timeline,
                )
                inc = await incident_service.create_incident(db, project_id, data)
                await db.commit()
                logger.info("incident_created id=%s severity=%s", inc.id, severity)
                return json.dumps({
                    "id": str(inc.id), "title": inc.title,
                    "severity": severity, "status": inc.status.value,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_incident_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_incidents(
        severity: str | None = None,
        status: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        limit: int = 50,
        offset: int = 0,
        rerank: bool = False,
    ) -> str:
        """Search incidents. Supports semantic search, keyword search, and filtering by severity/status.

        Args:
            severity: Filter by severity — info/low/medium/high/critical
            status: Filter by status — open/investigating/mitigated/resolved/closed
            query: Semantic search query
            keyword: BM25 keyword search
            limit: Max results (default 50)
            offset: Pagination offset
            rerank: Cross-encoder reranking (default false)
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                if not project_id:
                    return json.dumps({"error": "No project context. Cannot search incidents without project scope."})

                sev = Severity(severity) if severity else None
                st = IncidentStatus(status) if status else None
                incidents = await incident_service.list_incidents(
                    db, project_id, severity=sev, status=st,
                    query=query, keyword=keyword, limit=limit, offset=offset, rerank=rerank,
                )
                return json.dumps([{
                    "id": str(i.id), "title": i.title,
                    "severity": i.severity.value, "status": i.status.value,
                    "created_at": i.created_at.isoformat() if i.created_at else None,
                } for i in incidents])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_incidents_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_incident(incident_id: str) -> str:
        """Get full details of an incident including RCA, timeline, and impact.

        Args:
            incident_id: UUID of the incident
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                inc = await incident_service.get_incident(db, project_id, uuid.UUID(incident_id))
                if not inc:
                    return json.dumps({"error": f"Incident {incident_id} not found"})
                return json.dumps({
                    "id": str(inc.id), "title": inc.title,
                    "severity": inc.severity.value, "status": inc.status.value,
                    "summary": inc.summary, "root_cause_html": inc.root_cause_html,
                    "impact": inc.impact, "affected_components": inc.affected_components,
                    "timeline": inc.timeline,
                    "created_at": inc.created_at.isoformat() if inc.created_at else None,
                    "resolved_at": inc.resolved_at.isoformat() if inc.resolved_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_incident_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_incident(
        incident_id: str,
        title: str | None = None,
        severity: str | None = None,
        status: str | None = None,
        summary: str | None = None,
        root_cause_html: str | None = None,
        impact: str | None = None,
        affected_components: list[str] | None = None,
        timeline: list[dict] | None = None,
    ) -> str:
        """Update an existing incident report.

        Args:
            incident_id: UUID of the incident to update
            title: New title
            severity: New severity — info/low/medium/high/critical
            status: New status — open/investigating/mitigated/resolved/closed
            summary: New summary
            root_cause_html: New root cause analysis as HTML
            impact: New impact description
            affected_components: New affected components
            timeline: New timeline entries
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                update_kwargs = {}
                if title:
                    update_kwargs["title"] = title
                if severity:
                    update_kwargs["severity"] = Severity(severity)
                if status:
                    update_kwargs["status"] = IncidentStatus(status)
                if summary:
                    update_kwargs["summary"] = summary
                if root_cause_html is not None:
                    update_kwargs["root_cause_html"] = root_cause_html
                if impact is not None:
                    update_kwargs["impact"] = impact
                if affected_components is not None:
                    update_kwargs["affected_components"] = affected_components
                if timeline is not None:
                    update_kwargs["timeline"] = timeline
                inc = await incident_service.update_incident(
                    db, project_id, uuid.UUID(incident_id), IncidentUpdate(**update_kwargs)
                )
                if not inc:
                    return json.dumps({"error": f"Incident {incident_id} not found"})
                await db.commit()
                logger.info("incident_updated id=%s", incident_id)
                return json.dumps({"id": str(inc.id), "title": inc.title, "status": inc.status.value})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_incident_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_incident(incident_id: str) -> str:
        """Delete an incident report.

        Args:
            incident_id: UUID of the incident to delete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                deleted = await incident_service.delete_incident(db, project_id, uuid.UUID(incident_id))
                if not deleted:
                    return json.dumps({"error": f"Incident {incident_id} not found"})
                await db.commit()
                logger.info("incident_deleted id=%s", incident_id)
                return json.dumps({"deleted": incident_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_incident_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
