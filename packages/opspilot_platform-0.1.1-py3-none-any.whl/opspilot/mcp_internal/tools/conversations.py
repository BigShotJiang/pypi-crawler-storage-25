import json
import logging
import uuid
from datetime import datetime

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.services import conversation_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def search_conversations(
        updated_after: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> str:
        """Search chat conversations. Filter by last-updated date.

        Args:
            updated_after: ISO8601 datetime — only conversations updated after this time
            limit: Max results (default 20)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                if not project_id:
                    return json.dumps([])

                dt: datetime | None = None
                if updated_after:
                    try:
                        dt = datetime.fromisoformat(updated_after.replace("Z", "+00:00"))
                    except ValueError:
                        return json.dumps({"error": f"Invalid updated_after: {updated_after!r} — use ISO8601"})

                rows = await conversation_service.list_conversations(
                    db, project_id,
                    updated_after=dt,
                    limit=limit,
                    offset=offset,
                )
                return json.dumps([
                    {
                        "id": str(c.id),
                        "title": c.title,
                        "agent_type": c.agent_type.value if hasattr(c.agent_type, "value") else str(c.agent_type),
                        "updated_at": c.updated_at.isoformat(),
                        "created_at": c.created_at.isoformat(),
                    }
                    for c in rows
                ])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_conversations_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_conversation(conversation_id: str) -> str:
        """Get full details and message history for a chat conversation.

        Args:
            conversation_id: UUID of the conversation to retrieve
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                result = await conversation_service.get_conversation_with_messages(
                    db, project_id, uuid.UUID(conversation_id),
                )
                if not result:
                    return json.dumps({"error": f"Conversation not found: {conversation_id}"})
                return json.dumps(result)

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_conversation_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
