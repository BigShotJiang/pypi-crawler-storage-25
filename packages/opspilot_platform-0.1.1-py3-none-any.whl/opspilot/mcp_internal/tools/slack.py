"""Slack MCP tools — list channels, read messages, threads, and user info."""

import json
import logging
import re
import uuid

import httpx
from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

SLACK_API = "https://slack.com/api"
_UID_RE = re.compile(r"<@([A-Z0-9]+)>")
_user_cache: dict[str, str] = {}  # uid → display name, process-level cache


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (token, workspace_name) for the given account_id or first active Slack account.

    Prefers the user token (xoxp-) for silent read access. Falls back to bot token.
    Enforces project isolation: only accounts belonging to the current project are accessible.
    """
    from opspilot.services.oauth_service import decrypt_token

    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "slack")
            if not account:
                return "", ""

        workspace = account.provider_email
        # Prefer user token (xoxp-) — reads channels silently without bot presence
        if account.user_access_token:
            token = decrypt_token(account.user_access_token)
        else:
            token = await oauth_service.get_valid_access_token(db, account.id)

    return token, workspace


async def _slack_get(token: str, method: str, params: dict | None = None) -> dict:
    """Call a Slack Web API method via GET."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{SLACK_API}/{method}",
            headers={"Authorization": f"Bearer {token}"},
            params=params or {},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    if not data.get("ok"):
        raise ValueError(f"Slack API error: {data.get('error', 'unknown')}")
    return data


async def _resolve_mentions(token: str, messages: list[dict]) -> list[dict]:
    """Replace <@UID> tokens in message text with '@DisplayName'."""
    # Collect all unique UIDs — from @mentions in text AND sender user fields
    uids = {m for msg in messages for m in _UID_RE.findall(msg.get("text", ""))}
    uids |= {msg["user"] for msg in messages if msg.get("user")}
    if not uids:
        return messages

    # Resolve UIDs — use cache first, fetch only unknowns (Tier 4, high rate limit)
    uid_to_name: dict[str, str] = {}
    uncached = uids - _user_cache.keys()
    async with httpx.AsyncClient() as client:
        for uid in uncached:
            try:
                resp = await client.get(
                    f"{SLACK_API}/users.info",
                    headers={"Authorization": f"Bearer {token}"},
                    params={"user": uid},
                    timeout=10,
                )
                data = resp.json()
                if data.get("ok"):
                    user = data["user"]
                    name = user.get("profile", {}).get("display_name") or user.get("real_name") or user.get("name", uid)
                    _user_cache[uid] = name
            except Exception:
                pass  # Leave unresolved UIDs as-is
    uid_to_name = {uid: _user_cache.get(uid, uid) for uid in uids}

    def _replace(text: str) -> str:
        return _UID_RE.sub(lambda m: f"@{uid_to_name.get(m.group(1), m.group(1))}", text)

    return [
        {**msg, "text": _replace(msg.get("text", "")), "user": uid_to_name.get(msg.get("user", ""), msg.get("user", ""))}
        for msg in messages
    ]


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def slack_list_workspaces() -> str:
        """List connected Slack workspaces. Call this first before using other Slack tools.

        Pass the returned account_id to target a specific workspace.
        """
        project_id = get_project_id()
        async with async_session_factory() as db:
            result = await db.execute(
                select(ConnectedAccount)
                .where(
                    ConnectedAccount.project_id == project_id,
                    ConnectedAccount.provider == "slack",
                )
                .order_by(ConnectedAccount.created_at)
            )
            accounts = result.scalars().all()

        if not accounts:
            return json.dumps({"workspaces": [], "message": "No Slack workspaces connected. Visit /integrations to connect one."})

        return json.dumps({
            "workspaces": [
                {
                    "account_id": str(a.id),
                    "workspace": a.provider_email,
                    "team_id": a.provider_account_id,
                    "label": a.label,
                    "status": a.status,
                    "default": i == 0,
                }
                for i, a in enumerate(accounts)
            ],
            "note": "Pass account_id to other slack tools to target a specific workspace. The first workspace is used by default.",
        })

    @mcp.tool()
    async def slack_list_channels(
        types: str = "public_channel,private_channel",
        limit: int = 100,
        account_id: str | None = None,
    ) -> str:
        """List Slack channels the bot can see.

        Args:
            types: Channel types: public_channel, private_channel, mpim, im
            limit: Max channels (1-1000)
            account_id: Target workspace UUID; uses first active if omitted.
        """
        try:
            token, workspace = await _resolve_account(account_id)
            if not token:
                return json.dumps({"error": "No active Slack workspace connected. Connect one at /integrations."})

            limit = max(1, min(1000, limit))
            data = await _slack_get(token, "conversations.list", {
                "types": types,
                "limit": limit,
                "exclude_archived": "true",
            })

            channels = []
            for ch in data.get("channels", []):
                channels.append({
                    "id": ch["id"],
                    "name": ch.get("name", ""),
                    "is_private": ch.get("is_private", False),
                    "is_member": ch.get("is_member", False),
                    "num_members": ch.get("num_members", 0),
                    "topic": (ch.get("topic") or {}).get("value", ""),
                    "purpose": (ch.get("purpose") or {}).get("value", ""),
                })

            logger.info("slack_list_channels workspace=%s count=%d", workspace, len(channels))
            return json.dumps({"workspace": workspace, "channels": channels, "total": len(channels)})

        except Exception as e:
            logger.error("slack_list_channels_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def slack_read_channel_history(
        channel: str,
        limit: int = 20,
        oldest: str | None = None,
        latest: str | None = None,
        account_id: str | None = None,
    ) -> str:
        """Read message history from a Slack channel.

        Args:
            channel: Channel ID from slack_list_channels (e.g. "C123456")
            limit: Messages to return (1-100)
            oldest: Only messages after this Unix timestamp
            latest: Only messages before this Unix timestamp
            account_id: Target workspace UUID; uses first active if omitted.
        """
        try:
            token, workspace = await _resolve_account(account_id)
            if not token:
                return json.dumps({"error": "No active Slack workspace connected."})

            limit = max(1, min(100, limit))
            params: dict = {"channel": channel, "limit": limit}
            if oldest:
                params["oldest"] = oldest
            if latest:
                params["latest"] = latest

            data = await _slack_get(token, "conversations.history", params)

            messages = []
            for msg in data.get("messages", []):
                messages.append({
                    "ts": msg.get("ts"),
                    "user": msg.get("user"),
                    "text": msg.get("text", ""),
                    "type": msg.get("type"),
                    "subtype": msg.get("subtype"),
                    "thread_ts": msg.get("thread_ts"),
                    "reply_count": msg.get("reply_count", 0),
                })

            messages = await _resolve_mentions(token, messages)
            logger.info("slack_read_channel_history workspace=%s channel=%s count=%d", workspace, channel, len(messages))
            return json.dumps({
                "workspace": workspace,
                "channel": channel,
                "messages": messages,
                "has_more": data.get("has_more", False),
            })

        except Exception as e:
            logger.error("slack_read_channel_history_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def slack_read_thread(
        channel: str,
        thread_ts: str,
        limit: int = 50,
        account_id: str | None = None,
    ) -> str:
        """Read all replies in a Slack thread.

        Args:
            channel: Channel ID
            thread_ts: Parent message timestamp from slack_read_channel_history
            limit: Max replies (1-200)
            account_id: Target workspace UUID; uses first active if omitted.
        """
        try:
            token, workspace = await _resolve_account(account_id)
            if not token:
                return json.dumps({"error": "No active Slack workspace connected."})

            limit = max(1, min(200, limit))
            data = await _slack_get(token, "conversations.replies", {
                "channel": channel,
                "ts": thread_ts,
                "limit": limit,
            })

            messages = []
            for msg in data.get("messages", []):
                messages.append({
                    "ts": msg.get("ts"),
                    "user": msg.get("user"),
                    "text": msg.get("text", ""),
                    "type": msg.get("type"),
                    "subtype": msg.get("subtype"),
                })

            messages = await _resolve_mentions(token, messages)
            logger.info("slack_read_thread workspace=%s channel=%s thread=%s count=%d", workspace, channel, thread_ts, len(messages))
            return json.dumps({
                "workspace": workspace,
                "channel": channel,
                "thread_ts": thread_ts,
                "messages": messages,
                "has_more": data.get("has_more", False),
            })

        except Exception as e:
            logger.error("slack_read_thread_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def slack_get_user_info(
        user_id: str,
        account_id: str | None = None,
    ) -> str:
        """Get profile information for a Slack user.

        Args:
            user_id: User ID from message fields (e.g. "U123456")
            account_id: Target workspace UUID; uses first active if omitted.
        """
        try:
            token, workspace = await _resolve_account(account_id)
            if not token:
                return json.dumps({"error": "No active Slack workspace connected."})

            data = await _slack_get(token, "users.info", {"user": user_id})

            user = data.get("user", {})
            profile = user.get("profile", {})

            logger.info("slack_get_user_info workspace=%s user=%s", workspace, user_id)
            return json.dumps({
                "workspace": workspace,
                "user": {
                    "id": user.get("id"),
                    "name": user.get("name"),
                    "real_name": user.get("real_name"),
                    "display_name": profile.get("display_name"),
                    "email": profile.get("email"),
                    "title": profile.get("title"),
                    "status_text": profile.get("status_text"),
                    "is_bot": user.get("is_bot", False),
                    "is_admin": user.get("is_admin", False),
                    "tz": user.get("tz"),
                },
            })

        except Exception as e:
            logger.error("slack_get_user_info_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def slack_get_my_mentions(
        limit: int = 20,
        include_threads: bool = True,
        hours: int | None = None,
        account_id: str | None = None,
    ) -> str:
        """Get messages where you are @mentioned, across all accessible channels.

        Args:
            limit: Max mentions (1-100)
            include_threads: Fetch full thread context for each mention (default: True)
            hours: Restrict to last N hours (e.g. 24); omit for all time
            account_id: Target workspace UUID; uses first active if omitted.
        """
        try:
            token, workspace = await _resolve_account(account_id)
            if not token:
                return json.dumps({"error": "No active Slack workspace connected."})

            limit = max(1, min(100, limit))

            # auth.test to get the authenticated user's ID
            auth_data = await _slack_get(token, "auth.test")
            my_uid = auth_data.get("user_id", "")

            # Build query — optionally restrict to last N hours via Slack's after: filter
            query = f"<@{my_uid}>"
            if hours:
                from datetime import datetime, timezone, timedelta
                cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
                query += f" after:{cutoff.strftime('%Y-%m-%d')}"

            # Search for direct @mentions using the user's own UID — most precise filter
            data = await _slack_get(token, "search.messages", {
                "query": query,
                "count": limit,
                "sort": "timestamp",
                "sort_dir": "desc",
            })

            raw_messages = data.get("messages", {}).get("matches", [])
            mentions = []
            for msg in raw_messages:
                channel = msg.get("channel", {})
                channel_id = channel.get("id", "")
                ts = msg.get("ts")
                thread_ts = msg.get("thread_ts")
                is_thread_reply = bool(thread_ts and thread_ts != ts)

                mention = {
                    "ts": ts,
                    "user": msg.get("username") or msg.get("user", ""),
                    "text": msg.get("text", ""),
                    "channel_id": channel_id,
                    "channel_name": channel.get("name", ""),
                    "thread_ts": thread_ts,
                    "is_thread_reply": is_thread_reply,
                    "permalink": msg.get("permalink", ""),
                }

                # Fetch full thread context if requested
                if include_threads and channel_id and ts:
                    # For thread replies use thread_ts; for top-level messages use ts itself
                    root_ts = thread_ts if is_thread_reply else ts
                    try:
                        thread_data = await _slack_get(token, "conversations.replies", {
                            "channel": channel_id,
                            "ts": root_ts,
                            "limit": 50,
                        })
                        thread_msgs = []
                        for tm in thread_data.get("messages", []):
                            thread_msgs.append({
                                "ts": tm.get("ts"),
                                "user": tm.get("user", ""),
                                "text": tm.get("text", ""),
                            })
                        thread_msgs = await _resolve_mentions(token, thread_msgs)
                        mention["thread"] = thread_msgs
                    except Exception:
                        mention["thread"] = []

                mentions.append(mention)

            # Resolve @mentions in the mention text itself
            mentions = await _resolve_mentions(token, mentions)

            logger.info("slack_get_my_mentions workspace=%s my_uid=%s count=%d include_threads=%s", workspace, my_uid, len(mentions), include_threads)
            return json.dumps({
                "workspace": workspace,
                "my_user_id": my_uid,
                "total": len(mentions),
                "mentions": mentions,
            })

        except Exception as e:
            logger.error("slack_get_my_mentions_error: %s", e)
            return json.dumps({"error": str(e)})
