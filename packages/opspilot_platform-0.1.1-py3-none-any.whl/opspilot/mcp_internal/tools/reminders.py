import json
import logging
import uuid
from datetime import date, datetime, timezone

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.services import reminder_service

logger = logging.getLogger(__name__)

VALID_CHANNELS = reminder_service.VALID_CHANNELS


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_reminder(
        name: str,
        description: str | None = None,
        channels: list[str] | None = None,
        scheduled_at: str | None = None,
        schedule: list[str] | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new reminder. Delivered via email, Slack, or Pushover.

        Args:
            name: Reminder title
            description: Body text
            channels: Delivery channels — ["email", "slack", "pushover"] (default: ["email"])
            scheduled_at: ISO8601 datetime for a single trigger; omit for immediate delivery
            schedule: List of ISO8601 datetimes for multiple triggers. First entry becomes scheduled_at;
                remaining entries fire in order. Example: ["2026-03-10T09:00:00Z", "2026-03-10T21:00:00Z"]
            session_id: Current session ID
        """
        try:
            effective_channels = channels or ["email"]
            invalid = set(effective_channels) - VALID_CHANNELS
            if invalid:
                return json.dumps({"error": f"Invalid channels: {list(invalid)}. Allowed: {sorted(VALID_CHANNELS)}"})

            # schedule=[t1, t2, t3] is shorthand for scheduled_at=t1 + extra_schedules=[t2, t3]
            effective_scheduled_at = scheduled_at
            extra_schedules: list[str] | None = None
            if schedule:
                if len(schedule) < 1:
                    return json.dumps({"error": "schedule must have at least one entry"})
                effective_scheduled_at = schedule[0]
                extra_schedules = schedule[1:] if len(schedule) > 1 else None

            scheduled_dt: datetime | None = None
            if effective_scheduled_at:
                try:
                    scheduled_dt = datetime.fromisoformat(effective_scheduled_at.replace("Z", "+00:00"))
                    if scheduled_dt.tzinfo is None:
                        scheduled_dt = scheduled_dt.replace(tzinfo=timezone.utc)
                except ValueError:
                    return json.dumps({"error": f"Invalid scheduled_at: {effective_scheduled_at!r}. Use ISO8601."})

            now = datetime.now(timezone.utc)
            send_now = scheduled_dt is None or scheduled_dt <= now

            async with async_session_factory() as db:
                project_id = get_project_id()
                r = await reminder_service.create_reminder(
                    db, project_id,
                    name=name,
                    description=description,
                    channels=effective_channels,
                    scheduled_at=scheduled_dt,
                    extra_schedules=extra_schedules,
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                reminder_id_str = str(r.id)
                await db.commit()

            logger.info("mcp_reminder_created id=%s name=%s send_now=%s schedule_count=%d",
                        reminder_id_str, name, send_now, len(schedule or [effective_scheduled_at or ""]))

            if send_now:
                from opspilot.worker.tasks import send_reminder
                send_reminder.delay(reminder_id_str)

            total_triggers = len(schedule) if schedule else 1
            return json.dumps({
                "reminder_id": reminder_id_str,
                "name": name,
                "channels": effective_channels,
                "scheduled_at": effective_scheduled_at,
                "extra_schedules": extra_schedules,
                "total_triggers": total_triggers,
                "status": "pending",
                "message": (
                    "Reminder queued for immediate delivery" if send_now
                    else f"Reminder scheduled for {total_triggers} trigger(s) starting {effective_scheduled_at}"
                ),
            })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_reminder_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_reminders(
        status: str | None = None,
        scheduled_date: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> str:
        """Search reminders. Filter by status or scheduled date.

        Args:
            status: Filter by status — pending/sent/failed/cancelled
            scheduled_date: Filter by date (ISO format, e.g. "2026-03-01")
            limit: Max results (default 50)
            offset: Pagination offset
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                if not project_id:
                    return json.dumps({"error": "No project context. Cannot search reminders without project scope."})

                filter_date: date | None = None
                if scheduled_date:
                    try:
                        filter_date = date.fromisoformat(scheduled_date)
                    except ValueError:
                        return json.dumps({"error": f"Invalid scheduled_date: {scheduled_date!r}. Use ISO date format e.g. '2026-02-28'."})

                reminders = await reminder_service.list_reminders(
                    db, project_id,
                    status=status,
                    scheduled_date=filter_date,
                )
                return json.dumps([{
                    "reminder_id": str(r.id),
                    "name": r.name,
                    "channels": r.channels,
                    "status": r.status,
                    "scheduled_at": r.scheduled_at.isoformat() if r.scheduled_at else None,
                    "sent_at": r.sent_at.isoformat() if r.sent_at else None,
                    "created_at": r.created_at.isoformat() if r.created_at else None,
                } for r in reminders])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_reminders_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_reminder(reminder_id: str) -> str:
        """Get full details of a reminder.

        Args:
            reminder_id: UUID of the reminder
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    r = await reminder_service.get_reminder(db, project_id, uuid.UUID(reminder_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid reminder_id: {reminder_id!r}"})
                if not r:
                    return json.dumps({"error": f"Reminder not found: {reminder_id}"})
                return json.dumps({
                    "reminder_id": str(r.id),
                    "name": r.name,
                    "description": r.description,
                    "channels": r.channels,
                    "status": r.status,
                    "scheduled_at": r.scheduled_at.isoformat() if r.scheduled_at else None,
                    "sent_at": r.sent_at.isoformat() if r.sent_at else None,
                    "error_message": r.error_message,
                    "created_at": r.created_at.isoformat() if r.created_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_reminder_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_reminder(
        reminder_id: str,
        name: str | None = None,
        description: str | None = None,
        channels: list[str] | None = None,
        scheduled_at: str | None = None,
    ) -> str:
        """Update an existing pending reminder.

        Args:
            reminder_id: UUID of the reminder to update
            name: New title
            description: New body text
            channels: New delivery channels
            scheduled_at: New scheduled time (ISO8601)
        """
        try:
            # Validate channels if provided
            if channels:
                invalid = set(channels) - VALID_CHANNELS
                if invalid:
                    return json.dumps({"error": f"Invalid channels: {list(invalid)}"})

            # Parse scheduled_at if provided
            parsed_scheduled_at = ...  # sentinel: do not change
            if scheduled_at is not None:
                if scheduled_at:
                    try:
                        scheduled_dt = datetime.fromisoformat(scheduled_at.replace("Z", "+00:00"))
                        if scheduled_dt.tzinfo is None:
                            scheduled_dt = scheduled_dt.replace(tzinfo=timezone.utc)
                        parsed_scheduled_at = scheduled_dt
                    except ValueError:
                        return json.dumps({"error": f"Invalid scheduled_at: {scheduled_at!r}"})
                else:
                    parsed_scheduled_at = None

            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    rid = uuid.UUID(reminder_id)
                except ValueError:
                    return json.dumps({"error": f"Invalid reminder_id: {reminder_id!r}"})

                r = await reminder_service.get_reminder(db, project_id, rid)
                if not r:
                    return json.dumps({"error": f"Reminder not found: {reminder_id}"})
                if r.status != "pending":
                    return json.dumps({"error": f"Cannot update reminder with status '{r.status}' — only pending reminders can be updated"})

                r = await reminder_service.update_reminder(
                    db, project_id, rid,
                    name=name,
                    description=description,
                    channels=channels,
                    scheduled_at=parsed_scheduled_at,
                )
                await db.commit()
                logger.info("mcp_reminder_updated id=%s", reminder_id)
                return json.dumps({"reminder_id": reminder_id, "name": r.name, "status": r.status, "message": "Updated"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_reminder_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def cancel_reminder(reminder_id: str) -> str:
        """Cancel a pending reminder.

        Args:
            reminder_id: UUID of the reminder to cancel
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    rid = uuid.UUID(reminder_id)
                except ValueError:
                    return json.dumps({"error": f"Invalid reminder_id: {reminder_id!r}"})

                r = await reminder_service.get_reminder(db, project_id, rid)
                if not r:
                    return json.dumps({"error": f"Reminder not found: {reminder_id}"})
                if r.status != "pending":
                    return json.dumps({"error": f"Cannot cancel reminder with status '{r.status}'"})

                r = await reminder_service.cancel_reminder(db, project_id, rid)
                await db.commit()
                logger.info("mcp_reminder_cancelled id=%s", reminder_id)
                return json.dumps({"reminder_id": reminder_id, "status": "cancelled", "message": "Reminder cancelled"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("cancel_reminder_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def send_reminder_now(reminder_id: str) -> str:
        """Send a pending reminder immediately.

        Args:
            reminder_id: UUID of the reminder to send now
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    rid = uuid.UUID(reminder_id)
                except ValueError:
                    return json.dumps({"error": f"Invalid reminder_id: {reminder_id!r}"})

                r = await reminder_service.get_reminder(db, project_id, rid)
                if not r:
                    return json.dumps({"error": f"Reminder not found: {reminder_id}"})
                if r.status != "pending":
                    return json.dumps({"error": f"Cannot send reminder with status '{r.status}'"})

                await db.commit()
                from opspilot.worker.tasks import send_reminder
                send_reminder.delay(reminder_id)
                logger.info("mcp_reminder_send_now id=%s", reminder_id)
                return json.dumps({"reminder_id": reminder_id, "message": "Reminder dispatched for immediate delivery"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("send_reminder_now_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
