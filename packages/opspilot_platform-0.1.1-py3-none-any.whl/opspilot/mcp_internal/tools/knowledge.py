import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.schemas.knowledge import KnowledgeEntryCreate, KnowledgeEntryUpdate
from opspilot.services import knowledge_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_knowledge(
        title: str,
        content: str,
        category: str | None = None,
        tags: list[str] | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new knowledge base entry (runbook, rule, architecture decision).

        Args:
            title: Entry title
            content: Markdown content
            category: Grouping label (e.g. "kubernetes", "security")
            tags: String tags
            session_id: Current session UUID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                data = KnowledgeEntryCreate(
                    title=title,
                    content=content,
                    category=category,
                    tags=tags or [],
                    session_id=uuid.UUID(session_id) if session_id else None,
                )
                entry = await knowledge_service.create_knowledge(db, project_id, data)
                await db.commit()
                logger.info("knowledge_created id=%s title=%s", entry.id, title)
                return json.dumps({"id": str(entry.id), "title": title, "created_at": entry.created_at.isoformat()})

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_knowledge_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_knowledge(
        category: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        limit: int = 20,
        offset: int = 0,
        rerank: bool = False,
    ) -> str:
        """Search the team knowledge base. Supports semantic search, keyword search, and category filtering.

        Args:
            category: Filter by category (e.g. "kubernetes", "security")
            query: Semantic search query
            keyword: BM25 keyword search
            limit: Max results (default 20)
            offset: Pagination offset
            rerank: Cross-encoder reranking (default false)
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                if not project_id:
                    return json.dumps({"error": "No project context. Cannot search knowledge without project scope."})

                entries = await knowledge_service.list_knowledge(
                    db, project_id, category=category, query=query, keyword=keyword,
                    limit=limit, offset=offset, rerank=rerank,
                )
                return json.dumps([
                    {
                        "id": str(e.id),
                        "title": e.title,
                        "category": e.category,
                        "tags": list(e.tags or []),
                        "created_at": e.created_at.isoformat(),
                    }
                    for e in entries
                ])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_knowledge_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_knowledge(knowledge_id: str) -> str:
        """Get full details of a knowledge base entry by ID.

        Args:
            knowledge_id: UUID of the knowledge entry
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                entry = await knowledge_service.get_knowledge(db, project_id, uuid.UUID(knowledge_id))
                if not entry:
                    return json.dumps({"error": f"Knowledge entry not found: {knowledge_id}"})
                return json.dumps({
                    "id": str(entry.id),
                    "title": entry.title,
                    "content": entry.content,
                    "category": entry.category,
                    "tags": list(entry.tags or []),
                    "session_id": str(entry.session_id) if entry.session_id else None,
                    "created_at": entry.created_at.isoformat(),
                    "updated_at": entry.updated_at.isoformat(),
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_knowledge_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_knowledge(
        knowledge_id: str,
        title: str | None = None,
        content: str | None = None,
        category: str | None = None,
        tags: list[str] | None = None,
    ) -> str:
        """Update an existing knowledge base entry.

        Args:
            knowledge_id: UUID of the knowledge entry to update
            title: New title
            content: New markdown content
            category: New category
            tags: New tags
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                update_kwargs = {}
                if title is not None:
                    update_kwargs["title"] = title
                if content is not None:
                    update_kwargs["content"] = content
                if category is not None:
                    update_kwargs["category"] = category
                if tags is not None:
                    update_kwargs["tags"] = tags
                entry = await knowledge_service.update_knowledge(
                    db, project_id, uuid.UUID(knowledge_id), KnowledgeEntryUpdate(**update_kwargs)
                )
                if not entry:
                    return json.dumps({"error": f"Knowledge entry not found: {knowledge_id}"})
                await db.commit()
                logger.info("knowledge_updated id=%s", knowledge_id)
                return json.dumps({"id": knowledge_id, "title": entry.title, "updated_at": entry.updated_at.isoformat()})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_knowledge_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_knowledge(knowledge_id: str) -> str:
        """Delete a knowledge base entry.

        Args:
            knowledge_id: UUID of the knowledge entry to delete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                deleted = await knowledge_service.delete_knowledge(db, project_id, uuid.UUID(knowledge_id))
                if not deleted:
                    return json.dumps({"error": f"Knowledge entry not found: {knowledge_id}"})
                await db.commit()
                logger.info("knowledge_deleted id=%s", knowledge_id)
                return json.dumps({"deleted": knowledge_id})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_knowledge_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
