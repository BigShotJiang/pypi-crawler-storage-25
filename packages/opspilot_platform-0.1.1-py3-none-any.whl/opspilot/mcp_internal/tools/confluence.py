import json
import logging
import uuid

import httpx
from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

CONFLUENCE_API_BASE = "https://api.atlassian.com/ex/confluence"


async def _resolve_confluence_account(account_id: str | None) -> tuple[str, str, str]:
    """Return (access_token, cloud_id, site_name) for the given account or first active."""
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            cloud_id = account.provider_metadata.get("cloud_id", "")
            site_name = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "confluence")
            if not account:
                return "", "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            cloud_id = account.provider_metadata.get("cloud_id", "")
            site_name = account.provider_email
    return token, cloud_id, site_name


async def _confluence_request(
    method: str,
    path: str,
    access_token: str,
    cloud_id: str,
    json_body: dict | None = None,
    params: dict | None = None,
) -> dict:
    """Make an authenticated request to the Confluence REST API."""
    url = f"{CONFLUENCE_API_BASE}/{cloud_id}/wiki/rest/api{path}"
    async with httpx.AsyncClient() as client:
        resp = await client.request(
            method,
            url,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json=json_body,
            params=params,
            timeout=20,
        )
        resp.raise_for_status()
        if resp.status_code == 204:
            return {}
        return resp.json()


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def confluence_list_accounts() -> str:
        """List all connected Confluence sites for the current project.

        Call this first to discover which Confluence sites are available.
        Returns account IDs, site names, and status.
        """
        try:
            project_id = get_project_id()
            async with async_session_factory() as db:
                result = await db.execute(
                    select(ConnectedAccount).where(
                        ConnectedAccount.project_id == project_id,
                        ConnectedAccount.provider == "confluence",
                    )
                )
                accounts = result.scalars().all()

            items = [
                {
                    "id": str(a.id),
                    "site_name": a.provider_email,
                    "site_url": a.provider_metadata.get("site_url", ""),
                    "cloud_id": a.provider_metadata.get("cloud_id", ""),
                    "status": a.status,
                    "scopes": a.scopes,
                }
                for a in accounts
            ]
            return json.dumps({"accounts": items, "total": len(items)})
        except Exception as e:
            logger.error("confluence_list_accounts_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def confluence_list_spaces(
        max_results: int = 25,
        space_type: str = "global",
        account_id: str | None = None,
    ) -> str:
        """List spaces on the connected Confluence site.

        Args:
            max_results: Max spaces to return (1-50).
            space_type: Filter by type — "global" (default) or "personal".
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, cloud_id, site_name = await _resolve_confluence_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Confluence account connected. Connect one at /integrations."})

            max_results = max(1, min(50, max_results))
            data = await _confluence_request(
                "GET", "/space", access_token, cloud_id,
                params={"limit": max_results, "type": space_type, "expand": "description.plain"},
            )

            spaces = [
                {
                    "key": s["key"],
                    "name": s["name"],
                    "type": s.get("type", ""),
                    "description": s.get("description", {}).get("plain", {}).get("value", ""),
                    "url": s.get("_links", {}).get("webui", ""),
                }
                for s in data.get("results", [])
            ]
            logger.info("confluence_list_spaces site=%s count=%d", site_name, len(spaces))
            return json.dumps({"site": site_name, "spaces": spaces, "total": len(spaces)})
        except Exception as e:
            logger.error("confluence_list_spaces_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def confluence_search(
        cql: str = "",
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """Search Confluence content using CQL (Confluence Query Language).

        Args:
            cql: CQL query (e.g. 'space = "DEV" AND type = page AND text ~ "deployment"').
                 Defaults to listing recently updated pages.
            max_results: Max results to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, cloud_id, site_name = await _resolve_confluence_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Confluence account connected. Connect one at /integrations."})

            max_results = max(1, min(50, max_results))
            query = cql or "type = page ORDER BY lastmodified DESC"
            data = await _confluence_request(
                "GET", "/search", access_token, cloud_id,
                params={
                    "cql": query,
                    "limit": max_results,
                    "expand": "space,version",
                },
            )

            results = [
                {
                    "id": r.get("content", {}).get("id", ""),
                    "type": r.get("content", {}).get("type", ""),
                    "title": r.get("title", ""),
                    "space_key": r.get("resultGlobalContainer", {}).get("title", ""),
                    "url": r.get("url", ""),
                    "last_modified": r.get("lastModified", ""),
                    "excerpt": r.get("excerpt", ""),
                }
                for r in data.get("results", [])
            ]
            logger.info("confluence_search site=%s cql=%s count=%d", site_name, query[:80], len(results))
            return json.dumps({"site": site_name, "results": results, "total": data.get("totalSize", len(results))})
        except Exception as e:
            logger.error("confluence_search_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def confluence_get_page(
        page_id: str = "",
        account_id: str | None = None,
    ) -> str:
        """Get the full content of a Confluence page by ID.

        Args:
            page_id: The Confluence page ID (numeric string).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            if not page_id:
                return json.dumps({"error": "page_id is required"})

            access_token, cloud_id, site_name = await _resolve_confluence_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Confluence account connected. Connect one at /integrations."})

            data = await _confluence_request(
                "GET", f"/content/{page_id}", access_token, cloud_id,
                params={"expand": "body.storage,version,space,ancestors"},
            )

            body_html = data.get("body", {}).get("storage", {}).get("value", "")
            result = {
                "id": data["id"],
                "title": data.get("title", ""),
                "type": data.get("type", ""),
                "space_key": data.get("space", {}).get("key", ""),
                "space_name": data.get("space", {}).get("name", ""),
                "version": data.get("version", {}).get("number", 1),
                "created_by": data.get("version", {}).get("by", {}).get("displayName", ""),
                "url": data.get("_links", {}).get("webui", ""),
                "body_storage": body_html,
                "ancestors": [{"id": a["id"], "title": a.get("title", "")} for a in data.get("ancestors", [])],
            }
            logger.info("confluence_get_page site=%s id=%s title=%s", site_name, page_id, result["title"])
            return json.dumps({"site": site_name, "page": result})
        except Exception as e:
            logger.error("confluence_get_page_error: %s", e)
            return json.dumps({"error": str(e)})
