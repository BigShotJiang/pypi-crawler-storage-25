import json
import logging
import uuid
from datetime import datetime, timezone

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.schemas.todos import TodoCreate, TodoUpdate
from opspilot.services import todo_service

logger = logging.getLogger(__name__)

VALID_STATUSES = {"todo", "in_progress", "done", "cancelled"}
VALID_PRIORITIES = {"low", "medium", "high", "urgent"}


def _parse_due_date(due_date: str | None) -> datetime | None:
    if not due_date:
        return None
    dt = datetime.fromisoformat(due_date.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_todo(
        title: str,
        description: str | None = None,
        notes: str | None = None,
        context: str | None = None,
        priority: str = "medium",
        tags: list[str] | None = None,
        due_date: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new todo item.

        Args:
            title: Task title
            description: Optional description
            notes: Detailed notes or steps
            context: Context label (e.g. "AckSession", "Personal")
            priority: low | medium | high | urgent (default: medium)
            tags: Labels list
            due_date: ISO8601 date/datetime (e.g. "2026-03-01" or "2026-03-01T09:00:00Z")
            session_id: Current session ID
        """
        try:
            if priority not in VALID_PRIORITIES:
                return json.dumps({"error": f"Invalid priority: {priority!r}. Allowed: {sorted(VALID_PRIORITIES)}"})
            try:
                due_dt = _parse_due_date(due_date)
            except ValueError:
                return json.dumps({"error": f"Invalid due_date: {due_date!r}. Use ISO8601."})

            async with async_session_factory() as db:
                project_id = get_project_id()
                data = TodoCreate(
                    title=title,
                    description=description,
                    notes=notes,
                    context=context,
                    priority=priority,
                    tags=tags or [],
                    due_date=due_dt,
                    session_id=uuid.UUID(session_id) if session_id else None,
                    status="todo",
                )
                item = await todo_service.create_todo(db, project_id, data)
                await db.commit()
                logger.info("mcp_todo_created id=%s title=%r priority=%s", item.id, title, priority)
                return json.dumps({
                    "todo_id": str(item.id),
                    "title": title,
                    "status": "todo",
                    "priority": priority,
                    "context": context,
                    "due_date": due_date,
                    "message": f"Todo created: {title!r}",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_todo_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_todos(
        status: str | None = None,
        priority: str | None = None,
        context: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        limit: int = 20,
        offset: int = 0,
        rerank: bool = False,
    ) -> str:
        """Search todo items. Supports semantic search, keyword search, and filtering.

        Args:
            status: Filter by status — todo/in_progress/done/cancelled
            priority: Filter by priority — low/medium/high/urgent
            context: Filter by context label
            query: Semantic search query
            keyword: BM25 keyword search
            limit: Max results (default 20)
            offset: Pagination offset
            rerank: Cross-encoder reranking (default false)
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                if not project_id:
                    return json.dumps({"error": "No project context. Cannot search todos without project scope."})

                items = await todo_service.list_todos(
                    db, project_id,
                    status=status,
                    priority=priority,
                    context=context,
                    query=query,
                    keyword=keyword,
                    limit=limit,
                    offset=offset,
                    rerank=rerank,
                )
                return json.dumps([{
                    "todo_id": str(i.id),
                    "title": i.title,
                    "status": i.status,
                    "priority": i.priority,
                    "context": i.context,
                    "tags": i.tags,
                    "due_date": i.due_date.isoformat() if i.due_date else None,
                    "completed_at": i.completed_at.isoformat() if i.completed_at else None,
                    "created_at": i.created_at.isoformat() if i.created_at else None,
                } for i in items])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_todos_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_todo(todo_id: str) -> str:
        """Get full details of a todo item.

        Args:
            todo_id: UUID of the todo item
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    item = await todo_service.get_todo(db, project_id, uuid.UUID(todo_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid todo_id: {todo_id!r}"})
                if not item:
                    return json.dumps({"error": f"Todo not found: {todo_id}"})
                return json.dumps({
                    "todo_id": str(item.id),
                    "title": item.title,
                    "description": item.description,
                    "notes": item.notes,
                    "context": item.context,
                    "status": item.status,
                    "priority": item.priority,
                    "tags": item.tags,
                    "due_date": item.due_date.isoformat() if item.due_date else None,
                    "completed_at": item.completed_at.isoformat() if item.completed_at else None,
                    "created_at": item.created_at.isoformat() if item.created_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_todo_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_todo(
        todo_id: str,
        title: str | None = None,
        description: str | None = None,
        notes: str | None = None,
        context: str | None = None,
        priority: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        due_date: str | None = None,
    ) -> str:
        """Update an existing todo item.

        Args:
            todo_id: UUID of the todo item to update
            title: New title
            description: New description
            notes: New notes
            context: New context label
            priority: New priority — low/medium/high/urgent
            status: New status — todo/in_progress/done/cancelled
            tags: New tags
            due_date: New due date (ISO8601), or empty string to clear
        """
        try:
            if status and status not in VALID_STATUSES:
                return json.dumps({"error": f"Invalid status: {status!r}. Allowed: {sorted(VALID_STATUSES)}"})
            if priority and priority not in VALID_PRIORITIES:
                return json.dumps({"error": f"Invalid priority: {priority!r}. Allowed: {sorted(VALID_PRIORITIES)}"})

            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    update_kwargs = {}
                    if title:
                        update_kwargs["title"] = title
                    if description is not None:
                        update_kwargs["description"] = description
                    if notes is not None:
                        update_kwargs["notes"] = notes
                    if context is not None:
                        update_kwargs["context"] = context
                    if priority:
                        update_kwargs["priority"] = priority
                    if tags:
                        update_kwargs["tags"] = tags
                    if status:
                        update_kwargs["status"] = status
                    if due_date is not None:
                        if due_date:
                            update_kwargs["due_date"] = _parse_due_date(due_date)
                        else:
                            update_kwargs["due_date"] = None
                    item = await todo_service.update_todo(db, project_id, uuid.UUID(todo_id), TodoUpdate(**update_kwargs))
                except ValueError as e:
                    return json.dumps({"error": str(e)})
                if not item:
                    return json.dumps({"error": f"Todo not found: {todo_id}"})
                await db.commit()
                logger.info("mcp_todo_updated id=%s", todo_id)
                return json.dumps({"todo_id": todo_id, "title": item.title, "status": item.status, "priority": item.priority, "message": "Updated"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_todo_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_todo(todo_id: str) -> str:
        """Delete a todo item.

        Args:
            todo_id: UUID of the todo item to delete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    deleted = await todo_service.delete_todo(db, project_id, uuid.UUID(todo_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid todo_id: {todo_id!r}"})
                if not deleted:
                    return json.dumps({"error": f"Todo not found: {todo_id}"})
                await db.commit()
                logger.info("mcp_todo_deleted id=%s", todo_id)
                return json.dumps({"deleted": todo_id, "message": "Todo deleted"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_todo_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def complete_todo(todo_id: str) -> str:
        """Mark a todo item as completed.

        Args:
            todo_id: UUID of the todo item to complete
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                try:
                    item = await todo_service.complete_todo(db, project_id, uuid.UUID(todo_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid todo_id: {todo_id!r}"})
                if not item:
                    return json.dumps({"error": f"Todo not found: {todo_id}"})
                if item.completed_at and item.status == "done":
                    await db.commit()
                logger.info("mcp_todo_completed id=%s", todo_id)
                return json.dumps({"todo_id": todo_id, "title": item.title, "status": "done", "message": f"Todo completed: {item.title!r}"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("complete_todo_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
