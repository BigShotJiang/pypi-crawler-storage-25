import asyncio
import base64
import json
import logging
import uuid
from functools import partial

from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)


def _build_gmail_service(access_token: str):
    """Build a Gmail API service from a raw access token."""
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

    creds = Credentials(token=access_token)
    return build("gmail", "v1", credentials=creds, cache_discovery=False)


def _extract_body(payload: dict) -> str:
    """Recursively extract plain-text body from a Gmail message payload."""
    mime_type = payload.get("mimeType", "")
    body_data = payload.get("body", {}).get("data", "")

    if mime_type == "text/plain" and body_data:
        return base64.urlsafe_b64decode(body_data + "==").decode("utf-8", errors="replace")

    for part in payload.get("parts", []):
        result = _extract_body(part)
        if result:
            return result

    # Fallback: decode body data even for non-plain types
    if body_data:
        return base64.urlsafe_b64decode(body_data + "==").decode("utf-8", errors="replace")
    return ""


def _get_header(headers: list[dict], name: str) -> str:
    for h in headers:
        if h.get("name", "").lower() == name.lower():
            return h.get("value", "")
    return ""


def _extract_attachments(payload: dict) -> list[dict]:
    """Recursively extract attachment metadata from a Gmail message payload."""
    attachments = []
    for part in payload.get("parts", []):
        filename = part.get("filename", "")
        if filename:
            attachments.append({
                "filename": filename,
                "mime_type": part.get("mimeType", ""),
                "size": part.get("body", {}).get("size", 0),
                "attachment_id": part.get("body", {}).get("attachmentId", ""),
            })
        # Recursively check nested parts
        attachments.extend(_extract_attachments(part))
    return attachments


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given account_id or first active account.

    Enforces project isolation: only accounts belonging to the current project are accessible.
    """
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            # Verify account belongs to this project
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            email_addr = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "google")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            email_addr = account.provider_email
    return token, email_addr


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def gmail_list_accounts() -> str:
        """List connected Gmail accounts. Call this first before using other Gmail tools.

        Pass the returned account_id to target a specific account.
        """
        project_id = get_project_id()
        async with async_session_factory() as db:
            result = await db.execute(
                select(ConnectedAccount)
                .where(
                    ConnectedAccount.project_id == project_id,
                    ConnectedAccount.provider == "google",
                )
                .order_by(ConnectedAccount.created_at)
            )
            accounts = result.scalars().all()

        if not accounts:
            return json.dumps({"accounts": [], "message": "No Gmail accounts connected. Visit /integrations to connect one."})

        return json.dumps({
            "accounts": [
                {
                    "account_id": str(a.id),
                    "email": a.provider_email,
                    "label": a.label,
                    "status": a.status,
                    "default": i == 0,
                }
                for i, a in enumerate(accounts)
            ],
            "note": "Pass account_id to gmail_list_emails, gmail_read_email, or gmail_get_thread to target a specific account. The first account is used by default.",
        })

    @mcp.tool()
    async def gmail_list_emails(
        query: str = "is:unread",
        max_results: int = 10,
        account_id: str | None = None,
    ) -> str:
        """List emails from a Gmail account.

        Args:
            query: Gmail search query (e.g. "is:unread", "from:boss@example.com")
            max_results: Max emails to return (1-50)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Gmail account connected. Connect one at /integrations."})

            max_results = max(1, min(50, max_results))

            loop = asyncio.get_event_loop()
            gmail = _build_gmail_service(access_token)

            # List message IDs
            list_fn = partial(
                gmail.users().messages().list(userId="me", q=query, maxResults=max_results).execute
            )
            list_result = await loop.run_in_executor(None, list_fn)
            messages_raw = list_result.get("messages", [])

            if not messages_raw:
                return json.dumps({"account": email_addr, "emails": [], "total": 0})

            # Fetch metadata for each message
            emails = []
            for msg in messages_raw:
                get_fn = partial(
                    gmail.users().messages().get(
                        userId="me",
                        id=msg["id"],
                        format="metadata",
                        metadataHeaders=["Subject", "From", "To", "Date"],
                    ).execute
                )
                msg_data = await loop.run_in_executor(None, get_fn)
                headers = msg_data.get("payload", {}).get("headers", [])
                emails.append({
                    "id": msg_data["id"],
                    "thread_id": msg_data.get("threadId"),
                    "subject": _get_header(headers, "Subject") or "(no subject)",
                    "from": _get_header(headers, "From"),
                    "to": _get_header(headers, "To"),
                    "date": _get_header(headers, "Date"),
                    "snippet": msg_data.get("snippet", ""),
                    "labels": msg_data.get("labelIds", []),
                })

            logger.info("gmail_list_emails account=%s count=%d", email_addr, len(emails))
            return json.dumps({"account": email_addr, "emails": emails, "total": len(emails)})

        except Exception as e:
            logger.error("gmail_list_emails_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def gmail_read_email(
        message_id: str,
        account_id: str | None = None,
    ) -> str:
        """Read the full content of a Gmail message.

        Args:
            message_id: Message ID from gmail_list_emails
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Gmail account connected."})

            loop = asyncio.get_event_loop()
            gmail = _build_gmail_service(access_token)

            get_fn = partial(
                gmail.users().messages().get(userId="me", id=message_id, format="full").execute
            )
            msg_data = await loop.run_in_executor(None, get_fn)

            headers = msg_data.get("payload", {}).get("headers", [])
            body = _extract_body(msg_data.get("payload", {}))

            result = {
                "id": msg_data["id"],
                "thread_id": msg_data.get("threadId"),
                "subject": _get_header(headers, "Subject") or "(no subject)",
                "from": _get_header(headers, "From"),
                "to": _get_header(headers, "To"),
                "cc": _get_header(headers, "Cc"),
                "date": _get_header(headers, "Date"),
                "labels": msg_data.get("labelIds", []),
                "snippet": msg_data.get("snippet", ""),
                "body": body[:32000],  # Cap to avoid huge messages
                "attachments": _extract_attachments(msg_data.get("payload", {})),
            }
            logger.info("gmail_read_email account=%s message_id=%s", email_addr, message_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("gmail_read_email_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def gmail_get_thread(
        thread_id: str,
        account_id: str | None = None,
    ) -> str:
        """Retrieve all messages in a Gmail thread (chronological order).

        Args:
            thread_id: Thread ID from gmail_list_emails or gmail_read_email
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Gmail account connected."})

            loop = asyncio.get_event_loop()
            gmail = _build_gmail_service(access_token)

            get_fn = partial(
                gmail.users().threads().get(userId="me", id=thread_id, format="full").execute
            )
            thread_data = await loop.run_in_executor(None, get_fn)

            messages = []
            for msg_data in thread_data.get("messages", []):
                headers = msg_data.get("payload", {}).get("headers", [])
                body = _extract_body(msg_data.get("payload", {}))

                messages.append({
                    "id": msg_data["id"],
                    "from": _get_header(headers, "From"),
                    "to": _get_header(headers, "To"),
                    "cc": _get_header(headers, "Cc"),
                    "date": _get_header(headers, "Date"),
                    "subject": _get_header(headers, "Subject") or "(no subject)",
                    "snippet": msg_data.get("snippet", ""),
                    "body": body[:32000],
                    "labels": msg_data.get("labelIds", []),
                    "attachments": _extract_attachments(msg_data.get("payload", {})),
                })

            result = {
                "thread_id": thread_id,
                "account": email_addr,
                "message_count": len(messages),
                "messages": messages,
            }
            logger.info("gmail_get_thread account=%s thread_id=%s message_count=%d", email_addr, thread_id, len(messages))
            return json.dumps(result)

        except Exception as e:
            logger.error("gmail_get_thread_error: %s", e)
            return json.dumps({"error": str(e)})

    # gmail_send_email is disabled — uncomment to enable outbound email via agent
    # @mcp.tool()
    # async def gmail_send_email(
    #     to: str,
    #     subject: str,
    #     body: str,
    #     account_id: str | None = None,
    # ) -> str:
    #     """Send an email via a connected Gmail account."""
    #     try:
    #         access_token, email_addr = await _resolve_account(account_id)
    #         if not access_token:
    #             return json.dumps({"error": "No active Gmail account connected."})
    #         msg = MIMEText(body)
    #         msg["to"] = to
    #         msg["from"] = email_addr
    #         msg["subject"] = subject
    #         raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    #         loop = asyncio.get_event_loop()
    #         gmail = _build_gmail_service(access_token)
    #         send_fn = partial(gmail.users().messages().send(userId="me", body={"raw": raw}).execute)
    #         result = await loop.run_in_executor(None, send_fn)
    #         logger.info("gmail_send_email from=%s to=%s subject=%s id=%s", email_addr, to, subject, result.get("id"))
    #         return json.dumps({"status": "sent", "message_id": result.get("id"), "from": email_addr, "to": to})
    #     except Exception as e:
    #         logger.error("gmail_send_email_error: %s", e)
    #         return json.dumps({"error": str(e)})
