import json
import logging
import uuid

import httpx
from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


async def _resolve_account(account_id: str | None) -> tuple[str, str]:
    """Return (access_token, provider_email) for the given account or first active Microsoft account."""
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            email_addr = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "microsoft")
            if not account:
                return "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            email_addr = account.provider_email
    return token, email_addr


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def outlook_list_accounts() -> str:
        """List connected Microsoft/Outlook accounts. Call this first before using other Outlook tools.

        Pass the returned account_id to target a specific account.
        """
        project_id = get_project_id()
        async with async_session_factory() as db:
            result = await db.execute(
                select(ConnectedAccount)
                .where(
                    ConnectedAccount.project_id == project_id,
                    ConnectedAccount.provider == "microsoft",
                )
                .order_by(ConnectedAccount.created_at)
            )
            accounts = result.scalars().all()

        if not accounts:
            return json.dumps({"accounts": [], "message": "No Microsoft accounts connected. Visit /integrations to connect one."})

        return json.dumps({
            "accounts": [
                {
                    "account_id": str(a.id),
                    "email": a.provider_email,
                    "label": a.label,
                    "status": a.status,
                    "default": i == 0,
                }
                for i, a in enumerate(accounts)
            ],
            "note": "Pass account_id to outlook_list_emails, outlook_read_email, or outlook_get_thread to target a specific account. The first account is used by default.",
        })

    @mcp.tool()
    async def outlook_list_emails(
        query: str = "",
        folder: str = "inbox",
        max_results: int = 10,
        unread_only: bool = False,
        account_id: str | None = None,
    ) -> str:
        """List emails from a Microsoft Outlook account.

        Args:
            query: OData $search query (e.g. "from:boss@example.com", "subject:deployment")
            folder: Mail folder (inbox, sentitems, drafts, archive, junkemail, deleteditems)
            max_results: Max emails to return (1-50)
            unread_only: If true, only return unread emails
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected. Connect one at /integrations."})

            max_results = max(1, min(50, max_results))

            url = f"{GRAPH_BASE}/me/mailFolders/{folder}/messages"
            params: dict[str, str | int] = {
                "$top": max_results,
                "$select": "id,conversationId,subject,from,toRecipients,receivedDateTime,bodyPreview,isRead,hasAttachments",
                "$orderby": "receivedDateTime desc",
            }
            if query:
                params["$search"] = f'"{query}"'
            if unread_only:
                params["$filter"] = "isRead eq false"

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    url,
                    headers={"Authorization": f"Bearer {access_token}"},
                    params=params,
                    timeout=15,
                )
                resp.raise_for_status()
                data = resp.json()

            emails = []
            for msg in data.get("value", []):
                from_addr = msg.get("from", {}).get("emailAddress", {})
                to_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])]
                emails.append({
                    "id": msg.get("id"),
                    "conversation_id": msg.get("conversationId"),
                    "subject": msg.get("subject", "(no subject)"),
                    "from": f"{from_addr.get('name', '')} <{from_addr.get('address', '')}>",
                    "to": ", ".join(to_list),
                    "date": msg.get("receivedDateTime"),
                    "snippet": msg.get("bodyPreview", ""),
                    "is_read": msg.get("isRead", False),
                    "has_attachments": msg.get("hasAttachments", False),
                })

            logger.info("outlook_list_emails account=%s count=%d", email_addr, len(emails))
            return json.dumps({"account": email_addr, "emails": emails, "total": len(emails)})

        except Exception as e:
            logger.error("outlook_list_emails_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_read_email(
        message_id: str,
        account_id: str | None = None,
    ) -> str:
        """Read the full content of an Outlook email message.

        Args:
            message_id: Message ID from outlook_list_emails
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            url = f"{GRAPH_BASE}/me/messages/{message_id}"
            params = {
                "$select": "id,conversationId,subject,from,toRecipients,ccRecipients,receivedDateTime,body,bodyPreview,isRead,hasAttachments,attachments",
                "$expand": "attachments($select=id,name,contentType,size)",
            }

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    url,
                    headers={"Authorization": f"Bearer {access_token}"},
                    params=params,
                    timeout=15,
                )
                resp.raise_for_status()
                msg = resp.json()

            from_addr = msg.get("from", {}).get("emailAddress", {})
            to_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])]
            cc_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("ccRecipients", [])]
            body = msg.get("body", {})

            # Extract text content, prefer text/plain
            body_content = body.get("content", "")
            if body.get("contentType") == "html":
                # Strip HTML for agent consumption — keep raw for reference
                body_content = body_content[:32000]

            attachments = [
                {
                    "id": att.get("id"),
                    "name": att.get("name"),
                    "content_type": att.get("contentType"),
                    "size": att.get("size"),
                }
                for att in msg.get("attachments", [])
            ]

            result = {
                "id": msg.get("id"),
                "conversation_id": msg.get("conversationId"),
                "subject": msg.get("subject", "(no subject)"),
                "from": f"{from_addr.get('name', '')} <{from_addr.get('address', '')}>",
                "to": ", ".join(to_list),
                "cc": ", ".join(cc_list),
                "date": msg.get("receivedDateTime"),
                "is_read": msg.get("isRead", False),
                "body_type": body.get("contentType", "text"),
                "body": body_content,
                "attachments": attachments,
            }
            logger.info("outlook_read_email account=%s message_id=%s", email_addr, message_id)
            return json.dumps(result)

        except Exception as e:
            logger.error("outlook_read_email_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def outlook_get_thread(
        conversation_id: str,
        max_results: int = 25,
        account_id: str | None = None,
    ) -> str:
        """Retrieve all messages in an Outlook conversation thread.

        Args:
            conversation_id: Conversation ID from outlook_list_emails or outlook_read_email
            max_results: Max messages to return (1-50)
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, email_addr = await _resolve_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Microsoft account connected."})

            max_results = max(1, min(50, max_results))

            url = f"{GRAPH_BASE}/me/messages"
            params = {
                "$filter": f"conversationId eq '{conversation_id}'",
                "$top": max_results,
                "$select": "id,conversationId,subject,from,toRecipients,ccRecipients,receivedDateTime,body,hasAttachments",
                "$orderby": "receivedDateTime asc",
            }

            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    url,
                    headers={"Authorization": f"Bearer {access_token}"},
                    params=params,
                    timeout=15,
                )
                resp.raise_for_status()
                data = resp.json()

            messages = []
            for msg in data.get("value", []):
                from_addr = msg.get("from", {}).get("emailAddress", {})
                to_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])]
                cc_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("ccRecipients", [])]
                body = msg.get("body", {})

                messages.append({
                    "id": msg.get("id"),
                    "from": f"{from_addr.get('name', '')} <{from_addr.get('address', '')}>",
                    "to": ", ".join(to_list),
                    "cc": ", ".join(cc_list),
                    "date": msg.get("receivedDateTime"),
                    "subject": msg.get("subject", "(no subject)"),
                    "body": body.get("content", "")[:32000],
                    "body_type": body.get("contentType", "text"),
                    "has_attachments": msg.get("hasAttachments", False),
                })

            result = {
                "conversation_id": conversation_id,
                "account": email_addr,
                "message_count": len(messages),
                "messages": messages,
            }
            logger.info("outlook_get_thread account=%s conversation_id=%s message_count=%d", email_addr, conversation_id, len(messages))
            return json.dumps(result)

        except Exception as e:
            logger.error("outlook_get_thread_error: %s", e)
            return json.dumps({"error": str(e)})
