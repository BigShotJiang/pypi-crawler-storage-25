import json
import logging
import uuid

import httpx
from fastmcp import FastMCP
from sqlalchemy import select

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models import ConnectedAccount
from opspilot.services import oauth_service

logger = logging.getLogger(__name__)

JIRA_API_BASE = "https://api.atlassian.com/ex/jira"


async def _resolve_jira_account(account_id: str | None) -> tuple[str, str, str]:
    """Return (access_token, cloud_id, site_name) for the given account or first active."""
    project_id = get_project_id()
    async with async_session_factory() as db:
        if account_id:
            try:
                aid = uuid.UUID(account_id)
            except ValueError:
                return "", "", ""
            result = await db.execute(
                select(ConnectedAccount).where(
                    ConnectedAccount.id == aid,
                    ConnectedAccount.project_id == project_id,
                )
            )
            account = result.scalar_one_or_none()
            if not account:
                return "", "", ""
            token = await oauth_service.get_valid_access_token(db, aid)
            cloud_id = account.provider_metadata.get("cloud_id", "")
            site_name = account.provider_email
        else:
            account = await oauth_service.get_first_active_account(db, project_id, "jira")
            if not account:
                return "", "", ""
            token = await oauth_service.get_valid_access_token(db, account.id)
            cloud_id = account.provider_metadata.get("cloud_id", "")
            site_name = account.provider_email
    return token, cloud_id, site_name


async def _jira_request(
    method: str,
    path: str,
    access_token: str,
    cloud_id: str,
    json_body: dict | None = None,
    params: dict | None = None,
) -> dict:
    """Make an authenticated request to the Jira REST API v3."""
    url = f"{JIRA_API_BASE}/{cloud_id}/rest/api/3{path}"
    async with httpx.AsyncClient() as client:
        resp = await client.request(
            method,
            url,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json=json_body,
            params=params,
            timeout=20,
        )
        resp.raise_for_status()
        if resp.status_code == 204:
            return {}
        return resp.json()


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def jira_list_accounts() -> str:
        """List all connected Jira sites for the current project.

        Call this first to discover which Jira sites are available.
        Returns account IDs, site names, and status.
        """
        try:
            project_id = get_project_id()
            async with async_session_factory() as db:
                result = await db.execute(
                    select(ConnectedAccount).where(
                        ConnectedAccount.project_id == project_id,
                        ConnectedAccount.provider == "jira",
                    )
                )
                accounts = result.scalars().all()

            items = [
                {
                    "id": str(a.id),
                    "site_name": a.provider_email,
                    "site_url": a.provider_metadata.get("site_url", ""),
                    "cloud_id": a.provider_metadata.get("cloud_id", ""),
                    "status": a.status,
                    "scopes": a.scopes,
                }
                for a in accounts
            ]
            return json.dumps({"accounts": items, "total": len(items)})
        except Exception as e:
            logger.error("jira_list_accounts_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def jira_list_projects(
        max_results: int = 50,
        account_id: str | None = None,
    ) -> str:
        """List projects on the connected Jira site.

        Args:
            max_results: Max projects to return (1-50).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, cloud_id, site_name = await _resolve_jira_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Jira account connected. Connect one at /integrations."})

            max_results = max(1, min(50, max_results))
            data = await _jira_request(
                "GET", "/project/search", access_token, cloud_id,
                params={"maxResults": max_results, "orderBy": "name"},
            )

            projects = [
                {
                    "id": p["id"],
                    "key": p["key"],
                    "name": p["name"],
                    "style": p.get("style", ""),
                    "is_private": p.get("isPrivate", False),
                }
                for p in data.get("values", [])
            ]
            logger.info("jira_list_projects site=%s count=%d", site_name, len(projects))
            return json.dumps({"site": site_name, "projects": projects, "total": len(projects)})
        except Exception as e:
            logger.error("jira_list_projects_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def jira_search_issues(
        jql: str = "order by updated DESC",
        max_results: int = 20,
        account_id: str | None = None,
    ) -> str:
        """Search Jira issues using JQL (Jira Query Language).

        Args:
            jql: JQL query string (e.g. "project = PROJ AND status = Open", "assignee = currentUser()").
            max_results: Max issues to return (1-100).
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            access_token, cloud_id, site_name = await _resolve_jira_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Jira account connected. Connect one at /integrations."})

            max_results = max(1, min(100, max_results))
            data = await _jira_request(
                "POST", "/search", access_token, cloud_id,
                json_body={
                    "jql": jql,
                    "maxResults": max_results,
                    "fields": ["summary", "status", "assignee", "priority", "issuetype", "project", "updated", "created", "labels"],
                },
            )

            issues = [
                {
                    "key": issue["key"],
                    "id": issue["id"],
                    "summary": fields.get("summary", ""),
                    "status": fields.get("status", {}).get("name", ""),
                    "issue_type": fields.get("issuetype", {}).get("name", ""),
                    "priority": fields.get("priority", {}).get("name", ""),
                    "assignee": (fields.get("assignee") or {}).get("displayName", "Unassigned"),
                    "project": fields.get("project", {}).get("key", ""),
                    "labels": fields.get("labels", []),
                    "created": fields.get("created", ""),
                    "updated": fields.get("updated", ""),
                }
                for issue in data.get("issues", [])
                for fields in [issue.get("fields", {})]
            ]
            logger.info("jira_search_issues site=%s jql=%s count=%d", site_name, jql[:80], len(issues))
            return json.dumps({"site": site_name, "issues": issues, "total": data.get("total", len(issues))})
        except Exception as e:
            logger.error("jira_search_issues_error: %s", e)
            return json.dumps({"error": str(e)})

    @mcp.tool()
    async def jira_get_issue(
        issue_key: str = "",
        account_id: str | None = None,
    ) -> str:
        """Get full details of a Jira issue by key (e.g. "PROJ-123").

        Args:
            issue_key: The issue key (e.g. "PROJ-123") or issue ID.
            account_id: Target account UUID; uses first active if omitted.
        """
        try:
            if not issue_key:
                return json.dumps({"error": "issue_key is required"})

            access_token, cloud_id, site_name = await _resolve_jira_account(account_id)
            if not access_token:
                return json.dumps({"error": "No active Jira account connected. Connect one at /integrations."})

            data = await _jira_request(
                "GET", f"/issue/{issue_key}", access_token, cloud_id,
                params={"expand": "renderedFields"},
            )

            fields = data.get("fields", {})
            result = {
                "key": data["key"],
                "id": data["id"],
                "summary": fields.get("summary", ""),
                "description": fields.get("description"),
                "status": fields.get("status", {}).get("name", ""),
                "issue_type": fields.get("issuetype", {}).get("name", ""),
                "priority": fields.get("priority", {}).get("name", ""),
                "assignee": (fields.get("assignee") or {}).get("displayName", "Unassigned"),
                "reporter": (fields.get("reporter") or {}).get("displayName", ""),
                "project": fields.get("project", {}).get("key", ""),
                "labels": fields.get("labels", []),
                "components": [c.get("name", "") for c in fields.get("components", [])],
                "created": fields.get("created", ""),
                "updated": fields.get("updated", ""),
                "resolution": (fields.get("resolution") or {}).get("name"),
                "rendered_description": data.get("renderedFields", {}).get("description", ""),
                "comment_count": fields.get("comment", {}).get("total", 0),
            }

            logger.info("jira_get_issue site=%s key=%s", site_name, issue_key)
            return json.dumps({"site": site_name, "issue": result})
        except Exception as e:
            logger.error("jira_get_issue_error: %s", e)
            return json.dumps({"error": str(e)})
