import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.application.tasks_service import CeleryTaskRunner, TasksService
from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.infrastructure.repos.task_repo import SqlaTaskRepository
from opspilot.models import AgentType
from opspilot.schemas.tasks import TaskCreate, TaskUpdate

logger = logging.getLogger(__name__)

VALID_AGENT_TYPES = {"claude-code", "codex", "gemini"}


def _make_service(db) -> TasksService:
    return TasksService(repo=SqlaTaskRepository(db), runner=CeleryTaskRunner())


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_task(
        name: str,
        prompt: str,
        description: str | None = None,
        system_prompt: str | None = None,
        agent_type: str = "claude-code",
        cron_schedule: str | None = None,
        timeout_seconds: int = 600,
        enabled: bool = True,
    ) -> str:
        """Create a new automation task.

        Args:
            name: Task name
            prompt: Agent instruction (the main prompt)
            description: Short description
            system_prompt: System-level context appended to the agent
            agent_type: claude-code (default) | codex | gemini
            cron_schedule: Cron expression (e.g. "0 * * * *"); omit for manual-only
            timeout_seconds: Max runtime seconds (default: 600)
            enabled: Active for scheduled runs (default: true)
        """
        try:
            if agent_type not in VALID_AGENT_TYPES:
                return json.dumps({"error": f"Invalid agent_type: {agent_type!r}. Allowed: {sorted(VALID_AGENT_TYPES)}"})

            async with async_session_factory() as db:
                svc = _make_service(db)
                data = TaskCreate(
                    name=name.strip(),
                    description=description,
                    prompt=prompt,
                    system_prompt=system_prompt,
                    agent_type=AgentType(agent_type),
                    cron_schedule=cron_schedule,
                    timeout_seconds=timeout_seconds,
                    enabled=enabled,
                )
                t = await svc.create_task(data)
                await db.commit()
                logger.info("mcp_task_created id=%s name=%r agent=%s", t.id, name, agent_type)
                return json.dumps({
                    "task_id": str(t.id),
                    "name": t.name,
                    "agent_type": t.agent_type.value,
                    "enabled": t.enabled,
                    "message": f"Task created: {name!r}",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_task_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_tasks(limit: int = 20) -> str:
        """List all automation tasks with their status and schedule.

        Args:
            limit: Max results (default 20)
        """
        try:
            if not get_project_id():
                return json.dumps({"error": "No project context. Cannot list tasks without project scope."})

            async with async_session_factory() as db:
                svc = _make_service(db)
                tasks, total = await svc.list_tasks(limit=limit)
                return json.dumps([{
                    "task_id": str(t.id),
                    "name": t.name,
                    "description": t.description,
                    "agent_type": t.agent_type.value,
                    "cron_schedule": t.cron_schedule,
                    "enabled": t.enabled,
                    "last_run_at": t.last_run_at.isoformat() if t.last_run_at else None,
                    "next_run_at": t.next_run_at.isoformat() if t.next_run_at else None,
                    "created_at": t.created_at.isoformat() if t.created_at else None,
                } for t in tasks])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_tasks_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_task(task_id: str) -> str:
        """Get full details of an automation task.

        Args:
            task_id: UUID of the task
        """
        try:
            async with async_session_factory() as db:
                svc = _make_service(db)
                try:
                    t = await svc.get_task(uuid.UUID(task_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid task_id: {task_id!r}"})
                if not t:
                    return json.dumps({"error": f"Task not found: {task_id}"})
                return json.dumps({
                    "task_id": str(t.id),
                    "name": t.name,
                    "description": t.description,
                    "prompt": t.prompt,
                    "system_prompt": t.system_prompt,
                    "agent_type": t.agent_type.value,
                    "cron_schedule": t.cron_schedule,
                    "timeout_seconds": t.timeout_seconds,
                    "max_retries": t.max_retries,
                    "enabled": t.enabled,
                    "last_run_at": t.last_run_at.isoformat() if t.last_run_at else None,
                    "next_run_at": t.next_run_at.isoformat() if t.next_run_at else None,
                    "created_at": t.created_at.isoformat() if t.created_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_task_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_task(
        task_id: str,
        name: str | None = None,
        description: str | None = None,
        prompt: str | None = None,
        system_prompt: str | None = None,
        agent_type: str | None = None,
        cron_schedule: str | None = None,
        timeout_seconds: int | None = None,
        enabled: bool | None = None,
    ) -> str:
        """Update an existing automation task.

        Args:
            task_id: UUID of the task to update
            name: New name
            description: New description
            prompt: New agent instruction
            system_prompt: New system prompt
            agent_type: New agent type — claude-code/codex/gemini
            cron_schedule: New cron expression (empty string to clear)
            timeout_seconds: New timeout
            enabled: Enable/disable scheduled runs
        """
        try:
            if agent_type is not None and agent_type not in VALID_AGENT_TYPES:
                return json.dumps({"error": f"Invalid agent_type: {agent_type!r}. Allowed: {sorted(VALID_AGENT_TYPES)}"})

            async with async_session_factory() as db:
                svc = _make_service(db)
                update_kwargs = {}
                if name is not None:
                    update_kwargs["name"] = name.strip()
                if description is not None:
                    update_kwargs["description"] = description
                if prompt is not None:
                    update_kwargs["prompt"] = prompt
                if system_prompt is not None:
                    update_kwargs["system_prompt"] = system_prompt
                if agent_type is not None:
                    update_kwargs["agent_type"] = AgentType(agent_type)
                if cron_schedule is not None:
                    update_kwargs["cron_schedule"] = cron_schedule or None
                if timeout_seconds is not None:
                    update_kwargs["timeout_seconds"] = timeout_seconds
                if enabled is not None:
                    update_kwargs["enabled"] = enabled
                try:
                    t = await svc.update_task(uuid.UUID(task_id), TaskUpdate(**update_kwargs))
                except ValueError:
                    return json.dumps({"error": f"Invalid task_id: {task_id!r}"})
                if not t:
                    return json.dumps({"error": f"Task not found: {task_id}"})
                await db.commit()
                logger.info("mcp_task_updated id=%s", task_id)
                return json.dumps({
                    "task_id": task_id,
                    "name": t.name,
                    "enabled": t.enabled,
                    "message": "Task updated",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_task_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def delete_task(task_id: str) -> str:
        """Delete an automation task permanently.

        Args:
            task_id: UUID of the task to delete
        """
        try:
            async with async_session_factory() as db:
                svc = _make_service(db)
                try:
                    await svc.delete_task(uuid.UUID(task_id))
                except ValueError:
                    return json.dumps({"error": f"Invalid task_id: {task_id!r}"})
                except Exception:
                    return json.dumps({"error": f"Task not found: {task_id}"})
                await db.commit()
                logger.info("mcp_task_deleted id=%s", task_id)
                return json.dumps({"deleted": task_id, "message": "Task deleted"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("delete_task_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def trigger_task(task_id: str) -> str:
        """Manually trigger an automation task immediately. Returns a session_id to track progress.

        Args:
            task_id: UUID of the task to trigger
        """
        try:
            async with async_session_factory() as db:
                svc = _make_service(db)
                try:
                    result = await svc.trigger_task(uuid.UUID(task_id), trigger_source="manual")
                except ValueError:
                    return json.dumps({"error": f"Invalid task_id: {task_id!r}"})
                except Exception as e:
                    return json.dumps({"error": f"Task not found or trigger failed: {task_id} — {e}"})
                logger.info("mcp_task_triggered task_id=%s session_id=%s", task_id, result.session_id)
                return json.dumps({
                    "task_id": task_id,
                    "session_id": str(result.session_id),
                    "message": f"Task triggered. Session ID: {result.session_id}",
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("trigger_task_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def update_task_memory(task_id: str, memory: str) -> str:
        """Replace the full task memory content. Used by agents to persist knowledge across sessions.

        Args:
            task_id: UUID of the task
            memory: New task memory content (replaces existing)
        """
        try:
            async with async_session_factory() as db:
                svc = _make_service(db)
                try:
                    t = await svc.update_task(uuid.UUID(task_id), TaskUpdate(task_memory=memory))
                except ValueError:
                    return json.dumps({"error": f"Invalid task_id: {task_id!r}"})
                if not t:
                    return json.dumps({"error": f"Task not found: {task_id}"})
                await db.commit()
                logger.info("mcp_task_memory_updated task_id=%s", task_id)
                return json.dumps({"task_id": task_id, "message": "Task memory updated"})

        except ToolError:
            raise
        except Exception as e:
            logger.error("update_task_memory_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
