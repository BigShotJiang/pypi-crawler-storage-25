import json
import logging
import uuid

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError

from opspilot.context import get_project_id
from opspilot.database import async_session_factory
from opspilot.models.findings import FindingType
from opspilot.models.common import Severity
from opspilot.schemas.findings import FindingCreate
from opspilot.services import finding_service

logger = logging.getLogger(__name__)


def register(mcp: FastMCP):

    @mcp.tool()
    async def create_finding(
        finding_type: str,
        severity: str,
        title: str,
        summary: str,
        affected_components: list[str] | None = None,
        evidence: dict | None = None,
        recommendation: str | None = None,
        session_id: str | None = None,
    ) -> str:
        """Create a new finding (vulnerability, anomaly, cost spike, or recommendation).

        Args:
            finding_type: incident/anomaly/cost_spike/prediction/recommendation/auto_remediation
            severity: info/low/medium/high/critical
            title: Short descriptive title
            summary: Detailed summary with evidence
            affected_components: Affected services/resources
            evidence: Structured evidence dict
            recommendation: Recommended action
            session_id: Current session ID
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                data = FindingCreate(
                    session_id=uuid.UUID(session_id) if session_id else None,
                    finding_type=FindingType(finding_type),
                    severity=Severity(severity),
                    title=title,
                    summary=summary,
                    affected_components=affected_components,
                    evidence=evidence,
                    recommendation=recommendation,
                )
                f = await finding_service.create_finding(db, project_id, data)
                await db.commit()
                logger.info("finding_created id=%s severity=%s type=%s", f.id, severity, finding_type)
                return json.dumps({
                    "id": str(f.id), "title": f.title,
                    "severity": severity, "finding_type": finding_type,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("create_finding_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def search_findings(
        finding_type: str | None = None,
        severity: str | None = None,
        session_id: str | None = None,
        query: str | None = None,
        keyword: str | None = None,
        limit: int = 50,
        offset: int = 0,
        rerank: bool = False,
    ) -> str:
        """Search and list findings. Supports semantic search, keyword search, and filtering.

        Args:
            finding_type: Filter by type — incident/anomaly/cost_spike/prediction/recommendation/auto_remediation
            severity: Filter by severity — info/low/medium/high/critical
            session_id: Filter by session ID
            query: Semantic search query
            keyword: BM25 keyword search
            limit: Max results (default 50)
            offset: Pagination offset
            rerank: Re-rank results for relevance (default false)
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                if not project_id:
                    return json.dumps({"error": "No project context. Cannot search findings without project scope."})

                sid = uuid.UUID(session_id) if session_id else None
                sev = Severity(severity) if severity else None
                ft = FindingType(finding_type) if finding_type else None
                findings = await finding_service.list_findings(
                    db, project_id, session_id=sid, severity=sev, finding_type=ft,
                    query=query, keyword=keyword, limit=limit, offset=offset, rerank=rerank,
                )
                return json.dumps([{
                    "id": str(f.id), "title": f.title,
                    "severity": f.severity.value, "finding_type": f.finding_type.value,
                    "acknowledged": f.acknowledged,
                    "created_at": f.created_at.isoformat() if f.created_at else None,
                } for f in findings])

        except ToolError:
            raise
        except Exception as e:
            logger.error("search_findings_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))

    @mcp.tool()
    async def get_finding(finding_id: str) -> str:
        """Get full details of a finding by ID.

        Args:
            finding_id: UUID of the finding
        """
        try:
            async with async_session_factory() as db:
                project_id = get_project_id()
                f = await finding_service.get_finding(db, project_id, uuid.UUID(finding_id))
                if not f:
                    return json.dumps({"error": f"Finding {finding_id} not found"})
                return json.dumps({
                    "id": str(f.id), "title": f.title,
                    "severity": f.severity.value, "finding_type": f.finding_type.value,
                    "summary": f.summary, "recommendation": f.recommendation,
                    "affected_components": f.affected_components,
                    "evidence": f.evidence, "acknowledged": f.acknowledged,
                    "created_at": f.created_at.isoformat() if f.created_at else None,
                })

        except ToolError:
            raise
        except Exception as e:
            logger.error("get_finding_failed error=%s", e, exc_info=True)
            raise ToolError(str(e))
