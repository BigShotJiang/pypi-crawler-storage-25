from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from opspilot.database import Base

_enum_values = lambda e: [m.value for m in e]  # noqa: E731


class AlertGroupStatus(str, enum.Enum):
    COLLECTING = "collecting"
    DISPATCHED = "dispatched"
    RESOLVED = "resolved"


class AlertGroup(Base):
    __tablename__ = "alert_groups"
    __table_args__ = (
        Index("ix_alert_groups_task_fp_status", "task_id", "fingerprint", "status"),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    task_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False)
    fingerprint: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    status: Mapped[AlertGroupStatus] = mapped_column(
        Enum(AlertGroupStatus, values_callable=_enum_values, name="alertgroupstatusenum"),
        nullable=False,
        default=AlertGroupStatus.COLLECTING,
    )
    alerts: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    alert_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    window_expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    session_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    dispatched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
