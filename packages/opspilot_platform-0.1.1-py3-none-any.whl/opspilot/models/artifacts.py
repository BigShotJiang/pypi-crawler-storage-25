from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from opspilot.database import Base

_enum_values = lambda e: [m.value for m in e]  # noqa: E731


class ArtifactSourceType(str, enum.Enum):
    SESSION = "session"
    CONVERSATION = "conversation"


class ArtifactTrigger(str, enum.Enum):
    AUTO = "auto"
    MANUAL = "manual"


class Artifact(Base):
    __tablename__ = "artifacts"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    source_type: Mapped[ArtifactSourceType] = mapped_column(Enum(ArtifactSourceType, values_callable=_enum_values), nullable=False)
    session_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="SET NULL"), nullable=True)
    conversation_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="SET NULL"), nullable=True)
    trigger: Mapped[ArtifactTrigger] = mapped_column(Enum(ArtifactTrigger, values_callable=_enum_values), nullable=False, default=ArtifactTrigger.MANUAL)
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    archive_format: Mapped[str] = mapped_column(String(20), nullable=False, default="tar.gz")
    file_size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    original_size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    s3_key: Mapped[str] = mapped_column(String(500), unique=True, nullable=False)
    s3_url: Mapped[str] = mapped_column(String(1000), nullable=False)
    file_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    workspace_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    session: Mapped["Session | None"] = relationship(back_populates="artifacts")
    conversation: Mapped["Conversation | None"] = relationship(back_populates="artifacts")


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from opspilot.models.conversations import Conversation, Session
