from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from opspilot.database import Base

_enum_values = lambda e: [m.value for m in e]  # noqa: E731

from typing import TYPE_CHECKING

from opspilot.models.common import AgentType, TriggerSource

if TYPE_CHECKING:
    from opspilot.models.common import AgentType, TriggerSource
    from opspilot.models.tasks import Task
    from opspilot.models.integrations import GitRepo
    from opspilot.models.artifacts import Artifact


class SessionStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"



class MessageRole(str, enum.Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"



class ToolCallStatus(str, enum.Enum):
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"



class ConversationMcpServer(Base):
    __tablename__ = "conversation_mcp_servers"

    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), primary_key=True)
    mcp_server_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("mcp_servers.id", ondelete="CASCADE"), primary_key=True)



class ConversationMemoryFile(Base):
    __tablename__ = "conversation_memory_files"

    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), primary_key=True)
    memory_file_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("memory_files.id", ondelete="CASCADE"), primary_key=True)


class ConversationGitRepo(Base):
    __tablename__ = "conversation_git_repos"

    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), primary_key=True)
    git_repo_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("git_repos.id", ondelete="CASCADE"), primary_key=True)



class Session(Base):
    __tablename__ = "sessions"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    task_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("tasks.id", ondelete="SET NULL"), nullable=True)
    status: Mapped[SessionStatus] = mapped_column(Enum(SessionStatus, values_callable=_enum_values), default=SessionStatus.PENDING)
    agent_type: Mapped[AgentType] = mapped_column(Enum(AgentType, values_callable=_enum_values), nullable=False)
    system_prompt_snapshot: Mapped[str | None] = mapped_column(Text, nullable=True)
    prompt_snapshot: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    summary: Mapped[str | None] = mapped_column(Text)
    findings_count: Mapped[int] = mapped_column(Integer, default=0)
    error_message: Mapped[str | None] = mapped_column(Text)
    error_details: Mapped[str | None] = mapped_column(Text)
    raw_output_path: Mapped[str | None] = mapped_column(Text)
    workspace_path: Mapped[str | None] = mapped_column(Text)
    trigger_source: Mapped[TriggerSource] = mapped_column(String(20), default=TriggerSource.MANUAL, server_default="manual")
    idempotency_key: Mapped[str | None] = mapped_column(String(255), unique=True, index=True)
    git_clone_results: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    agent_native_session_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    task: Mapped["Task | None"] = relationship(back_populates="sessions")
    messages: Mapped[list["Message"]] = relationship(back_populates="session", order_by="Message.sequence")
    tool_calls: Mapped[list["ToolCall"]] = relationship(back_populates="session", order_by="ToolCall.sequence")
    findings: Mapped[list["Finding"]] = relationship(back_populates="session", order_by="Finding.created_at")
    reports: Mapped[list["Report"]] = relationship(back_populates="session", order_by="Report.created_at")
    incidents: Mapped[list["Incident"]] = relationship(back_populates="session", order_by="Incident.created_at")
    skills: Mapped[list["Skill"]] = relationship(back_populates="session", order_by="Skill.created_at")
    runbooks: Mapped[list["Runbook"]] = relationship(back_populates="session", order_by="Runbook.created_at")
    notification_logs: Mapped[list["NotificationLog"]] = relationship(back_populates="session", order_by="NotificationLog.sent_at")
    knowledge_entries: Mapped[list["KnowledgeEntry"]] = relationship(back_populates="session", order_by="KnowledgeEntry.created_at")
    artifacts: Mapped[list["Artifact"]] = relationship(back_populates="session", order_by="Artifact.created_at")
    approvals: Mapped[list["Approval"]] = relationship(back_populates="session", order_by="Approval.created_at")

    def start(self) -> None:
        """Domain logic to start a session."""
        if self.status != SessionStatus.PENDING:
            raise ValueError(f"Cannot start session in status {self.status}")
        self.status = SessionStatus.RUNNING
        self.started_at = func.now()

    def complete(self, summary: str, input_tokens: int = 0, output_tokens: int = 0, cost_usd: float = 0.0) -> None:
        """Domain logic to complete a session."""
        if self.status != SessionStatus.RUNNING:
            raise ValueError(f"Cannot complete session in status {self.status}")
        self.status = SessionStatus.COMPLETED
        self.finished_at = func.now()
        self.summary = summary
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.total_tokens = input_tokens + output_tokens
        self.cost_usd = cost_usd

    def fail(self, error_message: str, error_details: str | None = None) -> None:
        """Domain logic to fail a session."""
        self.status = SessionStatus.FAILED
        self.finished_at = func.now()
        self.error_message = error_message
        self.error_details = error_details



class Message(Base):
    __tablename__ = "messages"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False)
    role: Mapped[MessageRole] = mapped_column(Enum(MessageRole, values_callable=_enum_values), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    session: Mapped[Session] = relationship(back_populates="messages")



class ToolCall(Base):
    __tablename__ = "tool_calls"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False)
    tool_name: Mapped[str] = mapped_column(String(255), nullable=False)
    tool_server: Mapped[str | None] = mapped_column(String(255))
    input_params: Mapped[dict | None] = mapped_column(JSONB)
    output_result: Mapped[str | None] = mapped_column(Text)
    status: Mapped[ToolCallStatus] = mapped_column(Enum(ToolCallStatus, values_callable=_enum_values), default=ToolCallStatus.RUNNING)
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    session: Mapped[Session] = relationship(back_populates="tool_calls")



class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False, default="New Chat")
    agent_type: Mapped[AgentType] = mapped_column(Enum(AgentType, values_callable=_enum_values), default=AgentType.CLAUDE_CODE)
    system_prompt: Mapped[str] = mapped_column(Text, nullable=False, default="You are a helpful DevOps assistant.")
    agent_settings: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    pre_run_context: Mapped[dict] = mapped_column(JSONB, nullable=False, default=lambda: {"inject_skills": True}, server_default='{"inject_skills": true}')
    agent_native_session_id: Mapped[str | None] = mapped_column(String(255))  # for --resume on next turn
    total_input_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    total_output_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    total_cost_usd: Mapped[float] = mapped_column(nullable=False, default=0.0, server_default="0.0")
    git_clone_results: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    messages: Mapped[list["ConversationMessage"]] = relationship(back_populates="conversation", order_by="ConversationMessage.sequence", cascade="all, delete-orphan", passive_deletes=True)
    tool_calls: Mapped[list["ConversationToolCall"]] = relationship(back_populates="conversation", order_by="ConversationToolCall.sequence", cascade="all, delete-orphan", passive_deletes=True)
    mcp_servers: Mapped[list["McpServer"]] = relationship(secondary="conversation_mcp_servers")
    memory_files: Mapped[list["MemoryFile"]] = relationship(secondary="conversation_memory_files")
    git_repos: Mapped[list["GitRepo"]] = relationship(secondary="conversation_git_repos")
    artifacts: Mapped[list["Artifact"]] = relationship(back_populates="conversation", order_by="Artifact.created_at")



class ConversationMessage(Base):
    __tablename__ = "conversation_messages"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role: Mapped[MessageRole] = mapped_column(Enum(MessageRole, values_callable=_enum_values), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    attachments: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    turn_sequence: Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # which user turn
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")  # pending|success|failed
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation: Mapped[Conversation] = relationship(back_populates="messages")



class ConversationToolCall(Base):
    __tablename__ = "conversation_tool_calls"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    turn_sequence: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    tool_name: Mapped[str] = mapped_column(String(255), nullable=False)
    tool_server: Mapped[str | None] = mapped_column(String(255))
    input_params: Mapped[dict | None] = mapped_column(JSONB)
    output_result: Mapped[str | None] = mapped_column(Text)
    status: Mapped[ToolCallStatus] = mapped_column(Enum(ToolCallStatus, values_callable=_enum_values), default=ToolCallStatus.RUNNING)
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation: Mapped[Conversation] = relationship(back_populates="tool_calls")


# --- Connected Accounts (OAuth) ---

