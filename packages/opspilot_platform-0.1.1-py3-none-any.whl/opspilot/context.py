from contextvars import ContextVar
from uuid import UUID

_project_id: ContextVar[UUID | None] = ContextVar("project_id", default=None)


def get_project_id() -> UUID | None:
    """Return the current project ID from the request context."""
    return _project_id.get()


def set_project_id(value: UUID | None) -> None:
    """Set the current project ID in the request context."""
    _project_id.set(value)
