import logging

import sqlalchemy as sa
from sqlalchemy import select

from opspilot.config import settings
from opspilot.database import async_session_factory
from opspilot.defaults import GLOBAL_SYSTEM_PROMPT
from opspilot.models import McpServer, TaskTemplate
from opspilot.models import AgentType, Setting

logger = logging.getLogger(__name__)

TEMPLATES = [
    {
        "name": "Cluster Health Monitor",
        "slug": "cluster-health-monitor",
        "description": "Comprehensive health check of Kubernetes clusters including pods, nodes, resources, events, and ArgoCD sync status.",
        "default_cron": "0 */6 * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",  # Loaded from prompts/ at runtime
        "default_mcp_servers": ["prometheus", "loki", "opspilot", "opspilot-notify"],
        "default_timeout_seconds": 600,
        "icon": "heart-pulse",
        "color": "green",
    },
    {
        "name": "Incident Detector",
        "slug": "incident-detector",
        "description": "Analyze metrics and logs for anomalies, error spikes, and potential incidents. Generates RCA reports for detected issues.",
        "default_cron": "*/15 * * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["prometheus", "loki", "tempo", "opspilot", "opspilot-notify"],
        "default_timeout_seconds": 300,
        "icon": "alert-triangle",
        "color": "red",
    },
    {
        "name": "Change Correlator",
        "slug": "change-correlator",
        "description": "Correlate incidents with recent Git commits, ArgoCD syncs, and deployments to identify change-induced failures.",
        "default_cron": "*/30 * * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["prometheus", "loki", "opspilot", "opspilot-notify"],
        "default_timeout_seconds": 300,
        "icon": "git-compare",
        "color": "purple",
    },
    {
        "name": "Cost Monitor",
        "slug": "cost-monitor",
        "description": "Analyze GCP billing, resource utilization, and identify cost spikes, idle resources, and optimization opportunities.",
        "default_cron": "0 8 * * 1",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["prometheus", "opspilot", "opspilot-notify"],
        "default_timeout_seconds": 900,
        "icon": "dollar-sign",
        "color": "yellow",
    },
    {
        "name": "Predictive Alerter",
        "slug": "predictive-alerter",
        "description": "Trend analysis on key metrics to predict threshold breaches before they happen. Alert on projected issues.",
        "default_cron": "0 */4 * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["prometheus", "opspilot", "opspilot-notify"],
        "default_timeout_seconds": 600,
        "icon": "trending-up",
        "color": "orange",
    },
    {
        "name": "Auto-Remediator",
        "slug": "auto-remediator",
        "description": "Execute pre-approved fixes via GitOps PRs: restart stuck pods, scale up on load, clear caches, etc.",
        "default_cron": "*/10 * * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["prometheus", "loki", "opspilot", "opspilot-notify"],
        "default_timeout_seconds": 300,
        "icon": "wrench",
        "color": "blue",
    },
    {
        "name": "Alert Investigator",
        "slug": "alert-investigator",
        "description": "Investigates incoming webhook alerts with automatic correlation, runbook matching, and structured triage. Infrastructure-agnostic — configure your monitoring tools and environment details in the task prompt.",
        "default_cron": "",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["opspilot", "opspilot-notify"],
        "default_timeout_seconds": 600,
        "icon": "bell-ring",
        "color": "red",
    },
    {
        "name": "Custom Task",
        "slug": "custom",
        "description": "A blank template for any custom agent task. Define your own prompt, schedule, and tools.",
        "default_cron": "0 * * * *",
        "default_agent_type": AgentType.CLAUDE_CODE,
        "system_prompt": "",
        "default_mcp_servers": ["opspilot", "opspilot-notify", "opspilot-google"],
        "default_timeout_seconds": 600,
        "icon": "settings",
        "color": "gray",
    },
    {
        "name": "Memory Extractor",
        "slug": "memory-extractor",
        "description": "Mines recent conversations and agent sessions to extract and persist facts, preferences, procedures, and entity knowledge into agent memory.",
        "default_cron": "0 * * * *",
        "default_agent_type": AgentType.CODEX,
        "system_prompt": "You are a memory extraction agent for the OpsPilot platform. Your only job is to read recent agent sessions and chat conversations, extract structured facts from them, and persist those facts into the memory store using the memory MCP tool. Be precise, avoid duplicates, and use upsert semantics — calling memory create with the same entity_type/entity_key/key simply updates the existing record. Do not create findings, incidents, or reports. Only use the memory, session, and conversation MCP tools.",
        "default_mcp_servers": ["opspilot"],
        "default_timeout_seconds": 300,
        "icon": "brain",
        "color": "purple",
    },
]


_TEMPLATE_SYNC_FIELDS = (
    "name", "description", "default_cron", "default_agent_type",
    "system_prompt", "default_mcp_servers", "default_timeout_seconds", "icon", "color",
)


async def seed_templates():
    """Seed task templates for all projects."""
    logger.debug("seed_templates_start")
    async with async_session_factory() as session:
        created_count = 0
        updated_count = 0

        # Get all projects
        result = await session.execute(select(sa.func.distinct(TaskTemplate.project_id)).select_from(TaskTemplate))
        all_project_ids = [row[0] for row in result if row[0]]

        for project_id in all_project_ids:
            for tmpl_data in TEMPLATES:
                stmt = select(TaskTemplate).where(
                    TaskTemplate.project_id == project_id,
                    TaskTemplate.slug == tmpl_data["slug"]
                )
                result = await session.execute(stmt)
                existing = result.scalar_one_or_none()
                if not existing:
                    session.add(TaskTemplate(**tmpl_data, project_id=project_id))
                    created_count += 1
                else:
                    for field in _TEMPLATE_SYNC_FIELDS:
                        if field in tmpl_data:
                            setattr(existing, field, tmpl_data[field])
                    updated_count += 1

        await session.commit()
        logger.info("seed_templates_completed created=%s updated=%s total=%s", created_count, updated_count, len(TEMPLATES))


DEFAULT_SETTINGS = [
    {"key": "brand_name",           "value": "OpsPilot",                    "description": "Customer-facing brand name"},
    {"key": "brand_tagline",        "value": "Agentic Operations Platform", "description": "Short marketing tagline"},
    {"key": "brand_logo_url",       "value": "",                            "description": "Brand logo URL"},
    {"key": "brand_favicon_url",    "value": "",                            "description": "Favicon URL"},
    {"key": "brand_background_url", "value": "",                            "description": "Background watermark image URL"},
    {"key": "theme_preset",         "value": "darkGold",                    "description": "Selected theme preset"},
    {"key": "theme_mode",           "value": "dark",                        "description": "light or dark"},
    {"key": "theme_primary",        "value": "#d4af37",                     "description": "Primary color"},
    {"key": "theme_background",     "value": "#050505",                     "description": "Background color"},
    {"key": "theme_accent",         "value": "#0f0f17",                     "description": "Accent color"},
    {"key": "theme_border",         "value": "#1f1f28",                     "description": "Border color"},
    {"key": "theme_muted",          "value": "#11131a",                     "description": "Muted surface color"},
    # AI Agent
    {"key": "global_system_prompt", "value": GLOBAL_SYSTEM_PROMPT, "description": "Global system prompt prepended to every agent session — gives the agent identity, personality, and platform context"},
    # Notifications
    {"key": "slack_webhook_url",    "value": "",                            "description": "Slack incoming webhook URL for notifications"},
    {"key": "email_recipients",     "value": "",                            "description": "Comma-separated email addresses for notifications"},
    {"key": "pushover_user_key",    "value": "",                            "description": "Pushover user key for push notifications"},
    {"key": "pushover_api_token",   "value": "",                            "description": "Pushover application API token"},
]


async def seed_default_settings():
    """Legacy settings seeding - deprecated.

    Settings are now project-scoped via ProjectSettings table.
    The migration backfills from old settings table.
    ProjectSettings are auto-created with defaults on first access via get_or_create_default_settings.
    """
    logger.debug("seed_default_settings_skipped - settings are now project-scoped")


INTERNAL_MCP_SERVERS = [
    {
        "name": "OpsPilot Core",
        "slug": "opspilot",
        "description": "Core ops tools: incidents, findings, reports, skills, todos, file storage",
        "transport": "http",
        "url_path": "/mcp/core/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Notify",
        "slug": "opspilot-notify",
        "description": "Notification tools: Slack, email, Pushover, and scheduled reminders",
        "transport": "http",
        "url_path": "/mcp/notify/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Google",
        "slug": "opspilot-google",
        "description": "Google Workspace tools: Gmail, Calendar, and Drive",
        "transport": "http",
        "url_path": "/mcp/google/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Jira",
        "slug": "opspilot-jira",
        "description": "Jira tools: list projects, search issues via JQL, get issue details",
        "transport": "http",
        "url_path": "/mcp/jira/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Confluence",
        "slug": "opspilot-confluence",
        "description": "Confluence tools: list spaces, search pages via CQL, get page content",
        "transport": "http",
        "url_path": "/mcp/confluence/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Microsoft",
        "slug": "opspilot-microsoft",
        "description": "Microsoft 365 tools: Outlook mail, Calendar, and OneDrive",
        "transport": "http",
        "url_path": "/mcp/microsoft/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Slack",
        "slug": "opspilot-slack",
        "description": "Slack workspace tools: list channels, read messages, and threads",
        "transport": "http",
        "url_path": "/mcp/slack/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot WhatsApp",
        "slug": "opspilot-whatsapp",
        "description": "WhatsApp tools: list groups, list contacts, and read message history",
        "transport": "http",
        "url_path": "/mcp/whatsapp/mcp",
        "is_internal": True,
        "enabled": True,
    },
    {
        "name": "OpsPilot Task Automation",
        "slug": "opspilot-tasks",
        "description": "Create, list, update, trigger, and delete automation tasks.",
        "transport": "http",
        "url_path": "/mcp/tasks/mcp",
        "is_internal": True,
        "enabled": False,
    },
]


async def seed_mcp_servers_for_project(db, project_id):
    """Seed internal MCP servers for a specific project."""
    for _srv in INTERNAL_MCP_SERVERS:
        srv_data = dict(_srv)
        url_path = srv_data.pop("url_path")
        full_url = f"{settings.api_base_url}{url_path}"
        stmt = select(McpServer).where(
            McpServer.project_id == project_id,
            McpServer.slug == srv_data["slug"]
        )
        existing = (await db.execute(stmt)).scalar_one_or_none()
        if not existing:
            db.add(McpServer(
                **srv_data,
                project_id=project_id,
                url=full_url,
                command="",
            ))
            logger.info("seed_mcp_server_for_project project_id=%s slug=%s", project_id, srv_data["slug"])


async def seed_task_templates_for_project(db, project_id):
    """Seed task templates for a specific project."""
    for tmpl in TEMPLATES:
        tmpl_data = dict(tmpl)
        stmt = select(TaskTemplate).where(
            TaskTemplate.project_id == project_id,
            TaskTemplate.slug == tmpl_data["slug"]
        )
        existing = (await db.execute(stmt)).scalar_one_or_none()
        if not existing:
            db.add(TaskTemplate(
                **tmpl_data,
                project_id=project_id,
            ))
            logger.info("seed_task_template_for_project project_id=%s slug=%s", project_id, tmpl_data["slug"])


async def seed_internal_mcp_servers():
    """Seed internal MCP servers for all projects."""
    async with async_session_factory() as session:
        # Get all projects
        result = await session.execute(select(sa.func.distinct(McpServer.project_id)).select_from(McpServer))
        project_ids = [row[0] for row in result if row[0]]  # Get actual project IDs that have servers

        # For each project, ensure all internal servers exist
        if project_ids:
            for project_id in project_ids:
                await seed_mcp_servers_for_project(session, project_id)

        await session.commit()
