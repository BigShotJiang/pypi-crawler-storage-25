import logging
import time
import traceback
import uuid
from contextlib import asynccontextmanager
from uuid import UUID as PyUUID

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.base import BaseHTTPMiddleware

from opspilot.context import set_project_id

from opspilot.api import api_router
from opspilot.channels import ChannelManager
from opspilot.config import settings
from opspilot.logging_setup import configure_logging, trace_id_var
from opspilot.mcp_internal import create_confluence_server, create_core_server, create_google_server, create_jira_server, create_microsoft_server, create_notify_server, create_slack_server, create_tasks_server, create_whatsapp_server
from opspilot.seed import seed_default_settings, seed_internal_mcp_servers, seed_templates
from opspilot.services import health_service

configure_logging()
logger = logging.getLogger(__name__)

mcp_core = create_core_server()
mcp_notify = create_notify_server()
mcp_google = create_google_server()
mcp_slack = create_slack_server()
mcp_jira = create_jira_server()
mcp_confluence = create_confluence_server()
mcp_microsoft = create_microsoft_server()
mcp_tasks = create_tasks_server()
mcp_whatsapp = create_whatsapp_server()
mcp_core_app = mcp_core.http_app(path="", stateless_http=True)
mcp_notify_app = mcp_notify.http_app(path="", stateless_http=True)
mcp_google_app = mcp_google.http_app(path="", stateless_http=True)
mcp_slack_app = mcp_slack.http_app(path="", stateless_http=True)
mcp_jira_app = mcp_jira.http_app(path="", stateless_http=True)
mcp_confluence_app = mcp_confluence.http_app(path="", stateless_http=True)
mcp_microsoft_app = mcp_microsoft.http_app(path="", stateless_http=True)
mcp_tasks_app = mcp_tasks.http_app(path="", stateless_http=True)
mcp_whatsapp_app = mcp_whatsapp.http_app(path="", stateless_http=True)

channel_manager = ChannelManager()


class MCPProjectMiddleware(BaseHTTPMiddleware):
    """Middleware to set project context from X-Project-ID header for MCP requests."""

    async def dispatch(self, request: Request, call_next):
        # Accept project_id from header (Claude/Gemini) or query param (Codex, which
        # doesn't support custom HTTP headers on MCP servers).
        pid_str = request.headers.get("X-Project-ID") or request.query_params.get("project_id")
        if pid_str:
            try:
                set_project_id(PyUUID(pid_str))
            except (ValueError, TypeError):
                logger.warning("invalid_project_id_header value=%s", pid_str)
                set_project_id(None)
        else:
            set_project_id(None)
        return await call_next(request)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("starting_app")
    async with mcp_core_app.lifespan(mcp_core_app):
        async with mcp_notify_app.lifespan(mcp_notify_app):
            async with mcp_google_app.lifespan(mcp_google_app):
                async with mcp_slack_app.lifespan(mcp_slack_app):
                    async with mcp_jira_app.lifespan(mcp_jira_app):
                        async with mcp_confluence_app.lifespan(mcp_confluence_app):
                          async with mcp_microsoft_app.lifespan(mcp_microsoft_app):
                            async with mcp_tasks_app.lifespan(mcp_tasks_app):
                                async with mcp_whatsapp_app.lifespan(mcp_whatsapp_app):
                                    await seed_templates()
                                    await seed_default_settings()
                                    await seed_internal_mcp_servers()
                                    logger.info("seed_completed")
                                    # Pre-warm fastembed model so first semantic search isn't slow
                                    try:
                                        from opspilot.services.embeddings import embed_query_async
                                        await embed_query_async("warmup")
                                        logger.info("embedding_model_warmed")
                                    except Exception:
                                        logger.warning("embedding_model_warmup_failed", exc_info=True)
                                    await channel_manager.start()
                                    app.state.channel_manager = channel_manager
                                    yield
                                    await channel_manager.stop()
    logger.info("shutting_down_app")


app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)

# Add project context middleware to MCP apps
for mcp_app in [mcp_core_app, mcp_notify_app, mcp_google_app, mcp_slack_app, mcp_jira_app, mcp_confluence_app, mcp_microsoft_app, mcp_tasks_app, mcp_whatsapp_app]:
    mcp_app.add_middleware(MCPProjectMiddleware)

app.mount("/mcp/core", mcp_core_app)
app.mount("/mcp/notify", mcp_notify_app)
app.mount("/mcp/google", mcp_google_app)
app.mount("/mcp/slack", mcp_slack_app)
app.mount("/mcp/jira", mcp_jira_app)
app.mount("/mcp/confluence", mcp_confluence_app)
app.mount("/mcp/microsoft", mcp_microsoft_app)
app.mount("/mcp/tasks", mcp_tasks_app)
app.mount("/mcp/whatsapp", mcp_whatsapp_app)


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    req_id = request.headers.get("X-Request-Id", str(uuid.uuid4()))
    trace_id_var.set(req_id)

    start = time.perf_counter()
    logger.debug("request_started method=%s path=%s", request.method, request.url.path)
    try:
        response = await call_next(request)
        response.headers["X-Trace-Id"] = req_id
    except Exception as e:
        elapsed_ms = int((time.perf_counter() - start) * 1000)
        logger.exception(
            "request_failed method=%s path=%s elapsed_ms=%s error=%s",
            request.method,
            request.url.path,
            elapsed_ms,
            str(e),
        )
        raise

    elapsed_ms = int((time.perf_counter() - start) * 1000)
    logger.info(
        "request_completed method=%s path=%s status=%s elapsed_ms=%s",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    return response


_PROJECT_EXEMPT = (
    "/health",
    "/docs",
    "/openapi.json",
    "/redoc",
    "/favicon.ico",
    "/api/projects",
    "/api/oauth/callback",
    "/api/webhooks",
    "/api/telegram",
    "/api/slack",
    "/api/voice",
    "/mcp",  # MCP endpoints from Claude Code - may not send X-Project-ID header
)


def _is_exempt(path: str) -> bool:
    """Check if path is exempt from X-Project-ID requirement."""
    if any(path.startswith(p) for p in _PROJECT_EXEMPT):
        return True
    # Approval detail/approve/reject endpoints are exempt (links from notifications)
    # but the list endpoint (/api/approvals) requires project scope
    if path.startswith("/api/approvals/"):
        return True
    return False


@app.middleware("http")
async def project_middleware(request: Request, call_next):
    if not _is_exempt(request.url.path):
        pid_str = request.headers.get("X-Project-ID") or request.query_params.get("project_id")
        if not pid_str:
            return JSONResponse(
                status_code=422,
                content={"detail": "X-Project-ID header is required"},
            )
        try:
            set_project_id(PyUUID(pid_str))
        except ValueError:
            return JSONResponse(
                status_code=422,
                content={"detail": "X-Project-ID header must be a valid UUID"},
            )
    else:
        set_project_id(None)
    return await call_next(request)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    trace_id = trace_id_var.get()
    logger.exception(
        "unhandled_exception method=%s path=%s error=%s trace_id=%s",
        request.method,
        request.url.path,
        str(exc),
        trace_id,
    )
    body = {
        "error": "Internal server error",
        "message": str(exc),
        "trace_id": trace_id,
    }
    if settings.debug:
        body["details"] = traceback.format_exc()

    return JSONResponse(status_code=500, content=body)


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    trace_id = trace_id_var.get()
    body = {
        "error": exc.detail,
        "trace_id": trace_id,
    }
    return JSONResponse(status_code=exc.status_code, content=body)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    trace_id = trace_id_var.get()
    body = {
        "error": "Validation error",
        "details": exc.errors(),
        "trace_id": trace_id,
    }
    return JSONResponse(status_code=422, content=body)


@app.get("/health/live", tags=["health"])
async def liveness():
    """Process is alive. Always 200 if the process is running."""
    return {"status": "ok"}

@app.get("/health/ready", tags=["health"])
async def readiness():
    """All dependencies are reachable. Returns 503 if any dependency is down."""
    ok, checks = await health_service.readiness()
    body = {
        "status": "ready" if ok else "degraded",
        "checks": [
            {
                "name": c.name,
                "ok": c.ok,
                "latency_ms": round(c.latency_ms, 1),
                "error": c.error
            } for c in checks
        ],
    }
    return JSONResponse(status_code=200 if ok else 503, content=body)

@app.get("/health", include_in_schema=False)
async def health():
    return RedirectResponse(url="/health/live")


def _resolve_frontend_dir() -> Path | None:
    """Resolve frontend static directory: installed package, then dev repo fallback."""
    env_dir = settings.frontend_dir
    if env_dir:
        p = Path(env_dir)
        return p if p.is_dir() else None
    # 1. Installed package: opspilot/frontend_static/
    pkg = Path(__file__).resolve().parent / "frontend_static"
    if pkg.is_dir():
        return pkg
    # 2. Dev repo: backend/../frontend/out/
    repo = Path(__file__).resolve().parent.parent.parent / "frontend" / "out"
    return repo if repo.is_dir() else None


def _mount_frontend() -> None:
    """Mount static Next.js export under /ui if available."""
    frontend_dir = _resolve_frontend_dir()
    if frontend_dir is None or not frontend_dir.is_dir():
        return

    index_html = frontend_dir / "index.html"
    if not index_html.is_file():
        logger.warning("Frontend dir %s has no index.html — skipping", frontend_dir)
        return

    next_dir = frontend_dir / "_next"
    if next_dir.is_dir():
        app.mount("/ui/_next", StaticFiles(directory=next_dir), name="next-static")

    @app.get("/ui/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str) -> FileResponse:
        if full_path and ".." not in full_path:
            requested = frontend_dir / full_path
            if requested.is_file():
                return FileResponse(requested)
            html_file = frontend_dir / f"{full_path}.html"
            if html_file.is_file():
                return FileResponse(html_file)
            parts = full_path.split("/")
            for i in range(len(parts), 0, -1):
                wildcard = frontend_dir / "/".join(parts[: i - 1]) / "_.html"
                if wildcard.is_file():
                    return FileResponse(wildcard)
        return FileResponse(index_html)

    @app.get("/ui", include_in_schema=False)
    async def ui_root() -> FileResponse:
        return FileResponse(index_html)

    logger.info("Frontend mounted at /ui from %s", frontend_dir)


_mount_frontend()
