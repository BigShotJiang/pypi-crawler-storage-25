"""
Event Client for the Soorma SDK.

This module provides an EventClient class that connects to the Soorma Event Service
using Server-Sent Events (SSE) for real-time event streaming and HTTP for publishing.

The SDK abstracts away the underlying message bus (NATS, Kafka, etc.), providing
a clean interface for agents to publish and subscribe to events.

Usage:
    from soorma.events import EventClient

    # Create client
    client = EventClient(
        event_service_url="http://localhost:8082",
        agent_id="my-agent",
    )

    # Define event handlers
    @client.on_event("research.requested")
    async def handle_research(event):
        print(f"Got research request: {event['data']}")

    # Connect and start receiving events
    await client.connect(topics=["research.*", "action-requests"])

    # Publish events
    await client.publish(
        event_type="research.completed",
        topic="action-results",
        data={"result": "Analysis complete"},
    )
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional, Union
from uuid import uuid4

from .auth import AuthTokenProvider, resolve_auth_token
from soorma_common.events import EventEnvelope, EventTopic

logger = logging.getLogger(__name__)

# Type alias for event handlers
EventHandler = Callable[[EventEnvelope], Awaitable[None]]


class EventClient:
    """
    Client for publishing and subscribing to events via the Soorma Event Service.
    
    This client:
    - Uses HTTP POST for publishing events
    - Uses SSE (Server-Sent Events) for real-time event subscription
    - Handles auto-reconnection with exponential backoff
    - Dispatches events to registered handlers
    
    Attributes:
        event_service_url: Base URL of the Event Service
        agent_id: Unique identifier for this agent
        source: Source identifier for published events (defaults to agent_id)
    """
    
    def __init__(
        self,
        event_service_url: str = "http://localhost:8082",
        agent_id: Optional[str] = None,
        source: Optional[str] = None,
        auth_token: Optional[str] = None,
        auth_token_provider: Optional[AuthTokenProvider] = None,
        platform_tenant_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        session_id: Optional[str] = None,
        events_consumed: Optional[List[Any]] = None,
        max_reconnect_attempts: int = -1,  # -1 = infinite
        reconnect_base_delay: float = 1.0,
        reconnect_max_delay: float = 60.0,
    ):
        """
        Initialize the EventClient.
        
        Args:
            event_service_url: Base URL of the Event Service (e.g., "http://localhost:8082")
            agent_id: Unique identifier for this agent (auto-generated if not provided)
            source: Source identifier for events (defaults to agent_id)
            platform_tenant_id: Optional explicit platform tenant value retained
                only for envelope metadata compatibility.
            tenant_id: Default tenant ID for multi-tenancy
            session_id: Default session ID for correlation
            events_consumed: Optional list of EventDefinition objects to auto-register
                with the Registry on connect (inline schemas are registered too).
            max_reconnect_attempts: Max reconnection attempts (-1 for infinite)
            reconnect_base_delay: Initial delay between reconnection attempts (seconds)
            reconnect_max_delay: Maximum delay between reconnection attempts (seconds)
        """
        self.event_service_url = event_service_url.rstrip("/")
        self.agent_id = agent_id or f"agent-{str(uuid4())[:8]}"
        self.source = source or self.agent_id
        self.auth_token = auth_token
        self.auth_token_provider = auth_token_provider
        self.platform_tenant_id = platform_tenant_id
        self.tenant_id = tenant_id
        self.session_id = session_id
        
        # Reconnection settings
        self._max_reconnect_attempts = max_reconnect_attempts
        self._reconnect_base_delay = reconnect_base_delay
        self._reconnect_max_delay = reconnect_max_delay
        
        # Connection state
        self._connected = False
        self._connection_id: Optional[str] = None
        self._subscribed_topics: List[str] = []
        self._stream_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()
        
        # Event handlers: event_type -> list of handlers
        self._handlers: Dict[str, List[EventHandler]] = {}
        # Catch-all handlers (receive all events)
        self._catch_all_handlers: List[EventHandler] = []
        
        # HTTP client (lazy initialized)
        self._http_client = None

        # EventDefinitions to auto-register with the Registry on connect()
        self._pending_event_definitions: List[Any] = []
        if events_consumed:
            for e in events_consumed:
                if hasattr(e, "event_name"):
                    self._pending_event_definitions.append(e)

    def set_auth_token(self, auth_token: Optional[str]) -> None:
        """Inject or replace bearer token for event-service requests."""
        self.auth_token = auth_token

    def set_auth_token_provider(self, auth_token_provider: Optional[AuthTokenProvider]) -> None:
        """Inject or replace bearer token provider for event-service requests."""
        self.auth_token_provider = auth_token_provider

    async def _build_auth_headers(self) -> dict[str, str]:
        """Build outbound auth headers for event-service calls."""
        token = await resolve_auth_token(self.auth_token, self.auth_token_provider)
        if not token:
            return {}
        return {"Authorization": f"Bearer {token}"}
    
    # =========================================================================
    # Decorator for registering handlers
    # =========================================================================
    
    def on_event(
        self,
        event_type: str,
        *,
        topic: Optional[EventTopic] = None,
    ) -> Callable[[EventHandler], EventHandler]:
        """
        Decorator to register an event handler for a specific event type.
        
        Usage:
            @client.on_event("research.requested", topic=EventTopic.ACTION_REQUESTS)
            async def handle_research(event: EventEnvelope):
                print(f"Received: {event.type}, data: {event.data}")
        
        Args:
            event_type: The event type to handle (e.g., "research.requested")
            topic: Optional topic (for consistency with Agent.on_event(), not yet enforced)
        
        Returns:
            Decorator function
        """
        def decorator(func: EventHandler) -> EventHandler:
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            self._handlers[event_type].append(func)
            logger.debug(f"Registered handler for event type: {event_type}")
            return func
        return decorator
    
    def on_all_events(self, func: EventHandler) -> EventHandler:
        """
        Decorator to register a catch-all event handler.
        
        Usage:
            @client.on_all_events
            async def handle_all(event: EventEnvelope):
                print(f"Received: {event.type}")
        
        Args:
            func: The handler function
        
        Returns:
            The handler function
        """
        self._catch_all_handlers.append(func)
        logger.debug("Registered catch-all handler")
        return func
    
    # =========================================================================
    # Connection Management
    # =========================================================================
    
    async def connect(self, topics: List[Union[EventTopic, str]]) -> None:
        """
        Connect to the Event Service and start receiving events.
        
        This method:
        1. Establishes an SSE connection to the Event Service
        2. Subscribes to the specified topics
        3. Starts a background task to process incoming events
        
        Note: If topics list is empty, no SSE connection is established.
        This is useful for publish-only clients.
        
        Args:
            topics: List of topics (EventTopic enum) or patterns (str for wildcards like "research.*")
        
        Raises:
            ConnectionError: If unable to connect to the Event Service
        """
        if self._connected:
            logger.warning("Already connected")
            return

        # Auto-register event definitions (+ inline schemas) with Registry
        if self._pending_event_definitions:
            await self._register_event_definitions()

        # Convert EventTopic enums to strings
        self._subscribed_topics = [t.value if isinstance(t, EventTopic) else t for t in topics]
        
        # If no topics, skip SSE connection (publish-only mode)
        if not self._subscribed_topics:
            logger.info("No topics to subscribe to, skipping SSE connection (publish-only mode)")
            self._connected = True  # Mark as connected for publish to work
            return
        
        self._stop_event.clear()
        
        # Start the SSE stream task
        self._stream_task = asyncio.create_task(self._run_stream())
        
        # Wait briefly for connection to establish
        await asyncio.sleep(0.5)
        
        if not self._connected:
            logger.warning("Connection not yet established, will retry in background")
    
    async def _register_event_definitions(self) -> None:
        """Auto-register event definitions (and inline schemas) with the Registry.

        Called automatically by connect() when events_consumed was supplied.
        Mirrors the auto-registration performed by BaseAgent at startup.
        Failures are non-fatal — logged as warnings.
        """
        import os as _os
        from soorma.registry.client import RegistryClient
        from soorma_common import PayloadSchema

        registry_url = _os.getenv("SOORMA_REGISTRY_URL", "http://localhost:8081")
        registry_client = RegistryClient(
            base_url=registry_url,
            auth_token=self.auth_token,
            auth_token_provider=self.auth_token_provider,
        )

        for event_def in self._pending_event_definitions:
            # Register event definition
            try:
                await registry_client.register_event(event_def)
                logger.debug(f"EventClient: registered event '{event_def.event_name}'")
            except Exception as e:
                status = getattr(getattr(e, "response", None), "status_code", None)
                if status == 409:
                    logger.debug(f"EventClient: event '{event_def.event_name}' already registered")
                else:
                    logger.warning(f"EventClient: failed to register event '{event_def.event_name}': {e}")

            # Register inline schema if present
            schema_name = getattr(event_def, "payload_schema_name", None)
            inline_body = getattr(event_def, "payload_schema", None)
            if schema_name and inline_body:
                try:
                    schema = PayloadSchema(
                        schema_name=schema_name,
                        version=getattr(event_def, "version", "1.0.0") or "1.0.0",
                        json_schema=inline_body,
                        description=getattr(event_def, "description", None),
                        owner_agent_id=self.agent_id,
                    )
                    await registry_client.register_schema(schema)
                    logger.debug(f"EventClient: registered inline schema '{schema_name}'")
                except Exception as e:
                    status = getattr(getattr(e, "response", None), "status_code", None)
                    if status == 409:
                        logger.debug(f"EventClient: schema '{schema_name}' already registered")
                    else:
                        logger.warning(f"EventClient: failed to register schema '{schema_name}': {e}")

    async def disconnect(self) -> None:
        """
        Disconnect from the Event Service.
        
        This gracefully closes the SSE connection and stops the background task.
        """
        logger.info("Disconnecting from Event Service")
        
        self._stop_event.set()
        
        if self._stream_task:
            self._stream_task.cancel()
            try:
                await self._stream_task
            except asyncio.CancelledError:
                pass
            self._stream_task = None
        
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
        
        self._connected = False
        self._connection_id = None
        logger.info("Disconnected from Event Service")
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to the Event Service."""
        return self._connected
    
    # =========================================================================
    # Publishing
    # =========================================================================
    
    async def publish(
        self,
        event_type: str,
        topic: Union[EventTopic, str],
        data: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
        subject: Optional[str] = None,
        response_event: Optional[str] = None,
        response_topic: Optional[str] = None,
        response_schema_name: Optional[str] = None,
        trace_id: Optional[str] = None,
        parent_event_id: Optional[str] = None,
        payload_schema_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        goal_id: Optional[str] = None,
        plan_id: Optional[str] = None,
    ) -> str:
        """
        Publish an event to the Event Service.
        
        Args:
            event_type: Event type (e.g., "research.completed")
            topic: Target topic (EventTopic enum or string)
            data: Event payload data
            correlation_id: Optional correlation ID for tracing
            subject: Optional subject/resource identifier
            response_event: Event type for response (DisCo pattern)
            response_topic: Topic for response (defaults to action-results)
            trace_id: Root trace ID for distributed tracing
            parent_event_id: ID of parent event in trace tree
            payload_schema_name: Registered schema name for payload
            tenant_id: Tenant ID for multi-tenancy (overrides client default)
            user_id: User ID for authentication/authorization (envelope metadata)
            session_id: Session ID for conversation correlation (overrides client default)
            goal_id: Goal ID for coordinated multi-step workflows (envelope metadata)
            plan_id: Plan ID for plan execution tracking and observability (envelope metadata)
        
        Returns:
            The event ID
        
        Raises:
            ConnectionError: If unable to publish the event
        """
        await self._ensure_http_client()
        
        event_id = str(uuid4())
        
        # Convert EventTopic to string if needed
        topic_str = topic.value if isinstance(topic, EventTopic) else topic
        
        event = {
            "id": event_id,
            "source": self.source,
            "specversion": "1.0",
            "type": event_type,
            "topic": topic_str,
            "time": datetime.now(timezone.utc).isoformat(),
            "data": data or {},
            "correlation_id": correlation_id or str(uuid4()),
        }
        
        # Add optional fields
        if subject:
            event["subject"] = subject
        if response_event:
            event["response_event"] = response_event
        if response_topic:
            event["response_topic"] = response_topic
        if response_schema_name:
            event["response_schema_name"] = response_schema_name
        if trace_id:
            event["trace_id"] = trace_id
        if parent_event_id:
            event["parent_event_id"] = parent_event_id
        if payload_schema_name:
            event["payload_schema_name"] = payload_schema_name
        
        # Use provided tenant_id/user_id/session_id, or fall back to client defaults
        if tenant_id or self.tenant_id:
            event["tenant_id"] = tenant_id or self.tenant_id
        if user_id:
            event["user_id"] = user_id
        if session_id or self.session_id:
            event["session_id"] = session_id or self.session_id
        if goal_id:
            event["goal_id"] = goal_id
        if plan_id:
            event["plan_id"] = plan_id
        
        url = f"{self.event_service_url}/v1/events/publish"
        
        try:
            response = await self._http_client.post(
                url,
                json={"event": event},
                headers=await self._build_auth_headers(),
                timeout=30.0,
            )
            
            if response.status_code != 200:
                error_detail = response.text
                raise ConnectionError(f"Failed to publish event: {response.status_code} - {error_detail}")
            
            result = response.json()
            logger.debug(f"Published event {event_id} to {topic}")
            
            return result.get("event_id", event_id)
            
        except Exception as e:
            logger.error(f"Error publishing event: {e}")
            raise ConnectionError(f"Failed to publish event: {e}") from e
    
    # =========================================================================
    # SSE Stream Processing
    # =========================================================================
    
    async def _run_stream(self) -> None:
        """
        Main loop for the SSE stream.
        
        Handles connection, reconnection with exponential backoff, and event dispatch.
        """
        attempt = 0
        
        while not self._stop_event.is_set():
            try:
                await self._stream_events()
                # If we get here, connection closed gracefully
                if self._stop_event.is_set():
                    break
                attempt = 0  # Reset on successful connection
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._connected = False
                
                # Only log if there's meaningful error info
                error_msg = str(e).strip()
                if error_msg:
                    logger.warning(f"Stream connection issue: {error_msg}")
                else:
                    logger.debug("Stream disconnected, reconnecting...")
                
                # Check if we should retry
                if self._max_reconnect_attempts >= 0 and attempt >= self._max_reconnect_attempts:
                    logger.error("Max reconnection attempts reached")
                    break
                
                # Calculate backoff delay
                delay = min(
                    self._reconnect_base_delay * (2 ** attempt),
                    self._reconnect_max_delay,
                )
                
                # Only log reconnection on first few attempts to reduce noise
                if attempt < 3:
                    logger.debug(f"Reconnecting in {delay:.1f}s (attempt {attempt + 1})")
                
                try:
                    await asyncio.wait_for(
                        self._stop_event.wait(),
                        timeout=delay,
                    )
                    break  # Stop event was set
                except asyncio.TimeoutError:
                    pass  # Continue with retry
                
                attempt += 1
    
    async def _stream_events(self) -> None:
        """
        Connect to SSE stream and process events.
        """
        await self._ensure_http_client()
        
        topics_param = ",".join(self._subscribed_topics)
        # Pass source as agent_name for load balancing queue groups
        url = f"{self.event_service_url}/v1/events/stream?topics={topics_param}&agent_id={self.agent_id}&agent_name={self.source}"
        
        logger.info(f"Connecting to SSE stream: {url}")
        
        async with self._http_client.stream("GET", url, headers=await self._build_auth_headers()) as response:
            if response.status_code != 200:
                raise ConnectionError(f"SSE connection failed: {response.status_code}")
            
            # Process SSE stream
            event_type = None
            data_lines: List[str] = []
            
            async for line in response.aiter_lines():
                if self._stop_event.is_set():
                    break
                
                line = line.strip()
                
                if not line:
                    # Empty line = end of event
                    if event_type and data_lines:
                        data = "\n".join(data_lines)
                        await self._handle_sse_event(event_type, data)
                    event_type = None
                    data_lines = []
                    continue
                
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_lines.append(line[5:].strip())
                # Ignore other fields (id, retry, etc.)
    
    async def _handle_sse_event(self, event_type: str, data: str) -> None:
        """
        Handle an SSE event.
        
        Args:
            event_type: SSE event type (e.g., "connected", "message", "heartbeat")
            data: Event data (JSON string)
        """
        try:
            parsed_data = json.loads(data)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse SSE data: {data}")
            return
        
        if event_type == "connected":
            self._connected = True
            self._connection_id = parsed_data.get("connection_id")
            logger.info(f"Connected to Event Service (connection_id: {self._connection_id})")
            
        elif event_type == "heartbeat":
            logger.debug("Received heartbeat")
            
        elif event_type == "message":
            # Dispatch to handlers
            await self._dispatch_event(parsed_data)
            
        elif event_type == "disconnected":
            self._connected = False
            logger.info("Received disconnect from Event Service")
            
        else:
            logger.debug(f"Unknown SSE event type: {event_type}")
    
    async def _dispatch_event(self, event: Dict[str, Any]) -> None:
        """
        Dispatch an event to registered handlers.
        
        Args:
            event: The event data (dict that will be deserialized to EventEnvelope)
        """
        event_type = event.get("type", "")
        
        # Deserialize to EventEnvelope for type safety
        try:
            event_envelope = EventEnvelope(**event)
        except Exception as e:
            logger.error(f"Failed to deserialize event to EventEnvelope: {e}")
            logger.debug(f"Event data: {event}")
            return
        
        # Call specific handlers
        handlers = self._handlers.get(event_type, [])
        for handler in handlers:
            try:
                await handler(event_envelope)
            except Exception as e:
                logger.error(f"Error in handler for {event_type}: {e}")
                logger.exception(f"Handler exception details for {event_type}:")
        
        # Call catch-all handlers
        for handler in self._catch_all_handlers:
            try:
                await handler(event_envelope)
            except Exception as e:
                logger.error(f"Error in catch-all handler: {e}")
                logger.exception("Catch-all handler exception details:")
        
        if not handlers and not self._catch_all_handlers:
            logger.debug(f"No handlers for event type: {event_type}")
    
    # =========================================================================
    # HTTP Client Management
    # =========================================================================
    
    async def _ensure_http_client(self) -> None:
        """Ensure HTTP client is initialized."""
        if self._http_client is None:
            try:
                import httpx
            except ImportError:
                raise ImportError(
                    "httpx is required for EventClient. "
                    "Install it with: pip install httpx"
                )
            
            # Configure timeout for SSE streaming:
            # - connect: 10s for initial connection
            # - read: None (no timeout) for long-lived SSE streams
            # - write: 30s for publishing
            # - pool: None (no timeout) for connection pool
            timeout = httpx.Timeout(
                connect=10.0,
                read=None,  # SSE streams are long-lived
                write=30.0,
                pool=None,
            )
            
            self._http_client = httpx.AsyncClient(timeout=timeout)
    
    # =========================================================================
    # Context Manager Support
    # =========================================================================
    
    async def __aenter__(self) -> "EventClient":
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
