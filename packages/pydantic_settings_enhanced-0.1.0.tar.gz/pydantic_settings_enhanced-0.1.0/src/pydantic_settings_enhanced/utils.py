from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    TomlConfigSettingsSource,
)
from typing import Tuple, Type, Any
import os
from pathlib import Path
import inspect

from pydantic_settings.sources import PathType, DEFAULT_PATH

CONFIG_ROOT = Path(__file__).parent
BASE_ROOT = CONFIG_ROOT.parent

environment = os.getenv("ENVIRONMENT", "dev")


class TomlConfigDirSettingsSource(TomlConfigSettingsSource):
    # 自动解析嵌目录
    def _read_files(self, files: PathType | None, deep_merge: bool = False) -> dict[str, Any]:
        new_files = []
        dirs = []
        for file in files:
            # print("file:", file)
            if isinstance(file, Path) and file.is_dir():
                # print("日志目录", file)
                dirs.append(file)
            else:
                new_files.append(file)

        vars = super()._read_files(new_files, deep_merge)

        for d in dirs:
            # print("dir:", d.name)
            dmap = {}
            for sub_file in d.iterdir():
                if sub_file.is_file() and sub_file.suffix == ".toml":
                    dmap[sub_file.stem] = self._read_file(sub_file)
                    print("sub_file:", sub_file.stem)
            vars[d.name] = dmap
        # print("vars:", vars['terminals'])
        return vars


class TomlBaseSettings(BaseSettings):
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        toml_file = cls.get_config_files()
        return (TomlConfigDirSettingsSource(settings_cls, toml_file),)

    @classmethod
    def get_config_files(cls) -> list[Path]:
        # Get the module where the class is defined
        module = inspect.getmodule(cls)
        # Get the absolute file path of the module
        confd = Path(module.__file__).parent / "confd"
        return [confd / "shared.toml", confd / f"{environment}.toml"]
        # raise NotImplementedError("Subclasses must implement this class method")
