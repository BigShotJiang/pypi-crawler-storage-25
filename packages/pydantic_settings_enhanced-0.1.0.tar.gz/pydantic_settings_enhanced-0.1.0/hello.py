def main():
    print("Hello from pydantic-settings-enhanced!")


if __name__ == "__main__":
    main()
