"""Aleph Prover CLI — submit Lean proof requests and apply results."""

from __future__ import annotations

from typing import Any

import importlib.resources
import os
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

import click
import httpx

DEFAULT_API_URL = "https://alephprover.logicalintelligence.com"
POLL_INTERVAL = 15  # seconds
POLL_TIMEOUT = 60 * 60  # 60 minutes

# Project config files needed for building — searched project-wide
CONFIG_GLOBS = ("lakefile.lean", "lakefile.toml", "lean-toolchain", "lake-manifest.json")

# Documentation / supporting text files — always included regardless of Lake source paths
DOC_GLOBS = ("*.txt", "*.md", "*.tex")


def find_project_root(start: Path) -> Path:
    """Walk up from start to find directory containing lakefile.lean or lakefile.toml."""
    current = start.resolve()
    if current.is_file():
        current = current.parent
    while current != current.parent:
        if (current / "lakefile.lean").exists() or (current / "lakefile.toml").exists():
            return current
        current = current.parent
    click.echo(
        "Error: Could not find a Lean project root (lakefile.lean or lakefile.toml).\n"
        "Make sure you are inside a Lean project directory.",
        err=True,
    )
    sys.exit(1)


def validate_api_key() -> str:
    """Check PROVER_API_KEY env var."""
    key = os.environ.get("PROVER_API_KEY", "")
    if not key:
        click.echo(
            "Error: PROVER_API_KEY is not set.\n"
            "\n"
            "To set up:\n"
            "  1. Get an API key from https://alephprover.logicalintelligence.com/account\n"
            '  2. export PROVER_API_KEY="sk-aleph-..."',
            err=True,
        )
        sys.exit(1)
    if not key.startswith("sk-aleph-"):
        click.echo(
            'Error: PROVER_API_KEY must start with "sk-aleph-".\n'
            "Check your API key at https://alephprover.logicalintelligence.com/account",
            err=True,
        )
        sys.exit(1)
    return key


def get_api_url() -> str:
    return os.environ.get("PROVER_API_URL", DEFAULT_API_URL).rstrip("/")


def get_lean_src_paths(project_root: Path) -> list[str] | None:
    """Query Lake for source directories. Returns None if Lake is unavailable."""
    try:
        result = subprocess.run(
            ["lake", "env", "printenv", "LEAN_SRC_PATH"],
            capture_output=True,
            text=True,
            cwd=project_root,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout.strip():
            return [p for p in result.stdout.strip().split(":") if p]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _git_ls_files(root: Path) -> set[str] | None:
    """Return all tracked + untracked-not-ignored files using git, or None if unavailable."""
    try:
        # Tracked files (root + submodules)
        tracked = subprocess.run(
            ["git", "ls-files", "--cached", "--recurse-submodules"],
            cwd=root, capture_output=True, text=True, timeout=30,
        )
        if tracked.returncode != 0:
            return None

        # Untracked-not-ignored (root only)
        untracked = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=root, capture_output=True, text=True, timeout=30,
        )

        result = set(tracked.stdout.splitlines())
        if untracked.returncode == 0:
            result.update(untracked.stdout.splitlines())

        # Untracked files in submodules
        submodules = subprocess.run(
            ["git", "submodule", "--quiet", "foreach", "echo $displaypath"],
            cwd=root, capture_output=True, text=True, timeout=30,
        )
        if submodules.returncode == 0:
            for sm_path in submodules.stdout.splitlines():
                sm_dir = root / sm_path
                if not sm_dir.is_dir():
                    continue
                sm_untracked = subprocess.run(
                    ["git", "ls-files", "--others", "--exclude-standard"],
                    cwd=sm_dir, capture_output=True, text=True, timeout=30,
                )
                if sm_untracked.returncode == 0:
                    for f in sm_untracked.stdout.splitlines():
                        result.add(f"{sm_path}/{f}")

        return result
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def zip_project(project_root: Path, verbose: bool = False, all_files: bool = False) -> Path:
    """Create a ZIP archive with only the files needed for building.

    Uses Lake to discover source directories when available. Falls back to
    including all .lean files outside .lake/.
    """
    # Collect files to archive
    files: list[Path] = []

    if all_files:
        git_files = _git_ls_files(project_root)

        if git_files is not None:
            click.echo("Warning: --all-files includes all project files (respecting .gitignore). Archive may be large.", err=True)
            for rel in sorted(git_files):
                if ".lake" in rel.split("/"):
                    continue
                p = project_root / rel
                if p.is_file():
                    files.append(p)
        else:
            click.echo("Warning: --all-files includes ALL project files. git not available, .gitignore is NOT respected. Archive may contain sensitive data.", err=True)
            for p in sorted(project_root.rglob("*")):
                if not p.is_file():
                    continue
                rel = p.relative_to(project_root).as_posix()
                if ".git" in rel.split("/") or ".lake" in rel.split("/"):
                    continue
                files.append(p)
    else:
        resolved_root = project_root.resolve()

        # Config files and doc files: always search project-wide
        for glob in CONFIG_GLOBS + DOC_GLOBS:
            for p in sorted(project_root.rglob(glob)):
                rel = p.relative_to(resolved_root).as_posix()
                if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                    files.append(p)

        # .lean files: use Lake source paths when available, else fallback
        src_paths = get_lean_src_paths(project_root)

        if src_paths is not None:
            click.echo(f"Lake source paths: {', '.join(src_paths) or '.'}")
            if src_paths:
                for src in src_paths:
                    src_dir = (project_root / src).resolve()
                    if not src_dir.is_dir():
                        continue
                    if not src_dir.is_relative_to(resolved_root):
                        continue
                    rel_dir = src_dir.relative_to(resolved_root).as_posix()
                    if rel_dir.startswith(".lake") or rel_dir.startswith("lake-packages"):
                        continue
                    for p in sorted(src_dir.rglob("*.lean")):
                        rel = p.relative_to(resolved_root).as_posix()
                        if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                            files.append(p)
            else:
                # Empty LEAN_SRC_PATH means project root is the source dir
                for p in sorted(project_root.rglob("*.lean")):
                    rel = p.relative_to(resolved_root).as_posix()
                    if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                        files.append(p)
        else:
            click.echo("Lake not available, including all .lean files")
            for p in sorted(project_root.rglob("*.lean")):
                rel = p.relative_to(resolved_root).as_posix()
                if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                    files.append(p)

    # Deduplicate while preserving order
    seen: set[Path] = set()
    unique_files: list[Path] = []
    for f in files:
        if f not in seen:
            seen.add(f)
            unique_files.append(f)

    # Create archive
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", prefix="alephprover-", delete=False)
    tmp.close()
    zip_path = Path(tmp.name)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in unique_files:
            rel = path.relative_to(project_root).as_posix()
            if verbose:
                click.echo(f"  {rel}")
            zf.write(path, rel)

    size_mb = zip_path.stat().st_size / (1024 * 1024)
    click.echo(f"Archived {len(unique_files)} files ({size_mb:.1f} MB)")
    return zip_path


def submit(
    api_url: str,
    api_key: str,
    zip_path: Path,
    file_path: str,
    theorem_name: str,
    hints: str | None,
    time_budget: int | None,
    cost_budget: float | None,
) -> str:
    """Submit the archive and return the request ID."""
    data: dict[str, str] = {
        "file_path": file_path,
        "theorem_name": theorem_name,
    }
    if hints:
        data["hints"] = hints
    if time_budget is not None:
        data["time_budget_minutes"] = str(time_budget)
    if cost_budget is not None:
        # TODO: switch to "cost_budget" once prover-public#357 deployed everywhere (1 credit = $1).
        data["cost_budget_usd"] = str(cost_budget)

    with open(zip_path, "rb") as f:
        files = {"archive": ("project.zip", f, "application/zip")}
        response = httpx.post(
            f"{api_url}/api/v1/requests/upload",
            headers={"Authorization": f"Bearer {api_key}"},
            data=data,
            files=files,
            timeout=120.0,
        )

    if response.status_code != 201:
        click.echo(f"Error: Upload failed (HTTP {response.status_code})", err=True)
        try:
            click.echo(response.json(), err=True)
        except Exception:
            click.echo(response.text, err=True)
        sys.exit(1)

    request_id = response.json()["id"]
    return request_id


TERMINAL_STATUSES = ("completed", "completed_partial", "failed", "cancelled")


def poll_status(api_url: str, api_key: str, request_id: str) -> dict:
    """Poll until terminal status. Returns final response data."""
    headers = {"Authorization": f"Bearer {api_key}"}
    start = time.time()
    last_stage = None

    while time.time() - start < POLL_TIMEOUT:
        try:
            response = httpx.get(
                f"{api_url}/api/v1/requests/{request_id}",
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()
        except httpx.HTTPError as e:
            click.echo(f"Warning: Poll request failed ({e}), retrying...", err=True)
            time.sleep(POLL_INTERVAL)
            continue

        data = response.json()
        status = data["status"]
        stage = data.get("stage")

        if stage and stage != last_stage:
            click.echo(f"  Stage: {stage}")
            last_stage = stage

        if status in TERMINAL_STATUSES:
            return data

        time.sleep(POLL_INTERVAL)

    click.echo(
        f"Timeout: polling exceeded {POLL_TIMEOUT // 60} minutes.\n"
        f"Check status at: {api_url}/requests/{request_id}",
        err=True,
    )
    sys.exit(1)


def download_diff(api_url: str, api_key: str, request_id: str) -> Path | None:
    """Download the diff patch. Returns path or None on failure."""
    response = httpx.get(
        f"{api_url}/api/v1/requests/{request_id}/diff",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=60.0,
    )
    if response.status_code != 200:
        return None

    patch_path = Path(tempfile.mktemp(suffix=".patch", prefix=f"proof-{request_id[:8]}-"))
    patch_path.write_bytes(response.content)
    return patch_path


def apply_patch(patch_path: Path, project_root: Path) -> bool:
    """Apply patch with git apply. Returns True on success."""
    result = subprocess.run(
        ["git", "apply", str(patch_path)],
        capture_output=True,
        text=True,
        cwd=project_root,
    )
    if result.returncode == 0:
        return True

    # Try --3way fallback
    click.echo("Standard apply failed, trying --3way...")
    result = subprocess.run(
        ["git", "apply", "--3way", str(patch_path)],
        capture_output=True,
        text=True,
        cwd=project_root,
    )
    return result.returncode == 0


@click.group()
@click.version_option(package_name="alephprover")
def main():
    """Aleph Prover CLI — submit Lean proof requests."""


@main.command()
@click.argument("file_path")
@click.argument("theorem_name")
@click.option("--hints", default=None, help="Hints for the prover")
@click.option("--time-budget", default=None, type=int, help="Time budget in minutes (default: server-side 900)")
@click.option("--cost-budget", default=None, type=float, help="Cost budget in credits (default: server-side 50)")
@click.option("-v", "--verbose", is_flag=True, help="List files included in the archive")
@click.option("--all-files", is_flag=True, help="Archive all project files (excludes .git, .lake, and .gitignore patterns)")
@click.option("--no-poll", is_flag=True, help="Submit and exit without waiting")
def prove(
    file_path: str,
    theorem_name: str,
    hints: str | None,
    time_budget: int | None,
    cost_budget: float | None,
    verbose: bool,
    all_files: bool,
    no_poll: bool,
):
    """Submit a Lean theorem for proving.

    FILE_PATH is the path to the Lean file (relative to project root).
    THEOREM_NAME is the name of the theorem to prove.
    """
    api_key = validate_api_key()
    api_url = get_api_url()

    # Find project root
    if Path(file_path).is_absolute():
        start = Path(file_path)
    else:
        start = Path.cwd()
    project_root = find_project_root(start)
    click.echo(f"Project root: {project_root}")

    # Resolve file_path relative to project root
    abs_file = (project_root / file_path) if not Path(file_path).is_absolute() else Path(file_path)
    if not abs_file.exists():
        click.echo(f"Error: File not found: {abs_file}", err=True)
        sys.exit(1)
    rel_file = abs_file.relative_to(project_root).as_posix()

    # Zip
    click.echo("Zipping project...")
    zip_path = zip_project(project_root, verbose=verbose, all_files=all_files)

    try:
        # Submit
        click.echo("Submitting proof request...")
        request_id = submit(api_url, api_key, zip_path, rel_file, theorem_name, hints, time_budget, cost_budget)
        click.echo(f"Request ID: {request_id}")
        click.echo(f"View at: {api_url}/requests/{request_id}")

        if no_poll:
            return

        # Poll
        click.echo("Waiting for proof...")
        result = poll_status(api_url, api_key, request_id)
        status = result["status"]

        if status not in ("completed", "completed_partial"):
            click.echo(f"Proof request {status}.", err=True)
            if result.get("message"):
                click.echo(f"Error: {result['message']}", err=True)
            click.echo(f"Details: {api_url}/requests/{request_id}", err=True)
            sys.exit(1)

        if status == "completed_partial":
            click.echo("Proof partially completed (budget exhausted).")
        else:
            click.echo("Proof completed!")

        # Download diff
        click.echo("Downloading diff...")
        patch_path = download_diff(api_url, api_key, request_id)

        if patch_path is None:
            click.echo(
                "Could not download diff. Check results at:\n"
                f"  {api_url}/requests/{request_id}",
                err=True,
            )
            sys.exit(1)

        # Apply
        click.echo("Applying patch...")
        if apply_patch(patch_path, project_root):
            click.echo("Proof applied successfully!")
            # Show what changed
            result = subprocess.run(["git", "diff", "--stat"], capture_output=True, text=True, cwd=project_root)
            if result.stdout:
                click.echo(result.stdout)
            # Cleanup patch
            patch_path.unlink(missing_ok=True)
        else:
            click.echo(
                f"Could not apply patch automatically.\n"
                f"Patch saved to: {patch_path}\n"
                f"Apply manually with: git apply {patch_path}",
                err=True,
            )
            sys.exit(1)
    finally:
        # Cleanup zip
        Path(zip_path).unlink(missing_ok=True)


@main.command("status")
@click.argument("request_id")
def status_cmd(request_id: str):
    """Show detailed status of a proof request."""
    api_key = validate_api_key()
    api_url = get_api_url()

    response = httpx.get(
        f"{api_url}/api/v1/requests/{request_id}",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30.0,
    )
    if response.status_code == 404:
        click.echo("Error: Proof request not found.", err=True)
        sys.exit(1)
    response.raise_for_status()

    data = response.json()
    click.echo(f"Request:  {data['id']}")
    click.echo(f"Status:   {data['status']}")
    if data.get("repository_url"):
        click.echo(f"Repo:     {data['repository_url']}")
    if data.get("file_path"):
        click.echo(f"File:     {data['file_path']}")
    if data.get("theorem_name"):
        click.echo(f"Theorem:  {data['theorem_name']}")
    if data.get("pr_url"):
        click.echo(f"PR:       {data['pr_url']}")
    if data.get("message"):
        click.echo(f"Message:  {data['message']}")

    stages = data.get("stages", [])
    if stages:
        click.echo("\nStages:")
        for s in stages:
            icon = {"completed": "+", "completed_partial": "~", "failed": "x", "cancelled": "-"}.get(s["status"], " ")
            dur = f" ({s['duration_seconds']:.0f}s)" if s.get("duration_seconds") else ""
            click.echo(f"  [{icon}] {s['stage']}: {s['status']}{dur}")
            if s.get("message"):
                click.echo(f"      {s['message']}")
            if s.get("summary"):
                click.echo(f"      {s['summary']}")

    artifacts = data.get("artifacts", [])
    if artifacts:
        click.echo("\nArtifacts:")
        for a in artifacts:
            size_kb = a["size_bytes"] / 1024
            click.echo(f"  {a['type']} ({size_kb:.1f} KB)  id={a['artifact_id']}")

    if data.get("is_continuable"):
        click.echo(f"\nThis request can be continued: alephprover continue {request_id}")


@main.command("list")
@click.option("--limit", default=20, type=int, help="Max number of results")
@click.option("--offset", default=0, type=int, help="Offset for pagination")
@click.option("--search", default=None, help="Search by theorem, file path, or repo")
def list_cmd(limit: int, offset: int, search: str | None):
    """List proof requests."""
    api_key = validate_api_key()
    api_url = get_api_url()

    params: dict[str, str | int] = {"limit": limit, "offset": offset}
    if search:
        params["search"] = search

    response = httpx.get(
        f"{api_url}/api/v1/requests",
        headers={"Authorization": f"Bearer {api_key}"},
        params=params,
        timeout=30.0,
    )
    response.raise_for_status()

    data = response.json()
    items = data.get("items", [])
    total = data.get("total", 0)

    if not items:
        click.echo("No proof requests found.")
        return

    # Table header
    click.echo(f"{'ID':<38} {'Status':<20} {'Stage':<8} {'Theorem':<30} {'Created'}")
    click.echo("-" * 121)
    for item in items:
        rid = item["id"]
        status = item["status"]
        stage = item.get("stage") or ""
        theorem = (item.get("theorem_name") or "")[:29]
        created = item.get("created_at", "")[:19]
        click.echo(f"{rid:<38} {status:<20} {stage:<8} {theorem:<30} {created}")

    click.echo(f"\nShowing {len(items)} of {total} total")


@main.command()
@click.argument("request_id")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation")
def cancel(request_id: str, yes: bool):
    """Cancel a proof request."""
    api_key = validate_api_key()
    api_url = get_api_url()

    if not yes:
        click.confirm(f"Cancel request {request_id}?", abort=True)

    response = httpx.post(
        f"{api_url}/api/v1/requests/{request_id}/cancel",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30.0,
    )

    if response.status_code == 404:
        click.echo("Error: Proof request not found.", err=True)
        sys.exit(1)
    if response.status_code == 409:
        detail = "Cannot cancel this request"
        try:
            detail = response.json().get("detail", detail)
        except Exception:
            pass
        click.echo(f"Error: {detail}", err=True)
        sys.exit(1)
    response.raise_for_status()

    click.echo(f"Cancelled request {request_id}")


@main.command("continue")
@click.argument("request_id")
@click.option("--time-budget", default=None, type=int, help="New time budget in minutes")
@click.option("--cost-budget", default=None, type=float, help="New cost budget in credits")
@click.option("--hints", default=None, help="Additional hints appended to original")
@click.option("--no-poll", is_flag=True, help="Submit and exit without waiting")
def continue_cmd(request_id: str, time_budget: int | None, cost_budget: float | None, hints: str | None, no_poll: bool):
    """Continue a cancelled or partial proof request with new budget."""
    api_key = validate_api_key()
    api_url = get_api_url()

    payload: dict[str, Any] = {}
    if time_budget is not None:
        payload["time_budget_minutes"] = time_budget
    if cost_budget is not None:
        # TODO: switch to "cost_budget" once prover-public#357 deployed everywhere (1 credit = $1).
        payload["cost_budget_usd"] = cost_budget
    if hints:
        payload["additional_hints"] = hints

    response = httpx.post(
        f"{api_url}/api/v1/requests/{request_id}/continue",
        headers={"Authorization": f"Bearer {api_key}"},
        json=payload,
        timeout=30.0,
    )

    if response.status_code == 404:
        click.echo("Error: Proof request not found.", err=True)
        sys.exit(1)
    if response.status_code == 409:
        detail = "Proof request cannot be continued"
        try:
            detail = response.json().get("detail", detail)
        except Exception:
            pass
        click.echo(f"Error: {detail}", err=True)
        sys.exit(1)
    if response.status_code >= 400:
        click.echo(f"Error: Failed to continue (HTTP {response.status_code})", err=True)
        sys.exit(1)

    new_id = response.json()["id"]
    click.echo(f"Continued as new request: {new_id}")
    click.echo(f"View at: {api_url}/requests/{new_id}")

    if no_poll:
        return

    click.echo("Waiting for proof...")
    result = poll_status(api_url, api_key, new_id)
    status = result["status"]

    if status not in ("completed", "completed_partial"):
        click.echo(f"Proof request {status}.", err=True)
        if result.get("message"):
            click.echo(f"Error: {result['message']}", err=True)
        click.echo(f"Details: {api_url}/requests/{new_id}", err=True)
        sys.exit(1)

    if status == "completed_partial":
        click.echo("Proof partially completed (budget exhausted).")
    else:
        click.echo("Proof completed!")

    click.echo(f"Download results with: alephprover download {new_id}")


@main.command()
@click.argument("request_id")
@click.option("--artifact", default=None, help="Artifact ID to download (default: prover_result.zip)")
@click.option("-o", "--output", default=None, type=click.Path(), help="Output file path")
def download(request_id: str, artifact: str | None, output: str | None):
    """Download proof result or a specific artifact."""
    api_key = validate_api_key()
    api_url = get_api_url()
    headers = {"Authorization": f"Bearer {api_key}"}

    if artifact:
        # Download specific artifact
        response = httpx.get(
            f"{api_url}/api/v1/requests/{request_id}/artifacts/{artifact}",
            headers=headers,
            timeout=60.0,
        )
    else:
        # Download default result (prover_result.zip)
        response = httpx.get(
            f"{api_url}/api/v1/requests/{request_id}/download",
            headers=headers,
            timeout=60.0,
        )

    if response.status_code == 404:
        click.echo("Error: Artifact not found. Use 'alephprover status <id>' to see available artifacts.", err=True)
        sys.exit(1)
    response.raise_for_status()

    # Determine output filename
    if output:
        out_path = Path(output)
    else:
        # Try to get filename from content-disposition
        cd = response.headers.get("content-disposition", "")
        if "filename=" in cd:
            fname = cd.split("filename=")[-1].strip('" ')
        else:
            fname = f"result-{request_id[:8]}.zip"
        out_path = Path(fname)

    out_path.write_bytes(response.content)
    size_kb = len(response.content) / 1024
    click.echo(f"Downloaded {out_path} ({size_kb:.1f} KB)")


@main.command("install-skill")
@click.option("--global", "global_", is_flag=True, help="Install to ~/.claude/commands/ instead of project")
def install_skill(global_: bool):
    """Install the /prove skill for Claude Code."""
    if global_:
        target = Path.home() / ".claude" / "commands" / "prove.md"
    else:
        target = Path.cwd() / ".claude" / "commands" / "prove.md"

    source = importlib.resources.files("alephprover") / "prove.md"
    content = source.read_text(encoding="utf-8")

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    click.echo(f"Installed /prove skill to {target}")
