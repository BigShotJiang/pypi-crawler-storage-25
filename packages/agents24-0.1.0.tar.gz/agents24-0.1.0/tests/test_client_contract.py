from __future__ import annotations

import json

import pytest
import requests

from agents24 import Agents24
from agents24.errors import Agents24SDKError
from agents24.generated.manifest import SDK_OPERATION_IDS


EVENT = {
    "version": "run-stream.v2",
    "seq": 1,
    "ts": "2026-05-24T00:00:00.000Z",
    "event": "run.accepted",
    "run_id": "run-1",
    "stage": "run",
    "payload": {},
    "diagnostics": [],
}


class FakeResponse:
    def __init__(self, body=None, *, status_code=200, reason="OK", headers=None, lines=None):
        self._body = {} if body is None else body
        self.status_code = status_code
        self.reason = reason
        self.headers = headers or {}
        self._lines = lines or []
        self.text = json.dumps(self._body) if self._body is not None else ""

    def json(self):
        return self._body

    def iter_lines(self, decode_unicode=False):
        for line in self._lines:
            if decode_unicode:
                yield line
            else:
                yield line.encode("utf-8")


class FakeSession:
    def __init__(self, responses=None, *, error=None, stream=None, multipart=None):
        self.responses = list(responses or [])
        self.error = error
        self.stream = stream
        self.multipart = multipart
        self.calls = []

    def request(self, **kwargs):
        self.calls.append(kwargs)
        if self.error:
            raise self.error
        if kwargs.get("stream"):
            return self.stream or stream_response()
        if "files" in kwargs:
            return self.multipart or FakeResponse({"items": []})
        if self.responses:
            return self.responses.pop(0)
        return FakeResponse(
            {
                "id": "ok",
                "items": [],
                "total": 0,
                "run_id": "run-1",
                "thread_id": "thread-1",
                "status": "cancelled",
            }
        )


def stream_response(*, omit_run_header=False, bad_version=False):
    event = {**EVENT, "version": "bad-version" if bad_version else EVENT["version"]}
    headers = {"X-Thread-ID": "thread-1"}
    if not omit_run_header:
        headers["X-Run-ID"] = "run-1"
    return FakeResponse(
        {},
        headers=headers,
        lines=[f"data: {json.dumps(event)}", ""],
    )


def make_client(session=None):
    return Agents24(
        base_url="https://api.example.com///",
        api_key="sdk-key",
        organization_id="org-1",
        project_id="project-1",
        session=session or FakeSession(),
    )


def test_generated_operation_manifest_matches_expected_surface():
    assert SDK_OPERATION_IDS == [
        "agents.cancel_run",
        "agents.catalog",
        "agents.create",
        "agents.delete",
        "agents.get",
        "agents.list",
        "agents.publish",
        "agents.resume_run",
        "agents.schema",
        "agents.start_run",
        "agents.stream",
        "agents.update",
        "agents.update_graph",
        "agents.upload_attachments",
        "agents.validate",
        "embed.cancel_agent_run",
        "embed.delete_agent_thread",
        "embed.get_agent_run_context",
        "embed.get_agent_thread",
        "embed.list_agent_threads",
        "embed.stream_agent",
        "embed.upload_agent_attachments",
        "runs.get",
        "runs.get_context",
        "runs.get_events",
        "runs.get_tree",
    ]


def test_client_config_validation_and_mutation_headers():
    with pytest.raises(Agents24SDKError):
        Agents24(base_url="https://api.example.com", api_key="")
    with pytest.raises(Agents24SDKError):
        Agents24(base_url="", api_key="key")
    with pytest.raises(Agents24SDKError):
        Agents24(base_url="not-a-url", api_key="key")

    session = FakeSession([FakeResponse({"id": "agent-1"})])
    client = make_client(session)
    client.agents.create(
        {"name": "Agent", "graph_definition": {"nodes": [], "edges": []}},
        options={
            "idempotency_key": "idem-1",
            "dry_run": True,
            "validate_only": True,
            "request_metadata": {"test": "headers"},
        },
    )

    call = session.calls[0]
    assert call["url"] == "https://api.example.com/agents"
    assert call["params"] == {"dry_run": True, "validate_only": True}
    assert call["headers"]["Authorization"] == "Bearer sdk-key"
    assert call["headers"]["X-Organization-ID"] == "org-1"
    assert call["headers"]["X-Project-ID"] == "project-1"
    assert call["headers"]["X-SDK-Contract"] == "1"
    assert call["headers"]["X-Idempotency-Key"] == "idem-1"
    assert call["headers"]["X-Request-Metadata"] == '{"test":"headers"}'


def test_network_and_http_errors_are_normalized():
    network_client = make_client(FakeSession(error=requests.ConnectionError("socket closed")))
    with pytest.raises(Agents24SDKError) as network_error:
        network_client.agents.list()
    assert network_error.value.kind == "network"

    http_client = make_client(FakeSession([FakeResponse({"detail": {"message": "missing scope"}}, status_code=403, reason="Forbidden")]))
    with pytest.raises(Agents24SDKError) as http_error:
        http_client.agents.list()
    assert http_error.value.kind == "http"
    assert http_error.value.status == 403
    assert "missing scope" in str(http_error.value)


def test_agent_and_graph_builders_compile_to_graphspec():
    session = FakeSession([FakeResponse({"id": "agent-1", "name": "Builder Agent"})])
    client = make_client(session)
    builder = client.agent(
        {
            "name": "Builder Agent",
            "description": "description",
            "instructions": "Reply briefly.",
            "model": {"id": "model-1"},
            "tools": ["tool-1", {"id": "tool-2"}, "tool-1"],
            "toolsets": [{"id": "toolset-1"}],
            "knowledge": ["knowledge-1", {"id": "knowledge-2"}],
            "memory": {"short_term_enabled": True},
            "execution": {"timeout_seconds": 30},
        }
    )

    graph = builder.to_graph()
    assert graph["spec_version"] == "4.0"
    assert [node["id"] for node in graph["nodes"]] == ["start", "agent", "end"]
    assert graph["nodes"][1]["config"]["tools"] == ["tool-1", "tool-2"]
    assert graph["nodes"][1]["config"]["model_id"] == "model-1"

    request = builder.to_create_request()
    assert request["memory_config"]["long_term_enabled"] is True
    assert request["memory_config"]["long_term_index_id"] == "knowledge-1"
    assert request["execution_constraints"] == {"timeout_seconds": 30}
    builder.create()
    assert session.calls[0]["json"]["name"] == "Builder Agent"

    explicit = client.graph()
    start = explicit.node("start", {}, id="start", label="Start", x=10, y=20)
    agent = explicit.node("agent", {"instructions": "Test"}, id="agent")
    explicit.connect(start, agent, id="edge-1", source_handle="out", target_handle="in")
    payload = explicit.to_graph()
    assert payload["spec_version"] == "4.0"
    assert payload["nodes"][0]["label"] == "Start"
    assert payload["edges"][0]["source_handle"] == "out"
    with pytest.raises(ValueError, match="Duplicate graph node id"):
        explicit.node("agent", {}, id="agent")
    with pytest.raises(ValueError, match="Unknown source node id"):
        explicit.connect("missing", "agent")


def test_agents_namespace_covers_requests_stream_and_upload():
    session = FakeSession()
    client = make_client(session)

    client.agents.list(status="draft", skip=2, limit=3, view="full")
    client.agents.get("agent-1")
    client.agents.create({"name": "A", "graph_definition": {"nodes": [], "edges": []}})
    client.agents.update("agent-1", {"description": "B"})
    client.agents.update_graph("agent-1", {"nodes": [], "edges": []})
    client.agents.delete("agent-1")
    client.agents.catalog()
    client.agents.schema(["agent"])
    client.agents.validate("agent-1")
    client.agents.publish("agent-1")
    client.agents.start_run("agent-1", {"input": "hello"})
    events = []
    result = client.agents.stream("agent-1", {"input": "hello"}, events.append, mode="debug")
    client.agents.resume_run("run-1", {"approved": True})
    client.agents.cancel_run("run-1", assistant_output_text="partial")
    client.agents.upload_attachments("agent-1", [("files", ("note.txt", b"hello", "text/plain"))])

    assert session.calls[0]["params"] == {"status": "draft", "skip": 2, "limit": 3, "view": "full"}
    assert session.calls[11]["url"] == "https://api.example.com/agents/agent-1/stream"
    assert session.calls[11]["params"] == {"mode": "debug"}
    assert events[0]["event"] == "run.accepted"
    assert result == {"thread_id": "thread-1", "run_id": "run-1"}
    assert session.calls[14]["data"] == {}


def test_embed_namespace_covers_requests_stream_upload_and_validation():
    session = FakeSession()
    client = make_client(session)

    events = []
    client.embed.stream_agent("agent-1", {"input": "hello", "external_user_id": "user-1"}, events.append)
    client.embed.list_agent_threads("agent-1", external_user_id="user-1", external_session_id="session-1")
    client.embed.get_agent_thread(
        "agent-1",
        "thread-1",
        external_user_id="user-1",
        external_session_id="session-1",
        include_subthreads=True,
        subthread_depth=2,
    )
    client.embed.get_agent_run_context("agent-1", "run-1", external_user_id="user-1")
    client.embed.cancel_agent_run("agent-1", "run-1", external_user_id="user-1", assistant_output_text="partial")
    client.embed.upload_agent_attachments(
        "agent-1",
        [("files", ("note.txt", b"hello", "text/plain"))],
        external_user_id="user-1",
    )
    client.embed.delete_agent_thread("agent-1", "thread-1", external_user_id="user-1")

    assert events[0]["event"] == "run.accepted"
    assert session.calls[1]["url"] == "https://api.example.com/public/embed/agents/agent-1/threads"
    assert session.calls[2]["params"]["include_subthreads"] is True
    assert session.calls[5]["data"]["external_user_id"] == "user-1"
    with pytest.raises(Agents24SDKError, match="external_user_id"):
        client.embed.upload_agent_attachments("agent-1", [("files", ("note.txt", b"hello", "text/plain"))])


def test_runs_namespace_trace_and_sse_protocol_errors():
    session = FakeSession(
        [
            FakeResponse({"id": "run-1", "status": "completed"}),
            FakeResponse({"root_run_id": "run-1", "runs": []}),
            FakeResponse({"events": [EVENT]}),
            FakeResponse({"run_id": "run-1", "thread_id": "thread-1", "run_usage": {}}),
        ]
    )
    client = make_client(session)
    trace = client.runs.get_trace("run-1")
    assert trace["run"]["status"] == "completed"
    assert trace["events"]["events"][0]["event"] == "run.accepted"
    assert trace["context"]["thread_id"] == "thread-1"
    assert [call["url"] for call in session.calls] == [
        "https://api.example.com/agents/runs/run-1",
        "https://api.example.com/agents/runs/run-1/tree",
        "https://api.example.com/agents/runs/run-1/events",
        "https://api.example.com/agents/runs/run-1/context",
    ]

    bad_stream = make_client(FakeSession(stream=stream_response(bad_version=True)))
    with pytest.raises(Agents24SDKError, match="protocol mismatch"):
        bad_stream.agents.stream("agent-1", {"input": "hello"})

    no_header = make_client(FakeSession(stream=stream_response(omit_run_header=True)))
    assert no_header.embed.stream_agent("agent-1", {"input": "hello"})["run_id"] == "run-1"
