from __future__ import annotations

import os
import time

import pytest

from agents24 import Agents24


REQUIRED_ENV = [
    "AGENTS24_TEST_BASE_URL",
    "AGENTS24_TEST_API_KEY",
    "AGENTS24_TEST_ORGANIZATION_ID",
    "AGENTS24_TEST_PROJECT_ID",
]


def _build_replacement_graph(client: Agents24) -> dict:
    graph = client.graph()
    start = graph.node("start", {}, id="start", label="Start", x=0, y=0)
    agent = graph.node(
        "agent",
        {"instructions": "Return a concise SDK test response.", "tools": [], "toolsets": []},
        id="agent",
        x=260,
        y=0,
    )
    end = graph.node("end", {}, id="end", x=520, y=0)
    graph.connect(start, agent).connect(agent, end)
    return graph.to_graph()


def _wait_for_run(client: Agents24, run_id: str) -> dict:
    last = {}
    for _ in range(20):
        last = client.runs.get(run_id, include_tree=True)
        if str(last.get("status")) in {"completed", "failed", "cancelled", "paused"}:
            return last
        time.sleep(0.1)
    return last


def _delete_agent(client: Agents24, agent_id: str, cleanup_failures: list[dict]) -> None:
    try:
        client.agents.delete(agent_id)
    except Exception as exc:
        cleanup_failures.append({"label": f"delete agent {agent_id}", "message": str(exc)})


@pytest.mark.skipif(any(not os.getenv(name) for name in REQUIRED_ENV), reason="missing Agents24 local integration env")
def test_python_sdk_exercises_fastapi_routes_over_http():
    prefix = os.getenv("AGENTS24_TEST_PREFIX") or f"sdk-e2e-{int(time.time())}"
    client = Agents24(
        base_url=os.environ["AGENTS24_TEST_BASE_URL"],
        api_key=os.environ["AGENTS24_TEST_API_KEY"],
        organization_id=os.environ["AGENTS24_TEST_ORGANIZATION_ID"],
        project_id=os.environ["AGENTS24_TEST_PROJECT_ID"],
    )
    created_agent_ids: list[str] = []
    cleanup_failures: list[dict] = []
    external_user_id = f"{prefix}-py-user"
    external_session_id = f"{prefix}-py-session"

    try:
        draft = client.agent(
            {
                "name": f"{prefix} python builder agent",
                "description": "Created by the Agents24 Python SDK E2E harness.",
                "instructions": "Return a concise SDK test response.",
                "tools": [],
                "toolsets": [],
                "memory": {"short_term_enabled": True},
                "execution": {"timeout_seconds": 60},
            }
        ).create(options={"idempotency_key": f"{prefix}-py-create-agent"})
        created_agent_ids.append(draft["id"])
        assert draft["name"] == f"{prefix} python builder agent"

        fetched = client.agents.get(draft["id"])
        assert fetched["id"] == draft["id"]

        listed = client.agents.list(limit=100, view="summary")
        assert any(item["id"] == draft["id"] for item in listed["items"])

        updated = client.agents.update(draft["id"], {"description": f"{prefix} python updated"})
        assert updated["description"] == f"{prefix} python updated"

        graph_updated = client.agents.update_graph(draft["id"], _build_replacement_graph(client))
        assert len(graph_updated["graph_definition"]["nodes"]) == 3

        assert isinstance(client.agents.catalog(), dict)
        assert isinstance(client.agents.schema(["start", "agent", "end"]), dict)
        assert isinstance(client.agents.validate(draft["id"]), dict)

        published = client.agents.publish(draft["id"])
        assert published["id"] == draft["id"]

        start_run = client.agents.start_run(draft["id"], {"input": "Python SDK start_run test"})
        assert start_run["run_id"]

        run_status = _wait_for_run(client, start_run["run_id"])
        assert run_status
        assert isinstance(client.runs.get_tree(start_run["run_id"]), dict)
        assert isinstance(client.runs.get_events(start_run["run_id"], limit=1000)["events"], list)
        assert client.runs.get_context(start_run["run_id"])["run_id"] == start_run["run_id"]
        assert client.runs.get_trace(start_run["run_id"])["run"]["id"] == start_run["run_id"]

        stream_events: list[dict] = []
        stream_result = client.agents.stream(
            draft["id"],
            {"input": "Python SDK stream test"},
            stream_events.append,
            mode="debug",
        )
        assert stream_result["run_id"]
        assert any(event["event"] == "run.accepted" for event in stream_events)
        assert any(event["event"] in {"run.completed", "run.failed", "run.cancelled"} for event in stream_events)

        internal_upload = client.agents.upload_attachments(
            draft["id"],
            [("files", (f"{prefix}-python-internal.txt", b"internal attachment", "text/plain"))],
            thread_id=stream_result["thread_id"],
        )
        assert isinstance(internal_upload["items"], list)

        control_cancel_run_id = os.getenv("AGENTS24_TEST_CONTROL_CANCEL_RUN_ID")
        if control_cancel_run_id:
            cancel_result = client.agents.cancel_run(
                control_cancel_run_id,
                assistant_output_text="cancelled by Python SDK E2E",
            )
            assert cancel_result["run_id"] == control_cancel_run_id
            assert cancel_result["status"] == "cancelled"

        embed_events: list[dict] = []
        embed_stream = client.embed.stream_agent(
            draft["id"],
            {
                "input": "Python SDK embed stream test",
                "external_user_id": external_user_id,
                "external_session_id": external_session_id,
            },
            embed_events.append,
        )
        assert embed_stream["thread_id"]
        assert embed_stream["run_id"]
        assert any(event["event"] == "run.accepted" for event in embed_events)

        embed_threads = client.embed.list_agent_threads(
            draft["id"],
            external_user_id=external_user_id,
            external_session_id=external_session_id,
        )
        assert any(item["id"] == embed_stream["thread_id"] for item in embed_threads["items"])

        embed_thread = client.embed.get_agent_thread(
            draft["id"],
            embed_stream["thread_id"],
            external_user_id=external_user_id,
            external_session_id=external_session_id,
            include_subthreads=True,
            subthread_depth=1,
        )
        assert embed_thread["id"] == embed_stream["thread_id"]

        embed_upload = client.embed.upload_agent_attachments(
            draft["id"],
            [("files", (f"{prefix}-python-embed.txt", b"embed attachment", "text/plain"))],
            external_user_id=external_user_id,
            external_session_id=external_session_id,
            thread_id=embed_stream["thread_id"],
        )
        assert isinstance(embed_upload["items"], list)

        embed_run_context = client.embed.get_agent_run_context(
            draft["id"],
            embed_stream["run_id"],
            external_user_id=external_user_id,
            external_session_id=external_session_id,
        )
        assert embed_run_context["run_id"] == embed_stream["run_id"]

        seeded_agent_id = os.getenv("AGENTS24_TEST_EMBED_CANCEL_AGENT_ID")
        seeded_run_id = os.getenv("AGENTS24_TEST_EMBED_CANCEL_RUN_ID")
        seeded_user_id = os.getenv("AGENTS24_TEST_EMBED_EXTERNAL_USER_ID")
        if seeded_agent_id and seeded_run_id and seeded_user_id:
            seeded_cancel = client.embed.cancel_agent_run(
                seeded_agent_id,
                seeded_run_id,
                external_user_id=seeded_user_id,
                external_session_id=os.getenv("AGENTS24_TEST_EMBED_EXTERNAL_SESSION_ID"),
                assistant_output_text="cancelled by Python SDK E2E",
            )
            assert seeded_cancel["run_id"] == seeded_run_id
            assert seeded_cancel["status"] == "cancelled"

        deleted_thread = client.embed.delete_agent_thread(
            draft["id"],
            embed_stream["thread_id"],
            external_user_id=external_user_id,
            external_session_id=external_session_id,
        )
        assert deleted_thread["deleted"] is True

        client.agents.delete(draft["id"])
        created_agent_ids.pop()
    finally:
        for agent_id in reversed(created_agent_ids):
            _delete_agent(client, agent_id, cleanup_failures)
        assert cleanup_failures == []
