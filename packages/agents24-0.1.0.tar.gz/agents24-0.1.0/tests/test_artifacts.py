from __future__ import annotations

import importlib

import agents24.artifacts as artifacts


def test_artifact_helpers_declare_and_describe_multi_export_artifacts():
    module = importlib.reload(artifacts)

    @module.tool(
        name="lookup",
        description="Lookup records.",
        input_schema={"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
        output_schema={"type": "object"},
        side_effects=["network"],
    )
    def lookup(input, config, context):
        return input

    @module.agent_node(name="rank", input_schema={"type": "object"}, output_schema={"type": "object"})
    def rank(input, config, context):
        return input

    @module.rag_operator(name="chunk", execution_mode="background", input_schema={"type": "object"})
    def chunk(input, config, context):
        return input

    manifest = module.describe_exports()

    assert [(item["name"], item["kind"], item["handler_ref"]) for item in manifest] == [
        ("lookup", "tool", "lookup"),
        ("rank", "agent_node", "rank"),
        ("chunk", "rag_operator", "chunk"),
    ]
    assert manifest[0]["input_schema"]["properties"]["query"]["type"] == "string"
    assert manifest[0]["side_effects"] == ["network"]
    assert manifest[2]["execution_mode"] == "background"
