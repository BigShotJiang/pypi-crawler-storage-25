# agents24

Last Updated: 2026-05-25

Unified Python SDK for Agents24.

Endpoint methods are generated from `packages/agents24-sdk-contract/agents24.sdk.json`.
Do not edit files under `agents24/generated/` directly. For SDK maintenance, see `docs/references/agents24_sdk_development_guide.md`.

```python
from agents24 import Agents24

client = Agents24(
    base_url="http://localhost:8000",
    api_key="tpk_...",
    organization_id="org-id",
    project_id="project-id",
)

agent = client.agent({
    "name": "Support Agent",
    "instructions": "Answer briefly.",
}).create()

client.agents.publish(agent["id"])
```

## Artifact Authoring

Artifact code imports lightweight helpers from `agents24.artifacts`:

```python
from agents24.artifacts import tool


@tool(
    name="echo",
    input_schema={
        "type": "object",
        "properties": {"text": {"type": "string"}},
        "required": ["text"],
    },
    output_schema={
        "type": "object",
        "properties": {"text": {"type": "string"}},
        "required": ["text"],
    },
)
async def echo(input, config, context):
    return {"text": input["text"]}
```

The `agents24.artifacts` module is transport-free and safe for artifact runtime code.

## Development

```bash
pnpm run generate:sdk
pnpm run check:sdk-contract
pnpm run test:agents24-python
```

Generated endpoint methods must stay in parity with the TypeScript `@agents24/sdk` package.
