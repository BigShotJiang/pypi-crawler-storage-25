from __future__ import annotations

from typing import Any, NotRequired, TypeAlias, TypedDict

JSONDict: TypeAlias = dict[str, Any]


class RequestOptions(TypedDict, total=False):
    idempotency_key: str
    dry_run: bool
    validate_only: bool
    request_metadata: dict[str, Any]


class RuntimeEvent(TypedDict):
    version: str
    seq: int | float
    ts: str
    event: str
    run_id: str
    stage: str
    payload: dict[str, Any]
    diagnostics: list[dict[str, Any]]


class StreamResult(TypedDict):
    thread_id: str | None
    run_id: str | None


class AttachmentUploadResult(TypedDict):
    items: list[dict[str, Any]]


class AgentCreateRequest(TypedDict):
    name: str
    graph_definition: dict[str, Any]
    description: NotRequired[str | None]
    memory_config: NotRequired[dict[str, Any]]
    execution_constraints: NotRequired[dict[str, Any]]


AgentUpdateRequest: TypeAlias = dict[str, Any]
AgentResponse: TypeAlias = dict[str, Any]
AgentListResponse: TypeAlias = dict[str, Any]
AgentStreamRequest: TypeAlias = dict[str, Any]
EmbedStreamRequest: TypeAlias = dict[str, Any]
StartRunResult: TypeAlias = dict[str, Any]
RunCancelResult: TypeAlias = dict[str, Any]
RunContext: TypeAlias = dict[str, Any]
RunEventsResponse: TypeAlias = dict[str, Any]
RunStatus: TypeAlias = dict[str, Any]
RunTrace: TypeAlias = dict[str, Any]
ThreadDeleteResult: TypeAlias = dict[str, Any]
ThreadDetail: TypeAlias = dict[str, Any]
ThreadsResponse: TypeAlias = dict[str, Any]
