from __future__ import annotations

from typing import Any, Mapping


def _ref_id(ref: str | Mapping[str, Any]) -> str:
    return ref if isinstance(ref, str) else str(ref["id"])


def _normalize_refs(refs: list[str | Mapping[str, Any]] | None) -> list[str]:
    seen: list[str] = []
    for ref in refs or []:
        value = _ref_id(ref)
        if value and value not in seen:
            seen.append(value)
    return seen


class AgentDefinitionBuilder:
    def __init__(self, agents: Any, options: Mapping[str, Any]) -> None:
        self._agents = agents
        self._options = dict(options)

    def to_graph(self) -> dict[str, Any]:
        model = self._options.get("model")
        config: dict[str, Any] = {
            "instructions": self._options.get("instructions") or "",
            "tools": _normalize_refs(self._options.get("tools")),
            "toolsets": _normalize_refs(self._options.get("toolsets")),
        }
        if model:
            config["model_id"] = _ref_id(model)
        return {
            "spec_version": "4.0",
            "workflow_contract": {"inputs": []},
            "state_contract": {"variables": []},
            "nodes": [
                {"id": "start", "type": "start", "position": {"x": 0, "y": 0}, "config": {}},
                {"id": "agent", "type": "agent", "position": {"x": 260, "y": 0}, "config": config},
                {"id": "end", "type": "end", "position": {"x": 520, "y": 0}, "config": {}},
            ],
            "edges": [
                {"id": "start-agent", "source": "start", "target": "agent", "type": "control"},
                {"id": "agent-end", "source": "agent", "target": "end", "type": "control"},
            ],
        }

    def to_create_request(self) -> dict[str, Any]:
        knowledge_refs = _normalize_refs(self._options.get("knowledge"))
        memory = dict(self._options.get("memory") or {})
        if knowledge_refs:
            memory.update(
                {
                    "long_term_enabled": True,
                    "long_term_index_id": knowledge_refs[0],
                    "knowledge_refs": knowledge_refs,
                }
            )
        return {
            "name": self._options["name"],
            "description": self._options.get("description"),
            "graph_definition": self.to_graph(),
            "memory_config": memory,
            "execution_constraints": dict(self._options.get("execution") or {}),
        }

    def create(self, options: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._agents.create(self.to_create_request(), options=options)


class GraphBuilder:
    def __init__(self) -> None:
        self._nodes: dict[str, dict[str, Any]] = {}
        self._edges: list[dict[str, Any]] = []

    def node(
        self,
        type_: str,
        config: Mapping[str, Any] | None = None,
        *,
        id: str | None = None,
        x: int | float | None = None,
        y: int | float | None = None,
        label: str | None = None,
    ) -> dict[str, Any]:
        node_id = id or f"{type_}_{len(self._nodes) + 1}"
        if node_id in self._nodes:
            raise ValueError(f"Duplicate graph node id: {node_id}")
        node = {
            "id": node_id,
            "type": type_,
            "position": {"x": x if x is not None else len(self._nodes) * 260, "y": y if y is not None else 0},
            "config": dict(config or {}),
        }
        if label:
            node["label"] = label
        self._nodes[node_id] = node
        return node

    def connect(
        self,
        source: str | Mapping[str, Any],
        target: str | Mapping[str, Any],
        *,
        id: str | None = None,
        source_handle: str | None = None,
        target_handle: str | None = None,
    ) -> "GraphBuilder":
        source_id = source if isinstance(source, str) else str(source["id"])
        target_id = target if isinstance(target, str) else str(target["id"])
        if source_id not in self._nodes:
            raise ValueError(f"Unknown source node id: {source_id}")
        if target_id not in self._nodes:
            raise ValueError(f"Unknown target node id: {target_id}")
        edge = {"id": id or f"{source_id}-{target_id}", "source": source_id, "target": target_id, "type": "control"}
        if source_handle:
            edge["source_handle"] = source_handle
        if target_handle:
            edge["target_handle"] = target_handle
        self._edges.append(edge)
        return self

    def to_graph(self) -> dict[str, Any]:
        return {
            "spec_version": "4.0",
            "workflow_contract": {"inputs": []},
            "state_contract": {"variables": []},
            "nodes": list(self._nodes.values()),
            "edges": list(self._edges),
        }
