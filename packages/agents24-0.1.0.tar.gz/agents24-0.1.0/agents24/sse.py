from __future__ import annotations

import json
from collections.abc import Iterable

from .errors import Agents24SDKError
from .types import RuntimeEvent


def _parse_sse_block(block: str) -> str | None:
    data_lines: list[str] = []
    for raw_line in block.split("\n"):
        line = raw_line.rstrip("\r")
        if not line or line.startswith(":"):
            continue
        field, _, value = line.partition(":")
        if value.startswith(" "):
            value = value[1:]
        if field == "data":
            data_lines.append(value)
    return "\n".join(data_lines) if data_lines else None


def parse_runtime_event(raw_payload: str) -> RuntimeEvent:
    try:
        parsed = json.loads(raw_payload)
    except Exception as exc:
        raise Agents24SDKError("Malformed SSE event: invalid JSON payload.", kind="protocol", details=raw_payload) from exc
    if not isinstance(parsed, dict) or parsed.get("version") != "run-stream.v2":
        raise Agents24SDKError("SSE protocol mismatch: expected run-stream.v2 event envelopes.", kind="protocol", details=parsed)
    for field in ("seq", "ts", "event", "run_id", "stage"):
        if field not in parsed:
            raise Agents24SDKError("Malformed SSE event: missing required envelope fields.", kind="protocol", details=parsed)
    payload = parsed.get("payload") or {}
    diagnostics = parsed.get("diagnostics") or []
    if not isinstance(payload, dict) or not isinstance(diagnostics, list):
        raise Agents24SDKError("Malformed SSE event payload.", kind="protocol", details=parsed)
    parsed["payload"] = payload
    parsed["diagnostics"] = diagnostics
    return parsed  # type: ignore[return-value]


def consume_event_stream(lines: Iterable[str | bytes]) -> Iterable[RuntimeEvent]:
    buffer: list[str] = []
    for item in lines:
        line = item.decode("utf-8") if isinstance(item, bytes) else str(item)
        if line == "":
            payload = _parse_sse_block("\n".join(buffer))
            buffer = []
            if payload:
                yield parse_runtime_event(payload)
        else:
            buffer.append(line)
    if buffer:
        payload = _parse_sse_block("\n".join(buffer))
        if payload:
            yield parse_runtime_event(payload)
