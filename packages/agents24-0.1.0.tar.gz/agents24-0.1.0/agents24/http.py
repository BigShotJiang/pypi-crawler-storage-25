from __future__ import annotations

import json
import uuid
from collections.abc import Mapping, Sequence
from typing import Any, Callable

import requests

from .errors import Agents24SDKError
from .sse import consume_event_stream
from .types import RequestOptions, RuntimeEvent, StreamResult


class Agents24HttpClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        organization_id: str | None = None,
        project_id: str | None = None,
        timeout: float = 30.0,
        session: requests.Session | None = None,
    ) -> None:
        self.base_url = self._normalize_base_url(base_url)
        self.api_key = str(api_key or "").strip()
        if not self.api_key:
            raise Agents24SDKError("Agents24 requires a non-empty api_key.", kind="protocol")
        self.organization_id = str(organization_id) if organization_id else None
        self.project_id = str(project_id) if project_id else None
        self.timeout = timeout
        self.session = session or requests.Session()

    @staticmethod
    def _normalize_base_url(base_url: str) -> str:
        normalized = str(base_url or "").strip().rstrip("/")
        if not normalized or "://" not in normalized:
            raise Agents24SDKError("Agents24 requires a valid base_url.", kind="protocol")
        return normalized

    def _headers(
        self,
        *,
        accept: str = "application/json",
        content_type: str | None = "application/json",
        mutation: bool = False,
        options: RequestOptions | None = None,
    ) -> dict[str, str]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": accept,
            "X-SDK-Contract": "1",
        }
        if content_type:
            headers["Content-Type"] = content_type
        if self.organization_id:
            headers["X-Organization-ID"] = self.organization_id
        if self.project_id:
            headers["X-Project-ID"] = self.project_id
        if mutation:
            headers["X-Idempotency-Key"] = (options or {}).get("idempotency_key") or str(uuid.uuid4())
        metadata = (options or {}).get("request_metadata")
        if metadata:
            headers["X-Request-Metadata"] = json.dumps(metadata, separators=(",", ":"))
        return headers

    @staticmethod
    def _params(params: Mapping[str, Any] | None, options: RequestOptions | None = None) -> dict[str, Any]:
        merged = {k: v for k, v in dict(params or {}).items() if v not in (None, "")}
        if options and "dry_run" in options:
            merged["dry_run"] = bool(options["dry_run"])
        if options and "validate_only" in options:
            merged["validate_only"] = bool(options["validate_only"])
        return merged

    def request_json(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json_body: Any = None,
        options: RequestOptions | None = None,
        mutation: bool = False,
    ) -> Any:
        try:
            response = self.session.request(
                method=method,
                url=f"{self.base_url}{path}",
                params=self._params(params, options),
                json=json_body,
                headers=self._headers(mutation=mutation, options=options),
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise Agents24SDKError("Failed to connect to the Agents24 API.", kind="network") from exc
        self._raise_for_status(response)
        if response.text:
            return response.json()
        return None

    def request_multipart(
        self,
        method: str,
        path: str,
        *,
        data: Mapping[str, Any],
        files: Sequence[Any],
    ) -> Any:
        form_data = {k: v for k, v in dict(data or {}).items() if v not in (None, "")}
        try:
            response = self.session.request(
                method=method,
                url=f"{self.base_url}{path}",
                data=form_data,
                files={"files": files} if files and not isinstance(files[0], tuple) else list(files),
                headers=self._headers(content_type=None),
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise Agents24SDKError("Failed to connect to the Agents24 attachment endpoint.", kind="network") from exc
        self._raise_for_status(response)
        return response.json()

    def request_stream(
        self,
        method: str,
        path: str,
        *,
        json_body: Mapping[str, Any],
        params: Mapping[str, Any] | None,
        on_event: Callable[[RuntimeEvent], None] | None,
    ) -> StreamResult:
        try:
            response = self.session.request(
                method=method,
                url=f"{self.base_url}{path}",
                params=self._params(params),
                json=dict(json_body),
                headers=self._headers(accept="text/event-stream"),
                timeout=self.timeout,
                stream=True,
            )
        except requests.RequestException as exc:
            raise Agents24SDKError("Failed to connect to the Agents24 stream endpoint.", kind="network") from exc
        self._raise_for_status(response)
        observed_run_id = response.headers.get("X-Run-ID")
        for event in consume_event_stream(response.iter_lines(decode_unicode=True)):
            observed_run_id = observed_run_id or event["run_id"]
            if on_event:
                on_event(event)
        return {
            "thread_id": response.headers.get("X-Thread-ID"),
            "run_id": observed_run_id,
        }

    @staticmethod
    def _raise_for_status(response: requests.Response) -> None:
        if response.status_code < 400:
            return
        details: Any
        try:
            details = response.json()
        except Exception:
            details = response.text
        message = response.reason or "Request failed"
        if isinstance(details, dict):
            detail = details.get("detail")
            if isinstance(detail, str):
                message = detail
            elif isinstance(detail, dict) and isinstance(detail.get("message"), str):
                message = detail["message"]
            elif isinstance(details.get("message"), str):
                message = details["message"]
        elif isinstance(details, str) and details:
            message = details
        raise Agents24SDKError(message, kind="http", status=response.status_code, details=details)
