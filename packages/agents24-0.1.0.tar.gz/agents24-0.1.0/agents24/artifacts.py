_EXPORTS = []


def _json_schema(value):
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_json_schema"):
        return value.model_json_schema()
    if hasattr(value, "schema"):
        return value.schema()
    raise TypeError("schema must be a JSON Schema dict or a Pydantic model")


def _register(kind, fn=None, **options):
    def decorate(handler):
        name = str(options.get("name") or handler.__name__).strip()
        _EXPORTS.append(
            {
                "name": name,
                "kind": kind,
                "description": options.get("description") or getattr(handler, "__doc__", None),
                "input_schema": _json_schema(options.get("input_schema") or options.get("input")),
                "output_schema": _json_schema(options.get("output_schema") or options.get("output")),
                "config_schema": _json_schema(options.get("config_schema") or options.get("config")),
                "ui_schema": dict(options.get("ui_schema") or options.get("ui") or {}),
                "side_effects": list(options.get("side_effects") or []),
                "execution_mode": options.get("execution_mode") or "interactive",
                "handler_ref": options.get("handler_ref") or handler.__name__,
            }
        )
        return handler

    if callable(fn):
        return decorate(fn)
    return decorate


def tool(fn=None, **options):
    return _register("tool", fn, **options)


def agent_node(fn=None, **options):
    return _register("agent_node", fn, **options)


def rag_operator(fn=None, **options):
    return _register("rag_operator", fn, **options)


def artifact(*, exports=None):
    for item in exports or []:
        if isinstance(item, dict):
            _EXPORTS.append(item)
    return {"exports": _EXPORTS}


def describe_exports():
    return list(_EXPORTS)
