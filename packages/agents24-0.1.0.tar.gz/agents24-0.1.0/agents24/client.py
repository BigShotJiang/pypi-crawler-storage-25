from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import requests

from .builders import AgentDefinitionBuilder, GraphBuilder
from .generated.agents import AgentsNamespace
from .generated.embed import EmbedNamespace
from .generated.runs import GeneratedRunsNamespace
from .http import Agents24HttpClient


class RunsNamespace(GeneratedRunsNamespace):
    def get_trace(self, run_id: str) -> dict[str, Any]:
        return {
            "run": self.get(run_id),
            "tree": self.get_tree(run_id),
            "events": self.get_events(run_id),
            "context": self.get_context(run_id),
        }


class Agents24:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        organization_id: str | None = None,
        project_id: str | None = None,
        timeout: float = 30.0,
        session: requests.Session | None = None,
    ) -> None:
        self._http = Agents24HttpClient(
            base_url=base_url,
            api_key=api_key,
            organization_id=organization_id,
            project_id=project_id,
            timeout=timeout,
            session=session,
        )
        self.agents = AgentsNamespace(self._http)
        self.embed = EmbedNamespace(self._http)
        self.runs = RunsNamespace(self._http)

    def agent(self, options: Mapping[str, Any]) -> AgentDefinitionBuilder:
        return AgentDefinitionBuilder(self.agents, options)

    def graph(self) -> GraphBuilder:
        return GraphBuilder()
