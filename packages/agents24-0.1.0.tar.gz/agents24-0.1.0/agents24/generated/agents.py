from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

from ..errors import Agents24SDKError
from ..http import Agents24HttpClient
from ..types import AgentListResponse, AgentResponse, AttachmentUploadResult, RequestOptions, RunCancelResult, RuntimeEvent, StartRunResult, StreamResult

class AgentsNamespace:
    def __init__(self, http: Agents24HttpClient) -> None:
        self._http = http

    def list(self, status: str | None = None, skip: int = 0, limit: int = 20, view: str = "summary") -> AgentListResponse:
        return self._http.request_json("GET", "/agents", params={
            "status": status,
            "skip": skip if skip is not None else 0,
            "limit": limit if limit is not None else 20,
            "view": view if view is not None else "summary",
        }, json_body=None, options=None, mutation=False)

    def get(self, agent_id: str) -> AgentResponse:
        return self._http.request_json("GET", f"/agents/{agent_id}", params=None, json_body=None, options=None, mutation=False)

    def create(self, request: Mapping[str, Any], options: RequestOptions | None = None) -> AgentResponse:
        return self._http.request_json("POST", "/agents", params=None, json_body=request, options=options, mutation=True)

    def update(self, agent_id: str, request: Mapping[str, Any], options: RequestOptions | None = None) -> AgentResponse:
        return self._http.request_json("PATCH", f"/agents/{agent_id}", params=None, json_body=request, options=options, mutation=True)

    def update_graph(self, agent_id: str, graph: Mapping[str, Any], options: RequestOptions | None = None) -> AgentResponse:
        return self._http.request_json("PUT", f"/agents/{agent_id}/graph", params=None, json_body=graph, options=options, mutation=True)

    def delete(self, agent_id: str, options: RequestOptions | None = None) -> Any:
        return self._http.request_json("DELETE", f"/agents/{agent_id}", params=None, json_body=None, options=options, mutation=True)

    def catalog(self) -> Any:
        return self._http.request_json("GET", "/agents/nodes/catalog", params=None, json_body=None, options=None, mutation=False)

    def schema(self, node_types: Any) -> Any:
        return self._http.request_json("POST", "/agents/nodes/schema", params=None, json_body={
            "node_types": node_types,
        }, options=None, mutation=False)

    def validate(self, agent_id: str) -> Any:
        return self._http.request_json("POST", f"/agents/{agent_id}/validate", params=None, json_body={}, options=None, mutation=False)

    def publish(self, agent_id: str, options: RequestOptions | None = None) -> AgentResponse:
        return self._http.request_json("POST", f"/agents/{agent_id}/publish", params=None, json_body={}, options=options, mutation=True)

    def start_run(self, agent_id: str, payload: Mapping[str, Any], options: RequestOptions | None = None) -> StartRunResult:
        return self._http.request_json("POST", f"/agents/{agent_id}/run", params=None, json_body=payload, options=options, mutation=True)

    def stream(self, agent_id: str, payload: Mapping[str, Any], on_event: Callable[[RuntimeEvent], None] | None = None, mode: str | None = None) -> StreamResult:
        return self._http.request_stream("POST", f"/agents/{agent_id}/stream", json_body=dict(payload), params={"mode": mode}, on_event=on_event)

    def resume_run(self, run_id: str, payload: Mapping[str, Any], options: RequestOptions | None = None) -> Any:
        return self._http.request_json("POST", f"/agents/runs/{run_id}/resume", params=None, json_body=payload, options=options, mutation=True)

    def cancel_run(self, run_id: str, assistant_output_text: str | None = None) -> RunCancelResult:
        return self._http.request_json("POST", f"/agents/runs/{run_id}/cancel", params=None, json_body={
            "assistant_output_text": assistant_output_text,
        }, options=None, mutation=True)

    def upload_attachments(self, agent_id: str, files: Sequence[Any], thread_id: str | None = None) -> AttachmentUploadResult:
        return self._http.request_multipart("POST", f"/agents/{agent_id}/attachments/upload", data={
            "thread_id": thread_id,
        }, files=files)
