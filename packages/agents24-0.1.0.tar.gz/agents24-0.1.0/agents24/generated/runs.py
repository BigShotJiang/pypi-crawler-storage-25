from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

from ..errors import Agents24SDKError
from ..http import Agents24HttpClient
from ..types import RequestOptions, RunContext, RunEventsResponse, RunStatus

class GeneratedRunsNamespace:
    def __init__(self, http: Agents24HttpClient) -> None:
        self._http = http

    def get(self, run_id: str, include_tree: bool | None = None) -> RunStatus:
        return self._http.request_json("GET", f"/agents/runs/{run_id}", params={
            "include_tree": include_tree,
        }, json_body=None, options=None, mutation=False)

    def get_tree(self, run_id: str) -> Any:
        return self._http.request_json("GET", f"/agents/runs/{run_id}/tree", params=None, json_body=None, options=None, mutation=False)

    def get_events(self, run_id: str, after_sequence: int | None = None, limit: int | None = None) -> RunEventsResponse:
        return self._http.request_json("GET", f"/agents/runs/{run_id}/events", params={
            "after_sequence": after_sequence,
            "limit": limit,
        }, json_body=None, options=None, mutation=False)

    def get_context(self, run_id: str) -> RunContext:
        return self._http.request_json("GET", f"/agents/runs/{run_id}/context", params=None, json_body=None, options=None, mutation=False)
