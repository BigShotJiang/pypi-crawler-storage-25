from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

from ..errors import Agents24SDKError
from ..http import Agents24HttpClient
from ..types import AttachmentUploadResult, RequestOptions, RunCancelResult, RunContext, RuntimeEvent, StreamResult, ThreadDeleteResult, ThreadDetail, ThreadsResponse

class EmbedNamespace:
    def __init__(self, http: Agents24HttpClient) -> None:
        self._http = http

    def stream_agent(self, agent_id: str, payload: Mapping[str, Any], on_event: Callable[[RuntimeEvent], None] | None = None) -> StreamResult:
        return self._http.request_stream("POST", f"/public/embed/agents/{agent_id}/chat/stream", json_body=dict(payload), params=None, on_event=on_event)

    def list_agent_threads(self, agent_id: str, external_user_id: Any = None, external_session_id: Any = None, skip: Any = 0, limit: Any = 20) -> ThreadsResponse:
        return self._http.request_json("GET", f"/public/embed/agents/{agent_id}/threads", params={
            "external_user_id": external_user_id,
            "external_session_id": external_session_id,
            "skip": skip if skip is not None else 0,
            "limit": limit if limit is not None else 20,
        }, json_body=None, options=None, mutation=False)

    def get_agent_thread(self, agent_id: str, thread_id: str, external_user_id: Any = None, external_session_id: Any = None, before_turn_index: Any = None, limit: Any = None, include_subthreads: Any = None, subthread_depth: Any = None, subthread_turn_limit: Any = None, subthread_child_limit: Any = None) -> ThreadDetail:
        return self._http.request_json("GET", f"/public/embed/agents/{agent_id}/threads/{thread_id}", params={
            "external_user_id": external_user_id,
            "external_session_id": external_session_id,
            "before_turn_index": before_turn_index,
            "limit": limit,
            "include_subthreads": include_subthreads,
            "subthread_depth": subthread_depth,
            "subthread_turn_limit": subthread_turn_limit,
            "subthread_child_limit": subthread_child_limit,
        }, json_body=None, options=None, mutation=False)

    def delete_agent_thread(self, agent_id: str, thread_id: str, external_user_id: Any = None, external_session_id: Any = None, options: RequestOptions | None = None) -> ThreadDeleteResult:
        return self._http.request_json("DELETE", f"/public/embed/agents/{agent_id}/threads/{thread_id}", params={
            "external_user_id": external_user_id,
            "external_session_id": external_session_id,
        }, json_body=None, options=options, mutation=True)

    def get_agent_run_context(self, agent_id: str, run_id: str, external_user_id: Any = None, external_session_id: Any = None) -> RunContext:
        return self._http.request_json("GET", f"/public/embed/agents/{agent_id}/runs/{run_id}/context", params={
            "external_user_id": external_user_id,
            "external_session_id": external_session_id,
        }, json_body=None, options=None, mutation=False)

    def cancel_agent_run(self, agent_id: str, run_id: str, external_user_id: Any = None, external_session_id: Any = None, assistant_output_text: str | None = None) -> RunCancelResult:
        return self._http.request_json("POST", f"/public/embed/agents/{agent_id}/runs/{run_id}/cancel", params={
            "external_user_id": external_user_id,
            "external_session_id": external_session_id,
        }, json_body={
            "assistant_output_text": assistant_output_text,
        }, options=None, mutation=True)

    def upload_agent_attachments(self, agent_id: str, files: Sequence[Any], external_user_id: str | None = None, external_session_id: str | None = None, thread_id: str | None = None) -> AttachmentUploadResult:
        if not external_user_id:
            raise Agents24SDKError("upload_agent_attachments requires external_user_id.", kind="protocol")
        return self._http.request_multipart("POST", f"/public/embed/agents/{agent_id}/attachments/upload", data={
            "external_user_id": external_user_id,
            "external_session_id": external_session_id,
            "thread_id": thread_id,
        }, files=files)
