from __future__ import annotations

from typing import Any


class Agents24SDKError(Exception):
    def __init__(
        self,
        message: str,
        *,
        kind: str,
        status: int | None = None,
        details: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.kind = kind
        self.status = status
        self.details = details
