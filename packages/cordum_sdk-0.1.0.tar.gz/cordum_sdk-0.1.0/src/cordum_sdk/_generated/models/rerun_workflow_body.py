from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Union






T = TypeVar("T", bound="RerunWorkflowBody")


@_attrs_define
class RerunWorkflowBody:
    """ 
        Attributes:
            from_step (Union[Unset, str]): Step ID to resume from
            dry_run (Union[Unset, bool]):  Default: False.
     """

    from_step: Union[Unset, str] = UNSET
    dry_run: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        from_step = self.from_step

        dry_run = self.dry_run


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if from_step is not UNSET:
            field_dict["from_step"] = from_step
        if dry_run is not UNSET:
            field_dict["dry_run"] = dry_run

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        from_step = d.pop("from_step", UNSET)

        dry_run = d.pop("dry_run", UNSET)

        rerun_workflow_body = cls(
            from_step=from_step,
            dry_run=dry_run,
        )


        rerun_workflow_body.additional_properties = d
        return rerun_workflow_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
