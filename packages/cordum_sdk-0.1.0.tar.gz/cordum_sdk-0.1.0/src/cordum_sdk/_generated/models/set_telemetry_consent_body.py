from typing import Any, Dict, Type, TypeVar, Tuple, Optional, BinaryIO, TextIO, TYPE_CHECKING

from typing import List


from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.set_telemetry_consent_body_mode import SetTelemetryConsentBodyMode






T = TypeVar("T", bound="SetTelemetryConsentBody")


@_attrs_define
class SetTelemetryConsentBody:
    """ 
        Attributes:
            mode (SetTelemetryConsentBodyMode):
     """

    mode: SetTelemetryConsentBodyMode
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> Dict[str, Any]:
        mode = self.mode.value


        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "mode": mode,
        })

        return field_dict



    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        mode = SetTelemetryConsentBodyMode(d.pop("mode"))




        set_telemetry_consent_body = cls(
            mode=mode,
        )


        set_telemetry_consent_body.additional_properties = d
        return set_telemetry_consent_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
