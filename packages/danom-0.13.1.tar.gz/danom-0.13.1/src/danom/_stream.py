from __future__ import annotations

import asyncio
import itertools
import os
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable, Iterable
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from copy import deepcopy
from enum import Enum
from functools import partial, reduce
from itertools import batched
from typing import ParamSpec, TypeVar, cast

import attrs

from danom._either import Either
from danom._result import Result

T = TypeVar("T")
U = TypeVar("U")
E = TypeVar("E")
P = ParamSpec("P")

MapFn = Callable[P, U]
FilterFn = Callable[P, bool]
TapFn = Callable[P, None]

AsyncMapFn = Callable[P, Awaitable[U]]
AsyncFilterFn = Callable[P, Awaitable[bool]]
AsyncTapFn = Callable[P, Awaitable[None]]

StreamFn = MapFn | FilterFn | TapFn
AsyncStreamFn = AsyncMapFn | AsyncFilterFn | AsyncTapFn


@attrs.define(frozen=True)
class _BaseStream[T](ABC):
    seq: tuple = attrs.field(validator=attrs.validators.instance_of(tuple))
    ops: tuple = attrs.field(default=(), validator=attrs.validators.instance_of(tuple), repr=False)

    @classmethod
    @abstractmethod
    def from_iterable(cls, it: Iterable) -> _BaseStream[T]: ...

    @abstractmethod
    def map[**P](
        self, fn: MapFn | AsyncMapFn, *args: P.args, **kwargs: P.kwargs
    ) -> _BaseStream[T]: ...

    @abstractmethod
    def filter[**P](
        self, fn: FilterFn | AsyncFilterFn, *args: P.args, **kwargs: P.kwargs
    ) -> _BaseStream[T]: ...

    @abstractmethod
    def tap[**P](
        self, fn: TapFn | AsyncTapFn, *args: P.args, **kwargs: P.kwargs
    ) -> _BaseStream[T]: ...

    @abstractmethod
    def partition[U](
        self, fn: FilterFn, *, workers: int = 1, use_threads: bool = False
    ) -> tuple[_BaseStream[T], _BaseStream[U]]: ...

    @abstractmethod
    def fold(
        self, initial: T, fn: Callable[[T, U], T], *, workers: int = 1, use_threads: bool = False
    ) -> T: ...

    @abstractmethod
    def collect(self) -> tuple[U, ...]: ...

    @abstractmethod
    def par_collect(self, workers: int = 4, *, use_threads: bool = False) -> tuple[U, ...]: ...

    @abstractmethod
    async def async_collect(self) -> Awaitable[tuple[U, ...]]: ...

    def __bool__(self) -> bool:
        return bool(self.seq)


@attrs.define(frozen=True)
class Stream[T](_BaseStream):
    """An immutable lazy iterator with functional operations.

    Why bother?
    -----------

    Readability counts, abstracting common operations helps reduce cognitive complexity when reading code.

    Comparison
    ----------

    Take this imperative pipeline of operations, it iterates once over the data, skipping the value if it fails one of the filter checks:

    .. code-block:: python

        res = []

        for x in range(1_000_000):
            item = triple(x)

            if not is_gt_ten(item):
                continue

            item = min_two(item)

            if not is_even_num(item):
                continue

            item = square(item)

            if not is_lt_400(item):
                continue

            res.append(item)
        [100, 256]

    number of tokens: `90`

    number of keywords: `11`

    keyword breakdown: `{'for': 1, 'in': 1, 'if': 3, 'not': 3, 'continue': 3}`

    After a bit of experience with python you might use list comprehensions, however this is arguably _less_ clear and iterates multiple times over the same data

    .. code-block:: python

        mul_three = [triple(x) for x in range(1_000_000)]
        gt_ten = [x for x in mul_three if is_gt_ten(x)]
        sub_two = [min_two(x) for x in gt_ten]
        is_even = [x for x in sub_two if is_even_num(x)]
        squared = [square(x) for x in is_even]
        lt_400 = [x for x in squared if is_lt_400(x)]
        [100, 256]

    number of tokens: `92`

    number of keywords: `15`

    keyword breakdown: `{'for': 6, 'in': 6, 'if': 3}`

    This still has a lot of tokens that the developer has to read to understand the code. The extra keywords add noise that cloud the actual transformations.

    Using a ``Stream`` results in this:

    .. code-block:: python

        from danom import Stream

        (
            Stream.from_iterable(range(1_000_000))
            .map(triple)
            .filter(is_gt_ten)
            .map(min_two)
            .filter(is_even_num)
            .map(square)
            .filter(is_lt_400)
            .collect()
        )
        (100, 256)

    number of tokens: `60`

    number of keywords: `0`

    keyword breakdown: `{}`

    The business logic is arguably much clearer like this.

    Version changes
    ----------
    ``0.13.0``: ``Stream.map``, ``Stream.filter`` and ``Stream.tap`` now take kwargs and ``partial`` them into the passed in function.

    """

    @classmethod
    def from_iterable(cls, it: Iterable) -> Stream[T]:
        """This is the recommended way of creating a `Stream` object.

        .. doctest::

            >>> from danom import Stream

            >>> Stream.from_iterable([0, 1, 2, 3]).collect() == (0, 1, 2, 3)
            True
        """
        if not isinstance(it, Iterable):
            it = [it]
        return cls(seq=tuple(it))

    def map[**P](self, fn: MapFn | AsyncMapFn, *args: P.args, **kwargs: P.kwargs) -> Stream[T]:
        """Map a function to the elements in the ``Stream``. Will return a new ``Stream`` with the modified sequence.

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable([0, 1, 2, 3]).map(add_one).collect() == (1, 2, 3, 4)

        This can also be mixed with ``safe`` functions:

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable([0, 1, 2, 3]).map(add_one).collect() == (Ok(1), Ok(2), Ok(3), Ok(4))

            @safe
            def two_div_value(x: float) -> float:
                return 2 / x

            Stream.from_iterable([0, 1, 2, 4]).map(two_div_value).collect() == (Err(error=ZeroDivisionError('division by zero')), Ok(2.0), Ok(1.0), Ok(0.5))


        Keyword arguments can be passed into the functions:

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable(range(5)).map(mul, b=2).map(add, b=1).collect() == (1, 3, 5, 7, 9)

        """
        plan = (*self.ops, (_MAP, partial(fn, *args, **kwargs)))
        object.__setattr__(self, "ops", plan)
        return self

    def filter[**P](
        self, fn: FilterFn | AsyncFilterFn, *args: P.args, **kwargs: P.kwargs
    ) -> Stream[T]:
        """Filter the stream based on a predicate. Will return a new ``Stream`` with the modified sequence.

        .. doctest::

            >>> from danom import Stream

            >>> Stream.from_iterable([0, 1, 2, 3]).filter(lambda x: x % 2 == 0).collect() == (0, 2)
            True

        Keyword arguments can be passed into the functions:

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable(range(20)).filter(divisible_by, x=3).filter(divisible_by, x=5).collect() == (0, 15)

        """
        plan = (*self.ops, (_FILTER, partial(fn, *args, **kwargs)))
        object.__setattr__(self, "ops", plan)
        return self

    def tap[**P](self, fn: TapFn | AsyncTapFn, *args: P.args, **kwargs: P.kwargs) -> Stream[T]:
        """Tap the values to another process that returns None. Will return a new ``Stream`` with the modified sequence.

        The value passed to the tap function will be deep-copied to avoid any modification to the ``Stream`` item for downstream consumers.

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable([0, 1, 2, 3]).tap(log_value).collect() == (0, 1, 2, 3)


        Simple functions can be passed in sequence for multiple ``tap`` operations

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable([0, 1, 2, 3]).tap(log_value).tap(print_value).collect() == (0, 1, 2, 3)


        ``tap`` is useful for logging and similar actions without effecting the individual items, in this example eligible and dormant users are logged using ``tap``:

        .. code-block:: python

            from danom import Stream

            active_users, inactive_users = (
                Stream.from_iterable(users).map(parse_user_objects).partition(inactive_users)
            )

            active_users.filter(eligible_for_promotion).tap(log_eligible_users).map(construct_promo_email).map(send_with_confirmation).collect()

            inactive_users.tap(log_inactive_users).map(create_dormant_user_entry).map(add_to_dormant_table).collect()

        """
        plan = (*self.ops, (_TAP, partial(fn, *args, **kwargs)))
        object.__setattr__(self, "ops", plan)
        return self

    def partition(
        self, fn: FilterFn, *, workers: int = 1, use_threads: bool = False
    ) -> tuple[Stream[T], Stream[U]]:
        """Similar to ``filter`` except splits the ``True`` and ``False`` values. Will return a two new ``Stream`` with the partitioned sequences.

        Each partition is independently replayable.

        .. doctest::

            from danom import Stream

            >>> part1, part2 = Stream.from_iterable([0, 1, 2, 3]).partition(lambda x: x % 2 == 0)
            >>> part1.collect() == (0, 2)
            True
            >>> part2.collect() == (1, 3)
            True

        As ``partition`` triggers an action, the parameters will be forwarded to the ``par_collect`` call if the ``workers`` are greater than 1.

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable(range(10)).map(add_one).map(add_one).partition(divisible_by_3, workers=4)
            part1.map(add_one).par_collect() == (4, 7, 10)
            part2.collect() == (2, 4, 5, 7, 8, 10, 11)

        """
        # have to materialise to be able to replay each side independently
        if workers > 1:
            seq_tuple = self.par_collect(workers=workers, use_threads=use_threads)
        else:
            seq_tuple = self.collect()

        pos, neg = [], []

        for x in seq_tuple:
            if fn(x):
                pos.append(x)
            else:
                neg.append(x)
        return (Stream.from_iterable(pos), Stream.from_iterable(neg))

    def sequence(
        self, *, workers: int = 1, use_threads: bool = False
    ) -> Result[T, E] | Either[T, E]:
        """Convert a ``Stream`` of ``Result`` or ``Either`` monads to a monad of Stream

        .. doctest::

            >>> from danom import Ok, Stream

            >>> Stream.from_iterable((Ok(0), Ok(1), Ok(2))).sequence() == Ok(Stream.from_iterable((0, 1, 2)))
            True

            >>> Stream.from_iterable((Right(0), Right(1), Right(2))).sequence() == Right(Stream.from_iterable((0, 1, 2)))
            True

            >>> Stream.from_iterable((Ok(0), Err(1), Ok(2))).sequence() == Err(1)
            True

            >>> Stream.from_iterable((Right(0), Left(1), Right(2))).sequence() == Left(1)
            True

        If the ``Stream`` is of mixed monads, the final wrapped result will be ok the last seen monad type

        .. doctest::

            >>> from danom import Ok, Stream

            >>> Stream.from_iterable((Right(0), Right(1), Ok(2))).sequence() == Ok(Stream.from_iterable((0, 1, 2)))
            True

        """

        if workers > 1:
            seq_tuple = self.par_collect(workers=workers, use_threads=use_threads)
        else:
            seq_tuple = self.collect()

        if not all(isinstance(res, (Result, Either)) for res in seq_tuple):
            raise TypeError("All elements in the `Stream` must be of `Result` or `Either` type")

        results = []

        for res in seq_tuple:
            if not res.is_ok():
                return res
            results.append(res.unwrap())

        return type(res)(Stream.from_iterable(results))

    def fold(
        self, initial: T, fn: Callable[[T, U], T], *, workers: int = 1, use_threads: bool = False
    ) -> T:
        """Fold the results into a single value. ``fold`` triggers an action so will incur a ``collect``.

        .. doctest::

            >>> from danom import Stream

            >>> Stream.from_iterable([1, 2, 3, 4]).fold(0, lambda a, b: a + b) == 10
            True
            >>> Stream.from_iterable([[1], [2], [3], [4]]).fold([0], lambda a, b: a + b) == [0, 1, 2, 3, 4]
            True
            >>> Stream.from_iterable([1, 2, 3, 4]).fold(1, lambda a, b: a * b) == 24
            True


        As ``fold`` triggers an action, the parameters will be forwarded to the ``par_collect`` call if the ``workers`` are greater than 1.
        This will only effect the ``collect`` that is used to create the iterable to reduce, not the ``fold`` operation itself.

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable([1, 2, 3, 4]).map(some_expensive_fn).fold(0, add, workers=4, use_threads=False)

        """
        if workers > 1:
            return reduce(fn, self.par_collect(workers=workers, use_threads=use_threads), initial)
        return reduce(fn, self.collect(), initial)

    def collect(self) -> tuple[U, ...]:
        """Materialise the sequence from the ``Stream``.

        .. code-block:: python

            from danom import Stream

            stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
            stream.collect() == (1, 2, 3, 4)

        """
        return tuple(_apply_fns(self.seq, self.ops))

    def par_collect(self, workers: int = 4, *, use_threads: bool = False) -> tuple[U, ...]:
        """Materialise the sequence from the ``Stream`` in parallel.

        .. code-block:: python

            from danom import Stream

            stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
            stream.par_collect() == (1, 2, 3, 4)

        Use the ``workers`` arg to select the number of workers to use. Use ``-1`` to use all available processors (except 1).
        Defaults to ``4``.

        .. code-block:: python

            from danom import Stream

            stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
            stream.par_collect(workers=-1) == (1, 2, 3, 4)

        For smaller I/O bound tasks use the ``use_threads`` flag as ``True``.
        If False the processing will use ``ProcessPoolExecutor`` else it will use ``ThreadPoolExecutor``.

        .. code-block:: python

            from danom import Stream

            stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
            stream.par_collect(use_threads=True) == (1, 2, 3, 4)

        Note that all operations should be pickle-able, for that reason ``Stream`` does not support lambdas or closures.
        """
        if workers == -1:
            workers = (os.cpu_count() or 5) - 1

        executor_cls = ThreadPoolExecutor if use_threads else ProcessPoolExecutor

        batches = [
            (list(chunk), self.ops)
            for chunk in batched(self.seq, n=max(4, len(self.seq) // workers))
        ]

        with executor_cls(max_workers=workers) as ex:
            return cast(
                tuple[U, ...],
                tuple(itertools.chain.from_iterable(ex.map(_apply_fns_worker, batches))),
            )

    async def async_collect(self) -> Awaitable[tuple[U, ...]]:
        """Async version of collect. Note that all functions in the stream should be ``Awaitable``.

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable(file_paths).map(async_read_files).async_collect()

        If there are no operations in the ``Stream`` then this will act as a normal collect.

        .. code-block:: python

            from danom import Stream

            Stream.from_iterable(file_paths).async_collect()

        """
        if not self.ops:
            return cast(Awaitable[tuple[U, ...]], self.collect())

        res = await asyncio.gather(*(_async_apply_fns(x, self.ops) for x in self.seq))
        return cast(
            Awaitable[tuple[U, ...]], tuple(elem for elem in res if elem != _Nothing.NOTHING)
        )


_MAP = 0
_FILTER = 1
_TAP = 2


class _Nothing(Enum):
    NOTHING = 0


PlannedOps = tuple[str, StreamFn]
AsyncPlannedOps = tuple[str, AsyncStreamFn]


def _apply_fns_worker[T](args: tuple[tuple[T], tuple[PlannedOps, ...]]) -> tuple[T, ...]:
    seq, ops = args
    return _par_apply_fns(seq, ops)


@attrs.define(frozen=True, hash=True, eq=True)
class _Tap:
    fn: Callable

    def __call__(self, value: T) -> T:
        deepcopy(self.fn(value))
        return value


def _apply_fns[T](elements: tuple[T], ops: tuple[PlannedOps, ...]) -> tuple[T, ...]:
    pipeline = elements
    for op, fn in ops:
        if op == _MAP:
            pipeline = map(fn, pipeline)
        elif op == _FILTER:
            pipeline = filter(fn, pipeline)
        elif op == _TAP:
            pipeline = map(_Tap(fn), pipeline)
        else:
            raise RuntimeError("Invalid operation selected. Valid options [map, filter, tap]")

    return tuple(pipeline)  # ty: ignore[invalid-return-type]


def _par_apply_fns[T](elements: tuple[T], ops: tuple[PlannedOps, ...]) -> tuple[T, ...]:
    results = []
    for elem in elements:
        valid = True
        res = elem
        for op, op_fn in ops:
            if op == _MAP:
                res = op_fn(res)
            elif op == _FILTER and not op_fn(res):
                valid = False
                break
            elif op == _TAP:
                op_fn(deepcopy(res))
        if valid:
            results.append(res)
    return tuple(results)


async def _async_apply_fns[T](elem: T, ops: tuple[AsyncPlannedOps, ...]) -> T | _Nothing:
    res = elem
    for op, op_fn in ops:
        if op == _MAP:
            res = await op_fn(res)
        elif op == _FILTER and not await op_fn(res):
            return _Nothing.NOTHING
        elif op == _TAP:
            await op_fn(deepcopy(res))
    return res  # ty: ignore[invalid-return-type]
