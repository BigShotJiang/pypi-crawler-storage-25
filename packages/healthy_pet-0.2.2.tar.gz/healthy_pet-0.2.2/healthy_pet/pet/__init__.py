"""Desktop pet visual layer."""
