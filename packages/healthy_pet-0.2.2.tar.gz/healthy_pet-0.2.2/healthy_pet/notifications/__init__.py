"""Notification and bubble UI."""
