"""FUSE-based file picker integration."""

__version__ = "0.1.0"
