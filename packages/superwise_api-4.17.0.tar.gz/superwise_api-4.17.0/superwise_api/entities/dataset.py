import json
from typing import Optional

from pydantic import conint

from superwise_api.client.models.page import Page
from superwise_api.entities.base import BaseApi, CoreEntitiyApi
from superwise_api.models.dataset.dataset import Dataset, NaturalLanguageQueryResponse, SqlQueryResponse
from superwise_api.models.dataset.dataset_schema import RecordLogMessage
from superwise_api.models.dataset_source.dataset_source import DatasetSource
from superwise_api.models.dataset_source.dataset_source import IngestType


class DatasetApi(CoreEntitiyApi):
    """
    This class provides methods to interact with the Dataset API.

    Attributes:
        api_client (ApiClient): An instance of the ApiClient to make requests.
        _model_name (str): The name of the model.
        _resource_path (str): The path of the resource.
        _dataset_source_model_name (str): The name of the dataset source model.
        _dataset_source_path (str): The path of the dataset source resource.
    """

    _model_name = "dataset"
    _dataset_source_model_name = "dataset_source"
    _resource_path = "/v1/datasets"
    _dataset_source_path = "/v1/dataset-sources"
    _model_class = Dataset

    def delete(self, dataset_id: str, **kwargs):
        """
        Deletes a dataset.

        Args:
            dataset_id (str): The id of the dataset to delete.
            **kwargs: Arbitrary keyword arguments.
        """
        return super().delete(_id=dataset_id, **kwargs)

    def get_by_id(self, dataset_id: str, **kwargs) -> Dataset:
        """
        Retrieves a dataset by its id.

        Args:
            dataset_id (str): The id of the dataset to retrieve.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Dataset: The retrieved dataset.
        """
        return super().get_by_id(_id=dataset_id, **kwargs)

    def create(
        self,
        name: str,
        description: Optional[str] = None,
        schema: Optional[dict] = None,
        **kwargs,
    ) -> Dataset:
        """
        Creates a new dataset.

        Args:
            name (str): The name of the dataset.
            description (str, optional): The description of the dataset.
            schema (dict, optional): The schema of the dataset.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Dataset: The created dataset.
        """
        data = {k: v for k, v in dict(name=name, description=description, schema=schema).items() if v is not None}
        return self.api_client.create(
            resource_path=self._resource_path, model_name=self._model_name, model_class=Dataset, data=data, **kwargs
        )

    def get(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
        id: Optional[str] = None,
        model_version_id: Optional[str] = None,
        created_by: Optional[str] = None,
        page: Optional[conint(strict=True, ge=1)] = None,
        size: Optional[conint(strict=True, le=500, ge=1)] = None,
        **kwargs,
    ) -> Page:
        """
        Retrieves datasets based on the provided filters.

        Args:
            name (Optional[str], optional): The name of the dataset to retrieve.
            description (Optional[str], optional): The description of the dataset to retrieve.
            id (Optional[str], optional): The id of the dataset to retrieve.
            model_version_id (Optional[str], optional): The model version id of the dataset to retrieve.
            created_by (Optional[str], optional): The creator of the dataset to retrieve.
            page (Optional[conint(strict=True, ge=1)], optional): The page number to retrieve.
            size (Optional[conint(strict=True, le=500, ge=1)], optional): The number of datasets to retrieve per page.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Page: A page of datasets.
        """
        query_params = {
            k: v
            for k, v in dict(
                name=name,
                description=description,
                id=id,
                model_version_id=model_version_id,
                created_by=created_by,
                page=page,
                size=size,
            ).items()
            if v is not None
        }
        return self.api_client.get(
            resource_path=self._resource_path,
            model_name=self._model_name,
            model_class=Dataset,
            query_params=query_params,
            **kwargs,
        )

    def update(
        self,
        dataset_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        schema: Optional[dict] = None,
        **kwargs,
    ) -> Dataset:
        """
        Updates a dataset.

        Args:
            dataset_id (str): The id of the dataset to update.
            name (str, optional): The new name of the dataset.
            description (str, optional): The new description of the dataset.
            schema (dict, optional): The new schema of the dataset.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Dataset: The updated dataset.
        """
        if not any([name, description, schema]):
            raise ValueError("At least one parameter must be provided to update the dataset.")

        data = {k: v for k, v in dict(name=name, description=description, schema=schema).items() if v is not None}
        return self.api_client.update(
            resource_path=self._resource_path,
            entity_id=dataset_id,
            model_name=self._model_name,
            model_class=Dataset,
            data=data,
            **kwargs,
        )

    @BaseApi.raise_exception
    def connect_to_source(self, dataset_id: str, source_id: str, ingest_type: IngestType, folder: str, **kwargs):
        """
        Connects a dataset to a source.

        Args:
            dataset_id (str): The id of the dataset to connect.
            source_id (str): The id of the source to connect to.
            ingest_type (IngestType): The ingestion type.
            folder (str): The folder path to connect to inside the bucket. e.g. "folder1/folder2".
            **kwargs: Arbitrary keyword arguments.
        """
        data = dict(dataset_id=dataset_id, source_id=source_id, ingest_type=ingest_type, folder=folder)
        return self.api_client.create(
            resource_path=self._dataset_source_path,
            model_name=self._dataset_source_model_name,
            model_class=DatasetSource,
            data=data,
            **kwargs,
        )

    @BaseApi.raise_exception
    def get_connected_sources(self, dataset_id: str, **kwargs) -> Page:
        """
        Retrieves the sources connected to a dataset.

        Args:
            dataset_id (str): The id of the dataset to retrieve the connected sources for.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Page: A page of connected sources.
        """
        return self.api_client.get(
            resource_path=f"{self._dataset_source_path}",
            model_name=self._dataset_source_model_name,
            model_class=DatasetSource,
            query_params={"dataset_id": dataset_id},
            **kwargs,
        )

    @BaseApi.raise_exception
    def get_models_for_dataset(
        self,
        dataset_id: str,
        **kwargs,
    ) -> Page:
        """
        Retrieves all models for a dataset.

        Args:
            dataset_id (str): The id of the dataset.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Page: A page of models.
        """
        return self.api_client.get(
            resource_path=f"{self._resource_path}/{dataset_id}/models",
            model_name=self._model_name,
            model_class=Dataset,
            **kwargs,
        )

    def log_record_to_dataset(
        self,
        dataset_id: str,
        data: dict,
        images: dict[str, tuple[bytes, str]] | None = None,
        **kwargs,
    ):
        """Log a record to a dataset.

        Args:
            dataset_id: The dataset id.
            data: Record data as a dict.
            images: Optional image uploads keyed by schema field name.
                Each value is a ``(image_bytes, content_type)`` tuple,
                e.g. ``{"photo": (raw_bytes, "image/jpeg")}``.
        """
        if images:
            return self._log_record_with_images(dataset_id, data, images, **kwargs)
        return self.api_client.post(
            resource_path=f"{self._resource_path}/{dataset_id}/log",
            data=RecordLogMessage(record=data).model_dump(),
            **kwargs,
        )

    def _log_record_with_images(
        self,
        dataset_id: str,
        data: dict,
        images: dict[str, tuple[bytes, str]],
        **kwargs,
    ):
        """Send a multipart/form-data log request with embedded images."""
        post_params = [("record", json.dumps(data))]
        for field_name, (image_bytes, content_type) in images.items():
            post_params.append((field_name, (field_name, image_bytes, content_type)))

        return self.api_client.call_api(
            f"{self._resource_path}/{dataset_id}/log",
            "POST",
            header_params={"Content-Type": "multipart/form-data"},
            post_params=post_params,
            response_types_map={},
            auth_settings=["implicit"],
            _return_http_data_only=True,
            _preload_content=True,
        )

    def log_batch_to_dataset(self, dataset_id: str, records: list[dict]) -> dict:
        """Log multiple records via ``POST /v1/datasets/log-batch`` (JSON body, ``x-dataset-id`` header).

        Each item in ``records`` is the inner record dict (field names → values), e.g. for ``image_link``
        fields use ``{"type": "image_link", "url": "https://..."}`` per schema.
        """
        body = [RecordLogMessage(record=r).model_dump() for r in records]
        return self.api_client.call_api(
            f"{self._resource_path}/log-batch",
            "POST",
            header_params={"x-dataset-id": dataset_id},
            body=body,
            response_types_map={"202": object},
            auth_settings=["implicit"],
            _return_http_data_only=True,
            _preload_content=True,
        )

    def update_record_in_dataset(self, dataset_id: str, key_field: str, key_value: str, record: dict, **kwargs):
        """Update a record via ``POST /{dataset_id}/update`` (async; waits for row then publishes)."""
        return self.api_client.post(
            resource_path=f"{self._resource_path}/{dataset_id}/update",
            data={"key_field": key_field, "key_value": key_value, "record": record},
            **kwargs,
        )

    def get_media(self, dataset_id: str, image_id: str, thumbnail: bool = False, **kwargs) -> tuple[str, bytes]:
        """Retrieve a single image from a dataset.

        Args:
            dataset_id: The dataset that owns the image.
            image_id: Image UUID to retrieve.
            thumbnail: When True, return a down-scaled thumbnail instead of the full image.

        Returns:
            ``(content_type, image_bytes)`` tuple,
            e.g. ``("image/jpeg", b"\\xff\\xd8...")``.
        """
        payload = {"dataset_id": dataset_id, "image_id": image_id, "thumbnail": thumbnail}

        response = self.api_client.call_api(
            f"{self._resource_path}/get-media",
            "POST",
            body=payload,
            response_types_map={"200": "bytearray"},
            auth_settings=["implicit"],
            _return_http_data_only=True,
            _preload_content=True,
        )
        content_type = self.api_client.last_response.getheader("Content-Type", "application/octet-stream")
        return content_type, response

    def execute_query(self, sql: str, **kwargs) -> SqlQueryResponse:
        """
        Executes a raw SELECT SQL query and returns the results.

        Args:
            sql (str): A raw SELECT SQL query to execute.
            **kwargs: Arbitrary keyword arguments passed to the API client.

        Returns:
            RawSqlResponse: Contains a valid flag, optional error message, and query data.
        """
        return self._post_query(sql=sql, validate_only=False, **kwargs)

    def validate_query(self, sql: str, **kwargs) -> SqlQueryResponse:
        """
        Validates a raw SELECT SQL query without executing it.

        Args:
            sql (str): A raw SELECT SQL query to validate.
            **kwargs: Arbitrary keyword arguments passed to the API client.

        Returns:
            RawSqlResponse: Contains a valid flag and optional error message. Data is always None.
        """
        return self._post_query(sql=sql, validate_only=True, **kwargs)

    def _post_query(self, sql: str, validate_only: bool, **kwargs) -> SqlQueryResponse:
        response_types_map = {
            "200": SqlQueryResponse,
            "400": None,
            "422": None,
            "500": None,
        }
        return self.api_client.post(
            resource_path=self._resource_path + "/sql-query",
            data={"sql": sql, "validate_only": validate_only},
            response_types_map=response_types_map,
            **kwargs,
        )

    def execute_nl_query(self, query: str, dataset_ids: list[str], **kwargs) -> NaturalLanguageQueryResponse:
        """
        Convert a natural language request to SQL and execute it.

        Args:
            query (str): Plain English description of the data you want.
            dataset_ids (list[str]): Dataset IDs to scope the query.
            **kwargs: Arbitrary keyword arguments passed to the API client.

        Returns:
            NaturalLanguageQueryResponse: Contains the generated SQL, a valid flag,
                optional error message, and query data.
        """
        return self._post_nl_query(query=query, dataset_ids=dataset_ids, generate_only=False, **kwargs)

    def generate_nl_query(self, query: str, dataset_ids: list[str], **kwargs) -> NaturalLanguageQueryResponse:
        """
        Convert a natural language request to SQL without executing it.

        Args:
            query (str): Plain English description of the data you want.
            dataset_ids (list[str]): Dataset IDs to scope the query.
            **kwargs: Arbitrary keyword arguments passed to the API client.

        Returns:
            NaturalLanguageQueryResponse: Contains the generated SQL and a valid flag.
                Data is always None.
        """
        return self._post_nl_query(query=query, dataset_ids=dataset_ids, generate_only=True, **kwargs)

    def _post_nl_query(
        self, query: str, dataset_ids: list[str], generate_only: bool, **kwargs
    ) -> NaturalLanguageQueryResponse:
        response_types_map = {
            "200": NaturalLanguageQueryResponse,
            "400": None,
            "422": None,
            "500": None,
        }
        return self.api_client.post(
            resource_path=self._resource_path + "/nl-query",
            data={"query": query, "dataset_ids": dataset_ids, "generate_only": generate_only},
            response_types_map=response_types_map,
            **kwargs,
        )
