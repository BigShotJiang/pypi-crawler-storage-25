import io
import json
from typing import Iterator

from typing import Sequence

from PIL import Image
from pydantic import conint

from superwise_api.client.api_client import ApiClient
from superwise_api.client.models.page import Page
from superwise_api.entities.base import BaseApi, CoreEntitiyApi
from superwise_api.models.agent.agent import AgentConfig, Version, GuardrailConfig
from superwise_api.models.agent.agent import Agent
from superwise_api.models.agent.agent import ModelLLM
from superwise_api.models.agent.agent import ToolDef
from superwise_api.models.agent.flowise import FlowiseCredentialUserInput
from superwise_api.models.agent.playground import AskResponsePayload
from superwise_api.models.agent.playground import StreamedResponse
from superwise_api.models.dataset.dataset import Dataset
from superwise_api.models.agent.feedback import EventFeedbackData


class AgentApi(CoreEntitiyApi):
    """
    This class provides methods to interact with the Agent API.

    Attributes:
        api_client (ApiClient): An instance of the ApiClient to make requests.
        _model_name (str): The name of the model.
        _resource_path (str): The path of the resource.
    """

    _model_name = "agent"
    _resource_path = "/v1/agents"
    _model_class = Agent

    def __init__(self, api_client: ApiClient) -> None:
        """
        Initializes the DatasetApi class.

        Args:
            api_client (ApiClient): An instance of the SuperwiseApiClient to make requests.
        """
        super().__init__(api_client)
        self._playground_resource_path = "/v1/application-playground"

    def _detect_image_type(self, image_bytes: bytes) -> tuple[str, str]:
        try:
            with Image.open(io.BytesIO(image_bytes)) as img:
                format_name = img.format
                if format_name is None:
                    raise ValueError("Could not detect image format")
                format_map = {
                    "JPEG": ("image/jpeg", "jpg"),
                    "PNG": ("image/png", "png"),
                    "WEBP": ("image/webp", "webp"),
                }
                if format_name in format_map:
                    return format_map[format_name]
                raise ValueError(f"Unsupported image format: {format_name}. Supported formats: JPEG, PNG, WEBP")
        except ValueError:
            raise
        except Exception:
            raise ValueError("Image type not allowed. Only PNG, JPEG, and WebP are supported.")

    def _validate_images(self, images: list[bytes]) -> None:
        if len(images) > 3:
            raise ValueError(f"Maximum 3 images allowed, got {len(images)}")
        for idx, img in enumerate(images):
            if not isinstance(img, bytes):
                raise ValueError(f"Image at index {idx} must be bytes, got {type(img)}")
            if len(img) > 20 * 1024 * 1024:
                raise ValueError(f"Image at index {idx} exceeds the 20MB size limit")
            self._detect_image_type(img)

    def _build_image_fields(self, images: list[bytes]) -> list[tuple]:
        fields = []
        for i, img in enumerate(images):
            media_type, ext = self._detect_image_type(img)
            fields.append(("images", (f"image{i}.{ext}", img, media_type)))
        return fields

    def create(
        self,
        name: str,
        description: str = None,
        authentication_enabled: bool = False,
        observability_enabled: bool = True,
        guardrails_violation_message: str | None = None,
        **kwargs,
    ) -> Agent:
        """
        Creates a new agent.

        Args:
            name (str): The name of the agent.
            description (str): The agent's description.
            authentication_enabled (bool): Whether the agent requires an api token for access or not.
            observability_enabled (bool): Whether the agent logs conversation to the db or not.

        Returns:
            Agent: The created agent.
        """

        payload = {
            "name": name,
            "authentication_enabled": authentication_enabled,
            "observability_enabled": observability_enabled,
        }
        if description:
            payload["description"] = description
        if guardrails_violation_message:
            payload["guardrails_violation_message"] = guardrails_violation_message
        return self.api_client.create(
            resource_path=self._resource_path,
            model_name=self._model_name,
            model_class=Agent,
            data=payload,
            **kwargs,
        )

    def create_version(
        self,
        agent_id: str,
        name: str,
        agent_config: AgentConfig,
        guardrails: list[GuardrailConfig] | list[str] = None,
        description: str = None,
        **kwargs,
    ) -> Version:
        """
        Creates a new version for the agent.

        Args:
            agent_id (str): The id of the agent.
            name (str): The name of the version.
            description (str): The version's description.
            agent_config (AgentConfig): agent configuration for this version.
            guardrails: list(GuardrailConfig): list of guardrails ids and blocking configuration.

        Returns:
            Version: The created version.
        """

        processed_guardrails = [
            GuardrailConfig(version_id=guardrail) if not isinstance(guardrail, GuardrailConfig) else guardrail
            for guardrail in (guardrails or [])
        ]

        payload = {
            "name": name,
            "agent_config": agent_config,
            "guardrails": [guardrail.model_dump(by_alias=True) for guardrail in processed_guardrails],
        }
        if description:
            payload["description"] = description
        return self.api_client.create(
            resource_path=self._resource_path + f"/{agent_id}/versions",
            model_name=self._model_name,
            model_class=Version,
            data=payload,
            **kwargs,
        )

    def update(
        self,
        agent_id: str,
        name: str | None = None,
        description: str | None = None,
        authentication_enabled: bool | None = None,
        observability_enabled: bool | None = None,
        guardrails_violation_message: str | None = None,
        dataset_id: str | None = None,
        **kwargs,
    ) -> Agent:
        """
        Updates the agent.

        Args:
            agent_id (str): The id of the agent.
            name (str, optional): The new name of the agent.
            description (str, optional): Description for the agent.
            authentication_enabled (bool, optional): Whether the agent requires an api token for access or not.
            observability_enabled (bool, optional): Whether the agent logs conversation to the db or not.
            guardrails_violation_message (str, optional): The message to show when guardrails are violated.
            dataset_id (str, optional): The id of the dataset to associate with the agent.

        Returns:
            Agent: The updated agent.
        """

        payload = {
            "name": name,
            "description": description,
            "authentication_enabled": authentication_enabled,
            "observability_enabled": observability_enabled,
            "guardrails_violation_message": guardrails_violation_message,
            "dataset_id": dataset_id,
        }
        data = {k: v for k, v in payload.items() if v is not None}
        if len(data) == 0:
            raise ValueError("At least one parameter must be provided to update the agent.")
        return self.api_client.update(
            resource_path=self._resource_path,
            model_name=self._model_name,
            model_class=Agent,
            entity_id=agent_id,
            data=data,
            **kwargs,
        )

    def update_version(
        self,
        version_id: str,
        agent_id: str,
        name: str | None = None,
        description: str | None = None,
        **kwargs,
    ) -> Version:
        """
        Updates the agent's version.

        Args:
            version_id (str): The version's id.
            agent_id (str): The id of the version's agent.
            name (str, optional): The new name of the version.
            description (str, optional): New description for the version.

        Returns:
            Version: The updated version.
        """

        payload = {"name": name, "description": description}
        data = {k: v for k, v in payload.items() if v is not None}
        if len(data) == 0:
            raise ValueError("At least one parameter must be provided to update the version.")
        return self.api_client.update(
            resource_path=self._resource_path + "/{agent_id}/versions/{version_id}",
            model_name=self._model_name,
            model_class=Version,
            entity_id=agent_id,
            data=data,
            path_params={"agent_id": agent_id, "version_id": version_id},
            **kwargs,
        )

    def get_version_by_id(self, agent_id: str, version_id: str, **kwargs) -> Version:
        """
        Retrieves an entity by its id.

        Args:
            agent_id (str): The id of the agent.
            version_id (str): The id of the version to retrieve.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Source: The retrieved entity.
        """
        return self.api_client.get_by_id(
            resource_path=self._resource_path + f"/{agent_id}/versions/{version_id}",
            model_name="version",
            model_class=Version,
            entity_id=version_id,
            path_params={"agent_id": agent_id, "version_id": version_id},
            **kwargs,
        )

    def get_versions(
        self, agent_id: str, name: str | None = None, created_by: str | None = None, **kwargs
    ) -> list[Version]:
        """
        Retrieves agent entities.

        Args:
            agent_id (str): The id of the agent.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            list[Version]: The retrieved entities.
        """
        query_params = {
            k: v
            for k, v in dict(
                name=name,
                created_by=created_by,
            ).items()
            if v is not None
        }

        return self.api_client.get(
            resource_path=self._resource_path + f"/{agent_id}/versions",
            model_name="version",
            model_class=Version,
            query_params=query_params,
            paginate=False,
            **kwargs,
        )

    def get(
        self,
        name: str | None = None,
        created_by: str | None = None,
        prompt: str | None = None,
        dataset_id: str | None = None,
        page: conint(strict=True, ge=1) | None = None,
        size: conint(strict=True, le=500, ge=1) | None = None,
        **kwargs,
    ) -> Page:
        """
        Gets agents. Filter if any of the parameters are provided.

        Args:
            name (str, optional): The name of the agent.
            created_by (str, optional): The creator of the agent.
            prompt (str, optional): The prompt of the agent.
            dataset_id (str, optional): The id of the dataset.
            page (int, optional): The page number.
            size (int, optional): The size of the page.

        Returns:
            Page: A page of agents.
        """

        query_params = {
            k: v
            for k, v in dict(
                name=name,
                created_by=created_by,
                prompt=prompt,
                dataset_id=dataset_id,
                page=page,
                size=size,
            ).items()
            if v is not None
        }
        return self.api_client.get(
            resource_path=self._resource_path,
            model_name=self._model_name,
            model_class=Agent,
            query_params=query_params,
            **kwargs,
        )

    @BaseApi.raise_exception
    def test_model_connection(self, llm_model: ModelLLM, **kwargs):
        """
        Tests the connection to the model. Raises exception on fail.

        Args:
            llm_model (ModelLLM): The model to test.
        """
        response_types_map = {"204": None, "422": "HTTPValidationError"}
        return self.api_client.post(
            resource_path=self._resource_path + "/test-model-connection",
            data=llm_model.model_dump(),
            response_types_map=response_types_map,
            **kwargs,
        )

    @BaseApi.raise_exception
    def test_tool_connection(self, tool: ToolDef, **kwargs):
        """
        Tests the connection to the tool. Raises exception on fail.

        Args:
            tool (ToolDef): The tool to test.
        """
        response_types_map = {"204": None, "422": "HTTPValidationError"}
        return self.api_client.post(
            resource_path=self._resource_path + "/test-tool-connection",
            data=tool.model_dump(),
            response_types_map=response_types_map,
            **kwargs,
        )

    @BaseApi.raise_exception
    def ask_playground(
        self,
        input: str,
        agent_config: AgentConfig,
        chat_history: Sequence[dict] | None = None,
        images: list[bytes] | None = None,
        **kwargs,
    ) -> AskResponsePayload:
        """
        Performs ask request in playground mode.

        Args:
            input (str): The input to the model.
            agent_config (AgentConfig): The type of the agent and connected tools/context.
            chat_history (Sequence[dict], optional): The chat history.
            images (list[bytes], optional): Up to 3 images (PNG, JPEG, WEBP, max 20MB each).

        Returns:
            AskResponsePayload: The response payload.
        """
        response_types_map = {"200": AskResponsePayload, "422": "HTTPValidationError"}
        if images:
            self._validate_images(images)
            fields = [
                ("input", input),
                ("chat_history", json.dumps(chat_history or [])),
                ("config", agent_config.model_dump_json(by_alias=True)),
            ]
            fields.extend(self._build_image_fields(images))
            return self.api_client.post(
                resource_path=self._playground_resource_path + "/ask",
                post_params=fields,
                response_types_map=response_types_map,
                **kwargs,
            )
        payload = {
            "config": agent_config,
            "input": input,
            "chat_history": chat_history or [],
        }
        return self.api_client.post(
            resource_path=self._playground_resource_path + "/ask",
            data=payload,
            response_types_map=response_types_map,
            **kwargs,
        )

    @BaseApi.raise_exception
    def ask_worker(
        self,
        agent_id: str,
        input: str,
        api_token: str | None = None,
        chat_history: Sequence[dict] | None = None,
        context_id: str | None = None,
        metadata: dict | None = None,
        images: list[bytes] | None = None,
        **kwargs,
    ) -> AskResponsePayload:
        """
        Performs ask request to the specified worker.

        Args:
            agent_id (str): The agent asked.
            input (str): The input to the model.
            api_token (str): The API token of the agent.
            chat_history (Sequence[dict], optional): The chat history.
            context_id (str, optional): The context ID for the conversation.
            metadata (dict, optional): Additional metadata.
            images (list[bytes], optional): Up to 3 images (PNG, JPEG, WEBP, max 20MB each).

        Returns:
            AskResponsePayload: The response payload.
        """
        response_types_map = {"200": AskResponsePayload, "422": "HTTPValidationError"}
        if images:
            self._validate_images(images)
        headers = {"x-api-token": api_token} if api_token else {}
        if images:
            fields = [
                ("input", input),
                ("chat_history", json.dumps(chat_history or [])),
            ]
            if context_id is not None:
                fields.append(("context_id", context_id))
            if metadata is not None:
                fields.append(("metadata", json.dumps(metadata)))
            fields.extend(self._build_image_fields(images))
            return self.api_client.post(
                resource_path=f"/v1/app-worker/{agent_id}/v1/ask",
                post_params=fields,
                response_types_map=response_types_map,
                _headers=headers,
                **kwargs,
            )
        payload = {"input": input, "chat_history": chat_history or [], "context_id": context_id, "metadata": metadata}
        return self.api_client.post(
            resource_path=f"/v1/app-worker/{agent_id}/v1/ask",
            data=payload,
            response_types_map=response_types_map,
            _headers=headers,
            **kwargs,
        )

    def ask_playground_stream(
        self,
        input: str,
        agent_config: AgentConfig,
        chat_history: Sequence[dict] | None = None,
        guardrails: list[str] | None = None,
        images: list[bytes] | None = None,
        **kwargs,
    ) -> Iterator[StreamedResponse]:
        """
        Performs streaming ask request in playground mode.

        Args:
            input (str): The input to the model.
            agent_config (AgentConfig): The type of the agent and connected tools/context.
            chat_history (Sequence[dict], optional): The chat history.
            guardrails (list[str], optional): List of guardrail IDs to apply.
            images (list[bytes], optional): Up to 3 images (PNG, JPEG, WEBP, max 20MB each).

        Yields:
            StreamedResponse: Individual streaming events (system, guardrails, llm, tool, response).

        Raises:
            StreamingError: If an error event is received in the stream.
        """
        if images:
            self._validate_images(images)
        if images:
            fields = [
                ("input", input),
                ("chat_history", json.dumps(chat_history or [])),
                ("config", agent_config.model_dump_json(by_alias=True)),
            ]
            if guardrails:
                fields.append(("guardrails", json.dumps(guardrails)))
            fields.extend(self._build_image_fields(images))
            return self.api_client.post_stream(
                resource_path=self._playground_resource_path + "/ask/stream",
                response_model=StreamedResponse,
                post_params=fields,
                **kwargs,
            )
        payload = {
            "config": agent_config,
            "input": input,
            "chat_history": chat_history or [],
        }
        if guardrails:
            payload["guardrails"] = guardrails
        return self.api_client.post_stream(
            resource_path=self._playground_resource_path + "/ask/stream",
            response_model=StreamedResponse,
            data=payload,
            **kwargs,
        )

    def ask_worker_stream(
        self,
        agent_id: str,
        input: str,
        api_token: str | None = None,
        chat_history: Sequence[dict] | None = None,
        context_id: str | None = None,
        metadata: dict | None = None,
        images: list[bytes] | None = None,
        **kwargs,
    ) -> Iterator[StreamedResponse]:
        """
        Performs streaming ask request to the specified worker.

        Args:
            agent_id (str): The agent asked.
            input (str): The input to the model.
            api_token (str): The API token of the agent.
            chat_history (Sequence[dict], optional): The chat history.
            context_id (str, optional): The context ID for the conversation.
            metadata (dict, optional): Additional metadata.
            images (list[bytes], optional): Up to 3 images (PNG, JPEG, WEBP, max 20MB each).

        Yields:
            StreamedResponse: Individual streaming events (system, guardrails, llm, tool, response).

        Raises:
            StreamingError: If an error event is received in the stream.
        """
        if images:
            self._validate_images(images)
        headers = {"x-api-token": api_token} if api_token else {}
        if images:
            fields = [
                ("input", input),
                ("chat_history", json.dumps(chat_history or [])),
            ]
            if context_id is not None:
                fields.append(("context_id", context_id))
            if metadata is not None:
                fields.append(("metadata", json.dumps(metadata)))
            fields.extend(self._build_image_fields(images))
            return self.api_client.post_stream(
                resource_path=f"/v1/app-worker/{agent_id}/v1/ask/stream",
                response_model=StreamedResponse,
                post_params=fields,
                _headers=headers,
                **kwargs,
            )
        payload = {"input": input, "chat_history": chat_history or [], "context_id": context_id, "metadata": metadata}
        return self.api_client.post_stream(
            resource_path=f"/v1/app-worker/{agent_id}/v1/ask/stream",
            response_model=StreamedResponse,
            data=payload,
            _headers=headers,
            **kwargs,
        )

    def get_flowise_credential_schema(self, url: str, api_key: str, flow_id, **kwargs) -> FlowiseCredentialUserInput:
        """
        Get credential schema.

        Args:
            url (str): url to the flowise agent.
            api_key (str): Flow-relevant API key.
            flow_id (str): ID of the requested flow.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            FlowiseCredentialUserInput: Required schema of the credentials.
        """
        payload = {
            "url": url,
            "api_key": api_key,
            "flow_id": flow_id,
        }
        response_types_map = {
            "200": FlowiseCredentialUserInput,
            "404": None,
            "422": None,
            "500": None,
        }
        return self.api_client.post(
            resource_path=self._resource_path + "/credential-schema",
            model_name=self._model_name,
            data=payload,
            response_types_map=response_types_map,
            **kwargs,
        )

    @BaseApi.raise_exception
    def regenerate_api_key(self, agent_id: str, **kwargs) -> Agent:
        """
        Regenerates api key for agent.

        Args:
            agent_id (str): The agent asked.
        Returns:
            Agent: Agent with the new api key.
        """
        response_types_map = {"200": Agent, "422": "HTTPValidationError"}
        return self.api_client.post(
            resource_path=self._resource_path + f"/{agent_id}/regenerate",
            response_types_map=response_types_map,
            **kwargs,
        )

    def create_dataset(self, agent_id: str, name: str, **kwargs) -> Dataset:
        """
        Creates a new dataset for the agent.

        Args:
            agent_id (str): The id of the agent.
            name (str): The name of the version.

        Returns:
            Dataset: The created dataset.
        """

        payload = {
            "name": name,
        }
        return self.api_client.create(
            resource_path=self._resource_path + f"/{agent_id}/create-dataset",
            model_name=self._model_name,
            model_class=Dataset,
            data=payload,
            **kwargs,
        )

    @BaseApi.raise_exception
    def send_feedback(
        self,
        agent_id: str,
        payload: EventFeedbackData,
        api_token: str | None = None,
        **kwargs,
    ) -> None:
        """
        Sends feedback to the specified worker for its answer.

        Args:
            agent_id (str): The agent receiving the feedback.
            payload (EventFeedbackData): The feedback payload.
            api_token (str): The API token of the application.
        Returns:
            None
        """
        headers = {"x-api-token": api_token} if api_token else {}
        response_types_map = {
            "200": None,
            "422": "HTTPValidationError",
            "401": "HTTPUnauthorized",
            "500": None,
        }

        self.api_client.post(
            resource_path=f"/v1/app-worker/{agent_id}/v1/feedback",
            data=payload,
            response_types_map=response_types_map,
            _headers=headers,
            **kwargs,
        )

    @BaseApi.raise_exception
    def verify_dataset_schema(self, dataset_id: str, **kwargs) -> bool:
        """
        Verifies that the dataset schema matches the expected agent dataset schema or is a superset of it.

        Args:
            dataset_id (str): The id of the dataset to verify.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            bool: True if the schema matches, False otherwise.
        """
        response_types_map = {
            "200": bool,
            "404": None,
            "500": None,
        }
        return self.api_client.post(
            resource_path=f"{self._resource_path}/verify-dataset-schema/{dataset_id}",
            response_types_map=response_types_map,
            **kwargs,
        )

    def publish(self, agent_id: str, **kwargs):
        """Publishes (activates) the agent's latest version."""
        return self.api_client.post(f"{self._resource_path}/{agent_id}/activate", **kwargs)

    def unpublish(self, agent_id: str, **kwargs):
        return self.api_client.post(f"{self._resource_path}/{agent_id}/unpublish", **kwargs)
