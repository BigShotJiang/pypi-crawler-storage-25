from functools import wraps
from typing import Literal, Any

from superwise_api.client.api_client import ApiClient
from superwise_api.client.exceptions import ApiAttributeError
from superwise_api.client.exceptions import ApiException
from superwise_api.client.exceptions import ApiKeyError
from superwise_api.client.exceptions import ApiTypeError
from superwise_api.client.exceptions import ApiValueError
from superwise_api.errors import SuperwiseApiException
from superwise_api.models.utils import BulkActionResponse, SearchParams
from superwise_api.client.models.page import Page


class BaseApi:
    _resource_path = None
    _model_name = None
    _model_class = None

    def __init__(self, api_client: ApiClient):
        """
        Initializes the Api class.

        Args:
            api_client (ApiClient): An instance of the SuperwiseApiClient to make requests.
        """
        self.api_client = api_client
        self.wrap_api_calls()

    def wrap_api_calls(self):
        for method_name in dir(self):
            method = getattr(self, method_name)
            if callable(method) and method_name in ["put", "update", "create", "get", "get_by_id", "delete"]:
                setattr(self, method_name, self.raise_exception(method))

    @staticmethod
    def raise_exception(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except ApiException as e:
                raise SuperwiseApiException(original_exception=e, message=e.body)
            except (ApiTypeError, ApiValueError, ApiAttributeError, ApiKeyError) as e:
                raise e
            except Exception as e:
                raise SuperwiseApiException(e, message="A general error occurred - We are looking into it")

        return wrapper

    def get_by_id(self, _id: str, **kwargs):
        """
        Retrieves an entity by its id.

        Args:
            _id (str): The id of the entity to retrieve.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            Source: The retrieved entity.
        """
        return self.api_client.get_by_id(
            resource_path=self._resource_path,
            model_name=self._model_name,
            model_class=self._model_class,
            entity_id=_id,
            **kwargs,
        )

    def delete(self, _id: str, **kwargs):
        """
        Deletes an entity.

        Args:
            _id (str): The id of the entity to delete.
            **kwargs: Arbitrary keyword arguments.
        """
        return self.api_client.delete(
            resource_path=self._resource_path, model_name=self._model_name, entity_id=_id, **kwargs
        )


class CoreEntitiyApi(BaseApi):
    """Used for core entities shared interface: Dashboard, Dataset, Guardrails, Policy, Agent"""

    def search(
        self,
        only_archived: bool = False,
        filters: list[Any] | None = None,
        search: str | None = None,
        sort_by: str | None = None,
        sort_direction: Literal["asc", "desc"] = "desc",
        **kwargs,
    ) -> Page:
        """
        Searches for a model class based on a prefix.

        Args:
            only_archived (bool): Whether to return only archived, or only active entities
            filters (list[Any]): Filter on db columns, list of tuples.
                e.g. [[["id", "eq", "5c05dc9f-f04a-4ce8-9d57-2ec63ee76aac"], "and", ["description", "ilike", "Construction"]], "or", ["name", "ilike", "active"]]
            search (str): Free text search on searchable fields
            sort_by (str): Field to sort by
            sort_direction (Literal["asc", "desc"]): Sort direction (ascending or descending)
            query_params can be passed as part of the kwargs for pagination

        Returns:
            Page: A page of a model class.
        """
        data = SearchParams(
            only_archived=only_archived,
            filters=filters,
            search=search,
            sort_by=sort_by,
            sort_direction=sort_direction,
        ).model_dump(exclude_none=True)
        response_types_map = {
            "200": Page.set_model(self._model_class),
            "422": None,
            "500": None,
        }
        path = "/v1/enriched-agents" if "agents" in self._resource_path else self._resource_path
        return self.api_client.post(
            resource_path=f"{path}/search",
            data=data,
            response_types_map=response_types_map,
            **kwargs,
        )

    def archive(self, entity_id: str, **kwargs):
        return self.api_client.post(f"{self._resource_path}/{entity_id}/archive", **kwargs)

    def unarchive(self, entity_id: str, **kwargs):
        response_types_map = {
            "200": self._model_class,
            "422": None,
            "500": None,
        }
        return self.api_client.post(
            f"{self._resource_path}/{entity_id}/unarchive", response_types_map=response_types_map, **kwargs
        )

    def add_tags(
        self,
        entity_id: str,
        tag_ids: list[str],
        **kwargs,
    ):
        """
        Add tags to the entity.

        Args:
            entity_id (str): The id of the entity.
            tag_ids list(str): List of tag ids to add the entity
        Returns:
            None
        """
        return self.api_client.post(
            resource_path=self._resource_path + f"/{entity_id}/tags",
            data=tag_ids,
            **kwargs,
        )

    def remove_tags(
        self,
        entity_id: str,
        tag_ids: list[str],
        **kwargs,
    ):
        """
        Delete tags from an entity.

        Args:
            entity_id (str): The id of the entity.
            tag_ids list(str): List of tag ids to remove from the entity
        Returns:
            None
        """
        return self.api_client.delete(
            resource_path=self._resource_path + "/{entity_id}/tags",
            model_name=self._model_name,
            entity_id=entity_id,
            path_params={"entity_id": entity_id},
            query_params=[("ids", id) for id in tag_ids],
            **kwargs,
        )

    def bulk_action(self, ids: list[str], action: str, **kwargs) -> BulkActionResponse:
        """
        Perform a bulk action on multiple entities.

        Args:
            ids: list[str]: The ids of the entities to perform the action on.
            action: str: The action to perform.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            BulkActionResponse: The response from the bulk action.
        """
        payload = {
            "ids": ids,
            "action": action,
        }
        response_types_map = {
            "200": BulkActionResponse,
            "422": None,
            "500": None,
        }

        return self.api_client.post(
            resource_path=f"{self._resource_path}/bulk-action",
            data=payload,
            response_types_map=response_types_map,
            **kwargs,
        )
