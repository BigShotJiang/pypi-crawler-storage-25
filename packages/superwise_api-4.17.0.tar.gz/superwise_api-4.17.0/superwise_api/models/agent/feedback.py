from uuid import UUID

from superwise_api.models import SuperwiseEntity


class EventFeedbackData(SuperwiseEntity):
    interaction_id: UUID
    question: str
    answer: str
    is_positive: bool
    negative_feedback_category_harmful: bool
    negative_feedback_category_untrue: bool
    negative_feedback_category_unhelpful: bool
    negative_feedback_category_other: bool
    feedback_description: str
    agent_id: str
