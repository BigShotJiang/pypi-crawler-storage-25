from datetime import datetime
from enum import Enum
from typing import Optional
from typing import Union

from pydantic import BaseModel
from pydantic import Field

from superwise_api.models import SuperwiseEntity


class Empty(BaseModel): ...


class StreamEventType(str, Enum):
    """Event types for streamed responses."""

    SYSTEM = "system"
    GUARDRAILS = "guardrails"
    LLM = "llm"
    TOOL = "tool"
    ERROR = "error"
    RESPONSE = "response"
    INTERNAL = "internal"
    GUARDRAIL_VIOLATION = "guardrail_violation"
    LLM_ERROR = "llm_error"


class StreamedResponse(BaseModel):
    """A single event from the streaming response."""

    event: StreamEventType = Field(..., description="The type of streaming event.")
    text: str = Field(..., description="The text content of the event.")
    event_subtype: Optional[str] = Field(
        default=None, description="Subtype of the event (e.g., LLM provider or tool type)."
    )

    @classmethod
    def from_dict(cls, data: dict) -> "StreamedResponse":
        return cls(**data)


class IntermediateStep(BaseModel):
    start_time: datetime = Field(default_factory=datetime.utcnow)
    end_time: datetime = Field(default_factory=datetime.utcnow)
    input_data: Optional[str]
    output_data: Optional[str]


class DebugMetadata(BaseModel):
    question: str
    answer: str
    start_time: datetime
    end_time: datetime
    intermediate_steps: list[IntermediateStep]


class ResponseMetadata(BaseModel):
    cite_sources: Optional[list[Optional[str]]] = Field(default=None, description="The sources cited in the response.")
    debug_metadata: Optional[DebugMetadata] = Field(
        default=None, description="Debug metadata associated with the response if applicable."
    )
    task_id: Optional[str] = Field(default=None, description="The task ID associated with the response.")
    is_guardrails_violated: Optional[bool] = Field(default=None, description="Whether guardrails were violated.")
    guardrails_violations: Optional[list] = Field(default=None, description="List of guardrail violations if any.")


class AskResponsePayload(SuperwiseEntity):
    output: str = Field(..., description="The AI agent's response to the user's inquiry.")
    metadata: Union[ResponseMetadata, Empty] = Field(
        default=Empty(), description="The metadata associated with the response."
    )
    interaction_id: Optional[str] = Field(
        default=None, description="Unique identifier for this interaction, used for feedback."
    )

    @classmethod
    def from_dict(cls, data: dict) -> "AskResponsePayload":
        metadata = data.get("metadata")
        if metadata:
            data["metadata"] = ResponseMetadata(**metadata)
        return cls(**data)
