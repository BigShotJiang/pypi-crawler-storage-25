from datetime import datetime
from enum import Enum
from typing import Union, Annotated
from uuid import UUID

from pydantic import field_serializer, ConfigDict, BaseModel, Discriminator

from superwise_api.models import SuperwiseEntity


class DestinationType(str, Enum):
    SLACK = "slack"
    TEAMS = "teams"
    EMAIL = "email"


class SlackDestinationParams(SuperwiseEntity):
    channel_id: str


class TeamsDestinationParams(SuperwiseEntity):
    webhook_url: str


class EmailDestinationParams(SuperwiseEntity):
    emails: list[str]


class DestinationBase(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    integration_type: DestinationType


class TeamsDestinationTestRequest(TeamsDestinationParams, DestinationBase):
    integration_type: DestinationType = DestinationType.TEAMS.value


class SlackDestinationTestRequest(SlackDestinationParams, DestinationBase):
    integration_type: DestinationType = DestinationType.SLACK.value
    integration_id: UUID


class EmailDestinationTestRequest(EmailDestinationParams, DestinationBase):
    integration_type: DestinationType = DestinationType.EMAIL.value


DestinationParams = Union[SlackDestinationParams, TeamsDestinationParams, EmailDestinationParams]
DestinationTestRequest = Annotated[
    TeamsDestinationTestRequest,
    SlackDestinationTestRequest,
    EmailDestinationTestRequest,
    Discriminator("integration_type"),
]


class Destination(SuperwiseEntity):
    id: UUID
    name: str
    integration_id: UUID
    params: SlackDestinationParams | TeamsDestinationParams | EmailDestinationParams
    updated_at: datetime
    created_at: datetime
    created_by: str
    tenant_id: str

    @field_serializer("created_at", "updated_at")
    def serialize_dt(self, dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]

    def to_dict(self) -> dict:
        dict_ = self.model_dump(exclude_none=True)
        return dict_

    @classmethod
    def from_dict(cls, dict_: dict) -> "Destination":
        if "webhook_url" in dict_["params"]:
            dict_["params"] = TeamsDestinationParams(**dict_["params"])
        elif "emails" in dict_["params"]:
            dict_["params"] = EmailDestinationParams(**dict_["params"])
        else:
            dict_["params"] = SlackDestinationParams(**dict_["params"])
        return cls(**dict_)
