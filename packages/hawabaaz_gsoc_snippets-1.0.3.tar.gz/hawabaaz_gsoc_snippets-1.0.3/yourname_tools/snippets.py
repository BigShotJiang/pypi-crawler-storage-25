import pandas as pd

def analyze_data(data):
    df = pd.DataFrame(data)

    mean_revenue = df['Revenue'].mean()
    median_revenue = df['Revenue'].median()
    std_revenue = df['Revenue'].std(ddof=1)

    most_common_channel = df['Channel'].value_counts().idxmax()

    if df['Visitors'].nunique() <= 1 or df['Revenue'].nunique() <= 1:
        visitors_revenue_corr = 0
    else:
        corr = df['Visitors'].corr(df['Revenue'])
        if pd.isna(corr):
            visitors_revenue_corr = 0
        else:
            visitors_revenue_corr = corr

    result = pd.Series(
        [mean_revenue, median_revenue, std_revenue, most_common_channel, visitors_revenue_corr]
    )

    return result

corr3 = df.groupby('Category').apply(
    lambda x: x['Sales'].corr(x['Profit'])
)
ax=sns.barplot(df_melted,x='Class',y='Score',hue='Subject')

import pandas as pd
def loss_sales_pattern(df):
    # mean_sales = df['Sales'].mean()
    # filtered_df = df[(df['Sales'] > mean_sales) & (df['Profit'] < 0)]
    # if filtered_df.empty:
    #     return 0.0
    # ct = pd.crosstab(filtered_df['Category'], filtered_df['State_Bin'], normalize='index')
    # max_val = ct.values.max()
    # return round(float(max_val), 2)
    mean_sales = df['Sales'].mean()
    filtered_df =df[(df['Sales']>mean_sales)& (df['Profit']<0)]
    if filtered_df.empty:
        return 0.0
    ct = pd.crosstab(filtered_df['Category'],filtered_df['State_Bin'],normalize='index')
    max_val = ct.values.max()
    return round(float(max_val),2)

average_scores = df.groupby("Study_Group")["Exam_Score"].mean()
average_scores = average_scores.reindex(["Low", "Medium", "High"])

average_scores

df[df['Doors'].isin([3,5])]

df.groupby('FuelType').agg({'Price':['count','mean'], 'KM':'max'})

sns.barplot(data=titanic, x='sex', y='survived', hue='class')

sns.countplot(data=titanic,x='class')

dept_counts.plot(kind='bar')

counts, bins, patches = plt.hist(df["Salary"],bins=10)

boxplot=plt.boxplot(df['Salary'])

box = boxplot["boxes"][0]
y_values = box.get_ydata()

q1 = y_values[1]
q3 = y_values[3]

quartiles = {
    "q1": round(q1, 2),
    "q3": round(q3, 2)
}

json.dumps(quartiles)

sns.relplot(data = tips, x = "total_bill", y = "tip", col = "time", hue = "smoker", style = "smoker")

# Combine into one dataframe - axis=1 for columns side by side join
    result = pd.concat([total_sales, avg_profit], axis=1)

ax = df.boxplot(column="Transaction_Amount", by="Customer_Segment")

sns.set_theme(style="darkgrid")


    # Create relational plot
    sns.relplot(
        data=tips,
        x="total_bill",
        y="tip",
        col="time",      # separate plots for Lunch & Dinner
        hue="smoker",    # color differentiation
        style="smoker"   # style differentiation
    )


df.groupby(["Category", "Region", "Segment"])
        .agg(
            Total_Sales=("Sales", "sum"),
            Avg_Profit=("Profit", "mean")
        )
        .reset_index()
        .sort_values(by=["Category", "Region", "Segment"])


bars = plt.bar(x=role_dist.index, height=role_dist.values)


pivot_table = merged_df.pivot_table(
    values='Revenue', 
    index='Month', 
    columns='Segment', 
    aggfunc='sum', 
    fill_value=0
)

X = df.drop(columns=["Disease_Risk_Index"])

sales_corr = corr_matrix["Sales"].drop("Sales")

corr_abs = corr_matrix.abs()

# Remove diagonal influence
np.fill_diagonal(corr_abs.values, 0)

# Unstack and sort
pairs = corr_abs.unstack().sort_values(ascending=False)

# Remove duplicate pairs (A,B) and (B,A)
pairs = pairs[pairs.index.get_level_values(0) < pairs.index.get_level_values(1)]

# Get top 2 pairs
top_pairs = list(pairs.head(2).index)


import pandas as pd
import numpy as np

def upper_outlier_boundaries(df):

    # Handle empty dataframe
    if df.empty:
        return pd.Series(dtype=float)

    # Convert Salary safely
    df['Salary'] = pd.to_numeric(df['Salary'], errors='coerce')

    # Remove invalid rows
    df = df.dropna(subset=['Salary'])

    result = {}

    # Group by Department
    grouped = df.groupby('Department')

    for dept, group in grouped:

        salaries = group['Salary']

        # If records >= 5 → IQR Method
        if len(salaries) >= 5:

            q1 = salaries.quantile(0.25)
            q3 = salaries.quantile(0.75)

            iqr = q3 - q1

            upper_boundary = q3 + 1.5 * iqr

        # If records < 5 → 90th percentile
        else:

            upper_boundary = salaries.quantile(0.90)

        result[dept] = float(upper_boundary)

    # Return Series instead of dict
    return pd.Series(result)


ax = df.boxplot(column="Transaction_Amount", by="Customer_Segment")

# Clean title formatting
plt.title("Transaction Amount Distribution by Customer Segment")
plt.suptitle("")

plt.show()

# Return plot object
ax


dept_severity_matrix = df.groupby(["Department", "Severity"])["Recovery_Days"] \
                        .mean() \
                        .unstack()


def filtered_transpose_sum(lst):
    condition=lst.sum(axis=1)>=10
    lst = lst[condition]
    cond2=lst<3
    lst[cond2]=0
    cond3=lst.mean(axis=1)>4
    lst=lst[cond3]
    lst=lst.T
    avg=lst.mean(axis=0)
    total=lst.sum(axis=0)

    return np.round((avg+total),2)