from setuptools import setup, find_packages

setup(
    # ⚠️ THIS MUST BE 100% UNIQUE GLOBALLY. 
    # If someone else on earth has used this name, PyPI will reject it.
    name='Hawabaaz_gsoc_snippets', 
    
    # You must change this number every time you upload an update (1.0.1, 1.0.2, etc.)
    version='1.0.3',
    
    packages=find_packages(),
    install_requires=[
        # List any libraries your snippets rely on
        'pandas',
        'matplotlib'
    ],
    description='My personal code snippets',
    author='Hawabaaz'
)