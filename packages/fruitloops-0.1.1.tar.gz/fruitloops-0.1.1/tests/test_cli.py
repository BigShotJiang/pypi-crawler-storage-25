from __future__ import annotations

import csv
import importlib.util
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from fruitloops.cli import main
from fruitloops.bulk import archive_stem, list_sources, safe_identifier, where_clause
from fruitloops.cache import get_or_fetch, list_cache
from fruitloops.env import load_env_file
from fruitloops.live import parse_in_filters, parse_ints
from fruitloops.plotting import PlotSpec


class CliTest(unittest.TestCase):
    def test_datasets_uses_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            write_csv(
                data / "manifest.csv",
                [
                    {
                        "dataset": "flywire",
                        "collection": "analysis_outputs",
                        "file_id": "flywire_analysis_outputs_full_summary",
                        "relative_path": "flywire/analysis_outputs/full_summary.csv",
                        "rows": "1",
                        "columns": "LN_type|n_synapses",
                        "size_bytes": "1",
                        "sha256": "x",
                    }
                ],
            )
            write_csv(data / "flywire/analysis_outputs/full_summary.csv", [{"LN_type": "il3LN6", "n_synapses": "7"}])

            output = run_cli("--data-dir", str(data), "datasets")

        self.assertIn("flywire", output)

    def test_aggregate_sums_filtered_rows(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            write_csv(
                data / "manifest.csv",
                [
                    {
                        "dataset": "flywire",
                        "collection": "source_audit",
                        "file_id": "audit",
                        "relative_path": "flywire/source_audit/orn.csv",
                        "rows": "3",
                        "columns": "LN_type|analysis_hemisphere|input_relation|n_synapses",
                        "size_bytes": "1",
                        "sha256": "x",
                    }
                ],
            )
            write_csv(
                data / "flywire/source_audit/orn.csv",
                [
                    {"LN_type": "il3LN6", "analysis_hemisphere": "L", "input_relation": "ipsi", "n_synapses": "2"},
                    {"LN_type": "il3LN6", "analysis_hemisphere": "L", "input_relation": "ipsi", "n_synapses": "3"},
                    {"LN_type": "lLN2T", "analysis_hemisphere": "L", "input_relation": "ipsi", "n_synapses": "100"},
                ],
            )

            output = run_cli(
                "--data-dir",
                str(data),
                "aggregate",
                "--table",
                "audit",
                "--where",
                "LN_type=il3LN6",
                "--by",
                "analysis_hemisphere,input_relation",
                "--sum",
                "n_synapses",
                "--format",
                "csv",
            )

        self.assertIn("L,ipsi,2,5", output)

    def test_plot_spec_defaults_to_png(self) -> None:
        spec = PlotSpec(kind="scatter", x="x", y="y")

        self.assertEqual(spec.formats, ("png",))

    def test_plot_accepts_csv_path_without_data_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "table.csv"
            write_csv(path, [{"score": "0.1"}, {"score": "0.2"}])

            with patch("fruitloops.cli.render_plot", return_value=[]) as render:
                output = run_cli(
                    "--data-dir",
                    str(Path(tmp) / "missing-data"),
                    "plot",
                    "--csv",
                    str(path),
                    "--kind",
                    "hist",
                    "--value",
                    "score",
                    "--output",
                    str(Path(tmp) / "hist"),
                )

        self.assertEqual(output, "")
        self.assertEqual(len(render.call_args.args[0]), 2)

    def test_env_file_loads_without_overriding_existing_values(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / ".env"
            path.write_text("FRUITLOOPS_TEST_VALUE=from-file\nFRUITLOOPS_KEEP=from-file\n")

            with patch.dict(
                "os.environ",
                {"FRUITLOOPS_KEEP": "existing"},
                clear=False,
            ):
                load_env_file(path)
                import os

                self.assertEqual(os.environ["FRUITLOOPS_TEST_VALUE"], "from-file")
                self.assertEqual(os.environ["FRUITLOOPS_KEEP"], "existing")

    def test_live_id_and_filter_parsing(self) -> None:
        self.assertEqual(parse_ints(["1,2", "3"]), [1, 2, 3])
        self.assertEqual(parse_in_filters([("pre_pt_root_id", "1,2")]), {"pre_pt_root_id": [1, 2]})

    def test_cache_fetches_once_then_reads_offline(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            calls = 0

            def fetch() -> list[dict[str, str]]:
                nonlocal calls
                calls += 1
                return [{"id": "1", "weight": "2"}]

            cache_dir = Path(tmp) / "cache"
            query = {"body_id": [1], "limit": 1}
            rows, entry, source = get_or_fetch(cache_dir, "hemibrain", "neurons", query, fetch)
            self.assertEqual(source, "live")
            self.assertEqual(rows, [{"id": "1", "weight": "2"}])
            self.assertIsNotNone(entry)

            rows, _, source = get_or_fetch(cache_dir, "hemibrain", "neurons", query, fetch)
            self.assertEqual(source, "cache")
            self.assertEqual(rows, [{"id": "1", "weight": "2"}])
            self.assertEqual(calls, 1)
            self.assertEqual(len(list_cache(cache_dir)), 1)

    def test_offline_only_misses_without_fetching(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            rows, entry, source = get_or_fetch(
                Path(tmp),
                "flywire",
                "tables",
                {},
                lambda: [{"table": "synapses_nt_v1"}],
                offline_only=True,
            )

        self.assertEqual(rows, [])
        self.assertIsNone(entry)
        self.assertEqual(source, "miss")

    def test_bulk_sources_include_primary_offline_tables(self) -> None:
        rows = list_sources()
        keys = {(row["dataset"], row["kind"]) for row in rows}

        self.assertIn(("flywire", "proofread-connections"), keys)
        self.assertIn(("hemibrain", "compact-adjacencies"), keys)
        self.assertIn(("hemibrain", "neo4j-inputs"), keys)

    def test_bulk_identifier_and_where_clause_are_sanitized(self) -> None:
        self.assertEqual(safe_identifier("pre.pt-root id"), "pre_pt_root_id")
        clause, params = where_clause([("pre.pt-root id", "123")])

        self.assertEqual(clause, " WHERE pre_pt_root_id = ?")
        self.assertEqual(params, ["123"])
        self.assertEqual(
            archive_stem(Path("exported-traced-adjacencies-v1.2.tar.gz")),
            "exported-traced-adjacencies-v1.2",
        )

    @unittest.skipIf(importlib.util.find_spec("duckdb") is None, "duckdb not installed")
    def test_bulk_import_and_partner_commands_with_fixture(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = Path(tmp) / "fixture.duckdb"
            fixture = Path("tests/fixtures/bulk/flywire_connections.csv")
            run_cli(
                "bulk",
                "--store",
                str(store),
                "import",
                "--path",
                str(fixture),
                "--table",
                "flywire_test_connections",
                "--replace",
            )

            output = run_cli(
                "bulk",
                "--store",
                str(store),
                "inputs",
                "--table",
                "flywire_test_connections",
                "--body-id",
                "201",
                "--format",
                "csv",
            )
            run_cli(
                "bulk",
                "--store",
                str(store),
                "views",
                "--table",
                "flywire_test_connections",
                "--prefix",
                "flywire_test",
            )
            optimize_output = run_cli(
                "bulk",
                "--store",
                str(store),
                "optimize",
                "--table",
                "flywire_test_connections",
                "--prefix",
                "flywire_test",
                "--format",
                "csv",
            )
            view_output = run_cli(
                "bulk",
                "--store",
                str(store),
                "query",
                "--table",
                "flywire_test_partners",
                "--where",
                "body_id=201",
                "--where",
                "direction=input",
                "--limit",
                "1",
                "--format",
                "csv",
            )

        self.assertIn("101,AL_R,7,1", output)
        self.assertIn("index,flywire_test_pre_idx,pre_pt_root_id", optimize_output)
        self.assertIn("analyze,flywire_test_connections,", optimize_output)
        self.assertIn("body_id,partner_id,direction,roi,total_weight,connection_rows", view_output)

    @unittest.skipIf(importlib.util.find_spec("duckdb") is None, "duckdb not installed")
    def test_olfaction_builds_offline_tables_and_orn_input_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = Path(tmp) / "fixture.duckdb"
            imports = [
                ("tests/fixtures/bulk/flywire_olf_connections.csv", "flywire_proofread_connections"),
                ("tests/fixtures/bulk/hemibrain_neurons.csv", "hemibrain_traced_neurons"),
                ("tests/fixtures/bulk/flywire_hierarchical.csv", "flywire_hierarchical_neuron_annotations"),
                ("tests/fixtures/bulk/flywire_neuron_info.csv", "flywire_neuron_information_v2"),
            ]
            for path, table in imports:
                run_cli(
                    "bulk",
                    "--store",
                    str(store),
                    "import",
                    "--path",
                    path,
                    "--table",
                    table,
                    "--replace",
                )

            build_output = run_cli(
                "olfaction",
                "--store",
                str(store),
                "build",
                "--dataset",
                "flywire",
                "--format",
                "csv",
            )
            pn_output = run_cli(
                "olfaction",
                "--store",
                str(store),
                "pns",
                "--dataset",
                "flywire",
                "--glomerulus",
                "DM1",
                "--format",
                "csv",
            )
            orn_input_output = run_cli(
                "olfaction",
                "--store",
                str(store),
                "orn-inputs",
                "--dataset",
                "flywire",
                "--glomerulus",
                "DM1",
                "--by-side",
                "--format",
                "csv",
            )

        self.assertIn("flywire,flywire_proofread_connections,4,imported", build_output)
        self.assertIn("all,olf_annotations,5,built", build_output)
        self.assertIn("flywire,2001,DM1_lPN_R,,PN,DM1,R", pn_output)
        self.assertIn("flywire,2001,DM1_lPN_R,DM1,1,12,R,R,ipsi", orn_input_output)
        self.assertIn("flywire,2001,DM1_lPN_R,DM1,1,5,R,L,contra", orn_input_output)


def run_cli(*args: str) -> str:
    output = StringIO()
    with redirect_stdout(output):
        result = main(list(args))
    if result != 0:
        raise AssertionError(f"CLI exited with {result}")
    return output.getvalue()


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    unittest.main()
