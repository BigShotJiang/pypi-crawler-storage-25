"""Comandos de CLI: vote, ledger verify, ledger checkpoint."""

from __future__ import annotations

import asyncio
import sqlite3
import sys

import click
from rich.panel import Panel

from cortex.cli.common import DEFAULT_DB, cli, console, get_engine
from cortex.cli.errors import err_empty_results, err_validation, handle_cli_error

# Importe actualizado para Wave 5 Fase 2
from cortex.consensus.vote_ledger import ImmutableVoteLedger

__all__ = [
    "ledger",
    "ledger_checkpoint",
    "ledger_status",
    "ledger_verify",
    "vote",
]


@cli.command()
@click.argument("fact_id", type=int)
@click.argument("value", type=int)
@click.option("--agent", "-a", default="human", help="Nombre del agente")
@click.option("--db", default=DEFAULT_DB, help="Ruta de la base de datos")
def vote(fact_id, value, agent, db) -> None:
    """Emite un voto de consenso sobre un hecho (1=verificar, -1=disputar)."""

    async def _vote_async():
        engine = get_engine(db)
        try:
            # En Wave 5 usamos sesiones transaccionales
            async with engine.session() as conn:
                ledger = ImmutableVoteLedger(engine._pool if hasattr(engine, "_pool") else conn)  # type: ignore[reportAttributeAccessIssue]

                if value not in [1, -1]:
                    err_validation("value", "El voto debe ser 1 (verificar) o -1 (disputar)")
                    return

                # Peso 10.0 para votos humanos. Usando tenant_id default
                entry = await ledger.append_vote(fact_id, agent, str(value), "default", 10.0)
                await conn.commit()

                console.print(
                    f"[green]✓[/] El agente [bold]{agent}[/] votó {value} en el hecho [bold]#{fact_id}[/].\n"
                    f"   [dim]Hash: {entry.hash[:16]}...[/]"  # pyright: ignore
                )
        except (sqlite3.Error, OSError, ValueError, RuntimeError) as e:
            handle_cli_error(e, db_path=db, context="casting vote")
        finally:
            await engine.close()

    asyncio.run(_vote_async())


@cli.group()
def ledger():
    """Administrar el registro inmutable de votos."""
    pass


@ledger.command("status")
@click.option("--db", default=DEFAULT_DB, help="Ruta de la base de datos")
def ledger_status(db):
    """Muestra el estado actual del registro de votos."""

    async def _ledger_status_async():
        engine = get_engine(db)
        try:
            async with engine.session() as conn:
                async with conn.execute("SELECT COUNT(*) FROM vote_ledger") as cursor:
                    res = await cursor.fetchone()
                    vote_count = res[0] if res else 0
                async with conn.execute("SELECT COUNT(*) FROM vote_merkle_roots") as cursor:
                    res = await cursor.fetchone()
                    checkpoint_count = res[0] if res else 0
                async with conn.execute("SELECT MAX(vote_end_id) FROM vote_merkle_roots") as cursor:
                    res = await cursor.fetchone()
                    last_audited = res[0] or 0 if res else 0

                console.print(
                    Panel(
                        f"[bold cyan]Altura del Registro:[/] {vote_count} votos\n"
                        f"[bold cyan]Puntos de Control:[/] {checkpoint_count}\n"
                        f"[bold cyan]Último ID Auditado:[/] {last_audited}\n"
                        f"[bold cyan]Votos no Auditados:[/] {vote_count - last_audited}",
                        title="📊 Estado del Registro de Votos",
                        border_style="cyan",
                    )
                )
        except (sqlite3.Error, OSError, ValueError, RuntimeError) as e:
            handle_cli_error(e, db_path=db, context="fetching ledger status")
        finally:
            await engine.close()

    asyncio.run(_ledger_status_async())


@ledger.command("checkpoint")
@click.option("--db", default=DEFAULT_DB, help="Ruta de la base de datos")
def ledger_checkpoint(db):
    """Activa manualmente un punto de control (Merkle root)."""

    async def _ledger_checkpoint_async():
        engine = get_engine(db)
        try:
            async with engine.session() as conn:
                pool_attr = engine._pool if hasattr(engine, "_pool") else conn  # type: ignore[reportAttributeAccessIssue]
                ledger = ImmutableVoteLedger(pool_attr)  # type: ignore[reportAttributeAccessIssue]
                with console.status(
                    "[bold yellow]Calculando Merkle Root y creando punto de control...[/]"
                ):
                    root = await ledger.create_checkpoint()

                if root:
                    console.print(
                        f"[green]✅ Punto de control creado con éxito.[/] Raíz: [bold]{root}[/]"
                    )
                else:
                    err_empty_results("votos nuevos para auditar")
        except (sqlite3.Error, OSError, ValueError, RuntimeError) as e:
            handle_cli_error(e, db_path=db, context="creating ledger checkpoint")
        finally:
            await engine.close()

    asyncio.run(_ledger_checkpoint_async())


@ledger.command("verify")
@click.option("--db", default=DEFAULT_DB, help="Ruta de la base de datos")
def ledger_verify(db):
    """Verifica la integridad criptográfica del registro de votos."""

    async def _ledger_verify_async():
        engine = get_engine(db)
        try:
            async with engine.session() as conn:
                pool_attr = engine._pool if hasattr(engine, "_pool") else conn  # type: ignore[reportAttributeAccessIssue]
                ledger_inst = ImmutableVoteLedger(pool_attr)  # type: ignore[reportAttributeAccessIssue]
                with console.status(
                    "[bold blue]Verificando la cadena de hashes del registro...[/]"
                ):
                    report = await ledger_inst.verify_chain_integrity()

                with console.status("[bold magenta]Verificando raíces de Merkle...[/]"):
                    merkle_report = await ledger_inst.verify_merkle_roots()

                _print_chain_report(report)
                _print_merkle_report(merkle_report)

                if not (report["valid"] and all(r["valid"] for r in merkle_report)):
                    sys.exit(1)
        except (sqlite3.Error, OSError, ValueError, RuntimeError) as e:
            handle_cli_error(e, db_path=db, context="verifying ledger")
        finally:
            await engine.close()

    asyncio.run(_ledger_verify_async())


def _print_chain_report(report: dict) -> None:
    """Imprime el resultado de verificación de cadena de hashes."""
    if report["valid"]:
        console.print(
            f"[green]✅ Integridad de Cadena de Hashes: OK[/] ({report['votes_checked']} votos)"
        )
        return

    console.print("[red]❌ Integridad de Cadena de Hashes: FALLIDA[/]")
    for v in report["violations"]:
        console.print(f"  [red]✗[/] {v['type']} en el Voto #{v.get('vote_id', 'N/A')}")


def _print_merkle_report(merkle_report: list[dict]) -> None:
    """Imprime el resultado de verificación de raíces Merkle."""
    merkle_valid = all(r["valid"] for r in merkle_report)
    if merkle_valid:
        console.print(
            f"[green]✅ Integridad de Raíz Merkle: OK[/] ({len(merkle_report)} puntos de control)"
        )
        return

    console.print("[red]❌ Integridad de Raíz Merkle: FALLIDA[/]")
    for r in merkle_report:
        if not r["valid"]:
            console.print(
                f"  [red]✗[/] ¡Desajuste en Punto de Control {r['checkpoint_id']}! "
                f"Esperado {r['expected'][:16]}... vs Actual {r['actual'][:16]}..."
            )
