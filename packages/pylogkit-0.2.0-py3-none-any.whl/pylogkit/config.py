"""One-call logging setup for applications."""

import contextvars
import logging
import sys


def setup_logging(
    level: str = "INFO",
    service_name: str | None = None,
    json_format: bool | None = None,
    slack_token: str | None = None,
    slack_channel: str | None = None,
    slack_webhook_url: str | None = None,
    slack_level: str = "ERROR",
    slack_rate_limit: int = 1,
    slack_rate_period: float = 60.0,
    slack_dedupe_window: float = 300.0,
    extra_context: dict[str, str] | None = None,
    loggers: dict[str, str] | None = None,
    ctx_var: contextvars.ContextVar | None = None,
) -> None:
    """Configure logging for the application in one call.

    Args:
        level: Root log level (default: INFO).
        service_name: Service identifier added to every log record.
        json_format: Force JSON (True) or colored (False) output.
            If None, auto-detects: JSON when not a TTY, colored otherwise.
        slack_token: Slack Bot token for error notifications.
        slack_channel: Slack channel for error notifications.
        slack_webhook_url: Slack incoming webhook URL (alternative to token).
        slack_level: Minimum level for Slack notifications (default: ERROR).
        slack_rate_limit: Max Slack messages per rate_period (default: 1).
        slack_rate_period: Rate limit window in seconds (default: 60).
        slack_dedupe_window: Deduplication window in seconds (default: 300).
        extra_context: Static fields added to every log record.
        loggers: Per-logger level overrides, e.g. ``{"httpx": "WARNING"}``.
        ctx_var: A ``ContextVar[dict]`` for request-scoped fields.
            If provided, a ``ContextVarsFilter`` is added to all handlers.

    Example::

        from pylogkit import setup_logging

        setup_logging(
            level="INFO",
            service_name="my-api",
            slack_token=os.environ.get("SLACK_BOT_TOKEN"),
            slack_channel="#errors",
            loggers={"httpx": "WARNING", "sqlalchemy": "WARNING"},
        )
    """
    from .filters import ContextFilter, ContextVarsFilter
    from .formatters import ColoredFormatter, JsonFormatter

    root = logging.getLogger()

    # Prevent duplicate setup
    if any(getattr(h, "_pylogkit", False) for h in root.handlers):
        return

    resolved_level = getattr(logging, level.upper(), logging.INFO)
    root.setLevel(resolved_level)

    # ── Console handler ──────────────────────────────────
    use_json = json_format if json_format is not None else not sys.stdout.isatty()

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(resolved_level)
    console._pylogkit = True  # type: ignore[attr-defined]

    if use_json:
        console.setFormatter(JsonFormatter())
    else:
        console.setFormatter(ColoredFormatter())

    # Add context filter (static fields)
    context = {"service": service_name} if service_name else {}
    if extra_context:
        context.update(extra_context)
    if context:
        console.addFilter(ContextFilter(**context))

    # Add contextvars filter (request-scoped fields)
    if ctx_var is not None:
        console.addFilter(ContextVarsFilter(ctx_var))

    root.addHandler(console)

    # ── Slack handler ────────────────────────────────────
    if slack_token or slack_webhook_url:
        _setup_slack_handler(
            token=slack_token,
            channel=slack_channel,
            webhook_url=slack_webhook_url,
            level=slack_level,
            rate_limit=slack_rate_limit,
            rate_period=slack_rate_period,
            dedupe_window=slack_dedupe_window,
            context=context,
            ctx_var=ctx_var,
            service_name=service_name,
        )

    # ── Per-logger levels ────────────────────────────────
    if loggers:
        for name, lvl in loggers.items():
            logging.getLogger(name).setLevel(getattr(logging, lvl.upper(), logging.INFO))


def _setup_slack_handler(
    token: str | None,
    channel: str | None,
    webhook_url: str | None,
    level: str,
    rate_limit: int,
    rate_period: float,
    dedupe_window: float,
    context: dict[str, str],
    ctx_var: contextvars.ContextVar | None = None,
    service_name: str | None = None,
) -> None:
    """Set up Slack handler with rate limiting and deduplication."""
    from .filters import ContextFilter, ContextVarsFilter, DeduplicationFilter, RateLimitFilter, SlackAlertFilter
    from .handlers import SlackHandler

    try:
        handler = SlackHandler(
            token=token,
            channel=channel,
            webhook_url=webhook_url,
            level=getattr(logging, level.upper(), logging.ERROR),
            service_name=service_name,
        )
        handler._pylogkit = True  # type: ignore[attr-defined]

        # Opt-out filter: drop records with slack_alert=False before any other filtering
        handler.addFilter(SlackAlertFilter())

        # Rate limit: prevent Slack spam
        handler.addFilter(RateLimitFilter(rate=rate_limit, period=rate_period))

        # Deduplication: suppress identical errors
        if dedupe_window > 0:
            handler.addFilter(DeduplicationFilter(window=dedupe_window))

        # Context
        if context:
            handler.addFilter(ContextFilter(**context))

        # Contextvars
        if ctx_var is not None:
            handler.addFilter(ContextVarsFilter(ctx_var))

        logging.getLogger().addHandler(handler)

    except Exception as e:
        print(f"[pylogkit] Failed to initialize SlackHandler: {e}", file=sys.stderr)
