"""Log filters: context injection, rate limiting, deduplication, and contextvars."""

import contextvars
import logging
import threading
import time
from typing import Any


class ContextFilter(logging.Filter):
    """Injects static context fields into every log record.

    Args:
        **context: Key-value pairs to add to each record.

    Example::

        handler.addFilter(ContextFilter(service="my-api", env="production"))
        # Every record will have record.service and record.env
    """

    def __init__(self, **context: Any):
        super().__init__()
        self._context = context

    def filter(self, record: logging.LogRecord) -> bool:
        for key, value in self._context.items():
            if not hasattr(record, key):
                setattr(record, key, value)
        return True

    def update(self, **context: Any) -> None:
        """Update or add context fields."""
        self._context.update(context)


class ContextVarsFilter(logging.Filter):
    """Injects context from ``contextvars.ContextVar`` into log records.

    Useful for request-scoped context (request_id, user_id, etc.)
    without passing ``extra={}`` to every log call.

    Args:
        ctx_var: A ``ContextVar`` holding a dict of fields to inject.

    Example::

        import contextvars
        from pylogkit import ContextVarsFilter

        log_context: contextvars.ContextVar[dict] = contextvars.ContextVar(
            "log_context", default={}
        )

        # Attach to handler or logger
        handler.addFilter(ContextVarsFilter(log_context))

        # In request handler:
        log_context.set({"request_id": "abc-123", "user_id": "42"})
        logger.info("Processing request")  # includes request_id and user_id
    """

    def __init__(self, ctx_var: contextvars.ContextVar):
        super().__init__()
        self._ctx_var = ctx_var

    def filter(self, record: logging.LogRecord) -> bool:
        ctx = self._ctx_var.get(None)
        if ctx is not None:
            for key, value in ctx.items():
                if not hasattr(record, key):
                    setattr(record, key, value)
        return True


class SlackAlertFilter(logging.Filter):
    """Blocks log records that explicitly opt out of Slack notifications.

    Records with ``extra={"slack_alert": False}`` are silently dropped
    from the Slack handler while still reaching all other handlers
    (console, Cloud Logging, etc.).

    Records without ``slack_alert`` or with ``slack_alert=True`` pass through.

    Example::

        # This error goes to Slack (default):
        logger.error("Account 123 failed: ...")

        # This error is logged but NOT sent to Slack:
        logger.error("Retry attempt failed", extra={"slack_alert": False})
    """

    def filter(self, record: logging.LogRecord) -> bool:
        return getattr(record, "slack_alert", True) is not False


class RateLimitFilter(logging.Filter):
    """Limits how often the same log message can pass through.

    Uses a token bucket per unique message. Each unique message is identified
    by its ``msg`` template (before formatting) + logger name + level.

    Args:
        rate: Maximum messages per ``period`` seconds for each unique message.
        period: Time window in seconds (default: 60).

    Example::

        handler.addFilter(RateLimitFilter(rate=1, period=60))
        # Each unique message passes at most once per minute.
    """

    _CLEANUP_EVERY = 100  # prune stale keys every N calls

    def __init__(self, rate: int = 1, period: float = 60.0):
        super().__init__()
        self.rate = rate
        self.period = period
        self._buckets: dict[str, list] = {}  # key -> [timestamps]
        self._lock = threading.Lock()
        self._call_count = 0

    def filter(self, record: logging.LogRecord) -> bool:
        key = f"{record.name}:{record.levelno}:{record.msg}"
        now = time.monotonic()

        with self._lock:
            self._call_count += 1
            if self._call_count % self._CLEANUP_EVERY == 0:
                self._prune(now)

            timestamps = self._buckets.get(key)
            if timestamps is None:
                self._buckets[key] = [now]
                return True

            # Remove expired timestamps
            cutoff = now - self.period
            timestamps[:] = [t for t in timestamps if t > cutoff]

            if len(timestamps) >= self.rate:
                return False

            timestamps.append(now)
            return True

    def _prune(self, now: float) -> None:
        """Remove keys with only expired timestamps."""
        cutoff = now - self.period
        stale = [k for k, ts in self._buckets.items() if all(t <= cutoff for t in ts)]
        for k in stale:
            del self._buckets[k]


class DeduplicationFilter(logging.Filter):
    """Suppresses duplicate log messages within a time window.

    Two messages are considered duplicates if they have the same:
    - logger name
    - log level
    - message template (``record.msg``, before formatting)

    On suppression, counts occurrences. When the window expires,
    the next message passes through with the suppressed count
    added as ``record._suppressed_count`` (does not mutate ``record.msg``).

    Args:
        window: Deduplication window in seconds (default: 300 = 5 min).

    Example::

        handler.addFilter(DeduplicationFilter(window=300))
    """

    _CLEANUP_EVERY = 100  # prune stale keys every N calls

    def __init__(self, window: float = 300.0):
        super().__init__()
        self.window = window
        self._seen: dict[str, _DedupeEntry] = {}
        self._lock = threading.Lock()
        self._call_count = 0

    def filter(self, record: logging.LogRecord) -> bool:
        key = self._make_key(record)
        now = time.monotonic()

        with self._lock:
            self._call_count += 1
            if self._call_count % self._CLEANUP_EVERY == 0:
                self._prune(now)

            entry = self._seen.get(key)

            if entry is None:
                self._seen[key] = _DedupeEntry(first_seen=now, count=1)
                return True

            # Window expired — let it through, reset
            if now - entry.first_seen >= self.window:
                suppressed = entry.count - 1
                self._seen[key] = _DedupeEntry(first_seen=now, count=1)
                if suppressed > 0:
                    record._suppressed_count = suppressed  # type: ignore[attr-defined]
                return True

            # Within window — suppress
            entry.count += 1
            return False

    def _prune(self, now: float) -> None:
        """Remove entries with expired windows."""
        stale = [k for k, e in self._seen.items() if now - e.first_seen >= self.window]
        for k in stale:
            del self._seen[k]

    @staticmethod
    def _make_key(record: logging.LogRecord) -> str:
        """Create a deduplication key from the record."""
        return f"{record.name}:{record.levelno}:{record.msg}"


class _DedupeEntry:
    __slots__ = ("first_seen", "count")

    def __init__(self, first_seen: float, count: int):
        self.first_seen = first_seen
        self.count = count
