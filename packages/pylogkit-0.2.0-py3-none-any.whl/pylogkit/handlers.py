"""Slack log handler with async dispatch and rate limiting."""

import atexit
import contextlib
import logging
import queue
import threading
import time
import traceback

from ._constants import BUILTIN_RECORD_ATTRS


class SlackHandler(logging.Handler):
    """Sends log records to a Slack channel via ``slack_sdk``.

    Features:
    - **Non-blocking**: dispatches messages via a background thread + queue.
    - **Built-in rate limiting**: respects Slack's 1 msg/sec limit per channel.
    - **Exponential backoff**: backs off on consecutive Slack failures.
    - **Graceful shutdown**: flushes pending messages on interpreter exit.
    - **Fallback**: logs to stderr if Slack is unreachable.

    Requires ``slack-sdk``: install with ``pip install pylogkit[slack]``.

    Args:
        token: Slack Bot OAuth token (``xoxb-...``).
        channel: Slack channel ID or name (e.g. ``#alerts``).
        level: Minimum log level (default: ERROR).
        max_queue_size: Max queued messages before dropping (default: 100).
        webhook_url: Use incoming webhook URL instead of Bot token.
            If provided, ``token`` and ``channel`` are ignored.

    Example::

        handler = SlackHandler(token="xoxb-...", channel="#errors")
        handler.setLevel(logging.ERROR)
        logging.getLogger().addHandler(handler)
    """

    # Slack rate limit: 1 message per second per channel
    _MIN_INTERVAL = 1.1
    # Exponential backoff limits
    _MAX_BACKOFF = 300.0  # 5 minutes max
    _BACKOFF_BASE = 2.0

    def __init__(
        self,
        token: str | None = None,
        channel: str | None = None,
        level: int = logging.ERROR,
        max_queue_size: int = 100,
        webhook_url: str | None = None,
        service_name: str | None = None,
    ):
        super().__init__(level)

        self._webhook_url = webhook_url
        self._token = token
        self._channel = channel
        self._service_name = service_name

        if not webhook_url and not token:
            raise ValueError("Either 'token' or 'webhook_url' must be provided")
        if not webhook_url and not channel:
            raise ValueError("'channel' is required when using token auth")

        self._queue: queue.Queue = queue.Queue(maxsize=max_queue_size)
        self._shutdown = threading.Event()

        self._thread = threading.Thread(
            target=self._worker,
            name="pylogkit-slack",
            daemon=True,
        )
        self._thread.start()
        atexit.register(self.close)

    def emit(self, record: logging.LogRecord) -> None:
        """Queue the record for async dispatch. Drops if queue is full."""
        with contextlib.suppress(queue.Full):
            self._queue.put_nowait(record)

    def close(self) -> None:
        """Flush remaining messages and stop the worker thread."""
        if self._shutdown.is_set():
            return
        self._shutdown.set()
        self._thread.join(timeout=10)
        super().close()

    def _worker(self) -> None:
        """Background worker: drain queue and send to Slack."""
        try:
            client = self._create_client()
        except ImportError as e:
            import sys

            print(f"[pylogkit] SlackHandler worker failed to start: {e}", file=sys.stderr)
            return

        last_send = 0.0
        consecutive_failures = 0

        while not self._shutdown.is_set():
            try:
                record = self._queue.get(timeout=1.0)
            except queue.Empty:
                continue

            # Rate limit
            elapsed = time.monotonic() - last_send
            if elapsed < self._MIN_INTERVAL:
                time.sleep(self._MIN_INTERVAL - elapsed)

            success = self._send(client, record)
            last_send = time.monotonic()
            self._queue.task_done()

            if success:
                consecutive_failures = 0
            else:
                consecutive_failures += 1
                backoff = min(
                    self._BACKOFF_BASE**consecutive_failures,
                    self._MAX_BACKOFF,
                )
                self._shutdown.wait(timeout=backoff)

        # Flush remaining on shutdown
        while not self._queue.empty():
            try:
                record = self._queue.get_nowait()
                self._send(client, record)
                time.sleep(self._MIN_INTERVAL)
            except queue.Empty:
                break

    def _create_client(self):
        """Create Slack client (lazy import to keep slack_sdk optional)."""
        try:
            if self._webhook_url:
                from slack_sdk.webhook import WebhookClient

                return WebhookClient(url=self._webhook_url)
            else:
                from slack_sdk import WebClient

                return WebClient(token=self._token)
        except ImportError as err:
            raise ImportError(
                "slack-sdk is required for SlackHandler. Install with: pip install pylogkit[slack]"
            ) from err

    def _send(self, client, record: logging.LogRecord) -> bool:
        """Send a single record to Slack. Returns True on success."""
        try:
            attachment = self._format_attachment(record)

            if self._webhook_url:
                client.send(attachments=[attachment])
            else:
                client.chat_postMessage(
                    channel=self._channel,
                    text=f"[{record.levelname}] {record.getMessage()[:200]}",
                    attachments=[attachment],
                )
            return True
        except Exception as e:
            # Never let Slack failures propagate — print to stderr as fallback
            import sys

            print(
                f"[pylogkit] Failed to send to Slack: {e}",
                file=sys.stderr,
            )
            return False

    def _format_attachment(self, record: logging.LogRecord) -> dict:
        """Format log record as a Slack attachment."""
        color_map = {
            logging.WARNING: "warning",
            logging.ERROR: "danger",
            logging.CRITICAL: "#8B0000",
        }
        color = color_map.get(record.levelno, "warning")

        text = record.getMessage()
        suppressed = getattr(record, "_suppressed_count", 0)
        if suppressed:
            text = f"{text} (suppressed {suppressed} duplicates)"
        if len(text) > 2000:
            text = text[:2000] + "…"

        fields = [
            {"title": "Level", "value": record.levelname, "short": True},
            {"title": "Logger", "value": record.name, "short": True},
            {"title": "Module", "value": f"{record.pathname}:{record.lineno}", "short": False},
        ]

        # Include extra fields (structured logging context)
        extras = {
            k: v
            for k, v in record.__dict__.items()
            if k not in BUILTIN_RECORD_ATTRS and not k.startswith("_")
        }
        if extras:
            extras_text = "\n".join(f"• *{k}*: {v}" for k, v in extras.items())
            if len(extras_text) > 500:
                extras_text = extras_text[:500] + "\n… (truncated)"
            fields.append({"title": "Context", "value": extras_text, "short": False})

        # Only include traceback if there's a real exception
        if record.exc_info and record.exc_info[0] is not None:
            tb = "".join(traceback.format_exception(*record.exc_info))
            if len(tb) > 1000:
                tb = tb[:1000] + "\n… (truncated)"
            fields.append({"title": "Traceback", "value": f"```{tb}```", "short": False})

        attachment: dict = {
            "color": color,
            "text": text,
            "fields": fields,
            "ts": int(record.created),
        }
        if self._service_name:
            attachment["footer"] = self._service_name
        return attachment
