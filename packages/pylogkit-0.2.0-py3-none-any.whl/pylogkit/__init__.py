"""pylogkit — structured logging with Slack integration, rate limiting, and deduplication."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("pylogkit")
except PackageNotFoundError:
    __version__ = "0.0.0"

import logging

from .config import setup_logging
from .filters import ContextFilter, ContextVarsFilter, DeduplicationFilter, RateLimitFilter, SlackAlertFilter
from .formatters import ColoredFormatter, JsonFormatter

__all__ = [
    "setup_logging",
    "get_logger",
    "JsonFormatter",
    "ColoredFormatter",
    "ContextFilter",
    "ContextVarsFilter",
    "RateLimitFilter",
    "DeduplicationFilter",
    "SlackAlertFilter",
]

# Library best practice: NullHandler so library consumers don't get warnings
logging.getLogger(__name__).addHandler(logging.NullHandler())


def get_logger(name: str, **context) -> logging.Logger:
    """Get a logger with optional context fields.

    Args:
        name: Logger name (typically ``__name__``).
        **context: Static fields added to every record from this logger.

    If called again with the same logger name, the context is updated
    (merged with existing fields).

    Returns:
        Configured ``logging.Logger`` instance.

    Example::

        from pylogkit import get_logger

        logger = get_logger(__name__, pipeline="laba_czech")
        logger.info("Deal processed", extra={"deal_id": "123"})
    """
    log = logging.getLogger(name)
    if context:
        # Find existing ContextFilter or create a new one
        for f in log.filters:
            if isinstance(f, ContextFilter):
                f.update(**context)
                return log
        log.addFilter(ContextFilter(**context))
    return log


# Lazy import — only loaded when explicitly requested
def __getattr__(name: str):
    if name == "SlackHandler":
        from .handlers import SlackHandler

        return SlackHandler
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
