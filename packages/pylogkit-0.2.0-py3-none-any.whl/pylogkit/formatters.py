"""Log formatters: JSON for production, colored for development."""

import contextlib
import logging
from datetime import UTC, datetime
from typing import Any

from pythonjsonlogger.json import JsonFormatter as BaseJsonFormatter

from ._constants import BUILTIN_RECORD_ATTRS


class JsonFormatter(BaseJsonFormatter):
    """JSON formatter with clean output for production.

    Produces structured JSON with:
    - timestamp (ISO 8601 UTC)
    - level, logger, message
    - All extra fields passed via ``extra={}``
    - Exception traceback (if present)

    Strips verbose internal fields for cleaner output.
    """

    def add_fields(
        self,
        log_record: dict[str, Any],
        record: logging.LogRecord,
        message_dict: dict[str, Any],
    ) -> None:
        super().add_fields(log_record, record, message_dict)

        log_record["timestamp"] = datetime.fromtimestamp(record.created, tz=UTC).isoformat()
        log_record["level"] = record.levelname
        log_record["logger"] = record.name

        # Remove verbose internal fields
        for key in ("levelname", "funcName", "lineno", "pathname", "exc_text", "taskName"):
            log_record.pop(key, None)

        # Include formatted traceback
        if record.exc_info and not log_record.get("traceback"):
            log_record["traceback"] = self.formatException(record.exc_info)

        # Include suppressed duplicate count from DeduplicationFilter
        suppressed = getattr(record, "_suppressed_count", 0)
        if suppressed:
            log_record["suppressed_duplicates"] = suppressed


class ColoredFormatter(logging.Formatter):
    """Colored formatter for development with extras display.

    Falls back to plain text if ``colorlog`` is not installed.
    Appends extra fields as ``[key=value ...]`` to the message.
    """

    _MAX_EXTRA_VALUE_LEN = 50

    def __init__(
        self,
        fmt: str | None = None,
        datefmt: str | None = None,
        use_color: bool = True,
    ):
        self._use_color = use_color
        self._inner: logging.Formatter

        default_fmt = "%(asctime)s %(levelname)-8s %(name)s — %(message)s"

        if use_color:
            try:
                import colorlog

                self._inner = colorlog.ColoredFormatter(
                    f"%(log_color)s{default_fmt}%(reset)s",
                    datefmt=datefmt,
                    log_colors={
                        "DEBUG": "cyan",
                        "INFO": "green",
                        "WARNING": "yellow",
                        "ERROR": "red",
                        "CRITICAL": "red,bg_white",
                    },
                )
            except ImportError:
                self._use_color = False
                self._inner = logging.Formatter(fmt or default_fmt, datefmt=datefmt)
        else:
            self._inner = logging.Formatter(fmt or default_fmt, datefmt=datefmt)

    def format(self, record: logging.LogRecord) -> str:
        # Work on a copy to avoid mutating the original record
        # (important when multiple handlers process the same record)
        record = logging.makeLogRecord(record.__dict__)

        # Collect extra fields
        extras = {
            k: v
            for k, v in record.__dict__.items()
            if k not in BUILTIN_RECORD_ATTRS and not k.startswith("_")
        }

        # Format the message first (resolves % args), then append extras
        # This prevents breakage when extra values contain % characters
        if record.args:
            with contextlib.suppress(TypeError, ValueError):
                record.msg = record.msg % record.args
            record.args = None

        # Append suppressed duplicate count from DeduplicationFilter
        suppressed = getattr(record, "_suppressed_count", 0)
        if suppressed:
            record.msg = f"{record.msg} (suppressed {suppressed} duplicates)"

        if extras:
            parts = []
            for k, v in extras.items():
                s = str(v)
                if len(s) > self._MAX_EXTRA_VALUE_LEN:
                    s = s[: self._MAX_EXTRA_VALUE_LEN] + "…"
                parts.append(f"{k}={s}")
            record.msg = f"{record.msg}  [{' '.join(parts)}]"

        return self._inner.format(record)
