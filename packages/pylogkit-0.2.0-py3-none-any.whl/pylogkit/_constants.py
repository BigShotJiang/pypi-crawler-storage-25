"""Shared constants for pylogkit."""

# Standard logging record attributes to exclude when collecting extra fields.
# Used by formatters and handlers to identify user-supplied fields.
BUILTIN_RECORD_ATTRS: frozenset[str] = frozenset(
    {
        "args",
        "asctime",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "message",
        "module",
        "msecs",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "taskName",
        "thread",
        "threadName",
        # pylogkit control fields — internal, not shown in output
        "slack_alert",
    }
)
