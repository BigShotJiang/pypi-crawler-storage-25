"""GPU availability command.

Shows current GPU availability across regions, grouped by GPU type and region.
Designed for quick capacity checks: "what's available right now?"
"""

import json
from contextlib import nullcontext
from typing import Any

import click

from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel
from flow.cli.utils.error_handling import cli_error_guard, render_auth_required_message
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.errors import AuthenticationError


class AvailabilityCommand(BaseCommand):
    """Show current GPU availability across regions."""

    @property
    def name(self) -> str:
        return "availability"

    @property
    def help(self) -> str:
        return "Show current GPU availability across regions"

    def get_command(self) -> click.Command:
        from flow.cli.completion import complete_gpu_families as _complete_gpu_families

        @click.command(name=self.name, help=self.help)
        @click.option(
            "--gpu",
            help="Filter by GPU type (e.g., b200, h100)",
            shell_complete=_complete_gpu_families,
        )
        @click.option("--region", help="Filter by region (e.g., us-central5-a)")
        @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
        @cli_error_guard(self)
        def availability(
            gpu: str | None = None,
            region: str | None = None,
            as_json: bool = False,
        ):
            self._execute(gpu=gpu, region=region, as_json=as_json)

        return availability

    def _execute(
        self,
        *,
        gpu: str | None,
        region: str | None,
        as_json: bool,
    ) -> None:
        # Fetch instances via SDK
        import flow.sdk.factory as sdk_factory

        try:
            client = sdk_factory.create_client(auto_init=True)
        except AuthenticationError:
            render_auth_required_message(console, output_json=as_json)
            return

        req: dict[str, Any] = {}
        if region:
            req["region"] = region

        progress = (
            nullcontext()
            if as_json
            else AnimatedEllipsisProgress(
                console, "Checking GPU availability", transient=True, start_immediately=True
            )
        )
        with progress:
            instances = client.find_instances(req, limit=100)

        if not instances:
            if as_json:
                click.echo(json.dumps({"availability": []}, indent=2))
            else:
                console.print("[dim]No instances found.[/dim]")
            return

        # Build raw rows from SDK response
        raw_rows: list[dict[str, Any]] = []
        for inst in instances:
            gpu_type = (inst.gpu_type or "") or extract_gpu_info(inst.instance_type)[0]
            raw_rows.append(
                {
                    "region": inst.region,
                    "gpu_type": gpu_type,
                    "gpu_count": inst.gpu_count,
                    "price_per_hour": inst.price_per_hour,
                    "instance_type": inst.instance_type,
                    "available_quantity": inst.available_quantity,
                }
            )

        # Filter out zero-availability entries — this is an availability view.
        raw_rows = [r for r in raw_rows if (r.get("available_quantity") or 0) > 0]

        # Apply GPU filter
        gpu_filter = (gpu or "").lower().strip()
        if gpu_filter:
            raw_rows = [r for r in raw_rows if (r.get("gpu_type") or "").lower() == gpu_filter]

        if not raw_rows:
            if as_json:
                click.echo(json.dumps({"availability": []}, indent=2))
            else:
                console.print("[dim]No matching instances found.[/dim]")
            return

        # JSON output: return raw listings
        if as_json:
            click.echo(json.dumps({"availability": raw_rows}, indent=2))
            return

        # Group by (gpu_type, region). The API's available_quantity is an
        # instance count (server already divides resource_gpus // instance_gpus).
        groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for r in raw_rows:
            key = (r.get("gpu_type", ""), r.get("region", ""))
            gpu_count = r.get("gpu_count") or 1
            avail = r.get("available_quantity") or 0
            price = r.get("price_per_hour")
            price_per_gpu = None
            if isinstance(price, int | float) and price > 0 and gpu_count > 0:
                price_per_gpu = price / gpu_count
            groups.setdefault(key, []).append(
                {
                    "gpu_count": gpu_count,
                    "price_per_gpu": price_per_gpu,
                    "available": avail,
                }
            )

        # Build display rows. When per-GPU prices within a (gpu_type, region)
        # diverge by more than 2x, split into separate rows so users see the
        # real price for each config instead of a misleading min().
        _PRICE_DIVERGENCE_RATIO = 2.0
        _PRICE_DIVERGENCE_MIN_DIFF = 0.50  # Don't split over trivial differences
        display_rows: list[dict[str, Any]] = []

        for (gpu_type, rgn), configs in groups.items():
            prices = [
                c["price_per_gpu"]
                for c in configs
                if c["price_per_gpu"] is not None and c["price_per_gpu"] > 0
            ]
            should_split = (
                len(prices) >= 2
                and max(prices) / min(prices) > _PRICE_DIVERGENCE_RATIO
                and (max(prices) - min(prices)) > _PRICE_DIVERGENCE_MIN_DIFF
            )

            if should_split:
                for c in configs:
                    display_rows.append(
                        {
                            "gpu_type": gpu_type,
                            "region": rgn,
                            "gpu_count": c["gpu_count"],
                            "sizes_str": f"{c['gpu_count']}x",
                            "price_per_gpu": c["price_per_gpu"] or float("inf"),
                            "available": c["available"],
                        }
                    )
            else:
                sizes = sorted({c["gpu_count"] for c in configs if c["gpu_count"] > 0})
                sizes_str = ", ".join(f"{s}x" for s in sizes) if sizes else "-"
                # Merged row spans multiple config sizes that share a GPU pool.
                # Show total GPUs (instance_count * gpu_count) as the common unit.
                pool_gpus = max(
                    (c["available"] * c["gpu_count"] for c in configs), default=0
                )
                min_price = min(prices) if prices else float("inf")
                display_rows.append(
                    {
                        "gpu_type": gpu_type,
                        "region": rgn,
                        "gpu_count": sizes[0] if sizes else 0,
                        "sizes_str": sizes_str,
                        "price_per_gpu": min_price,
                        "available": pool_gpus,
                    }
                )

        display_rows.sort(
            key=lambda r: (r["gpu_type"], r["price_per_gpu"], r["gpu_count"])
        )

        # Render table
        accent = theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")
        table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
        table.add_column("GPU", style=accent, no_wrap=True)
        table.add_column("Region", style=muted, no_wrap=True)
        table.add_column("GPU Configs", style=muted, no_wrap=True)
        table.add_column("Price/GPU", justify="right", no_wrap=True)
        table.add_column("Available", justify="right")

        for row in display_rows:
            price = row["price_per_gpu"]
            price_str = f"${price:.2f}/hr" if price < float("inf") else "-"
            avail_str = str(row["available"])
            table.add_row(row["gpu_type"], row["region"], row["sizes_str"], price_str, avail_str)

        title_parts = ["GPU Availability"]
        if gpu_filter:
            # Canonical lowercase family — matches `flow submit -i` and the
            # table body. Count is not known at the filter level; it appears
            # separately in the "GPU Configs" column per row.
            title_parts.append(gpu_filter.lower())
        if region:
            title_parts.append(region)
        wrap_table_in_panel(table, " - ".join(title_parts), console)


command = AvailabilityCommand()
