"""Smoke tests — runs against a mock server via pytest-httpx.

Install dev deps first:
    pip install -e '.[dev]'
Run:
    pytest
"""
from __future__ import annotations

import json

import pytest

from nage import Nage, AuthError, RateLimitError, ThinkResponse
from nage.types import Stemma


def _think_response_fixture():
    return {
        "response": "The right to erasure under GDPR Article 17 allows...",
        "stemma": {
            "weights": {"fehm-en": 0.71, "cortex-reasoning": 0.21, "cortex-eval": 0.08},
            "dominant_varve": "fehm-en",
            "entropy": 0.52,
            "facies_mass": 0.11,
            "entries": [
                {"varve_id": "v-1", "name": "fehm-en",          "weight": 0.71, "rank": 1},
                {"varve_id": "v-2", "name": "cortex-reasoning", "weight": 0.21, "rank": 2},
            ],
        },
        "meta": {"latency_ms": 847, "active_k": 2, "facies_mass": 0.11},
        "thought_id": "t-abc123",
    }


def test_think_happy_path(httpx_mock):
    httpx_mock.add_response(
        url="https://api.sedim.ai/think",
        method="POST",
        json=_think_response_fixture(),
    )
    client = Nage(api_key="nk_test_xxx")
    r = client.think(query="Explain GDPR 17", platform="nm/fehm")

    assert isinstance(r, ThinkResponse)
    assert r.text.startswith("The right to erasure")
    assert isinstance(r.stemma, Stemma)
    assert r.stemma.dominant_varve == "fehm-en"
    assert r.stemma.weights["fehm-en"] == pytest.approx(0.71)
    assert r.latency_ms == 847
    assert r.thought_id == "t-abc123"


def test_missing_credentials_raises():
    import os
    os.environ.pop("NAGE_API_KEY", None)
    with pytest.raises(ValueError, match="No credentials"):
        Nage()


def test_auth_error_on_401(httpx_mock):
    httpx_mock.add_response(
        url="https://api.sedim.ai/think",
        method="POST",
        status_code=401,
        json={"detail": "Invalid API key"},
    )
    client = Nage(api_key="nk_test_xxx", max_retries=0)
    with pytest.raises(AuthError) as ei:
        client.think(query="hi")
    assert ei.value.status == 401


def test_rate_limit_exhausted(httpx_mock):
    # Always 429 — should retry then surface RateLimitError
    for _ in range(4):
        httpx_mock.add_response(
            url="https://api.sedim.ai/think",
            method="POST",
            status_code=429,
            headers={"Retry-After": "1"},
            json={"detail": "rate_limit_exceeded"},
        )
    client = Nage(api_key="nk_test_xxx", max_retries=1)
    with pytest.raises(RateLimitError) as ei:
        client.think(query="hi")
    assert ei.value.retry_after == 1


def test_varves_list(httpx_mock):
    httpx_mock.add_response(
        url="https://api.sedim.ai/varves/",
        method="GET",
        json=[
            {"id": "v1", "name": "fehm-tr", "layer": "FEHM", "status": "active", "rank": 32},
            {"id": "v2", "name": "fehm-en", "layer": "FEHM", "status": "active", "rank": 32},
        ],
    )
    client = Nage(api_key="nk_test_xxx")
    varves = client.varves.list()
    assert len(varves) == 2
    assert varves[0].name == "fehm-tr"
    assert varves[1].status == "active"
