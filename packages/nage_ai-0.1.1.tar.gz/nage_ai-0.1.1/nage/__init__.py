"""Nage — official Python SDK for the source-attributed AI platform on SEDIM.

Quickstart:

    from nage import Nage

    client = Nage(api_key="nk_live_...")

    r = client.think(
        query="Explain GDPR Article 17",
        platform="nm/fehm",
        inference_mode="top_k",
    )
    print(r.text)
    print(r.stemma.weights)    # {"fehm-en": 0.71, "cortex-reasoning": 0.21, ...}
    print(r.stemma.entropy)    # 0.52

    # VARVE management
    for v in client.varves.list():
        print(v.name, v.status)

    health = client.varves.health("<varve-id>")
    print(health.status)        # "optimal" | "weak" | "collapsed" | ...

Full docs: https://nage.ai/docs
"""

from nage.client import Nage
from nage.errors import (
    NageError,
    AuthError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    ServerError,
)
from nage.types import (
    Stemma,
    StemmaEntry,
    ThinkResponse,
    VARVE,
    VARVEHealth,
    InferenceMode,
)

__version__ = "0.1.1"

__all__ = [
    "Nage",
    "NageError",
    "AuthError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "Stemma",
    "StemmaEntry",
    "ThinkResponse",
    "VARVE",
    "VARVEHealth",
    "InferenceMode",
]
