"""Nage client — sync.

One HTTP client, automatic retries on 429/5xx with exponential backoff,
typed responses. Authentication via API key (`X-Nage-Key` header) or JWT
(`Authorization: Bearer ...`). API key is the default.
"""

from __future__ import annotations

import os
import random
import time
from typing import Any

import httpx

from nage.errors import (
    AuthError,
    NageError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from nage.resources.varves import VarvesResource
from nage.resources.ingest import IngestResource
from nage.types import InferenceMode, ThinkResponse


DEFAULT_BASE_URL = "https://api.sedim.ai"


class Nage:
    """Nage API client.

    Args:
        api_key: `nk_live_...` or `nk_test_...` key from /dashboard/keys.
                 Falls back to NAGE_API_KEY env var if not provided.
        bearer_token: JWT for user-scoped operations. Takes precedence over
                      api_key if both are set.
        base_url: override the default endpoint (e.g. for self-hosted).
        timeout_s: per-request timeout in seconds (default 90 — cold-start
                   on serverless GPU can take ~30s).
        max_retries: retry count on 429/5xx (default 3, exponential backoff).

    Example:
        >>> client = Nage(api_key="nk_live_...")
        >>> r = client.think(query="What is SEDIM?", platform="nm/fehm")
        >>> print(r.text, r.stemma.weights)
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        bearer_token: str | None = None,
        base_url: str | None = None,
        timeout_s: float = 90.0,
        max_retries: int = 3,
    ):
        self.api_key = api_key or os.environ.get("NAGE_API_KEY")
        self.bearer_token = bearer_token
        if not self.api_key and not self.bearer_token:
            raise ValueError(
                "No credentials provided. Pass api_key=... or bearer_token=..., "
                "or set NAGE_API_KEY environment variable."
            )
        self.base_url = (base_url or os.environ.get("NAGE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout_s = timeout_s
        self.max_retries = max_retries
        self._http = httpx.Client(timeout=timeout_s, headers=self._default_headers())

        # Resource groups
        self.varves: VarvesResource = VarvesResource(self)
        self.ingest: IngestResource = IngestResource(self)

    # ── public methods ───────────────────────────────────────────────────

    def think(
        self,
        query: str,
        *,
        platform: str = "nm/fehm",
        inference_mode: InferenceMode = "top_k",
        max_tokens: int = 512,
        temperature: float = 0.7,
        varve_ids: list[str] | None = None,
        context: list[dict] | None = None,
        **extra: Any,
    ) -> ThinkResponse:
        """Send a query, get a source-attributed response.

        See https://nage.ai/docs#think for full parameter reference.
        """
        payload = {
            "query":          query,
            "platform":       platform,
            "inference_mode": inference_mode,
            "max_tokens":     max_tokens,
            "temperature":    temperature,
        }
        if varve_ids is not None:
            payload["varve_ids"] = varve_ids
        if context is not None:
            payload["context"] = context
        payload.update(extra)
        data = self._request("POST", "/think", json=payload)
        return ThinkResponse.from_dict(data)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Nage":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── internal — request plumbing ──────────────────────────────────────

    def _default_headers(self) -> dict[str, str]:
        h = {
            "Content-Type": "application/json",
            "User-Agent":   f"nage-python/0.1.0",
        }
        if self.bearer_token:
            h["Authorization"] = f"Bearer {self.bearer_token}"
        elif self.api_key:
            h["X-Nage-Key"] = self.api_key
        return h

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        files: dict | None = None,
        data: dict | None = None,
    ) -> dict:
        url = f"{self.base_url}{path}"
        attempt = 0
        while True:
            try:
                if files:
                    # multipart: don't send Content-Type header (httpx sets boundary)
                    headers = {k: v for k, v in self._default_headers().items() if k != "Content-Type"}
                    resp = self._http.request(method, url, params=params, data=data, files=files, headers=headers)
                else:
                    resp = self._http.request(method, url, json=json, params=params)
            except httpx.TimeoutException as e:
                raise ServerError(f"Request timed out: {e}") from e
            except httpx.HTTPError as e:
                raise NageError(f"Network error: {e}") from e

            if resp.status_code < 400:
                if resp.status_code == 204 or not resp.content:
                    return {}
                try:
                    return resp.json()
                except Exception:
                    return {"_raw": resp.text}

            # Error handling + retry
            body: dict = {}
            try:
                body = resp.json()
            except Exception:
                body = {"detail": resp.text}
            detail = body.get("detail") if isinstance(body, dict) else str(body)
            if isinstance(detail, dict):
                detail = detail.get("error") or detail.get("hint") or str(detail)
            detail_str = str(detail) if detail is not None else resp.reason_phrase

            # Retryable — 429, 5xx
            if resp.status_code in (429, 500, 502, 503, 504) and attempt < self.max_retries:
                retry_after = _retry_after_seconds(resp)
                backoff = retry_after if retry_after is not None else _exp_backoff(attempt)
                time.sleep(backoff)
                attempt += 1
                continue

            # Terminal
            if resp.status_code == 401 or resp.status_code == 403:
                raise AuthError(detail_str, status=resp.status_code, body=body)
            if resp.status_code == 404:
                raise NotFoundError(detail_str, status=resp.status_code, body=body)
            if resp.status_code == 429:
                raise RateLimitError(
                    detail_str, status=resp.status_code, body=body,
                    retry_after=_retry_after_seconds(resp),
                )
            if 400 <= resp.status_code < 500:
                raise ValidationError(detail_str, status=resp.status_code, body=body)
            raise ServerError(detail_str, status=resp.status_code, body=body)


def _retry_after_seconds(resp: httpx.Response) -> int | None:
    v = resp.headers.get("retry-after") or resp.headers.get("Retry-After")
    if not v:
        return None
    try:
        return int(v)
    except ValueError:
        return None


def _exp_backoff(attempt: int, base: float = 0.5, cap: float = 10.0) -> float:
    """Exponential backoff with full jitter."""
    return min(cap, base * (2 ** attempt)) * random.random()
