"""Exception hierarchy.

All SDK-raised exceptions inherit from NageError so callers can catch
broadly (`except NageError: ...`) or narrowly (`except RateLimitError:`).
HTTP status is preserved on the exception for logging/retry logic.
"""

from __future__ import annotations


class NageError(Exception):
    """Base class for all Nage SDK errors."""

    def __init__(self, message: str, *, status: int | None = None, body: dict | None = None):
        super().__init__(message)
        self.status = status
        self.body = body or {}


class AuthError(NageError):
    """401 / 403 — missing or invalid credentials, or tier-gated endpoint."""


class RateLimitError(NageError):
    """429 — too many requests for this tier's per-minute / per-month cap.

    Includes `retry_after` (seconds) when server sends Retry-After header.
    """

    def __init__(self, message: str, *, status: int | None = 429, body: dict | None = None,
                 retry_after: int | None = None):
        super().__init__(message, status=status, body=body)
        self.retry_after = retry_after


class NotFoundError(NageError):
    """404 — resource (VARVE, agent, canvas, ...) does not exist."""


class ValidationError(NageError):
    """400 — request payload failed validation."""


class ServerError(NageError):
    """5xx — retryable server error."""
