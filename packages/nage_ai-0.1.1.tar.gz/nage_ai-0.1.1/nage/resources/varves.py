"""/varves endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

from nage.types import VARVE, VARVEHealth

if TYPE_CHECKING:
    from nage.client import Nage


class VarvesResource:
    def __init__(self, client: "Nage"):
        self._client = client

    def list(self) -> list[VARVE]:
        """Return all VARVEs the caller has access to."""
        data = self._client._request("GET", "/varves/")
        rows = data if isinstance(data, list) else (data.get("varves") or [])
        return [VARVE.from_dict(r) for r in rows]

    def get(self, varve_id: str) -> VARVE:
        """Fetch a single VARVE by id."""
        data = self._client._request("GET", f"/varves/{varve_id}")
        return VARVE.from_dict(data)

    def health(self, varve_id: str) -> VARVEHealth:
        """Orbital health snapshot — ρ band + status."""
        data = self._client._request("GET", f"/varves/{varve_id}/health")
        return VARVEHealth.from_dict(data)

    def health_summary(self) -> dict:
        """Aggregate health across all VARVEs in the org."""
        return self._client._request("GET", "/varves/health/summary")

    def privacy_delete(self, varve_id: str) -> dict:
        """GDPR / KVKK Article 17 — surgical removal.

        Anonymizes VARVE weights, nulls STEMMA logs, and records a signed
        deletion proof in the audit log. Irreversible.
        """
        return self._client._request("POST", f"/varves/{varve_id}/privacy-delete")

    def promote(self, varve_id: str, *, to: str = "active") -> dict:
        """Promote a VARVE along its lifecycle (e.g., volatile → active)."""
        return self._client._request(
            "POST", f"/varves/{varve_id}/promote", json={"status": to}
        )

    def rollback(self, varve_id: str, *, version_id: str | None = None) -> dict:
        """Roll a VARVE back to a previous version."""
        payload = {"version_id": version_id} if version_id else {}
        return self._client._request("POST", f"/varves/{varve_id}/rollback", json=payload)

    def audit(self, varve_id: str) -> list[dict]:
        """Hash-chained audit events for this VARVE (every lifecycle mutation)."""
        data = self._client._request("GET", f"/varves/{varve_id}/audit")
        return data if isinstance(data, list) else (data.get("events") or [])
