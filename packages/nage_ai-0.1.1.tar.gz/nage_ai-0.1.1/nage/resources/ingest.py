"""/ingest endpoints — upload files, train VARVEs."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from nage.types import VARVE

if TYPE_CHECKING:
    from nage.client import Nage


class IngestResource:
    def __init__(self, client: "Nage"):
        self._client = client

    def upload_and_train(
        self,
        file_path: str | Path,
        *,
        name: str,
        layer: str = "FEHM",
        varve_type: str = "flash",
        rank: int | None = None,
        wait_for_ready: bool = False,
        poll_interval_s: float = 5.0,
    ) -> VARVE:
        """Upload a file and train a VARVE on it.

        Args:
            file_path: local path to a .pdf, .txt, .md, .docx, .jsonl, etc.
            name: VARVE name (must be unique per org).
            layer: FEHM / MING / CORTEX / CHI or custom family label.
            varve_type: 'ephemeral' (no persistence) | 'flash' (rank 32) |
                        'full' (rank 128, Business+).
            rank: override the default rank for this layer.
            wait_for_ready: if True, block until training completes.
            poll_interval_s: poll frequency when wait_for_ready=True.

        Returns:
            VARVE metadata (status will be 'pending' / 'training' unless
            wait_for_ready=True, then 'active' or 'ready').
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(file_path)

        data: dict[str, Any] = {
            "name":       name,
            "layer":      layer,
            "varve_type": varve_type,
        }
        if rank is not None:
            data["rank"] = str(rank)

        with path.open("rb") as f:
            files = {"file": (path.name, f, "application/octet-stream")}
            result = self._client._request(
                "POST", "/ingest/upload-and-train", data=data, files=files
            )

        varve = VARVE.from_dict(result)
        if not wait_for_ready:
            return varve

        # Poll until status is active / ready / failed
        import time as _time
        deadline = _time.time() + 1800  # 30 min hard cap
        while _time.time() < deadline:
            current = self._client.varves.get(varve.id)
            if current.status in ("active", "ready"):
                return current
            if current.status in ("failed", "forgotten"):
                raise RuntimeError(f"VARVE training failed: {current.raw}")
            _time.sleep(poll_interval_s)
        raise TimeoutError(f"VARVE {varve.id} did not reach ready within 30 min")
