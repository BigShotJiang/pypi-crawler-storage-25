"""Typed response objects.

Every resource method returns a dataclass so callers get autocomplete and
type checking. Raw dicts are exposed as `.raw` for forward-compat with new
server fields.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


# Accepted values for think(inference_mode=...)
InferenceMode = Literal["full", "top_k", "adaptive", "static", "resonance"]


@dataclass
class StemmaEntry:
    """A single VARVE's contribution to one response."""
    name:     str
    weight:   float
    varve_id: str | None = None
    rank:     int | None = None


@dataclass
class Stemma:
    """Attribution map returned with every /think response."""
    weights:         dict[str, float]
    dominant_varve:  str | None
    entropy:         float
    facies_mass:     float
    entries:         list[StemmaEntry] = field(default_factory=list)
    raw:             dict[str, Any]    = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Stemma":
        entries = [
            StemmaEntry(
                name=e.get("name", ""),
                weight=float(e.get("weight", 0.0)),
                varve_id=e.get("varve_id"),
                rank=e.get("rank"),
            )
            for e in (d.get("entries") or [])
        ]
        return cls(
            weights=dict(d.get("weights") or {}),
            dominant_varve=d.get("dominant_varve"),
            entropy=float(d.get("entropy", 0.0)),
            facies_mass=float(d.get("facies_mass", 0.0)),
            entries=entries,
            raw=d,
        )


@dataclass
class ThinkResponse:
    """Response from client.think(...)."""
    text:       str
    stemma:     Stemma
    thought_id: str | None
    latency_ms: int | None
    active_k:   int | None
    raw:        dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ThinkResponse":
        meta = d.get("meta") or {}
        return cls(
            text=d.get("response", "") or d.get("text", ""),
            stemma=Stemma.from_dict(d.get("stemma") or {}),
            thought_id=d.get("thought_id"),
            latency_ms=meta.get("latency_ms"),
            active_k=meta.get("active_k"),
            raw=d,
        )


@dataclass
class VARVE:
    """Minimal VARVE metadata — what /varves/ returns per row."""
    id:          str
    name:        str
    layer:       str | None     # FEHM / MING / CORTEX / CHI / custom
    status:      str            # seed / active / volatile / archived / merged / forgotten
    rank:        int | None
    varve_type:  str | None     # ephemeral / flash / full / market
    created_at:  str | None
    raw:         dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "VARVE":
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            layer=d.get("layer"),
            status=d.get("status", "unknown"),
            rank=d.get("rank"),
            varve_type=d.get("varve_type") or d.get("type"),
            created_at=d.get("created_at"),
            raw=d,
        )


@dataclass
class VARVEHealth:
    """Orbital health snapshot for a VARVE."""
    varve_id:   str
    status:     str            # optimal / weak / collapsed / overtrained / unknown
    rho:        float | None   # ||VARVE||_F / ||FACIES||_F
    message:    str | None
    raw:        dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "VARVEHealth":
        return cls(
            varve_id=d.get("varve_id") or d.get("id", ""),
            status=d.get("status", "unknown"),
            rho=d.get("rho") if d.get("rho") is not None else d.get("orbital_radius"),
            message=d.get("message"),
            raw=d,
        )
