"""
Road geometry — Lane and Road.

The Road class is the single indirection point for leader resolution.
Today it performs a static lookup via vehicle.leader_id; in future
multi-lane scenarios it will perform a spatial, lane-aware search
without any changes to the SimulationLoop.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cacc_sim.vehicle import Vehicle


@dataclass
class Lane:
    """One lane on the road.  Width is stored for future lateral geometry."""
    lane_id: int
    width_m: float = 3.7


@dataclass
class Road:
    """
    Road geometry container and leader-resolution authority.

    Parameters
    ----------
    length_m : float
        Total road length (m).
    lanes : list[Lane]
        Ordered list of lanes.  Index 0 is the rightmost lane (standard
        convention).  Single-lane roads have exactly one entry.

    Notes
    -----
    get_leader() is the only method the SimulationLoop calls.  Its
    signature is stable; its implementation will evolve from a static
    dict lookup to a spatial search as multi-lane support is added.
    """

    length_m: float
    lanes: list[Lane] = field(default_factory=lambda: [Lane(lane_id=0)])

    @classmethod
    def single_lane(cls, length_m: float) -> Road:
        """Convenience factory for the common single-lane case."""
        return cls(length_m=length_m, lanes=[Lane(lane_id=0)])

    def get_leader(
        self,
        vehicle: Vehicle,
        vehicles_by_id: dict[int, Vehicle],
    ) -> Vehicle | None:
        """
        Return the vehicle immediately ahead of *vehicle*.

        Today: static lookup via vehicle.leader_id.
        Future: spatial search within vehicle.lane_id, handling overtakes
        and lane changes dynamically.

        Parameters
        ----------
        vehicle : Vehicle
            The ego vehicle whose leader is needed.
        vehicles_by_id : dict[int, Vehicle]
            All active vehicles keyed by id — the SimulationLoop's map.
        """
        if vehicle.leader_id is None:
            return None
        return vehicles_by_id.get(vehicle.leader_id)
