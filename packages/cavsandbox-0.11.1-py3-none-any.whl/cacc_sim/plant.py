"""
Vehicle physics layer: kinematic integrator and actuator response model.
"""
from __future__ import annotations

import numpy as np


class VehiclePlant:
    """
    Longitudinal kinematic integrator.  State: (position, speed).

    Integrates speed and position at each timestep given the actual
    (post-response-model) acceleration.  Speed is clamped at zero so the
    vehicle never reverses.
    """

    def __init__(self, x0: float, v0: float, length: float, dt: float = 0.01):
        self.x = x0
        self.v = v0
        self.length = length
        self.dt = dt
        self.a = 0.0  # last applied acceleration; callers read this for logging/BSM

    def step(self, a_actual: float) -> tuple[float, float]:
        """
        Advance one timestep.

        Parameters
        ----------
        a_actual : float
            Acceleration output from VehicleResponseModel (m/s²).

        Returns
        -------
        x, v : float
            Updated position (m) and speed (m/s).
        """
        self.a = a_actual
        self.v = max(0.0, self.v + a_actual * self.dt)
        self.x += self.v * self.dt
        return self.x, self.v

    def gap_to(self, leader: VehiclePlant) -> float:
        """
        Bumper-to-bumper gap to the vehicle immediately ahead.

        gap = leader rear bumper − ego front bumper
            = leader.x − self.x − leader.length
        """
        return leader.x - self.x - leader.length


class VehicleResponseModel:
    """
    Models actuator lag between commanded and actual acceleration.

    Two modes (selected at construction via the ``mode`` parameter):

    ``'kinematic'``
        Level 1 — commanded acceleration is applied instantly each step.
        No lag, no divide-by-zero risk.  Useful for quick prototyping or
        verifying control-law logic without physical actuator effects.

    ``'lag'``  (default)
        Level 2 — 1st-order low-pass lag on acceleration with separate
        throttle and brake time constants, a deadband coasting regime with
        passive drag, and jerk limiting.  Recommended for ACC/CACC research
        (§8.1 of design notes).

    The ``response_model`` key in the Excel simulation sheet ('kinematic' or
    'lag') maps directly to this ``mode`` parameter.

    Passive drag model (deadband regime)
    -------------------------------------
    Coasting deceleration uses a physically correct two-term model:

        a_drag = -(crr * g + k_aero * v²)

    where:
        crr    — rolling resistance coefficient (dimensionless); typical 0.01–0.015
        g      — gravitational acceleration, 9.81 m/s²
        k_aero — aerodynamic drag coefficient (1/m); = 0.5 * Cd * A * rho / m
                 typical car: Cd≈0.3, A≈2.2 m², rho≈1.2 kg/m³, m≈1500 kg → k_aero≈1.76e-4
                 typical truck: higher frontal area and mass give a different k_aero

    Rolling resistance dominates at low speed; aerodynamic drag dominates at
    highway speed.  The linear model (drag proportional to v) overstates drag
    by 2–3x at 30 m/s, so the quadratic form is preferred.
    """

    _VALID_MODES = ('kinematic', 'lag')

    def __init__(
        self,
        mode: str = 'lag',
        tau_throttle: float = 0.5,
        tau_brake: float = 0.3,
        deadband: float = 0.05,
        crr: float = 0.012,
        k_aero: float = 1.76e-4,
        a_max: float = 2.5,
        a_min: float = -8.0,
        j_max: float = 5.0,
        dt: float = 0.01,
    ):
        if mode not in self._VALID_MODES:
            raise ValueError(
                f"mode must be one of {self._VALID_MODES!r}, got {mode!r}"
            )
        self.mode = mode
        self.tau_throttle = tau_throttle
        self.tau_brake = tau_brake
        self.deadband = deadband
        self.crr = crr
        self.k_aero = k_aero
        self.a_max = a_max
        self.a_min = a_min
        self.j_max = j_max
        self.dt = dt
        self.a_actual = 0.0

    def step(self, a_commanded: float, v_ego: float) -> float:
        """
        Compute actual acceleration for this timestep.

        Parameters
        ----------
        a_commanded : float
            Acceleration requested by the driving model (m/s²).
        v_ego : float
            Current ego vehicle speed (m/s); used for passive-drag in deadband.

        Returns
        -------
        float
            Actual acceleration to apply to VehiclePlant (m/s²).
        """
        if self.mode == 'kinematic':
            self.a_actual = float(np.clip(a_commanded, self.a_min, self.a_max))
            return self.a_actual

        # ── 'lag' mode ──────────────────────────────────────────────────────
        a_sat = float(np.clip(a_commanded, self.a_min, self.a_max))

        if a_sat > self.deadband:
            tau = self.tau_throttle
        elif a_sat < -self.deadband:
            tau = self.tau_brake
        else:
            tau = 0.1  # numerical stabiliser — value only matters at lag granularity
            a_sat = -(self.crr * 9.81 + self.k_aero * v_ego ** 2)

        delta = float(np.clip(
            (self.dt / tau) * (a_sat - self.a_actual),
            -self.j_max * self.dt,
            self.j_max * self.dt,
        ))
        self.a_actual = float(np.clip(
            self.a_actual + delta, self.a_min, self.a_max
        ))
        return self.a_actual
