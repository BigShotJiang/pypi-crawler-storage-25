"""
Sensor, ego-sensor, BSM tracker, and fusion ABCs with concrete implementations.

Passthrough classes pass true plant values unchanged — useful for unit-testing
the fusion layer in isolation.  In the simulation loop, sensor_model =
'passthrough' bypasses all of these at the vehicle.step() level (no
instantiation at all); see Vehicle.step() for the branch logic.

Sensor pipeline (non-passthrough config)
-----------------------------------------
true_gap, true_gap_rate
  -> RadarSensor.step()
       -> DelayBuffer  (70 ms fixed latency)
       -> ARNoise      (AR(1) correlated measurement noise)
       -> GapKalmanFilter or LowPassFilter
  -> returns (gap_meas, gap_rate_meas, gap_filtered, gap_rate_filtered)

  -> FusionKalmanFilter.step(gap_filtered, rate_filtered, lead_a_v2v,
                             bsm_age_s, a_ego)
     OR PassthroughFusionEstimator.step(...)
  -> returns (gap_fused, rate_fused, lead_a_radar)

Ego sensor pipeline
-------------------
true_speed, true_accel
  -> NoisyEgoSensor.step()
  -> returns (v_meas, a_meas)
  vehicle stores _last_a_meas = a_meas for use by BSM tracker

BSM tracker (comms_model = 'dsrc')
-----------------------------------
DSRCBSMTracker.update(leader._last_a_meas)  [called every step]
  -> fires packet every bsm_interval_steps; drops with probability drop_rate
DSRCBSMTracker.acceleration  -> last received value; 0.0 when stale
DSRCBSMTracker.is_valid      -> True while age_s < max_age_s
DSRCBSMTracker.age_s         -> seconds since last received packet
"""
from __future__ import annotations

import math
import random
from abc import ABC, abstractmethod

import numpy as np

from cacc_sim.core import DelayBuffer

# ---------------------------------------------------------------------------
# Physical defaults for RadarSensor (fixed; not user-configurable in Step 16)
# ---------------------------------------------------------------------------
_RADAR_DELAY_S:   float = 0.07   # 70 ms processing latency
_RADAR_SIGMA_GAP: float = 0.30   # range noise std dev (m)
_RADAR_SIGMA_RATE: float = 0.10  # range-rate (Doppler) noise std dev (m/s)
_RADAR_RHO:       float = 0.80   # AR(1) temporal correlation coefficient
_RADAR_CUTOFF_HZ: float = 2.0    # LPF cutoff frequency (Hz)
_RADAR_SIGMA_A:   float = 1.0    # KF process noise: relative acceleration std dev (m/s²)

_EGO_SPEED_SIGMA:       float = 0.05   # wheel-encoder speed noise std dev (m/s)
_EGO_ACCEL_BIAS_DRIFT:  float = 0.02   # IMU bias drift rate (m/s² per step std dev / dt)
_EGO_ACCEL_NOISE_SIGMA: float = 0.08   # IMU vibration noise std dev (m/s²)


# ---------------------------------------------------------------------------
# AR(1) correlated noise
# ---------------------------------------------------------------------------

class ARNoise:
    """
    First-order autoregressive noise process.

    x[k] = rho * x[k-1] + sigma * sqrt(1 - rho²) * w[k],  w[k] ~ N(0,1)

    Steady-state variance = sigma², so sigma is the standard deviation of the
    noise in physical units.  rho controls temporal correlation (0 = white
    noise, 1 = random walk).

    Parameters
    ----------
    sigma : float
        Steady-state standard deviation of the noise (physical units).
    rho : float
        AR(1) coefficient (temporal correlation); must be in [0, 1).
    rng : random.Random
        Caller-supplied RNG instance (from vehicle_rng()).
    """

    def __init__(self, sigma: float, rho: float, rng: random.Random) -> None:
        self.sigma = sigma
        self.rho   = rho
        self._rng  = rng
        self._innov_std = sigma * math.sqrt(1.0 - rho ** 2)
        self._state: float = 0.0

    def sample(self) -> float:
        """Return the next noise sample."""
        self._state = (self.rho * self._state
                       + self._innov_std * self._rng.gauss(0.0, 1.0))
        return self._state


# ---------------------------------------------------------------------------
# Gap filter implementations
# ---------------------------------------------------------------------------

class GapKalmanFilter:
    """
    2-state linear Kalman filter for gap tracking.

    State  : x = [gap, gap_rate]
    Observe: z = [gap_meas, gap_rate_meas]  (range + Doppler)

    Constant-velocity state transition; process noise captures uncertainty in
    relative acceleration over one timestep.

    Parameters
    ----------
    dt : float
        Simulation timestep (s).
    sigma_gap : float
        Observation noise std dev for gap measurement (m).
    sigma_rate : float
        Observation noise std dev for gap-rate measurement (m/s).
    sigma_a : float
        Process noise: relative acceleration std dev (m/s²).
    """

    _I2 = np.eye(2)

    def __init__(
        self,
        dt: float,
        sigma_gap: float  = _RADAR_SIGMA_GAP,
        sigma_rate: float = _RADAR_SIGMA_RATE,
        sigma_a: float    = _RADAR_SIGMA_A,
    ) -> None:
        self.F = np.array([[1.0, dt], [0.0, 1.0]])
        self.H = np.eye(2)
        self.Q = sigma_a ** 2 * np.array([
            [dt ** 4 / 4.0, dt ** 3 / 2.0],
            [dt ** 3 / 2.0, dt ** 2],
        ])
        self.R = np.diag([sigma_gap ** 2, sigma_rate ** 2])
        self.x: np.ndarray | None = None
        self.P = np.diag([sigma_gap ** 2, sigma_rate ** 2])

    def step(self, gap_meas: float, rate_meas: float) -> tuple[float, float]:
        """
        Predict + update for one timestep.

        Returns
        -------
        (gap_filtered, gap_rate_filtered) : tuple[float, float]
        """
        if self.x is None:
            self.x = np.array([gap_meas, rate_meas])
            self.P = np.diag([self.R[0, 0], self.R[1, 1]])
            return gap_meas, rate_meas

        # Predict
        xp = self.F @ self.x
        Pp = self.F @ self.P @ self.F.T + self.Q

        # Update
        z  = np.array([gap_meas, rate_meas])
        S  = Pp + self.R          # H = I so H @ Pp @ H.T = Pp
        K  = Pp @ np.linalg.inv(S)
        self.x = xp + K @ (z - xp)
        self.P = (self._I2 - K) @ Pp

        return float(self.x[0]), float(self.x[1])


class LowPassFilter:
    """
    1st-order IIR low-pass filter applied independently to gap and gap_rate.

    Alpha is derived from a physical cutoff frequency so the filter is
    timestep-aware (never copy alpha from a different timestep).

    Parameters
    ----------
    cutoff_hz : float
        -3 dB cutoff frequency (Hz).
    dt : float
        Simulation timestep (s).
    """

    def __init__(self, cutoff_hz: float = _RADAR_CUTOFF_HZ, dt: float = 0.01) -> None:
        omega      = 2.0 * math.pi * cutoff_hz
        tau        = 1.0 / omega
        self.alpha = dt / (tau + dt)
        self._gap_y:  float | None = None
        self._rate_y: float | None = None

    def step(self, gap: float, rate: float) -> tuple[float, float]:
        """Return (gap_filtered, rate_filtered)."""
        if self._gap_y is None:
            self._gap_y  = gap
            self._rate_y = rate
        else:
            a = self.alpha
            self._gap_y  = a * gap  + (1.0 - a) * self._gap_y
            self._rate_y = a * rate + (1.0 - a) * self._rate_y
        return self._gap_y, self._rate_y


# ---------------------------------------------------------------------------
# BaseSensor ABC and concrete implementations
# ---------------------------------------------------------------------------

class BaseSensor(ABC):
    """
    Abstract base for radar/lidar range sensors.

    step() returns four values so the caller can log both the raw measurement
    and the filtered output without side effects:

        (gap_meas, gap_rate_meas, gap_filtered, gap_rate_filtered)
    """

    @abstractmethod
    def step(
        self, true_gap: float, true_gap_rate: float
    ) -> tuple[float, float, float, float]:
        """
        Parameters
        ----------
        true_gap : float
            True bumper-to-bumper gap (m).
        true_gap_rate : float
            True rate of change of gap (m/s); positive = gap growing.

        Returns
        -------
        gap_meas, gap_rate_meas, gap_filtered, gap_rate_filtered : float
        """


class PassthroughSensor(BaseSensor):
    """Perfect measurement with no delay, noise, or filtering.

    Intended for unit-testing the fusion layer in isolation, not for
    production use (config 'passthrough' bypasses the sensor entirely).
    """

    def step(self, true_gap: float, true_gap_rate: float) -> tuple[float, float, float, float]:
        return true_gap, true_gap_rate, true_gap, true_gap_rate


class RadarSensor(BaseSensor):
    """
    Automotive radar pipeline: fixed delay → AR(1) noise → gap filter.

    Fixed physical defaults (see module constants):
    - Detection delay: 70 ms
    - Range noise: σ = 0.30 m, ρ = 0.80
    - Range-rate noise: σ = 0.10 m/s, ρ = 0.80

    Parameters
    ----------
    rng : random.Random
        Caller-supplied per-vehicle RNG (from vehicle_rng()).
    dt : float
        Simulation timestep (s).
    filter_type : str
        'kalman' (default) or 'lpf'.
    """

    def __init__(
        self,
        rng: random.Random,
        dt: float = 0.01,
        filter_type: str = 'kalman',
    ) -> None:
        self._delay_gap  = DelayBuffer(_RADAR_DELAY_S, dt)
        self._delay_rate = DelayBuffer(_RADAR_DELAY_S, dt)
        self._noise_gap  = ARNoise(_RADAR_SIGMA_GAP,  _RADAR_RHO, rng)
        self._noise_rate = ARNoise(_RADAR_SIGMA_RATE, _RADAR_RHO, rng)
        if filter_type == 'kalman':
            self._filter: GapKalmanFilter | LowPassFilter = GapKalmanFilter(dt)
        else:
            self._filter = LowPassFilter(dt=dt)

    def step(self, true_gap: float, true_gap_rate: float) -> tuple[float, float, float, float]:
        delayed_gap  = self._delay_gap.push_and_read(true_gap)
        delayed_rate = self._delay_rate.push_and_read(true_gap_rate)

        if delayed_gap is None:
            # Delay buffer not yet full — return true values (startup transient)
            return true_gap, true_gap_rate, true_gap, true_gap_rate

        gap_meas  = delayed_gap  + self._noise_gap.sample()
        rate_meas = delayed_rate + self._noise_rate.sample()
        gap_filt, rate_filt = self._filter.step(gap_meas, rate_meas)

        return gap_meas, rate_meas, gap_filt, rate_filt


# ---------------------------------------------------------------------------
# BaseEgoSensor ABC and concrete implementations
# ---------------------------------------------------------------------------

class BaseEgoSensor(ABC):
    """Abstract base for ego vehicle state measurement (speed, acceleration)."""

    @abstractmethod
    def step(self, true_speed: float, true_accel: float) -> tuple[float, float]:
        """Return (measured_speed, measured_accel)."""


class PassthroughEgoSensor(BaseEgoSensor):
    """Perfect ego state — no noise.  Used when ego sensor columns are zero."""

    def step(self, true_speed: float, true_accel: float) -> tuple[float, float]:
        return true_speed, true_accel


class NoisyEgoSensor(BaseEgoSensor):
    """
    Realistic ego sensor: wheel encoder (speed) + IMU (acceleration).

    Speed    : white Gaussian noise (wheel-encoder quantization).
    Accel    : slow-varying IMU bias drift + vibration white noise.

    The IMU bias is broadcast in BSM packets and propagates into CACC
    feedforward of following vehicles — physically correct behavior.

    Parameters
    ----------
    rng : random.Random
        Caller-supplied per-vehicle RNG.
    speed_sigma : float
        Speed measurement noise std dev (m/s).
    accel_bias_drift : float
        IMU bias drift rate: std dev added per step = accel_bias_drift * dt.
    accel_noise_sigma : float
        IMU vibration noise std dev (m/s²).
    dt : float
        Simulation timestep (s).
    """

    def __init__(
        self,
        rng: random.Random,
        speed_sigma:       float = _EGO_SPEED_SIGMA,
        accel_bias_drift:  float = _EGO_ACCEL_BIAS_DRIFT,
        accel_noise_sigma: float = _EGO_ACCEL_NOISE_SIGMA,
        dt: float = 0.01,
    ) -> None:
        self._rng              = rng
        self.speed_sigma       = speed_sigma
        self.accel_bias_drift  = accel_bias_drift
        self.accel_noise_sigma = accel_noise_sigma
        self.dt                = dt
        self._accel_bias: float = 0.0

    def step(self, true_speed: float, true_accel: float) -> tuple[float, float]:
        v_meas = max(0.0, true_speed + self._rng.gauss(0.0, self.speed_sigma))
        self._accel_bias += self._rng.gauss(0.0, self.accel_bias_drift * self.dt)
        a_meas = true_accel + self._accel_bias + self._rng.gauss(0.0, self.accel_noise_sigma)
        return v_meas, a_meas


# ---------------------------------------------------------------------------
# BaseBSMTracker ABC and concrete implementations
# ---------------------------------------------------------------------------

class BaseBSMTracker(ABC):
    """Abstract base for V2V BSM reception and tracking."""

    @abstractmethod
    def update(self, leader_accel: float) -> None:
        """Ingest the most recent leader acceleration (m/s²)."""

    @property
    @abstractmethod
    def is_valid(self) -> bool:
        """True when a recent BSM is available."""

    @property
    @abstractmethod
    def age_s(self) -> float:
        """Seconds elapsed since the most recent received packet."""

    @property
    @abstractmethod
    def acceleration(self) -> float:
        """Most recent leader acceleration estimate (m/s²)."""


class PassthroughBSMTracker(BaseBSMTracker):
    """
    Perfect V2V — no latency, no packet drop.

    Used when sensor_model != 'passthrough' but realistic comms are not yet
    needed.  Returns the leader's measured acceleration exactly; age_s is
    always 0.0 (considered perpetually fresh).
    """

    def __init__(self) -> None:
        self._accel: float = 0.0

    def update(self, leader_accel: float) -> None:
        self._accel = leader_accel

    @property
    def is_valid(self) -> bool:
        return True

    @property
    def age_s(self) -> float:
        return 0.0

    @property
    def acceleration(self) -> float:
        return self._accel


class DSRCBSMTracker(BaseBSMTracker):
    """
    DSRC/C-V2X BSM tracker with realistic channel model.

    The leader broadcasts a Basic Safety Message every bsm_interval_steps
    simulation steps.  Each broadcast is independently dropped with
    probability packet_drop_rate.  A received acceleration is considered
    valid until max_age_s seconds have elapsed since reception; after that,
    acceleration returns 0.0 (graceful degradation to pure feedback).

    A per-vehicle random phase offset staggered via phase_rng ensures
    vehicles do not all broadcast simultaneously, which is more representative
    of DSRC slot usage.

    Parameters
    ----------
    rng : random.Random
        Per-vehicle RNG for packet-drop decisions
        (from vehicle_rng(..., 'bsm_comms')).
    phase_rng : random.Random
        Per-vehicle RNG for initial phase offset
        (from vehicle_rng(..., 'bsm_phase')).
    dt : float
        Simulation timestep (s).
    bsm_rate_hz : float
        BSM broadcast rate (Hz); default 10 Hz per DSRC standard.
    packet_drop_rate : float
        Per-packet loss probability; default 0.05.
    max_age_s : float
        Stale timeout: acceleration returns 0.0 after this many seconds
        without a received packet; default 0.2 s (2 missed intervals).
    """

    def __init__(
        self,
        rng: random.Random,
        phase_rng: random.Random,
        dt: float = 0.01,
        bsm_rate_hz: float = 10.0,
        packet_drop_rate: float = 0.05,
        max_age_s: float = 0.2,
    ) -> None:
        self._rng        = rng
        self._dt         = dt
        self._drop_rate  = packet_drop_rate
        self._max_age_s  = max_age_s
        self._interval_steps: int = max(1, round(1.0 / (bsm_rate_hz * dt)))

        # Random initial phase to stagger broadcasts across vehicles.
        self._phase_offset: int = phase_rng.randint(0, self._interval_steps - 1)
        self._tx_counter:   int = self._phase_offset

        # Start stale — no packet received yet.
        self._age_steps: int = round(max_age_s / dt) + 1
        self._accel: float   = 0.0

    def update(self, leader_accel: float) -> None:
        """
        Called every sim step with the leader's ego-measured acceleration.

        Fires a packet transmission attempt every bsm_interval_steps steps;
        resets age to 0 on a successful (non-dropped) reception.
        """
        self._tx_counter += 1
        self._age_steps  += 1
        if self._tx_counter % self._interval_steps == 0:
            if self._rng.random() >= self._drop_rate:
                self._accel     = leader_accel
                self._age_steps = 0

    @property
    def is_valid(self) -> bool:
        return self._age_steps * self._dt < self._max_age_s

    @property
    def age_s(self) -> float:
        return self._age_steps * self._dt

    @property
    def acceleration(self) -> float:
        return self._accel if self.is_valid else 0.0

    @property
    def phase_offset_steps(self) -> int:
        """Initial broadcast phase (steps); logged in YAML for reproducibility."""
        return self._phase_offset


# ---------------------------------------------------------------------------
# BaseFusionEstimator ABC and concrete implementations
# ---------------------------------------------------------------------------

class BaseFusionEstimator(ABC):
    """
    Abstract base for sensor fusion (radar + BSM → fused state estimate).

    Inputs : filtered gap and gap_rate from the radar pipeline, lead_a_v2v from BSM.
    Outputs: fused gap, fused gap_rate, and lead_a_radar (Kalman-estimated leader
             acceleration for use by EIDM/CAH models).

    lead_a_radar is 0.0 in PassthroughFusionEstimator; a 3-state KF fusing
    radar + BSM will populate it in a future step.
    """

    @abstractmethod
    def step(
        self,
        gap_filtered: float,
        rate_filtered: float,
        lead_a_v2v: float,
        bsm_age_s: float = 0.0,
        a_ego: float = 0.0,
    ) -> tuple[float, float, float]:
        """
        Parameters
        ----------
        gap_filtered : float
            Radar-filtered gap estimate (m).
        rate_filtered : float
            Radar-filtered gap-rate estimate (m/s).
        lead_a_v2v : float
            BSM-reported leader acceleration (0.0 when stale/dropped).
        bsm_age_s : float
            Seconds since last BSM packet; < dt means fresh this step.
        a_ego : float
            Ego vehicle's measured acceleration (m/s²); used in state transition.

        Returns
        -------
        gap_fused, rate_fused, lead_a_radar : float
        """

    def seed(self, gap: float, rate: float) -> None:
        """Seed initial state before first step(). No-op for passthrough."""
        pass


class PassthroughFusionEstimator(BaseFusionEstimator):
    """Identity fusion — passes radar output directly to controller."""

    def step(
        self,
        gap_filtered: float,
        rate_filtered: float,
        lead_a_v2v: float,
        bsm_age_s: float = 0.0,
        a_ego: float = 0.0,
    ) -> tuple[float, float, float]:
        return gap_filtered, rate_filtered, 0.0


class FusionKalmanFilter(BaseFusionEstimator):
    """
    3-state multi-rate Kalman filter fusing radar and DSRC BSM.

    State: x = [gap, gap_rate, a_lead]ᵀ

    Prediction uses ego acceleration as a known input u = a_ego:
        gap[k+1]      = gap[k]      + dt·gap_rate[k] + ½dt²·(a_lead[k] − a_ego[k])
        gap_rate[k+1] = gap_rate[k] + dt·(a_lead[k] − a_ego[k])
        a_lead[k+1]   = a_lead[k]   + process noise

    Observations applied each step in sequence:
    1. Radar (100 Hz, every step): z_r = [gap_filtered, rate_filtered]
    2. BSM   (10 Hz, when bsm_age_s < dt): z_b = [lead_a_v2v]

    R_bsm is pre-computed by the loader as:
        sqrt(accel_noise_sigma² + accel_bias_drift² · dt · bsm_interval_s)
    which accounts for white vibration noise plus accumulated bias drift
    between consecutive BSM packets.

    Q[2,2] = (j_max · dt)² anchors the a_lead process noise to the physical
    jerk limit of the CACC platoon.

    Parameters
    ----------
    dt : float
        Simulation timestep (s).
    sigma_gap : float
        Radar gap observation noise std dev (m).
    sigma_rate : float
        Radar range-rate observation noise std dev (m/s).
    sigma_bsm_a : float
        BSM acceleration observation noise std dev (m/s²).
    sigma_q_rate : float
        Process noise std dev for gap_rate (m/s²); default 1.5 — larger
        than the radar-only KF to absorb unmodeled disturbances.
    j_max : float
        Leader jerk limit (m/s³); anchors Q[2,2] = (j_max · dt)².
    """

    _I3 = np.eye(3)

    def __init__(
        self,
        dt: float,
        sigma_gap: float    = _RADAR_SIGMA_GAP,
        sigma_rate: float   = _RADAR_SIGMA_RATE,
        sigma_bsm_a: float  = _EGO_ACCEL_NOISE_SIGMA,
        sigma_q_rate: float = 0.3,
        j_max: float        = 5.0,
    ) -> None:
        self._dt = dt

        # State transition F and ego-acceleration input vector B
        self._F = np.array([
            [1.0, dt,  0.5 * dt * dt],
            [0.0, 1.0, dt           ],
            [0.0, 0.0, 1.0          ],
        ])
        self._B = np.array([-0.5 * dt * dt, -dt, 0.0])   # (3,) vector

        # Observation matrices
        self._H_r = np.array([[1.0, 0.0, 0.0],
                               [0.0, 1.0, 0.0]])   # (2×3) radar
        self._h_b = np.array([0.0, 0.0, 1.0])      # (3,) BSM row vector

        # Observation noise covariances
        self._R_r: np.ndarray = np.diag([sigma_gap ** 2, sigma_rate ** 2])
        self._R_b: float      = sigma_bsm_a ** 2   # scalar — single obs

        # Process noise Q: diagonal, anchored to physics
        self._Q = np.diag([
            0.0,                        # gap: deterministic from gap_rate
            (sigma_q_rate * dt) ** 2,   # gap_rate: unmodeled disturbances
            (j_max * dt) ** 2,          # a_lead: jerk-bounded
        ])

        # State and covariance (None until seed() or first step() call)
        self.x: np.ndarray | None = None
        self.P: np.ndarray = np.diag([
            sigma_gap ** 2, sigma_rate ** 2, sigma_bsm_a ** 2
        ])

    def seed(self, gap: float, rate: float) -> None:
        """Seed initial state from true plant values before first step().

        gap and rate are exact (from plant, not sensor) so P uses sensor
        noise directly for these states.  a_lead is initialized to 0 with
        P[2,2]=0 so Q builds up uncertainty gradually, avoiding a large
        Kalman gain on the first (noisy) BSM packet.
        """
        self.x = np.array([float(gap), float(rate), 0.0])
        self.P = np.diag([
            self._R_r[0, 0],      # gap  — seeded from truth, R appropriate
            self._R_r[1, 1],      # rate — seeded from truth, R appropriate
            0.0,                  # accel — confident a_lead=0 at init; Q builds it up
        ])

    def step(
        self,
        gap_filtered: float,
        rate_filtered: float,
        lead_a_v2v: float,
        bsm_age_s: float = 0.0,
        a_ego: float = 0.0,
    ) -> tuple[float, float, float]:
        """
        Predict + update for one timestep.

        Returns
        -------
        (gap_fused, rate_fused, lead_a_radar) : tuple[float, float, float]
        """
        has_bsm = bsm_age_s < self._dt

        # Safety fallback — seed() was not called before first step()
        if self.x is None:
            self.x = np.array([float(gap_filtered), 0.0, 0.0])
            self.P = np.diag([
                self._R_r[0, 0],
                self._R_r[1, 1] * 10.0,   # unknown rate — inflate
                self._R_b * 10.0,          # unknown accel — inflate
            ])
            return float(self.x[0]), float(self.x[1]), float(self.x[2])

        # Predict
        self.x = self._F @ self.x + self._B * a_ego
        self.P = self._F @ self.P @ self._F.T + self._Q

        # Radar update (every step)
        z_r    = np.array([float(gap_filtered), float(rate_filtered)])
        S_r    = self._H_r @ self.P @ self._H_r.T + self._R_r
        K_r    = self.P @ self._H_r.T @ np.linalg.inv(S_r)
        self.x = self.x + K_r @ (z_r - self._H_r @ self.x)
        self.P = (self._I3 - K_r @ self._H_r) @ self.P

        # BSM update (fresh packet only — scalar form)
        if has_bsm:
            pht    = self.P @ self._h_b                        # (3,)
            s_b    = float(self._h_b @ pht) + self._R_b        # scalar
            K_b    = pht / s_b                                  # (3,)
            innov  = float(lead_a_v2v) - float(self._h_b @ self.x)
            self.x = self.x + K_b * innov
            self.P = (self._I3 - np.outer(K_b, self._h_b)) @ self.P

        return float(self.x[0]), float(self.x[1]), float(self.x[2])
