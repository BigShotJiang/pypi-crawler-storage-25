"""
Longitudinal control primitives — reusable by built-in and plugin DrivingModels.

CACCController : P+FF (predecessor-following topology)
PIController   : proportional-integral (placeholder for future ACCModel)
"""
from __future__ import annotations

import warnings


class CACCController:
    """
    CACC longitudinal controller: proportional feedback + V2V feedforward.

    Control law::

        e_gap = gap - (T_h * ego_speed + s0)          # gap error (m)
        a_cmd = k1 * e_gap
              + k2 * (lead_speed - ego_speed)
              + k_ff * lead_a_v2v

    The integral term is **deliberately omitted**:

    * ``k_ff`` provides disturbance rejection that an integrator would otherwise
      supply.  When feedforward is working, steady-state gap error is negligible.
    * An integrator accumulates error during V2V comms dropout and produces a
      jerk transient on re-engagement — unsafe and hard to explain to students.
    * Omitting the integral preserves the clean string-stability condition:
      the platoon is string-stable when ``k_ff + k2 * T_h >= 1``.

    This asymmetry with ACCModel (which uses a PI controller) is intentional and
    principled — see Section 6 of the design notes.

    Parameters
    ----------
    k1 : float
        Gap-error gain (m/s² per m).
    k2 : float
        Speed-error gain (m/s² per m/s).
    k_ff : float
        Feedforward gain on V2V acceleration (dimensionless; 1.0 = perfect).
    target_headway_s : float
        Desired time headway T_h (s).
    s0 : float
        Standstill gap (m).
    """

    def __init__(
        self,
        k1: float = 0.45,
        k2: float = 0.25,
        k_ff: float = 0.90,
        target_headway_s: float = 0.6,
        s0: float = 2.0,
    ) -> None:
        # k_ff=0.90 gives string stability margin at the default 0.6 s headway
        # (condition: k_ff + k2*T_h >= 1  →  0.90 + 0.25*0.6 = 1.05 > 1).
        # The PATH field-test value (k_ff=0.45) is marginally unstable at
        # this headway — set it deliberately to study instability, not as
        # a default.
        self.k1  = k1
        self.k2  = k2
        self.k_ff = k_ff
        self.T_h = target_headway_s
        self.s0  = s0
        self._check_string_stability()

    # ── String stability ───────────────────────────────────────────────────────

    def _check_string_stability(self) -> None:
        """Warn if the gains violate the string-stability condition."""
        # Condition: k_ff + k2 * T_h >= 1
        # Derived from the DC-gain requirement on the predecessor-following
        # transfer function (Seiler, Pant & Hedrick 2004; Milanes & Shladover 2014).
        margin = self.k_ff + self.k2 * self.T_h
        if margin < 1.0:
            required_k_ff = 1.0 - self.k2 * self.T_h
            warnings.warn(
                f"CACCController: gains are string-unstable "
                f"(k_ff={self.k_ff:.3f} < required {required_k_ff:.3f} "
                f"at T_h={self.T_h:.3f} s, k2={self.k2:.3f}). "
                f"Platoon spacing errors will amplify upstream.",
                stacklevel=3,
            )

    @property
    def string_stable(self) -> bool:
        """True when k_ff + k2 * T_h >= 1.0 (no disturbance amplification)."""
        return self.k_ff + self.k2 * self.T_h >= 1.0

    # ── Control law ───────────────────────────────────────────────────────────

    def compute(
        self,
        gap: float,
        ego_speed: float,
        lead_speed: float,
        lead_a_v2v: float,
    ) -> float:
        """
        Compute commanded acceleration (m/s²), *not* yet clipped by vehicle limits.

        Parameters
        ----------
        gap : float
            Bumper-to-bumper gap to the immediately preceding vehicle (m).
        ego_speed : float
            Ego vehicle speed (m/s).
        lead_speed : float
            Immediately preceding vehicle speed (m/s).
        lead_a_v2v : float
            Leader acceleration from BSM (m/s²); 0.0 when BSM unavailable.
        """
        e_gap = gap - (self.T_h * ego_speed + self.s0)
        return (
            self.k1 * e_gap
            + self.k2 * (lead_speed - ego_speed)
            + self.k_ff * lead_a_v2v
        )
