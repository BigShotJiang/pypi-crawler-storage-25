"""
CSVPlayback — replay a saved simulation CSV through the shared PygameRenderer.

Keyboard controls during playback:
    Space       Pause / resume
    → / ←       Step forward / backward one render frame (while paused)
    + / -       Increase / decrease playback speed (powers of two: 0.25–4×)
    R           Rewind to start
    Q / Escape  Quit
"""
from __future__ import annotations

import bisect
import math
import time

import pandas as pd

from cacc_sim.renderer import PygameRenderer, RenderFrame, VehicleRenderState


# Playback speed steps in powers of two
_SPEED_STEPS = [0.25, 0.5, 1.0, 2.0, 4.0]


class CSVPlayback:
    """
    Reads a simulation CSV (produced by SimulationLoop.run()) and replays it
    through the same PygameRenderer used for live runs.

    The CSV must contain columns: t, id, x, v, a, gap, model, vehicle_type, length.

    Parameters
    ----------
    df : pd.DataFrame
        Simulation output, already loaded.
    renderer : PygameRenderer
        Shared renderer instance.
    render_interval_s : float
        How often to draw a frame (matches config.render_interval_s).
        Rows between render frames are skipped.
    initial_speed : float
        Starting playback speed multiplier (default 1.0×).
    """

    def __init__(
        self,
        df: pd.DataFrame,
        renderer: PygameRenderer,
        render_interval_s: float = 0.1,
        initial_speed: float = 1.0,
    ) -> None:
        self._renderer   = renderer
        self._render_dt  = render_interval_s

        # Pre-compute render times: unique t values spaced >= render_interval_s apart
        all_times = sorted(df['t'].unique())
        self._render_times: list[float] = []
        last = -render_interval_s
        for t in all_times:
            if t - last >= render_interval_s - 1e-9:
                self._render_times.append(t)
                last = t

        # Full speed traces for the chart: {vehicle_id: [(t, v_mps), ...]}
        speed_traces: dict[int, list[tuple[float, float]]] = {
            int(vid): list(zip(grp['t'].tolist(), grp['v'].tolist()))
            for vid, grp in df.groupby('id')
        }
        v_max_display_kmh = math.ceil(df['v'].max() * 3.6 * 1.1 / 10) * 10
        t_max = float(df['t'].max())
        chart_full_range = (0.0, t_max)

        # Group rows by t for fast per-frame lookup; stamp each with chart data
        self._frames: dict[float, RenderFrame] = {}
        for t in self._render_times:
            group = df[df['t'] == t]
            frame = _frame_from_group(t, group)
            frame.speed_traces       = speed_traces
            frame.v_max_display_kmh  = v_max_display_kmh
            frame.chart_full_range   = chart_full_range
            frame.playback_cursor_t  = t
            self._frames[t] = frame

        self._speed_idx = _SPEED_STEPS.index(
            min(_SPEED_STEPS, key=lambda s: abs(s - initial_speed))
        )

    @classmethod
    def from_csv(
        cls,
        path: str,
        renderer: PygameRenderer,
        render_interval_s: float = 0.1,
        initial_speed: float = 1.0,
    ) -> 'CSVPlayback':
        """Convenience constructor: load CSV from path then build CSVPlayback."""
        return cls(pd.read_csv(path), renderer, render_interval_s, initial_speed)

    def run(self) -> None:
        """
        Play back the full recording.  Returns when playback finishes or the
        user presses Q / Escape / closes the window.
        """
        pg       = self._renderer._pygame
        times    = self._render_times
        n        = len(times)
        idx      = 0
        paused   = False
        running  = True

        wall_start    = time.perf_counter()
        playback_t0   = times[0] if times else 0.0  # sim time at play-start

        while running and idx < n:
            speed   = _SPEED_STEPS[self._speed_idx]
            paused, running, delta, rewind, seek_time = self._handle_playback_events(paused)

            if not running:
                break

            if rewind:
                idx          = 0
                playback_t0  = times[0]
                wall_start   = time.perf_counter()
                paused       = True

            if seek_time is not None:
                # Snap to the nearest render frame and pause
                idx        = max(0, min(n - 1, bisect.bisect_left(times, seek_time)))
                playback_t0 = times[0]
                wall_start  = time.perf_counter() - ((times[idx] - playback_t0) / speed)
                paused      = True

            if delta != 0 and paused:
                # Frame-step while paused
                idx = max(0, min(n - 1, idx + delta))
                frame = self._frames[times[idx]]
                self._renderer.draw(frame, paused=True, simulation_speed=speed)
                continue

            if paused:
                # Keep wall reference current so unpause has no debt
                elapsed_sim = times[idx] - playback_t0
                wall_start  = time.perf_counter() - (elapsed_sim / speed)
                frame = self._frames[times[idx]]
                self._renderer.draw(frame, paused=True, simulation_speed=speed)
                time.sleep(0.016)
                continue

            frame = self._frames[times[idx]]
            self._renderer.draw(frame, paused=False, simulation_speed=speed)

            # Pace: advance wall clock to match sim time
            elapsed_sim  = times[idx] - playback_t0
            wall_target  = elapsed_sim / speed
            wall_elapsed = time.perf_counter() - wall_start
            wait         = wall_target - wall_elapsed
            if wait > 0:
                time.sleep(wait)

            idx += 1

    # ── Private ────────────────────────────────────────────────────────────

    def _handle_playback_events(
        self, paused: bool
    ) -> tuple[bool, bool, int, bool, float | None]:
        """
        Process pygame events for playback mode.

        Returns (paused, running, frame_delta, rewind, seek_time).
        frame_delta is +1 or -1 when arrow keys are pressed while paused.
        rewind is True when R is pressed.
        seek_time is a sim time when the user clicks the speed chart, else None.
        """
        pg        = self._renderer._pygame
        delta     = 0
        rewind    = False
        seek_time = None
        for event in pg.event.get():
            if event.type == pg.QUIT:
                return paused, False, 0, False, None
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE:
                    paused = not paused
                elif event.key in (pg.K_q, pg.K_ESCAPE):
                    return paused, False, 0, False, None
                elif event.key == pg.K_RIGHT:
                    delta = +1
                elif event.key == pg.K_LEFT:
                    delta = -1
                elif event.key in (pg.K_PLUS, pg.K_EQUALS, pg.K_KP_PLUS):
                    self._speed_idx = min(self._speed_idx + 1, len(_SPEED_STEPS) - 1)
                elif event.key in (pg.K_MINUS, pg.K_KP_MINUS):
                    self._speed_idx = max(self._speed_idx - 1, 0)
                elif event.key == pg.K_r:
                    rewind = True
            if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                seek_time = self._renderer._chart_click_time(event.pos)
        return paused, True, delta, rewind, seek_time


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _frame_from_group(t: float, group: pd.DataFrame) -> RenderFrame:
    """Build a RenderFrame from one time-slice of the simulation DataFrame."""
    vehicles = []
    for _, row in group.iterrows():
        vt = row.get('vehicle_type')
        vehicles.append(VehicleRenderState(
            id           = int(row['id']),
            x            = float(row['x']),
            v            = float(row['v']),
            a            = float(row['a']),
            gap          = float(row['gap']),
            model        = str(row['model']),
            vehicle_type = str(vt) if pd.notnull(vt) else None,
            length       = float(row['length']),
        ))
    return RenderFrame(sim_time=t, vehicles=vehicles)
