"""
Built-in concrete DrivingModel implementations.
"""
from __future__ import annotations

import math

import numpy as np

from cacc_sim.controllers import CACCController
from cacc_sim.core import DelayBuffer, DrivingModel, DrivingModelOutput, VehicleState

# LeadVehicleProfile imported inside LeadVehicleModel to avoid circular imports
# at module level (profile.py has no cacc_sim imports; this is safe at call time).


# ---------------------------------------------------------------------------
# Shared IDM formula
# ---------------------------------------------------------------------------

def _idm_accel(
    speed: float,
    gap: float,
    lead_speed: float,
    v0: float,
    T: float,
    s0: float,
    a_max: float,
    b: float,
    delta: float,
    a_min: float,
) -> float:
    """Pure IDM formula. Returns clipped acceleration (m/s²)."""
    dv     = speed - lead_speed
    s      = max(gap, 0.1)
    s_star = s0 + speed * T + speed * dv / (2.0 * math.sqrt(a_max * b))
    a      = a_max * (1.0 - (speed / v0) ** delta - (s_star / s) ** 2)
    return float(np.clip(a, a_min, a_max))


class IDMModel(DrivingModel):
    """
    Intelligent Driver Model (Treiber, Hennecke & Helbing 2000).

    No reaction delay — models an ACC sensor replacing human perception.
    Reads: state.speed, state.gap, state.lead_speed.

    Parameters
    ----------
    desired_speed : float
        Free-flow target speed v0 (m/s).
    time_headway : float
        Desired time headway T (s).
    s0 : float
        Standstill gap (m).
    a_max : float
        Maximum acceleration (m/s²).
    b : float
        Comfortable deceleration (m/s²).
    delta : float
        Acceleration exponent (dimensionless; 4 is the IDM standard).
    a_min : float
        Hard output clip — minimum acceleration (m/s²).
    """

    def __init__(
        self,
        desired_speed: float,
        time_headway: float,
        s0: float = 2.0,
        a_max: float = 1.5,
        b: float = 2.0,
        delta: float = 4.0,
        a_min: float = -6.0,
    ):
        self.v0 = desired_speed
        self.T = time_headway
        self.s0 = s0
        self.a_max = a_max
        self.b = b
        self.delta = delta
        self.a_min = a_min

    @classmethod
    def required_inputs(cls) -> set[str]:
        return {'speed', 'gap', 'lead_speed'}

    @classmethod
    def from_excel_row(cls, row, sim_config) -> 'IDMModel':
        return cls(
            desired_speed=float(row['desired_speed_mps']),
            time_headway=float(row['time_headway_s']),
        )

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        return DrivingModelOutput(acceleration=_idm_accel(
            state.speed, state.gap, state.lead_speed,
            self.v0, self.T, self.s0, self.a_max, self.b, self.delta, self.a_min,
        ))


class IDMHumanModel(DrivingModel):
    """
    IDM with perceived-quantity reaction time delay. Represents a human driver.

    Only gap, lead_speed, and lead_acceleration are delayed — the driver's
    perception of the vehicle ahead.  Ego speed (known from proprioception /
    speedometer) is always current.

    On first call the delay buffer is seeded with the initial perceived
    quantities, so there is no startup transient.

    Parameters
    ----------
    desired_speed : float
        Free-flow target speed v0 (m/s).
    time_headway : float
        Desired time headway T (s).
    reaction_time : float
        Perception-reaction delay (s); default 0.8 s.
    s0 : float
        Standstill gap (m).
    a_max : float
        Maximum acceleration (m/s²).
    b : float
        Comfortable deceleration (m/s²).
    delta : float
        Acceleration exponent (dimensionless; 4 is the IDM standard).
    a_min : float
        Hard output clip — minimum acceleration (m/s²).
    dt : float
        Simulation timestep (s); used to size the delay buffer.
    """

    def __init__(
        self,
        desired_speed: float,
        time_headway: float,
        reaction_time: float = 0.8,
        s0: float = 2.0,
        a_max: float = 1.5,
        b: float = 2.0,
        delta: float = 4.0,
        a_min: float = -6.0,
        dt: float = 0.01,
    ):
        self.v0 = desired_speed
        self.T = time_headway
        self.s0 = s0
        self.a_max = a_max
        self.b = b
        self.delta = delta
        self.a_min = a_min
        self._delay = DelayBuffer(reaction_time, dt)
        self._seeded = False

    @classmethod
    def required_inputs(cls) -> set[str]:
        return {'speed', 'gap', 'lead_speed'}

    @classmethod
    def from_excel_row(cls, row, sim_config) -> 'IDMHumanModel':
        return cls(
            desired_speed=float(row['desired_speed_mps']),
            time_headway=float(row['time_headway_s']),
            reaction_time=float(row['reaction_time_s']),
            dt=sim_config.timestep_s,
        )

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        perceived = (state.gap, state.lead_speed, state.lead_a_radar)
        if not self._seeded:
            self._delay.fill(perceived)
            self._seeded = True
        gap, lead_speed, _ = self._delay.push_and_read(perceived)
        return DrivingModelOutput(acceleration=_idm_accel(
            state.speed, gap, lead_speed,
            self.v0, self.T, self.s0, self.a_max, self.b, self.delta, self.a_min,
        ))


class CACCModel(DrivingModel):
    """
    CACC driving model — predecessor-following topology, P+FF control law.

    Delegates to CACCController for the feedback + feedforward computation.
    A free-road saturation term (IDM-style) caps the output when the ego
    vehicle is far from the platoon, preventing runaway acceleration.

    When ``state.lead_a_v2v`` is 0.0 (BSM unavailable), the feedforward term
    drops out naturally, leaving pure gap/speed feedback.  No explicit fallback
    branch is needed.

    Parameters
    ----------
    desired_speed : float
        Free-flow target speed v0 (m/s).
    controller : CACCController
        Pre-configured P+FF controller instance.
    a_max : float
        Maximum output clip (m/s²).
    a_min : float
        Minimum output clip (m/s²).
    delta : float
        Free-road acceleration exponent (4 is the IDM standard).
    """

    def __init__(
        self,
        desired_speed: float,
        controller: CACCController,
        a_max: float = 2.5,
        a_min: float = -8.0,
        delta: float = 4.0,
    ) -> None:
        self.v0 = desired_speed
        self.controller = controller
        self.a_max = a_max
        self.a_min = a_min
        self.delta = delta

    @classmethod
    def required_inputs(cls) -> set[str]:
        return {'speed', 'gap', 'lead_speed', 'lead_a_v2v'}

    @classmethod
    def from_excel_row(cls, row, sim_config) -> 'CACCModel':
        controller = CACCController(
            k1               = sim_config.cacc_k1,
            k2               = sim_config.cacc_k2,
            k_ff             = sim_config.cacc_k_ff,
            target_headway_s = sim_config.cacc_target_headway_s,
            s0               = sim_config.cacc_s0_m,
        )
        return cls(
            desired_speed=float(row['desired_speed_mps']),
            controller=controller,
        )

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        # Free-road saturation: identical to IDM's first term.
        # Caps output when gap is huge (no vehicle ahead or far from platoon).
        speed_ratio = state.speed / self.v0 if self.v0 > 0.0 else 1.0
        a_free = self.a_max * (1.0 - speed_ratio ** self.delta)

        # lead_a_v2v = 0.0 when BSM unavailable — feedforward term naturally drops
        # out, leaving pure gap/speed feedback.  No None check needed.
        a_follow = self.controller.compute(
            state.gap,
            state.speed,
            state.lead_speed,
            state.lead_a_v2v,
        )
        a_cmd = min(a_free, a_follow)

        return DrivingModelOutput(
            acceleration=float(np.clip(a_cmd, self.a_min, self.a_max))
        )


class LeadVehicleModel(DrivingModel):
    """
    Follows a time-triggered speed profile via proportional speed control.

    Not a car-following model — the lead vehicle ignores any preceding vehicle
    and simply tracks the profile's target speed.  The kp gain determines how
    aggressively it chases the target; the output is clipped to realistic limits.

    Parameters
    ----------
    profile : LeadVehicleProfile
        The drive-cycle profile providing target speeds.
    kp : float
        Proportional gain on speed error (m/s² per m/s).
    a_max : float
        Maximum commanded acceleration (m/s²).
    a_min : float
        Minimum commanded acceleration (m/s²).
    """

    def __init__(self, profile, kp: float = 0.5,
                 a_max: float = 2.0, a_min: float = -4.0):
        self.profile = profile
        self.kp = kp
        self.a_max = a_max
        self.a_min = a_min

    @classmethod
    def required_inputs(cls) -> set[str]:
        return {'speed', 'time'}

    @classmethod
    def from_excel_row(cls, row, sim_config) -> 'LeadVehicleModel':
        # LeadVehicleModel requires a profile object that load_vehicles() supplies
        # separately from the row — it cannot be constructed from row/sim_config alone.
        raise NotImplementedError(
            "LeadVehicleModel requires a LeadVehicleProfile; use load_vehicles() "
            "or construct it directly with LeadVehicleModel(profile=...)."
        )

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        target = self.profile.get_speed_target(state.time)
        a = self.kp * (target - state.speed)
        return DrivingModelOutput(acceleration=float(np.clip(a, self.a_min, self.a_max)))
