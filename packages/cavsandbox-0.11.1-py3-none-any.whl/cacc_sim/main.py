"""Entry point: python -m cacc_sim.main <input.xlsx|results.csv> [--seed N]"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(
        prog='cavsandbox',
        description='CAVSandbox: longitudinal car-following simulation',
    )
    parser.add_argument(
        'input',
        help='Path to scenario Excel workbook (.xlsx) or results CSV for playback (.csv)',
    )
    parser.add_argument('--seed', type=int, help='Override random seed (simulation only)')
    args = parser.parse_args()

    suffix = Path(args.input).suffix.lower()

    if suffix == '.csv':
        try:
            from cacc_sim.playback import CSVPlayback
            from cacc_sim.renderer import PygameRenderer
            CSVPlayback.from_csv(args.input, PygameRenderer()).run()
        except Exception as exc:
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)

    elif suffix == '.xlsx':
        try:
            from cacc_sim.loader import load_vehicles
            from cacc_sim.output import save_run
            from cacc_sim.simulation import SimulationLoop

            vehicles, config = load_vehicles(args.input)

            if args.seed is not None:
                config.master_seed = args.seed

            loop = SimulationLoop(vehicles, config)

            if config.simulation_speed == 0:
                df = loop.run()
            else:
                from cacc_sim.renderer import PygameRenderer
                df = loop.run_live(PygameRenderer())

            results_dir = save_run(df, args.input, vehicles, config)
            print(f"Results saved to {results_dir}")

        except Exception as exc:
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)

    else:
        parser.error(f"unrecognised file type {suffix!r}: expected .xlsx (simulation) or .csv (playback)")


if __name__ == '__main__':
    main()
