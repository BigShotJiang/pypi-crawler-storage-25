"""
SimulationLoop — advances time and orchestrates all vehicles each timestep.
"""
from __future__ import annotations

import math
import sys
import time
from collections import deque

import pandas as pd

from cacc_sim.loader import SimConfig
from cacc_sim.road import Road
from cacc_sim.vehicle import Vehicle

# Width of the rolling speed-chart window (seconds).  Must match
# PygameRenderer.CHART_WINDOW_S so the deque maxlen is sized correctly.
_CHART_WINDOW_S: float = 30.0


class _CollisionError(Exception):
    """Raised when a vehicle's gap to its leader goes negative."""

    def __init__(self, follower_id: int, leader_id: int, t: float) -> None:
        self.follower_id = follower_id
        self.leader_id   = leader_id
        self.t           = t
        super().__init__(
            f'Collision at t={t:.3f}s: vehicle {follower_id} into vehicle {leader_id}'
        )


class SimulationLoop:
    """
    Main time-stepping loop.

    Processes vehicles in lead-to-back order each timestep so each follower
    sees the leader's already-updated position (front-to-back sequential
    update).  State is logged to a list of dicts and returned as a DataFrame
    at the end of run() or run_live().

    Parameters
    ----------
    vehicles : list[Vehicle]
        Ordered lead-to-back (as returned by load_vehicles()).
    config : SimConfig
        Global simulation parameters.
    road : Road or None
        Road geometry and leader-resolution authority.  If None, a
        single-lane road of config.road_length_m is created automatically.
    """

    def __init__(
        self,
        vehicles: list[Vehicle],
        config: SimConfig,
        road: Road | None = None,
    ):
        self.vehicles = vehicles
        self.config = config
        self._vehicle_map: dict[int, Vehicle] = {v.id: v for v in vehicles}
        self._road = road if road is not None else Road.single_lane(config.road_length_m)
        self.log: list[dict] = []
        # Decimation: log every N-th sim step so CSV rate matches log_rate_hz.
        self._log_interval: int = max(1, round(1.0 / (config.log_rate_hz * config.timestep_s)))
        self._step_idx: int = 0
        # Rolling speed buffer for live chart — separate from full log.
        _buf_len = round(_CHART_WINDOW_S / config.timestep_s)
        self._speed_buf: dict[int, deque] = {
            v.id: deque(maxlen=_buf_len) for v in vehicles
        }
        self._v_max_display_kmh: float = self._compute_v_max(vehicles)
        self._seed_filters()

    def run(self) -> pd.DataFrame:
        """
        Run the full simulation headless (no renderer).

        Returns
        -------
        pd.DataFrame
            One row per vehicle per timestep with columns:
            t, id, x, v, a, gap, model, vehicle_type, length.
            Partial if a collision is detected; collision row is included.
        """
        dt = self.config.timestep_s
        n_steps = round(self.config.duration_s / dt)
        t = 0.0
        try:
            for _ in range(n_steps):
                self._step(t)
                t += dt
        except _CollisionError as exc:
            print(
                f'\nWARNING: {exc}  — simulation stopped early.\n',
                file=sys.stderr,
            )
        return pd.DataFrame(self.log)

    def run_live(self, renderer: object) -> pd.DataFrame:
        """
        Run the simulation with a live Pygame renderer.

        Handles the render/pace/event loop.  The sim advances at
        config.simulation_speed × real time; spacebar pauses; Q/Escape quits
        early.  Wall-clock reference is reset each frame while paused so
        unpausing never triggers catch-up.

        Parameters
        ----------
        renderer : PygameRenderer
            Must implement handle_events(paused) → (paused, running)
            and draw(frame, paused, simulation_speed).

        Returns
        -------
        pd.DataFrame
            Same schema as run().  May be incomplete if the user quits early.
        """
        dt        = self.config.timestep_s
        render_dt = self.config.render_interval_s
        speed     = self.config.simulation_speed
        n_steps   = round(self.config.duration_s / dt)

        t            = 0.0
        last_render_t = -render_dt      # force first render immediately
        wall_start   = time.perf_counter()
        paused       = False
        running      = True
        last_frame   = self._make_frame(t)

        step = 0
        try:
            while step < n_steps and running:
                paused, running, _ = renderer.handle_events(paused)

                if paused:
                    # Keep wall_start current so unpause has no catch-up debt.
                    if speed > 0:
                        wall_start = time.perf_counter() - (t / speed)
                    renderer.draw(last_frame, paused=True, simulation_speed=speed)
                    time.sleep(0.016)       # ~60 Hz idle while paused
                    continue

                self._step(t)
                t += dt
                step += 1

                if t - last_render_t >= render_dt:
                    last_frame = self._make_frame(t)
                    renderer.draw(last_frame, paused=False, simulation_speed=speed)
                    last_render_t = t

                    if speed > 0:
                        wall_elapsed = time.perf_counter() - wall_start
                        sim_ahead    = (t / speed) - wall_elapsed
                        if sim_ahead > 0:
                            time.sleep(sim_ahead)

        except _CollisionError as exc:
            print(
                f'\nWARNING: {exc}  — simulation stopped early.\n',
                file=sys.stderr,
            )
            collision_msg = (
                f'COLLISION DETECTED\n'
                f'Vehicle {exc.follower_id} → Vehicle {exc.leader_id}\n'
                f't = {exc.t:.3f} s'
            )
            collision_frame = self._make_frame(exc.t)
            # Frozen event loop: show overlay until user quits.
            while True:
                _, still_open, _ = renderer.handle_events(paused=False)
                if not still_open:
                    break
                renderer.draw(
                    collision_frame,
                    paused=False,
                    simulation_speed=speed,
                    collision_message=collision_msg,
                )
                time.sleep(0.016)

        return pd.DataFrame(self.log)

    # ── Internal helpers ───────────────────────────────────────────────────

    def _step(self, t: float) -> None:
        """Advance all vehicles by one timestep at simulation time t."""
        should_log = self._step_idx % self._log_interval == 0
        for vehicle in self.vehicles:
            leader = self._road.get_leader(vehicle, self._vehicle_map)
            record = vehicle.step(t, leader)
            is_collision = record['gap'] is not None and record['gap'] < 0
            if should_log or is_collision:
                self.log.append(record)
            self._speed_buf[vehicle.id].append((t, vehicle.plant.v))
            if is_collision:
                self._step_idx += 1
                raise _CollisionError(vehicle.id, vehicle.leader_id, t)
        self._step_idx += 1

    def _make_frame(self, t: float) -> object:
        """Build a RenderFrame from current vehicle plant state."""
        from cacc_sim.renderer import RenderFrame, VehicleRenderState
        return RenderFrame(
            sim_time=t,
            vehicles=[
                VehicleRenderState(
                    id           = v.id,
                    x            = v.plant.x,
                    v            = v.plant.v,
                    a            = v.plant.a,
                    gap          = (
                        v.plant.gap_to(self._vehicle_map[v.leader_id].plant)
                        if v.leader_id is not None else 9999.0
                    ),
                    model        = type(v.model).__name__,
                    vehicle_type = v.vehicle_type,
                    length       = v.plant.length,
                )
                for v in self.vehicles
            ],
            speed_traces=self._speed_buf,
            v_max_display_kmh=self._v_max_display_kmh,
        )

    def _seed_filters(self) -> None:
        """Seed FusionKalmanFilter initial state from exact plant values."""
        for vehicle in self.vehicles:
            if vehicle.fusion is None:
                continue
            leader = self._road.get_leader(vehicle, self._vehicle_map)
            if leader is not None:
                initial_gap  = leader.plant.x - vehicle.plant.x - leader.plant.length
                initial_rate = leader.plant.v - vehicle.plant.v
                vehicle.fusion.seed(initial_gap, initial_rate)

    def _compute_v_max(self, vehicles: list[Vehicle]) -> float:
        """Fixed y-axis ceiling for the speed chart.

        Considers three speed sources per vehicle:
          - initial plant speed (all vehicles)
          - desired_speed attribute (IDM/CACC models)
          - profile peak speed (LeadVehicleModel)
        Then adds 25% headroom and rounds up to the nearest 10 km/h.
        """
        speeds = [v.plant.v for v in vehicles]
        for v in vehicles:
            if hasattr(v.model, 'desired_speed'):
                speeds.append(v.model.desired_speed)
            if hasattr(v.model, 'profile'):
                speeds.append(float(v.model.profile._events['value'].max()))
        return math.ceil(max(speeds) * 3.6 * 1.1 / 10) * 10
