"""
Reproducible random number generation for stochastic simulation components.

A single master_seed derives independent random.Random instances for each
process, so adding or removing a process does not affect any other process's
sequence.  Per-vehicle processes use the vehicle_id as an additional input
so fleet size changes are also isolated.
"""
from __future__ import annotations

import random


# XOR offsets for per-simulation processes (master-seed level)
_SIM_OFFSETS: dict[str, int] = {
    'comms_drop': 0x9ABC,
}

# XOR offsets for per-vehicle processes (vehicle-id level)
_VEH_OFFSETS: dict[str, int] = {
    'sensor_noise': 0x1000,
    'ego_noise':    0x2000,
    'wiedemann':    0x3000,
    'idm_human':    0x4000,
    'bsm_comms':    0x5000,   # DSRC packet-drop decisions
    'bsm_phase':    0x6000,   # initial BSM broadcast phase offset
}


def vehicle_rng(master_seed: int, vehicle_id: int, process: str) -> random.Random:
    """
    Derive an independent random.Random for one vehicle and process.

    The seed is derived as::

        seed = master_seed XOR (vehicle_id * 0x100) XOR process_offset

    This guarantees that:
    - Different vehicles get different seeds for the same process.
    - Different processes on the same vehicle get different seeds.
    - Adding or removing a vehicle changes no other vehicle's sequence.

    Parameters
    ----------
    master_seed : int
        Global seed from SimConfig.  0 uses a fixed deterministic seed.
    vehicle_id : int
        The vehicle's integer id.
    process : str
        One of 'sensor_noise', 'ego_noise', 'wiedemann', 'idm_human',
        'bsm_comms', 'bsm_phase'.
    """
    if process not in _VEH_OFFSETS:
        raise ValueError(
            f"Unknown per-vehicle process {process!r}. "
            f"Valid: {sorted(_VEH_OFFSETS)}"
        )
    seed = master_seed ^ (vehicle_id * 0x100) ^ _VEH_OFFSETS[process]
    return random.Random(seed)
