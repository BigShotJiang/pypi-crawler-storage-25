"""
Built-in Filter implementations.
"""
from __future__ import annotations

from cacc_sim.core import Filter, FilterInput, FilterOutput


class PassthroughFilter(Filter):
    """
    Perfect filter — passes raw value through unchanged.

    Used as the initial implementation while sensor noise modelling is out of
    scope (Step 14 of the development sequence).  Has the same ABC interface
    as future real filters so the simulation loop and vehicle code never need
    to know which is installed.
    """

    def update(self, input: FilterInput) -> FilterOutput:
        return FilterOutput(filtered_value=input.raw_value, confidence=1.0)
