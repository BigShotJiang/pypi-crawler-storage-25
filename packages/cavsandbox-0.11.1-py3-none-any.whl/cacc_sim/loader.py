"""
Excel input loader: SimConfig, validation, and vehicle instantiation.
"""
from __future__ import annotations

import importlib.util
import inspect
import math
import pathlib
import sys
import warnings
from dataclasses import dataclass
from typing import Any

import pandas as pd

from cacc_sim.core import DrivingModel, Filter
from cacc_sim.driving_models import CACCModel, IDMHumanModel, IDMModel, LeadVehicleModel
from cacc_sim.filters import PassthroughFilter
from cacc_sim.plant import VehiclePlant, VehicleResponseModel
from cacc_sim.profile import LeadVehicleProfile
from cacc_sim.rng import vehicle_rng
from cacc_sim.vehicle import Vehicle

# ---------------------------------------------------------------------------
# Registries
# ---------------------------------------------------------------------------

MODEL_REGISTRY: dict[str, type] = {
    'IDMModel':      IDMModel,
    'IDMHumanModel': IDMHumanModel,
    'CACCModel':     CACCModel,
    'LEAD_PROFILE':  LeadVehicleModel,
}

FILTER_REGISTRY: dict[str, type] = {
    'passthrough': PassthroughFilter,
}


# ---------------------------------------------------------------------------
# Plugin loader
# ---------------------------------------------------------------------------

def load_plugins(plugin_dir: str = 'plugins') -> None:
    """
    Scan *plugin_dir* for DrivingModel and Filter subclasses; register them.

    Safe to call multiple times — re-registering the same class under the same
    name is a silent no-op.  A name collision between a plugin and an already-
    registered class (built-in or different plugin) raises a warning and the
    existing entry is preserved.

    Parameters
    ----------
    plugin_dir : str
        Path to the plugins folder, relative to the current working directory.
        Defaults to ``'plugins'``.  Missing directory is a no-op.
    """
    plugin_path = pathlib.Path(plugin_dir)
    if not plugin_path.exists():
        return

    for path in sorted(plugin_path.glob('*.py')):
        module_key = f'_cacc_plugin_{path.stem}'
        if module_key in sys.modules:
            module = sys.modules[module_key]
        else:
            spec   = importlib.util.spec_from_file_location(module_key, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_key] = module
            spec.loader.exec_module(module)

        for name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, DrivingModel) and obj is not DrivingModel:
                if name in MODEL_REGISTRY:
                    if MODEL_REGISTRY[name] is not obj:
                        warnings.warn(
                            f"Plugin class '{name}' in {path.name} collides with an "
                            f"existing registry entry. Existing entry kept; rename the "
                            f"plugin class to register it.",
                            stacklevel=2,
                        )
                else:
                    MODEL_REGISTRY[name] = obj

            if issubclass(obj, Filter) and obj is not Filter:
                if name in FILTER_REGISTRY:
                    if FILTER_REGISTRY[name] is not obj:
                        warnings.warn(
                            f"Plugin filter '{name}' in {path.name} collides with an "
                            f"existing registry entry. Existing entry kept.",
                            stacklevel=2,
                        )
                else:
                    FILTER_REGISTRY[name] = obj

# Excel column names required by each model (beyond the universal required set)
_MODEL_REQUIRED_COLUMNS: dict[str, list[str]] = {
    'IDMModel':        ['desired_speed_mps', 'time_headway_s'],
    'IDMHumanModel':   ['desired_speed_mps', 'time_headway_s', 'reaction_time_s'],
    'CACCModel':       ['desired_speed_mps'],
    'Wiedemann99Model':['desired_speed_mps'],
    'LEAD_PROFILE':    [],
}

# Hardcoded level-4 defaults for the five response parameters
_RESPONSE_DEFAULTS: dict[str, float] = {
    'tau_throttle_s': 0.5,
    'tau_brake_s':    0.3,
    'a_max_mps2':     2.5,
    'a_min_mps2':    -8.0,
    'j_max_mps3':     5.0,
}


# ---------------------------------------------------------------------------
# SimConfig
# ---------------------------------------------------------------------------

@dataclass
class SimConfig:
    """
    Global simulation parameters read from the simulation sheet.

    Attribute names match the Excel column names exactly so that
    resolve_param() can use getattr() for level-3 lookup.
    """
    timestep_s:             float = 0.01
    duration_s:             float = 100.0
    road_length_m:          float = 1000.0
    render_interval_s:      float = 0.1
    simulation_speed:       float = 1.0
    sensor_model:           str   = 'passthrough'
    comms_model:            str   = 'passthrough'
    response_model:         str   = 'lag'
    cacc_target_headway_s:  float = 0.6
    # CACC controller gains — system-level, not per-vehicle
    cacc_k1:                float = 0.45  # gap-error gain (m/s² per m)
    cacc_k2:                float = 0.25  # speed-error gain (m/s² per m/s)
    cacc_k_ff:              float = 0.90  # feedforward gain; PATH value 0.45 is string-unstable at default headway
    cacc_s0_m:              float = 2.0   # standstill gap (m)
    # Random seed for stochastic components (0 = fixed deterministic default)
    master_seed:            int   = 0
    # CSV logging decimation: 10 Hz keeps every 10th sim step (sim runs at 100 Hz)
    log_rate_hz:            float = 10.0
    # DSRC/C-V2X comms parameters (active when comms_model = 'v2v')
    bsm_rate_hz:            float = 10.0   # BSM broadcast rate (Hz)
    bsm_packet_drop_rate:   float = 0.02   # 0.05 causes frequent stale events at 10 Hz; 0.02 is realistic for favorable DSRC conditions
    bsm_max_age_s:          float = 0.30   # one missed packet = 0.10s; 0.30s tolerates two consecutive drops before declaring stale
    sigma_q_rate:           float = 0.3    # KF process noise on gap-rate state (m/s²·√s)
    # Level-3 defaults for response parameters (overridden per vehicle_type or per vehicle)
    a_max_mps2:             float = 2.5
    a_min_mps2:             float = -8.0
    j_max_mps3:             float = 5.0
    tau_throttle_s:         float = 0.5
    tau_brake_s:            float = 0.3


# ---------------------------------------------------------------------------
# Four-level parameter resolution
# ---------------------------------------------------------------------------

def resolve_param(
    param: str,
    row: pd.Series,
    type_row: pd.Series | None,
    sim_config: SimConfig,
) -> float:
    """
    Resolve a vehicle response parameter using the four-level hierarchy:

    1. Per-vehicle override column in the vehicles sheet (non-blank wins)
    2. vehicle_types sheet lookup via the vehicle_type column
    3. Simulation sheet global (SimConfig attribute of the same name)
    4. Hardcoded default in _RESPONSE_DEFAULTS

    Parameters
    ----------
    param : str
        Column / attribute name, e.g. 'tau_throttle_s'.
    row : pd.Series
        One row from the vehicles DataFrame.
    type_row : pd.Series or None
        Matching row from the vehicle_types table, or None if not applicable.
    sim_config : SimConfig
        Loaded simulation sheet values.
    """
    val = row.get(param)
    if val is not None and pd.notnull(val):
        return float(val)                                    # level 1

    if type_row is not None:
        tval = type_row.get(param)
        if tval is not None and pd.notnull(tval):
            return float(tval)                               # level 2

    if hasattr(sim_config, param):
        return float(getattr(sim_config, param))             # level 3

    return float(_RESPONSE_DEFAULTS[param])                  # level 4


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_vehicle_df(
    df: pd.DataFrame,
    type_table: pd.DataFrame | None = None,
) -> None:
    """
    Validate the vehicles DataFrame.  Raises ValueError listing all problems
    found.  Warnings are issued for non-fatal issues (empty rows).

    Parameters
    ----------
    df : pd.DataFrame
        The vehicles sheet, already loaded.
    type_table : pd.DataFrame or None
        The vehicle_types sheet indexed by type_id, or None if absent.
    """
    errors: list[str] = []

    # ── Category 1: required columns ────────────────────────────────────────
    required_cols = {
        'vehicle_id', 'model', 'initial_position_m',
        'initial_speed_mps', 'vehicle_length_m', 'leader_id', 'filter',
    }
    missing_cols = required_cols - set(df.columns)
    if missing_cols:
        raise ValueError(f"Missing required columns: {sorted(missing_cols)}")

    # ── Category 2: drop/warn on fully empty rows ────────────────────────────
    empty_mask = df.isnull().all(axis=1)
    if empty_mask.any():
        warnings.warn(f"Dropping {empty_mask.sum()} fully empty row(s) from vehicles sheet.")
        df = df[~empty_mask].reset_index(drop=True)

    # ── Category 3: vehicle_id — unique integers ────────────────────────────
    if df['vehicle_id'].duplicated().any():
        dups = df.loc[df['vehicle_id'].duplicated(keep=False), 'vehicle_id'].tolist()
        errors.append(f"Duplicate vehicle_id values: {dups}")

    # ── Category 4: model names in registry ─────────────────────────────────
    unknown_models = [
        m for m in df['model'].dropna()
        if m not in MODEL_REGISTRY and m not in _MODEL_REQUIRED_COLUMNS
    ]
    if unknown_models:
        errors.append(f"Unknown model name(s): {sorted(set(unknown_models))}")

    # ── Category 5: filter names in registry ────────────────────────────────
    unknown_filters = [
        f for f in df['filter'].dropna()
        if f not in FILTER_REGISTRY
    ]
    if unknown_filters:
        errors.append(f"Unknown filter name(s): {sorted(set(unknown_filters))}")

    # Raise now so topology checks have clean data
    if errors:
        raise ValueError('\n'.join(errors))

    # ── Category 6: model-conditional required columns ───────────────────────
    for _, row in df.iterrows():
        model_name = str(row['model'])
        required_for_model = _MODEL_REQUIRED_COLUMNS.get(model_name, [])
        for col in required_for_model:
            if col not in df.columns or pd.isnull(row.get(col)):
                errors.append(
                    f"Vehicle {row['vehicle_id']}: model '{model_name}' "
                    f"requires column '{col}' to be non-blank."
                )

    # ── Category 7: range checks ─────────────────────────────────────────────
    for _, row in df.iterrows():
        vid = row['vehicle_id']
        if pd.notnull(row['initial_position_m']) and row['initial_position_m'] < 0:
            errors.append(f"Vehicle {vid}: initial_position_m must be ≥ 0.")
        if pd.notnull(row['initial_speed_mps']) and row['initial_speed_mps'] < 0:
            errors.append(f"Vehicle {vid}: initial_speed_mps must be ≥ 0.")
        if pd.notnull(row['vehicle_length_m']) and row['vehicle_length_m'] <= 0:
            errors.append(f"Vehicle {vid}: vehicle_length_m must be > 0.")
        # Per-vehicle response overrides
        for param, (lo, hi, rule) in {
            'a_max_mps2': (0, None,  '> 0'),
            'a_min_mps2': (None, 0,  '< 0'),
            'j_max_mps3': (0, None,  '> 0'),
            'tau_throttle_s': (0, None, '> 0'),
            'tau_brake_s':    (0, None, '> 0'),
        }.items():
            val = row.get(param)
            if val is not None and pd.notnull(val):
                if lo is not None and float(val) <= lo:
                    errors.append(f"Vehicle {vid}: {param} must be {rule}, got {val}.")
                if hi is not None and float(val) >= hi:
                    errors.append(f"Vehicle {vid}: {param} must be {rule}, got {val}.")

    if errors:
        raise ValueError('\n'.join(errors))

    # ── Category 8: leader_id topology ──────────────────────────────────────
    valid_ids = set(df['vehicle_id'].tolist())
    blank_mask = df['leader_id'].isnull()
    n_blank = blank_mask.sum()

    if n_blank == 0:
        errors.append("No lead vehicle found: exactly one row must have a blank leader_id.")
    elif n_blank > 1:
        errors.append(
            f"{n_blank} rows have blank leader_id — exactly one is required "
            f"(vehicle_ids: {df.loc[blank_mask, 'vehicle_id'].tolist()})."
        )

    # Invalid references
    for _, row in df[~blank_mask].iterrows():
        lid = row['leader_id']
        if pd.notnull(lid) and int(lid) not in valid_ids:
            errors.append(
                f"Vehicle {row['vehicle_id']}: leader_id {int(lid)} "
                f"does not reference a valid vehicle_id."
            )

    if errors:
        raise ValueError('\n'.join(errors))

    # ── Category 9: lead vehicle must use LEAD_PROFILE ───────────────────────
    lead_rows = df[blank_mask]
    for _, row in lead_rows.iterrows():
        if row['model'] != 'LEAD_PROFILE':
            errors.append(
                f"Vehicle {row['vehicle_id']} has blank leader_id (lead vehicle) "
                f"but model='{row['model']}' — lead vehicle must use LEAD_PROFILE."
            )

    # ── Category 10: circular leader_id chains ───────────────────────────────
    id_to_leader: dict[int, int | None] = {}
    for _, row in df.iterrows():
        lid = row['leader_id']
        id_to_leader[int(row['vehicle_id'])] = int(lid) if pd.notnull(lid) else None

    circular = _find_circular_chains(id_to_leader)
    if circular:
        errors.append(f"Circular leader_id chain detected involving vehicle(s): {circular}")

    if errors:
        raise ValueError('\n'.join(errors))

    # ── Category 11: vehicle_types checks ────────────────────────────────────
    if type_table is not None:
        _validate_type_table(type_table, errors)

    # vehicle_type references must resolve
    if 'vehicle_type' in df.columns and type_table is not None:
        for _, row in df.iterrows():
            vt = row.get('vehicle_type')
            if vt is not None and pd.notnull(vt) and str(vt) not in type_table.index:
                errors.append(
                    f"Vehicle {row['vehicle_id']}: vehicle_type '{vt}' "
                    f"not found in vehicle_types sheet."
                )
    elif 'vehicle_type' in df.columns:
        non_blank = df['vehicle_type'].dropna()
        if len(non_blank) > 0:
            errors.append(
                "vehicle_type column is non-blank for some vehicles but "
                "vehicle_types sheet is absent."
            )

    # ── Category 12: position overlap errors ────────────────────────────────
    positions = df[['vehicle_id', 'initial_position_m', 'vehicle_length_m']].copy()
    positions = positions.sort_values('initial_position_m', ascending=False)
    prev_rear: float | None = None
    prev_vid:  int  | None = None
    for _, row in positions.iterrows():
        vid   = int(row['vehicle_id'])
        front = float(row['initial_position_m'])
        rear  = front - float(row['vehicle_length_m'])
        if prev_rear is not None and front > prev_rear:
            errors.append(
                f"[vehicles sheet] Vehicle {vid} initial position overlaps with the vehicle "
                f"ahead: vehicle {vid} front bumper is at {front:.2f} m but vehicle {prev_vid} "
                f"rear bumper is at {prev_rear:.2f} m. Increase initial_position_m for vehicle "
                f"{prev_vid} or decrease it for vehicle {vid} so that gap = "
                f"{prev_rear:.2f} - {front:.2f} = {prev_rear - front:.2f} m is positive."
            )
        prev_rear = rear
        prev_vid  = vid

    if errors:
        raise ValueError('\n'.join(errors))


def _find_circular_chains(id_to_leader: dict[int, int | None]) -> list[int]:
    """Return vehicle_ids involved in circular leader_id chains."""
    circular: list[int] = []
    for start_id in id_to_leader:
        if id_to_leader[start_id] is None:
            continue
        visited: set[int] = {start_id}
        current: int | None = id_to_leader[start_id]
        while current is not None:
            if current not in id_to_leader:
                break
            if current in visited:
                if current not in circular:
                    circular.append(current)
                break
            visited.add(current)
            current = id_to_leader[current]
    return circular


def _validate_type_table(type_table: pd.DataFrame, errors: list[str]) -> None:
    """Validate the vehicle_types table (indexed by type_id)."""
    numeric_cols = ['tau_throttle_s', 'tau_brake_s', 'a_max_mps2', 'a_min_mps2', 'j_max_mps3']
    for col in numeric_cols:
        if col not in type_table.columns:
            errors.append(f"vehicle_types sheet missing column '{col}'.")
            continue
        if type_table[col].isnull().any():
            bad = type_table.index[type_table[col].isnull()].tolist()
            errors.append(f"vehicle_types: '{col}' is blank for type_id(s): {bad}.")
    if 'a_max_mps2' in type_table.columns:
        bad = type_table[type_table['a_max_mps2'] <= 0].index.tolist()
        if bad:
            errors.append(f"vehicle_types: a_max_mps2 must be > 0 for type_id(s): {bad}.")
    if 'a_min_mps2' in type_table.columns:
        bad = type_table[type_table['a_min_mps2'] >= 0].index.tolist()
        if bad:
            errors.append(f"vehicle_types: a_min_mps2 must be < 0 for type_id(s): {bad}.")


# ---------------------------------------------------------------------------
# Sim config loader
# ---------------------------------------------------------------------------

def _resolve_simulation_speed(raw: dict) -> float:
    """Return simulation_speed from the raw simulation sheet dict, defaulting to 1.0."""
    if 'simulation_speed' in raw:
        return float(raw['simulation_speed'])
    return 1.0


def load_sim_config(xl: pd.ExcelFile) -> SimConfig:
    """
    Read the simulation sheet into a SimConfig.  Unknown keys are ignored.
    Missing keys fall back to SimConfig defaults.
    """
    df = xl.parse('simulation', header=None, index_col=0)
    raw: dict[str, Any] = df[1].to_dict()

    def get(key: str, default: Any) -> Any:
        return raw.get(key, default)

    return SimConfig(
        duration_s            = float(get('duration_s',            100.0)),
        road_length_m         = float(get('road_length_m',         1000.0)),
        render_interval_s     = float(get('render_interval_s',     0.1)),
        simulation_speed      = float(_resolve_simulation_speed(raw)),
        sensor_model          = str(get('sensor_model',            'passthrough')),
        comms_model           = str(get('comms_model',             'passthrough')),
        response_model        = str(get('response_model',          'lag')),
        cacc_target_headway_s = float(get('cacc_target_headway_s', 0.6)),
        cacc_k1               = float(get('cacc_k1',               0.45)),
        cacc_k2               = float(get('cacc_k2',               0.25)),
        cacc_k_ff             = float(get('cacc_k_ff',             0.90)),
        cacc_s0_m             = float(get('cacc_s0_m',             2.0)),
        master_seed           = int(get('master_seed',             0)),
        log_rate_hz           = float(get('log_rate_hz',           10.0)),
        bsm_rate_hz           = float(get('bsm_rate_hz',           10.0)),
        bsm_packet_drop_rate  = float(get('bsm_packet_drop_rate',  0.02)),
        bsm_max_age_s         = float(get('bsm_max_age_s',         0.30)),
        sigma_q_rate          = float(get('sigma_q_rate',           0.3)),
        a_max_mps2            = float(get('a_max_mps2',            2.5)),
        a_min_mps2            = float(get('a_min_mps2',           -8.0)),
        j_max_mps3            = float(get('j_max_mps3',            5.0)),
        tau_throttle_s        = float(get('tau_throttle_s',        0.5)),
        tau_brake_s           = float(get('tau_brake_s',           0.3)),
    )


# ---------------------------------------------------------------------------
# Main loader
# ---------------------------------------------------------------------------

def _build_sensor(sim_config: SimConfig, rng):
    """Instantiate RadarSensor for the given filter_type, or None for passthrough."""
    from cacc_sim.sensors import RadarSensor
    ft = sim_config.sensor_model   # 'kalman' or 'lpf'
    return RadarSensor(rng=rng, dt=sim_config.timestep_s, filter_type=ft)


def _build_ego_sensor(row: pd.Series, rng, dt: float):
    """
    Always returns NoisyEgoSensor (called only when sensor_model != 'passthrough').
    Per-vehicle columns ego_speed_sigma and ego_accel_bias_drift override the
    module-level defaults; blank or zero falls back to those defaults so that
    sensor_model='kalman'/'lpf' with no ego columns produces realistic noise.
    """
    from cacc_sim.sensors import (
        NoisyEgoSensor,
        _EGO_SPEED_SIGMA,
        _EGO_ACCEL_BIAS_DRIFT,
    )
    raw_sigma = row.get('ego_speed_sigma')
    raw_drift = row.get('ego_accel_bias_drift')
    sigma = (float(raw_sigma)
             if raw_sigma is not None and pd.notnull(raw_sigma) and float(raw_sigma) > 0
             else _EGO_SPEED_SIGMA)
    drift = (float(raw_drift)
             if raw_drift is not None and pd.notnull(raw_drift) and float(raw_drift) > 0
             else _EGO_ACCEL_BIAS_DRIFT)
    return NoisyEgoSensor(rng=rng, speed_sigma=sigma, accel_bias_drift=drift, dt=dt)


def _build_bsm_tracker(sim_config: 'SimConfig', rng, phase_rng):
    """Instantiate DSRCBSMTracker for comms_model='v2v', else PassthroughBSMTracker."""
    if sim_config.comms_model == 'v2v':
        from cacc_sim.sensors import DSRCBSMTracker
        return DSRCBSMTracker(
            rng=rng,
            phase_rng=phase_rng,
            dt=sim_config.timestep_s,
            bsm_rate_hz=sim_config.bsm_rate_hz,
            packet_drop_rate=sim_config.bsm_packet_drop_rate,
            max_age_s=sim_config.bsm_max_age_s,
        )
    from cacc_sim.sensors import PassthroughBSMTracker
    return PassthroughBSMTracker()


def _build_fusion(sim_config: 'SimConfig', ego_sensor):
    """
    Instantiate FusionKalmanFilter for comms_model='v2v', else Passthrough.

    R_bsm is derived from the ego sensor's noise parameters to keep the
    fusion KF internally consistent with the sensor model:
        sigma_bsm_a² = accel_noise_sigma² + accel_bias_drift² * dt * bsm_interval_s
    """
    if sim_config.comms_model != 'v2v':
        from cacc_sim.sensors import PassthroughFusionEstimator
        return PassthroughFusionEstimator()

    from cacc_sim.sensors import (
        _EGO_ACCEL_BIAS_DRIFT,
        _EGO_ACCEL_NOISE_SIGMA,
        _RADAR_SIGMA_GAP,
        _RADAR_SIGMA_RATE,
        FusionKalmanFilter,
        NoisyEgoSensor,
    )
    if isinstance(ego_sensor, NoisyEgoSensor):
        accel_noise_sigma = ego_sensor.accel_noise_sigma
        accel_bias_drift  = ego_sensor.accel_bias_drift
    else:
        accel_noise_sigma = _EGO_ACCEL_NOISE_SIGMA
        accel_bias_drift  = _EGO_ACCEL_BIAS_DRIFT

    bsm_interval_s = 1.0 / sim_config.bsm_rate_hz
    inflation  = accel_bias_drift ** 2 * sim_config.timestep_s * bsm_interval_s
    sigma_bsm_a = math.sqrt(accel_noise_sigma ** 2 + inflation)

    return FusionKalmanFilter(
        dt=sim_config.timestep_s,
        sigma_gap=_RADAR_SIGMA_GAP,
        sigma_rate=_RADAR_SIGMA_RATE,
        sigma_bsm_a=sigma_bsm_a,
        sigma_q_rate=sim_config.sigma_q_rate,
        j_max=sim_config.j_max_mps3,
    )


def _topological_order(vehicles: list[Vehicle]) -> list[Vehicle]:
    """
    Return vehicles ordered lead-to-back by following the leader_id chain.
    The SimulationLoop must process vehicles in this order so each follower
    uses the leader's already-updated position for the current timestep.
    """
    lead = next(v for v in vehicles if v.leader_id is None)
    ordered: list[Vehicle] = [lead]
    remaining = {v.id: v for v in vehicles if v.leader_id is not None}
    while remaining:
        last_id = ordered[-1].id
        nxt = next((v for v in remaining.values() if v.leader_id == last_id), None)
        if nxt is None:
            break
        ordered.append(nxt)
        del remaining[nxt.id]
    ordered.extend(remaining.values())
    return ordered


def _build_model(row: pd.Series, profile: LeadVehicleProfile | None, sim_config: SimConfig):
    """Instantiate the driving model for one vehicle row via from_excel_row()."""
    name = str(row['model'])
    if name == 'LEAD_PROFILE':
        # LeadVehicleModel needs the profile object, not just the row.
        if profile is None:
            raise ValueError("LEAD_PROFILE model requires a profile sheet.")
        return LeadVehicleModel(profile=profile)
    cls = MODEL_REGISTRY[name]
    return cls.from_excel_row(row, sim_config)


def load_vehicles(path: str) -> tuple[list[Vehicle], SimConfig]:
    """
    Load and validate the Excel input file; return (vehicles, sim_config).

    The returned vehicle list is ordered lead-to-back, ready for the
    SimulationLoop to process in sequence each timestep.

    Parameters
    ----------
    path : str
        Path to the Excel workbook.
    """
    load_plugins()

    xl = pd.ExcelFile(path)

    sim_config = load_sim_config(xl)

    # Load optional vehicle_types sheet
    type_table: pd.DataFrame | None = None
    if 'vehicle_types' in xl.sheet_names:
        type_table = xl.parse('vehicle_types').set_index('type_id')

    # Load and validate vehicles sheet
    df = xl.parse('vehicles')
    validate_vehicle_df(df, type_table)

    # Load profile (required because LEAD_PROFILE must exist)
    profile: LeadVehicleProfile | None = None
    if 'profile' in xl.sheet_names:
        profile = LeadVehicleProfile(xl.parse('profile'))

    # Build Vehicle objects
    vehicles: list[Vehicle] = []
    for _, row in df.iterrows():
        # Resolve leader_id
        raw_lid = row.get('leader_id')
        leader_id = int(raw_lid) if pd.notnull(raw_lid) else None

        # Resolve type row for level-2 lookup
        type_row: pd.Series | None = None
        if type_table is not None:
            vt = row.get('vehicle_type')
            if vt is not None and pd.notnull(vt) and str(vt) in type_table.index:
                type_row = type_table.loc[str(vt)]

        vid     = int(row['vehicle_id'])
        model   = _build_model(row, profile, sim_config)
        filter_ = FILTER_REGISTRY[str(row['filter'])]()
        plant   = VehiclePlant(
            x0     = float(row['initial_position_m']),
            v0     = float(row['initial_speed_mps']),
            length = float(row['vehicle_length_m']),
        )
        response = VehicleResponseModel(
            mode         = sim_config.response_model,
            tau_throttle = resolve_param('tau_throttle_s', row, type_row, sim_config),
            tau_brake    = resolve_param('tau_brake_s',    row, type_row, sim_config),
            a_max        = resolve_param('a_max_mps2',     row, type_row, sim_config),
            a_min        = resolve_param('a_min_mps2',     row, type_row, sim_config),
            j_max        = resolve_param('j_max_mps3',     row, type_row, sim_config),
        )

        # Sensor pipeline — only instantiated when sensor_model != 'passthrough'
        if sim_config.sensor_model == 'passthrough':
            ego_sensor = radar = bsm_tracker = fusion = None
        else:
            s_rng  = vehicle_rng(sim_config.master_seed, vid, 'sensor_noise')
            e_rng  = vehicle_rng(sim_config.master_seed, vid, 'ego_noise')
            b_rng  = vehicle_rng(sim_config.master_seed, vid, 'bsm_comms')
            bp_rng = vehicle_rng(sim_config.master_seed, vid, 'bsm_phase')
            radar       = _build_sensor(sim_config, s_rng)
            ego_sensor  = _build_ego_sensor(row, e_rng, sim_config.timestep_s)
            bsm_tracker = _build_bsm_tracker(sim_config, b_rng, bp_rng)
            fusion      = _build_fusion(sim_config, ego_sensor)

        vt = row.get('vehicle_type')
        vehicles.append(Vehicle(
            id           = vid,
            model        = model,
            response     = response,
            plant        = plant,
            filter_      = filter_,
            leader_id    = leader_id,
            vehicle_type = str(vt) if pd.notnull(vt) else None,
            sensor_model = sim_config.sensor_model,
            ego_sensor   = ego_sensor,
            radar        = radar,
            bsm_tracker  = bsm_tracker,
            fusion       = fusion,
        ))

    ordered = _topological_order(vehicles)

    # Wire platoon_leader for every follower so plugin models can read
    # state.leader_speed / state.leader_acceleration from the front vehicle.
    lead_vehicle = next(v for v in ordered if v.leader_id is None)
    for v in ordered:
        if v.leader_id is not None:
            v.platoon_leader = lead_vehicle

    return ordered, sim_config
