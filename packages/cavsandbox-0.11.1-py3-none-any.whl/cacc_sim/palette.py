"""
Shared visual identity: colors and line styles keyed on driving model class name.

Two separate color palettes are defined:
  MODEL_COLORS       — pygame renderer (live view).  Light grey lead is readable
                       on the black road canvas; bright cyan reads at distance.
  MODEL_COLORS_PLOT  — matplotlib post-run plots.  Black lead is legible on a
                       white background; darker teal avoids the washed-out cyan
                       that matplotlib renders on paper.

Line styles and line width are shared between both views.
Matplotlib uses hex strings; pygame uses RGB-255 tuples — convert with to_rgb255().
"""
from __future__ import annotations

# ── Pygame renderer palette ───────────────────────────────────────────────────
MODEL_COLORS: dict[str, str] = {
    'LeadVehicleModel': '#DCDCDC',   # light grey  — forcing function, neutral
    'IDMHumanModel':    '#E6961E',   # amber        — warm = human driver
    'IDMModel':         '#3CB43C',   # green        — automated; safe/go convention
    'CACCModel':        '#3CC8DC',   # cyan         — higher automation than ACC
}

DEFAULT_COLOR: str = '#A0A0A0'   # fallback for unknown/plugin models (pygame)

# ── Matplotlib plot palette ───────────────────────────────────────────────────
MODEL_COLORS_PLOT: dict[str, str] = {
    'LeadVehicleModel': '#000000',   # black        — legible on white background
    'IDMHumanModel':    '#E6961E',   # amber        — same as pygame
    'IDMModel':         '#3CB43C',   # green        — same as pygame
    'CACCModel':        '#008080',   # dark teal    — richer than cyan on paper
}

DEFAULT_COLOR_PLOT: str = '#606060'  # fallback for unknown/plugin models (plots)

# Line styles per model — differentiates models in black-and-white print
MODEL_LINESTYLES: dict[str, str] = {
    'LeadVehicleModel': 'solid',
    'IDMHumanModel':    'dashed',
    'IDMModel':         'dashdot',
    'CACCModel':        'dotted',
}

DEFAULT_LINESTYLE: str = 'solid'

LINE_WIDTH: float = 2.0   # thicker than matplotlib default (1.5) for print legibility


def to_rgb255(hex_color: str) -> tuple[int, int, int]:
    """Convert '#RRGGBB' to an (R, G, B) tuple with values 0–255 (pygame format)."""
    h = hex_color.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
