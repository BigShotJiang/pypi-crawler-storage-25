"""
Core dataclasses and abstract base classes.

All other cacc_sim modules import from here. No numpy dependency — pure Python.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# DelayBuffer
# ---------------------------------------------------------------------------

class DelayBuffer:
    """
    Fixed-length FIFO that delays a signal by approximately delay_s seconds.

    push_and_read(value) inserts the new value at the front and returns the
    value that was pushed (n − 1) steps ago, where n = round(delay_s / dt).
    All slots are initialised to None.  Call fill(seed) before first use to
    avoid a None startup transient.

    With n=1 (delay_s < dt) the returned value equals the just-pushed value
    (zero delay), which is the correct limiting behaviour.
    """

    def __init__(self, delay_s: float, dt: float = 0.01) -> None:
        n = max(1, round(delay_s / dt))
        self._buf: deque = deque([None] * n, maxlen=n)

    def push_and_read(self, value):
        """Push value onto the front; return the value from (n − 1) steps ago."""
        self._buf.appendleft(value)
        return self._buf[-1]

    def fill(self, value) -> None:
        """Replace every slot with value (seed the buffer before first push)."""
        n = self._buf.maxlen
        self._buf.clear()
        self._buf.extend([value] * n)


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class VehicleState:
    """Full input state passed to every DrivingModel.compute() call."""

    # ── Ego vehicle (universal) ─────────────────────────────────────────────
    speed:              float           # m/s
    acceleration:       float           # current actual acceleration (m/s²)
    time:               float           # simulation time (s)
    position:           float           # longitudinal position (m)

    # ── Immediately preceding vehicle (universal) ───────────────────────────
    gap:                float           # bumper-to-bumper gap (m) — filtered/fused value
    lead_speed:         float           # speed of immediately preceding vehicle (m/s)
    lead_max_decel:     float | None = None  # Gipps only: assumed b̂ of leader (m/s²)

    # ── Sensor-derived leader acceleration (two distinct sources) ────────────
    lead_a_radar: float = 0.0   # Kalman-estimated from radar; for EIDM/CAH (future)
                                 # 0.0 in Step 16 — populated by 3-state KF later
    lead_a_v2v:   float = 0.0   # From BSM feedforward; for CACC control law
                                 # 0.0 when BSM unavailable (graceful degradation)

    # ── Platoon leader fields (predecessor-leader topology) ──────────────────
    leader_speed:       float | None = None  # platoon leader speed (m/s)
    leader_acceleration: float | None = None  # platoon leader accel (m/s²)

    # ── Context ──────────────────────────────────────────────────────────────
    is_string_leader:   bool = False    # True if this vehicle leads the platoon
    driving_mode:       object = None   # DrivingMode enum, if mode switching active

    # ── Escape hatch ─────────────────────────────────────────────────────────
    extras:             dict = field(default_factory=dict)


@dataclass
class DrivingModelOutput:
    """Output of every DrivingModel.compute() call."""
    acceleration: float  # m/s²


@dataclass
class FilterInput:
    """Input to every Filter.update() call."""
    timestamp:      float
    raw_value:      float
    gps_covariance: float | None = None
    extras:         dict = field(default_factory=dict)


@dataclass
class FilterOutput:
    """Output of every Filter.update() call."""
    filtered_value: float
    confidence:     float


# ---------------------------------------------------------------------------
# Abstract base classes
# ---------------------------------------------------------------------------

class DrivingModel(ABC):
    """Strategy interface for all longitudinal control algorithms."""

    @abstractmethod
    def compute(self, state: VehicleState) -> DrivingModelOutput: ...

    @classmethod
    @abstractmethod
    def required_inputs(cls) -> set[str]:
        """Return the set of VehicleState field names this model reads."""
        ...

    @classmethod
    def from_excel_row(cls, row: object, sim_config: object) -> 'DrivingModel':
        """
        Instantiate this model from one vehicles-sheet row and the SimConfig.

        Built-in models override this with explicit column extraction.
        Plugin authors must implement this to be usable via the Excel loader.

        Parameters
        ----------
        row : pandas.Series
            One row from the vehicles DataFrame.
        sim_config : SimConfig
            Global simulation parameters (gains, timestep, etc.).
        """
        raise NotImplementedError(
            f"{cls.__name__} must implement from_excel_row(row, sim_config) "
            f"to be usable as a plugin model."
        )


class Filter(ABC):
    """Strategy interface for all sensor data filters."""

    @abstractmethod
    def update(self, input: FilterInput) -> FilterOutput: ...

    @classmethod
    def required_fields(cls) -> set[str]:
        """FilterInput top-level fields required beyond timestamp and raw_value."""
        return set()

    @classmethod
    def required_extras(cls) -> set[str]:
        """Keys in FilterInput.extras that this filter needs."""
        return set()
