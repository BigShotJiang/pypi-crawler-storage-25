"""
Post-run visualisation: five-panel composite plot and individual panel files.

Called automatically by save_run() after every simulation run.
Usable standalone::

    python -m cacc_sim.plot <results.csv> [--show]

Output written next to the CSV:
    <stem>.png              five-panel composite (shared time axis)
    <stem>_speed.png        speed vs. time
    <stem>_gap.png          gap vs. time (following vehicles only)
    <stem>_accel.png        actual acceleration vs. time
    <stem>_lag.png          commanded vs. actual acceleration (response model lag)
    <stem>_spacetime.png    space-time diagram (position vs. time)
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.axes import Axes
from matplotlib.lines import Line2D

from cacc_sim.palette import (
    DEFAULT_COLOR_PLOT,
    DEFAULT_LINESTYLE,
    LINE_WIDTH,
    MODEL_COLORS_PLOT,
    MODEL_LINESTYLES,
)

# Individual panel specs: (file suffix, y-label, draw function name)
_PANEL_KEYS = ('speed', 'gap', 'accel', 'lag', 'spacetime')
_PANEL_YLABELS = {
    'speed':     'Speed (m/s)',
    'gap':       'Gap (m)',
    'accel':     'Acceleration (m/s²)',
    'lag':       'Acceleration (m/s²)',
    'spacetime': 'Position (m)',
}

_SPACETIME_CAPTION = (
    'Slope = speed.  Horizontal spacing = gap.  Parallel lines = string stable.\n'
    'Note: time on x-axis, position on y-axis — transposed from traffic engineering convention.'
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def plot_run(csv_path: str, show: bool = False) -> None:
    """
    Generate all standard plots from a simulation CSV.

    Saves six PNG files alongside *csv_path*: one five-panel composite and
    five individual panels.  If *show* is True, calls plt.show() after saving
    so the composite is displayed interactively.

    Parameters
    ----------
    csv_path : str
        Path to the CSV produced by save_run() / SimulationLoop.run().
    show : bool
        If True, open an interactive matplotlib window after saving.
        Has no effect in headless / Agg environments.
    """
    df = pd.read_csv(csv_path)
    p = Path(csv_path)
    base = p.with_suffix('')
    # Use parent folder name (e.g. scenario_20260424_143022) as title when
    # the CSV lives inside a per-run subfolder; fall back to the file stem.
    title = p.parent.name if p.name == 'data.csv' else base.name

    fig, axes = plt.subplots(
        5, 1,
        figsize=(12, 13),
        sharex=True,
        constrained_layout=True,
    )
    fig.suptitle(title, fontsize=11, color='0.4')

    _draw_speed(axes[0], df)
    _draw_gap(axes[1], df)
    _draw_accel(axes[2], df)
    _draw_lag(axes[3], df)
    _draw_spacetime(axes[4], df)

    axes[-1].set_xlabel('Time (s)')

    fig.savefig(str(base) + '.png', dpi=150)

    # Individual panels — re-draw into a fresh single-panel figure each time
    for key, ax_composite in zip(_PANEL_KEYS, axes):
        fig_s, ax_s = plt.subplots(figsize=(12, 3))
        _DRAW_FUNCS[key](ax_s, df)
        ax_s.set_xlabel('Time (s)')
        fig_s.savefig(str(base) + f'_{key}.png', dpi=150, bbox_inches='tight')
        plt.close(fig_s)

    if show:
        plt.show()
    else:
        plt.close(fig)


# ---------------------------------------------------------------------------
# Panel drawing helpers (each accepts an Axes and the full DataFrame)
# ---------------------------------------------------------------------------

def _vehicle_style(model: str) -> dict:
    return {
        'color':     MODEL_COLORS_PLOT.get(model, DEFAULT_COLOR_PLOT),
        'linestyle': MODEL_LINESTYLES.get(model, DEFAULT_LINESTYLE),
        'linewidth': LINE_WIDTH,
    }


def _draw_speed(ax: Axes, df: pd.DataFrame) -> None:
    for vid, grp in df.groupby('id', sort=True):
        model = grp['model'].iloc[0]
        ax.plot(grp['t'], grp['v'], label=f'V{vid}', **_vehicle_style(model))
    ax.set_ylabel(_PANEL_YLABELS['speed'])
    ax.grid(True, alpha=0.25)
    _add_legend(ax, df)


def _draw_gap(ax: Axes, df: pd.DataFrame) -> None:
    following = df[df['leader_id'].notna()]
    if following.empty:
        ax.text(0.5, 0.5, 'No following vehicles', transform=ax.transAxes,
                ha='center', va='center', color='0.5')
    else:
        for vid, grp in following.groupby('id', sort=True):
            model = grp['model'].iloc[0]
            ax.plot(grp['t'], grp['gap'], label=f'V{vid}', **_vehicle_style(model))
    ax.set_ylabel(_PANEL_YLABELS['gap'])
    ax.grid(True, alpha=0.25)
    _add_legend(ax, df[df['leader_id'].notna()])


def _draw_accel(ax: Axes, df: pd.DataFrame) -> None:
    for vid, grp in df.groupby('id', sort=True):
        model = grp['model'].iloc[0]
        ax.plot(grp['t'], grp['a'], label=f'V{vid}', **_vehicle_style(model))
    ax.axhline(0, color='0.5', linewidth=0.6, linestyle='solid')
    ax.set_ylabel(_PANEL_YLABELS['accel'])
    ax.grid(True, alpha=0.25)
    _add_legend(ax, df)


def _draw_spacetime(ax: Axes, df: pd.DataFrame) -> None:
    """Space-time diagram: position (y) vs. time (x) per vehicle."""
    for vid, grp in df.groupby('id', sort=True):
        model = grp['model'].iloc[0]
        ax.plot(grp['t'], grp['x'], label=f'V{vid}', **_vehicle_style(model))
    ax.set_ylabel(_PANEL_YLABELS['spacetime'])
    ax.grid(True, alpha=0.25)
    ax.set_title(_SPACETIME_CAPTION, fontsize=7, color='0.4', loc='left', style='italic')
    _add_legend(ax, df)


def _draw_lag(ax: Axes, df: pd.DataFrame) -> None:
    """Actual vs. commanded acceleration for vehicle 2 (first follower)."""
    following = df[df['leader_id'].notna()]
    if following.empty:
        ax.text(0.5, 0.5, 'No following vehicles', transform=ax.transAxes,
                ha='center', va='center', color='0.5')
        ax.set_ylabel(_PANEL_YLABELS['lag'])
        ax.grid(True, alpha=0.25)
        return

    # Prefer vehicle id=2; fall back to the first following vehicle.
    vids = sorted(following['id'].unique())
    vid  = 2 if 2 in vids else vids[0]
    grp  = following[following['id'] == vid]
    model = grp['model'].iloc[0]
    color = MODEL_COLORS_PLOT.get(model, DEFAULT_COLOR_PLOT)

    ax.plot(grp['t'], grp['a'],     color=color, linestyle='solid',
            linewidth=LINE_WIDTH, label='actual')
    ax.plot(grp['t'], grp['a_cmd'], color=color, linestyle='dashed',
            linewidth=LINE_WIDTH, label='commanded')
    ax.axhline(0, color='0.5', linewidth=0.6, linestyle='solid')
    ax.set_ylabel(_PANEL_YLABELS['lag'])
    ax.set_title(f'V{vid} — actual vs. commanded', fontsize=9, color='0.4', loc='left')
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8, loc='upper right', framealpha=0.7)


# ---------------------------------------------------------------------------
# Legend helpers
# ---------------------------------------------------------------------------

def _legend_handles(df: pd.DataFrame) -> list[Line2D]:
    handles = []
    for vid, grp in df.groupby('id', sort=True):
        model = grp['model'].iloc[0]
        handles.append(Line2D([0], [0], label=f'V{vid}', **_vehicle_style(model)))
    return handles


def _add_legend(ax: Axes, df: pd.DataFrame) -> None:
    handles = _legend_handles(df)
    if handles:
        ax.legend(handles=handles, fontsize=8, loc='upper right', framealpha=0.7)


# Dispatch table used by plot_run for individual panel saves
_DRAW_FUNCS = {
    'speed':     _draw_speed,
    'gap':       _draw_gap,
    'accel':     _draw_accel,
    'lag':       _draw_lag,
    'spacetime': _draw_spacetime,
}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    if len(sys.argv) < 2:
        print('Usage: cavsandbox-plot <results.csv> [--show]', file=sys.stderr)
        sys.exit(1)
    plot_run(sys.argv[1], show='--show' in sys.argv)


if __name__ == '__main__':
    main()
