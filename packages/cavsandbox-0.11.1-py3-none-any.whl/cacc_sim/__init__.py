"""
cacc_sim — CAV Sandbox simulation core package.

Public API re-exported here so plugins can write:
    from cacc_sim import DrivingModel, DrivingModelOutput, VehicleState
"""
try:
    from cacc_sim._version import __version__
except ImportError:
    __version__ = "0.0.0+unknown"
from cacc_sim.core import (
    VehicleState,
    DrivingModelOutput,
    FilterInput,
    FilterOutput,
    DrivingModel,
    Filter,
    DelayBuffer,
)
from cacc_sim.plant import VehiclePlant, VehicleResponseModel
from cacc_sim.controllers import CACCController
from cacc_sim.driving_models import IDMModel, IDMHumanModel, CACCModel, LeadVehicleModel
from cacc_sim.filters import PassthroughFilter
from cacc_sim.profile import LeadVehicleProfile
from cacc_sim.vehicle import Vehicle
from cacc_sim.rng import vehicle_rng
from cacc_sim.sensors import (
    ARNoise,
    BaseSensor, PassthroughSensor, RadarSensor,
    BaseEgoSensor, PassthroughEgoSensor, NoisyEgoSensor,
    BaseBSMTracker, PassthroughBSMTracker,
    BaseFusionEstimator, PassthroughFusionEstimator,
    GapKalmanFilter, LowPassFilter,
)
from cacc_sim.loader import SimConfig, MODEL_REGISTRY, FILTER_REGISTRY, load_vehicles, load_plugins, resolve_param
from cacc_sim.road import Lane, Road
from cacc_sim.simulation import SimulationLoop
from cacc_sim.renderer import VehicleRenderState, RenderFrame, PygameRenderer
from cacc_sim.playback import CSVPlayback
from cacc_sim.output import save_run

__all__ = [
    # Core dataclasses, ABCs, and utilities
    "VehicleState",
    "DrivingModelOutput",
    "FilterInput",
    "FilterOutput",
    "DrivingModel",
    "Filter",
    "DelayBuffer",
    # Physics layer
    "VehiclePlant",
    "VehicleResponseModel",
    # Controllers
    "CACCController",
    # Driving models
    "IDMModel",
    "IDMHumanModel",
    "CACCModel",
    "LeadVehicleModel",
    # Filters
    "PassthroughFilter",
    # Profile
    "LeadVehicleProfile",
    # Vehicle
    "Vehicle",
    # RNG
    "vehicle_rng",
    # Sensors
    "ARNoise",
    "BaseSensor", "PassthroughSensor", "RadarSensor",
    "BaseEgoSensor", "PassthroughEgoSensor", "NoisyEgoSensor",
    "BaseBSMTracker", "PassthroughBSMTracker",
    "BaseFusionEstimator", "PassthroughFusionEstimator",
    "GapKalmanFilter", "LowPassFilter",
    # Loader
    "SimConfig",
    "MODEL_REGISTRY",
    "FILTER_REGISTRY",
    "load_vehicles",
    "load_plugins",
    "resolve_param",
    # Road
    "Lane",
    "Road",
    # Simulation
    "SimulationLoop",
    # Renderer
    "VehicleRenderState",
    "RenderFrame",
    "PygameRenderer",
    # Playback
    "CSVPlayback",
    # Output
    "save_run",
]
