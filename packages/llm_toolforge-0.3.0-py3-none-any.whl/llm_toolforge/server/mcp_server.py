"""
MCP Server 层

调用 create_app() 可获得已配置好的 Starlette SSE 应用。
uvicorn 使用方式（--factory 模式）：
    uvicorn llm_toolforge.server.mcp_server:create_app --factory
"""

import asyncio
import inspect
import json
import time
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

try:
    from mcp.server.transport_security import TransportSecuritySettings
    _TRANSPORT_SECURITY = TransportSecuritySettings(enable_dns_rebinding_protection=False)
except ImportError:
    _TRANSPORT_SECURITY = None

from starlette.middleware.cors import CORSMiddleware as StarletteCORS
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp, Receive, Scope, Send

from ..core.base import LLMServiceError, Plugin, UploadError
from ..core.log_store import LogStore
from ..core.load_monitor import LoadMonitor, OverloadedError
from ..config import load_config
from ..discovery import discover_plugins


def create_app():
    """创建并返回 MCP SSE Starlette 应用实例。

    从 TOOLFORGE_CONFIG 环境变量或 CWD/config.yaml 读取配置，
    自动发现并注册所有插件为 MCP tools。
    """
    config = load_config()
    server_cfg: dict = config.get("server", {})
    enable_auth: bool = server_cfg.get("enable_auth", False)
    authorization: str = server_cfg.get("authorization", "")
    request_timeout_s: float = float(server_cfg.get("request_timeout_s", 180))

    plugins: list[Plugin] = discover_plugins(config)

    service_name = plugins[0].name if len(plugins) == 1 else "工具服务"
    service_instructions = "；".join(p.description for p in plugins)

    # ── MCP 实例 ──────────────────────────────────────────────────────────────

    mcp_kwargs = dict(name=service_name, instructions=service_instructions)
    if _TRANSPORT_SECURITY is not None:
        mcp_kwargs["transport_security"] = _TRANSPORT_SECURITY
    mcp = FastMCP(**mcp_kwargs)

    # ── 工具函数 ──────────────────────────────────────────────────────────────

    async def _run_tool_with_deadline(func):
        loop = asyncio.get_running_loop()
        future = loop.run_in_executor(None, func)
        if request_timeout_s <= 0:
            return await future
        return await asyncio.wait_for(future, timeout=request_timeout_s)

    # ── 注册每个 Plugin 为 MCP tool ───────────────────────────────────────────

    def _register_tool(plugin: Plugin) -> None:
        async def _tool(**kwargs) -> str:
            started_at = time.perf_counter()
            try:
                async with LoadMonitor.request():
                    result = await _run_tool_with_deadline(
                        lambda: plugin.generator.generate(**kwargs)
                    )
            except LLMServiceError as e:
                LoadMonitor.record_result(started_at, "error", "llm_error")
                raise RuntimeError(f"LLM 服务调用失败: {e}") from e
            except UploadError as e:
                LoadMonitor.record_result(started_at, "error", "upload_error")
                raise RuntimeError(f"上传失败: {e}") from e
            except asyncio.TimeoutError as e:
                LoadMonitor.record_result(started_at, "error", "request_timeout")
                raise RuntimeError(f"工具调用超过 {request_timeout_s:g}s 未完成") from e
            except OverloadedError as e:
                raise RuntimeError(f"服务当前负载过高: {e}") from e
            except Exception:
                LoadMonitor.record_result(started_at, "error", "unknown_error")
                raise

            error_type = "" if result.status.value == "success" else (result.error_type or "business_error")
            LoadMonitor.record_result(started_at, result.status.value, error_type)
            return json.dumps(
                {
                    "status": result.status.value,
                    "outputs": result.outputs,
                    "message": result.message,
                    "token_usage": result.token_usage,
                    "error_type": result.error_type,
                },
                ensure_ascii=False,
            )

        params = []
        input_docs = []
        for inp in plugin.inputs:
            p = inspect.Parameter(
                inp.name,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=inp.type,
                **({"default": inp.default} if not inp.required else {}),
            )
            params.append(p)
            examples_str = ", ".join(str(e) for e in inp.examples) if inp.examples else ""
            opt_tag = "" if inp.required else "（可选）"
            input_docs.append(
                f"  {inp.name}{opt_tag}: {inp.description}"
                + (f"  示例: {examples_str}" if examples_str else "")
            )

        _tool.__signature__ = inspect.Signature(parameters=params, return_annotation=str)
        _tool.__name__ = plugin.operation_id
        _tool.__doc__ = (
            f"{plugin.description}\n\n"
            f"输入参数：\n" + "\n".join(input_docs) + "\n\n"
            "返回 JSON 字符串，字段：\n"
            "  status: success | error\n"
            "  outputs: 工具输出数据（dict，成功时有数据，失败时为空）\n"
            "  message: 失败时为错误原因，成功时通常为空\n"
            "  token_usage: 按模型名聚合的 token 用量；未使用 LLM 的工具为空 dict"
        )

        mcp.add_tool(_tool, description=plugin.description)

    for _plugin in plugins:
        _register_tool(_plugin)

    # ── 鉴权中间件 ────────────────────────────────────────────────────────────

    class _AuthMiddleware:
        def __init__(self, inner_app: ASGIApp) -> None:
            self.app = inner_app

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            if scope["type"] not in ("http", "websocket"):
                await self.app(scope, receive, send)
                return
            headers = dict(scope.get("headers", []))
            if scope.get("path") in ("/healthz", "/readyz"):
                await self.app(scope, receive, send)
                return
            token = headers.get(b"authorization", b"").decode()
            if token != authorization:
                response = Response("未授权访问", status_code=401)
                await response(scope, receive, send)
                return
            await self.app(scope, receive, send)

    # ── 健康探针 ──────────────────────────────────────────────────────────────

    async def _healthz(request):
        return JSONResponse({"status": "ok", "service": "mcp", "tools": len(plugins), "timestamp": int(time.time())})

    async def _readyz(request):
        dependency_health = await LogStore.health()
        snapshot = LoadMonitor.snapshot()
        body = {
            "status": "ok" if dependency_health["ok"] else "not_ready",
            "service": "mcp", "tools": len(plugins),
            "load": {
                "status": snapshot.get("status"),
                "active_requests": snapshot.get("active_requests"),
                "pending_requests": snapshot.get("pending_requests"),
                "max_concurrency": snapshot.get("max_concurrency"),
                "event_loop_lag_ms": snapshot.get("event_loop_lag_ms"),
            },
            "dependencies": dependency_health["checks"],
            "timestamp": int(time.time()),
        }
        return JSONResponse(body, status_code=200 if dependency_health["ok"] else 503)

    # ── lifespan ──────────────────────────────────────────────────────────────

    heartbeat_interval = int(config.get("logging", {}).get("heartbeat_interval_s", 5))

    @asynccontextmanager
    async def _lifespan(starlette_app):
        LoadMonitor.setup(config, service="mcp")
        await LogStore.setup(config)
        LogStore.set_instance_id(LoadMonitor.snapshot().get("instance_id", ""))
        lag_task = asyncio.create_task(LoadMonitor.loop_lag_probe())
        hb_task = asyncio.create_task(_heartbeat_loop())
        try:
            yield
        finally:
            lag_task.cancel()
            hb_task.cancel()
            await LogStore.shutdown()

    async def _heartbeat_loop() -> None:
        while True:
            try:
                await LogStore.write_worker_heartbeat(LoadMonitor.snapshot())
            except Exception:
                pass
            await asyncio.sleep(heartbeat_interval)

    # ── 组装 Starlette 应用 ───────────────────────────────────────────────────

    starlette_app = mcp.sse_app()
    starlette_app.router.lifespan_context = _lifespan
    starlette_app.add_route("/healthz", _healthz, methods=["GET"])
    starlette_app.add_route("/readyz", _readyz, methods=["GET"])
    if enable_auth:
        starlette_app.add_middleware(_AuthMiddleware)
    starlette_app.add_middleware(
        StarletteCORS,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return starlette_app
