"""
双进程启动器：同时拉起 API（HTTP）和 MCP（SSE）两个 uvicorn 进程。
"""

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional


def _resolve_workers(value, *, max_workers: int, multiplier: int = 1) -> int:
    if isinstance(value, int):
        return max(1, value)
    if str(value).lower() != "auto":
        return max(1, int(value))
    cpu = os.cpu_count() or 1
    return min(max_workers, max(1, cpu * multiplier))


def _start(name: str, cmd: list[str], env: dict) -> subprocess.Popen:
    print(f"[{name}] {' '.join(str(c) for c in cmd)}")
    return subprocess.Popen(cmd, env=env)


def _terminate(processes: list[subprocess.Popen]) -> None:
    for p in processes:
        if p.poll() is None:
            p.terminate()
    for p in processes:
        try:
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()


def run(
    config_path: Optional[str] = None,
    api_only: bool = False,
    mcp_only: bool = False,
) -> int:
    """启动 API 和/或 MCP 服务进程。

    Args:
        config_path: config.yaml 路径，None 时按标准顺序查找。
        api_only: 只启动 HTTP API。
        mcp_only: 只启动 MCP SSE 服务。
    """
    from ..config import load_config, find_config

    cfg_file = str(find_config(config_path)) if config_path else str(find_config())
    config = load_config(config_path)
    server_cfg = config.get("server", {})

    host = server_cfg.get("host", "0.0.0.0")
    api_port = str(server_cfg.get("port", 12345))
    mcp_port = str(server_cfg.get("mcp_port", 12346))

    api_workers = _resolve_workers(
        server_cfg.get("api_workers", "auto"),
        max_workers=int(server_cfg.get("max_api_workers", 8)),
        multiplier=int(server_cfg.get("worker_multiplier", 1)),
    )
    mcp_workers = _resolve_workers(
        server_cfg.get("mcp_workers", 1),
        max_workers=int(server_cfg.get("max_mcp_workers", 4)),
    )

    # 将 config 路径通过环境变量传递给 worker 进程
    env = os.environ.copy()
    env["TOOLFORGE_CONFIG"] = cfg_file

    processes = []
    if not mcp_only:
        api_cmd = [
            sys.executable, "-m", "uvicorn",
            "llm_toolforge.server.api:create_app",
            "--factory",
            "--host", host, "--port", api_port,
            "--workers", str(api_workers),
        ]
        print(f"[API]  http://{host}:{api_port}  workers={api_workers}")
        processes.append(_start("API", api_cmd, env))

    if not api_only:
        mcp_cmd = [
            sys.executable, "-m", "uvicorn",
            "llm_toolforge.server.mcp_server:create_app",
            "--factory",
            "--host", host, "--port", mcp_port,
            "--workers", str(mcp_workers),
        ]
        print(f"[MCP]  http://{host}:{mcp_port}/sse  workers={mcp_workers}")
        processes.append(_start("MCP", mcp_cmd, env))

    try:
        while True:
            for p in processes:
                code = p.poll()
                if code is not None:
                    _terminate(processes)
                    return code
            time.sleep(1)
    except KeyboardInterrupt:
        _terminate(processes)
        return 0
