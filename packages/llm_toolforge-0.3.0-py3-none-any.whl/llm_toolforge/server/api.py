"""
HTTP API 层

调用 create_app() 可获得已配置好的 FastAPI 实例。
uvicorn 使用方式（--factory 模式）：
    uvicorn llm_toolforge.server.api:create_app --factory
"""

import asyncio
import json
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated, Literal, Optional

from fastapi import BackgroundTasks, Depends, FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, create_model

from ..core.base import (
    BaseGenerator,
    GenerateProgress,
    GenerateResult,
    LLMServiceError,
    Plugin,
    UploadError,
)
from ..core.log_store import LogStore
from ..core.load_monitor import LoadMonitor, OverloadedError
from ..core.oss_client import OSSClient
from ..config import load_config
from ..discovery import discover_plugins


def create_app() -> FastAPI:
    """创建并返回 FastAPI 应用实例。

    从 TOOLFORGE_CONFIG 环境变量或 CWD/config.yaml 读取配置，
    自动发现并注册所有插件。
    """
    config = load_config()
    server_cfg: dict = config.get("server", {})

    enable_web_ui: bool = server_cfg.get("enable_web_ui", False)
    enable_auth: bool = server_cfg.get("enable_auth", False)
    authorization: str = server_cfg.get("authorization", "")
    server_host: str = server_cfg.get("host", "127.0.0.1")
    server_port: int = server_cfg.get("port", 8080)
    request_timeout_s: float = float(server_cfg.get("request_timeout_s", 180))
    max_upload_bytes: int = int(float(server_cfg.get("max_upload_mb", 50)) * 1024 * 1024)
    heartbeat_interval_s: int = int(config.get("logging", {}).get("heartbeat_interval_s", 5))

    plugins: list[Plugin] = discover_plugins(config)

    service_name = plugins[0].name if len(plugins) == 1 else "工具服务"
    service_desc = (
        plugins[0].description
        if len(plugins) == 1
        else "包含 {} 个工具：{}。各工具说明详见对应接口。".format(
            len(plugins),
            "、".join(p.name for p in plugins),
        )
    )

    # ── 静态资源目录 ────────────────────────────────────────────────────────────
    # server/api.py → server/ → llm_toolforge/ → static/
    framework_static = Path(__file__).parent.parent / "static"

    # ── 鉴权 ────────────────────────────────────────────────────────────────────

    async def verify_auth(request: Request):
        if not enable_auth:
            return
        token = request.headers.get("Authorization", "")
        if token != authorization:
            raise HTTPException(status_code=401, detail="未授权访问")

    # ── lifespan ────────────────────────────────────────────────────────────────

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        LoadMonitor.setup(config, service="api")
        await LogStore.setup(config)
        LogStore.set_instance_id(LoadMonitor.snapshot().get("instance_id", ""))
        lag_task = asyncio.create_task(LoadMonitor.loop_lag_probe())
        heartbeat_task = asyncio.create_task(_heartbeat_loop())
        try:
            yield
        finally:
            lag_task.cancel()
            heartbeat_task.cancel()
            await LogStore.shutdown()

    async def _heartbeat_loop() -> None:
        while True:
            try:
                await LogStore.write_worker_heartbeat(LoadMonitor.snapshot())
            except Exception:
                pass
            await asyncio.sleep(heartbeat_interval_s)

    # ── FastAPI 应用 ─────────────────────────────────────────────────────────────

    app = FastAPI(
        title=service_name,
        description=service_desc,
        version="1.0.0",
        servers=[{"url": f"http://{server_host}:{server_port}", "description": "当前服务"}],
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.exception_handler(RequestValidationError)
    async def _safe_validation_error_handler(request: Request, exc: RequestValidationError):
        def _sanitize(obj):
            if isinstance(obj, bytes):
                try:
                    return obj.decode()
                except UnicodeDecodeError:
                    return f"<binary {len(obj)} bytes>"
            if isinstance(obj, dict):
                return {k: _sanitize(v) for k, v in obj.items()}
            if isinstance(obj, (list, tuple)):
                return [_sanitize(v) for v in obj]
            return obj

        return JSONResponse(
            status_code=422,
            content={"detail": _sanitize(exc.errors())},
        )

    # ── 响应模型 ─────────────────────────────────────────────────────────────────

    class GenerateResponse(BaseModel):
        status: Literal["success", "error"] = Field(
            description="生成结果状态：success=成功，error=失败"
        )
        outputs: dict = Field(
            default_factory=dict,
            description="工具输出数据，结构因工具而异。成功时包含数据，失败时为空。",
        )
        message: Optional[str] = Field(None, description="失败时为错误原因，成功时通常为空")
        token_usage: dict = Field(
            default_factory=dict,
            description="按模型名聚合的 token 用量。未使用 LLM 的工具为空 dict。",
        )
        error_type: str = Field(
            default="",
            description="错误分类，成功时为空；例如 business_error / upstream_error / upload_error。",
        )

    # ── 工具函数 ─────────────────────────────────────────────────────────────────

    def _result_to_dict(result: GenerateResult) -> dict:
        return {
            "status": result.status.value,
            "outputs": result.outputs,
            "message": result.message,
            "token_usage": result.token_usage,
            "error_type": result.error_type,
        }

    def _error_type_from_exception(exc: Exception) -> str:
        if isinstance(exc, LLMServiceError):
            return "llm_error"
        if isinstance(exc, UploadError):
            return "upload_error"
        if isinstance(exc, OverloadedError):
            return "server_overloaded"
        return "unknown_error"

    async def _run_tool_with_deadline(func):
        loop = asyncio.get_running_loop()
        future = loop.run_in_executor(None, func)
        if request_timeout_s <= 0:
            return await future
        return await asyncio.wait_for(future, timeout=request_timeout_s)

    # ── 动态注册每个 Plugin 的路由 ────────────────────────────────────────────────

    _STREAM_SENTINEL = object()

    async def _stream_response(p: Plugin, kwargs: dict, request_id: str, client_ip: str) -> StreamingResponse:
        async def event_generator():
            task_id = request_id
            created_at = time.time()
            monitor_start = time.perf_counter()

            started = json.dumps({"task_id": task_id, "created_at": created_at}, ensure_ascii=False)
            yield f"event: started\ndata: {started}\n\n"

            try:
                async with LoadMonitor.request():
                    loop = asyncio.get_running_loop()
                    queue: asyncio.Queue = asyncio.Queue()

                    def _run_generator():
                        try:
                            for item in p.generator.generate_stream(**kwargs):
                                loop.call_soon_threadsafe(queue.put_nowait, item)
                        except (LLMServiceError, UploadError) as e:
                            loop.call_soon_threadsafe(queue.put_nowait, e)
                        except Exception as e:
                            loop.call_soon_threadsafe(queue.put_nowait, e)
                        finally:
                            loop.call_soon_threadsafe(queue.put_nowait, _STREAM_SENTINEL)

                    loop.run_in_executor(None, _run_generator)

                    while True:
                        if request_timeout_s > 0:
                            remaining = request_timeout_s - (time.time() - created_at)
                            if remaining <= 0:
                                raise asyncio.TimeoutError
                            item = await asyncio.wait_for(queue.get(), timeout=remaining)
                        else:
                            item = await queue.get()

                        if item is _STREAM_SENTINEL:
                            break

                        if isinstance(item, Exception):
                            error_type = _error_type_from_exception(item)
                            LoadMonitor.record_result(monitor_start, "error", error_type)
                            asyncio.create_task(LogStore.write({
                                "request_id": request_id,
                                "tool_name": p.name,
                                "input_params": json.dumps(kwargs, ensure_ascii=False),
                                "status": "error",
                                "error_type": error_type,
                                "error_msg": str(item),
                                "elapsed_ms": round((time.time() - created_at) * 1000),
                                "client_ip": client_ip,
                            }))
                            error_data = json.dumps(
                                {"task_id": task_id, "error": str(item), "code": error_type},
                                ensure_ascii=False,
                            )
                            yield f"event: error\ndata: {error_data}\n\n"
                            break

                        if isinstance(item, GenerateProgress):
                            data = json.dumps(
                                {"task_id": task_id, "step": item.step, "message": item.message},
                                ensure_ascii=False,
                            )
                            yield f"event: progress\ndata: {data}\n\n"
                        elif isinstance(item, GenerateResult):
                            finished_at = time.time()
                            error_type = "" if item.status.value == "success" else (item.error_type or "business_error")
                            LoadMonitor.record_result(monitor_start, item.status.value, error_type)
                            result_data = _result_to_dict(item)
                            result_data.update({
                                "task_id": task_id,
                                "elapsed_time": round(finished_at - created_at, 3),
                                "created_at": created_at,
                                "finished_at": finished_at,
                            })
                            asyncio.create_task(LogStore.write({
                                "request_id": request_id,
                                "tool_name": p.name,
                                "input_params": json.dumps(kwargs, ensure_ascii=False),
                                "status": item.status.value,
                                "error_type": error_type,
                                "output": json.dumps(item.outputs, ensure_ascii=False),
                                "elapsed_ms": round((finished_at - created_at) * 1000),
                                "client_ip": client_ip,
                            }))
                            data = json.dumps(result_data, ensure_ascii=False)
                            yield f"event: result\ndata: {data}\n\n"

            except OverloadedError as e:
                asyncio.create_task(LogStore.write({
                    "request_id": request_id, "tool_name": p.name,
                    "input_params": json.dumps(kwargs, ensure_ascii=False),
                    "status": "error", "error_type": "server_overloaded",
                    "error_msg": str(e),
                    "elapsed_ms": round((time.time() - created_at) * 1000),
                    "client_ip": client_ip,
                }))
                yield f"event: error\ndata: {json.dumps({'task_id': task_id, 'error': str(e), 'code': 'server_overloaded'}, ensure_ascii=False)}\n\n"
            except asyncio.TimeoutError:
                LoadMonitor.record_result(monitor_start, "error", "request_timeout")
                msg = f"请求超过 {request_timeout_s:g}s 未完成"
                asyncio.create_task(LogStore.write({
                    "request_id": request_id, "tool_name": p.name,
                    "input_params": json.dumps(kwargs, ensure_ascii=False),
                    "status": "error", "error_type": "request_timeout", "error_msg": msg,
                    "elapsed_ms": round((time.time() - created_at) * 1000),
                    "client_ip": client_ip,
                }))
                yield f"event: error\ndata: {json.dumps({'task_id': task_id, 'error': msg, 'code': 'request_timeout'}, ensure_ascii=False)}\n\n"

            yield f"event: ping\ndata: {{}}\n\n"

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    def _register_plugin(plugin: Plugin) -> None:
        fields = {}
        for inp in plugin.inputs:
            if inp.required:
                fi = Field(..., description=inp.description, examples=inp.examples)
            else:
                fi = Field(inp.default, description=inp.description, examples=inp.examples)
            fields[inp.name] = (inp.type, fi)

        RequestModel = create_model(f"{plugin.operation_id}Request", **fields)

        def _make_handler(p: Plugin, model):
            async def handler(
                req: Request,
                body: model,
                background_tasks: BackgroundTasks,
                stream: bool = Query(False),
            ) -> GenerateResponse:
                kwargs = {inp.name: getattr(body, inp.name) for inp in p.inputs}
                client_ip = req.client.host if req.client else ""
                request_id = uuid.uuid4().hex

                if stream:
                    return await _stream_response(p, kwargs, request_id, client_ip)

                start = time.time()
                monitor_start = time.perf_counter()
                try:
                    async with LoadMonitor.request():
                        try:
                            result = await _run_tool_with_deadline(
                                lambda: p.generator.generate(**kwargs)
                            )
                        except (LLMServiceError, UploadError) as e:
                            error_type = _error_type_from_exception(e)
                            elapsed_ms = round((time.time() - start) * 1000)
                            LoadMonitor.record_result(monitor_start, "error", error_type)
                            background_tasks.add_task(LogStore.write, {
                                "request_id": request_id, "tool_name": p.name,
                                "input_params": json.dumps(kwargs, ensure_ascii=False),
                                "status": "error", "error_type": error_type,
                                "error_msg": str(e), "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                            })
                            raise HTTPException(status_code=502, detail=str(e)) from e
                        except asyncio.TimeoutError as e:
                            elapsed_ms = round((time.time() - start) * 1000)
                            LoadMonitor.record_result(monitor_start, "error", "request_timeout")
                            background_tasks.add_task(LogStore.write, {
                                "request_id": request_id, "tool_name": p.name,
                                "input_params": json.dumps(kwargs, ensure_ascii=False),
                                "status": "error", "error_type": "request_timeout",
                                "error_msg": f"请求超过 {request_timeout_s:g}s 未完成",
                                "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                            })
                            raise HTTPException(
                                status_code=504,
                                detail=f"请求超过 {request_timeout_s:g}s 未完成",
                            ) from e
                        except Exception as e:
                            elapsed_ms = round((time.time() - start) * 1000)
                            LoadMonitor.record_result(monitor_start, "error", "unknown_error")
                            background_tasks.add_task(LogStore.write, {
                                "request_id": request_id, "tool_name": p.name,
                                "input_params": json.dumps(kwargs, ensure_ascii=False),
                                "status": "error", "error_type": "unknown_error",
                                "error_msg": str(e), "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                            })
                            raise
                except OverloadedError as e:
                    elapsed_ms = round((time.time() - start) * 1000)
                    background_tasks.add_task(LogStore.write, {
                        "request_id": request_id, "tool_name": p.name,
                        "input_params": json.dumps(kwargs, ensure_ascii=False),
                        "status": "error", "error_type": "server_overloaded",
                        "error_msg": str(e), "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                    })
                    raise HTTPException(status_code=503, detail=str(e)) from e
                except (LLMServiceError, UploadError) as e:
                    elapsed_ms = round((time.time() - start) * 1000)
                    error_type = _error_type_from_exception(e)
                    LoadMonitor.record_result(monitor_start, "error", error_type)
                    background_tasks.add_task(LogStore.write, {
                        "request_id": request_id, "tool_name": p.name,
                        "input_params": json.dumps(kwargs, ensure_ascii=False),
                        "status": "error", "error_type": error_type,
                        "error_msg": str(e), "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                    })
                    raise HTTPException(status_code=502, detail=str(e)) from e
                except asyncio.TimeoutError as e:
                    elapsed_ms = round((time.time() - start) * 1000)
                    LoadMonitor.record_result(monitor_start, "error", "request_timeout")
                    background_tasks.add_task(LogStore.write, {
                        "request_id": request_id, "tool_name": p.name,
                        "input_params": json.dumps(kwargs, ensure_ascii=False),
                        "status": "error", "error_type": "request_timeout",
                        "error_msg": f"请求超过 {request_timeout_s:g}s 未完成",
                        "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                    })
                    raise HTTPException(
                        status_code=504,
                        detail=f"请求超过 {request_timeout_s:g}s 未完成",
                    ) from e

                elapsed_ms = round((time.time() - start) * 1000)
                error_type = "" if result.status.value == "success" else (result.error_type or "business_error")
                LoadMonitor.record_result(monitor_start, result.status.value, error_type)
                background_tasks.add_task(LogStore.write, {
                    "request_id": request_id, "tool_name": p.name,
                    "input_params": json.dumps(kwargs, ensure_ascii=False),
                    "status": result.status.value, "error_type": error_type,
                    "output": json.dumps(result.outputs, ensure_ascii=False),
                    "elapsed_ms": elapsed_ms, "client_ip": client_ip,
                })
                return GenerateResponse(**_result_to_dict(result))

            handler.__name__ = p.operation_id
            # Cython 编译后 inner function 的 __annotations__ 不会保留，手动补全
            handler.__annotations__ = {
                "req": Request,
                "body": model,
                "background_tasks": BackgroundTasks,
                "stream": bool,
                "return": GenerateResponse,
            }
            return handler

        app.add_api_route(
            plugin.route_path,
            _make_handler(plugin, RequestModel),
            methods=["POST"],
            summary=plugin.route_summary,
            description=plugin.description,
            operation_id=plugin.operation_id,
            dependencies=[Depends(verify_auth)],
        )

    for _plugin in plugins:
        _register_plugin(_plugin)

    # ── 公共路由 ─────────────────────────────────────────────────────────────────

    @app.get("/tools", summary="工具列表", operation_id="listTools", include_in_schema=False)
    def list_tools():
        return [
            {
                "name": p.name,
                "description": p.description,
                "route_path": p.route_path,
                "operation_id": p.operation_id,
                "supports_stream": type(p.generator).generate_stream is not BaseGenerator.generate_stream,
                "inputs": [
                    {
                        "name": inp.name,
                        "type": inp.type.__name__,
                        "description": inp.description,
                        "required": inp.required,
                        "default": inp.default,
                        "examples": inp.examples,
                        "kind": inp.kind,
                        "accept": inp.accept,
                    }
                    for inp in p.inputs
                ],
            }
            for p in plugins
        ]

    @app.get("/healthz", summary="存活检查", operation_id="healthz")
    def healthz():
        return {"status": "ok", "service": "api", "tools": len(plugins), "timestamp": int(time.time())}

    @app.get("/readyz", summary="就绪检查", operation_id="readyz")
    async def readyz():
        dependency_health = await LogStore.health()
        snapshot = LoadMonitor.snapshot()
        body = {
            "status": "ok" if dependency_health["ok"] else "not_ready",
            "service": "api", "tools": len(plugins),
            "load": {
                "status": snapshot.get("status"),
                "active_requests": snapshot.get("active_requests"),
                "pending_requests": snapshot.get("pending_requests"),
                "max_concurrency": snapshot.get("max_concurrency"),
                "event_loop_lag_ms": snapshot.get("event_loop_lag_ms"),
            },
            "dependencies": dependency_health["checks"],
            "timestamp": int(time.time()),
        }
        return JSONResponse(status_code=200 if dependency_health["ok"] else 503, content=body)

    @app.get("/version", summary="版本信息", operation_id="getVersion", include_in_schema=False)
    def version():
        g = globals()
        return {
            "version": g.get("__version__", "dev"),
            "build_time": g.get("__build_time__"),
            "git_sha": g.get("__git_sha__"),
        }

    def _resolve_scope(request: Request, scope: str) -> str:
        if scope == "global":
            if LogStore.is_admin_token(request.headers.get("X-Admin-Token")):
                return "global"
            raise HTTPException(status_code=403, detail="scope=global 需要 X-Admin-Token")
        return "service"

    @app.get("/logs", summary="调用日志", operation_id="queryLogs", dependencies=[Depends(verify_auth)])
    async def query_logs(
        request: Request,
        tool: Optional[str] = Query(None),
        status: Optional[str] = Query(None),
        start: Optional[str] = Query(None),
        end: Optional[str] = Query(None),
        page: Annotated[int, Query(ge=1)] = 1,
        page_size: Annotated[int, Query(ge=1, le=100)] = 20,
        scope: str = Query("service"),
    ):
        return await LogStore.query(
            tool=tool, status=status, start=start, end=end,
            page=page, page_size=page_size,
            scope=_resolve_scope(request, scope),
        )

    @app.get(
        "/logs/{log_id}/payload", operation_id="getLogPayload",
        include_in_schema=False, dependencies=[Depends(verify_auth)],
    )
    async def get_log_payload(request: Request, log_id: int, scope: str = Query("service")):
        payload = await LogStore.get_payload(log_id, scope=_resolve_scope(request, scope))
        if payload is None:
            raise HTTPException(status_code=404, detail="日志不存在或不属于当前 service")
        return payload

    @app.get(
        "/stats", summary="统计概览", operation_id="getStats",
        include_in_schema=False, dependencies=[Depends(verify_auth)],
    )
    async def get_stats(request: Request, range: str = Query("24h"), scope: str = Query("service")):
        if range not in ("24h", "7d", "30d"):
            raise HTTPException(status_code=400, detail="range 参数无效，支持: 24h, 7d, 30d")
        return await LogStore.stats(range, scope=_resolve_scope(request, scope))

    @app.get(
        "/load", summary="接口负载", operation_id="getLoad",
        include_in_schema=False, dependencies=[Depends(verify_auth)],
    )
    async def get_load(request: Request, scope: str = Query("service")):
        snapshot = LoadMonitor.snapshot()
        await LogStore.write_worker_heartbeat(snapshot)
        return await LogStore.load_workers(snapshot, scope=_resolve_scope(request, scope))

    @app.get(
        "/logs/stream", summary="实时日志流", operation_id="streamLogs",
        include_in_schema=False, dependencies=[Depends(verify_auth)],
    )
    async def stream_logs(request: Request):
        async def event_gen():
            queue: asyncio.Queue = asyncio.Queue(maxsize=200)

            async def _pump():
                try:
                    async for entry in LogStore.subscribe_iter():
                        try:
                            queue.put_nowait(entry)
                        except asyncio.QueueFull:
                            pass
                except asyncio.CancelledError:
                    pass

            pump_task = asyncio.create_task(_pump())
            try:
                while True:
                    try:
                        entry = await asyncio.wait_for(queue.get(), timeout=15.0)
                        data = json.dumps(entry, ensure_ascii=False)
                        yield f"event: log\ndata: {data}\n\n"
                    except asyncio.TimeoutError:
                        yield f"event: ping\ndata: {{}}\n\n"
            except asyncio.CancelledError:
                pass
            finally:
                pump_task.cancel()

        return StreamingResponse(
            event_gen(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.post(
        "/upload", summary="上传文件到 OSS",
        include_in_schema=False, dependencies=[Depends(verify_auth)],
    )
    async def upload_file(file: UploadFile = File(...)):
        chunks = []
        total = 0
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if max_upload_bytes > 0 and total > max_upload_bytes:
                raise HTTPException(
                    status_code=413,
                    detail=f"上传文件超过限制：最大 {max_upload_bytes // 1024 // 1024} MB",
                )
            chunks.append(chunk)
        data = b"".join(chunks)
        original_name = file.filename or "upload"
        from pathlib import Path as _Path
        ext = _Path(original_name).suffix or ""
        unique_name = f"upload/{uuid.uuid4().hex}{ext}"
        try:
            loop = asyncio.get_running_loop()
            oss = OSSClient()
            url = await loop.run_in_executor(None, lambda: oss.upload_bytes(data, unique_name))
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"OSS 上传失败: {e}") from e
        return {"url": url, "filename": original_name, "size": len(data)}

    @app.get("/mcp-info", include_in_schema=False)
    def mcp_info():
        return {
            "host": server_cfg.get("host", "0.0.0.0"),
            "port": server_cfg.get("mcp_port", 12346),
        }

    # ── Web 测试台 ───────────────────────────────────────────────────────────────
    if enable_web_ui and framework_static.exists():
        app.mount("/hub-assets", StaticFiles(directory=framework_static), name="hub_assets")

        @app.get("/", include_in_schema=False)
        def hub():
            return FileResponse(framework_static / "index.html")

        _favicon = framework_static / "favicon.ico"
        if _favicon.exists():
            @app.get("/favicon.ico", include_in_schema=False)
            def favicon():
                return FileResponse(_favicon)

    return app
