"""
插件发现 — 双轨机制

轨道 1: entry_points
    第三方工具包在 pyproject.toml 中声明：
        [project.entry-points."llm_toolforge.plugins"]
        my_tool = "my_pkg.tools.my_tool:plugin"
    安装后 toolforge 自动发现，无需修改 config.yaml。

轨道 2: 目录扫描
    config.yaml 中配置：
        plugins_dirs: [tools]    # 默认扫描 ./tools/
    每个含 __init__.py 并导出 plugin 对象的子目录都会被加载。

两轨合并，去重（按 operation_id）。
"""

import importlib
import importlib.metadata
import sys
from pathlib import Path

from .core.base import Plugin


def _import_from_path(directory: Path):
    """从文件系统目录动态加载包（适用于未安装的本地工具目录）。"""
    parent_str = str(directory.parent.resolve())
    if parent_str not in sys.path:
        sys.path.insert(0, parent_str)
    if directory.name in sys.modules:
        return sys.modules[directory.name]
    return importlib.import_module(directory.name)


def _scan_dir(scan_dir: Path, seen: set, result: list) -> None:
    if not scan_dir.exists():
        return
    for sub in sorted(scan_dir.iterdir()):
        if not sub.is_dir() or sub.name.startswith("_"):
            continue
        if not (sub / "__init__.py").exists():
            continue
        try:
            mod = _import_from_path(sub)
            if not hasattr(mod, "plugin"):
                continue
            op_id = getattr(mod.plugin, "operation_id", sub.name)
            if op_id not in seen:
                seen.add(op_id)
                result.append(mod.plugin)
        except Exception as e:
            print(f"[toolforge] 警告：加载 {sub} 失败：{e}")


def discover_plugins(config: dict) -> list[Plugin]:
    """发现所有插件，返回 Plugin 列表（operation_id 唯一）。

    Args:
        config: 已加载的 config.yaml 内容（dict）。
    """
    plugins: list[Plugin] = []
    seen: set[str] = set()

    # ── 轨道 1: entry_points ─────────────────────────────────────────────────
    try:
        for ep in importlib.metadata.entry_points(group="llm_toolforge.plugins"):
            try:
                obj = ep.load()
                op_id = getattr(obj, "operation_id", ep.name)
                if op_id not in seen:
                    seen.add(op_id)
                    plugins.append(obj)
            except Exception as e:
                print(f"[toolforge] 警告：entry_point '{ep.name}' 加载失败：{e}")
    except Exception:
        pass

    # ── 轨道 2: 目录扫描 ─────────────────────────────────────────────────────
    raw_dirs = config.get("plugins_dirs", ["tools"])
    if isinstance(raw_dirs, str):
        raw_dirs = [raw_dirs]

    for d in raw_dirs:
        scan = Path(d) if Path(d).is_absolute() else Path.cwd() / d
        _scan_dir(scan, seen, plugins)

    if not plugins:
        raise ValueError(
            "没有发现任何插件。\n"
            "请检查 config.yaml 的 plugins_dirs 配置，"
            "或在 tools/ 目录下创建工具（用 `toolforge new tool <name>` 生成骨架）。"
        )
    return plugins
