"""
框架核心抽象

仅包含数据类、枚举、抽象基类、异常。
无任何文件 I/O 或配置读取逻辑（那些在 llm_toolforge.config 中）。
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


# ─── 状态 / 结果 ──────────────────────────────────────────────────────────────

class ResultStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


@dataclass
class GenerateResult:
    """统一的生成结果。

    成功时 outputs 包含工具输出数据，message 为 None；
    失败时 outputs 为空 dict，message 为错误原因。
    token_usage 按模型名聚合：{model_name: {input, output, total}}，未用 LLM 时为空 dict。
    """
    status: ResultStatus
    outputs: dict = field(default_factory=dict)
    message: Optional[str] = None
    token_usage: dict = field(default_factory=dict)
    error_type: str = ""


@dataclass
class GenerateProgress:
    """流式进度事件，在 generate_stream() 中 yield。"""
    step: str
    message: str


# ─── 异常 ─────────────────────────────────────────────────────────────────────

class GeneratorError(Exception):
    """生成器基础异常"""


class LLMServiceError(GeneratorError):
    """LLM 服务本身不可用（网络 / 限流 / 鉴权）"""


class UploadError(GeneratorError):
    """文件上传失败"""


# ─── 输入字段定义 ──────────────────────────────────────────────────────────────

@dataclass
class InputField:
    """描述工具的一个输入参数。"""
    name: str
    type: type = str
    description: str = ""
    required: bool = True
    default: Any = None
    examples: list = field(default_factory=list)
    # 控制前端渲染控件类型：
    #   "text"  — 普通文本框（默认）
    #   "image" — 图片上传 + 预览
    #   "file"  — 文件上传，走 POST /upload → OSS，generator 收到 OSS URL
    # 不填则框架按字段名自动推断。
    kind: Optional[str] = None
    # kind="file" 时限制可选文件类型，格式同 HTML <input accept>
    accept: Optional[str] = None


# ─── 抽象基类 ─────────────────────────────────────────────────────────────────

class BaseGenerator(ABC):
    """
    所有工具的 Generator 必须继承此类，实现 generate() 方法。

    框架不限制构造函数签名，工具自行决定注入什么依赖。
    """

    @abstractmethod
    def generate(self, **kwargs) -> GenerateResult:
        ...

    def generate_stream(self, **kwargs):
        """产出进度和最终结果的生成器（可选覆写）。

        默认实现：将 generate() 包装为单步流，无需覆写也能走 SSE 端点。
        多步骤工具覆写此方法后可通过 yield GenerateProgress(...) 逐步推送进度。

        Yields:
            GenerateProgress — 中间进度（可多条）
            GenerateResult   — 最终结果（必须是最后一条 yield）
        """
        yield GenerateProgress(step="processing", message="处理中…")
        yield self.generate(**kwargs)


# ─── Plugin ───────────────────────────────────────────────────────────────────

@dataclass
class Plugin:
    """一个工具的完整定义，框架通过它自动装配 HTTP 路由、MCP tool、Web 表单。"""
    name: str
    description: str
    generator: BaseGenerator

    route_path: str
    operation_id: str
    route_summary: str

    inputs: list = field(default_factory=list)
    static_dir: Optional[Path] = None
