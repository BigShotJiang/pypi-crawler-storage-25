"""
AI客户端统一管理模块 (AI Client Module)

功能说明：
    统一管理多个AI服务提供商的客户端，提供统一的调用接口。
    支持阿里云、豆包、OpenAI和Gemini四个渠道。
    根据provider按需加载SDK，未使用的SDK不会被导入。

核心类：
    AIClient - AI客户端管理类

主要方法：
    chat(model, text, images=None, temperature=0.1, thinking=False) -> str
        发送聊天请求并返回AI响应（一站式调用）
        
使用示例：
    from ai_client import AIClient
    
    # 初始化客户端（指定provider）
    client = AIClient(provider="alibaba")
    
    # 方式1: 纯文本消息
    response = client.chat(model="qwen-plus", text="你好，介绍一下自己")
    
    # 方式2: 图文消息（本地文件，自动转base64）
    response = client.chat(
        model="qwen-vl-plus",
        text="这张图片是什么?",
        images=["photo.jpg"]  # 直接传文件路径
    )
    
    # 方式3: 使用 Gemini 渠道
    client = AIClient(provider="gemini")
    response = client.chat(
        model="gemini-3-pro-preview",
        text="描述这张图片",
        images=["photo.jpg"],
        thinking=True  # 开启深度思考
    )
    
    # 方式4: 多张图片（混合本地文件、URL和Base64）
    client = AIClient(provider="doubao")
    response = client.chat(
        model="doubao-vision",
        text="对比这些图片",
        images=[
            "photo1.jpg",  # 本地文件
            "http://example.com/2.jpg",  # URL
            "iVBORw0KGgo..."  # base64字符串
        ]
    )

注意事项：
    - 需要在config.yaml中配置对应的API密钥和地址
    - 不同provider支持的参数可能不同
    - 根据provider按需加载SDK，未使用的SDK不会被导入
"""

import os
import base64
import threading
from typing import List, Dict, Any, Optional, Union, Tuple
from dataclasses import dataclass, field, asdict
from loguru import logger
import yaml

from ..config import find_config


@dataclass
class ChatResult:
    """AI 调用结果，包含响应文本和 token 用量"""
    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""
    provider: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

os.environ['NO_PROXY'] = '*'
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''



class AIClient:
    """AI客户端统一管理类"""
    
    SUPPORTED_PROVIDERS = ["alibaba", "doubao", "openai", "gemini"]
    
    @staticmethod
    def _is_url(s: str) -> bool:
        """判断字符串是否为URL"""
        return s.startswith(('http://', 'https://'))
    
    @staticmethod
    def _is_base64_with_prefix(s: str) -> bool:
        """判断字符串是否为带data前缀的base64"""
        return s.startswith('data:image/')
    
    @staticmethod
    def _is_local_file(s: str) -> bool:
        """判断字符串是否为本地文件路径"""
        return os.path.isfile(s)
    
    @staticmethod
    def _process_image(img: Union[str, Tuple[str, str]]) -> str:
        """
        处理单个图片，返回可用的URL格式
        
        Args:
            img: 可以是文件路径、URL、base64字符串或(mime_type, base64_data)元组
        
        Returns:
            处理后的图片URL
        """
        if isinstance(img, tuple):
            # (mime_type, base64_data) 格式
            mime_type, base64_data = img
            return f"data:{mime_type};base64,{base64_data}"
        
        elif isinstance(img, str):
            # 判断是否为URL
            if AIClient._is_url(img):
                return img
            
            # 判断是否为带前缀的base64
            if AIClient._is_base64_with_prefix(img):
                return img
            
            # 判断是否为本地文件路径
            if AIClient._is_local_file(img):
                mime_type, base64_data = AIClient.encode_image_base64(img)
                return f"data:{mime_type};base64,{base64_data}"
            
            # 否则当作纯base64字符串处理，默认为jpeg
            return f"data:image/jpeg;base64,{img}"
        
        else:
            raise ValueError(f"不支持的图片格式: {type(img)}")
    
    @staticmethod
    def _build_image_content(images: List[Union[str, Tuple[str, str]]]) -> List[Dict[str, Any]]:
        """
        构建图片内容列表（通用格式）
        
        Args:
            images: 图片列表，支持：
                - 本地文件路径: "../images/test/1.jpg"
                - URL字符串: "http://example.com/image.jpg"
                - Base64字符串: "iVBORw0KGgo..."
                - (mime_type, base64_data)元组: ("image/jpeg", "iVBORw0KGgo...")
        
        Returns:
            图片内容列表
        """
        content = []
        for img in images:
            url = AIClient._process_image(img)
            content.append({
                "type": "image_url",
                "image_url": {"url": url}
            })
        return content
    
    @staticmethod
    def _create_alibaba_message(text: str, images: List[Union[str, Tuple[str, str]]] = None, role: str = "user") -> Dict[str, Any]:
        """
        创建阿里云格式的消息
        
        Args:
            text: 文本内容
            images: 图片列表（可选）
            role: 角色
        
        Returns:
            阿里云格式的消息字典
        """
        if images:
            content = AIClient._build_image_content(images)
            content.append({"type": "text", "text": text})
            return {"role": role, "content": content}
        else:
            return {"role": role, "content": text}
    
    @staticmethod
    def _create_doubao_message(text: str, images: List[Union[str, Tuple[str, str]]] = None, role: str = "user") -> Dict[str, Any]:
        """
        创建豆包格式的消息
        
        Args:
            text: 文本内容
            images: 图片列表（可选）
            role: 角色
        
        Returns:
            豆包格式的消息字典
        """
        if images:
            content = AIClient._build_image_content(images)
            content.append({"type": "text", "text": text})
            return {"role": role, "content": content}
        else:
            return {"role": role, "content": text}
    
    @staticmethod
    def _create_openai_message(text: str, images: List[Union[str, Tuple[str, str]]] = None, role: str = "user") -> Dict[str, Any]:
        """
        创建OpenAI格式的消息（responses.create格式）
        
        Args:
            text: 文本内容
            images: 图片列表（可选）
            role: 角色
        
        Returns:
            OpenAI格式的消息字典
        """
        if images:
            content = []
            # 先添加文本
            content.append({"type": "input_text", "text": text})
            # 再添加图片
            for img in images:
                url = AIClient._process_image(img)
                content.append({
                    "type": "input_image",
                    "image_url": url
                })
            return {"role": role, "content": content}
        else:
            return {"role": role, "content": text}
    
    def _build_gemini_parts(self, text: str, images: List[Union[str, Tuple[str, str]]] = None) -> List:
        """
        构建 Gemini API 需要的 parts 列表
        
        Args:
            text: 文本内容
            images: 图片列表（可选）
        
        Returns:
            types.Part 列表
        """
        types = self._genai_types
        parts = [types.Part(text=text)]
        
        if images:
            for img in images:
                if isinstance(img, tuple):
                    # (mime_type, base64_data) 格式
                    mime_type, base64_data = img
                elif os.path.isfile(img):
                    # 本地文件
                    mime_type, base64_data = self.encode_image_base64(img)
                elif self._is_base64_with_prefix(img):
                    # data:image/xxx;base64,xxx 格式
                    # 解析出 mime_type 和 base64_data
                    prefix, base64_data = img.split(',', 1)
                    mime_type = prefix.split(':')[1].split(';')[0]
                else:
                    # 纯 base64 字符串，默认 jpeg
                    mime_type = "image/jpeg"
                    base64_data = img
                
                parts.append(types.Part(
                    inline_data=types.Blob(
                        mime_type=mime_type,
                        data=base64_data
                    )
                ))
        
        return parts
    
    @staticmethod
    def encode_image_base64(image_path: str) -> Tuple[str, str]:
        """
        将图片文件编码为base64
        
        Args:
            image_path: 图片文件路径
        
        Returns:
            (mime_type, base64_data) 元组
        
        Examples:
            >>> mime_type, base64_data = AIClient.encode_image_base64("photo.jpg")
            >>> msg = client.create_message("分析图片", 
            ...     images=[(mime_type, base64_data)]
            ... )
        """
        # 根据文件扩展名推断MIME类型
        ext = os.path.splitext(image_path)[1].lower()
        mime_types = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.webp': 'image/webp',
            '.bmp': 'image/bmp'
        }
        mime_type = mime_types.get(ext, 'image/jpeg')
        
        # 读取并编码
        with open(image_path, 'rb') as f:
            base64_data = base64.b64encode(f.read()).decode('utf-8')
        
        return mime_type, base64_data
    
    def __init__(self, provider: str = "alibaba", config_path: str = None):
        """
        初始化AI客户端
        
        Args:
            provider: AI服务提供商，支持 "alibaba", "doubao", "openai"
            config_path: 已弃用，不再使用。AI渠道配置现在从 config.yaml 加载
        Raises:
            ValueError: 当配置不正确或provider不支持时抛出
        """
        if provider not in self.SUPPORTED_PROVIDERS:
            raise ValueError(f"不支持的provider: {provider}，支持的有: {self.SUPPORTED_PROVIDERS}")
        
        self.provider = provider
        self._client = None
        self._usage_state = threading.local()
        
        # 加载配置文件（从 config.yaml 加载 AI 渠道配置）
        interface_path = str(find_config())

        with open(interface_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        self._config = config["ai_providers"][provider]
        default_timeout = float((config.get("server") or {}).get("ai_request_timeout_s", 120))
        self._timeout = float(self._config.get("timeout_s", default_timeout))
        
        # 按需初始化客户端（延迟加载SDK）
        self._init_client()
        
        # logger.info(f"[AI客户端] 初始化完成，使用 {provider} 提供商")
    
    def _init_client(self):
        """根据provider按需初始化客户端，延迟加载SDK"""
        if self.provider == "alibaba":
            from openai import OpenAI
            self._client = OpenAI(
                api_key=self._config["key"],
                base_url=self._config["base_url"],
                timeout=self._timeout,
            )
        elif self.provider == "doubao":
            from volcenginesdkarkruntime import Ark
            self._client = Ark(
                api_key=self._config["key"],
                base_url=self._config["base_url"],
                timeout=self._timeout,
            )
        elif self.provider == "openai":
            import httpx
            from openai import OpenAI
            http_client = httpx.Client(
                timeout=self._timeout,
                limits=httpx.Limits(max_keepalive_connections=5, max_connections=10)
            )
            self._client = OpenAI(
                http_client=http_client,
                api_key=self._config["key"],
                base_url=self._config["base_url"],
                timeout=self._timeout,
            )
        elif self.provider == "gemini":
            from google import genai
            from google.genai import types
            self._genai_types = types  # 保存 types 模块供后续使用
            http_options = {"base_url": self._config["base_url"]}
            if self._timeout > 0:
                http_options["timeout"] = int(self._timeout * 1000)
            try:
                options = types.HttpOptions(**http_options)
            except TypeError:
                options = types.HttpOptions(base_url=self._config["base_url"])
            self._client = genai.Client(
                http_options=options,
                api_key=self._config["key"]
            )
    
    def reset_usage(self) -> None:
        """重置当前线程的 token 用量累加器，每次请求开头调用。"""
        self._usage_state.usage = {}

    def get_usage(self) -> dict:
        """返回当前线程累计的 token 用量，格式：{model_name: {input, output, total}}。"""
        usage = getattr(self._usage_state, "usage", None)
        if not usage:
            return {}
        return {k: dict(v) for k, v in usage.items()}

    def _record_usage(self, model: str, input_tokens: int, output_tokens: int) -> None:
        """将本次调用的 token 计入当前线程的累加器。"""
        usage = getattr(self._usage_state, "usage", None)
        if usage is None:
            usage = {}
            self._usage_state.usage = usage
        slot = usage.setdefault(model, {"input": 0, "output": 0, "total": 0})
        slot["input"] += int(input_tokens or 0)
        slot["output"] += int(output_tokens or 0)
        slot["total"] = slot["input"] + slot["output"]

    def create_message(self, text: str, images: List[Union[str, Tuple[str, str]]] = None) -> List[Dict[str, Any]]:
        """
        创建消息列表（根据初始化时的provider确定格式）
        
        Args:
            text: 文本内容（必填，只支持单个文本）
            images: 图片列表（可选，支持多个），自动识别类型：
                - 本地文件路径: "../images/test/1.jpg" (自动读取并转base64)
                - URL字符串: "http://example.com/image.jpg"
                - Base64字符串: "iVBORw0KGgo..."
                - (mime_type, base64_data)元组: ("image/jpeg", "iVBORw0KGgo...")
        
        Returns:
            消息列表 [{"role": "user", "content": ...}]
        
        Examples:
            >>> # 纯文本
            >>> client = AIClient(provider="alibaba")
            >>> client.create_message("你好")
            [{"role": "user", "content": "你好"}]
            
            >>> # 单张本地图片（自动转base64）
            >>> client.create_message("这是什么?", 
            ...     images=["../images/test/1.jpg"]
            ... )
            
            >>> # 单张URL图片
            >>> client.create_message("分析图片", 
            ...     images=["http://example.com/img.jpg"]
            ... )
            
            >>> # 多张图片（混合本地文件、URL和Base64）
            >>> client.create_message("对比这些图片",
            ...     images=[
            ...         "../images/test/1.jpg",  # 本地文件
            ...         "http://example.com/2.jpg",  # URL
            ...         "iVBORw0KGgo..."  # base64
            ...     ]
            ... )
        """
        role = "user"
        if self.provider == "alibaba":
            msg = AIClient._create_alibaba_message(text, images, role)
        elif self.provider == "doubao":
            msg = AIClient._create_doubao_message(text, images, role)
        elif self.provider == "openai":
            msg = AIClient._create_openai_message(text, images, role)
        elif self.provider == "gemini":
            # Gemini 使用 parts 格式，在 chat 中直接构建
            return self._build_gemini_parts(text, images)
        
        return [msg]
    
    def chat(
        self, 
        model: str, 
        text: str, 
        images: List[Union[str, Tuple[str, str]]] = None,
        temperature: float = 0.1, 
        thinking: bool = False
    ) -> ChatResult:
        """
        发送聊天请求（一站式调用，无需单独创建消息）
        
        Args:
            model: 指定使用的模型
            text: 文本内容
            images: 图片列表（可选），自动识别类型：
                - 本地文件路径: "../images/test/1.jpg" (自动读取并转base64)
                - URL字符串: "http://example.com/image.jpg"
                - Base64字符串: "iVBORw0KGgo..."
                - (mime_type, base64_data)元组: ("image/jpeg", "iVBORw0KGgo...")
            temperature: 温度参数，控制随机性
            thinking: 是否使用深度思考能力
            
        Returns:
            ChatResult: 包含响应文本和 token 用量信息
    
        Raises:
            Exception: 当API调用失败时抛出
            
        Examples:
            >>> # 纯文本对话
            >>> client = AIClient(provider="alibaba")
            >>> result = client.chat(model="qwen-plus", text="你好")
            >>> print(result.text)  # 响应文本
            >>> print(result.input_tokens, result.output_tokens)  # token 用量
            
            >>> # 图文对话
            >>> result = client.chat(
            ...     model="qwen-vl-plus",
            ...     text="这张图片是什么?",
            ...     images=["photo.jpg"]
            ... )
        """
        # 构建消息
        messages = self.create_message(text, images)
        
        try:
            if self.provider == "doubao":
                # 豆包可能支持thinking参数
                if thinking:
                    thinking_config = {"type": "enabled"}
                else:
                    thinking_config = {"type": "disabled"}
                completion = self._client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    thinking=thinking_config,
                )
                # 提取 usage
                usage = getattr(completion, 'usage', None)
                input_tokens = getattr(usage, 'prompt_tokens', 0) if usage else 0
                output_tokens = getattr(usage, 'completion_tokens', 0) if usage else 0
                
                self._record_usage(model, input_tokens, output_tokens)
                return ChatResult(
                    text=completion.choices[0].message.content.strip(),
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    provider=self.provider
                )
            
            elif self.provider == "alibaba":
                if thinking:
                    extra_body = {'enable_thinking': True, "thinking_budget": 81920}
                else:
                    extra_body = {'enable_thinking': False, "thinking_budget": 0}

                completion = self._client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    extra_body=extra_body,
                )
                # 提取 usage
                usage = getattr(completion, 'usage', None)
                input_tokens = getattr(usage, 'prompt_tokens', 0) if usage else 0
                output_tokens = getattr(usage, 'completion_tokens', 0) if usage else 0
                
                self._record_usage(model, input_tokens, output_tokens)
                return ChatResult(
                    text=completion.choices[0].message.content.strip(),
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    provider=self.provider
                )

            elif self.provider == "openai":
                if thinking:
                    reasoning = {"effort": "medium"}
                else:
                    reasoning = {"effort": "none"}
                response = self._client.responses.create(
                    model=model,
                    input=messages,
                    reasoning=reasoning
                )
                # OpenAI responses API usage 结构
                usage = getattr(response, 'usage', None)
                input_tokens = getattr(usage, 'input_tokens', 0) if usage else 0
                output_tokens = getattr(usage, 'output_tokens', 0) if usage else 0
                
                self._record_usage(model, input_tokens, output_tokens)
                return ChatResult(
                    text=response.output_text.strip(),
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    provider=self.provider
                )
            
            elif self.provider == "gemini":
                types = self._genai_types
                # Gemini 的 thinking 映射
                thinking_level = "medium" if thinking else "none"
                response = self._client.models.generate_content(
                    model=model,
                    contents=[types.Content(parts=messages)],
                    config=types.GenerateContentConfig(
                        thinking_config=types.ThinkingConfig(thinking_level=thinking_level)
                    )
                )
                # Gemini usage_metadata
                usage = getattr(response, 'usage_metadata', None)
                input_tokens = getattr(usage, 'prompt_token_count', 0) if usage else 0
                output_tokens = getattr(usage, 'candidates_token_count', 0) if usage else 0
                
                self._record_usage(model, input_tokens, output_tokens)
                return ChatResult(
                    text=response.text.strip() if response.text else "",
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    provider=self.provider
                )

        except Exception as e:
            logger.error(f"[AI客户端] API调用失败: {e}")
            raise e


if __name__ == "__main__":
    import time
    
    #测试豆包客户端
    print("测试豆包客户端")
    doubao_client = AIClient(provider="doubao")
    start_time = time.time()
    response = doubao_client.chat(
        model="doubao-seed-1-8",
        text="分析这张图片",
        images=["../images/test/1.jpg"]
    )
    print(response)
    end_time = time.time()
    print(f"豆包客户端耗时: {end_time - start_time}秒\n")

    # 测试阿里云客户端
    # print("测试阿里云客户端")
    # alibaba_client = AIClient(provider="alibaba")
    # start_time = time.time()
    # response = alibaba_client.chat(
    #     model="qwen3-vl-plus",
    #     text="分析这张图片",
    #     images=["../images/test/TEST.jpg"]
    # )
    # print(response)
    # end_time = time.time()
    # print(f"阿里云客户端耗时: {end_time - start_time}秒\n")

    # # 测试OpenAI客户端
    # print("测试OpenAI客户端")
    # openai_client = AIClient(provider="openai")
    # start_time = time.time()
    # response = openai_client.chat(
    #     model="gpt-5.1",
    #     text="分析这张图片",
    #     images=["../images/test/1.jpg"],
    #     thinking=True
    # )
    # print(response)
    # end_time = time.time()
    # print(f"OpenAI客户端耗时: {end_time - start_time}秒")

    # print("测试Gemini客户端")
    # gemini_client = AIClient(provider="gemini")
    # start_time = time.time()
    # response = gemini_client.chat(
    #     model="gemini-3-pro-preview",
    #     text="OCR这张图片",
    #     images=["../images/test/TEST.jpg"]
    #     # thinking=True
    # )
    # print(response)
    # end_time = time.time()
    # print(f"Gemini客户端耗时: {end_time - start_time}秒")