"""
调用日志存储模块（v2：service 隔离 + 批量写 + Redis 协同）

变更要点（相对老版本）：
  1. 新表 tool_call_events，强制带 service_name / instance_id 字段；按月 RANGE 分区。
  2. 写入走内存队列 + 后台 flusher，单 SQL 多 VALUES，降低 MySQL 压力。
  3. 心跳 / 实时流 / stats 缓存全部下沉到 Redis，跨 Pod 一致。
  4. /logs /stats /load 默认按当前 service 过滤；运维全局视图通过 scope=global + admin token。
  5. p95/p99 改为采样 + DB 端聚合，不再把 elapsed_ms 全表拉到 Python。
  6. TTL 后台任务按月 DROP 老分区（O(1)，不锁表），失败自动降级 DELETE。

老表 ai_tool_log 不动；新表名由 mysql.table_name 控制（默认 tool_call_events）。
"""

from __future__ import annotations

import asyncio
import json
import os
import time as _time
from datetime import datetime, timedelta
from typing import Optional

from loguru import logger

from .redis_client import RedisClient


class LogStore:
    _backend: Optional[str] = None        # "mysql" | "sqlite" | "disabled"
    _pool = None                           # aiomysql 连接池
    _sqlite_path: Optional[str] = None
    _table: str = "tool_call_events"
    _max_output_size: int = 0

    # 批量写
    _write_queue: Optional[asyncio.Queue] = None
    _flusher_task: Optional[asyncio.Task] = None
    _ttl_task: Optional[asyncio.Task] = None
    _batch_size: int = 100
    _batch_flush_ms: int = 1000
    _retention_days: int = 90

    # 心跳
    _heartbeat_ttl_s: int = 15

    # service 标识
    _service_name: str = ""
    _service_version: str = ""
    _instance_id: str = ""
    _admin_token: str = ""

    # stats 本地兜底缓存（Redis 不可用时使用，进程级）
    _stats_local_cache: dict = {}
    _STATS_CACHE_TTL: int = 60

    # ── 初始化 ────────────────────────────────────────────────────────────────

    @classmethod
    async def setup(cls, config: dict) -> None:
        """
        初始化存储后端、Redis、批量写后台任务、TTL 后台任务。

        service_name 解析顺序：环境变量 SERVICE_NAME > config.service.name；
        都缺失时 fail-fast，避免上线后跨部署串数据。
        """
        log_cfg: dict = config.get("logging", {})
        storage = log_cfg.get("storage", "disabled")
        cls._max_output_size = int(log_cfg.get("max_output_size", 0))
        cls._batch_size = int(log_cfg.get("batch_size", 100))
        cls._batch_flush_ms = int(log_cfg.get("batch_flush_ms", 1000))
        cls._retention_days = int(log_cfg.get("retention_days", 90))
        cls._heartbeat_ttl_s = int(log_cfg.get("heartbeat_ttl_s", 15))

        svc_cfg: dict = config.get("service") or {}
        cls._service_name = (
            os.getenv("SERVICE_NAME")
            or str(svc_cfg.get("name") or "").strip()
        )
        cls._service_version = (
            os.getenv("SERVICE_VERSION")
            or str(svc_cfg.get("version") or "").strip()
        )
        if not cls._service_name:
            raise RuntimeError(
                "[LogStore] 必须配置 service.name 或 SERVICE_NAME 环境变量，"
                "用于隔离不同部署的日志/统计/心跳，避免跨服务串数据"
            )

        cls._admin_token = str((config.get("server") or {}).get("global_admin_token") or "")

        if storage == "disabled":
            cls._backend = "disabled"
            logger.info("[LogStore] 日志存储已禁用")
            return

        if storage == "mysql":
            await cls._setup_mysql(config)
        elif storage == "sqlite":
            await cls._setup_sqlite(log_cfg)
        else:
            raise ValueError(
                f"[LogStore] 未知的 storage 类型: {storage!r}，支持 mysql / sqlite / disabled"
            )

        cls._backend = storage

        # Redis 是新方案的强依赖（心跳 / 实时流 / 缓存），失败 fail-fast
        await RedisClient.setup(config, cls._service_name)

        # 启动后台任务（同进程多次 setup 时先 cancel 旧任务，避免重复跑）
        cls._write_queue = asyncio.Queue(maxsize=10000)
        if cls._flusher_task and not cls._flusher_task.done():
            cls._flusher_task.cancel()
        cls._flusher_task = asyncio.create_task(cls._flush_loop())

        if cls._ttl_task and not cls._ttl_task.done():
            cls._ttl_task.cancel()
        if cls._retention_days > 0:
            cls._ttl_task = asyncio.create_task(cls._ttl_loop())

        logger.info(
            f"[LogStore] setup 完成 service={cls._service_name} backend={cls._backend} "
            f"batch={cls._batch_size}/{cls._batch_flush_ms}ms retention={cls._retention_days}d"
        )

    @classmethod
    async def _setup_mysql(cls, config: dict) -> None:
        import aiomysql

        mysql_cfg: dict = config.get("mysql", {})
        # 老配置 table_name=ai_tool_log；为避免读到老表 schema，强制使用新表名
        # 用户想自定义可在 config 显式传 events_table
        cls._table = mysql_cfg.get("events_table") or "tool_call_events"

        try:
            cls._pool = await aiomysql.create_pool(
                host=mysql_cfg["host"],
                port=int(mysql_cfg.get("port", 3306)),
                user=mysql_cfg["username"],
                password=mysql_cfg["password"],
                db=mysql_cfg["database"],
                charset="utf8mb4",
                autocommit=True,
                minsize=1,
                maxsize=int(mysql_cfg.get("pool_max", 10)),
            )
            await cls._create_table_mysql()
            logger.info(f"[LogStore] MySQL 连接成功，表: {cls._table}")
        except Exception as e:
            raise RuntimeError(f"[LogStore] MySQL 连接失败，服务无法启动: {e}") from e

    @classmethod
    async def _setup_sqlite(cls, log_cfg: dict) -> None:
        import aiosqlite

        cls._sqlite_path = log_cfg.get("sqlite_path", "logs.db")
        try:
            async with aiosqlite.connect(cls._sqlite_path) as db:
                await cls._create_table_sqlite(db)
            logger.info(f"[LogStore] SQLite 初始化成功: {cls._sqlite_path}")
        except Exception as e:
            raise RuntimeError(f"[LogStore] SQLite 初始化失败，服务无法启动: {e}") from e

    @classmethod
    def set_instance_id(cls, instance_id: str) -> None:
        """LoadMonitor.setup 之后调用，让 write() 自动补 instance_id。"""
        cls._instance_id = str(instance_id or "")

    @classmethod
    async def shutdown(cls) -> None:
        """优雅关停：把队列里剩余日志 flush 完再退出，避免丢日志。"""
        for task in (cls._flusher_task, cls._ttl_task):
            if task and not task.done():
                task.cancel()
        if cls._write_queue is not None:
            remaining = []
            while True:
                try:
                    remaining.append(cls._write_queue.get_nowait())
                except asyncio.QueueEmpty:
                    break
            if remaining:
                try:
                    await cls._flush_batch(remaining)
                except Exception as e:
                    logger.warning(f"[LogStore] shutdown flush 失败，可能丢失 {len(remaining)} 条日志: {e}")
        await RedisClient.close()

    @classmethod
    async def health(cls) -> dict:
        """
        返回日志/协同依赖的就绪状态。

        healthz 只证明进程活着；readyz 使用这里的结果决定是否接业务流量。
        """
        checks: dict[str, dict] = {}

        if cls._backend == "disabled":
            checks["log_store"] = {
                "ok": True,
                "backend": "disabled",
                "message": "logging disabled",
            }
            return {"ok": True, "checks": checks}

        if not cls._backend:
            checks["log_store"] = {
                "ok": False,
                "backend": None,
                "message": "log store not initialized",
            }
            return {"ok": False, "checks": checks}

        if cls._backend == "mysql":
            checks["mysql"] = await cls._check_mysql()
        elif cls._backend == "sqlite":
            checks["sqlite"] = await cls._check_sqlite()
        else:
            checks["log_store"] = {
                "ok": False,
                "backend": cls._backend,
                "message": f"unknown backend {cls._backend!r}",
            }

        redis_ok, redis_msg = await RedisClient.ping()
        checks["redis"] = {"ok": redis_ok, "message": redis_msg}

        queue_size = cls._write_queue.qsize() if cls._write_queue is not None else 0
        queue_max = cls._write_queue.maxsize if cls._write_queue is not None else 0
        flusher_alive = bool(cls._flusher_task and not cls._flusher_task.done())
        checks["log_queue"] = {
            "ok": cls._write_queue is not None and flusher_alive,
            "size": queue_size,
            "max_size": queue_max,
            "flusher_alive": flusher_alive,
        }

        return {
            "ok": all(item.get("ok", False) for item in checks.values()),
            "checks": checks,
        }

    @classmethod
    async def _check_mysql(cls) -> dict:
        if cls._pool is None:
            return {"ok": False, "backend": "mysql", "message": "pool not initialized"}
        try:
            async with cls._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("SELECT 1")
                    await cur.fetchone()
            return {"ok": True, "backend": "mysql", "message": "ok"}
        except Exception as e:
            return {"ok": False, "backend": "mysql", "message": str(e)}

    @classmethod
    async def _check_sqlite(cls) -> dict:
        if not cls._sqlite_path:
            return {"ok": False, "backend": "sqlite", "message": "sqlite path not initialized"}
        try:
            import aiosqlite

            async with aiosqlite.connect(cls._sqlite_path) as db:
                await db.execute("SELECT 1")
            return {"ok": True, "backend": "sqlite", "message": "ok"}
        except Exception as e:
            return {"ok": False, "backend": "sqlite", "message": str(e)}

    # ── 建表 ──────────────────────────────────────────────────────────────────

    # 字段注释集中维护：建表 / 在线补注释复用同一份，避免漂移
    _MYSQL_COLUMN_COMMENTS: list[tuple[str, str, str]] = [
        ("id",              "BIGINT       NOT NULL AUTO_INCREMENT",        "自增主键"),
        ("service_name",    "VARCHAR(64)  NOT NULL",                       "服务名（隔离不同部署的日志/统计/心跳）"),
        ("service_version", "VARCHAR(32)            DEFAULT ''",            "服务版本号"),
        ("instance_id",     "VARCHAR(128) NOT NULL",                       "实例 ID（同一 service 下区分多 Pod/进程）"),
        ("request_id",      "VARCHAR(64)  NOT NULL",                       "请求 ID（贯穿一次工具调用，用于链路追踪）"),
        ("tool_name",       "VARCHAR(128) NOT NULL",                       "被调用的工具名"),
        ("status",          "VARCHAR(16)  NOT NULL",                       "调用状态：success / error"),
        ("error_type",      "VARCHAR(64)            DEFAULT ''",            "错误类型（异常类名或业务错误码），成功时为空"),
        ("error_msg",       "TEXT",                                        "错误信息文本，成功时为 NULL"),
        ("elapsed_ms",      "INT",                                         "工具执行耗时（毫秒）"),
        ("client_ip",       "VARCHAR(64)",                                 "调用方客户端 IP"),
        ("input_size",      "INT                    DEFAULT 0",            "输入参数序列化后的字节数"),
        ("output_size",     "INT                    DEFAULT 0",            "输出内容字节数（受 max_output_size 截断）"),
        ("input_params",    "MEDIUMTEXT",                                  "工具调用的输入参数（JSON 文本）"),
        ("output",          "MEDIUMTEXT",                                  "工具调用的输出内容（可能被截断）"),
        ("created_at",      "DATETIME     NOT NULL",                       "记录创建时间（分区键，主键的一部分）"),
    ]
    _MYSQL_TABLE_COMMENT = "工具调用事件日志（按月 RANGE 分区，多 service 共用）"

    @classmethod
    async def _create_table_mysql(cls) -> None:
        # 主键含 created_at 是分区表硬性要求（PARTITION BY 列必须在主键里）
        # 提前预留 12 个月分区 + pmax，TTL 任务再周期补未来分区
        partitions_sql = cls._initial_partitions_sql()
        columns_sql = ",\n            ".join(
            f"`{name}` {type_def} COMMENT '{comment}'"
            for name, type_def, comment in cls._MYSQL_COLUMN_COMMENTS
        )
        sql = f"""
        CREATE TABLE IF NOT EXISTS `{cls._table}` (
            {columns_sql},
            PRIMARY KEY (`id`, `created_at`),
            KEY `idx_svc_created`        (`service_name`, `created_at`),
            KEY `idx_svc_tool_created`   (`service_name`, `tool_name`, `created_at`),
            KEY `idx_svc_status_created` (`service_name`, `status`, `created_at`),
            KEY `idx_request`            (`request_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='{cls._MYSQL_TABLE_COMMENT}'
        PARTITION BY RANGE (TO_DAYS(`created_at`)) (
            {partitions_sql}
        )
        """
        async with cls._pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SET SESSION sql_notes = 0")
                try:
                    try:
                        await cur.execute(sql)
                    except Exception as e:
                        # 表已存在但建表 SQL 失败时（例如手工建过非分区表）忽略；
                        # 业务字段缺失会在第一次写入抛错暴露
                        await cur.execute(f"SHOW TABLES LIKE %s", (cls._table,))
                        if not await cur.fetchone():
                            raise
                        logger.info(f"[LogStore] 表 {cls._table} 已存在，跳过分区建表: {e}")
                finally:
                    await cur.execute("SET SESSION sql_notes = 1")

        # 老表升级：在线补齐 表注释 / 字段注释（COMMENT 修改不锁表数据，仅改元数据）
        try:
            await cls._ensure_mysql_comments()
        except Exception as e:
            logger.warning(f"[LogStore] 同步表/字段注释失败（不影响业务）: {e}")

    @classmethod
    async def _ensure_mysql_comments(cls) -> None:
        """
        为已存在的表补齐表注释和字段注释。
        - 表注释：直接 ALTER TABLE ... COMMENT='...'（幂等）
        - 字段注释：仅在 information_schema.COLUMNS.COLUMN_COMMENT 为空且字段存在时
          执行 MODIFY COLUMN，避免覆盖 DBA 手工写过的注释，也避免误改字段类型。
        """
        import aiomysql

        async with cls._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(
                    "SELECT COLUMN_NAME, COLUMN_COMMENT "
                    "FROM information_schema.COLUMNS "
                    "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s",
                    (cls._table,),
                )
                existing = {r["COLUMN_NAME"]: (r["COLUMN_COMMENT"] or "") for r in await cur.fetchall()}
                if not existing:
                    return

                await cur.execute(
                    f"ALTER TABLE `{cls._table}` COMMENT = '{cls._MYSQL_TABLE_COMMENT}'"
                )

                for name, type_def, comment in cls._MYSQL_COLUMN_COMMENTS:
                    if name not in existing:
                        continue
                    if existing[name].strip():
                        continue
                    safe_comment = comment.replace("'", "''")
                    try:
                        await cur.execute(
                            f"ALTER TABLE `{cls._table}` "
                            f"MODIFY COLUMN `{name}` {type_def} COMMENT '{safe_comment}'"
                        )
                    except Exception as e:
                        logger.warning(f"[LogStore] 补字段 {name} 注释失败: {e}")

    @staticmethod
    def _month_partition_def(year: int, month: int) -> tuple[str, str]:
        """返回 (分区名, LESS THAN 表达式) 二元组。"""
        if month == 12:
            ny, nm = year + 1, 1
        else:
            ny, nm = year, month + 1
        next_first = f"{ny:04d}-{nm:02d}-01"
        return f"p{year:04d}{month:02d}", f"TO_DAYS('{next_first}')"

    @classmethod
    def _initial_partitions_sql(cls) -> str:
        """生成首批 12 个月 + pmax 分区定义。"""
        now = datetime.now()
        parts = []
        y, m = now.year, now.month
        for _ in range(12):
            name, expr = cls._month_partition_def(y, m)
            parts.append(f"PARTITION {name} VALUES LESS THAN ({expr})")
            m += 1
            if m > 12:
                m = 1
                y += 1
        parts.append("PARTITION pmax VALUES LESS THAN MAXVALUE")
        return ",\n            ".join(parts)

    @classmethod
    async def _create_table_sqlite(cls, db) -> None:
        t = cls._table
        await db.execute(f"""
        CREATE TABLE IF NOT EXISTS {t} (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            service_name    TEXT NOT NULL,
            service_version TEXT DEFAULT '',
            instance_id     TEXT NOT NULL,
            request_id      TEXT NOT NULL,
            tool_name       TEXT NOT NULL,
            status          TEXT NOT NULL,
            error_type      TEXT DEFAULT '',
            error_msg       TEXT,
            elapsed_ms      INTEGER,
            client_ip       TEXT,
            input_size      INTEGER DEFAULT 0,
            output_size     INTEGER DEFAULT 0,
            input_params    TEXT,
            output          TEXT,
            created_at      TEXT NOT NULL
        )""")
        await db.execute(f"CREATE INDEX IF NOT EXISTS idx_svc_created ON {t}(service_name, created_at)")
        await db.execute(f"CREATE INDEX IF NOT EXISTS idx_svc_tool ON {t}(service_name, tool_name, created_at)")
        await db.execute(f"CREATE INDEX IF NOT EXISTS idx_svc_status ON {t}(service_name, status, created_at)")
        await db.execute(f"CREATE INDEX IF NOT EXISTS idx_request ON {t}(request_id)")
        await db.commit()

    # ── 写入：入队 + 批量 flush ───────────────────────────────────────────────

    @classmethod
    async def write(cls, entry: dict) -> None:
        """fire-and-forget 写入。把条目入队，由后台 flusher 批量落库 + Redis publish。"""
        if not cls._backend or cls._backend == "disabled":
            return
        if cls._write_queue is None:
            return
        try:
            entry.setdefault("service_name", cls._service_name)
            entry.setdefault("service_version", cls._service_version)
            entry.setdefault("instance_id", cls._instance_id)
            entry["created_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            output = entry.get("output") or ""
            if cls._max_output_size > 0 and len(output) > cls._max_output_size:
                output = output[: cls._max_output_size]
                entry["output"] = output
            entry["output_size"] = len(output)
            entry["input_size"] = len(entry.get("input_params") or "")

            # 实时 publish 不走批量队列：订阅者要的是低延迟
            await RedisClient.publish_log(cls._build_broadcast(entry))

            try:
                cls._write_queue.put_nowait(entry)
            except asyncio.QueueFull:
                logger.warning("[LogStore] 写入队列已满（10000），丢弃 1 条日志")
        except Exception as e:
            logger.warning(f"[LogStore] 入队失败: {e}")

    @staticmethod
    def _build_broadcast(entry: dict) -> dict:
        out = entry.get("output") or ""
        return {
            "service_name":  entry.get("service_name", ""),
            "instance_id":   entry.get("instance_id", ""),
            "tool_name":     entry.get("tool_name", ""),
            "status":        entry.get("status", ""),
            "elapsed_ms":    entry.get("elapsed_ms"),
            "error_type":    entry.get("error_type", ""),
            "client_ip":     entry.get("client_ip", ""),
            "created_at":    entry.get("created_at", ""),
            "input_params":  (entry.get("input_params") or "")[:500],
            "output":        out[:500],
            "error_msg":     entry.get("error_msg") or "",
            "request_id":    entry.get("request_id", ""),
        }

    @classmethod
    async def _flush_loop(cls) -> None:
        """后台 flusher：攒够 batch_size 或超时 batch_flush_ms 立即 flush。"""
        try:
            while True:
                batch: list[dict] = []
                try:
                    first = await cls._write_queue.get()
                    batch.append(first)
                except asyncio.CancelledError:
                    break

                deadline = _time.monotonic() + cls._batch_flush_ms / 1000
                while len(batch) < cls._batch_size:
                    timeout = max(0.0, deadline - _time.monotonic())
                    if timeout == 0.0:
                        break
                    try:
                        item = await asyncio.wait_for(cls._write_queue.get(), timeout=timeout)
                        batch.append(item)
                    except asyncio.TimeoutError:
                        break

                try:
                    await cls._flush_batch(batch)
                except Exception as e:
                    logger.warning(f"[LogStore] flush {len(batch)} 条失败: {e}")
        except asyncio.CancelledError:
            return

    @classmethod
    async def _flush_batch(cls, batch: list[dict]) -> None:
        if not batch:
            return
        if cls._backend == "mysql":
            await cls._flush_batch_mysql(batch)
        elif cls._backend == "sqlite":
            await cls._flush_batch_sqlite(batch)

    @classmethod
    async def _flush_batch_mysql(cls, batch: list[dict]) -> None:
        cols = (
            "service_name, service_version, instance_id, request_id, tool_name, "
            "status, error_type, error_msg, elapsed_ms, client_ip, "
            "input_size, output_size, input_params, output, created_at"
        )
        placeholders = "(" + ",".join(["%s"] * 15) + ")"
        sql = f"INSERT INTO `{cls._table}` ({cols}) VALUES {placeholders}"
        rows = [cls._row_tuple(e) for e in batch]
        async with cls._pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.executemany(sql, rows)

    @classmethod
    async def _flush_batch_sqlite(cls, batch: list[dict]) -> None:
        import aiosqlite
        cols = (
            "service_name, service_version, instance_id, request_id, tool_name, "
            "status, error_type, error_msg, elapsed_ms, client_ip, "
            "input_size, output_size, input_params, output, created_at"
        )
        placeholders = "(" + ",".join(["?"] * 15) + ")"
        sql = f"INSERT INTO {cls._table} ({cols}) VALUES {placeholders}"
        rows = [cls._row_tuple(e) for e in batch]
        async with aiosqlite.connect(cls._sqlite_path) as db:
            await db.executemany(sql, rows)
            await db.commit()

    @staticmethod
    def _row_tuple(e: dict) -> tuple:
        return (
            e.get("service_name", ""),
            e.get("service_version", ""),
            e.get("instance_id", ""),
            e.get("request_id", ""),
            e.get("tool_name", ""),
            e.get("status", ""),
            e.get("error_type") or "",
            e.get("error_msg"),
            e.get("elapsed_ms"),
            e.get("client_ip"),
            int(e.get("input_size") or 0),
            int(e.get("output_size") or 0),
            e.get("input_params", ""),
            e.get("output", ""),
            e.get("created_at"),
        )

    # ── 查询：列表 ────────────────────────────────────────────────────────────

    @classmethod
    async def query(
        cls,
        tool: Optional[str] = None,
        status: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
        scope: str = "service",
    ) -> dict:
        """
        scope:
          "service" — 默认，仅查当前 service
          "global"  — 跨 service 查询，由路由层校验 admin token
        列表查询不返回 input_params/output 大字段，避免列表页拖垮查询。
        """
        if not cls._backend or cls._backend == "disabled":
            return {"total": 0, "items": []}

        if cls._backend == "mysql":
            return await cls._query_mysql(tool, status, start, end, page, page_size, scope)
        return await cls._query_sqlite(tool, status, start, end, page, page_size, scope)

    @classmethod
    def _build_where(
        cls,
        tool: Optional[str],
        status: Optional[str],
        start: Optional[str],
        end: Optional[str],
        scope: str,
        ph: str = "%s",
    ):
        conds, params = [], []
        if scope != "global":
            conds.append(f"service_name = {ph}")
            params.append(cls._service_name)
        if tool:
            conds.append(f"tool_name = {ph}")
            params.append(tool)
        if status:
            conds.append(f"status = {ph}")
            params.append(status)
        if start:
            conds.append(f"created_at >= {ph}")
            params.append(start + " 00:00:00")
        if end:
            conds.append(f"created_at <= {ph}")
            params.append(end + " 23:59:59")
        where = ("WHERE " + " AND ".join(conds)) if conds else ""
        return where, params

    # 列表查询固定字段集（不含 input_params / output 等大字段）
    _LIST_COLUMNS = (
        "id, service_name, instance_id, request_id, tool_name, status, "
        "error_type, error_msg, elapsed_ms, client_ip, "
        "input_size, output_size, created_at"
    )

    @classmethod
    async def _query_mysql(cls, tool, status, start, end, page, page_size, scope) -> dict:
        import aiomysql
        where, params = cls._build_where(tool, status, start, end, scope, "%s")
        offset = (page - 1) * page_size
        async with cls._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(
                    f"SELECT COUNT(*) AS cnt FROM `{cls._table}` {where}", params
                )
                total = (await cur.fetchone())["cnt"]
                await cur.execute(
                    f"SELECT {cls._LIST_COLUMNS} FROM `{cls._table}` {where} "
                    f"ORDER BY created_at DESC, id DESC LIMIT %s OFFSET %s",
                    params + [page_size, offset],
                )
                items = await cur.fetchall()
        for item in items:
            if isinstance(item.get("created_at"), datetime):
                item["created_at"] = item["created_at"].strftime("%Y-%m-%d %H:%M:%S")
        return {"total": total, "items": items}

    @classmethod
    async def _query_sqlite(cls, tool, status, start, end, page, page_size, scope) -> dict:
        import aiosqlite
        where, params = cls._build_where(tool, status, start, end, scope, "?")
        offset = (page - 1) * page_size
        async with aiosqlite.connect(cls._sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                f"SELECT COUNT(*) FROM {cls._table} {where}", params
            ) as cur:
                row = await cur.fetchone()
                total = row[0]
            async with db.execute(
                f"SELECT {cls._LIST_COLUMNS} FROM {cls._table} {where} "
                f"ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
                params + [page_size, offset],
            ) as cur:
                rows = await cur.fetchall()
                items = [dict(r) for r in rows]
        return {"total": total, "items": items}

    @classmethod
    async def get_payload(cls, log_id: int, scope: str = "service") -> Optional[dict]:
        """详情接口：单独 fetch 大字段。前端展开时按需调用。"""
        if not cls._backend or cls._backend == "disabled":
            return None
        if cls._backend == "mysql":
            return await cls._get_payload_mysql(log_id, scope)
        return await cls._get_payload_sqlite(log_id, scope)

    @classmethod
    async def _get_payload_mysql(cls, log_id: int, scope: str) -> Optional[dict]:
        import aiomysql
        where = "id = %s"
        params: list = [log_id]
        if scope != "global":
            where += " AND service_name = %s"
            params.append(cls._service_name)
        async with cls._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(
                    f"SELECT id, input_params, output FROM `{cls._table}` WHERE {where}",
                    params,
                )
                return await cur.fetchone()

    @classmethod
    async def _get_payload_sqlite(cls, log_id: int, scope: str) -> Optional[dict]:
        import aiosqlite
        where = "id = ?"
        params: list = [log_id]
        if scope != "global":
            where += " AND service_name = ?"
            params.append(cls._service_name)
        async with aiosqlite.connect(cls._sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                f"SELECT id, input_params, output FROM {cls._table} WHERE {where}",
                params,
            ) as cur:
                row = await cur.fetchone()
                return dict(row) if row else None

    # ── 统计：DB 端聚合 + 采样 ───────────────────────────────────────────────

    @classmethod
    async def stats(cls, range_: str = "24h", scope: str = "service") -> dict:
        """聚合统计；Redis 缓存 60 秒，跨 worker 共享。"""
        cache_key_range = f"{range_}:{scope}"

        cached = await RedisClient.get_stats_cache(cache_key_range)
        if cached:
            return cached

        # Redis 不可用时退到本地缓存兜底
        local = cls._stats_local_cache.get(cache_key_range)
        if local and (_time.time() - local[0]) < cls._STATS_CACHE_TTL:
            return local[1]

        if not cls._backend or cls._backend == "disabled":
            data = cls._empty_stats(range_)
        elif cls._backend == "mysql":
            data = await cls._stats_mysql(range_, scope)
        else:
            data = await cls._stats_sqlite(range_, scope)

        await RedisClient.set_stats_cache(cache_key_range, data, cls._STATS_CACHE_TTL)
        cls._stats_local_cache[cache_key_range] = (_time.time(), data)
        return data

    @staticmethod
    def _range_to_cutoff(range_: str) -> str:
        delta = {
            "24h": timedelta(hours=24),
            "7d":  timedelta(days=7),
            "30d": timedelta(days=30),
        }.get(range_, timedelta(hours=24))
        return (datetime.now() - delta).strftime("%Y-%m-%d %H:%M:%S")

    # 大范围统计的 elapsed_ms 采样上限：避免百万行拖垮 Python
    _LATENCY_SAMPLE_LIMIT = 5000

    @classmethod
    async def _stats_mysql(cls, range_: str, scope: str) -> dict:
        import aiomysql
        cutoff = cls._range_to_cutoff(range_)
        bucket = (
            "DATE_FORMAT(created_at, '%%Y-%%m-%%d %%H:00')"
            if range_ == "24h"
            else "DATE_FORMAT(created_at, '%%Y-%%m-%%d')"
        )
        t = f"`{cls._table}`"

        svc_clause = "service_name = %s AND" if scope != "global" else ""
        svc_param: list = [cls._service_name] if scope != "global" else []

        async with cls._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(
                    f"SELECT COUNT(*) AS total, "
                    f"SUM(status='success') AS success_count, "
                    f"SUM(status='error')   AS error_count, "
                    f"ROUND(AVG(elapsed_ms)) AS avg_elapsed_ms "
                    f"FROM {t} WHERE {svc_clause} created_at >= %s",
                    svc_param + [cutoff],
                )
                summary = dict(await cur.fetchone())

                await cur.execute(
                    f"SELECT tool_name, COUNT(*) AS total, "
                    f"SUM(status='success') AS success_count, "
                    f"SUM(status='error')   AS error_count, "
                    f"ROUND(AVG(elapsed_ms)) AS avg_elapsed_ms "
                    f"FROM {t} WHERE {svc_clause} created_at >= %s "
                    f"GROUP BY tool_name ORDER BY total DESC",
                    svc_param + [cutoff],
                )
                by_tool = [dict(r) for r in await cur.fetchall()]

                await cur.execute(
                    f"SELECT {bucket} AS ts, COUNT(*) AS total, "
                    f"SUM(status='error') AS error_count "
                    f"FROM {t} WHERE {svc_clause} created_at >= %s "
                    f"GROUP BY ts ORDER BY ts",
                    svc_param + [cutoff],
                )
                timeline = [dict(r) for r in await cur.fetchall()]

                # 采样：按 id 取样（顺序扫，避免 ORDER BY RAND() 全表 sort）
                await cur.execute(
                    f"SELECT elapsed_ms FROM {t} "
                    f"WHERE {svc_clause} created_at >= %s AND elapsed_ms IS NOT NULL "
                    f"LIMIT %s",
                    svc_param + [cutoff, cls._LATENCY_SAMPLE_LIMIT],
                )
                latency_rows = [dict(r) for r in await cur.fetchall()]

                await cur.execute(
                    f"SELECT COALESCE(NULLIF(error_type, ''), 'unknown_error') AS error_type, "
                    f"COUNT(*) AS total FROM {t} "
                    f"WHERE {svc_clause} created_at >= %s AND status='error' "
                    f"GROUP BY error_type ORDER BY total DESC",
                    svc_param + [cutoff],
                )
                error_by_type = [dict(r) for r in await cur.fetchall()]

        return cls._build_stats(range_, summary, by_tool, timeline, latency_rows, error_by_type)

    @classmethod
    async def _stats_sqlite(cls, range_: str, scope: str) -> dict:
        import aiosqlite
        cutoff = cls._range_to_cutoff(range_)
        bucket = (
            "strftime('%Y-%m-%d %H:00', created_at)"
            if range_ == "24h"
            else "date(created_at)"
        )
        t = cls._table
        _sum = "SUM(CASE WHEN status='success' THEN 1 ELSE 0 END)"
        _err = "SUM(CASE WHEN status='error'   THEN 1 ELSE 0 END)"

        svc_clause = "service_name = ? AND" if scope != "global" else ""
        svc_param: list = [cls._service_name] if scope != "global" else []

        async with aiosqlite.connect(cls._sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                f"SELECT COUNT(*) AS total, {_sum} AS success_count, "
                f"{_err} AS error_count, ROUND(AVG(elapsed_ms)) AS avg_elapsed_ms "
                f"FROM {t} WHERE {svc_clause} created_at >= ?",
                svc_param + [cutoff],
            ) as cur:
                summary = dict(await cur.fetchone())

            async with db.execute(
                f"SELECT tool_name, COUNT(*) AS total, {_sum} AS success_count, "
                f"{_err} AS error_count, ROUND(AVG(elapsed_ms)) AS avg_elapsed_ms "
                f"FROM {t} WHERE {svc_clause} created_at >= ? "
                f"GROUP BY tool_name ORDER BY total DESC",
                svc_param + [cutoff],
            ) as cur:
                by_tool = [dict(r) for r in await cur.fetchall()]

            async with db.execute(
                f"SELECT {bucket} AS ts, COUNT(*) AS total, {_err} AS error_count "
                f"FROM {t} WHERE {svc_clause} created_at >= ? "
                f"GROUP BY ts ORDER BY ts",
                svc_param + [cutoff],
            ) as cur:
                timeline = [dict(r) for r in await cur.fetchall()]

            async with db.execute(
                f"SELECT elapsed_ms FROM {t} "
                f"WHERE {svc_clause} created_at >= ? AND elapsed_ms IS NOT NULL "
                f"LIMIT ?",
                svc_param + [cutoff, cls._LATENCY_SAMPLE_LIMIT],
            ) as cur:
                latency_rows = [dict(r) for r in await cur.fetchall()]

            async with db.execute(
                f"SELECT COALESCE(NULLIF(error_type, ''), 'unknown_error') AS error_type, "
                f"COUNT(*) AS total FROM {t} "
                f"WHERE {svc_clause} created_at >= ? AND status='error' "
                f"GROUP BY error_type ORDER BY total DESC",
                svc_param + [cutoff],
            ) as cur:
                error_by_type = [dict(r) for r in await cur.fetchall()]

        return cls._build_stats(range_, summary, by_tool, timeline, latency_rows, error_by_type)

    @classmethod
    def _build_stats(cls, range_, summary, by_tool, timeline, latency_rows, error_by_type) -> dict:
        total = int(summary.get("total") or 0)
        success = int(summary.get("success_count") or 0)
        error = int(summary.get("error_count") or 0)
        avg_ms = int(summary.get("avg_elapsed_ms") or 0)
        latencies = [
            int(r.get("elapsed_ms") or 0)
            for r in latency_rows
            if r.get("elapsed_ms") is not None
        ]
        return {
            "range": range_,
            "summary": {
                "total": total,
                "success": success,
                "error": error,
                "success_rate": round(success / total * 100, 1) if total > 0 else 0.0,
                "avg_elapsed_ms": avg_ms,
                "p95_elapsed_ms": cls._percentile(latencies, 95),
                "p99_elapsed_ms": cls._percentile(latencies, 99),
                "latency_sample_size": len(latencies),
            },
            "error_by_type": [
                {"error_type": r.get("error_type") or "unknown_error",
                 "total": int(r.get("total") or 0)}
                for r in error_by_type
            ],
            "by_tool": [
                {"tool_name":      r.get("tool_name", ""),
                 "total":          int(r.get("total") or 0),
                 "success":        int(r.get("success_count") or 0),
                 "error":          int(r.get("error_count") or 0),
                 "avg_elapsed_ms": int(r.get("avg_elapsed_ms") or 0)}
                for r in by_tool
            ],
            "timeline": [
                {"ts": str(r.get("ts", "")),
                 "total": int(r.get("total") or 0),
                 "error": int(r.get("error_count") or 0)}
                for r in timeline
            ],
        }

    @staticmethod
    def _percentile(values: list[int], pct: int) -> int:
        if not values:
            return 0
        ordered = sorted(values)
        idx = min(len(ordered) - 1, round((pct / 100) * (len(ordered) - 1)))
        return int(ordered[idx])

    @staticmethod
    def _empty_stats(range_: str) -> dict:
        return {
            "range": range_,
            "summary": {
                "total": 0, "success": 0, "error": 0,
                "success_rate": 0.0, "avg_elapsed_ms": 0,
                "p95_elapsed_ms": 0, "p99_elapsed_ms": 0,
                "latency_sample_size": 0,
            },
            "error_by_type": [],
            "by_tool": [],
            "timeline": [],
        }

    # ── 心跳 / 负载（Redis 取代 MySQL 心跳表） ───────────────────────────────

    @classmethod
    async def write_worker_heartbeat(cls, snapshot: dict) -> None:
        if not cls._backend or cls._backend == "disabled":
            return
        # 注入 service_name，方便跨 service 视图聚合
        snapshot = dict(snapshot)
        snapshot["service_name"] = cls._service_name
        snapshot["service_version"] = cls._service_version
        await RedisClient.write_heartbeat(snapshot, cls._heartbeat_ttl_s)

    @classmethod
    async def load_workers(cls, current_snapshot: dict, scope: str = "service") -> dict:
        # scope=service 只看本 service；global 暂不支持跨服务（实现需 SCAN 全 prefix，
        # 后续如果有需要再扩，目前先不复杂化）
        workers = await RedisClient.list_alive_workers()
        if not workers:
            workers = [current_snapshot]
        return cls._build_load_snapshot(workers)

    @staticmethod
    def _build_load_snapshot(workers: list) -> dict:
        total_active = sum(int(w.get("active_requests") or 0) for w in workers)
        total_pending = sum(int(w.get("pending_requests") or 0) for w in workers)
        total_max = sum(int(w.get("max_concurrency") or 0) for w in workers)
        rejected = sum(int(w.get("rejected_overload_total") or 0) for w in workers)
        p95 = max((float(w.get("p95_latency_ms") or 0) for w in workers), default=0)
        lag = max((float(w.get("event_loop_lag_ms") or 0) for w in workers), default=0)
        ratio = total_active / total_max if total_max > 0 else 0
        if ratio >= 0.8 or total_pending > 0 or lag >= 500:
            status = "overloaded"
        elif ratio >= 0.6:
            status = "busy"
        else:
            status = "normal"
        return {
            "status": status,
            "summary": {
                "active_requests":         total_active,
                "pending_requests":        total_pending,
                "max_concurrency":         total_max,
                "rejected_overload_total": rejected,
                "rps_1m": round(sum(float(w.get("rps_1m") or 0) for w in workers), 2),
                "avg_latency_ms": round(
                    sum(float(w.get("avg_latency_ms") or 0) for w in workers)
                    / max(len(workers), 1),
                    2,
                ),
                "p95_latency_ms": p95,
                "p99_latency_ms": max(
                    (float(w.get("p99_latency_ms") or 0) for w in workers), default=0
                ),
                "event_loop_lag_ms": lag,
            },
            "workers": workers,
        }

    # ── 实时订阅：跨 Pod via Redis Pub/Sub ───────────────────────────────────

    @classmethod
    async def subscribe_iter(cls):
        """供路由层 `async for entry in LogStore.subscribe_iter():` 使用。"""
        async for entry in RedisClient.subscribe_logs():
            yield entry

    # ── TTL：按月 DROP 旧分区 ────────────────────────────────────────────────

    @classmethod
    async def _ttl_loop(cls) -> None:
        """每 6 小时跑一次：补未来分区 + DROP 超过 retention 的老分区。"""
        try:
            while True:
                try:
                    if cls._backend == "mysql":
                        await cls._ttl_mysql()
                    elif cls._backend == "sqlite":
                        await cls._ttl_sqlite()
                except Exception as e:
                    logger.warning(f"[LogStore] TTL 任务失败（不影响业务）: {e}")
                await asyncio.sleep(6 * 3600)
        except asyncio.CancelledError:
            return

    @classmethod
    async def _ttl_mysql(cls) -> None:
        """
        策略：
          - 提前补未来 3 个月分区
          - DROP 早于 (now - retention_days) 的整月分区（O(1) 不锁表）
          - 若 DDL 权限不足，降级到 DELETE WHERE created_at < cutoff（慢但兜底）
        """
        import aiomysql

        ddl_failed = False
        async with cls._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                # 拉当前分区列表
                await cur.execute(
                    "SELECT PARTITION_NAME, PARTITION_DESCRIPTION "
                    "FROM information_schema.PARTITIONS "
                    "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s "
                    "AND PARTITION_NAME IS NOT NULL AND PARTITION_NAME != 'pmax'",
                    (cls._table,),
                )
                rows = await cur.fetchall()
                existing = {r["PARTITION_NAME"] for r in rows}
                if not existing:
                    return  # 表不是分区表，跳过分区维护

                # 1) 补未来 3 个月分区（在 pmax 之前 REORGANIZE 出新分区）
                now = datetime.now()
                y, m = now.year, now.month
                for _ in range(3):
                    name, expr = cls._month_partition_def(y, m)
                    if name not in existing:
                        try:
                            await cur.execute(
                                f"ALTER TABLE `{cls._table}` REORGANIZE PARTITION pmax INTO ("
                                f"PARTITION {name} VALUES LESS THAN ({expr}), "
                                f"PARTITION pmax VALUES LESS THAN MAXVALUE)"
                            )
                            existing.add(name)
                        except Exception as e:
                            ddl_failed = True
                            logger.warning(f"[LogStore] 补分区 {name} 失败: {e}")
                            break
                    m += 1
                    if m > 12:
                        m = 1; y += 1

                # 2) DROP 老分区
                cutoff_date = (datetime.now() - timedelta(days=cls._retention_days))
                cutoff_str = cutoff_date.strftime("%Y%m")
                for name in sorted(existing):
                    if not name.startswith("p") or len(name) != 7 or not name[1:].isdigit():
                        continue
                    if name[1:] < cutoff_str:
                        try:
                            await cur.execute(f"ALTER TABLE `{cls._table}` DROP PARTITION {name}")
                            logger.info(f"[LogStore] TTL 已 DROP 分区 {name}")
                        except Exception as e:
                            ddl_failed = True
                            logger.warning(f"[LogStore] DROP 分区 {name} 失败: {e}")

        if ddl_failed:
            # 降级：DELETE 兜底
            cutoff = (datetime.now() - timedelta(days=cls._retention_days)).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            async with cls._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        f"DELETE FROM `{cls._table}` WHERE created_at < %s LIMIT 5000",
                        (cutoff,),
                    )

    @classmethod
    async def _ttl_sqlite(cls) -> None:
        import aiosqlite
        cutoff = (datetime.now() - timedelta(days=cls._retention_days)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        async with aiosqlite.connect(cls._sqlite_path) as db:
            await db.execute(
                f"DELETE FROM {cls._table} WHERE created_at < ?", (cutoff,)
            )
            await db.commit()

    # ── 全局视图鉴权 ─────────────────────────────────────────────────────────

    @classmethod
    def is_admin_token(cls, token: Optional[str]) -> bool:
        """运维通过 ?scope=global + X-Admin-Token: <token> 跨 service 查询。"""
        if not cls._admin_token:
            return False
        return bool(token) and token == cls._admin_token
