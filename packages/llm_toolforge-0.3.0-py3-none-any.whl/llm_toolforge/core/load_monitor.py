"""
运行时负载监控。

只依赖标准库，提供请求计数、延迟滑窗、受控并发和当前进程快照。
多 worker / 多 Pod 的跨进程聚合由 LogStore 的 heartbeat 持久化完成。
"""

from __future__ import annotations

import asyncio
import os
import platform
import socket
import threading
import time
from collections import Counter, deque
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional


class OverloadedError(RuntimeError):
    """服务当前负载过高，无法在等待时间内获得并发许可。"""


class LoadMonitor:
    _service: str = "api"
    _instance_id: str = ""
    _max_concurrency: int = 0
    _overload_timeout_ms: int = 1000
    _semaphore: Optional[asyncio.Semaphore] = None

    _lock = threading.Lock()
    _active_requests: int = 0
    _pending_requests: int = 0
    _total_requests: int = 0
    _success_requests: int = 0
    _error_requests: int = 0
    _rejected_overload: int = 0
    _latencies: deque = deque(maxlen=1000)
    _recent_requests: deque = deque(maxlen=5000)
    _error_types: Counter = Counter()
    _loop_lag_ms: float = 0.0
    _last_cpu_sample = None

    @classmethod
    def setup(cls, config: dict, service: str = "api") -> None:
        server_cfg = config.get("server", {})
        cls._service = service
        cls._instance_id = str(
            server_cfg.get("instance_id")
            or os.getenv("POD_NAME")
            or os.getenv("HOSTNAME")
            or socket.gethostname()
        )
        cls._max_concurrency = cls._resolve_max_concurrency(server_cfg)
        cls._overload_timeout_ms = int(server_cfg.get("overload_timeout_ms", 1000))
        cls._semaphore = (
            asyncio.Semaphore(cls._max_concurrency)
            if cls._max_concurrency > 0
            else None
        )

    @classmethod
    def _resolve_max_concurrency(cls, server_cfg: dict) -> int:
        value = server_cfg.get("max_concurrency", 1)
        if isinstance(value, int):
            return max(0, value)
        if str(value).lower() == "disabled":
            return 0

        try:
            return max(0, int(value))
        except (TypeError, ValueError) as e:
            raise ValueError("server.max_concurrency 必须是整数或 disabled") from e

    @classmethod
    @asynccontextmanager
    async def request(cls) -> AsyncIterator[None]:
        start = time.perf_counter()
        acquired = False
        cls._mark_started()
        try:
            if cls._semaphore is not None:
                cls._mark_pending(1)
                try:
                    await asyncio.wait_for(
                        cls._semaphore.acquire(),
                        timeout=max(cls._overload_timeout_ms, 1) / 1000,
                    )
                    acquired = True
                except asyncio.TimeoutError as e:
                    cls._mark_pending(-1)
                    cls._mark_finished(start, "error", "server_overloaded")
                    with cls._lock:
                        cls._rejected_overload += 1
                    raise OverloadedError("服务当前负载过高，请稍后重试") from e
                cls._mark_pending(-1)

            cls._mark_active(1)
            yield
        except OverloadedError:
            raise
        finally:
            if acquired and cls._semaphore is not None:
                cls._semaphore.release()
            if acquired or cls._semaphore is None:
                cls._mark_active(-1)

    @classmethod
    def record_result(
        cls,
        started_at: float,
        status: str,
        error_type: str = "",
    ) -> None:
        cls._mark_finished(started_at, status, error_type)

    @classmethod
    def _mark_started(cls) -> None:
        now = time.time()
        with cls._lock:
            cls._total_requests += 1
            cls._recent_requests.append(now)

    @classmethod
    def _mark_pending(cls, delta: int) -> None:
        with cls._lock:
            cls._pending_requests = max(0, cls._pending_requests + delta)

    @classmethod
    def _mark_active(cls, delta: int) -> None:
        with cls._lock:
            cls._active_requests = max(0, cls._active_requests + delta)

    @classmethod
    def _mark_finished(cls, started_at: float, status: str, error_type: str) -> None:
        elapsed_ms = round((time.perf_counter() - started_at) * 1000, 2)
        with cls._lock:
            cls._latencies.append(elapsed_ms)
            if status == "success":
                cls._success_requests += 1
            else:
                cls._error_requests += 1
                if error_type:
                    cls._error_types[error_type] += 1

    @classmethod
    async def loop_lag_probe(cls) -> None:
        while True:
            start = time.perf_counter()
            await asyncio.sleep(1)
            lag = max(0.0, (time.perf_counter() - start - 1) * 1000)
            with cls._lock:
                cls._loop_lag_ms = round(lag, 2)

    @classmethod
    def snapshot(cls) -> dict:
        now = time.time()
        with cls._lock:
            latencies = list(cls._latencies)
            recent = [ts for ts in cls._recent_requests if now - ts <= 60]
            cpu_percent = cls._cpu_percent_locked()
            data = {
                "instance_id": cls._instance_id,
                "service": cls._service,
                "pid": os.getpid(),
                "worker_id": os.getpid(),
                "active_requests": cls._active_requests,
                "pending_requests": cls._pending_requests,
                "max_concurrency": cls._max_concurrency,
                "total_requests": cls._total_requests,
                "success_requests": cls._success_requests,
                "error_requests": cls._error_requests,
                "rejected_overload_total": cls._rejected_overload,
                "rps_1m": round(len(recent) / 60, 2),
                "avg_latency_ms": round(sum(latencies) / len(latencies), 2) if latencies else 0,
                "p95_latency_ms": cls._percentile(latencies, 95),
                "p99_latency_ms": cls._percentile(latencies, 99),
                "error_types": dict(cls._error_types),
                "cpu_percent": cpu_percent,
                "memory_rss_mb": cls._memory_rss_mb(),
                "event_loop_lag_ms": cls._loop_lag_ms,
                "last_seen": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
        data["status"] = cls._status(data)
        return data

    @classmethod
    def _status(cls, data: dict) -> str:
        max_concurrency = data.get("max_concurrency") or 0
        active = data.get("active_requests") or 0
        ratio = active / max_concurrency if max_concurrency > 0 else 0
        if (
            ratio >= 0.8
            or data.get("pending_requests", 0) > 0
            or data.get("event_loop_lag_ms", 0) >= 500
        ):
            return "overloaded"
        if ratio >= 0.6:
            return "busy"
        return "normal"

    @staticmethod
    def _percentile(values: list, pct: int) -> float:
        if not values:
            return 0
        ordered = sorted(values)
        idx = min(len(ordered) - 1, round((pct / 100) * (len(ordered) - 1)))
        return round(ordered[idx], 2)

    @classmethod
    def _cpu_percent_locked(cls) -> float:
        times = os.times()
        sample = time.time(), times.user + times.system
        if cls._last_cpu_sample is None:
            cls._last_cpu_sample = sample
            return 0.0
        last_time, last_cpu = cls._last_cpu_sample
        cls._last_cpu_sample = sample
        elapsed = max(sample[0] - last_time, 0.001)
        cpu_elapsed = sample[1] - last_cpu
        return round(min(100.0, cpu_elapsed / elapsed * 100), 2)

    @staticmethod
    def _memory_rss_mb() -> float:
        if os.name == "nt":
            return LoadMonitor._memory_rss_mb_windows()
        try:
            import resource

            rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if platform.system().lower() == "darwin":
                return round(rss / 1024 / 1024, 2)
            return round(rss / 1024, 2)
        except Exception:
            return 0.0

    @staticmethod
    def _memory_rss_mb_windows() -> float:
        try:
            import ctypes
            import ctypes.wintypes

            class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("cb", ctypes.wintypes.DWORD),
                    ("PageFaultCount", ctypes.wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                ]

            counters = PROCESS_MEMORY_COUNTERS()
            counters.cb = ctypes.sizeof(counters)
            handle = ctypes.windll.kernel32.GetCurrentProcess()
            ok = ctypes.windll.psapi.GetProcessMemoryInfo(
                handle, ctypes.byref(counters), counters.cb
            )
            if not ok:
                return 0.0
            return round(counters.WorkingSetSize / 1024 / 1024, 2)
        except Exception:
            return 0.0

