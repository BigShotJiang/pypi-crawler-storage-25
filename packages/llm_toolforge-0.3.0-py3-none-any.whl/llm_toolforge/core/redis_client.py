"""
Redis 客户端封装

承担三类职责：
  1. 心跳：每个 worker 周期 SET <prefix>:hb:<service>:<instance>:<pid>，TTL 自动过期，
     /load 接口 SCAN 同 service 下所有 key 即可聚合。
  2. 实时流：write 时 PUBLISH 到 <prefix>:stream:<service>，
     /logs/stream 跨 Pod 订阅同一频道，避免老方案"只能看到本 Pod"的问题。
  3. 共享缓存：stats 结果按 (service, range) 写入 Redis，多 Pod 命中同一份。

启用条件：config.yaml 里有 redis_config.host。缺失则退化为 None，调用方应自行降级。
失败一律静默（捕获异常，不影响业务路径），降级路径在 LogStore 内处理。
"""

from __future__ import annotations

import json
from typing import AsyncIterator, Optional

from loguru import logger


class RedisClient:
    _client = None                    # redis.asyncio.Redis | None
    _prefix: str = "tool_log"
    _service: str = "default"

    @classmethod
    async def setup(cls, config: dict, service_name: str) -> None:
        """根据 config 建立 Redis 连接；未配置 host 时静默跳过（降级模式：心跳/实时流/缓存不可用）。"""
        cfg = config.get("redis_config") or {}
        if not cfg.get("host"):
            cls._client = None
            logger.warning(
                "[RedisClient] 未配置 redis_config.host，Redis 功能已禁用。"
                "心跳检测(/load)、实时日志流(/logs/stream)、统计缓存将不可用。"
                "如需启用，请在 config.yaml 中配置 redis_config。"
            )
            return

        import redis.asyncio as aioredis

        cls._prefix = str(cfg.get("key_prefix") or "tool_log")
        cls._service = service_name

        try:
            cls._client = aioredis.Redis(
                host=cfg["host"],
                port=int(cfg.get("port", 6379)),
                password=cfg.get("password") or None,
                db=int(cfg.get("database", 0)),
                socket_timeout=3.0,
                socket_connect_timeout=3.0,
                decode_responses=True,
            )
            await cls._client.ping()
            logger.info(
                f"[RedisClient] 连接成功 host={cfg['host']} db={cfg.get('database', 0)} "
                f"prefix={cls._prefix} service={service_name}"
            )
        except Exception as e:
            cls._client = None
            raise RuntimeError(f"[RedisClient] Redis 连接失败，服务无法启动: {e}") from e

    @classmethod
    async def close(cls) -> None:
        if cls._client is not None:
            try:
                await cls._client.close()
            except Exception:
                pass
            cls._client = None

    @classmethod
    def is_ready(cls) -> bool:
        return cls._client is not None

    @classmethod
    async def ping(cls) -> tuple[bool, str]:
        """轻量探测 Redis 连接是否仍可用。"""
        if cls._client is None:
            return False, "redis client not initialized"
        try:
            await cls._client.ping()
            return True, "ok"
        except Exception as e:
            return False, str(e)

    # ── Key 命名 ─────────────────────────────────────────────────────────────

    @classmethod
    def _hb_key(cls, service: str, instance: str, pid: int) -> str:
        return f"{cls._prefix}:hb:{service}:{instance}:{pid}"

    @classmethod
    def _hb_pattern(cls, service: str) -> str:
        return f"{cls._prefix}:hb:{service}:*"

    @classmethod
    def _stream_channel(cls, service: str) -> str:
        return f"{cls._prefix}:stream:{service}"

    @classmethod
    def _stats_key(cls, service: str, range_: str) -> str:
        return f"{cls._prefix}:stats:{service}:{range_}"

    # ── 心跳 ─────────────────────────────────────────────────────────────────

    @classmethod
    async def write_heartbeat(cls, snapshot: dict, ttl_s: int) -> None:
        """SET 心跳，TTL 由调用方传入；失败静默。"""
        if cls._client is None:
            return
        try:
            key = cls._hb_key(
                cls._service,
                str(snapshot.get("instance_id") or ""),
                int(snapshot.get("pid") or 0),
            )
            await cls._client.set(key, json.dumps(snapshot, ensure_ascii=False), ex=ttl_s)
        except Exception as e:
            logger.warning(f"[RedisClient] write_heartbeat 失败: {e}")

    @classmethod
    async def list_alive_workers(cls, service: Optional[str] = None) -> list[dict]:
        """返回当前 service 下所有未过期的心跳 payload；service 为 None 时只看本 service。"""
        if cls._client is None:
            return []
        target = service or cls._service
        results: list[dict] = []
        try:
            cursor = 0
            keys: list[str] = []
            while True:
                cursor, batch = await cls._client.scan(
                    cursor=cursor,
                    match=cls._hb_pattern(target),
                    count=200,
                )
                keys.extend(batch)
                if cursor == 0:
                    break
            if not keys:
                return []
            values = await cls._client.mget(keys)
            for v in values:
                if not v:
                    continue
                try:
                    results.append(json.loads(v))
                except Exception:
                    pass
        except Exception as e:
            logger.warning(f"[RedisClient] list_alive_workers 失败: {e}")
        return results

    # ── 实时流 ──────────────────────────────────────────────────────────────

    @classmethod
    async def publish_log(cls, payload: dict) -> None:
        if cls._client is None:
            return
        try:
            await cls._client.publish(
                cls._stream_channel(cls._service),
                json.dumps(payload, ensure_ascii=False),
            )
        except Exception as e:
            logger.warning(f"[RedisClient] publish_log 失败: {e}")

    @classmethod
    async def subscribe_logs(cls) -> AsyncIterator[dict]:
        """订阅当前 service 的实时日志频道；调用方在异步 for 里消费。"""
        if cls._client is None:
            return
        pubsub = cls._client.pubsub()
        try:
            await pubsub.subscribe(cls._stream_channel(cls._service))
            async for message in pubsub.listen():
                if message.get("type") != "message":
                    continue
                data = message.get("data")
                if not data:
                    continue
                try:
                    yield json.loads(data)
                except Exception:
                    continue
        finally:
            try:
                await pubsub.unsubscribe(cls._stream_channel(cls._service))
                await pubsub.close()
            except Exception:
                pass

    # ── stats 共享缓存 ───────────────────────────────────────────────────────

    @classmethod
    async def get_stats_cache(cls, range_: str) -> Optional[dict]:
        if cls._client is None:
            return None
        try:
            raw = await cls._client.get(cls._stats_key(cls._service, range_))
            return json.loads(raw) if raw else None
        except Exception as e:
            logger.warning(f"[RedisClient] get_stats_cache 失败: {e}")
            return None

    @classmethod
    async def set_stats_cache(cls, range_: str, data: dict, ttl_s: int) -> None:
        if cls._client is None:
            return
        try:
            await cls._client.set(
                cls._stats_key(cls._service, range_),
                json.dumps(data, ensure_ascii=False),
                ex=ttl_s,
            )
        except Exception as e:
            logger.warning(f"[RedisClient] set_stats_cache 失败: {e}")
