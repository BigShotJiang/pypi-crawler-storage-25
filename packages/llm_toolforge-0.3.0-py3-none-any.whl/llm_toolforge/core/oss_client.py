"""
对象存储客户端
支持阿里云 OSS（oss2）和腾讯云 COS（cos-python-sdk-v5）

通过 config.yaml 中的 storage 块配置（推荐）：
  storage:
    provider: aliyun   # aliyun | tencent，默认 aliyun
    ...                # 对应 provider 的字段

向后兼容旧格式（storage_provider + oss_config/cos_config）。
"""

import io
import os
import base64
import yaml
from datetime import datetime
from typing import Optional

from ..config import find_config


class OSSClient:
    """
    对象存储客户端，公共接口不变，内部按 provider 路由到阿里云或腾讯云。
    """

    def __init__(self, config_path: Optional[str] = None):
        interface_path = config_path or str(find_config())

        with open(interface_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        server_cfg = config.get("server") or {}
        self._max_upload_bytes = int(
            float(server_cfg.get("max_upload_mb", 50)) * 1024 * 1024
        )

        storage_cfg = config.get("storage") or {}
        if storage_cfg:
            provider = storage_cfg.get("provider", "aliyun").lower()
        else:
            # 向后兼容旧格式
            provider = config.get("storage_provider", "aliyun").lower()
            if provider == "tencent":
                storage_cfg = config.get("cos_config") or {}
            else:
                storage_cfg = config.get("oss_config") or {}

        if provider == "tencent":
            self._impl = _TencentCOSImpl(storage_cfg)
        else:
            self._impl = _AliyunOSSImpl(storage_cfg)

    def upload_image(self, image_path: str, filename: Optional[str] = None) -> str:
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            ext = os.path.splitext(image_path)[1] or ".jpg"
            filename = f"{timestamp}{ext}"

        with open(image_path, 'rb') as f:
            return self._impl.upload(f.read(), filename)

    def upload_bytes(self, image_bytes: bytes, filename: str) -> str:
        if self._max_upload_bytes > 0 and len(image_bytes) > self._max_upload_bytes:
            raise ValueError(f"上传内容超过限制：最大 {self._max_upload_bytes // 1024 // 1024} MB")
        return self._impl.upload(image_bytes, filename)

    def upload_base64(self, base64_string: str, filename: Optional[str] = None) -> str:
        ext = '.jpg'
        if base64_string.startswith('data:'):
            comma_index = base64_string.find(',')
            if comma_index != -1:
                header = base64_string[:comma_index]
                base64_string = base64_string[comma_index + 1:]

                if filename is None:
                    if 'image/png' in header:
                        ext = '.png'
                    elif 'image/jpeg' in header or 'image/jpg' in header:
                        ext = '.jpg'
                    elif 'image/gif' in header:
                        ext = '.gif'
                    elif 'image/webp' in header:
                        ext = '.webp'

        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            filename = f"{timestamp}{ext}"

        try:
            image_bytes = base64.b64decode(base64_string)
        except Exception as e:
            raise ValueError(f"BASE64 解码失败: {e}")

        return self.upload_bytes(image_bytes, filename)


class _AliyunOSSImpl:
    """阿里云 OSS 实现"""

    def __init__(self, storage_cfg: dict):
        import oss2
        auth = oss2.Auth(storage_cfg["access_key_id"], storage_cfg["access_key_secret"])
        self._bucket = oss2.Bucket(auth, storage_cfg["endpoint"], storage_cfg["bucket"])
        self._bucket_host = storage_cfg["bucket_host"].rstrip("/")
        self._path_prefix = storage_cfg.get("path_prefix", "").strip("/")

    def upload(self, data: bytes, filename: str) -> str:
        object_key = f"{self._path_prefix}/{filename}" if self._path_prefix else filename
        self._bucket.put_object(object_key, data)
        return f"{self._bucket_host}/{object_key}"


class _TencentCOSImpl:
    """腾讯云 COS 实现"""

    def __init__(self, storage_cfg: dict):
        from qcloud_cos import CosConfig, CosS3Client
        # 同时兼容新字段名 secret_id/secret_key 和旧字段名 secretId/secretKey
        secret_id = storage_cfg.get("secret_id") or storage_cfg.get("secretId")
        secret_key = storage_cfg.get("secret_key") or storage_cfg.get("secretKey")
        cfg = CosConfig(
            Region=storage_cfg["region"],
            SecretId=secret_id,
            SecretKey=secret_key,
        )
        self._client = CosS3Client(cfg)
        self._bucket = storage_cfg["bucket"]
        self._path_prefix = (
            storage_cfg.get("path_prefix") or storage_cfg.get("pathPrefix") or ""
        ).strip("/")

        cdn = (storage_cfg.get("cdn_endpoint") or storage_cfg.get("cdnEndpoint") or "").rstrip("/")
        if not cdn:
            cdn = f"https://{self._bucket}.cos.{storage_cfg['region']}.myqcloud.com"
        self._cdn_endpoint = cdn

    def upload(self, data: bytes, filename: str) -> str:
        object_key = f"{self._path_prefix}/{filename}" if self._path_prefix else filename
        self._client.put_object(
            Bucket=self._bucket,
            Key=object_key,
            Body=io.BytesIO(data),
        )
        return f"{self._cdn_endpoint}/{object_key}"
