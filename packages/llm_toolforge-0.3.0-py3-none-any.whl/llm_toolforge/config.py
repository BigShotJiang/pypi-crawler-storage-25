"""
配置加载

所有 config.yaml 相关的 I/O 都在这个模块，框架其余部分不直接读文件。

查找优先级（find_config）：
  1. 环境变量 TOOLFORGE_CONFIG（绝对路径或相对于 CWD）
  2. CWD/config.yaml
  3. 从 CWD 向上逐级搜索（兼容 cd 到子目录运行的场景）
"""

import os
from pathlib import Path
from typing import Optional

import yaml


def find_config(path: Optional[str] = None) -> Path:
    """定位 config.yaml 并返回其绝对路径。

    Args:
        path: 明确指定的路径（优先级最高），None 则自动查找。

    Raises:
        FileNotFoundError: 找不到配置文件时抛出，消息包含修复建议。
    """
    if path:
        p = Path(path)
        if not p.is_absolute():
            p = Path.cwd() / p
        if not p.exists():
            raise FileNotFoundError(f"指定的配置文件不存在：{p}")
        return p.resolve()

    env = os.environ.get("TOOLFORGE_CONFIG")
    if env:
        p = Path(env)
        if not p.is_absolute():
            p = Path.cwd() / p
        if p.exists():
            return p.resolve()
        raise FileNotFoundError(
            f"环境变量 TOOLFORGE_CONFIG 指向的文件不存在：{p}\n"
            "请检查路径是否正确。"
        )

    cwd_cfg = Path.cwd() / "config.yaml"
    if cwd_cfg.exists():
        return cwd_cfg

    d = Path.cwd()
    for _ in range(4):
        d = d.parent
        cfg = d / "config.yaml"
        if cfg.exists():
            return cfg

    raise FileNotFoundError(
        "找不到 config.yaml。\n"
        "请在项目根目录创建配置文件，或通过 TOOLFORGE_CONFIG 环境变量指定路径。\n"
        "可以用 `toolforge new project .` 生成配置模板。"
    )


def load_config(path: Optional[str] = None) -> dict:
    """加载并返回 config.yaml 的内容（dict）。"""
    return yaml.safe_load(find_config(path).read_text(encoding="utf-8")) or {}


def load_tool_config(name: str, config: Optional[dict] = None) -> dict:
    """加载工具私有配置段 tools.<name>。

    工具在 __init__.py 中调用（不需要知道文件路径）：

        from llm_toolforge import load_tool_config
        _CFG = load_tool_config("my_tool")

    Args:
        name:   工具注册名（与 tools/ 下子目录名一致）。
        config: 已加载的 config dict，传入可避免重复读文件。

    Returns:
        dict，没有对应配置段时返回 {}。
    """
    if config is None:
        config = load_config()
    return (config.get("tools") or {}).get(name) or {}
