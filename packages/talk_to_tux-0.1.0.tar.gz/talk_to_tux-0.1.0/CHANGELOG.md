# Changelog

All notable changes to Talk-to-Tux are documented here.

## [Unreleased]

### Added — P7: PyPI release pipeline

- `pyproject.toml` switched to dynamic version (`[tool.hatch.version].path`) — single writable source is `src/talk_to_tux/__init__.py` `__version__`.
- Full PyPI Trove classifier set, including `Environment :: X11 Applications :: Gnome`, `Operating System :: POSIX :: Linux`, and Python 3.11/3.12 version classifiers.
- `[tool.hatch.build.targets.sdist]` target ensures README, LICENSE, CHANGELOG, pyproject ship in sdist.
- Wheel ships `gnome-extension/` and `default_app_rules.toml` via the `packages = ["src/talk_to_tux"]` tree (no `force-include` — it would duplicate entries and trigger a PyPI 400 on upload).
- Entry point `talk-to-tux = talk_to_tux.cli:main` via a delegating shim in `cli.py`.
- `README.md` Prerequisites rewritten with apt/pacman/dnf package matrix + `ydotool` v1.0+ build-from-source pointer + `uv run talk-to-tux --doctor` self-verify.
- `.github/workflows/release.yml` tag-triggered OIDC publish to PyPI via `pypa/gh-action-pypi-publish@release/v1` (Trusted Publishing, no long-lived secret).

### Added
- **Production-readiness hardening** (reviewer findings):
  - `PipelineCache.finalize_run()` — releases the in-memory run handle so
    post-failure operations can't write into a stale run dir.
  - `App._track()` helper for fire-and-forget `asyncio.create_task()` call
    sites. Tasks are registered in a set with a `done_callback` to self-clear
    and are cancelled on shutdown (prevents GC of live background tasks).
  - `systemd` unit hardening: `NoNewPrivileges`, `ProtectSystem=strict`,
    `ProtectHome=read-only`, `PrivateTmp`, `ReadWritePaths` scoped to
    `~/.config/talk-to-tux` and `~/.cache/talk-to-tux`, plus kernel and
    namespace protections. `/dev/input` left accessible for evdev.
  - Regression tests for background-task tracking, cache finalization after
    STT errors, `elevenlabs_api_key` masking, `local_whisper` timeout default,
    and CWD `.env` isolation.
- **Pre-recording ring buffer**: Microphone runs continuously with a 2-second
  circular buffer. Speech spoken before the button press is captured
  automatically — no more lost first words.
- **Audio stream watchdog**: Detects stale PortAudio streams (callback stalled
  or all-silent for >60s) and auto-recreates them. Prevents the app from going
  silent after long uptimes due to PipeWire suspend/profile changes.
- **Trigger-to-record telemetry**: `trigger_to_record_ms` in pipeline telemetry
  measures the true latency from physical button press to recording start.
- **ElevenLabs STT support**: Added as a provider in the STT chain with native
  `keyterms` parameter support for correction learning.
- **Correction learning** (Phase 19): Automatic word-level correction via
  `CorrectionLearner`. Learns from user edits after paste, applies corrections
  pre-rewrite, and injects keyterms into STT providers.
- **SECURITY.md**: Vulnerability reporting policy and security scope documentation.
- **AGPL-3.0 license**: Switched from MIT to enable dual-licensing model for
  open-source community use with commercial licensing available.
- **Beta signup backend** (Phase P6): Public beta application flow and cron-driven
  screening automation. Includes `POST /v1/beta/apply` (with Cloudflare Turnstile
  validation), `GET /v1/beta/status` (unauthenticated status + screener verdict),
  `cron-screen-applications` (LLM-judged pass/reject/borderline with invite email),
  `cron-reset-quota` (monthly quota reset + 30-day tombstone hard-delete), and
  `cron-anomaly-watchdog` (weekly median+σ outlier detection with admin alert).

### Changed
- **VAD now trims silence before STT**: Previously VAD only decided *whether*
  to call STT; the raw recording was uploaded in full. STT providers now
  receive speech-only audio, so cost scales with spoken seconds rather than
  held-button seconds (10-minute hold with 90s of speech → ~90s of billed
  audio, not 10 minutes). `telemetry.audio_duration_ms` remains the raw hold
  duration for UX analytics; new `telemetry.stt_audio_duration_ms` reports
  what was actually sent to STT.
- **Confirmation tooltip default off**: `tooltip.enabled` now defaults to
  `false` — the rewrite result auto-pastes straight into the focused app with
  no confirm-before-paste popup. Re-enable with `[tooltip] enabled = true` in
  `config.toml` or `TTT_TOOLTIP__ENABLED=true`.
- **Recording dot decoupled from tooltip**: The red recording dot next to
  the cursor (mic-is-hot feedback) now shows regardless of `tooltip.enabled`.
  Previously it was gated on the same flag, so disabling the tooltip also
  hid the dot.
- **Transcript logs redacted**: INFO-level logs no longer emit raw STT /
  rewrite text. Char counts only at INFO; full text still logged at DEBUG.
- **`config.toml` `.env` precedence**: Secrets loader now reads only from
  `~/.config/talk-to-tux/secrets.env`, not the current working directory.
  Prevents a rogue CWD `.env` from overriding user secrets.
- **`LocalWhisperConfig.timeout`**: Default reduced from 30s to 5s so the
  provider fails fast into the fallback chain when the local server is down.

### Fixed
- **API key masking in `--show-config`**: `elevenlabs_api_key` is now included
  in the secret-redaction set alongside `openai_api_key`, `google_api_key`,
  and `groq_api_key`.
- **Transcription truncation**: Multiple causes identified and fixed:
  - Double-VAD trimming (our VAD + provider VAD) was cutting first words.
    Now sends raw audio to STT providers.
  - Double-tap hold detection consumed button presses meant for recording,
    losing 2–5 seconds of speech. Now uses speculative recording with VAD
    speech-detection override via the ring buffer.
  - 300ms hold-detection delay eliminated by starting recorder immediately
    on button press (speculative recording).
  - Event loop contention from 500ms focus poll reduced by pausing the poll
    during recording/processing states.
- **GVariant quote parsing**: Window titles with apostrophes (e.g. ChatGPT
  "Let's discuss...") broke D-Bus JSON parsing. Fixed by unescaping `\'`
  before `json.loads()`.
- **Paste into own UI window**: The talk-to-tux indicator/debug window was
  triggering false context-change detection. Now excluded from paste decision.
- **Paste with failed window detection**: When window detection fails at
  recording time (`window_class=None`), auto-paste instead of blocking with
  `offer_both` notification.
- **Rewrite prompt**: Added rules to never add escape characters (`\'`) and
  to preserve interrogative form (questions stay questions).
- **Per-member rewrite provider attribution**: `RewriteOutput.provider` now
  reports the actual BAML fallback chain member that answered
  (`LocalAI`, `Groq`, `Gemini`, `Ollama`) instead of the generic
  `SmartRewriteClient`. A `baml_py.Collector` is attached per-call and the
  `selected_call.client_name` is read after the response. Telemetry, debug
  tooltip, feedback analysis, and the new `INFO Rewrite member: <name>` log
  line all attribute outputs to the real member so future regressions are
  traceable. Falls back to the chain name if the collector is unavailable.
- **TARGET WINDOW salience**: The `TARGET WINDOW` line now includes the
  enriched app-type classification (`kitty — terminal (SSH to claw — remote
  zellij detected, use screenshot)`) instead of just the window class
  (`kitty`). Previously the SSH/TUI tag sat two blocks up in the
  `KNOWN APPLICATIONS` list and got out-weighted by branch-shaped titles
  in `WINDOW STATE`, producing shell commands (`git push`) from prose in
  SSH'd zellij sessions. Extracted `classify_window()` from `build_static`
  so both the list and the target line render from the same classifier.
- **TUI detection lost on fallback models**: `SmartRewriter._build_kwargs()`
  was discarding the fresh active-window `AppContext` (enriched with
  `terminal_info` via /proc walk) whenever the indicator's poll-cached
  `all_windows` was non-empty. Fallback rewrite models (Groq, Gemini) then
  saw `[1] kitty — terminal` instead of `[1] kitty — terminal running claude
  (chat)` and inserted shell commands inside TUIs. Fresh context now replaces
  the matching `window_id` entry in `all_windows` before context blocks are
  built.

### Changed
- **Default server URLs**: Changed from `http://ai:8000` / `http://ai:11434`
  to `http://localhost:8000` / `http://localhost:11434` for open-source
  distribution.
- **Wayland paste tool**: Documentation updated from `wtype` (which doesn't
  work on GNOME/Mutter) to `ydotool` v1.0+ with `ydotoold` daemon.
- **VAD role**: VAD now only gates (no-speech detection to skip STT). Raw
  audio is sent to STT providers which have their own VAD. Configurable
  `pre_pad_ms` and `post_pad_ms` retained but defaulted to 0.

### Removed
- **`.env.op`**: 1Password vault reference file removed from git tracking.
