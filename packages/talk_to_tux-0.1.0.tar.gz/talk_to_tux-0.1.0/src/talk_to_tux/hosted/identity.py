"""HostedIdentity + load_identity helper."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from talk_to_tux.auth import TokenStore


@dataclass(frozen=True)
class HostedIdentity:
    email: str
    tier: str
    expires_at: datetime | None
    token_id: str

    @property
    def expired(self) -> bool:
        if self.expires_at is None:
            return False
        return self.expires_at <= datetime.now(timezone.utc)


def load_identity(token_store: TokenStore) -> HostedIdentity | None:
    """Load identity from token store. Returns None if no token or parse fails."""
    try:
        tokens = token_store.load()
    except Exception:
        return None

    if tokens is None:
        return None

    if tokens.user_email is None or tokens.tier is None:
        return None

    try:
        from talk_to_tux.auth import parse_access_token
        token_id, _ = parse_access_token(tokens.access_token)
    except Exception:
        return None

    return HostedIdentity(
        email=tokens.user_email,
        tier=tokens.tier,
        expires_at=tokens.expires_at,
        token_id=token_id,
    )
