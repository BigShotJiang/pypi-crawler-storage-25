"""hosted — lazy re-exports for hosted-mode data layer."""
from __future__ import annotations

__all__ = [
    "UPGRADE_URL",
    "QuotaSnapshot",
    "HostedQuotaClient",
    "HostedIdentity",
    "load_identity",
]

_URLS = {"UPGRADE_URL"}
_QUOTA = {"QuotaSnapshot", "HostedQuotaClient"}
_IDENTITY = {"HostedIdentity", "load_identity"}


def __getattr__(name: str) -> object:
    if name in _URLS:
        from .urls import UPGRADE_URL
        return UPGRADE_URL
    if name in _QUOTA:
        from . import quota_client
        return getattr(quota_client, name)
    if name in _IDENTITY:
        from . import identity
        return getattr(identity, name)
    raise AttributeError(name)
