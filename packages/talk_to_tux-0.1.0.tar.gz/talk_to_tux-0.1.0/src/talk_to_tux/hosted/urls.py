"""Hosted-mode URL constants."""
from __future__ import annotations

UPGRADE_URL = "https://www.talk-to-tux.com/upgrade"
