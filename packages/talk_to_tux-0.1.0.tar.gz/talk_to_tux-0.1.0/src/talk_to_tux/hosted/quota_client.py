"""HostedQuotaClient — fetch /v1/quota from the hosted backend."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

import httpx

from talk_to_tux.auth import (
    HostedError,
    QuotaExhausted,
    TierLocked,
    TokenInvalid,
)
from talk_to_tux.config import HostedConfig


@dataclass(frozen=True)
class QuotaSnapshot:
    period_start: datetime
    period_end: datetime
    stt_seconds_used: float
    stt_seconds_limit: float | None
    rewrite_used: int
    rewrite_limit: int | None
    cap_hits: int
    tier: str

    @property
    def stt_hours_used(self) -> float:
        return self.stt_seconds_used / 3600.0

    @property
    def stt_hours_limit(self) -> float | None:
        if self.stt_seconds_limit is None:
            return None
        return self.stt_seconds_limit / 3600.0

    @property
    def rewrite_used_pct(self) -> float | None:
        if self.rewrite_limit is None or self.rewrite_limit == 0:
            return None
        return self.rewrite_used / self.rewrite_limit

    @property
    def reset_in_days(self) -> int:
        delta = (self.period_end - datetime.now(timezone.utc)).days
        return max(0, delta)

    @property
    def exhausted(self) -> bool:
        stt_exhausted = (
            self.stt_seconds_limit is not None
            and self.stt_seconds_used >= self.stt_seconds_limit
        )
        rewrite_exhausted = (
            self.rewrite_limit is not None
            and self.rewrite_used >= self.rewrite_limit
        )
        return stt_exhausted or rewrite_exhausted


class HostedQuotaClient:
    """Fetches quota information from the hosted /v1/quota endpoint."""

    def __init__(
        self,
        hosted_config: HostedConfig,
        token_store: object,
        *,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._hosted_config = hosted_config
        self._token_store = token_store
        self._timeout = timeout
        self._owns_client = http_client is None
        self._http = http_client if http_client is not None else httpx.AsyncClient()

    async def fetch(self) -> QuotaSnapshot:
        tokens = self._token_store.load()
        if tokens is None:
            raise TokenInvalid()

        url = f"{self._hosted_config.base_url}/functions/v1/v1-quota"
        try:
            response = await self._http.get(
                url,
                headers={"Authorization": f"Bearer {tokens.access_token}"},
                timeout=self._timeout,
            )
        except (httpx.ConnectError, httpx.TimeoutException):
            raise HostedError("network_error")

        status = response.status_code

        if status == 200:
            body = response.json()
            return QuotaSnapshot(
                period_start=datetime.fromisoformat(body["period_start"]),
                period_end=datetime.fromisoformat(body["period_end"]),
                stt_seconds_used=body["stt_audio_seconds"],
                stt_seconds_limit=body["stt_audio_limit_seconds"],
                rewrite_used=body["rewrite_calls"],
                rewrite_limit=body["rewrite_limit"],
                cap_hits=body["cap_hits"],
                tier=body["tier"],
            )

        if status == 401:
            raise TokenInvalid()

        if status == 402:
            body = response.json()
            code = body.get("code", "")
            if code == "tier_locked":
                raise TierLocked()
            reset_at_raw = body.get("reset_at")
            reset_at: datetime | None = None
            if reset_at_raw:
                try:
                    reset_at = datetime.fromisoformat(reset_at_raw)
                except (ValueError, TypeError):
                    reset_at = None
            remaining_stt = body.get("remaining_stt_seconds")
            remaining_rewrites = body.get("remaining_rewrites")
            raise QuotaExhausted(
                reset_at=reset_at,
                remaining_stt_seconds=remaining_stt,
                remaining_rewrites=remaining_rewrites,
            )

        raise HostedError(f"server_error {status}")

    async def aclose(self) -> None:
        if self._owns_client:
            await self._http.aclose()
