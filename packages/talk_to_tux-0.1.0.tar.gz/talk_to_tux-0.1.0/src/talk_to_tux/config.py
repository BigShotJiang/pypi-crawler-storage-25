from __future__ import annotations

import enum
import fnmatch
import importlib.resources
import logging
import os
import re
import tomllib
from datetime import datetime
from pathlib import Path
from typing import Any, ClassVar, Literal

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict
from pydantic_settings import DotEnvSettingsSource


# ---------------------------------------------------------------------------
# XDG config directory helpers
# ---------------------------------------------------------------------------

def _config_dir() -> Path:
    """Return XDG config directory for talk-to-tux."""
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return Path(base) / "talk-to-tux"


def _config_toml_path() -> Path:
    return _config_dir() / "config.toml"


def _secrets_env_path() -> Path:
    return _config_dir() / "secrets.env"


# ---------------------------------------------------------------------------
# Hosted-mode enums and config
# ---------------------------------------------------------------------------

class ApiMode(str, enum.Enum):
    BYO_KEY = "byo_key"
    HOSTED = "hosted"


class HostedConfig(BaseModel):
    base_url: str = "https://xslzowzdkgxapohjihrs.supabase.co"
    access_token: str | None = Field(default=None, exclude=True)
    refresh_token: str | None = Field(default=None, exclude=True)
    expires_at: datetime | None = None
    user_email: str | None = None
    tier: str | None = None


# ---------------------------------------------------------------------------
# Nested config sub-models (plain BaseModel, not settings — these are
# embedded in the top-level Settings via TOML or direct construction)
# ---------------------------------------------------------------------------

class DisplayConfig(BaseModel):
    server: Literal["auto", "x11", "wayland"] = "auto"


class AudioConfig(BaseModel):
    sample_rate: int = 16000
    channels: int = 1
    input_device: int | None = None


class VadConfig(BaseModel):
    threshold: float = 0.5
    pre_pad_ms: float = 0.0
    post_pad_ms: float = 50.0

    @field_validator("threshold")
    @classmethod
    def _threshold_range(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError("vad.threshold must be between 0.0 and 1.0")
        return v


class MouseTriggerConfig(BaseModel):
    device_path: str | None = None  # explicit /dev/input/eventN (fragile across reboots)
    device_name: str | None = None  # match by device name substring (stable across reboots)
    button_codes: list[int] = [275, 276]  # BTN_SIDE + BTN_EXTRA
    grab: bool = True  # grab device, forward non-target events via uinput
    dismiss_context_menu: bool = True  # legacy (L+R chord only)

    @model_validator(mode="before")
    @classmethod
    def _migrate_button_code(cls, data: Any) -> Any:
        """Accept legacy single button_code and convert to button_codes list."""
        if isinstance(data, dict) and "button_code" in data and "button_codes" not in data:
            code = data.pop("button_code")
            data["button_codes"] = [code] if isinstance(code, int) else code
        return data


class KeyboardTriggerConfig(BaseModel):
    hotkey: str = "KEY_LEFTCTRL+KEY_LEFTMETA"
    device_path: str | None = None
    device_name: str | None = None


class TriggerConfig(BaseModel):
    mode: Literal["auto", "mouse", "keyboard"] = "auto"
    record_mode: Literal["toggle", "hold"] = "hold"
    chord_timeout_ms: int = 150
    chord_debounce_ms: int = 300
    max_recording_s: int = 300  # safety limit — auto-stop recording after this many seconds
    silence_timeout_s: float = 30.0  # auto-stop after N seconds of silence (0 = disabled)
    mouse: MouseTriggerConfig = MouseTriggerConfig()

    @field_validator("silence_timeout_s")
    @classmethod
    def _silence_timeout_must_be_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("silence_timeout_s must be >= 0")
        return v
    keyboard: KeyboardTriggerConfig = KeyboardTriggerConfig()

    @field_validator("chord_timeout_ms")
    @classmethod
    def _chord_timeout_must_be_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("chord_timeout_ms must be > 0")
        return v

    @field_validator("chord_debounce_ms")
    @classmethod
    def _chord_debounce_must_be_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("chord_debounce_ms must be > 0")
        return v


class GpuServerConfig(BaseModel):
    url: str = "http://localhost:8000"
    timeout: float = 10.0


class LocalWhisperConfig(BaseModel):
    url: str = "http://win:8003/v1"
    timeout: float = 5.0


class SttConfig(BaseModel):
    providers: list[str] = Field(default=["groq", "openai", "google"])
    gpu_server: GpuServerConfig = GpuServerConfig()
    local_whisper: LocalWhisperConfig = LocalWhisperConfig()
    openai_model: str = "whisper-1"
    groq_model: str = "whisper-large-v3-turbo"
    elevenlabs_model: str = "scribe_v2"

    _VALID_PROVIDERS: ClassVar[frozenset[str]] = frozenset(
        {"gpu_server", "groq", "openai", "google", "elevenlabs", "local_whisper"}
    )

    @field_validator("providers")
    @classmethod
    def _providers_must_be_valid(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("stt.providers must not be empty")
        unknown = set(v) - cls._VALID_PROVIDERS
        if unknown:
            raise ValueError(f"Unknown STT providers: {unknown}")
        return v


class RewriteConfig(BaseModel):
    enabled: bool = True
    ollama_base_url: str = "http://localhost:11434/v1"
    local_ai_url: str = "http://ai:8002/v1"
    local_ai_model: str = "cyankiwi/gemma-4-26B-A4B-it-AWQ-4bit"
    groq_model: str = "meta-llama/llama-4-scout-17b-16e-instruct"
    gemini_model: str = "gemini-3.1-flash-lite-preview"
    context_budget_pct: float = 0.6
    model_context_tokens: int = 8192

    @property
    def context_budget_tokens(self) -> int:
        return int(self.context_budget_pct * self.model_context_tokens)


class ContextConfig(BaseModel):
    screenshot_enabled: bool = True
    screenshot_max_width: int = 1024
    screenshot_jpeg_quality: int = 85


class ScreenshotConfig(BaseModel):
    cache_enabled: bool = True
    cache_max_windows: int = 5
    preprocess_max_width: int = 800
    preprocess_jpeg_quality: int = 60


class PasteConfig(BaseModel):
    enabled: bool = True
    clipboard_delay_ms: int = 50
    wayland_keystroke_tool: Literal["auto", "wtype", "ydotool", "xdotool"] = "auto"


class CacheConfig(BaseModel):
    enabled: bool = True
    max_age_hours: float = 72.0
    max_runs: int = 50
    analysis_threshold: int = 10  # auto-analyze after N unreviewed runs accumulate


class IndicatorConfig(BaseModel):
    enabled: bool = True
    history_count: int = 20
    focus_poll_ms: int = 500
    recent_count: int = 10


class TooltipConfig(BaseModel):
    enabled: bool = False
    use_notifications: bool = True
    timeout_s: float = 30.0
    post_paste_timeout_s: float = 5.0
    double_chord_window_ms: int = 600
    hover_rewrite_debounce_ms: int = 800


class ValidationConfig(BaseModel):
    enabled: bool = True
    timeout_ms: int = 300
    warning_sound: bool = True
    warning_tooltip_ms: int = 3500


class DuckingConfig(BaseModel):
    enabled: bool = True
    factor: float = 0.15  # duck to 15% of original

    @field_validator("factor")
    @classmethod
    def _factor_range(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError("ducking.factor must be between 0.0 and 1.0")
        return v


class CorrectionConfig(BaseModel):
    enabled: bool = True
    min_occurrences: int = 3
    max_keyterms: int = 100


class DebugConfig(BaseModel):
    tooltip_enabled: bool = False


# ---------------------------------------------------------------------------
# Per-app rules
# ---------------------------------------------------------------------------

class AppRule(BaseModel):
    match: str
    match_title: str | None = None
    is_terminal: bool | None = None
    paste_shortcut: str | None = None
    paste_method: Literal["clipboard", "typing"] | None = None
    rewrite_hint: str | None = None
    output_format: str | None = None
    clipboard_delay_ms: int | None = None
    disabled: bool = False


class AppRuleMatcher:
    """First-match lookup for per-app rules."""

    def __init__(self, rules: list[AppRule]) -> None:
        self._rules = rules

    @staticmethod
    def _pattern_matches(pattern: str, value: str) -> bool:
        """Check if *pattern* matches *value* (exact, glob, or ~regex)."""
        if pattern.startswith("~"):
            try:
                return bool(re.fullmatch(pattern[1:], value))
            except re.error:
                return False
        if "*" in pattern or "?" in pattern:
            return fnmatch.fnmatch(value, pattern)
        return pattern == value

    def find(
        self, window_class: str | None, window_title: str | None = None,
    ) -> AppRule | None:
        if not window_class:
            return None
        for rule in self._rules:
            if rule.disabled:
                continue
            if not self._pattern_matches(rule.match, window_class):
                continue
            # If rule requires a title match, check it
            if rule.match_title is not None:
                if not window_title or not self._pattern_matches(rule.match_title, window_title):
                    continue
            return rule
        return None


logger = logging.getLogger(__name__)


def _load_default_app_rules() -> list[AppRule]:
    """Load shipped default app rules from the data package."""
    try:
        ref = importlib.resources.files("talk_to_tux.data").joinpath("default_app_rules.toml")
        data = tomllib.loads(ref.read_text(encoding="utf-8"))
        raw_rules = data.get("app", [])
        return [AppRule(**r) for r in raw_rules]
    except Exception:
        logger.debug("Failed to load default app rules", exc_info=True)
        return []


# ---------------------------------------------------------------------------
# TOML settings source
# ---------------------------------------------------------------------------

class TomlConfigSettingsSource(PydanticBaseSettingsSource):
    """Read settings from ~/.config/talk-to-tux/config.toml."""

    def __init__(self, settings_cls: type[BaseSettings]) -> None:
        super().__init__(settings_cls)
        self._data: dict[str, Any] = {}
        path = _config_toml_path()
        if path.exists():
            with open(path, "rb") as f:
                self._data = tomllib.load(f)

    def get_field_value(
        self, field: Any, field_name: str
    ) -> tuple[Any, str, bool]:
        return self._data.get(field_name), field_name, field_name in self._data

    def __call__(self) -> dict[str, Any]:
        # Map TOML [[app]] → Settings.apps
        data = dict(self._data)
        if "app" in data and "apps" not in data:
            data["apps"] = data.pop("app")
        return data


# ---------------------------------------------------------------------------
# Top-level Settings (BaseSettings — supports env vars, .env, TOML, etc.)
# ---------------------------------------------------------------------------

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="TTT_",
        env_nested_delimiter="__",
    )

    # --- Nested config sections ---
    display: DisplayConfig = DisplayConfig()
    audio: AudioConfig = AudioConfig()
    vad: VadConfig = VadConfig()
    trigger: TriggerConfig = TriggerConfig()
    stt: SttConfig = SttConfig()
    rewrite: RewriteConfig = RewriteConfig()
    context: ContextConfig = ContextConfig()
    paste: PasteConfig = PasteConfig()
    cache: CacheConfig = CacheConfig()
    indicator: IndicatorConfig = IndicatorConfig()
    tooltip: TooltipConfig = TooltipConfig()
    screenshot: ScreenshotConfig = ScreenshotConfig()
    validation: ValidationConfig = ValidationConfig()
    ducking: DuckingConfig = DuckingConfig()
    correction: CorrectionConfig = CorrectionConfig()
    debug: DebugConfig = DebugConfig()
    hosted: HostedConfig = Field(default_factory=HostedConfig)
    api_mode: ApiMode = ApiMode.BYO_KEY

    # --- Per-app rules ---
    apps: list[AppRule] = Field(default_factory=list)

    # --- API keys (flat, top-level — secrets) ---
    openai_api_key: str | None = None
    google_api_key: str | None = None
    groq_api_key: str | None = None
    elevenlabs_api_key: str | None = None

    # --- Legacy flat fields (loaded from TTT_ env vars for backward compat) ---
    hotkey: str | None = Field(default=None, exclude=True)
    sample_rate: int | None = Field(default=None, exclude=True)
    channels: int | None = Field(default=None, exclude=True)
    gpu_server_url: str | None = Field(default=None, exclude=True)
    gpu_server_timeout: float | None = Field(default=None, exclude=True)
    openai_model: str | None = Field(default=None, exclude=True)
    stt_providers: str | None = Field(default=None, exclude=True)
    cache_enabled: bool | None = Field(default=None, exclude=True)
    cache_max_age_hours: float | None = Field(default=None, exclude=True)
    cache_max_runs: int | None = Field(default=None, exclude=True)
    vad_threshold: float | None = Field(default=None, exclude=True)
    input_device: int | None = Field(default=None, exclude=True)
    evdev_device_path: str | None = Field(default=None, exclude=True)
    screenshot_max_width: int | None = Field(default=None, exclude=True)
    screenshot_jpeg_quality: int | None = Field(default=None, exclude=True)
    screenshot_enabled: bool | None = Field(default=None, exclude=True)
    ollama_base_url: str | None = Field(default=None, exclude=True)
    rewrite_enabled: bool | None = Field(default=None, exclude=True)
    paste_enabled: bool | None = Field(default=None, exclude=True)
    trigger_mode: str | None = Field(default=None, exclude=True)
    record_mode: str | None = Field(default=None, exclude=True)
    chord_timeout_ms: int | None = Field(default=None, exclude=True)
    chord_debounce_ms: int | None = Field(default=None, exclude=True)
    dismiss_context_menu: bool | None = Field(default=None, exclude=True)
    mouse_device_path: str | None = Field(default=None, exclude=True)
    mouse_device_name: str | None = Field(default=None, exclude=True)
    evdev_device_name: str | None = Field(default=None, exclude=True)
    indicator_enabled: bool | None = Field(default=None, exclude=True)
    indicator_history_count: int | None = Field(default=None, exclude=True)
    indicator_focus_poll_ms: int | None = Field(default=None, exclude=True)
    tooltip_enabled: bool | None = Field(default=None, exclude=True)
    tooltip_timeout_s: float | None = Field(default=None, exclude=True)
    double_chord_window_ms: int | None = Field(default=None, exclude=True)
    hover_rewrite_debounce_ms: int | None = Field(default=None, exclude=True)
    use_notifications: bool | None = Field(default=None, exclude=True)
    silence_timeout_s: float | None = Field(default=None, exclude=True)
    ducking_enabled: bool | None = Field(default=None, exclude=True)
    ducking_factor: float | None = Field(default=None, exclude=True)

    def model_post_init(self, __context: Any) -> None:
        """Apply legacy flat env vars → nested fields, then merge default rules."""
        self._apply_legacy_overrides()
        self._merge_default_app_rules()
        self._resolve_api_mode()

    def _resolve_api_mode(self) -> None:
        """Auto-detect api_mode when still at default (BYO_KEY).

        Resolution order:
        1. secrets.env has a non-empty, non-sentinel TTT_*_API_KEY → BYO_KEY.
        2. keyring has a non-empty talk-to-tux/access_token → HOSTED.
        3. Default: BYO_KEY.
        """
        if self.api_mode is not ApiMode.BYO_KEY:
            return  # user set it explicitly in config — honour that

        # Step 1: check secrets.env for real API keys
        secrets_path = _secrets_env_path()
        if secrets_path.exists():
            try:
                from dotenv import dotenv_values  # python-dotenv
                values = dotenv_values(str(secrets_path))
                for key, val in values.items():
                    if re.match(r"^TTT_.*_API_KEY$", key) and val and val != "BYO_KEY":
                        self.api_mode = ApiMode.BYO_KEY
                        return
            except Exception:
                pass

        # Step 2: check keyring for a hosted access token
        try:
            import keyring  # type: ignore[import]
            token = keyring.get_password("talk-to-tux", "access_token")
            if token:
                self.api_mode = ApiMode.HOSTED
                return
        except (ImportError, Exception):
            pass

        # Step 3: default
        self.api_mode = ApiMode.BYO_KEY

    def _merge_default_app_rules(self) -> None:
        """Append shipped default rules after user rules (user rules = higher priority)."""
        default_rules = _load_default_app_rules()
        if default_rules:
            if self.apps:
                self.apps = list(self.apps) + default_rules
            else:
                self.apps = default_rules

    def _apply_legacy_overrides(self) -> None:
        """Bridge old TTT_* flat env vars into nested structures."""
        # audio
        if self.sample_rate is not None:
            self.audio.sample_rate = self.sample_rate
        if self.channels is not None:
            self.audio.channels = self.channels
        if self.input_device is not None:
            self.audio.input_device = self.input_device
        # vad
        if self.vad_threshold is not None:
            self.vad.threshold = self.vad_threshold
        # trigger
        if self.trigger_mode is not None:
            self.trigger.mode = self.trigger_mode  # type: ignore[assignment]
        if self.record_mode is not None:
            self.trigger.record_mode = self.record_mode  # type: ignore[assignment]
        if self.chord_timeout_ms is not None:
            self.trigger.chord_timeout_ms = self.chord_timeout_ms
        if self.chord_debounce_ms is not None:
            self.trigger.chord_debounce_ms = self.chord_debounce_ms
        if self.hotkey is not None:
            self.trigger.keyboard.hotkey = self.hotkey
        if self.evdev_device_path is not None:
            self.trigger.keyboard.device_path = self.evdev_device_path
        if self.mouse_device_path is not None:
            self.trigger.mouse.device_path = self.mouse_device_path
        if self.mouse_device_name is not None:
            self.trigger.mouse.device_name = self.mouse_device_name
        if self.evdev_device_name is not None:
            self.trigger.keyboard.device_name = self.evdev_device_name
        if self.dismiss_context_menu is not None:
            self.trigger.mouse.dismiss_context_menu = self.dismiss_context_menu
        # stt
        if self.gpu_server_url is not None:
            self.stt.gpu_server.url = self.gpu_server_url
        if self.gpu_server_timeout is not None:
            self.stt.gpu_server.timeout = self.gpu_server_timeout
        if self.openai_model is not None:
            self.stt.openai_model = self.openai_model
        if self.stt_providers is not None:
            names = [s.strip() for s in self.stt_providers.split(",") if s.strip()]
            if names:
                self.stt.providers = names
        # rewrite
        if self.rewrite_enabled is not None:
            self.rewrite.enabled = self.rewrite_enabled
        if self.ollama_base_url is not None:
            self.rewrite.ollama_base_url = self.ollama_base_url
        # context / screenshot
        if self.screenshot_enabled is not None:
            self.context.screenshot_enabled = self.screenshot_enabled
        if self.screenshot_max_width is not None:
            self.context.screenshot_max_width = self.screenshot_max_width
        if self.screenshot_jpeg_quality is not None:
            self.context.screenshot_jpeg_quality = self.screenshot_jpeg_quality
        # paste
        if self.paste_enabled is not None:
            self.paste.enabled = self.paste_enabled
        # cache
        if self.cache_enabled is not None:
            self.cache.enabled = self.cache_enabled
        if self.cache_max_age_hours is not None:
            self.cache.max_age_hours = self.cache_max_age_hours
        if self.cache_max_runs is not None:
            self.cache.max_runs = self.cache_max_runs
        # indicator
        if self.indicator_enabled is not None:
            self.indicator.enabled = self.indicator_enabled
        if self.indicator_history_count is not None:
            self.indicator.history_count = self.indicator_history_count
        if self.indicator_focus_poll_ms is not None:
            self.indicator.focus_poll_ms = self.indicator_focus_poll_ms
        # tooltip
        if self.tooltip_enabled is not None:
            self.tooltip.enabled = self.tooltip_enabled
        if self.tooltip_timeout_s is not None:
            self.tooltip.timeout_s = self.tooltip_timeout_s
        if self.double_chord_window_ms is not None:
            self.tooltip.double_chord_window_ms = self.double_chord_window_ms
        if self.hover_rewrite_debounce_ms is not None:
            self.tooltip.hover_rewrite_debounce_ms = self.hover_rewrite_debounce_ms
        if self.use_notifications is not None:
            self.tooltip.use_notifications = self.use_notifications
        # trigger (silence)
        if self.silence_timeout_s is not None:
            self.trigger.silence_timeout_s = self.silence_timeout_s
        # ducking
        if self.ducking_enabled is not None:
            self.ducking.enabled = self.ducking_enabled
        if self.ducking_factor is not None:
            self.ducking.factor = self.ducking_factor

    def has_hosted_token(self) -> bool:
        """Return True iff a valid hosted token can be loaded.

        Tries KeyringTokenStore first; falls back to checking the filesystem
        tokens.json path. Catches ImportError and any keyring backend errors.
        """
        try:
            from talk_to_tux.auth.token_store import KeyringTokenStore
            store = KeyringTokenStore()
            if store.load() is not None:
                return True
        except (ImportError, Exception):
            pass

        # Filesystem fallback
        try:
            tokens_path = _config_dir() / "secrets" / "tokens.json"
            return tokens_path.exists() and tokens_path.stat().st_size > 0
        except Exception:
            return False

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """Precedence: init > env > dotenv > toml.

        env_file is resolved here (not in model_config) so that
        XDG_CONFIG_HOME overrides in tests take effect.

        Only loads ~/.config/talk-to-tux/secrets.env — CWD .env is
        deliberately excluded so secrets and provider lists don't
        change based on where the packaged app is launched.
        """
        dotenv_source = DotEnvSettingsSource(
            settings_cls,
            env_file=(str(_secrets_env_path()),),
        )
        return (
            init_settings,
            env_settings,
            dotenv_source,
            TomlConfigSettingsSource(settings_cls),
        )


def get_settings() -> Settings:
    return Settings()
