"""Event log for deterministic screenshot capture at pipeline state transitions."""
from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class EventEntry:
    """A single event in the pipeline run."""

    seq: int
    event: str
    timestamp: float
    has_screenshot: bool = False
    pipeline_state: str = ""
    metadata: dict | None = None

    def to_dict(self) -> dict:
        d: dict = {
            "seq": self.seq,
            "event": self.event,
            "timestamp": self.timestamp,
            "has_screenshot": self.has_screenshot,
            "pipeline_state": self.pipeline_state,
        }
        if self.metadata is not None:
            d["metadata"] = self.metadata
        return d


@dataclass
class EventLog:
    """Accumulator for pipeline events within a single run.

    Thread safety: ``add()`` uses ``list.append()`` which is GIL-atomic,
    safe for concurrent calls from GTK and asyncio threads.
    """

    entries: list[EventEntry] = field(default_factory=list)
    _seq: int = field(default=0, repr=False)

    def add(
        self,
        event: str,
        *,
        has_screenshot: bool = False,
        pipeline_state: str = "",
        metadata: dict | None = None,
    ) -> EventEntry:
        """Append a new event and return it."""
        entry = EventEntry(
            seq=self._seq,
            event=event,
            timestamp=time.time(),
            has_screenshot=has_screenshot,
            pipeline_state=pipeline_state,
            metadata=metadata,
        )
        self.entries.append(entry)
        self._seq += 1
        return entry

    def to_list(self) -> list[dict]:
        """Return JSON-serializable list of event dicts."""
        return [e.to_dict() for e in self.entries]


def event_screenshot_filename(seq: int, event: str) -> str:
    """Return the filename for an event screenshot."""
    return f"event_{seq:02d}_{event}.jpg"
