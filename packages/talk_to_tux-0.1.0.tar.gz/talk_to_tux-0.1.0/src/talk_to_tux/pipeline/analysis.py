"""Auto-analysis of pipeline feedback runs via BAML AnalyzeFeedback."""
from __future__ import annotations

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def _load_image(path: Path):
    """Load image as baml_py.Image if file exists, else None."""
    if not path.exists():
        return None
    try:
        import base64

        from baml_py import Image

        return Image.from_base64(
            "image/jpeg", base64.b64encode(path.read_bytes()).decode()
        )
    except Exception:
        return None


async def analyze_run(
    cache, run_dir: Path, mark_reviewed: bool = True
) -> dict | None:
    """Analyze a single run via BAML. Returns analysis dict or None on failure."""
    cache.load_run(run_dir.name)
    feedback = cache.load_feedback()
    if feedback is None:
        logger.debug("Skip %s: no feedback.json", run_dir.name)
        return None

    record_json = json.dumps(feedback, indent=2)

    # Load screenshots — prefer event-based, fall back to legacy filenames
    pre_ss = None
    tooltip_shown = None
    tooltip_interaction = None
    post_immediate = None
    post_delayed = None

    event_log = cache.load_event_log()
    if event_log:
        event_files = {
            e["event"]: f"event_{e['seq']:02d}_{e['event']}.jpg"
            for e in event_log
            if e.get("has_screenshot")
        }
        pre_ss = _load_image(run_dir / event_files.get("recording_start", ""))
        tooltip_shown = _load_image(run_dir / event_files.get("tooltip_ready", ""))
        tooltip_interaction = _load_image(
            run_dir / event_files.get("tooltip_click", "")
        )
        post_immediate = _load_image(
            run_dir / event_files.get("paste_complete", "")
        )
        post_delayed = _load_image(run_dir / event_files.get("settled", ""))

    # Fall back to legacy filenames
    if pre_ss is None:
        pre_ss = _load_image(run_dir / "screenshot.jpg")
    if tooltip_shown is None:
        tooltip_shown = _load_image(run_dir / "tooltip_shown.jpg")
    if tooltip_interaction is None:
        tooltip_interaction = _load_image(run_dir / "tooltip_click.jpg")
    if post_immediate is None:
        post_immediate = _load_image(run_dir / "post_paste_0.jpg")
    if post_delayed is None:
        post_delayed = _load_image(run_dir / "post_paste_1.jpg")

    try:
        from baml_client.async_client import b

        result = await b.AnalyzeFeedback(
            record_json=record_json,
            pre_recording_screenshot=pre_ss,
            tooltip_shown_screenshot=tooltip_shown,
            tooltip_interaction_screenshot=tooltip_interaction,
            post_paste_screenshot_immediate=post_immediate,
            post_paste_screenshot_delayed=post_delayed,
        )

        analysis = {
            "summary": result.summary,
            "issues": [
                {
                    "category": i.category,
                    "severity": i.severity,
                    "description": i.description,
                    "suggestion": i.suggestion,
                }
                for i in result.issues
            ],
            "paste_accuracy_score": result.paste_accuracy_score,
            "context_quality_score": result.context_quality_score,
            "latency_assessment": result.latency_assessment,
            "tooltip_ux_notes": result.tooltip_ux_notes,
            "recommendations": result.recommendations,
        }

        cache.save_analysis(analysis)
        if mark_reviewed:
            cache.mark_reviewed(run_dir.name)

        return analysis
    except Exception:
        logger.debug("Failed to analyze run %s", run_dir.name, exc_info=True)
        return None
