from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)

# Track the currently active notification process so it can be cancelled
_active_proc: asyncio.subprocess.Process | None = None


def cancel_active_notification() -> None:
    """Kill the in-flight notify-send process, dismissing any visible notification.

    Safe to call from any asyncio context.  No-op if nothing is active.
    """
    global _active_proc
    if _active_proc is not None:
        try:
            _active_proc.kill()
        except ProcessLookupError:
            pass  # already exited
        _active_proc = None
        # Dismiss visible GNOME toast by replacing with instant-expire notification
        import subprocess
        try:
            subprocess.Popen(
                ["notify-send", "-t", "1",
                 "-h", "string:x-canonical-private-synchronous:talk-to-tux",
                 "", ""],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except FileNotFoundError:
            pass


async def notify(
    title: str,
    body: str,
    urgency: str = "normal",
    timeout_ms: int | None = None,
    actions: dict[str, str] | None = None,
) -> str | None:
    """Send desktop notification via notify-send.

    Returns the action name clicked by the user, or ``None`` if the
    notification timed out / was dismissed / actions are unsupported.
    """
    global _active_proc
    try:
        cmd: list[str] = [
            "notify-send",
            "-u", urgency,
            "-a", "Talk-to-Tux",
            "-h", "string:x-canonical-private-synchronous:talk-to-tux",
        ]
        if timeout_ms is not None:
            cmd += ["-t", str(timeout_ms)]
        if actions:
            for key, label in actions.items():
                cmd += ["-A", f"{key}={label}"]
        cmd += [title, body]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _active_proc = proc
        # GNOME ignores -t when --wait is active (implied by -A), so
        # enforce our own timeout by killing the process.
        timeout_s = timeout_ms / 1000 if timeout_ms is not None else None
        try:
            stdout, _ = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return None
        finally:
            if _active_proc is proc:
                _active_proc = None
        if proc.returncode == 0 and stdout:
            return stdout.decode().strip() or None
        return None
    except Exception:
        logger.debug("notify-send failed", exc_info=True)
        return None
