"""FeedbackCollector — accumulates full pipeline state per run for quality analysis."""
from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class FeedbackCollector:
    """Accumulates pipeline state for a single run.

    Pure Python — no BAML runtime dependency.  Produces dicts matching the
    BAML ``PipelineFeedbackRecord`` schema so they can be loaded by the
    analysis script.
    """

    run_id: str | None = None
    timestamp: float = field(default_factory=time.time)
    trigger_type: str = "unknown"
    pipeline_outcome: str = "unknown"
    user_action: str | None = None
    total_ms: float | None = None

    # Stage timings
    stages: list[dict] = field(default_factory=list)

    # Context snapshots
    pre_recording_context: dict | None = None
    recording_context: dict | None = None
    post_paste_context_immediate: dict | None = None
    post_paste_context_delayed: dict | None = None

    audio_duration_ms: float | None = None

    # STT
    stt: dict | None = None

    # Rewrite
    rewrite: dict | None = None

    # Paste
    paste: dict | None = None

    # Tooltip
    tooltip: dict | None = None
    tooltip_interactions: list[dict] = field(default_factory=list)

    # Paste decision
    paste_decision_action: str | None = None
    paste_decision_reason: str | None = None

    # Rewrite option texts (for tooltip multi-option)
    rewrite_options: list[str] = field(default_factory=list)

    # Event log
    event_log: list[dict] = field(default_factory=list)

    # Correction log
    correction_log: list[dict] = field(default_factory=list)

    # Review state
    reviewed: bool = False
    review_timestamp: float | None = None

    # --- Capture methods ---

    def set_trigger(self, trigger_type: str) -> None:
        self.trigger_type = trigger_type

    def capture_pre_recording(self, ctx: object | None) -> None:
        self.pre_recording_context = _context_to_dict(ctx)

    def capture_recording_context(self, ctx: object | None) -> None:
        self.recording_context = _context_to_dict(ctx)

    def capture_stt(self, result: object, duration_ms: float) -> None:
        self.stt = {
            "provider": getattr(result, "source", "unknown"),
            "text": getattr(result, "text", ""),
            "chain_position": getattr(result, "chain_position", None),
            "chain_length": getattr(result, "chain_length", None),
            "failures": list(getattr(result, "failures", [])),
            "duration_ms": duration_ms,
        }

    def capture_rewrite(self, rewrite: object, duration_ms: float) -> None:
        self.rewrite = {
            "source": getattr(rewrite, "source", "unknown"),
            "provider": getattr(rewrite, "provider", None),
            "text": getattr(rewrite, "text", ""),
            "format": getattr(rewrite, "format", ""),
            "reasoning": getattr(rewrite, "reasoning", ""),
            "duration_ms": duration_ms,
        }

    def set_paste_decision(self, action: str, reason: str) -> None:
        self.paste_decision_action = action
        self.paste_decision_reason = reason

    def capture_paste(
        self,
        text: str,
        ctx: object | None,
        duration_ms: float,
        success: bool,
    ) -> None:
        self.paste = {
            "text": text,
            "target_window_class": getattr(ctx, "window_class", None),
            "target_window_id": getattr(ctx, "window_id", None),
            "duration_ms": duration_ms,
            "success": success,
        }

    def capture_tooltip(
        self,
        options_count: int,
        selected_index: int | None = None,
        shown_duration_ms: float | None = None,
        confirm_method: str | None = None,
        was_edited: bool = False,
        edited_text: str | None = None,
    ) -> None:
        self.tooltip = {
            "options_count": options_count,
            "selected_index": selected_index,
            "shown_duration_ms": shown_duration_ms,
            "confirm_method": confirm_method,
            "was_edited": was_edited,
            "edited_text": edited_text,
        }

    def capture_post_paste_immediate(self, ctx: object | None) -> None:
        self.post_paste_context_immediate = _context_to_dict(ctx)

    def capture_post_paste_delayed(self, ctx: object | None) -> None:
        self.post_paste_context_delayed = _context_to_dict(ctx)

    def add_tooltip_interaction(self, event: str, ts: float | None = None) -> None:
        self.tooltip_interactions.append({
            "event": event,
            "timestamp": ts if ts is not None else time.time(),
        })

    def set_user_action(self, action: str) -> None:
        self.user_action = action

    def set_outcome(self, outcome: str) -> None:
        self.pipeline_outcome = outcome

    def set_total_ms(self, ms: float) -> None:
        self.total_ms = ms

    def add_stage(
        self,
        stage: str,
        duration_ms: float,
        ok: bool = True,
        detail: str | None = None,
    ) -> None:
        entry: dict = {
            "stage": stage,
            "duration_ms": duration_ms,
            "ok": ok,
        }
        if detail is not None:
            entry["detail"] = detail
        self.stages.append(entry)

    def add_rewrite_option(self, text: str) -> None:
        self.rewrite_options.append(text)

    def set_event_log(self, events: list[dict]) -> None:
        self.event_log = events

    def record_correction(
        self,
        pasted: str,
        submitted: str,
        method: str,
        app_class: str | None = None,
        widget_role: str | None = None,
        stt_text: str | None = None,
    ) -> None:
        """Record a correction observation."""
        self.correction_log.append({
            "pasted": pasted,
            "submitted": submitted,
            "method": method,
            "app_class": app_class,
            "widget_role": widget_role,
            "stt_text": stt_text,
        })

    # --- Serialization ---

    def to_dict(self) -> dict:
        """Return JSON-serializable dict matching PipelineFeedbackRecord schema."""
        return {
            "run_id": self.run_id,
            "timestamp": self.timestamp,
            "trigger_type": self.trigger_type,
            "pipeline_outcome": self.pipeline_outcome,
            "user_action": self.user_action,
            "total_ms": self.total_ms,
            "stages": self.stages,
            "pre_recording_context": self.pre_recording_context,
            "recording_context": self.recording_context,
            "post_paste_context_immediate": self.post_paste_context_immediate,
            "post_paste_context_delayed": self.post_paste_context_delayed,
            "audio_duration_ms": self.audio_duration_ms,
            "stt": self.stt,
            "rewrite": self.rewrite,
            "paste": self.paste,
            "tooltip": self.tooltip,
            "tooltip_interactions": self.tooltip_interactions,
            "paste_decision_action": self.paste_decision_action,
            "paste_decision_reason": self.paste_decision_reason,
            "rewrite_options": self.rewrite_options,
            "event_log": self.event_log,
            "correction_log": self.correction_log,
            "reviewed": self.reviewed,
            "review_timestamp": self.review_timestamp,
        }


def _context_to_dict(ctx: object | None) -> dict | None:
    """Extract AppContext fields as dict, excluding screenshot bytes."""
    if ctx is None:
        return None
    return {
        "timestamp": getattr(ctx, "timestamp", None),
        "window_id": getattr(ctx, "window_id", None),
        "window_title": getattr(ctx, "window_title", None),
        "window_class": getattr(ctx, "window_class", None),
        "window_instance": getattr(ctx, "window_instance", None),
        "window_pid": getattr(ctx, "window_pid", None),
        "widget_role": getattr(ctx, "widget_role", None),
        "widget_name": getattr(ctx, "widget_name", None),
        "cursor_widget_role": getattr(ctx, "cursor_widget_role", None),
        "cursor_widget_name": getattr(ctx, "cursor_widget_name", None),
        "caret_offset": getattr(ctx, "caret_offset", None),
        "screenshot_width": getattr(ctx, "screenshot_width", None),
        "screenshot_height": getattr(ctx, "screenshot_height", None),
        "text_around_caret": getattr(ctx, "text_around_caret", None),
    }
