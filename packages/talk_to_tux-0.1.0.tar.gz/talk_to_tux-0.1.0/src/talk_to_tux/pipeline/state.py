from __future__ import annotations

from enum import Enum, auto


class PipelineState(Enum):
    """States for the tooltip confirmation pipeline."""

    IDLE = auto()
    RECORDING = auto()
    PROCESSING = auto()
    TOOLTIP_SHOWN = auto()
    PASTING = auto()
