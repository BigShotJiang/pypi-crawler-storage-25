"""Builds deterministic, layered context blocks for KV cache optimization.

Context is structured in layers ordered by change frequency:
  Layer 1: Immutable rules (in BAML prompt)
  Layer 2: Static app info (rarely changes — windows open/close)
  Layer 3: Semi-static window state (changes on tab switch, cd, etc.)
  Layer 4: Dynamic internal context (AT-SPI text content, on-change)
  Layer 5: Screenshots (periodic, for windows lacking metadata)
  Layer 6: Per-request (active window + transcription)

Deterministic sorting by window_id ensures identical prefix across requests
when nothing changes, maximizing KV cache hits on local LLM backends.
"""
from __future__ import annotations

import hashlib
import logging

from talk_to_tux.context.models import AppContext

logger = logging.getLogger(__name__)

_SHELLS = frozenset({"bash", "zsh", "fish", "sh", "dash", "ksh", "tcsh", "csh", "nu"})

# Map window class to human-readable app type
_APP_TYPES: dict[str, str] = {
    # Terminals
    "kitty": "terminal",
    "Alacritty": "terminal",
    "alacritty": "terminal",
    "gnome-terminal-server": "terminal",
    "Gnome-terminal": "terminal",
    "foot": "terminal",
    "wezterm": "terminal",
    "Wezterm": "terminal",
    "konsole": "terminal",
    "Konsole": "terminal",
    "xterm": "terminal",
    "XTerm": "terminal",
    "Terminator": "terminal",
    "Tilix": "terminal",
    "st-256color": "terminal",
    "urxvt": "terminal",
    "URxvt": "terminal",
    "rio": "terminal",
    "sakura": "terminal",
    "lxterminal": "terminal",
    "mate-terminal": "terminal",
    "Xfce4-terminal": "terminal",
    # Code editors / IDEs
    "Code": "code-editor",
    "code": "code-editor",
    "vscodium": "code-editor",
    "VSCodium": "code-editor",
    "Sublime_text": "code-editor",
    "jetbrains-idea": "code-editor",
    "jetbrains-pycharm": "code-editor",
    "jetbrains-clion": "code-editor",
    "jetbrains-goland": "code-editor",
    "jetbrains-webstorm": "code-editor",
    "jetbrains-rider": "code-editor",
    "Emacs": "code-editor",
    "emacs": "code-editor",
    "Neovide": "code-editor",
    "neovide": "code-editor",
    # Browsers
    "Firefox": "browser",
    "firefox": "browser",
    "chromium": "browser",
    "Chromium": "browser",
    "Google-chrome": "browser",
    "google-chrome": "browser",
    "Brave-browser": "browser",
    # Chat / messaging
    "Slack": "chat",
    "discord": "chat",
    "Discord": "chat",
    "Element": "chat",
    "Telegram": "chat",
    "telegram-desktop": "chat",
    "Signal": "chat",
    # Text editors
    "Gedit": "text-editor",
    "gedit": "text-editor",
    "org.gnome.TextEditor": "text-editor",
    "mousepad": "text-editor",
    # Document / office
    "libreoffice": "document",
    "Soffice": "document",
    # File managers
    "Nautilus": "file-manager",
    "nautilus": "file-manager",
    "Thunar": "file-manager",
}


def classify_window(w: AppContext) -> str:
    """Return the app-type classification string for a window.

    For terminals with a /proc-detected `terminal_info`, expands the classification
    to reflect what's actually running (TUI app, SSH session, multiplexer). Used by
    both `build_static` (KNOWN APPLICATIONS list) and the TARGET WINDOW line so the
    enriched tag is salient next to the active window, not buried in a list.
    """
    app_type = _APP_TYPES.get(w.window_class or "", "unknown")
    if app_type == "terminal" and w.terminal_info:
        ti = w.terminal_info
        if ti.tui_apps:
            primary = ti.tui_apps[0]
            app_type = f"terminal running {primary[0]} ({primary[1]})"
            if len(ti.tui_apps) > 1:
                others = ", ".join(f"{n} ({t})" for n, t in ti.tui_apps[1:])
                app_type += f" [also: {others}]"
        elif ti.active_pane_command and ti.active_pane_command in _SHELLS:
            app_type = "terminal (shell prompt)"
        elif ti.has_ssh:
            host = f" to {ti.ssh_remote_host}" if ti.ssh_remote_host else ""
            if ti.remote_multiplexer_hint:
                app_type = f"terminal (SSH{host} — remote {ti.remote_multiplexer_hint} detected, use screenshot)"
            else:
                app_type = f"terminal (SSH{host} — use screenshot)"
        elif ti.multiplexer:
            app_type = f"terminal ({ti.multiplexer} multiplexer — use screenshot)"
    return app_type



class ContextPacker:
    """Builds layered context blocks with on-change hash tracking.

    Args:
        budget_tokens: Maximum token budget for context layers (estimated as len//4).
    """

    def __init__(self, budget_tokens: int = 4900) -> None:
        self._budget = budget_tokens
        self._hashes: dict[str, str] = {}  # window_id -> hash of dynamic context

    def build_static(self, windows: list[AppContext]) -> str:
        """Layer 2: App classification. Rarely changes."""
        if not windows:
            return "(no windows)"
        sorted_wins = sorted(windows, key=lambda w: w.window_id or "")
        lines = []
        for i, w in enumerate(sorted_wins, 1):
            lines.append(f"[{i}] {w.window_class or '?'} — {classify_window(w)}")
        return "\n".join(lines)

    def build_dynamic(self, windows: list[AppContext]) -> str:
        """Layer 3: Window state. Updated on-change."""
        if not windows:
            return ""
        sorted_wins = sorted(windows, key=lambda w: w.window_id or "")
        lines = []
        for i, w in enumerate(sorted_wins, 1):
            parts = [f"[{i}] {w.window_class or '?'}:"]
            if w.window_title:
                parts.append(f'title="{w.window_title}"')
            if w.widget_role:
                widget = w.widget_role
                if w.widget_name:
                    widget += f" ({w.widget_name})"
                parts.append(f"widget={widget}")
            if w.cursor_widget_role:
                parts.append(f"cursor_at={w.cursor_widget_role}")
            lines.append(" ".join(parts))
        return "\n".join(lines)

    def build_internal_context(self, windows: list[AppContext]) -> str:
        """Layer 4: Dynamic internal context from AT-SPI text."""
        parts = []
        for w in sorted(windows, key=lambda w: w.window_id or ""):
            text_around = getattr(w, "text_around_caret", None)
            text_content = getattr(w, "text_content", None)
            if text_around:
                parts.append(f"[{w.window_class}] near cursor:\n{text_around[:500]}")
            elif text_content:
                parts.append(f"[{w.window_class}] visible:\n{text_content[-500:]}")
        return "\n---\n".join(parts) if parts else ""

    def has_changed(self, window: AppContext) -> bool:
        """Check if this window's dynamic context changed since last pack."""
        text = self.build_dynamic([window])
        h = hashlib.sha1(text.encode()).hexdigest()[:12]
        wid = window.window_id or ""
        old = self._hashes.get(wid)
        self._hashes[wid] = h
        return old != h

    def trim_to_budget(
        self,
        static: str,
        dynamic: str,
        internal: str = "",
        screenshot_tokens: int = 0,
    ) -> tuple[str, str, str, bool]:
        """Trim context to fit budget.

        Returns (static, dynamic, internal, include_screenshot).
        Trimming priority: screenshots first, then internal context, then dynamic.
        """
        est = (len(static) + len(dynamic) + len(internal)) // 4 + screenshot_tokens
        if est <= self._budget:
            return static, dynamic, internal, True
        # Drop screenshot first (largest token cost)
        est -= screenshot_tokens
        if est <= self._budget:
            return static, dynamic, internal, False
        # Drop internal context
        if internal:
            est -= len(internal) // 4
            if est <= self._budget:
                return static, dynamic, "", False
        # Trim dynamic context: remove lines from the end (oldest windows)
        while est > self._budget and dynamic:
            lines = dynamic.split("\n")
            if len(lines) <= 1:
                break
            lines.pop()
            dynamic = "\n".join(lines)
            est = (len(static) + len(dynamic)) // 4
        return static, dynamic, "", False
