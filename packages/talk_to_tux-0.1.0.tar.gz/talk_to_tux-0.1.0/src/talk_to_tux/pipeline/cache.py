from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


class PipelineCache:
    """Persistent cache for pipeline runs under ~/.cache/talk-to-tux/runs/."""

    def __init__(
        self,
        enabled: bool = True,
        cache_dir: Path | None = None,
        max_age_hours: float = 72.0,
        max_runs: int = 50,
    ) -> None:
        self._enabled = enabled
        if cache_dir is None:
            xdg = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
            cache_dir = Path(xdg) / "talk-to-tux" / "runs"
        self._cache_dir = cache_dir
        self._max_age_hours = max_age_hours
        self._max_runs = max_runs
        self._run_dir: Path | None = None

    def begin_run(self) -> Path | None:
        """Create a new run directory and update the latest symlink."""
        if not self._enabled:
            return None
        run_id = datetime.now().strftime("%Y%m%d-%H%M%S-%f")[:23]  # trim microseconds to millis
        self._run_dir = self._cache_dir / run_id
        self._run_dir.mkdir(parents=True, exist_ok=True)
        self._save_status("started", "")
        # Update latest symlink
        latest = self._cache_dir / "latest"
        try:
            latest.unlink(missing_ok=True)
            latest.symlink_to(run_id)
        except OSError:
            logger.debug("Failed to update latest symlink", exc_info=True)
        return self._run_dir

    def load_run(self, run_id: str | None = None) -> Path | None:
        """Load an existing run. If run_id is None, use latest symlink."""
        if not self._enabled:
            return None
        if run_id is None or run_id == "latest":
            latest = self._cache_dir / "latest"
            if latest.is_symlink():
                self._run_dir = self._cache_dir / latest.resolve().name
            else:
                return None
        else:
            self._run_dir = self._cache_dir / run_id
        if self._run_dir.is_dir():
            return self._run_dir
        self._run_dir = None
        return None

    # --- Write methods (fire-and-forget, never raise) ---

    def save_audio(self, wav_bytes: bytes) -> None:
        if self._run_dir is None:
            return
        try:
            (self._run_dir / "audio.wav").write_bytes(wav_bytes)
        except Exception:
            logger.debug("Failed to save audio", exc_info=True)

    def save_screenshot(self, screenshot_bytes: bytes) -> None:
        if self._run_dir is None:
            return
        try:
            (self._run_dir / "screenshot.jpg").write_bytes(screenshot_bytes)
        except Exception:
            logger.debug("Failed to save screenshot", exc_info=True)

    def save_context(self, context) -> None:
        """Save window metadata (not screenshot bytes) as JSON."""
        if self._run_dir is None:
            return
        try:
            data = {
                "timestamp": context.timestamp,
                "window_title": context.window_title,
                "window_class": context.window_class,
                "window_instance": context.window_instance,
                "window_pid": context.window_pid,
                "screenshot_width": context.screenshot_width,
                "screenshot_height": context.screenshot_height,
                "widget_role": context.widget_role,
                "widget_name": context.widget_name,
                "caret_offset": context.caret_offset,
                "window_id": context.window_id,
                "cursor_widget_role": context.cursor_widget_role,
                "cursor_widget_name": context.cursor_widget_name,
            }
            (self._run_dir / "context.json").write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
            # Save screenshot separately if present
            if context.screenshot_png:
                self.save_screenshot(context.screenshot_png)
        except Exception:
            logger.debug("Failed to save context", exc_info=True)

    def save_stt(self, result) -> None:
        if self._run_dir is None:
            return
        try:
            data = {"text": result.text, "source": result.source}
            (self._run_dir / "stt.json").write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
            self._save_status("stt", "")
        except Exception:
            logger.debug("Failed to save STT result", exc_info=True)

    def save_rewrite(self, result) -> None:
        if self._run_dir is None:
            return
        try:
            data = {
                "text": result.text,
                "format": result.format,
                "reasoning": result.reasoning,
                "source": result.source,
            }
            (self._run_dir / "rewrite.json").write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
            self._save_status("rewrite", "")
        except Exception:
            logger.debug("Failed to save rewrite result", exc_info=True)

    def save_telemetry(self, telemetry) -> None:
        if self._run_dir is None:
            return
        try:
            (self._run_dir / "telemetry.json").write_text(
                json.dumps(telemetry.to_dict(), indent=2), encoding="utf-8"
            )
        except Exception:
            logger.debug("Failed to save telemetry", exc_info=True)

    def load_telemetry(self) -> dict | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / "telemetry.json"
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to load telemetry", exc_info=True)
            return None

    # --- Feedback persistence (fire-and-forget) ---

    def save_feedback(self, collector) -> None:
        """Save feedback.json from a FeedbackCollector."""
        if self._run_dir is None:
            return
        try:
            (self._run_dir / "feedback.json").write_text(
                json.dumps(collector.to_dict(), indent=2), encoding="utf-8"
            )
        except Exception:
            logger.debug("Failed to save feedback", exc_info=True)

    def load_feedback(self) -> dict | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / "feedback.json"
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to load feedback", exc_info=True)
            return None

    def save_post_paste_screenshot(self, data: bytes, idx: int) -> None:
        """Save a post-paste screenshot (idx=0 immediate, idx=1 delayed)."""
        if self._run_dir is None:
            return
        try:
            (self._run_dir / f"post_paste_{idx}.jpg").write_bytes(data)
        except Exception:
            logger.debug("Failed to save post-paste screenshot %d", idx, exc_info=True)

    def load_post_paste_screenshot(self, idx: int) -> bytes | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / f"post_paste_{idx}.jpg"
        return p.read_bytes() if p.exists() else None

    def save_tooltip_screenshot(self, event: str, data: bytes) -> None:
        """Save a tooltip interaction screenshot (e.g. tooltip_shown.jpg)."""
        if self._run_dir is None:
            return
        try:
            (self._run_dir / f"tooltip_{event}.jpg").write_bytes(data)
        except Exception:
            logger.debug("Failed to save tooltip screenshot %s", event, exc_info=True)

    def load_tooltip_screenshot(self, event: str) -> bytes | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / f"tooltip_{event}.jpg"
        return p.read_bytes() if p.exists() else None

    def mark_reviewed(self, run_id: str | None = None) -> bool:
        """Set reviewed=True + timestamp in feedback.json. Returns True if updated."""
        target = self._run_dir
        if run_id is not None:
            target = self._cache_dir / run_id
        if target is None or not target.is_dir():
            return False
        p = target / "feedback.json"
        if not p.exists():
            return False
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            data["reviewed"] = True
            data["review_timestamp"] = time.time()
            p.write_text(json.dumps(data, indent=2), encoding="utf-8")
            return True
        except Exception:
            logger.debug("Failed to mark reviewed", exc_info=True)
            return False

    # --- Event log persistence (fire-and-forget) ---

    def save_event_screenshot(self, filename: str, data: bytes) -> None:
        """Save an event screenshot (e.g. event_00_recording_start.jpg)."""
        if self._run_dir is None:
            return
        try:
            (self._run_dir / filename).write_bytes(data)
        except Exception:
            logger.debug("Failed to save event screenshot %s", filename, exc_info=True)

    def save_event_log(self, event_log) -> None:
        """Save events.json manifest from an EventLog."""
        if self._run_dir is None:
            return
        try:
            (self._run_dir / "events.json").write_text(
                json.dumps(event_log.to_list(), indent=2), encoding="utf-8"
            )
        except Exception:
            logger.debug("Failed to save event log", exc_info=True)

    def load_event_log(self) -> list[dict] | None:
        """Load events.json manifest. Returns list of event dicts or None."""
        if self._run_dir is None:
            return None
        p = self._run_dir / "events.json"
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to load event log", exc_info=True)
            return None

    def save_analysis(self, analysis_dict: dict) -> None:
        """Save analysis.json (AnalyzeFeedback result)."""
        if self._run_dir is None:
            return
        try:
            (self._run_dir / "analysis.json").write_text(
                json.dumps(analysis_dict, indent=2), encoding="utf-8"
            )
        except Exception:
            logger.debug("Failed to save analysis", exc_info=True)

    def load_analysis(self) -> dict | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / "analysis.json"
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to load analysis", exc_info=True)
            return None

    @staticmethod
    def has_unreviewed_feedback(run_dir: Path) -> bool:
        """Check if a run has feedback.json with reviewed=False."""
        p = run_dir / "feedback.json"
        if not p.exists():
            return False
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            return not data.get("reviewed", False)
        except Exception:
            return False

    def list_unreviewed_runs(self, limit: int = 50) -> list[Path]:
        """Return unreviewed runs (newest first)."""
        if not self._enabled or not self._cache_dir.exists():
            return []
        try:
            runs = sorted(
                [d for d in self._cache_dir.iterdir()
                 if d.is_dir() and d.name != "latest"],
                key=lambda d: d.name,
                reverse=True,
            )
            result = []
            for run_dir in runs:
                if self.has_unreviewed_feedback(run_dir):
                    result.append(run_dir)
                    if len(result) >= limit:
                        break
            return result
        except Exception:
            logger.debug("Failed to list unreviewed runs", exc_info=True)
            return []

    def save_done(self) -> None:
        self._save_status("done", "")

    def finalize_run(self) -> None:
        """Clear the in-memory run handle. Idempotent; safe in a finally."""
        self._run_dir = None

    def save_error(self, stage: str, error: str) -> None:
        self._save_status(stage, error)

    def save_early_exit(self, reason: str) -> None:
        """Mark run as finished due to early exit (no_audio, no_speech)."""
        self._save_status(reason, "")

    def _save_status(self, stage: str, error: str) -> None:
        if self._run_dir is None:
            return
        try:
            data = {"stage": stage, "ts": time.time(), "error": error}
            (self._run_dir / "status.json").write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
        except Exception:
            logger.debug("Failed to save status", exc_info=True)

    # --- Read methods (for retry) ---

    def load_audio(self) -> bytes | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / "audio.wav"
        return p.read_bytes() if p.exists() else None

    def load_context(self):
        """Load context from JSON. Returns AppContext or None."""
        if self._run_dir is None:
            return None
        p = self._run_dir / "context.json"
        if not p.exists():
            return None
        try:
            from talk_to_tux.context.models import AppContext
            data = json.loads(p.read_text(encoding="utf-8"))
            # Load screenshot if available
            ss_path = self._run_dir / "screenshot.jpg"
            screenshot_bytes = ss_path.read_bytes() if ss_path.exists() else None
            return AppContext(
                timestamp=data.get("timestamp", 0.0),
                window_title=data.get("window_title"),
                window_class=data.get("window_class"),
                window_instance=data.get("window_instance"),
                window_pid=data.get("window_pid"),
                screenshot_png=screenshot_bytes,
                screenshot_width=data.get("screenshot_width", 0),
                screenshot_height=data.get("screenshot_height", 0),
                widget_role=data.get("widget_role"),
                widget_name=data.get("widget_name"),
                caret_offset=data.get("caret_offset"),
                window_id=data.get("window_id"),
                cursor_widget_role=data.get("cursor_widget_role"),
                cursor_widget_name=data.get("cursor_widget_name"),
            )
        except Exception:
            logger.debug("Failed to load context", exc_info=True)
            return None

    def load_stt(self):
        """Load TranscriptionResult or None."""
        if self._run_dir is None:
            return None
        p = self._run_dir / "stt.json"
        if not p.exists():
            return None
        try:
            from talk_to_tux.stt.client import TranscriptionResult
            data = json.loads(p.read_text(encoding="utf-8"))
            return TranscriptionResult(text=data["text"], source=data["source"])
        except Exception:
            logger.debug("Failed to load STT result", exc_info=True)
            return None

    def load_rewrite(self):
        """Load RewriteOutput or None."""
        if self._run_dir is None:
            return None
        p = self._run_dir / "rewrite.json"
        if not p.exists():
            return None
        try:
            from talk_to_tux.pipeline.rewrite import RewriteOutput
            data = json.loads(p.read_text(encoding="utf-8"))
            return RewriteOutput(
                text=data["text"],
                format=data["format"],
                reasoning=data["reasoning"],
                source=data["source"],
            )
        except Exception:
            logger.debug("Failed to load rewrite result", exc_info=True)
            return None

    def load_status(self) -> dict | None:
        if self._run_dir is None:
            return None
        p = self._run_dir / "status.json"
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to load status", exc_info=True)
            return None

    # --- Listing ---

    def list_runs(self, limit: int = 20) -> list[Path]:
        """Return sorted run directories (newest first), up to limit."""
        if not self._enabled or not self._cache_dir.exists():
            return []
        try:
            runs = sorted(
                [d for d in self._cache_dir.iterdir()
                 if d.is_dir() and d.name != "latest"],
                key=lambda d: d.name,
                reverse=True,
            )
            return runs[:limit]
        except Exception:
            logger.debug("Failed to list runs", exc_info=True)
            return []

    # --- Eviction ---

    def evict(self) -> int:
        """Remove old runs. Returns number of runs removed."""
        if not self._enabled or not self._cache_dir.exists():
            return 0
        removed = 0
        try:
            runs = sorted(
                [d for d in self._cache_dir.iterdir() if d.is_dir()],
                key=lambda d: d.name,
            )
            now = time.time()
            cutoff = now - self._max_age_hours * 3600

            # Remove by age (skip unreviewed feedback)
            remaining = []
            for run_dir in runs:
                status_file = run_dir / "status.json"
                if status_file.exists():
                    try:
                        data = json.loads(status_file.read_text(encoding="utf-8"))
                        if data.get("ts", 0) < cutoff:
                            if self.has_unreviewed_feedback(run_dir):
                                remaining.append(run_dir)
                                continue
                            _rmtree(run_dir)
                            removed += 1
                            continue
                    except Exception:
                        pass
                remaining.append(run_dir)

            # Remove by count (keep newest max_runs, skip unreviewed)
            if len(remaining) > self._max_runs:
                excess = remaining[: len(remaining) - self._max_runs]
                for run_dir in excess:
                    if self.has_unreviewed_feedback(run_dir):
                        continue
                    _rmtree(run_dir)
                    removed += 1

        except Exception:
            logger.debug("Eviction error", exc_info=True)
        return removed


def _rmtree(path: Path) -> None:
    """Remove directory tree."""
    import shutil
    shutil.rmtree(path, ignore_errors=True)
