"""CorrectionLearner — accumulates STT correction patterns from user edits."""
from __future__ import annotations

import difflib
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)


class CorrectionLearner:
    """Manages correction dictionary and keyterms accumulation.

    Loaded at startup, queried synchronously on hot path (dict lookups only),
    updated asynchronously off hot path.
    """

    def __init__(
        self,
        config_dir: Path,
        min_occurrences: int = 3,
        max_keyterms: int = 100,
    ) -> None:
        self._config_dir = config_dir
        self._min_occurrences = min_occurrences
        self._max_keyterms = max_keyterms
        self._corrections_path = config_dir / "corrections.toml"
        self._keyterms_path = config_dir / "keyterms.toml"

        # In-memory state
        self._counts: dict[str, int] = {}  # wrong_word -> count
        self._mapping: dict[str, str] = {}  # wrong_word -> right_word

        # Load persisted state
        self._load()

    def _load(self) -> None:
        """Load corrections.toml and keyterms.toml from config dir."""
        try:
            data = _load_toml(self._corrections_path)
            corrections = data.get("corrections", {})
            counts = data.get("counts", {})
            for wrong, right in corrections.items():
                self._mapping[wrong] = right
                self._counts[wrong] = counts.get(wrong, self._min_occurrences)
        except Exception:
            logger.debug("No corrections.toml loaded", exc_info=True)

    def observe(
        self,
        pasted: str,
        submitted: str,
        app_class: str | None = None,
        stt_text: str | None = None,
    ) -> None:
        """Word-level diff: extract substitutions and increment frequency counter.

        Fire-and-forget, never raises.
        """
        try:
            subs = self._extract_substitutions(pasted, submitted)
            for old, new in subs:
                key = old.lower()
                self._mapping[key] = new
                self._counts[key] = self._counts.get(key, 0) + 1
        except Exception:
            logger.debug("observe() failed", exc_info=True)

    @staticmethod
    def _extract_substitutions(
        pasted: str, submitted: str,
    ) -> list[tuple[str, str]]:
        """Return (old, new) word-level replacements only.

        Insertions and deletions are filtered out — they're not corrections.
        """
        old_words = pasted.split()
        new_words = submitted.split()
        matcher = difflib.SequenceMatcher(None, old_words, new_words)
        subs: list[tuple[str, str]] = []
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "replace":
                # Pair up replacements word-by-word
                old_chunk = old_words[i1:i2]
                new_chunk = new_words[j1:j2]
                if len(old_chunk) == len(new_chunk):
                    for o, n in zip(old_chunk, new_chunk):
                        if o != n:
                            subs.append((o, n))
                else:
                    # Multi-word replacement — treat as single substitution
                    subs.append((" ".join(old_chunk), " ".join(new_chunk)))
        return subs

    def get_keyterms(self) -> list[str]:
        """Return corrected words seen >= min_occurrences, capped at max_keyterms."""
        terms = [
            self._mapping[k]
            for k, count in self._counts.items()
            if count >= self._min_occurrences and k in self._mapping
        ]
        # Deduplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for t in terms:
            if t not in seen:
                seen.add(t)
                unique.append(t)
        return unique[: self._max_keyterms]

    def get_corrections(self) -> dict[str, str]:
        """Return {wrong: right} mapping for corrections above threshold."""
        return {
            k: self._mapping[k]
            for k, count in self._counts.items()
            if count >= self._min_occurrences and k in self._mapping
        }

    def apply_corrections(self, text: str) -> str:
        """Word-boundary-aware regex replacement on transcript."""
        corrections = self.get_corrections()
        if not corrections:
            return text
        for wrong, right in corrections.items():
            pattern = re.compile(re.escape(wrong), re.IGNORECASE)
            text = pattern.sub(right, text)
        return text

    def promote(self) -> None:
        """Write accumulated corrections meeting threshold to TOML files.

        Called async after observe(), never on hot path.
        """
        try:
            self._config_dir.mkdir(parents=True, exist_ok=True)

            # Write corrections.toml
            corrections = self.get_corrections()
            if corrections or self._counts:
                _save_toml(self._corrections_path, {
                    "corrections": self._mapping,
                    "counts": self._counts,
                })

            # Write keyterms.toml
            keyterms = self.get_keyterms()
            if keyterms:
                _save_toml(self._keyterms_path, {
                    "terms": keyterms,
                })
        except Exception:
            logger.debug("promote() failed", exc_info=True)


def _load_toml(path: Path) -> dict:
    """Load TOML file, return empty dict if missing."""
    if not path.exists():
        return {}
    import tomllib
    with open(path, "rb") as f:
        return tomllib.load(f)


def _save_toml(path: Path, data: dict) -> None:
    """Write dict to TOML file."""
    lines: list[str] = []
    for key, value in data.items():
        if isinstance(value, dict):
            lines.append(f"[{key}]")
            for k, v in value.items():
                lines.append(f"{_toml_key(k)} = {_toml_value(v)}")
            lines.append("")
        elif isinstance(value, list):
            lines.append(f"{key} = {_toml_value(value)}")
            lines.append("")
        else:
            lines.append(f"{key} = {_toml_value(value)}")
    path.write_text("\n".join(lines), encoding="utf-8")


def _toml_key(k: str) -> str:
    """Quote TOML key if it contains special characters."""
    if re.match(r"^[A-Za-z0-9_-]+$", k):
        return k
    return f'"{k}"'


def _toml_value(v: object) -> str:
    """Format a Python value as TOML."""
    if isinstance(v, str):
        return f'"{v}"'
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return str(v)
    if isinstance(v, list):
        items = ", ".join(_toml_value(i) for i in v)
        return f"[{items}]"
    return f'"{v}"'
