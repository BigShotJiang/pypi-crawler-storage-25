from __future__ import annotations

import base64
import logging
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass

from talk_to_tux.context.models import AppContext
from talk_to_tux.pipeline.context_packer import ContextPacker, classify_window

logger = logging.getLogger(__name__)


@dataclass
class RewriteOutput:
    text: str
    format: str
    reasoning: str
    source: str  # "llm", "llm_partial", or "passthrough"
    provider: str | None = None  # e.g. "Groq", "Gemini", "Ollama"


def _build_provider_registry(
    groq_model: str = "meta-llama/llama-4-scout-17b-16e-instruct",
    gemini_model: str = "gemini-3.1-flash-lite-preview",
    local_ai_url: str = "http://ai:8002/v1",
    local_ai_model: str = "cyankiwi/gemma-4-26B-A4B-it-AWQ-4bit",
) -> tuple | None:
    """Build a BAML ClientRegistry that overrides individual clients by name.

    BAML's `SmartRewriteClient` (in baml_src/clients.baml) declares the
    fallback chain LocalAI → Groq → Gemini → Ollama. This registry injects
    user-configured models / URLs for each member but does NOT call
    `set_primary` — doing so would bypass the fallback strategy and force
    single-client mode. Returns None only if the ClientRegistry import fails.
    """
    groq_key = os.environ.get("GROQ_API_KEY", "")
    google_key = os.environ.get("GOOGLE_API_KEY", "")
    try:
        from baml_py import ClientRegistry
    except ImportError:
        return None

    cr = ClientRegistry()
    cr.add_llm_client(
        name="LocalAI",
        provider="openai-generic",
        options={
            "base_url": local_ai_url,
            "model": local_ai_model,
        },
    )
    if groq_key:
        cr.add_llm_client(
            name="Groq",
            provider="openai-generic",
            options={
                "base_url": "https://api.groq.com/openai/v1",
                "model": groq_model,
                "api_key": groq_key,
            },
        )
    if google_key:
        cr.add_llm_client(
            name="Gemini",
            provider="google-ai",
            options={
                "model": gemini_model,
                "api_key": google_key,
            },
        )
    # Primary is SmartRewriteClient (BAML-defined fallback chain).
    return cr, "SmartRewriteClient"


class SmartRewriter:
    def __init__(
        self,
        enabled: bool = True,
        app_rules: list | None = None,
        context_packer: ContextPacker | None = None,
        rewrite_config: object | None = None,
        screenshot_config: object | None = None,
    ) -> None:
        self._enabled = enabled
        self._client = None
        self._app_rules = app_rules
        self._matcher = None
        self._packer = context_packer or ContextPacker()
        self._rewrite_config = rewrite_config
        self._screenshot_config = screenshot_config
        self._registry = None
        self._registry_built = False
        self._primary_provider: str | None = None
        if app_rules:
            from talk_to_tux.config import AppRuleMatcher
            self._matcher = AppRuleMatcher(app_rules)

    def _get_client(self):
        """Lazy import of BAML async client — avoids crash if baml_client/ missing."""
        if self._client is None:
            from baml_client.async_client import b

            self._client = b
        return self._client

    def _ensure_registry(self) -> None:
        """Lazily build ClientRegistry for optimal provider routing."""
        if self._registry_built:
            return
        self._registry_built = True
        try:
            build_kwargs = {}
            if self._rewrite_config is not None:
                for field in ("groq_model", "gemini_model", "local_ai_url", "local_ai_model"):
                    if hasattr(self._rewrite_config, field):
                        build_kwargs[field] = getattr(self._rewrite_config, field)
            result = _build_provider_registry(**build_kwargs)
            if result is not None:
                self._registry, self._primary_provider = result
                logger.debug("Provider routing: %s primary", self._primary_provider)
            else:
                # No API keys → BAML default chain (Groq → Gemini → Ollama)
                # Ollama (Qwen) is last resort, so primary is effectively not Qwen
                self._primary_provider = None
        except Exception:
            logger.debug("Failed to build ClientRegistry, using defaults", exc_info=True)

    def _build_kwargs(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> dict:
        """Build kwargs for SmartRewrite BAML call with layered context."""
        windows = list(all_windows or [])
        if context is not None:
            replaced = False
            if context.window_id:
                for i, w in enumerate(windows):
                    if w.window_id == context.window_id:
                        windows[i] = context
                        replaced = True
                        break
            if not replaced:
                windows.append(context)
        static_ctx = self._packer.build_static(windows)
        dynamic_ctx = self._packer.build_dynamic(windows)
        internal_ctx = self._packer.build_internal_context(windows)
        static_ctx, dynamic_ctx, internal_ctx, include_ss = self._packer.trim_to_budget(
            static_ctx, dynamic_ctx, internal_ctx,
        )

        # Screenshots always included when available (context stuffing for LLM)
        screenshot = None
        if (
            include_ss
            and context is not None
            and context.screenshot_png is not None
        ):
            try:
                import baml_py
                from talk_to_tux.context.screenshot import ScreenshotCapturer
                preprocess_kwargs = {}
                if self._screenshot_config is not None:
                    if hasattr(self._screenshot_config, "preprocess_max_width"):
                        preprocess_kwargs["max_width"] = self._screenshot_config.preprocess_max_width
                    if hasattr(self._screenshot_config, "preprocess_jpeg_quality"):
                        preprocess_kwargs["jpeg_quality"] = self._screenshot_config.preprocess_jpeg_quality
                preprocessed = ScreenshotCapturer.preprocess_for_llm(context.screenshot_png, **preprocess_kwargs)
                encoded = base64.b64encode(preprocessed).decode()
                screenshot = baml_py.Image.from_base64("image/jpeg", encoded)
                logger.debug("Screenshot preprocessed: %d -> %d bytes", len(context.screenshot_png), len(preprocessed))
            except Exception:
                logger.debug("Failed to encode screenshot for BAML", exc_info=True)

        # Per-app rewrite hint from matched rule
        rewrite_hint = None
        if self._matcher is not None and context is not None:
            rule = self._matcher.find(context.window_class, context.window_title)
            if rule is not None and rule.rewrite_hint:
                rewrite_hint = rule.rewrite_hint

        # /no_think is Qwen-specific — only include for Ollama (Qwen) provider
        self._ensure_registry()
        thinking = "/no_think" if self._primary_provider == "Ollama" else None

        active_window_label: str | None = None
        if context is not None and context.window_class:
            active_window_label = f"{context.window_class} — {classify_window(context)}"

        return {
            "static_context": static_ctx,
            "dynamic_context": dynamic_ctx,
            "internal_context": internal_ctx or None,
            "screenshot": screenshot,
            "active_window": active_window_label,
            "transcription": transcription,
            "rewrite_hint": rewrite_hint,
            "thinking_directive": thinking,
        }

    async def rewrite(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> RewriteOutput:
        if not self._enabled:
            return self._passthrough(transcription)
        try:
            return await self._call_baml(transcription, context, all_windows)
        except Exception:
            logger.exception("Smart rewrite failed, falling back to passthrough")
            return self._passthrough(transcription)

    def _get_baml_options(self, collector=None) -> dict:
        """Return baml_options with provider registry + optional per-call collector."""
        self._ensure_registry()
        opts: dict = {}
        if self._registry is not None:
            opts["client_registry"] = self._registry
        if collector is not None:
            opts["collector"] = collector
        return opts

    @staticmethod
    def _new_collector():
        """Create a per-call BAML Collector, or None if baml_py unavailable."""
        try:
            import baml_py
            return baml_py.Collector(name="rewrite")
        except Exception:
            return None

    @staticmethod
    def _selected_member(collector) -> str | None:
        """Return the actual fallback member name BAML routed to (e.g. 'Groq')."""
        if collector is None:
            return None
        try:
            log = collector.last
            if log is None:
                return None
            call = getattr(log, "selected_call", None)
            if call is None:
                return None
            return getattr(call, "client_name", None)
        except Exception:
            return None

    async def _call_baml(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> RewriteOutput:
        client = self._get_client()
        kwargs = self._build_kwargs(transcription, context, all_windows)
        collector = self._new_collector()
        baml_options = self._get_baml_options(collector)

        if baml_options:
            result = await client.SmartRewrite(**kwargs, baml_options=baml_options)
        else:
            result = await client.SmartRewrite(**kwargs)

        fmt = result.format
        fmt_str = fmt.value if hasattr(fmt, "value") else str(fmt)
        provider = self._selected_member(collector) or self._primary_provider or "default"
        logger.info("Rewrite member: %s", provider)

        return RewriteOutput(
            text=result.text,
            format=fmt_str,
            reasoning=result.reasoning,
            source="llm",
            provider=provider,
        )

    async def rewrite_stream(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> AsyncIterator[RewriteOutput]:
        """Streaming rewrite — yields partial text, then final RewriteOutput."""
        if not self._enabled:
            yield self._passthrough(transcription)
            return
        try:
            client = self._get_client()
            kwargs = self._build_kwargs(transcription, context, all_windows)
            collector = self._new_collector()
            baml_options = self._get_baml_options(collector)
            fallback_provider = self._primary_provider or "default"

            if baml_options:
                stream = client.stream.SmartRewrite(**kwargs, baml_options=baml_options)
            else:
                stream = client.stream.SmartRewrite(**kwargs)

            async for partial in stream:
                if hasattr(partial, "text") and partial.text:
                    yield RewriteOutput(
                        text=partial.text, format="", reasoning="", source="llm_partial",
                        provider=fallback_provider,
                    )
            final = await stream.get_final_response()
            fmt = final.format
            fmt_str = fmt.value if hasattr(fmt, "value") else str(fmt)
            provider = self._selected_member(collector) or fallback_provider
            logger.info("Rewrite member (stream): %s", provider)
            yield RewriteOutput(
                text=final.text,
                format=fmt_str,
                reasoning=final.reasoning,
                source="llm",
                provider=provider,
            )
        except Exception:
            logger.exception("Streaming rewrite failed, falling back to passthrough")
            yield self._passthrough(transcription)

    @staticmethod
    def _passthrough(transcription: str) -> RewriteOutput:
        return RewriteOutput(
            text=transcription,
            format="plain",
            reasoning="",
            source="passthrough",
        )
