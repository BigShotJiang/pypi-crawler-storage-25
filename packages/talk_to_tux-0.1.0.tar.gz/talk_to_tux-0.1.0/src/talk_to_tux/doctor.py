"""Diagnostic checks for talk-to-tux system requirements."""
from __future__ import annotations

import grp
import logging
import os
import shutil
import subprocess

import httpx

from talk_to_tux.config import Settings

logger = logging.getLogger(__name__)

# Check result constants
PASS = "PASS"
FAIL = "FAIL"
WARN = "WARN"


def _fmt(status: str, label: str, detail: str) -> str:
    return f"[{status}] {label}: {detail}"


def _suggestion(text: str) -> str:
    return f"       Suggestion: {text}"


async def check_input_group() -> list[str]:
    """Check if current user is in the 'input' group (active in session)."""
    lines: list[str] = []
    try:
        input_gid = grp.getgrnam("input").gr_gid
    except KeyError:
        lines.append(_fmt(WARN, "Input group", "'input' group does not exist on this system"))
        return lines

    if input_gid in os.getgroups():
        lines.append(_fmt(PASS, "Input group", f"active (gid={input_gid})"))
    else:
        lines.append(_fmt(FAIL, "Input group", f"not in active session groups (gid={input_gid})"))
        lines.append(_suggestion(
            f"sudo usermod -aG input $USER && newgrp input  (or re-login)"
        ))
    return lines


async def check_mouse_device(settings: Settings) -> list[str]:
    """Check mouse device detection."""
    lines: list[str] = []
    try:
        from evdev import InputDevice, ecodes
        import glob as glob_mod

        candidates: list[tuple[str, str]] = []
        for path in sorted(glob_mod.glob("/dev/input/event*")):
            try:
                dev = InputDevice(path)
                caps = dev.capabilities()
                has_rel = (
                    ecodes.EV_REL in caps
                    and ecodes.REL_X in caps.get(ecodes.EV_REL, [])
                )
                has_buttons = (
                    ecodes.EV_KEY in caps
                    and ecodes.BTN_LEFT in caps.get(ecodes.EV_KEY, [])
                    and ecodes.BTN_RIGHT in caps.get(ecodes.EV_KEY, [])
                )
                if has_rel and has_buttons:
                    candidates.append((path, dev.name))
                dev.close()
            except (PermissionError, OSError):
                continue

        if settings.trigger.mouse.device_path:
            lines.append(_fmt(PASS, "Mouse device",
                              f"{settings.trigger.mouse.device_path} (configured)"))
        elif len(candidates) == 1:
            lines.append(_fmt(PASS, "Mouse device",
                              f"{candidates[0][0]} ({candidates[0][1]})"))
        elif len(candidates) > 1:
            names = ", ".join(f"{p} ({n})" for p, n in candidates)
            lines.append(_fmt(WARN, "Mouse device",
                              f"{len(candidates)} candidates found: {names}"))
            lines.append(_suggestion(
                f"Set TTT_MOUSE_DEVICE_PATH={candidates[0][0]} or run --setup"
            ))
        else:
            lines.append(_fmt(FAIL, "Mouse device", "no mouse device found"))
            lines.append(_suggestion(
                "Check that you are in the 'input' group and a mouse is connected"
            ))
    except ImportError:
        lines.append(_fmt(FAIL, "Mouse device", "evdev not installed"))
    except Exception as e:
        lines.append(_fmt(FAIL, "Mouse device", str(e)))
    return lines


async def check_keyboard_device(settings: Settings) -> list[str]:
    """Check keyboard device for hotkey chord keys."""
    lines: list[str] = []
    hotkey = settings.trigger.keyboard.hotkey
    if "+" not in hotkey:
        # Single key hotkey — just check evdev can find any keyboard
        try:
            from evdev import ecodes
            key_code = ecodes.ecodes.get(hotkey)
            if key_code is None:
                lines.append(_fmt(FAIL, "Keyboard device", f"unknown key: {hotkey}"))
                return lines
            from talk_to_tux.hotkey.listener import HotkeyListener
            paths = HotkeyListener._find_all_devices_with_key(key_code)
            lines.append(_fmt(PASS, "Keyboard device",
                              f"{len(paths)} device(s) with {hotkey}: {', '.join(paths)}"))
        except RuntimeError as e:
            lines.append(_fmt(FAIL, "Keyboard device", str(e)))
        except ImportError:
            lines.append(_fmt(FAIL, "Keyboard device", "evdev not installed"))
        except (PermissionError, OSError) as e:
            lines.append(_fmt(FAIL, "Keyboard device", f"permission error: {e}"))
        return lines

    # Chord hotkey (e.g. KEY_LEFTCTRL+KEY_LEFTMETA)
    parts = hotkey.split("+", 1)
    try:
        from evdev import InputDevice, ecodes
        import glob as glob_mod

        key_a = ecodes.ecodes.get(parts[0].strip())
        key_b = ecodes.ecodes.get(parts[1].strip())
        if key_a is None or key_b is None:
            lines.append(_fmt(FAIL, "Keyboard chord", f"unknown key(s) in: {hotkey}"))
            return lines

        if settings.trigger.keyboard.device_path:
            lines.append(_fmt(PASS, "Keyboard chord",
                              f"{settings.trigger.keyboard.device_path} (configured)"))
            return lines

        found: list[str] = []
        for path in sorted(glob_mod.glob("/dev/input/event*")):
            try:
                dev = InputDevice(path)
                caps = dev.capabilities()
                keys = caps.get(ecodes.EV_KEY, [])
                if key_a in keys and key_b in keys:
                    lines.append(_fmt(PASS, "Keyboard chord",
                                      f"{path} ({dev.name})"))
                    found.append(path)
                dev.close()
            except (PermissionError, OSError):
                continue

        if not found:
            lines.append(_fmt(WARN, "Keyboard chord",
                              f"{hotkey} not found on auto-detected device"))
            lines.append(_suggestion(
                "Set TTT_EVDEV_DEVICE_PATH=/dev/input/eventNN"
            ))
        elif len(found) > 1:
            lines.append(_fmt(PASS, "Keyboard chord",
                              f"monitoring all {len(found)} devices"))
    except ImportError:
        lines.append(_fmt(FAIL, "Keyboard chord", "evdev not installed"))
    return lines


async def check_display_server() -> list[str]:
    """Detect and validate X11 / Wayland display."""
    lines: list[str] = []
    original_display = os.environ.get("DISPLAY", "")
    original_wayland = os.environ.get("WAYLAND_DISPLAY", "")

    from talk_to_tux.context.display import detect_and_fix_display

    display = detect_and_fix_display()
    if display is None:
        lines.append(_fmt(WARN, "Display server", "no working display found"))
        lines.append(_suggestion(
            "Check that an X11 or Wayland session is running"
        ))
    elif display != original_display and display != original_wayland:
        original = original_display or original_wayland or "(unset)"
        lines.append(_fmt(WARN, "Display server",
                          f"fixed stale display ({original} -> {display})"))
    else:
        kind = "wayland" if original_wayland else "x11"
        lines.append(_fmt(PASS, "Display server", f"{kind} ({display})"))
    return lines


async def check_paste_tools() -> list[str]:
    """Check clipboard and keystroke tools."""
    lines: list[str] = []
    from talk_to_tux.paste.paster import Paster
    paster = Paster()
    tools = await paster.check_tools()
    if not tools:
        lines.append(_fmt(WARN, "Paste tools", "no display server detected"))
        return lines

    is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))

    # Separate clipboard tools from keystroke tools
    clipboard_tools = {k: v for k, v in tools.items() if k in ("wl-copy", "wl-paste", "xclip")}
    keystroke_tools = {k: v for k, v in tools.items() if k in ("wtype", "ydotool", "xdotool")}

    # Report clipboard tools
    clip_missing = [t for t, ok in clipboard_tools.items() if not ok]
    clip_present = [t for t, ok in clipboard_tools.items() if ok]
    if clip_missing:
        lines.append(_fmt(FAIL, "Clipboard tools", f"missing: {', '.join(clip_missing)}"))
        lines.append(_suggestion(f"Install: {', '.join(clip_missing)}"))
    else:
        lines.append(_fmt(PASS, "Clipboard tools", ", ".join(clip_present)))

    # Report keystroke tools (Wayland has a fallback chain)
    if is_wayland:
        ks_present = [t for t, ok in keystroke_tools.items() if ok]
        if not ks_present:
            lines.append(_fmt(FAIL, "Keystroke tools",
                              "none found (need wtype, ydotool, or xdotool)"))
            lines.append(_suggestion(
                "Install ydotool for GNOME Wayland: sudo apt install ydotool"))
        elif ks_present == ["xdotool"]:
            lines.append(_fmt(WARN, "Keystroke tools",
                              "xdotool only (XWayland apps only)"))
            lines.append(_suggestion(
                "Install ydotool for native Wayland: sudo apt install ydotool"))
        else:
            lines.append(_fmt(PASS, "Keystroke tools",
                              ", ".join(ks_present) + " (Wayland)"))
            if "wtype" not in ks_present:
                has_ydotool = "ydotool" in ks_present
                if has_ydotool:
                    lines.append(_suggestion(
                        "wtype unavailable (GNOME), using ydotool fallback"))
                else:
                    lines.append(_suggestion(
                        "xdotool only works for XWayland apps — "
                        "install ydotool for native Wayland: sudo apt install ydotool"))

        # Check ydotoold daemon status when ydotool is installed
        if "ydotool" in ks_present:
            try:
                result = subprocess.run(
                    ["pgrep", "-x", "ydotoold"],
                    capture_output=True, timeout=2,
                )
                if result.returncode == 0:
                    lines.append(_fmt(PASS, "ydotoold daemon", "running"))
                else:
                    lines.append(_fmt(WARN, "ydotoold daemon", "not running"))
                    lines.append(_suggestion(
                        "talk-to-tux auto-starts it, or run: "
                        "sudo systemctl enable --now ydotool"))
            except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
                lines.append(_fmt(WARN, "ydotoold daemon", "unable to check"))

            # Check evdev uinput fallback when ydotoold is not running
            if not (result and result.returncode == 0):  # type: ignore[possibly-undefined]
                uinput_path = "/dev/uinput"
                if os.path.exists(uinput_path) and os.access(uinput_path, os.W_OK):
                    lines.append(_fmt(PASS, "evdev uinput",
                                      "available — fallback for keystroke injection"))
                elif os.path.exists(uinput_path):
                    lines.append(_fmt(WARN, "evdev uinput",
                                      f"{uinput_path} exists but not writable"))
                    lines.append(_suggestion(
                        "Add user to input group: sudo usermod -aG input $USER"))
                else:
                    lines.append(_fmt(WARN, "evdev uinput",
                                      f"{uinput_path} not found"))
    else:
        # X11 — xdotool is the only keystroke tool
        if tools.get("xdotool"):
            lines.append(_fmt(PASS, "Keystroke tools", "xdotool"))
        else:
            lines.append(_fmt(FAIL, "Keystroke tools", "xdotool missing"))
            lines.append(_suggestion("Install xdotool: sudo apt install xdotool"))
    return lines


async def check_audio_device() -> list[str]:
    """Check for audio input device."""
    lines: list[str] = []
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        # Look for any input device
        has_input = False
        if isinstance(devices, dict):
            has_input = devices.get("max_input_channels", 0) > 0
        else:
            for d in devices:
                if d.get("max_input_channels", 0) > 0:
                    has_input = True
                    break
        if has_input:
            lines.append(_fmt(PASS, "Audio input", "device available"))
        else:
            lines.append(_fmt(WARN, "Audio input", "no input device found"))
    except ImportError:
        lines.append(_fmt(WARN, "Audio input", "sounddevice not installed (PortAudio)"))
    except Exception as e:
        lines.append(_fmt(WARN, "Audio input", f"error querying devices: {e}"))
    return lines


async def check_gpu_stt_server(settings: Settings) -> list[str]:
    """Health-check the GPU STT server."""
    lines: list[str] = []
    url = settings.stt.gpu_server.url.rstrip("/")
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{url}/health")
            if resp.status_code == 200:
                data = resp.json()
                model = data.get("model", "unknown")
                gpu = data.get("gpu_available", "unknown")
                lines.append(_fmt(PASS, "GPU STT server",
                                  f"{url} (model={model}, gpu={gpu})"))
            else:
                lines.append(_fmt(FAIL, "GPU STT server",
                                  f"{url} returned status {resp.status_code}"))
    except Exception as e:
        lines.append(_fmt(FAIL, "GPU STT server", f"{url} unreachable ({e})"))
    return lines


async def check_stt_fallbacks(settings: Settings) -> list[str]:
    """Check which STT providers have API keys configured."""
    lines: list[str] = []
    providers = list(settings.stt.providers)
    configured: list[str] = []
    for p in providers:
        if p == "gpu_server":
            configured.append("gpu_server")
        elif p == "elevenlabs" and settings.elevenlabs_api_key:
            configured.append("elevenlabs")
        elif p == "groq" and settings.groq_api_key:
            configured.append("groq")
        elif p == "openai" and settings.openai_api_key:
            configured.append("openai")
        elif p == "google" and settings.google_api_key:
            configured.append("google")

    if len(configured) <= 1:
        only = configured[0] if configured else "none"
        lines.append(_fmt(WARN, "STT fallbacks",
                          f"only {only} configured (no fallback providers)"))
        if not settings.groq_api_key:
            lines.append(_suggestion(
                "Set TTT_GROQ_API_KEY for free Whisper fallback"
            ))
    else:
        lines.append(_fmt(PASS, "STT fallbacks", ", ".join(configured)))
    return lines


async def check_accessibility() -> list[str]:
    """Check AT-SPI accessibility bus connectivity."""
    lines: list[str] = []

    dbus_addr = os.environ.get("DBUS_SESSION_BUS_ADDRESS", "")
    if not dbus_addr:
        bus_path = f"/run/user/{os.getuid()}/bus"
        if os.path.exists(bus_path):
            lines.append(_fmt(WARN, "D-Bus session",
                              f"DBUS_SESSION_BUS_ADDRESS unset (fallback: {bus_path})"))
        else:
            lines.append(_fmt(FAIL, "D-Bus session",
                              "DBUS_SESSION_BUS_ADDRESS unset and no bus socket found"))
            lines.append(_suggestion(
                "Ensure you are running inside a desktop session (not bare SSH)"
            ))
            return lines
    else:
        lines.append(_fmt(PASS, "D-Bus session", dbus_addr))

    # Check AT-SPI bus reachability (safe subprocess check — avoids fatal g_error)
    try:
        from talk_to_tux.context.accessibility import _check_atspi_bus
        if _check_atspi_bus():
            lines.append(_fmt(PASS, "AT-SPI bus", "reachable"))
        else:
            lines.append(_fmt(WARN, "AT-SPI bus",
                              "unreachable — cursor validation and widget context disabled"))
            lines.append(_suggestion(
                "Check that at-spi-bus-launcher is running: "
                "systemctl --user status at-spi-dbus-bus"
            ))
    except Exception as e:
        lines.append(_fmt(WARN, "AT-SPI bus", f"check failed: {e}"))
    return lines


async def check_rewrite_engine() -> list[str]:
    """Check if baml_client is available."""
    lines: list[str] = []
    try:
        import baml_client  # noqa: F401
        lines.append(_fmt(PASS, "Rewrite engine", "baml_client available"))
    except ImportError:
        lines.append(_fmt(WARN, "Rewrite engine",
                          "baml_client not found"))
        lines.append(_suggestion("Run: uv run baml-cli generate"))
    return lines


async def check_screenshot_tools() -> list[str]:
    """Check screenshot tool availability for the current display server."""
    lines: list[str] = []
    is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))

    if is_wayland:
        has_grim = shutil.which("grim") is not None
        has_gnome_screenshot = shutil.which("gnome-screenshot") is not None
        # Check if xdg-desktop-portal is running
        has_portal = False
        try:
            result = subprocess.run(
                ["busctl", "--user", "list"],
                capture_output=True, text=True, timeout=2,
            )
            has_portal = "org.freedesktop.portal.Desktop" in result.stdout
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            pass

        available = []
        if has_grim:
            available.append("grim")
        if has_gnome_screenshot:
            available.append("gnome-screenshot")
        if has_portal:
            available.append("portal")

        if available:
            lines.append(_fmt(PASS, "Screenshot tools",
                              ", ".join(available) + " (Wayland)"))
        else:
            has_scrot = shutil.which("scrot") is not None
            if has_scrot:
                lines.append(_fmt(WARN, "Screenshot tools",
                    "only scrot (XWayland fallback — "
                    "native Wayland apps may not be captured)"))
                lines.append(_suggestion(
                    "Install gnome-screenshot or grim for native Wayland capture"))
            else:
                lines.append(_fmt(FAIL, "Screenshot tools",
                    "no screenshot tools for Wayland"))
                lines.append(_suggestion(
                    "Install gnome-screenshot or grim for native Wayland capture"))
    else:
        has_scrot = shutil.which("scrot") is not None
        has_import = shutil.which("import") is not None
        if has_scrot or has_import:
            tools = []
            if has_scrot:
                tools.append("scrot")
            if has_import:
                tools.append("import (ImageMagick)")
            lines.append(_fmt(PASS, "Screenshot tools", ", ".join(tools)))
        else:
            lines.append(_fmt(FAIL, "Screenshot tools",
                              "need scrot or ImageMagick"))
            lines.append(_suggestion("Install scrot: sudo apt install scrot"))
    return lines


async def check_recording_dot_extension() -> list[str]:
    """Check GNOME Shell recording dot extension status (Wayland only)."""
    lines: list[str] = []
    is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))
    if not is_wayland:
        # GTK popup works fine on X11 — skip check
        return lines

    from talk_to_tux.indicator.recording_dot import (
        _DBUS_DEST,
        _DBUS_IFACE,
        _DBUS_PATH,
        _EXTENSION_UUID,
    )

    ext_dir = os.path.expanduser(
        f"~/.local/share/gnome-shell/extensions/{_EXTENSION_UUID}"
    )
    if not os.path.isdir(ext_dir):
        lines.append(_fmt(WARN, "Recording dot ext",
                          "not installed"))
        lines.append(_suggestion(
            "Run ttt to auto-install, then restart GNOME Shell (log out/in)"))
        return lines

    # Installed — check if GNOME Shell has discovered and enabled it
    try:
        result = subprocess.run(
            ["gnome-extensions", "info", _EXTENSION_UUID],
            capture_output=True, text=True, timeout=5,
        )
        info_text = result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        info_text = ""

    if not info_text:
        lines.append(_fmt(WARN, "Recording dot ext",
                          "installed but not discovered by Shell"))
        lines.append(_suggestion(
            "Restart GNOME Shell (log out/in) to discover the extension"))
        return lines

    if "ENABLED" not in info_text.upper():
        lines.append(_fmt(WARN, "Recording dot ext",
                          "installed but not enabled"))
        lines.append(_suggestion(
            f"Run: gnome-extensions enable {_EXTENSION_UUID}"))
        return lines

    # Enabled — check D-Bus reachability
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", _DBUS_DEST,
                "--object-path", _DBUS_PATH,
                "--method", "org.freedesktop.DBus.Peer.Ping",
            ],
            capture_output=True, timeout=2,
        )
        dbus_ok = result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        dbus_ok = False

    if dbus_ok:
        lines.append(_fmt(PASS, "Recording dot ext",
                          "installed, enabled, D-Bus reachable"))
    else:
        lines.append(_fmt(WARN, "Recording dot ext",
                          "enabled but D-Bus not responding"))
        lines.append(_suggestion(
            "Restart GNOME Shell (log out/in) to activate the extension"))
    return lines


async def check_window_context() -> list[str]:
    """Check window context availability (Wayland only)."""
    lines: list[str] = []
    is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))
    if not is_wayland:
        return lines

    # Try our bundled extension first
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", "org.gnome.shell.extensions.TalkToTux",
                "--object-path", "/org/gnome/shell/extensions/TalkToTux/Window",
                "--method",
                "org.gnome.shell.extensions.TalkToTux.Window.GetFocusedWindow",
            ],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            lines.append(_fmt(PASS, "Window context",
                              "Talk-to-Tux extension D-Bus (GetFocusedWindow)"))
            return lines
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass

    # Try third-party window-calls-extended
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", "org.gnome.Shell",
                "--object-path", "/org/gnome/Shell/Extensions/Windows",
                "--method", "org.gnome.Shell.Extensions.Windows.List",
            ],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            lines.append(_fmt(PASS, "Window context",
                              "window-calls-extended D-Bus (fallback)"))
            return lines
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass

    lines.append(_fmt(WARN, "Window context",
                      "unavailable — restart GNOME Shell (log out/in) "
                      "to activate bundled extension"))
    return lines


async def check_desktop_compatibility() -> list[str]:
    """Show desktop environment compatibility status."""
    lines: list[str] = []
    is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))

    if is_wayland:
        desktop = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
        is_gnome = "gnome" in desktop
        de_name = "GNOME" if is_gnome else desktop.split(":")[-1] or "Wayland"

        lines.append(_fmt(WARN, "Desktop compat",
            f"{de_name} Wayland — some features require Shell restart after first run"))

        if is_gnome:
            lines.append(_suggestion(
                "Restart GNOME Shell (log out/in) to activate bundled extension"))
            lines.append(_suggestion(
                "Install ydotool for keystroke injection: sudo apt install ydotool"))
        else:
            lines.append(_suggestion(
                "Restart GNOME Shell (log out/in) to activate bundled extension"
            ))
    else:
        lines.append(_fmt(PASS, "Desktop compat", "X11 — full feature support"))
    return lines


async def run_doctor(settings: Settings) -> str:
    """Run all diagnostic checks and return formatted output."""
    all_lines: list[str] = []

    checks = [
        check_input_group(),
        check_mouse_device(settings),
        check_keyboard_device(settings),
        check_display_server(),
        check_desktop_compatibility(),
        check_recording_dot_extension(),
        check_window_context(),
        check_screenshot_tools(),
        check_accessibility(),
        check_paste_tools(),
        check_audio_device(),
        check_gpu_stt_server(settings),
        check_stt_fallbacks(settings),
        check_rewrite_engine(),
    ]

    for check in checks:
        result_lines = await check
        all_lines.extend(result_lines)

    # Config summary
    from talk_to_tux.cli import show_config
    all_lines.append("")
    all_lines.append(show_config(settings))

    return "\n".join(all_lines)
