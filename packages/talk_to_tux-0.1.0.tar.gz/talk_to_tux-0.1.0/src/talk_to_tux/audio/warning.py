"""Fire-and-forget audio warning with 3-level fallback."""
from __future__ import annotations

import asyncio
import logging
import sys

logger = logging.getLogger(__name__)


async def play_warning_sound() -> None:
    """Play a warning sound using the best available method.

    Fallback chain:
    1. canberra-gtk-play — official XDG/GNOME sound event API
    2. paplay — PulseAudio/PipeWire direct playback
    3. Terminal bell (\\a) — last resort
    """
    # Try canberra-gtk-play (GNOME sound theme)
    try:
        proc = await asyncio.create_subprocess_exec(
            "canberra-gtk-play", "-i", "dialog-warning",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=3.0)
        if proc.returncode == 0:
            return
    except (FileNotFoundError, asyncio.TimeoutError, OSError):
        pass

    # Try paplay with freedesktop sound
    try:
        proc = await asyncio.create_subprocess_exec(
            "paplay", "/usr/share/sounds/freedesktop/stereo/dialog-warning.oga",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=3.0)
        if proc.returncode == 0:
            return
    except (FileNotFoundError, asyncio.TimeoutError, OSError):
        pass

    # Last resort: terminal bell
    try:
        sys.stderr.write("\a")
        sys.stderr.flush()
    except OSError:
        pass

    logger.debug("Warning sound: all methods attempted")
