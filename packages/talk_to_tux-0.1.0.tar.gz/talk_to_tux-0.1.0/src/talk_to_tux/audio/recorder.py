from __future__ import annotations

import collections
import io
import logging
import time
from typing import TYPE_CHECKING, Any, Callable

import numpy as np
import soundfile as sf

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    import sounddevice as sd
    from numpy.typing import NDArray

HOSTED_RECORDER_HARD_CAP_S: float = 600.0


def _import_sd() -> Any:
    import sounddevice as sd
    return sd


class AudioRecorder:
    """Audio recorder with a pre-recording circular buffer.

    The microphone stream runs continuously.  A ring buffer keeps the last
    ``pre_buffer_s`` seconds of audio so that speech occurring *before*
    the button press is preserved.

    Lifecycle::

        __init__   → stream created and started (always listening)
        start()    → snapshot the ring buffer, begin accumulating chunks
        stop()     → return ring-buffer snapshot + accumulated chunks
        close()    → release audio device
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        channels: int = 1,
        device: int | None = None,
        pre_buffer_s: float = 2.0,
        hard_cap_s: float | None = None,
        on_auto_stop: Callable[[], None] | None = None,
    ) -> None:
        self._sample_rate = sample_rate
        self._channels = channels
        self._device = device
        self._pre_buffer_samples = int(sample_rate * pre_buffer_s)
        self._hard_cap_s = hard_cap_s
        self._on_auto_stop = on_auto_stop

        # Ring buffer for pre-recording audio (always filling)
        self._ring: collections.deque[NDArray[np.float32]] = collections.deque()
        self._ring_samples: int = 0

        # Chunks accumulated between start() and stop()
        self._chunks: list[NDArray[np.float32]] = []
        self._recording: bool = False
        self._pre_snapshot: NDArray[np.float32] | None = None
        self._auto_stop_fired: bool = False
        self._record_start_ts: float = 0.0

        # Watchdog liveness signals
        self._last_callback_ts: float = time.monotonic()
        self._last_nonsilent_ts: float = time.monotonic()
        self._silence_threshold: float = 1e-5

        # Create and start the stream immediately — always listening
        sd = _import_sd()
        self._stream: sd.InputStream = sd.InputStream(
            samplerate=sample_rate,
            channels=channels,
            dtype="float32",
            device=device,
            callback=self._callback,
        )
        self._stream.start()

    def _callback(
        self, indata: NDArray, frames: int, time_info: object, status: object
    ) -> None:
        # Watchdog: callback fired
        now = time.monotonic()
        self._last_callback_ts = now
        mono = indata[:, 0].copy() if indata.ndim > 1 else indata.copy().ravel()
        # Watchdog: track non-silent audio
        if len(mono) > 0 and float(np.abs(mono).max()) > self._silence_threshold:
            self._last_nonsilent_ts = now
        if self._recording:
            self._chunks.append(mono)
            # Hard cap: fire on_auto_stop once per session when cap elapses
            if (
                self._hard_cap_s is not None
                and self._on_auto_stop is not None
                and not self._auto_stop_fired
                and now - self._record_start_ts >= self._hard_cap_s
            ):
                self._auto_stop_fired = True
                self._on_auto_stop()
        else:
            # Fill ring buffer
            self._ring.append(mono)
            self._ring_samples += len(mono)
            # Evict old chunks to stay within budget
            while self._ring_samples > self._pre_buffer_samples and self._ring:
                removed = self._ring.popleft()
                self._ring_samples -= len(removed)

    def start(self) -> None:
        """Begin a recording.  Snapshots the ring buffer so pre-button
        audio is preserved, then starts accumulating new chunks."""
        # Snapshot the ring buffer (pre-button audio)
        if self._ring:
            self._pre_snapshot = np.concatenate(list(self._ring))
        else:
            self._pre_snapshot = None
        self._chunks = []
        self._record_start_ts = time.monotonic()
        self._auto_stop_fired = False
        self._recording = True

    def stop(self) -> NDArray[np.float32]:
        """Stop recording and return pre-buffer + recorded audio."""
        self._recording = False
        parts: list[NDArray[np.float32]] = []
        if self._pre_snapshot is not None:
            parts.append(self._pre_snapshot)
            self._pre_snapshot = None
        if self._chunks:
            parts.append(np.concatenate(self._chunks))
        self._chunks = []
        if not parts:
            return np.array([], dtype=np.float32)
        audio = np.concatenate(parts)
        return audio

    def close(self) -> None:
        """Release the audio device (call at shutdown)."""
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None

    def peek_tail(self, n_samples: int) -> NDArray[np.float32] | None:
        """Return the last *n_samples* of recorded audio without modifying buffers.

        Returns a 1-D float32 array (mono). If no audio has been captured yet,
        returns ``None``. If fewer than *n_samples* are available, returns
        everything captured so far.
        """
        if not self._chunks:
            return None

        collected: list[NDArray[np.float32]] = []
        remaining = n_samples
        for chunk in reversed(self._chunks):
            if remaining <= 0:
                break
            c = chunk[:, 0] if chunk.ndim > 1 else chunk
            if len(c) >= remaining:
                collected.append(c[-remaining:])
                remaining = 0
            else:
                collected.append(c)
                remaining -= len(c)

        collected.reverse()
        return np.concatenate(collected)

    def get_partial_wav(self, from_chunk_idx: int = 0) -> tuple[bytes, int]:
        """Return current recording audio as WAV bytes plus the current chunk count.

        Thread-safe via GIL (list copy of ``self._chunks`` is atomic).

        - ``from_chunk_idx == 0``: include the pre-recording snapshot and all chunks.
        - ``from_chunk_idx > 0``: include only ``chunks[from_chunk_idx:]`` (tail since
          the last speculative call).

        Returns ``(b"", len(self._chunks))`` when the relevant slice is empty.
        """
        chunks_snapshot = list(self._chunks)  # GIL-safe atomic copy
        current_count = len(chunks_snapshot)

        parts: list[NDArray[np.float32]] = []
        if from_chunk_idx == 0:
            if self._pre_snapshot is not None:
                parts.append(self._pre_snapshot)
            parts.extend(chunks_snapshot)
        else:
            parts.extend(chunks_snapshot[from_chunk_idx:])

        if not parts:
            return b"", current_count

        audio = np.concatenate(parts)
        return ndarray_to_wav_bytes(audio, self._sample_rate), current_count

    def is_recording(self) -> bool:
        return self._recording

    def is_stream_healthy(self) -> bool:
        """Return True if the audio stream is delivering fresh, non-silent data.

        Two failure modes are detected:
        1. Callback hasn't fired in >5s (PortAudio stream stopped)
        2. Callback fires but audio is all-silent for >60s (PipeWire feeding
           zeros after a stream disconnection)

        The silence check is skipped during active recording so that a
        quiet user does not trigger a false-positive recreate.
        """
        now = time.monotonic()
        if now - self._last_callback_ts > 5.0:
            return False
        if not self._recording and now - self._last_nonsilent_ts > 60.0:
            return False
        return True

    def recreate_stream(self) -> None:
        """Tear down and recreate the underlying PortAudio stream.

        Used by the watchdog to recover from stale streams (e.g. after
        PipeWire device suspend/profile-change).  The ring buffer is
        preserved so any earlier audio is not lost.
        """
        logger.warning("Audio stream stale, recreating")
        try:
            if self._stream is not None:
                self._stream.stop()
                self._stream.close()
        except Exception:
            logger.debug("Stream stop/close failed during recreate", exc_info=True)
        sd = _import_sd()
        self._stream = sd.InputStream(
            samplerate=self._sample_rate,
            channels=self._channels,
            dtype="float32",
            device=self._device,
            callback=self._callback,
        )
        self._stream.start()
        # Reset liveness markers so the watchdog gives the new stream
        # time to deliver data before re-evaluating health.
        now = time.monotonic()
        self._last_callback_ts = now
        self._last_nonsilent_ts = now


def ndarray_to_wav_bytes(audio: NDArray[np.float32], sample_rate: int = 16000) -> bytes:
    buf = io.BytesIO()
    sf.write(buf, audio, sample_rate, format="WAV", subtype="PCM_16")
    buf.seek(0)
    return buf.read()
