"""Audio ducking — reduce other apps' volume during recording.

Uses PipeWire softVolumes instead of channelVolumes so that WirePlumber's
restore-stream DB is never corrupted with ducked values.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def _state_file_path() -> Path:
    """Return path to the duck state file, respecting XDG_CACHE_HOME."""
    cache_dir = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return cache_dir / "talk-to-tux" / "duck_state.json"


def _set_soft_volumes(node_id: int, volumes: list[float]) -> bool:
    """Set PipeWire softVolumes on a node via pw-cli.

    softVolumes are independent of channelVolumes and NOT saved by WirePlumber,
    making them safe for temporary ducking without corrupting the restore-stream DB.
    """
    vol_str = ", ".join(f"{v}" for v in volumes)
    cmd = ["pw-cli", "s", str(node_id), "Props", f"{{ softVolumes: [ {vol_str} ] }}"]
    try:
        result = subprocess.run(cmd, capture_output=True, timeout=5)
        if result.returncode != 0:
            logger.debug(
                "pw-cli failed for node %d: %s",
                node_id, result.stderr.decode(errors="replace"),
            )
            return False
        return True
    except FileNotFoundError:
        logger.debug("pw-cli not found — cannot set softVolumes")
        return False
    except (subprocess.TimeoutExpired, OSError) as exc:
        logger.debug("pw-cli error for node %d: %s", node_id, exc)
        return False


def _get_pw_node_id(si) -> int:
    """Get PipeWire-compatible node ID from a pulsectl sink input.

    PipeWire's pulse bridge exposes object.id in proplist; pw-cli needs this,
    not the PulseAudio serial (si.index). Falls back to si.index for plain
    PulseAudio (X11).
    """
    return int(si.proplist.get("object.id", si.index))


def _import_pulsectl():
    """Lazy import pulsectl (sync)."""
    import pulsectl
    return pulsectl


def _restore_soft_volumes_for_nodes(entries: list[dict]) -> int:
    """Reset softVolumes to 1.0 for a list of {node_id, n_channels} entries.

    Returns the number of successfully restored nodes.
    """
    restored = 0
    for entry in entries:
        node_id = entry["node_id"]
        n_channels = entry["n_channels"]
        if _set_soft_volumes(node_id, [1.0] * n_channels):
            restored += 1
    return restored


def _legacy_recovery(saved: dict[str, list[float]]) -> None:
    """Handle recovery from old pulsectl-based state format.

    Since we don't have node IDs, enumerate current streams and reset
    softVolumes for any matching app names.
    """
    try:
        pulsectl = _import_pulsectl()
    except ImportError:
        return
    try:
        with pulsectl.Pulse("talk-to-tux-unduck") as pulse:
            inputs = pulse.sink_input_list()
            for si in inputs:
                app = si.proplist.get("application.name", f"idx-{si.index}")
                if app in saved:
                    n_channels = len(si.volume.values)
                    _set_soft_volumes(_get_pw_node_id(si), [1.0] * n_channels)
    except Exception:
        logger.debug("Legacy audio restore failed", exc_info=True)


def recover_ducked_volumes() -> None:
    """Restore volumes from a prior crash's state file, if present.

    Call this at startup before any recording can happen. Safe to call
    even when there is no state file (normal case).
    """
    state_path = _state_file_path()
    if not state_path.exists():
        return
    try:
        data = json.loads(state_path.read_text())
        if not isinstance(data, dict) or not data:
            state_path.unlink(missing_ok=True)
            return

        # Detect format: new format has dicts, old format has floats
        is_new_format = False
        for _app, entries in data.items():
            if isinstance(entries, list) and entries and isinstance(entries[0], dict):
                is_new_format = True
                break

        if is_new_format:
            # New format: {app_name: [{"node_id": int, "n_channels": int}, ...]}
            restored = 0
            for _app, entries in data.items():
                if isinstance(entries, list):
                    restored += _restore_soft_volumes_for_nodes(entries)
            logger.info("Recovered ducked volumes from prior crash (%d nodes)", restored)
        else:
            # Old format: {app_name: [vol1, vol2, ...]} — legacy pulsectl-based
            _legacy_recovery(data)
            logger.info("Recovered ducked volumes from legacy state (%d apps)", len(data))
    except Exception:
        logger.debug("Failed to recover ducked volumes", exc_info=True)
    finally:
        try:
            state_path.unlink(missing_ok=True)
        except OSError:
            pass


class AudioDucker:
    """Reduce playback streams to *factor* of their volume while recording.

    Uses pulsectl (sync) for stream enumeration and pw-cli to set softVolumes,
    which are NOT saved by WirePlumber's restore-stream DB.
    All operations are fire-and-forget safe — exceptions are caught internally.
    """

    def __init__(self, factor: float = 0.15, enabled: bool = True) -> None:
        self._factor = factor
        self._enabled = enabled
        # {app_name: [{"node_id": int, "n_channels": int}, ...]}
        self._saved: dict[str, list[dict[str, int]]] | None = None
        self._state_path = _state_file_path()
        # Serialize duck/restore so a fire-and-forget restore() finishes
        # before the next duck() reads volumes from PulseAudio.
        self._lock = asyncio.Lock()

    @property
    def is_ducked(self) -> bool:
        return self._saved is not None

    async def duck(self) -> None:
        """Save current stream info and reduce all playback via softVolumes."""
        if not self._enabled:
            return
        async with self._lock:
            if self._saved is not None:
                # Prior restore didn't run — auto-restore first
                await self._do_restore()
            loop = asyncio.get_running_loop()
            saved = await loop.run_in_executor(None, self._duck_sync)
            if saved is not None:
                self._saved = saved

    async def restore(self) -> None:
        """Restore softVolumes to 1.0. No-op if not ducked."""
        async with self._lock:
            await self._do_restore()

    async def _do_restore(self) -> None:
        """Unlocked restore — called from duck() and restore() under _lock."""
        if self._saved is None:
            return
        saved = self._saved
        self._saved = None  # CLEAR FIRST, unconditionally
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._restore_sync, saved)
        self._delete_state()  # Always clean up, even if restore_sync failed

    def _duck_sync(self) -> dict[str, list[dict[str, int]]] | None:
        """Sync helper — runs in thread executor.

        Uses pulsectl to enumerate streams, pw-cli to set softVolumes.
        Returns {app_name: [{"node_id": int, "n_channels": int}, ...]}
        """
        try:
            pulsectl = _import_pulsectl()
        except ImportError:
            logger.debug("pulsectl not installed — skipping duck")
            return None
        try:
            with pulsectl.Pulse("talk-to-tux-duck") as pulse:
                inputs = pulse.sink_input_list()
                saved: dict[str, list[dict[str, int]]] = {}
                for si in inputs:
                    vol = si.volume.value_flat
                    if vol <= 0.0:
                        continue  # already silent — skip
                    app = si.proplist.get("application.name", f"idx-{si.index}")
                    n_channels = len(si.volume.values)
                    pw_id = _get_pw_node_id(si)
                    if _set_soft_volumes(pw_id, [self._factor] * n_channels):
                        saved.setdefault(app, []).append({
                            "node_id": pw_id,
                            "n_channels": n_channels,
                        })
                logger.debug("Ducked %d streams (factor=%.2f)", len(saved), self._factor)
                self._write_state(saved)
                return saved
        except Exception:
            logger.debug("Audio ducking failed", exc_info=True)
            return None

    def _restore_sync(self, saved: dict[str, list[dict[str, int]]]) -> None:
        """Sync helper — runs in thread executor. Exceptions logged, not raised."""
        try:
            restored = 0
            failed_apps: dict[str, int] = {}  # app_name → n_channels for fallback
            for app_name, entries in saved.items():
                for entry in entries:
                    node_id = entry["node_id"]
                    n_channels = entry["n_channels"]
                    if _set_soft_volumes(node_id, [1.0] * n_channels):
                        restored += 1
                    else:
                        failed_apps[app_name] = n_channels
            # Fallback: if node IDs are gone, try matching by app name
            if failed_apps:
                restored += self._restore_fallback(failed_apps)
            logger.debug("Restored %d streams (%d apps)", restored, len(saved))
        except Exception:
            logger.warning("Audio restore failed", exc_info=True)

    def _restore_fallback(self, failed_apps: dict[str, int]) -> int:
        """Fallback restore: find streams by app name when node IDs are stale."""
        restored = 0
        try:
            pulsectl = _import_pulsectl()
        except ImportError:
            return 0
        try:
            with pulsectl.Pulse("talk-to-tux-unduck-fallback") as pulse:
                inputs = pulse.sink_input_list()
                for si in inputs:
                    app = si.proplist.get("application.name", f"idx-{si.index}")
                    if app in failed_apps:
                        n_channels = len(si.volume.values)
                        if _set_soft_volumes(_get_pw_node_id(si), [1.0] * n_channels):
                            restored += 1
        except Exception:
            logger.debug("Fallback restore failed", exc_info=True)
        return restored

    def _write_state(self, saved: dict[str, list[dict[str, int]]]) -> None:
        """Write saved state to file for crash recovery."""
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            self._state_path.write_text(json.dumps(saved))
        except OSError:
            logger.debug("Failed to write duck state file", exc_info=True)

    def _delete_state(self) -> None:
        """Delete state file after restore."""
        try:
            self._state_path.unlink(missing_ok=True)
        except OSError:
            pass
