from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import torch

if TYPE_CHECKING:
    from numpy.typing import NDArray


class VoiceActivityDetector:
    def __init__(self, threshold: float = 0.5, sample_rate: int = 16000) -> None:
        self._threshold = threshold
        self._sample_rate = sample_rate
        self._model, self._utils = torch.hub.load(
            "snakers4/silero-vad", "silero_vad", trust_repo=True
        )

    def get_speech_timestamps(
        self, audio: NDArray[np.float32]
    ) -> list[dict[str, int]]:
        tensor = torch.from_numpy(audio)
        get_speech_ts = self._utils[0]
        timestamps = get_speech_ts(
            tensor, self._model, threshold=self._threshold, sampling_rate=self._sample_rate
        )
        return [{"start": ts["start"], "end": ts["end"]} for ts in timestamps]

    def trim_silence(
        self,
        audio: NDArray[np.float32],
        pre_pad_ms: float = 0.0,
        post_pad_ms: float = 0.0,
    ) -> NDArray[np.float32] | None:
        timestamps = self.get_speech_timestamps(audio)
        if not timestamps:
            return None
        pre_samples = int(self._sample_rate * pre_pad_ms / 1000)
        post_samples = int(self._sample_rate * post_pad_ms / 1000)
        n = len(audio)
        segments = [
            audio[max(0, ts["start"] - pre_samples):min(n, ts["end"] + post_samples)]
            for ts in timestamps
        ]
        return np.concatenate(segments)
