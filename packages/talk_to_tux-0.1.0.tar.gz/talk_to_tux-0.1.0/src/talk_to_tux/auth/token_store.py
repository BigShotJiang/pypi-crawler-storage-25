"""KeyringTokenStore — TokenStore implementation with filesystem fallback.

Single-blob keyring pattern: one entry ("talk-to-tux", "tokens") holds a JSON
dict with all Tokens fields. Falls back to filesystem when keyring is unavailable.
"""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

import keyring
import keyring.backends.fail
from keyring.errors import KeyringError

from talk_to_tux.auth import AuthFailed, Tokens

_SERVICE = "talk-to-tux"
_USERNAME = "tokens"


def _config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / "talk-to-tux"


def _fs_path() -> Path:
    return _config_dir() / "secrets" / "tokens.json"


def _tokens_to_dict(tokens: Tokens) -> dict:
    return {
        "access_token": tokens.access_token,
        "refresh_token": tokens.refresh_token,
        "expires_at": tokens.expires_at.isoformat() if tokens.expires_at is not None else None,
        "user_email": tokens.user_email,
        "tier": tokens.tier,
    }


def _dict_to_tokens(data: dict) -> Tokens:
    expires_at_raw = data.get("expires_at")
    expires_at = datetime.fromisoformat(expires_at_raw) if expires_at_raw is not None else None
    return Tokens(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token"),
        expires_at=expires_at,
        user_email=data.get("user_email"),
        tier=data.get("tier"),
    )


def _is_fail_backend() -> bool:
    return isinstance(keyring.get_keyring(), keyring.backends.fail.Keyring)


def _save_to_filesystem(blob: str) -> None:
    path = _fs_path()
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        fd, tmp_path = tempfile.mkstemp(dir=parent, suffix=".tmp")
        try:
            os.chmod(tmp_path, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(blob)
            os.replace(tmp_path, path)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except OSError as exc:
        raise AuthFailed("cannot_persist_tokens") from exc


def _load_from_filesystem() -> Tokens | None:
    path = _fs_path()
    try:
        text = path.read_text()
    except OSError:
        return None
    try:
        data = json.loads(text)
        return _dict_to_tokens(data)
    except Exception:
        return None


class KeyringTokenStore:
    """TokenStore backed by system keyring with transparent filesystem fallback."""

    def load(self) -> Tokens | None:
        if not _is_fail_backend():
            try:
                blob = keyring.get_password(_SERVICE, _USERNAME)
                if blob is not None:
                    try:
                        return _dict_to_tokens(json.loads(blob))
                    except Exception:
                        return None
            except KeyringError:
                pass
        return _load_from_filesystem()

    def save(self, tokens: Tokens) -> None:
        blob = json.dumps(_tokens_to_dict(tokens))
        if not _is_fail_backend():
            try:
                keyring.set_password(_SERVICE, _USERNAME, blob)
                return
            except KeyringError:
                pass
        _save_to_filesystem(blob)

    def delete(self) -> None:
        # Best-effort: clear both keyring and filesystem
        try:
            keyring.delete_password(_SERVICE, _USERNAME)
        except Exception:
            pass
        try:
            _fs_path().unlink(missing_ok=True)
        except OSError:
            pass
