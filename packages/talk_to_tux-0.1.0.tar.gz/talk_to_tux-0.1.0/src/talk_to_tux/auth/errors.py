"""Exception hierarchy for hosted-mode authentication and quota errors."""
from __future__ import annotations

from datetime import datetime


class HostedError(Exception):
    """Base class for all hosted-mode errors."""


class AuthFailed(HostedError):
    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


class TokenInvalid(HostedError):
    """Raised when a stored access token is structurally invalid or rejected."""


class TierLocked(HostedError):
    """Raised when the operation is not permitted on the current subscription tier."""


class QuotaExhausted(HostedError):
    def __init__(
        self,
        reset_at: datetime | None,
        remaining_stt_seconds: float | None = None,
        remaining_rewrites: int | None = None,
    ) -> None:
        self.reset_at = reset_at
        self.remaining_stt_seconds = remaining_stt_seconds
        self.remaining_rewrites = remaining_rewrites
        super().__init__(
            f"quota exhausted (resets at {reset_at}, "
            f"stt_s={remaining_stt_seconds}, rewrites={remaining_rewrites})"
        )


class RecordingTooLong(HostedError):
    def __init__(
        self,
        raw_ms: int,
        trimmed_ms: int,
        raw_cap: int = 600_000,
        trimmed_cap: int = 300_000,
    ) -> None:
        self.raw_ms = raw_ms
        self.trimmed_ms = trimmed_ms
        self.raw_cap = raw_cap
        self.trimmed_cap = trimmed_cap
        super().__init__(
            f"recording too long: raw={raw_ms}ms (cap {raw_cap}ms), "
            f"trimmed={trimmed_ms}ms (cap {trimmed_cap}ms)"
        )
