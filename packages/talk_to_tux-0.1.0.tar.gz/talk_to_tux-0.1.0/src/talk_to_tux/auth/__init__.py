"""auth — Tokens, TokenStore Protocol, parse_access_token, and error re-exports."""
from __future__ import annotations

import re
import typing
from dataclasses import dataclass
from datetime import datetime

__all__ = [
    "Tokens",
    "TokenStore",
    "parse_access_token",
    "HostedError",
    "AuthFailed",
    "TokenInvalid",
    "TierLocked",
    "QuotaExhausted",
    "RecordingTooLong",
]

_TOKEN_RE = re.compile(r"^ttt_([A-Za-z0-9_-]{22})_([A-Za-z0-9_-]+)$")


@dataclass(frozen=True)
class Tokens:
    access_token: str
    refresh_token: str | None
    expires_at: datetime | None
    user_email: str | None = None
    tier: str | None = None


class TokenStore(typing.Protocol):
    def load(self) -> Tokens | None: ...
    def save(self, tokens: Tokens) -> None: ...
    def delete(self) -> None: ...


def parse_access_token(token: str) -> tuple[str, str]:
    """Split a ttt_ access token into (token_id_b64url, secret_b64url).

    Raises ValueError if the token does not match the expected format.
    The secret segment may contain underscores.
    """
    m = _TOKEN_RE.match(token)
    if not m:
        raise ValueError(
            f"Invalid access token format. Expected ttt_<22-char-id>_<secret>, got: {token!r}"
        )
    return m.group(1), m.group(2)


def __getattr__(name: str) -> object:
    if name in {"HostedError", "AuthFailed", "TokenInvalid", "TierLocked", "QuotaExhausted", "RecordingTooLong"}:
        from . import errors
        return getattr(errors, name)
    raise AttributeError(name)
