from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
import signal
import sys
import termios
import time



from talk_to_tux.audio.recorder import AudioRecorder, ndarray_to_wav_bytes
from talk_to_tux.audio.vad import VoiceActivityDetector
from talk_to_tux.audio.warning import play_warning_sound
from talk_to_tux.cli import apply_overrides, parse_args, show_config
from talk_to_tux.config import Settings, get_settings
from talk_to_tux.context.capturer import ContextCapturer
from talk_to_tux.context.validation import CursorValidationResult, validate_cursor_target
from talk_to_tux.hotkey import InputListener
from talk_to_tux.hotkey.keyboard_chord import KeyboardChordListener
from talk_to_tux.hotkey.listener import HotkeyListener
from talk_to_tux.hotkey.mouse import MouseChordListener  # legacy, kept for isinstance check
from talk_to_tux.hotkey.side_button import SideButtonListener
from talk_to_tux.paste.paster import Paster
from talk_to_tux.pipeline.cache import PipelineCache
from talk_to_tux.pipeline.event_log import EventLog, event_screenshot_filename
from talk_to_tux.pipeline.correction_learner import CorrectionLearner
from talk_to_tux.pipeline.feedback import FeedbackCollector
from talk_to_tux.pipeline.paste_decision import PasteDecider
from talk_to_tux.pipeline.rewrite import SmartRewriter
from talk_to_tux.pipeline.state import PipelineState
from talk_to_tux.pipeline.telemetry import PipelineTelemetry
from talk_to_tux.stt.client import STTClient, TranscriptionResult as STTResult

logger = logging.getLogger(__name__)


def _pidfile_path() -> Path:
    """Return path to the PID file, respecting XDG_CACHE_HOME."""
    cache_dir = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return cache_dir / "talk-to-tux" / "talk-to-tux.pid"


def _acquire_pidfile() -> bool:
    """Write our PID to the pidfile. Return False if another instance is alive."""
    pidfile = _pidfile_path()
    if pidfile.exists():
        try:
            old_pid = int(pidfile.read_text().strip())
            os.kill(old_pid, 0)  # check if alive (no signal sent)
            # Process exists — another instance is running
            logger.error(
                "Another instance is already running (PID %d). "
                "Kill it first: kill %d",
                old_pid,
                old_pid,
            )
            return False
        except (ValueError, ProcessLookupError, OSError):
            # PID file is stale — process is gone
            pass
    pidfile.parent.mkdir(parents=True, exist_ok=True)
    pidfile.write_text(str(os.getpid()))
    return True


def _release_pidfile() -> None:
    """Remove the PID file if it contains our PID."""
    pidfile = _pidfile_path()
    try:
        if pidfile.exists() and pidfile.read_text().strip() == str(os.getpid()):
            pidfile.unlink()
    except OSError:
        pass


class App:
    def __init__(
        self,
        settings: Settings,
        listener: InputListener,
        recorder: AudioRecorder,
        vad: VoiceActivityDetector,
        stt_client: STTClient,
        context_capturer: ContextCapturer | None = None,
        smart_rewriter: SmartRewriter | None = None,
        paster: Paster | None = None,
        cache: PipelineCache | None = None,
        indicator: object | None = None,
        token_store: object | None = None,
    ) -> None:
        self._settings = settings
        self._listener = listener
        self._recorder = recorder
        self._vad = vad
        self._stt_client = stt_client
        self._context_capturer = context_capturer
        self._smart_rewriter = smart_rewriter
        self._paster = paster
        self._cache = cache
        self._indicator = indicator
        self._token_store = token_store
        try:
            self._loop: asyncio.AbstractEventLoop | None = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = None
        self._paste_decider = PasteDecider()
        self._context_task: asyncio.Task | None = None
        self._state: PipelineState = PipelineState.IDLE
        self._enter_armed: bool = False  # double-tap Enter enabled after paste
        self._enter_paste_window_id: str | None = None  # window that received the paste
        # Pending results for tooltip confirmation flow
        self._pending_transcription: str | None = None
        self._pending_rewrites: list[tuple[str, object | None]] = []
        self._pending_context: object | None = None
        self._last_tooltip_chord_time: float | None = None
        self._tooltip_timeout_handle: asyncio.TimerHandle | None = None
        self._pre_chord_window_id: str | None = None
        self._escape_task: asyncio.Task | None = None
        self._pending_enter: bool = False  # first tap after paste seen
        # Post-paste tooltip state
        self._last_auto_paste_text: str | None = None
        self._last_auto_paste_context: object | None = None
        self._post_paste_tooltip_handle: asyncio.TimerHandle | None = None
        # Feedback
        self._feedback: FeedbackCollector | None = None
        self._event_log: EventLog | None = None
        self._buffered_event_screenshots: list[tuple[str, bytes]] = []
        self._run_dir_ready: bool = False
        self._post_paste_screenshot_tasks: list[asyncio.Task] = []
        # Fire-and-forget tasks that aren't pinned to a dedicated field.
        # Tracked so shutdown() can cancel them and so they aren't GC'd
        # mid-flight (asyncio only holds weak refs to running tasks).
        self._background_tasks: set[asyncio.Task] = set()
        self._validation_task: asyncio.Task | None = None
        self._processing_task: asyncio.Task | None = None
        self._analysis_task: asyncio.Task | None = None
        self._max_record_handle: asyncio.TimerHandle | None = None
        self._silence_task: asyncio.Task | None = None
        self._audio_watchdog_task: asyncio.Task | None = None
        self._deferred_start: bool = False  # button pressed during PROCESSING
        self._ducker: object | None = None  # lazy AudioDucker
        # Double-tap timeout / drift / hold override
        self._enter_arm_win_rect: tuple[int, int, int, int] | None = None
        self._drift_monitor_task: asyncio.Task | None = None
        self._enter_arm_timeout_handle: asyncio.TimerHandle | None = None
        self._hold_override_handle: asyncio.TimerHandle | None = None
        self._hold_pending_tap: bool = False
        self._speculative_recording: bool = False  # recorder started during hold detection
        # Speculative transcription during recording (Change 2)
        self._speculative_results: list[str] = []
        self._speculative_chunk_idx: int = 0
        self._speculative_task: asyncio.Task | None = None
        # Enter watcher for correction learning
        self._enter_watcher_tasks: list[asyncio.Task] = []
        self._enter_watcher_devices: list = []  # list[InputDevice]
        self._ignore_next_enter: bool = False
        self._enter_watcher_timeout_handle: asyncio.TimerHandle | None = None
        # Correction learner
        self._correction_learner: CorrectionLearner | None = None
        if settings.correction.enabled:
            from talk_to_tux.config import _config_dir
            self._correction_learner = CorrectionLearner(
                _config_dir(),
                min_occurrences=settings.correction.min_occurrences,
                max_keyterms=settings.correction.max_keyterms,
            )

    def _track(self, coro) -> asyncio.Task:
        """Create + track a fire-and-forget task.

        asyncio only holds weak refs to running tasks, so untracked
        create_task() calls can be garbage-collected mid-flight. Tracked
        tasks are also cancelled cleanly in shutdown().
        """
        task = asyncio.create_task(coro)
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        return task

    async def _validate_cursor(self) -> CursorValidationResult:
        """Run AT-SPI cursor validation via subprocess. Timeout/error -> PASS."""
        from talk_to_tux.context.accessibility import query_widgets_subprocess

        try:
            validation_timeout = self._settings.validation.timeout_ms / 1000
            focused, cursor, atspi_ok = await query_widgets_subprocess(
                timeout=validation_timeout,
            )
            return validate_cursor_target(
                focused, cursor,
                atspi_available=atspi_ok,
            )
        except Exception:
            logger.debug("Cursor validation failed", exc_info=True)
            return CursorValidationResult(
                is_typeable=True,
                reason="Validation error — allowing recording",
            )

    async def _async_validate_and_cancel(self) -> None:
        """Run validation concurrently; cancel recording if target is non-typeable.

        Called as a fire-and-forget task from on_record_start(). If validation
        fails while still in RECORDING state, stops the recorder, resets to IDLE,
        and shows a warning. The race window is tiny (~300ms of potentially
        wasted audio).
        """
        validation = await self._validate_cursor()
        if not validation.is_typeable:
            logger.info("Cursor validation failed: %s", validation.reason)
            # Only cancel if still in RECORDING state
            if self._state == PipelineState.RECORDING:
                self._recorder.stop()  # discard audio
                # Restore ducked audio
                if self._ducker is not None:
                    await self._ducker.restore()
                if self._context_task is not None:
                    self._context_task.cancel()
                    self._context_task = None
                if self._silence_task is not None:
                    self._silence_task.cancel()
                    self._silence_task = None
                self._event_log = None
                self._feedback = None
                self._state = PipelineState.IDLE
                if self._settings.validation.warning_sound:
                    self._track(play_warning_sound())
                if self._indicator is not None:
                    if hasattr(self._indicator, 'hide_tooltip'):
                        self._indicator.hide_tooltip()
                    if hasattr(self._indicator, 'show_warning_tooltip'):
                        self._indicator.show_warning_tooltip(validation.reason)
                    self._indicator.set_status("idle")

    def _get_ducker(self):
        """Lazy-create AudioDucker from config. Returns None if disabled."""
        if not self._settings.ducking.enabled:
            return None
        if self._ducker is None:
            from talk_to_tux.audio.ducking import AudioDucker
            self._ducker = AudioDucker(
                factor=self._settings.ducking.factor,
                enabled=True,
            )
        return self._ducker

    def _debug(self, section: str, content: str) -> None:
        """Update a debug tooltip section if debug mode is enabled."""
        if not self._settings.debug.tooltip_enabled:
            return
        if self._indicator is not None and hasattr(self._indicator, 'update_debug_section'):
            self._indicator.update_debug_section(section, content)

    @property
    def _processing(self) -> bool:
        """Backward-compat alias for tests checking _processing."""
        return self._state not in (PipelineState.IDLE, PipelineState.TOOLTIP_SHOWN)

    @_processing.setter
    def _processing(self, value: bool) -> None:
        """Backward-compat setter — only used by legacy test code."""
        if value:
            self._state = PipelineState.PROCESSING
        else:
            if self._state not in (PipelineState.IDLE, PipelineState.TOOLTIP_SHOWN):
                self._state = PipelineState.IDLE

    # --- Event log helpers ---

    async def _capture_event_screenshot(self, entry) -> None:
        """Fire-and-forget async screenshot capture for an event.

        Only runs when TTT_DEBUG_EVENT_SCREENSHOTS=1 is set. In normal
        operation, event *entries* are still recorded (timestamps, state)
        but the expensive screenshot capture is skipped.
        """
        if not os.environ.get("TTT_DEBUG_EVENT_SCREENSHOTS"):
            return
        try:
            if self._context_capturer is None:
                return
            ss_bytes, _w, _h = await self._context_capturer._screenshot.capture()
            if ss_bytes:
                filename = event_screenshot_filename(entry.seq, entry.event)
                if self._run_dir_ready and self._cache is not None:
                    self._cache.save_event_screenshot(filename, ss_bytes)
                else:
                    # Buffer until begin_run() creates the run dir
                    self._buffered_event_screenshots.append((filename, ss_bytes))
                entry.has_screenshot = True
        except Exception:
            logger.debug("Event screenshot failed for %s", entry.event, exc_info=True)

    def _add_event(self, name: str, *, metadata: dict | None = None):
        """Add event to log with current pipeline state. Returns entry or None."""
        if self._event_log is None:
            return None
        return self._event_log.add(
            name, pipeline_state=self._state.name, metadata=metadata,
        )

    def _save_event_log(self) -> None:
        """Persist event log to cache and feedback."""
        if self._event_log is not None and self._cache is not None:
            self._cache.save_event_log(self._event_log)
        if self._event_log is not None and self._feedback is not None:
            self._feedback.set_event_log(self._event_log.to_list())

    def _flush_indicator_event_screenshots(self) -> None:
        """Retrieve and save GTK-captured event screenshots from indicator."""
        if self._indicator is None or not hasattr(self._indicator, 'pop_event_screenshots'):
            return
        for entry, shot_bytes in self._indicator.pop_event_screenshots():
            if self._cache is not None:
                self._cache.save_event_screenshot(
                    event_screenshot_filename(entry.seq, entry.event), shot_bytes,
                )

    # --- Double-tap arming / disarming / drift / hold ---

    @staticmethod
    def _get_cursor_pos_sync() -> tuple[int, int] | None:
        """Get current cursor (x, y) via xdotool. Runs in executor."""
        import subprocess
        try:
            r = subprocess.run(
                ["xdotool", "getmouselocation", "--shell"],
                capture_output=True, text=True, timeout=2,
            )
            if r.returncode != 0:
                return None
            vals: dict[str, int] = {}
            for line in r.stdout.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    vals[k] = int(v)
            return (vals["X"], vals["Y"])
        except Exception:
            return None

    @staticmethod
    def _get_window_geometry_sync(window_id: str) -> tuple[int, int, int, int] | None:
        """Get window (x, y, width, height) via xdotool. Runs in executor."""
        import subprocess
        try:
            r = subprocess.run(
                ["xdotool", "getwindowgeometry", "--shell", window_id],
                capture_output=True, text=True, timeout=2,
            )
            if r.returncode != 0:
                return None
            vals: dict[str, int] = {}
            for line in r.stdout.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    vals[k] = int(v)
            return (vals["X"], vals["Y"], vals["WIDTH"], vals["HEIGHT"])
        except Exception:
            return None

    async def _arm_double_tap(self, window_id: str | None) -> None:
        """Arm double-tap Enter with 30s timeout, drift monitor, and armed icon.

        On Wayland without GNOME Shell extension, window_id may be None.
        Double-tap still works — drift detection is skipped (timeout-only disarm).
        """
        self._enter_armed = True
        self._enter_paste_window_id = window_id
        self._pending_enter = False

        # Capture paste window geometry for drift detection
        try:
            loop = asyncio.get_running_loop()
            self._enter_arm_win_rect = await loop.run_in_executor(
                None, self._get_window_geometry_sync, window_id,
            )
        except Exception:
            self._enter_arm_win_rect = None

        # Start drift monitor
        if self._drift_monitor_task is not None:
            self._drift_monitor_task.cancel()
        self._drift_monitor_task = asyncio.create_task(self._drift_monitor())

        # Start 30s timeout
        if self._enter_arm_timeout_handle is not None:
            self._enter_arm_timeout_handle.cancel()
        try:
            loop = asyncio.get_running_loop()
            self._enter_arm_timeout_handle = loop.call_later(
                30, self._disarm_double_tap,
            )
        except RuntimeError:
            pass

        # Armed icon
        if self._indicator is not None:
            self._indicator.set_status("armed")

    def _disarm_double_tap(self) -> None:
        """Clear all armed state, cancel timers, restore idle icon."""
        self._enter_armed = False
        self._pending_enter = False
        self._enter_arm_win_rect = None
        self._hold_pending_tap = False

        # Clean up speculative recording if still pending
        if self._speculative_recording:
            try:
                self._recorder.stop()
            except Exception:
                pass
            self._speculative_recording = False

        if self._drift_monitor_task is not None:
            self._drift_monitor_task.cancel()
            self._drift_monitor_task = None
        if self._enter_arm_timeout_handle is not None:
            self._enter_arm_timeout_handle.cancel()
            self._enter_arm_timeout_handle = None
        if self._hold_override_handle is not None:
            self._hold_override_handle.cancel()
            self._hold_override_handle = None

        # Restore idle icon only if currently in IDLE state
        if self._state == PipelineState.IDLE and self._indicator is not None:
            self._indicator.set_status("idle")

    async def _drift_monitor(self) -> None:
        """Check cursor position every 1s; disarm if outside window grace zone."""
        try:
            while self._enter_armed:
                await asyncio.sleep(1)
                if not self._enter_armed or self._enter_arm_win_rect is None:
                    return
                loop = asyncio.get_running_loop()
                pos = await loop.run_in_executor(None, self._get_cursor_pos_sync)
                if pos is None:
                    continue
                cx, cy = pos
                wx, wy, ww, wh = self._enter_arm_win_rect
                # Grace zone: expand window rect by 50% of window height on all sides
                pad = int(wh * 0.5)
                if cx < wx - pad or cx > wx + ww + pad or cy < wy - pad or cy > wy + wh + pad:
                    logger.debug("Cursor drifted outside grace zone — disarming double-tap")
                    self._disarm_double_tap()
                    return
        except asyncio.CancelledError:
            pass

    def _start_enter_watcher(self) -> None:
        """Start passive Enter key monitoring on all keyboards.

        Idempotent — stops any existing watcher before starting a new one.
        Schedules an independent 35s timeout for automatic cleanup.
        """
        self._stop_enter_watcher()
        try:
            from evdev import InputDevice, ecodes

            paths = HotkeyListener._find_all_devices_with_key(ecodes.KEY_ENTER)
            for path in paths:
                try:
                    dev = InputDevice(path)
                    # Filter out our own UInput devices
                    if dev.name in ("talk-to-tux-mouse", "talk-to-tux-keys"):
                        dev.close()
                        continue
                    task = asyncio.create_task(self._enter_event_loop(dev))
                    self._enter_watcher_tasks.append(task)
                    self._enter_watcher_devices.append(dev)
                except Exception:
                    logger.debug("Failed to open %s for Enter watch", path)
            if self._enter_watcher_devices:
                logger.info(
                    "Enter watcher: monitoring %d keyboard(s)",
                    len(self._enter_watcher_devices),
                )
            # Schedule independent 35s timeout
            try:
                loop = asyncio.get_running_loop()
                self._enter_watcher_timeout_handle = loop.call_later(
                    35, self._stop_enter_watcher,
                )
            except RuntimeError:
                pass
        except Exception:
            logger.info("Enter watcher startup failed", exc_info=True)

    def _stop_enter_watcher(self) -> None:
        """Cancel all Enter watcher tasks, close devices, and cancel timeout."""
        if self._enter_watcher_timeout_handle is not None:
            self._enter_watcher_timeout_handle.cancel()
            self._enter_watcher_timeout_handle = None
        for t in self._enter_watcher_tasks:
            t.cancel()
        self._enter_watcher_tasks.clear()
        for dev in self._enter_watcher_devices:
            try:
                dev.close()
            except Exception:
                pass
        self._enter_watcher_devices.clear()

    async def _enter_event_loop(self, device: object) -> None:
        """Watch a single keyboard device for Enter key press."""
        try:
            from evdev import ecodes

            async for event in device.async_read_loop():
                if (
                    event.type == ecodes.EV_KEY
                    and event.code == ecodes.KEY_ENTER
                    and event.value == 1  # key down
                ):
                    if self._ignore_next_enter:
                        logger.info("Enter watcher: ignoring injected Enter")
                        self._ignore_next_enter = False
                        continue
                    # Check for Shift (Shift+Enter = newline, not submit)
                    try:
                        active = device.active_keys()
                        from evdev.ecodes import KEY_LEFTSHIFT, KEY_RIGHTSHIFT
                        if KEY_LEFTSHIFT in active or KEY_RIGHTSHIFT in active:
                            continue
                    except Exception:
                        pass
                    self._track(self._on_manual_enter())
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.debug("Enter event loop failed", exc_info=True)

    async def _on_manual_enter(self) -> None:
        """Read back text via AT-SPI and record correction if user edited."""
        if self._last_auto_paste_text is None:
            return
        try:
            from talk_to_tux.context.accessibility import query_widgets_subprocess

            focused, _cursor, _ok = await query_widgets_subprocess(timeout=1.5)
            submitted_text = None
            widget_role = None
            if focused is not None:
                widget_role = focused.role
                submitted_text = focused.text_around_caret or focused.text_content

            if submitted_text is None:
                logger.info("manual_enter_unknown — AT-SPI returned no text")
                # Capture screenshot for later analysis (Chrome/Electron apps)
                await self._capture_correction_screenshot()
            elif submitted_text.strip() == self._last_auto_paste_text.strip():
                logger.info("manual_enter_accepted — text matches pasted")
            else:
                logger.info("manual_enter_edited — user corrected text")
                self._record_correction(
                    self._last_auto_paste_text,
                    submitted_text,
                    "atspi_readback",
                    widget_role=widget_role,
                )
        except Exception:
            logger.debug("_on_manual_enter failed", exc_info=True)
        finally:
            self._stop_enter_watcher()
            self._last_auto_paste_text = None
            self._last_auto_paste_context = None
            if self._enter_armed:
                self._disarm_double_tap()

    def _record_correction(
        self,
        pasted: str,
        submitted: str,
        method: str,
        widget_role: str | None = None,
    ) -> None:
        """Route correction data to feedback and the learning accumulator."""
        app_class = getattr(self._last_auto_paste_context, 'window_class', None)
        stt_text = None
        if self._feedback is not None and self._feedback.stt is not None:
            stt_text = self._feedback.stt.get("text")

        if self._feedback is not None:
            self._feedback.record_correction(
                pasted, submitted, method,
                app_class=app_class,
                widget_role=widget_role,
                stt_text=stt_text,
            )
            self._feedback.set_user_action("manual_enter_edited")

        if self._correction_learner is not None:
            self._correction_learner.observe(pasted, submitted, app_class, stt_text)
            self._correction_learner.promote()

    async def _capture_correction_screenshot(self) -> None:
        """Capture screenshot when AT-SPI can't read text (Chrome/Electron apps).

        Saves to the current run directory as correction_screenshot.jpg for
        later LLM-based analysis of what the user actually submitted.
        """
        try:
            if self._context_capturer is None:
                return
            ss_bytes, _w, _h = await self._context_capturer._screenshot.capture()
            if ss_bytes and self._cache is not None:
                self._cache.save_event_screenshot("correction_screenshot.jpg", ss_bytes)
                logger.info(
                    "Saved correction screenshot (%d bytes) for later analysis",
                    len(ss_bytes),
                )
                # Record in feedback that a screenshot-based correction is pending
                if self._feedback is not None:
                    self._feedback.record_correction(
                        pasted=self._last_auto_paste_text or "",
                        submitted="[screenshot pending analysis]",
                        method="screenshot",
                        app_class=getattr(
                            self._last_auto_paste_context, 'window_class', None,
                        ),
                        stt_text=(
                            self._feedback.stt.get("text")
                            if self._feedback.stt else None
                        ),
                    )
                    self._feedback.set_user_action("manual_enter_screenshot")
        except Exception:
            logger.debug("Correction screenshot failed", exc_info=True)

    async def _execute_deferred_tap(self) -> None:
        """Handle a quick tap while armed: first tap sets pending, second sends Enter.

        If the speculative recording captured speech, override the tap and
        start a real recording — the user was dictating, not double-tapping.
        """
        if self._speculative_recording:
            # Check if user was actually speaking during the tap
            audio = self._recorder.stop()
            self._speculative_recording = False
            if len(audio) > 0 and self._vad.get_speech_timestamps(audio):
                logger.info("Speculative recording has speech — converting to real recording")
                self._disarm_double_tap()
                # Re-feed the captured audio: restart recorder and stash the
                # already-captured samples so they aren't lost.
                self._recorder.start()
                self._recorder._chunks.insert(0, audio.reshape(-1, 1) if audio.ndim == 1 else audio)
                await self._begin_recording_session(start_recorder=False)
                return
        if self._pending_enter:
            # Second tap — send Enter
            logger.info("Double-tap → Enter")
            wid = getattr(self._last_auto_paste_context, 'window_id', None)
            wpid = getattr(self._last_auto_paste_context, 'window_pid', None)
            self._ignore_next_enter = True
            if self._paster is not None:
                await self._paster.send_enter(window_id=wid, pid=wpid)
            if self._feedback is not None:
                self._feedback.set_user_action("double_tap_enter")
            self._disarm_double_tap()
            self._stop_enter_watcher()
            self._last_auto_paste_text = None
            self._last_auto_paste_context = None
        else:
            # First tap after paste — wait for second
            logger.debug("First tap after paste — waiting for double-tap")
            self._pending_enter = True

    async def _override_double_tap_and_record(self) -> None:
        """Hold timer fired (>300ms) — disarm and start recording.

        Recorder is already running from speculative start; just need to
        set up the pipeline session state (event log, feedback, indicator, etc.).
        """
        self._hold_pending_tap = False
        was_speculative = self._speculative_recording
        self._speculative_recording = False
        # Disarm without stopping recorder (already cleared by flag above)
        self._enter_armed = False
        self._pending_enter = False
        self._enter_arm_win_rect = None
        if self._drift_monitor_task is not None:
            self._drift_monitor_task.cancel()
            self._drift_monitor_task = None
        if self._enter_arm_timeout_handle is not None:
            self._enter_arm_timeout_handle.cancel()
            self._enter_arm_timeout_handle = None
        # hold_override_handle already fired (this IS the callback)

        if self._state == PipelineState.IDLE:
            if was_speculative:
                # Recorder already running — just set up the session
                await self._begin_recording_session(start_recorder=False)
            else:
                await self.on_record_start()

    async def on_record_start(self) -> None:
        if self._state == PipelineState.TOOLTIP_SHOWN:
            await self._handle_tooltip_chord()
            return

        # Double-tap sends Enter after a recent paste (requires TWO taps).
        # The ring buffer in the recorder captures ~2s of audio before the
        # button press, so the speculative recording check in
        # _execute_deferred_tap() can reliably distinguish "user is
        # speaking" from "user is just tapping" via VAD on the ring buffer.
        if self._enter_armed and self._paster is not None:
            current_wid = None
            if self._indicator is not None:
                ctx = self._indicator.last_focused_context
                current_wid = getattr(ctx, 'window_id', None)
            wid_match = (
                self._enter_paste_window_id is None
                or current_wid == self._enter_paste_window_id
            )
            if wid_match:
                # Speculative recording: snapshot the ring buffer.  On quick
                # release, _execute_deferred_tap() checks VAD; if speech is
                # found in the captured audio (including the pre-button ring
                # buffer), the tap is converted to a real recording.
                self._hold_pending_tap = True
                self._speculative_recording = True
                self._record_start_ts = time.perf_counter()
                try:
                    self._recorder.start()
                except Exception:
                    self._speculative_recording = False
                try:
                    loop = asyncio.get_running_loop()
                    self._hold_override_handle = loop.call_later(
                        0.3,
                        lambda: asyncio.ensure_future(self._override_double_tap_and_record()),
                    )
                except RuntimeError:
                    pass
                return  # wait for UP (tap) or hold timeout (recording)
            else:
                self._disarm_double_tap()
        self._pending_enter = False  # not armed

        if self._state == PipelineState.PROCESSING:
            # Button pressed during processing — defer until processing completes
            logger.debug("Deferring record_start — state is PROCESSING")
            self._deferred_start = True
            # Cancel any blocking notification so processing completes quickly
            from talk_to_tux.pipeline.notify import cancel_active_notification
            cancel_active_notification()
            return
        if self._state != PipelineState.IDLE:
            logger.debug("Ignoring record_start — state is %s", self._state.name)
            return

        # New recording clears any armed double-tap state
        self._disarm_double_tap()

        # Cancel any in-flight notification from a previous run
        from talk_to_tux.pipeline.notify import cancel_active_notification
        cancel_active_notification()

        # Start the recorder and set up the recording session
        await self._begin_recording_session(start_recorder=True)

    async def _begin_recording_session(self, start_recorder: bool = True) -> None:
        """Set up recording session state and optionally start the recorder.

        When called from the speculative-recording hold path, the recorder is
        already running so ``start_recorder=False`` skips the start() call.
        """
        # Transition to RECORDING immediately — validation runs concurrently
        self._state = PipelineState.RECORDING
        logger.info("Recording...")

        # Create event log and feedback collector for this run
        self._event_log = EventLog()
        self._run_dir_ready = False
        self._feedback = FeedbackCollector()
        if isinstance(self._listener, SideButtonListener):
            self._feedback.set_trigger("side_button")
        elif isinstance(self._listener, KeyboardChordListener):
            self._feedback.set_trigger("keyboard_chord")
        elif isinstance(self._listener, HotkeyListener):
            self._feedback.set_trigger("hotkey")
        elif isinstance(self._listener, MouseChordListener):
            self._feedback.set_trigger("mouse_chord")
        else:
            self._feedback.set_trigger("unknown")

        # Capture pre-recording context from indicator's cached focus window
        if self._indicator is not None:
            self._feedback.capture_pre_recording(self._indicator.last_focused_context)

        # Clear debug tooltip for new run
        if self._indicator is not None and hasattr(self._indicator, 'clear_debug_tooltip'):
            self._indicator.clear_debug_tooltip()
        self._debug("Trigger", f"State:  RECORDING\nTime:   {time.strftime('%H:%M:%S')}")

        if self._indicator is not None:
            if hasattr(self._indicator, 'set_event_log'):
                self._indicator.set_event_log(self._event_log)
            self._indicator.set_status("recording")
            if hasattr(self._indicator, 'show_tooltip_recording'):
                self._indicator.show_tooltip_recording()

        if start_recorder:
            # Start recording immediately (before validation completes)
            self._record_start_ts = time.perf_counter()
            logger.info("recorder.start() at perf_counter=%.3f", self._record_start_ts)
            try:
                self._recorder.start()
            except Exception:
                logger.warning("Audio recorder failed to start", exc_info=True)
                self._state = PipelineState.IDLE
                if self._indicator is not None:
                    if hasattr(self._indicator, 'hide_tooltip'):
                        self._indicator.hide_tooltip()
                    self._indicator.set_status("idle")
                return

        # Duck other audio streams (awaited — must complete before stop can restore)
        ducker = self._get_ducker()
        if ducker is not None:
            await ducker.duck()

        # Safety timer: auto-stop after max_recording_s
        try:
            loop = asyncio.get_running_loop()
            self._max_record_handle = loop.call_later(
                self._settings.trigger.max_recording_s,
                lambda: asyncio.ensure_future(self._safety_stop_recording()),
            )
        except RuntimeError:
            pass

        # Silence monitor: auto-stop after prolonged silence
        self._silence_task = None
        if self._settings.trigger.silence_timeout_s > 0:
            self._silence_task = asyncio.create_task(self._silence_monitor())

        # Speculative transcription loop (Change 2): only when gpu_server is first in chain
        self._speculative_results = []
        self._speculative_chunk_idx = 0
        self._speculative_task = None
        if (
            self._stt_client is not None
            and self._stt_client._chain
            and self._stt_client._chain[0][0] == "gpu_server"
        ):
            self._speculative_task = asyncio.create_task(self._speculative_transcript_loop())

        # Event: recording_start (async screenshot)
        entry = self._add_event("recording_start")
        if entry is not None and self._context_capturer is not None:
            self._track(self._capture_event_screenshot(entry))

        # Cursor validation runs concurrently — cancels recording if it fails
        self._validation_task = None
        if self._settings.validation.enabled:
            self._validation_task = asyncio.create_task(
                self._async_validate_and_cancel()
            )

        # Fire-and-forget: detect cursor window + start context capture
        # so on_record_start() returns immediately after recorder.start()
        self._track(self._start_context_capture())

    async def _start_context_capture(self) -> None:
        """Detect cursor window and start context capture (fire-and-forget)."""
        self._pre_chord_window_id = None
        try:
            from talk_to_tux.context.window import get_window_under_cursor
            loop = asyncio.get_running_loop()
            self._pre_chord_window_id = await loop.run_in_executor(
                None, get_window_under_cursor,
            )
        except Exception:
            logger.debug("Failed to get window under cursor", exc_info=True)

        if self._context_capturer is not None:
            self._context_task = asyncio.create_task(
                self._context_capturer.capture(
                    cursor_window_id=self._pre_chord_window_id,
                )
            )

    async def _handle_tooltip_chord(self) -> None:
        """Handle a chord press while tooltip is shown (double-chord to confirm)."""
        now = time.monotonic()
        if (
            self._last_tooltip_chord_time is not None
            and now - self._last_tooltip_chord_time <= self._settings.tooltip.double_chord_window_ms / 1000
        ):
            # Double chord confirmed -> paste (no Enter — chord is just a confirm gesture)
            self._last_tooltip_chord_time = None
            await self.on_confirm_paste(send_enter=False)
        else:
            self._last_tooltip_chord_time = now

    async def on_confirm_paste(
        self, send_enter: bool = False, clicked_index: int | None = None,
    ) -> None:
        """Paste the selected tooltip text into the active app."""
        if self._state != PipelineState.TOOLTIP_SHOWN:
            return
        self._state = PipelineState.PASTING

        # Cancel auto-dismiss timeout
        if self._tooltip_timeout_handle is not None:
            self._tooltip_timeout_handle.cancel()
            self._tooltip_timeout_handle = None

        # Get text: clicked_index (from click) takes priority, then tooltip selection, then first
        text_to_paste = None
        paste_context = None
        if clicked_index is not None and clicked_index < len(self._pending_rewrites):
            text_to_paste, paste_context = self._pending_rewrites[clicked_index]
        elif self._indicator is not None and hasattr(self._indicator, 'get_tooltip_selected'):
            selected = self._indicator.get_tooltip_selected()
            if selected is not None:
                idx, text_to_paste = selected
                if idx < len(self._pending_rewrites):
                    _, paste_context = self._pending_rewrites[idx]
        if text_to_paste is None and self._pending_rewrites:
            text_to_paste, paste_context = self._pending_rewrites[0]

        # Use CURRENT focused window for paste (not stale recording-time context)
        if self._indicator is not None and hasattr(self._indicator, 'last_focused_context'):
            current_ctx = self._indicator.last_focused_context
            if current_ctx is not None:
                paste_context = current_ctx

        # Hide tooltip BEFORE pasting — the GTK popup can interfere with
        # keystroke routing to the target window on X11/Mutter.
        if self._indicator is not None and hasattr(self._indicator, 'hide_tooltip'):
            self._indicator.hide_tooltip()
        await asyncio.sleep(0.15)  # let Mutter refocus the target window

        _arm_wid = None
        if text_to_paste is not None:
            logger.debug(
                "Pasting into window_id=%s window_class=%s",
                getattr(paste_context, 'window_id', None),
                getattr(paste_context, 'window_class', None),
            )
            # Event: pre_paste (awaited)
            pre_entry = self._add_event("pre_paste")
            if pre_entry is not None and self._context_capturer is not None:
                await self._capture_event_screenshot(pre_entry)

            t0_paste = time.perf_counter()
            await self._do_paste(text_to_paste, paste_context)
            _arm_wid = getattr(paste_context, 'window_id', None)

            # Event: paste_complete (async)
            pc_entry = self._add_event("paste_complete")
            if pc_entry is not None and self._context_capturer is not None:
                self._track(self._capture_event_screenshot(pc_entry))
            if send_enter and self._paster is not None:
                wid = getattr(paste_context, 'window_id', None)
                await self._paster.send_enter(window_id=wid)
            # Feedback: tooltip confirm
            if self._feedback is not None:
                paste_ms = (time.perf_counter() - t0_paste) * 1000
                self._feedback.capture_paste(text_to_paste, paste_context, paste_ms, success=True)
                if self._indicator is not None:
                    self._feedback.capture_post_paste_immediate(
                        self._indicator.last_focused_context
                    )
                confirm_method = "double_chord" if not send_enter and clicked_index is None else "click"
                if clicked_index is not None:
                    confirm_method = "click"
                self._feedback.set_user_action("tooltip_confirm")
                self._feedback.capture_tooltip(
                    options_count=len(self._pending_rewrites),
                    selected_index=clicked_index,
                    confirm_method=confirm_method,
                )
                # Flush event screenshots from GTK and save event log
                self._flush_indicator_event_screenshots()
                self._save_event_log()
                self._save_feedback_now()
            self._schedule_post_paste_screenshots()

        self._restore_debounce()
        self._state = PipelineState.IDLE
        if self._indicator is not None:
            self._indicator.set_status("idle")
        await self._arm_double_tap(_arm_wid)
        self._start_enter_watcher()

    async def on_dismiss_tooltip(self) -> None:
        """Hide tooltip and return to IDLE."""
        if self._state != PipelineState.TOOLTIP_SHOWN:
            return
        if self._tooltip_timeout_handle is not None:
            self._tooltip_timeout_handle.cancel()
            self._tooltip_timeout_handle = None
        if self._indicator is not None and hasattr(self._indicator, 'hide_tooltip'):
            self._indicator.hide_tooltip()
        self._restore_debounce()
        self._state = PipelineState.IDLE
        if self._indicator is not None:
            self._indicator.set_status("idle")
        if self._feedback is not None:
            self._feedback.set_user_action("tooltip_dismiss")
            self._flush_indicator_event_screenshots()
            self._save_event_log()
            self._save_feedback_now()
        await self._maybe_auto_analyze()
        logger.info("Tooltip dismissed")

    async def _eager_rewrite(self, context: object) -> None:
        """Rewrite pending transcription for a new context (hover target)."""
        if self._state != PipelineState.TOOLTIP_SHOWN or self._smart_rewriter is None:
            return
        if self._pending_transcription is None:
            return
        # Dedup: skip if already have rewrite for this window_class
        for _, existing_ctx in self._pending_rewrites:
            if (
                existing_ctx is not None
                and hasattr(existing_ctx, 'window_class')
                and hasattr(context, 'window_class')
                and existing_ctx.window_class == context.window_class
            ):
                return
        all_windows = self._get_all_windows()
        rewrite = await self._smart_rewriter.rewrite(
            self._pending_transcription, context, all_windows=all_windows,
        )
        self._pending_rewrites.append((rewrite.text, context))
        if self._indicator is not None and hasattr(self._indicator, 'update_tooltip'):
            label = ""
            if hasattr(context, 'window_class'):
                label = context.window_class or ""
            if not label and hasattr(context, 'window_title'):
                label = context.window_title or ""
            self._indicator.update_tooltip(rewrite.text, label)

    def _get_all_windows(self) -> list:
        """Get all tracked window contexts from indicator."""
        if self._indicator is not None and hasattr(self._indicator, 'all_window_contexts'):
            return self._indicator.all_window_contexts
        return []

    def _restore_debounce(self) -> None:
        """Restore the mouse listener's debounce and dismiss behavior."""
        if hasattr(self._listener, 'set_debounce'):
            self._listener.set_debounce(self._settings.trigger.chord_debounce_ms / 1000)
        if hasattr(self._listener, '_suppress_dismiss'):
            self._listener._suppress_dismiss = False
        self._last_tooltip_chord_time = None
        if self._escape_task is not None:
            self._escape_task.cancel()
            self._escape_task = None

    async def _watch_escape(self) -> None:
        """Watch for Escape key on ALL keyboards to dismiss tooltip."""
        try:
            from evdev import InputDevice, ecodes

            if self._settings.trigger.keyboard.device_path:
                paths = [self._settings.trigger.keyboard.device_path]
            else:
                paths = HotkeyListener._find_all_devices_with_key(ecodes.KEY_ESC)

            async def _watch_one(path: str) -> None:
                dev = InputDevice(path)
                try:
                    async for event in dev.async_read_loop():
                        if event.type == ecodes.EV_KEY and event.code == ecodes.KEY_ESC and event.value == 1:
                            return
                finally:
                    dev.close()

            watchers = [asyncio.create_task(_watch_one(p)) for p in paths]
            try:
                done, pending = await asyncio.wait(watchers, return_when=asyncio.FIRST_COMPLETED)
                for t in pending:
                    t.cancel()
                await self.on_dismiss_tooltip()
            finally:
                for t in watchers:
                    if not t.done():
                        t.cancel()
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.debug("Escape watcher failed", exc_info=True)

    async def _safety_stop_recording(self) -> None:
        """Auto-stop recording after max_recording_s to prevent infinite recordings."""
        if self._state != PipelineState.RECORDING:
            return
        logger.warning(
            "Safety timer: auto-stopping recording after %ds",
            self._settings.trigger.max_recording_s,
        )
        await self.on_record_stop()

    async def _silence_monitor(self) -> None:
        """Auto-stop recording when no speech is detected for silence_timeout_s.

        Wakes every 2s, peeks at the last 2s of audio, runs VAD to check for
        speech. If no speech is detected for the configured timeout, triggers
        on_record_stop(). A 3s grace period at the start gives the user time
        to begin speaking.
        """
        timeout = self._settings.trigger.silence_timeout_s
        sample_rate = self._settings.audio.sample_rate
        window_samples = sample_rate * 2  # 2 seconds of audio
        last_speech_time = time.monotonic()

        try:
            # Grace period — user needs time to start speaking
            await asyncio.sleep(3)

            while self._state == PipelineState.RECORDING:
                await asyncio.sleep(2)
                if self._state != PipelineState.RECORDING:
                    break

                tail = self._recorder.peek_tail(window_samples)
                if tail is None or len(tail) == 0:
                    continue

                # Run VAD in executor (silero inference ~5ms, but keep off event loop)
                loop = asyncio.get_running_loop()
                timestamps = await loop.run_in_executor(
                    None,
                    self._vad.get_speech_timestamps,
                    tail,
                )

                if timestamps:
                    last_speech_time = time.monotonic()
                elif time.monotonic() - last_speech_time >= timeout:
                    logger.info(
                        "Silence monitor: no speech for %.0fs — auto-stopping",
                        timeout,
                    )
                    await self.on_record_stop()
                    return
        except asyncio.CancelledError:
            pass

    async def on_record_stop(self) -> None:
        # Hold detection: button released before 300ms → quick tap
        if self._hold_override_handle is not None:
            self._hold_override_handle.cancel()
            self._hold_override_handle = None
            if self._hold_pending_tap:
                self._hold_pending_tap = False
                await self._execute_deferred_tap()
                return  # quick tap, not a recording stop

        if self._state == PipelineState.TOOLTIP_SHOWN:
            # Release after chord in tooltip state — no-op
            return
        if self._state == PipelineState.PROCESSING:
            # If pending_enter, this is a release between double-tap taps — don't cancel deferred
            if not self._pending_enter:
                self._deferred_start = False
            return
        if self._state != PipelineState.RECORDING:
            logger.debug("Ignoring record_stop — state is %s", self._state.name)
            return

        # Cancel safety timer
        if self._max_record_handle is not None:
            self._max_record_handle.cancel()
            self._max_record_handle = None

        # Cancel silence monitor
        if self._silence_task is not None:
            self._silence_task.cancel()
            self._silence_task = None

        # Cancel speculative transcription loop
        if self._speculative_task is not None:
            self._speculative_task.cancel()
            try:
                await self._speculative_task
            except asyncio.CancelledError:
                pass
            self._speculative_task = None

        # Restore ducked audio (awaited — must complete before next duck)
        if self._ducker is not None:
            await self._ducker.restore()

        self._state = PipelineState.PROCESSING

        # Event: processing
        entry = self._add_event("processing")
        if entry is not None and self._context_capturer is not None:
            self._track(self._capture_event_screenshot(entry))

        self._processing_task = asyncio.create_task(self._process_recording_safe())

    async def _process_recording_safe(self) -> None:
        """Wrapper that catches exceptions so they don't crash the event loop."""
        from talk_to_tux.auth import (
            AuthFailed,
            HostedError,
            QuotaExhausted,
            RecordingTooLong,
            TierLocked,
            TokenInvalid,
        )
        try:
            await self._process_recording()
            # Hunk 4 — post-recording quota refresh (fire-and-forget)
            if self._indicator is not None:
                self._indicator.refresh_quota_after_recording()
        except (RecordingTooLong, QuotaExhausted, TierLocked, AuthFailed) as exc:
            self._hide_early_tooltip()
            if self._ducker is not None:
                await self._ducker.restore()
            self._state = PipelineState.IDLE
            if self._indicator is not None:
                self._indicator.set_status("idle")
            await self._handle_hosted_error_notification(exc)
        except TokenInvalid as exc:
            self._hide_early_tooltip()
            if self._ducker is not None:
                await self._ducker.restore()
            self._state = PipelineState.IDLE
            if self._indicator is not None:
                self._indicator.set_status("idle")
            await self._handle_hosted_error_notification(exc)
            if self._token_store is not None:
                self._token_store.delete()
        except HostedError as exc:
            self._hide_early_tooltip()
            if self._ducker is not None:
                await self._ducker.restore()
            self._state = PipelineState.IDLE
            if self._indicator is not None:
                self._indicator.set_status("idle")
            await self._handle_hosted_error_notification(exc)
        except Exception:
            logger.exception("Pipeline processing failed")
            self._hide_early_tooltip()
            if self._ducker is not None:
                await self._ducker.restore()  # idempotent — safe if already restored
            self._state = PipelineState.IDLE
            if self._indicator is not None:
                self._indicator.set_status("idle")
        finally:
            # Always release the cache run handle so the next trigger can't
            # accidentally write into a stale run dir after a mid-pipeline
            # failure.
            if self._cache is not None:
                self._cache.finalize_run()
            self._run_dir_ready = False
            await self._maybe_auto_analyze()
            # If button was pressed during processing, start recording now
            if self._deferred_start and self._state == PipelineState.IDLE:
                self._deferred_start = False
                # Verify button is still physically held — avoids phantom recording
                # if UP event was processed after state went IDLE but before this check
                btn_held = (
                    hasattr(self._listener, '_btn_states')
                    and any(self._listener._btn_states.values())
                )
                if btn_held:
                    logger.info("Executing deferred record_start")
                    await self.on_record_start()
                else:
                    logger.debug("Deferred record_start skipped — button already released")

    def _tooltip_status(self, text: str) -> None:
        """Update tooltip status label if indicator supports it."""
        if (
            self._settings.tooltip.enabled
            and self._indicator is not None
            and hasattr(self._indicator, 'set_tooltip_status')
        ):
            self._indicator.set_tooltip_status(text)

    def _on_partial_transcript(self, text: str) -> None:
        """Called after each SSE segment; shows truncated partial text in tooltip."""
        self._tooltip_status(f"\U0001f3a4 {text[:60]}…")

    async def _speculative_transcript_loop(self) -> None:
        """Fire background STT calls against the GPU server during recording.

        Sends non-overlapping audio windows every 10 s so that by the time
        the button is released most of the transcript is already assembled.
        Only runs when gpu_server is first in the STT chain.
        """
        await asyncio.sleep(10)
        while self._state == PipelineState.RECORDING:
            try:
                wav, new_idx = self._recorder.get_partial_wav(self._speculative_chunk_idx)
                if wav:
                    initial_prompt = " ".join(self._speculative_results) or None
                    result = await self._stt_client.transcribe(wav, initial_prompt=initial_prompt)
                    self._speculative_results.append(result.text)
                    self._speculative_chunk_idx = new_idx
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.debug("Speculative transcription tick failed", exc_info=True)
            await asyncio.sleep(10)

    def _hide_early_tooltip(self) -> None:
        """Hide recording dot / processing tooltip on early exit (no audio, no speech)."""
        if (
            self._indicator is not None
            and hasattr(self._indicator, 'hide_tooltip')
        ):
            self._indicator.hide_tooltip()

    async def _process_recording(self) -> None:
        logger.info("Processing...")
        if self._indicator is not None:
            self._indicator.set_status("processing")
            self._indicator.set_recording_dot_processing()
        self._tooltip_status("\u2699 Processing...")

        t_start = time.perf_counter()
        telemetry = PipelineTelemetry()

        # Measure trigger-to-recording latency
        trigger_ts = getattr(self._listener, 'last_trigger_ts', None)
        record_start_ts = getattr(self, '_record_start_ts', None)
        if isinstance(trigger_ts, float) and isinstance(record_start_ts, float) and trigger_ts > 0:
            telemetry.trigger_to_record_ms = (record_start_ts - trigger_ts) * 1000
            # Also measure kernel→Python delay (event loop contention)
            kernel_ts = getattr(self._listener, 'last_trigger_kernel_ts', None)
            kernel_delay_ms = None
            if isinstance(kernel_ts, float) and kernel_ts > 0:
                # kernel_ts is time.time()-based; convert perf_counter diff
                kernel_delay_ms = (trigger_ts - (time.perf_counter() - time.time() + kernel_ts)) * 1000
            logger.info(
                "Trigger-to-record: %.1fms (kernel→Python: %s)",
                telemetry.trigger_to_record_ms,
                f"{kernel_delay_ms:.0f}ms" if kernel_delay_ms is not None else "?",
            )

        if self._cache is not None:
            run_dir = self._cache.begin_run()
            if run_dir is not None:
                telemetry.run_id = run_dir.name
                if self._feedback is not None:
                    self._feedback.run_id = run_dir.name
                # Flush any event screenshots buffered before begin_run()
                for filename, ss_bytes in self._buffered_event_screenshots:
                    self._cache.save_event_screenshot(filename, ss_bytes)
                self._buffered_event_screenshots.clear()
                self._run_dir_ready = True

        # Snapshot speculative state before stop() clears chunks (Change 2)
        _spec_results = list(self._speculative_results)
        _spec_chunk_idx = self._speculative_chunk_idx
        _tail_wav = b""
        if _spec_results:
            _tail_wav, _ = self._recorder.get_partial_wav(from_chunk_idx=_spec_chunk_idx)

        audio = self._recorder.stop()

        # Set audio_duration_ms early so all outcomes (no_speech, stt_error) have it
        if self._feedback is not None and len(audio) > 0:
            self._feedback.audio_duration_ms = len(audio) / self._settings.audio.sample_rate * 1000

        if len(audio) == 0:
            logger.info("No audio captured.")
            telemetry.outcome = "no_audio"
            telemetry.total_ms = (time.perf_counter() - t_start) * 1000
            telemetry.emit()
            if self._cache is not None:
                self._cache.save_telemetry(telemetry)
                self._cache.save_early_exit("no_audio")
            if self._feedback is not None:
                self._feedback.set_outcome("no_audio")
                self._feedback.set_total_ms(telemetry.total_ms)
                self._save_event_log()
                self._save_feedback_now()
            self._hide_early_tooltip()
            self._state = PipelineState.IDLE
            return

        # VAD — detect speech presence; STT providers do their own trimming
        raw_duration_ms = len(audio) / self._settings.audio.sample_rate * 1000
        t0 = time.perf_counter()
        trimmed = self._vad.trim_silence(
            audio,
            pre_pad_ms=self._settings.vad.pre_pad_ms,
            post_pad_ms=self._settings.vad.post_pad_ms,
        )
        telemetry.add_stage("vad", (time.perf_counter() - t0) * 1000, ok=trimmed is not None)

        if trimmed is None:
            logger.info("No speech detected.")
            telemetry.outcome = "no_speech"
            telemetry.total_ms = (time.perf_counter() - t_start) * 1000
            telemetry.emit()
            if self._cache is not None:
                self._cache.save_telemetry(telemetry)
                self._cache.save_early_exit("no_speech")
            if self._feedback is not None:
                self._feedback.set_outcome("no_speech")
                self._feedback.set_total_ms(telemetry.total_ms)
                self._save_event_log()
                self._save_feedback_now()
            self._hide_early_tooltip()
            self._state = PipelineState.IDLE
            return

        trimmed_duration_ms = len(trimmed) / self._settings.audio.sample_rate * 1000
        logger.debug(
            "Audio: raw=%.0fms, VAD-trimmed=%.0fms (%.0f%% kept)",
            raw_duration_ms, trimmed_duration_ms,
            trimmed_duration_ms / raw_duration_ms * 100 if raw_duration_ms > 0 else 0,
        )

        # Send VAD-trimmed audio so STT bills for speech, not held-button time.
        # The recorder's 2s ring buffer preserves the pre-onset noise floor that
        # Whisper-family models adapt to; long silent gaps between utterances
        # are dropped.
        stt_audio = trimmed
        telemetry.audio_duration_ms = raw_duration_ms
        telemetry.stt_audio_duration_ms = trimmed_duration_ms

        wav_bytes = ndarray_to_wav_bytes(stt_audio, self._settings.audio.sample_rate)
        if self._cache is not None:
            self._cache.save_audio(wav_bytes)

        # Collect context if available
        context = None
        if self._context_task is not None:
            t0 = time.perf_counter()
            context = await self._context_task
            telemetry.add_stage("context", (time.perf_counter() - t0) * 1000)
            self._context_task = None
            # Override with cursor window to fix stale-context / wrong-window.
            # Skip override when context already has wm_class from D-Bus
            # (Mutter IDs differ from xdotool IDs — mismatch is expected).
            if (
                self._pre_chord_window_id
                and context.window_id != self._pre_chord_window_id
                and not context.window_class
            ):
                from talk_to_tux.context.window import get_window_info_by_id
                cursor_info = get_window_info_by_id(self._pre_chord_window_id)
                if cursor_info is not None:
                    logger.debug(
                        "Overriding context window: %s/%s -> %s/%s (cursor)",
                        context.window_id, context.window_class,
                        self._pre_chord_window_id, cursor_info.wm_class,
                    )
                    context.window_id = self._pre_chord_window_id
                    context.window_title = cursor_info.title
                    context.window_class = cursor_info.wm_class
                    context.window_instance = cursor_info.wm_instance
                    context.window_pid = cursor_info.pid
                else:
                    logger.debug(
                        "Overriding context window_id: %s -> %s (cursor, metadata unavailable)",
                        context.window_id,
                        self._pre_chord_window_id,
                    )
                    context.window_id = self._pre_chord_window_id
            if context.window_title:
                logger.info(
                    "  Window: %s (%s)", context.window_title, context.window_class
                )
            if context.screenshot_png:
                logger.info(
                    "  Screenshot: %dx%d, %s bytes",
                    context.screenshot_width,
                    context.screenshot_height,
                    f"{len(context.screenshot_png):,}",
                )
            if self._cache is not None:
                self._cache.save_context(context)
            if self._feedback is not None:
                self._feedback.capture_recording_context(context)

            # Debug: Window info
            self._debug("Window", (
                f"Title:    {context.window_title or '—'}\n"
                f"Class:    {context.window_class or '—'}\n"
                f"Instance: {context.window_instance or '—'}\n"
                f"PID:      {context.window_pid or '—'}\n"
                f"ID:       {context.window_id or '—'}"
            ))
            # Debug: Widget info
            self._debug("Widget", (
                f"Focused:  {context.widget_role or '—'} / {context.widget_name or '—'}\n"
                f"Cursor:   {context.cursor_widget_role or '—'} / {context.cursor_widget_name or '—'}\n"
                f"Caret:    {context.caret_offset if context.caret_offset is not None else '—'}"
            ))
            # Debug: Screenshot info
            if context.screenshot_png:
                method = "grim (full screen)" if os.environ.get("WAYLAND_DISPLAY") else "scrot -u (focused window)"
                self._debug("Screenshot", (
                    f"Size:     {context.screenshot_width}x{context.screenshot_height}\n"
                    f"Bytes:    {len(context.screenshot_png):,}\n"
                    f"Method:   {method}"
                ))
            # Debug: Terminal info
            if context.terminal_info is not None:
                ti = context.terminal_info
                self._debug("Terminal", (
                    f"Mux:      {getattr(ti, 'multiplexer', None) or '—'}\n"
                    f"TUI:      {', '.join(f'{name} ({typ})' for name, typ in (getattr(ti, 'tui_apps', None) or [])) or '—'}\n"
                    f"SSH:      {'yes' if getattr(ti, 'has_ssh', False) else 'no'}\n"
                    f"Pane:     {getattr(ti, 'active_pane_command', None) or '—'}"
                ))
            # Debug: Visible text from AT-SPI
            text_lines = []
            if context.text_around_caret:
                text_lines.append(f"Near caret (±250ch):\n{context.text_around_caret[:500]}")
            elif context.text_content:
                text_lines.append(f"Visible ({len(context.text_content)} ch):\n{context.text_content[-500:]}")
            else:
                text_lines.append("(no text captured)")
            self._debug("Text", "\n".join(text_lines))

        # STT
        self._tooltip_status("\U0001f3a4 Transcribing...")
        t0 = time.perf_counter()
        try:
            _keyterms = self._correction_learner.get_keyterms() if self._correction_learner else None
            if _spec_results and not _tail_wav:
                # Speculative calls covered everything; synthesise result
                result = STTResult(
                    text=" ".join(_spec_results),
                    source="gpu_server_speculative",
                    chain_position=0,
                    chain_length=len(self._stt_client._chain),
                )
            elif _spec_results and _tail_wav:
                # Transcribe only the tail, use speculative text as context
                _initial_prompt = " ".join(_spec_results)
                result = await self._stt_client.transcribe(
                    _tail_wav,
                    keyterms=_keyterms,
                    on_partial=self._on_partial_transcript,
                    initial_prompt=_initial_prompt,
                )
                result.text = " ".join(_spec_results + [result.text])
            else:
                # No speculative data — full transcription with streaming feedback
                result = await self._stt_client.transcribe(
                    wav_bytes,
                    keyterms=_keyterms,
                    on_partial=self._on_partial_transcript,
                )
        except RuntimeError as exc:
            telemetry.add_stage("stt", (time.perf_counter() - t0) * 1000, ok=False)
            telemetry.outcome = "stt_error"
            telemetry.total_ms = (time.perf_counter() - t_start) * 1000
            telemetry.emit()
            if self._cache is not None:
                self._cache.save_error("stt", str(exc))
                self._cache.save_telemetry(telemetry)
            if self._feedback is not None:
                self._feedback.set_outcome("stt_error")
                self._feedback.set_total_ms(telemetry.total_ms)
                self._save_event_log()
                self._save_feedback_now()
            if self._indicator is not None:
                self._indicator.set_status("error")
            self._hide_early_tooltip()
            self._track(self._handle_stt_failure_notification())
            raise
        telemetry.add_stage("stt", (time.perf_counter() - t0) * 1000, detail=result.source)
        telemetry.stt_provider = result.source
        telemetry.stt_chain_position = result.chain_position
        telemetry.stt_chain_length = result.chain_length
        telemetry.stt_failures = result.failures
        stt_ms = (time.perf_counter() - t0) * 1000
        logger.info("[%s] %d chars", result.source, len(result.text))
        logger.debug("[%s] text: %s", result.source, result.text)
        if self._cache is not None:
            self._cache.save_stt(result)
        if self._feedback is not None:
            self._feedback.capture_stt(result, stt_ms)

        # Debug: STT info
        self._debug("STT", (
            f"Provider: {result.source}\n"
            f"Chain:    {result.chain_position}/{result.chain_length}\n"
            f"Text:     {result.text[:120]}{'...' if len(result.text) > 120 else ''}"
        ))

        # Apply learned corrections (dict lookup, <1ms)
        if self._correction_learner is not None:
            corrected = self._correction_learner.apply_corrections(result.text)
            if corrected != result.text:
                logger.debug("Applied corrections: %r -> %r", result.text, corrected)
                result = type(result)(
                    text=corrected,
                    source=result.source,
                    chain_position=result.chain_position,
                    chain_length=result.chain_length,
                    failures=result.failures,
                )

        # Always rewrite — no conditional skip
        self._tooltip_status("\u270d Rewriting...")
        all_windows = self._get_all_windows()
        rewrite = None
        t0 = time.perf_counter()

        if self._smart_rewriter is not None:
            rewrite = await self._smart_rewriter.rewrite(result.text, context, all_windows)

        text_to_paste = result.text
        if rewrite is not None:
            rewrite_ms = (time.perf_counter() - t0) * 1000
            telemetry.add_stage("rewrite", rewrite_ms, detail=rewrite.source)
            telemetry.rewrite_source = rewrite.source
            telemetry.rewrite_provider = rewrite.provider
            logger.info(
                "[rewrite:%s/%s] %d chars",
                rewrite.source, rewrite.provider or "?", len(rewrite.text),
            )
            logger.debug(
                "[rewrite:%s/%s] text: %s",
                rewrite.source, rewrite.provider or "?", rewrite.text,
            )
            text_to_paste = rewrite.text
            if self._cache is not None:
                self._cache.save_rewrite(rewrite)
            if self._feedback is not None:
                self._feedback.capture_rewrite(rewrite, rewrite_ms)
        else:
            telemetry.add_stage("rewrite", 0.0, detail="no_rewriter")
            telemetry.rewrite_source = "no_rewriter"

        # Debug: Rewrite info
        self._debug("Rewrite", (
            f"Source:   {telemetry.rewrite_source}\n"
            f"Provider: {rewrite.provider if rewrite else '—'}\n"
            f"Format:   {getattr(rewrite, 'format', '—') if rewrite else '—'}\n"
            f"Text:     {text_to_paste[:120]}{'...' if len(text_to_paste) > 120 else ''}"
        ))

        # Debug: Context sent to LLM
        if self._smart_rewriter is not None and hasattr(self._smart_rewriter, '_context_packer'):
            packer = self._smart_rewriter._context_packer
            try:
                ctx_list = [context] if context else []
                packed = packer.build_dynamic(ctx_list)
                internal = packer.build_internal_context(ctx_list)
                prompt_text = ""
                if packed:
                    prompt_text += f"Dynamic:\n{packed[:300]}\n"
                if internal:
                    prompt_text += f"Internal:\n{internal[:300]}"
                self._debug("Prompt", prompt_text or "(empty)")
            except Exception:
                pass

        # Paste Decision Engine: compare original context vs current
        current_ctx = None
        if self._indicator is not None and hasattr(self._indicator, 'last_focused_context'):
            current_ctx = self._indicator.last_focused_context

        decision = self._paste_decider.decide(context, current_ctx)
        logger.info("[paste_decision] %s: %s", decision.action, decision.reason)
        telemetry.paste_decision_action = decision.action
        telemetry.paste_decision_reason = decision.reason
        if self._feedback is not None:
            self._feedback.set_paste_decision(decision.action, decision.reason)

        # Debug: Decision info
        self._debug("Decision", (
            f"Action:   {decision.action}\n"
            f"Reason:   {decision.reason}"
        ))

        # Route: tooltip with options vs auto-paste
        use_tooltip = (
            self._indicator is not None
            and hasattr(self._indicator, 'show_tooltip')
            and self._settings.tooltip.enabled
        )
        use_notifications = self._settings.tooltip.use_notifications

        # --- Notification path: offer_both ---
        if decision.action == "offer_both" and use_notifications:
            self._hide_early_tooltip()  # dismiss recording dot before notification
            # Store pending data for edit panel
            self._pending_transcription = result.text
            self._pending_rewrites = [(text_to_paste, context)]
            self._pending_context = context

            # Eager rewrite for new context
            if self._smart_rewriter is not None and current_ctx is not None:
                new_rewrite = await self._smart_rewriter.rewrite(
                    result.text, current_ctx, all_windows,
                )
                self._pending_rewrites.insert(0, (new_rewrite.text, current_ctx))
            if rewrite is not None and rewrite.text != result.text:
                self._pending_rewrites.append((result.text, None))

            # Show notification with actions
            preview = text_to_paste[:80] + ("..." if len(text_to_paste) > 80 else "")
            from talk_to_tux.pipeline.notify import notify
            action = await notify(
                "Rewrite ready",
                preview,
                timeout_ms=int(self._settings.tooltip.timeout_s * 1000),
                actions={"paste": "Paste", "edit": "Edit", "discard": "Discard"},
            )

            _notif_arm_wid = None
            if action == "paste":
                # Refocus target window and paste the best option
                best_text, best_ctx = self._pending_rewrites[0]
                # Event: pre_paste (awaited)
                pre_entry = self._add_event("pre_paste")
                if pre_entry is not None and self._context_capturer is not None:
                    await self._capture_event_screenshot(pre_entry)
                t0_paste = time.perf_counter()
                await self._do_paste(best_text, best_ctx)
                _notif_arm_wid = getattr(best_ctx, 'window_id', None)
                pc_entry = self._add_event("paste_complete")
                if pc_entry is not None and self._context_capturer is not None:
                    self._track(self._capture_event_screenshot(pc_entry))
                if self._feedback is not None:
                    paste_ms = (time.perf_counter() - t0_paste) * 1000
                    self._feedback.capture_paste(best_text, best_ctx, paste_ms, success=True)
                    self._feedback.set_user_action("notification_paste")
                    self._flush_indicator_event_screenshots()
                    self._save_event_log()
                    self._save_feedback_now()
                self._schedule_post_paste_screenshots()
            elif action == "edit":
                self._last_auto_paste_text = self._pending_rewrites[0][0]
                self._last_auto_paste_context = self._pending_rewrites[0][1] or context
                # Show post-paste tooltip directly in edit mode
                if self._indicator is not None and hasattr(self._indicator, 'show_post_paste_tooltip'):
                    label = getattr(self._last_auto_paste_context, 'window_class', '') or ''
                    self._indicator.show_post_paste_tooltip(
                        self._pending_rewrites[0][0], label,
                        edit_immediately=True,
                    )
                    # Auto-dismiss timeout
                    timeout = self._settings.tooltip.post_paste_timeout_s
                    try:
                        loop = asyncio.get_running_loop()
                        self._post_paste_tooltip_handle = loop.call_later(
                            timeout, self._dismiss_post_paste_tooltip,
                        )
                    except RuntimeError:
                        pass
                # Stay IDLE — tooltip doesn't require TOOLTIP_SHOWN state
                telemetry.outcome = "ok"
                telemetry.total_ms = (time.perf_counter() - t_start) * 1000
                telemetry.emit()
                if self._feedback is not None:
                    self._feedback.set_user_action("notification_edit")
                    self._copy_telemetry_to_feedback(telemetry)
                    self._flush_indicator_event_screenshots()
                    self._save_event_log()
                    self._save_feedback_now()
                if self._cache is not None:
                    self._cache.save_telemetry(telemetry)
                    self._cache.save_done()
                if self._indicator is not None:
                    self._indicator.set_status("idle")
                self._state = PipelineState.IDLE
                return
            else:
                # Discard / timeout — copy to clipboard only
                if self._paster is not None:
                    try:
                        best_text = self._pending_rewrites[0][0]
                        await self._paster._set_clipboard(best_text)
                    except Exception:
                        logger.debug("Clipboard copy on notification dismiss failed", exc_info=True)
                if self._feedback is not None:
                    self._feedback.set_user_action("notification_dismiss")

            telemetry.outcome = "ok"
            telemetry.total_ms = (time.perf_counter() - t_start) * 1000
            telemetry.emit()
            if self._feedback is not None:
                self._copy_telemetry_to_feedback(telemetry)
                self._flush_indicator_event_screenshots()
                self._save_event_log()
                self._save_feedback_now()
            if self._cache is not None:
                self._cache.save_telemetry(telemetry)
                self._cache.save_done()
            if self._indicator is not None:
                self._indicator.set_status("idle")
            self._state = PipelineState.IDLE
            if _notif_arm_wid is not None:
                await self._arm_double_tap(_notif_arm_wid)
                self._start_enter_watcher()
            return

        if decision.action == "offer_both" and use_tooltip:
            # Context changed — offer rewrite for both original and new context
            self._pending_transcription = result.text
            self._pending_rewrites = [(text_to_paste, context)]

            # Eager rewrite for new context (KV cache hit on Layers 1-3)
            if self._smart_rewriter is not None and current_ctx is not None:
                new_rewrite = await self._smart_rewriter.rewrite(
                    result.text, current_ctx, all_windows,
                )
                self._pending_rewrites.insert(0, (new_rewrite.text, current_ctx))

            # Add plain transcript fallback if rewrite differs
            if rewrite is not None and rewrite.text != result.text:
                self._pending_rewrites.append((result.text, None))

            self._pending_context = context
            # Show tooltip with first option
            first_text, first_ctx = self._pending_rewrites[0]
            label = ""
            if first_ctx is not None and hasattr(first_ctx, 'window_class'):
                label = first_ctx.window_class or ""
            self._indicator.show_tooltip(first_text, label)

            # Add remaining options
            for opt_text, opt_ctx in self._pending_rewrites[1:]:
                opt_label = ""
                if opt_ctx is not None and hasattr(opt_ctx, 'window_class'):
                    opt_label = opt_ctx.window_class or ""
                elif opt_ctx is None:
                    opt_label = "Plain transcript"
                if hasattr(self._indicator, 'update_tooltip'):
                    self._indicator.update_tooltip(opt_text, opt_label)

            self._setup_tooltip_state()

            telemetry.outcome = "ok"
            telemetry.total_ms = (time.perf_counter() - t_start) * 1000
            telemetry.emit()
            if self._feedback is not None:
                for txt, _ in self._pending_rewrites:
                    self._feedback.add_rewrite_option(txt)
                self._copy_telemetry_to_feedback(telemetry)
                # Save event log (tooltip path — will be updated again after confirm/dismiss)
                self._flush_indicator_event_screenshots()
                self._save_event_log()
                self._save_feedback_now()
            if self._cache is not None:
                self._cache.save_telemetry(telemetry)
                self._cache.save_done()
            return

        if decision.action == "auto_paste":
            # Same context — paste immediately (no tooltip needed)
            pass  # fall through to auto-paste below

        # No indicator or tooltip disabled or auto_paste — auto-paste
        self._hide_early_tooltip()  # dismiss recording/processing tooltip

        # Event: pre_paste (awaited — must complete before paste)
        pre_entry = self._add_event("pre_paste")
        if pre_entry is not None and self._context_capturer is not None:
            await self._capture_event_screenshot(pre_entry)

        t0_paste = time.perf_counter()
        await self._do_paste(text_to_paste, context, telemetry)
        _auto_arm_wid = getattr(context, 'window_id', None)

        # Event: paste_complete (async)
        pc_entry = self._add_event("paste_complete")
        if pc_entry is not None and self._context_capturer is not None:
            self._track(self._capture_event_screenshot(pc_entry))
        if self._feedback is not None:
            paste_ms = (time.perf_counter() - t0_paste) * 1000
            self._feedback.capture_paste(
                text_to_paste, context, paste_ms,
                success=True,  # _do_paste logs failure but doesn't propagate
            )
            self._feedback.set_user_action("auto_paste")
            if self._indicator is not None:
                self._feedback.capture_post_paste_immediate(
                    self._indicator.last_focused_context
                )

        # Post-paste feedback: notification or tooltip
        if use_notifications and self._settings.tooltip.enabled:
            # Notification path: fire-and-forget Toast with Edit action
            self._last_auto_paste_text = text_to_paste
            self._last_auto_paste_context = context
            self._track(
                self._post_paste_notification(text_to_paste, context)
            )
        elif (
            self._settings.tooltip.enabled
            and self._indicator is not None
            and hasattr(self._indicator, 'show_post_paste_tooltip')
            and not use_notifications
        ):
            # Legacy tooltip path
            if self._post_paste_tooltip_handle is not None:
                self._post_paste_tooltip_handle.cancel()
                self._post_paste_tooltip_handle = None
            label = ""
            if context is not None and hasattr(context, 'window_class') and context.window_class:
                label = context.window_class
            self._indicator.show_post_paste_tooltip(text_to_paste, label)
            self._last_auto_paste_text = text_to_paste
            self._last_auto_paste_context = context
            timeout = self._settings.tooltip.post_paste_timeout_s
            logger.debug("Post-paste tooltip shown, auto-dismiss in %.1fs", timeout)
            try:
                loop = asyncio.get_running_loop()
                self._post_paste_tooltip_handle = loop.call_later(
                    timeout,
                    self._dismiss_post_paste_tooltip,
                )
            except RuntimeError:
                pass

        telemetry.outcome = "ok"
        telemetry.total_ms = (time.perf_counter() - t_start) * 1000
        telemetry.emit()
        if self._feedback is not None:
            self._copy_telemetry_to_feedback(telemetry)
        self._schedule_post_paste_screenshots()

        # Save event log (includes GTK events) and feedback immediately
        self._flush_indicator_event_screenshots()
        self._save_event_log()
        self._save_feedback_now()

        # Debug: Pipeline summary
        stage_lines = "\n".join(
            f"  {s.stage}: {s.duration_ms:.0f}ms" for s in telemetry.stages
        )
        self._debug("Pipeline", (
            f"Total:    {telemetry.total_ms:.0f}ms\n"
            f"Outcome:  {telemetry.outcome}\n"
            f"{stage_lines}"
        ))

        if self._cache is not None:
            self._cache.save_telemetry(telemetry)
            self._cache.save_done()

        if self._indicator is not None:
            self._indicator.set_status("idle")
        self._state = PipelineState.IDLE
        await self._arm_double_tap(_auto_arm_wid)
        self._start_enter_watcher()

    def _setup_tooltip_state(self) -> None:
        """Configure state for tooltip confirmation flow."""
        # Lower debounce for double-chord detection and suppress dismiss
        if hasattr(self._listener, 'set_debounce'):
            self._listener.set_debounce(0.08)
        if hasattr(self._listener, '_suppress_dismiss'):
            self._listener._suppress_dismiss = True
        self._state = PipelineState.TOOLTIP_SHOWN
        # Start escape key watcher
        self._escape_task = asyncio.create_task(self._watch_escape())
        # Auto-dismiss timeout
        try:
            loop = asyncio.get_running_loop()
            self._tooltip_timeout_handle = loop.call_later(
                self._settings.tooltip.timeout_s,
                lambda: asyncio.ensure_future(self.on_dismiss_tooltip()),
            )
        except RuntimeError:
            pass

    async def _do_paste(
        self, text: str, context: object | None, telemetry: PipelineTelemetry | None = None,
    ) -> None:
        """Execute the paste operation with optional telemetry."""
        if self._paster is not None:
            t0 = time.perf_counter()
            ok = await self._paster.paste(text, context)
            if telemetry is not None:
                telemetry.add_stage("paste", (time.perf_counter() - t0) * 1000, ok=ok)
            if ok:
                logger.info("Pasted %d chars", len(text))
            else:
                logger.warning("Paste failed")

    async def on_fire_edited_text(self, text: str) -> None:
        """Replace previously auto-pasted text with edited version."""
        if self._last_auto_paste_context is None:
            return
        # Cancel auto-dismiss
        if self._post_paste_tooltip_handle is not None:
            self._post_paste_tooltip_handle.cancel()
            self._post_paste_tooltip_handle = None
        # Hide edit panel and/or tooltip
        if self._indicator is not None:
            if hasattr(self._indicator, 'hide_edit_panel'):
                self._indicator.hide_edit_panel()
            self._indicator.hide_tooltip()
        await asyncio.sleep(0.15)  # let Mutter refocus

        ctx = self._last_auto_paste_context
        wid = getattr(ctx, 'window_id', None)

        # Undo the original paste, then paste the edited text
        # Skip undo for terminals — Ctrl+Z sends SIGTSTP (suspend), not undo
        if self._paster is not None:
            from talk_to_tux.paste.paster import is_terminal
            wc = getattr(ctx, 'window_class', None)
            if not is_terminal(wc):
                await self._paster.send_undo(window_id=wid)
                await asyncio.sleep(0.05)
            await self._paster.paste(text, ctx)
            await self._arm_double_tap(getattr(ctx, 'window_id', None))
            self._start_enter_watcher()

        # Feedback: post-paste edit
        if self._feedback is not None:
            self._feedback.set_user_action("post_paste_edit")
            self._flush_indicator_event_screenshots()
            self._save_event_log()
            self._save_feedback_now()
        self._schedule_post_paste_screenshots()

        self._last_auto_paste_text = None
        self._last_auto_paste_context = None

    async def _post_paste_notification(self, text: str, context: object | None) -> None:
        """Show a post-paste notification with Edit action (fire-and-forget)."""
        from talk_to_tux.pipeline.notify import notify
        preview = text[:80] + ("..." if len(text) > 80 else "")
        timeout_ms = int(self._settings.tooltip.post_paste_timeout_s * 1000)
        action = await notify(
            "Pasted",
            preview,
            timeout_ms=timeout_ms,
            actions={"edit": "Edit"},
        )
        if action == "edit" and self._last_auto_paste_context is not None:
            # Show post-paste tooltip directly in edit mode (works on Wayland)
            if self._indicator is not None and hasattr(self._indicator, 'show_post_paste_tooltip'):
                label = getattr(self._last_auto_paste_context, 'window_class', '') or ''
                self._indicator.show_post_paste_tooltip(
                    self._last_auto_paste_text or text, label,
                    edit_immediately=True,
                )
                # Auto-dismiss timeout
                timeout = self._settings.tooltip.post_paste_timeout_s
                try:
                    loop = asyncio.get_running_loop()
                    self._post_paste_tooltip_handle = loop.call_later(
                        timeout, self._dismiss_post_paste_tooltip,
                    )
                except RuntimeError:
                    pass

    def _open_edit_panel(self, text: str, context: object | None) -> None:
        """Open the edit panel with the given text and context."""
        self._last_auto_paste_text = text
        self._last_auto_paste_context = context
        if self._indicator is not None and hasattr(self._indicator, 'show_edit_panel'):
            try:
                target_label = getattr(context, 'window_class', None) or ""
                self._indicator.show_edit_panel(
                    text=text,
                    target_label=target_label,
                    on_fire=self._on_edit_panel_fire,
                    on_cancel=self._on_edit_panel_cancel,
                )
                self._state = PipelineState.TOOLTIP_SHOWN
            except Exception:
                logger.warning("Edit panel failed to open, resetting to IDLE", exc_info=True)
                self._state = PipelineState.IDLE
                if self._indicator is not None:
                    self._indicator.set_status("idle")
        else:
            # No indicator — stay IDLE
            self._state = PipelineState.IDLE

    def _on_edit_panel_fire(self, text: str) -> None:
        """Called from GTK thread when Fire is clicked in the edit panel."""
        if self._indicator is not None and hasattr(self._indicator, '_loop'):
            loop = self._indicator._loop
        else:
            return
        future = asyncio.run_coroutine_threadsafe(
            self.on_fire_edited_text(text), loop
        )
        future.add_done_callback(
            lambda f: logger.debug("Edit panel fire error: %s", f.exception()) if f.exception() else None
        )

    def _on_edit_panel_cancel(self) -> None:
        """Called from GTK thread when Cancel is clicked in the edit panel."""
        if self._indicator is not None and hasattr(self._indicator, '_loop'):
            loop = self._indicator._loop
        else:
            return
        future = asyncio.run_coroutine_threadsafe(
            self._on_edit_panel_cancel_async(), loop
        )
        future.add_done_callback(
            lambda f: logger.debug("Edit panel cancel error: %s", f.exception()) if f.exception() else None
        )

    async def _on_edit_panel_cancel_async(self) -> None:
        """Handle edit panel cancellation on asyncio thread."""
        self._last_auto_paste_text = None
        self._last_auto_paste_context = None
        self._state = PipelineState.IDLE
        if self._indicator is not None:
            self._indicator.set_status("idle")
        if self._feedback is not None:
            self._feedback.set_user_action("edit_cancel")
            self._flush_indicator_event_screenshots()
            self._save_event_log()
            self._save_feedback_now()

    def _dismiss_post_paste_tooltip(self) -> None:
        """Dismiss the post-paste tooltip (auto-dismiss or manual)."""
        logger.debug("Auto-dismissing post-paste tooltip")
        if self._indicator is not None:
            self._indicator.hide_tooltip()
        self._last_auto_paste_text = None
        self._last_auto_paste_context = None
        self._post_paste_tooltip_handle = None

    def on_cancel_post_paste_timeout(self) -> None:
        """Cancel the post-paste auto-dismiss timer (called when user starts editing)."""
        if self._post_paste_tooltip_handle is not None:
            self._post_paste_tooltip_handle.cancel()
            self._post_paste_tooltip_handle = None

    def _on_recorder_auto_stop(self) -> None:
        """Called from audio thread when hard cap elapses; hops to asyncio loop."""
        asyncio.run_coroutine_threadsafe(self.on_record_stop(), self._loop)

    async def _handle_hosted_error_notification(self, exc: object) -> None:
        """Show a notification for a hosted-mode error."""
        from talk_to_tux.auth import (
            AuthFailed,
            HostedError,
            QuotaExhausted,
            RecordingTooLong,
            TierLocked,
            TokenInvalid,
        )

        if isinstance(exc, RecordingTooLong):
            title = "Recording Too Long"
            body = (
                "Recording auto-stopped at 10 min. "
                "Speak in shorter sessions or upgrade for longer recordings."
            )
        elif isinstance(exc, QuotaExhausted):
            title = "Quota Exhausted"
            if exc.reset_at is not None:
                from datetime import datetime, timezone
                days = max(0, (exc.reset_at - datetime.now(timezone.utc)).days)
                body = f"You're over the free limit — your quota resets in {days} day(s)."
            else:
                days = 30
                body = "You're over the free limit — your quota resets soon."
            if self._indicator is not None:
                from talk_to_tux.hosted.urls import UPGRADE_URL
                self._indicator.show_quota_exhausted_toast(
                    resets_in_days=days,
                    upgrade_url=UPGRADE_URL,
                )
                return
        elif isinstance(exc, TierLocked):
            title = "Account Locked"
            body = "Your hosted account is locked — contact support."
        elif isinstance(exc, TokenInvalid):
            title = "Session Expired"
            body = "Your session expired — run `talk-to-tux login` to reconnect."
        elif isinstance(exc, AuthFailed) and getattr(exc, "reason", None) == "no_tokens":
            title = "Sign-In Required"
            body = "Hosted mode requires sign-in — run `talk-to-tux login`."
        elif isinstance(exc, HostedError):
            title = "Hosted Service Error"
            reason = str(exc) or "unknown"
            body = f"Hosted service error: {reason}."
        else:
            title = "Hosted Error"
            body = str(exc)

        try:
            import subprocess as _subprocess
            _subprocess.run(
                ["notify-send", "--urgency=normal", title, body],
                timeout=5,
                check=False,
            )
        except Exception:
            logger.warning("notify-send failed for hosted error: %s", exc)

    async def _handle_stt_failure_notification(self) -> None:
        """Show interactive notification for STT failure; handle user action."""
        from talk_to_tux.pipeline.notify import notify

        actions = {"retry": "Retry"}
        if self._indicator is not None:
            actions["dashboard"] = "View History"
        action = await notify(
            "STT Failed",
            "All providers failed.",
            urgency="normal",
            timeout_ms=10000,
            actions=actions,
        )
        if action == "retry":
            await self.retry_from_cache()
        elif action == "dashboard" and self._indicator is not None:
            self._indicator.open_dashboard()

    async def retry_from_cache(self, run_id: str | None = None) -> None:
        """Replay from a cached run, resuming from the last successful stage."""
        if self._cache is None:
            logger.error("Cache is disabled, cannot retry")
            return
        run_dir = self._cache.load_run(run_id)
        if run_dir is None:
            logger.error("No cached run found")
            return

        status = self._cache.load_status()
        stage = status.get("stage", "") if status else ""
        logger.info("Retrying from cache: %s (stage: %s)", run_dir.name, stage)

        context = self._cache.load_context()

        if stage in ("started", "stt"):
            # Need to re-run STT from cached audio
            wav_bytes = self._cache.load_audio()
            if wav_bytes is None:
                logger.error("No cached audio found")
                return
            _keyterms = self._correction_learner.get_keyterms() if self._correction_learner else None
            result = await self._stt_client.transcribe(wav_bytes, keyterms=_keyterms)
            logger.info("[%s] %d chars", result.source, len(result.text))
            logger.debug("[%s] text: %s", result.source, result.text)
            self._cache.save_stt(result)
        else:
            result = self._cache.load_stt()
            if result is None:
                logger.error("No cached STT result found")
                return

        if stage in ("started", "stt", "rewrite"):
            text_to_paste = result.text
            if self._smart_rewriter is not None:
                rewrite = await self._smart_rewriter.rewrite(result.text, context)
                logger.info(
                    "[rewrite:%s/%s] %d chars",
                    rewrite.source, rewrite.provider or "?", len(rewrite.text),
                )
                logger.debug(
                    "[rewrite:%s/%s] text: %s",
                    rewrite.source, rewrite.provider or "?", rewrite.text,
                )
                text_to_paste = rewrite.text
                self._cache.save_rewrite(rewrite)
        else:
            rewrite = self._cache.load_rewrite()
            text_to_paste = rewrite.text if rewrite else result.text

        if self._paster is not None:
            ok = await self._paster.paste(text_to_paste, context)
            if ok:
                logger.info("Pasted %d chars", len(text_to_paste))
            else:
                logger.warning("Paste failed")

        self._cache.save_done()

    async def run(self) -> None:
        stop_event = asyncio.Event()
        loop = asyncio.get_running_loop()

        # Recover any volumes left ducked by a prior crash
        if self._settings.ducking.enabled:
            from talk_to_tux.audio.ducking import recover_ducked_volumes
            await loop.run_in_executor(None, recover_ducked_volumes)

        # Clear any stale recording overlay from a prior crash
        from talk_to_tux.indicator.recording_dot import cleanup_stale_overlay
        cleanup_stale_overlay()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, stop_event.set)

        hotkey = self._settings.trigger.keyboard.hotkey
        trigger_desc = "Hold " + hotkey
        if isinstance(self._listener, SideButtonListener):
            trigger_desc = "Side button (hold to record)"
        elif isinstance(self._listener, MouseChordListener):
            trigger_desc = "L+R mouse chord"
        elif isinstance(self._listener, KeyboardChordListener):
            trigger_desc = "Ctrl+Super chord"
        logger.info("Talk-to-Tux ready. %s to speak. Ctrl+C to quit.", trigger_desc)

        health = await self._stt_client.health_check()
        if health:
            logger.info("GPU STT server: connected")
        else:
            fallbacks = [n for n, _ in self._stt_client._chain if n != "gpu_server"]
            if fallbacks:
                logger.info(
                    "GPU STT server: unreachable (fallbacks: %s)",
                    ", ".join(fallbacks),
                )
            else:
                logger.info("GPU STT server: unreachable (no fallbacks configured)")

        rewrite_status = "enabled" if self._smart_rewriter is not None else "disabled"
        logger.info("Rewrite engine: %s", rewrite_status)

        if self._paster is not None:
            tools = await self._paster.check_tools()
            missing = [t for t, ok in tools.items() if not ok]
            if missing:
                is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))
                if is_wayland and "ydotool" in missing:
                    logger.warning(
                        "Paste tools missing: %s — on GNOME Wayland, install ydotool: "
                        "sudo apt install ydotool",
                        ", ".join(missing),
                    )
                else:
                    logger.warning("Paste tools missing: %s", ", ".join(missing))
            else:
                logger.info("Paste integration: ready")

        # Start the audio stream watchdog (recovers from stale PortAudio
        # streams after PipeWire suspend/profile-change events).
        self._audio_watchdog_task = asyncio.create_task(self._audio_watchdog())

        await self._listener.start()
        await stop_event.wait()
        await self.shutdown()

    async def _audio_watchdog(self) -> None:
        """Periodically check the audio stream is alive; recreate if stale."""
        try:
            while True:
                await asyncio.sleep(10)
                if self._recorder.is_recording():
                    continue
                if not self._recorder.is_stream_healthy():
                    logger.warning("Audio watchdog: stream stale, recreating")
                    try:
                        self._recorder.recreate_stream()
                    except Exception:
                        logger.error(
                            "Audio watchdog: recreate failed", exc_info=True,
                        )
        except asyncio.CancelledError:
            pass

    # --- Post-paste settled event ---

    def _schedule_post_paste_screenshots(self) -> None:
        """Schedule the settled event (3s after paste)."""
        # Cancel any pending tasks from a previous paste
        for t in self._post_paste_screenshot_tasks:
            t.cancel()
        self._post_paste_screenshot_tasks.clear()

        async def _settled_and_save() -> None:
            try:
                await asyncio.sleep(3.0)
            except asyncio.CancelledError:
                return
            # Capture delayed post-paste context (3s after paste)
            if self._feedback is not None and self._indicator is not None:
                self._feedback.capture_post_paste_delayed(
                    self._indicator.last_focused_context
                )
            # Flush any GTK events that fired after the initial save
            # (e.g., post_paste_tooltip which fires via GLib.idle_add)
            self._flush_indicator_event_screenshots()
            # Add settled event screenshot
            settled_entry = self._add_event("settled")
            if settled_entry is not None and self._context_capturer is not None:
                await self._capture_event_screenshot(settled_entry)
            # Save updated event log + feedback
            self._save_event_log()
            if self._feedback is not None and self._cache is not None:
                self._cache.save_feedback(self._feedback)

        self._post_paste_screenshot_tasks.append(self._track(_settled_and_save()))

    def _save_feedback_now(self) -> None:
        """Save feedback immediately (for early exits like no_audio, stt_error)."""
        if self._feedback is not None and self._cache is not None:
            self._cache.save_feedback(self._feedback)

    def _copy_telemetry_to_feedback(self, telemetry: PipelineTelemetry) -> None:
        """Copy telemetry data to feedback collector."""
        if self._feedback is None:
            return
        self._feedback.set_outcome(telemetry.outcome)
        if telemetry.total_ms is not None:
            self._feedback.set_total_ms(telemetry.total_ms)
        self._feedback.audio_duration_ms = telemetry.audio_duration_ms
        for s in telemetry.stages:
            self._feedback.add_stage(s.stage, s.duration_ms, s.ok, s.detail)

    async def _maybe_auto_analyze(self) -> None:
        """Check unreviewed count and trigger background BAML analysis if threshold met."""
        if self._cache is None or not self._cache._enabled:
            return
        try:
            threshold = self._settings.cache.analysis_threshold
            if threshold <= 0:
                return
            unreviewed = self._cache.list_unreviewed_runs()
            if len(unreviewed) >= threshold:
                logger.info("Auto-analyzing %d unreviewed feedback runs", len(unreviewed))
                self._analysis_task = asyncio.create_task(self._run_analysis(unreviewed))
        except Exception:
            logger.debug("Auto-analysis check failed", exc_info=True)

    async def _run_analysis(self, runs: list[Path]) -> None:
        """Background task: analyze unreviewed runs via BAML."""
        try:
            from talk_to_tux.pipeline.analysis import analyze_run
            for run_dir in runs:
                try:
                    await analyze_run(self._cache, run_dir, mark_reviewed=True)
                    logger.debug("Analyzed run %s", run_dir.name)
                except Exception:
                    logger.debug("Failed to analyze run %s", run_dir.name, exc_info=True)
        except Exception:
            logger.debug("Auto-analysis batch failed", exc_info=True)

    async def shutdown(self) -> None:
        # Stop enter watcher explicitly (also done by _disarm but be safe)
        self._stop_enter_watcher()
        # Disarm double-tap (cancels drift monitor, timeout, hold override)
        self._disarm_double_tap()
        # Cancel safety timer
        if self._max_record_handle is not None:
            self._max_record_handle.cancel()
            self._max_record_handle = None
        # Cancel silence monitor
        if self._silence_task is not None:
            self._silence_task.cancel()
            self._silence_task = None
        # Cancel audio watchdog
        if self._audio_watchdog_task is not None:
            self._audio_watchdog_task.cancel()
            self._audio_watchdog_task = None
        # Cancel pending analysis task
        if self._analysis_task is not None:
            self._analysis_task.cancel()
            self._analysis_task = None
        # Cancel pending processing task
        if self._processing_task is not None:
            self._processing_task.cancel()
            self._processing_task = None
        # Cancel pending validation task
        if self._validation_task is not None:
            self._validation_task.cancel()
            self._validation_task = None
        # Cancel pending post-paste screenshot tasks
        for t in self._post_paste_screenshot_tasks:
            t.cancel()
        self._post_paste_screenshot_tasks.clear()
        # Cancel any still-tracked fire-and-forget tasks
        for t in list(self._background_tasks):
            t.cancel()
        if self._context_task is not None:
            self._context_task.cancel()
            try:
                await self._context_task
            except (asyncio.CancelledError, Exception):
                pass
            self._context_task = None
        # Restore ducked audio (await — not fire-and-forget during shutdown)
        if self._ducker is not None:
            await self._ducker.restore()
        await self._listener.stop()
        await self._stt_client.close()
        if self._recorder is not None and hasattr(self._recorder, 'close'):
            self._recorder.close()
        if self._indicator is not None:
            self._indicator.stop()
        logger.info("Shut down.")


def _ensure_dbus_session() -> None:
    """Ensure DBUS_SESSION_BUS_ADDRESS is set for AT-SPI accessibility.

    On systemd-based Linux, the standard user session bus socket lives at
    /run/user/<uid>/bus.  When talk-to-tux is launched from a context that
    doesn't inherit the full desktop environment (e.g. SSH, cron, a bare
    terminal without proper session setup), this variable may be empty,
    causing AT-SPI to fatally abort the process.

    This function detects the missing variable and sets the standard path
    so that AT-SPI (and any other D-Bus client) can connect normally.
    """
    if os.environ.get("DBUS_SESSION_BUS_ADDRESS"):
        return  # already set

    bus_path = f"/run/user/{os.getuid()}/bus"
    if os.path.exists(bus_path):
        addr = f"unix:path={bus_path}"
        os.environ["DBUS_SESSION_BUS_ADDRESS"] = addr
        logger.info("Set DBUS_SESSION_BUS_ADDRESS=%s (was unset)", addr)
    else:
        logger.warning(
            "DBUS_SESSION_BUS_ADDRESS is unset and %s does not exist — "
            "AT-SPI accessibility features will be unavailable",
            bus_path,
        )


def _build_providers(settings: "Settings", token_store: object) -> tuple:
    """Return (stt_provider, rewriter) based on settings.api_mode."""
    from talk_to_tux.config import ApiMode

    if settings.api_mode == ApiMode.HOSTED:
        from talk_to_tux.stt.hosted import HostedSttProvider
        from talk_to_tux.pipeline.hosted_rewrite import HostedBamlRouter
        stt = HostedSttProvider(settings.hosted, token_store)
        rw = HostedBamlRouter(settings.hosted, token_store)
        return stt, rw

    # BYO_KEY path
    stt = STTClient(
        gpu_server_url=settings.stt.gpu_server.url,
        gpu_server_timeout=settings.stt.gpu_server.timeout,
        openai_api_key=settings.openai_api_key,
        openai_model=settings.stt.openai_model,
        groq_api_key=settings.groq_api_key,
        groq_model=settings.stt.groq_model,
        google_api_key=settings.google_api_key,
        elevenlabs_api_key=settings.elevenlabs_api_key,
        elevenlabs_model=settings.stt.elevenlabs_model,
        local_whisper_url=settings.stt.local_whisper.url,
        local_whisper_timeout=settings.stt.local_whisper.timeout,
        stt_providers=settings.stt.providers,
    )
    rw: SmartRewriter | None = None
    if settings.rewrite.enabled:
        from talk_to_tux.pipeline.context_packer import ContextPacker
        packer = ContextPacker(budget_tokens=settings.rewrite.context_budget_tokens)
        rw = SmartRewriter(
            enabled=True,
            app_rules=settings.apps or None,
            context_packer=packer,
            rewrite_config=settings.rewrite,
            screenshot_config=settings.screenshot,
        )
    return stt, rw


def main() -> None:
    # Prevent GTK from auto-initializing the AT-SPI bridge (app-side).
    # Talk-to-tux reads other apps' widgets via Atspi directly; it doesn't
    # need to publish its own widgets.  Without this, the bridge init can
    # fail and corrupt process state, causing a fatal g_error() abort.
    os.environ.setdefault("NO_AT_BRIDGE", "1")

    # Safety net: prevent fatal abort() if AT-SPI bus connection fails.
    # Must be set before any GLib/GTK/dbus initialization.
    os.environ.setdefault("DBUS_FATAL_WARNINGS", "0")

    args = parse_args()

    log_format = "%(message)s"
    log_level = logging.INFO
    if args.debug:
        log_format = "%(levelname)s %(name)s: %(message)s"
        log_level = logging.DEBUG
    logging.basicConfig(level=log_level, format=log_format)

    # Suppress noisy third-party loggers that dump raw tensor/audio data at DEBUG
    for noisy in ("torch", "silero_vad", "speechbrain", "urllib3", "matplotlib"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # Ensure D-Bus session bus is discoverable (for AT-SPI accessibility)
    _ensure_dbus_session()

    # Disable stdin echo — talk-to-tux uses evdev for input, so terminal stdin
    # just leaks raw escape codes (mouse tracking, keyboard protocol) otherwise.
    _old_termios = None
    try:
        fd = sys.stdin.fileno()
        _old_termios = termios.tcgetattr(fd)
        new = termios.tcgetattr(fd)
        new[3] &= ~termios.ECHO  # disable echo only
        termios.tcsetattr(fd, termios.TCSANOW, new)
    except (termios.error, OSError, ValueError):
        pass  # not a terminal (piped, etc.)

    from talk_to_tux.context.display import detect_and_fix_display

    display = detect_and_fix_display()
    if display:
        logger.info("Display: %s", display)
    else:
        logger.warning("No display detected — paste/screenshot/tooltip will be limited")

    settings = get_settings()
    settings = apply_overrides(settings, args)

    if args.show_config:
        print(show_config(settings))
        return

    if args.doctor:
        from talk_to_tux.doctor import run_doctor
        result = asyncio.run(run_doctor(settings))
        print(result)
        return

    if args.migrate_config:
        from talk_to_tux.setup_wizard import migrate_config
        migrate_config()
        return

    # Hunk 1 — hosted subcommand dispatch (early-exit before daemon startup)
    from talk_to_tux.cli_hosted import dispatch as _hosted_dispatch
    rc = _hosted_dispatch(args, settings)
    if rc is not None:
        sys.exit(rc)

    # Hunk 2 — first-run wizard detection (--setup flag or fresh install)
    from talk_to_tux.setup_wizard import SetupWizard, _needs_first_run
    if getattr(args, "setup", False) or _needs_first_run(settings):
        sys.exit(asyncio.run(SetupWizard().run()))

    from talk_to_tux.auth.token_store import KeyringTokenStore
    token_store = KeyringTokenStore()

    vad = VoiceActivityDetector(
        threshold=settings.vad.threshold,
        sample_rate=settings.audio.sample_rate,
    )

    # Bridge TTT_ env vars to BAML-expected names
    if settings.google_api_key:
        os.environ.setdefault("GOOGLE_API_KEY", settings.google_api_key)
    if settings.groq_api_key:
        os.environ.setdefault("GROQ_API_KEY", settings.groq_api_key)
    os.environ.setdefault("OLLAMA_BASE_URL", settings.rewrite.ollama_base_url)

    stt_client, smart_rewriter = _build_providers(settings, token_store)

    context_capturer: ContextCapturer | None = None
    if settings.context.screenshot_enabled:
        context_capturer = ContextCapturer(
            max_width=settings.context.screenshot_max_width,
            jpeg_quality=settings.context.screenshot_jpeg_quality,
        )

    paster: Paster | None = None
    if settings.paste.enabled:
        paster = Paster(
            app_rules=settings.apps or None,
            keystroke_tool=settings.paste.wayland_keystroke_tool,
        )

    cache: PipelineCache | None = None
    if settings.cache.enabled:
        cache = PipelineCache(
            enabled=True,
            max_age_hours=settings.cache.max_age_hours,
            max_runs=settings.cache.max_runs,
        )
        cache.evict()

    if args.retry is not None:
        async def _retry() -> None:
            app = App(
                settings=settings,
                listener=None,  # type: ignore[arg-type]
                recorder=None,  # type: ignore[arg-type]
                vad=None,  # type: ignore[arg-type]
                stt_client=stt_client,
                smart_rewriter=smart_rewriter,
                paster=paster,
                cache=cache,
                token_store=token_store,
            )
            await app.retry_from_cache(args.retry)
            if hasattr(stt_client, "close"):
                await stt_client.close()
        asyncio.run(_retry())
        return

    def _create_keyboard_listener(app: App) -> InputListener:
        """Create the appropriate keyboard listener based on hotkey config."""
        hotkey = settings.trigger.keyboard.hotkey
        if "+" in hotkey:
            # Chord-based: e.g. KEY_LEFTCTRL+KEY_LEFTMETA
            parts = hotkey.split("+", 1)
            from evdev import ecodes
            key_a = ecodes.ecodes.get(parts[0].strip())
            key_b = ecodes.ecodes.get(parts[1].strip())
            if key_a is None or key_b is None:
                raise ValueError(f"Unknown key name(s) in hotkey: {hotkey}")
            return KeyboardChordListener(
                on_start=app.on_record_start,
                on_stop=app.on_record_stop,
                mode=settings.trigger.record_mode,
                chord_timeout=settings.trigger.chord_timeout_ms / 1000,
                debounce=settings.trigger.chord_debounce_ms / 1000,
                device_path=settings.trigger.keyboard.device_path,
                key_a=key_a,
                key_b=key_b,
            )
        else:
            return HotkeyListener(
                key_name=hotkey,
                on_press=app.on_record_start,
                on_release=app.on_record_stop,
                device_path=settings.trigger.keyboard.device_path,
            )

    listener: InputListener = None  # type: ignore[assignment]

    async def _run() -> None:
        nonlocal listener
        if not _acquire_pidfile():
            sys.exit(1)
        from talk_to_tux.config import ApiMode
        from talk_to_tux.audio.recorder import HOSTED_RECORDER_HARD_CAP_S

        # Build app first (without recorder) so _on_recorder_auto_stop is available
        app = App(
            settings=settings,
            listener=None,  # type: ignore[arg-type] -- set below
            recorder=None,  # type: ignore[arg-type] -- set below
            vad=vad,
            stt_client=stt_client,
            context_capturer=context_capturer,
            smart_rewriter=smart_rewriter,
            paster=paster,
            cache=cache,
            token_store=token_store,
        )

        # Construct recorder after app so on_auto_stop can reference app method
        if settings.api_mode == ApiMode.HOSTED:
            recorder = AudioRecorder(
                sample_rate=settings.audio.sample_rate,
                channels=settings.audio.channels,
                device=settings.audio.input_device,
                hard_cap_s=HOSTED_RECORDER_HARD_CAP_S,
                on_auto_stop=app._on_recorder_auto_stop,
            )
        else:
            recorder = AudioRecorder(
                sample_rate=settings.audio.sample_rate,
                channels=settings.audio.channels,
                device=settings.audio.input_device,
            )
        app._recorder = recorder

        if settings.trigger.mode in ("auto", "mouse"):
            try:
                async def _on_side_button_disconnect() -> None:
                    logger.warning("Side-button mouse disconnected — waiting for reconnect")
                    if app._indicator is not None:
                        app._indicator.set_status("error")

                async def _on_side_button_reconnect() -> None:
                    logger.info("Side-button mouse reconnected")
                    if app._indicator is not None:
                        app._indicator.set_status("idle")

                listener = SideButtonListener(
                    on_start=app.on_record_start,
                    on_stop=app.on_record_stop,
                    device_path=settings.trigger.mouse.device_path,
                    device_name=settings.trigger.mouse.device_name,
                    button_codes=settings.trigger.mouse.button_codes,
                    grab=settings.trigger.mouse.grab,
                    on_disconnect=_on_side_button_disconnect,
                    on_reconnect=_on_side_button_reconnect,
                )
                logger.info(
                    "Trigger: Side buttons %s (grab=%s)",
                    settings.trigger.mouse.button_codes,
                    settings.trigger.mouse.grab,
                )
            except RuntimeError:
                if settings.trigger.mode == "mouse":
                    raise
                logger.info("No mouse with side button found, falling back to keyboard")
                try:
                    listener = _create_keyboard_listener(app)
                except RuntimeError:
                    logger.error("No input device found (mouse or keyboard)")
                    sys.exit(1)
        else:
            listener = _create_keyboard_listener(app)

        app._listener = listener

        # Start indicator (optional — gracefully degrades)
        if settings.indicator.enabled:
            try:
                from talk_to_tux.indicator import IndicatorController
                loop = asyncio.get_running_loop()
                indicator = IndicatorController(app=app, loop=loop, settings=settings)
                indicator.start()
                app._indicator = indicator
                logger.info("Panel indicator: active")
            except Exception:
                logger.debug("Panel indicator unavailable", exc_info=True)

        await app.run()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        pass
    except Exception:
        logger.exception("Fatal error")
        sys.exit(1)
    finally:
        _release_pidfile()
        # Restore terminal settings
        if _old_termios is not None:
            try:
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, _old_termios)
            except (termios.error, OSError, ValueError):
                pass
