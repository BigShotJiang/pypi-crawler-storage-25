/**
 * Talk-to-Tux — GNOME Shell extension for the Talk-to-Tux voice pipeline.
 *
 * Provides two D-Bus interfaces:
 *
 * 1. Recording overlay (cursor-following dot):
 *   Show("recording")   → red pulsing dot near cursor
 *   Show("processing")  → amber steady dot near cursor
 *   Keepalive()         → reset the crash-safety watchdog (call every 3s while recording)
 *   Hide()              → remove dot
 *
 * 2. Window context:
 *   GetFocusedWindow()  → JSON string with focused window metadata
 */

import St from 'gi://St';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const DBUS_IFACE = `<node>
  <interface name="org.gnome.shell.extensions.TalkToTux">
    <method name="Show">
      <arg type="s" direction="in" name="state"/>
    </method>
    <method name="Keepalive"/>
    <method name="Hide"/>
  </interface>
</node>`;

const WINDOW_DBUS_IFACE = `<node>
  <interface name="org.gnome.shell.extensions.TalkToTux.Window">
    <method name="GetFocusedWindow">
      <arg type="s" direction="out" name="window_json"/>
    </method>
  </interface>
</node>`;

const STYLES = {
    recording:  'background-color: #e53e3e; border-radius: 10px;'
              + 'box-shadow: 0 0 6px rgba(229,62,62,0.8);',
    processing: 'background-color: #f6ad55; border-radius: 10px;'
              + 'box-shadow: 0 0 6px rgba(246,173,85,0.8);',
};

// Crash-safety watchdog: if no Keepalive() arrives within this many seconds,
// the overlay is force-hidden.  The Python app sends Keepalive() every 3s, so
// a 6s window gives two missed beats before hiding.
const WATCHDOG_SECONDS = 6;

export default class TalkToTuxOverlay extends Extension {
    enable() {
        this._dot = null;
        this._followId = null;
        this._pulseId = null;
        this._autoHideId = null;
        this._pulseBright = true;

        // Read cursor size once; used to position the dot below the cursor so
        // it is never hidden under the cursor image (important for large cursors
        // such as 48px where +16,+16 lands inside the I-beam image).
        try {
            const ifaceSettings = new Gio.Settings({
                schema_id: 'org.gnome.desktop.interface',
            });
            this._cursorSize = ifaceSettings.get_int('cursor-size') || 24;
        } catch (_) {
            this._cursorSize = 24;
        }

        // Export overlay D-Bus interface
        this._dbusImpl = Gio.DBusExportedObject.wrapJSObject(DBUS_IFACE, this);
        this._dbusImpl.export(
            Gio.DBus.session,
            '/org/gnome/shell/extensions/TalkToTux',
        );

        // Export window context D-Bus interface
        this._windowDbusImpl = Gio.DBusExportedObject.wrapJSObject(
            WINDOW_DBUS_IFACE, this,
        );
        this._windowDbusImpl.export(
            Gio.DBus.session,
            '/org/gnome/shell/extensions/TalkToTux/Window',
        );

        this._ownerId = Gio.bus_own_name(
            Gio.BusType.SESSION,
            'org.gnome.shell.extensions.TalkToTux',
            Gio.BusNameOwnerFlags.NONE,
            null, null, null,
        );
    }

    disable() {
        this.Hide();
        if (this._ownerId) {
            Gio.bus_unown_name(this._ownerId);
            this._ownerId = null;
        }
        if (this._windowDbusImpl) {
            this._windowDbusImpl.unexport();
            this._windowDbusImpl = null;
        }
        if (this._dbusImpl) {
            this._dbusImpl.unexport();
            this._dbusImpl = null;
        }
    }

    Show(state) {
        this.Hide();

        const style = STYLES[state] || STYLES.processing;
        this._dot = new St.Widget({
            style: style,
            width: 16,
            height: 16,
            reactive: false,
            can_focus: false,
        });

        Main.uiGroup.add_child(this._dot);
        this._followCursor();

        // Cursor following at ~50ms (20 fps)
        this._followId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT, 50, () => {
                this._followCursor();
                return GLib.SOURCE_CONTINUE;
            },
        );

        // Crash-safety watchdog: hide if no Keepalive() within WATCHDOG_SECONDS.
        // The live app resets this via Keepalive() every 3s.
        this._armWatchdog();

        // Pulse for recording state
        if (state === 'recording') {
            this._pulseBright = true;
            this._pulseId = GLib.timeout_add(
                GLib.PRIORITY_DEFAULT, 750, () => {
                    this._pulseBright = !this._pulseBright;
                    if (this._dot)
                        this._dot.opacity = this._pulseBright ? 255 : 80;
                    return GLib.SOURCE_CONTINUE;
                },
            );
        }
    }

    Keepalive() {
        // Reset the crash-safety watchdog.  Called every 3s by the Python app.
        if (this._dot)
            this._armWatchdog();
    }

    Hide() {
        if (this._autoHideId) {
            GLib.source_remove(this._autoHideId);
            this._autoHideId = null;
        }
        if (this._followId) {
            GLib.source_remove(this._followId);
            this._followId = null;
        }
        if (this._pulseId) {
            GLib.source_remove(this._pulseId);
            this._pulseId = null;
        }
        if (this._dot) {
            Main.uiGroup.remove_child(this._dot);
            this._dot.destroy();
            this._dot = null;
        }
    }

    GetFocusedWindow() {
        const win = global.display.focus_window;
        if (!win)
            return '{}';
        const rect = win.get_frame_rect();
        return JSON.stringify({
            title: win.get_title() || '',
            wm_class: win.get_wm_class() || '',
            wm_class_instance: win.get_wm_class_instance() || '',
            pid: win.get_pid(),
            id: win.get_id(),
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
        });
    }

    _armWatchdog() {
        if (this._autoHideId) {
            GLib.source_remove(this._autoHideId);
            this._autoHideId = null;
        }
        this._autoHideId = GLib.timeout_add_seconds(
            GLib.PRIORITY_DEFAULT, WATCHDOG_SECONDS, () => {
                this.Hide();
                this._autoHideId = null;
                return GLib.SOURCE_REMOVE;
            },
        );
    }

    _followCursor() {
        if (!this._dot) return;
        const [x, y] = global.get_pointer();
        const dotSize = 16;
        const offsetX = 8;
        // Default: place below the cursor image.  cursorSize is the full image
        // height so the dot clears even large cursors (48px Adwaita, etc.).
        // When near the bottom of the monitor (common for text-input boxes at
        // the bottom of browser windows), flip above the cursor instead so the
        // dot never goes off-screen.
        let offsetY = this._cursorSize + 4;
        try {
            for (const mon of Main.layoutManager.monitors) {
                if (x >= mon.x && x < mon.x + mon.width &&
                    y >= mon.y && y < mon.y + mon.height) {
                    if (y + offsetY + dotSize > mon.y + mon.height)
                        offsetY = -(dotSize + 4);
                    break;
                }
            }
        } catch (_) {}
        this._dot.set_position(x + offsetX, y + offsetY);
    }
}
