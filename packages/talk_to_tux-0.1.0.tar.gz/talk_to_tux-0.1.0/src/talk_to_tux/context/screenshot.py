from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import tempfile
from io import BytesIO
from pathlib import Path
from urllib.parse import unquote, urlparse

from PIL import Image

logger = logging.getLogger(__name__)


class ScreenshotCapturer:
    """Captures and processes screenshots for LLM context."""

    def __init__(self, max_width: int = 1024, jpeg_quality: int = 85) -> None:
        self._max_width = max_width
        self._jpeg_quality = jpeg_quality
        self._failed_methods: set[str] = set()

    async def capture(self, window_id: str | None = None) -> tuple[bytes, int, int]:
        """Capture a screenshot and return (jpeg_bytes, width, height)."""
        path = await self._capture_screenshot(window_id=window_id)
        try:
            # Run PIL processing in executor — avoids blocking the event loop
            # and ensures PIL's C extensions don't overlap with GTK's gdk-pixbuf
            # (both link against libjpeg/libz).
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None, self._resize_and_compress, path
            )
        finally:
            path.unlink(missing_ok=True)

    async def capture_raw(self, window_id: str | None = None) -> Path:
        """Capture screenshot to temp file. Caller must unlink."""
        return await self._capture_screenshot(window_id=window_id)

    def crop_and_compress(
        self, path: Path, crop_rect: tuple[int, int, int, int] | None = None
    ) -> tuple[bytes, int, int]:
        """Open image, optionally crop to (x, y, w, h), resize, compress to JPEG."""
        img = Image.open(path)
        if crop_rect:
            x, y, w, h = crop_rect
            x2 = min(x + w, img.width)
            y2 = min(y + h, img.height)
            x, y = max(0, x), max(0, y)
            if x2 > x and y2 > y:
                img = img.crop((x, y, x2, y2))
        w, h = img.size
        if w > self._max_width:
            ratio = self._max_width / w
            img = img.resize((self._max_width, int(h * ratio)), Image.LANCZOS)
            w, h = img.size
        buf = BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=self._jpeg_quality)
        return buf.getvalue(), w, h

    async def _capture_screenshot(self, window_id: str | None = None) -> Path:
        """Dispatch to grim/portal (Wayland) or scrot (X11) based on display server.

        Failed methods are cached in ``_failed_methods`` so subsequent captures
        skip them immediately (avoids repeated 2s portal timeouts, etc.).
        """
        if os.environ.get("WAYLAND_DISPLAY"):
            if "grim" not in self._failed_methods:
                try:
                    return await self._capture_grim()
                except RuntimeError:
                    self._failed_methods.add("grim")
                    logger.info("grim failed on Wayland, trying xdg-desktop-portal")
            if "portal" not in self._failed_methods:
                try:
                    return await self._capture_portal()
                except RuntimeError:
                    self._failed_methods.add("portal")
                    logger.info("portal failed on Wayland, falling back to scrot")
            return await self._capture_scrot(window_id=window_id)
        return await self._capture_scrot(window_id=window_id)

    async def _capture_grim(self) -> Path:
        """Capture full screen via grim (Wayland)."""
        tmp = tempfile.mktemp(suffix=".png")
        proc = await asyncio.create_subprocess_exec(
            "grim", tmp,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        if proc.returncode == 0 and Path(tmp).exists():
            return Path(tmp)

        Path(tmp).unlink(missing_ok=True)
        raise RuntimeError("Screenshot capture failed: grim not available or failed")

    async def _capture_portal(self) -> Path:
        """Capture via xdg-desktop-portal Screenshot (Wayland).

        Uses the freedesktop Screenshot portal, which works on GNOME and KDE
        Wayland sessions. Starts a gdbus monitor to capture the async Response
        signal containing the screenshot file URI.
        """
        # Monitor for the async Response signal
        monitor = await asyncio.create_subprocess_exec(
            "gdbus", "monitor", "--session",
            "--dest", "org.freedesktop.portal.Desktop",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            await asyncio.sleep(0.05)  # let monitor subscribe

            proc = await asyncio.create_subprocess_exec(
                "gdbus", "call", "--session",
                "--dest", "org.freedesktop.portal.Desktop",
                "--object-path", "/org/freedesktop/portal/desktop",
                "--method", "org.freedesktop.portal.Screenshot.Screenshot",
                "", '{"interactive": <false>}',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=2)
            if proc.returncode != 0:
                raise RuntimeError(
                    f"Portal call failed: {stderr.decode().strip()}"
                )

            # Read monitor output until we find the file URI in the Response
            buf = b""
            try:
                while True:
                    chunk = await asyncio.wait_for(
                        monitor.stdout.read(4096), timeout=2
                    )
                    if not chunk:
                        break
                    buf += chunk
                    text = buf.decode(errors="replace")
                    m = re.search(r"'uri':\s*<'(file://[^']+)'>", text)
                    if m:
                        parsed = urlparse(m.group(1))
                        src = Path(unquote(parsed.path))
                        if not src.exists():
                            raise RuntimeError(
                                f"Portal screenshot not found: {src}"
                            )
                        # Copy to our temp (portal may save to user-visible dir)
                        tmp = tempfile.mktemp(suffix=".png")
                        shutil.copy2(str(src), tmp)
                        return Path(tmp)
            except asyncio.TimeoutError:
                pass

            raise RuntimeError("Portal screenshot: no URI in response")
        finally:
            try:
                monitor.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(monitor.wait(), timeout=1)
            except (asyncio.TimeoutError, ProcessLookupError):
                try:
                    monitor.kill()
                except ProcessLookupError:
                    pass

    async def _capture_scrot(self, window_id: str | None = None) -> Path:
        """Capture via import -window (if window_id), else scrot -u, else scrot."""
        tmp = tempfile.mktemp(suffix=".png")

        # Try ImageMagick import -window when we know the target window
        if window_id:
            try:
                proc = await asyncio.create_subprocess_exec(
                    "import", "-window", window_id, tmp,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
                if proc.returncode == 0 and Path(tmp).exists():
                    logger.debug("Screenshot via import -window %s", window_id)
                    return Path(tmp)
            except FileNotFoundError:
                pass  # import not installed
            logger.info("import -window failed, falling back to scrot")

        # Try focused window first
        proc = await asyncio.create_subprocess_exec(
            "scrot", "-u", tmp,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        if proc.returncode == 0 and Path(tmp).exists():
            return Path(tmp)

        # Fallback: full screen
        logger.info("scrot -u failed, trying full screen")
        proc = await asyncio.create_subprocess_exec(
            "scrot", tmp,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        if proc.returncode == 0 and Path(tmp).exists():
            return Path(tmp)

        raise RuntimeError("Screenshot capture failed: scrot not available or failed")

    @staticmethod
    def preprocess_for_llm(png_bytes: bytes, max_width: int = 800, jpeg_quality: int = 60) -> bytes:
        """Downscale + grayscale + contrast-enhance for minimal LLM tokens.

        Optimizes for readability of text and UI borders while minimizing
        image tokens. Grayscale removes color info (irrelevant for text/border
        detection). Contrast + sharpness boost sharpens text edges.
        """
        from PIL import ImageEnhance

        img = Image.open(BytesIO(png_bytes))

        # Adaptive downscaling: maintain text readability
        if img.width > max_width:
            ratio = max_width / img.width
            img = img.resize((max_width, int(img.height * ratio)), Image.LANCZOS)

        # Grayscale: color is irrelevant for text/border structure
        img = img.convert("L")

        # Contrast boost: sharpen text edges, make borders crisper
        img = ImageEnhance.Contrast(img).enhance(1.5)
        img = ImageEnhance.Sharpness(img).enhance(1.3)

        buf = BytesIO()
        img.save(buf, format="JPEG", quality=jpeg_quality)
        return buf.getvalue()

    def _resize_and_compress(self, path: Path) -> tuple[bytes, int, int]:
        """Open image, resize to max_width if needed, return JPEG bytes."""
        img = Image.open(path)
        w, h = img.size

        if w > self._max_width:
            ratio = self._max_width / w
            new_w = self._max_width
            new_h = int(h * ratio)
            img = img.resize((new_w, new_h), Image.LANCZOS)
            w, h = new_w, new_h

        buf = BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=self._jpeg_quality)
        return buf.getvalue(), w, h
