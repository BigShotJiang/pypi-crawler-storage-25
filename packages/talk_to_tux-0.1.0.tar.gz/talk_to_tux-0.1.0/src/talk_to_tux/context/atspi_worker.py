"""Subprocess AT-SPI worker — queries focused/cursor widgets, outputs JSON, exits.

Designed to be run as ``python -m talk_to_tux.context.atspi_worker``.
Process death reclaims all GLib/D-Bus resources — no leak accumulation.
Logging goes to stderr; only the JSON result goes to stdout.
"""
from __future__ import annotations

import json
import logging
import signal
import sys

logging.basicConfig(stream=sys.stderr, level=logging.WARNING)
logger = logging.getLogger(__name__)

_TIMEOUT_S = 2


def _widget_to_dict(widget) -> dict | None:
    if widget is None:
        return None
    return {
        "role": widget.role,
        "name": widget.name,
        "states": widget.states,
        "caret_offset": widget.caret_offset,
        "text_content": widget.text_content,
        "text_around_caret": widget.text_around_caret,
    }


def _run() -> dict:
    """Query AT-SPI widgets and return result dict."""
    from talk_to_tux.context.accessibility import get_focused_widget, get_widget_at_cursor

    atspi_available = True
    try:
        focused = get_focused_widget()
        cursor = get_widget_at_cursor()
    except Exception:
        focused = None
        cursor = None
        atspi_available = False

    return {
        "focused": _widget_to_dict(focused),
        "cursor": _widget_to_dict(cursor),
        "atspi_available": atspi_available,
    }


def _alarm_handler(signum, frame):
    logger.error("AT-SPI worker timed out after %ds", _TIMEOUT_S)
    sys.exit(1)


def main() -> None:
    signal.signal(signal.SIGALRM, _alarm_handler)
    signal.alarm(_TIMEOUT_S)
    try:
        result = _run()
    except Exception as exc:
        logger.error("AT-SPI worker failed: %s", exc)
        result = {
            "focused": None,
            "cursor": None,
            "atspi_available": False,
        }
    signal.alarm(0)
    json.dump(result, sys.stdout)
    sys.stdout.flush()


if __name__ == "__main__":
    main()
