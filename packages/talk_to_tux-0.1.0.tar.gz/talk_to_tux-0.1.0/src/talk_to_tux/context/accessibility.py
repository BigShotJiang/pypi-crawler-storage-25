"""AT-SPI accessibility helpers for focused/cursor widget context."""
from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys

from talk_to_tux.context.models import WidgetInfo

logger = logging.getLogger(__name__)

_atspi_warned: bool = False
_atspi_bus_checked: bool = False
_atspi_bus_ok: bool = False


def _check_atspi_bus() -> bool:
    """Two-phase pre-check of AT-SPI bus reachability (subprocess-safe).

    Phase 1: Query org.a11y.Bus.GetAddress for the bus socket address.
    Phase 2: Ping the returned address to verify the bus is actually live.

    The gi.repository.Atspi import triggers a C-level g_error() → abort()
    when the AT-SPI bus is unreachable.  Since g_error() is unconditionally
    fatal (cannot be caught by Python or overridden by env vars once GLib
    is initialized), we MUST verify connectivity before importing Atspi.
    """
    # Phase 1: resolve the AT-SPI bus address
    try:
        result = subprocess.run(
            [
                "dbus-send", "--session",
                "--dest=org.a11y.Bus",
                "--print-reply",
                "/org/a11y/bus",
                "org.a11y.Bus.GetAddress",
            ],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode != 0:
            return False
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False

    # Phase 2: extract bus address and ping it
    # The reply contains a line like:  string "unix:path=/tmp/at-spi2/..."
    address = None
    for line in result.stdout.splitlines():
        line = line.strip()
        if line.startswith('string "') and line.endswith('"'):
            address = line[len('string "'):-1]
            break

    if not address:
        logger.debug("AT-SPI bus address not found in GetAddress reply")
        return False

    try:
        ping = subprocess.run(
            [
                "dbus-send",
                f"--address={address}",
                "--print-reply",
                "--dest=org.freedesktop.DBus",
                "/org/freedesktop/DBus",
                "org.freedesktop.DBus.Peer.Ping",
            ],
            capture_output=True,
            text=True,
            timeout=2,
        )
        return ping.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False


def _import_atspi():
    """Lazy-import Atspi via GObject introspection.

    Guards against fatal process abort by pre-checking the AT-SPI bus
    before importing.  Raises ImportError if the bus is unreachable.
    """
    global _atspi_bus_checked, _atspi_bus_ok

    if not _atspi_bus_checked:
        _atspi_bus_ok = _check_atspi_bus()
        _atspi_bus_checked = True
        if _atspi_bus_ok:
            logger.debug("AT-SPI bus pre-check: reachable")
        else:
            logger.warning("AT-SPI bus pre-check: unreachable — accessibility features disabled")

    if not _atspi_bus_ok:
        raise ImportError("AT-SPI bus is not reachable")

    import gi

    gi.require_version("Atspi", "2.0")
    from gi.repository import Atspi

    return Atspi


def _extract_widget_info(accessible) -> WidgetInfo | None:
    """Extract WidgetInfo fields from an Atspi.Accessible object."""
    if accessible is None:
        return None
    role = accessible.get_localized_role_name() or None
    name = accessible.get_name() or None

    # Human-readable state names
    states: list[str] | None = None
    try:
        state_set = accessible.get_state_set()
        if state_set is not None:
            Atspi = _import_atspi()
            raw = []
            for s in Atspi.StateType.__enum_values__.values():
                if state_set.contains(s):
                    raw.append(s.value_nick.replace("-", "_"))
            states = raw if raw else None
    except Exception:
        pass

    # Text interface: caret offset + visible text content
    caret_offset: int | None = None
    text_content: str | None = None
    text_around_caret: str | None = None
    try:
        text_iface = accessible.get_text()
        if text_iface is not None:
            caret_offset = text_iface.get_caret_offset()

            # Read visible text content
            char_count = text_iface.get_character_count()
            if char_count > 0:
                # Cap at 2000 chars to avoid overwhelming the prompt
                read_count = min(char_count, 2000)
                # Read from end (most recent content, e.g., latest terminal lines)
                start = max(0, char_count - read_count)
                text_content = text_iface.get_text(start, char_count)

                # Context around caret (if caret is valid)
                if caret_offset is not None and caret_offset >= 0:
                    ctx_start = max(0, caret_offset - 250)
                    ctx_end = min(char_count, caret_offset + 250)
                    text_around_caret = text_iface.get_text(ctx_start, ctx_end)
    except Exception:
        logger.debug("AT-SPI text read failed", exc_info=True)

    return WidgetInfo(
        role=role, name=name, states=states, caret_offset=caret_offset,
        text_content=text_content, text_around_caret=text_around_caret,
    )


def _find_focused_in_tree(accessible, depth: int = 0, max_depth: int = 10):
    """Depth-limited walk looking for a FOCUSED accessible."""
    if depth > max_depth:
        return None
    try:
        Atspi = _import_atspi()
        state_set = accessible.get_state_set()
        if state_set is not None and state_set.contains(Atspi.StateType.FOCUSED):
            return accessible
        n = accessible.get_child_count()
        for i in range(n):
            child = accessible.get_child_at_index(i)
            if child is None:
                continue
            result = _find_focused_in_tree(child, depth + 1, max_depth)
            if result is not None:
                return result
    except Exception:
        pass
    return None


def get_focused_widget() -> WidgetInfo | None:
    """Return info about the currently focused AT-SPI widget, or None."""
    global _atspi_warned
    try:
        Atspi = _import_atspi()
    except (ImportError, ValueError):
        if not _atspi_warned:
            logger.debug("AT-SPI not available")
            _atspi_warned = True
        return None

    try:
        desktop = Atspi.get_desktop(0)
        if desktop is None:
            return None

        # Walk children of the desktop (each is an application)
        n_apps = desktop.get_child_count()
        for i in range(n_apps):
            app = desktop.get_child_at_index(i)
            if app is None:
                continue
            focused = _find_focused_in_tree(app)
            if focused is not None:
                return _extract_widget_info(focused)
        return None
    except Exception:
        logger.debug("AT-SPI focused widget lookup failed", exc_info=True)
        return None


def _get_cursor_position() -> tuple[int, int] | None:
    """Get cursor (x, y) via xdotool getmouselocation."""
    try:
        result = subprocess.run(
            ["xdotool", "getmouselocation", "--shell"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        x = y = None
        for line in result.stdout.strip().splitlines():
            if line.startswith("X="):
                x = int(line.split("=", 1)[1])
            elif line.startswith("Y="):
                y = int(line.split("=", 1)[1])
        if x is not None and y is not None:
            return (x, y)
        return None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError, ValueError):
        return None


def get_widget_at_cursor() -> WidgetInfo | None:
    """Return info about the AT-SPI widget under the mouse cursor, or None."""
    global _atspi_warned
    pos = _get_cursor_position()
    if pos is None:
        return None

    try:
        Atspi = _import_atspi()
    except (ImportError, ValueError):
        if not _atspi_warned:
            logger.debug("AT-SPI not available")
            _atspi_warned = True
        return None

    try:
        desktop = Atspi.get_desktop(0)
        if desktop is None:
            return None
        component = desktop.get_accessible_at_point(
            pos[0], pos[1], Atspi.CoordType.SCREEN
        )
        return _extract_widget_info(component)
    except Exception:
        logger.debug("AT-SPI cursor widget lookup failed", exc_info=True)
        return None


def _dict_to_widget(d: dict | None) -> WidgetInfo | None:
    """Convert a JSON-parsed dict back to a WidgetInfo."""
    if d is None:
        return None
    return WidgetInfo(
        role=d.get("role"),
        name=d.get("name"),
        states=d.get("states"),
        caret_offset=d.get("caret_offset"),
        text_content=d.get("text_content"),
        text_around_caret=d.get("text_around_caret"),
    )


_FALLBACK = (None, None, False)


async def query_widgets_subprocess(
    timeout: float = 2.5,
) -> tuple[WidgetInfo | None, WidgetInfo | None, bool]:
    """Spawn atspi_worker as a subprocess, parse JSON result.

    Returns (focused, cursor, atspi_available).
    On timeout/crash/parse error returns (None, None, False).
    """
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "talk_to_tux.context.atspi_worker",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        logger.debug("AT-SPI subprocess timed out after %.1fs", timeout)
        try:
            proc.kill()  # type: ignore[possibly-undefined]
        except ProcessLookupError:
            pass
        return _FALLBACK
    except Exception:
        logger.debug("AT-SPI subprocess launch failed", exc_info=True)
        return _FALLBACK

    if proc.returncode != 0:
        logger.debug("AT-SPI subprocess exited with code %d: %s", proc.returncode, stderr.decode(errors="replace"))
        return _FALLBACK

    try:
        data = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        logger.debug("AT-SPI subprocess returned invalid JSON: %r", stdout[:200])
        return _FALLBACK

    focused = _dict_to_widget(data.get("focused"))
    cursor = _dict_to_widget(data.get("cursor"))
    atspi_available = data.get("atspi_available", False)
    return (focused, cursor, atspi_available)
