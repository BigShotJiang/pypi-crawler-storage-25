"""Boot-resilient display detection.

After reboot the inherited DISPLAY / WAYLAND_DISPLAY env vars may be stale
(e.g. :0 when the actual X server is at :1).  This module validates the
current value and, if broken, probes the system for a working display so
downstream X11 tools (xdotool, xclip, scrot, xprop) work immediately.
"""
from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

_PROBE_TIMEOUT = 2  # seconds per candidate


def _validate_wayland(runtime_dir: str, wayland_display: str) -> bool:
    """Return True if the WAYLAND_DISPLAY socket exists."""
    sock = Path(runtime_dir) / wayland_display
    return sock.exists()


def _probe_wayland_sockets(runtime_dir: str) -> str | None:
    """Scan XDG_RUNTIME_DIR for wayland-* sockets; return first found or None."""
    rd = Path(runtime_dir)
    if not rd.is_dir():
        return None
    for entry in sorted(rd.iterdir()):
        if entry.name.startswith("wayland-") and not entry.name.endswith(".lock"):
            return entry.name
    return None


def _validate_x11(display: str) -> bool:
    """Return True if xdotool can reach the given DISPLAY."""
    env = {**os.environ, "DISPLAY": display}
    try:
        result = subprocess.run(
            ["xdotool", "getactivewindow"],
            env=env,
            capture_output=True,
            timeout=_PROBE_TIMEOUT,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False


def _probe_x11_sockets() -> str | None:
    """Scan /tmp/.X11-unix/ for X* sockets and return first working `:N`."""
    x11_dir = Path("/tmp/.X11-unix")
    if not x11_dir.is_dir():
        return None
    for entry in sorted(x11_dir.iterdir()):
        name = entry.name
        if not name.startswith("X"):
            continue
        display_num = name[1:]
        if not display_num.isdigit():
            continue
        candidate = f":{display_num}"
        if _validate_x11(candidate):
            return candidate
    return None


def detect_and_fix_display() -> str | None:
    """Ensure DISPLAY/WAYLAND_DISPLAY points to a working server.

    Validates the current env vars and, if stale, probes the system for a
    working display.  Fixes ``os.environ`` in-place so all downstream code
    inherits the corrected value.

    Returns the display string (e.g. ``":1"`` or ``"wayland-0"``) on success,
    or ``None`` if no working display could be found.
    """
    runtime_dir = os.environ.get("XDG_RUNTIME_DIR", "")

    # --- Wayland path ---
    wayland = os.environ.get("WAYLAND_DISPLAY", "")
    if wayland:
        if runtime_dir and _validate_wayland(runtime_dir, wayland):
            return wayland
        # Socket missing — try probing
        if runtime_dir:
            found = _probe_wayland_sockets(runtime_dir)
            if found:
                logger.warning(
                    "Stale WAYLAND_DISPLAY=%s — fixed to %s", wayland, found,
                )
                os.environ["WAYLAND_DISPLAY"] = found
                return found

    # --- X11 path ---
    display = os.environ.get("DISPLAY", "")
    if display:
        if _validate_x11(display):
            return display
        # Current DISPLAY is stale — probe sockets
        found = _probe_x11_sockets()
        if found:
            logger.warning(
                "Stale DISPLAY=%s — fixed to %s", display, found,
            )
            os.environ["DISPLAY"] = found
            return found

    # --- DISPLAY not set — probe from scratch ---
    if not display and not wayland:
        # Try Wayland first
        if runtime_dir:
            found_wl = _probe_wayland_sockets(runtime_dir)
            if found_wl:
                logger.warning("WAYLAND_DISPLAY unset — discovered %s", found_wl)
                os.environ["WAYLAND_DISPLAY"] = found_wl
                return found_wl
        # Then X11
        found_x = _probe_x11_sockets()
        if found_x:
            logger.warning("DISPLAY unset — discovered %s", found_x)
            os.environ["DISPLAY"] = found_x
            return found_x

    return None
