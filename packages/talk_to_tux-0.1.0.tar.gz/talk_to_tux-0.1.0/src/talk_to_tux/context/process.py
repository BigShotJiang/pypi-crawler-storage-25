"""Detect TUI apps running inside terminals via /proc process tree scanning.

Walks the process tree from a terminal window's PID to find multiplexers
(zellij, tmux, screen) and TUI applications (vim, claude, htop, etc.).
All reads are from /proc — no subprocess calls, typically <1ms total.

When a multiplexer is detected, queries it for the active pane's foreground
command so the LLM sees the correct app context (not just all apps).
"""
from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Map process comm names to human-readable app types
_TUI_APPS: dict[str, str] = {
    "claude": "chat",
    "vim": "code-editor",
    "nvim": "code-editor",
    "nano": "text-editor",
    "emacs": "code-editor",
    "htop": "dashboard",
    "btop": "dashboard",
    "top": "dashboard",
    "lazygit": "code-editor",
    "lazydocker": "dashboard",
    "mc": "file-manager",
    "ranger": "file-manager",
    "nnn": "file-manager",
    "lf": "file-manager",
    "weechat": "chat",
    "irssi": "chat",
    "mutt": "chat",
    "neomutt": "chat",
    "ncmpcpp": "media-player",
    "cmus": "media-player",
    "newsboat": "reader",
    "w3m": "browser",
    "lynx": "browser",
    "links": "browser",
    "tig": "code-editor",
    "k9s": "dashboard",
}

_MULTIPLEXERS = frozenset({"zellij", "tmux", "screen"})
_SHELLS = frozenset({"bash", "zsh", "fish", "sh", "dash", "ksh", "tcsh", "csh", "nu"})

_PROC = Path("/proc")


@dataclass
class TerminalProcessInfo:
    """Info about processes running inside a terminal window."""

    multiplexer: str | None = None
    tui_apps: list[tuple[str, str]] = field(default_factory=list)
    has_ssh: bool = False
    ssh_remote_host: str | None = None
    remote_multiplexer_hint: str | None = None
    active_pane_command: str | None = None  # e.g. "claude", "vim", "bash"


def _read_comm(pid: int) -> str | None:
    """Read /proc/<pid>/comm — the process name."""
    try:
        return (_PROC / str(pid) / "comm").read_text().strip()
    except (OSError, ValueError):
        return None


def _build_children_map() -> dict[int, list[int]]:
    """Build pid->children map by reading ppid from /proc/*/stat.

    Reliable for multi-threaded parents (unlike /proc/pid/task/pid/children
    which only tracks children of the main thread).
    """
    children: dict[int, list[int]] = {}
    for entry in _PROC.iterdir():
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        try:
            stat = (entry / "stat").read_text()
            # Format: pid (comm) state ppid ...
            # comm can contain spaces/parens, so find last ')' first
            close_paren = stat.rfind(")")
            if close_paren < 0:
                continue
            fields = stat[close_paren + 2 :].split()
            ppid = int(fields[1])  # fields[0]=state, fields[1]=ppid
            children.setdefault(ppid, []).append(pid)
        except (OSError, ValueError, IndexError):
            continue
    return children


def _walk_descendants(
    pid: int, children_map: dict[int, list[int]], max_depth: int = 10
) -> list[int]:
    """BFS walk of all descendant PIDs using pre-built children map."""
    result: list[int] = []
    queue = [pid]
    depth = 0
    while queue and depth < max_depth:
        next_queue: list[int] = []
        for p in queue:
            kids = children_map.get(p, [])
            result.extend(kids)
            next_queue.extend(kids)
        queue = next_queue
        depth += 1
    return result


def _find_zellij_server_pid(session_name: str) -> int | None:
    """Find zellij server process by scanning /proc/*/cmdline for session name."""
    try:
        for entry in _PROC.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                cmdline = (entry / "cmdline").read_bytes()
            except OSError:
                continue
            # cmdline is null-separated
            parts = cmdline.decode("utf-8", errors="replace").split("\0")
            # Look for: zellij --server <path>/<session_name>
            if len(parts) >= 3 and "zellij" in parts[0] and "--server" in parts:
                server_idx = parts.index("--server")
                if server_idx + 1 < len(parts):
                    server_path = parts[server_idx + 1]
                    if server_path.endswith("/" + session_name):
                        return int(entry.name)
            # Also check: the path itself contains the session name after last /
            for part in parts:
                if "/zellij-" in part and part.endswith("/" + session_name):
                    return int(entry.name)
    except OSError:
        pass
    return None


def _extract_zellij_session(window_title: str | None) -> str | None:
    """Extract zellij session name from window title.

    Zellij titles look like: "session-name | Tab: pane_name"
    or: "Zellij (session-name)"
    """
    if not window_title:
        return None
    # Format: "session-name | ..."
    if " | " in window_title:
        return window_title.split(" | ")[0].strip()
    # Format: "Zellij (session-name)"
    if window_title.startswith("Zellij (") and window_title.endswith(")"):
        return window_title[8:-1]
    return None


def _read_zellij_session_from_env(pid: int) -> str | None:
    """Read ZELLIJ_SESSION_NAME from a zellij process's environment."""
    try:
        environ = (_PROC / str(pid) / "environ").read_bytes()
        for var in environ.decode("utf-8", errors="replace").split("\0"):
            if var.startswith("ZELLIJ_SESSION_NAME="):
                return var.split("=", 1)[1]
    except (OSError, ValueError):
        pass
    return None


def _parse_ssh_host(pid: int) -> str | None:
    """Extract remote host from SSH process cmdline."""
    try:
        cmdline = (_PROC / str(pid) / "cmdline").read_bytes()
        parts = cmdline.decode("utf-8", errors="replace").split("\0")
        # ssh [options] [user@]hostname [command]
        # Skip flags (-p, -i, -L, etc.) and their arguments
        skip_next = False
        for part in parts[1:]:
            if skip_next:
                skip_next = False
                continue
            if part.startswith("-"):
                if part in ("-p", "-i", "-F", "-L", "-R", "-D", "-o", "-J", "-W"):
                    skip_next = True  # these take an argument
                continue
            if part:  # first non-flag, non-empty arg is the destination
                return part
    except (OSError, ValueError):
        pass
    return None


def _get_zellij_active_pane_command(
    server_pid: int, children_map: dict[int, list[int]]
) -> str | None:
    """Query zellij for the focused pane, then find its running command via /proc."""
    import json as _json

    try:
        result = subprocess.run(
            ["zellij", "action", "list-panes"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode != 0:
            return None
        data = _json.loads(result.stdout)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError, ValueError):
        return None

    focused_pane_id = None
    for tab_panes in data.get("panes", {}).values():
        for pane in tab_panes:
            if pane.get("is_focused") and not pane.get("is_plugin"):
                focused_pane_id = pane["id"]
                break
        if focused_pane_id is not None:
            break
    if focused_pane_id is None:
        return None

    # Find shell child of server with matching ZELLIJ_PANE_ID
    for child_pid in children_map.get(server_pid, []):
        comm = _read_comm(child_pid)
        if comm not in _SHELLS:
            continue
        try:
            environ = (_PROC / str(child_pid) / "environ").read_bytes()
            env_str = environ.decode("utf-8", errors="replace")
            for var in env_str.split("\0"):
                if var.startswith("ZELLIJ_PANE_ID="):
                    pane_id = int(var.split("=", 1)[1])
                    if pane_id == focused_pane_id:
                        # Walk this shell's children for TUI app
                        descendants = _walk_descendants(
                            child_pid, children_map, max_depth=5
                        )
                        for d_pid in descendants:
                            d_comm = _read_comm(d_pid)
                            if d_comm and d_comm in _TUI_APPS:
                                return d_comm
                            if (
                                d_comm
                                and d_comm not in _SHELLS
                                and d_comm not in _MULTIPLEXERS
                            ):
                                return d_comm  # unknown app, still useful
                        return comm  # shell itself (bare shell pane)
        except (OSError, ValueError):
            continue
    return None


def _get_active_pane_command(
    multiplexer: str,
    server_pid: int | None = None,
    children_map: dict[int, list[int]] | None = None,
) -> str | None:
    """Query multiplexer for the active pane's foreground command.

    For tmux: runs ``tmux display-message -p '#{pane_current_command}'``.
    For zellij: runs ``zellij action list-panes`` and correlates via /proc.
    """
    if multiplexer == "tmux":
        try:
            result = subprocess.run(
                ["tmux", "display-message", "-p", "#{pane_current_command}"],
                capture_output=True,
                text=True,
                timeout=1,
            )
            if result.returncode == 0:
                cmd = result.stdout.strip()
                if cmd:
                    return cmd
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            pass
    elif multiplexer == "zellij" and server_pid and children_map:
        return _get_zellij_active_pane_command(server_pid, children_map)
    return None


def detect_terminal_apps(
    window_pid: int, window_title: str | None = None
) -> TerminalProcessInfo:
    """Detect TUI apps running inside a terminal by walking /proc.

    Args:
        window_pid: PID of the terminal window process.
        window_title: Window title (used to bridge zellij client→server).

    Returns:
        TerminalProcessInfo with detected multiplexer, TUI apps, and SSH status.
    """
    info = TerminalProcessInfo()

    # Build pid->children map once from /proc/*/stat
    children_map = _build_children_map()

    # Walk descendants of the window PID
    descendants = _walk_descendants(window_pid, children_map)
    comms: dict[int, str] = {}
    for pid in descendants:
        comm = _read_comm(pid)
        if comm:
            comms[pid] = comm

    # Detect multiplexer and SSH in direct descendants
    zellij_session: str | None = None
    server_pid: int | None = None
    for pid, comm in comms.items():
        if comm in _MULTIPLEXERS:
            info.multiplexer = comm
            if comm == "zellij":
                # Primary: read session name from environment
                zellij_session = _read_zellij_session_from_env(pid)
                # Fallback: parse from window title
                if not zellij_session:
                    zellij_session = _extract_zellij_session(window_title)
        if comm == "ssh":
            info.has_ssh = True
            info.ssh_remote_host = _parse_ssh_host(pid)

    # If zellij detected, bridge to server process and walk its children
    if info.multiplexer == "zellij" and zellij_session:
        server_pid = _find_zellij_server_pid(zellij_session)
        if server_pid:
            server_descendants = _walk_descendants(server_pid, children_map)
            for pid in server_descendants:
                comm = _read_comm(pid)
                if comm:
                    comms[pid] = comm

    # Match process names against TUI apps (skip shells and multiplexers)
    seen_apps: set[str] = set()
    for comm in comms.values():
        if comm in _SHELLS or comm in _MULTIPLEXERS:
            continue
        if comm in _TUI_APPS and comm not in seen_apps:
            info.tui_apps.append((comm, _TUI_APPS[comm]))
            seen_apps.add(comm)

    # Query multiplexer for active pane's foreground command
    if info.multiplexer:
        active_cmd = _get_active_pane_command(
            info.multiplexer,
            server_pid=server_pid,
            children_map=children_map,
        )
        if active_cmd:
            info.active_pane_command = active_cmd
            # Filter TUI apps to active pane only
            if active_cmd in _TUI_APPS:
                info.tui_apps = [(active_cmd, _TUI_APPS[active_cmd])]
            elif active_cmd in _SHELLS:
                info.tui_apps = []
            # else: unknown app — keep all TUI apps (fallback)

    # Detect remote multiplexer from window title when SSH + no local multiplexer
    if info.has_ssh and not info.multiplexer and window_title:
        if " | " in window_title:
            info.remote_multiplexer_hint = "zellij"

    return info
