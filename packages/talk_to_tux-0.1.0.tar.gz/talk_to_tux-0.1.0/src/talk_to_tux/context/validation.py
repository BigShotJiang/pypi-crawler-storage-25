"""Pre-recording cursor typeability validation using AT-SPI."""
from __future__ import annotations

from dataclasses import dataclass

from talk_to_tux.context.models import WidgetInfo

# Roles that are typically typeable (text input surfaces)
_TYPEABLE_ROLES: frozenset[str] = frozenset({
    "text",
    "entry",
    "terminal",
    "document",
    "paragraph",
    "editbar",
    "password text",
    "spin button",
    "combo box",
    "document text",
    "document frame",
    "document web",
    "document spreadsheet",
    "document presentation",
})


@dataclass
class CursorValidationResult:
    """Result of pre-recording cursor position validation."""

    is_typeable: bool
    reason: str
    widget_role: str | None = None
    widget_name: str | None = None
    has_editable_state: bool = False
    atspi_available: bool = True


def is_widget_typeable(widget: WidgetInfo | None) -> bool:
    """Check if a single widget is typeable (editable state or typeable role)."""
    if widget is None:
        return False
    # Check for "editable" in states
    if widget.states and "editable" in widget.states:
        return True
    # Check role against known typeable roles
    if widget.role and widget.role.lower() in _TYPEABLE_ROLES:
        return True
    return False


def validate_cursor_target(
    focused: WidgetInfo | None,
    cursor: WidgetInfo | None,
    atspi_available: bool = True,
) -> CursorValidationResult:
    """Validate whether the cursor is over a typeable widget.

    Graceful degradation:
    - AT-SPI unavailable → PASS (can't determine, allow recording)
    - No widgets found → PASS (AT-SPI may not cover this app)
    - Only FAIL when AT-SPI works AND widget is definitively non-typeable
    """
    if not atspi_available:
        return CursorValidationResult(
            is_typeable=True,
            reason="AT-SPI unavailable — allowing recording",
            atspi_available=False,
        )

    # Check cursor widget first (where mouse actually points)
    if cursor is not None:
        editable = bool(cursor.states and "editable" in cursor.states)
        if is_widget_typeable(cursor):
            return CursorValidationResult(
                is_typeable=True,
                reason=f"Cursor over typeable widget: {cursor.role}",
                widget_role=cursor.role,
                widget_name=cursor.name,
                has_editable_state=editable,
            )
        # Cursor widget exists but is not typeable — check focused as fallback
        if focused is not None:
            focused_editable = bool(focused.states and "editable" in focused.states)
            if is_widget_typeable(focused):
                return CursorValidationResult(
                    is_typeable=True,
                    reason=f"Focused widget is typeable: {focused.role}",
                    widget_role=focused.role,
                    widget_name=focused.name,
                    has_editable_state=focused_editable,
                )
        # Both exist, neither typeable → FAIL
        return CursorValidationResult(
            is_typeable=False,
            reason=f"Cursor over non-typeable widget: {cursor.role or 'unknown'}",
            widget_role=cursor.role,
            widget_name=cursor.name,
            has_editable_state=False,
        )

    # No cursor widget — check focused widget
    if focused is not None:
        editable = bool(focused.states and "editable" in focused.states)
        if is_widget_typeable(focused):
            return CursorValidationResult(
                is_typeable=True,
                reason=f"Focused widget is typeable: {focused.role}",
                widget_role=focused.role,
                widget_name=focused.name,
                has_editable_state=editable,
            )
        # Focused exists but not typeable → FAIL
        return CursorValidationResult(
            is_typeable=False,
            reason=f"Focused widget is non-typeable: {focused.role or 'unknown'}",
            widget_role=focused.role,
            widget_name=focused.name,
            has_editable_state=False,
        )

    # No widgets found at all — graceful degradation → PASS
    return CursorValidationResult(
        is_typeable=True,
        reason="No widgets detected — allowing recording",
    )
