from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from talk_to_tux.context.process import TerminalProcessInfo


@dataclass
class WindowInfo:
    """Intermediate result from window metadata capture."""

    title: str | None = None
    wm_class: str | None = None
    wm_instance: str | None = None
    pid: int | None = None
    window_id: str | None = None
    geometry: tuple[int, int, int, int] | None = None  # (x, y, width, height)


@dataclass
class WidgetInfo:
    """Accessibility info about a single widget."""

    role: str | None = None
    name: str | None = None
    states: list[str] | None = None
    caret_offset: int | None = None
    text_content: str | None = None
    text_around_caret: str | None = None


@dataclass
class AppContext:
    """Complete captured application context."""

    timestamp: float = field(default_factory=time.time)
    window_title: str | None = None
    window_class: str | None = None
    window_instance: str | None = None
    window_pid: int | None = None
    screenshot_png: bytes | None = None
    screenshot_width: int = 0
    screenshot_height: int = 0
    widget_role: str | None = None
    widget_name: str | None = None
    caret_offset: int | None = None
    window_id: str | None = None
    cursor_widget_role: str | None = None
    cursor_widget_name: str | None = None
    text_content: str | None = None
    text_around_caret: str | None = None
    terminal_info: TerminalProcessInfo | None = None
