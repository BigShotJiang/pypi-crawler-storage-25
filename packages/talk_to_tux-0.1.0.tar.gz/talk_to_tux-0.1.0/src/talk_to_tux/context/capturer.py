from __future__ import annotations

import asyncio
import logging
import time

from talk_to_tux.context.accessibility import query_widgets_subprocess
from pathlib import Path

from talk_to_tux.context.models import AppContext, WidgetInfo, WindowInfo
from talk_to_tux.context.screenshot import ScreenshotCapturer
from talk_to_tux.context.window import get_window_info

logger = logging.getLogger(__name__)


class ContextCapturer:
    """Orchestrates screenshot + window metadata capture."""

    def __init__(
        self,
        screenshot_capturer: ScreenshotCapturer | None = None,
        max_width: int = 1024,
        jpeg_quality: int = 85,
    ) -> None:
        self._screenshot = screenshot_capturer or ScreenshotCapturer(
            max_width=max_width, jpeg_quality=jpeg_quality
        )

    async def capture(self, cursor_window_id: str | None = None) -> AppContext:
        """Capture screenshot, window info, and widget context concurrently."""
        loop = asyncio.get_event_loop()

        # Phase 1: parallel capture (raw screenshot, window info, widgets)
        raw_task = asyncio.create_task(self._capture_raw(cursor_window_id))
        window_task = loop.run_in_executor(None, self._capture_window)
        widget_task = asyncio.create_task(self._capture_widgets_async())

        raw_result, window_result, widget_result = await asyncio.gather(
            raw_task, window_task, widget_task, return_exceptions=True
        )

        # Phase 2: crop screenshot to window bounds if available
        screenshot_png = None
        screenshot_width = 0
        screenshot_height = 0
        if isinstance(raw_result, Path):
            crop_rect = None
            if isinstance(window_result, WindowInfo) and window_result.geometry:
                crop_rect = window_result.geometry
            try:
                screenshot_png, screenshot_width, screenshot_height = (
                    await loop.run_in_executor(
                        None, self._screenshot.crop_and_compress, raw_result, crop_rect
                    )
                )
            except Exception as e:
                logger.warning("Screenshot processing failed: %s", e)
            finally:
                raw_result.unlink(missing_ok=True)
        elif isinstance(raw_result, BaseException):
            logger.warning("Screenshot capture failed: %s", raw_result)

        # Unpack window info
        window_title = None
        window_class = None
        window_instance = None
        window_pid = None
        window_id = None
        if isinstance(window_result, BaseException):
            logger.warning("Window info capture failed: %s", window_result)
        elif window_result is not None:
            window_title = window_result.title
            window_class = window_result.wm_class
            window_instance = window_result.wm_instance
            window_pid = window_result.pid
            window_id = window_result.window_id

        # Unpack widget context
        widget_role = None
        widget_name = None
        caret_offset = None
        cursor_widget_role = None
        cursor_widget_name = None
        if isinstance(widget_result, BaseException):
            logger.warning("Widget context capture failed: %s", widget_result)
        elif widget_result is not None:
            focused, cursor = widget_result
            if focused is not None:
                widget_role = focused.role
                widget_name = focused.name
                caret_offset = focused.caret_offset
            if cursor is not None:
                cursor_widget_role = cursor.role
                cursor_widget_name = cursor.name

        # Thread text content from focused widget
        text_content = None
        text_around_caret = None
        if isinstance(widget_result, tuple):
            focused, _ = widget_result
            if focused is not None:
                text_content = focused.text_content
                text_around_caret = focused.text_around_caret

        # Detect TUI apps for terminal windows via /proc
        terminal_info = None
        if window_pid and self._is_terminal_class(window_class):
            terminal_info = self._detect_terminal(window_pid, window_title)

        return AppContext(
            timestamp=time.time(),
            window_title=window_title,
            window_class=window_class,
            window_instance=window_instance,
            window_pid=window_pid,
            window_id=window_id,
            screenshot_png=screenshot_png,
            screenshot_width=screenshot_width,
            screenshot_height=screenshot_height,
            widget_role=widget_role,
            widget_name=widget_name,
            caret_offset=caret_offset,
            cursor_widget_role=cursor_widget_role,
            cursor_widget_name=cursor_widget_name,
            text_content=text_content,
            text_around_caret=text_around_caret,
            terminal_info=terminal_info,
        )

    async def _capture_raw(self, window_id: str | None = None) -> Path:
        return await self._screenshot.capture_raw(window_id=window_id)

    @staticmethod
    def _capture_window():
        # All methods below use subprocess.run (thread-safe, no GLib).
        # Wnck is NOT used here to avoid heap corruption when called
        # from executor threads.
        import os
        if os.environ.get("WAYLAND_DISPLAY"):
            from talk_to_tux.context.window import _get_via_dbus_ttt
            result = _get_via_dbus_ttt()
            if result is not None:
                return result
            from talk_to_tux.context.window import _get_via_dbus_gnome
            result = _get_via_dbus_gnome()
            if result is not None:
                return result
        from talk_to_tux.context.window import _get_via_xdotool
        return _get_via_xdotool()

    @staticmethod
    async def _capture_widgets_async() -> tuple[WidgetInfo | None, WidgetInfo | None]:
        """Capture focused widget and widget under cursor via subprocess."""
        focused, cursor, _available = await query_widgets_subprocess()
        return (focused, cursor)

    @staticmethod
    def _is_terminal_class(window_class: str | None) -> bool:
        """Check if window class is a known terminal emulator."""
        if not window_class:
            return False
        from talk_to_tux.pipeline.context_packer import _APP_TYPES

        return _APP_TYPES.get(window_class) == "terminal"

    @staticmethod
    def _detect_terminal(window_pid: int, window_title: str | None):
        """Detect TUI apps via /proc process tree. Returns TerminalProcessInfo or None."""
        try:
            from talk_to_tux.context.process import detect_terminal_apps

            return detect_terminal_apps(window_pid, window_title)
        except Exception:
            logger.debug("Process tree detection failed", exc_info=True)
            return None
