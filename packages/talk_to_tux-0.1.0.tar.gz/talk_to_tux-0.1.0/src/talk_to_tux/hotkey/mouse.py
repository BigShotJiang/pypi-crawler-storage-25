from __future__ import annotations

import asyncio
import glob
import logging
import os
import time
from typing import Awaitable, Callable

from evdev import InputDevice, ecodes

logger = logging.getLogger(__name__)


class MouseChordListener:
    """Detects left+right mouse button chord and triggers recording."""

    def __init__(
        self,
        on_start: Callable[[], Awaitable[None]],
        on_stop: Callable[[], Awaitable[None]],
        mode: str = "toggle",
        chord_timeout: float = 0.15,
        debounce: float = 0.3,
        dismiss_menu: bool = True,
        device_path: str | None = None,
    ) -> None:
        self._on_start = on_start
        self._on_stop = on_stop
        self._mode = mode
        self._chord_timeout = chord_timeout
        self._debounce = debounce
        self._dismiss_menu = dismiss_menu
        # Resolve device path eagerly so callers can catch RuntimeError
        # during construction and fall back to keyboard.
        self._device_path = device_path or self._find_mouse_device()

        self._device: InputDevice | None = None
        self._task: asyncio.Task | None = None

        # State tracking
        self._recording: bool = False
        self._left_down_time: float | None = None
        self._right_down_time: float | None = None
        self._last_chord_time: float = 0.0
        self._left_held: bool = False
        self._right_held: bool = False
        self._suppress_dismiss: bool = False

    @staticmethod
    def _find_mouse_device() -> str:
        candidates: list[tuple[str, str]] = []
        for path in sorted(glob.glob("/dev/input/event*")):
            try:
                dev = InputDevice(path)
                caps = dev.capabilities()
                if (
                    ecodes.EV_REL in caps
                    and ecodes.REL_X in caps.get(ecodes.EV_REL, [])
                    and ecodes.EV_KEY in caps
                    and ecodes.BTN_LEFT in caps.get(ecodes.EV_KEY, [])
                    and ecodes.BTN_RIGHT in caps.get(ecodes.EV_KEY, [])
                ):
                    candidates.append((path, dev.name))
                dev.close()
            except (PermissionError, OSError):
                continue
        if not candidates:
            raise RuntimeError("No mouse device found")
        # Prefer devices with "Mouse" in the name (real mice over phantom HID)
        candidates.sort(key=lambda c: ("Mouse" not in c[1], c[0]))
        path, name = candidates[0]
        logger.info("Mouse device: %s (%s)", path, name)
        return path

    async def _event_loop(self) -> None:
        if self._device is None:
            raise RuntimeError("Cannot run event loop without a device; call start() first")
        try:
            async for event in self._device.async_read_loop():
                if event.type != ecodes.EV_KEY:
                    continue
                if event.code not in (ecodes.BTN_LEFT, ecodes.BTN_RIGHT):
                    continue

                now = time.monotonic()

                if event.value == 1:  # button down
                    if event.code == ecodes.BTN_LEFT:
                        self._left_down_time = now
                        self._left_held = True
                    else:
                        self._right_down_time = now
                        self._right_held = True

                    # Check for chord: other button pressed within timeout
                    chord = False
                    if event.code == ecodes.BTN_LEFT and self._right_down_time is not None:
                        if now - self._right_down_time <= self._chord_timeout:
                            chord = True
                    elif event.code == ecodes.BTN_RIGHT and self._left_down_time is not None:
                        if now - self._left_down_time <= self._chord_timeout:
                            chord = True

                    if chord:
                        if now - self._last_chord_time > self._debounce:
                            logger.debug(
                                "Chord detected (L=%.3f R=%.3f gap=%.3fms)",
                                self._left_down_time or 0,
                                self._right_down_time or 0,
                                abs((self._left_down_time or 0) - (self._right_down_time or 0)) * 1000,
                            )
                            self._last_chord_time = now
                            self._left_down_time = None
                            self._right_down_time = None
                            await self._handle_chord()
                        else:
                            logger.debug("Chord suppressed by debounce (%.0fms since last)", (now - self._last_chord_time) * 1000)

                elif event.value == 0:  # button up
                    if event.code == ecodes.BTN_LEFT:
                        self._left_held = False
                    else:
                        self._right_held = False

                    # Hold mode: stop only when BOTH buttons are released
                    if (
                        self._mode == "hold"
                        and self._recording
                        and not self._left_held
                        and not self._right_held
                    ):
                        self._recording = False
                        await self._on_stop()

                    # Dismiss context menu after both buttons released
                    # (skip when tooltip is shown — dismiss is suppressed)
                    if (
                        self._dismiss_menu
                        and not self._suppress_dismiss
                        and not self._left_held
                        and not self._right_held
                        and self._last_chord_time > 0
                        and now - self._last_chord_time < 1.0
                    ):
                        await self._dismiss_context_menu()
        except OSError as e:
            logger.error("Mouse device disconnected: %s", e)

    async def _handle_chord(self) -> None:
        if self._mode == "toggle":
            if not self._recording:
                self._recording = True
                await self._on_start()
            else:
                self._recording = False
                await self._on_stop()
        else:  # hold
            self._recording = True
            await self._on_start()

    async def _dismiss_context_menu(self) -> None:
        # Skip Escape in terminals — it disrupts shell/multiplexers
        try:
            from talk_to_tux.context.window import get_window_info
            from talk_to_tux.paste.paster import TERMINAL_WM_CLASSES

            info = get_window_info()
            if info is not None and info.wm_class in TERMINAL_WM_CLASSES:
                logger.debug("Skipping context menu dismiss (terminal: %s)", info.wm_class)
                return
        except Exception:
            pass  # If window detection fails, proceed with Escape as before

        await asyncio.sleep(0.1)
        if os.environ.get("WAYLAND_DISPLAY"):
            cmd = ["wtype", "-k", "Escape"]
        else:
            cmd = ["xdotool", "key", "Escape"]
        logger.debug("Dismissing context menu: %s", " ".join(cmd))
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
        except FileNotFoundError:
            logger.warning("Could not dismiss context menu: %s not found", cmd[0])

    def set_debounce(self, seconds: float) -> None:
        """Change the debounce interval (e.g. lower for double-chord detection)."""
        self._debounce = seconds

    async def start(self) -> None:
        self._device = InputDevice(self._device_path)
        # NO grab -- passive reading (grab would freeze cursor)
        self._task = asyncio.create_task(self._event_loop())

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        if self._device is not None:
            self._device.close()
            self._device = None
