from __future__ import annotations

import asyncio
import glob
import logging
import time
from typing import Callable, Awaitable

import evdev
from evdev import InputDevice, InputEvent, ecodes

logger = logging.getLogger(__name__)


class HotkeyListener:
    def __init__(
        self,
        key_name: str,
        on_press: Callable[[], Awaitable[None]],
        on_release: Callable[[], Awaitable[None]],
        device_path: str | None = None,
    ) -> None:
        if key_name not in ecodes.ecodes:
            raise ValueError(f"Unknown key name: {key_name}")
        self._key_code: int = ecodes.ecodes[key_name]
        self._on_press = on_press
        self._on_release = on_release
        self._device_path = device_path
        self._devices: list[InputDevice] = []
        self._tasks: list[asyncio.Task] = []
        self.last_trigger_ts: float = 0.0

    # -- backward-compat properties (tests set listener._device = mock) --

    @property
    def _device(self) -> InputDevice | None:
        return self._devices[0] if self._devices else None

    @_device.setter
    def _device(self, value: InputDevice | None) -> None:
        if value is None:
            self._devices = []
        else:
            self._devices = [value]

    @property
    def _task(self) -> asyncio.Task | None:
        return self._tasks[0] if self._tasks else None

    @_task.setter
    def _task(self, value: asyncio.Task | None) -> None:
        if value is None:
            self._tasks = []
        else:
            self._tasks = [value]

    @staticmethod
    def _find_all_devices_with_key(key_code: int) -> list[str]:
        """Find ALL devices that have the required key."""
        paths: list[str] = []
        for path in sorted(glob.glob("/dev/input/event*")):
            try:
                dev = InputDevice(path)
                caps = dev.capabilities()
                keys = caps.get(ecodes.EV_KEY, [])
                if key_code in keys:
                    logger.debug("Hotkey device: %s (%s)", path, dev.name)
                    paths.append(path)
                dev.close()
            except (PermissionError, OSError):
                continue
        if not paths:
            raise RuntimeError(
                f"No keyboard device found with key {ecodes.KEY.get(key_code, key_code)}"
            )
        return paths

    @staticmethod
    def _find_device_with_key(key_code: int) -> str:
        """Find the first device that has the required key."""
        return HotkeyListener._find_all_devices_with_key(key_code)[0]

    async def _event_loop(self, device: InputDevice | None = None) -> None:
        dev = device or (self._devices[0] if self._devices else None)
        if dev is None:
            raise RuntimeError("Cannot run event loop without a device; call start() first")
        try:
            async for event in dev.async_read_loop():
                if event.type != ecodes.EV_KEY:
                    continue
                if event.code != self._key_code:
                    continue
                if event.value == 1:  # key down
                    self.last_trigger_ts = time.perf_counter()
                    await self._on_press()
                elif event.value == 0:  # key up
                    await self._on_release()
                # value == 2 is key repeat — ignore
        except OSError as e:
            logger.error("Keyboard device disconnected: %s", e)

    async def start(self) -> None:
        if self._device_path:
            # Explicit single device
            dev = InputDevice(self._device_path)
            self._devices = [dev]
            self._tasks = [asyncio.create_task(self._event_loop(dev))]
        else:
            # Monitor ALL matching keyboards
            paths = self._find_all_devices_with_key(self._key_code)
            for path in paths:
                dev = InputDevice(path)
                self._devices.append(dev)
                self._tasks.append(asyncio.create_task(self._event_loop(dev)))
            if len(paths) > 1:
                logger.info("Monitoring %d keyboard devices for hotkey", len(paths))
        # NO grab -- passive reading so other apps still receive keys

    async def stop(self) -> None:
        for task in self._tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._tasks = []
        for dev in self._devices:
            dev.close()
        self._devices = []
