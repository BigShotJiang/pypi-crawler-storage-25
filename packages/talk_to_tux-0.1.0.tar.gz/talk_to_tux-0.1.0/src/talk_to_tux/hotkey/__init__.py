from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class InputListener(Protocol):
    """Protocol for input trigger listeners (keyboard hotkey, mouse chord, etc.)."""

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
