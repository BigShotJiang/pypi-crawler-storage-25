"""Passive Ctrl+Super keyboard chord listener via evdev."""
from __future__ import annotations

import asyncio
import glob
import logging
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable

from evdev import InputDevice, ecodes

logger = logging.getLogger(__name__)


@dataclass
class _ChordDeviceState:
    """Per-device chord tracking — prevents cross-keyboard phantom chords."""
    a_held: bool = False
    b_held: bool = False
    a_down_time: float | None = None
    b_down_time: float | None = None


class KeyboardChordListener:
    """Detects Ctrl+Super keyboard chord and triggers recording.

    Uses passive evdev reading (no grab) — avoids capturing all keyboard input.
    Note: Super key may briefly trigger GNOME Activities overlay.  To suppress,
    run: gsettings set org.gnome.mutter overlay-key ''
    """

    def __init__(
        self,
        on_start: Callable[[], Awaitable[None]],
        on_stop: Callable[[], Awaitable[None]],
        mode: str = "hold",
        chord_timeout: float = 0.15,
        debounce: float = 0.3,
        device_path: str | None = None,
        key_a: int = ecodes.KEY_LEFTCTRL,
        key_b: int = ecodes.KEY_LEFTMETA,
    ) -> None:
        self._on_start = on_start
        self._on_stop = on_stop
        self._mode = mode
        self._chord_timeout = chord_timeout
        self._debounce = debounce
        self._key_a = key_a
        self._key_b = key_b
        # Resolve device paths eagerly so callers can catch RuntimeError
        if device_path:
            self._device_paths: list[str] = [device_path]
        else:
            self._device_paths = self._find_all_devices_with_keys(key_a, key_b)

        self._devices: list[InputDevice] = []
        self._tasks: list[asyncio.Task] = []

        # Shared state (one recording at a time, any keyboard can trigger)
        self._recording: bool = False
        self._last_chord_time: float = 0.0

    # -- backward-compat properties --

    @property
    def _device_path(self) -> str:
        return self._device_paths[0] if self._device_paths else ""

    @_device_path.setter
    def _device_path(self, value: str) -> None:
        self._device_paths = [value]

    @property
    def _device(self) -> InputDevice | None:
        return self._devices[0] if self._devices else None

    @_device.setter
    def _device(self, value: InputDevice | None) -> None:
        if value is None:
            self._devices = []
        else:
            self._devices = [value]

    @property
    def _task(self) -> asyncio.Task | None:
        return self._tasks[0] if self._tasks else None

    @_task.setter
    def _task(self, value: asyncio.Task | None) -> None:
        if value is None:
            self._tasks = []
        else:
            self._tasks = [value]

    @staticmethod
    def _find_all_devices_with_keys(key_a: int, key_b: int) -> list[str]:
        """Find ALL devices that have both chord keys."""
        paths: list[str] = []
        for path in sorted(glob.glob("/dev/input/event*")):
            try:
                dev = InputDevice(path)
                caps = dev.capabilities()
                keys = caps.get(ecodes.EV_KEY, [])
                if key_a in keys and key_b in keys:
                    logger.debug("Chord device: %s (%s)", path, dev.name)
                    paths.append(path)
                dev.close()
            except (PermissionError, OSError):
                continue
        if not paths:
            raise RuntimeError(
                f"No keyboard device found with keys "
                f"{ecodes.KEY.get(key_a, key_a)} + {ecodes.KEY.get(key_b, key_b)}"
            )
        return paths

    @staticmethod
    def _find_device_with_keys(key_a: int, key_b: int) -> str:
        """Find the first device that has both chord keys."""
        return KeyboardChordListener._find_all_devices_with_keys(key_a, key_b)[0]

    async def _event_loop(self, device: InputDevice | None = None, state: _ChordDeviceState | None = None) -> None:
        dev = device or (self._devices[0] if self._devices else None)
        if dev is None:
            raise RuntimeError("Cannot run event loop without a device; call start() first")
        st = state or _ChordDeviceState()
        try:
            async for event in dev.async_read_loop():
                if event.type != ecodes.EV_KEY:
                    continue
                if event.code not in (self._key_a, self._key_b):
                    continue

                now = time.monotonic()

                if event.value == 1:  # key down
                    if event.code == self._key_a:
                        st.a_down_time = now
                        st.a_held = True
                    else:
                        st.b_down_time = now
                        st.b_held = True

                    # Check for chord: other key pressed within timeout
                    chord = False
                    if event.code == self._key_a and st.b_down_time is not None:
                        if now - st.b_down_time <= self._chord_timeout:
                            chord = True
                    elif event.code == self._key_b and st.a_down_time is not None:
                        if now - st.a_down_time <= self._chord_timeout:
                            chord = True

                    if chord:
                        if now - self._last_chord_time > self._debounce:
                            logger.debug(
                                "Keyboard chord detected (A=%.3f B=%.3f gap=%.3fms)",
                                st.a_down_time or 0,
                                st.b_down_time or 0,
                                abs((st.a_down_time or 0) - (st.b_down_time or 0)) * 1000,
                            )
                            self._last_chord_time = now
                            st.a_down_time = None
                            st.b_down_time = None
                            await self._handle_chord()
                        else:
                            logger.debug(
                                "Keyboard chord suppressed by debounce (%.0fms since last)",
                                (now - self._last_chord_time) * 1000,
                            )

                elif event.value == 0:  # key up
                    if event.code == self._key_a:
                        st.a_held = False
                    else:
                        st.b_held = False

                    # Hold mode: stop only when BOTH keys are released
                    if (
                        self._mode == "hold"
                        and self._recording
                        and not st.a_held
                        and not st.b_held
                    ):
                        self._recording = False
                        await self._on_stop()
        except OSError as e:
            logger.error("Keyboard device disconnected: %s", e)

    async def _handle_chord(self) -> None:
        if self._mode == "toggle":
            if not self._recording:
                self._recording = True
                await self._on_start()
            else:
                self._recording = False
                await self._on_stop()
        else:  # hold
            self._recording = True
            await self._on_start()

    def set_debounce(self, seconds: float) -> None:
        """Change the debounce interval."""
        self._debounce = seconds

    async def start(self) -> None:
        # NO grab -- passive reading (grab would capture all keyboard input)
        for path in self._device_paths:
            dev = InputDevice(path)
            st = _ChordDeviceState()
            self._devices.append(dev)
            self._tasks.append(asyncio.create_task(self._event_loop(dev, st)))
        if len(self._device_paths) > 1:
            logger.info("Monitoring %d keyboard devices for chord", len(self._device_paths))

    async def stop(self) -> None:
        for task in self._tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._tasks = []
        for dev in self._devices:
            dev.close()
        self._devices = []
