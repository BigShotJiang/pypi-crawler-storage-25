"""GTK3 rewrite tooltip popup for confirmation flow."""
from __future__ import annotations

import logging
from typing import Callable

logger = logging.getLogger(__name__)


def _import_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, Gtk
    return Gtk, Gdk


class RewriteTooltip:
    """Undecorated popup window showing rewrite options near the mouse cursor."""

    def __init__(
        self,
        on_dismiss: Callable[[], None],
        on_row_clicked: Callable[[int, str], None] | None = None,
        on_fire_edited: Callable[[str], None] | None = None,
        on_cancel_auto_dismiss: Callable[[], None] | None = None,
        on_edit_clicked: Callable[[], None] | None = None,
    ) -> None:
        Gtk, Gdk = _import_gtk()
        self._Gtk = Gtk
        self._Gdk = Gdk
        self._on_dismiss = on_dismiss
        self._on_row_clicked = on_row_clicked
        self._on_fire_edited = on_fire_edited
        self._on_cancel_auto_dismiss = on_cancel_auto_dismiss
        self._on_edit_clicked_cb = on_edit_clicked

        # Data: list of (text, label) options
        self._options: list[tuple[str, str]] = []
        self._text_labels: list = []  # track text labels for dynamic max_width_chars
        self._selected_index: int = 0

        # Edit mode state
        self._editing: bool = False
        self._textview = None
        self._edit_btn = None
        self._fire_btn = None
        self._button_bar = None

        # TOPLEVEL so the WM can grant focus when editing.
        # UTILITY type hint: stays above, no taskbar entry, WM provides title bar.
        self._window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        self._window.set_decorated(True)
        self._window.set_title("Talk-to-Tux")
        self._window.set_accept_focus(False)
        self._window.set_skip_taskbar_hint(True)
        self._window.set_skip_pager_hint(True)
        self._window.set_type_hint(Gdk.WindowTypeHint.UTILITY)
        self._window.set_keep_above(True)
        self._min_width = 400
        self._max_width = 800  # clamped to screen in _position_near_mouse
        self._window.set_default_size(self._min_width, -1)  # height auto

        # Main container
        self._vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self._vbox.set_margin_top(8)
        self._vbox.set_margin_bottom(8)
        self._vbox.set_margin_start(10)
        self._vbox.set_margin_end(10)

        # Status bar at top (shows recording/processing state)
        self._status_label = Gtk.Label()
        self._status_label.set_xalign(0)
        self._status_label.set_markup('<small><span foreground="#888">Processing...</span></small>')
        self._vbox.pack_start(self._status_label, False, False, 0)

        # Scrollable list of rewrite options
        self._scrolled = Gtk.ScrolledWindow()
        self._scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._scrolled.set_max_content_height(600)
        self._scrolled.set_propagate_natural_height(True)

        self._listbox = Gtk.ListBox()
        self._listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self._listbox.set_activate_on_single_click(True)
        self._listbox.connect("row-selected", self._on_row_selected)
        self._listbox.connect("row-activated", self._on_row_activated)
        self._scrolled.add(self._listbox)
        self._vbox.pack_start(self._scrolled, True, True, 0)

        # Button bar (hidden by default, shown in post-paste mode)
        self._button_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self._edit_btn = Gtk.Button(label="Edit")
        self._edit_btn.get_style_context().add_class("tooltip-btn")
        self._edit_btn.connect("clicked", lambda _: self._on_edit_clicked())
        self._button_bar.pack_start(self._edit_btn, False, False, 0)
        self._fire_btn = Gtk.Button(label="\u25b6")
        self._fire_btn.get_style_context().add_class("tooltip-fire-btn")
        self._fire_btn.connect("clicked", lambda _: self._on_fire_clicked())
        self._fire_btn.set_no_show_all(True)  # hidden until edit mode
        self._button_bar.pack_end(self._fire_btn, False, False, 0)
        self._button_bar.set_no_show_all(True)  # hidden by default
        self._vbox.pack_start(self._button_bar, False, False, 0)

        # Hint label at bottom
        self._hint_label = Gtk.Label()
        self._hint_label.set_xalign(0)
        self._hint_label.set_markup(
            '<small><span foreground="#888">Click to paste | Tap trigger for Enter | Esc to dismiss</span></small>'
        )
        self._vbox.pack_start(self._hint_label, False, False, 0)

        self._window.add(self._vbox)

        # Connect key events for Escape dismiss
        self._window.connect("key-press-event", self._on_key_press)


        # Apply minimal CSS for tooltip appearance
        self._apply_style()

    def _calc_width(self, text: str) -> int:
        """Calculate preferred width from longest line in text."""
        longest_line = max((len(line) for line in text.splitlines()), default=0)
        # ~8px per char + padding for margins/borders
        return max(self._min_width, min(int(longest_line * 8) + 40, self._max_width))

    def _apply_style(self) -> None:
        Gtk = self._Gtk
        css = b"""
        window {
            background-color: #2d2d2d;
            border: 1px solid #555;
            border-radius: 6px;
        }
        label {
            color: #eee;
        }
        .option-row {
            padding: 4px 6px;
            border-radius: 4px;
        }
        .option-row:selected {
            background-color: #3a6ea5;
        }
        textview, textview text {
            background-color: #383838;
            color: #eee;
        }
        .tooltip-btn {
            background-image: none;
            background-color: #505050;
            color: #ffffff;
            border: 1px solid #888;
            border-radius: 4px;
            padding: 4px 12px;
            min-height: 26px;
            font-weight: bold;
        }
        .tooltip-btn:hover {
            background-color: #666;
        }
        .tooltip-fire-btn {
            background-image: none;
            background-color: #3a6ea5;
            color: #ffffff;
            border: 1px solid #5a9ed6;
            border-radius: 4px;
            padding: 4px 12px;
            min-height: 26px;
            font-weight: bold;
        }
        .tooltip-fire-btn:hover {
            background-color: #4a8ec5;
        }
        """
        try:
            provider = Gtk.CssProvider()
            provider.load_from_data(css)
            screen = self._Gdk.Screen.get_default()
            if screen is not None:
                # Use USER priority to override GTK theme
                Gtk.StyleContext.add_provider_for_screen(
                    screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_USER
                )
        except Exception:
            logger.debug("Failed to apply tooltip CSS", exc_info=True)

    def _on_key_press(self, _widget, event) -> bool:
        if event.keyval == self._Gdk.KEY_Escape:
            self.close()
            self._on_dismiss()
            return True
        return False


    # --- Post-paste edit mode ---

    def enter_post_paste_mode(self) -> None:
        """Show the Edit button and update hint for post-paste state."""
        if self._button_bar is not None:
            self._button_bar.set_no_show_all(False)
            self._button_bar.show_all()
            # Keep fire button hidden until edit mode
            if self._fire_btn is not None:
                self._fire_btn.hide()
        self._hint_label.set_markup(
            '<small><span foreground="#888">Edit to modify | Esc to dismiss</span></small>'
        )

    def enter_edit_mode_directly(self) -> None:
        """Skip display mode — open directly in editable textview with Fire button."""
        # Show button bar first (needed for _on_edit_clicked to show fire btn)
        if self._button_bar is not None:
            self._button_bar.set_no_show_all(False)
            self._button_bar.show_all()
        self._on_edit_clicked()

    def _on_edit_clicked(self) -> None:
        """Switch from listbox display to editable TextView."""
        if self._editing or not self._options:
            return
        # Notify indicator to capture screenshot before edit mode switch
        if self._on_edit_clicked_cb is not None:
            self._on_edit_clicked_cb()
        self._editing = True

        Gtk = self._Gtk
        text = self._options[0][0]

        # Remove listbox from scrolled window, add a TextView
        self._scrolled.remove(self._listbox)
        self._textview = Gtk.TextView()
        self._textview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        buf = self._textview.get_buffer()
        buf.set_text(text)
        self._scrolled.add(self._textview)
        self._textview.show()

        # Enable focus so the user can type into the textview
        self._window.set_accept_focus(True)
        self._window.present()
        self._textview.grab_focus()

        # Show fire button, hide edit button
        if self._fire_btn is not None:
            self._fire_btn.show()
        if self._edit_btn is not None:
            self._edit_btn.hide()

        self._hint_label.set_markup(
            '<small><span foreground="#888">Click \u25b6 to replace | Esc to cancel</span></small>'
        )

        # Cancel auto-dismiss while editing
        if self._on_cancel_auto_dismiss is not None:
            self._on_cancel_auto_dismiss()

    def _on_fire_clicked(self) -> None:
        """Fire the edited text back to the app for replacement paste."""
        if not self._editing or self._textview is None:
            return
        buf = self._textview.get_buffer()
        start, end = buf.get_bounds()
        text = buf.get_text(start, end, True)
        # NOTE: screenshot is captured by IndicatorController._on_tooltip_fire_edited()
        # using bbox-aware path *before* close() destroys the window.
        if self._on_fire_edited is not None:
            self._on_fire_edited(text)

    def get_edited_text(self) -> str | None:
        """Return textview content if editing, else None."""
        if not self._editing or self._textview is None:
            return None
        buf = self._textview.get_buffer()
        start, end = buf.get_bounds()
        return buf.get_text(start, end, True)

    def _on_row_activated(self, _listbox, row) -> None:
        """Handle single-click activation on a tooltip row to paste."""
        if self._on_row_clicked is None or row is None:
            return
        idx = row.get_index()
        if idx < len(self._options):
            self._on_row_clicked(idx, self._options[idx][0])

    def _on_row_selected(self, _listbox, row) -> None:
        if row is not None:
            self._selected_index = row.get_index()

    def set_status(self, text: str) -> None:
        """Update the status label (e.g. 'Recording...', 'Processing...')."""
        self._status_label.set_markup(f'<small><span foreground="#888">{text}</span></small>')

    def add_option(self, text: str, label: str) -> int:
        """Add a rewrite option. Returns its index."""
        Gtk = self._Gtk
        idx = len(self._options)
        self._options.append((text, label))

        row_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        row_box.set_margin_top(3)
        row_box.set_margin_bottom(3)
        row_box.set_margin_start(4)
        row_box.set_margin_end(4)

        # Context label (dim, small)
        if label:
            ctx_label = Gtk.Label()
            ctx_label.set_xalign(0)
            ctx_label.set_markup(f'<small><span foreground="#aaa">{label}</span></small>')
            row_box.pack_start(ctx_label, False, False, 0)

        # Full text (line-wrapped)
        text_label = Gtk.Label(label=text)
        text_label.set_xalign(0)
        text_label.set_line_wrap(True)
        try:
            from gi.repository import Pango
            text_label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        except Exception:
            pass
        self._text_labels.append(text_label)
        row_box.pack_start(text_label, False, False, 0)

        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("option-row")
        row.add(row_box)
        self._listbox.add(row)

        # Select first option by default
        if idx == 0:
            self._listbox.select_row(row)
            self._selected_index = 0

        # Recalculate window width from widest option; let height be natural
        widest = max(self._calc_width(t) for t, _ in self._options)
        # Update all text labels to wrap at the window's available width
        # ~60px total for window margins(10*2) + row margins(4*2) + listbox padding(~12)
        available_chars = max(50, (widest - 60) // 8)
        for tl in self._text_labels:
            tl.set_max_width_chars(available_chars)
        self._window.set_size_request(widest, -1)
        self._window.queue_resize()

        # Show new row if window is visible
        row.show_all()
        return idx

    def update_primary_text(self, text: str) -> None:
        """Update the primary (first) option text in-place for streaming."""
        if self._options and self._text_labels:
            self._options[0] = (text, self._options[0][1])
            self._text_labels[0].set_text(text)

    def get_selected(self) -> tuple[int, str] | None:
        """Return (index, text) of the selected option, or None if empty."""
        if not self._options:
            return None
        if self._selected_index < len(self._options):
            return (self._selected_index, self._options[self._selected_index][0])
        return None

    def show(self) -> None:
        """Position near mouse and show the tooltip."""
        self._position_near_mouse()
        self._window.show_all()

    def _position_near_mouse(self) -> None:
        """Place the tooltip to the right of the cursor, falling back to left."""
        try:
            display = self._Gdk.Display.get_default()
            if display is None:
                return
            seat = display.get_default_seat()
            if seat is None:
                return
            pointer = seat.get_pointer()
            if pointer is None:
                return
            _, x, y = pointer.get_position()

            screen = self._Gdk.Screen.get_default()
            if screen is None:
                return

            # Use actual preferred width instead of hardcoded value
            preferred = self._window.get_preferred_width()
            tooltip_width = preferred.natural_width if hasattr(preferred, 'natural_width') and preferred.natural_width > 0 else self._min_width
            screen_width = screen.get_width()
            tooltip_width = min(tooltip_width, screen_width - 30)  # screen edge guard
            gap = 15

            # Prefer right of cursor; fall back to left if near right edge
            if x + gap + tooltip_width < screen_width:
                pos_x = x + gap
            else:
                pos_x = max(0, x - gap - tooltip_width)

            # Slightly above cursor
            pos_y = max(0, y - 20)
            self._window.move(pos_x, pos_y)
        except Exception:
            logger.debug("Failed to position tooltip near mouse", exc_info=True)

    def hide(self) -> None:
        """Hide the tooltip window (does not destroy)."""
        try:
            self._window.hide()
        except Exception:
            pass

    def close(self) -> None:
        """Hide and destroy the tooltip window."""
        try:
            self._window.hide()
            self._window.destroy()
        except Exception:
            pass
