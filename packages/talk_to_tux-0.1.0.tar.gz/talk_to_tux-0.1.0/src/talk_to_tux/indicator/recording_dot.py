"""Tiny recording indicator dot shown near the cursor during recording.

On Wayland: uses the Talk-to-Tux GNOME Shell extension via D-Bus
  (cursor-following overlay rendered by the compositor).
On X11: uses a GTK popup window positioned near the cursor.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess

logger = logging.getLogger(__name__)

_EXTENSION_UUID = "talk-to-tux-overlay@talk-to-tux"
_DBUS_DEST = "org.gnome.shell.extensions.TalkToTux"
_DBUS_PATH = "/org/gnome/shell/extensions/TalkToTux"
_DBUS_IFACE = "org.gnome.shell.extensions.TalkToTux"

# Must match metadata.json "version" — triggers upgrade when bundled > installed.
_BUNDLED_VERSION = 5

# Cached at first RecordingDot creation — avoids repeated subprocess calls.
_dbus_mode: bool | None = None


def _is_wayland() -> bool:
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def _extension_installed() -> bool:
    """Check if the GNOME Shell extension is installed."""
    ext_dir = os.path.expanduser(
        f"~/.local/share/gnome-shell/extensions/{_EXTENSION_UUID}"
    )
    return os.path.isdir(ext_dir)


def _installed_version(ext_dir: str) -> int:
    """Read the installed extension version from metadata.json.

    Returns 0 if metadata.json is missing or unparseable.
    """
    import json
    meta_path = os.path.join(ext_dir, "metadata.json")
    try:
        with open(meta_path) as f:
            return int(json.load(f).get("version", 0))
    except Exception:
        return 0


def install_extension() -> bool:
    """Install or upgrade the GNOME Shell extension from bundled data.

    Returns True if installed/up-to-date, False on failure.
    """
    ext_dir = os.path.expanduser(
        f"~/.local/share/gnome-shell/extensions/{_EXTENSION_UUID}"
    )
    if os.path.isdir(ext_dir):
        installed = _installed_version(ext_dir)
        if installed >= _BUNDLED_VERSION:
            return True
        logger.info(
            "Upgrading GNOME Shell extension from v%d to v%d",
            installed, _BUNDLED_VERSION,
        )

    try:
        import importlib.resources as pkg_resources
        src_dir = pkg_resources.files("talk_to_tux.data") / "gnome-extension"
        os.makedirs(ext_dir, exist_ok=True)
        for name in ("extension.js", "metadata.json"):
            src_file = src_dir / name
            dst_file = os.path.join(ext_dir, name)
            with pkg_resources.as_file(src_file) as src_path:
                shutil.copy2(str(src_path), dst_file)
        logger.info("Installed GNOME Shell extension to %s", ext_dir)
        # Attempt to enable — won't take effect until Shell restarts,
        # but saves the user a manual CLI step.
        try:
            subprocess.run(
                ["gnome-extensions", "enable", _EXTENSION_UUID],
                capture_output=True, timeout=5,
            )
            logger.info(
                "Enabled extension %s — restart GNOME Shell (log out/in) to activate",
                _EXTENSION_UUID,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            logger.info(
                "Enable with: gnome-extensions enable %s  "
                "(then restart GNOME Shell: log out/in)",
                _EXTENSION_UUID,
            )
        return True
    except Exception:
        logger.debug("Failed to install GNOME Shell extension", exc_info=True)
        return False


def _extension_dbus_available() -> bool:
    """Check if the extension's D-Bus interface is reachable."""
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", _DBUS_DEST,
                "--object-path", _DBUS_PATH,
                "--method", "org.freedesktop.DBus.Peer.Ping",
            ],
            capture_output=True, timeout=1,
        )
        return result.returncode == 0
    except Exception:
        return False


def _import_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, GLib, Gtk
    return Gtk, Gdk, GLib


def cleanup_stale_overlay() -> None:
    """Send Hide to the extension D-Bus to clear any stale overlay from a previous crash."""
    if not _is_wayland():
        return
    try:
        subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", _DBUS_DEST,
                "--object-path", _DBUS_PATH,
                "--method", f"{_DBUS_IFACE}.Hide",
            ],
            capture_output=True, timeout=2,
        )
    except Exception:
        pass


class RecordingDot:
    """Tiny overlay showing recording state near the mouse cursor.

    On Wayland: delegates to GNOME Shell extension via D-Bus.
    On X11: GTK popup window that follows the cursor at 50ms intervals.
    """

    def __init__(self) -> None:
        global _dbus_mode
        if _dbus_mode is None:
            cleanup_stale_overlay()
            # Always try to install/upgrade the extension on Wayland
            if _is_wayland():
                install_extension()
            _dbus_mode = _is_wayland() and _extension_dbus_available()
            if _dbus_mode:
                import atexit
                atexit.register(cleanup_stale_overlay)
                logger.info("RecordingDot: using GNOME Shell extension (D-Bus)")
            elif _is_wayland() and not _extension_installed():
                logger.warning(
                    "Recording dot overlay requires the GNOME Shell extension. "
                    "Run: gnome-extensions enable %s  then restart Shell.",
                    _EXTENSION_UUID,
                )

        self._use_dbus = _dbus_mode

        self._keepalive_source_id: int | None = None

        if self._use_dbus:
            self._window = None
        else:
            Gtk, Gdk, GLib = _import_gtk()
            self._Gtk = Gtk
            self._Gdk = Gdk
            self._GLib = GLib

            self._window = Gtk.Window(type=Gtk.WindowType.POPUP)
            self._window.set_decorated(False)
            self._window.set_accept_focus(False)
            self._window.set_type_hint(Gdk.WindowTypeHint.TOOLTIP)
            self._window.set_keep_above(True)
            self._window.set_skip_taskbar_hint(True)
            self._window.set_skip_pager_hint(True)

            self._label = Gtk.Label()
            self._label.set_markup(
                '<span font="18" foreground="#e53e3e">\u23fa</span>'
            )
            self._window.add(self._label)

            self._apply_css()
            self._pulse_source_id: int | None = None
            self._follow_source_id: int | None = None
            self._pulse_bright = True

    def _apply_css(self) -> None:
        css = b"""
        .recording-dot-window {
            background-color: rgba(30, 30, 30, 0.85);
            border-radius: 20px;
            padding: 4px 8px;
        }
        """
        try:
            provider = self._Gtk.CssProvider()
            provider.load_from_data(css)
            self._window.get_style_context().add_class("recording-dot-window")
            self._window.get_style_context().add_provider(
                provider, self._Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
            )
        except Exception:
            logger.debug("Failed to apply recording dot CSS", exc_info=True)

    # -- D-Bus helpers (Wayland / GNOME Shell extension) -------------------

    def _dbus_call(self, method: str, *args: str) -> None:
        """Fire-and-forget D-Bus method call to the extension."""
        cmd = [
            "gdbus", "call", "--session",
            "--dest", _DBUS_DEST,
            "--object-path", _DBUS_PATH,
            "--method", f"{_DBUS_IFACE}.{method}",
            *args,
        ]
        try:
            subprocess.Popen(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except Exception:
            logger.debug("D-Bus call %s failed", method, exc_info=True)

    # -- Public API --------------------------------------------------------

    def show(self) -> None:
        """Show recording indicator near the cursor."""
        import time as _time
        logger.info("RecordingDot.show() called at perf_counter=%.3f", _time.perf_counter())
        if self._use_dbus:
            self._dbus_call("Show", "recording")
            self._start_keepalive()
            return

        if self._window is None:
            return
        self._position_near_mouse()
        self._window.show_all()
        self._pulse_source_id = self._GLib.timeout_add(750, self._pulse_tick)
        self._follow_source_id = self._GLib.timeout_add(50, self._follow_tick)

    def _start_keepalive(self) -> None:
        """Start a 3s GLib timer that sends Keepalive() to the extension."""
        self._stop_keepalive()
        try:
            from gi.repository import GLib
            self._keepalive_source_id = GLib.timeout_add_seconds(
                3, self._keepalive_tick,
            )
        except Exception:
            logger.debug("Failed to start keepalive timer", exc_info=True)

    def _stop_keepalive(self) -> None:
        if self._keepalive_source_id is not None:
            try:
                from gi.repository import GLib
                GLib.source_remove(self._keepalive_source_id)
            except Exception:
                pass
            self._keepalive_source_id = None

    def _keepalive_tick(self) -> bool:
        self._dbus_call("Keepalive")
        return True  # GLib.SOURCE_CONTINUE

    def set_processing(self) -> None:
        """Switch from recording to processing/thinking appearance."""
        if self._use_dbus:
            self._stop_keepalive()
            self._dbus_call("Show", "processing")
            return

        if self._window is None:
            return
        self._label.set_opacity(1.0)
        self._label.set_markup(
            '<span font="18" foreground="#f6ad55">\u23f3</span>'
        )
        if self._pulse_source_id is not None:
            self._GLib.source_remove(self._pulse_source_id)
            self._pulse_source_id = None

    def close(self) -> None:
        """Hide and destroy the indicator."""
        if self._use_dbus:
            self._stop_keepalive()
            self._dbus_call("Hide")
            return

        if self._window is None:
            return
        if hasattr(self, '_pulse_source_id') and self._pulse_source_id is not None:
            self._GLib.source_remove(self._pulse_source_id)
            self._pulse_source_id = None
        if hasattr(self, '_follow_source_id') and self._follow_source_id is not None:
            self._GLib.source_remove(self._follow_source_id)
            self._follow_source_id = None
        try:
            self._window.hide()
            self._window.destroy()
        except Exception:
            pass

    # -- X11 GTK popup helpers ---------------------------------------------

    def _pulse_tick(self) -> bool:
        self._pulse_bright = not self._pulse_bright
        self._label.set_opacity(1.0 if self._pulse_bright else 0.35)
        return True

    def _follow_tick(self) -> bool:
        self._position_near_mouse()
        return True

    def _position_near_mouse(self) -> None:
        try:
            display = self._Gdk.Display.get_default()
            if display is None:
                return
            seat = display.get_default_seat()
            if seat is None:
                return
            pointer = seat.get_pointer()
            if pointer is None:
                return
            _, x, y = pointer.get_position()
            self._window.move(x + 16, y + 16)
        except Exception:
            logger.debug("Failed to position recording dot", exc_info=True)
