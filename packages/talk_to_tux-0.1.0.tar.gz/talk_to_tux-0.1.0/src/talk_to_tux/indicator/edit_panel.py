"""GTK3 edit panel anchored to bottom-right of screen.

Opened when user clicks Edit on a notification toast.  Provides a
multi-line text editor with Cancel / Fire buttons.
"""
from __future__ import annotations

import logging
from typing import Callable

logger = logging.getLogger(__name__)


def _import_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, GLib, Gtk
    return Gtk, Gdk, GLib


class EditPanel:
    """Fixed-position edit window at bottom-right of the screen.

    Styled to match RecordingDot / WarningTooltip (dark semi-transparent).
    """

    def __init__(
        self,
        text: str,
        target_label: str,
        on_fire: Callable[[str], None],
        on_cancel: Callable[[], None],
    ) -> None:
        Gtk, Gdk, GLib = _import_gtk()
        self._Gtk = Gtk
        self._Gdk = Gdk
        self._GLib = GLib
        self._on_fire = on_fire
        self._on_cancel = on_cancel

        self._window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        self._window.set_title("Talk-to-Tux Edit")
        self._window.set_default_size(420, -1)
        self._window.set_decorated(False)
        self._window.set_accept_focus(True)
        self._window.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self._window.set_keep_above(True)
        self._window.set_skip_taskbar_hint(True)
        self._window.set_skip_pager_hint(True)
        self._window.connect("key-press-event", self._on_key_press)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        vbox.set_margin_top(12)
        vbox.set_margin_bottom(12)
        vbox.set_margin_start(14)
        vbox.set_margin_end(14)

        # Header: target app label
        header = Gtk.Label()
        header.set_xalign(0)
        safe_label = GLib.markup_escape_text(target_label or "Unknown")
        header.set_markup(
            f'<span foreground="#80b0ff"><b>Target:</b> {safe_label}</span>'
        )
        vbox.pack_start(header, False, False, 0)

        # Text editor
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(80)
        scrolled.set_max_content_height(300)

        self._textview = Gtk.TextView()
        self._textview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self._textview.set_left_margin(6)
        self._textview.set_right_margin(6)
        self._textview.set_top_margin(4)
        self._textview.set_bottom_margin(4)
        self._textview.get_buffer().set_text(text)
        scrolled.add(self._textview)
        vbox.pack_start(scrolled, True, True, 0)

        # Button bar
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_box.set_halign(Gtk.Align.END)

        cancel_btn = Gtk.Button(label="Cancel")
        cancel_btn.connect("clicked", self._on_cancel_clicked)
        btn_box.pack_start(cancel_btn, False, False, 0)

        fire_btn = Gtk.Button(label="Fire")
        fire_btn.connect("clicked", self._on_fire_clicked)
        btn_box.pack_start(fire_btn, False, False, 0)

        vbox.pack_start(btn_box, False, False, 0)

        self._window.add(vbox)
        self._apply_style()

    def _apply_style(self) -> None:
        Gtk = self._Gtk
        css = b"""
        window {
            background-color: #1e1e2e;
            border: 1px solid #444466;
            border-radius: 8px;
        }
        label {
            color: #d0d0d0;
        }
        textview text {
            background-color: #2a2a3e;
            color: #e0e0e0;
        }
        button {
            background: #3a3a5e;
            color: #d0d0d0;
            border: 1px solid #555577;
            border-radius: 4px;
            padding: 4px 14px;
        }
        button:hover {
            background: #4a4a6e;
        }
        """
        try:
            provider = Gtk.CssProvider()
            provider.load_from_data(css)
            screen = self._Gdk.Screen.get_default()
            if screen is not None:
                Gtk.StyleContext.add_provider_for_screen(
                    screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
                )
        except Exception:
            logger.debug("Failed to apply edit panel CSS", exc_info=True)

    def _position_bottom_right(self) -> None:
        """Anchor to bottom-right of the primary monitor."""
        try:
            screen = self._Gdk.Screen.get_default()
            if screen is None:
                return
            panel_width = 420
            screen_width = screen.get_width()
            screen_height = screen.get_height()
            margin = 20
            pos_x = screen_width - panel_width - margin
            pos_y = screen_height - 300 - margin  # rough estimate
            self._window.move(pos_x, pos_y)
        except Exception:
            logger.debug("Failed to position edit panel", exc_info=True)

    def show(self) -> None:
        """Position and show the edit panel."""
        self._position_bottom_right()
        self._window.show_all()
        self._window.present()  # Force raise + focus on Wayland/Mutter
        # Focus the text view for immediate editing
        self._textview.grab_focus()

    def get_text(self) -> str:
        """Return the current text in the editor."""
        buf = self._textview.get_buffer()
        return buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)

    def close(self) -> None:
        """Hide and destroy the panel."""
        try:
            self._window.hide()
            self._window.destroy()
        except Exception:
            pass

    # --- Event handlers ---

    def _on_key_press(self, _widget, event) -> bool:
        if event.keyval == self._Gdk.KEY_Escape:
            self._on_cancel()
            self.close()
            return True
        return False

    def _on_fire_clicked(self, _btn) -> None:
        text = self.get_text()
        self.close()
        self._on_fire(text)

    def _on_cancel_clicked(self, _btn) -> None:
        self.close()
        self._on_cancel()
