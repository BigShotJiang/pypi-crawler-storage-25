"""GTK3 warning tooltip popup for cursor validation failures."""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def _import_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, GLib, Gtk
    return Gtk, Gdk, GLib


class WarningTooltip:
    """Red/orange-accented popup shown when cursor is not over a typeable widget."""

    def __init__(self, auto_dismiss_ms: int = 3500, on_click=None) -> None:
        Gtk, Gdk, GLib = _import_gtk()
        self._Gtk = Gtk
        self._Gdk = Gdk
        self._GLib = GLib
        self._auto_dismiss_ms = auto_dismiss_ms
        self._on_click = on_click
        self._dismiss_source_id: int | None = None

        self._window = Gtk.Window(type=Gtk.WindowType.POPUP)
        self._window.set_decorated(False)
        self._window.set_accept_focus(False)
        self._window.set_type_hint(Gdk.WindowTypeHint.TOOLTIP)
        self._window.set_keep_above(True)
        self._window.set_default_size(360, -1)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vbox.set_margin_top(10)
        vbox.set_margin_bottom(10)
        vbox.set_margin_start(12)
        vbox.set_margin_end(12)

        # Warning icon + title
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        icon_label = Gtk.Label()
        icon_label.set_markup('<span font="16">\u26a0</span>')
        header.pack_start(icon_label, False, False, 0)

        self._title_label = Gtk.Label()
        self._title_label.set_xalign(0)
        self._title_label.set_markup(
            '<b><span foreground="#ff9060">Cannot type here</span></b>'
        )
        header.pack_start(self._title_label, True, True, 0)
        vbox.pack_start(header, False, False, 0)

        # Message label
        self._message_label = Gtk.Label()
        self._message_label.set_xalign(0)
        self._message_label.set_line_wrap(True)
        try:
            from gi.repository import Pango
            self._message_label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        except Exception:
            pass
        self._message_label.set_max_width_chars(45)
        vbox.pack_start(self._message_label, False, False, 0)

        # Hint text
        hint = Gtk.Label()
        hint.set_xalign(0)
        hint.set_markup(
            '<small><span foreground="#aa8060">Move cursor to a text field and try again</span></small>'
        )
        vbox.pack_start(hint, False, False, 0)

        self._window.add(vbox)
        if self._on_click is not None:
            self._window.set_events(Gdk.EventMask.BUTTON_PRESS_MASK)
            self._window.connect("button-press-event", self._on_window_click)
        self._apply_style()

    def _apply_style(self) -> None:
        Gtk = self._Gtk
        css = b"""
        window {
            background-color: #3d2020;
            border: 2px solid #e06040;
            border-radius: 6px;
        }
        label {
            color: #eee;
        }
        """
        try:
            provider = Gtk.CssProvider()
            provider.load_from_data(css)
            screen = self._Gdk.Screen.get_default()
            if screen is not None:
                Gtk.StyleContext.add_provider_for_screen(
                    screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
                )
        except Exception:
            logger.debug("Failed to apply warning tooltip CSS", exc_info=True)

    def show(self, message: str) -> None:
        """Position near mouse, set message, show, and auto-dismiss."""
        self._message_label.set_text(message)
        self._position_near_mouse()
        self._window.show_all()

        # Auto-dismiss
        if self._dismiss_source_id is not None:
            self._GLib.source_remove(self._dismiss_source_id)
        self._dismiss_source_id = self._GLib.timeout_add(
            self._auto_dismiss_ms, self._auto_dismiss
        )

    def _on_window_click(self, widget, event) -> bool:
        if self._on_click is not None:
            try:
                self._on_click()
            except Exception:
                logger.debug("WarningTooltip on_click raised", exc_info=True)
        self.close()
        return True

    def _auto_dismiss(self) -> bool:
        self._dismiss_source_id = None
        self.close()
        return False  # one-shot

    def _position_near_mouse(self) -> None:
        """Place near cursor, similar to RewriteTooltip positioning."""
        try:
            display = self._Gdk.Display.get_default()
            if display is None:
                return
            seat = display.get_default_seat()
            if seat is None:
                return
            pointer = seat.get_pointer()
            if pointer is None:
                return
            _, x, y = pointer.get_position()

            screen = self._Gdk.Screen.get_default()
            if screen is None:
                return

            tooltip_width = 360
            screen_width = screen.get_width()
            gap = 15

            if x + gap + tooltip_width < screen_width:
                pos_x = x + gap
            else:
                pos_x = max(0, x - gap - tooltip_width)

            pos_y = max(0, y - 20)
            self._window.move(pos_x, pos_y)
        except Exception:
            logger.debug("Failed to position warning tooltip", exc_info=True)

    def close(self) -> None:
        """Hide and destroy the warning tooltip."""
        if self._dismiss_source_id is not None:
            self._GLib.source_remove(self._dismiss_source_id)
            self._dismiss_source_id = None
        try:
            self._window.hide()
            self._window.destroy()
        except Exception:
            pass
