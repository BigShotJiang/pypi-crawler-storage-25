"""Persistent debug metadata window for pipeline inspection."""
from __future__ import annotations

import logging
from collections import OrderedDict

logger = logging.getLogger(__name__)


def _import_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, GLib, Gtk
    return Gtk, Gdk, GLib


class DebugTooltip:
    """Persistent TOPLEVEL window showing real-time pipeline metadata.

    Can be moved/resized/closed by the user. Hides instead of destroying
    on close — reused across runs.
    """

    # Section header colors for visual distinction
    _SECTION_COLORS: dict[str, str] = {
        "Trigger": "#80b0ff",
        "Window": "#80d0a0",
        "Widget": "#c0a060",
        "Screenshot": "#d080c0",
        "Terminal": "#a0c0d0",
        "STT": "#e0a070",
        "Rewrite": "#90c0e0",
        "Decision": "#d0a0a0",
        "Pipeline": "#80e0e0",
    }

    def __init__(self) -> None:
        Gtk, Gdk, GLib = _import_gtk()
        self._Gtk = Gtk
        self._Gdk = Gdk
        self._GLib = GLib

        self._window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        self._window.set_title("Talk-to-Tux Debug")
        self._window.set_default_size(380, 500)
        self._window.set_accept_focus(False)
        self._window.set_keep_above(True)
        self._window.connect("delete-event", self._on_delete)

        # Scrollable container
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self._vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self._vbox.set_margin_top(8)
        self._vbox.set_margin_bottom(8)
        self._vbox.set_margin_start(10)
        self._vbox.set_margin_end(10)

        scrolled.add(self._vbox)
        self._window.add(scrolled)

        # Track sections: name -> (header_label, content_label)
        self._sections: OrderedDict[str, tuple] = OrderedDict()

        self._apply_style()

    def _apply_style(self) -> None:
        Gtk = self._Gtk
        css = b"""
        window {
            background-color: #1a1a2e;
        }
        label {
            color: #d0d0d0;
            font-family: monospace;
            font-size: 11px;
        }
        """
        try:
            provider = Gtk.CssProvider()
            provider.load_from_data(css)
            screen = self._Gdk.Screen.get_default()
            if screen is not None:
                Gtk.StyleContext.add_provider_for_screen(
                    screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
                )
        except Exception:
            logger.debug("Failed to apply debug tooltip CSS", exc_info=True)

    def _position_top_right(self) -> None:
        """Position the window at the top-right of the screen, out of the way."""
        try:
            screen = self._Gdk.Screen.get_default()
            if screen is None:
                return

            tooltip_width = 380
            screen_width = screen.get_width()
            margin = 10

            pos_x = screen_width - tooltip_width - margin
            pos_y = margin

            self._window.move(pos_x, pos_y)
        except Exception:
            logger.debug("Failed to position debug tooltip", exc_info=True)

    def _on_delete(self, _widget, _event) -> bool:
        """Hide instead of destroy on window close."""
        self._window.hide()
        return True  # prevent actual destroy

    def update_section(self, name: str, content: str) -> None:
        """Create or update a named section."""
        if name in self._sections:
            _, content_label = self._sections[name]
            content_label.set_text(content)
        else:
            self._add_section(name, content)
        self._window.show_all()

    def _add_section(self, name: str, content: str) -> None:
        """Add a new section with header and content labels."""
        Gtk = self._Gtk

        # Separator (except for first section)
        if self._sections:
            sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            self._vbox.pack_start(sep, False, False, 2)

        color = self._SECTION_COLORS.get(name, "#a0a0c0")
        header = Gtk.Label()
        header.set_xalign(0)
        header.set_markup(f'<b><span foreground="{color}">{name}</span></b>')
        self._vbox.pack_start(header, False, False, 0)

        content_label = Gtk.Label(label=content)
        content_label.set_xalign(0)
        content_label.set_selectable(True)
        content_label.set_line_wrap(True)
        try:
            from gi.repository import Pango
            content_label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        except Exception:
            pass
        self._vbox.pack_start(content_label, False, False, 0)

        self._sections[name] = (header, content_label)

    def clear(self) -> None:
        """Remove all sections for a new pipeline run."""
        for child in self._vbox.get_children():
            self._vbox.remove(child)
        self._sections.clear()

    def show(self) -> None:
        """Show the debug window at the top-right of the screen."""
        self._position_top_right()
        self._window.show_all()

    def hide(self) -> None:
        """Hide the debug window."""
        try:
            self._window.hide()
        except Exception:
            pass

    def close(self) -> None:
        """Destroy the debug window."""
        try:
            self._window.hide()
            self._window.destroy()
        except Exception:
            pass
