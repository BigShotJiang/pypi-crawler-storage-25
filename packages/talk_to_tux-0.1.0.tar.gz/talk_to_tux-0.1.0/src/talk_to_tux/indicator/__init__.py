"""GNOME panel indicator with asyncio<->GTK bridge."""
from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import threading
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from talk_to_tux.context.models import AppContext
    from talk_to_tux.config import ApiMode
    from talk_to_tux.hosted.identity import HostedIdentity
    from talk_to_tux.hosted.quota_client import QuotaSnapshot

logger = logging.getLogger(__name__)


@dataclass
class HostedState:
    """Mutable hosted-mode state; only mutated on GTK thread via GLib.idle_add."""
    api_mode: Any  # ApiMode enum (imported lazily to avoid circular)
    signed_in_as: str | None
    quota: Any | None  # QuotaSnapshot | None
    last_refresh: datetime | None

# Sentinel WM classes for the GNOME Shell itself (should not be cached as focus target)
_SHELL_WM_CLASSES = frozenset({"Gnome-shell", "gnome-shell"})


def _log_future_exception(future: concurrent.futures.Future) -> None:
    """Log exceptions from asyncio.run_coroutine_threadsafe futures."""
    try:
        exc = future.exception()
    except concurrent.futures.CancelledError:
        return
    if exc is not None:
        logger.error("Async callback failed: %s", exc, exc_info=exc)


class IndicatorController:
    """Bridges GTK indicator (separate thread) with asyncio App (main thread).

    GTK -> asyncio: ``asyncio.run_coroutine_threadsafe()``
    asyncio -> GTK: ``GLib.idle_add()``
    """

    def __init__(self, app: Any, loop: asyncio.AbstractEventLoop, settings: Any) -> None:
        self._app = app
        self._loop = loop
        self._settings = settings
        self._tray: Any = None
        self._gtk_thread: threading.Thread | None = None
        self._last_focused_context: AppContext | None = None
        self._focus_poll_handle: asyncio.TimerHandle | None = None
        self._focus_poll_running = False
        self._recording = False
        self._tooltip: Any = None
        self._last_tooltip_data: list[tuple[str, str]] | None = None
        self._window_contexts: dict[str, AppContext] = {}  # window_id -> AppContext
        self._recording_dot: Any = None
        self._warning_tooltip: Any = None
        self._debug_tooltip: Any = None
        self._edit_panel: Any = None
        self._debug_enabled: bool = getattr(settings, 'debug', None) is not None and settings.debug.tooltip_enabled
        self._quota_refresh_lock: asyncio.Lock = asyncio.Lock()
        # Event-driven screenshot capture
        self._event_log = None  # set per-run via set_event_log()
        self._pending_event_screenshots: list[tuple] = []  # list of (EventEntry, bytes)
        import concurrent.futures
        self._screenshot_pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="evt-screenshot",
        )

    # --- Lifecycle ---

    def start(self) -> None:
        """Start GTK main loop in a daemon thread."""
        from talk_to_tux.context.window import force_xdotool_backend
        force_xdotool_backend()
        self._gtk_thread = threading.Thread(target=self._run_gtk, daemon=True)
        self._gtk_thread.start()
        self._start_focus_polling()

    def _run_gtk(self) -> None:
        """Entry point for the GTK thread."""
        try:
            import gi
            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk

            import webbrowser
            from talk_to_tux.hosted.urls import UPGRADE_URL
            from talk_to_tux.indicator.tray import TrayIcon

            def _on_sign_in():
                future = asyncio.run_coroutine_threadsafe(
                    self._run_cli_login(), self._loop
                )
                future.add_done_callback(_log_future_exception)

            def _on_upgrade():
                webbrowser.open(UPGRADE_URL)

            self._tray = TrayIcon(
                on_record_toggle=self._on_record_toggle,
                on_retry=self._request_retry,
                on_history=self._request_history,
                on_quit=self._request_quit,
                on_show_last=self._request_show_last,
                on_recent_selected=self._on_recent_selected,
                on_recent_show=self._on_recent_show,
                on_sign_in=_on_sign_in,
                on_upgrade=_on_upgrade,
            )
            Gtk.main()
        except Exception:
            logger.debug("GTK thread failed", exc_info=True)

    def stop(self) -> None:
        """Stop GTK main loop and focus polling."""
        if self._focus_poll_handle is not None:
            self._focus_poll_handle.cancel()
            self._focus_poll_handle = None
        try:
            import gi
            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk
            Gtk.main_quit()
        except Exception:
            logger.debug("GTK main_quit failed", exc_info=True)

    # --- Focus tracking (asyncio thread) ---

    def _start_focus_polling(self) -> None:
        """Poll active window on the asyncio event loop."""
        poll_s = self._settings.indicator.focus_poll_ms / 1000
        self._focus_poll_handle = self._loop.call_later(poll_s, self._poll_focus)

    def _poll_focus(self) -> None:
        """Schedule async focus poll (non-blocking)."""
        if self._focus_poll_running:
            # Previous poll still in flight — skip and reschedule
            self._start_focus_polling()
            return
        self._focus_poll_running = True
        self._loop.create_task(self._poll_focus_async())

    async def _poll_focus_async(self) -> None:
        """Cache the currently focused window (if not GNOME Shell).

        Uses xdotool backend (not Wnck) because this runs in a thread executor
        and Wnck/GLib are NOT thread-safe — calling Wnck.Screen.force_update()
        from a non-GTK thread while the GTK daemon thread processes icon updates
        corrupts GLib's internal state (malloc heap corruption via shared
        libpng/libz between gdk-pixbuf and PIL).

        Skips the expensive subprocess calls when the app is recording or
        processing to avoid event loop contention that delays button events.
        """
        try:
            from talk_to_tux.pipeline.state import PipelineState
            if self._app._state not in (PipelineState.IDLE, PipelineState.TOOLTIP_SHOWN):
                return  # skip poll during recording/processing to reduce latency

            from talk_to_tux.context.capturer import ContextCapturer
            info = await self._loop.run_in_executor(None, ContextCapturer._capture_window)
            if info is not None and info.wm_class not in _SHELL_WM_CLASSES:
                from talk_to_tux.context.models import AppContext
                new_ctx = AppContext(
                    timestamp=0.0,
                    window_title=info.title,
                    window_class=info.wm_class,
                    window_instance=info.wm_instance,
                    window_pid=info.pid,
                    window_id=info.window_id,
                )

                # Track window contexts for multi-window context blocks
                if new_ctx.window_id:
                    self._window_contexts[new_ctx.window_id] = new_ctx
                    # Evict old (keep last 10)
                    if len(self._window_contexts) > 10:
                        oldest_id = min(
                            self._window_contexts,
                            key=lambda k: self._window_contexts[k].timestamp,
                        )
                        del self._window_contexts[oldest_id]

                # Detect hover change during tooltip state -> eager rewrite
                from talk_to_tux.pipeline.state import PipelineState
                if (
                    self._app._state == PipelineState.TOOLTIP_SHOWN
                    and self._last_focused_context is not None
                    and new_ctx.window_class != self._last_focused_context.window_class
                ):
                    await self._app._eager_rewrite(new_ctx)

                self._last_focused_context = new_ctx
        except Exception:
            logger.debug("Focus poll failed", exc_info=True)
        finally:
            self._focus_poll_running = False
            # Re-schedule
            self._start_focus_polling()

    @property
    def last_focused_context(self) -> AppContext | None:
        return self._last_focused_context

    @property
    def all_window_contexts(self) -> list[AppContext]:
        return list(self._window_contexts.values())

    # --- GTK -> asyncio bridge (called from GTK thread) ---

    def _on_record_toggle(self) -> None:
        """Toggle recording start/stop."""
        if self._recording:
            self.request_record_stop()
        else:
            self.request_record_start()

    def request_record_start(self) -> None:
        """Schedule on_record_start on the asyncio loop."""
        self._recording = True
        future = asyncio.run_coroutine_threadsafe(self._app.on_record_start(), self._loop)
        future.add_done_callback(_log_future_exception)

    def request_record_stop(self) -> None:
        """Schedule on_record_stop on the asyncio loop."""
        self._recording = False
        future = asyncio.run_coroutine_threadsafe(self._app.on_record_stop(), self._loop)
        future.add_done_callback(_log_future_exception)

    def request_paste_from_history(self, text: str) -> None:
        """Schedule paste of history text at the last focused window."""

        async def _paste():
            await self._app._do_paste(text, self._last_focused_context)

        future = asyncio.run_coroutine_threadsafe(_paste(), self._loop)
        future.add_done_callback(_log_future_exception)

    def _request_retry(self) -> None:
        """Schedule retry_from_cache on the asyncio loop."""
        future = asyncio.run_coroutine_threadsafe(self._app.retry_from_cache(), self._loop)
        future.add_done_callback(_log_future_exception)

    def _request_history(self) -> None:
        """Open history dashboard on GTK thread."""
        try:
            from talk_to_tux.indicator.dashboard import HistoryDashboard
            runs = []
            if self._app._cache is not None:
                runs = self._app._cache.list_runs(
                    limit=self._settings.indicator.history_count
                )
            dashboard = HistoryDashboard(
                runs=runs,
                on_insert=self.request_paste_from_history,
                on_retry=self._request_retry,
            )
            dashboard.show()
        except Exception:
            logger.debug("Failed to open history dashboard", exc_info=True)

    def _request_show_last(self) -> None:
        """Show last transcript tooltip from GTK thread."""
        self.show_last_transcript()

    def _on_recent_selected(self, text: str) -> None:
        """Handle click on a Recent submenu entry (GTK thread) — copy to clipboard."""
        future = asyncio.run_coroutine_threadsafe(
            self._copy_to_clipboard(text), self._loop
        )
        future.add_done_callback(_log_future_exception)

    async def _copy_to_clipboard(self, text: str) -> None:
        """Copy text to system clipboard (xclip on X11, wl-copy on Wayland)."""
        from talk_to_tux.paste.paster import detect_display_server

        ds = detect_display_server()
        if ds == "wayland":
            cmd = ["wl-copy", "--"]
        else:
            cmd = ["xclip", "-selection", "clipboard"]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate(input=text.encode())

    def _on_recent_show(self) -> None:
        """Populate recent items when main menu is about to be shown (GTK thread)."""
        try:
            from talk_to_tux.indicator.dashboard import _load_run_text, _parse_timestamp
            items: list[tuple[str, str]] = []
            if self._app._cache is not None:
                limit = self._settings.indicator.recent_count
                runs = self._app._cache.list_runs(limit=limit)
                for run_dir in runs:
                    text = _load_run_text(run_dir)
                    if text:
                        ts = _parse_timestamp(run_dir.name)
                        items.append((ts, text))
            if self._tray is not None:
                self._tray.populate_recent_items(items)
        except Exception:
            logger.debug("Failed to populate recent items", exc_info=True)

    def _request_quit(self) -> None:
        """Schedule shutdown on the asyncio loop."""

        async def _shutdown():
            await self._app.shutdown()
            # Also stop the asyncio event loop
            self._loop.stop()

        future = asyncio.run_coroutine_threadsafe(_shutdown(), self._loop)
        future.add_done_callback(_log_future_exception)

    # --- Public API for asyncio callers ---

    def open_dashboard(self) -> None:
        """Open history dashboard from asyncio thread (bridges to GTK)."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._request_history)
        except Exception:
            logger.debug("Failed to open dashboard from asyncio", exc_info=True)

    # --- Recording dot processing state (asyncio -> GTK) ---

    def set_recording_dot_processing(self) -> None:
        """Switch recording dot to processing appearance from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._set_recording_dot_processing_gtk)
        except Exception:
            logger.debug("set_recording_dot_processing failed", exc_info=True)

    def _set_recording_dot_processing_gtk(self) -> bool:
        """Switch recording dot on GTK thread."""
        if self._recording_dot is not None:
            self._recording_dot.set_processing()
        return False

    # --- Tooltip bridge (asyncio -> GTK) ---

    def show_tooltip_recording(self) -> None:
        """Show empty tooltip with 'Recording...' status from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._show_tooltip_recording_gtk)
        except Exception:
            logger.debug("show_tooltip_recording failed", exc_info=True)

    def _show_tooltip_recording_gtk(self) -> bool:
        """Show small recording dot instead of full tooltip on GTK thread."""
        try:
            if self._tooltip is not None:
                self._tooltip.close()
                self._tooltip = None
            from talk_to_tux.indicator.recording_dot import RecordingDot
            self._recording_dot = RecordingDot()
            self._recording_dot.show()
            self._add_gtk_event("tooltip_recording")
        except Exception:
            logger.debug("Failed to create recording dot", exc_info=True)
        return False

    def set_tooltip_status(self, text: str) -> None:
        """Update tooltip status label from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._set_tooltip_status_gtk, text)
        except Exception:
            logger.debug("set_tooltip_status failed", exc_info=True)

    def _set_tooltip_status_gtk(self, text: str) -> bool:
        """Update tooltip status on GTK thread."""
        if self._tooltip is not None:
            self._tooltip.set_status(text)
        return False

    def show_tooltip(self, text: str, label: str) -> None:
        """Show tooltip popup from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._show_tooltip_gtk, text, label)
        except Exception:
            logger.debug("show_tooltip failed", exc_info=True)

    def _show_tooltip_gtk(self, text: str, label: str) -> bool:
        """Create (or update existing) tooltip and add text on GTK thread."""
        try:
            # Close recording dot — results are ready, switch to full tooltip
            if self._recording_dot is not None:
                self._recording_dot.close()
                self._recording_dot = None
            if self._tooltip is None:
                from talk_to_tux.indicator.tooltip import RewriteTooltip
                # Defensive: close stale tooltip if somehow still alive
                self._tooltip = RewriteTooltip(
                    on_dismiss=self._on_tooltip_dismiss,
                    on_row_clicked=self._on_tooltip_row_clicked,
                )
                self._tooltip.show()
                self._add_gtk_event("tooltip_ready")
            self._tooltip.set_status("Ready")
            self._tooltip.add_option(text, label)
            self._last_tooltip_data = [(text, label)]
            if self._tray is not None and hasattr(self._tray, 'enable_show_last'):
                self._tray.enable_show_last()
        except Exception:
            logger.debug("Failed to create tooltip", exc_info=True)
        return False  # GLib.idle_add one-shot

    def update_tooltip(self, text: str, label: str) -> None:
        """Add an option to the existing tooltip from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._update_tooltip_gtk, text, label)
        except Exception:
            logger.debug("update_tooltip failed", exc_info=True)

    def _update_tooltip_gtk(self, text: str, label: str) -> bool:
        """Add option on GTK thread."""
        if self._tooltip is not None:
            self._tooltip.add_option(text, label)
            if self._last_tooltip_data is not None:
                self._last_tooltip_data.append((text, label))
        return False

    def update_tooltip_primary(self, text: str) -> None:
        """Update primary tooltip text for streaming from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._update_tooltip_primary_gtk, text)
        except Exception:
            logger.debug("update_tooltip_primary failed", exc_info=True)

    def _update_tooltip_primary_gtk(self, text: str) -> bool:
        """Update primary option text on GTK thread."""
        if self._tooltip is not None:
            self._tooltip.update_primary_text(text)
        return False

    def hide_tooltip(self) -> None:
        """Hide and destroy tooltip from asyncio thread."""
        try:
            from gi.repository import GLib
            # Use HIGH priority so the hide fires before any queued repaints/idles
            GLib.idle_add(self._hide_tooltip_gtk, priority=GLib.PRIORITY_HIGH)
        except Exception:
            logger.debug("hide_tooltip failed", exc_info=True)

    def _hide_tooltip_gtk(self) -> bool:
        """Destroy tooltip and/or recording dot on GTK thread."""
        if self._recording_dot is not None:
            self._recording_dot.close()
            self._recording_dot = None
        if self._tooltip is not None:
            self._add_gtk_event("tooltip_dismiss")
            self._tooltip.close()
            self._tooltip = None
        return False

    def get_tooltip_selected(self) -> tuple[int, str] | None:
        """Get the currently selected tooltip option (thread-safe read)."""
        if self._tooltip is not None:
            return self._tooltip.get_selected()
        return None

    def _on_tooltip_dismiss(self) -> None:
        """Called from GTK thread when tooltip is dismissed (Escape, etc.)."""
        future = asyncio.run_coroutine_threadsafe(self._app.on_dismiss_tooltip(), self._loop)
        future.add_done_callback(_log_future_exception)

    def _on_tooltip_row_clicked(self, idx: int, text: str) -> None:
        """Called from GTK thread when a tooltip row is left-clicked."""
        self._add_gtk_event("tooltip_click")
        # Hide immediately so window visually disappears.
        if self._tooltip is not None:
            self._tooltip.hide()
        # Defer destroy to next idle — destroy during row-activated signal is unreliable.
        from gi.repository import GLib
        GLib.idle_add(self._hide_tooltip_gtk)
        future = asyncio.run_coroutine_threadsafe(
            self._app.on_confirm_paste(send_enter=False, clicked_index=idx), self._loop
        )
        future.add_done_callback(_log_future_exception)

    # --- Post-paste tooltip (asyncio -> GTK) ---

    def show_post_paste_tooltip(self, text: str, label: str, *, edit_immediately: bool = False) -> None:
        """Show a post-paste tooltip with edit capability from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._show_post_paste_tooltip_gtk, text, label, edit_immediately)
        except Exception:
            logger.debug("show_post_paste_tooltip failed", exc_info=True)

    def _show_post_paste_tooltip_gtk(self, text: str, label: str, edit_immediately: bool = False) -> bool:
        """Create post-paste tooltip with edit/fire buttons on GTK thread."""
        try:
            # Close recording dot if still visible
            if self._recording_dot is not None:
                self._recording_dot.close()
                self._recording_dot = None
            # Close any existing tooltip before creating a new one
            if self._tooltip is not None:
                self._tooltip.close()
                self._tooltip = None
            from talk_to_tux.indicator.tooltip import RewriteTooltip
            self._tooltip = RewriteTooltip(
                on_dismiss=self._on_tooltip_dismiss,
                on_row_clicked=self._on_tooltip_row_clicked,
                on_fire_edited=self._on_tooltip_fire_edited,
                on_cancel_auto_dismiss=self._on_tooltip_cancel_auto_dismiss,
                on_edit_clicked=self._on_tooltip_edit_clicked,
            )
            self._tooltip.set_status("Pasted")
            self._tooltip.add_option(text, label)
            if edit_immediately:
                self._tooltip.enter_edit_mode_directly()
            else:
                self._tooltip.enter_post_paste_mode()
            self._tooltip.show()
            self._add_gtk_event("post_paste_tooltip")
            self._last_tooltip_data = [(text, label)]
            if self._tray is not None and hasattr(self._tray, 'enable_show_last'):
                self._tray.enable_show_last()
        except Exception:
            logger.debug("Failed to create post-paste tooltip", exc_info=True)
        return False

    def _on_tooltip_fire_edited(self, text: str) -> None:
        """Called from GTK thread when fire button is clicked with edited text."""
        # Compute bbox while tooltip is still alive (includes tooltip rect)
        bbox = self._compute_capture_bbox()
        self._tooltip.close()
        self._tooltip = None
        # Capture via standard bbox-aware path
        if self._event_log is not None:
            entry = self._event_log.add("tooltip_fire", has_screenshot=False)
            self._screenshot_pool.submit(self._capture_and_store, entry, bbox)
        # Marshal to asyncio
        future = asyncio.run_coroutine_threadsafe(
            self._app.on_fire_edited_text(text), self._loop
        )
        future.add_done_callback(_log_future_exception)

    def _on_tooltip_edit_clicked(self) -> None:
        """Called from GTK thread when edit button is clicked (before edit mode)."""
        self._add_gtk_event("tooltip_edit")

    def _on_tooltip_cancel_auto_dismiss(self) -> None:
        """Called from GTK thread when user starts editing (cancel auto-dismiss)."""
        future = asyncio.run_coroutine_threadsafe(
            self._cancel_post_paste_timeout_async(), self._loop
        )
        future.add_done_callback(_log_future_exception)

    async def _cancel_post_paste_timeout_async(self) -> None:
        """Cancel the post-paste auto-dismiss timeout on the asyncio thread."""
        self._app.on_cancel_post_paste_timeout()

    def show_last_transcript(self) -> None:
        """Re-show the last tooltip from asyncio thread."""
        if self._last_tooltip_data:
            try:
                from gi.repository import GLib
                GLib.idle_add(self._show_last_tooltip_gtk)
            except Exception:
                logger.debug("show_last_transcript failed", exc_info=True)

    def _show_last_tooltip_gtk(self) -> bool:
        """Re-create tooltip from saved data on GTK thread."""
        if self._last_tooltip_data:
            try:
                from talk_to_tux.indicator.tooltip import RewriteTooltip
                self._tooltip = RewriteTooltip(
                    on_dismiss=self._on_tooltip_dismiss,
                    on_row_clicked=self._on_tooltip_row_clicked,
                )
                self._tooltip.set_status("Previous result")
                for text, label in self._last_tooltip_data:
                    self._tooltip.add_option(text, label)
                self._tooltip.show()
            except Exception:
                logger.debug("Failed to show last tooltip", exc_info=True)
        return False

    # --- Warning tooltip bridge (asyncio -> GTK) ---

    def show_warning_tooltip(self, message: str) -> None:
        """Show a warning tooltip from asyncio thread."""
        try:
            from gi.repository import GLib
            warning_ms = 3500
            if hasattr(self._settings, 'validation'):
                warning_ms = self._settings.validation.warning_tooltip_ms
            GLib.idle_add(self._show_warning_tooltip_gtk, message, warning_ms)
        except Exception:
            logger.debug("show_warning_tooltip failed", exc_info=True)

    def _show_warning_tooltip_gtk(self, message: str, auto_dismiss_ms: int) -> bool:
        """Create and show warning tooltip on GTK thread."""
        try:
            from talk_to_tux.indicator.warning_tooltip import WarningTooltip
            self._warning_tooltip = WarningTooltip(auto_dismiss_ms=auto_dismiss_ms)
            self._warning_tooltip.show(message)
        except Exception:
            logger.debug("Failed to create warning tooltip", exc_info=True)
        return False

    # --- Hosted-mode account state API (SL-0 stubs; SL-4 fills bodies) ---

    def set_account_state(self, identity: Any, api_mode: Any) -> None:
        """Schedule tray menu update with hosted identity + mode (asyncio -> GTK)."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._tray.update_hosted, identity, api_mode)
        except Exception:
            logger.debug("set_account_state failed", exc_info=True)

    def set_quota(self, snapshot: Any) -> None:
        """Schedule tray quota label update (asyncio -> GTK)."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._tray.update_quota, snapshot)
        except Exception:
            logger.debug("set_quota failed", exc_info=True)

    def show_quota_exhausted_toast(
        self,
        *,
        resets_in_days: int,
        upgrade_url: str = "https://www.talk-to-tux.com/upgrade",
    ) -> None:
        """Show quota-exhausted warning toast with upgrade link (asyncio -> GTK)."""
        msg = f"Quota exhausted — resets in {resets_in_days} day(s). Click to upgrade."
        try:
            from gi.repository import GLib
            warning_ms = 6000

            def _show_toast_gtk(_msg=msg, _url=upgrade_url, _ms=warning_ms) -> bool:
                try:
                    import webbrowser
                    from talk_to_tux.indicator.warning_tooltip import WarningTooltip
                    self._warning_tooltip = WarningTooltip(
                        auto_dismiss_ms=_ms,
                        on_click=lambda: webbrowser.open(_url),
                    )
                    self._warning_tooltip.show(_msg)
                except Exception:
                    logger.debug("Failed to create quota toast", exc_info=True)
                return False

            GLib.idle_add(_show_toast_gtk)
        except Exception:
            logger.debug("show_quota_exhausted_toast failed", exc_info=True)


    async def _run_cli_login(self) -> None:
        """Spawn 'talk-to-tux login' in a subprocess (sign-in triggered from tray)."""
        import sys as _sys
        proc = await asyncio.create_subprocess_exec(
            _sys.executable, '-m', 'talk_to_tux', 'login',
        )
        await proc.wait()

    def refresh_quota_after_recording(self) -> None:
        """Fire-and-forget quota refresh after a successful recording.

        Skips if already refreshing (lock held) or if not in hosted mode or not signed in.
        """
        from talk_to_tux.config import ApiMode
        if getattr(self._settings, 'api_mode', None) != ApiMode.HOSTED:
            return
        token_store = getattr(self._app, '_token_store', None)
        if token_store is None or token_store.load() is None:
            return
        if self._quota_refresh_lock.locked():
            return
        asyncio.run_coroutine_threadsafe(self._refresh_quota_async(), self._loop)

    async def _refresh_quota_async(self) -> None:
        """Internal coroutine: fetch quota under lock, then update tray."""
        if self._quota_refresh_lock.locked():
            return
        async with self._quota_refresh_lock:
            try:
                from talk_to_tux.hosted.quota_client import HostedQuotaClient
                client = HostedQuotaClient(self._settings.hosted, self._app._token_store)
                snapshot = await client.fetch()
                self.set_quota(snapshot)
            except Exception:
                logger.debug("refresh_quota_after_recording failed", exc_info=True)

    # --- Debug tooltip bridge (asyncio -> GTK) ---

    def update_debug_section(self, name: str, content: str) -> None:
        """Update a debug tooltip section from asyncio thread. No-op if disabled."""
        if not self._debug_enabled:
            return
        try:
            from gi.repository import GLib
            GLib.idle_add(self._update_debug_section_gtk, name, content)
        except Exception:
            logger.debug("update_debug_section failed", exc_info=True)

    def _update_debug_section_gtk(self, name: str, content: str) -> bool:
        """Create or update debug section on GTK thread."""
        try:
            if self._debug_tooltip is None:
                from talk_to_tux.indicator.debug_tooltip import DebugTooltip
                self._debug_tooltip = DebugTooltip()
                self._debug_tooltip.show()
            self._debug_tooltip.update_section(name, content)
        except Exception:
            logger.debug("Failed to update debug section", exc_info=True)
        return False

    def clear_debug_tooltip(self) -> None:
        """Clear all debug sections for a new pipeline run. No-op if disabled."""
        if not self._debug_enabled:
            return
        try:
            from gi.repository import GLib
            GLib.idle_add(self._clear_debug_gtk)
        except Exception:
            logger.debug("clear_debug_tooltip failed", exc_info=True)

    def _clear_debug_gtk(self) -> bool:
        """Clear debug tooltip on GTK thread."""
        if self._debug_tooltip is not None:
            self._debug_tooltip.clear()
        return False

    # --- Edit panel bridge (asyncio -> GTK) ---

    def show_edit_panel(
        self,
        text: str,
        target_label: str,
        on_fire: Any,
        on_cancel: Any,
    ) -> None:
        """Show the edit panel from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(
                self._show_edit_panel_gtk, text, target_label, on_fire, on_cancel,
            )
        except Exception:
            logger.debug("show_edit_panel failed", exc_info=True)

    def _show_edit_panel_gtk(
        self, text: str, target_label: str, on_fire, on_cancel,
    ) -> bool:
        """Create EditPanel on GTK thread."""
        try:
            if self._edit_panel is not None:
                self._edit_panel.close()
                self._edit_panel = None
            from talk_to_tux.indicator.edit_panel import EditPanel
            self._edit_panel = EditPanel(
                text=text,
                target_label=target_label,
                on_fire=on_fire,
                on_cancel=on_cancel,
            )
            self._edit_panel.show()
        except Exception:
            logger.warning("Failed to create edit panel", exc_info=True)
        return False

    def hide_edit_panel(self) -> None:
        """Hide and destroy edit panel from asyncio thread."""
        try:
            from gi.repository import GLib
            GLib.idle_add(self._hide_edit_panel_gtk)
        except Exception:
            logger.debug("hide_edit_panel failed", exc_info=True)

    def _hide_edit_panel_gtk(self) -> bool:
        """Destroy edit panel on GTK thread."""
        if self._edit_panel is not None:
            self._edit_panel.close()
            self._edit_panel = None
        return False

    # --- Event-driven screenshot capture ---

    def set_event_log(self, event_log) -> None:
        """Set the EventLog for the current run (called from asyncio thread)."""
        self._event_log = event_log
        self._pending_event_screenshots.clear()

    def _compute_capture_bbox(self) -> tuple[int, int, int, int] | None:
        """Compute bounding box covering cursor monitor + tooltip. GTK thread only."""
        try:
            from gi.repository import Gdk
            display = Gdk.Display.get_default()
            if display is None:
                return None

            # 1. Get cursor position and its monitor bounds
            seat = display.get_default_seat()
            pointer = seat.get_pointer()
            _, cursor_x, cursor_y = pointer.get_position()
            monitor = display.get_monitor_at_point(cursor_x, cursor_y)
            if monitor is None:
                return None
            mon = monitor.get_geometry()  # Gdk.Rectangle(x, y, width, height)
            # Start with monitor bounds as the maximum extent
            x1, y1 = mon.x, mon.y
            x2, y2 = mon.x + mon.width, mon.y + mon.height

            # 2. If tooltip is visible, union its rect (may overhang monitor edge)
            if self._tooltip is not None:
                try:
                    tx, ty = self._tooltip._window.get_position()
                    tw, th = self._tooltip._window.get_size()
                    x1 = min(x1, tx)
                    y1 = min(y1, ty)
                    x2 = max(x2, tx + tw)
                    y2 = max(y2, ty + th)
                except Exception:
                    pass

            return (x1, y1, x2, y2)
        except Exception:
            logger.debug("_compute_capture_bbox failed", exc_info=True)
            return None

    def _add_gtk_event(self, event: str) -> None:
        """Add event + capture screenshot off GTK thread (~330ms capture)."""
        if self._event_log is None:
            return
        entry = self._event_log.add(event, has_screenshot=False)
        bbox = self._compute_capture_bbox()
        # Run screenshot capture in thread pool to avoid blocking the GTK loop
        self._screenshot_pool.submit(self._capture_and_store, entry, bbox)

    def _capture_and_store(self, entry, bbox=None) -> None:
        """Capture screenshot in thread pool, then store result (thread-safe)."""
        shot = self._capture_screen_sync(bbox=bbox)
        if shot is not None:
            entry.has_screenshot = True
            # list.append is GIL-atomic — safe from any thread
            self._pending_event_screenshots.append((entry, shot))

    def pop_event_screenshots(self) -> list[tuple]:
        """Return and clear pending event screenshots (asyncio thread)."""
        result = self._pending_event_screenshots.copy()
        self._pending_event_screenshots.clear()
        return result

    # --- Feedback screenshot capture ---

    def _capture_screen_sync(self, bbox: tuple[int, int, int, int] | None = None) -> bytes | None:
        """Quick synchronous screenshot, optionally cropped to *bbox*.

        Uses PIL.ImageGrab which works from daemon threads (subprocess-based
        tools like scrot/import hang because they conflict with GTK's X11 lock).
        Falls back to grim subprocess on Wayland where ImageGrab is unsupported.

        *bbox* is ``(x1, y1, x2, y2)`` in absolute screen coordinates.  When
        provided on X11 it is passed directly to ``ImageGrab.grab(bbox=…)``
        so only the relevant monitor region (plus tooltip) is captured.
        """
        import os
        try:
            if os.environ.get("WAYLAND_DISPLAY"):
                import subprocess
                import tempfile
                from pathlib import Path as _Path
                tmp = tempfile.mktemp(suffix=".png")
                r = subprocess.run(["grim", tmp], capture_output=True, timeout=2)
                if r.returncode != 0:
                    # grim failed — return None (scrot won't help from GTK thread)
                    _Path(tmp).unlink(missing_ok=True)
                    return None
                if r.returncode == 0:
                    data = _Path(tmp).read_bytes()
                    _Path(tmp).unlink(missing_ok=True)
                    # Crop on Wayland: full capture then PIL crop
                    if bbox is not None:
                        try:
                            from io import BytesIO
                            from PIL import Image
                            img = Image.open(BytesIO(data))
                            img = img.crop(bbox)
                            buf = BytesIO()
                            img.save(buf, format="JPEG", quality=75)
                            return buf.getvalue()
                        except Exception:
                            pass  # fall through to return raw data
                    return data
            else:
                from io import BytesIO
                from PIL import ImageGrab
                img = ImageGrab.grab(bbox=bbox)
                # Cap width at 1920px to keep file size reasonable
                if img.width > 1920:
                    ratio = 1920 / img.width
                    from PIL import Image
                    img = img.resize((1920, int(img.height * ratio)), Image.LANCZOS)
                buf = BytesIO()
                img.save(buf, format="JPEG", quality=75)
                return buf.getvalue()
        except Exception:
            logger.debug("Sync screenshot capture failed", exc_info=True)
        return None

    # --- asyncio -> GTK bridge (called from asyncio thread) ---

    def set_status(self, status: str) -> None:
        """Update tray icon status from the asyncio thread."""
        if status in ("idle", "error"):
            self._recording = False
        if self._tray is None:
            return
        try:
            from gi.repository import GLib
            GLib.idle_add(self._tray.set_status, status)
        except Exception:
            logger.debug("set_status failed", exc_info=True)
