"""History dashboard popup showing past transcriptions."""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _import_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk
    return Gtk


def _parse_timestamp(run_name: str) -> str:
    """Parse YYYYMMDD-HHMMSS-fff format into readable timestamp."""
    try:
        dt = datetime.strptime(run_name[:15], "%Y%m%d-%H%M%S")
        return dt.strftime("%H:%M:%S")
    except (ValueError, IndexError):
        return run_name


def _load_run_text(run_dir: Path) -> str | None:
    """Load rewrite text if available, otherwise STT text."""
    rewrite = run_dir / "rewrite.json"
    if rewrite.exists():
        try:
            data = json.loads(rewrite.read_text(encoding="utf-8"))
            return data.get("text")
        except Exception:
            pass
    stt = run_dir / "stt.json"
    if stt.exists():
        try:
            data = json.loads(stt.read_text(encoding="utf-8"))
            return data.get("text")
        except Exception:
            pass
    return None


def _load_run_context(run_dir: Path) -> tuple[str, str]:
    """Load window_title and window_class from context."""
    ctx = run_dir / "context.json"
    if ctx.exists():
        try:
            data = json.loads(ctx.read_text(encoding="utf-8"))
            return data.get("window_title", ""), data.get("window_class", "")
        except Exception:
            pass
    return "", ""


def _load_run_status(run_dir: Path) -> str:
    """Load stage from status.json."""
    status = run_dir / "status.json"
    if status.exists():
        try:
            data = json.loads(status.read_text(encoding="utf-8"))
            return data.get("stage", "")
        except Exception:
            pass
    return ""


class HistoryDashboard:
    """GTK3 popup window showing recent transcriptions."""

    def __init__(
        self,
        runs: list[Path],
        on_insert: Callable[[str], None],
        on_retry: Callable[[], None],
    ) -> None:
        Gtk = _import_gtk()
        self._Gtk = Gtk
        self._on_insert = on_insert
        self._on_retry = on_retry

        self._window = Gtk.Window(title="Talk-to-Tux History")
        self._window.set_default_size(420, 350)
        self._window.set_position(Gtk.WindowPosition.MOUSE)
        self._window.set_type_hint(1)  # GDK_WINDOW_TYPE_HINT_UTILITY
        self._window.set_keep_above(True)
        self._window.connect("delete-event", self._on_close)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        listbox = Gtk.ListBox()
        listbox.set_selection_mode(Gtk.SelectionMode.NONE)

        if not runs:
            label = Gtk.Label(label="No history yet.")
            label.set_margin_top(20)
            listbox.add(label)
        else:
            for run_dir in runs:
                row = self._build_row(run_dir)
                if row is not None:
                    listbox.add(row)

        scrolled.add(listbox)
        self._window.add(scrolled)

    def _build_row(self, run_dir: Path):
        Gtk = self._Gtk
        text = _load_run_text(run_dir)
        stage = _load_run_status(run_dir)
        title, wm_class = _load_run_context(run_dir)
        ts = _parse_timestamp(run_dir.name)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.set_margin_top(4)
        box.set_margin_bottom(4)
        box.set_margin_start(8)
        box.set_margin_end(8)

        # Status indicator
        if stage == "done":
            status_label = Gtk.Label(label="\u2713")  # checkmark
        else:
            status_label = Gtk.Label(label="\u2717")  # x mark
        box.pack_start(status_label, False, False, 0)

        # Text content
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        preview = (text[:80] + "...") if text and len(text) > 80 else (text or "(no text)")
        text_label = Gtk.Label(label=preview)
        text_label.set_xalign(0)
        text_label.set_line_wrap(True)
        text_label.set_max_width_chars(50)
        vbox.pack_start(text_label, False, False, 0)

        meta = f"{ts}"
        if title:
            meta += f" \u2022 {title[:30]}"
        if wm_class:
            meta += f" ({wm_class})"
        meta_label = Gtk.Label(label=meta)
        meta_label.set_xalign(0)
        meta_label.get_style_context().add_class("dim-label")
        vbox.pack_start(meta_label, False, False, 0)

        box.pack_start(vbox, True, True, 0)

        # Action button
        if stage == "done" and text:
            btn = Gtk.Button(label="Insert")
            final_text = text
            btn.connect("activate", lambda _: self._do_insert(final_text))
            btn.connect("clicked", lambda _: self._do_insert(final_text))
        else:
            btn = Gtk.Button(label="Retry")
            btn.connect("activate", lambda _: self._do_retry())
            btn.connect("clicked", lambda _: self._do_retry())
        box.pack_end(btn, False, False, 0)

        row = Gtk.ListBoxRow()
        row.add(box)
        return row

    def _do_insert(self, text: str) -> None:
        self._on_insert(text)
        self._window.close()

    def _do_retry(self) -> None:
        self._on_retry()
        self._window.close()

    def _on_close(self, *_args):
        self._window.hide()
        return True

    def show(self) -> None:
        self._window.show_all()

    def close(self) -> None:
        self._window.close()
