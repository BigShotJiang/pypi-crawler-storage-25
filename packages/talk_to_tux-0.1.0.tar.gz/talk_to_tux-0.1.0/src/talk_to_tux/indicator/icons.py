"""SVG icon paths for the GNOME panel indicator."""
from __future__ import annotations

from pathlib import Path

_ICON_DIR = Path(__file__).parent / "icons"

ICON_IDLE = str(_ICON_DIR / "ttt-idle-symbolic.svg")
ICON_RECORDING = str(_ICON_DIR / "ttt-recording-symbolic.svg")
ICON_PROCESSING = str(_ICON_DIR / "ttt-processing-symbolic.svg")
ICON_ERROR = str(_ICON_DIR / "ttt-error-symbolic.svg")
ICON_ARMED = str(_ICON_DIR / "ttt-armed-symbolic.svg")

STATUS_ICONS: dict[str, str] = {
    "idle": ICON_IDLE,
    "recording": ICON_RECORDING,
    "processing": ICON_PROCESSING,
    "error": ICON_ERROR,
    "armed": ICON_ARMED,
}
