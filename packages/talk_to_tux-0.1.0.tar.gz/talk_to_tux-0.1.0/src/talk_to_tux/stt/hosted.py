from __future__ import annotations

import json
import logging
from collections.abc import Callable
from datetime import datetime
from io import BytesIO
from typing import TYPE_CHECKING

import httpx

from talk_to_tux.auth import (
    AuthFailed,
    HostedError,
    QuotaExhausted,
    RecordingTooLong,
    TierLocked,
    TokenInvalid,
    TokenStore,
)
from talk_to_tux.config import HostedConfig
from talk_to_tux.stt.client import TranscriptionResult

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _wav_duration_seconds(wav_bytes: bytes) -> float:
    try:
        import soundfile as sf
        info = sf.info(BytesIO(wav_bytes))
        return info.frames / info.samplerate
    except Exception:
        # rough estimate for 16kHz mono 16-bit PCM
        return len(wav_bytes) / 32000


class HostedSttProvider:
    def __init__(
        self,
        hosted_config: HostedConfig,
        token_store: TokenStore,
        *,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._hosted_config = hosted_config
        self._token_store = token_store
        self._timeout = timeout
        self._owns_client = http_client is None
        self._http = http_client if http_client is not None else httpx.AsyncClient()

    async def transcribe(
        self,
        wav_bytes: bytes,
        keyterms: list[str] | None = None,
        on_partial: Callable[[str], None] | None = None,
        initial_prompt: str | None = None,
    ) -> TranscriptionResult:
        tokens = self._token_store.load()
        if tokens is None:
            raise AuthFailed("no_tokens")

        duration_s = _wav_duration_seconds(wav_bytes)
        raw_ms = int(duration_s * 1000)
        trimmed_ms = raw_ms

        metadata_json = json.dumps({
            "raw_ms": raw_ms,
            "trimmed_ms": trimmed_ms,
            "keyterms": keyterms or [],
            "initial_prompt": initial_prompt or "",
        })

        url = f"{self._hosted_config.base_url}/functions/v1/v1-stt"
        try:
            response = await self._http.post(
                url,
                content=wav_bytes,
                headers={
                    "Authorization": f"Bearer {tokens.access_token}",
                    "Content-Type": "audio/wav",
                    "X-Talk-To-Tux-Metadata": metadata_json,
                },
                timeout=self._timeout,
            )
        except (httpx.ConnectError, httpx.TimeoutException):
            raise HostedError("network_error")

        status = response.status_code

        if status == 200:
            body = response.json()
            return TranscriptionResult(
                text=body["text"],
                source=body.get("provider", "hosted"),
                chain_position=body.get("chain_position", 0),
                chain_length=body.get("chain_length", 1),
                failures=[],
            )

        if status == 401:
            raise TokenInvalid()

        if status == 402:
            body = response.json()
            code = body.get("code", "")
            if code == "tier_locked":
                raise TierLocked()
            # quota_exhausted
            reset_at_raw = body.get("reset_at")
            reset_at: datetime | None = None
            if reset_at_raw:
                try:
                    reset_at = datetime.fromisoformat(reset_at_raw)
                except (ValueError, TypeError):
                    reset_at = None
            remaining_stt = body.get("remaining_stt_seconds")
            remaining_rewrites = body.get("remaining_rewrites")
            raise QuotaExhausted(
                reset_at=reset_at,
                remaining_stt_seconds=remaining_stt,
                remaining_rewrites=remaining_rewrites,
            )

        if status == 413:
            body = response.json()
            raise RecordingTooLong(
                raw_ms=body["raw_ms"],
                trimmed_ms=body["trimmed_ms"],
                raw_cap=body.get("raw_cap", 600_000),
                trimmed_cap=body.get("trimmed_cap", 300_000),
            )

        raise HostedError(f"server_error {status}")

    async def close(self) -> None:
        if self._owns_client:
            await self._http.aclose()

    async def health_check(self) -> bool:
        return True
