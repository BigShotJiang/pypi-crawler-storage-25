from __future__ import annotations

import io
import json
import logging
from collections.abc import Callable
from dataclasses import dataclass, field

import httpx

logger = logging.getLogger(__name__)


@dataclass
class TranscriptionResult:
    text: str
    source: str  # provider name from the chain
    chain_position: int = 0
    chain_length: int = 1
    failures: list[str] = field(default_factory=list)


class STTClient:
    def __init__(
        self,
        gpu_server_url: str = "http://localhost:8000",
        gpu_server_timeout: float = 10.0,
        openai_api_key: str | None = None,
        openai_model: str = "whisper-1",
        groq_api_key: str | None = None,
        groq_model: str = "whisper-large-v3-turbo",
        google_api_key: str | None = None,
        elevenlabs_api_key: str | None = None,
        elevenlabs_model: str = "scribe_v2",
        local_whisper_url: str = "http://win:8003/v1",
        local_whisper_timeout: float = 30.0,
        stt_providers: str | list[str] = "gpu_server,groq,openai,google",
    ) -> None:
        self._gpu_server_url = gpu_server_url.rstrip("/")
        self._gpu_server_timeout = gpu_server_timeout
        self._openai_api_key = openai_api_key
        self._openai_model = openai_model
        self._groq_api_key = groq_api_key
        self._groq_model = groq_model
        self._google_api_key = google_api_key
        self._elevenlabs_api_key = elevenlabs_api_key
        self._elevenlabs_model = elevenlabs_model
        self._http = httpx.AsyncClient(timeout=gpu_server_timeout)
        self._elevenlabs_http = httpx.AsyncClient(timeout=30.0) if elevenlabs_api_key else None
        self._local_whisper_http: httpx.AsyncClient | None = None
        self._openai_client = None
        self._groq_client = None

        # Accept either comma-separated string or list
        if isinstance(stt_providers, str):
            provider_list = [p.strip() for p in stt_providers.split(",") if p.strip()]
        else:
            provider_list = list(stt_providers)

        self._chain: list[tuple[str, Callable]] = []
        for provider in provider_list:
            if provider == "gpu_server":
                self._chain.append(("gpu_server", self._transcribe_gpu))
            elif provider == "local_whisper":
                self._local_whisper_url = local_whisper_url.rstrip("/")
                self._local_whisper_http = httpx.AsyncClient(timeout=local_whisper_timeout)
                self._chain.append(("local_whisper", self._transcribe_local_whisper))
            elif provider == "elevenlabs" and elevenlabs_api_key:
                self._chain.append(("elevenlabs", self._transcribe_elevenlabs))
            elif provider == "groq" and groq_api_key:
                from openai import AsyncOpenAI

                self._groq_client = AsyncOpenAI(
                    base_url="https://api.groq.com/openai/v1",
                    api_key=groq_api_key,
                )
                self._chain.append(("groq", self._transcribe_groq))
            elif provider == "openai" and openai_api_key:
                from openai import AsyncOpenAI

                self._openai_client = AsyncOpenAI(api_key=openai_api_key)
                self._chain.append(("openai", self._transcribe_openai))
            elif provider == "google" and google_api_key:
                self._chain.append(("google", self._transcribe_google))

    async def _transcribe_elevenlabs(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._elevenlabs_api_key is None or self._elevenlabs_http is None:
            raise ValueError("ElevenLabs client not configured (no API key provided)")
        data: dict[str, str] = {"model_id": self._elevenlabs_model}
        if keyterms:
            data["keyterms"] = json.dumps(keyterms)
        response = await self._elevenlabs_http.post(
            "https://api.elevenlabs.io/v1/speech-to-text",
            headers={"xi-api-key": self._elevenlabs_api_key},
            files={"file": ("audio.wav", wav_bytes, "audio/wav")},
            data=data,
        )
        response.raise_for_status()
        return response.json()["text"]

    async def _transcribe_local_whisper(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._local_whisper_http is None:
            raise ValueError("local_whisper client not configured")
        data: dict[str, str] = {"model": "whisper-1"}
        if keyterms:
            data["prompt"] = "Terms: " + ", ".join(keyterms)
        response = await self._local_whisper_http.post(
            f"{self._local_whisper_url}/audio/transcriptions",
            files={"file": ("audio.wav", wav_bytes, "audio/wav")},
            data=data,
        )
        response.raise_for_status()
        return response.json()["text"]

    async def _transcribe_gpu(
        self,
        wav_bytes: bytes,
        keyterms: list[str] | None = None,
        on_partial: Callable[[str], None] | None = None,
        initial_prompt: str | None = None,
    ) -> str:
        form_data: dict[str, str] = {}
        if initial_prompt:
            form_data["initial_prompt"] = initial_prompt

        # Try SSE streaming endpoint first
        stream_url = f"{self._gpu_server_url}/transcribe/stream"
        try:
            accumulated: list[str] = []
            async with self._http.stream(
                "POST",
                stream_url,
                files={"file": ("audio.wav", wav_bytes, "audio/wav")},
                data=form_data,
            ) as response:
                if response.status_code == 404:
                    # Old server — fall through to batch
                    raise httpx.HTTPStatusError(
                        "404", request=response.request, response=response
                    )
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload == "[DONE]":
                        break
                    if payload.startswith("{"):
                        seg = json.loads(payload)
                        accumulated.append(seg["text"])
                        if on_partial and accumulated:
                            on_partial(" ".join(accumulated))
            return " ".join(accumulated)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code != 404:
                raise
            logger.debug("GPU server has no /transcribe/stream, falling back to batch")
        except Exception:
            raise

        # Batch fallback
        response = await self._http.post(
            f"{self._gpu_server_url}/transcribe",
            files={"file": ("audio.wav", wav_bytes, "audio/wav")},
            data=form_data,
        )
        response.raise_for_status()
        return response.json()["text"]

    async def _transcribe_openai(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._openai_client is None:
            raise ValueError("OpenAI client not configured (no API key provided)")
        buf = io.BytesIO(wav_bytes)
        buf.name = "audio.wav"
        kwargs: dict = {"model": self._openai_model, "file": buf}
        if keyterms:
            kwargs["prompt"] = "Terms: " + ", ".join(keyterms)
        transcript = await self._openai_client.audio.transcriptions.create(**kwargs)
        return transcript.text

    async def _transcribe_groq(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._groq_client is None:
            raise ValueError("Groq client not configured (no API key provided)")
        buf = io.BytesIO(wav_bytes)
        buf.name = "audio.wav"
        kwargs: dict = {"model": self._groq_model, "file": buf}
        if keyterms:
            kwargs["prompt"] = "Terms: " + ", ".join(keyterms)
        transcript = await self._groq_client.audio.transcriptions.create(**kwargs)
        return transcript.text

    async def _transcribe_google(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        import base64

        import baml_py
        from baml_client.async_client import b

        audio_b64 = base64.b64encode(wav_bytes).decode("ascii")
        audio = baml_py.Audio.from_base64("audio/wav", audio_b64)
        return await b.TranscribeAudio(audio=audio, hint=None)

    async def transcribe(
        self,
        wav_bytes: bytes,
        keyterms: list[str] | None = None,
        on_partial: Callable[[str], None] | None = None,
        initial_prompt: str | None = None,
    ) -> TranscriptionResult:
        if not self._chain:
            raise RuntimeError("No STT providers configured")
        errors: list[tuple[str, Exception]] = []
        for idx, (name, method) in enumerate(self._chain):
            try:
                if name == "gpu_server":
                    text = await method(
                        wav_bytes,
                        keyterms=keyterms,
                        on_partial=on_partial,
                        initial_prompt=initial_prompt,
                    )
                else:
                    text = await method(wav_bytes, keyterms=keyterms)
                return TranscriptionResult(
                    text=text,
                    source=name,
                    chain_position=idx,
                    chain_length=len(self._chain),
                    failures=[n for n, _ in errors],
                )
            except Exception as exc:
                logger.warning("STT provider %s failed: %s", name, exc)
                errors.append((name, exc))
        detail = ", ".join(f"{name}: {exc}" for name, exc in errors)
        raise RuntimeError(f"All STT providers failed. {detail}")

    async def health_check(self) -> bool:
        try:
            response = await self._http.get(f"{self._gpu_server_url}/health")
            return response.status_code == 200
        except Exception:
            return False

    async def close(self) -> None:
        await self._http.aclose()
        if self._elevenlabs_http is not None:
            await self._elevenlabs_http.aclose()
        if self._local_whisper_http is not None:
            await self._local_whisper_http.aclose()
