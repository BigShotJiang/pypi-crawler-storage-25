from __future__ import annotations

import asyncio
import logging
import os

from talk_to_tux.context.models import AppContext

logger = logging.getLogger(__name__)

TERMINAL_WM_CLASSES: set[str] = {
    "Gnome-terminal",
    "Alacritty",
    "kitty",
    "foot",
    "Terminator",
    "Tilix",
    "urxvt",
    "URxvt",
    "Wezterm",
    "wezterm",
    "Konsole",
    "xterm",
    "XTerm",
    "st-256color",
    "sakura",
    "lxterminal",
    "mate-terminal",
    "Xfce4-terminal",
    "rio",
    "Hyper",
    "tabby",
}


def detect_display_server() -> str:
    if os.environ.get("WAYLAND_DISPLAY"):
        return "wayland"
    if os.environ.get("DISPLAY"):
        return "x11"
    return "unknown"


def is_terminal(window_class: str | None) -> bool:
    if not window_class:
        return False
    return window_class in TERMINAL_WM_CLASSES


async def check_system_tools(display_server: str) -> dict[str, bool]:
    if display_server == "x11":
        tools = ["xclip", "xdotool"]
    elif display_server == "wayland":
        tools = ["wl-copy", "wl-paste", "wtype", "ydotool", "xdotool"]
    else:
        return {}

    result: dict[str, bool] = {}
    for tool in tools:
        proc = await asyncio.create_subprocess_exec(
            "which", tool,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
        result[tool] = proc.returncode == 0
    return result


def _parse_shortcut_xdotool(shortcut: str, window_id: str | None = None) -> list[str]:
    """Parse 'ctrl+shift+v' into xdotool key command args.

    When window_id is provided, uses --window to send a single XKeyEvent via
    XSendEvent with modifier mask set in the event structure.  This avoids
    generating separate modifier-key press/release events that kitty's keyboard
    protocol would encode as CSI u sequences and forward to SSH/zellij.
    """
    cmd = ["xdotool", "key"]
    if window_id:
        cmd.extend(["--window", window_id])
    cmd.extend(["--delay", "0", shortcut])
    return cmd


def _parse_shortcut_wtype(shortcut: str) -> list[str]:
    """Parse 'ctrl+shift+v' into wtype command args."""
    parts = shortcut.lower().split("+")
    key = parts[-1]
    modifiers = parts[:-1]
    cmd: list[str] = ["wtype"]
    for mod in modifiers:
        cmd.extend(["-M", mod])
    cmd.append(key)
    for mod in reversed(modifiers):
        cmd.extend(["-m", mod])
    return cmd


# ydotool v0.1.8 (Ubuntu 24.04) uses evdev scancodes
_EVDEV_SCANCODES: dict[str, int] = {
    "ctrl": 29, "shift": 42, "alt": 56, "super": 125, "meta": 125,
    "v": 47, "z": 44, "c": 46, "x": 45, "a": 30,
    "return": 28, "enter": 28, "tab": 15, "space": 57,
    "escape": 1, "backspace": 14, "delete": 111,
}


def _parse_shortcut_ydotool(shortcut: str) -> list[str]:
    """Parse 'ctrl+v' into ydotool key command with evdev scancodes.

    ydotool v0.1.8 syntax: ``ydotool key <code>:1 <code>:0`` where
    ``:1`` = press, ``:0`` = release.  Modifiers are pressed first in
    order, then the key is pressed+released, then modifiers are released
    in reverse order.
    """
    parts = shortcut.lower().split("+")
    key = parts[-1]
    modifiers = parts[:-1]

    events: list[str] = []
    # Press modifiers
    for mod in modifiers:
        code = _EVDEV_SCANCODES.get(mod)
        if code is None:
            raise ValueError(f"Unknown modifier for ydotool: {mod}")
        events.append(f"{code}:1")
    # Press + release key
    key_code = _EVDEV_SCANCODES.get(key)
    if key_code is None:
        raise ValueError(f"Unknown key for ydotool: {key}")
    events.append(f"{key_code}:1")
    events.append(f"{key_code}:0")
    # Release modifiers in reverse
    for mod in reversed(modifiers):
        code = _EVDEV_SCANCODES[mod]
        events.append(f"{code}:0")

    return ["ydotool", "key", *events]


class Paster:
    def __init__(
        self,
        display_server: str | None = None,
        app_rules: list | None = None,
        keystroke_tool: str | None = None,
    ) -> None:
        self._display_server = display_server or detect_display_server()
        self._app_rules = app_rules
        self._matcher = None
        if app_rules:
            from talk_to_tux.config import AppRuleMatcher
            self._matcher = AppRuleMatcher(app_rules)
        # Keystroke backend: set from config or detected lazily
        self._keystroke_tool_config = keystroke_tool  # "auto" | "wtype" | "ydotool" | "xdotool" | None
        self._keystroke_backend: str | None = None
        self._ydotool_type_only: bool = False  # True when ydotool key injection is broken

    async def check_tools(self) -> dict[str, bool]:
        return await check_system_tools(self._display_server)

    async def _test_tool(self, *cmd: str) -> bool:
        """Run a command and return True if it exits 0."""
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
            return proc.returncode == 0
        except (FileNotFoundError, OSError):
            return False

    async def _ensure_ydotoold(self) -> None:
        """Ensure ydotoold daemon is running. Start it if not.

        Sets ``_ydotool_type_only`` when the daemon cannot be started —
        older ydotool (0.1.x) can still ``type`` text but ``key`` injection
        produces garbage without the daemon.
        """
        try:
            proc = await asyncio.create_subprocess_exec(
                "pgrep", "-x", "ydotoold",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
            if proc.returncode == 0:
                return  # already running

            logger.info("Starting ydotoold daemon")
            await asyncio.create_subprocess_exec(
                "ydotoold",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
                start_new_session=True,
            )
            # Give daemon time to initialize
            await asyncio.sleep(0.5)

            # Verify it actually started
            proc2 = await asyncio.create_subprocess_exec(
                "pgrep", "-x", "ydotoold",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc2.wait()
            if proc2.returncode != 0:
                self._ydotool_type_only = True
                logger.info(
                    "ydotoold not running — using evdev uinput for "
                    "keystroke injection")
        except (FileNotFoundError, OSError):
            self._ydotool_type_only = True
            logger.info(
                "ydotoold not found — using evdev uinput for "
                "keystroke injection")

    async def _ensure_backend(self) -> None:
        """Detect keystroke backend once (lazy). No-op after first call."""
        if self._keystroke_backend is not None:
            return

        # X11 always uses xdotool
        if self._display_server != "wayland":
            self._keystroke_backend = "xdotool"
            return

        # Config override (non-auto)
        if self._keystroke_tool_config and self._keystroke_tool_config != "auto":
            self._keystroke_backend = self._keystroke_tool_config
            logger.info("Keystroke backend: %s (configured)", self._keystroke_backend)
            if self._keystroke_backend == "ydotool":
                await self._ensure_ydotoold()
            return

        # Auto-detect on Wayland: wtype -> ydotool -> xdotool
        if await self._test_tool("wtype", ""):
            self._keystroke_backend = "wtype"
        elif await self._test_tool("which", "ydotool"):
            self._keystroke_backend = "ydotool"
            await self._ensure_ydotoold()
        elif await self._test_tool("xdotool", "version"):
            self._keystroke_backend = "xdotool"
        else:
            # Last resort
            self._keystroke_backend = "wtype"
            logger.warning("No keystroke tool found, defaulting to wtype")

        logger.info("Keystroke backend: %s (auto-detected)", self._keystroke_backend)

    def _build_paste_cmd(
        self, terminal: bool, window_id: str | None = None,
    ) -> list[str]:
        """Build paste keystroke command for the current backend."""
        backend = self._keystroke_backend
        if backend == "wtype":
            if terminal:
                return ["wtype", "-M", "ctrl", "-M", "shift", "v", "-m", "shift", "-m", "ctrl"]
            return ["wtype", "-M", "ctrl", "v", "-m", "ctrl"]
        elif backend == "ydotool":
            shortcut = "ctrl+shift+v" if terminal else "ctrl+v"
            return _parse_shortcut_ydotool(shortcut)
        else:  # xdotool
            key = "ctrl+shift+v" if terminal else "ctrl+v"
            cmd = ["xdotool", "key"]
            if window_id:
                cmd.extend(["--window", window_id])
            cmd.extend(["--delay", "0", key])
            return cmd

    def _build_key_cmd(self, key: str, window_id: str | None = None) -> list[str]:
        """Build single key press command (e.g. Return)."""
        backend = self._keystroke_backend
        if backend == "wtype":
            return ["wtype", "-k", key]
        elif backend == "ydotool":
            code = _EVDEV_SCANCODES.get(key.lower())
            if code is None:
                raise ValueError(f"Unknown key for ydotool: {key}")
            return ["ydotool", "key", f"{code}:1", f"{code}:0"]
        else:  # xdotool
            cmd = ["xdotool", "key"]
            if window_id:
                cmd.extend(["--window", window_id])
            cmd.extend(["--delay", "0", key])
            return cmd

    def _build_type_cmd(
        self, text: str, window_id: str | None = None,
    ) -> list[str]:
        """Build direct text typing command."""
        backend = self._keystroke_backend
        if backend == "wtype":
            return ["wtype", "--", text]
        elif backend == "ydotool":
            return ["ydotool", "type", "--", text]
        else:  # xdotool
            cmd = ["xdotool", "type"]
            if window_id:
                cmd.extend(["--window", window_id])
            cmd.extend(["--delay", "0", "--", text])
            return cmd

    def _build_shortcut_cmd(
        self, shortcut: str, window_id: str | None = None,
    ) -> list[str]:
        """Build arbitrary shortcut command (e.g. 'ctrl+z')."""
        backend = self._keystroke_backend
        if backend == "wtype":
            return _parse_shortcut_wtype(shortcut)
        elif backend == "ydotool":
            return _parse_shortcut_ydotool(shortcut)
        else:  # xdotool
            return _parse_shortcut_xdotool(shortcut, window_id)

    async def _get_active_window_id(self) -> str | None:
        if self._display_server != "x11":
            return None
        try:
            proc = await asyncio.create_subprocess_exec(
                "xdotool", "getactivewindow",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode == 0 and stdout:
                return stdout.decode().strip()
        except Exception:
            logger.debug("Failed to get active window ID", exc_info=True)
        return None

    async def _activate_window(self, window_id: str) -> bool:
        if self._display_server != "x11":
            return False
        try:
            proc = await asyncio.create_subprocess_exec(
                "xdotool", "windowactivate", window_id,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
            return proc.returncode == 0
        except Exception:
            logger.debug("Failed to activate window %s", window_id, exc_info=True)
            return False

    async def _ensure_focus(self, context: AppContext | None) -> bool:
        if context is None or not context.window_id:
            return True
        if self._display_server != "x11":
            return True
        try:
            current_id = await self._get_active_window_id()
            if current_id == context.window_id:
                return True
            logger.info(
                "Focus changed: %s → %s, restoring", context.window_id, current_id,
            )
            ok = await self._activate_window(context.window_id)
            if ok:
                await asyncio.sleep(0.1)
            return ok
        except Exception:
            logger.debug("Focus restoration failed", exc_info=True)
            return False

    def _resolve_rule(self, context: AppContext | None):
        """Look up per-app rule for the given context."""
        if self._matcher is None or context is None:
            return None
        return self._matcher.find(
            context.window_class, getattr(context, "window_title", None),
        )

    async def paste(self, text: str, context: AppContext | None = None) -> bool:
        if not text:
            return False
        await self._ensure_backend()
        await self._ensure_focus(context)

        rule = self._resolve_rule(context)
        window_id = getattr(context, "window_id", None) if context else None

        # Determine terminal status and clipboard delay from rule or fallback
        if rule is not None and rule.is_terminal is not None:
            terminal = rule.is_terminal
        else:
            terminal = is_terminal(context.window_class if context else None)

        # Wayland safety net: when window_class is unknown (extension not yet
        # active after install), use ctrl+shift+v which works in terminals
        # (required), GTK apps, Electron, and browsers.
        if (
            not terminal
            and self._display_server == "wayland"
            and context is not None
            and context.window_class is None
        ):
            terminal = True

        clipboard_delay = 0.05  # default 50ms
        if rule is not None and rule.clipboard_delay_ms is not None:
            clipboard_delay = rule.clipboard_delay_ms / 1000

        # Only use --window targeting for terminals (XSendEvent workaround for
        # kitty keyboard protocol). Non-terminal apps like Flutter ignore
        # XSendEvent — use XTEST (no --window) for reliable delivery.
        keystroke_window_id = window_id if terminal else None

        # If rule specifies a custom paste shortcut, use it
        if rule is not None and rule.paste_shortcut is not None:
            try:
                await self._paste_via_clipboard_shortcut(
                    text, rule.paste_shortcut, clipboard_delay, keystroke_window_id,
                )
                return True
            except Exception:
                logger.debug("Custom shortcut paste failed, trying fallback", exc_info=True)

        # Honour paste_method from app rule
        if rule is not None and rule.paste_method == "typing":
            try:
                return await self._paste_via_typing(text, keystroke_window_id)
            except Exception:
                logger.debug("Typing paste failed, trying clipboard fallback", exc_info=True)

        # Standard clipboard paste
        try:
            await self._paste_via_clipboard(text, terminal, clipboard_delay, keystroke_window_id)
            return True
        except Exception:
            logger.debug("Clipboard paste failed, trying direct typing", exc_info=True)
        try:
            return await self._paste_via_typing(text, keystroke_window_id)
        except Exception:
            logger.warning("All paste methods failed", exc_info=True)
            return False

    async def _paste_via_clipboard_shortcut(
        self, text: str, shortcut: str, delay: float = 0.05,
        window_id: str | None = None,
    ) -> None:
        """Set clipboard and simulate a custom paste shortcut."""
        await self._set_clipboard(text)
        await asyncio.sleep(delay)
        await self._simulate_custom_keystroke(shortcut, window_id)

    async def _simulate_custom_keystroke(
        self, shortcut: str, window_id: str | None = None,
    ) -> None:
        """Simulate a custom shortcut like 'ctrl+v' or 'ctrl+shift+v'."""
        await self._ensure_backend()

        # ydotool without daemon: use evdev uinput for keystroke injection.
        if self._ydotool_type_only:
            loop = asyncio.get_running_loop()
            ok = await loop.run_in_executor(
                None, self._inject_keys_uinput, shortcut,
            )
            if not ok:
                raise RuntimeError("UInput custom keystroke failed")
            return

        cmd = self._build_shortcut_cmd(shortcut, window_id)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
        if proc.returncode != 0:
            raise RuntimeError(f"Custom keystroke command failed with rc={proc.returncode}")

    async def _paste_via_clipboard(
        self, text: str, terminal: bool, delay: float = 0.05,
        window_id: str | None = None,
    ) -> None:
        await self._set_clipboard(text)
        await asyncio.sleep(delay)
        await self._simulate_paste_keystroke(terminal, window_id)

    async def _set_clipboard(self, text: str) -> None:
        if self._display_server == "wayland":
            cmd = ["wl-copy", "--"]
        else:
            cmd = ["xclip", "-selection", "clipboard"]

        logger.debug("_set_clipboard: %s (%d bytes)", cmd[0], len(text.encode()))
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate(input=text.encode())
        if proc.returncode != 0:
            raise RuntimeError(f"Clipboard command failed with rc={proc.returncode}")

    async def _simulate_paste_keystroke(
        self, terminal: bool, window_id: str | None = None,
    ) -> None:
        await self._ensure_backend()

        # ydotool without daemon: use evdev uinput for keystroke injection.
        if self._ydotool_type_only:
            shortcut = "ctrl+shift+v" if terminal else "ctrl+v"
            loop = asyncio.get_running_loop()
            ok = await loop.run_in_executor(
                None, self._inject_keys_uinput, shortcut,
            )
            if not ok:
                raise RuntimeError("UInput paste keystroke failed")
            return

        cmd = self._build_paste_cmd(terminal, window_id)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
        if proc.returncode != 0:
            raise RuntimeError(f"Keystroke command failed with rc={proc.returncode}")

    async def send_undo(self, window_id: str | None = None) -> bool:
        """Simulate Ctrl+Z to undo the last action."""
        await asyncio.sleep(0.05)
        await self._ensure_backend()

        # ydotool without daemon: use evdev uinput for keystroke injection.
        if self._ydotool_type_only:
            try:
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(
                    None, self._inject_keys_uinput, "ctrl+z",
                )
            except Exception:
                logger.debug("send_undo (evdev uinput) failed", exc_info=True)
                return False

        cmd = self._build_shortcut_cmd("ctrl+z", window_id)
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
            return proc.returncode == 0
        except Exception:
            logger.debug("send_undo failed", exc_info=True)
            return False

    async def send_enter(self, window_id: str | None = None, **_kw) -> bool:
        """Simulate pressing Enter (e.g. to send a message after paste)."""
        await asyncio.sleep(0.05)  # let paste settle
        await self._ensure_backend()
        # ydotool without daemon: use evdev uinput for key injection.
        if self._ydotool_type_only:
            try:
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(
                    None, self._inject_keys_uinput, "enter",
                )
            except Exception:
                logger.debug("send_enter (evdev uinput) failed", exc_info=True)
                return False
        # On xdotool, activate target window first, then use XTEST (no --window).
        # --window uses XSendEvent which terminals like Kitty ignore.
        if self._keystroke_backend == "xdotool" and window_id:
            await self._activate_window(window_id)
            await asyncio.sleep(0.05)
        cmd = self._build_key_cmd("Return")
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
            return proc.returncode == 0
        except Exception:
            logger.debug("send_enter failed", exc_info=True)
            return False

    @staticmethod
    def _inject_keys_uinput(shortcut: str) -> bool:
        """Inject arbitrary key combo via evdev uinput (works without ydotoold).

        Accepts shortcut strings like "ctrl+v", "ctrl+shift+v", "ctrl+z", "enter".
        """
        import evdev

        parts = shortcut.lower().split("+")
        key_name = parts[-1]
        modifier_names = parts[:-1]

        # Resolve scancodes
        modifier_codes: list[int] = []
        for mod in modifier_names:
            code = _EVDEV_SCANCODES.get(mod)
            if code is None:
                raise ValueError(f"Unknown modifier for uinput: {mod}")
            modifier_codes.append(code)

        key_code = _EVDEV_SCANCODES.get(key_name)
        if key_code is None:
            raise ValueError(f"Unknown key for uinput: {key_name}")

        import time

        ui = evdev.UInput()
        try:
            # Press modifiers
            for code in modifier_codes:
                ui.write(evdev.ecodes.EV_KEY, code, 1)
            # Press key
            ui.write(evdev.ecodes.EV_KEY, key_code, 1)
            ui.syn()
            # Let the terminal fully process the press event
            time.sleep(0.05)
            # Release key
            ui.write(evdev.ecodes.EV_KEY, key_code, 0)
            # Release modifiers in reverse
            for code in reversed(modifier_codes):
                ui.write(evdev.ecodes.EV_KEY, code, 0)
            ui.syn()
            # Wait for release to be fully consumed before destroying device
            time.sleep(0.05)
            return True
        finally:
            ui.close()

    async def _paste_via_typing(
        self, text: str, window_id: str | None = None,
    ) -> bool:
        await self._ensure_backend()
        cmd = self._build_type_cmd(text, window_id)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
        ok = proc.returncode == 0
        if ok:
            try:
                await self._set_clipboard(text)
            except Exception:
                logger.debug("Best-effort clipboard copy after typing paste failed", exc_info=True)
        return ok
