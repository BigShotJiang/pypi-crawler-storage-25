"""cli_hosted.logout — 'talk-to-tux logout' subcommand."""
from __future__ import annotations

import argparse
from typing import TYPE_CHECKING

from talk_to_tux.auth.token_store import KeyringTokenStore

if TYPE_CHECKING:
    from talk_to_tux.config import Settings


def run(args: argparse.Namespace, settings: Settings) -> int:
    store = KeyringTokenStore()
    if store.load() is None:
        print("Not signed in.")
        return 0

    store.delete()
    print("Signed out.")
    return 0
