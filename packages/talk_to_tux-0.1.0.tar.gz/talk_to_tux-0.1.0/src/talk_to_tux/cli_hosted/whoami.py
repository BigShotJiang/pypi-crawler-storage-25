"""cli_hosted.whoami — 'talk-to-tux whoami' subcommand."""
from __future__ import annotations

import argparse
from typing import TYPE_CHECKING

from talk_to_tux.auth.token_store import KeyringTokenStore
from talk_to_tux.hosted.identity import load_identity

if TYPE_CHECKING:
    from talk_to_tux.config import Settings

_NOT_SIGNED_IN = "Not signed in. Run 'talk-to-tux login' to connect."


def run(args: argparse.Namespace, settings: Settings) -> int:
    store = KeyringTokenStore()
    identity = load_identity(store)

    if identity is None or identity.expired:
        print(_NOT_SIGNED_IN)
        return 1

    expires_str = identity.expires_at.isoformat() if identity.expires_at is not None else "never"
    print(f"Signed in as {identity.email} (tier: {identity.tier}) \u2014 token expires {expires_str}")
    return 0
