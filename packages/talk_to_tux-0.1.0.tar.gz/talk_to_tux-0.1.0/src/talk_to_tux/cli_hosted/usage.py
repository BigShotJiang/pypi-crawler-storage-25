"""cli_hosted.usage — 'talk-to-tux usage' subcommand."""
from __future__ import annotations

import argparse
import asyncio
from typing import TYPE_CHECKING

from talk_to_tux.auth import HostedError, TokenInvalid
from talk_to_tux.auth.token_store import KeyringTokenStore
from talk_to_tux.hosted.quota_client import HostedQuotaClient

if TYPE_CHECKING:
    from talk_to_tux.config import Settings


async def _run(args: argparse.Namespace, settings: Settings) -> int:
    store = KeyringTokenStore()
    if store.load() is None:
        print("Not signed in. Run 'talk-to-tux login' to connect.")
        return 1

    client = HostedQuotaClient(settings.hosted, store)
    try:
        snapshot = await client.fetch()
    except TokenInvalid:
        print("Token invalid or expired. Run 'talk-to-tux login' to reconnect.")
        return 1
    except HostedError as exc:
        print(f"Failed to fetch quota: {exc}")
        return 1
    finally:
        await client.aclose()

    stt_used = f"{snapshot.stt_hours_used:.1f}"
    stt_limit = f"{snapshot.stt_hours_limit:.1f}" if snapshot.stt_hours_limit is not None else "unlimited"
    rewrite_limit = str(snapshot.rewrite_limit) if snapshot.rewrite_limit is not None else "unlimited"

    print(f"Tier: {snapshot.tier}")
    print(f"Period: {snapshot.period_start.date()} to {snapshot.period_end.date()}")
    print(f"STT: {stt_used} / {stt_limit} hrs")
    print(f"Rewrites: {snapshot.rewrite_used} / {rewrite_limit}")
    return 0


def run(args: argparse.Namespace, settings: Settings) -> int:
    return asyncio.run(_run(args, settings))
