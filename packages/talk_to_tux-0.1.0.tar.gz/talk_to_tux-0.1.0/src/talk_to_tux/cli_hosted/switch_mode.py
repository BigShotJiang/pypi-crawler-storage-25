"""cli_hosted.switch_mode — 'talk-to-tux switch-mode {hosted,byo-key}' subcommand."""
from __future__ import annotations

import argparse
from typing import TYPE_CHECKING

from talk_to_tux.auth.token_store import KeyringTokenStore
from talk_to_tux.setup_wizard import set_api_mode

if TYPE_CHECKING:
    from talk_to_tux.config import Settings

_MODE_MAP = {
    "byo-key": "byo_key",
    "hosted": "hosted",
}


def run(args: argparse.Namespace, settings: Settings) -> int:
    cli_mode: str = args.mode  # "hosted" or "byo-key"
    toml_mode = _MODE_MAP[cli_mode]

    if toml_mode == "hosted":
        store = KeyringTokenStore()
        if store.load() is None:
            print("No hosted account found. Run 'talk-to-tux login' first.")
            return 1

    set_api_mode(toml_mode)
    print(f"API mode set to {cli_mode}.")
    return 0
