"""cli_hosted — hosted-mode CLI subcommand registry and dispatcher. (SL-0 scaffold)"""
from __future__ import annotations

import argparse
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from talk_to_tux.config import Settings

_SUBCOMMANDS = ("login", "logout", "whoami", "usage", "switch-mode")


def add_hosted_subparsers(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register hosted-mode subparsers onto the root parser's subparsers action."""
    login_p = subparsers.add_parser("login", help="Sign in to hosted mode")
    login_p.set_defaults(command="login")

    logout_p = subparsers.add_parser("logout", help="Sign out of hosted mode")
    logout_p.set_defaults(command="logout")

    whoami_p = subparsers.add_parser("whoami", help="Show current signed-in account")
    whoami_p.set_defaults(command="whoami")

    usage_p = subparsers.add_parser("usage", help="Show quota usage")
    usage_p.set_defaults(command="usage")

    switch_p = subparsers.add_parser("switch-mode", help="Switch between hosted and BYO-key modes")
    switch_p.add_argument(
        "mode",
        choices=["hosted", "byo-key"],
        help="Target mode: hosted or byo-key",
    )
    switch_p.set_defaults(command="switch-mode")


def dispatch(args: argparse.Namespace, settings: Settings) -> int | None:
    """Dispatch to a hosted subcommand if one was requested.

    Returns None when no hosted subcommand was given (normal daemon startup).
    Returns an int exit code otherwise.
    """
    command = getattr(args, "command", None)
    if command is None:
        return None

    if command == "login":
        from talk_to_tux.cli_hosted import login
        return login.run(args, settings)
    if command == "logout":
        from talk_to_tux.cli_hosted import logout
        return logout.run(args, settings)
    if command == "whoami":
        from talk_to_tux.cli_hosted import whoami
        return whoami.run(args, settings)
    if command == "usage":
        from talk_to_tux.cli_hosted import usage
        return usage.run(args, settings)
    if command == "switch-mode":
        from talk_to_tux.cli_hosted import switch_mode
        return switch_mode.run(args, settings)

    return None
