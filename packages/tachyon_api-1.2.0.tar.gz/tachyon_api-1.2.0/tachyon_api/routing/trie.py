"""
Radix trie router — O(k) path matching where k = number of path segments.

Replaces Starlette's O(N × regex) linear route scan. Each static segment is
a dict lookup; each param segment is a single branch check.

Path format: /users/{user_id}/profile  (Starlette / FastAPI convention)
"""

from __future__ import annotations

from types import MappingProxyType
from typing import Callable, Dict, Optional, Set, Tuple, Any


_NOT_FOUND          = 0
_METHOD_NOT_ALLOWED = 1
_FOUND              = 2

# Immutable empty sentinel — returned for routes with no path params.
# MappingProxyType prevents accidental mutation; safe because nobody writes to path_params.
_EMPTY_PARAMS = MappingProxyType({})


class _Node:
    """One node in the radix trie — represents one path segment."""

    __slots__ = ("static", "param_child", "param_name", "handlers", "allowed", "allow_header")

    def __init__(self) -> None:
        self.static: Dict[str, _Node] = {}       # segment text → child
        self.param_child: Optional[_Node] = None  # {name} wildcard child
        self.param_name: Optional[str] = None     # name extracted from {name}
        self.handlers: Dict[str, Callable] = {}   # METHOD → async handler
        self.allowed: Set[str] = set()            # all registered methods (for 405)
        self.allow_header: str = ""               # pre-sorted Allow header value, e.g. "GET, POST"


class RadixTrie:
    """
    Register routes at startup, match in O(k) per request.

    Usage:
        trie = RadixTrie()
        trie.add("/users/{id}", "GET", handler)
        status, handler, params, allowed = trie.match("/users/42", "GET")
    """

    __slots__ = ("_root",)

    def __init__(self) -> None:
        self._root = _Node()

    # ── Registration ────────────────────────────────────────────────────────

    def add(self, path: str, method: str, handler: Callable) -> None:
        """Register a (path, method) → handler mapping."""
        node = self._root
        for seg in _segments(path):
            if seg[0] == "{" and seg[-1] == "}":
                # Param segment — create param child if needed
                if node.param_child is None:
                    node.param_child = _Node()
                    node.param_child.param_name = seg[1:-1]
                node = node.param_child
            else:
                # Static segment — O(1) dict lookup/insert
                child = node.static.get(seg)
                if child is None:
                    child = _Node()
                    node.static[seg] = child
                node = child

        m = method.upper()
        node.handlers[m] = handler
        node.allowed.add(m)
        # Keep Allow header pre-sorted — avoids sorted() on every 405 response
        node.allow_header = ", ".join(sorted(node.allowed))

    # ── Matching ─────────────────────────────────────────────────────────────

    def match(
        self, path: str, method: str
    ) -> Tuple[int, Optional[Callable], Dict[str, str], Optional[str]]:
        """
        Match path + method in O(k).

        Returns (status, handler, path_params, allow_header):
        - status 0 (_NOT_FOUND):          no path match
        - status 1 (_METHOD_NOT_ALLOWED): path matched, method not registered
        - status 2 (_FOUND):              full match

        path_params is _EMPTY_PARAMS (MappingProxyType) for routes with no path
        parameters — avoids a dict allocation on every static-route request.
        """
        node = self._root
        path_params = None  # deferred: only allocated on first param segment hit

        length = len(path)
        pos = 1 if length > 0 and path[0] == "/" else 0

        while pos < length:
            slash = path.find("/", pos)
            if slash == -1:
                seg = path[pos:]
                pos = length
            else:
                seg = path[pos:slash]
                pos = slash + 1

            if not seg:
                continue

            child = node.static.get(seg)
            if child is not None:
                node = child
            elif node.param_child is not None:
                if path_params is None:
                    path_params = {}
                path_params[node.param_child.param_name] = seg
                node = node.param_child
            else:
                return _NOT_FOUND, None, _EMPTY_PARAMS, None

        handler = node.handlers.get(method.upper())
        if handler is not None:
            return _FOUND, handler, path_params if path_params is not None else _EMPTY_PARAMS, None

        if node.allowed:
            return _METHOD_NOT_ALLOWED, None, path_params if path_params is not None else _EMPTY_PARAMS, node.allow_header

        return _NOT_FOUND, None, _EMPTY_PARAMS, None


def _segments(path: str):
    """Split a URL path into non-empty segments."""
    return [s for s in path.split("/") if s]
