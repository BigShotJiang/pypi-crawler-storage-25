# haluguard CLI

[![PyPI version](https://img.shields.io/pypi/v/haluguard.svg)](https://pypi.org/project/haluguard/)
[![License](https://img.shields.io/pypi/l/haluguard.svg)](./LICENSE)

Verify LLM output for hallucinations directly from your terminal or CI/CD pipeline.
Plugs into the [haluguard](https://haluguard.com) hosted API.

## Install

```bash
pip install haluguard
```

Zero runtime dependencies — pure stdlib, installs in seconds.

## Quick start

```bash
# 1. Save your API token (get one at haluguard.com)
haluguard auth login

# 2. Verify a file
haluguard check report.md

# 3. Or pipe input
echo "Microsoft was founded in 1981 by Bill Gates." | haluguard check

# JSON output for scripts / CI
haluguard check report.md --json | jq .

# Exit non-zero only above a confidence threshold (useful in CI)
haluguard check report.md --threshold 0.7
```

## Output

Human-readable by default:

```
✗ HALLUCINATIONS    severity=clear  score=0.95  claims=1/2  latency=4ms
verdict source: data_contradicted

  [CONTRADICTED] high · wikidata
    claim:    Microsoft was founded in 1981
    evidence: Wikidata confirms Microsoft was founded in 1975
    source:   https://www.wikidata.org/wiki/Q2283
    fix:      1975
```

`--json` returns the raw API response (verdict, severity_tier, score, findings, etc).

## Exit codes

| Code | Meaning |
|------|---------|
| 0    | Clean / no hallucinations above threshold |
| 1    | Hallucinations detected |
| 2    | Transient API error (rate-limited, 5xx, network) |
| 3    | Auth error (no token / invalid token) |
| 4    | Bad input / usage |

## CI/CD example — GitHub Actions

```yaml
- name: Verify generated docs
  env:
    HALUGUARD_TOKEN: ${{ secrets.HALUGUARD_TOKEN }}
  run: |
    pip install haluguard
    haluguard check generated/release-notes.md --threshold 0.7
```

For a dedicated GitHub Action with richer output, see
[haluguard-action](https://github.com/haluguard/check-action).

## Env vars

| Var | Default | Purpose |
|-----|---------|---------|
| `HALUGUARD_TOKEN` | (required) | Bearer token. Used in CI. Overrides `~/.haluguard/config.json`. |
| `HALUGUARD_API_URL` | `https://api.haluguard.com` | Override for self-host / dev. |
| `NO_COLOR` | unset | Disable ANSI colors. |

## License

MIT (the CLI itself). The hosted API behind it is a paid subscription
service — see [haluguard.com](https://haluguard.com).
