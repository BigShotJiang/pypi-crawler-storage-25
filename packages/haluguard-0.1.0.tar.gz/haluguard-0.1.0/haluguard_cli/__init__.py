"""haluguard CLI — verify LLM output from your terminal or CI/CD pipeline."""

__version__ = "0.1.0"
