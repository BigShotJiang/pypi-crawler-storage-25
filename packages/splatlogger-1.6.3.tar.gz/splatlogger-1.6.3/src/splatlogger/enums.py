# Splatlogger (c) 2025 Shadow Doggo.

from enum import IntEnum


class Pointers(IntEnum):
    SESSION = 0x106EB980
    STATIC_MEM = 0x106E0330
    MAIN_MGR_BASE = 0x106E5814
    MAIN_MGR_VS_GAME = 0x106E7FF8


class Addresses(IntEnum):
    # A bunch of data including player stats from the latest match somewhere on the stack.
    # I'm not exactly sure what this is, but it works.
    WIN_TEAM = 0x107AF914
    STATS = 0x107AF944


class Offsets(IntEnum):
    SESSION_ID_IDX = 0xBD
    SESSION_ID = 0xCC
    MAINMGR_PLAYER_MGR = 0x268
    MAINMGR_SCENE_INFO = 0x2A4
    PLAYERMGR_PLAYER_COUNT = 0x320
    SCENE_INFO_RESULTS_SHOWN = 0x330  # Some sort of timer?
    STATICMEM_PLAYER_INFO_ARY = 0x10
    STATICMEM_STAGE = 0x28
    STATICMEM_MATCH_HOUR = 0x234
    STATICMEM_VERSUS_MODE = 0x238
    STATICMEM_VERSUS_RULE = 0x23C
    CEMU_WIN_TEAM = 0xF556C
    CEMU_STATS = 0xF559C
