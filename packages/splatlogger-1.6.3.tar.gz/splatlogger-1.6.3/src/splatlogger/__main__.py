# Splatlogger (c) 2025 Shadow Doggo.

import argparse
import binascii
import ipaddress
import json
import sys
import time
import webbrowser
from base64 import b64decode
from datetime import datetime
from importlib import resources
from pathlib import Path
from typing import Optional
from xml.etree import ElementTree

import requests
import userpaths  # type: ignore[import-untyped]

from .cemu_gecko import CemuGecko, CemuGeckoError
from .enums import Pointers, Offsets
from .match_logger import MatchLogger
from .tcpgecko import TCPGecko, TCPGeckoError, to_hex, GeckoConnectionFailedError
from .tcpgecko_aroma import TCPGeckoAroma
from .tuples import Options, CommonAddresses, AccountInfo, PlayerInfo

_VERSION = "1.6.3"
_OPTIONS: Options
_GECKO: TCPGecko | TCPGeckoAroma | CemuGecko
_STATIC_MEM_ADR: int
_API: dict[str, str]
with resources.path(__package__, "data") as data_path:
    try:
        with open(data_path / "api.json", "r", encoding="utf-8") as api_f:
            _API = json.load(api_f)
    except FileNotFoundError:
        print("Couldn't find 'api.json'. The package may have been installed incorrectly.")
        sys.exit()


def main() -> None:
    print(f"Splatlogger v{_VERSION} by Shadow Doggo\n")

    parser = argparse.ArgumentParser(description="PID (Principal ID)/PNID grabber and match logger for Splatoon.")
    parser.add_argument("-ip", help="Your Wii U's LAN IP address.")
    parser.add_argument("-aroma", help="Switch to Aroma mode. Enable if using the TCPGecko Aroma plugin.",
                        action="store_true")
    parser.add_argument("-cemu",
                        help="Switch to Cemu mode (optional: PID of the Cemu process).", metavar="PID",
                        nargs="?", const=-1)
    parser.add_argument("-log-level", help="Set how much data should be logged (see README).",
                        choices=["none", "standard", "extended", "stats"], default="standard")
    parser.add_argument("-auto",
                        help="Enable auto logging (see README).",
                        choices=["all", "latest"], nargs="?", const="all")
    parser.add_argument("-stack",
                        help="Beginning address of the stack space for Default Core 1 (Cemu only, see README).",
                        metavar="Address (in hex)")
    parser.add_argument("-spfn", help="Fetch SFID instead of PNID. Enable if playing on SPFN.",
                        action="store_true")
    parser.add_argument("-no-pnid", help="Disable fetching PNIDs.", action="store_true")
    parser.add_argument("-silent", help="Disable printing logs to the console.", action="store_true")

    if (args_path := Path(userpaths.get_my_documents()) / "Splatlogger/args.txt").is_file():
        with open(args_path, encoding="utf-8") as args_f:
            args = parser.parse_args(args_f.read().split())
    else:
        args = parser.parse_args()

    if len(sys.argv) == 1 and not args_path.is_file():
        print('No arguments were provided. Run "splatlogger -h" for help.'
              "\nWould you like to open the README? (y/n)")
        if input().lower() in ("y", "yes"):
            webbrowser.open("https://codeberg.org/ShadowDoggo/Splatlogger/src/branch/main/README.md")

        sys.exit()

    if args.aroma and args.cemu:
        print("Cannot use both Aroma and Cemu modes.")
        sys.exit()

    stack_addr: int | None = None
    if args.stack and args.cemu:
        try:
            stack_addr = int(args.stack, 16)
        except ValueError:
            print("Invalid stack address. Please provide a valid hex value.")
            sys.exit()

    global _OPTIONS
    _OPTIONS = Options(log_level=args.log_level,
                       auto_logging=args.auto in ("all", "latest"),
                       log_latest=args.auto == "latest",
                       aroma=args.aroma,
                       cemu=args.cemu is not None,
                       spfn=args.spfn,
                       no_pnid=args.no_pnid,
                       silent_logging=args.silent,
                       stack=stack_addr)

    ptr_offset = 0
    global _GECKO
    if args.cemu:
        ptr_offset = 0x503000
        try:
            print("Opening Cemu process...")
            _GECKO = CemuGecko(int(args.cemu))
        except CemuGeckoError as e:
            print(e)
            sys.exit()
    else:
        try:
            ipaddress.ip_address(args.ip)
            print("Connecting to:", args.ip)
            _GECKO = TCPGeckoAroma(args.ip) if _OPTIONS.aroma else TCPGecko(args.ip)
        except ValueError:
            print("Please provide a valid IP address.")
            sys.exit()
        except GeckoConnectionFailedError as e:
            print(e)
            sys.exit()

    global _STATIC_MEM_ADR
    _STATIC_MEM_ADR = 0
    for _ in range(3):
        try:
            _STATIC_MEM_ADR = _GECKO.peek32(Pointers.STATIC_MEM - ptr_offset)
            assert _STATIC_MEM_ADR != 0

            print("Success.\n" if _OPTIONS.cemu else "Connected.\n")
            break
        except (OSError, TCPGeckoError) as e:
            print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
            time.sleep(10)
        except AssertionError:
            print("\nCould not find StaticMem address."
                  "\nIf you're on Cemu, this is likely due to the program not being able to read process memory",
                  "due to ptrace protection."
                  "\nRetrying in 10 seconds...")
            time.sleep(10)
    else:
        _exit_with_close("\nFailed after 3 tries.")

    match_logger: MatchLogger | None = None
    if _OPTIONS.log_level != "none":
        try:
            match_logger = MatchLogger(_OPTIONS, _GECKO, _STATIC_MEM_ADR)
        except FileNotFoundError:
            _exit_with_close("Couldn't find 'names.json'. The package may have been installed incorrectly.")
    if match_logger:
        try:
            match_logger.create_new_log()
        except OSError as e:
            _exit_with_close(f"Failed to create log file: {e}")

        if _OPTIONS.auto_logging:
            print("Auto logging enabled.")
            _auto_log(match_logger)

    for _ in range(3):
        try:
            _splatlog(match_logger, match_count=1)
            break
        except (OSError, TCPGeckoError) as e:
            print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
            time.sleep(10)
    else:
        _exit_with_close("\nFailed after 3 tries.")


def _auto_log(match_logger: MatchLogger) -> None:
    match_in_progress = False
    count = 0
    retry_count = 0
    ptr_offset = 0x503000 if _OPTIONS.cemu else 0
    while True:
        try:
            main_mgr_vs_game_adr = _GECKO.peek32(Pointers.MAIN_MGR_VS_GAME - ptr_offset)
            if main_mgr_vs_game_adr == 0:
                match_in_progress = False

            # MainMgrVSGame is initialized when a VS match starts.
            if not match_in_progress and main_mgr_vs_game_adr != 0:
                match_in_progress = True
                count += 1

                if _OPTIONS.log_latest:
                    match_logger.create_new_log()

                if not _OPTIONS.silent_logging:
                    print(f"\nMatch {count}\n")

                time.sleep(1)

                for _ in range(3):
                    try:
                        _splatlog(match_logger, count)
                        break
                    except (OSError, TCPGeckoError) as e:
                        print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
                        time.sleep(10)
                else:
                    _exit_with_close("\nFailed after 3 tries.")

            retry_count = 0
            time.sleep(10)
        except KeyboardInterrupt:
            _exit_with_close("\nExiting.")
        except (OSError, TCPGeckoError) as e:
            if retry_count < 3:
                print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
                retry_count += 1
                time.sleep(10)
            else:
                _exit_with_close("\nFailed after 3 tries.")


def _splatlog(match_logger: MatchLogger | None, match_count: int) -> None:
    session_id = 0
    player_count = 8
    request_errors: list[str] = []
    player_info_list: list[PlayerInfo] = []
    date = datetime.now()
    ptr_offset = 0x503000 if _OPTIONS.cemu else 0

    if (session_adr := _GECKO.peek32(Pointers.SESSION - ptr_offset)) != 0:
        session_id_idx = int.from_bytes(_GECKO.peek_raw(session_adr + Offsets.SESSION_ID_IDX,
                                                        length=1), byteorder="big")
        session_id = _GECKO.peek32(session_adr + session_id_idx * 4 + Offsets.SESSION_ID)

    main_mgr_base_adr = _GECKO.peek32(Pointers.MAIN_MGR_BASE - ptr_offset)
    if _GECKO.peek32(Pointers.MAIN_MGR_VS_GAME - ptr_offset) != 0 or _OPTIONS.auto_logging:
        if (player_mgr_adr := _GECKO.peek32(main_mgr_base_adr + Offsets.MAINMGR_PLAYER_MGR)) != 0:
            player_count = _GECKO.peek8(player_mgr_adr + Offsets.PLAYERMGR_PLAYER_COUNT)
    else:
        print("You are currently not in a match. Logging previous match data "
              "(Player 1 data will be your own, Session ID will be the current one).\n")

    player_info_ary_adr = _GECKO.peek32(_STATIC_MEM_ADR + Offsets.STATICMEM_PLAYER_INFO_ARY)
    assert player_info_ary_adr != 0, "PlayerInfoAry pointer is null."

    network_id_type = "SFID" if _OPTIONS.spfn else "PNID"
    print(f"{'Player':<8} | {'PID (Hex)':<10} | {'PID (Dec)':<10} | {network_id_type:<16} | Name\n"
          f"{'-' * 73}")

    for player_idx in range(player_count):
        player_info_adr = _GECKO.peek32(player_info_ary_adr + player_idx * 0x4)
        if player_info_adr == 0:
            continue

        player_info_raw = _GECKO.peek_raw(player_info_adr, length=0xD4)

        player_pid = int.from_bytes(player_info_raw[0xD0:0xD4], byteorder="big")
        if player_pid != 0:
            player_name = (player_info_raw[0x6:0x26]
                           .decode("utf-16-be")
                           .split("\u0000")[0]
                           .replace("\n", "")
                           .replace("\r", ""))

            if not _OPTIONS.no_pnid:
                act_info = _get_spfn_act_info(player_pid) if _OPTIONS.spfn else _get_act_info(player_pid)
                if act_info.request_error != "":
                    request_errors.append(act_info.request_error)
                    act_info = AccountInfo("", player_name, "")
            else:
                act_info = AccountInfo("", player_name, "")

            if _OPTIONS.log_level != "none":
                player_info_list.append(PlayerInfo(
                    idx=player_idx,
                    pid=player_pid,
                    pnid=act_info.pnid,
                    name=player_name,
                    mii_name=act_info.mii_name,
                    team=int.from_bytes(player_info_raw[0x33:0x34], byteorder="big"),
                    gender=int.from_bytes(player_info_raw[0x37:0x38], byteorder="big"),
                    skin_tone=int.from_bytes(player_info_raw[0x3B:0x3C], byteorder="big"),
                    eye_color=int.from_bytes(player_info_raw[0x3F:0x40], byteorder="big"),
                    weapon=int.from_bytes(player_info_raw[0x46:0x48], byteorder="big"),
                    sub_weapon=int.from_bytes(player_info_raw[0x4A:0x4C], byteorder="big"),
                    special_weapon=int.from_bytes(player_info_raw[0x4D:0x50], byteorder="big"),
                    shoes=int.from_bytes(player_info_raw[0x54:0x58], byteorder="big"),
                    clothes=int.from_bytes(player_info_raw[0x70:0x74], byteorder="big"),
                    headgear=int.from_bytes(player_info_raw[0x8C:0x90], byteorder="big"),
                    level=int.from_bytes(player_info_raw[0xAF:0xB0], byteorder="big", signed=True) + 1,
                    rank=int.from_bytes(player_info_raw[0xB3:0xB4], byteorder="big", signed=True)
                ))

            if not _OPTIONS.silent_logging:
                print(f"Player {player_idx + 1} | "
                      f"{to_hex(player_pid):<8} | "
                      f"{player_pid:<10} | "
                      f"{act_info.pnid:<16} | "
                      f"{player_name} {f'({act_info.mii_name})' if player_name != act_info.mii_name else ''}")

    if not _OPTIONS.silent_logging:
        print()
        if request_errors:
            print(f"Failed to get account data for one or more players: {'; '.join(request_errors)}\n")

        if session_id != 0:
            print(f"Session ID: {to_hex(session_id)} ({session_id})")
        else:
            print("Session ID: None")

        print(f"Fetched at: {date.strftime('%Y-%m-%d %H:%M:%S')} ({date.astimezone().tzname()})")

    if _OPTIONS.log_level != "none" and match_logger:
        adrs = CommonAddresses(main_mgr_base_adr, player_info_ary_adr)
        match_logger.log_match(date, session_id, match_count, player_info_list, adrs)


def _get_act_info(player_pid: int) -> AccountInfo:
    pnid = ""
    mii_name = ""
    request_error = ""

    for _ in range(3):
        try:
            response = requests.get(
                f"https://account.pretendo.cc/v1/api/miis?pids={player_pid}",
                headers={"X-Nintendo-Client-ID": _API["client_id"],
                         "X-Nintendo-Client-Secret": _API["client_secret"]},
                timeout=5
            )

            try:
                root = ElementTree.fromstring(response.text)
            except ElementTree.ParseError:
                return AccountInfo("", "", "Got empty or invalid response.")

            if not root or len(root) == 0:
                return AccountInfo("", "", "Got empty or invalid response.")

            if not (isinstance(root[0].find("user_id"), ElementTree.Element)
                    and isinstance(root[0].find("name"), ElementTree.Element)):
                return AccountInfo("", "", "Got empty or invalid response.")

            pnid = root[0].find("user_id").text  # type: ignore
            mii_name = (root[0].find("name")  # type: ignore
                        .text
                        .replace("\n", "")
                        .replace("\r", ""))
            break
        except requests.RequestException as ex:
            request_error = str(ex)
            time.sleep(1)

    return AccountInfo(pnid, mii_name, request_error)  # type: ignore


def _get_spfn_act_info(player_pid: int) -> AccountInfo:
    pnid = ""
    mii_name = ""
    request_error = ""

    for _ in range(3):
        try:
            response = requests.get(
                f"https://account.spfn.net/v1/api/miis?pids={player_pid}",
                timeout=5
            )
            mii_data_response = requests.get(
                f"https://account.spfn.net/api/v2/users/{player_pid}/mii",
                timeout=5
            )

            try:
                root = ElementTree.fromstring(response.text)
            except ElementTree.ParseError:
                return AccountInfo("", "", "Got empty or invalid response.")

            if not root or len(root) == 0:
                return AccountInfo("", "", "Got empty or invalid response.")

            if not isinstance(root[0].find("user_id"), ElementTree.Element):
                return AccountInfo("", "", "Got empty or invalid response.")

            pnid = root[0].find("user_id").text  # type: ignore

            try:
                mii_data = b64decode(mii_data_response.text.replace("\\n", "").replace("\\r", ""))
                mii_name = mii_data.decode("utf-16")[13:23]
            except (binascii.Error, UnicodeDecodeError):
                return AccountInfo("", "", "Got empty or invalid response.")

            break
        except requests.RequestException as ex:
            request_error = str(ex)
            time.sleep(1)

    return AccountInfo(pnid, mii_name, request_error)  # type: ignore


def _exit_with_close(message: Optional[str] = None) -> None:
    if message:
        print(message)
    _GECKO.close()
    sys.exit()


if __name__ == "__main__":
    main()
