# Splatlogger (c) 2025 Shadow Doggo.

from typing import NamedTuple


class Options(NamedTuple):
    log_level: str
    auto_logging: bool
    log_latest: bool
    aroma: bool
    cemu: bool
    spfn: bool
    no_pnid: bool
    silent_logging: bool
    stack: int | None


class CommonAddresses(NamedTuple):
    main_mgr_base_adr: int
    player_info_ary_adr: int


class AccountInfo(NamedTuple):
    pnid: str
    mii_name: str
    request_error: str


class PlayerInfo(NamedTuple):
    idx: int
    pid: int
    pnid: str
    name: str
    mii_name: str
    team: int
    gender: int
    skin_tone: int
    eye_color: int
    weapon: int
    sub_weapon: int
    special_weapon: int
    shoes: int
    clothes: int
    headgear: int
    level: int
    rank: int
