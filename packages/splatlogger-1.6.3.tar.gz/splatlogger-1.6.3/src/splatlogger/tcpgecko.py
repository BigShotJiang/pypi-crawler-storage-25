# Splatlogger (c) 2025 Shadow Doggo.
# tcpgecko.py from pyGecko (https://github.com/wiiudev/pyGecko) was used as a reference to make this.
# Credit to the pyGecko authors for their work.

import socket
import struct


def to_hex(value: int) -> str:
    return hex(value).upper().replace("X", "x")


class TCPGecko:
    """Python library for use with TCPGecko."""

    def __init__(self, ip: str, *, port: int = 7331, timeout: int = 10) -> None:
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)
        self._socket.settimeout(timeout)
        try:
            self._socket.connect((ip, port))
        except (socket.error, socket.timeout) as e:
            raise GeckoConnectionFailedError(f"Failed to connect: {e}") from e

    def close(self) -> None:
        """Close the TCPGecko connection."""
        self._socket.close()

    def peek_raw(self, address: int, length: int) -> bytes:
        """Read raw memory starting at address and ending at address + length.
        Returns a bytes object.
        """
        if length <= 0:
            raise TCPGeckoError("Reading memory requires a positive length (# of bytes).")

        if not self._valid_range(address, length):
            raise GeckoInvalidRangeError(f"Address {to_hex(address)} is outside the valid range.")

        if not self._valid_access(address, length, "read"):
            raise GeckoInvalidAccessError(f"Cannot read from address {to_hex(address)}.")

        chunks: list[bytes] = []
        # Read in chunks of up to 1024 bytes.
        while length > 0:
            chunk_size = min(length, 1024)
            chunks.append(self._peek_request(address, chunk_size))
            address += chunk_size
            length -= chunk_size

        return b"".join(chunks)

    def peek8(self, address: int, *, signed: bool = False) -> int:
        """Get an 8-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address + 3, length=1), byteorder="big", signed=signed)

    def peek16(self, address: int, *, signed: bool = False) -> int:
        """Get a 16-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address + 2, length=2), byteorder="big", signed=signed)

    def peek32(self, address: int, *, signed: bool = False) -> int:
        """Get a 32-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address, length=4), byteorder="big", signed=signed)

    def peek_float(self, address: int) -> float:
        """Get a floating point value stored at the specified address."""
        return struct.unpack(">f", self.peek_raw(address, length=4))[0]

    def read_string(self, address: int, length: int = 1, encoding: str = "utf-8") -> str:
        """Read a string of text starting at the specified address."""
        return self.peek_raw(address, length).decode(encoding)

    def _recv_all(self, length: int) -> bytes:
        chunks: list[bytes] = []
        while length > 0:
            chunk = self._socket.recv(length)
            if not chunk:
                raise GeckoConnectionClosedError("Connection closed unexpectedly while receiving data.")
            chunks.append(chunk)
            length -= len(chunk)

        return b"".join(chunks)

    def _peek_request(self, address: int, length: int) -> bytes:
        self._socket.sendall(b"\x04")
        request = struct.pack(">II", address, address + length)
        self._socket.sendall(request)

        status = self._socket.recv(1)
        if status == b"\xbd":
            return self._recv_all(length)
        if status == b"\xb0":
            return b"\x00" * length

        raise GeckoPeekError(f"Failed to read memory: Received invalid status {status!r}.")

    @staticmethod
    def _valid_range(address: int, length: int) -> bool:
        ranges = [
            (0x01000000, 0x01800000),
            (0x0E000000, 0x10000000),
            (0x10000000, 0x50000000),
            (0xE0000000, 0xE4000000),
            (0xE8000000, 0xEA000000),
            (0xF4000000, 0xF6800000),
            (0xF8000000, 0xFB800000),
            (0xFFFE0000, 0xFFFFFFFF),
        ]

        end_address = address + length

        return any(start <= address and end_address <= end for start, end in ranges)

    @staticmethod
    def _valid_access(address: int, length: int, access: str) -> bool | None:
        if access not in ("read", "write"):
            raise GeckoInvalidAccessError(f"Invalid access type: {access}")

        ranges = [
            (0x01000000, 0x01800000, True, False),
            (0x0E000000, 0x10000000, True, False),
            (0x10000000, 0x50000000, True, True),
            (0xE0000000, 0xE4000000, True, False),
            (0xE8000000, 0xEA000000, True, False),
            (0xF4000000, 0xF6000000, True, False),
            (0xF6000000, 0xF6800000, True, False),
            (0xF8000000, 0xFB000000, True, False),
            (0xFB000000, 0xFB800000, True, False),
            (0xFFFE0000, 0xFFFFFFFF, True, True),
        ]

        end_address = address + length

        for start, end, is_readable, is_writable in ranges:
            if start <= address and end_address <= end:
                if access == "read":
                    return is_readable
                if access == "write":
                    return is_writable

                return None

        return False


class TCPGeckoError(Exception): pass


class GeckoConnectionFailedError(TCPGeckoError): pass


class GeckoConnectionClosedError(TCPGeckoError): pass


class GeckoInvalidRangeError(TCPGeckoError): pass


class GeckoInvalidAccessError(TCPGeckoError): pass


class GeckoPeekError(TCPGeckoError): pass
