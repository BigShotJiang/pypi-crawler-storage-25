# Splatlogger (c) 2025 Shadow Doggo.

import json
import platform
import time
from datetime import datetime
from importlib import resources
from pathlib import Path
from typing import Any

import userpaths  # type: ignore[import-untyped]

from .cemu_gecko import CemuGecko
from .enums import Pointers, Addresses, Offsets
from .tcpgecko import TCPGecko, to_hex
from .tuples import Options, CommonAddresses, PlayerInfo


class MatchLogger:
    """Provides the match logging functionality of Splatlogger."""

    def __init__(self, options: Options, gecko: TCPGecko | CemuGecko, static_mem_adr: int) -> None:
        self._date = datetime.now()
        self._log_path: Path = (Path(userpaths.get_my_documents()) /
                                f"Splatlogger/logs/{self._date.strftime('%Y-%m-%d')}")
        self._options = options
        self._gecko = gecko
        self._static_mem_adr = static_mem_adr
        self._stats_offset: int | None = None
        self._align = 2 if options.auto_logging else 0
        self._names: dict[str, Any]
        with resources.path(__package__, "data") as data_path:
            with open(data_path / "names.json", "r", encoding="utf-8") as names_f:
                self._names = json.load(names_f)

    def create_new_log(self) -> None:
        """Initialize a new log file."""
        if not self._log_path.exists():
            self._log_path.mkdir(parents=True)

        self._write_log(log=f"Splatlogger log from {self._date.strftime('%Y-%m-%d %H:%M:%S')} "
                            f"({self._date.astimezone().tzname()})\n", mode="w")

    def log_match(self, date: datetime, session_id: int, match_count: int, player_info_list: list[PlayerInfo],
                  adrs: CommonAddresses) -> None:
        """Write player and match data to the log file."""
        disconnect = False

        match_log, versus_rule = self._new_match(date, session_id, match_count)
        network_id_type = "SFID" if self._options.spfn else "PNID"
        if self._options.log_level == "standard":
            match_log += (f"\n{'Player':<8} | {'PID (Hex)':<10} | {'PID (Dec)':<10} | {network_id_type:<16} | Name\n"
                          f"{'-' * 73}\n")

        for player_info in player_info_list:
            match_log += (
                f"Player {player_info.idx + 1} | "
                f"{to_hex(player_info.pid):<8} | "
                f"{player_info.pid:<10} | "
                f"{player_info.pnid:<16} | "
                f"{player_info.name} "
                f"{f'({player_info.mii_name})' if player_info.name != player_info.mii_name else ''}\n"
            ) if self._options.log_level == "standard" else (
                f"\n{' ' * self._align}[Player {player_info.idx + 1}]\n"
                f"{' ' * (self._align + 2)}Name: {player_info.name}"
                f"{' (Mii name: ' + player_info.mii_name + ')' if player_info.name != player_info.mii_name else ''}\n"
                f"{' ' * (self._align + 2)}PID: {to_hex(player_info.pid)} ({player_info.pid})\n"
                f"{' ' * (self._align + 2)}{network_id_type}: {player_info.pnid}\n"
                f"{' ' * (self._align + 2)}Team: {self._get_name('team', player_info.team)} "
                f"({player_info.team})\n"
                f"{' ' * (self._align + 2)}Appearance: Gender: {self._get_name('gender', player_info.gender)} "
                f"({player_info.gender}) | "
                f"Skin tone: {self._get_name('skin_tone', player_info.skin_tone)} ({player_info.skin_tone}) | "
                f"Eye color: {self._get_name('eye_color', player_info.eye_color)} ({player_info.eye_color})\n"
                f"{' ' * (self._align + 2)}Gear: Headgear: {self._get_name('headgear', player_info.headgear)} "
                f"({player_info.headgear}) | "
                f"Clothes: {self._get_name('clothes', player_info.clothes)} ({player_info.clothes}) | "
                f"Shoes: {self._get_name('shoes', player_info.shoes)} ({player_info.shoes})\n"
                f"{' ' * (self._align + 2)}Weapons: Main: {self._get_name('weapon', player_info.weapon)} "
                f"({player_info.weapon}) | "
                f"Sub: {self._get_name('sub_weapon', player_info.sub_weapon)} ({player_info.sub_weapon}) | "
                f"Special: {self._get_name('special_weapon', player_info.special_weapon)} "
                f"({player_info.special_weapon})\n"
                f"{' ' * (self._align + 2)}Level: {player_info.level}\n"
                f"{' ' * (self._align + 2)}Rank: {self._get_name('rank', player_info.rank)} "
                f"({player_info.rank})\n"
            )

            if self._options.log_level == "stats" and not disconnect:
                if stats := self._get_stats(player_info, versus_rule, adrs):
                    match_log += stats
                else:
                    disconnect = True

        if self._options.log_level == "standard":
            match_log += (f"\nSession ID: {to_hex(session_id)} ({session_id})\n" +
                          (f"Fetched at: {date.strftime('%H:%M:%S')}\n" if self._options.auto_logging else ""))

        self._write_log(log=match_log, mode="a")

    def _get_name(self, name: str, value: int | str) -> str:
        return self._names[f"{name}_name"].get(str(value), "Unknown")

    def _write_log(self, log: str, mode: str) -> None:
        with open(self._log_path / f"{self._date.strftime('%Y-%m-%d %H-%M-%S')} log.txt",
                  mode, encoding="utf-8") as log_f:
            log_f.write(log)

    def _new_match(self, date: datetime, session_id: int, match_count: int) -> tuple[str, int]:
        stage = self._gecko.read_string(self._static_mem_adr + Offsets.STATICMEM_STAGE, length=32).split("\u0000")[0]
        match_hour = self._gecko.peek8(self._static_mem_adr + Offsets.STATICMEM_MATCH_HOUR)
        versus_mode = self._gecko.peek8(self._static_mem_adr + Offsets.STATICMEM_VERSUS_MODE)
        versus_rule = self._gecko.peek8(self._static_mem_adr + Offsets.STATICMEM_VERSUS_RULE)

        match_info = ""
        if self._options.log_level == "standard":
            match_info += f"\nMatch {match_count}\n"
        elif self._options.auto_logging:
            match_info += (
                f"\n[Match {match_count}]\n"
                f"{' ' * self._align}Time: {date.strftime('%H:%M:%S')}\n"
                f"{' ' * self._align}Session ID: {to_hex(session_id)} ({session_id})\n"
                f"{' ' * self._align}Lobby type: {self._get_name('versus_mode', versus_mode)} "
                f"({versus_mode})\n"
                f"{' ' * self._align}Game mode: {self._get_name('versus_rule', versus_rule)} "
                f"({versus_rule})\n"
                f"{' ' * self._align}Stage: {self._get_name('stage', stage)} ({stage})\n"
                f"{' ' * self._align}Match hour: {self._get_name('match_hour', match_hour)} ({match_hour})\n"
            )
        else:
            match_info += (
                f"\n{' ' * self._align}Session ID: {to_hex(session_id)} ({session_id})\n"
                f"{' ' * self._align}Lobby type: {self._get_name('versus_mode', versus_mode)} "
                f"({versus_mode})\n"
                f"{' ' * self._align}Game mode: {self._get_name('versus_rule', versus_rule)} "
                f"({versus_rule})\n"
                f"{' ' * self._align}Stage: {self._get_name('stage', stage)} ({stage})\n"
                f"{' ' * self._align}Match hour: {self._get_name('match_hour', match_hour)} ({match_hour})\n"
            )

        return match_info, versus_rule

    def _get_stats(self, player_info: PlayerInfo, versus_rule: int, adrs: CommonAddresses) -> str | None:
        # If this looks overly complicated, That's because it is. Getting stuff from the stack reliably is a PITA.
        stats_adr: int = Addresses.STATS
        win_team_adr: int = Addresses.WIN_TEAM
        ptr_offset = 0x503000 if self._options.cemu else 0

        if self._options.cemu and self._options.stack:
            stats_adr = self._options.stack + Offsets.CEMU_STATS
            win_team_adr = self._options.stack + Offsets.CEMU_WIN_TEAM
        elif self._options.cemu:
            # Assume default values if stack is not provided. These seem consistent across various systems.
            stack_adr = 0xE101440 if platform.system() == "Windows" else 0xE175900
            stats_adr = stack_adr + Offsets.CEMU_STATS
            win_team_adr = stack_adr + Offsets.CEMU_WIN_TEAM

        if player_info.idx == 0:
            count = 0
            while count < 200:  # Any match probably shouldn't last longer than 10 minutes.
                # If MainMgrVSGame gets unloaded here, the player likely exited the match due to a disconnect.
                if self._gecko.peek32(Pointers.MAIN_MGR_VS_GAME - ptr_offset) == 0:
                    return None

                if self._gecko.peek32(self._gecko.peek32(adrs.main_mgr_base_adr + Offsets.MAINMGR_SCENE_INFO)
                                      + Offsets.SCENE_INFO_RESULTS_SHOWN) == 0:
                    break

                time.sleep(3)
                count += 1

        # If on tiramisu/aroma, get stats offset after the first match is complete.
        if not self._options.cemu:
            if self._stats_offset is None:
                if (stats_offset := self._find_stats_offset(adrs.player_info_ary_adr)) is None:
                    return None
                self._stats_offset = stats_offset

            stats_adr += self._stats_offset
            win_team_adr += self._stats_offset

        winning_team = self._gecko.peek8(win_team_adr)
        stats = self._gecko.peek_raw(stats_adr, length=0x124)  # Read updated stats again.
        offset = player_info.idx * 0x20
        points = int.from_bytes(stats[offset + 0x3A:offset + 0x3C], byteorder="big")
        kills = int.from_bytes(stats[offset + 0x3E:offset + 0x40], byteorder="big")
        deaths = int.from_bytes(stats[offset + 0x42:offset + 0x44], byteorder="big")

        points_log = ""
        if versus_rule == 0:  # Only log points in turf war cause in ranked they're the same for all players.
            points_log = f"{' ' * (self._align + 2)}Points: {points + 1000}p ({points}p w/o win bonus)\n" if \
                player_info.team == winning_team else f"{' ' * (self._align + 2)}Points: {points}p\n"

        return (f"{points_log}{' ' * (self._align + 2)}K/D: {kills}/{deaths}\n{' ' * (self._align + 2)}"
                f"Result: {'Win' if player_info.team == winning_team else 'Lose'}\n")

    def _find_stats_offset(self, player_info_ary_adr: int) -> int | None:
        # Find pointer to the first player's PlayerInfo within the stats and calculate offset.
        first_player_info_adr = self._gecko.peek32(player_info_ary_adr)

        # Check default offsets of 0 and -0x38 first. The pointer is at 0x30.
        if self._gecko.peek32(Addresses.STATS + 0x30) == first_player_info_adr:
            return 0
        if self._gecko.peek32(Addresses.STATS - 0x8) == first_player_info_adr:
            return -0x38

        search_space = self._gecko.peek_raw(Addresses.STATS - 0x100, length=0x200)
        stats_offset = search_space.find(first_player_info_adr.to_bytes(length=4, byteorder="big"))

        return None if stats_offset == -1 else stats_offset - 0x130
