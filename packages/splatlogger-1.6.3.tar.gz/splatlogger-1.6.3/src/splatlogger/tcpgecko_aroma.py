# Splatlogger (c) 2025 Shadow Doggo.

from .tcpgecko import TCPGecko, TCPGeckoError, GeckoInvalidRangeError, GeckoInvalidAccessError, to_hex


class TCPGeckoAroma(TCPGecko):
    """Extends the TCPGecko class to provide support for the Aroma TCPGecko plugin."""

    def __init__(self, ip: str, *, port: int = 7332, timeout: int = 10) -> None:
        super().__init__(ip, port=port, timeout=timeout)

    def peek_raw(self, address: int, length: int) -> bytes:
        """Read raw memory starting at address and ending at address + length.
        Returns a bytes object.
        """
        if length <= 0:
            raise TCPGeckoError("Reading memory requires a positive length (# of bytes).")

        if not self._valid_range(address, length):
            raise GeckoInvalidRangeError(f"Address {to_hex(address)} is outside the valid range.")

        if not self._valid_access(address, length, "read"):
            raise GeckoInvalidAccessError(f"Cannot read from address {to_hex(address)}.")

        chunks: list[bytes] = []
        if length <= 4:
            return self._peek_request(address, length=length)

        chunks_amount, remainder = divmod(length, 4)
        for _ in range(chunks_amount):
            chunks.append(self._peek_request(address, length=4))
            address += 4

        if remainder:
            chunks.append(self._peek_request(address, length=remainder))

        return b"".join(chunks)

    def peek8(self, address: int, *, signed: bool = False) -> int:
        """Get an 8-bit integer value stored at the specified address."""
        if not self._valid_range(address, length=1):
            raise GeckoInvalidRangeError(f"Address {to_hex(address)} is outside the valid range.")

        if not self._valid_access(address, length=1, access="read"):
            raise GeckoInvalidAccessError(f"Cannot read from address {to_hex(address)}.")

        request = bytes(f"peek -t u8 -a {to_hex(address + 3)}", "utf-8")
        self._socket.sendall(request)

        response = self._socket.recv(8)
        val = int(response.decode("utf-8").strip())

        return val - 2 ** 8 if signed and val >= 2 ** 7 else val  # Rough unsigned to signed conversion.

    def peek16(self, address: int, *, signed: bool = False) -> int:
        """Get a 16-bit integer value stored at the specified address."""
        if not self._valid_range(address, length=2):
            raise GeckoInvalidRangeError(f"Address {to_hex(address)} is outside the valid range.")

        if not self._valid_access(address, length=2, access="read"):
            raise GeckoInvalidAccessError(f"Cannot read from address {to_hex(address)}.")

        request = bytes(f"peek -t u16 -a {to_hex(address + 2)}", "utf-8")
        self._socket.sendall(request)

        response = self._socket.recv(16)
        val = int(response.decode("utf-8").strip())

        return val - 2 ** 16 if signed and val >= 2 ** 15 else val

    def peek32(self, address: int, *, signed: bool = False) -> int:
        """Get a 32-bit integer value stored at the specified address."""
        if not self._valid_range(address, length=4):
            raise GeckoInvalidRangeError(f"Address {to_hex(address)} is outside the valid range.")

        if not self._valid_access(address, length=4, access="read"):
            raise GeckoInvalidAccessError(f"Cannot read from address {to_hex(address)}.")

        request = bytes(f"peek -t u32 -a {to_hex(address)}", "utf-8")
        self._socket.sendall(request)

        response = self._socket.recv(32)
        val = int(response.decode("utf-8").strip())

        return val - 2 ** 32 if signed and val >= 2 ** 31 else val

    def peek_float(self, address: int) -> float:
        """Get a floating point value stored at the specified address."""
        if not self._valid_range(address, length=4):
            raise GeckoInvalidRangeError(f"Address {to_hex(address)} is outside the valid range.")

        if not self._valid_access(address, length=4, access="read"):
            raise GeckoInvalidAccessError(f"Cannot read from address {to_hex(address)}.")

        request = bytes(f"peek -t f32 -a {to_hex(address)}", "utf-8")
        self._socket.sendall(request)

        response = self._socket.recv(32)

        return float(response.decode("utf-8").strip())

    def _peek_request(self, address: int, length: int) -> bytes:
        request = bytes(f"peek -t u32 -a {to_hex(address)}", "utf-8")
        self._socket.sendall(request)

        response = self._socket.recv(32)
        value = int(response.decode("utf-8").strip())

        return value.to_bytes(4, byteorder="big")[:length]
