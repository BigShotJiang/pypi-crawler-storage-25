"""
FLAMLTrainer - FLAML 训练器

封装 FLAML 训练逻辑，支持 Databricks 风格的参数。

该模块是训练编排的核心，将数据加载、指标计算、MLflow 管理、
时序预测处理和日志管理等职责委托给拆分后的子模块：

- data_loader: 数据加载、时区处理、Spark 转换、数据划分、特征存储
- metrics: 自定义指标、指标验证、估计器列表
- mlflow_manager: MLflow 实验设置、Tag 管理、模型记录/注册
- forecast_handler: 时序预测专用逻辑
- log_manager: FLAML 日志文件路径生成和清理
"""
import logging
import os
import time
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

# 禁用 MLflow 2.15+ 的 LoggedModel 功能（避免与旧版 MLflow 服务器不兼容）
# 必须在 import mlflow 之前设置
os.environ.setdefault("MLFLOW_ENABLE_LOGGED_MODELS", "false")

import mlflow  # noqa: E402
from sklearn.pipeline import Pipeline as SkPipe  # noqa: E402

# Robust import for FLAML
try:
    from flaml import AutoML
    import flaml as flaml_pkg
except ImportError:
    try:
        from flaml.automl.automl import AutoML
        import flaml as flaml_pkg
    except ImportError as e:
        raise ImportError(
            "Cannot import AutoML from flaml. "
            "Please install flaml with AutoML support: pip install 'flaml[automl]==2.3.6'"
        ) from e

from wedata_automl.summary import AutoMLSummary  # noqa: E402
from wedata_automl.utils.sk_pipeline import build_numeric_preprocessor  # noqa: E402
from wedata_automl.utils.print_utils import safe_print, print_separator  # noqa: E402
from wedata_automl.engines.trial_hook import TrialHook  # noqa: E402

def _build_mlflow_input_dataset(pdf, data_source_table, target_col):
    """Build an MLflow Dataset object for log_input, with safe fallback.

    Call once inside the parent run context to associate training data with
    the run, so the MLflow UI dataset column gets populated. Returns None on
    any failure so the caller can simply skip log_input without aborting.
    """
    try:
        import mlflow.data
    except Exception:
        return None

    name = data_source_table if data_source_table else "training_data"
    try:
        return mlflow.data.from_pandas(
            pdf,
            source=name,
            name=name,
            targets=target_col,
        )
    except Exception:
        try:
            return mlflow.data.from_pandas(
                pdf,
                name=name,
                targets=target_col,
            )
        except Exception:
            return None


# 拆分后的子模块
from wedata_automl.engines.log_manager import (  # noqa: E402
    generate_log_file_path, cleanup_old_log_files,
)
from wedata_automl.engines.metrics import (  # noqa: E402
    SUPPORTED_METRICS,
    SUPPORTED_ESTIMATORS,
    get_default_metric,
    get_flaml_metric,
    get_estimator_list,
)
from wedata_automl.engines.mlflow_manager import (  # noqa: E402
    setup_mlflow_user_id,
    set_run_wedata_tags,
    set_model_version_wedata_tags,
    log_feature_list,
    log_best_config_overall,
    log_best_config_per_estimator,
    log_engine_meta,
    setup_mlflow_experiment,
    upload_log_file,
    log_model_with_mlflow,
)
from wedata_automl.engines.data_loader import (  # noqa: E402
    load_data,
    prepare_data,
    apply_feature_store_lookups,
)
from wedata_automl.engines.forecast_handler import (  # noqa: E402
    prepare_forecast_data,
    save_forecast_predictions,
    log_forecast_model,
    resolve_frequency,
)

logger = logging.getLogger(__name__)


class FLAMLTrainer:
    """
    FLAML 训练器

    封装 FLAML 训练逻辑，支持 Databricks 风格的参数。
    作为训练编排核心，协调各子模块完成端到端的 AutoML 训练流程。
    """

    # 支持的指标和估计器配置（引用子模块的常量，保持向后兼容）
    SUPPORTED_METRICS = SUPPORTED_METRICS
    SUPPORTED_ESTIMATORS = SUPPORTED_ESTIMATORS

    def __init__(
        self,
        task: str,
        target_col: str,
        timeout_minutes: int = 5,
        max_trials: Optional[int] = None,
        metric: str = "auto",
        exclude_cols: Optional[List[str]] = None,
        exclude_frameworks: Optional[List[str]] = None,
        estimator_list: Optional[List[str]] = None,
        sample_weight_col: Optional[str] = None,
        pos_label: Optional[Union[str, int]] = None,
        data_split_col: Optional[str] = None,
        experiment_name: Optional[str] = None,
        experiment_id: Optional[str] = None,
        run_name: Optional[str] = None,
        register_model: bool = True,
        model_name: Optional[str] = None,
        max_concurrent_trials: int = 1,
        use_spark: bool = False,
        custom_hp: Optional[Dict[str, Any]] = None,
        workspace_id: Optional[str] = None,
        log_file_dir: Optional[str] = None,
        auto_cleanup_logs: bool = True,
        log_max_age_hours: int = 24,
        log_max_files: int = 100,
        imputers: Optional[Dict[str, Union[str, Dict[str, Any]]]] = None,
        country_code: Optional[str] = "US",
        feature_store_lookups: Optional[List[Dict[str, Any]]] = None,
        # Catalog 注册参数
        register_to_catalog: bool = False,
        catalog_model_name: Optional[str] = None,
        catalog_region: str = "ap-beijing",
        # 父run和模型名称后缀
        name_suffix: Optional[str] = "",
        **kwargs
    ):
        """
        初始化 FLAML 训练器

        Args:
            task: 任务类型 ("classification", "regression" 或 "forecast")
            target_col: 目标列名
            timeout_minutes: 超时时间（分钟）
            max_trials: 最大试验次数
            metric: 评估指标，用于选择最佳模型
            exclude_cols: 排除的列
            exclude_frameworks: 排除的框架（已弃用，请使用 estimator_list）
            estimator_list: 估计器列表
            sample_weight_col: 样本权重列
            pos_label: 正类标签（二分类）
            data_split_col: 数据划分列
            experiment_name: MLflow 实验名称
            experiment_id: MLflow 实验 ID
            run_name: MLflow run 名称
            register_model: 是否注册模型
            model_name: 模型名称
            max_concurrent_trials: 并发 trials 数量
            use_spark: 是否使用 Spark 作为并行后端
            custom_hp: 自定义超参数搜索空间
            workspace_id: 项目 ID
            log_file_dir: FLAML log 文件存储目录
            auto_cleanup_logs: 是否自动清理旧的 log 文件
            log_max_age_hours: log 文件最大保留时间（小时）
            log_max_files: log 文件最大保留数量
            imputers: 缺失值填充策略字典
            country_code: 节假日国家代码（仅 Prophet 时序预测使用）
            feature_store_lookups: 特征存储查找配置
            register_to_catalog: 是否注册到 TencentCloud Catalog
            catalog_model_name: Catalog 模型名称
            catalog_region: Catalog 地域
            name_suffix: 父run和模型名称后缀
            **kwargs: 其他参数

        Raises:
            ValueError: 如果 workspace_id 未配置
        """
        self.task = task
        self.target_col = target_col
        self.timeout_minutes = timeout_minutes
        self.max_trials = max_trials
        self.metric = metric if metric != "auto" else get_default_metric(task)
        self.exclude_cols = exclude_cols or []
        self.exclude_frameworks = exclude_frameworks or []
        self.estimator_list = estimator_list
        self.sample_weight_col = sample_weight_col
        self.pos_label = pos_label
        self.data_split_col = data_split_col
        self.experiment_name = experiment_name or "wedata_automl"
        self.experiment_id = experiment_id
        self.run_name = run_name or f"flaml_automl_{task}"
        self.name_suffix = name_suffix
        self.register_model = register_model
        self.model_name = model_name
        self.max_concurrent_trials = max_concurrent_trials
        self.use_spark = use_spark
        self.custom_hp = custom_hp
        self.imputers = imputers
        self.country_code = country_code
        self.feature_store_lookups = feature_store_lookups or []

        # 预测结果存储参数（仅时序预测使用）
        self.prediction_result_storage = kwargs.pop("prediction_result_storage", None)
        self.storage_data_source_id = kwargs.pop("storage_data_source_id", None)
        self.storage_data_source_name = kwargs.pop("storage_data_source_name", None)

        # Catalog 注册参数
        self.register_to_catalog = register_to_catalog
        self.catalog_model_name = catalog_model_name
        self.catalog_region = catalog_region or os.getenv("QCLOUD_REGION")

        # Log 文件管理配置
        self.log_file_dir = log_file_dir
        self.auto_cleanup_logs = auto_cleanup_logs
        self.log_max_age_hours = log_max_age_hours
        self.log_max_files = log_max_files

        # 处理 workspace_id：优先使用用户传入的值，否则从环境变量读取
        self.workspace_id = workspace_id or os.environ.get("WEDATA_WORKSPACE_ID")

        # 验证 workspace_id 是否存在
        if not self.workspace_id:
            raise ValueError(
                "❌ 未配置 Project ID！\n"
                "请通过以下任一方式配置 Project ID：\n"
                "1. 传递 workspace_id 参数：classify(..., workspace_id='your_project_id')\n"
                "2. 设置环境变量：export WEDATA_WORKSPACE_ID='your_project_id'\n"
                "\n"
                "Project ID 用于多租户隔离，确保实验可以通过后端 API 正确查询。"
            )

        self.kwargs = kwargs

        # 内部状态
        self.automl = None
        self.pipeline = None
        self.features = None
        self.preprocessor = None
        self.data_source_table = None

    # ========================================================================
    # 私有方法：模型评估
    # ========================================================================
    def _evaluate_model(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_val: pd.DataFrame,
        y_val: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray
    ) -> Dict[str, float]:
        """
        评估模型（分类/回归任务）

        Returns:
            评估指标字典
        """
        metrics = {}

        if self.task == "classification":
            from sklearn.metrics import (
                accuracy_score, f1_score, precision_score, recall_score,
                log_loss as sklearn_log_loss, roc_auc_score
            )

            for name, X, y_true in [
                ("train", X_train, y_train),
                ("val", X_val, y_val),
                ("test", X_test, y_test),
            ]:
                pred = self.pipeline.predict(X)
                acc = float(accuracy_score(y_true, pred))
                f1 = float(f1_score(y_true, pred, average='weighted', zero_division=0))
                precision = float(precision_score(y_true, pred, average='weighted', zero_division=0))
                recall = float(recall_score(y_true, pred, average='weighted', zero_division=0))

                metrics[f"{name}_accuracy"] = acc
                metrics[f"{name}_f1"] = f1
                metrics[f"{name}_precision"] = precision
                metrics[f"{name}_recall"] = recall

                mlflow.log_metric(f"{name}_accuracy", acc)
                mlflow.log_metric(f"{name}_f1", f1)
                mlflow.log_metric(f"{name}_precision", precision)
                mlflow.log_metric(f"{name}_recall", recall)

                # 概率相关指标
                logloss = None
                roc_auc = None
                try:
                    pred_proba = self.pipeline.predict_proba(X)

                    logloss = float(sklearn_log_loss(y_true, pred_proba))
                    metrics[f"{name}_log_loss"] = logloss
                    mlflow.log_metric(f"{name}_log_loss", logloss)

                    n_classes = len(np.unique(y_true))
                    if n_classes == 2:
                        roc_auc = float(roc_auc_score(y_true, pred_proba[:, 1]))
                    else:
                        roc_auc = float(roc_auc_score(y_true, pred_proba, multi_class='ovr', average='weighted'))
                    metrics[f"{name}_roc_auc"] = roc_auc
                    mlflow.log_metric(f"{name}_roc_auc", roc_auc)

                except Exception as e:
                    logger.debug(f"Failed to compute probability-based metrics for {name}: {e}")

                metric_parts = [f"Accuracy: {acc:.4f}", f"F1: {f1:.4f}"]
                if logloss is not None:
                    metric_parts.append(f"LogLoss: {logloss:.4f}")
                if roc_auc is not None:
                    metric_parts.append(f"ROC-AUC: {roc_auc:.4f}")
                safe_print(f"{name.capitalize():5s} Set - " + " | ".join(metric_parts))

        elif self.task == "regression":
            from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

            for name, X, y_true in [
                ("train", X_train, y_train),
                ("val", X_val, y_val),
                ("test", X_test, y_test),
            ]:
                pred = self.pipeline.predict(X)

                r2 = float(r2_score(y_true, pred))
                mse = float(mean_squared_error(y_true, pred))
                mae = float(mean_absolute_error(y_true, pred))
                rmse = float(np.sqrt(mse))
                deviance = float(np.sum((y_true - pred) ** 2))

                metrics[f"{name}_r2"] = r2
                metrics[f"{name}_mse"] = mse
                metrics[f"{name}_mae"] = mae
                metrics[f"{name}_rmse"] = rmse
                metrics[f"{name}_deviance"] = deviance

                mlflow.log_metric(f"{name}_r2", r2)
                mlflow.log_metric(f"{name}_mse", mse)
                mlflow.log_metric(f"{name}_mae", mae)
                mlflow.log_metric(f"{name}_rmse", rmse)
                mlflow.log_metric(f"{name}_deviance", deviance)

                safe_print(
                    f"{name.capitalize():5s} Set - R²: {r2:.4f} | RMSE: {rmse:.4f}"
                    f" | MAE: {mae:.4f} | Deviance: {deviance:.4f}"
                )

        return metrics

    # ========================================================================
    # 私有方法：构建 FLAML 设置
    # ========================================================================
    def _build_flaml_settings(self, log_file_path: str) -> dict:
        """构建 FLAML AutoML 配置"""
        estimator_list_resolved = get_estimator_list(
            self.task, self.estimator_list, self.exclude_frameworks
        )

        # FLAML 任务类型映射
        flaml_task = "ts_forecast" if self.task == "forecast" else self.task

        # 获取指标
        metric = get_flaml_metric(self.metric, self.task)

        settings = {
            "task": flaml_task,
            "metric": metric,
            "time_budget": int(self.timeout_minutes * 60),
            "eval_method": "holdout",
            "ensemble": False,
            "verbose": 0,
            "estimator_list": estimator_list_resolved,
            "seed": 42,
            "log_file_name": log_file_path,
            "mlflow_logging": False,
            "early_stop": False,
            "log_type": "all",
            "n_concurrent_trials": self.max_concurrent_trials,
            "use_spark": self.use_spark,
        }

        if self.max_trials:
            settings["max_iter"] = self.max_trials

        if self.use_spark:
            settings["force_cancel"] = True

        if self.custom_hp:
            settings["custom_hp"] = self.custom_hp
            safe_print(f"Custom hyperparameter search space provided for: {', '.join(self.custom_hp.keys())}")

        if self.task == "forecast" and self.country_code is not None:
            if "prophet" not in settings.get("custom_hp", {}):
                settings.setdefault("custom_hp", {})["prophet"] = {}
            safe_print(f"Country code for holidays: '{self.country_code}' (Prophet only)")

        # 打印配置信息
        safe_print(f"Task: {self.task} (FLAML task: {flaml_task})")
        safe_print(f"Metric: {self.metric}")
        safe_print(f"Time budget: {self.timeout_minutes} minutes ({int(self.timeout_minutes * 60)} seconds)")
        safe_print(f"Max trials: {self.max_trials if self.max_trials else 'unlimited'}")
        safe_print(f"Concurrent trials: {self.max_concurrent_trials}")
        safe_print(f"Parallel backend: {'Spark' if self.use_spark else 'Local (multi-thread)'}")
        safe_print(f"Estimators: {', '.join(estimator_list_resolved)}")
        safe_print("Evaluation method: holdout")
        if self.custom_hp:
            safe_print(f"Custom search space: Yes ({len(self.custom_hp)} estimator(s))")

        return settings

    # ========================================================================
    # 私有方法：执行 AutoML 训练
    # ========================================================================
    def _run_automl_training(self, fit_kwargs: dict) -> float:
        """执行 FLAML AutoML 训练"""
        import logging as py_logging

        # 抑制日志
        flaml_logger = py_logging.getLogger("flaml.automl.logger")
        flaml_automl_logger = py_logging.getLogger("flaml.automl")
        mlflow_logger = py_logging.getLogger("mlflow.tracking._tracking_service.client")
        mlflow_utils_logger = py_logging.getLogger("mlflow.utils")

        original_levels = {
            "flaml": flaml_logger.level,
            "flaml_automl": flaml_automl_logger.level,
            "mlflow": mlflow_logger.level,
            "mlflow_utils": mlflow_utils_logger.level,
        }

        flaml_logger.setLevel(py_logging.WARNING)
        flaml_automl_logger.setLevel(py_logging.WARNING)
        mlflow_logger.setLevel(py_logging.WARNING)
        mlflow_utils_logger.setLevel(py_logging.WARNING)

        safe_print("Training in progress... (FLAML debug logs suppressed)")

        start_time = time.time()
        try:
            self.automl.fit(**fit_kwargs)
        finally:
            flaml_logger.setLevel(original_levels["flaml"])
            flaml_automl_logger.setLevel(original_levels["flaml_automl"])
            mlflow_logger.setLevel(original_levels["mlflow"])
            mlflow_utils_logger.setLevel(original_levels["mlflow_utils"])

        return time.time() - start_time

    # ========================================================================
    # 私有方法：模型记录和注册
    # ========================================================================
    def _log_and_register_model(  # noqa: C901
        self,
        parent_run_id: str,
        X_train: pd.DataFrame
    ) -> tuple:
        """记录和注册模型"""
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print("💾 Model Logging & Registration")
        print_separator()

        if not self.register_model:
            safe_print(f"ℹ️  register_model: {self.register_model}. Model registration Skipped! ")
            return None, None

        if self.model_name:
            registered_model_name = self.model_name
        else:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            exp_name = self.experiment_name or "automl"
            exp_name_clean = "".join(c if c.isalnum() or c == "_" else "_" for c in exp_name)
            workspace_id = self.workspace_id or "default"
            task_type = self.task or "model"
            registered_model_name = f"{exp_name_clean}_{workspace_id}_{task_type}_{timestamp}"
            safe_print(f"ℹ️  Auto-generated model name: {registered_model_name}")

        model_version = None
        model_uri = None

        # 时序预测任务使用专用方法记录模型
        if self.task == "forecast":
            safe_print("Using forecast model logging (pyfunc)")
            model_uri, model_version = log_forecast_model(
                automl=self.automl,
                pipeline=self.pipeline,
                parent_run_id=parent_run_id,
                task=self.task,
                target_col=self.target_col,
                name_suffix=self.name_suffix,
                registered_model_name=registered_model_name if self.register_model else None,
                **self.kwargs
            )
            return model_uri, model_version

        has_training_set = hasattr(self, '_training_set') and self._training_set is not None

        if has_training_set:
            safe_print("Using FeatureStoreClient.log_model (with feature lineage)")
            try:
                from wedata.feature_store.client import FeatureStoreClient
                from mlflow.models import infer_signature

                signature = None
                input_example = None
                try:
                    X_sample = X_train.head(100) if len(X_train) > 100 else X_train
                    y_pred = self.pipeline.predict(X_sample)
                    signature = infer_signature(X_sample, y_pred)
                    input_example = X_sample.head(5) if len(X_sample) > 5 else X_sample
                    safe_print("✅ Model signature inferred successfully")
                except Exception as e:
                    safe_print(f"⚠️  Failed to infer model signature: {e}")

                if not hasattr(self, '_fs_client') or self._fs_client is None:
                    self._fs_client = FeatureStoreClient()

                log_model_kwargs = {
                    "model": self.pipeline,
                    "artifact_path": f"model{self.name_suffix}",
                    "flavor": mlflow.sklearn,
                    "registered_model_name": registered_model_name,
                    "signature": signature,
                    "training_set": self._training_set,
                    "input_example": input_example,
                }

                self._fs_client.log_model(**log_model_kwargs)
                model_uri = f"runs:/{parent_run_id}/model{self.name_suffix}"
                safe_print(f"✅ Model logged to MLflow: {model_uri}")

                if registered_model_name:
                    try:
                        client = mlflow.tracking.MlflowClient()
                        versions = client.search_model_versions(filter_string=f"name='{registered_model_name}'")
                        if versions:
                            model_version = max(v.version for v in versions)
                        safe_print(f"✅ Model registered: '{registered_model_name}' version {model_version}")
                        mlflow.set_tag("wedata.has_registered_model", "true")
                        if model_version:
                            set_model_version_wedata_tags(
                                registered_model_name=registered_model_name,
                                model_version=model_version,
                                task=self.task
                            )
                    except Exception as e:
                        safe_print(f"⚠️  Could not get model version: {e}")
                        mlflow.set_tag("wedata.has_registered_model", "true")
                else:
                    safe_print(
                        f"ℹ️  Model not registered "
                        f"(register_model={self.register_model}, model_name={self.model_name})"
                    )
                    mlflow.set_tag("wedata.has_registered_model", "false")

            except ImportError:
                safe_print("⚠️  wedata-feature-engineering not available, falling back to mlflow.sklearn.log_model")
                X_sample = X_train.head(100) if len(X_train) > 100 else X_train
                model_uri, model_version = log_model_with_mlflow(
                    self.pipeline, self.task, parent_run_id, self.name_suffix,
                    registered_model_name, X_sample=X_sample
                )
            except Exception as e:
                safe_print(f"⚠️  FeatureStoreClient.log_model failed: {e}")
                safe_print("   Falling back to mlflow.sklearn.log_model...")
                X_sample = X_train.head(100) if len(X_train) > 100 else X_train
                model_uri, model_version = log_model_with_mlflow(
                    self.pipeline, self.task, parent_run_id, self.name_suffix,
                    registered_model_name, X_sample=X_sample
                )
        else:
            safe_print("Using mlflow.sklearn.log_model")
            X_sample = X_train.head(100) if len(X_train) > 100 else X_train
            model_uri, model_version = log_model_with_mlflow(
                self.pipeline, self.task, parent_run_id, self.name_suffix,
                registered_model_name, X_sample=X_sample
            )

        return model_uri, model_version

    # ========================================================================
    # 私有方法：Catalog 模型记录和注册
    # ========================================================================
    def _log_model_for_catalog(self, model_uri, experiment, best_trial_run_id, trial_hook, best_est):
        """写入 Catalog 模型记录和注册"""
        if self.register_to_catalog:
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("📦 Registering Model to TencentCloud Catalog")
            print_separator()

            if not model_uri:
                safe_print("Model URI is empty, skipping model registration to Catalog. "
                           "You may need to check the model logging step.", level="WARNING")
                return

            if self.catalog_model_name:
                catalog_model_name = self.catalog_model_name
            else:
                from datetime import datetime
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                exp_name_clean = "".join(
                    c if c.isalnum() or c == "_" else "_" for c in (self.experiment_name or "automl"))
                model_name_part = f"{exp_name_clean}_{self.task}_{timestamp}"

                if self.data_source_table:
                    table_parts = self.data_source_table.split('.')
                    if len(table_parts) >= 3:
                        catalog_name = table_parts[0]
                        schema_name = table_parts[1]
                    elif len(table_parts) == 2:
                        catalog_name = os.getenv('TENCENTCLOUD_DEFAULT_CATALOG_NAME', 'default')
                        schema_name = table_parts[0]
                    else:
                        catalog_name = os.getenv('TENCENTCLOUD_DEFAULT_CATALOG_NAME', 'default')
                        schema_name = os.getenv('TENCENTCLOUD_DEFAULT_SCHEMA_NAME', 'default')
                else:
                    catalog_name = os.getenv('TENCENTCLOUD_DEFAULT_CATALOG_NAME', 'default')
                    schema_name = os.getenv('TENCENTCLOUD_DEFAULT_SCHEMA_NAME', 'default')

                catalog_model_name = f"{catalog_name}.{schema_name}.{model_name_part}"
                safe_print(f"ℹ️  Auto-generated catalog model name: {catalog_model_name}")
                safe_print(f"   Catalog: {catalog_name}, Schema: {schema_name}, Model: {model_name_part}")

            tracking_uri = mlflow.get_tracking_uri()
            run_link = f"{tracking_uri}/#/experiments/{experiment.experiment_id}/runs/{best_trial_run_id}"

            catalog_result = trial_hook.register_best_model_to_catalog(
                model_uri=model_uri,
                model_name=catalog_model_name,
                region=self.catalog_region,
                description=f"AutoML {self.task} model - {best_est}",
                run_link=run_link,
            )
            if catalog_result:
                safe_print(
                    f"✅ Model registered to Catalog: {catalog_model_name} "
                    f"v{catalog_result.get('version')}  ID:{catalog_result.get('model_id')}"
                )
            else:
                safe_print("⚠️  Catalog registration skipped or failed")
        else:
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"ℹ️  register_to_catalog:{self.register_to_catalog} . Catalog registration skipped")
            print_separator()

        return

    # ========================================================================
    # 私有方法：创建 AutoMLSummary
    # ========================================================================
    def _create_summary(
        self,
        experiment,
        experiment_name: str,
        parent_run_id: str,
        best_trial_run_id: str,
        model_uri: str,
        model_version: str,
        metrics: dict,
        best_est: str,
        best_cfg: dict,
    ) -> AutoMLSummary:
        """创建 AutoMLSummary 对象"""
        task_kwargs = {}
        if self.task == "forecast":
            task_kwargs = {
                "time_col": self.kwargs.get("time_col"),
                "horizon": self.kwargs.get("horizon"),
                "frequency": self.kwargs.get("frequency"),
                "identity_col": self.kwargs.get("identity_col"),
            }

        if self.data_source_table:
            task_kwargs["data_source_table"] = self.data_source_table

        return AutoMLSummary(
            experiment_id=experiment.experiment_id,
            run_id=parent_run_id,
            best_trial_run_id=best_trial_run_id,
            model_uri=model_uri,
            model_version=model_version,
            metrics=metrics,
            best_estimator=best_est,
            best_params=best_cfg,
            task=self.task,
            mlflow_tracking_uri=mlflow.get_tracking_uri(),
            features=self.features,
            target_col=self.target_col,
            metric=self.metric,
            task_kwargs=task_kwargs,
            workspace_id=self.workspace_id,
            experiment_name=experiment_name,
        )

    # ========================================================================
    # 私有方法：打印最终总结
    # ========================================================================
    def _print_final_summary(
        self,
        experiment_name: str,
        experiment_id: str,
        parent_run_id: str,
        best_est: str,
        model_uri: str,
        model_version: str,
        metrics: dict,
    ):
        """打印训练完成的最终总结"""
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print("🎉 Training Pipeline Completed Successfully!")
        print_separator()
        safe_print(f"Experiment: {experiment_name} (ID: {experiment_id})")
        safe_print(f"Run ID: {parent_run_id}")
        safe_print(f"Best Model: {best_est}")
        if self.register_model and self.model_name:
            safe_print(f"Registered Model: {self.model_name} v{model_version}")
        safe_print(f"Model URI: {model_uri}")

        if self.task == "classification":
            test_acc = metrics.get("test_accuracy", 0)
            test_f1 = metrics.get("test_f1", 0)
            safe_print(f"Test Accuracy: {test_acc:.4f}")
            safe_print(f"Test F1 Score: {test_f1:.4f}")
        elif self.task == "regression":
            test_r2 = metrics.get("test_r2", 0)
            test_rmse = metrics.get("test_rmse", 0)
            safe_print(f"Test R²: {test_r2:.4f}")
            safe_print(f"Test RMSE: {test_rmse:.4f}")

        print_separator()

    # ========================================================================
    # 主方法：训练
    # ========================================================================
    def train(  # noqa: C901
        self,
        dataset: Union[pd.DataFrame, Any],
        data_source_table: str,
        spark=None
    ) -> AutoMLSummary:
        """
        训练模型

        Args:
            dataset: 数据集（Pandas DataFrame、Spark DataFrame 或表名）
            data_source_table: 数据源表名（三段式：catalog.schema.table_name）
            spark: Spark session（如果 dataset 是表名）

        Returns:
            AutoMLSummary 对象
        """
        # 保存数据源表名
        self.data_source_table = data_source_table

        # ================================================================
        # 阶段 1: 数据加载
        # ================================================================
        pdf = load_data(
            dataset, self.task, data_source_table,
            time_col=self.kwargs.get("time_col"), spark=spark
        )

        if pdf is None or len(pdf) == 0:
            raise ValueError(
                "Dataset is empty (0 samples). Please check:\n"
                "  1. The data source table exists and contains data\n"
                "  2. The dataset parameter is correctly specified\n"
                "  3. Any data filters or transformations are not removing all rows"
            )
        safe_print(f"✅ Data loaded: {len(pdf)} samples, {len(pdf.columns)} columns")

        # ================================================================
        # 阶段 2: 特征存储查找（可选）
        # ================================================================
        self._fs_client = None
        self._feature_lookups = None
        self._training_set = None

        if self.feature_store_lookups:
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("🔗 Feature Store Lookups", show_timestamp=False, show_level=False)
            print_separator()
            pdf, self._fs_client, self._feature_lookups, self._training_set = apply_feature_store_lookups(
                pdf, self.feature_store_lookups, self.target_col, spark
            )

        # ================================================================
        # 阶段 3: 数据准备
        # ================================================================
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print("🔧 Data Preparation", show_timestamp=False, show_level=False)
        print_separator()
        X_train, y_train, X_val, y_val, X_test, y_test, sample_weight_train, self.features = prepare_data(
            pdf, self.target_col, None, self.task,
            self.exclude_cols, self.sample_weight_col, self.data_split_col
        )
        self._pdf = pdf  # 保存 pdf 引用（时序预测任务需要）

        # ================================================================
        # 阶段 4: 特征预处理
        # ================================================================
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print("⚙️  Feature Preprocessing")
        print_separator()

        if self.imputers:
            safe_print(f"Custom imputers configured for {len(self.imputers)} columns:")
            for col, strategy in self.imputers.items():
                safe_print(f"  - {col}: {strategy}")
        else:
            safe_print("Using default imputer: auto (median)")

        self.preprocessor = build_numeric_preprocessor(
            self.features,
            imputers=self.imputers,
            default_imputer="auto"
        )
        X_train_num = self.preprocessor.fit_transform(X_train)
        X_val_num = self.preprocessor.transform(X_val)
        X_test_num = self.preprocessor.transform(X_test)

        safe_print("Preprocessor fitted successfully")
        safe_print(f"  - Train set: {X_train_num.shape}")
        safe_print(f"  - Val set:   {X_val_num.shape}")
        safe_print(f"  - Test set:  {X_test_num.shape}")

        # ================================================================
        # 阶段 5: MLflow 实验设置
        # ================================================================
        experiment, experiment_name, experiment_id = setup_mlflow_experiment(
            self.experiment_name, self.experiment_id, self.workspace_id
        )

        # ================================================================
        # 阶段 6: MLflow Run 和 AutoML 训练
        # ================================================================
        setup_mlflow_user_id()

        with mlflow.start_run(run_name=f"{self.run_name}{self.name_suffix}") as parent_run:
            parent_run_id = parent_run.info.run_id
            safe_print(f"Run name: '{self.run_name}{self.name_suffix}'")
            safe_print(f"Run ID: {parent_run_id}")

            # 删除父 run 的 mlflow.source.name tag
            try:
                mlflow.delete_tag("mlflow.source.name")
            except Exception:
                pass

            # 设置 WeData 平台 tags
            set_run_wedata_tags(task=self.task)

            # 记录基本参数
            mlflow.log_params({
                "task": self.task,
                "target_col": self.target_col,
                "timeout_minutes": self.timeout_minutes,
                "metric": self.metric,
                "n_rows": len(pdf),
                "n_features": len(self.features),
            })

            if self.data_source_table:
                mlflow.log_param("data_source_table", self.data_source_table)
                mlflow.set_tag("wedata.data_source_table", self.data_source_table)

            input_dataset = _build_mlflow_input_dataset(pdf, self.data_source_table, self.target_col)
            if input_dataset is not None:
                try:
                    mlflow.log_input(input_dataset, context="training")
                    safe_print(f"Logged input dataset to parent run: {getattr(input_dataset, 'name', 'training_data')}")
                except Exception as _log_input_err:
                    safe_print(f"Failed to log_input on parent run: {_log_input_err}")
                    input_dataset = None

            log_feature_list(self.features)
            log_engine_meta({"engine": "flaml", "version": getattr(flaml_pkg, "__version__", "unknown")})

            # ================================================================
            # 阶段 7: FLAML 配置
            # ================================================================
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("🤖 AutoML Training Configuration")
            print_separator()
            self.automl = AutoML()

            # 清理旧日志文件
            if self.auto_cleanup_logs:
                safe_print("", show_timestamp=False, show_level=False)
                safe_print("🧹 Cleaning up old log files...")
                try:
                    deleted_count = cleanup_old_log_files(
                        base_dir=self.log_file_dir,
                        max_age_hours=self.log_max_age_hours,
                        max_files=self.log_max_files,
                        dry_run=False
                    )
                    if deleted_count > 0:
                        safe_print(f"✅ Deleted {deleted_count} old log files")
                    else:
                        safe_print("✅ No old log files to clean up")
                except Exception as e:
                    safe_print(f"⚠️  Failed to cleanup old log files: {e}")

            # 生成日志文件路径
            log_file_path = generate_log_file_path(
                base_dir=self.log_file_dir,
                run_id=parent_run_id,
                use_timestamp=True,
                use_uuid=True
            )
            safe_print(f"📝 FLAML log file: {log_file_path}")

            # 构建 FLAML 设置
            settings = self._build_flaml_settings(log_file_path)

            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("🚀 Starting AutoML Training...", show_timestamp=False, show_level=False)
            print_separator()

            # ================================================================
            # 阶段 8: 准备 fit 参数并训练
            # ================================================================
            safe_print("", show_timestamp=False, show_level=False)
            safe_print("🔧 Preparing TrialHook to log all trials...")
            trial_hook = TrialHook(
                parent_run_id=parent_run_id,
                features=self.features,
                task=self.task,
                metric=self.metric,
                enable_logging=True,
                input_dataset=input_dataset,
            )

            # 准备 fit 参数
            if self.task == "forecast":
                fit_kwargs, inferred_freq = prepare_forecast_data(
                    self._pdf, self.target_col, self.features, settings,
                    time_col=self.kwargs.get("time_col"),
                    horizon=self.kwargs.get("horizon", 1),
                    frequency=self.kwargs.get("frequency", "auto"),
                )
                # 更新 frequency：优先使用推断值，否则映射用户传入值
                if inferred_freq:
                    self.kwargs["frequency"] = inferred_freq
                else:
                    self.kwargs["frequency"] = resolve_frequency(
                        self.kwargs.get("frequency", "D")
                    )
            else:
                fit_kwargs = {
                    "X_train": X_train_num,
                    "y_train": y_train,
                    "X_val": X_val_num,
                    "y_val": y_val,
                    **settings,
                }
                if sample_weight_train is not None:
                    fit_kwargs["sample_weight"] = sample_weight_train
                    safe_print("Using sample weights for training")

            # 执行训练
            start_time = time.time()
            actual_train_time = self._run_automl_training(fit_kwargs)

            # 记录 trials
            trial_hook.log_trials_from_automl(
                self.automl,
                log_file_path=log_file_path,
                feature_names=self.features,
                time_budget=int(self.timeout_minutes * 60),
                train_time=actual_train_time
            )

            # 上传日志文件
            upload_log_file(log_file_path, auto_cleanup=self.auto_cleanup_logs)

            # ================================================================
            # 阶段 9: 训练完成后处理
            # ================================================================
            elapsed_time = time.time() - start_time
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("✅ AutoML Training Completed", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"Total training time: {elapsed_time:.1f}s ({elapsed_time/60:.2f} minutes)")

            trial_hook.print_summary()

            # 设置 best trial tags
            if self.task == "forecast":
                trial_hook.set_best_trial_tags(
                    source_name=None,
                    workspace_id=self.workspace_id,
                    task=self.task,
                )
            else:
                trial_hook.set_best_trial_tags(
                    source_name="wedata-automl",
                    workspace_id=self.workspace_id,
                    task=self.task,
                )
            trial_hook.cleanup_child_runs_source_name(experiment.experiment_id, preserve_best=True)

            # 获取 TrialHook 统计信息
            hook_summary = trial_hook.get_summary()
            total_trials_run = hook_summary['total_trials']
            best_trial_run_id = hook_summary['best_trial_run_id']
            best_trial_run_name = hook_summary['best_trial_run_name']

            # 记录最佳配置
            best_est = self.automl.best_estimator
            best_cfg = self.automl.best_config
            log_best_config_overall(best_cfg)
            if getattr(self.automl, "best_config_per_estimator", None):
                log_best_config_per_estimator(self.automl.best_config_per_estimator)

            mlflow.log_param("best_estimator", best_est)
            mlflow.log_param("best_trial_run_id", best_trial_run_id)
            mlflow.log_param("total_trials", total_trials_run)

            if "learning_rate" in best_cfg:
                mlflow.log_param("learning_rate", best_cfg["learning_rate"])
            if "n_estimators" in best_cfg:
                mlflow.log_param("n_estimators", best_cfg["n_estimators"])

            mlflow.set_tags({
                "wedata.total_trials_run": str(total_trials_run),
                "wedata.best_run_id": best_trial_run_id,
                "wedata.best_run_name": best_trial_run_name,
            })
            safe_print(
                f"✅ Tags set: total_trials_run={total_trials_run}, "
                f"best_run_id={best_trial_run_id}, best_run_name={best_trial_run_name}"
            )

            safe_print("", show_timestamp=False, show_level=False)
            safe_print(f"Best estimator: {best_est}")
            safe_print(f"Best config: {best_cfg}")

            # ================================================================
            # 阶段 10: 构建管道和评估
            # ================================================================
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("🔨 Building Serving Pipeline")
            print_separator()

            if self.task == "forecast":
                self.pipeline = self.automl.model
                safe_print("Pipeline built: [TimeSeriesEstimator] (forecast mode)")
            else:
                clf = self.automl.model
                self.pipeline = SkPipe([("preprocess", self.preprocessor), ("clf", clf)])
                self.pipeline.fit(X_train, y_train)
                safe_print("Pipeline built: [Preprocessor] -> [Classifier/Regressor]")

            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("📊 Model Evaluation")
            print_separator()

            if self.task == "forecast":
                metrics = {"best_loss": self.automl.best_loss}

                mlflow.log_metric("best_loss", self.automl.best_loss)
                if self.metric:
                    mlflow.log_metric(f"best_{self.metric}", self.automl.best_loss)

                # 尝试计算更多评估指标
                try:
                    y_val_pred = self.automl.predict(X_val)
                    y_val_true = np.array(y_val)
                    y_val_pred = np.array(y_val_pred)

                    mse = float(np.mean((y_val_true - y_val_pred) ** 2))
                    metrics["val_mse"] = mse
                    mlflow.log_metric("val_mse", mse)

                    rmse = float(np.sqrt(mse))
                    metrics["val_rmse"] = rmse
                    mlflow.log_metric("val_rmse", rmse)

                    mae = float(np.mean(np.abs(y_val_true - y_val_pred)))
                    metrics["val_mae"] = mae
                    mlflow.log_metric("val_mae", mae)

                    denominator = (np.abs(y_val_true) + np.abs(y_val_pred)) / 2
                    denominator = np.where(denominator == 0, 1e-10, denominator)
                    smape = float(np.mean(np.abs(y_val_pred - y_val_true) / denominator) * 100)
                    metrics["val_smape"] = smape
                    mlflow.log_metric("val_smape", smape)

                    y_val_true_safe = np.where(y_val_true == 0, 1e-10, y_val_true)
                    ape = np.abs(y_val_pred - y_val_true) / np.abs(y_val_true_safe) * 100
                    mdape = float(np.median(ape))
                    metrics["val_mdape"] = mdape
                    mlflow.log_metric("val_mdape", mdape)

                    safe_print("  Validation Metrics:")
                    safe_print(f"    SMAPE: {smape:.4f}% | RMSE: {rmse:.4f} | MAE: {mae:.4f} | MDAPE: {mdape:.4f}%")

                except Exception as e:
                    logger.debug(f"Failed to compute additional forecast metrics: {e}")
                    safe_print(f"  Best loss: {self.automl.best_loss:.4f}")
            else:
                metrics = self._evaluate_model(X_train, y_train, X_val, y_val, X_test, y_test)

            # ================================================================
            # 阶段 11: 模型记录和注册
            # ================================================================
            model_uri, model_version = self._log_and_register_model(parent_run_id, X_train)

            # ================================================================
            # 阶段 11.5: 时序预测结果保存（可选）
            # ================================================================
            if self.task == "forecast" and self.prediction_result_storage:
                save_forecast_predictions(
                    automl=self.automl,
                    parent_run_id=parent_run_id,
                    pdf=pdf,
                    prediction_result_storage=self.prediction_result_storage,
                    target_col=self.target_col,
                    time_col=self.kwargs.get("time_col"),
                    horizon=self.kwargs.get("horizon", 1),
                    frequency=self.kwargs.get("frequency", "D"),
                    spark=spark
                )

            # ================================================================
            # 阶段 11.6: 注册模型到 TencentCloud Catalog（可选）
            # ================================================================
            self._log_model_for_catalog(model_uri, experiment, best_trial_run_id, trial_hook, best_est)

            # ================================================================
            # 阶段 12: 创建 Summary 并返回
            # ================================================================
            summary = self._create_summary(
                experiment=experiment,
                experiment_name=experiment_name,
                parent_run_id=parent_run_id,
                best_trial_run_id=best_trial_run_id,
                model_uri=model_uri,
                model_version=model_version,
                metrics=metrics,
                best_est=best_est,
                best_cfg=best_cfg,
            )

            self._print_final_summary(
                experiment_name=experiment_name,
                experiment_id=experiment.experiment_id,
                parent_run_id=parent_run_id,
                best_est=best_est,
                model_uri=model_uri,
                model_version=model_version,
                metrics=metrics,
            )

            mlflow_client = mlflow.tracking.MlflowClient()
            mlflow_client.set_experiment_tag(experiment_id, "wedata.experiment.automl.status", "FINISHED")
            end_ts = str(int(time.time() * 1000))
            mlflow_client.set_experiment_tag(
                experiment_id, "wedata.experiment.automl.end.timestamp", end_ts
            )
            return summary
