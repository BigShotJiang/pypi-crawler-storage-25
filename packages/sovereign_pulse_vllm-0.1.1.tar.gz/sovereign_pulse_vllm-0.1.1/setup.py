from setuptools import setup, find_packages

setup(
    name="sovereign-pulse-vllm",
    version="0.1.1",
    author="Mahdi Diab",
    author_email="poseidoelunico@gmail.com",
    description="Sovereign Pulse physics gate — vLLM LogitsProcessor plugin",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=["torch>=2.0"],
    extras_require={"vllm": ["vllm>=0.4.0"]},
    entry_points={
        "vllm.logits_processors": [
            "sovereign_pulse = sovereign_pulse_vllm:SovereignPulseLogitsProcessor",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
