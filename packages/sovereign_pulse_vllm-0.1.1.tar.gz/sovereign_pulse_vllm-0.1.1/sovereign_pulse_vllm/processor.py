"""
SovereignPulseLogitsProcessor — vLLM plugin

Integrates the Sovereign Pulse physics gate as a vLLM LogitsProcessor.
Blocked tokens have their logits set to -inf, preventing sampling.

Usage:
    from sovereign_pulse_vllm import SovereignPulseLogitsProcessor
    from vllm import LLM, SamplingParams

    gate = SovereignPulseLogitsProcessor(mass_budget=500.0)
    params = SamplingParams(logits_processors=[gate], temperature=0)
    llm = LLM(model="meta-llama/Meta-Llama-3-8B-Instruct")
    output = llm.generate("The capital of France is", params)
"""
from __future__ import annotations

import math
from typing import List

import torch

try:
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../python'))
    from sovereign_pulse import SovereignPulse, LmOutputs
    _SP_AVAILABLE = True
except Exception:
    _SP_AVAILABLE = False


class SovereignPulseLogitsProcessor:
    """
    vLLM-compatible LogitsProcessor that gates each token using
    Sovereign Pulse physics laws.

    Blocked tokens: logits set to -inf (token cannot be sampled).
    Passed tokens: logits unchanged.

    Args:
        mass_budget:       Session energy budget (default 500.0 for large models)
        confidence_floor:  Minimum truth_index to pass (default 0.02)
        vocab_size:        Model vocabulary size (auto-detected if 0)
        verbose:           Print gate decisions to stdout
    """

    def __init__(
        self,
        mass_budget: float = 500.0,
        confidence_floor: float = 0.02,
        vocab_size: int = 0,
        verbose: bool = False,
    ):
        self.mass_budget = mass_budget
        self.confidence_floor = confidence_floor
        self.vocab_size = vocab_size
        self.verbose = verbose
        self._sp = None
        self._step = 0
        self._stats = {"passed": 0, "blocked": 0}

        if not _SP_AVAILABLE:
            import warnings
            warnings.warn(
                "sovereign_pulse native library not found. "
                "Gate will run in simulation mode (truth_index only). "
                "Build with: cargo build --release --features std",
                RuntimeWarning,
                stacklevel=2,
            )

    def _ensure_gate(self, vocab_size: int) -> None:
        if self._sp is None:
            vs = vocab_size if vocab_size > 0 else (self.vocab_size or 50257)
            if _SP_AVAILABLE:
                self._sp = SovereignPulse.create(
                    mass_budget=self.mass_budget,
                    vocab_size=vs,
                    confidence_floor=self.confidence_floor,
                )
                self._sp.__enter__()
            self.vocab_size = vs

    def _entropy_bits(self, probs: torch.Tensor) -> float:
        nz = probs[probs > 1e-10]
        return float(-(nz * torch.log2(nz)).sum())

    def _renyi_delta(self, probs: torch.Tensor, p1: float, entropy: float) -> float:
        """ΔH = H_shannon - H_inf = entropy + log2(p1). Rényi tail gap."""
        import math
        h_inf = -math.log2(max(p1, 1e-10))
        return max(0.0, entropy - h_inf)

    def _hamiltonian(self, p1: float, p2: float) -> float:
        """H = branch_mass / (truth_index × budget). >1.0 means compute exceeds value."""
        ti = (p1 - p2) / max(p1, 1e-9)
        branch_mass = 1.0 - p1
        return branch_mass / max(ti * max(self.mass_budget * 0.001, 1e-9), 1e-9)

    def _simulate_pass(self, p1: float, p2: float,
                       probs: "torch.Tensor | None" = None,
                       entropy: float = 0.0) -> tuple[bool, str]:
        """5-gate Python fallback: truth_index → Rényi → Hamiltonian → Landauer → basic."""
        ti = (p1 - p2) / max(p1, 1e-9)

        # Gate 1: truth_index (Noether symmetry)
        if ti < self.confidence_floor:
            return False, f"truth_index={ti:.3f} below floor={self.confidence_floor}"

        # Gate 2: Rényi tail (heavy-tail uncertainty Shannon misses)
        if probs is not None and entropy > 0:
            delta_h = self._renyi_delta(probs, p1, entropy)
            if delta_h > 1.8:
                return False, f"renyi_tail: ΔH={delta_h:.3f} > 1.8"

        # Gate 3: Hamiltonian (compute cost exceeds information value)
        h = self._hamiltonian(p1, p2)
        if h > 1.0:
            return False, f"hamiltonian: H={h:.3f} > 1.0"

        # Gate 4: Landauer — p1 must be above kT·ln2 floor (proxy: p1 > 1/vocab)
        if self.vocab_size > 0 and p1 < 1.0 / self.vocab_size:
            return False, f"landauer: p1={p1:.4f} below 1/vocab floor"

        return True, "ok"

    def __call__(self, token_ids: List[int], logits: torch.Tensor) -> torch.Tensor:
        vocab_size = logits.shape[-1]
        self._ensure_gate(vocab_size)

        probs = torch.softmax(logits.float(), dim=-1)
        top2 = torch.topk(probs, k=2)
        p1 = float(top2.values[0])
        p2 = float(top2.values[1])
        top1_id = int(top2.indices[0])
        entropy = self._entropy_bits(probs)

        if _SP_AVAILABLE and self._sp is not None:
            lm = LmOutputs(
                top1_prob=p1,
                top2_prob=p2,
                entropy_bits=entropy,
                vocab_size=vocab_size,
            )
            result = self._sp.process_token(
                token_id=top1_id,
                position=self._step,
                lm=lm,
                is_last=False,
            )
            passed = result.passed
            reason = "ok" if passed else result.reason
        else:
            passed, reason = self._simulate_pass(p1, p2, probs=probs, entropy=entropy)

        self._step += 1

        if passed:
            self._stats["passed"] += 1
        else:
            self._stats["blocked"] += 1
            # Block the top-1 token by setting its logit to -inf
            logits[top1_id] = float("-inf")
            if self.verbose:
                ti = (p1 - p2) / max(p1, 1e-9)
                print(f"[SP gate] step={self._step} BLOCK p1={p1:.3f} "
                      f"ti={ti:.3f} ent={entropy:.2f} reason={reason}")

        return logits

    def reset(self) -> None:
        """Reset gate state for a new session."""
        if self._sp is not None and _SP_AVAILABLE:
            try:
                self._sp.__exit__(None, None, None)
            except Exception:
                pass
        self._sp = None
        self._step = 0
        self._stats = {"passed": 0, "blocked": 0}

    @property
    def stats(self) -> dict:
        total = self._stats["passed"] + self._stats["blocked"]
        return {
            **self._stats,
            "total": total,
            "block_rate": self._stats["blocked"] / max(total, 1),
        }

    def __del__(self):
        if self._sp is not None and _SP_AVAILABLE:
            try:
                self._sp.__exit__(None, None, None)
            except Exception:
                pass
