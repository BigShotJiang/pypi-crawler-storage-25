"""
Sovereign Pulse — vLLM LogitsProcessor plugin
Blocks uncertain tokens before they reach the sampler.
"""
from .processor import SovereignPulseLogitsProcessor

__all__ = ["SovereignPulseLogitsProcessor"]
__version__ = "0.1.1"
