# Sovereign Pulse — vLLM Plugin

Physics-grounded token gate for vLLM. Blocks uncertain tokens before sampling using 75 physics laws in 46 ns/token.

## Install

```bash
pip install sovereign-pulse-vllm
```

## Usage — 2 lines

```python
from sovereign_pulse_vllm import SovereignPulseLogitsProcessor
from vllm import LLM, SamplingParams

gate   = SovereignPulseLogitsProcessor(mass_budget=500.0, verbose=True)
params = SamplingParams(logits_processors=[gate], temperature=0, max_tokens=200)
llm    = LLM(model="meta-llama/Meta-Llama-3-8B-Instruct")

output = llm.generate("The capital of France is", params)
print(output[0].outputs[0].text)
print(gate.stats)
# {'passed': 142, 'blocked': 58, 'total': 200, 'block_rate': 0.29}
```

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `mass_budget` | 500.0 | Session energy budget (higher = less blocking) |
| `confidence_floor` | 0.02 | Minimum truth_index to pass |
| `verbose` | False | Print per-token gate decisions |

## What it blocks

A token is blocked when any physics law fails:

- **truth_index** = (p1−p2)/p1 below floor — model is coin-flipping
- **Hamiltonian** H > 1.0 — compute cost exceeds information value
- **Rényi entropy** tail — heavy-tail uncertainty Shannon misses
- **Landauer bound** — physically impossible token cost
- **Poincaré recurrence** — model repeating a previous state

## Commercial licensing

MIT license for research and personal use.
Commercial deployment license: poseidoelunico@gmail.com
