"""
Tests for SovereignPulseLogitsProcessor — runs without vLLM.
__call__ tests patch _SP_AVAILABLE=False to run in simulation mode
so they work regardless of whether the native .so is built.
"""
import math
from unittest.mock import patch
import torch
import pytest
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import sovereign_pulse_vllm.processor as _proc_mod
from sovereign_pulse_vllm import SovereignPulseLogitsProcessor


def _make_logits(vocab_size: int, top1_id: int, p1: float, p2: float) -> torch.Tensor:
    """Build a logit tensor where top1_id has probability p1 and top1_id+1 has p2."""
    logits = torch.full((vocab_size,), -1e9)
    remaining = 1.0 - p1 - p2
    logits[:] = math.log(max(remaining / max(vocab_size - 2, 1), 1e-30))
    logits[top1_id] = math.log(p1)
    logits[(top1_id + 1) % vocab_size] = math.log(p2)
    return logits


# ── instantiation ─────────────────────────────────────────────────────────────

def test_default_init():
    gate = SovereignPulseLogitsProcessor()
    assert gate.mass_budget == 500.0
    assert gate.confidence_floor == 0.02
    assert gate.vocab_size == 0
    assert not gate.verbose


def test_custom_init():
    gate = SovereignPulseLogitsProcessor(mass_budget=10.0, confidence_floor=0.1, vocab_size=32000)
    assert gate.mass_budget == 10.0
    assert gate.confidence_floor == 0.1
    assert gate.vocab_size == 32000


# ── simulation pass/block ─────────────────────────────────────────────────────

def test_decisive_token_passes():
    gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
    passed, reason = gate._simulate_pass(p1=0.80, p2=0.10)
    assert passed
    assert reason == "ok"


def test_coin_flip_token_blocked():
    gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
    # truth_index = (0.50 - 0.496) / 0.50 = 0.008 — strictly below floor
    passed, reason = gate._simulate_pass(p1=0.50, p2=0.496)
    assert not passed
    assert "truth_index" in reason


def test_high_floor_blocks_moderate_token():
    gate = SovereignPulseLogitsProcessor(confidence_floor=0.50)
    # truth_index = (0.60 - 0.50) / 0.60 ≈ 0.167 — below 0.50 floor
    passed, _ = gate._simulate_pass(p1=0.60, p2=0.50)
    assert not passed


def test_zero_p1_does_not_divide_by_zero():
    gate = SovereignPulseLogitsProcessor()
    passed, reason = gate._simulate_pass(p1=0.0, p2=0.0)
    assert not passed  # truth_index ≈ 0


# ── __call__ — logit modification ─────────────────────────────────────────────

def test_blocked_token_gets_neg_inf():
    with patch.object(_proc_mod, '_SP_AVAILABLE', False):
        gate = SovereignPulseLogitsProcessor(confidence_floor=0.50)
        vocab = 100
        top1_id = 7
        logits = _make_logits(vocab, top1_id, p1=0.51, p2=0.49)
        # truth_index ≈ 0.039 < 0.50 floor → should block
        result = gate([], logits)
        assert result[top1_id] == float("-inf")


def test_passed_token_logits_unchanged():
    with patch.object(_proc_mod, '_SP_AVAILABLE', False):
        gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
        vocab = 100
        top1_id = 3
        logits = _make_logits(vocab, top1_id, p1=0.90, p2=0.05)
        original_top1 = float(logits[top1_id])
        result = gate([], logits)
        assert result[top1_id] == pytest.approx(original_top1)


def test_call_returns_tensor():
    with patch.object(_proc_mod, '_SP_AVAILABLE', False):
        gate = SovereignPulseLogitsProcessor()
        logits = _make_logits(50257, 0, 0.8, 0.1)
        result = gate([], logits)
        assert isinstance(result, torch.Tensor)
        assert result.shape == logits.shape


# ── stats tracking ────────────────────────────────────────────────────────────

def test_stats_count_passed():
    with patch.object(_proc_mod, '_SP_AVAILABLE', False):
        gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
        for _ in range(5):
            gate([], _make_logits(100, 0, 0.90, 0.05))  # all pass
        assert gate.stats["passed"] == 5
        assert gate.stats["blocked"] == 0
        assert gate.stats["total"] == 5
        assert gate.stats["block_rate"] == 0.0


def test_stats_count_blocked():
    with patch.object(_proc_mod, '_SP_AVAILABLE', False):
        gate = SovereignPulseLogitsProcessor(confidence_floor=0.50)
        for _ in range(3):
            gate([], _make_logits(100, 0, 0.51, 0.49))  # all block
        assert gate.stats["blocked"] == 3
        assert gate.stats["passed"] == 0
        assert gate.stats["block_rate"] == 1.0


def test_stats_mixed():
    with patch.object(_proc_mod, '_SP_AVAILABLE', False):
        gate = SovereignPulseLogitsProcessor(confidence_floor=0.30)
        # truth_index = (0.9-0.05)/0.9 ≈ 0.94 → pass
        gate([], _make_logits(100, 0, 0.90, 0.05))
        # truth_index = (0.51-0.49)/0.51 ≈ 0.04 → block
        gate([], _make_logits(100, 0, 0.51, 0.49))
        assert gate.stats["passed"] == 1
        assert gate.stats["blocked"] == 1
        assert gate.stats["block_rate"] == pytest.approx(0.5)


def test_stats_block_rate_zero_tokens():
    gate = SovereignPulseLogitsProcessor()
    assert gate.stats["block_rate"] == 0.0  # no division by zero


# ── reset ─────────────────────────────────────────────────────────────────────

def test_reset_clears_stats():
    gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
    gate([], _make_logits(100, 0, 0.90, 0.05))
    gate.reset()
    assert gate.stats["passed"] == 0
    assert gate.stats["blocked"] == 0
    assert gate.stats["total"] == 0


def test_reset_clears_step():
    gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
    gate([], _make_logits(100, 0, 0.90, 0.05))
    assert gate._step == 1
    gate.reset()
    assert gate._step == 0


def test_works_after_reset():
    gate = SovereignPulseLogitsProcessor(confidence_floor=0.02)
    gate([], _make_logits(100, 0, 0.90, 0.05))
    gate.reset()
    gate([], _make_logits(100, 0, 0.90, 0.05))
    assert gate.stats["total"] == 1


# ── step counter ──────────────────────────────────────────────────────────────

def test_step_increments():
    gate = SovereignPulseLogitsProcessor()
    assert gate._step == 0
    gate([], _make_logits(100, 0, 0.80, 0.10))
    assert gate._step == 1
    gate([], _make_logits(100, 0, 0.80, 0.10))
    assert gate._step == 2
