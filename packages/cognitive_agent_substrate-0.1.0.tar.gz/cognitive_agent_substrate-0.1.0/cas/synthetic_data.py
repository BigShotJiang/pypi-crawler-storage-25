"""
Synthetic data generators for CAS experiments.
Provides deterministic, reproducible test data.
"""

import random
import numpy as np

ANIMALS = [
    ("cat", {"class": "mammal", "habitat": "domestic", "diet": "carnivore", "legs": "4"}),
    ("dog", {"class": "mammal", "habitat": "domestic", "diet": "omnivore", "legs": "4"}),
    ("whale", {"class": "mammal", "habitat": "ocean", "diet": "carnivore", "legs": "0"}),
    ("dolphin", {"class": "mammal", "habitat": "ocean", "diet": "carnivore", "legs": "0"}),
    ("eagle", {"class": "bird", "habitat": "mountain", "diet": "carnivore", "legs": "2"}),
    ("parrot", {"class": "bird", "habitat": "tropical", "diet": "herbivore", "legs": "2"}),
    ("penguin", {"class": "bird", "habitat": "arctic", "diet": "carnivore", "legs": "2"}),
    ("salmon", {"class": "fish", "habitat": "ocean", "diet": "carnivore", "legs": "0"}),
    ("trout", {"class": "fish", "habitat": "freshwater", "diet": "omnivore", "legs": "0"}),
    ("shark", {"class": "fish", "habitat": "ocean", "diet": "carnivore", "legs": "0"}),
    ("frog", {"class": "amphibian", "habitat": "freshwater", "diet": "carnivore", "legs": "4"}),
    ("salamander", {"class": "amphibian", "habitat": "forest", "diet": "carnivore", "legs": "4"}),
    ("cobra", {"class": "reptile", "habitat": "tropical", "diet": "carnivore", "legs": "0"}),
    ("turtle", {"class": "reptile", "habitat": "ocean", "diet": "omnivore", "legs": "4"}),
    ("crocodile", {"class": "reptile", "habitat": "freshwater", "diet": "carnivore", "legs": "4"}),
    ("horse", {"class": "mammal", "habitat": "grassland", "diet": "herbivore", "legs": "4"}),
    ("cow", {"class": "mammal", "habitat": "grassland", "diet": "herbivore", "legs": "4"}),
    ("rabbit", {"class": "mammal", "habitat": "grassland", "diet": "herbivore", "legs": "4"}),
    ("bear", {"class": "mammal", "habitat": "forest", "diet": "omnivore", "legs": "4"}),
    ("wolf", {"class": "mammal", "habitat": "forest", "diet": "carnivore", "legs": "4"}),
    ("lion", {"class": "mammal", "habitat": "savanna", "diet": "carnivore", "legs": "4"}),
    ("elephant", {"class": "mammal", "habitat": "savanna", "diet": "herbivore", "legs": "4"}),
    ("giraffe", {"class": "mammal", "habitat": "savanna", "diet": "herbivore", "legs": "4"}),
    ("bat", {"class": "mammal", "habitat": "cave", "diet": "omnivore", "legs": "2"}),
    ("owl", {"class": "bird", "habitat": "forest", "diet": "carnivore", "legs": "2"}),
    ("sparrow", {"class": "bird", "habitat": "urban", "diet": "omnivore", "legs": "2"}),
    ("hawk", {"class": "bird", "habitat": "mountain", "diet": "carnivore", "legs": "2"}),
    ("goldfish", {"class": "fish", "habitat": "freshwater", "diet": "omnivore", "legs": "0"}),
    ("tuna", {"class": "fish", "habitat": "ocean", "diet": "carnivore", "legs": "0"}),
    ("iguana", {"class": "reptile", "habitat": "tropical", "diet": "herbivore", "legs": "4"}),
    ("deer", {"class": "mammal", "habitat": "forest", "diet": "herbivore", "legs": "4"}),
    ("fox", {"class": "mammal", "habitat": "forest", "diet": "omnivore", "legs": "4"}),
    ("zebra", {"class": "mammal", "habitat": "savanna", "diet": "herbivore", "legs": "4"}),
    ("hippo", {"class": "mammal", "habitat": "freshwater", "diet": "herbivore", "legs": "4"}),
    ("seal", {"class": "mammal", "habitat": "ocean", "diet": "carnivore", "legs": "4"}),
    ("otter", {"class": "mammal", "habitat": "freshwater", "diet": "carnivore", "legs": "4"}),
    ("flamingo", {"class": "bird", "habitat": "freshwater", "diet": "omnivore", "legs": "2"}),
    ("pelican", {"class": "bird", "habitat": "ocean", "diet": "carnivore", "legs": "2"}),
    ("stork", {"class": "bird", "habitat": "grassland", "diet": "carnivore", "legs": "2"}),
    ("eel", {"class": "fish", "habitat": "ocean", "diet": "carnivore", "legs": "0"}),
    ("catfish", {"class": "fish", "habitat": "freshwater", "diet": "omnivore", "legs": "0"}),
    ("toad", {"class": "amphibian", "habitat": "forest", "diet": "carnivore", "legs": "4"}),
    ("newt", {"class": "amphibian", "habitat": "freshwater", "diet": "carnivore", "legs": "4"}),
    ("gecko", {"class": "reptile", "habitat": "tropical", "diet": "carnivore", "legs": "4"}),
    ("chameleon", {"class": "reptile", "habitat": "tropical", "diet": "carnivore", "legs": "4"}),
    ("leopard", {"class": "mammal", "habitat": "savanna", "diet": "carnivore", "legs": "4"}),
    ("gorilla", {"class": "mammal", "habitat": "forest", "diet": "herbivore", "legs": "4"}),
    ("chimpanzee", {"class": "mammal", "habitat": "forest", "diet": "omnivore", "legs": "4"}),
    ("ostrich", {"class": "bird", "habitat": "savanna", "diet": "omnivore", "legs": "2"}),
]

SECURITY_EVENTS = [
    ("port_scan_detected", "Port scan detected on port 80"),
    ("brute_force_attempt", "Brute force login attempt detected"),
    ("firewall_updated", "Firewall rules updated to block source IP"),
    ("server_restart", "Server restarted after security update"),
    ("malware_detected", "Malware signature detected in uploaded file"),
    ("quarantine_file", "Infected file moved to quarantine"),
    ("ids_alert", "IDS triggered alert for suspicious traffic pattern"),
    ("traffic_blocked", "Suspicious traffic blocked at gateway"),
    ("privilege_escalation", "Unauthorized privilege escalation attempt"),
    ("account_locked", "User account locked after failed attempts"),
    ("ssl_expired", "SSL certificate expired on web server"),
    ("ssl_renewed", "SSL certificate renewed and deployed"),
    ("ddos_detected", "DDoS attack pattern detected"),
    ("rate_limit_applied", "Rate limiting applied to source IP range"),
    ("data_exfiltration", "Potential data exfiltration detected"),
    ("vpn_blocked", "Unauthorized VPN connection blocked"),
]

CAUSAL_CHAINS = [
    ["port_scan_detected", "firewall_updated", "server_restart"],
    ["brute_force_attempt", "account_locked", "firewall_updated"],
    ["malware_detected", "quarantine_file", "server_restart"],
    ["ids_alert", "traffic_blocked", "firewall_updated"],
    ["privilege_escalation", "account_locked", "server_restart"],
    ["ssl_expired", "ssl_renewed", "server_restart"],
    ["ddos_detected", "rate_limit_applied", "traffic_blocked"],
    ["data_exfiltration", "vpn_blocked", "account_locked"],
]

KNOWLEDGE_QA = [
    {
        "query": "What class does the cat belong to?",
        "facts": ["A cat is a mammal", "Cats are domestic animals", "Cats are carnivores"],
        "answer": "mammal",
    },
    {
        "query": "What happens after a port scan is detected?",
        "facts": ["Port scan detected on port 80", "Firewall rules updated", "Server restarted"],
        "answer": "firewall update followed by server restart",
    },
    {
        "query": "Are dolphins and whales related?",
        "facts": ["Dolphins are mammals", "Whales are mammals", "Both live in the ocean"],
        "answer": "yes, both are ocean-dwelling mammals",
    },
    {
        "query": "What is the typical response to a brute force attack?",
        "facts": ["Brute force attempt detected", "Account locked", "Firewall updated"],
        "answer": "account lockout and firewall update",
    },
    {
        "query": "Which animals have four legs and live in forests?",
        "facts": ["Bears live in forests", "Wolves live in forests", "Bears have 4 legs", "Wolves have 4 legs"],
        "answer": "bears and wolves",
    },
    {
        "query": "What should happen when malware is found?",
        "facts": ["Malware detected in file", "File quarantined", "Server restarted"],
        "answer": "quarantine the file and restart the server",
    },
    {
        "query": "Are birds typically carnivores?",
        "facts": ["Eagles are carnivore birds", "Owls are carnivore birds", "Hawks are carnivore birds", "Parrots are herbivore birds"],
        "answer": "many birds are carnivores, but not all",
    },
    {
        "query": "What do ocean carnivores include?",
        "facts": ["Sharks are ocean carnivores", "Whales are ocean carnivores", "Tuna are ocean carnivores"],
        "answer": "sharks, whales, and tuna",
    },
]


def generate_animal_dataset(seed: int = 42) -> tuple[list, list]:
    """Split animals into train (80%) and test (20%)."""
    rng = random.Random(seed)
    animals = list(ANIMALS)
    rng.shuffle(animals)
    split = int(len(animals) * 0.8)
    return animals[:split], animals[split:]


def generate_security_corpus(n_chains: int = 50, seed: int = 42) -> list[dict]:
    """Generate security event traces with causal chains."""
    rng = random.Random(seed)
    corpus = []
    for i in range(n_chains):
        chain = rng.choice(CAUSAL_CHAINS)
        events = []
        for event_id in chain:
            for eid, desc in SECURITY_EVENTS:
                if eid == event_id:
                    events.append({"id": eid, "description": desc})
                    break
        corpus.append({
            "trace_id": f"trace_{i:04d}",
            "events": events,
            "chain_ids": chain,
        })
    return corpus


def generate_scaled_graph_data(n_nodes: int, avg_edges: int = 10, seed: int = 42) -> dict:
    """Generate synthetic graph data at specified scale."""
    rng = random.Random(seed)
    np_rng = np.random.RandomState(seed)

    nodes = []
    for i in range(n_nodes):
        node_type = rng.choice(["L1", "L2", "L3"])
        content = f"synthetic_entry_{i:06d}_{node_type}"
        embedding = np_rng.randn(384).astype(np.float32)
        embedding = embedding / (np.linalg.norm(embedding) + 1e-10)
        cluster_id = i % 256
        nodes.append({
            "node_id": f"{node_type}_{i:06d}",
            "node_type": node_type,
            "content": content,
            "embedding": embedding,
            "cluster_id": cluster_id,
        })

    edges = []
    for i in range(n_nodes):
        n_edges = min(avg_edges, n_nodes - 1)
        targets = rng.sample(range(n_nodes), min(n_edges, n_nodes))
        for t in targets:
            if t == i:
                continue
            edge_type = rng.choice(["semantic", "causal", "semantic"])  # 2:1 ratio
            weight = rng.uniform(0.3, 1.0)
            edges.append({
                "source": nodes[i]["node_id"],
                "target": nodes[t]["node_id"],
                "edge_type": edge_type,
                "weight": weight,
                "directed": edge_type == "causal",
            })

    return {"nodes": nodes, "edges": edges}
