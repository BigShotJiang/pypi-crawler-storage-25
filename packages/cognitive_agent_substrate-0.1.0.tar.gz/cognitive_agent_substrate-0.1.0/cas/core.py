"""
CAS Core: Graph engine, node/edge types, SQLite storage.
Implements the Heterogeneous Knowledge Graph (HKG) from the CAS paper.
"""

import sqlite3
import json
import time
import numpy as np
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from pathlib import Path


class NodeType(Enum):
    L1_SEMANTIC = "L1"
    L2_FACT = "L2"
    L3_TRACE = "L3"
    MACRO = "MACRO"


class EdgeType(Enum):
    SEMANTIC = "semantic"
    CAUSAL = "causal"
    MACRO = "macro"


EDGE_DISCOUNTS = {
    EdgeType.SEMANTIC: 0.7,
    EdgeType.CAUSAL: 1.0,
    EdgeType.MACRO: 0.9,
}


@dataclass
class Node:
    node_id: str
    node_type: NodeType
    content: str
    embedding: Optional[np.ndarray] = None
    cluster_id: int = -1
    metadata: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class Edge:
    source_id: str
    target_id: str
    edge_type: EdgeType
    weight: float = 1.0
    hit_count: int = 1
    directed: bool = False

    @property
    def edge_id(self) -> str:
        return f"{self.source_id}|{self.target_id}|{self.edge_type.value}"


class HKGStore:
    """SQLite-backed Heterogeneous Knowledge Graph storage with in-memory caching."""

    def __init__(self, db_path: str = ":memory:"):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=OFF")  # faster for in-memory
        self._create_tables()
        self._auto_commit = True
        # In-memory cache for hot-path lookups
        self._node_cache: dict[str, Node] = {}
        self._adj_out: dict[str, list[Edge]] = {}  # outgoing edges
        self._adj_in_undirected: dict[str, list[Edge]] = {}  # incoming undirected

    def _create_tables(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS nodes (
                node_id TEXT PRIMARY KEY,
                node_type TEXT NOT NULL,
                content TEXT NOT NULL,
                embedding BLOB,
                cluster_id INTEGER DEFAULT -1,
                metadata TEXT DEFAULT '{}',
                timestamp REAL
            );
            CREATE TABLE IF NOT EXISTS edges (
                source_id TEXT NOT NULL,
                target_id TEXT NOT NULL,
                edge_type TEXT NOT NULL,
                weight REAL DEFAULT 1.0,
                hit_count INTEGER DEFAULT 1,
                directed INTEGER DEFAULT 0,
                PRIMARY KEY (source_id, target_id, edge_type),
                FOREIGN KEY (source_id) REFERENCES nodes(node_id),
                FOREIGN KEY (target_id) REFERENCES nodes(node_id)
            );
            CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id);
            CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id);
            CREATE INDEX IF NOT EXISTS idx_nodes_cluster ON nodes(cluster_id);
            CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type);
        """)
        self.conn.commit()

    @contextmanager
    def batch_mode(self):
        """Context manager for batch inserts — defers commits."""
        self._auto_commit = False
        try:
            yield
        finally:
            self.conn.commit()
            self._auto_commit = True

    def add_node(self, node: Node):
        emb_blob = node.embedding.tobytes() if node.embedding is not None else None
        self.conn.execute(
            "INSERT OR REPLACE INTO nodes VALUES (?,?,?,?,?,?,?)",
            (node.node_id, node.node_type.value, node.content,
             emb_blob, node.cluster_id, json.dumps(node.metadata), node.timestamp)
        )
        self._node_cache[node.node_id] = node
        if self._auto_commit:
            self.conn.commit()

    def get_node(self, node_id: str) -> Optional[Node]:
        if node_id in self._node_cache:
            return self._node_cache[node_id]
        row = self.conn.execute("SELECT * FROM nodes WHERE node_id=?", (node_id,)).fetchone()
        if not row:
            return None
        emb = np.frombuffer(row[3], dtype=np.float32).copy() if row[3] else None
        node = Node(
            node_id=row[0], node_type=NodeType(row[1]), content=row[2],
            embedding=emb, cluster_id=row[4],
            metadata=json.loads(row[5]), timestamp=row[6]
        )
        self._node_cache[node_id] = node
        return node

    def get_nodes_by_cluster(self, cluster_id: int) -> list[Node]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE cluster_id=? AND node_type != 'MACRO'", (cluster_id,)
        ).fetchall()
        result = []
        for row in rows:
            nid = row[0]
            if nid in self._node_cache:
                result.append(self._node_cache[nid])
            else:
                emb = np.frombuffer(row[3], dtype=np.float32).copy() if row[3] else None
                node = Node(
                    node_id=nid, node_type=NodeType(row[1]), content=row[2],
                    embedding=emb, cluster_id=row[4],
                    metadata=json.loads(row[5]), timestamp=row[6]
                )
                self._node_cache[nid] = node
                result.append(node)
        return result

    def get_nodes_by_type(self, node_type: NodeType) -> list[Node]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE node_type=?", (node_type.value,)
        ).fetchall()
        result = []
        for row in rows:
            emb = np.frombuffer(row[3], dtype=np.float32).copy() if row[3] else None
            result.append(Node(
                node_id=row[0], node_type=NodeType(row[1]), content=row[2],
                embedding=emb, cluster_id=row[4],
                metadata=json.loads(row[5]), timestamp=row[6]
            ))
        return result

    def add_edge(self, edge: Edge):
        self.conn.execute(
            """INSERT INTO edges VALUES (?,?,?,?,?,?)
               ON CONFLICT(source_id, target_id, edge_type) DO UPDATE SET
               weight=excluded.weight, hit_count=hit_count+1""",
            (edge.source_id, edge.target_id, edge.edge_type.value,
             edge.weight, edge.hit_count, int(edge.directed))
        )
        # Invalidate adjacency cache for this source (will be reloaded on next read)
        self._adj_out.pop(edge.source_id, None)
        if not edge.directed:
            self._adj_in_undirected.pop(edge.target_id, None)
        if self._auto_commit:
            self.conn.commit()

    def get_edges_from(self, node_id: str, edge_type: Optional[EdgeType] = None) -> list[Edge]:
        if node_id in self._adj_out:
            edges = self._adj_out[node_id]
            if edge_type:
                return [e for e in edges if e.edge_type == edge_type]
            return edges
        if edge_type:
            rows = self.conn.execute(
                "SELECT * FROM edges WHERE source_id=? AND edge_type=?",
                (node_id, edge_type.value)
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM edges WHERE source_id=?", (node_id,)
            ).fetchall()
        edges = [Edge(r[0], r[1], EdgeType(r[2]), r[3], r[4], bool(r[5])) for r in rows]
        self._adj_out[node_id] = edges
        if edge_type:
            return [e for e in edges if e.edge_type == edge_type]
        return edges

    def get_edges_to(self, node_id: str, edge_type: Optional[EdgeType] = None) -> list[Edge]:
        if edge_type:
            rows = self.conn.execute(
                "SELECT * FROM edges WHERE target_id=? AND edge_type=?",
                (node_id, edge_type.value)
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM edges WHERE target_id=?", (node_id,)
            ).fetchall()
        return [Edge(r[0], r[1], EdgeType(r[2]), r[3], r[4], bool(r[5])) for r in rows]

    def get_neighbors(self, node_id: str) -> list[tuple[str, Edge]]:
        """Get all neighbors (both directions for undirected, forward for directed)."""
        neighbors = []
        # Outgoing
        for e in self.get_edges_from(node_id):
            neighbors.append((e.target_id, e))
        # Incoming undirected — use cache if available
        if node_id in self._adj_in_undirected:
            for e in self._adj_in_undirected[node_id]:
                neighbors.append((e.source_id, e))
        else:
            rows = self.conn.execute(
                "SELECT * FROM edges WHERE target_id=? AND directed=0", (node_id,)
            ).fetchall()
            for r in rows:
                edge = Edge(r[0], r[1], EdgeType(r[2]), r[3], r[4], bool(r[5]))
                neighbors.append((edge.source_id, edge))
        return neighbors

    def node_count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]

    def edge_count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]

    def get_all_node_ids(self) -> list[str]:
        rows = self.conn.execute("SELECT node_id FROM nodes").fetchall()
        return [r[0] for r in rows]

    def close(self):
        self._node_cache.clear()
        self._adj_out.clear()
        self._adj_in_undirected.clear()
        self.conn.close()
