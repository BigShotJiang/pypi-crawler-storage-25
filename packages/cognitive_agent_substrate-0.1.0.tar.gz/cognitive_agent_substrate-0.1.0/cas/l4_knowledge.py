"""
L4 - Knowledge Consolidation Layer.
Implements: graph construction, traversal, path convergence,
macro-node generalization, causal reasoning, topology chains.
"""

import time
import numpy as np
from collections import defaultdict
from dataclasses import dataclass

from .core import (
    HKGStore, Node, Edge, NodeType, EdgeType, EDGE_DISCOUNTS
)
from .embeddings import EmbeddingEngine


@dataclass
class PathResult:
    """A single path from query entry point to a conclusion node."""
    path: list[str]
    edges: list[Edge]
    confidence: float


@dataclass
class EpistemicResult:
    """Result of epistemic coverage check."""
    conclusion_id: str
    conclusion_content: str
    confidence: float       # path convergence (structural)
    query_relevance: float  # semantic similarity to query
    combined_score: float   # confidence weighted by relevance
    paths: list[PathResult]
    level: str  # "high", "medium", "low"


@dataclass
class TopologyChain:
    """Compressed representation for LLM consumption."""
    chain_text: str
    token_estimate: int
    source_node_count: int
    epistemic_results: list[EpistemicResult]


class L4KnowledgeConsolidation:
    """L4 Knowledge Consolidation via Heterogeneous Graph."""

    def __init__(
        self,
        store: HKGStore,
        engine: EmbeddingEngine,
        k_nn: int = 10,
        max_hops: int = 4,
        confidence_floor: float = 0.3,
        macro_threshold: float = 0.8,
        tau_high: float = 0.7,
        tau_low: float = 0.3,
        alpha: float = 0.4,
    ):
        self.store = store
        self.engine = engine
        self.k_nn = k_nn
        self.max_hops = max_hops
        self.confidence_floor = confidence_floor
        self.macro_threshold = macro_threshold
        self.tau_high = tau_high
        self.tau_low = tau_low
        self.alpha = alpha  # entity vs aspect weight blend

    # ---- Node/Edge Insertion ----

    def add_entry(self, content: str, node_type: NodeType, metadata: dict | None = None,
                  causal_sequence: list[str] | None = None) -> Node:
        """Add a single entry node to the graph."""
        embedding = self.engine.encode(content)[0]
        cluster_id = self.engine.assign_cluster(embedding)
        node_id = f"{node_type.value}_{hash(content) & 0xFFFFFFFF:08x}"
        node = Node(
            node_id=node_id, node_type=node_type, content=content,
            embedding=embedding, cluster_id=cluster_id,
            metadata=metadata or {}
        )
        self.store.add_node(node)

        macro_id = f"MACRO_{cluster_id}"
        self.store.add_edge(Edge(
            source_id=macro_id, target_id=node_id,
            edge_type=EdgeType.MACRO, weight=1.0, directed=True
        ))

        self._create_semantic_edges(node)

        if causal_sequence and node_type == NodeType.L3_TRACE:
            self._create_causal_edges(node_id, causal_sequence)

        self._update_macro_edges(cluster_id)
        return node

    def add_entries_batch(self, contents: list[str], node_type: NodeType,
                          metadatas: list[dict] | None = None) -> list[Node]:
        """Batch-add entries. Encodes all at once, then inserts incrementally.

        Key: semantic edges are built per-node right after insertion (same as
        sequential add_entry) to maintain identical graph topology. The batch
        speedup comes from encoding all texts in one model call."""
        if not contents:
            return []
        metadatas = metadatas or [{}] * len(contents)

        # Batch encode + cluster assign (the big speedup)
        embeddings = self.engine.encode_batch(contents)
        cluster_ids = self.engine.assign_clusters_batch(embeddings)

        nodes = []
        affected_clusters = set()
        with self.store.batch_mode():
            for i, content in enumerate(contents):
                emb = embeddings[i]
                cid = int(cluster_ids[i])
                node_id = f"{node_type.value}_{hash(content) & 0xFFFFFFFF:08x}"
                node = Node(
                    node_id=node_id, node_type=node_type, content=content,
                    embedding=emb, cluster_id=cid, metadata=metadatas[i]
                )
                self.store.add_node(node)
                self.store.add_edge(Edge(
                    source_id=f"MACRO_{cid}", target_id=node_id,
                    edge_type=EdgeType.MACRO, weight=1.0, directed=True
                ))
                # Build semantic edges immediately (incremental, same as sequential)
                self._create_semantic_edges(node)
                nodes.append(node)
                affected_clusters.add(cid)

        # Update macro-edges for affected clusters
        with self.store.batch_mode():
            for cid in affected_clusters:
                self._update_macro_edges(cid)

        return nodes

    def create_macro_nodes(self):
        """Create macro-nodes for all VQ centroids."""
        centroids = self.engine.get_centroids()
        for i, centroid in enumerate(centroids):
            macro_id = f"MACRO_{i}"
            node = Node(
                node_id=macro_id, node_type=NodeType.MACRO,
                content=f"Cluster {i} centroid",
                embedding=centroid, cluster_id=i
            )
            self.store.add_node(node)

    def _create_semantic_edges(self, node: Node):
        """Create semantic edges to K_nn nearest neighbors in same cluster."""
        cluster_nodes = self.store.get_nodes_by_cluster(node.cluster_id)
        if len(cluster_nodes) <= 1:
            return

        similarities = []
        for other in cluster_nodes:
            if other.node_id == node.node_id:
                continue
            if other.embedding is None or node.embedding is None:
                continue
            sim = EmbeddingEngine.cosine_similarity(node.embedding, other.embedding)
            similarities.append((other.node_id, sim))

        similarities.sort(key=lambda x: x[1], reverse=True)
        for neighbor_id, sim in similarities[:self.k_nn]:
            if sim > 0.3:  # minimum similarity threshold
                self.store.add_edge(Edge(
                    source_id=node.node_id, target_id=neighbor_id,
                    edge_type=EdgeType.SEMANTIC, weight=sim, directed=False
                ))

    def _create_causal_edges(self, trace_node_id: str, sequence: list[str]):
        """Create directed causal edges from execution sequence."""
        for i in range(len(sequence) - 1):
            self.store.add_edge(Edge(
                source_id=sequence[i], target_id=sequence[i + 1],
                edge_type=EdgeType.CAUSAL, weight=1.0, directed=True
            ))

    def _update_macro_edges(self, cluster_id: int):
        """Check if macro-edges should be created/updated for this cluster."""
        cluster_nodes = self.store.get_nodes_by_cluster(cluster_id)
        if len(cluster_nodes) < 3:
            return

        macro_id = f"MACRO_{cluster_id}"

        # Count semantic edge targets shared by cluster members
        target_counts: dict[str, int] = defaultdict(int)
        for node in cluster_nodes:
            edges = self.store.get_edges_from(node.node_id, EdgeType.SEMANTIC)
            for edge in edges:
                target_node = self.store.get_node(edge.target_id)
                if target_node and target_node.cluster_id != cluster_id:
                    target_counts[edge.target_id] += 1

        # Create macro-edges where threshold is met
        n_members = len(cluster_nodes)
        for target_id, count in target_counts.items():
            ratio = count / n_members
            if ratio >= self.macro_threshold:
                self.store.add_edge(Edge(
                    source_id=macro_id, target_id=target_id,
                    edge_type=EdgeType.MACRO, weight=ratio, directed=True
                ))

    # ---- Graph Traversal & Epistemic Check ----

    def epistemic_check(self, query: str) -> list[EpistemicResult]:
        """Perform epistemic coverage check via path convergence + aspect re-ranking.

        Three-stage scoring:
        1. Path convergence: structural confidence (how many independent paths)
        2. Entity relevance: cosine(query, conclusion) — finds the right entity
        3. Aspect alignment: cosine(aspect_vector, conclusion) — finds the right
           property of that entity

        The aspect vector isolates WHAT the query asks about beyond just the entity:
            aspect = query_emb - mean(entry_point_embs)
            "Is a parrot a carnivore?" - "parrot" ≈ direction of "carnivore/diet"

        combined_score = convergence * (α * entity_relevance + (1-α) * aspect_alignment)
        """
        query_emb = self.engine.encode(query)[0]
        entry_points = self._find_entry_points(query_emb)
        if not entry_points:
            return []

        # Compute aspect vector: query minus entity centroid
        ep_embeddings = []
        for ep_id in entry_points:
            ep_node = self.store.get_node(ep_id)
            if ep_node is not None and ep_node.embedding is not None:
                ep_embeddings.append(ep_node.embedding)

        if ep_embeddings:
            entity_centroid = np.mean(ep_embeddings, axis=0)
            # Aspect vector: the component of the query orthogonal to the entity
            # This captures WHAT is being asked, not WHICH entity
            entity_norm = entity_centroid / (np.linalg.norm(entity_centroid) + 1e-10)
            entity_proj = np.dot(query_emb, entity_norm) * entity_norm
            aspect_vec = query_emb - entity_proj
            aspect_norm = np.linalg.norm(aspect_vec)
            if aspect_norm > 1e-10:
                aspect_vec = aspect_vec / aspect_norm
            else:
                aspect_vec = query_emb  # fallback: degenerate case
        else:
            aspect_vec = query_emb

        # BFS with path tracking from each entry point
        all_paths: dict[str, list[PathResult]] = defaultdict(list)

        for start_id in entry_points:
            paths = self._bounded_traversal(start_id)
            for path_result in paths:
                conclusion = path_result.path[-1]
                all_paths[conclusion].append(path_result)

        # Also add entry points as direct conclusions
        for ep_id in entry_points:
            ep_node = self.store.get_node(ep_id)
            if ep_node and ep_node.embedding is not None:
                sim = EmbeddingEngine.cosine_similarity(query_emb, ep_node.embedding)
                direct_path = PathResult(path=[ep_id], edges=[], confidence=sim)
                all_paths[ep_id] = [direct_path] + all_paths.get(ep_id, [])

        alpha = self.alpha  # entity weight; (1-alpha) = aspect weight

        results = []
        for conclusion_id, paths in all_paths.items():
            node = self.store.get_node(conclusion_id)
            if not node:
                continue

            convergence = self._path_convergence(paths)

            if node.embedding is not None:
                entity_rel = EmbeddingEngine.cosine_similarity(query_emb, node.embedding)
                aspect_rel = abs(EmbeddingEngine.cosine_similarity(aspect_vec, node.embedding))
                # abs() because "herbivore" and "carnivore" are same aspect (diet),
                # just different directions. We want conclusions ON the diet axis,
                # regardless of which side.
            else:
                entity_rel = 0.0
                aspect_rel = 0.0

            # Blended relevance: entity match + aspect match
            relevance = alpha * entity_rel + (1 - alpha) * aspect_rel
            combined = convergence * relevance

            level = ("high" if combined > self.tau_high
                     else ("medium" if combined > self.tau_low else "low"))

            results.append(EpistemicResult(
                conclusion_id=conclusion_id,
                conclusion_content=node.content,
                confidence=convergence,
                query_relevance=relevance,
                combined_score=combined,
                paths=paths,
                level=level
            ))

        results.sort(key=lambda r: r.combined_score, reverse=True)
        return results

    def _find_entry_points(self, query_emb: np.ndarray, top_k: int = 5) -> list[str]:
        """Find nearest entry nodes to query embedding across all clusters."""
        # Search primary cluster + neighboring clusters for better recall
        primary_cluster = self.engine.assign_cluster(query_emb)

        # Get centroids and find top-3 closest clusters
        if self.engine._is_fitted:
            centroids = self.engine.get_centroids()
            cluster_sims = []
            for i, c in enumerate(centroids):
                sim = EmbeddingEngine.cosine_similarity(query_emb, c)
                cluster_sims.append((i, sim))
            cluster_sims.sort(key=lambda x: x[1], reverse=True)
            search_clusters = [cid for cid, _ in cluster_sims[:3]]
        else:
            search_clusters = [primary_cluster]

        scored = []
        for cid in search_clusters:
            cluster_nodes = self.store.get_nodes_by_cluster(cid)
            for node in cluster_nodes:
                if node.embedding is not None:
                    sim = EmbeddingEngine.cosine_similarity(query_emb, node.embedding)
                    scored.append((node.node_id, sim))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [nid for nid, _ in scored[:top_k]]

    def _bounded_traversal(self, start_id: str) -> list[PathResult]:
        """BFS traversal with hop limit, confidence floor, visited set."""
        results = []
        # (current_node, path_so_far, edges_so_far, cumulative_confidence)
        queue = [(start_id, [start_id], [], 1.0)]
        visited_per_path: set[str] = set()

        while queue:
            current, path, edges, conf = queue.pop(0)

            if len(path) > self.max_hops + 1:
                continue

            if len(path) > 1:
                results.append(PathResult(path=list(path), edges=list(edges), confidence=conf))

            neighbors = self.store.get_neighbors(current)
            for neighbor_id, edge in neighbors:
                if neighbor_id in path:  # visited set per path
                    continue
                discount = EDGE_DISCOUNTS.get(edge.edge_type, 0.7)
                new_conf = conf * edge.weight * discount
                if new_conf < self.confidence_floor:
                    continue
                queue.append((
                    neighbor_id,
                    path + [neighbor_id],
                    edges + [edge],
                    new_conf
                ))

        return results

    def _path_convergence(self, paths: list[PathResult]) -> float:
        """Compute convergence confidence: 1 - product(1 - p_i)."""
        if not paths:
            return 0.0
        product = 1.0
        for p in paths:
            product *= (1.0 - p.confidence)
        return 1.0 - product

    # ---- Topology Chain Compression ----

    def build_topology_chain(self, query: str, max_conclusions: int = 3) -> TopologyChain:
        """Build COMPACT topology chain (for token counting / E3).
        Strips to labels only."""
        return self._build_chain(query, max_conclusions, compact=True)

    def build_topology_chain_full(self, query: str, max_conclusions: int = 10,
                                   min_score: float = 0.05) -> TopologyChain:
        """Build FULL topology chain that preserves fact content (for LLM consumption / E7).

        Key difference from compact: includes full fact text for each relevant conclusion,
        organized by confidence tier. This prevents information loss while still providing
        structured context (relationships + confidence) that raw RAG lacks.
        """
        return self._build_chain(query, max_conclusions, compact=False, min_score=min_score)

    def _build_chain(self, query: str, max_conclusions: int, compact: bool = True,
                     min_score: float = 0.0) -> TopologyChain:
        results = self.epistemic_check(query)
        if not results:
            return TopologyChain(chain_text="[No graph coverage]", token_estimate=5,
                                 source_node_count=0, epistemic_results=[])

        lines = []
        node_set = set()
        seen_content = set()
        included = 0

        for er in results:
            if included >= max_conclusions:
                break
            if er.combined_score < min_score:
                break

            content_key = er.conclusion_content[:20]
            if content_key in seen_content:
                continue
            seen_content.add(content_key)
            node_set.add(er.conclusion_id)
            included += 1

            if compact:
                # Compact: label + metadata only
                best_path = max(er.paths, key=lambda p: p.confidence) if er.paths else None
                hops = len(best_path.path) - 1 if best_path else 0
                edge_types = set()
                if best_path:
                    for e in best_path.edges:
                        edge_types.add(e.edge_type.value[0])
                        node_set.add(e.source_id)
                types_str = "+".join(sorted(edge_types)) if edge_types else "d"
                label = er.conclusion_content[:40].strip()
                lines.append(f"[{label}](c={er.combined_score:.2f},{types_str},{hops}h,{len(er.paths)}p)")
            else:
                # Full: fact text + confidence + relationship type (NO path expansion)
                # Keeps output smaller than RAG while adding structure
                conf_label = "HIGH" if er.level == "high" else ("MED" if er.level == "medium" else "LOW")
                # Identify dominant edge type in best path
                best_path = max(er.paths, key=lambda p: p.confidence) if er.paths else None
                edge_type_str = ""
                if best_path and best_path.edges:
                    edge_counts = defaultdict(int)
                    for e in best_path.edges:
                        edge_counts[e.edge_type.value] += 1
                    edge_type_str = f" [{max(edge_counts, key=edge_counts.get)}]"
                lines.append(f"- {er.conclusion_content} ({conf_label}{edge_type_str})")

        if compact:
            chain_text = " | ".join(lines)
        else:
            chain_text = "\n".join(lines)

        token_estimate = len(chain_text.split())
        return TopologyChain(
            chain_text=chain_text,
            token_estimate=token_estimate,
            source_node_count=len(node_set),
            epistemic_results=results
        )

    def build_chain_for_profile(self, query: str, traversal_profile) -> TopologyChain:
        """Build topology chain controlled by L5 TraversalProfile.

        This is the key L5 integration: different expertise levels get
        structurally different context from the SAME graph.

        Expert:       shallow (2 hop), causal-only, 5 conclusions, no intermediates
        Intermediate: medium (3 hop), causal+semantic, 8 conclusions, with context
        Beginner:     deep (4 hop), all edges, 15 conclusions, full paths
        """
        tp = traversal_profile

        # Override traversal parameters temporarily
        orig_hops = self.max_hops
        self.max_hops = tp.max_hops

        # Run epistemic check with profile-specific depth
        results = self.epistemic_check(query)

        self.max_hops = orig_hops  # restore

        if not results:
            return TopologyChain(chain_text="[No graph coverage]", token_estimate=5,
                                 source_node_count=0, epistemic_results=[])

        # Filter by allowed edge types
        allowed_types = set(tp.edge_types)

        lines = []
        node_set = set()
        seen_content = set()
        included = 0

        for er in results:
            if included >= tp.max_conclusions:
                break
            if er.combined_score < tp.min_score:
                break

            content_key = er.conclusion_content[:20]
            if content_key in seen_content:
                continue
            seen_content.add(content_key)
            node_set.add(er.conclusion_id)
            included += 1

            # Check best path uses allowed edge types
            best_path = max(er.paths, key=lambda p: p.confidence) if er.paths else None
            edge_type_str = ""
            if best_path and best_path.edges:
                path_types = [e.edge_type.value for e in best_path.edges]
                # Only show if path uses allowed types
                relevant_types = [t for t in path_types if t in allowed_types]
                if relevant_types:
                    edge_type_str = f" [{relevant_types[0]}]"

            lines.append(f"- {er.conclusion_content}{edge_type_str}")

            # Include path context for intermediate/beginner
            if tp.include_path_context and best_path:
                for nid in best_path.path:
                    if nid == er.conclusion_id:
                        continue
                    pnode = self.store.get_node(nid)
                    if pnode and pnode.content[:20] not in seen_content:
                        # Check edge type filter
                        connecting_edge_type = None
                        for e in best_path.edges:
                            if e.source_id == nid or e.target_id == nid:
                                connecting_edge_type = e.edge_type.value
                                break
                        if connecting_edge_type and connecting_edge_type in allowed_types:
                            seen_content.add(pnode.content[:20])
                            node_set.add(nid)
                            lines.append(f"    -> {pnode.content}")

        chain_text = "\n".join(lines)
        return TopologyChain(
            chain_text=chain_text,
            token_estimate=len(chain_text.split()),
            source_node_count=len(node_set),
            epistemic_results=results
        )

    # ---- Causal Reasoning ----

    def causal_predict(self, event_node_id: str, max_depth: int = 4) -> list[tuple[str, float]]:
        """Predict next events via multi-hop causal chain traversal + transitive inference."""
        # Multi-hop: follow causal edges forward up to max_depth
        predictions = []
        visited = set()
        queue = [(event_node_id, 1.0, 0)]  # (node_id, confidence, depth)

        while queue:
            current, conf, depth = queue.pop(0)
            if current in visited or depth > max_depth:
                continue
            visited.add(current)

            causal_edges = self.store.get_edges_from(current, EdgeType.CAUSAL)
            for edge in causal_edges:
                new_conf = conf * edge.weight * EDGE_DISCOUNTS[EdgeType.CAUSAL]
                if new_conf >= self.confidence_floor:
                    predictions.append((edge.target_id, new_conf))
                    queue.append((edge.target_id, new_conf, depth + 1))

        # Also: transitive inference via semantic similarity (1 hop semantic + causal)
        semantic_edges = self.store.get_edges_from(event_node_id, EdgeType.SEMANTIC)
        for sem_edge in semantic_edges:
            causal_from_similar = self.store.get_edges_from(sem_edge.target_id, EdgeType.CAUSAL)
            for causal_edge in causal_from_similar:
                conf = sem_edge.weight * EDGE_DISCOUNTS[EdgeType.SEMANTIC] * causal_edge.weight
                if conf >= self.confidence_floor:
                    predictions.append((causal_edge.target_id, conf))

        # Deduplicate, keep max confidence
        pred_dict: dict[str, float] = {}
        for target, conf in predictions:
            if target != event_node_id:
                pred_dict[target] = max(pred_dict.get(target, 0), conf)

        return sorted(pred_dict.items(), key=lambda x: x[1], reverse=True)

    def impact_analysis(self, changed_node_id: str) -> list[tuple[str, float]]:
        """Blast radius: find all nodes causally downstream of changed node."""
        impacted = []
        visited = set()
        queue = [(changed_node_id, 1.0)]

        while queue:
            current, conf = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            if current != changed_node_id:
                impacted.append((current, conf))

            # Follow causal edges forward
            causal_edges = self.store.get_edges_from(current, EdgeType.CAUSAL)
            for edge in causal_edges:
                new_conf = conf * edge.weight * EDGE_DISCOUNTS[EdgeType.CAUSAL]
                if new_conf >= self.confidence_floor and edge.target_id not in visited:
                    queue.append((edge.target_id, new_conf))

            # Also follow semantic edges (with discount)
            semantic_edges = self.store.get_edges_from(current, EdgeType.SEMANTIC)
            for edge in semantic_edges:
                new_conf = conf * edge.weight * EDGE_DISCOUNTS[EdgeType.SEMANTIC]
                if new_conf >= self.confidence_floor and edge.target_id not in visited:
                    queue.append((edge.target_id, new_conf))

        return impacted
