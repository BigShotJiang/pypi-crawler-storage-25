"""
Embedding engine: MiniLM (local) or OpenAI text-embedding (API).
Wraps both backends with identical interface for CAS.
"""

import numpy as np
from sklearn.cluster import MiniBatchKMeans


# Module-level caches
_ST_MODEL_CACHE: dict = {}
_OPENAI_CLIENT = None


def _get_st_model(model_name: str):
    from sentence_transformers import SentenceTransformer
    if model_name not in _ST_MODEL_CACHE:
        _ST_MODEL_CACHE[model_name] = SentenceTransformer(model_name)
    return _ST_MODEL_CACHE[model_name]


def _get_openai_client():
    global _OPENAI_CLIENT
    if _OPENAI_CLIENT is None:
        from openai import OpenAI
        # Read key from .env or environment
        import os
        key = os.environ.get("OPENAI_API_KEY", "")
        if not key:
            try:
                env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
                with open(env_path) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#") and "=" not in line:
                            key = line  # bare key
                        elif line.startswith("OPENAI_API_KEY="):
                            key = line.split("=", 1)[1].strip()
                        elif line.startswith("sk-"):
                            key = line
            except FileNotFoundError:
                pass
        if not key:
            raise RuntimeError("No OpenAI API key found in .env or OPENAI_API_KEY env var")
        _OPENAI_CLIENT = OpenAI(api_key=key)
    return _OPENAI_CLIENT


class EmbeddingEngine:
    """Unified embedding engine supporting local (MiniLM) and API (OpenAI) backends."""

    BACKENDS = {"minilm", "openai"}

    def __init__(self, model_name: str = "all-MiniLM-L6-v2", n_clusters: int = 256,
                 backend: str = "minilm", openai_model: str = "text-embedding-3-small"):
        self.backend = backend
        self.n_clusters = n_clusters
        self.kmeans: MiniBatchKMeans | None = None
        self._is_fitted = False
        self._encode_cache: dict[str, np.ndarray] = {}

        if backend == "minilm":
            self.model = _get_st_model(model_name)
            self.dim = 384
            self._openai_model = None
        elif backend == "openai":
            self._openai_model = openai_model
            self.model = None
            # text-embedding-3-small=1536, text-embedding-3-large=3072
            self.dim = 1536 if "small" in openai_model else 3072
        else:
            raise ValueError(f"Unknown backend: {backend}. Use 'minilm' or 'openai'.")

    def _encode_raw(self, texts: list[str]) -> np.ndarray:
        """Raw encoding without cache. Returns L2-normalized (N, dim) float32."""
        if self.backend == "minilm":
            return self.model.encode(texts, normalize_embeddings=True).astype(np.float32)
        else:
            # OpenAI API — batch up to 2048 texts per call
            client = _get_openai_client()
            all_embs = []
            for i in range(0, len(texts), 2048):
                batch = texts[i:i+2048]
                resp = client.embeddings.create(input=batch, model=self._openai_model)
                for item in resp.data:
                    emb = np.array(item.embedding, dtype=np.float32)
                    emb = emb / (np.linalg.norm(emb) + 1e-10)  # L2 normalize
                    all_embs.append(emb)
            return np.array(all_embs, dtype=np.float32)

    def encode(self, texts: list[str] | str) -> np.ndarray:
        if isinstance(texts, str):
            texts = [texts]
        if len(texts) == 1 and texts[0] in self._encode_cache:
            return self._encode_cache[texts[0]].reshape(1, -1)
        result = self._encode_raw(texts)
        if len(texts) <= 10:
            for i, t in enumerate(texts):
                self._encode_cache[t] = result[i]
        return result

    def encode_batch(self, texts: list[str], batch_size: int = 128) -> np.ndarray:
        """Batch encode with caching."""
        results = np.empty((len(texts), self.dim), dtype=np.float32)
        uncached_indices = []
        uncached_texts = []
        for i, t in enumerate(texts):
            if t in self._encode_cache:
                results[i] = self._encode_cache[t]
            else:
                uncached_indices.append(i)
                uncached_texts.append(t)
        if uncached_texts:
            encoded = self._encode_raw(uncached_texts)
            for j, idx in enumerate(uncached_indices):
                results[idx] = encoded[j]
                self._encode_cache[uncached_texts[j]] = encoded[j]
        return results

    def fit_clusters(self, embeddings: np.ndarray):
        n = min(self.n_clusters, len(embeddings))
        self.kmeans = MiniBatchKMeans(n_clusters=n, random_state=42, batch_size=256, n_init=3)
        self.kmeans.fit(embeddings)
        self._is_fitted = True

    def assign_cluster(self, embedding: np.ndarray) -> int:
        if not self._is_fitted:
            raise RuntimeError("Clusters not fitted yet.")
        return int(self.kmeans.predict(embedding.reshape(1, -1))[0])

    def assign_clusters_batch(self, embeddings: np.ndarray) -> np.ndarray:
        if not self._is_fitted:
            raise RuntimeError("Clusters not fitted yet.")
        return self.kmeans.predict(embeddings).astype(int)

    def get_centroids(self) -> np.ndarray:
        if not self._is_fitted:
            raise RuntimeError("Clusters not fitted yet.")
        return self.kmeans.cluster_centers_.astype(np.float32)

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        return float(np.dot(a, b))

    @staticmethod
    def cosine_similarity_batch(query: np.ndarray, matrix: np.ndarray) -> np.ndarray:
        return matrix @ query

    def clear_cache(self):
        self._encode_cache.clear()
