"""
L5 - Personalization Layer (v2: graph-aware).

L5 controls graph traversal depth, not just prompt templates.
The LLM receives structurally different context per expertise level:
  Expert:       shallow, causal-only, conclusions only
  Intermediate: medium depth, causal+semantic, with 1-hop context
  Beginner:     full depth, all edge types, all reachable paths
"""

import numpy as np
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class ExpertiseLevel(Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    EXPERT = "expert"


@dataclass
class TraversalProfile:
    """Graph traversal parameters per expertise level."""
    max_hops: int
    edge_types: list[str]           # which edge types to follow
    max_conclusions: int            # how many conclusions to include
    include_path_context: bool      # include intermediate nodes
    min_score: float                # minimum combined_score threshold
    system_prefix: str              # prompt prefix (minimal)


TRAVERSAL_PROFILES = {
    ExpertiseLevel.EXPERT: TraversalProfile(
        max_hops=2,
        edge_types=["causal"],           # only proven relationships
        max_conclusions=5,                # just conclusions
        include_path_context=False,       # no intermediates
        min_score=0.05,
        system_prefix="Answer technically and concisely.",
    ),
    ExpertiseLevel.INTERMEDIATE: TraversalProfile(
        max_hops=3,
        edge_types=["causal", "semantic"],  # causal + semantic
        max_conclusions=6,                  # fewer than beginner's 15
        include_path_context=False,         # conclusions only, no path expansion
        min_score=0.03,                     # higher floor = fewer low-conf nodes
        system_prefix="Answer clearly. Include brief context where helpful.",
    ),
    ExpertiseLevel.BEGINNER: TraversalProfile(
        max_hops=4,
        edge_types=["causal", "semantic", "macro"],  # everything
        max_conclusions=15,
        include_path_context=True,                     # full paths
        min_score=0.005,
        system_prefix="Answer step by step. Define all technical terms simply.",
    ),
}


@dataclass
class UserProfile:
    user_id: str
    expertise_per_cluster: dict[int, float] = field(default_factory=dict)
    interaction_count: int = 0
    ema_alpha: float = 0.1

    def get_expertise_level(self, cluster_id: int = -1) -> ExpertiseLevel:
        if cluster_id >= 0:
            score = self.expertise_per_cluster.get(cluster_id, 0.5)
        else:
            scores = list(self.expertise_per_cluster.values())
            score = np.mean(scores) if scores else 0.5
        if score >= 0.7:
            return ExpertiseLevel.EXPERT
        elif score >= 0.4:
            return ExpertiseLevel.INTERMEDIATE
        else:
            return ExpertiseLevel.BEGINNER

    def update_expertise(self, cluster_id: int, signal: float):
        current = self.expertise_per_cluster.get(cluster_id, 0.5)
        self.expertise_per_cluster[cluster_id] = (
            self.ema_alpha * signal + (1 - self.ema_alpha) * current
        )
        self.interaction_count += 1


class L5Personalization:
    """L5 Personalization: controls graph traversal + prompt construction."""

    def __init__(self):
        self.profiles: dict[str, UserProfile] = {}

    def get_or_create_profile(self, user_id: str) -> UserProfile:
        if user_id not in self.profiles:
            self.profiles[user_id] = UserProfile(user_id=user_id)
        return self.profiles[user_id]

    def get_traversal_profile(self, expertise: ExpertiseLevel) -> TraversalProfile:
        return TRAVERSAL_PROFILES[expertise]

    def get_traversal_for_user(self, user_id: str, cluster_id: int = -1) -> TraversalProfile:
        profile = self.get_or_create_profile(user_id)
        expertise = profile.get_expertise_level(cluster_id)
        return TRAVERSAL_PROFILES[expertise]

    def build_prompt(self, system_prefix: str, context: str, query: str) -> str:
        return f"{system_prefix}\n\nContext:\n{context}\n\nQuestion: {query}"

    @staticmethod
    def estimate_token_overhead(expertise: ExpertiseLevel) -> int:
        return len(TRAVERSAL_PROFILES[expertise].system_prefix.split())
