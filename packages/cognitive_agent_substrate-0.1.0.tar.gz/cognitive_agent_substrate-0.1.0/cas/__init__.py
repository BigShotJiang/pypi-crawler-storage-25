# CAS - Cognitive Agent Substrate
__version__ = "0.1.0"

from .core import (
    HKGStore,
    Node,
    Edge,
    NodeType,
    EdgeType,
    EDGE_DISCOUNTS,
)
from .embeddings import EmbeddingEngine
from .l4_knowledge import (
    L4KnowledgeConsolidation,
    PathResult,
    EpistemicResult,
    TopologyChain,
)
from .l5_personalization import (
    L5Personalization,
    ExpertiseLevel,
    TraversalProfile,
)

__all__ = [
    # Core graph
    "HKGStore", "Node", "Edge", "NodeType", "EdgeType", "EDGE_DISCOUNTS",
    # Embeddings
    "EmbeddingEngine",
    # L4
    "L4KnowledgeConsolidation", "PathResult", "EpistemicResult", "TopologyChain",
    # L5
    "L5Personalization", "ExpertiseLevel", "TraversalProfile",
]
