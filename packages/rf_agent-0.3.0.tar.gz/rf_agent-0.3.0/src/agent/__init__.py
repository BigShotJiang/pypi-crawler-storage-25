"""RF spectrum streaming agent."""
