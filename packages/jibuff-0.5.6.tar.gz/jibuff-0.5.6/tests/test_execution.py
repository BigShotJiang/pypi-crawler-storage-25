"""Phase 2 — Execution Layer tests."""

from __future__ import annotations

import json
import textwrap
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from orchestrator.agent_runner import AgentRunner, resolve_agent_cmd
from orchestrator.loop_controller import LoopController, ValidatorProtocol
from orchestrator.task_queue import Task, TaskClaimError, TaskQueue
from reporters.failure_report import write_failure_report
from reporters.progress import write_progress

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_TASKS_MD = textwrap.dedent(
    """\
    # Tasks

    ## Phase 0

    - [ ] P0-01: Initialize pyproject.toml
    - [ ] P0-02: Create directory skeleton
    - [x] P0-03: Write smoke test
    - [~] P0-04: Set up CI
    - [!] P0-05: Configure secrets
"""
)


@pytest.fixture
def tmp_tasks(tmp_path: Path) -> tuple[Path, Path]:
    tasks_file = tmp_path / "tasks.md"
    status_file = tmp_path / "task_status.json"
    tasks_file.write_text(SAMPLE_TASKS_MD, encoding="utf-8")
    return tasks_file, status_file


# ---------------------------------------------------------------------------
# TaskQueue
# ---------------------------------------------------------------------------


def test_task_queue_parses_all_tasks(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    assert len(q._tasks) == 5


def test_task_queue_status_markers(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    statuses = {t.id: t.status for t in q._tasks}
    assert statuses["P0-01"] == "todo"
    assert statuses["P0-03"] == "done"
    assert statuses["P0-04"] == "in_progress"
    assert statuses["P0-05"] == "blocked"


def test_task_queue_next_returns_first_todo(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    task = q.next()
    assert task is not None
    assert task.id == "P0-01"


def test_task_queue_next_returns_none_when_all_done(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    for task in q._tasks:
        task.status = "done"
    assert q.next() is None


def test_task_queue_mark_done_persists(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    q.mark_done("P0-01")

    # Reload from status file
    q2 = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    statuses = {t.id: t.status for t in q2._tasks}
    assert statuses["P0-01"] == "done"


def test_task_queue_claim_metadata_persists(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    token = q.mark_in_progress("P0-01", claimed_by="worker-1")

    q2 = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    task = next(t for t in q2._tasks if t.id == "P0-01")
    assert task.status == "in_progress"
    assert task.revision == 1
    assert task.claimed_by == "worker-1"
    assert task.claimed_at is not None
    assert task.claim_token == token


def test_task_queue_requeue_clears_claim(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    q.mark_in_progress("P0-01", claimed_by="worker-1")
    q.requeue("P0-01")

    q2 = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    task = next(t for t in q2._tasks if t.id == "P0-01")
    assert task.status == "todo"
    assert task.revision == 2
    assert task.claimed_by is None
    assert task.claim_token is None


def test_task_queue_rejects_stale_claim_token(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    q.mark_in_progress("P0-01", claimed_by="worker-1")

    with pytest.raises(TaskClaimError, match="stale claim"):
        q.mark_done("P0-01", claim_token="wrong-token")


def test_task_queue_requeue_resets_to_todo(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    q.mark_in_progress("P0-01")
    q.requeue("P0-01")
    statuses = {t.id: t.status for t in q._tasks}
    assert statuses["P0-01"] == "todo"


def test_task_queue_all_done_false(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    assert q.all_done() is False


def test_task_queue_summary(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    s = q.summary()
    assert s["todo"] == 2
    assert s["done"] == 1
    assert s["in_progress"] == 1
    assert s["blocked"] == 1


def test_task_queue_status_json_overrides_marker(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    status_file.write_text(
        json.dumps(
            {
                "version": "0.1.0",
                "tasks": [{"id": "P0-01", "status": "done", "description": "..."}],
            }
        ),
        encoding="utf-8",
    )
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    statuses = {t.id: t.status for t in q._tasks}
    assert statuses["P0-01"] == "done"


# ---------------------------------------------------------------------------
# AgentRunner
# ---------------------------------------------------------------------------


def test_agent_runner_success(tmp_path: Path) -> None:
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])
    task = Task(id="P0-01", description="test task", status="todo")
    result = runner.run(task)
    assert result.success is True
    assert result.returncode == 0
    assert result.task_id == "P0-01"


def test_agent_runner_failure(tmp_path: Path) -> None:
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["false"])
    task = Task(id="P0-01", description="test task", status="todo")
    result = runner.run(task)
    assert result.success is False
    assert result.returncode != 0


def test_agent_runner_not_found(tmp_path: Path) -> None:
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["__no_such_cmd__"])
    task = Task(id="P0-01", description="test task", status="todo")
    result = runner.run(task)
    assert result.success is False
    assert result.returncode == -1
    assert "not found" in result.stderr


def test_agent_runner_prompt_includes_failure_context(tmp_path: Path) -> None:
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])
    task = Task(id="P0-01", description="test task", status="todo")
    prompt = runner._build_prompt(task, failure_context="[lint] E501 line too long")
    assert "Previous attempt failed" in prompt
    assert "E501 line too long" in prompt


def test_agent_runner_prompt_no_failure_context(tmp_path: Path) -> None:
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])
    task = Task(id="P0-01", description="test task", status="todo")
    prompt = runner._build_prompt(task, failure_context=None)
    assert "Previous attempt" not in prompt


# ---------------------------------------------------------------------------
# Reporters
# ---------------------------------------------------------------------------


def test_failure_report_creates_md(tmp_path: Path) -> None:
    task = Task(id="P0-01", description="init project", status="todo")
    errors = {"lint": "E501 line too long in main.py", "tests": "2 failed"}
    ctx = write_failure_report(task, errors, tmp_path)
    md = (tmp_path / "last_failure.md").read_text()
    assert "P0-01" in md
    assert "E501" in md
    assert ctx != ""


def test_failure_report_appends_open_issues(tmp_path: Path) -> None:
    task = Task(id="P0-01", description="init project", status="todo")
    write_failure_report(task, {"lint": "error 1"}, tmp_path)
    write_failure_report(task, {"tests": "error 2"}, tmp_path)
    issues = json.loads((tmp_path / "open_issues.json").read_text())
    assert len(issues) == 2


def test_progress_report_creates_md(tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    storage = status_file.parent / "storage"
    write_progress(q, storage)
    md = (storage / "progress.md").read_text()
    assert "Progress" in md
    assert "todo" in md


# ---------------------------------------------------------------------------
# LoopController
# ---------------------------------------------------------------------------


def _make_passing_validator(name: str = "mock") -> ValidatorProtocol:
    v = ValidatorProtocol()
    v.name = name
    v.run = MagicMock(return_value=(True, ""))  # type: ignore[method-assign]
    return v


def _make_failing_validator(name: str, error: str) -> ValidatorProtocol:
    v = ValidatorProtocol()
    v.name = name
    v.run = MagicMock(return_value=(False, error))  # type: ignore[method-assign]
    return v


def test_loop_controller_all_done_on_success(tmp_path: Path, tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])

    ctrl = LoopController(
        queue=q,
        runner=runner,
        validators=[_make_passing_validator()],
        storage_dir=tmp_path / "storage",
        workspace=tmp_path,
        auto_commit=False,
    )
    result = ctrl.run()
    # todo tasks (P0-01, P0-02) should be completed; in_progress/blocked are not processed
    assert result.stopped_reason == "no_runnable_tasks"
    assert len(result.completed_tasks) == 2
    assert q.next() is None  # no more todo tasks


def test_loop_controller_fails_and_requeues(tmp_path: Path, tmp_tasks: tuple[Path, Path]) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])

    call_count = 0

    def _toggle(workspace: Path) -> tuple[bool, str]:
        nonlocal call_count
        call_count += 1
        # Fail first 2 calls per task, then pass
        return (call_count % 3 == 0, "mock error")

    v = _make_passing_validator()
    v.run = _toggle  # type: ignore[method-assign]

    ctrl = LoopController(
        queue=q,
        runner=runner,
        validators=[v],
        storage_dir=tmp_path / "storage",
        workspace=tmp_path,
        max_iterations=30,
        auto_commit=False,
    )
    result = ctrl.run()
    assert result.total_iterations > 0


def test_loop_controller_stops_on_max_iterations(
    tmp_path: Path, tmp_tasks: tuple[Path, Path]
) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])

    ctrl = LoopController(
        queue=q,
        runner=runner,
        validators=[_make_failing_validator("lint", "always fails")],
        storage_dir=tmp_path / "storage",
        workspace=tmp_path,
        max_iterations=3,
        auto_commit=False,
    )
    result = ctrl.run()
    assert result.total_iterations == 3
    assert result.stopped_reason == "max_iterations"


def test_loop_controller_stops_on_agent_unavailable(
    tmp_path: Path, tmp_tasks: tuple[Path, Path]
) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["__no_such_cmd__"])

    ctrl = LoopController(
        queue=q,
        runner=runner,
        validators=[_make_passing_validator()],
        storage_dir=tmp_path / "storage",
        workspace=tmp_path,
        auto_commit=False,
    )
    result = ctrl.run()
    assert result.stopped_reason == "agent_unavailable"


# ---------------------------------------------------------------------------
# resolve_agent_cmd — agent CLI selection
# ---------------------------------------------------------------------------


def test_resolve_agent_cmd_uses_explicit_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("JIBUFF_AGENT_CMD", "should-be-ignored")
    assert resolve_agent_cmd(["my-agent", "--flag"]) == ["my-agent", "--flag"]


def test_resolve_agent_cmd_adds_codex_non_interactive_flag_to_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("JIBUFF_AGENT_CMD", "should-be-ignored")
    assert resolve_agent_cmd(["codex", "exec"]) == [
        "codex",
        "exec",
        "--dangerously-bypass-approvals-and-sandbox",
    ]


def test_resolve_agent_cmd_keeps_existing_codex_approval_flag(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("JIBUFF_AGENT_CMD", raising=False)
    assert resolve_agent_cmd(
        ["codex", "exec", "--dangerously-bypass-approvals-and-sandbox", "--json"]
    ) == ["codex", "exec", "--dangerously-bypass-approvals-and-sandbox", "--json"]


def test_resolve_agent_cmd_uses_env_var(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("JIBUFF_AGENT_CMD", "codex exec --some-flag")
    assert resolve_agent_cmd() == [
        "codex",
        "exec",
        "--dangerously-bypass-approvals-and-sandbox",
        "--some-flag",
    ]


def test_resolve_agent_cmd_autodetect_prefers_claude(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("JIBUFF_AGENT_CMD", raising=False)
    monkeypatch.setattr(
        "orchestrator.agent_runner.shutil.which",
        lambda name: f"/usr/local/bin/{name}",
    )
    cmd = resolve_agent_cmd()
    assert cmd[0] == "claude"
    assert "-p" in cmd


def test_resolve_agent_cmd_autodetect_falls_back_to_codex(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("JIBUFF_AGENT_CMD", raising=False)
    monkeypatch.setattr(
        "orchestrator.agent_runner.shutil.which",
        lambda name: f"/usr/local/bin/{name}" if name == "codex" else None,
    )
    cmd = resolve_agent_cmd()
    assert cmd[0] == "codex"
    assert cmd[1] == "exec"
    assert "--dangerously-bypass-approvals-and-sandbox" in cmd


def test_resolve_agent_cmd_raises_when_nothing_available(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("JIBUFF_AGENT_CMD", raising=False)
    monkeypatch.setattr("orchestrator.agent_runner.shutil.which", lambda _: None)
    with pytest.raises(RuntimeError, match="No agent CLI"):
        resolve_agent_cmd()


# ---------------------------------------------------------------------------
# LoopController — narration
# ---------------------------------------------------------------------------


def test_loop_controller_emits_per_step_narration_by_default(
    tmp_path: Path, tmp_tasks: tuple[Path, Path], capsys: pytest.CaptureFixture[str]
) -> None:
    tasks_file, status_file = tmp_tasks
    q = TaskQueue(tasks_file=tasks_file, status_file=status_file)
    runner = AgentRunner(workspace=tmp_path, agent_cmd=["echo"])

    ctrl = LoopController(
        queue=q,
        runner=runner,
        validators=[_make_passing_validator("lint"), _make_passing_validator("tests")],
        storage_dir=tmp_path / "storage",
        workspace=tmp_path,
        auto_commit=False,
    )
    ctrl.run()
    out = capsys.readouterr().err
    # Task header, agent invocation, validator section, completion line.
    assert "[task P0-01]" in out
    assert "iteration 1" in out
    assert "agent: echo" in out
    assert "validators (2):" in out
    assert "lint" in out and "tests" in out
    assert "task complete" in out


def test_loop_controller_has_no_verbose_toggle() -> None:
    assert "verbose" not in LoopController.__dataclass_fields__
