"""agentic-protocol: typed cross-repo contracts for the agentic system.

Pydantic v2 models that consumer packages (mcp-agent-handoff,
mcp-agent-orchestrator, agentic-bootstrap, agentic-system) import to
guarantee wire-level compatibility across out-of-process boundaries.
"""

from __future__ import annotations

from .bootstrap import BootstrapManifest, OverlayConfigEntry, OverlaySurface
from .compaction import DecisionRef, StructuredSummary, TurnRange
from .handoff import (
    ActiveTask,
    HandoffState,
    HandoffStatus,
    TargetWorktree,
    TaskPlanRef,
    TaskPlanResolution,
    TaskRef,
)
from .hooks import (
    PostToolUseEvent,
    PreToolUseEvent,
    SessionStartEvent,
    StopEvent,
    UserPromptSubmitEvent,
)
from .skills import SkillManifest, SkillScope

__version__ = "0.1.0"

__all__ = [
    "ActiveTask",
    "BootstrapManifest",
    "DecisionRef",
    "HandoffState",
    "HandoffStatus",
    "OverlayConfigEntry",
    "OverlaySurface",
    "PostToolUseEvent",
    "PreToolUseEvent",
    "SessionStartEvent",
    "SkillManifest",
    "SkillScope",
    "StopEvent",
    "StructuredSummary",
    "TargetWorktree",
    "TaskPlanRef",
    "TaskPlanResolution",
    "TaskRef",
    "TurnRange",
    "UserPromptSubmitEvent",
    "__version__",
]
