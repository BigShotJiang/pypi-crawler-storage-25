"""Bootstrap install manifest schema (Schema #5 from founding plan 0001).

The wire shape ``agentic-bootstrap`` writes to
``<target>/.agentic-overlay.json``. Captures the contract between
bootstrap and target repos so target-side guardrails (lint hoisted
paths, harness sync check, drift detectors) can validate against a
single typed shape rather than per-key heuristics.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class OverlaySurface(BaseModel):
    """A single overlay surface entry (e.g. skills, commands, hooks)."""

    model_config = ConfigDict(extra="allow")

    path: str = Field(description="Repo-relative surface path (e.g. '.claude/skills/handoff-lifecycle').")
    source: Literal["shared", "local", "overlapping", "generated"] = Field(
        description=(
            "Origin tier: 'shared' (symlinked from agentic-system), "
            "'local' (target-owned), 'overlapping' (target overrides shared), "
            "'generated' (per-agent surface produced by generate_agent_workflows.py "
            "during install — Plan 0002 step 1)."
        ),
    )


class OverlayConfigEntry(BaseModel):
    """A consumer-tool config that bootstrap wrote (e.g. .vscode/mcp.json).

    ``action`` is the string the install flow emits today
    (``created``, ``updated``, ``set``, ``unchanged``). Modeled as a
    free string rather than a Literal so the contract does not block
    bootstrap from introducing new actions before the protocol bumps.
    """

    model_config = ConfigDict(extra="allow")

    path: str
    action: str = Field(
        min_length=1,
        description="What bootstrap did to the config (e.g. 'created', 'updated', 'set', 'unchanged').",
    )


class BootstrapManifest(BaseModel):
    """Top-level shape of ``.agentic-overlay.json``.

    Validated on write by ``agentic-bootstrap.install`` so the file
    cannot drift silently. Consumers (drift detectors, doctor commands)
    parse the same model on read.
    """

    model_config = ConfigDict(extra="allow")

    schema_version: int = Field(ge=1, description="Manifest schema version.")
    remote_url: str = Field(min_length=1)
    remote_ref: str = Field(min_length=1)
    remote_sha: str = Field(
        min_length=40,
        max_length=40,
        pattern=r"^[0-9a-f]{40}$",
        description="Resolved 40-char git SHA at install time.",
    )
    surfaces: list[OverlaySurface] = Field(default_factory=list)
    configs: list[OverlayConfigEntry] = Field(default_factory=list)
