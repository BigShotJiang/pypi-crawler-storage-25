"""
iyzico payment provider.

This provider wraps the iyzico client to provide a consistent interface
compatible with the payments-tr provider abstraction.

Requires: pip install django-payments-tr[iyzico]
"""

from __future__ import annotations

import logging
from typing import Any

from payments_tr.providers.base import (
    BuyerInfo,
    PaymentLike,
    PaymentProvider,
    PaymentResult,
    RefundResult,
    WebhookResult,
)
from payments_tr.providers.iyzico.utils import kurus_to_try_string

logger = logging.getLogger(__name__)


class IyzicoProvider(PaymentProvider):
    """
    iyzico payment provider.

    This provider uses the iyzico client for the underlying implementation,
    providing a consistent interface for the payments-tr abstraction layer.

    Features:
        - Checkout form initialization (redirect-based flow)
        - 3D Secure payments
        - Installment payments
        - Refunds (full and partial)
        - Webhook/callback handling

    Example:
        >>> from payments_tr import get_payment_provider
        >>> provider = get_payment_provider("iyzico")
        >>> result = provider.create_payment(
        ...     payment,
        ...     callback_url="https://example.com/callback",
        ...     buyer_info={"email": "user@example.com"}
        ... )
        >>> if result.success:
        ...     redirect(result.checkout_url)
    """

    provider_name = "iyzico"

    def __init__(self) -> None:
        """Initialize the iyzico provider."""
        try:
            from payments_tr.providers.iyzico.client import IyzicoClient

            self._client = IyzicoClient()
        except ImportError as e:
            raise ImportError(
                "iyzico provider requires 'iyzipay' package. "
                "Install it with: pip install django-payments-tr[iyzico]"
            ) from e

    def create_payment(
        self,
        payment: PaymentLike,
        *,
        currency: str = "TRY",
        callback_url: str | None = None,
        buyer_info: BuyerInfo | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> PaymentResult:
        """
        Create an iyzico checkout form session.

        This creates a checkout form token that redirects the user
        to iyzico's hosted payment page.

        Args:
            payment: Payment object with id, amount, currency
            currency: Currency code (default: TRY)
            callback_url: URL where iyzico redirects after payment (required)
            buyer_info: Buyer information (required by iyzico)
            **kwargs: Additional options:
                - installments: List of installment options (e.g., [1, 2, 3, 6])
                - basket_items: Custom basket items list
                - locale: Locale for checkout (default: "tr")
                - marketplace: When ``True``, enable strict marketplace
                  routing — every basket item must carry both
                  ``subMerchantKey`` and ``subMerchantPrice``, and the
                  default synthetic single-item basket is rejected. The
                  default ``False`` keeps v0.4.0 behaviour byte-for-byte.

        Returns:
            PaymentResult with token and checkout_url
        """
        if not callback_url:
            return PaymentResult(
                success=False,
                error_message="callback_url is required for iyzico payments",
                error_code="MISSING_CALLBACK_URL",
            )

        marketplace = bool(kwargs.get("marketplace", False))

        # Convert buyer_info to BuyerInfo if dict
        if isinstance(buyer_info, dict):
            buyer_info = BuyerInfo.from_dict(buyer_info)
        elif buyer_info is None:
            # Try to extract from payment object
            buyer_info = self._extract_buyer_info(payment)

        try:
            # Build request data — _build_checkout_request reads
            # ``marketplace`` to decide whether the synthetic single-item
            # basket fallback is allowed.
            order_data, buyer_dict, billing_address, basket_items = self._build_checkout_request(
                payment=payment,
                currency=currency,
                buyer_info=buyer_info,
                **kwargs,
            )

            installments = kwargs.get("installments", [1, 2, 3, 6, 9, 12])

            # Create checkout form via iyzico client
            response = self._client.create_checkout_form(
                order_data=order_data,
                buyer=buyer_dict,
                billing_address=billing_address,
                basket_items=basket_items,
                callback_url=callback_url,
                enabled_installments=installments,
                marketplace=marketplace,
            )

            # If we get here, the response was successful
            token = response.token
            checkout_url = response.payment_page_url or response.checkout_form_content

            return PaymentResult(
                success=True,
                provider_payment_id=token,
                token=token,
                checkout_url=checkout_url,
                status="initialized",
                raw_response=response.to_dict(),
            )

        except Exception as e:
            # Extract error details if available
            error_code = getattr(e, "error_code", None) or "IYZICO_ERROR"
            error_message = str(e)
            logger.error(f"iyzico checkout form creation failed: {error_message}")
            return PaymentResult(
                success=False,
                error_message=error_message,
                error_code=error_code,
            )

    def confirm_payment(
        self,
        provider_payment_id: str,
        *,
        expected_amount: int | None = None,
        expected_currency: str | None = None,
    ) -> PaymentResult:
        """
        Confirm an iyzico payment by retrieving the checkout form result.

        Validates the provider-reported ``paidPrice`` and ``currency``
        against the caller's expected values when supplied (TOCTOU
        defense). See :meth:`PaymentProvider.confirm_payment`.

        Args:
            provider_payment_id: The iyzico token from the checkout form.
            expected_amount: Expected amount in kuruş (integer).
            expected_currency: Expected currency code (e.g. ``"TRY"``).

        Returns:
            PaymentResult with confirmation status.
        """
        try:
            response = self._client.retrieve_checkout_form(provider_payment_id)

            # Response is a CheckoutFormResultResponse object
            if not (response.is_successful() and response.payment_status == "SUCCESS"):
                error_message = response.error_message or "Payment not successful"
                return PaymentResult(
                    success=False,
                    error_message=error_message,
                    status=response.payment_status or "FAILURE",
                    raw_response=response.to_dict(),
                )

            # Provider says success — now make sure they paid for what
            # WE think they bought. Iyzico returns paidPrice in TRY (e.g.
            # "29.99"); convert to kuruş for an integer comparison that
            # cannot drift on float rounding.
            if expected_amount is None or expected_currency is None:
                logger.warning(
                    "confirm_payment called without expected_amount/"
                    "expected_currency — caller is responsible for "
                    "TOCTOU validation. Strongly recommended to supply "
                    "both for v0.4.0+."
                )
            else:
                mismatch = self._validate_amount_currency(
                    response,
                    expected_amount=expected_amount,
                    expected_currency=expected_currency,
                )
                if mismatch is not None:
                    return mismatch

            return PaymentResult(
                success=True,
                provider_payment_id=response.payment_id,
                status="succeeded",
                raw_response=response.to_dict(),
            )

        except Exception as e:
            # Extract error details if available
            error_code = getattr(e, "error_code", None) or "IYZICO_ERROR"
            error_message = str(e)
            logger.error(f"iyzico error confirming payment: {error_message}")
            return PaymentResult(
                success=False,
                error_message=error_message,
                error_code=error_code,
            )

    @staticmethod
    def _validate_amount_currency(
        response: Any,
        *,
        expected_amount: int,
        expected_currency: str,
    ) -> PaymentResult | None:
        """
        Compare provider-reported amount/currency with expected values.

        Returns a failing PaymentResult on mismatch, or None when valid.
        Comparisons are done in the smallest unit (kuruş) using Decimal
        to avoid float drift.
        """
        from decimal import Decimal

        provider_currency = (response.currency or "").upper()
        if provider_currency != expected_currency.upper():
            logger.error(
                "Iyzico currency mismatch: expected=%s provider=%s payment_id=%s",
                expected_currency,
                provider_currency,
                response.payment_id,
            )
            return PaymentResult(
                success=False,
                error_message=(
                    f"Currency mismatch: expected {expected_currency}, "
                    f"provider reported {provider_currency}"
                ),
                error_code="CURRENCY_MISMATCH",
                raw_response=response.to_dict(),
            )

        paid_price = response.paid_price  # Decimal in TRY (e.g. 29.99)
        if paid_price is None:
            logger.error(
                "Iyzico response missing paidPrice for payment_id=%s",
                response.payment_id,
            )
            return PaymentResult(
                success=False,
                error_message="Provider response missing paid amount",
                error_code="AMOUNT_MISSING",
                raw_response=response.to_dict(),
            )

        # Convert kuruş int → Decimal TRY for comparison.
        expected_decimal = Decimal(int(expected_amount)) / Decimal(100)
        if paid_price != expected_decimal:
            logger.error(
                "Iyzico amount mismatch: expected=%s provider=%s payment_id=%s",
                expected_decimal,
                paid_price,
                response.payment_id,
            )
            return PaymentResult(
                success=False,
                error_message=(
                    f"Amount mismatch: expected {expected_decimal:.2f} "
                    f"{expected_currency}, provider reported "
                    f"{paid_price:.2f} {provider_currency}"
                ),
                error_code="AMOUNT_MISMATCH",
                raw_response=response.to_dict(),
            )

        return None

    def create_refund(
        self,
        payment: PaymentLike,
        amount: int | None = None,
        reason: str = "",
        **kwargs: Any,
    ) -> RefundResult:
        """
        Create an iyzico refund.

        Args:
            payment: Payment object (must have provider payment ID)
            amount: Amount to refund in kuruş, or None for full refund
            reason: Reason for refund
            **kwargs: Additional options:
                - provider_payment_id: Override payment ID from payment object
                - ip_address: IP address for refund request (required by iyzico)
                - payment_transaction_id: Item-level transaction ID. When
                  set, the refund is targeted at a specific basket item's
                  sub-merchant share instead of the order-level payment id.
                  Required for marketplace refunds; for non-marketplace
                  flows this is ``None`` and we fall back to
                  ``provider_payment_id`` (same byte-for-byte v0.4.0
                  behaviour).

        Returns:
            RefundResult with refund status
        """
        from decimal import Decimal

        # Get the iyzico payment ID from the payment object
        provider_payment_id = getattr(payment, "iyzico_payment_id", None)
        if not provider_payment_id:
            provider_payment_id = kwargs.get("provider_payment_id")

        if not provider_payment_id:
            return RefundResult(
                success=False,
                error_message="No iyzico payment ID found on payment object",
                error_code="MISSING_PAYMENT_ID",
            )

        # Get IP address for refund (required by iyzico)
        ip_address = kwargs.get("ip_address", "127.0.0.1")
        payment_transaction_id = kwargs.get("payment_transaction_id")

        # Convert amount to Decimal for iyzico
        refund_amount = None
        if amount is not None:
            refund_amount = Decimal(str(amount)) / 100  # Convert kuruş to TRY

        try:
            response = self._client.refund_payment(
                payment_id=provider_payment_id,
                ip_address=ip_address,
                amount=refund_amount,
                reason=reason or None,
                payment_transaction_id=payment_transaction_id,
            )

            # If we get here, the refund was successful
            return RefundResult(
                success=True,
                provider_refund_id=response.refund_id,
                amount=amount or payment.amount,
                status="succeeded",
                raw_response=response.to_dict(),
            )

        except Exception as e:
            # Extract error details if available
            error_code = getattr(e, "error_code", None) or "IYZICO_ERROR"
            error_message = str(e)
            logger.error(f"iyzico refund failed: {error_message}")
            return RefundResult(
                success=False,
                error_message=error_message,
                error_code=error_code,
            )

    def _supports_alternative_webhook_auth(self) -> bool:
        """Iyzico uses server-side token retrieval for webhook authentication."""
        return True

    def _process_webhook(
        self,
        payload: bytes | dict[str, Any],
        signature: str | None = None,
        **kwargs: Any,
    ) -> WebhookResult:
        """
        Process an iyzico callback.

        iyzico uses callback URLs rather than HMAC-signed webhooks. The
        callback is received after the user completes payment on iyzico's
        page; authentication is performed via the server-side
        ``confirm_payment`` API call (token retrieval), declared by
        :meth:`_supports_alternative_webhook_auth` returning ``True``.

        Args:
            payload: Callback data (bytes or parsed dict)
            signature: Ignored (always None for iyzico).
            **kwargs: Additional data including 'token'.

        Returns:
            WebhookResult with event details
        """
        try:
            import json

            # Parse the callback data
            if isinstance(payload, bytes):
                data: dict[str, Any] = json.loads(payload.decode("utf-8"))
            else:
                data = payload

            token = data.get("token") or kwargs.get("token")

            if not token:
                return WebhookResult(
                    success=False,
                    error_message="No token in callback",
                )

            # Retrieve the payment result using the token
            confirm_result = self.confirm_payment(token)

            if confirm_result.success:
                return WebhookResult(
                    success=True,
                    event_type="payment.success",
                    provider_payment_id=confirm_result.provider_payment_id,
                    status="succeeded",
                )
            return WebhookResult(
                success=False,
                event_type="payment.failed",
                error_message=confirm_result.error_message,
            )

        except Exception as e:
            # Extract error details if available
            error_code = getattr(e, "error_code", None) or "IYZICO_ERROR"
            error_message = str(e)
            logger.error(f"iyzico error handling callback: {error_message}")
            return WebhookResult(
                success=False,
                error_message=error_message,
                error_code=error_code,
            )

    def get_payment_status(self, provider_payment_id: str) -> str:
        """Get the current status of a payment from iyzico."""
        result = self.confirm_payment(provider_payment_id)
        if result.success:
            return "succeeded"
        return result.status or "unknown"

    def supports_checkout_form(self) -> bool:
        """iyzico supports embedded checkout form content."""
        return True

    def supports_redirect(self) -> bool:
        """iyzico primarily uses redirect-based checkout."""
        return True

    def supports_installments(self) -> bool:
        """iyzico supports installment payments."""
        return True

    def supports_marketplace(self) -> bool:
        """
        iyzico supports marketplace (sub-merchant) payment splitting.

        Callers can opt in by passing ``marketplace=True`` to
        :meth:`create_payment` together with ``basket_items`` that carry
        ``subMerchantKey`` and ``subMerchantPrice``.
        """
        return True

    def _build_checkout_request(
        self,
        payment: PaymentLike,
        currency: str,
        buyer_info: BuyerInfo,
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
        """Build the checkout form request data components."""
        locale = kwargs.get("locale", "tr")
        basket_items = kwargs.get("basket_items")
        marketplace = bool(kwargs.get("marketplace", False))

        if not basket_items:
            if marketplace:
                # Don't synthesise a default basket in marketplace mode —
                # there is no plausible default ``subMerchantKey`` we
                # could put on it. The client layer will catch this too
                # (defence in depth), but failing here gives a clearer
                # provider-level error.
                from .exceptions import ValidationError as IyzicoValidationError

                raise IyzicoValidationError(
                    "marketplace=True requires explicit basket_items with sub-merchant fields",
                    error_code="MARKETPLACE_REQUIRES_BASKET_ITEMS",
                )
            basket_items = self._build_default_basket(payment)

        buyer_dict = buyer_info.to_dict()

        # Build order data — money MUST go through Decimal (never float)
        # because Iyzico signs the request body; float drift breaks the HMAC.
        price_str = kurus_to_try_string(payment.amount)
        order_data = {
            "locale": locale,
            "conversationId": str(payment.id),
            "price": price_str,
            "paidPrice": price_str,
            "currency": currency.upper(),
            "basketId": str(payment.id),
            "paymentGroup": "PRODUCT",
        }

        # Build billing address
        billing_address = {
            "address": buyer_dict.get("registrationAddress", "Address"),
            "city": buyer_dict.get("city", "Istanbul"),
            "country": buyer_dict.get("country", "Turkey"),
            "zipCode": buyer_dict.get("zipCode", "34000"),
        }

        return order_data, buyer_dict, billing_address, basket_items

    def _build_default_basket(self, payment: PaymentLike) -> list[dict[str, Any]]:
        """Build default basket items from payment."""
        return [
            {
                "id": str(payment.id),
                "name": "Payment",
                "category1": "Service",
                "itemType": "VIRTUAL",
                "price": kurus_to_try_string(payment.amount),
            }
        ]

    def _extract_buyer_info(self, payment: PaymentLike) -> BuyerInfo:
        """Try to extract buyer info from payment object."""
        # Try to get client/user from payment
        if hasattr(payment, "client"):
            client = payment.client
            user = getattr(client, "user", client)
            return BuyerInfo(
                id=str(getattr(client, "id", "")),
                email=getattr(user, "email", ""),
                name=getattr(
                    user,
                    "first_name",
                    (
                        getattr(user, "name", "").split()[0]
                        if getattr(user, "name", "")
                        else "Customer"
                    ),
                ),
                surname=getattr(
                    user,
                    "last_name",
                    (
                        getattr(user, "name", "").split()[-1]
                        if len(getattr(user, "name", "").split()) > 1
                        else "Customer"
                    ),
                ),
                phone=getattr(client, "phone", ""),
            )
        return BuyerInfo(email="customer@example.com")
