"""Tests for `/memory forget` and `/memory pin` slash commands.

Replaces the old `_pin` tests in `test_memory.py` that imported from the
deleted `abilities/memory_manage.py`. The shell command path is the
user-visible API for hard delete + pin in v0.5+ -- the brain agent has
no tool for these.
"""

import os
import tempfile

# Use temp DB for all tests in this module.
_TEMP_DB = tempfile.mktemp(suffix=".db")
os.environ["PHOENIX_MEMORY_DB"] = _TEMP_DB


from phoenix.memory import MemorySystem  # noqa: E402
from phoenix.memory.config import MINILM_PRESET, MemoryParams  # noqa: E402
from phoenix.shell.memory_commands import (  # noqa: E402
    _memory_forget,
    _memory_patterns,
    _memory_pin,
)

_PARAMS = MemoryParams(**MINILM_PRESET)


class TestMemoryPinCommand:
    async def test_pin_refuses_weak_memory(self):
        mem = MemorySystem(_PARAMS)
        await mem.post_turn("I sometimes use a debugger.", "OK.", session_id="t")
        results = await mem.store.search_text("debugger", limit=1)
        assert results, "expected the memory to be stored"
        msg = await _memory_pin(mem, "debugger", pinned=True)
        assert "Refusing to pin" in msg
        await mem.close()

    async def test_pin_accepts_strong_well_used_memory(self):
        mem = MemorySystem(_PARAMS)
        await mem.post_turn("I live in Singapore.", "OK.", session_id="t")
        results = await mem.store.search_text("Singapore", limit=1)
        assert results
        mid = results[0]["id"]
        # Bump strength above 1.5 and access_count above 3 to clear guards.
        await mem.store.update_strength(mid, 1.8)
        for _ in range(4):
            await mem.store.increment_access(mid)
        msg = await _memory_pin(mem, "Singapore", pinned=True)
        assert "Pinned" in msg and "Refusing" not in msg
        await mem.close()

    async def test_unpin_unrestricted(self):
        mem = MemorySystem(_PARAMS)
        await mem.post_turn("I sometimes use a profiler.", "OK.", session_id="t")
        msg = await _memory_pin(mem, "profiler", pinned=False)
        assert "Unpinned" in msg
        await mem.close()

    async def test_pin_empty_query_returns_usage(self):
        mem = MemorySystem(_PARAMS)
        msg = await _memory_pin(mem, "", pinned=True)
        assert "Usage" in msg and "/memory pin" in msg
        await mem.close()

    async def test_pin_no_match_returns_friendly_message(self):
        mem = MemorySystem(_PARAMS)
        msg = await _memory_pin(mem, "nonexistent-token-zzz", pinned=True)
        assert "No memories found" in msg
        await mem.close()


class TestMemoryForgetCommand:
    async def test_forget_deletes_best_match(self):
        mem = MemorySystem(_PARAMS)
        await mem.post_turn("I drink kombucha every morning.", "OK.", session_id="t")
        before = await mem.store.search_text("kombucha", limit=1)
        assert before, "memory should be stored before forget"

        msg = await _memory_forget(mem, "kombucha")
        assert "Forgotten" in msg

        after = await mem.store.search_text("kombucha", limit=1)
        assert not after, "memory should be hard-deleted"
        await mem.close()

    async def test_forget_empty_query_returns_usage(self):
        mem = MemorySystem(_PARAMS)
        msg = await _memory_forget(mem, "")
        assert "Usage" in msg and "/memory forget" in msg
        await mem.close()

    async def test_forget_no_match_is_no_op(self):
        mem = MemorySystem(_PARAMS)
        msg = await _memory_forget(mem, "nothing-here-xyz")
        assert "No memories found" in msg
        await mem.close()


class TestMemoryPatternsCommand:
    async def test_patterns_empty_returns_friendly_message(self):
        mem = MemorySystem(_PARAMS)
        msg = await _memory_patterns(mem)
        assert "No patterns yet" in msg
        await mem.close()

    async def test_patterns_shows_consolidated_insights(self):
        mem = MemorySystem(_PARAMS)
        await mem._ensure_initialized()
        # Inject a fake insight row directly so we don't have to wait
        # for consolidation to fire after 20 turns.
        embedding = mem.embedder.embed_document("[consolidated] sample pattern")
        await mem.store.add(
            content="[consolidated] sample pattern",
            category="insight",
            namespace="global",
            embedding=embedding,
            strength=1.0,
            source_session="consolidation",
        )
        msg = await _memory_patterns(mem)
        assert "Patterns Phoenix has noticed" in msg
        assert "sample pattern" in msg
        # The [consolidated] prefix is stripped for display.
        assert "[consolidated]" not in msg
        await mem.close()
