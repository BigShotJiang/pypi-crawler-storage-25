from __future__ import annotations

from agentic_memory.core.security import SecretScanPolicy


def test_secret_scan_policy_detects_common_secret_patterns() -> None:
    # Secret-like fixtures are assembled at runtime so that no literal token
    # appears in source and trips GitHub push protection / secret scanning.
    # The scanner sees the fully concatenated text, so detection is unaffected.
    aws_key = "AKI" + "A1234567890ABCDEF"
    github_pat = "ghp" + "_abcdefghijklmnopqrstuvwxyz1234567890"
    pem_header = "-----BEGIN " + "OPENSSH PRIVATE KEY-----"
    slack_bot = "xox" + "b-123456789012-123456789012-abcdefghijklmnopqrstuvwx"
    slack_user = "xox" + "p-123456789012-123456789012-abcdefghijklmnopqrstuvwx"
    api_token = "api_key=" + "sk_" + "live_abcdEFGH1234567890"
    entropy = "X7f0sM8qL2nP5vR9" + "tW1yZ4cB6dH3kJ8m"

    text = f"""
    aws = {aws_key}
    github = {github_pat}
    private_key = {pem_header}
    slack_bot = {slack_bot}
    slack_user = {slack_user}
    token = {api_token}
    entropy = {entropy}
    """

    matches = SecretScanPolicy.scan(text)
    pattern_names = {match.pattern_name for match in matches}

    assert "aws_access_key" in pattern_names
    assert "github_pat" in pattern_names
    assert "pem_private_key" in pattern_names
    assert "slack_token" in pattern_names
    assert "generic_api_token" in pattern_names
    assert "high_entropy_string" in pattern_names
    assert SecretScanPolicy.contains_secret(text) is True


def test_secret_scan_policy_ignores_safe_text() -> None:
    text = "workflow: prefer small changes and focused reviews"
    assert SecretScanPolicy.scan(text) == []
    assert SecretScanPolicy.contains_secret(text) is False


def test_secret_scan_policy_ignores_hex_digests_but_keeps_entropy_detection() -> None:
    md5_digest = "d41d8cd98f00b204e9800998ecf8427E"
    sha1_digest = "Da39a3ee5e6b4b0d3255bfef95601890afd80709"
    sha256_digest = "E3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    entropy = "X7f0sM8qL2nP5vR9" + "tW1yZ4cB6dH3kJ8m"

    digest_text = f"""
    md5 = {md5_digest}
    sha1 = {sha1_digest}
    sha256 = {sha256_digest}
    """
    assert SecretScanPolicy.scan(digest_text) == []
    assert SecretScanPolicy.contains_secret(digest_text) is False

    labeled_matches = SecretScanPolicy.scan(f"api_key={sha256_digest}")
    assert "generic_api_token" in {match.pattern_name for match in labeled_matches}
    assert any(
        match.pattern_name == "generic_api_token" and match.matched_text == sha256_digest
        for match in labeled_matches
    )

    matches = SecretScanPolicy.scan(f"entropy = {entropy}")
    assert [match.pattern_name for match in matches] == ["high_entropy_string"]
    assert matches[0].matched_text == entropy


def test_secret_scan_detects_ai_service_api_keys() -> None:
    anthropic_key = "sk-ant-" + "api03-" + "AbCdEfGh1234567890abcd"
    anthropic_short_key = "sk-ant-" + "AbCdEfGh1234567890abcdef"
    stripe_live_key = "sk_live_" + "AbCdEfGh1234567890abcdef"
    stripe_test_key = "sk_test_" + "AbCdEfGh1234567890abcdef"
    openai_key = "sk-proj-" + "AbCdEfGh1234567890abcdef"

    text = f"""
    anthropic = {anthropic_key}
    anthropic_short = {anthropic_short_key}
    stripe_live = {stripe_live_key}
    stripe_test = {stripe_test_key}
    openai = {openai_key}
    """

    matches = SecretScanPolicy.scan(text)
    pattern_names = {match.pattern_name for match in matches}
    ai_service_matches = {
        match.matched_text for match in matches if match.pattern_name == "ai_service_api_key"
    }

    assert "ai_service_api_key" in pattern_names
    assert ai_service_matches == {
        anthropic_key,
        anthropic_short_key,
        stripe_live_key,
        stripe_test_key,
        openai_key,
    }
