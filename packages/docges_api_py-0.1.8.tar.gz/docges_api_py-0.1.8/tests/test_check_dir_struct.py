"""Tests for check_dir_struct() — path traversal and creation logic."""

import httpx
import pytest
import respx

from docges_api_py.client import AsyncDocGes

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.fixture
def client():
    c = AsyncDocGes("http://test.example.com", "testuser", "testpass", "test-app")
    c._login_response = REAL_LOGIN_PAYLOAD
    return c


@pytest.mark.asyncio
async def test_check_dir_struct_existing_path(client):
    """When all categories exist, returns the path without creating anything."""
    with respx.mock:
        respx.post("http://test.example.com/Content/LoadChilds").mock(
            return_value=httpx.Response(
                200,
                json={
                    "result": {
                        "CategoriasHijas": [{"SID": "sid-2025", "Nombre": "2025"}],
                        "Documentos": [],
                    }
                },
            )
        )

        result = await client.check_dir_struct(
            root_sid="root-sid",
            path_names=["2025"],
            create_if_not_exist=False,
        )

    assert result == [
        {"sid": "sid-2025", "parent_sid": "root-sid", "name": "2025"}
    ]


@pytest.mark.asyncio
async def test_check_dir_struct_missing_path_without_create(client):
    """When category doesn't exist and create_if_not_exist=False, returns None."""
    with respx.mock:
        respx.post("http://test.example.com/Content/LoadChilds").mock(
            return_value=httpx.Response(
                200,
                json={
                    "result": {
                        "CategoriasHijas": [{"SID": "sid-existing", "Nombre": "existing"}],
                        "Documentos": [],
                    }
                },
            )
        )

        result = await client.check_dir_struct(
            root_sid="root-sid",
            path_names=["new-folder"],
            create_if_not_exist=False,
        )

    assert result is None


@pytest.mark.asyncio
async def test_check_dir_struct_creates_missing_path(client):
    """When category doesn't exist and create_if_not_exist=True, creates it."""
    with respx.mock:
        respx.post("http://test.example.com/Content/LoadChilds").mock(
            return_value=httpx.Response(
                200,
                json={"result": {"CategoriasHijas": [], "Documentos": []}},
            )
        )
        respx.post("http://test.example.com/Content/CreateCategory").mock(
            return_value=httpx.Response(200, json={"result": "new-sid-2025"})
        )

        result = await client.check_dir_struct(
            root_sid="root-sid",
            path_names=["2025"],
            create_if_not_exist=True,
        )

    assert result == [
        {"sid": "new-sid-2025", "parent_sid": "root-sid", "name": "2025"}
    ]


@pytest.mark.asyncio
async def test_check_dir_struct_mixed_path(client):
    """First level exists, second level needs creation."""
    with respx.mock:
        respx.post("http://test.example.com/Content/LoadChilds").mock(
            side_effect=[
                # First call: root has "2025"
                httpx.Response(
                    200,
                    json={
                        "result": {
                            "CategoriasHijas": [{"SID": "sid-2025", "Nombre": "2025"}],
                            "Documentos": [],
                        }
                    },
                ),
                # Second call: "2025" has no children
                httpx.Response(
                    200,
                    json={"result": {"CategoriasHijas": [], "Documentos": []}},
                ),
            ]
        )
        respx.post("http://test.example.com/Content/CreateCategory").mock(
            return_value=httpx.Response(200, json={"result": "new-sid-pm"})
        )

        result = await client.check_dir_struct(
            root_sid="root-sid",
            path_names=["2025", "PM-001"],
            create_if_not_exist=True,
        )

    assert result == [
        {"sid": "sid-2025", "parent_sid": "root-sid", "name": "2025"},
        {"sid": "new-sid-pm", "parent_sid": "sid-2025", "name": "PM-001"},
    ]


@pytest.mark.asyncio
async def test_check_dir_struct_full_info_false(client):
    """When full_info=False, returns only the last directory."""
    with respx.mock:
        # First level exists, second needs creation
        respx.post("http://test.example.com/Content/LoadChilds").mock(
            side_effect=[
                httpx.Response(
                    200,
                    json={
                        "result": {
                            "CategoriasHijas": [{"SID": "sid-2025", "Nombre": "2025"}],
                            "Documentos": [],
                        }
                    },
                ),
                httpx.Response(
                    200,
                    json={"result": {"CategoriasHijas": [], "Documentos": []}},
                ),
            ]
        )
        respx.post("http://test.example.com/Content/CreateCategory").mock(
            return_value=httpx.Response(200, json={"result": "new-sid-pm"})
        )

        result = await client.check_dir_struct(
            root_sid="root-sid",
            path_names=["2025", "PM-001"],
            create_if_not_exist=True,
            full_info=False,
        )

    assert result == {"sid": "new-sid-pm", "parent_sid": "sid-2025", "name": "PM-001"}
