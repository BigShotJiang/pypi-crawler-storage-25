"""Tests for retry behavior in AsyncDocGes.do_request()."""

from unittest.mock import AsyncMock, patch

import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes, RequestError

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_do_request_retries_on_server_error():
    """Test that do_request retries on 5xx errors and eventually succeeds."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        route = router.post(f"{base_url}/Content/Download").mock(
            side_effect=[
                httpx.Response(500, json={"error": "Internal Server Error"}),
                httpx.Response(500, json={"error": "Internal Server Error"}),
                httpx.Response(200, json={"result": {"name": "test.pdf", "id": "doc-123"}}),
            ]
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD  # inject session
        client.timeout = 0.1  # small timeout to reduce backoff sleep
        client.intents = 3

        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await client.do_request("/Content/Download")

        assert route.called
        assert len(route.calls) == 3
        assert result == {"result": {"name": "test.pdf", "id": "doc-123"}}

        await client.close()


@pytest.mark.asyncio
async def test_do_request_fails_after_max_retries():
    """Test that do_request raises RequestError after all intents are exhausted."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        route = router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(500, json={"error": "Internal Server Error"})
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.timeout = 0.1
        client.intents = 2  # only 2 attempts

        with patch("asyncio.sleep", new_callable=AsyncMock), pytest.raises(RequestError):
            await client.do_request("/Content/Download")

        assert len(route.calls) == 2

        await client.close()


@pytest.mark.asyncio
async def test_do_request_uses_exponential_backoff():
    """Task 3.2: retry delays must be min(2**attempt, 10), not timeout*attempt."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/Download").mock(
            side_effect=[
                httpx.Response(500, json={"error": "err"}),
                httpx.Response(500, json={"error": "err"}),
                httpx.Response(500, json={"error": "err"}),
            ]
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.timeout = 30.0  # large timeout — must NOT be used for backoff
        client.intents = 3

        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep, pytest.raises(RequestError):
            await client.do_request("/Content/Download")

        # attempt=1 → sleep(min(2**1, 10)) = sleep(2)
        # attempt=2 → sleep(min(2**2, 10)) = sleep(4)
        sleep_calls = [call.args[0] for call in mock_sleep.call_args_list]
        assert sleep_calls == [2, 4], (
            f"Expected exponential backoff [2, 4] but got {sleep_calls}"
        )

        await client.close()


@pytest.mark.asyncio
async def test_do_request_exponential_backoff_capped_at_10():
    """Task 3.2 triangulation: backoff must cap at 10 seconds regardless of attempt number."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(500, json={"error": "err"})
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.timeout = 30.0
        client.intents = 5  # attempt 4 → 2**4=16 → cap to 10

        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep, pytest.raises(RequestError):
            await client.do_request("/Content/Download")

        sleep_calls = [call.args[0] for call in mock_sleep.call_args_list]
        # attempts 1,2,3,4 → min(2,10), min(4,10), min(8,10), min(16,10)
        assert sleep_calls == [2, 4, 8, 10], (
            f"Expected capped backoff [2, 4, 8, 10] but got {sleep_calls}"
        )

        await client.close()
