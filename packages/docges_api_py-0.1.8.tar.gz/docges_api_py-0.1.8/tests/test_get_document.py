"""Tests for AsyncDocGes.get_document()."""

import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes, RequestError
from docges_api_py.models.document import Document

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_get_document_success():
    """Test that get_document returns a Document on success."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(
                200,
                json={
                    "result": {"name": "test.pdf", "data": "base64content", "type": "application/pdf"},
                    "message": "OK",
                },
            )
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD  # inject session, skip auth

        doc = await client.get_document("doc-123")

        assert isinstance(doc, Document)
        assert doc.id == "doc-123"
        assert doc.name == "test.pdf"

        await client.close()


@pytest.mark.asyncio
async def test_get_document_failure():
    """Test that get_document raises RequestError on persistent 500s."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx", assert_all_called=False) as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(500, json={"error": "Internal Server Error"})
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.timeout = 0.01  # fast backoff
        client.intents = 1    # only 1 attempt

        with pytest.raises(RequestError):
            await client.get_document("doc-123")

        await client.close()


@pytest.mark.asyncio
async def test_http_500_html_body_raises_structured_request_error():
    """Task 3.3: HTTP 500 with HTML body must raise RequestError, not JSONDecodeError."""
    base_url = "https://fake-docges.example.com"
    html_body = "<html><body><h1>500 Internal Server Error</h1></body></html>"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(
                500,
                content=html_body.encode(),
                headers={"Content-Type": "text/html"},
            )
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.intents = 1

        with pytest.raises(RequestError) as exc_info:
            await client.do_request("/Content/Download")

        # Must be a structured RequestError, NOT a JSONDecodeError crash
        assert "RequestError" in type(exc_info.value).__name__ or isinstance(exc_info.value, RequestError)
        # The error message should NOT be a raw JSONDecodeError
        assert "JSONDecodeError" not in type(exc_info.value).__name__

        await client.close()


@pytest.mark.asyncio
async def test_http_200_json_parse_error_raises_structured_request_error():
    """Task 3.3 triangulation: 200 response with non-JSON body raises RequestError, not crash."""
    base_url = "https://fake-docges.example.com"
    broken_body = "this is not json at all"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(
                200,
                content=broken_body.encode(),
                headers={"Content-Type": "text/plain"},
            )
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.intents = 1

        with pytest.raises(RequestError):
            await client.do_request("/Content/Download")

        await client.close()
