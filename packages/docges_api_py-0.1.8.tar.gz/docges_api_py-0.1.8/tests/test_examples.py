"""Tests for examples/02_initial_cats.py — verify login + initial categories example."""
from __future__ import annotations

import json
import os
import runpy
import sys

import httpx
import pytest
import respx

# Shared fixtures -----------------------------------------------------------------

LOGIN_RESPONSE = {
    "userInfo": {"SID": "a6e65fd7-0000-0000-0000-000000000001", "Nombre": "TestUser", "Id": 1},
    "wareHouseInfo": {"SID": "16cf3ed3-0000-0000-0000-000000000002", "Nombre": "devbg"},
}

CATS_RESPONSE = {
    "result": {
        "Nombre": "$",
        "SID": "root-sid",
        "CategoriaMadre": None,
        "CategoriasHijas": [
            {"Nombre": "CatA", "SID": "cat-a"},
            {"Nombre": "CatB", "SID": "cat-b"},
        ],
        "Documentos": [],
    },
    "message": "OK",
}

CATS_EMPTY_RESPONSE = {
    "result": {
        "Nombre": "$",
        "SID": "root-sid",
        "CategoriaMadre": None,
        "CategoriasHijas": [],
        "Documentos": [],
    },
    "message": "OK",
}

ENV_VARS = {
    "DOCGES_API_BASE_URL": "http://testserver.local",
    "DOCGES_USER": "testuser",
    "DOCGES_PASSWORD": "testpass",
    "DOCGES_APP_ID": "testapp",
}


def _run_example(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture, script_name: str
) -> str:
    """Run an example script in-process and return captured stdout."""
    for k, v in ENV_VARS.items():
        monkeypatch.setenv(k, v)

    example_path = os.path.join(os.path.dirname(__file__), "..", "examples", script_name)
    example_path = os.path.normpath(example_path)

    # Remove cached module state so re-runs are isolated (only example scripts, not the library)
    for mod in list(sys.modules.keys()):
        if "examples" in mod:
            del sys.modules[mod]

    runpy.run_path(example_path, run_name="__main__")
    return capsys.readouterr().out


# Tests ---------------------------------------------------------------------------


def test_example_prints_logged_in_user(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture
) -> None:
    """Script prints the logged-in user name from auth response."""
    with respx.mock:
        respx.post("http://testserver.local/Auth/Login").respond(json=LOGIN_RESPONSE)

        def load_ini_cats_handler(request):
            body = json.loads(request.content.decode())
            rm = body.get("requestModel", {})
            assert "loginDocGesData" in rm
            assert "loginResponse" in rm
            return httpx.Response(200, json=CATS_RESPONSE)

        respx.post(
            "http://testserver.local/Content/LoadIniCats"
        ).mock(side_effect=load_ini_cats_handler)

        output = _run_example(monkeypatch, capsys, "02_initial_cats.py")

    assert "TestUser" in output


def test_example_prints_categories(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture) -> None:
    """Script prints category names when categories are returned."""
    with respx.mock:
        respx.post("http://testserver.local/Auth/Login").respond(json=LOGIN_RESPONSE)
        respx.post("http://testserver.local/Content/LoadIniCats").mock(
            side_effect=lambda req: httpx.Response(200, json=CATS_RESPONSE)
        )

        output = _run_example(monkeypatch, capsys, "02_initial_cats.py")

    assert "CatA" in output
    assert "CatB" in output


def test_example_prints_empty_when_no_categories(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture
) -> None:
    """Script prints zero categories when no categories are returned."""
    with respx.mock:
        respx.post("http://testserver.local/Auth/Login").respond(json=LOGIN_RESPONSE)
        respx.post("http://testserver.local/Content/LoadIniCats").mock(
            side_effect=lambda req: httpx.Response(200, json=CATS_EMPTY_RESPONSE)
        )

        output = _run_example(monkeypatch, capsys, "02_initial_cats.py")

    assert "0" in output


def test_example_exits_when_env_vars_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """Script raises SystemExit when required environment variables are absent."""
    for k in ENV_VARS:
        monkeypatch.delenv(k, raising=False)

    example_path = os.path.join(
        os.path.dirname(__file__), "..", "examples", "02_initial_cats.py"
    )
    example_path = os.path.normpath(example_path)

    with pytest.raises(SystemExit):
        runpy.run_path(example_path, run_name="__main__")
