"""AsyncDocGes client — session-based auth, no JWT."""

from __future__ import annotations

import asyncio
import base64
from typing import Any

import httpx
from pydantic import BaseModel

from .models.auth import AuthRequest, AuthResponse
from .models.document import Document
from .models.responses import ResCat, ResFileDownload, ResSearch, ResultActionModel


class Endpoints:
    """DocGes API endpoint paths."""

    # Auth
    auth_login = "/Auth/Login"

    # Content - Tree
    content_load_ini_cats = "/Content/LoadIniCats"
    content_load_childs = "/Content/LoadChilds"

    # Content - Upload/Download
    content_download = "/Content/Download"
    content_upload = "/Content/Upload"
    content_upload_extended = "/Content/UploadExtended"

    # Content - Search
    content_search = "/Content/SearchContent"

    # Content - Categories
    content_create_category = "/Content/CreateCategory"
    content_rename_category = "/Content/RenameCategory"
    content_delete_category = "/Content/DeleteCategory"

    # Content - Document Management
    content_remove_document = "/Content/RemoveDocument"
    content_remove_documents = "/Content/RemoveDocuments"
    content_move = "/Content/Move"
    content_update = "/Content/Update"


class DocGesError(Exception):
    """Base exception for DocGes client errors."""


class DocGesAuthError(DocGesError):
    """Raised when DocGes login fails or the response payload is invalid."""


class AuthenticationError(DocGesAuthError):
    """Raised when authentication fails (alias for DocGesAuthError)."""


class RequestError(DocGesError):
    """Raised on HTTP or network errors."""


class AsyncDocGes:
    """Async client for DocGes REST API.

    Usage:
        async with AsyncDocGes(base_url, user, pwd, appid) as client:
            await client.auth()
            # use client for API calls
    """

    def __init__(
        self,
        base_url: str,
        user: str,
        pwd: str,
        appid: str,
        *,
        timeout: float = 30.0,
        intents: int = 3,
        # token_ttl kept for backward-compat signature but unused (session-based now)
        token_ttl: int = 3600,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.user = user
        self.pwd = pwd
        self.appid = appid

        self.timeout = timeout
        self.intents = intents

        # Session state — stores the full loginResponse dict from /Auth/Login
        self._login_response: dict[str, Any] | None = None
        self._client: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Client lifecycle
    # ------------------------------------------------------------------

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={"Content-Type": "application/json"},
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> AsyncDocGes:
        await self._get_client()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    async def auth(self) -> AuthResponse:
        """Authenticate against /Auth/Login and store the session loginResponse dict."""
        payload = AuthRequest(
            username=self.user,
            password=self.pwd,
            appID=self.appid,
        )

        try:
            resp = await self.do_request(Endpoints.auth_login, payload)
        except RequestError as e:
            
            raise AuthenticationError(f"Authentication failed")

        try:
            auth_resp = AuthResponse(**resp)
        except Exception as e:
            raise AuthenticationError(f"Invalid auth response")

        # Normalize: copy SIDraiz to SID in wareHouseInfo for bridge compatibility
        # The bridge C# code expects wareHouseInfo.SID, but the API returns SIDraiz
        if (
            "wareHouseInfo" in resp
            and "SIDraiz" in resp["wareHouseInfo"]
            and "SID" not in resp["wareHouseInfo"]
        ):
            resp["wareHouseInfo"]["SID"] = resp["wareHouseInfo"]["SIDraiz"]

        # Store the normalized dict for injection into every subsequent /Content/* request
        self._login_response = resp
        return auth_resp

    def _is_authenticated(self) -> bool:
        """Check if we have an active session."""
        return self._login_response is not None

    async def _ensure_session(self) -> None:
        """Ensure we have an active session; re-auth if not."""
        if not self._is_authenticated():
            await self.auth()

    # ------------------------------------------------------------------
    # Generic request wrapper with retries
    # ------------------------------------------------------------------

    async def do_request(
        self,
        url: str,
        data: BaseModel | None = None,
    ) -> dict[str, Any]:
        """POST to `url`, auto-injecting loginResponse for /Content/* endpoints.

        Builds ``{"requestModel": {...}}`` payload:
          - For /Content/* endpoints: injects ``loginResponse`` from stored session.
          - Merges any additional ``data`` fields (model_dump(exclude_none=True)).

        Raises:
            RequestError: if all attempts fail.
        """
        client = await self._get_client()

        # Build request payload
        # Auth endpoints: send data directly (no requestModel wrapper)
        # Content endpoints: wrap in requestModel + inject loginResponse
        if "/Auth/" in url:
            # Auth endpoints expect fields directly in the body
            payload: dict[str, Any] = {}
            if data is not None:
                payload.update(data.model_dump(exclude_none=True))
        else:
            # Content endpoints use requestModel wrapper
            request_model: dict[str, Any] = {}

            # Inject session for all Content endpoints
            if "/Content/" in url:
                # Include original login request data (loginDocGesData) so bridge can reconstruct
                # the DocGesLoginModel (some bridges expect this field).
                request_model["loginDocGesData"] = {
                    "username": self.user,
                    "password": self.pwd,
                    "appID": self.appid,
                }
                if self._login_response is not None:
                    request_model["loginResponse"] = self._login_response

            # Build final payload: extra data fields (contenidoModel, fileModel, etc.)
            # go at TOP LEVEL alongside requestModel — NOT nested inside requestModel.
            # This matches the server's RequestContentModel: { contenidoModel, requestModel }.
            payload = {"requestModel": request_model}
            if data is not None:
                extra = data.model_dump(exclude_none=True)
                # If data itself has a requestModel key, merge it into the top-level one
                if "requestModel" in extra:
                    request_model.update(extra.pop("requestModel"))
                payload.update(extra)

        last_exc: Exception | None = None

        for attempt in range(1, self.intents + 1):
            try:
                resp = await client.post(url, json=payload)
                resp.raise_for_status()
                # Handle non-JSON responses (e.g., HTML 500 error pages)
                try:
                    result = resp.json()
                except Exception as json_err:
                    # Server returned non-JSON (e.g., HTML 500 error page)
                    raise RequestError(
                        f"Server returned non-JSON response (status {resp.status_code}): {resp.text[:200]}"
                    ) from json_err
                if result is None:
                    raise RequestError("Server returned null JSON")
                return result  # type: ignore[no-any-return]
            except (httpx.HTTPStatusError, httpx.RequestError, RequestError) as exc:
                last_exc = exc
                if attempt < self.intents:
                    # Exponential backoff: 2s, 4s, 8s (capped at 10s)
                    await asyncio.sleep(min(2 ** attempt, 10))

        raise RequestError(
            f"Request to {url} failed after {self.intents} attempts"
        ) from last_exc

    # ------------------------------------------------------------------
    # Document endpoints
    # ------------------------------------------------------------------

    async def get_initial_cats(self) -> ResCat:
        """Load initial categories for the user's warehouse."""
        await self._ensure_session()
        resp = await self.do_request(Endpoints.content_load_ini_cats)
        return ResCat.from_json(resp.get("result", {}))

    async def get_cat_info(self, sid: str) -> ResCat:
        """Load category details and its children by SID."""

        await self._ensure_session()

        class _ReqSid(BaseModel):
            contenidoModel: dict[str, Any]

        data = _ReqSid(contenidoModel={"SIDContenido": sid})
        resp = await self.do_request(Endpoints.content_load_childs, data)
        return ResCat.from_json(resp.get("result", {}))

    async def download_content(self, sid: str) -> ResFileDownload:
        """Download a document by SID. Returns ResFileDownload with base64 data."""
        await self._ensure_session()

        class _ReqSid(BaseModel):
            contenidoModel: dict[str, Any]

        data = _ReqSid(contenidoModel={"SIDContenido": sid})
        resp = await self.do_request(Endpoints.content_download, data)
        return ResFileDownload.from_json(resp)

    async def upload_file(
        self,
        category_sid: str,
        file_path: str,
        erp_relation: str = "",
        erp_property: str = "",
    ) -> str:
        """Upload a file to a category. Returns document SID."""
        await self._ensure_session()

        with open(file_path, "rb") as f:
            file_data = base64.b64encode(f.read()).decode("utf-8")

        class _ReqUpload(BaseModel):
            fileModel: dict[str, Any]

        data = _ReqUpload(
            fileModel={
                "fileData": file_data,
                "fileName": file_path.split("/")[-1],
                "SIDCategory": category_sid,
                "erpRelation": erp_relation,
                "erpProperty": erp_property,
            }
        )
        resp = await self.do_request(Endpoints.content_upload_extended, data)
        result = ResultActionModel(**resp)
        if result.result:
            return str(result.result)
        raise RequestError(result.message)

    async def search_content(
        self,
        field_values: list[dict] | None = None,
        date_values: list[dict] | None = None,
    ) -> ResSearch:
        """Search documents by field values."""
        await self._ensure_session()

        class _ReqSearch(BaseModel):
            fieldValues: list[dict] | None = None
            dateValues: list[dict] | None = None

        data = _ReqSearch(fieldValues=field_values, dateValues=date_values)
        resp = await self.do_request(Endpoints.content_search, data)
        return ResSearch.from_json(resp)

    async def create_category(self, parent_sid: str, name: str) -> str:
        """Create a subcategory. Returns new category SID."""
        await self._ensure_session()

        class _ReqCreate(BaseModel):
            parentSID: str
            name: str

        data = _ReqCreate(parentSID=parent_sid, name=name)
        resp = await self.do_request(Endpoints.content_create_category, data)
        result = ResultActionModel(**resp)
        if result.result:
            return str(result.result)
        raise RequestError(result.message)

    async def rename_category(self, sid: str, new_name: str) -> bool:
        """Rename a category. Returns True on success."""
        await self._ensure_session()

        class _ReqRename(BaseModel):
            SID: str
            name: str

        data = _ReqRename(SID=sid, name=new_name)
        resp = await self.do_request(Endpoints.content_rename_category, data)
        return bool(resp.get("result"))

    async def delete_category(self, sid: str) -> bool:
        """Delete a category. Returns True on success."""
        await self._ensure_session()

        class _ReqDelete(BaseModel):
            SID: str

        data = _ReqDelete(SID=sid)
        resp = await self.do_request(Endpoints.content_delete_category, data)
        return bool(resp.get("result"))

    async def check_dir_struct(
        self,
        root_sid: str,
        path_names: list[str],
        create_if_not_exist: bool = False,
        full_info: bool = True,
    ) -> list[dict] | dict | None:
        """
        Check or create a directory structure under a given root SID.

        Traverses the hierarchy level by level. For each level:
        1. Gets child categories via get_cat_info()
        2. Searches for a matching category by name
        3. If not found and create_if_not_exist=True, creates it

        Args:
            root_sid: The root SID to start from
            path_names: List of category names to traverse/create (e.g., ["2025", "PM-001"])
            create_if_not_exist: If True, create missing categories
            full_info: If True, returns full path info. If False, returns only last directory.

        Returns:
            List of dicts with keys: sid, parent_sid, name (one per level)
            OR single dict with sid, parent_sid, name (if full_info=False)
            None on error
        """
        results: list[dict] = []
        current_sid = root_sid

        try:
            for name in path_names:
                cat_info = await self.get_cat_info(current_sid)

                found_sid = None
                if cat_info and cat_info.CategoriasHijas:
                    for child in cat_info.CategoriasHijas:
                        if child.get("Nombre") == name:
                            found_sid = child.get("SID")
                            break

                if found_sid:
                    results.append({
                        "sid": found_sid,
                        "parent_sid": current_sid,
                        "name": name,
                    })
                    current_sid = found_sid
                elif create_if_not_exist:
                    new_sid = await self.create_category(current_sid, name)
                    if new_sid:
                        results.append({
                            "sid": new_sid,
                            "parent_sid": current_sid,
                            "name": name,
                        })
                        current_sid = new_sid
                    else:
                        return None
                else:
                    return None

            if full_info:
                return results
            else:
                # Return only the last directory
                return results[-1] if results else None

        except Exception:
            return None

    async def remove_document(self, sid: str) -> bool:
        """Remove a single document. Returns True on success."""
        await self._ensure_session()

        class _ReqSid(BaseModel):
            contenidoModel: dict[str, Any]

        data = _ReqSid(contenidoModel={"SIDContenido": sid})
        resp = await self.do_request(Endpoints.content_remove_document, data)
        return bool(resp.get("result"))

    async def move_content(self, content_sid: str, destination_sid: str) -> bool:
        """Move a document to another category. Returns True on success."""
        await self._ensure_session()

        class _ReqMove(BaseModel):
            contentSID: str
            destinationSID: str

        data = _ReqMove(contentSID=content_sid, destinationSID=destination_sid)
        resp = await self.do_request(Endpoints.content_move, data)
        return bool(resp.get("result"))

    async def update_content(
        self,
        sid: str,
        erp_relation: str = "",
        erp_property: str = "",
    ) -> str:
        """Update document metadata. Returns document SID."""
        await self._ensure_session()

        class _ReqUpdate(BaseModel):
            contentModel: dict[str, Any]

        data = _ReqUpdate(
            contentModel={"SID": sid, "RelacionGestion": erp_relation, "PropiedadGestion": erp_property}
        )
        resp = await self.do_request(Endpoints.content_update, data)
        result = resp.get("result")
        return str(result) if result else ""

    async def get_document(self, document_id: str) -> Document:
        """Retrieve a document by ID (deprecated, use download_content)."""
        result = await self.download_content(document_id)
        return Document(id=document_id, name=result.result.name)
