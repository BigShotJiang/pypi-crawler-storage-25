"""
Humanos API Client with automatic request signing.

This module provides a high-level client that wraps the generated SDK
and automatically signs all requests.
"""

from dataclasses import dataclass
from typing import Optional
import time

# Import from generated SDK
from humanos_sdk_generated import ApiClient, Configuration
from humanos_sdk_generated.api import RequestsApi, ResourceApi, UserApi

from .signature import generate_signature

# The API version this SDK release is pinned to (YYYY-MM-DD).
API_VERSION = "2026-03-24"

# Identifies this SDK's language in request headers.
SDK_LANGUAGE = "python"


@dataclass
class HumanosClientConfig:
    """Configuration for the Humanos API client."""

    base_path: str
    """Base URL for the Humanos API (e.g., https://api.humanos.id)"""

    api_key: str
    """Your API key from Humanos"""

    signature_secret: str
    """Your signature secret from Humanos"""

    verify_ssl: bool = True
    """Whether to verify SSL certificates (default: True)"""


class SignedApiClient(ApiClient):
    """
    API client that automatically signs all requests.

    Extends the generated ApiClient to add signature headers to every request.
    """

    def __init__(self, configuration: Configuration, signature_secret: str):
        super().__init__(configuration)
        self.signature_secret = signature_secret

    def call_api(
        self,
        method,
        url,
        header_params=None,
        body=None,
        post_params=None,
        _request_timeout=None,
        **kwargs
    ):
        """Override call_api to add signature headers."""
        if header_params is None:
            header_params = {}

        # Add Authorization header with API key
        if self.configuration.access_token:
            header_params["Authorization"] = f"Bearer {self.configuration.access_token}"

        # Generate signature
        timestamp = int(time.time() * 1000)
        signature = generate_signature(body, self.signature_secret, timestamp)

        # Add signature headers
        header_params["X-Timestamp"] = str(timestamp)
        header_params["X-Signature"] = signature

        # Add API version and SDK language headers
        header_params["api-version"] = API_VERSION
        header_params["X-SDK-Language"] = SDK_LANGUAGE

        return super().call_api(
            method,
            url,
            header_params=header_params,
            body=body,
            post_params=post_params,
            _request_timeout=_request_timeout,
            **kwargs
        )


class HumanosClient:
    """
    Humanos API Client with automatic request signing.

    All API requests made through this client automatically include
    the required X-Timestamp and X-Signature headers.

    Example:
        >>> client = HumanosClient(HumanosClientConfig(
        ...     base_path="https://api.humanos.id",
        ...     api_key="your-api-key",
        ...     signature_secret="your-signature-secret",
        ... ))
        >>>
        >>> # All requests are automatically signed
        >>> requests = client.requests.get_requests()
        >>> resources = client.resources.get_resources()
    """

    def __init__(self, config: HumanosClientConfig):
        """
        Initialize the Humanos client.

        Args:
            config: Client configuration with API key and secrets
        """
        self._config = config

        # Create API configuration
        api_config = Configuration(
            host=config.base_path,
            access_token=config.api_key,
        )
        api_config.verify_ssl = config.verify_ssl

        # Create signed API client
        self._api_client = SignedApiClient(api_config, config.signature_secret)

        # Initialize API instances
        self._requests = RequestsApi(self._api_client)
        self._resources = ResourceApi(self._api_client)
        self._users = UserApi(self._api_client)

    @property
    def requests(self) -> RequestsApi:
        """API for managing credential requests."""
        return self._requests

    @property
    def resources(self) -> ResourceApi:
        """API for managing resources (documents, consents, forms, products)."""
        return self._resources

    @property
    def users(self) -> UserApi:
        """API for managing users."""
        return self._users

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup resources."""
        self._api_client.close()


def create_humanos_client(config: HumanosClientConfig) -> HumanosClient:
    """
    Create a pre-configured Humanos client.

    Convenience function for creating a client with automatic signing.

    Example:
        >>> import os
        >>> client = create_humanos_client(HumanosClientConfig(
        ...     base_path=os.environ["HUMANOS_API_URL"],
        ...     api_key=os.environ["HUMANOS_API_KEY"],
        ...     signature_secret=os.environ["HUMANOS_SIGNATURE_SECRET"],
        ... ))
    """
    return HumanosClient(config)

