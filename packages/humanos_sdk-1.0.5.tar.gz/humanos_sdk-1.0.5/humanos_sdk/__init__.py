"""
Humanos SDK - Enhanced SDK with automatic signing and webhook utilities.

This package extends the auto-generated Humanos SDK with:
- Automatic request signing (HMAC-SHA256)
- Webhook signature verification
- Webhook payload decryption (AES-256-GCM)
- Framework-specific webhook handlers (Flask, FastAPI)

Example:
    >>> from humanos_sdk import HumanosClient, HumanosClientConfig
    >>>
    >>> client = HumanosClient(HumanosClientConfig(
    ...     base_path="https://api.humanos.id",
    ...     api_key="your-api-key",
    ...     signature_secret="your-signature-secret",
    ... ))
    >>>
    >>> # All requests are automatically signed
    >>> requests = client.requests.get_requests()
"""

# Re-export everything from the generated SDK
from humanos_sdk_generated import *

# Export client
from .client import (
    API_VERSION,
    SDK_LANGUAGE,
    HumanosClient,
    HumanosClientConfig,
    SignedApiClient,
    create_humanos_client,
)

# Export signature utilities
from .signature import (
    generate_signature,
    create_signed_headers,
    SignedSession,
)

# Export webhook utilities
from .webhooks import (
    WebhookConfig,
    EncryptedPayload,
    verify_webhook_signature,
    decrypt_webhook_payload,
    process_webhook,
    create_flask_webhook_handler,
    create_fastapi_webhook_handler,
)

__version__ = "1.0.0"

