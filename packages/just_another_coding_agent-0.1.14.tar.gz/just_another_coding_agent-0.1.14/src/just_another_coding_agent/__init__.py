"""just_another_coding_agent package."""

__all__ = ["__version__"]

__version__ = "0.1.14"
