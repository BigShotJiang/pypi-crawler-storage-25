from enum import Enum


class CombinedSearchCountBodyCompanyParamsEmployeeTrendsType0ObeysAnyType0ItemCountCriteriaType2Type(str, Enum):
    CURRENT_COUNT = "current_count"

    def __str__(self) -> str:
        return str(self.value)
