from enum import Enum


class CombinedSearchCountBodyCompanyParamsCrunchbaseCategoriesType0AllOfType0ItemType(str, Enum):
    CATEGORY = "category"

    def __str__(self) -> str:
        return str(self.value)
