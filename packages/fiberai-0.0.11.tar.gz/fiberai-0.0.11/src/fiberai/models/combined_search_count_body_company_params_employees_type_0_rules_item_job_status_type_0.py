from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.combined_search_count_body_company_params_employees_type_0_rules_item_job_status_type_0_status import (
    CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0Status,
)

T = TypeVar("T", bound="CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0")


@_attrs_define
class CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0:
    """
    Attributes:
        status (CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0Status):
    """

    status: CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0Status
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0Status(d.pop("status"))

        combined_search_count_body_company_params_employees_type_0_rules_item_job_status_type_0 = cls(
            status=status,
        )

        combined_search_count_body_company_params_employees_type_0_rules_item_job_status_type_0.additional_properties = d
        return combined_search_count_body_company_params_employees_type_0_rules_item_job_status_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
