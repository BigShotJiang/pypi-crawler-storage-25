from enum import IntEnum


class CombinedSearchCountBodyCompanyParamsEmployeeCountV2Type0UpperBoundInclusiveType3(IntEnum):
    VALUE_50 = 50

    def __str__(self) -> str:
        return str(self.value)
