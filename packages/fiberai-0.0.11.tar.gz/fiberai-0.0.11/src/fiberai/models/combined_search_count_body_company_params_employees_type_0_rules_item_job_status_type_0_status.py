from enum import Enum


class CombinedSearchCountBodyCompanyParamsEmployeesType0RulesItemJobStatusType0Status(str, Enum):
    CURRENTLY_EMPLOYED = "currently-employed"

    def __str__(self) -> str:
        return str(self.value)
