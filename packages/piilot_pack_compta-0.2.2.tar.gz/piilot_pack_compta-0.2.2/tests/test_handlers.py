"""Tests for ``compta.journal_paie_import``.

The handler stitches together parse → ensure_compta_kbs → upsert
parent + replace detail. Each dependency is mocked at the
``piilot_pack_compta.handlers`` module level so the test exercises
only the orchestration layer and the data shape — the parser has
its own suite, and the SDK primitives are unit-tested upstream.
"""

from __future__ import annotations

import base64
import io
from datetime import date
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from openpyxl import Workbook

from piilot_pack_compta.handlers import (
    _build_detail_rows,
    _num_cell,
    journal_paie_import,
)

MOD = "piilot_pack_compta.handlers"


# Shared fake column_id map for mocked _column_id_map calls. The values
# don't matter beyond being unique strings — the handler just threads
# them through kb_rows.data.
_PARENT_COL_IDS = {
    "period_start": "p-pstart",
    "period_end": "p-pend",
    "period_type": "p-ptype",
    "period_label": "p-plabel",
    "employees_count": "p-emp",
    "rubrics_count": "p-rub",
    "rows_count": "p-rc",
    "last_source_file": "p-src",
    "last_source_format": "p-fmt",
    "last_imported_at": "p-at",
}
_DETAIL_COL_IDS = {
    "employee_code": "d-ecode",
    "employee_name": "d-ename",
    "rubric_code": "d-rcode",
    "rubric_label": "d-rlabel",
    "base_salariale": "d-base",
    "montant_salarial": "d-ms",
    "montant_patronal": "d-mp",
    "is_subtotal": "d-sub",
    "row_order": "d-ord",
}


def _silae_bytes_single_employee() -> bytes:
    """Minimal SILAE-shaped workbook: 1 employee, 2 rubric lines."""
    wb = Workbook()
    ws = wb.active
    ws.title = "JP TEST"
    ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
    ws.cell(3, 3, "EMP1 Alice")
    ws.cell(5, 1, "R1")
    ws.cell(5, 2, "Salaire")
    ws.cell(5, 3, 1000)
    ws.cell(5, 4, 800)
    ws.cell(5, 5, 200)
    ws.cell(6, 2, "Sous-total")
    ws.cell(6, 3, 1000)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _ctx(company_id: str = "co-1", user_id: str = "user-1") -> SimpleNamespace:
    """Fake Context carrying company + user."""
    return SimpleNamespace(
        company=SimpleNamespace(id=company_id, name="Fake Co"),
        user=SimpleNamespace(id=user_id),
        logger=MagicMock(),
    )


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


# ---------------------------------------------------------------------------
# Error paths — reject before DB writes
# ---------------------------------------------------------------------------


class TestRejectBeforeWrites:
    def test_missing_file_b64(self):
        result = journal_paie_import(_ctx(), {})
        assert result["status"] == "error"
        assert "file_b64" in result["reason"]

    def test_unsupported_format(self):
        result = journal_paie_import(
            _ctx(),
            {"file_b64": _b64(b"data"), "source_format": "cegid"},
        )
        assert result["status"] == "error"
        assert "cegid" in result["reason"].lower()

    def test_no_company_in_context(self):
        ctx = SimpleNamespace(company=None, user=None, logger=MagicMock())
        result = journal_paie_import(ctx, {"file_b64": _b64(b"data")})
        assert result["status"] == "error"
        assert "company" in result["reason"].lower()

    def test_bad_base64(self):
        result = journal_paie_import(
            _ctx(),
            {"file_b64": "not-valid-base64!!!"},
        )
        assert result["status"] == "error"
        assert "base64" in result["reason"].lower()

    def test_parse_error_surfaces_message(self):
        # A plain text file isn't a valid xlsx — openpyxl raises, parser
        # wraps, handler returns it as user-facing reason.
        result = journal_paie_import(_ctx(), {"file_b64": _b64(b"not xlsx")})
        assert result["status"] == "error"
        assert result["reason"]


# ---------------------------------------------------------------------------
# Happy path — fresh import
# ---------------------------------------------------------------------------


class TestFreshImport:
    @patch(f"{MOD}.insert_batch", return_value=1)
    @patch(f"{MOD}.update_row")
    @patch(f"{MOD}.insert_row")
    @patch(f"{MOD}._delete_children_of")
    @patch(f"{MOD}._find_parent_row_id", return_value=None)
    @patch(f"{MOD}._column_id_map")
    @patch(f"{MOD}.ensure_compta_kbs")
    def test_end_to_end_shape(
        self,
        ensure_kbs,
        col_map,
        find_parent,
        delete_children,
        insert_row_fn,
        update_row_fn,
        insert_batch_fn,
    ):
        ensure_kbs.return_value = (
            {"id": "parent-uuid"},
            {"id": "detail-uuid"},
        )
        # _column_id_map is called twice: once per KB.
        col_map.side_effect = [_PARENT_COL_IDS, _DETAIL_COL_IDS]
        insert_row_fn.return_value = {"id": "new-parent-row-1"}

        result = journal_paie_import(
            _ctx(),
            {
                "file_b64": _b64(_silae_bytes_single_employee()),
                "file_name": "silae-march-2023.xlsx",
                "source_format": "silae",
            },
        )

        assert result["status"] == "ok"
        assert result["replaced_existing"] is False
        assert result["period_type"] == "mensuel"
        assert result["employees_count"] == 1
        assert result["rubrics_count"] == 1  # 1 rubric + 1 sous-total
        assert result["rows_inserted"] == 1
        # SDK 0.5.0 renamed ``parent_kb_id`` (legacy structural field) →
        # ``period_kb_id`` (the KB id holding the period parent rows).
        assert result["period_kb_id"] == "parent-uuid"
        assert "parent_kb_id" not in result
        assert result["detail_kb_id"] == "detail-uuid"
        assert result["parent_row_id"] == "new-parent-row-1"

        # No delete on a fresh import.
        delete_children.assert_not_called()
        # Parent row inserted with full metadata — keys are column UUIDs.
        insert_row_fn.assert_called_once()
        parent_data = insert_row_fn.call_args.args[1]
        assert parent_data[_PARENT_COL_IDS["period_type"]] == "mensuel"
        assert parent_data[_PARENT_COL_IDS["employees_count"]] == 1
        assert parent_data[_PARENT_COL_IDS["last_source_file"]] == "silae-march-2023.xlsx"
        assert parent_data[_PARENT_COL_IDS["last_source_format"]] == "silae"
        # Detail rows carry parent_row_id at the row level (kb_rows
        # column), NOT as a JSONB cell. The kb_ref navigation filters
        # children by kb_rows.parent_row_id.
        detail_rows = insert_batch_fn.call_args.args[1]
        assert all(r["parent_row_id"] == "new-parent-row-1" for r in detail_rows)


# ---------------------------------------------------------------------------
# Idempotent re-import — replaces detail rows
# ---------------------------------------------------------------------------


class TestReImport:
    @patch(f"{MOD}.insert_batch", return_value=2)
    @patch(f"{MOD}.update_row")
    @patch(f"{MOD}.insert_row")
    @patch(f"{MOD}._delete_children_of", return_value=5)
    @patch(f"{MOD}._find_parent_row_id", return_value="existing-parent-row")
    @patch(f"{MOD}._column_id_map")
    @patch(f"{MOD}.ensure_compta_kbs")
    def test_replaces_existing_period(
        self,
        ensure_kbs,
        col_map,
        find_parent,
        delete_children,
        insert_row_fn,
        update_row_fn,
        insert_batch_fn,
    ):
        ensure_kbs.return_value = (
            {"id": "parent-uuid"},
            {"id": "detail-uuid"},
        )
        col_map.side_effect = [_PARENT_COL_IDS, _DETAIL_COL_IDS]

        result = journal_paie_import(
            _ctx(),
            {"file_b64": _b64(_silae_bytes_single_employee())},
        )

        assert result["status"] == "ok"
        assert result["replaced_existing"] is True
        assert result["parent_row_id"] == "existing-parent-row"

        # Old detail rows wiped via the SQL FK column, not a JSONB cell.
        delete_children.assert_called_once_with(
            "detail-uuid",
            "existing-parent-row",
        )
        # No insert_row call (parent row already exists).
        insert_row_fn.assert_not_called()
        # update_row called at least once (initial metadata + rows_count patch).
        assert update_row_fn.call_count >= 1


# ---------------------------------------------------------------------------
# Detail row builder — data shape
# ---------------------------------------------------------------------------


class TestBuildDetailRows:
    def test_shape(self):
        from piilot_pack_compta.parsers.silae import (
            Employee,
            EmployeeValues,
            ParsedJournal,
            ParsedRow,
        )

        parsed = ParsedJournal(
            period_start=date(2023, 3, 1),
            period_end=date(2023, 3, 31),
            period_type="mensuel",
            period_label="Mars 2023",
            sheet_name="JP TEST",
            employees=[
                Employee(code="E1", name="Alice", col_base=3, col_salarial=4, col_patronal=5),
            ],
            rows=[
                ParsedRow(
                    row_order=1,
                    rubric_code="R1",
                    rubric_label="Salaire",
                    is_subtotal=False,
                    values={"E1": EmployeeValues(1000.0, 800.0, 200.0)},
                ),
                ParsedRow(
                    row_order=2,
                    rubric_code="",
                    rubric_label="Sous-total",
                    is_subtotal=True,
                    values={"E1": EmployeeValues(1000.0, None, None)},
                ),
            ],
        )

        rows = _build_detail_rows(parsed, "parent-uuid", _DETAIL_COL_IDS)

        assert len(rows) == 2
        first = rows[0]
        assert first["position"] == 0
        # parent_row_id is a row-level FK (kb_rows.parent_row_id), NOT
        # a JSONB cell — the kb_ref navigation reads it from there.
        assert first["parent_row_id"] == "parent-uuid"
        assert first["data"][_DETAIL_COL_IDS["employee_code"]] == "E1"
        assert first["data"][_DETAIL_COL_IDS["rubric_code"]] == "R1"
        assert first["data"][_DETAIL_COL_IDS["base_salariale"]] == "1000"
        assert first["data"][_DETAIL_COL_IDS["is_subtotal"]] == "false"
        assert first["data"][_DETAIL_COL_IDS["row_order"]] == 1

        second = rows[1]
        assert second["position"] == 1
        assert second["parent_row_id"] == "parent-uuid"
        assert second["data"][_DETAIL_COL_IDS["is_subtotal"]] == "true"
        assert second["data"][_DETAIL_COL_IDS["montant_salarial"]] == ""  # None → ""
        assert second["data"][_DETAIL_COL_IDS["montant_patronal"]] == ""


class TestNumCell:
    def test_none_is_empty_string(self):
        assert _num_cell(None) == ""

    def test_integer_renders_without_dot(self):
        assert _num_cell(100.0) == "100"
        assert _num_cell(0.0) == "0"

    def test_decimal_trimmed_trailing_zeros(self):
        assert _num_cell(1365.50) == "1365.5"
        assert _num_cell(3.1400) == "3.14"
