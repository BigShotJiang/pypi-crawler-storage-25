"""Smoke tests that prove the plugin boots correctly.

Minimal guarantees every plugin release must satisfy:

1. The plugin package imports without error.
2. The manifest loaded from ``pyproject.toml`` is valid against the
   Piilot SDK JSON Schema (namespace, sdk_compat, supported_modes, ...).
3. The ``Plugin.register(ctx)`` call wires the declared handler +
   locales without raising.
4. The ``compta.journal_paie_import`` handler returns the canonical
   stub shape before the real parser lands (guards the contract for
   the frontend that consumes it).

These run **without** a Piilot backend — we feed the plugin a fake
Context from ``conftest.py``.
"""

from __future__ import annotations

import importlib


def test_plugin_package_imports():
    """The plugin package is importable — basic syntactic smoke."""
    pkg = importlib.import_module("piilot_pack_compta")
    assert hasattr(pkg, "Plugin"), "The plugin package must expose a 'Plugin' class"


def test_manifest_valid():
    """The pyproject.toml manifest passes the SDK schema."""
    pkg = importlib.import_module("piilot_pack_compta")
    m = pkg.Plugin.manifest
    assert m["manifest_version"] == 1
    assert m["namespace"] == "compta"
    assert m["category"] == "finance"
    assert m["sdk_compat"].startswith(">=0.5")
    assert set(m["supported_modes"]) >= {"saas", "selfhosted"}
    assert set(m["supported_locales"]) >= {"fr", "en"}


def test_plugin_register_wires_handler(fake_ctx, plugin_context):
    """Plugin.register() runs to completion and registers the handler.

    The ``fake_ctx.handlers.register`` stub in conftest swallows the
    call; here we swap it for a recorder so the assertion is real.
    """
    pkg = importlib.import_module("piilot_pack_compta")
    plugin = pkg.Plugin()

    registered: list[tuple] = []
    fake_ctx.handlers.register = lambda hid, fn: registered.append((hid, fn))

    with plugin_context("compta"):
        plugin.register(fake_ctx)

    assert len(registered) == 1
    handler_id, fn = registered[0]
    assert handler_id == "compta.journal_paie_import"
    assert callable(fn)


def test_journal_paie_import_stub_shape(fake_ctx):
    """Until the real parser lands, the handler returns the documented
    error shape so the frontend can render it without surprises."""
    from piilot_pack_compta.handlers import journal_paie_import

    result = journal_paie_import(fake_ctx, {})
    assert result["status"] == "error"
    assert "reason" in result
    assert isinstance(result["reason"], str) and result["reason"]
