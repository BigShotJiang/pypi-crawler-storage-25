"""Tests for the SILAE xlsx payroll journal parser.

Two layers:

* **Pure unit tests** — build minimal in-memory workbooks with
  ``openpyxl.Workbook`` to exercise period detection, employee
  splitting, subtotal detection, value coercion, error paths.
* **Fixture run** — parses the real ``jp_silae_fixture.xlsx`` shipped
  with the repo (redacted export from a Piilot test tenant) and
  asserts the counts / period metadata.

The parser is pure (no DB, no SDK runtime dependency), so these
tests stay very fast and require no plugin context.
"""

from __future__ import annotations

import io
from datetime import date
from pathlib import Path

import pytest
from openpyxl import Workbook

from piilot_pack_compta.parsers.silae import (
    SilaeParseError,
    _classify_period,
    _is_subtotal,
    _split_employee_label,
    _to_float,
    parse,
)

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "jp_silae_fixture.xlsx"


def _xlsx_bytes(build) -> bytes:
    """Helper — build a Workbook via callback and return its bytes."""
    wb = Workbook()
    ws = wb.active
    ws.title = "JP TEST"
    build(ws)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Stage 1 — sheet + period detection
# ---------------------------------------------------------------------------


class TestPeriodDetection:
    def test_monthly_period(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "EMP1 Alice")
            ws.cell(5, 1, "CODE")
            ws.cell(5, 2, "Label")
            ws.cell(5, 3, 100)

        j = parse(_xlsx_bytes(build))
        assert j.period_start == date(2023, 3, 1)
        assert j.period_end == date(2023, 3, 31)
        assert j.period_type == "mensuel"

    def test_annual_cumulative_period(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De janvier 2023 à décembre 2023")
            ws.cell(3, 3, "EMP1 Alice")
            ws.cell(5, 1, "CODE")
            ws.cell(5, 2, "Label")

        j = parse(_xlsx_bytes(build))
        assert j.period_start == date(2023, 1, 1)
        assert j.period_end == date(2023, 12, 31)
        assert j.period_type == "annuel"

    def test_custom_range_is_autre(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De avril 2023 à juin 2023")
            ws.cell(3, 3, "EMP1 Alice")
            ws.cell(5, 1, "CODE")
            ws.cell(5, 2, "Label")

        j = parse(_xlsx_bytes(build))
        assert j.period_type == "autre"

    def test_period_label_kept_verbatim(self):
        label = "Récapitulatif de paie détaillé - De mars 2024 à mars 2024"

        def build(ws):
            ws.cell(1, 1, label)
            ws.cell(3, 3, "EMP1 Alice")
            ws.cell(5, 1, "CODE")
            ws.cell(5, 2, "Label")

        j = parse(_xlsx_bytes(build))
        assert j.period_label == label

    def test_missing_period_raises(self):
        def build(ws):
            ws.cell(1, 1, "Wrong header")
            ws.cell(3, 3, "EMP1 Alice")

        with pytest.raises(SilaeParseError, match="Période illisible"):
            parse(_xlsx_bytes(build))

    def test_empty_a1_raises(self):
        def build(ws):
            ws.cell(3, 3, "EMP1 Alice")

        with pytest.raises(SilaeParseError, match="A1 ne contient"):
            parse(_xlsx_bytes(build))

    def test_unknown_month_raises(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De foobar 2023 à mars 2023")
            ws.cell(3, 3, "EMP1 Alice")

        with pytest.raises(SilaeParseError, match="Mois non reconnu"):
            parse(_xlsx_bytes(build))


# ---------------------------------------------------------------------------
# Stage 2 — employee extraction
# ---------------------------------------------------------------------------


class TestEmployees:
    def test_single_employee(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "ABELANGE ABELLARD ANGELIQUE")
            ws.cell(5, 1, "CODE")
            ws.cell(5, 2, "Label")

        j = parse(_xlsx_bytes(build))
        assert len(j.employees) == 1
        emp = j.employees[0]
        assert emp.code == "ABELANGE"
        assert emp.name == "ABELLARD ANGELIQUE"
        assert emp.col_base == 3
        assert emp.col_salarial == 4
        assert emp.col_patronal == 5

    def test_multiple_employees_in_triplets(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "EMP1 Alice Martin")
            ws.cell(3, 6, "EMP2 Bob Dupont")
            ws.cell(3, 9, "EMP3 Charlie N'Diaye")
            ws.cell(5, 1, "CODE")
            ws.cell(5, 2, "Label")

        j = parse(_xlsx_bytes(build))
        assert [e.code for e in j.employees] == ["EMP1", "EMP2", "EMP3"]
        assert j.employees[2].col_base == 9

    def test_no_employees_raises(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            # no row 3 content

        with pytest.raises(SilaeParseError, match="Aucun salarié"):
            parse(_xlsx_bytes(build))

    def test_split_employee_label(self):
        assert _split_employee_label("ABEL ANG") == ("ABEL", "ANG")
        assert _split_employee_label("FOO BAR BAZ") == ("FOO", "BAR BAZ")
        assert _split_employee_label("SINGLETON") == ("SINGLETON", "")


# ---------------------------------------------------------------------------
# Stage 3 — rows, subtotals, values
# ---------------------------------------------------------------------------


class TestRows:
    def test_values_captured_per_employee(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "E1 Alice")
            ws.cell(3, 6, "E2 Bob")
            ws.cell(5, 1, "RUB1")
            ws.cell(5, 2, "Salaire de base")
            ws.cell(5, 3, 1365)  # base E1
            ws.cell(5, 4, 15475.66)  # salarial E1
            # patronal E1 empty
            ws.cell(5, 6, 1820.04)  # base E2
            ws.cell(5, 7, 28165.2)  # salarial E2
            ws.cell(5, 8, 300.0)  # patronal E2

        j = parse(_xlsx_bytes(build))
        assert len(j.rows) == 1
        row = j.rows[0]
        assert row.rubric_code == "RUB1"
        assert row.rubric_label == "Salaire de base"
        assert row.is_subtotal is False
        assert row.values["E1"].base_salariale == 1365.0
        assert row.values["E1"].montant_salarial == 15475.66
        assert row.values["E1"].montant_patronal is None
        assert row.values["E2"].montant_patronal == 300.0

    def test_subtotal_detection(self):
        assert _is_subtotal("Sous-total Salaire de base") is True
        assert _is_subtotal("SOUS-TOTAL RUBRIQUES") is True
        assert _is_subtotal("sous total heures") is True
        assert _is_subtotal("Sous-totaux Cotisations") is True
        assert _is_subtotal("Salaire de base") is False
        assert _is_subtotal("") is False

    def test_subtotal_row_flagged(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "E1 Alice")
            ws.cell(5, 1, "")
            ws.cell(5, 2, "Sous-total Salaire de base")
            ws.cell(5, 3, 1365)

        j = parse(_xlsx_bytes(build))
        assert j.rows[0].is_subtotal is True
        assert j.rubrics_count == 0

    def test_rubrics_count_excludes_subtotals(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "E1 Alice")
            ws.cell(5, 1, "R1")
            ws.cell(5, 2, "Salaire")
            ws.cell(5, 3, 100)
            ws.cell(6, 2, "Sous-total")
            ws.cell(6, 3, 100)
            ws.cell(7, 1, "R2")
            ws.cell(7, 2, "Prime")
            ws.cell(7, 3, 50)

        j = parse(_xlsx_bytes(build))
        assert len(j.rows) == 3
        assert j.rubrics_count == 2  # R1 + R2

    def test_empty_row_skipped(self):
        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "E1 Alice")
            ws.cell(5, 1, "R1")
            ws.cell(5, 2, "Salaire")
            ws.cell(5, 3, 100)
            # row 6 entirely blank
            ws.cell(7, 1, "R2")
            ws.cell(7, 2, "Prime")
            ws.cell(7, 3, 50)

        j = parse(_xlsx_bytes(build))
        assert len(j.rows) == 2
        assert j.rows[0].rubric_code == "R1"
        assert j.rows[1].rubric_code == "R2"
        # row_order is sequential among emitted rows
        assert j.rows[0].row_order == 1
        assert j.rows[1].row_order == 2

    def test_row_without_any_values_still_emitted(self):
        """Rubric line with a label but zero values for every employee
        stays in the output (it's a meaningful "0 everywhere" line)."""

        def build(ws):
            ws.cell(1, 1, "Récapitulatif de paie détaillé - De mars 2023 à mars 2023")
            ws.cell(3, 3, "E1 Alice")
            ws.cell(5, 1, "HS25")
            ws.cell(5, 2, "Heures supplémentaires 25%")
            # no values in cols 3/4/5

        j = parse(_xlsx_bytes(build))
        assert len(j.rows) == 1
        assert j.rows[0].rubric_code == "HS25"
        assert j.rows[0].values == {}


# ---------------------------------------------------------------------------
# Stage 4 — helpers (pure)
# ---------------------------------------------------------------------------


class TestHelpers:
    @pytest.mark.parametrize(
        "y1,m1,y2,m2,expected",
        [
            (2023, 3, 2023, 3, "mensuel"),
            (2023, 1, 2023, 12, "annuel"),
            (2023, 4, 2023, 6, "autre"),
            (2023, 6, 2024, 5, "autre"),
        ],
    )
    def test_classify_period(self, y1, m1, y2, m2, expected):
        assert _classify_period(y1, m1, y2, m2) == expected

    def test_to_float_numeric(self):
        assert _to_float(42) == 42.0
        assert _to_float(3.14) == 3.14

    def test_to_float_string_fr(self):
        assert _to_float("1 365,50") == 1365.50
        assert _to_float(" 100 ") == 100.0

    def test_to_float_nonsense(self):
        assert _to_float(None) is None
        assert _to_float("") is None
        assert _to_float("  ") is None
        assert _to_float("abc") is None

    def test_to_float_zero(self):
        assert _to_float(0) == 0.0
        assert _to_float("0") == 0.0


# ---------------------------------------------------------------------------
# Stage 5 — end-to-end parse of the real SILAE fixture
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not FIXTURE_PATH.exists(), reason="fixture xlsx missing")
class TestRealFixture:
    """Anchor test against the real SILAE export (108 employees, 2023 annual)."""

    def test_period_is_annual_2023(self):
        data = FIXTURE_PATH.read_bytes()
        j = parse(data)
        assert j.period_type == "annuel"
        assert j.period_start == date(2023, 1, 1)
        assert j.period_end == date(2023, 12, 31)
        assert j.sheet_name.upper().startswith("JP")

    def test_employees_detected(self):
        data = FIXTURE_PATH.read_bytes()
        j = parse(data)
        # 326 columns → (326-2)/3 = 108 employees expected.
        assert j.employees_count == 108
        # First employee from our manual exploration.
        codes = [e.code for e in j.employees]
        assert "ABELANGE" in codes

    def test_rows_and_subtotals_detected(self):
        data = FIXTURE_PATH.read_bytes()
        j = parse(data)
        # The export has hundreds of rubric + subtotal lines — we only
        # assert the sanity invariants, not exact counts (which could
        # drift on a future fixture refresh).
        assert len(j.rows) > 50
        assert 0 < j.rubrics_count < len(j.rows)
        subtotals = [r for r in j.rows if r.is_subtotal]
        assert len(subtotals) > 0, "SILAE always ships subtotals"
