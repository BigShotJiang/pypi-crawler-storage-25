"""Tests for the plugin's KB seeding logic.

``ensure_compta_kbs`` must be fully idempotent: the first call
creates 2 KBs + 22 columns, every subsequent call is a no-op beyond
the two ``find_kb`` lookups. We exercise the happy path and both
edge cases (parent exists / detail missing, and vice-versa).

Mocks are applied at the module-attribute level of
``piilot_pack_compta.kb_seed`` so the closures defined there (``find_kb``,
``create_kb``, ``add_column`` imported with ``from X import Y``) pick
up the patched callable on every lookup.
"""

from __future__ import annotations

from unittest.mock import patch

from piilot_pack_compta.kb_seed import (
    KB_DETAIL_NAME,
    KB_PARENT_NAME,
    ensure_compta_kbs,
)

MOD = "piilot_pack_compta.kb_seed"


def _parent_row() -> dict:
    return {
        "id": "parent-uuid-111",
        "name": KB_PARENT_NAME,
        "owner_type": "plugin",
        "owner_ref": "compta",
        "schema_locked": True,
    }


def _detail_row() -> dict:
    return {
        "id": "detail-uuid-222",
        "name": KB_DETAIL_NAME,
        "owner_type": "plugin",
        "owner_ref": "compta",
        "schema_locked": True,
    }


class TestFirstCall:
    """Cold cache — neither KB exists yet; both get created + columns seeded."""

    @patch(f"{MOD}._has_kbref_to_detail", return_value=False)
    @patch(f"{MOD}.add_column")
    @patch(f"{MOD}.create_kb")
    @patch(f"{MOD}.find_kb", return_value=None)
    def test_creates_both_kbs(self, find_kb, create_kb, add_column, has_kbref):
        create_kb.side_effect = [_parent_row(), _detail_row()]

        parent, detail = ensure_compta_kbs("company-1")

        assert parent["id"] == "parent-uuid-111"
        assert detail["id"] == "detail-uuid-222"

        # find_kb hit twice: once per KB, both miss
        assert find_kb.call_count == 2
        # create_kb hit twice, in the right order
        assert create_kb.call_count == 2
        first_call, second_call = create_kb.call_args_list
        assert first_call.kwargs["name"] == KB_PARENT_NAME
        assert first_call.kwargs["company_id"] == "company-1"
        assert first_call.kwargs["schema_locked"] is True
        assert second_call.kwargs["name"] == KB_DETAIL_NAME
        # SDK 0.5.0 dropped the structural parent_kb_id parameter — the
        # parent ↔ child relationship is now expressed solely by the
        # ``detail`` kb_ref column on the parent (asserted below).
        assert "parent_kb_id" not in second_call.kwargs
        # 10 parent cols + 9 detail cols + 1 kb_ref on the parent
        # (appended after the 10 business cols) = 20 add_column calls.
        assert add_column.call_count == 20

    @patch(f"{MOD}._has_kbref_to_detail", return_value=False)
    @patch(f"{MOD}.add_column")
    @patch(f"{MOD}.create_kb")
    @patch(f"{MOD}.find_kb", return_value=None)
    def test_kb_ref_column_points_at_detail(self, find_kb, create_kb, add_column, has_kbref):
        create_kb.side_effect = [_parent_row(), _detail_row()]

        ensure_compta_kbs("company-1")

        # The single kb_ref column lives on the PARENT, pointing at the
        # detail KB (so clicking the cell filters the detail KB by
        # the parent row's kb_rows.id).
        kb_ref_calls = [
            c for c in add_column.call_args_list if c.kwargs.get("column_type") == "kb_ref"
        ]
        assert len(kb_ref_calls) == 1
        spec = kb_ref_calls[0].kwargs
        assert spec["name"] == "detail"
        assert spec["config"] == {"target_kb_id": "detail-uuid-222"}
        # The kb_ref column is the 11th (position=10) on the parent —
        # appended after the 10 business cols.
        assert spec["position"] == 10
        # It's added on the parent kb_id (1st positional arg).
        assert kb_ref_calls[0].args[0] == "parent-uuid-111"

    @patch(f"{MOD}._has_kbref_to_detail", return_value=False)
    @patch(f"{MOD}.add_column")
    @patch(f"{MOD}.create_kb")
    @patch(f"{MOD}.find_kb", return_value=None)
    def test_columns_are_positioned_in_order(self, find_kb, create_kb, add_column, has_kbref):
        create_kb.side_effect = [_parent_row(), _detail_row()]

        ensure_compta_kbs("company-1")

        # Order: 10 parent business cols, 9 detail cols, 1 parent kb_ref.
        parent_cols = add_column.call_args_list[:10]
        detail_cols = add_column.call_args_list[10:19]
        parent_kbref = add_column.call_args_list[19]

        for idx, call in enumerate(parent_cols):
            assert (
                call.kwargs["position"] == idx
            ), f"parent col #{idx} has wrong position {call.kwargs['position']}"
        for idx, call in enumerate(detail_cols):
            assert (
                call.kwargs["position"] == idx
            ), f"detail col #{idx} has wrong position {call.kwargs['position']}"
        assert parent_kbref.kwargs["position"] == 10


class TestWarmCache:
    """Both KBs already exist — pure idempotency run."""

    @patch(f"{MOD}._has_kbref_to_detail", return_value=True)
    @patch(f"{MOD}.add_column")
    @patch(f"{MOD}.create_kb")
    @patch(f"{MOD}.find_kb")
    def test_no_create_no_add_column(
        self,
        find_kb,
        create_kb,
        add_column,
        has_kbref,
    ):
        find_kb.side_effect = [_parent_row(), _detail_row()]

        parent, detail = ensure_compta_kbs("company-1")

        assert parent["id"] == "parent-uuid-111"
        assert detail["id"] == "detail-uuid-222"
        create_kb.assert_not_called()
        add_column.assert_not_called()
        # The kb_ref guard is still consulted (it's the self-heal path).
        has_kbref.assert_called_once_with("parent-uuid-111", "detail-uuid-222")

    @patch(f"{MOD}._has_kbref_to_detail", return_value=False)
    @patch(f"{MOD}.add_column")
    @patch(f"{MOD}.create_kb")
    @patch(f"{MOD}.find_kb")
    def test_warm_cache_but_missing_kbref_self_heals(
        self,
        find_kb,
        create_kb,
        add_column,
        has_kbref,
    ):
        """Earlier crash left the two KBs present but without the
        parent's kb_ref column — the next call must re-add it without
        re-creating KBs or re-seeding business columns."""
        find_kb.side_effect = [_parent_row(), _detail_row()]

        ensure_compta_kbs("company-1")

        create_kb.assert_not_called()
        # Only the kb_ref column gets added back.
        add_column.assert_called_once()
        kwargs = add_column.call_args.kwargs
        assert kwargs["column_type"] == "kb_ref"
        assert kwargs["config"] == {"target_kb_id": "detail-uuid-222"}


class TestPartialCache:
    """Parent exists, detail is missing — only the detail half gets seeded."""

    @patch(f"{MOD}._has_kbref_to_detail", return_value=False)
    @patch(f"{MOD}.add_column")
    @patch(f"{MOD}.create_kb")
    @patch(f"{MOD}.find_kb")
    def test_parent_exists_detail_missing(self, find_kb, create_kb, add_column, has_kbref):
        find_kb.side_effect = [_parent_row(), None]
        create_kb.return_value = _detail_row()

        ensure_compta_kbs("company-1")

        # Only detail was created. SDK 0.5.0 doesn't pass parent_kb_id
        # any more — the parent ↔ child link goes through the kb_ref
        # column added below.
        create_kb.assert_called_once()
        assert create_kb.call_args.kwargs["name"] == KB_DETAIL_NAME
        assert "parent_kb_id" not in create_kb.call_args.kwargs
        # 9 detail business cols + 1 kb_ref column on the parent.
        assert add_column.call_count == 10
        # The kb_ref lives on the parent, pointing at the freshly created detail.
        kb_ref_calls = [
            c for c in add_column.call_args_list if c.kwargs.get("column_type") == "kb_ref"
        ]
        assert len(kb_ref_calls) == 1
        assert kb_ref_calls[0].args[0] == "parent-uuid-111"
        assert kb_ref_calls[0].kwargs["config"] == {"target_kb_id": "detail-uuid-222"}


class TestColumnSpec:
    """Sanity — the specs match the documented SPEC."""

    def test_parent_has_10_columns_detail_has_9_columns(self):
        from piilot_pack_compta.kb_seed import (
            _DETAIL_COLUMN_SPECS,
            _PARENT_COLUMN_SPECS,
        )

        # Parent: 10 business cols (kb_ref appended separately).
        assert len(_PARENT_COLUMN_SPECS) == 10
        # Detail: 9 cols — no period_ref (linkage via parent_row_id)
        # and no period_label (dedup with parent).
        assert len(_DETAIL_COLUMN_SPECS) == 9

    def test_detail_first_column_is_employee_code(self):
        from piilot_pack_compta.kb_seed import _DETAIL_COLUMN_SPECS

        assert _DETAIL_COLUMN_SPECS[0]["name"] == "employee_code"

    def test_last_imported_at_is_date_type(self):
        from piilot_pack_compta.kb_seed import _PARENT_COLUMN_SPECS

        col = next(c for c in _PARENT_COLUMN_SPECS if c["name"] == "last_imported_at")
        assert col["column_type"] == "date"

    def test_neither_spec_contains_kb_ref(self):
        """The kb_ref column is appended post-seed by
        _seed_parent_detail_kbref, not declared in the spec lists."""
        from piilot_pack_compta.kb_seed import (
            _DETAIL_COLUMN_SPECS,
            _PARENT_COLUMN_SPECS,
        )

        all_types = [c["column_type"] for c in _PARENT_COLUMN_SPECS + _DETAIL_COLUMN_SPECS]
        assert "kb_ref" not in all_types
