"""Protected knowledge bases seeded by the ``piilot-pack-compta`` plugin.

Two KBs, both ``owner_type='plugin'`` + ``owner_ref='compta'``,
``schema_locked=true``. Their structure is frozen: bulk import, rename
and column CRUD are refused by the core API (HTTP 423 Locked). Cell
edits and single-row CRUD remain available to end users.

The parent↔child relationship is expressed by a ``kb_ref`` column on
the parent KB (``detail`` column → detail KB). Clicking the cell in
the UI pushes a navigation entry that filters the detail KB to rows
whose row-level ``parent_row_id`` matches. SDK 0.5.0 dropped the
legacy ``parent_kb_id`` structural FK; ``kb_ref`` is now the single
source of truth for the relationship.

Seeding is **lazy and idempotent**: the first call to
``ensure_compta_kbs(company_id)`` creates the two KBs plus their 22
locked columns; every subsequent call returns the existing rows via
:func:`piilot.sdk.knowledge.find_kb`, backed by the partial index
``idx_kb_plugin_owner`` added in core migration ``087_kb_plugin_owned``.
"""

from __future__ import annotations

from typing import Any

from piilot.sdk.db import cursor
from piilot.sdk.knowledge import add_column, create_kb, find_kb

# -- Canonical names of the two KBs ------------------------------------------
# Used as the idempotency key alongside ``(owner_type, owner_ref,
# organization_id)``. Changing these after a release means every active
# company has a "ghost" legacy KB on the old name — don't rename lightly.

KB_PARENT_NAME = "Journal de paie — Périodes"
KB_DETAIL_NAME = "Journal de paie — Détail"


# -- Column specs ------------------------------------------------------------
# ``position`` is significant: it drives the UI column order. The core
# refuses reordering on ``schema_locked=true`` KBs, so this is the
# authoritative layout.
#
# ``column_type`` must be one of {'text', 'numeric', 'date', 'file',
# 'kb_ref'} per the ``kb_columns.column_type`` CHECK constraint.
# ``file`` and ``kb_ref`` carry extra config on the column row — file
# is not used here (plugins don't persist user-uploaded files in v0.1),
# and ``kb_ref`` needs ``config={"target_kb_id": <parent_uuid>}`` which
# we patch in at runtime once the parent KB id is known.

_PARENT_COLUMN_SPECS: list[dict[str, Any]] = [
    {
        "name": "period_start",
        "column_type": "date",
        "description": "Premier jour couvert par cet import (inclus).",
    },
    {
        "name": "period_end",
        "column_type": "date",
        "description": "Dernier jour couvert par cet import (inclus).",
    },
    {
        "name": "period_type",
        "column_type": "text",
        "description": "Granularité couverte : 'annuel', 'mensuel' ou 'autre'.",
    },
    {
        "name": "period_label",
        "column_type": "text",
        "description": "Libellé humain de la période (ex. 'Mars 2023', '2023 (cumul annuel)').",
    },
    {
        "name": "employees_count",
        "column_type": "numeric",
        "description": "Nombre de salariés distincts détectés dans ce fichier.",
    },
    {
        "name": "rubrics_count",
        "column_type": "numeric",
        "description": "Nombre de rubriques distinctes (hors sous-totaux).",
    },
    {
        "name": "rows_count",
        "column_type": "numeric",
        "description": "Nombre total de lignes écrites dans la KB détail pour cette période.",
    },
    {
        "name": "last_source_file",
        "column_type": "text",
        "description": "Nom du dernier fichier importé (audit ; le xlsx n'est pas conservé).",
    },
    {
        "name": "last_source_format",
        "column_type": "text",
        "description": "Format du dernier import ('silae' pour la v0.1).",
    },
    {
        "name": "last_imported_at",
        "column_type": "date",
        "description": "Date du dernier import (ISO-8601, journée uniquement).",
    },
]


_DETAIL_COLUMN_SPECS: list[dict[str, Any]] = [
    {
        "name": "employee_code",
        "column_type": "text",
        "description": "Matricule SILAE du salarié (premier token du nom en ligne 3 de l'export).",
    },
    {
        "name": "employee_name",
        "column_type": "text",
        "description": "Nom + prénom du salarié (tokens restants de la ligne 3 de l'export).",
    },
    {
        "name": "rubric_code",
        "column_type": "text",
        "description": "Code rubrique (peut être vide pour les rubriques sans code explicite).",
    },
    {
        "name": "rubric_label",
        "column_type": "text",
        "description": "Libellé de la rubrique (colonne B de l'export SILAE).",
    },
    {
        "name": "base_salariale",
        "column_type": "numeric",
        "description": "Base de calcul salariale (1re colonne du triplet salarié dans l'export).",
    },
    {
        "name": "montant_salarial",
        "column_type": "numeric",
        "description": "Montant part salariale (2e colonne du triplet salarié dans l'export).",
    },
    {
        "name": "montant_patronal",
        "column_type": "numeric",
        "description": "Montant part patronale (3e colonne du triplet salarié dans l'export).",
    },
    {
        "name": "is_subtotal",
        "column_type": "text",
        "description": "'true' pour une ligne de sous-total SILAE, 'false' pour une rubrique.",
    },
    {
        "name": "row_order",
        "column_type": "numeric",
        "description": "Position de la ligne dans l'export source (pour restitution ordonnée).",
    },
]


def _seed_columns(kb_id: str, specs: list[dict[str, Any]]) -> None:
    """Insert every column spec on ``kb_id`` in order."""
    for position, spec in enumerate(specs):
        add_column(
            kb_id,
            name=spec["name"],
            column_type=spec["column_type"],
            description=spec["description"],
            position=position,
            is_required=False,
        )


_PARENT_KBREF_COLUMN_NAME = "detail"


def _has_kbref_to_detail(parent_kb_id: str, detail_kb_id: str) -> bool:
    """Return True if the parent KB already carries the ``detail`` kb_ref
    column pointing at ``detail_kb_id``.

    Checked at every ``ensure_compta_kbs`` call so the setup self-heals
    even if a previous run crashed mid-seed (or if the column was
    created then dropped outside the plugin).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT config FROM public.kb_columns "
            "WHERE kb_id = %s AND name = %s AND column_type = 'kb_ref' "
            "LIMIT 1",
            (parent_kb_id, _PARENT_KBREF_COLUMN_NAME),
        )
        row = cur.fetchone()
    if row is None:
        return False
    config = row["config"] or {}
    return config.get("target_kb_id") == detail_kb_id


def _seed_parent_detail_kbref(parent_kb_id: str, detail_kb_id: str, position: int) -> None:
    """Append a ``kb_ref`` column to the parent KB pointing at ``detail_kb_id``.

    Done *after* both KBs exist so ``config.target_kb_id`` has a real
    id. The frontend reads this column as a navigation link: clicking
    the cell pushes a ``kb_ref`` entry on the nav stack with
    ``parentRowId = row.id``, which then filters the detail KB rows to
    those whose ``kb_rows.parent_row_id`` matches. No value is stored
    in the parent cell itself; the link is purely structural.

    Idempotent: no-op if a ``detail`` kb_ref column already points at
    the right detail KB (see :func:`_has_kbref_to_detail`).
    """
    if _has_kbref_to_detail(parent_kb_id, detail_kb_id):
        return
    add_column(
        parent_kb_id,
        name=_PARENT_KBREF_COLUMN_NAME,
        column_type="kb_ref",
        description=(
            "Lignes détail associées à cette période. "
            "Cliquez la cellule pour voir les lignes (salarié × rubrique) "
            "filtrées par cette période."
        ),
        position=position,
        is_required=False,
        config={"target_kb_id": detail_kb_id},
    )


def ensure_compta_kbs(company_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Idempotently materialize the two compta KBs for ``company_id``.

    Returns ``(parent_kb, detail_kb)``. Safe to call from every import
    invocation — ``find_kb`` short-circuits when the rows already
    exist (indexed lookup on ``(organization_id, owner_type='plugin',
    owner_ref='compta', name=...)``).

    Must be called from a plugin context (``current_plugin.get()``
    resolves to ``'compta'``) because ``create_kb`` stamps
    ``owner_ref`` from the contextvar — the handler that wraps the
    module call already sets it for us.
    """
    parent = find_kb(company_id=company_id, name=KB_PARENT_NAME)
    detail = find_kb(company_id=company_id, name=KB_DETAIL_NAME)

    if parent is None:
        parent = create_kb(
            company_id=company_id,
            name=KB_PARENT_NAME,
            description=(
                "Une ligne par période couverte par un import de journal de paie. "
                "Nom, description et colonnes figés par le plugin compta. "
                "Import de masse désactivé — utilisez le module dédié « Import Journal de paie »."
            ),
            schema_locked=True,
        )
        _seed_columns(parent["id"], _PARENT_COLUMN_SPECS)

    if detail is None:
        detail = create_kb(
            company_id=company_id,
            name=KB_DETAIL_NAME,
            description=(
                "Lignes détail (salarié × rubrique) d'un import SILAE. "
                "Accessibles depuis la base « Journal de paie — Périodes » : cliquez "
                "sur la cellule « detail » d'une période pour afficher les lignes filtrées. "
                "Édition cellule par cellule possible ; import de masse désactivé."
            ),
            schema_locked=True,
        )
        _seed_columns(detail["id"], _DETAIL_COLUMN_SPECS)

    # Ensure the kb_ref column on the parent always exists and points
    # at the right detail KB. Idempotent by itself — runs even when
    # both KBs were already present from an earlier install that
    # crashed mid-seed.
    _seed_parent_detail_kbref(
        parent_kb_id=parent["id"],
        detail_kb_id=detail["id"],
        position=len(_PARENT_COLUMN_SPECS),
    )

    return parent, detail
