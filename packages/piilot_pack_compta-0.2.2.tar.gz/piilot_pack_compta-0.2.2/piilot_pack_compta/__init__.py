"""Piilot plugin ``compta`` — expert-comptable tooling.

Entry point referenced by ``[project.entry-points."piilot.plugins"]``
in ``pyproject.toml``. Instantiated once at Piilot backend startup.

v0.1 surface
============

* **1 module** — ``compta.journal_paie_import`` — the "Import Journal
  de paie" surface. Handler parses a SILAE ``.xlsx`` cumulative or
  monthly payroll export and feeds two plugin-owned KBs.
* **2 protected KBs per tenant** — seeded lazily on the first import:
  "Journal de paie — Périodes" (parent, one row per covered period)
  and "Journal de paie — Détail" (child, one row per period × employee
  × rubric). See :mod:`piilot_pack_compta.kb_seed`.
* **i18n** — FR + EN catalogs under the ``compta`` namespace.

Roadmap (not in v0.1)
=====================

* Agent templates — an "Assistant paie" that queries the KB parent ↔
  child via ``kb_ref`` navigation.
* Additional KBs (plan comptable, FEC, balance) + matching import
  modules (Sage, Cegid, Nibelis parsers).
* Connector to an accounting API for automatic nightly sync.
"""

from __future__ import annotations

from piilot.sdk import Plugin as _Plugin
from piilot.sdk import load_manifest

from .handlers import journal_paie_import
from .routes import wire_routes
from .seeds import wire_seeds


class Plugin(_Plugin):
    """Plugin entry class — must subclass :class:`piilot.sdk.Plugin`."""

    manifest = load_manifest(__file__)

    def register(self, ctx) -> None:
        """Wire i18n, module catalog row, handler and HTTP routes.

        The two KBs are **not** seeded here — ``register()`` is called
        at backend boot without a company context. KB seeding is lazy:
        the first ``compta.journal_paie_import`` invocation for a
        company materializes them via ``kb_seed.ensure_compta_kbs``.
        """
        ctx.i18n.register_locales("compta", __file__, "locales")
        ctx.handlers.register("compta.journal_paie_import", journal_paie_import)
        # Upsert the ``modules.modules`` catalog row so the module
        # appears in /modules/ for every company that activates the
        # plugin. Idempotent (ON CONFLICT DO UPDATE on module_slug).
        wire_seeds()
        # Mount /plugins/compta/import/journal-paie — direct multipart
        # upload path, bypasses /modules/{id}/run's 64 KB input cap.
        wire_routes()
