"""HTTP routes exposed by the ``compta`` plugin.

Mounted under ``/plugins/compta/*`` by the core loader. The frontend
module view POSTs directly to these endpoints (they bypass the
generic ``/modules/{id}/run`` path because the xlsx upload exceeds
the 64 KB ``input_data`` cap on module runs).

v0.1 surface:

* ``POST /plugins/compta/import/journal-paie`` — multipart upload of
  a SILAE ``.xlsx`` payroll journal. Parses + feeds the plugin's
  two protected KBs. Returns the handler's ``{"status": "ok", ...}``
  / ``{"status": "error", "reason": ...}`` dict verbatim.
"""

from __future__ import annotations

import base64
from types import SimpleNamespace

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from piilot.sdk.http import require_user

from .handlers import journal_paie_import

router = APIRouter()


# SILAE exports routinely weigh 200-500 KB; we leave headroom to 5 MB
# so companies with 500+ employees still fit. Above that we reject
# rather than load a huge blob into memory.
_MAX_UPLOAD_BYTES = 5 * 1024 * 1024


@router.post("/import/journal-paie")
async def import_journal_paie_endpoint(
    request: Request,
    file: UploadFile = File(...),  # noqa: B008 — FastAPI dependency marker pattern
    source_format: str = Form("silae"),  # noqa: B008 — idem
    auth=Depends(require_user),  # noqa: B008 — idem
) -> JSONResponse:
    """Accept a ``.xlsx`` payroll journal upload and run the import.

    The caller must be an authenticated member of the target company.
    ``require_user`` returns ``(user_id, role, company_id)``; we
    synthesize a minimal ``Context`` around that tuple so the handler
    can log + seed the right tenant's KBs.
    """
    user_id, _role, company_id = auth
    if not company_id:
        raise HTTPException(status_code=400, detail="Aucune company active.")

    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=422, detail="Fichier vide.")
    if len(raw) > _MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=(
                f"Fichier trop volumineux ({len(raw)} octets). "
                f"Maximum accepté : {_MAX_UPLOAD_BYTES // 1024 // 1024} Mo."
            ),
        )

    payload = {
        "file_b64": base64.b64encode(raw).decode("ascii"),
        "file_name": file.filename or "unknown.xlsx",
        "source_format": source_format,
    }

    # Synthesize the minimal Context fields the handler reads. The
    # handler doesn't need the full SDK Context — it only touches
    # ``ctx.company.id``, ``ctx.user.id`` and ``ctx.logger``.
    import logging

    ctx = SimpleNamespace(
        company=SimpleNamespace(id=company_id, name=None),
        user=SimpleNamespace(id=user_id),
        logger=logging.getLogger("piilot_pack_compta"),
    )

    result = journal_paie_import(ctx, payload)
    status_code = 200 if result.get("status") == "ok" else 422
    return JSONResponse(result, status_code=status_code)


def wire_routes() -> None:
    """Register the plugin router under ``/plugins/compta``.

    Called once from ``Plugin.register()``.
    """
    from piilot.sdk.http import register_router

    register_router(router)
