"""Idempotent upserts for host-side catalog rows owned by ``compta``.

Seeded once at ``Plugin.register()`` time. Currently only one row:
the ``modules.modules`` entry that powers the Modules listing and
the ``/modules/{id}/run`` dispatch. Agent templates will land here
in v0.2.

The slug must match the React slug registered from ``frontend/src/
index.ts`` (``core.registerModuleView('compta.journal_paie_import',
...)``); otherwise the host falls back to the generic step runner.
"""

from __future__ import annotations

from piilot.sdk.modules import register_module


def wire_seeds() -> None:
    """Upsert the module catalog row. ``register_module`` is idempotent
    (``ON CONFLICT (module_slug) DO UPDATE``), safe to re-run on every
    backend boot.

    No ``config`` payload here: the module is resolved by slug on the
    frontend (``registerModuleView('compta.journal_paie_import', ...)``),
    which is enough for the ``ModuleViewShell``. ``config`` (JSONB)
    can be added in a future bump if the host needs a routing hint —
    AICockpit core accepts dict payloads since PR #174 (Json wrap on
    ``_upsert_module``).
    """
    register_module(
        {
            "slug": "compta.journal_paie_import",
            "module_name": "Importer un journal de paie",
            "description": (
                "Import SILAE (.xlsx) d'un journal de paie — alimente les "
                "bases « Journal de paie — Périodes » et « Détail » "
                "protégées par le plugin."
            ),
            "icon": "file-spreadsheet",
            "category": "finance",
            "status": "published",
        }
    )
