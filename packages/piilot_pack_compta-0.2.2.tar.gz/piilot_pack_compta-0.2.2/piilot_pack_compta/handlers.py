"""Module handlers for the ``compta`` plugin.

``compta.journal_paie_import`` is the only handler in v0.1. It turns
a SILAE ``.xlsx`` payroll journal into:

* ONE row (upsert) in the "Journal de paie — Périodes" plugin-owned
  KB, keyed on ``(period_start, period_end, period_type)``.
* N rows (full replace) in the "Journal de paie — Détail" KB,
  linked via ``period_ref`` → parent row uuid.

The import is **transactionally safe from the user's point of view**:
a parse error returns ``{"status": "error", "reason": ...}`` before
touching the DB. Once the handler starts writing, it completes
end-to-end or re-runs the same import next time (idempotent via the
``(period_start, period_end, period_type)`` triple).

Re-importing the same period drops the detail rows and re-inserts —
this is intentional: users may correct their SILAE export and
re-upload, and we don't want stale rows from the previous version.
Individual cell edits made between the two imports **are lost** —
the plugin is the source of truth for the structure and the values.
"""

from __future__ import annotations

import base64
from datetime import UTC, datetime
from typing import Any

from piilot.sdk.knowledge import (
    delete_rows_by,
    find_rows,
    insert_batch,
    insert_row,
    list_columns,
    update_row,
)

from .kb_seed import ensure_compta_kbs
from .parsers.silae import ParsedJournal, SilaeParseError
from .parsers.silae import parse as parse_silae

# Dispatch table — add a new entry per supported payroll format.
# The SDK keeps ``source_format`` free-form text, so the plugin
# owns the enum. v0.1 ships a single parser.
_PARSERS: dict[str, Any] = {
    "silae": parse_silae,
}


def journal_paie_import(ctx, payload: dict[str, Any]) -> dict[str, Any]:
    """Parse a payroll journal file and materialize it into the KBs.

    See the module docstring for the transactional contract. On any
    recoverable error (missing payload, unsupported format, parse
    failure) the handler returns ``{"status": "error", "reason":
    ...}`` without touching the DB.
    """
    # -------- 1. Validate payload + context ---------------------------
    file_b64 = payload.get("file_b64")
    file_name = payload.get("file_name") or "unknown.xlsx"
    source_format = (payload.get("source_format") or "silae").lower()

    if not file_b64:
        return _error("Champ 'file_b64' manquant dans le payload.")
    if source_format not in _PARSERS:
        return _error(
            f"Format '{source_format}' non supporté. " f"Formats disponibles : {sorted(_PARSERS)}."
        )
    if ctx.company is None or not getattr(ctx.company, "id", None):
        return _error("Aucune company active dans le contexte plugin.")

    company_id = ctx.company.id

    # -------- 2. Decode + parse ---------------------------------------
    try:
        file_bytes = base64.b64decode(file_b64, validate=True)
    except Exception as exc:
        return _error(f"Contenu base64 invalide : {exc}")

    try:
        parsed: ParsedJournal = _PARSERS[source_format](file_bytes)
    except SilaeParseError as exc:
        return _error(str(exc))
    except Exception as exc:  # defensive — unforeseen parser crash
        ctx.logger.exception("journal_paie_import: parser crashed")
        return _error(f"Erreur interne lors du parsing : {exc}")

    # -------- 3. Ensure target KBs exist (idempotent) -----------------
    parent_kb, detail_kb = ensure_compta_kbs(company_id)
    parent_col_ids = _column_id_map(parent_kb["id"])
    detail_col_ids = _column_id_map(detail_kb["id"])

    # -------- 4. Upsert parent row + full-replace detail rows ---------
    period_start = parsed.period_start.isoformat()
    period_end = parsed.period_end.isoformat()
    period_type = parsed.period_type

    today_iso = datetime.now(UTC).date().isoformat()
    # kb_rows.data is a JSONB map keyed by column **UUID** (not column
    # name). The frontend reads cells as ``row.data[col.id]`` — storing
    # by name silently renders empty cells.
    parent_data: dict[str, Any] = {
        parent_col_ids["period_start"]: period_start,
        parent_col_ids["period_end"]: period_end,
        parent_col_ids["period_type"]: period_type,
        parent_col_ids["period_label"]: parsed.period_label,
        parent_col_ids["employees_count"]: parsed.employees_count,
        parent_col_ids["rubrics_count"]: parsed.rubrics_count,
        parent_col_ids["rows_count"]: 0,  # patched after insert_batch
        parent_col_ids["last_source_file"]: file_name,
        parent_col_ids["last_source_format"]: source_format,
        parent_col_ids["last_imported_at"]: today_iso,
    }

    existing_parent_row_id = _find_parent_row_id(
        parent_kb["id"],
        period_start=period_start,
        period_end=period_end,
        period_type=period_type,
    )
    if existing_parent_row_id is not None:
        # Drop old detail rows attached to this parent via the SQL FK
        # (kb_rows.parent_row_id — the "real" parent/child linkage, not
        # a JSONB cell). delete_rows_by can't express this filter yet;
        # go straight through the SDK's db cursor.
        _delete_children_of(detail_kb["id"], existing_parent_row_id)
        update_row(existing_parent_row_id, parent_data)
        parent_row_id = existing_parent_row_id
    else:
        inserted_parent = insert_row(parent_kb["id"], parent_data)
        parent_row_id = str(inserted_parent["id"])

    # -------- 5. Build + insert detail rows ---------------------------
    detail_rows = _build_detail_rows(parsed, parent_row_id, detail_col_ids)
    rows_inserted = insert_batch(detail_kb["id"], detail_rows)

    # -------- 6. Patch rows_count on parent with actual inserted ------
    rows_count_col = parent_col_ids["rows_count"]
    if rows_inserted != parent_data[rows_count_col]:
        parent_data[rows_count_col] = rows_inserted
        update_row(parent_row_id, parent_data)

    ctx.logger.info(
        "journal_paie_import: company=%s period=%s (%s) employees=%d " "rubrics=%d rows=%d",
        company_id,
        parsed.period_label,
        period_type,
        parsed.employees_count,
        parsed.rubrics_count,
        rows_inserted,
    )
    return {
        "status": "ok",
        "period_label": parsed.period_label,
        "period_type": period_type,
        "employees_count": parsed.employees_count,
        "rubrics_count": parsed.rubrics_count,
        "rows_inserted": rows_inserted,
        # Renamed: ``parent_kb_id`` was the legacy SDK 0.4 field. Since
        # 0.5.0 dropped the structural parent_kb_id link, we surface
        # the same UUID under a clearer name (``period_kb_id`` — the
        # KB that holds the period parent rows).
        "period_kb_id": str(parent_kb["id"]),
        "detail_kb_id": str(detail_kb["id"]),
        "parent_row_id": str(parent_row_id),
        "replaced_existing": existing_parent_row_id is not None,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _error(reason: str) -> dict[str, Any]:
    return {"status": "error", "reason": reason}


def _delete_children_of(kb_id: str, parent_row_id: str) -> int:
    """Delete every detail row whose row-level FK
    ``parent_row_id`` matches.

    SDK 0.5.0 added ``parent_row_id`` as a kwarg to
    :func:`piilot.sdk.knowledge.delete_rows_by`, replacing the v0.4
    workaround that dropped down to ``cursor()`` for this exact case.
    The repo decrements ``knowledge_bases.row_count`` atomically.
    """
    return delete_rows_by(kb_id, {}, parent_row_id=parent_row_id)


def _column_id_map(kb_id: str) -> dict[str, str]:
    """Return ``{column_name: column_uuid}`` for a KB.

    kb_rows.data is keyed by column UUID (the frontend reads cells
    via ``row.data[col.id]``), but the plugin thinks in
    human-readable names (``period_start``, etc.). This map bridges
    the two at runtime without leaking UUIDs into the business
    logic or the specs.

    SDK 0.5.0 exposes :func:`piilot.sdk.knowledge.list_columns` so
    we no longer need direct SQL on ``public.kb_columns``.
    """
    return {col["name"]: str(col["id"]) for col in list_columns(kb_id)}


def _find_parent_row_id(
    kb_id: str,
    period_start: str,
    period_end: str,
    period_type: str,
) -> str | None:
    """Look up the existing parent row for this period, if any.

    The triple ``(period_start, period_end, period_type)`` is the
    logical upsert key. SDK 0.5.0 :func:`find_rows` accepts a
    name-keyed filter dict and translates to the column UUIDs
    internally — the plugin never has to think in UUIDs here.
    """
    rows = find_rows(
        kb_id=kb_id,
        filters={
            "period_start": period_start,
            "period_end": period_end,
            "period_type": period_type,
        },
        limit=1,
    )
    if not rows:
        return None
    return str(rows[0]["id"])


def _build_detail_rows(
    parsed: ParsedJournal,
    parent_row_id: str,
    col_ids: dict[str, str],
) -> list[dict[str, Any]]:
    """Flatten ``(ParsedRow × EmployeeValues)`` into kb_rows payloads.

    Output shape matches ``piilot.sdk.knowledge.insert_batch``:
    ``[{"data": {...}, "position": int, "parent_row_id"?: str}, ...]``.

    ``data`` is keyed by column **UUID**, not by column name — the
    frontend reads cells as ``row.data[col.id]`` and keys the
    match against the live ``kb_columns.id``. ``col_ids`` is the
    name→uuid mapping fetched once by the handler via
    :func:`_column_id_map`.

    ``position`` is globally incrementing (not per rubric) so the UI
    preserves the import's natural ordering. ``parent_row_id`` on
    the kb_rows row itself is **not** set — parent↔child navigation
    goes through the ``period_ref`` JSONB cell (kb_ref mechanism),
    not the structural FK.
    """
    # Employee lookup — 108 employees in a SILAE annual, this avoids
    # the O(n_rubric × n_employee) scan inside the parser loop.
    employees_by_code = {e.code: e for e in parsed.employees}

    rows: list[dict[str, Any]] = []
    position = 0
    for parsed_row in parsed.rows:
        for employee_code, values in parsed_row.values.items():
            emp = employees_by_code.get(employee_code)
            if emp is None:  # defensive — shouldn't happen
                continue
            data = {
                col_ids["employee_code"]: emp.code,
                col_ids["employee_name"]: emp.name,
                col_ids["rubric_code"]: parsed_row.rubric_code,
                col_ids["rubric_label"]: parsed_row.rubric_label,
                col_ids["base_salariale"]: _num_cell(values.base_salariale),
                col_ids["montant_salarial"]: _num_cell(values.montant_salarial),
                col_ids["montant_patronal"]: _num_cell(values.montant_patronal),
                col_ids["is_subtotal"]: "true" if parsed_row.is_subtotal else "false",
                col_ids["row_order"]: parsed_row.row_order,
            }
            # ``parent_row_id`` at the row level (not inside data) drives
            # the kb_ref navigation: the parent KB's ``detail`` column
            # filters the detail KB to rows where kb_rows.parent_row_id
            # matches the parent row the user clicked.
            rows.append(
                {
                    "data": data,
                    "position": position,
                    "parent_row_id": parent_row_id,
                }
            )
            position += 1
    return rows


def _num_cell(v: float | None) -> str:
    """Render a numeric value for a JSONB ``numeric``-typed cell.

    Stored as a string because kb_rows.data is JSONB and the core
    ``kb_rows_repo.query`` path handles the ``(data->>'col')::numeric``
    cast for sorting and filtering. Empty values become "" — the UI
    renders them as "—" which matches the "no data for this cell"
    semantics we want for absent values (vs a stored zero, which
    SILAE emits explicitly when relevant).
    """
    if v is None:
        return ""
    if v == int(v):
        return str(int(v))
    # Cap noise from float printing — 4 decimals is well beyond
    # any real payroll amount precision.
    return f"{v:.4f}".rstrip("0").rstrip(".")
