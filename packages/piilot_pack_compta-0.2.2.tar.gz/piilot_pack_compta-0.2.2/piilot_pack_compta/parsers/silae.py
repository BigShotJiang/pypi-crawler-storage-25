"""SILAE Journal de paie (``.xlsx``) parser.

SILAE exports a wide-matrix workbook. The sheet (named ``JP ANNUEL``
for yearly cumulative exports, ``JP MENSUEL`` or similar for
monthly) follows a rigid layout:

::

    Row 1 : "Récapitulatif de paie détaillé - De {mois} {année} à {mois} {année}"
    Row 2 : blank
    Row 3 : employee full names repeated over their 3-column triplet
    Row 4 : headers ("Base S." / "Salarial" / "Patronal") per employee
    Row 5+: payroll lines — col A = rubric code, col B = rubric label,
            then triplets (base / salarial / patronal) for each employee

This parser walks the sheet, extracts the period from row 1, indexes
the employees from row 3, and emits one :class:`ParsedRow` per payroll
line with one :class:`EmployeeValues` per employee.

The parser is intentionally **conservative**: anything it can't
understand raises :class:`SilaeParseError` rather than silently
producing junk. The handler catches and converts to a user-facing
``{"status": "error", "reason": ...}`` dict.

Returned values are pure Python — no KB-specific shape — so the
parser is easily unit-testable with or without a Piilot backend.
"""

from __future__ import annotations

import calendar
import io
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from openpyxl import load_workbook


class SilaeParseError(Exception):
    """Raised when the SILAE file can't be parsed (wrong shape, missing
    sheet, unreadable period, etc.). Carries a user-facing message."""


# Month name → month number. Accent-insensitive via normalize().
_MONTHS_FR = {
    "janvier": 1,
    "fevrier": 2,
    "mars": 3,
    "avril": 4,
    "mai": 5,
    "juin": 6,
    "juillet": 7,
    "aout": 8,
    "septembre": 9,
    "octobre": 10,
    "novembre": 11,
    "decembre": 12,
}

# Period extraction regex — tolerant to whitespace variations.
_PERIOD_RE = re.compile(
    r"De\s+(?P<m1>\w+)\s+(?P<y1>\d{4})\s+à\s+(?P<m2>\w+)\s+(?P<y2>\d{4})",
    re.IGNORECASE,
)

# Prefix used by SILAE for aggregation lines. Checked in addition to
# a lenient "starts with Sous-total" match so future variants
# ("Sous total", "SOUS-TOTAL") don't sneak in.
_SUBTOTAL_PREFIXES = ("sous-total", "sous total", "sous-totaux", "sous totaux")


def _normalize(s: str) -> str:
    """Lowercase + strip accents + collapse whitespace — used for month
    names and subtotal labels so minor typographic variations stay
    recognized."""
    if not s:
        return ""
    import unicodedata

    nfkd = unicodedata.normalize("NFKD", s)
    stripped = "".join(c for c in nfkd if not unicodedata.combining(c))
    return " ".join(stripped.lower().split())


@dataclass(frozen=True)
class Employee:
    """One employee column block in the SILAE sheet."""

    code: str
    """SILAE matricule — first token of the row-3 cell (e.g. "ABELANGE")."""
    name: str
    """Remainder of the row-3 cell (e.g. "ABELLARD ANGELIQUE")."""
    col_base: int
    """1-indexed column number of the Base S. cell."""
    col_salarial: int
    """1-indexed column number of the Salarial cell."""
    col_patronal: int
    """1-indexed column number of the Patronal cell."""


@dataclass
class EmployeeValues:
    """The three numeric values for one employee on one payroll line."""

    base_salariale: float | None
    montant_salarial: float | None
    montant_patronal: float | None


@dataclass
class ParsedRow:
    """One row of the SILAE grid after parsing.

    Each ``values`` dict maps ``employee_code`` → :class:`EmployeeValues`.
    Rows are emitted in source order (from row 5 onward) so
    ``row_order`` can restore the original layout on re-export.
    """

    row_order: int
    rubric_code: str
    rubric_label: str
    is_subtotal: bool
    values: dict[str, EmployeeValues] = field(default_factory=dict)


@dataclass
class ParsedJournal:
    """Full parse result — the shape the handler consumes."""

    period_start: date
    period_end: date
    period_type: str  # "annuel" | "mensuel" | "autre"
    period_label: str  # verbatim row-1 extract
    sheet_name: str
    employees: list[Employee]
    rows: list[ParsedRow]

    @property
    def employees_count(self) -> int:
        return len(self.employees)

    @property
    def rubrics_count(self) -> int:
        """Rubric lines excluding subtotals (spec §4.3)."""
        return sum(1 for r in self.rows if not r.is_subtotal)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def parse(file_bytes: bytes) -> ParsedJournal:
    """Parse a SILAE ``.xlsx`` payroll journal from raw bytes.

    Raises :class:`SilaeParseError` with a user-facing message on any
    unrecoverable issue.
    """
    try:
        wb = load_workbook(
            io.BytesIO(file_bytes),
            data_only=True,
            read_only=True,
        )
    except Exception as exc:
        raise SilaeParseError(f"Impossible de lire le fichier Excel : {exc}") from exc

    sheet_name = _pick_sheet(wb)
    ws = wb[sheet_name]

    period_label, period_start, period_end, period_type = _parse_period(ws)
    employees = _parse_employees(ws)
    if not employees:
        raise SilaeParseError(
            "Aucun salarié détecté dans la ligne 3 de la feuille — "
            "fichier vide ou format inattendu."
        )
    rows = _parse_rows(ws, employees)

    return ParsedJournal(
        period_start=period_start,
        period_end=period_end,
        period_type=period_type,
        period_label=period_label,
        sheet_name=sheet_name,
        employees=employees,
        rows=rows,
    )


# ---------------------------------------------------------------------------
# Stage 1 — sheet selection
# ---------------------------------------------------------------------------


def _pick_sheet(wb: Any) -> str:
    """Find the SILAE sheet. Conventional names start with "JP "."""
    for name in wb.sheetnames:
        if name.upper().startswith("JP"):
            return name
    # Fallback to the first sheet — SILAE sometimes ships a single-sheet
    # file named after the export date.
    if wb.sheetnames:
        return wb.sheetnames[0]
    raise SilaeParseError("Le classeur Excel ne contient aucune feuille.")


# ---------------------------------------------------------------------------
# Stage 2 — period detection (row 1)
# ---------------------------------------------------------------------------


def _parse_period(ws: Any) -> tuple[str, date, date, str]:
    """Extract ``(period_label, period_start, period_end, period_type)``
    from the A1 cell. Raises if the expected pattern isn't found."""
    label = ws.cell(row=1, column=1).value
    if not label or not isinstance(label, str):
        raise SilaeParseError(
            "La cellule A1 ne contient pas le libellé attendu "
            '("Récapitulatif de paie détaillé - De …").'
        )

    match = _PERIOD_RE.search(label)
    if not match:
        raise SilaeParseError(
            f"Période illisible dans A1 ({label!r}). Format attendu : "
            '"De {mois} {année} à {mois} {année}".'
        )

    m1_word = _normalize(match.group("m1"))
    m2_word = _normalize(match.group("m2"))
    if m1_word not in _MONTHS_FR or m2_word not in _MONTHS_FR:
        raise SilaeParseError(f"Mois non reconnu dans la période : {m1_word!r} / {m2_word!r}.")

    m1 = _MONTHS_FR[m1_word]
    y1 = int(match.group("y1"))
    m2 = _MONTHS_FR[m2_word]
    y2 = int(match.group("y2"))

    period_start = date(y1, m1, 1)
    last_day = calendar.monthrange(y2, m2)[1]
    period_end = date(y2, m2, last_day)

    period_type = _classify_period(y1, m1, y2, m2)
    return label, period_start, period_end, period_type


def _classify_period(y1: int, m1: int, y2: int, m2: int) -> str:
    """Classify a detected period as 'mensuel', 'annuel' or 'autre'."""
    if y1 == y2 and m1 == m2:
        return "mensuel"
    if y1 == y2 and m1 == 1 and m2 == 12:
        return "annuel"
    return "autre"


# ---------------------------------------------------------------------------
# Stage 3 — employee columns (row 3)
# ---------------------------------------------------------------------------


def _parse_employees(ws: Any) -> list[Employee]:
    """Walk row 3 from column C onward in triplets. Each triplet whose
    first column carries a non-empty name yields an :class:`Employee`."""
    employees: list[Employee] = []
    max_col = ws.max_column
    col = 3  # col C
    while col <= max_col:
        raw = ws.cell(row=3, column=col).value
        if raw and isinstance(raw, str) and raw.strip():
            code, name = _split_employee_label(raw.strip())
            employees.append(
                Employee(
                    code=code,
                    name=name,
                    col_base=col,
                    col_salarial=col + 1,
                    col_patronal=col + 2,
                )
            )
        col += 3
    return employees


def _split_employee_label(label: str) -> tuple[str, str]:
    """Split ``"ABELANGE ABELLARD ANGELIQUE"`` → ``("ABELANGE", "ABELLARD ANGELIQUE")``.

    The first whitespace-separated token is the SILAE matricule; the
    remainder is the full name. We don't try to detect firstname /
    lastname split — that's SILAE-specific order (last, first) and
    unreliable. Downstream consumers can do it if they need to.
    """
    parts = label.split(None, 1)
    if len(parts) == 1:
        # Unusual: label is just a code with no name.
        return parts[0], ""
    return parts[0], parts[1]


# ---------------------------------------------------------------------------
# Stage 4 — payroll lines (row 5+)
# ---------------------------------------------------------------------------


def _parse_rows(ws: Any, employees: list[Employee]) -> list[ParsedRow]:
    """Walk rows 5..max_row, emitting one :class:`ParsedRow` per line.

    Uses ``ws.iter_rows(values_only=True)`` (streaming) rather than
    ``ws.cell()`` lookups. In ``read_only`` mode ``ws.cell()`` is
    O(n_row) per call (it re-walks the row each time); a 485×326
    sheet touching 108 employees would explode to ~50k cell calls
    and take several minutes. Streaming is ~100x faster.
    """
    # col-indexes list for fast per-row slicing (0-indexed into the tuple).
    emp_col_bases = [
        (emp, emp.col_base - 1, emp.col_salarial - 1, emp.col_patronal - 1) for emp in employees
    ]
    rows: list[ParsedRow] = []
    row_order = 0

    for row_values in ws.iter_rows(min_row=5, values_only=True):
        # iter_rows yields tuples of length max_col; pad defensively.
        row_len = len(row_values)
        code = row_values[0] if row_len > 0 else None
        label = row_values[1] if row_len > 1 else None

        if (code is None or str(code).strip() == "") and (
            label is None or str(label).strip() == ""
        ):
            continue

        code_s = str(code).strip() if code else ""
        label_s = str(label).strip() if label else ""
        is_subtotal = _is_subtotal(label_s)

        values: dict[str, EmployeeValues] = {}
        for emp, i_base, i_sal, i_pat in emp_col_bases:
            base_raw = row_values[i_base] if i_base < row_len else None
            sal_raw = row_values[i_sal] if i_sal < row_len else None
            pat_raw = row_values[i_pat] if i_pat < row_len else None
            base = _to_float(base_raw)
            salarial = _to_float(sal_raw)
            patronal = _to_float(pat_raw)
            if base is None and salarial is None and patronal is None:
                # Drop empty triplets to keep the detail KB lean —
                # a rubric with zero hits for an employee is
                # genuinely absent. The handler respects the omission.
                continue
            values[emp.code] = EmployeeValues(
                base_salariale=base,
                montant_salarial=salarial,
                montant_patronal=patronal,
            )

        row_order += 1
        rows.append(
            ParsedRow(
                row_order=row_order,
                rubric_code=code_s,
                rubric_label=label_s,
                is_subtotal=is_subtotal,
                values=values,
            )
        )
    return rows


def _is_subtotal(label: str) -> bool:
    """True if the label looks like a SILAE aggregation line."""
    if not label:
        return False
    norm = _normalize(label)
    return any(norm.startswith(prefix) for prefix in _SUBTOTAL_PREFIXES)


def _to_float(cell: Any) -> float | None:
    """Coerce a cell value to float, tolerating empty strings / None /
    numeric-looking text. Returns ``None`` for unusable input."""
    if cell is None:
        return None
    if isinstance(cell, (int, float)):
        return float(cell)
    s = str(cell).strip()
    if not s:
        return None
    # SILAE sometimes uses "," as decimal separator in text cells —
    # normalize before casting.
    s = s.replace(" ", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None
