"""Format-specific parsers for payroll journal imports.

Each module exposes ``parse(file_bytes: bytes) -> ParsedJournal`` and
may expose helpers used by the tests. The dispatch by
``source_format`` lives in :mod:`piilot_pack_compta.handlers`.
"""
