#!/usr/bin/env python3
"""Claude Code PreToolUse hook — in-process firewall (Phase 5, --mode local).

Donor: aegis-mvp v1.0.0 ``claude_hooks/pretool.py`` (in-process pattern),
adapted to MVP's 30-subfield ATV-2080-v1 firewall.

Solo Free deployment: Claude Code calls this script for every tool;
the script builds an :class:`aegis.schema.ATVInput` from the hook
payload, runs the firewall pipeline (310 → 311 → 312 → 320 → 330 → 335
→ 340) in-process, and signals the verdict back via exit code:

* ``0``  ALLOW             — tool runs.
* ``2``  BLOCK / REQUIRE_APPROVAL (when AEGIS_APPROVE_AS_BLOCK=1, the
                              default) — Claude Code aborts the tool
                              and surfaces the stderr message.

No HTTP, no docker, no audit signing — pure firewall in process.
:func:`aegis.cost.transcript.import_into_wal` is invoked separately by
the Stop hook (``tools/hooks/session_end.py``) for cost back-fill.

Env vars::

    AEGIS_TENANT_ID         claude-code-local   tag for every record
    AEGIS_LOCAL_AUDIT       ~/.aegis/audit.jsonl   per-call decision log
    AEGIS_APPROVE_AS_BLOCK  1                   set 0 to let
                                                  REQUIRE_APPROVAL pass
                                                  with a stderr warning
                                                  instead of blocking
    AEGIS_HOOK_VERBOSE      0                   1 → print ALLOWs to stderr
    AEGIS_POLICY_DIR        ./policies          path to sensitive_paths.json
                                                  + safe_bash_subcommands.json

The ``aegis install --mode local`` command (D3 / Phase 5) embeds the
right ``AEGIS_POLICY_DIR`` and ``PYTHONPATH`` into the registered hook
command line, so users never set these by hand.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

TENANT = os.environ.get("AEGIS_TENANT_ID", "claude-code-local")
APPROVE_AS_BLOCK = os.environ.get("AEGIS_APPROVE_AS_BLOCK", "1") == "1"
VERBOSE = os.environ.get("AEGIS_HOOK_VERBOSE", "0") == "1"
# v2.5 PR-ζ-head — Phase C advisor surface. Opt-in to keep the default
# Solo Free hot path zero-impact. When enabled, the hook composes an
# ActionAdvice from the 4-layer narrative (PR-θ / PR-ε / PR-ι / PR-η /
# PR-κ) and stamps it into ``explain.action_advice``. Set to ``haiku``
# (with ANTHROPIC_API_KEY) or leave default for the deterministic
# heuristic advisor.
ADVISOR_ENABLED = os.environ.get("AEGIS_ADVISOR_ENABLED", "0") == "1"
# v2.5.1 PR-ψ-gating — advisor only fires on "critical moments" so the
# expensive 4-layer pipeline + (optional) sLLM call doesn't run on every
# innocuous Read. ``AEGIS_ADVISOR_ALWAYS=1`` bypasses the gate (useful
# for burn-in collection or debugging).
ADVISOR_ALWAYS = os.environ.get("AEGIS_ADVISOR_ALWAYS", "0") == "1"
# Model the host is actually serving — feeds the cost FLOPS table so
# CostEfficiencyMetrics.cumulative_dollars and step335 budget gate
# evaluate against the right $/token. Override per-deployment.
MODEL_FOR_COST = os.environ.get("AEGIS_MODEL_FOR_COST", "claude-haiku-4-5")
LOCAL_AUDIT_PATH = Path(
    os.environ.get(
        "AEGIS_LOCAL_AUDIT", str(Path.home() / ".aegis" / "audit.jsonl")
    )
)
# ATMU 2PC intent log (M10) — per-process SQLite WAL. Disabled when
# AEGIS_ATMU_DISABLE=1 so users running on read-only file systems can
# opt out without touching code. Default path: ~/.aegis/intent_log.sqlite.
LOCAL_INTENT_LOG_PATH = Path(
    os.environ.get(
        "AEGIS_INTENT_LOG_DB", str(Path.home() / ".aegis" / "intent_log.sqlite")
    )
)
ATMU_DISABLED = os.environ.get("AEGIS_ATMU_DISABLE", "0") == "1"


def _emit(msg: str) -> None:
    print(f"[aegis-local] {msg}", file=sys.stderr, flush=True)


def _stderr_format_params(params: dict[str, Any]) -> str:
    """Compact rendering of an ActionStep.parameters dict for stderr.
    Picks the 2 most useful keys per common verb so the operator sees
    'prune-turns indices=[-3,-2,-1] save~$0.42' not the full JSON."""
    if not params:
        return ""
    # Per-verb key priority (stderr is line-bounded; show what matters).
    keys_to_show: list[str] = []
    if "turn_indices_rel" in params:
        keys_to_show.append("turn_indices_rel")
        if "saved_dollars_estimate" in params:
            keys_to_show.append("saved_dollars_estimate")
    elif "from_model" in params:
        keys_to_show.extend(["from_model", "to_model"])
    elif "from_tool" in params:
        keys_to_show.extend(["from_tool", "to_tool"])
    elif "turn_range" in params:
        keys_to_show.append("turn_range")
    elif "diagnostic_command" in params:
        keys_to_show.append("diagnostic_command")
    elif "clarifying_question" in params:
        keys_to_show.append("clarifying_question")
    elif "channel" in params:
        keys_to_show.extend(["channel", "summary"])
    elif "reason" in params:
        keys_to_show.append("reason")
    else:
        # Fallback: show first 2 keys.
        keys_to_show = list(params.keys())[:2]

    parts: list[str] = []
    for k in keys_to_show:
        if k not in params:
            continue
        v = params[k]
        if isinstance(v, list):
            if len(v) <= 4:
                rendered = "[" + ",".join(str(x) for x in v) + "]"
            else:
                head = ",".join(str(x) for x in v[:3])
                rendered = f"[{head},…+{len(v) - 3}]"
        elif isinstance(v, str):
            rendered = v if len(v) <= 32 else v[:31] + "…"
        else:
            rendered = str(v)
        parts.append(f"{k}={rendered}")
    return " ".join(parts)


def _build_explain_block(atv: Any, inp: Any, verdict: Any) -> dict[str, Any]:
    """Per-decision diagnostic block written into each audit record.

    Captures every signal the firewall *consulted* (not just the one
    that decided), so ``aegis report --explain TRACE`` can render a
    layer-by-layer "why" for any past decision. Every field is a pure
    function of the verdict / inp / atv tuple — we're just lifting
    information that already exists in memory at PreToolUse time so
    it survives in the audit chain instead of being lost.

    Fields written
    --------------
    * ``step_traces``   — the ``Verdict.step_traces`` dict, filtered
      to entries that are non-trivial (skipped / ok-only entries are
      noise; we keep BLOCK / REQUIRE_APPROVAL / hybrid / numeric
      payloads).
    * ``m13_top``       — top-5 (subfield, score) pairs from the M13
      attribution head, computed against the current ATV. Recomputed
      here rather than lifted from the verdict because step340 only
      sometimes embeds it in the reason string.
    * ``rag``           — count, top cosine, top label of the cases
      retrieved by step340 RAG (when BGE + memory are configured).
      ``null`` when RAG was inactive.
    * ``session_drift`` — ``topic_drift`` and ``n_calls`` for the
      session this call belongs to (when bge-local + session_id
      present, otherwise ``null``).
    * ``atv_dim`` / ``atv_sha3`` — sanity-check shape + content hash
      for downstream replay tools.

    Try/except around every sub-section: if any signal-gathering
    fails (e.g. M13 weights file unreadable), the block degrades to
    fewer fields rather than blocking the tool call.
    """
    explain: dict[str, Any] = {}

    # ── ATV shape + content fingerprint ──────────────────────────────
    try:
        import hashlib

        import numpy as np
        atv_arr = np.asarray(atv)
        explain["atv_dim"] = int(atv_arr.shape[0])
        explain["atv_sha3"] = hashlib.sha3_256(atv_arr.tobytes()).hexdigest()
    except Exception:  # noqa: BLE001
        pass

    # ── Step traces (filtered) ───────────────────────────────────────
    try:
        traces = dict(getattr(verdict, "step_traces", {}) or {})
        # Drop entries that are pure "ok" / "skipped" — they're noise.
        # Keep anything carrying numbers, BLOCK / REQUIRE_APPROVAL, or
        # hybrid output strings (which include attribution breakdowns).
        keep = {}
        for k, v in traces.items():
            if not isinstance(v, str):
                continue
            low = v.lower()
            keep_this = (
                "block" in low or "approval" in low or "hybrid" in low
                or "drift" in low or "loop" in low
                or any(c.isdigit() for c in v)
            )
            if keep_this:
                keep[k] = v[:200]
        explain["step_traces"] = keep
    except Exception:  # noqa: BLE001
        pass

    # ── PR-D: per-step latency (opt-in via AEGIS_STEP_TIMING_ENABLED) ─
    # The orchestrator populates Verdict.step_timings_us only when the
    # env var is set. When present, we embed the full dict so users can
    # see exactly which step ate the latency budget — most useful for
    # diagnosing why a particular session feels slow under --profile pro.
    try:
        timings = getattr(verdict, "step_timings_us", None)
        if timings:
            explain["step_timings_us"] = dict(timings)
    except Exception:  # noqa: BLE001
        pass

    # ── M13 top-5 attribution ───────────────────────────────────────
    try:
        from aegis.judge.attribution_head import AttributionHead
        head = AttributionHead()
        v = head.evaluate_full("", atv=atv, inp=inp)
        attribution = dict(getattr(v, "subfield_attribution", {}) or {})
        if attribution:
            top = sorted(
                attribution.items(), key=lambda kv: -float(kv[1]),
            )[:5]
            explain["m13_top"] = [
                {"subfield": name, "score": round(float(score), 4)}
                for name, score in top
            ]
            explain["m13_score"] = round(
                float(getattr(v, "confidence", 0.0)), 4,
            )
    except Exception:  # noqa: BLE001
        pass

    # ── RAG retrieval ────────────────────────────────────────────────
    try:
        from aegis.config import settings as _settings
        if _settings.aegis_embedding_provider == "bge-local":
            import numpy as np

            from aegis.judge.case_memory import load_default_memory
            from aegis.schema import SLICE_AGENT_STATE_EMBEDDING
            mem = load_default_memory()
            if not mem.is_empty:
                q = np.asarray(
                    atv[SLICE_AGENT_STATE_EMBEDDING], dtype=np.float32,
                )
                hits = mem.search(q, k=3) if q.size == mem.dim else []
                if hits:
                    explain["rag"] = {
                        "n_retrieved": len(hits),
                        "top_cos": round(float(hits[0].similarity), 4),
                        "top_label": str(hits[0].label),
                        "top_text": str(hits[0].text)[:120],
                    }
    except Exception:  # noqa: BLE001
        pass

    # ── Session drift snapshot ───────────────────────────────────────
    try:
        from aegis.atv.session_drift import load_session
        sid = getattr(inp.header, "aid", "") or ""
        # Heuristic: aid in our local hook is the Claude Code session_id
        # (set in adapter._tool_args_to_input). Look for the session
        # state directly.
        state = load_session(sid)
        if state is not None and state.drift_history:
            explain["session_drift"] = {
                "topic_drift": round(float(state.drift_history[-1]), 4),
                "max_drift": round(float(max(state.drift_history)), 4),
                "n_calls": int(state.n_calls),
            }
    except Exception:  # noqa: BLE001
        pass

    return explain


_INTENT_LOG_SINGLETON: Any = None


def _get_intent_log() -> Any:
    """Lazy per-process IntentLog singleton.

    Returns ``None`` when ATMU is disabled or initialisation fails so
    every caller can short-circuit safely. The hook must NEVER block
    a tool call because of intent-log trouble — its job is forensic
    bookkeeping, not gating.
    """
    global _INTENT_LOG_SINGLETON
    if ATMU_DISABLED:
        return None
    if _INTENT_LOG_SINGLETON is not None:
        return _INTENT_LOG_SINGLETON
    try:
        LOCAL_INTENT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        from aegis.atmu import IntentLog

        _INTENT_LOG_SINGLETON = IntentLog(str(LOCAL_INTENT_LOG_PATH))
        # v0.5.8 — auto WAL replay on first init. Sweep orphans
        # (TENTATIVE / PREPARED rows ≥ 24 h old) to ABORTED so the
        # intent log stays honest across Claude Code restarts /
        # crashes. Suppress every failure mode — the hook MUST come
        # up regardless of recovery outcome.
        try:
            from aegis.atmu.recovery import recover_orphans
            _sweep = recover_orphans(_INTENT_LOG_SINGLETON)
            if _sweep.n_swept and VERBOSE:
                _emit(
                    f"ATMU auto-recovery swept {_sweep.n_swept} "
                    f"orphan(s) → ABORTED"
                )
        except Exception as _e:  # noqa: BLE001 — defensive sweep
            if VERBOSE:
                _emit(f"ATMU auto-recovery skipped: {_e}")
        return _INTENT_LOG_SINGLETON
    except Exception as e:  # noqa: BLE001 — never block on infra failure
        if VERBOSE:
            _emit(f"ATMU disabled (init failed): {e}")
        return None


def _atmu_open_intent(inp: Any, atv: Any) -> str | None:
    """Phase 1 of 2PC — record TENTATIVE intent before the firewall runs.

    The ``record_id`` is the deterministic ``span_id`` so the
    PostToolUse hook (a separate process) can recompute and close
    the same record without a mapping table.

    Returns the record_id on success, ``None`` if ATMU is disabled
    or the append failed (in which case the caller proceeds without
    transactional bookkeeping).
    """
    log = _get_intent_log()
    if log is None:
        return None
    try:
        import hashlib

        from aegis.atmu.checkpoint import make_checkpoint
        from aegis.atmu.compensating import plan_for
        from aegis.firewall.step320_blast import (
            TOOL_BLAST_TABLE,
            UNKNOWN_TOOL_BLAST,
        )

        args_hash = hashlib.sha3_256(
            inp.tool_args_json.encode("utf-8")
        ).hexdigest()
        atv_commitment = hashlib.sha3_256(atv.tobytes()).hexdigest()
        blast = TOOL_BLAST_TABLE.get(inp.tool_name, UNKNOWN_TOOL_BLAST)
        checkpoint = make_checkpoint(inp, blast)
        rec = log.append_tentative(
            aid=inp.header.aid,
            tenant_id=inp.header.tenant_id,
            trace_id=inp.header.trace_id,
            span_id=inp.header.span_id,
            parent_span_id=inp.header.parent_span_id,
            tool_name=inp.tool_name,
            tool_args_hash=args_hash,
            blast_radius=blast,
            atv_commitment=atv_commitment,
            checkpoint_id=(
                checkpoint["checkpoint_id"] if checkpoint else None
            ),
            cost_profile=inp.header.cost_attestation_profile,
            record_id=inp.header.span_id,
        )
        comp = plan_for(inp.tool_name)
        if comp is not None:
            log.set_compensation_plan(rec["record_id"], comp)
        return str(rec["record_id"])
    except Exception as e:  # noqa: BLE001
        if VERBOSE:
            _emit(f"ATMU open_intent failed: {e}")
        return None


def _atmu_finalize_intent(record_id: str | None, decision: str, reason: str) -> None:
    """Phase 1.5 of 2PC — drive the intent record to its post-firewall state.

    * ``ALLOW``           — TENTATIVE → PREPARED → COMMITTED
    * ``REQUIRE_APPROVAL`` — TENTATIVE → PREPARED (committed at /approve time)
    * ``BLOCK``            — TENTATIVE → ABORTED
    """
    if record_id is None:
        return
    log = _get_intent_log()
    if log is None:
        return
    try:
        from aegis.atmu import TxState

        if decision == "BLOCK":
            log.transition(
                record_id,
                new_state=TxState.ABORTED,
                reason=f"firewall block: {reason}"[:200],
            )
        else:
            log.transition(
                record_id,
                new_state=TxState.PREPARED,
                reason=f"firewall {decision.lower()}",
            )
            if decision == "ALLOW":
                log.transition(
                    record_id,
                    new_state=TxState.COMMITTED,
                    reason="audit signed, host may execute",
                )
    except Exception as e:  # noqa: BLE001
        if VERBOSE:
            _emit(f"ATMU finalize_intent failed: {e}")


_CALIBRATION_SINGLETON: Any = None


def _get_calibration() -> Any:
    """Per-process advisor-calibration singleton (v2.6 PR-ψ-calibration).

    Returns ``None`` when the calibration module isn't importable, so
    the gate can short-circuit signals 6 & 7 safely. Loaded once and
    cached — no per-call file I/O on the hot path.
    """
    global _CALIBRATION_SINGLETON
    if _CALIBRATION_SINGLETON is False:
        return None
    if _CALIBRATION_SINGLETON is not None:
        return _CALIBRATION_SINGLETON
    try:
        from aegis.burnin.advisor_calibration import (
            load_calibration_or_default,
        )

        c = load_calibration_or_default()
        _CALIBRATION_SINGLETON = c if c.is_usable() else False
        return c if c.is_usable() else None
    except Exception:  # noqa: BLE001 — gate must never break the hook
        _CALIBRATION_SINGLETON = False
        return None


def _should_invoke_advisor(
    verdict: Any, explain_block: dict[str, Any]
) -> tuple[bool, str]:
    """Tier-3 gate — decide whether the advisor pipeline should run.

    Uses ONLY signals already present in ``verdict`` / ``explain_block``
    (sub-microsecond cost), so the 90%+ ALLOW path skips the advisor
    entirely.

    Signals 1-5 are deterministic firewall flags. Signals 6-7 are
    calibration-driven (v2.6) — they consult the burn-in derived
    percentile thresholds in :class:`AdvisorCalibration` and only fire
    when the calibration is usable.

    Returns ``(invoked, reason)``. ``reason`` is a short tag stamped
    into ``explain.advisor_gate`` for audit / replay.
    """
    if ADVISOR_ALWAYS:
        return True, "AEGIS_ADVISOR_ALWAYS=1"

    # 1. Non-ALLOW verdict — most common gate trigger. Catches M12
    #    escalation (which rewrites verdict.decision to REQUIRE_APPROVAL),
    #    step336 loop detector REQUIRE_APPROVAL, all step310/311 BLOCKs.
    decision = getattr(verdict, "decision", "ALLOW")
    if decision != "ALLOW":
        return True, f"verdict={decision}"

    traces = explain_block.get("step_traces") or {}
    if not isinstance(traces, dict):
        traces = {}

    # 2. M12 cost-divergence escalation trace present (defensive — should
    #    have flipped verdict, but we cover the case where it didn't).
    if "aegis.cost.escalation" in traces:
        return True, "cost-divergence escalation"

    # 3. step336 loop / redundancy hint. The detector emits
    #    "step336: loop (N× seen) — Tool" on a loop, "step336: redundant
    #    read-only (N× seen)" on a redundant repeat, and "step336: fresh
    #    call" otherwise. We match on "× seen" which appears only in
    #    the firing variants, regardless of count.
    s336 = str(traces.get("aegis.firewall.step336_loop.run", ""))
    if "× seen" in s336 or "redundant" in s336.lower():
        return True, "loop/redundancy signal"

    # 4. step335 budget warning (cumulative dollars approaching limit).
    s335 = str(traces.get("aegis.firewall.step335_cost.run", ""))
    if "warn" in s335.lower():
        return True, "cost approaching limit"

    # 5. step337 HW anomaly with populated band (skip the "T2 default"
    #    zero-fill case so we don't fire when AEGIS_HW_PROVIDER is unset).
    s337 = str(traces.get("aegis.firewall.step337_hw_anomaly.run", ""))
    low337 = s337.lower()
    if (
        ("anomaly" in low337 or "alert" in low337)
        and "t2 default" not in low337
    ):
        return True, "HW anomaly"

    # 6 + 7. Calibrated-percentile signals. Only consulted when burn-in
    #        calibration has at least MIN_SAMPLES_FOR_CALIBRATION samples
    #        for both metrics (otherwise thresholds are noise).
    cal = _get_calibration()
    if cal is not None:
        # 6. M13 attribution-head confidence in the bottom decile of
        #    historical baseline → "model itself flagging unusual".
        m13_score = explain_block.get("m13_score")
        if isinstance(m13_score, (int, float)) and m13_score < cal.m13_score_p10:
            return (
                True,
                f"M13 score {float(m13_score):.2f} < burn-in p10 "
                f"{cal.m13_score_p10:.2f}",
            )

        # 7. Session topic drift in the top 5% of historical baseline.
        drift = explain_block.get("session_drift")
        if isinstance(drift, dict):
            t = drift.get("topic_drift")
            if isinstance(t, (int, float)) and t > cal.topic_drift_p95:
                return (
                    True,
                    f"session drift {float(t):.2f} > burn-in p95 "
                    f"{cal.topic_drift_p95:.2f}",
                )

    return False, "no critical signals"


# Boot-once sentinel for the license gate (LICENSE_KEY.md §9 step 6).
# The hook is a fresh process per Claude Code call, so initialising
# the in-memory active license from disk exactly once on the first
# advisor invocation is enough — it avoids both per-call disk I/O AND
# the test/demo footgun where re-init wipes a license that was set
# via :func:`aegis.license.set_active_license`.
_license_booted: bool = False


def _license_grants_advisor_full() -> bool:
    """Return True iff the active license grants ``advisor.full``.

    First call per process: if no claims are active in memory, load
    ``~/.aegis/license.jwt`` (or ``$AEGIS_LICENSE_PATH``). Subsequent
    calls trust the in-memory state — callers that pre-set a license
    via ``set_active_license`` (demos, tests, sidecar reloads) keep
    control. Any exception is treated as "feature unavailable" so the
    firewall path is never crashed by an auxiliary license failure.
    """
    global _license_booted
    try:
        from aegis.license import (
            get_active_claims,
            has_feature,
            init_active_from_disk,
        )
        if not _license_booted and get_active_claims() is None:
            init_active_from_disk()
        _license_booted = True
        return has_feature("advisor.full")
    except Exception:  # noqa: BLE001 — defensive
        return False


def _compute_action_advice(
    *,
    inp: Any,
    verdict: Any,
    tool_name: str,
    transcript_path: Path | None,
    explain_block: dict[str, Any],
) -> dict[str, Any] | None:
    """Build the v2.5 ActionAdvice and return its dict form for the audit
    record. Returns ``None`` when the advisor is disabled or any sub-step
    fails — never raises so the firewall path is unaffected.

    Pulls the 4-layer narrative inputs (TemporalContext + burn-in baseline
    + trajectory catalog + intent classifier + action-embedding table)
    AND the v2.5.2 cost / cache / security signal dicts, then routes
    them through :func:`compose_advice_sllm`. Provider selection follows
    ``AEGIS_ADVISOR_PROVIDER`` (default ``dummy`` → heuristic).
    """
    if not ADVISOR_ENABLED:
        return None
    # License gate (LICENSE_KEY.md §9 step 6). The 8-advisor pipeline
    # is a Pro+ feature; without an active license that grants
    # ``advisor.full``, fall back silently to None (same observable
    # behavior as ADVISOR_ENABLED=0). This catches the case where a
    # Pro install + later license expiry: ADVISOR_ENABLED stays True
    # in the hook env, but the license is gone, so the advisor must
    # be inactive.
    #
    # Defensive: any error in the license module must NOT crash the
    # hook. Per the docs/THREAT_MODEL.md §5 P-3 contract, the
    # firewall path is never blocked by an auxiliary failure.
    if not _license_grants_advisor_full():
        return None
    try:
        from aegis.atv.temporal import load_recent_history
        from aegis.burnin.action_embeddings import load_table_or_default
        from aegis.burnin.anomaly import (
            compute_anomalies,
            load_baseline_or_default,
        )
        from aegis.burnin.intent_classifier import (
            load_classifier_or_default,
        )
        from aegis.burnin.trajectory_catalog import load_catalog_or_default
        from aegis.judge.advisor import compose_advice_sllm
        from aegis.judge.advisor_signals import (
            extract_cache_signals,
            extract_cost_signals,
            extract_security_signals,
        )

        ctx = load_recent_history(
            transcript_path=transcript_path,
            audit_path=LOCAL_AUDIT_PATH if LOCAL_AUDIT_PATH.is_file() else None,
            session_id=inp.header.aid,
        )
        baseline = load_baseline_or_default()
        catalog = load_catalog_or_default()
        classifier = load_classifier_or_default()
        action_table = load_table_or_default()

        anomalies = (
            compute_anomalies(temporal_ctx=ctx, baseline=baseline)
            if baseline is not None and baseline.is_usable()
            else []
        )

        cost_signals = extract_cost_signals(inp=inp, verdict=verdict)
        cache_signals = extract_cache_signals(temporal_ctx=ctx)
        security_signals = extract_security_signals(
            inp=inp, verdict=verdict, explain_block=explain_block,
        )

        # v2.7.1 — pass verdict.step_traces so the heuristic loop-breaker
        # fires on a fresh session that has the firewall's step336
        # trace but no burn-in redundancy baseline yet.
        verdict_traces = dict(getattr(verdict, "step_traces", {}) or {})

        advice = compose_advice_sllm(
            temporal_ctx=ctx,
            anomalies=anomalies,
            baseline=baseline,
            catalog=catalog,
            intent_classifier=classifier,
            action_table=action_table,
            base_decision=verdict.decision,
            base_reason=verdict.reason or "",
            current_tool=tool_name,
            cost_signals=cost_signals,
            cache_signals=cache_signals,
            security_signals=security_signals,
            step_traces=verdict_traces,
        )
        from aegis.judge.action_advice import advice_to_dict

        return advice_to_dict(advice)
    except Exception as e:  # noqa: BLE001 — advisor must never block
        if VERBOSE:
            _emit(f"advisor skipped: {e}")
        return None


def _append_audit(record: dict[str, Any]) -> None:
    """Append a chained audit record (v2.1.5 local-mode integrity).

    Each line carries ``prev_hash`` linking to the previous line's
    ``this_hash``, plus its own SHA3-256 ``this_hash``. Tampering
    with any historical line breaks every subsequent recompute, so
    ``aegis verify-audit`` (local mode) catches mutations.

    Side-effect: also appends an analytics-shaped projection of the
    record to ContextMemory (~/.aegis/context_memory.jsonl). The two
    stores are deliberately separate — audit is the cryptographic
    chain, ContextMemory is the silicon-ready analytics surface
    that ``aegis doctor`` reads.
    """
    try:
        from aegis.audit.local_chain import append as chain_append

        chain_append(LOCAL_AUDIT_PATH, record)
    except OSError:
        # Audit failure must never block the user's tool call.
        pass

    # ContextMemory write — fully defensive, swallows every error.
    # See src/aegis/context_memory/__init__.py for the silicon-roadmap
    # rationale (CXL SSD / Computational SSD emulation).
    try:
        from aegis.context_memory import append as cm_append
        cm_append(record, mode="local")
    except Exception:  # noqa: BLE001 — analytics writes never block
        pass


def handle_pretool(stdin: Any, stdout: Any) -> int:
    raw = stdin.read()
    if not raw or not raw.strip():
        if VERBOSE:
            _emit("no stdin payload — allowing")
        return 0
    try:
        event: dict[str, Any] = json.loads(raw)
    except json.JSONDecodeError as e:
        _emit(f"invalid PreToolUse JSON ({e}) — allowing")
        return 0

    if event.get("hook_event_name") not in (None, "", "PreToolUse"):
        return 0

    # Lazy imports keep startup small for the no-stdin / malformed case.
    import numpy as np

    from aegis.atv.adapter import (
        from_claude_code_payload,
        from_claude_code_payload_enhanced,
    )
    from aegis.atv.builder import build_atv
    from aegis.firewall.core import run_firewall

    t0 = time.perf_counter_ns()
    # Transcript-aware ATV builder when Claude Code passed transcript_path
    # (PreToolUse always does in v1.0+). Populates agent_state_text /
    # plan_text / recent_actions / memory_fingerprint / cost_estimate /
    # session_behavior — making step335 budget gate, novelty, and
    # session-drift signals real instead of zero. Falls back to the
    # sparse builder on missing / unparseable transcript so the hook
    # NEVER blocks a tool call because of transcript I/O.
    try:
        inp = from_claude_code_payload_enhanced(
            event, tenant_id=TENANT, model_for_cost=MODEL_FOR_COST,
        )
    except Exception as e:  # noqa: BLE001 — fall back, never block
        if VERBOSE:
            _emit(f"enhanced adapter failed ({e}) — falling back to sparse")
        inp = from_claude_code_payload(event, tenant_id=TENANT)

    # v2.3 HW telemetry — AEGIS_HW_PROVIDER=sim populates the 200-D HW
    # band so step337 + M12 cost-divergence can fire on real signals.
    # Returns None (zero-fill) when the env var is unset/none, matching
    # the sidecar's behaviour in src/aegis/api/evaluate.py.
    hw_counters = None
    try:
        from aegis.hw_telemetry.simulator import simulate_from_env

        hw_counters = simulate_from_env(inp)
    except Exception:  # noqa: BLE001 — HW telemetry must never block
        hw_counters = None

    atv: np.ndarray = build_atv(inp, hw=hw_counters)

    # M10 ATMU phase 1 — record TENTATIVE intent BEFORE the firewall.
    # Returns ``None`` if ATMU is disabled / initialisation failed; the
    # rest of the path runs unchanged in that case.
    intent_record_id = _atmu_open_intent(inp, atv)

    verdict = run_firewall(atv, inp, atv_id=inp.header.span_id)

    # M12 cost-divergence escalation — Claim 27 — independent of sLLM
    # judge. Mirrors src/aegis/api/evaluate.py:182. Only fires when the
    # HW band is populated (AEGIS_HW_PROVIDER=sim or =real). On HW-vs-SW
    # cost mismatch beyond 3× baseline, override ALLOW → REQUIRE_APPROVAL.
    # Wrapped in try/except — divergence calc must never block a tool call.
    if hw_counters is not None and verdict.decision == "ALLOW":
        try:
            from aegis.cost.divergence import compute_divergence
            from aegis.cost.escalation import evaluate_escalation

            divergence = compute_divergence(
                inp.cost_estimate,
                model_name=MODEL_FOR_COST,
                hw_flops_observed=hw_counters.flops_observed,
                hw_hbm_bytes_observed=hw_counters.hbm_bytes_observed,
            )
            esc = evaluate_escalation(divergence)
            if esc.triggered:
                verdict.decision = "REQUIRE_APPROVAL"
                verdict.reason = esc.reason
                verdict.step_traces["aegis.cost.escalation"] = (
                    f"M12: {esc.metric}={esc.observed:.3f} > "
                    f"threshold {esc.threshold:.3f}"
                )
                if VERBOSE:
                    _emit(f"M12 cost-divergence: {esc.metric}={esc.observed:.3f}")
        except Exception as e:  # noqa: BLE001 — telemetry, never block
            if VERBOSE:
                _emit(f"M12 escalation skipped: {e}")

    # v0.5.13: step331 — autonomy bypass. Short-circuits when
    # AEGIS_AUTONOMY_ENABLED is off (the operator's opt-in flag),
    # so legacy installs see byte-identical behaviour. When
    # enabled, downgrades a REQUIRE_APPROVAL whose (tool,
    # reason_signature) is in the learned trust table to ALLOW
    # + a permanent step_traces stamp; ε-greedy forced
    # exploration still asks the human in a deterministic
    # fraction of cases for drift / IPW coverage. Placed AFTER
    # the M12 cost-divergence escalation so the bypass evaluates
    # the *final* REQUIRE_APPROVAL signal, and BEFORE
    # _atmu_finalize_intent so ATMU records the bypassed verdict.
    try:
        from aegis.autonomy import apply_autonomy_bypass

        bypass_tool = event.get("tool_name", "") or inp.tool_name
        verdict, _autonomy_av = apply_autonomy_bypass(
            verdict,
            tool_name=bypass_tool,
            reason=verdict.reason or "",
        )
    except Exception as e:  # noqa: BLE001 — autonomy must never block
        if VERBOSE:
            _emit(f"autonomy bypass skipped: {e}")

    # M10 ATMU phase 1.5 — transition based on the (possibly M12-updated) verdict.
    _atmu_finalize_intent(intent_record_id, verdict.decision, verdict.reason or "")

    elapsed_ms = (time.perf_counter_ns() - t0) / 1_000_000

    tool_name = event.get("tool_name", "") or inp.tool_name
    decision = verdict.decision
    reason = verdict.reason or ""

    # Build the audit record. The base fields are unchanged from the
    # pre-#26 schema (`aegis verify-audit` and any downstream parsers
    # keep working). The new ``explain`` block carries the per-decision
    # signals so ``aegis report --explain`` can render the full "why"
    # — step traces, M13 attribution, RAG cases, session drift. Every
    # signal is a pure function of (atv, inp, verdict), so adding them
    # here doesn't change firewall behaviour.
    explain_block = _build_explain_block(atv, inp, verdict)
    if intent_record_id is not None:
        explain_block["intent_record_id"] = intent_record_id

    # v2.5 PR-ζ-head — opt-in ActionAdvice (heuristic by default; haiku
    # with AEGIS_ADVISOR_PROVIDER=haiku). v2.5.1 PR-ψ-gating ensures the
    # advisor only fires on "critical moments" so the 4-layer pipeline
    # and (optional) sLLM call don't run on every innocuous ALLOW.
    advice_dict: dict[str, Any] | None = None
    if ADVISOR_ENABLED:
        invoked, gate_reason = _should_invoke_advisor(verdict, explain_block)
        explain_block["advisor_gate"] = {
            "invoked": invoked,
            "reason": gate_reason,
        }
        if invoked:
            transcript_path_raw = event.get("transcript_path") or ""
            transcript_path = (
                Path(transcript_path_raw) if transcript_path_raw else None
            )
            advice_dict = _compute_action_advice(
                inp=inp,
                verdict=verdict,
                tool_name=event.get("tool_name", "") or inp.tool_name,
                transcript_path=transcript_path,
                explain_block=explain_block,
            )
            if advice_dict is not None:
                explain_block["action_advice"] = advice_dict

    # PR-A multi-agent attribution — promoted from the
    # session_behavior dict (where the adapter put them) to first-class
    # audit-record keys so `aegis report --by-aid` / `aegis cost
    # --by-aid` can group on them without diving into the explain
    # block. is_sidechain is a bool per-call; the subagent_count
    # fields are running totals over the session.
    sb = inp.session_behavior or {}
    audit_record: dict[str, Any] = {
        "ts_ns": time.time_ns(),
        "tool": tool_name,
        "aid": inp.header.aid,
        # v2.7 PR-ψ-retrospective — stamp invocation_id so the
        # PostToolUse hook can locate the matching PreToolUse
        # advice and compare predicted vs actual outcome.
        "invocation_id": event.get("invocation_id", "") or "",
        "decision": decision,
        "reason": reason,
        "trace_id": inp.header.trace_id,
        "latency_ms": round(elapsed_ms, 3),
        "mode": "local",
        "is_sidechain": bool(sb.get("sidechain_is_active", 0.0)),
        "sidechain_event_count": int(sb.get("sidechain_event_count", 0.0)),
        "sidechain_tool_call_count": int(sb.get("sidechain_tool_call_count", 0.0)),
        "explain": explain_block,
    }
    # PR-D OpenClaw multi-channel + provider attribution. Both fields
    # are stamped only when non-empty so Claude Code (single-channel
    # terminal, single-provider Anthropic) audit lines stay clean.
    if inp.header.channel:
        audit_record["channel"] = inp.header.channel
    if inp.header.provider:
        audit_record["provider"] = inp.header.provider
    _append_audit(audit_record)

    # Burn-in Shadow recording (opt-in via AEGIS_BURNIN_SHADOW=1).
    # Records the (ATVInput, verdict) pair for later M13 v2 retraining.
    # The shadow module is a no-op when the env flag is unset, so this
    # adds zero cost to the default Solo Free hot path.
    try:
        from aegis.burnin.shadow import record as _shadow_record
        _shadow_record(inp, verdict)
    except Exception:  # noqa: BLE001 — shadow must never block the tool
        pass

    if decision == "ALLOW":
        if VERBOSE:
            _emit(
                f"ALLOW  {tool_name}  trace={inp.header.trace_id[:8]}  "
                f"({elapsed_ms:.1f}ms)"
            )
        return 0

    if decision == "REQUIRE_APPROVAL" and not APPROVE_AS_BLOCK:
        _emit(
            f"WARN   {tool_name} would REQUIRE_APPROVAL — letting through "
            f"(AEGIS_APPROVE_AS_BLOCK=0)\n"
            f"           reason: {reason}"
        )
        return 0

    msg = (
        f"{decision}  {tool_name}  trace={inp.header.trace_id[:8]}  "
        f"({elapsed_ms:.1f}ms)\n"
        f"           reason: {reason}"
    )
    if advice_dict is not None:
        hint = advice_dict.get("next_action_hint")
        alt = advice_dict.get("alternative_tool")
        if hint:
            msg += f"\n           hint:   {hint}"
        if alt:
            msg += f"\n           alt:    try `{alt}` instead"
        # PR-ψ-multi-domain — surface up to 3 advisor recommendations
        # ranked by priority. Claude Code only sees stderr, so this is
        # the user-visible "call cost-optimizer + kv-cache-optimizer +
        # security-reviewer" pattern the design targets.
        # PR-ε (v2.8) — for each recommendation also render up to 2
        # ActionStep verbs with their key parameters so the operator
        # can see WHAT to do (e.g. "prune-turns indices=[-3,-2,-1]")
        # not just WHO to call.
        recs = advice_dict.get("recommended_advisors") or []
        if isinstance(recs, list) and recs:
            order = {"high": 0, "medium": 1, "low": 2}
            ranked = sorted(
                (r for r in recs if isinstance(r, dict)),
                key=lambda r: order.get(r.get("priority", "low"), 9),
            )[:3]
            if ranked:
                msg += "\n           advise:"
                for r in ranked:
                    pri = str(r.get("priority", "")).upper()
                    name = str(r.get("advisor", ""))
                    action = str(r.get("action", ""))
                    msg += f"\n             [{pri}] {name} — {action}"
                    steps = r.get("action_steps") or []
                    if isinstance(steps, list):
                        for step in steps[:2]:
                            if not isinstance(step, dict):
                                continue
                            verb = str(step.get("verb", ""))
                            params = step.get("parameters") or {}
                            params_str = (
                                _stderr_format_params(params)
                                if isinstance(params, dict)
                                else ""
                            )
                            impact = str(step.get("expected_impact", ""))
                            line = f"\n               • {verb}"
                            if params_str:
                                line += f" {params_str}"
                            if impact:
                                line += f" → {impact[:80]}"
                            msg += line
    _emit(msg)
    return 2


def main() -> int:
    return handle_pretool(sys.stdin, sys.stdout)


if __name__ == "__main__":
    raise SystemExit(main())
