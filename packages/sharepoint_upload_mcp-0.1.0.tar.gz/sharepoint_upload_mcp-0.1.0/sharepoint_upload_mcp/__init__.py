"""MCP server: upload files or Markdown to SharePoint via Microsoft Graph."""

__version__ = "0.1.0"
