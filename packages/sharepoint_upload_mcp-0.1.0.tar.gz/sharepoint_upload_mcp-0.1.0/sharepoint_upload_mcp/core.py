"""
Microsoft Graph upload logic for the SharePoint MCP server.

Kept in sync with scripts/upload-to-sharepoint.py (that script is standalone; change both if upload behavior changes).
"""

from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import quote

import msal
import requests

GRAPH_SCOPE = "https://graph.microsoft.com/.default"
GRAPH_SITE_LOOKUP = "https://graph.microsoft.com/v1.0/sites/{site_ref}"
GRAPH_SITE_UPLOAD = "https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{path}:/content"


def resolve_workspace_root() -> Path:
    """
    Root used to resolve relative file paths and to find `.env`.

    Set `SHAREPOINT_MCP_REPO_ROOT` when the MCP process cwd is not the repo root
    (e.g. in editor MCP configs). Defaults to current working directory.
    """
    raw = os.environ.get("SHAREPOINT_MCP_REPO_ROOT", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.cwd().resolve()


def _parse_env_line(line: str) -> tuple[str, str] | None:
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if "=" not in line:
        return None
    key, _, rest = line.partition("=")
    key = key.strip()
    val = rest.strip()
    if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
        val = val[1:-1]
    return key, val


def load_env_file(path: Path) -> bool:
    """Load KEY=VALUE pairs into os.environ (does not override existing vars)."""
    if not path.is_file():
        return False
    try:
        raw = path.read_text(encoding="utf-8-sig")
    except OSError:
        return False
    for line in raw.splitlines():
        parsed = _parse_env_line(line)
        if not parsed:
            continue
        k, v = parsed
        if k and k not in os.environ:
            os.environ[k] = v
    return True


def ensure_repo_dotenv_loaded() -> None:
    """Load `.env` from workspace root before reading SharePoint / Microsoft settings."""
    env_path = resolve_workspace_root() / ".env"
    try:
        from dotenv import load_dotenv

        load_dotenv(env_path, override=False)
        load_dotenv(override=False)
    except ImportError:
        pass
    load_env_file(env_path)


def get_token(tenant: str, client_id: str, device_flow: bool) -> str:
    authority = f"https://login.microsoftonline.com/{tenant}"
    app = msal.PublicClientApplication(client_id, authority=authority)
    if device_flow:
        flow = app.initiate_device_flow(scopes=[GRAPH_SCOPE])
        if "user_code" not in flow:
            raise ValueError(f"Device flow failed: {flow}")
        print(flow["message"], flush=True)
        result = app.acquire_token_by_device_flow(flow)
    else:
        result = app.acquire_token_interactive(scopes=[GRAPH_SCOPE])
    if "access_token" not in result:
        raise ValueError(f"Failed to get token: {result.get('error_description', result)}")
    return result["access_token"]


def resolve_token(
    tenant: str | None,
    client_id: str | None,
    device_flow: bool,
    access_token: str | None,
) -> str:
    if access_token and access_token.strip():
        return access_token.strip()
    cid = client_id or os.environ.get("MICROSOFT_CLIENT_ID")
    if not cid:
        raise ValueError("Set MICROSOFT_CLIENT_ID or GRAPH_ACCESS_TOKEN")
    tid = tenant or os.environ.get("MICROSOFT_TENANT_ID")
    if not tid:
        raise ValueError("Set MICROSOFT_TENANT_ID for MSAL auth")
    return get_token(tid, cid, device_flow)


def resolve_site_id(token: str, site_ref: str) -> str:
    url = GRAPH_SITE_LOOKUP.format(site_ref=quote(site_ref, safe=":/"))
    resp = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=60)
    if resp.status_code != 200:
        raise RuntimeError(f"Failed to resolve site ({resp.status_code}): {resp.text}")
    return resp.json()["id"]


def mime_for_path(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    return {
        ".md": "text/markdown",
        ".json": "application/json",
        ".html": "text/html",
        ".htm": "text/html",
        ".txt": "text/plain",
        ".pdf": "application/pdf",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".zip": "application/zip",
    }.get(ext, "application/octet-stream")


def resolve_local_path(local_path: str | Path) -> Path:
    """Resolve path; relative paths are interpreted from workspace root (see resolve_workspace_root)."""
    p = Path(local_path)
    if not p.is_absolute():
        p = (resolve_workspace_root() / p).resolve()
    return p


def upload_local_file_to_sharepoint(
    file_path: str | Path,
    *,
    destination_name: str | None = None,
    subfolder: str | None = None,
    base_path: str | None = None,
    site_host: str | None = None,
    site_path: str | None = None,
    tenant: str | None = None,
    client_id: str | None = None,
    device_flow: bool = False,
    access_token: str | None = None,
) -> dict[str, str]:
    """
    Upload a local file via Graph PUT .../drive/root:/{path}:/content.

    When a string parameter is None, the value is taken from the environment
    (same variables as scripts/upload-to-sharepoint.py).
    """
    ensure_repo_dotenv_loaded()

    path = resolve_local_path(file_path)
    if not path.is_file():
        raise ValueError(f"File not found: {path}")

    sh = site_host if site_host is not None else os.environ.get("SHAREPOINT_SITE_HOST")
    sp = site_path if site_path is not None else os.environ.get("SHAREPOINT_SITE_PATH")
    if not sh or not sp:
        raise ValueError(
            "SHAREPOINT_SITE_HOST and SHAREPOINT_SITE_PATH must be set (or passed explicitly)",
        )

    bp = base_path if base_path is not None else os.environ.get("SHAREPOINT_UPLOAD_BASE_PATH")
    if not bp:
        raise ValueError(
            "SHAREPOINT_UPLOAD_BASE_PATH must be set in .env or passed as base_path",
        )

    sf = (
        subfolder
        if subfolder is not None
        else os.environ.get("SHAREPOINT_UPLOAD_SUBFOLDER", "")
    )

    _cid = client_id if client_id is not None else os.environ.get("MICROSOFT_CLIENT_ID")
    _tok = access_token if access_token is not None else os.environ.get("GRAPH_ACCESS_TOKEN")
    if not _cid and not (_tok and _tok.strip()):
        raise ValueError("MICROSOFT_CLIENT_ID or GRAPH_ACCESS_TOKEN required")

    site_ref = f"{sh.rstrip(':')}{sp}"
    dest = destination_name or path.name
    parts = [bp.rstrip("/")]
    if sf:
        parts.append(sf.strip("/"))
    parts.append(dest)
    graph_path = "/".join(parts)
    path_encoded = quote(graph_path, safe="/")

    token = resolve_token(tenant, client_id, device_flow, access_token)
    site_id = resolve_site_id(token, site_ref)
    url = GRAPH_SITE_UPLOAD.format(site_id=site_id, path=path_encoded)

    content = path.read_bytes()
    resp = requests.put(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": mime_for_path(str(path)),
        },
        data=content,
        timeout=120,
    )

    if resp.status_code not in (200, 201):
        raise RuntimeError(f"Upload failed ({resp.status_code}): {resp.text}")

    data = resp.json()
    return {
        "webUrl": str(data.get("webUrl", "")),
        "graphPath": graph_path,
        "id": str(data.get("id", "")),
    }
