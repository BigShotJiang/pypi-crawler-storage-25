from sharepoint_upload_mcp.server import main

main()
