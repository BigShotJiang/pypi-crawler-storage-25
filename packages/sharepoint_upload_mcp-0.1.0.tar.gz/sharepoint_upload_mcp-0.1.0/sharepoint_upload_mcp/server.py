#!/usr/bin/env python3
"""MCP server: upload files or Markdown to SharePoint (same Graph flow as upload-to-sharepoint.py)."""

from __future__ import annotations

import tempfile
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from sharepoint_upload_mcp import core

mcp = FastMCP(
    "SharePoint documentation upload",
    instructions=(
        "Upload to the team SharePoint library via Microsoft Graph. "
        "Configure .env in the workspace root (or set SHAREPOINT_MCP_REPO_ROOT) with "
        "SHAREPOINT_SITE_HOST, SHAREPOINT_SITE_PATH, SHAREPOINT_UPLOAD_BASE_PATH, "
        "MICROSOFT_TENANT_ID, MICROSOFT_CLIENT_ID (or GRAPH_ACCESS_TOKEN). "
        "Relative local paths resolve from that root. "
        "For raw Markdown from the session, use sharepoint_upload_markdown so encoding and text/markdown are correct."
    ),
)


@mcp.tool()
def sharepoint_upload_file(
    local_path: str,
    destination_name: str | None = None,
    subfolder: str | None = None,
    base_path: str | None = None,
    site_host: str | None = None,
    site_path: str | None = None,
    device_flow: bool = False,
) -> dict[str, str]:
    """
    Upload a file from disk. Use a path under the repo (e.g. docs/Handoff.md) or an absolute path.
    Optional overrides match the CLI flags; when omitted, values come from .env.
    Set device_flow true only if interactive browser login is unavailable (uses device code in logs).
    """
    return core.upload_local_file_to_sharepoint(
        local_path,
        destination_name=destination_name,
        subfolder=subfolder,
        base_path=base_path,
        site_host=site_host,
        site_path=site_path,
        device_flow=device_flow,
    )


@mcp.tool()
def sharepoint_upload_markdown(
    filename: str,
    content: str,
    subfolder: str | None = None,
    destination_name: str | None = None,
    base_path: str | None = None,
    site_host: str | None = None,
    site_path: str | None = None,
    device_flow: bool = False,
) -> dict[str, str]:
    """
    Write Markdown as UTF-8 and upload with Content-Type text/markdown.
    `filename` is the remote basename (e.g. OC-9227-Feature.md). If it lacks .md, the suffix is added.
    `destination_name` overrides the remote filename when set.
    """
    name = (destination_name or filename).strip()
    if not name.lower().endswith(".md"):
        name = f"{name}.md"

    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        suffix=".md",
        delete=False,
    ) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    try:
        return core.upload_local_file_to_sharepoint(
            tmp_path,
            destination_name=name,
            subfolder=subfolder,
            base_path=base_path,
            site_host=site_host,
            site_path=site_path,
            device_flow=device_flow,
        )
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
