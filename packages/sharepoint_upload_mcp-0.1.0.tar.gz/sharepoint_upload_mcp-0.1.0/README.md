# sharepoint-upload-mcp

Python MCP server that uploads files or Markdown to SharePoint using Microsoft Graph (same behavior as the ChartSwap `scripts/upload-to-sharepoint.py` CLI).

## Install

From PyPI (after publish):

```bash
pip install sharepoint-upload-mcp
```

From this monorepo (editable, for development):

```bash
pip install -e ./packages/sharepoint-upload-mcp
```

## Environment

Set in `.env` at the workspace root (or in the process environment):

- `SHAREPOINT_SITE_HOST`, `SHAREPOINT_SITE_PATH`, `SHAREPOINT_UPLOAD_BASE_PATH`
- `MICROSOFT_TENANT_ID`, `MICROSOFT_CLIENT_ID` (or `GRAPH_ACCESS_TOKEN`)

Optional:

- `SHAREPOINT_MCP_REPO_ROOT` — directory used to resolve relative file paths and to load `.env`. If unset, the current working directory is used.

## Run (stdio MCP)

```bash
python -m sharepoint_upload_mcp
```

Or use the console script:

```bash
sharepoint-upload-mcp
```

## Cursor / MCP config example

```json
"sharepoint-upload": {
  "command": "py",
  "args": ["-m", "sharepoint_upload_mcp"],
  "env": {
    "SHAREPOINT_MCP_REPO_ROOT": "${workspaceFolder}"
  }
}
```

## Tools

- `sharepoint_upload_file` — upload a file from disk (relative paths use `SHAREPOINT_MCP_REPO_ROOT` or cwd).
- `sharepoint_upload_markdown` — upload UTF-8 Markdown with `text/markdown`.
