from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ssdlab-region-parser",
    version="0.1.0",
    author="ChufanHe",
    author_email="sthechufan@gmail.com",
    description="Chinese administrative region parser, not include Hong Kong, Macau and Taiwan yet.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.10",
    install_requires=[
        "pandas>=2.0",
        "jieba>=0.42.1",
        "openpyxl>=3.1.0",
    ],
    package_data={
        "region_parser.data": ["*.xlsx"],
    },
    include_package_data=True,
)