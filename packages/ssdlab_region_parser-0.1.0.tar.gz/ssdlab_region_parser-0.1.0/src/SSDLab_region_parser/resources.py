from importlib.resources import files
import pandas as pd
import jieba

from .models import CN_RegionResources


RESOURCE_PACKAGE = "region_parser.data"
REGION_EXCEL_NAME = "CN_Region_Reference_Library.xlsx"


def split_keywords(series: pd.Series) -> list[str]:
    words = (
        series.dropna()
        .astype(str)
        .str.split("|", regex=False)
        .explode()
        .astype(str)
        .str.strip()
    )
    words = words[words != ""].unique().tolist()
    words.sort(key=len, reverse=True)
    return words


def load_region_code_table() -> pd.DataFrame:
    excel_path = files(RESOURCE_PACKAGE).joinpath(REGION_EXCEL_NAME)
    return pd.read_excel(excel_path)


def build_word_to_paths(df_paths: pd.DataFrame) -> dict:
    word_to_paths = {}

    for _, row in df_paths.iterrows():
        path = row["path"]
        for col in ["省级关键词", "市级关键词", "区县关键词"]:
            value = row.get(col)
            if pd.isna(value):
                continue

            for word in str(value).split("|"):
                word = word.strip()
                if not word:
                    continue

                if word not in word_to_paths:
                    word_to_paths[word] = set()
                word_to_paths[word].add(path)

    return word_to_paths


def build_region_resources() -> CN_RegionResources:
    df_region_code = load_region_code_table()

    province_keywords = split_keywords(df_region_code["省级关键词"])
    city_keywords = split_keywords(df_region_code["市级关键词"])
    county_keywords = split_keywords(df_region_code["区县关键词"])

    region_keywords = sorted(
        set(province_keywords + city_keywords + county_keywords),
        key=len,
        reverse=True,
    )

    word_set = set(region_keywords)

    df_province = (
        df_region_code[["省级名称", "省级关键词", "省份代码"]]
        .dropna(subset=["省级关键词"])
        .assign(省级关键词=lambda x: x["省级关键词"].str.split("|", regex=False))
        .explode("省级关键词")
        .assign(省级关键词=lambda x: x["省级关键词"].astype(str).str.strip())
        .query("省级关键词 != ''")
        .drop_duplicates()
        .reset_index(drop=True)
    )
    province_dict = df_province.set_index("省级关键词")["省级名称"].to_dict()

    df_city = (
        df_region_code[["城市名称", "市级关键词", "城市代码"]]
        .dropna(subset=["市级关键词"])
        .assign(市级关键词=lambda x: x["市级关键词"].str.split("|", regex=False))
        .explode("市级关键词")
        .assign(市级关键词=lambda x: x["市级关键词"].astype(str).str.strip())
        .query("市级关键词 != ''")
        .drop_duplicates()
        .reset_index(drop=True)
    )
    city_dict = df_city.set_index("市级关键词")["城市名称"].to_dict()

    df_county = (
        df_region_code[["区县名称", "区县关键词", "区县代码"]]
        .dropna(subset=["区县关键词"])
        .assign(区县关键词=lambda x: x["区县关键词"].str.split("|", regex=False))
        .explode("区县关键词")
        .assign(区县关键词=lambda x: x["区县关键词"].astype(str).str.strip())
        .query("区县关键词 != ''")
        .drop_duplicates()
        .reset_index(drop=True)
    )
    county_dict = df_county.set_index("区县关键词")["区县名称"].to_dict()

    region_mapping_dict = {**province_dict, **city_dict, **county_dict}

    df_paths = df_region_code[
        ["省级名称", "城市名称", "区县名称", "省级关键词", "市级关键词", "区县关键词"]
    ].copy()

    df_paths["path"] = (
        df_paths["省级名称"].fillna("") + "|" +
        df_paths["城市名称"].fillna("") + "|" +
        df_paths["区县名称"].fillna("")
    )

    word_to_paths = build_word_to_paths(df_paths)

    return CN_RegionResources(
        df_region_code=df_region_code,
        province_keywords=province_keywords,
        city_keywords=city_keywords,
        county_keywords=county_keywords,
        region_keywords=region_keywords,
        word_set=word_set,
        province_dict=province_dict,
        city_dict=city_dict,
        county_dict=county_dict,
        region_mapping_dict=region_mapping_dict,
        df_paths=df_paths,
        word_to_paths=word_to_paths,
    )


def load_keywords_into_jieba(words: list[str]) -> None:
    for word in words:
        jieba.add_word(word, freq=1000)