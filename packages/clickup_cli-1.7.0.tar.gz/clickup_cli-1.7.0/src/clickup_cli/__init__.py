"""ClickUp CLI — the missing ClickUp CLI for developers and AI agents."""

__version__ = "1.7.0"
