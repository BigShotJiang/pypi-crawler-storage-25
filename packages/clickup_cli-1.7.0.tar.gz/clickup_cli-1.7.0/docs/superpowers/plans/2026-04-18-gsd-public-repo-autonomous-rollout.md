# GSD Public Repo Autonomous Rollout Implementation Plan

> Historical plan retained for context. This document describes a past planning/execution workflow and is not a live instruction file for repository contributors.

> `.planning/*` note: paths in this document refer to local historical planning artifacts from that workflow. They are included as archival context only.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

## Quick Links

- [Superpowers Docs Index](../README.md)
- [Related design spec](../specs/2026-04-18-gsd-public-repo-autonomous-design.md)
- [File Structure](#file-structure)
- [Task 1: Add Canonical Public Repo Rules](#task-1-add-canonical-public-repo-rules)
- [Task 2: Align Top-Level Milestone Docs](#task-2-align-top-level-milestone-docs)
- [Task 3: Add the Dedicated Phase 8 Release Closeout Plan](#task-3-add-the-dedicated-phase-8-release-closeout-plan)
- [Task 4: Propagate the Inline Public Repo Rules to Every Plan File](#task-4-propagate-the-inline-public-repo-rules-to-every-plan-file)

**Goal:** Retrofit this repo's current `.planning/` artifacts so autonomous GSD execution uses public-repo-safe human-authored commit and release language, propagates that rule into every phase plan, and finishes Phase 8 with an explicit version/release closeout plan.

**Architecture:** Add one canonical `.planning/PUBLIC-REPO-RULES.md` document, align the top-level milestone docs to reference it and stop contradicting release execution, then propagate the same in-band rules into every existing `*-PLAN.md`. Keep release closeout as its own Phase 8 plan (`08-03-PLAN.md`) so manifest refactor rollback stays separate from shipping/release work.

**Tech Stack:** Markdown planning artifacts, JSON config awareness, Python 3 verification scripts, shell validation commands, existing repo release workflow in `.claude/skills/release/SKILL.md`

---

## File Structure

- Create: `.planning/PUBLIC-REPO-RULES.md`
  Responsibility: canonical execution-policy document for public-repo-safe commit and release language.
- Create: `.planning/phases/08-unified-command-manifest/08-03-PLAN.md`
  Responsibility: dedicated Phase 8 release closeout plan covering version bump, changelog, validation, build, tag, publish, push, and GitHub release.
- Modify: `.planning/PROJECT.md`
  Responsibility: stop treating release work as out of scope, reference the canonical policy, and describe milestone closeout accurately.
- Modify: `.planning/REQUIREMENTS.md`
  Responsibility: add a closeout requirement without corrupting the 18 audit-finding traceability.
- Modify: `.planning/ROADMAP.md`
  Responsibility: extend Phase 8 to include release closeout and list the new `08-03-PLAN.md`.
- Modify: `.planning/STATE.md`
  Responsibility: make the live milestone state explicit about public-repo execution rules and the final release-closeout gate.
- Leave unchanged: `.planning/config.json`
  Responsibility: stay untouched because the public-repo policy lives in markdown docs, not in workflow toggles.
- Modify: `.planning/phases/01-contract-integrity-fixes/01-01-PLAN.md`
- Modify: `.planning/phases/01-contract-integrity-fixes/01-02-PLAN.md`
- Modify: `.planning/phases/01-contract-integrity-fixes/01-03-PLAN.md`
- Modify: `.planning/phases/02-space-and-docs-scope-corrections/02-01-PLAN.md`
- Modify: `.planning/phases/02-space-and-docs-scope-corrections/02-02-PLAN.md`
- Modify: `.planning/phases/03-config-identity-and-runtime-context/03-01-PLAN.md`
- Modify: `.planning/phases/03-config-identity-and-runtime-context/03-02-PLAN.md`
- Modify: `.planning/phases/03-config-identity-and-runtime-context/03-03-PLAN.md`
- Modify: `.planning/phases/04-bounded-task-payloads/04-01-PLAN.md`
- Modify: `.planning/phases/04-bounded-task-payloads/04-02-PLAN.md`
- Modify: `.planning/phases/05-maintainability-cleanup/05-01-PLAN.md`
- Modify: `.planning/phases/05-maintainability-cleanup/05-02-PLAN.md`
- Modify: `.planning/phases/06-test-boundary-cleanup/06-01-PLAN.md`
- Modify: `.planning/phases/06-test-boundary-cleanup/06-02-PLAN.md`
- Modify: `.planning/phases/07-tasks-command-decomposition/07-01-PLAN.md`
- Modify: `.planning/phases/07-tasks-command-decomposition/07-02-PLAN.md`
- Modify: `.planning/phases/08-unified-command-manifest/08-01-PLAN.md`
- Modify: `.planning/phases/08-unified-command-manifest/08-02-PLAN.md`
  Responsibility for all existing plan files: carry the same inline public-repo execution block so executor agents see the rule in-band.

### Task 1: Add Canonical Public Repo Rules

**Files:**
- Create: `.planning/PUBLIC-REPO-RULES.md`

- [ ] **Step 1: Write the failing verification for the missing canonical policy file**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path('.planning/PUBLIC-REPO-RULES.md')
assert path.exists(), 'missing canonical public repo rules file'
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: FAIL with `AssertionError: missing canonical public repo rules file`

- [ ] **Step 2: Create `.planning/PUBLIC-REPO-RULES.md` with the exact policy text**

```markdown
# Public Repo Execution Rules

## Repository Status

- This repository is public. Treat every autonomous commit, tag, changelog entry, release note, and GitHub release artifact as public-facing output.

## Commit Language

- Write commit messages like a normal human developer working in a public repository.
- Never mention AI, agent names, Claude, GSD, generated-by phrasing, or automation provenance in commit subjects or bodies.
- Keep commit text focused on the code or documentation change itself.

## Release Language

- Apply the same human-authored standard to `CHANGELOG.md`, GitHub release notes, and any other release-facing text.
- If a tool generates AI-sounding release text, rewrite it before committing, tagging, publishing, or posting.

## Autonomous Execution Scope

- These rules apply to wave commits, phase commits, milestone closeout commits, tag metadata, and release artifacts produced by autonomous execution.
- If a plan file contains additional release-specific instructions, those instructions augment this policy and do not replace it.

## Milestone Completion

- A milestone that includes release closeout is not complete until version bump, validation, build, tag, publish, push, and GitHub release creation all finish successfully.
```

- [ ] **Step 3: Run the verification again and confirm the policy markers exist**

```bash
python3 - <<'PY'
from pathlib import Path

text = Path('.planning/PUBLIC-REPO-RULES.md').read_text()
for needle in [
    '# Public Repo Execution Rules',
    '## Commit Language',
    'Never mention AI, agent names, Claude, GSD, generated-by phrasing',
    '## Milestone Completion',
]:
    assert needle in text, f'missing marker: {needle}'
print('ok: canonical public repo policy exists and contains the required rules')
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: PASS with `ok: canonical public repo policy exists and contains the required rules`

- [ ] **Step 4: Commit the new policy file if the execution session has commit approval**

```bash
git add .planning/PUBLIC-REPO-RULES.md && git commit -m "docs: add public repo execution rules"
```

### Task 2: Align Top-Level Milestone Docs

**Files:**
- Modify: `.planning/PROJECT.md`
- Modify: `.planning/REQUIREMENTS.md`
- Modify: `.planning/ROADMAP.md`
- Modify: `.planning/STATE.md`

- [ ] **Step 1: Write the failing verification for the current top-level contradictions**

```bash
python3 - <<'PY'
from pathlib import Path

project = Path('.planning/PROJECT.md').read_text()
requirements = Path('.planning/REQUIREMENTS.md').read_text()
roadmap = Path('.planning/ROADMAP.md').read_text()
state = Path('.planning/STATE.md').read_text()

assert '.planning/PUBLIC-REPO-RULES.md' in project, 'project doc missing public repo policy reference'
assert 'CLOSEOUT-001' in requirements, 'requirements missing release closeout requirement'
assert '08-03-PLAN.md' in roadmap, 'roadmap missing Phase 8 closeout plan'
assert '.planning/PUBLIC-REPO-RULES.md' in state, 'state missing public repo policy reference'
assert 'Release, publish, or push work' not in requirements, 'requirements still mark release work out of scope'
assert 'planning and local git commits only for this milestone' not in project, 'project still describes release work as out of scope'
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: FAIL on the first missing marker or stale out-of-scope line

- [ ] **Step 2: Update `.planning/PROJECT.md` so it references the new policy and stops excluding release work**

```markdown
Use this exact replacement for the current `### Out of Scope` block:

### Out of Scope

- New ClickUp command groups or endpoint coverage beyond the audited findings — this milestone is remediation, not product expansion.
- A user-facing `--workspace` CLI override — deferred until the internal workspace-context seam exists cleanly.
- Streaming or non-JSON output modes — would violate the core machine-consumable contract.
- Changes to the global GSD framework outside this repository — this milestone only updates repo-local planning and execution artifacts.

Add this exact constraint line under `## Constraints`:

- **Public Repo Execution**: This repo is public. All autonomous execution must follow `.planning/PUBLIC-REPO-RULES.md`, including human-authored commit, changelog, and release text.

Add this exact bullet to `## Current Milestone: v1.1 Audit Remediation` under `**Target features:**`:

- Finish milestone closeout with version bump, validation, publish, and GitHub release steps after the Phase 8 implementation plans complete
```

- [ ] **Step 3: Update `.planning/REQUIREMENTS.md` with a dedicated closeout requirement and corrected coverage**

```markdown
Insert this exact section after `### Structural Refactors`:

### Milestone Closeout

- [ ] **CLOSEOUT-001**: After Phase 8 implementation plans complete, the milestone finishes with repo release closeout: version bump in `src/clickup_cli/__init__.py` and `tests/test_cli.py`, changelog update, `ruff check src/ tests/`, `pytest -v`, `clickup --help`, `bash scripts/validate-cli-output.sh`, build, tag, publish, push, and GitHub release creation.

Remove this exact out-of-scope table row:

| Release/publish/push work | This session is planning-only and push is explicitly disallowed. |

Add this exact traceability row:

| CLOSEOUT-001 | Phase 8 | Pending |

Replace the existing `**Coverage:**` block with this exact text:

**Coverage:**
- Audit requirements: 18 total
- Mapped to phases: 18
- Unmapped audit requirements: 0 ✓
- Closeout requirements: 1 total
- Unmapped closeout requirements: 0 ✓
```

- [ ] **Step 4: Update `.planning/ROADMAP.md` and `.planning/STATE.md` for Phase 8 closeout and live-state accuracy**

```markdown
In `.planning/ROADMAP.md`, make these exact changes:

1. Replace the `## Overview` paragraph with:

Milestone v1.1 remediates the canonical audit corpus in reviewable slices: first lock down contract and correctness regressions, then straighten config/runtime seams, then bound high-risk payload paths, and finally pay down the structural hotspots that make future regressions likely. Each phase is scoped so behavior changes and refactors stay separable when practical, verification is explicit, rollback remains obvious in a public repo, and autonomous execution preserves human-authored public-repo commit and release language.

2. Replace the Phase 8 summary line with:

- [ ] **Phase 8: Unified Command Manifest** - Make parser registration and dispatch derive from one manifest, then finish the milestone with version and release closeout.

3. In the Phase 8 detail block, replace `**Plans**: 2 plans` with `**Plans**: 3 plans` and append this exact plan line:

- [ ] 08-03-PLAN.md — Run version bump and release closeout using the repo release workflow and public-repo language rules.

4. Add this exact Phase 8 success criterion as item 5:

5. Phase 8 is not complete until version bump, changelog update, validation, build, tag, publish, push, and GitHub release creation all succeed under the public-repo execution rules.

6. In the progress table, change the Phase 8 row from `0/2` to `0/3`.

In `.planning/STATE.md`, make these exact changes:

1. Add this exact line under `### Decisions` after the existing three bullets:

- Public-repo execution rules apply to every phase and release artifact in this milestone; see `.planning/PUBLIC-REPO-RULES.md`.

2. Add this exact line under `### Blockers/Concerns`:

- Milestone completion now includes Phase 8 release closeout; do not mark the milestone done after `08-02` alone.
```

- [ ] **Step 5: Run the verification again and confirm the top-level docs are aligned**

```bash
python3 - <<'PY'
from pathlib import Path

project = Path('.planning/PROJECT.md').read_text()
requirements = Path('.planning/REQUIREMENTS.md').read_text()
roadmap = Path('.planning/ROADMAP.md').read_text()
state = Path('.planning/STATE.md').read_text()

assert '.planning/PUBLIC-REPO-RULES.md' in project
assert 'Finish milestone closeout with version bump, validation, publish, and GitHub release steps after the Phase 8 implementation plans complete' in project
assert 'CLOSEOUT-001' in requirements
assert '| CLOSEOUT-001 | Phase 8 | Pending |' in requirements
assert '| Release/publish/push work | This session is planning-only and push is explicitly disallowed. |' not in requirements
assert '08-03-PLAN.md' in roadmap
assert '0/3' in roadmap
assert '.planning/PUBLIC-REPO-RULES.md' in state
assert 'do not mark the milestone done after `08-02` alone' in state
print('ok: top-level planning docs are aligned with public repo execution and Phase 8 closeout')
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: PASS with `ok: top-level planning docs are aligned with public repo execution and Phase 8 closeout`

- [ ] **Step 6: Commit the top-level planning doc changes if the execution session has commit approval**

```bash
git add .planning/PROJECT.md .planning/REQUIREMENTS.md .planning/ROADMAP.md .planning/STATE.md && git commit -m "docs: align milestone docs with public repo release closeout"
```

### Task 3: Add the Dedicated Phase 8 Release Closeout Plan

**Files:**
- Create: `.planning/phases/08-unified-command-manifest/08-03-PLAN.md`

- [ ] **Step 1: Write the failing verification for the missing Phase 8 closeout plan file**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path('.planning/phases/08-unified-command-manifest/08-03-PLAN.md')
assert path.exists(), 'missing Phase 8 release closeout plan'
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: FAIL with `AssertionError: missing Phase 8 release closeout plan`

- [ ] **Step 2: Create `.planning/phases/08-unified-command-manifest/08-03-PLAN.md` with the exact release-closeout content**

```markdown
---
phase: 08-unified-command-manifest
plan: 03
type: execute
wave: 3
depends_on:
  - 08-02
files_modified:
  - src/clickup_cli/__init__.py
  - tests/test_cli.py
  - CHANGELOG.md
autonomous: true
requirements:
  - CLOSEOUT-001
must_haves:
  truths:
    - "The shipped package version is bumped in `src/clickup_cli/__init__.py` and `tests/test_cli.py`."
    - "`CHANGELOG.md` gains a new top entry that describes the release in human-authored public-repo language."
    - "Release validation runs `ruff check src/ tests/`, `pytest -v`, `clickup --help`, and `bash scripts/validate-cli-output.sh` before tag and publish steps."
    - "Commit text, changelog prose, tag metadata, and GitHub release notes never mention AI, agent names, Claude, GSD, or generated-by phrasing."
    - "Phase 8 is not complete until version bump, validation, build, tag, publish, push, and GitHub release creation all succeed."
  artifacts:
    - path: src/clickup_cli/__init__.py
      provides: "Bumped package version"
      contains: "__version__ = "
    - path: tests/test_cli.py
      provides: "Updated version flag assertion"
      contains: "test_version_flag"
    - path: CHANGELOG.md
      provides: "New top release entry"
      contains: "## "
---

## Public Repo Execution Rules

- This repository is public. Treat every commit, changelog entry, release note, tag, and GitHub release artifact as public-facing.
- Use normal human developer commit subjects and bodies.
- Never mention AI, agent names, Claude, GSD, or generated-by phrasing in commit or release text.
- Keep commit summaries focused on the code or doc change itself.
- The release workflow in `.claude/skills/release/SKILL.md` must still be executed with these language constraints.

<objective>
Finish milestone v1.1 by shipping the audited changes as a real public release.

Purpose: perform the version bump, changelog update, validation, build, publish, and GitHub release steps that make Phase 8 truly complete.
Output: bumped version files, a new changelog entry, validated build artifacts, a pushed tag, a published PyPI release, and a GitHub release.
</objective>

<execution_context>
@.planning/PUBLIC-REPO-RULES.md
@.claude/skills/release/SKILL.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/ROADMAP.md
@.planning/REQUIREMENTS.md
@src/clickup_cli/__init__.py
@tests/test_cli.py
@CHANGELOG.md
@.claude/skills/release/SKILL.md
</context>

<tasks>

<task type="auto" tdd="false">
  <name>Task 1: Bump the version and write the release entry</name>
  <files>src/clickup_cli/__init__.py, tests/test_cli.py, CHANGELOG.md</files>
  <behavior>
    - The package version is incremented in the runtime source and the version-flag test.
    - `CHANGELOG.md` gets a new top section matching the existing date/version format.
    - Release-facing prose stays human-authored and public-repo-safe.
  </behavior>
  <action>Update `src/clickup_cli/__init__.py`, update `tests/test_cli.py::test_version_flag`, and add the new top `CHANGELOG.md` entry using the repo's existing release-note style. Do not add any AI or agent attribution to commit text, changelog prose, or release notes.</action>
  <verify>
    <automated>python3 - <<'PY'
from pathlib import Path
assert '__version__ = ' in Path('src/clickup_cli/__init__.py').read_text()
assert 'test_version_flag' in Path('tests/test_cli.py').read_text()
assert Path('CHANGELOG.md').read_text().splitlines()[2].startswith('## ')
print('ok: release files updated')
PY</automated>
  </verify>
  <done>The version and changelog are updated and the release text is public-repo-safe.</done>
</task>

<task type="auto" tdd="false">
  <name>Task 2: Run release validation and build artifacts</name>
  <files>src/clickup_cli/__init__.py, tests/test_cli.py, CHANGELOG.md</files>
  <behavior>
    - Release validation runs exactly the repo checks defined in `.claude/skills/release/SKILL.md`.
    - Build artifacts are created locally and verified before any publish step.
  </behavior>
  <action>Run `ruff check src/ tests/`, `pytest -v`, `clickup --help`, `bash scripts/validate-cli-output.sh`, `python -m build`, and `python -m twine check dist/*` in that order. Do not tag or publish until all validation steps pass.</action>
  <verify>
    <automated>ruff check src/ tests/ && pytest -v && clickup --help >/dev/null && bash scripts/validate-cli-output.sh && python -m build && python -m twine check dist/*</automated>
  </verify>
  <done>Validation passes and local build artifacts are ready for release.</done>
</task>

<task type="auto" tdd="false">
  <name>Task 3: Tag, publish, push, and create the GitHub release</name>
  <files>src/clickup_cli/__init__.py, tests/test_cli.py, CHANGELOG.md</files>
  <behavior>
    - The release commit and tag are created with human-authored text.
    - PyPI publish, git push, and GitHub release creation all complete.
    - The final public release artifacts stay free of AI or agent attribution.
  </behavior>
  <action>Follow `.claude/skills/release/SKILL.md` exactly for commit, tag, publish, push, and `gh release create`. Derive GitHub release notes from the new `CHANGELOG.md` entry, and rewrite any AI-sounding generated prose before publishing.</action>
  <verify>
    <automated>git describe --tags --exact-match HEAD && gh release list | grep -F "Latest"</automated>
  </verify>
  <done>The package is released, pushed, and represented by a GitHub release with human-authored notes.</done>
</task>

</tasks>
```

- [ ] **Step 3: Verify the new Phase 8 plan exists and carries the release markers**

```bash
python3 - <<'PY'
from pathlib import Path

text = Path('.planning/phases/08-unified-command-manifest/08-03-PLAN.md').read_text()
for needle in [
    'phase: 08-unified-command-manifest',
    'requirements:\n  - CLOSEOUT-001',
    '## Public Repo Execution Rules',
    '.claude/skills/release/SKILL.md',
    'Tag, publish, push, and create the GitHub release',
]:
    assert needle in text, f'missing marker: {needle}'
print('ok: Phase 8 closeout plan exists and contains the release workflow markers')
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: PASS with `ok: Phase 8 closeout plan exists and contains the release workflow markers`

- [ ] **Step 4: Commit the new Phase 8 closeout plan if the execution session has commit approval**

```bash
git add .planning/phases/08-unified-command-manifest/08-03-PLAN.md && git commit -m "docs: add phase 8 release closeout plan"
```

### Task 4: Propagate the Inline Public Repo Rules to Every Plan File

**Files:**
- Modify: `.planning/phases/01-contract-integrity-fixes/01-01-PLAN.md`
- Modify: `.planning/phases/01-contract-integrity-fixes/01-02-PLAN.md`
- Modify: `.planning/phases/01-contract-integrity-fixes/01-03-PLAN.md`
- Modify: `.planning/phases/02-space-and-docs-scope-corrections/02-01-PLAN.md`
- Modify: `.planning/phases/02-space-and-docs-scope-corrections/02-02-PLAN.md`
- Modify: `.planning/phases/03-config-identity-and-runtime-context/03-01-PLAN.md`
- Modify: `.planning/phases/03-config-identity-and-runtime-context/03-02-PLAN.md`
- Modify: `.planning/phases/03-config-identity-and-runtime-context/03-03-PLAN.md`
- Modify: `.planning/phases/04-bounded-task-payloads/04-01-PLAN.md`
- Modify: `.planning/phases/04-bounded-task-payloads/04-02-PLAN.md`
- Modify: `.planning/phases/05-maintainability-cleanup/05-01-PLAN.md`
- Modify: `.planning/phases/05-maintainability-cleanup/05-02-PLAN.md`
- Modify: `.planning/phases/06-test-boundary-cleanup/06-01-PLAN.md`
- Modify: `.planning/phases/06-test-boundary-cleanup/06-02-PLAN.md`
- Modify: `.planning/phases/07-tasks-command-decomposition/07-01-PLAN.md`
- Modify: `.planning/phases/07-tasks-command-decomposition/07-02-PLAN.md`
- Modify: `.planning/phases/08-unified-command-manifest/08-01-PLAN.md`
- Modify: `.planning/phases/08-unified-command-manifest/08-02-PLAN.md`

- [ ] **Step 1: Write the failing verification for missing inline execution blocks**

```bash
python3 - <<'PY'
from pathlib import Path

plan_paths = sorted(Path('.planning/phases').glob('*/*-PLAN.md'))
missing = [str(path) for path in plan_paths if '## Public Repo Execution Rules' not in path.read_text()]
assert not missing, 'missing public repo execution block:\n' + '\n'.join(missing)
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: FAIL and list the 18 existing plan files that still lack the inline block

- [ ] **Step 2: Insert the exact inline block into every existing plan file immediately after the closing frontmatter `---`**

```markdown
Insert this exact block into each of the 18 existing `*-PLAN.md` files immediately after the closing frontmatter `---` and before `<objective>`:

## Public Repo Execution Rules

- This repository is public. Treat every commit, changelog entry, release note, tag, and GitHub release artifact as public-facing.
- Use normal human developer commit subjects and bodies.
- Never mention AI, agent names, Claude, GSD, or generated-by phrasing in commit or release text.
- Keep commit summaries focused on the code or doc change itself.
- Follow `.planning/PUBLIC-REPO-RULES.md` for the canonical repo-wide policy.
```

- [ ] **Step 3: Run the propagation verification again and confirm every plan file now carries the block**

```bash
python3 - <<'PY'
from pathlib import Path

plan_paths = sorted(Path('.planning/phases').glob('*/*-PLAN.md'))
missing = [str(path) for path in plan_paths if '## Public Repo Execution Rules' not in path.read_text()]
assert len(plan_paths) == 19, f'expected 19 plan files after adding 08-03, found {len(plan_paths)}'
assert not missing, 'missing public repo execution block:\n' + '\n'.join(missing)
print(f'ok: all {len(plan_paths)} phase plan files carry the inline public repo execution rules')
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: PASS with `ok: all 19 phase plan files carry the inline public repo execution rules`

- [ ] **Step 4: Run the final structural sweep for the whole rollout**

```bash
python3 - <<'PY'
from pathlib import Path

assert Path('.planning/PUBLIC-REPO-RULES.md').exists()
assert Path('.planning/phases/08-unified-command-manifest/08-03-PLAN.md').exists()

project = Path('.planning/PROJECT.md').read_text()
requirements = Path('.planning/REQUIREMENTS.md').read_text()
roadmap = Path('.planning/ROADMAP.md').read_text()
state = Path('.planning/STATE.md').read_text()

assert '.planning/PUBLIC-REPO-RULES.md' in project
assert 'CLOSEOUT-001' in requirements
assert '08-03-PLAN.md' in roadmap
assert '.planning/PUBLIC-REPO-RULES.md' in state
assert '| Release/publish/push work | This session is planning-only and push is explicitly disallowed. |' not in requirements

plan_paths = sorted(Path('.planning/phases').glob('*/*-PLAN.md'))
missing = [str(path) for path in plan_paths if '## Public Repo Execution Rules' not in path.read_text()]
assert not missing, 'missing inline block:\n' + '\n'.join(missing)

print('ok: public repo rollout artifacts are structurally complete')
PY
```

Run: `python3 - <<'PY' ... PY`
Expected: PASS with `ok: public repo rollout artifacts are structurally complete`

- [ ] **Step 5: Commit the propagated plan updates if the execution session has commit approval**

```bash
git add .planning/phases && git commit -m "docs: add public repo rules to phase plans"
```
