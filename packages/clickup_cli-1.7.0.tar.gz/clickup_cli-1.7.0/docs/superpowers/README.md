# Superpowers Docs Index

This directory contains historical planning artifacts that were used to shape milestone work in this public repository.

These files are kept for context and traceability. They are not live repo instructions, and they should not be read as the current source of truth for day-to-day development workflow.

## What Each File Is For

- `../../FEATURE-GAP-ANALYSIS.md`: authoritative backlog inventory of candidate future gaps and deferred work.
- `specs/2026-04-19-core-workflow-parity-design.md`: authoritative design record for the currently selected milestone slice taken from that backlog.
- `specs/2026-04-18-gsd-public-repo-autonomous-design.md`: historical design note for prior public-repo planning cleanup.
- `plans/2026-04-18-gsd-public-repo-autonomous-rollout.md`: historical implementation plan for that same cleanup work.

## Reading Notes

- References to `.planning/*` describe local historical planning artifacts that existed during planning and execution. They are context references, not public repo files to follow or recreate from these docs alone.
- When a backlog item is selected, the spec for that slice is more authoritative than the backlog wording.
- If backlog and spec language differ, treat the spec as the chosen design for that slice and treat the backlog file as the broader option set.
