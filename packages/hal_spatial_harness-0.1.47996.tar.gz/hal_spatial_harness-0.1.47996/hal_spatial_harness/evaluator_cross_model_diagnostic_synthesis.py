# ================= STANDARD LIB =================
import json
from itertools import combinations

# ================= DATA =================
import numpy as np
import pandas as pd

# ================= ML / STATS =================
from scipy.stats import chi2
from sklearn.preprocessing import MultiLabelBinarizer




def bootstrap_ci(scores_lst, n_bootstrap=1000, alpha=0.05):
    """
    y_true: ground truth labels
    y_pred: model predictions
    metric_fn: function(y_true, y_pred) -> scalar metric (e.g., accuracy)
    """

    scores = []
    n = len(scores_lst)

    for _ in range(n_bootstrap):
        idx = np.random.randint(0, n, n)  # bootstrap sample

        score = np.array(scores_lst)[idx]
        
        scores.append(score)

    scores = np.array(scores)

    lower = np.percentile(scores, 100 * alpha / 2)
    upper = np.percentile(scores, 100 * (1 - alpha / 2))
    mean = np.mean(scores)

    return {
        "mean": mean,
        "ci_lower": lower,
        "ci_upper": upper,
        "std": np.std(scores)
    }





# ================= COHEN'S D =================
def cohens_d(x, y):
    x, y = np.asarray(x), np.asarray(y)

    nx, ny = len(x), len(y)
    sx, sy = np.var(x, ddof=1), np.var(y, ddof=1)
 
    pooled = np.sqrt(((nx - 1) * sx + (ny - 1) * sy) / (nx + ny - 2))
    return (np.mean(x) - np.mean(y)) / pooled if pooled != 0 else 0.0


# ================= MCNEMAR TEST =================
def mcnemar_test(x, y):
    x, y = np.asarray(x), np.asarray(y)

    b = np.sum((x == 1) & (y == 0))
    c = np.sum((x == 0) & (y == 1))

    if b + c == 0:
        return 0.0, 1.0

    stat = (abs(b - c) - 1) ** 2 / (b + c)
    p = 1 - chi2.cdf(stat, df=1)

    return stat, p


# ================= FULL PIPELINE =================
def full_pairwise_evaluation(model_dfs, score_col="accuracy_score"):
    """
    model_dfs: dict {model_name: dataframe}
    score_col: must be binary (0/1) for McNemar
    """

    models = list(model_dfs.keys())
    pairs = list(combinations(models, 2))

    m = len(pairs)
    bonf_alpha = 0.05 / m  # numeric Bonferroni threshold

    results = []

    for m1, m2 in pairs:
        m1_df=model_dfs[m1]
        m2_df=model_dfs[m2]
        m1_df = m1_df[m1_df["id"].isin(m2_df["id"])]
        m2_df = m2_df[m2_df["id"].isin(m1_df["id"])]
        x =m1_df[score_col]
        y = m2_df[score_col]

        # McNemar
        mcn_stat, mcn_p = mcnemar_test(x, y)

        # Cohen's d
        d = cohens_d(x, y)

        results.append({
            "model_1": m1,
            "model_2": m2,
            "mcnemar_stat": mcn_stat,
            "mcnemar_p": mcn_p,
            "cohens_d": d,
            "bonferroni_alpha": bonf_alpha,
            "significant": mcn_p < bonf_alpha
        })

    df = pd.DataFrame(results)

    # ================= REVERSE PAIRS =================
    rev = df.copy()

    rev[["model_1", "model_2"]] = rev[["model_2", "model_1"]]

    # flip Cohen's d sign
    rev["cohens_d"] = -rev["cohens_d"]

    # McNemar symmetric
    rev["mcnemar_stat"] = rev["mcnemar_stat"]
    rev["mcnemar_p"] = rev["mcnemar_p"]
    rev["significant"] = rev["significant"]

    return pd.concat([df, rev], ignore_index=True)






def cross_model_diagnostic_synthesis(csv_paths,save_dir):
    model_evals={}
    model_dfs={}
    error_types = set()
    model_dfs = {}
    model_evals = {}
    
    score_col="accuracy_score"
    for csv_path in csv_paths:
        df = pd.read_csv(csv_path)
        if score_col in df.columns:
            
    
            model_name = str(csv_path.parent).split("/")[-1]
        
            df = df[df["error_type"].notna()].copy()
            df["error_type"] = df["error_type"].apply(lambda x: [x] if isinstance(x, str) else [])
        
            error_types.update(df["error_type"].explode().dropna().unique())
        
            mlb = MultiLabelBinarizer()
        
            dummies = pd.DataFrame(
                mlb.fit_transform(df["error_type"]),
                columns=mlb.classes_,
                index=df.index
            )
        
            df = pd.concat([df, dummies], axis=1)
        
            res = {}
            
            res["bootstrap_ci"] = bootstrap_ci(df[score_col], n_bootstrap=500, alpha=0.05)
            res["error_types"] = list(mlb.classes_)  # cleaner than recomputing
        
            model_evals[model_name]["overall_score"] = pd.to_numeric(df[score_col], errors="coerce").mean()
            model_evals[model_name] = res
            model_dfs[model_name] = df
    
    # final global list
    error_types = list(error_types)


    for error_type in error_types:
        model_evals[model_name][error_type]={}
    
    for error_type in error_types:
        selected_models=[model for model , value in model_evals.items() if error_type in value["error_types"]  ]
        
        selected_model_dfs = {k: v for k, v in model_dfs.items() if k in selected_models}
        
        if len(selected_model_dfs)>1:
            eval_res_df = full_pairwise_evaluation(selected_model_dfs, score_col=error_type)
            
            for model in selected_models:
                
                model_infos=eval_res_df.to_dict(orient="records")
                model_evals[model]["Cohen_d"] = next(
                    (
                        {error_type:{"to": info["model_2"], "cohens_d": info["cohens_d"]}}
                        for info in model_infos
                        if info["model_1"] == model
                    ),
                    None
                )
                model_evals[model]["Bonferroni"] = next(
                    (
                        {error_type:{"to": info["model_2"], "bonferroni_alpha": info["bonferroni_alpha"]}}
                        for info in model_infos
                        if info["model_1"] == model
                    ),
                    None
                )
                model_evals[model]["Mcnemar"] = next(
                    (
                        {error_type:{"to": info["model_2"], "mcnemar_stat": info["mcnemar_stat"], "mcnemar_p":info["mcnemar_stat"]}}
                        for info in model_infos
                        if info["model_1"] == model
                    ),
                    None
                )
    rows = []
    
    for model, data in model_evals.items():
    
        # -------------------------
        # 1. bootstrap_ci
        # -------------------------
        bc = data.get("bootstrap_ci", {})
        if bc:
            rows.append({
                "model": model,
                "to": None,
                "metric": "bootstrap_mean",
                "error_type": "Overall",
                "value": float(bc["mean"])
            })
    
        # -------------------------
        # 3. Cohen's d
        # -------------------------
        for e, v in data.get("Cohen_d", {}).items():
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "cohens_d",
                "error_type": e,
                "value": v.get("cohens_d")
            })
    
        # -------------------------
        # 4. Bonferroni
        # -------------------------
        for e, v in data.get("Bonferroni", {}).items():
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "bonferroni_alpha",
                "error_type": e,
                "value": v.get("bonferroni_alpha")
            })
    
        # -------------------------
        # 5. McNemar
        # -------------------------
        for e, v in data.get("Mcnemar", {}).items():
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "mcnemar_stat",
                "error_type": e,
                "value": v.get("mcnemar_stat")
            })
    
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "mcnemar_p",
                "error_type": e,
                "value": v.get("mcnemar_p")
            })
    
    
    pd.DataFrame(rows).to_csv(save_dir/"model_evaluations.csv",index=False)
    json.dump(model_evals, open(save_dir/"model_evaluations.json","w"), indent=4)



