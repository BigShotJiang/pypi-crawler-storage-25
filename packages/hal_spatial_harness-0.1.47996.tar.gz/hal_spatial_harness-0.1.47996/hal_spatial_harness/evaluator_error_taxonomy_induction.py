# ================= STANDARD LIB =================
import os
import pandas as pd

# ================= ML / STATS =================
from sklearn.metrics import silhouette_score

# ================= DEEP LEARNING =================
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel

# ================= EMBEDDING / CLUSTERING =================
import umap
import hdbscan

# ================= UTILITIES =================
from alive_progress import alive_bar

from .utils import json_parser, get_client


error_taxonomies_prompt_template="""
You are an expert error taxonomy classifier for spatial reasoning models.

You will be given a set of clustered model failures. Your task is to assign each cluster to exactly ONE primary error type from a fixed taxonomy.

Return ONLY valid JSON. Do NOT include explanation, markdown, or extra text.

================ FIXED ERROR TAXONOMY =================

{error_taxonomies}

================ INPUT =================

Cluster ID: {cluster_id}

Cluster Examples:
{list_of_failure_samples}

================ TASK =================

1. Carefully analyze the cluster behavior.
2. Identify the SINGLE best matching error type.
3. Do NOT assign multiple labels.
4. Prefer the dominant failure mode in the cluster.

================ OUTPUT FORMAT =================

Return STRICT JSON only (no trailing commas, no Python types, use null not None):

{{
  "cluster_id": "{cluster_id}",
  "error_type": "",
  "error_name": "string label of selected type"
}}

"""




        







# ================= MEAN POOLING =================
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output.last_hidden_state
    mask = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * mask, dim=1) / torch.clamp(mask.sum(dim=1), min=1e-9)

# ================= EMBEDDING FUNCTION =================


model_name = "intfloat/e5-large-v2"
token = os.environ.get("HF_TOKEN", None)
device = "cuda" if torch.cuda.is_available() else "cpu"

tokenizer = AutoTokenizer.from_pretrained(model_name, token=token)
model = AutoModel.from_pretrained(model_name, token=token).to(device)
model.eval()


def get_embeddings(texts, batch_size=32):
    
    all_embeddings = []
    batches = [texts[i:i+batch_size] for i in range(0, len(texts), batch_size)]

    with alive_bar(len(batches),
                   title="Generating Embeddings",
                   bar='blocks',
                   spinner='dots') as bar:

        for batch in batches:
            # E5 prefix
            batch = [f"query: {t}" for t in batch]

            inputs = tokenizer(
                batch,
                padding=True,
                truncation=True,
                return_tensors="pt"
            ).to(device)

            with torch.no_grad():
                outputs = model(**inputs)

            emb = mean_pooling(outputs, inputs["attention_mask"])
            emb = F.normalize(emb, p=2, dim=1)

            all_embeddings.append(emb.cpu())

            bar()  # ✅ update per batch

    return torch.cat(all_embeddings, dim=0).numpy()





# ================= 3. HDBSCAN TUNING (WITH PROGRESS) =================
def tune_hdbscan(X, cluster_sizes=[15, 20, 30, 40, 50]):
    best_score = -1
    best_labels = None
    best_model = None
    best_k = None

    with alive_bar(len(cluster_sizes), title="Tuning HDBSCAN") as bar:
        for k in cluster_sizes:

            if k >= len(X):  # invalid setting
                bar()
                continue

            clusterer = hdbscan.HDBSCAN(
                min_cluster_size=k,
                metric='euclidean',
                cluster_selection_method='eom'
            )

            labels = clusterer.fit_predict(X)

            # remove noise
            mask = labels != -1

            # need at least 2 clusters after filtering
            if len(set(labels[mask])) < 2:
                bar()
                continue

            try:
                score = silhouette_score(X[mask], labels[mask])
            except:
                bar()
                continue

            if score > best_score:
                best_score = score
                best_labels = labels
                best_model = clusterer
                best_k = k

            bar()

    return best_model, best_labels, best_k, best_score





    





def error_taxonomy_induction(csv_path,error_taxonomies,model_name="google/gemini-3.1-flash-image-preview",):
    df=pd.read_csv(csv_path)

    df["combined_text"] = (
        df["task_description"] + "\n" +
        df["answer"] + "\n" +
        df["response"]
    )
    # ================= 1. EMBEDDING =================
    embeddings = get_embeddings(df["combined_text"].tolist())

    
    # ================= 2. UMAP REDUCTION =================
    reduced = umap.UMAP(
        n_neighbors=min(15, len(df) - 1),
        n_components=min(10, len(df) - 2),
        metric='cosine',
        random_state=42,
        verbose=False  
    ).fit_transform(embeddings)

    
    
    clusterer, labels, best_k, best_score = tune_hdbscan(reduced)

    print(f"Best Cluster Size for HDBSCAN: {best_k}")
    print(f"Best Silhouette score : {best_score:.4f}")
    
    # ================= 5. ATTACH RESULTS =================
    df["cluster"] = labels
    
    # optional
    df["is_noise"] = df["cluster"] == -1

    clusters=df["cluster"].unique()
    cluster_mapping={} 
    for cluster in clusters:
        question_samples=df[df["cluster"]==cluster]["task_description"].tolist()
        
        prompt = error_taxonomies_prompt_template.format(
            list_of_failure_samples=question_samples,
            cluster_id=cluster,
            error_taxonomies=error_taxonomies
        )
        
        client = get_client()

        content = [{"type": "text", "text": prompt}]
        retry_count = 0
        max_retry = 3
        
        while retry_count < max_retry:
            try:
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": content}],
                    temperature=0.1,
                    max_tokens=250,
                )
        
                res = json_parser(response.choices[0].message.content.strip()) if response else {}
                cluster_mapping[cluster] = res.get("error_type")
        
                break  # ✅ success → exit loop
        
            except Exception as e:
                retry_count += 1
        
                if retry_count == max_retry:
                    print(f"❌ Failed after {max_retry} attempts for Cluster {cluster}: {e}")
                    cluster_mapping[cluster] = None  # fallback
                
    df["error_type"]=df["cluster"].map(cluster_mapping)
    df.to_csv(csv_path,index=False)
    




