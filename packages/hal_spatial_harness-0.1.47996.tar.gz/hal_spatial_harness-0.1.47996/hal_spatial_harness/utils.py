import os
from openai import OpenAI
import base64

import re
import os

import json



def json_parser(json_text):
    try:
        return json.loads(re.search(r"\{.*\}", json_text, re.S).group())
    except Exception as e:
        print(f"Error {e}")
        print(json_text)
    



class InvalidPathNameError(ValueError):
    """Custom exception for invalid path names."""
    pass

def verify_run_name(name: str) -> str:
    """
    Verify that the given name is a valid filename/folder name.
    
    Rules:
    - Cannot contain forbidden characters: \ / : * ? " < > |
    - Cannot be empty or only whitespace
    - Cannot be a reserved Windows name (CON, PRN, AUX, NUL, COM1..9, LPT1..9)
    
    Returns the stripped valid name if valid.
    Raises InvalidPathNameError if invalid.
    """
    if not name or name.strip() == "":
        raise InvalidPathNameError("Path name cannot be empty or whitespace.")

    name = name.strip()
    
    # Forbidden characters
    forbidden_chars = r'[<>:"/\\|?*]'
    if re.search(forbidden_chars, name):
        raise InvalidPathNameError(
            f"Path name '{name}' contains forbidden characters: \\ / : * ? \" < > |"
        )

    # Reserved Windows names
    reserved = {"CON","PRN","AUX","NUL"} | {f"COM{i}" for i in range(1,10)} | {f"LPT{i}" for i in range(1,10)}
    if name.upper() in reserved:
        raise InvalidPathNameError(f"Path name '{name}' is a reserved system name.")

    return name


def encode_image(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def get_client():
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    OPEN_ROUTER_API_KEY = os.environ.get("OPEN_ROUTER_API_KEY")
    if OPEN_ROUTER_API_KEY:
        return OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPEN_ROUTER_API_KEY
        )
    elif OPENAI_API_KEY:
        return OpenAI(api_key=OPENAI_API_KEY)
    else:
        raise ValueError("No API key found. Set OPENAI_API_KEY or OPEN_ROUTER_API_KEY.")
        