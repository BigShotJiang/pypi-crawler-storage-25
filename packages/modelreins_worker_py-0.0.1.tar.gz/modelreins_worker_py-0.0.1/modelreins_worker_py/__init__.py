"""modelreins-worker-py — reserved. Install modelreins-worker instead.

See https://modelreins.com/docs/sdk/python
"""
raise ImportError(
    "modelreins-worker-py is a reserved name guard. "
    "Install the real package: pip install modelreins-worker"
)
