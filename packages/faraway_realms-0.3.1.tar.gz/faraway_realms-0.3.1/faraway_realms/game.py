"""Game state — holds the map, players, chat history, and tick processor."""

from __future__ import annotations

import random
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np

from faraway_realms import fov as _fov
from faraway_realms.abilities import (
    ABILITY_REGISTRY,
    Ability,
    ApplyStatusEffect,
    BackstepEffect,
    DamageEffect,
    KnockbackEffect,
    ProjectileEffect,
)
from faraway_realms.blood import BloodEvent, BloodMap
from faraway_realms.chat import (
    DEFAULT_COLOR,
    NPC_HIT_COLOR,
    OPP_ATTACK_COLOR,
    PLAYER_HIT_COLOR,
    ChatMessage,
)
from faraway_realms.commands import Command, CommandType, make_target_command
from faraway_realms.damage_types import compute_ability_damage
from faraway_realms.entity import Entity, GameEntity, Player, get_combat_profile
from faraway_realms.events import Event, EventType
from faraway_realms.factions import FactionRelations
from faraway_realms.light import LightSource
from faraway_realms.map import Map, chebyshev, is_adjacent
from faraway_realms.projectile import Projectile
from faraway_realms.static_object import StaticObject
from faraway_realms.stats import Pool
from faraway_realms.status import StatusInstance, is_stunned
from faraway_realms.systems.casting import CastingSystem
from faraway_realms.systems.combat import CombatResult, CombatSystem
from faraway_realms.systems.contact import ContactResolutionSystem
from faraway_realms.systems.death import DeathSystem
from faraway_realms.systems.movement import MovementSystem
from faraway_realms.systems.npc_intent import NpcIntentSystem
from faraway_realms.systems.projectile import ProjectileDetonation, ProjectileSystem
from faraway_realms.systems.status import StatusEffectSystem
from faraway_realms.systems.targeting import TargetingSystem

_MAX_EVENT_DEPTH: int = 10
_CAST_COLOR: tuple[int, int, int] = (100, 180, 255)
_STATUS_COLOR: tuple[int, int, int] = (200, 100, 220)

# When True, completing a cast resets the caster's attack cooldown, linking
# the ability and melee rhythms into a single combat cadence.
# Set to False to decouple them (attack cooldown runs independently).
CAST_REPRIMES_ATTACK: bool = True


@dataclass
class Game:
    """Central game state: map, players, chat history, and command queue.

    Parameters
    ----------
    game_map : Map
        The active map.
    tick_rate : float
        Target ticks per second for game state updates.
    faction_relations : FactionRelations
        Defines which factions are hostile to each other.
    """

    game_map: Map
    tick_rate: float = 10.0
    faction_relations: FactionRelations = field(default_factory=FactionRelations)
    _players: dict[str, Player] = field(default_factory=dict)
    _npcs: list[Entity] = field(default_factory=list)
    _entities: dict[int, GameEntity] = field(default_factory=dict)
    _chat_history: list[ChatMessage] = field(default_factory=list)
    _command_queue: list[Command] = field(default_factory=list)
    _event_queue: list[Event] = field(default_factory=list)
    _abs_tick: int = field(default=0)
    _creature_registry: dict[str, Callable[[int], Entity]] = field(default_factory=dict)
    _next_entity_id: int = field(default=1000)
    player_spawn_tiles: list[tuple[int, int]] = field(default_factory=list)
    _hit_seqs: dict[int, int] = field(default_factory=dict, init=False)
    _crit_dealt_seq: dict[int, int] = field(default_factory=dict, init=False)
    _attack_anim_events: list[
        tuple[tuple[int, int], tuple[int, int], tuple[int, int, int]]
    ] = field(default_factory=list, init=False)
    _blood_events: list[BloodEvent] = field(default_factory=list, init=False)
    _static_objects: list[StaticObject] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        """Initialise systems and command/event dispatch tables."""
        self._blood_map = BloodMap(self.game_map.width, self.game_map.height)
        self._casting = CastingSystem(self._entities, self.game_map)
        self._npc_intent = NpcIntentSystem(
            self.game_map,
            self._npcs,
            self._entities,
            self.faction_relations,
            casting_system=self._casting,
        )
        self._movement = MovementSystem(
            self.game_map, self._entities, self.faction_relations
        )
        self._combat = CombatSystem(self._entities)
        self._targeting = TargetingSystem(
            self._entities, self.game_map, self.faction_relations
        )
        self._contact = ContactResolutionSystem(self._entities)
        self._death = DeathSystem(self.game_map, self._entities, self._npcs)
        self._status_fx = StatusEffectSystem(self._entities)
        self._projectile_sys = ProjectileSystem(self._entities, self.game_map)

        self._handlers: dict[CommandType, Callable[[Command], None]] = {
            CommandType.MOVE: self._dispatch_move,
            CommandType.ATTACK: self._dispatch_attack,
            CommandType.OPPORTUNITY_ATTACK: self._dispatch_opportunity_attack,
            CommandType.TARGET: self._dispatch_target,
            CommandType.SPAWN: self._dispatch_spawn,
            CommandType.PRIME_COOLDOWN: self._dispatch_prime_cooldown,
            CommandType.CLEAR_PRIME: self._dispatch_clear_prime,
            CommandType.CAST: self._dispatch_cast,
            CommandType.INTERRUPT_CAST: self._dispatch_interrupt_cast,
        }
        self._event_handlers: dict[EventType, Callable[[Event], None]] = {
            EventType.CONTACT: self._dispatch_contact,
            EventType.DEATH: self._dispatch_death,
            EventType.CAST_COMPLETE: self._dispatch_cast_complete,
            EventType.CHANNEL_TICK: self._dispatch_cast_complete,
        }

    def add_npc(self, npc: Entity) -> None:
        """Register an NPC in the game.

        Parameters
        ----------
        npc : Entity
            The NPC to add.
        """
        self._npcs.append(npc)
        self._entities[npc.entity_id] = npc

    def add_player(self, player: Player) -> None:
        """Register a player in the game.

        Parameters
        ----------
        player : Player
            The player to add.
        """
        self._players[player.username] = player
        self._entities[player.entity.entity_id] = player.entity

    def register_creature(self, name: str, factory: Callable[[int], Entity]) -> None:
        """Register a creature factory for GM spawn commands.

        Parameters
        ----------
        name : str
            Creature type name used in ``/spawn me <name> <pos>``.
        factory : Callable[[int], Entity]
            Callable that receives an entity ID and returns a configured NPC.
        """
        self._creature_registry[name] = factory

    @property
    def command_queue_size(self) -> int:
        """Number of player/NPC commands queued ahead of the next tick."""
        return len(self._command_queue)

    def enqueue_command(self, command: Command) -> None:
        """Add a command to the queue for the current tick's drain.

        Parameters
        ----------
        command : Command
            The command to enqueue.
        """
        self._command_queue.append(command)

    def emit_event(self, event: Event) -> None:
        """Emit an event to be resolved after the current command drain.

        Parameters
        ----------
        event : Event
            The event to emit.
        """
        self._event_queue.append(event)

    def tick(self) -> None:
        """Advance game state: gather NPC intents, drain commands, drain events."""
        self._abs_tick += 1
        self._command_queue.extend(self._npc_intent.gather(self._abs_tick))
        queue, self._command_queue = self._command_queue, []
        for command in queue:
            self._process_command(command)
        self._drain_events()
        self._cancel_out_of_range_casts()
        for event in self._status_fx.tick(self._abs_tick):
            self.emit_event(event)
        self._drain_events()
        self._freeze_stunned_cooldowns()
        for det in self._projectile_sys.tick(self._abs_tick):
            self._handle_projectile_detonation(det)
        self._tick_mana_regen()
        self._maintain_player_targeting()

    def _maintain_player_targeting(self) -> None:
        for player in self._players.values():
            self._targeting.maintain_los(player.entity.entity_id)

    def _freeze_stunned_cooldowns(self) -> None:
        """Re-prime every stunned entity each tick so their attack bar stays at zero."""
        for entity_id, entity in self._entities.items():
            if is_stunned(entity, self._abs_tick):
                self._combat.prime(entity_id, self._abs_tick)

    def _cancel_out_of_range_casts(self) -> None:
        """Interrupt casts whose target has moved out of range this tick."""
        for entity_id in list(self._entities):
            self._check_cast_range(entity_id)

    def _check_cast_range(self, entity_id: int) -> None:
        cast_info = self._casting.active_cast(entity_id)
        if cast_info is None:
            return
        ability_name, target_id = cast_info
        ability = ABILITY_REGISTRY.get(ability_name)
        out_of_range = ability is not None and not self._cast_in_range(
            entity_id, target_id, ability
        )
        if out_of_range:
            self._log_cast_cancelled(entity_id, ability_name)
            self._casting.cancel(entity_id, ability_name)
            self._purge_cast_events(entity_id)

    def _cast_in_range(self, caster_id: int, target_id: int, ability: Ability) -> bool:
        """Return ``True`` when caster is still within ability range of target."""
        if not (
            self.game_map.has_entity(caster_id) and self.game_map.has_entity(target_id)
        ):
            return False
        cx, cy = self.game_map.get_entity_position(caster_id)
        tx, ty = self.game_map.get_entity_position(target_id)
        return chebyshev(cx, cy, tx, ty) <= ability.range_tiles

    # ------------------------------------------------------------------
    # Command dispatch
    # ------------------------------------------------------------------

    def add_chat_message(
        self,
        message: str,
        color: tuple[int, int, int] = DEFAULT_COLOR,
    ) -> None:
        """Append a message to the chat history.

        Parameters
        ----------
        message : str
            The message text.
        color : tuple[int, int, int]
            RGB foreground color.  Defaults to
            :data:`~faraway_realms.chat.DEFAULT_COLOR`.
        """
        self._chat_history.append(ChatMessage(text=message, color=color))

    def get_chat_history(self, last_n: int = 20) -> list[ChatMessage]:
        """Return the most recent chat messages.

        Parameters
        ----------
        last_n : int
            Maximum number of messages to return.

        Returns
        -------
        list[ChatMessage]
            The last ``last_n`` messages.
        """
        return self._chat_history[-last_n:]

    def _process_command(self, command: Command) -> None:
        handler = self._handlers.get(command.command_type)
        if handler is not None:
            handler(command)

    def _dispatch_move(self, command: Command) -> None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None or not command.args:
            return
        direction = command.args[0].lower()
        for event in self._movement.handle(actor_id, direction, self._abs_tick):
            self.emit_event(event)

    def _in_melee_range(self, a: int, b: int) -> bool:
        if not self.game_map.has_entity(a) or not self.game_map.has_entity(b):
            return False
        ax, ay = self.game_map.get_entity_position(a)
        bx, by = self.game_map.get_entity_position(b)
        return is_adjacent(ax, ay, bx, by)

    def _dispatch_attack(self, command: Command) -> None:
        attacker_id = self._resolve_actor(command.actor)
        if attacker_id is None or not command.args:
            return
        if self._attack_blocked(attacker_id):
            return
        target_id = self._resolve_target(attacker_id, command.args[0])
        if target_id is None or not self._in_melee_range(attacker_id, target_id):
            return
        haste = self._haste_factor(attacker_id)
        result = self._combat.handle(
            attacker_id, target_id, self._abs_tick, haste_factor=haste
        )
        self._apply_combat_result(attacker_id, target_id, result)

    def _attack_blocked(self, attacker_id: int) -> bool:
        """Return True when the attacker cannot swing (casting or stunned)."""
        return self._casting.is_casting(attacker_id) or self._entity_is_stunned(
            attacker_id
        )

    def _dispatch_opportunity_attack(self, command: Command) -> None:
        attacker_id = self._resolve_actor(command.actor)
        if attacker_id is None or not command.args:
            return
        target_id = self._resolve_target(attacker_id, command.args[0])
        if target_id is None:
            return
        haste = self._haste_factor(attacker_id)
        result = self._combat.handle(
            attacker_id,
            target_id,
            self._abs_tick,
            bypass_cooldown=True,
            haste_factor=haste,
        )
        self._apply_combat_result(attacker_id, target_id, result)

    def get_hit_seq(self, entity_id: int) -> int:
        """Return how many times *entity_id* has been hit (monotonically increasing)."""
        return self._hit_seqs.get(entity_id, 0)

    def get_crit_dealt_seq(self, entity_id: int) -> int:
        """Return how many crits *entity_id* has landed (monotonically increasing).

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        int
            Monotonically increasing crit count; ``0`` until first crit.
        """
        return self._crit_dealt_seq.get(entity_id, 0)

    @property
    def blood_map(self) -> BloodMap:
        """Return the authoritative blood stain map."""
        return self._blood_map

    def drain_blood_events(self) -> list[BloodEvent]:
        """Consume and return all pending blood splat events.

        Returns
        -------
        list[BloodEvent]
            Events accumulated since the last drain.
        """
        evts, self._blood_events = self._blood_events, []
        return evts

    @property
    def active_projectiles(self) -> list[Projectile]:
        """Return the current list of in-flight projectiles for rendering."""
        return self._projectile_sys.active_projectiles

    @property
    def static_objects(self) -> list[StaticObject]:
        """Return all static objects placed on the map."""
        return self._static_objects

    def add_static_object(self, obj: StaticObject) -> None:
        """Place a static object on the map.

        Parameters
        ----------
        obj : StaticObject
            The object to add.
        """
        self._static_objects.append(obj)

    def all_player_entities(self) -> list[GameEntity]:
        """Return all player-controlled entities."""
        return [p.entity for p in self._players.values()]

    def all_npcs(self) -> list[Entity]:
        """Return all NPC entities (those carrying a ``BehaviourComponent``)."""
        return [e for e in self._npcs if "behaviour" in e.components]

    def entity(self, entity_id: int) -> GameEntity | None:
        """Return entity by ID, or None."""
        return self._entities.get(entity_id)

    def player_entity_id(self, username: str) -> int | None:
        """Return the entity ID for *username*, or None if not registered."""
        player = self._players.get(username)
        return player.entity.entity_id if player is not None else None

    def spawn_player(
        self, username: str, char_name: str, color: tuple[int, int, int]
    ) -> int:
        """Spawn a new player entity and register it under *username*.

        Parameters
        ----------
        username : str
            Account name used to authenticate.
        char_name : str
            Display name for the character.
        color : tuple[int, int, int]
            RGB foreground colour.

        Returns
        -------
        int
            Entity ID of the newly created player entity.
        """
        from faraway_realms.character_type import CHARACTER_REGISTRY  # noqa: PLC0415

        entity_id = self._next_entity_id
        self._next_entity_id += 1
        entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id)
        entity.name = char_name
        entity.fg_color = color
        self.add_player(Player(username=username, entity=entity))
        x, y = self._pick_spawn_tile()
        self.game_map.place_entity(entity_id, x, y)
        return entity_id

    def _pick_spawn_tile(self) -> tuple[int, int]:
        occupied = frozenset(self.game_map.get_all_positions().values())
        candidates = [t for t in self.player_spawn_tiles if t not in occupied]
        if not candidates:
            candidates = self._all_walkable_unoccupied(occupied)
        return random.choice(candidates) if candidates else (1, 1)  # noqa: S311

    def _all_walkable_unoccupied(
        self, occupied: frozenset[tuple[int, int]]
    ) -> list[tuple[int, int]]:
        return [
            (x, y)
            for y in range(self.game_map.height)
            for x in range(self.game_map.width)
            if self.game_map.is_walkable(x, y) and (x, y) not in occupied
        ]

    def light_sources(self) -> list[tuple[int, int, LightSource]]:
        """Collect all active light source positions for rendering.

        Returns
        -------
        list[tuple[int, int, LightSource]]
            ``(x, y, light_source)`` for every static object, entity, and
            in-flight projectile that emits light.
        """
        result: list[tuple[int, int, LightSource]] = []
        self._collect_static_lights(result)
        self._collect_entity_lights(result)
        self._collect_projectile_lights(result)
        return result

    def _collect_static_lights(self, out: list[tuple[int, int, LightSource]]) -> None:
        from faraway_realms.components import LightEmitter

        for obj in self._static_objects:
            emitter = obj.components.get("light_emitter")
            if isinstance(emitter, LightEmitter):
                out.append((obj.x, obj.y, emitter))

    def _collect_entity_lights(self, out: list[tuple[int, int, LightSource]]) -> None:
        from faraway_realms.components import LightEmitter

        for entity in [*self.all_player_entities(), *self.all_npcs()]:
            emitter = entity.components.get("light_emitter")
            if isinstance(emitter, LightEmitter):
                try:
                    x, y = self.game_map.get_entity_position(entity.entity_id)
                    out.append((x, y, emitter))
                except KeyError:
                    pass

    def _collect_projectile_lights(
        self, out: list[tuple[int, int, LightSource]]
    ) -> None:
        for proj in self._projectile_sys.active_projectiles:
            if proj.light_source is not None:
                out.append((proj.x, proj.y, proj.light_source))

    def drain_attack_anim_events(
        self,
    ) -> list[tuple[tuple[int, int], tuple[int, int], tuple[int, int, int]]]:
        """Consume and return all pending melee attack animation events.

        Each event is ``(from_pos, to_pos, attacker_color)``.  The internal
        list is cleared so subsequent calls return an empty list until the
        next hit is recorded.

        Returns
        -------
        list[tuple[tuple[int, int], tuple[int, int], tuple[int, int, int]]]
            Animation events accumulated since the last drain.
        """
        evts, self._attack_anim_events = self._attack_anim_events, []
        return evts

    def _record_blood_splat(
        self,
        attacker_id: int,
        target_id: int,
        drop_count: int = 3,
        max_dist: int = 3,
    ) -> None:
        target = self._entities.get(target_id)
        if target is None:
            return
        blood_color = get_combat_profile(target).blood_color
        if blood_color is None:
            return
        if not (
            self.game_map.has_entity(attacker_id)
            and self.game_map.has_entity(target_id)
        ):
            return
        ax, ay = self.game_map.get_entity_position(attacker_id)
        tx, ty = self.game_map.get_entity_position(target_id)
        positions = self._blood_map.splat(
            tx, ty, ax, ay, blood_color, drop_count, max_dist
        )
        self._blood_events.append(
            BloodEvent(
                target_pos=(tx, ty),
                attacker_pos=(ax, ay),
                landing_positions=tuple(positions),
                color=blood_color,
            )
        )

    def _record_attack_anim(self, attacker_id: int, target_id: int) -> None:
        attacker = self._entities.get(attacker_id)
        if attacker is None:
            return
        if not (
            self.game_map.has_entity(attacker_id)
            and self.game_map.has_entity(target_id)
        ):
            return
        a_pos = self.game_map.get_entity_position(attacker_id)
        t_pos = self.game_map.get_entity_position(target_id)
        self._attack_anim_events.append((a_pos, t_pos, attacker.fg_color))

    def _apply_combat_result(
        self,
        attacker_id: int,
        target_id: int,
        result: CombatResult,
    ) -> None:
        for event in result.events:
            self.emit_event(event)
        if result.damage_dealt > 0:
            self._hit_seqs[target_id] = self._hit_seqs.get(target_id, 0) + 1
            if result.crit:
                self._crit_dealt_seq[attacker_id] = (
                    self._crit_dealt_seq.get(attacker_id, 0) + 1
                )
            self._log_hit(attacker_id, target_id, result.damage_dealt, result.crit)
            self._record_attack_anim(attacker_id, target_id)
            self._record_blood_splat(attacker_id, target_id)

    def _log_hit(
        self, attacker_id: int, target_id: int, damage: int, crit: bool = False
    ) -> None:
        attacker = self._entities.get(attacker_id)
        target = self._entities.get(target_id)
        if attacker is None or target is None:
            return
        player_ids = {p.entity.entity_id for p in self._players.values()}
        color = PLAYER_HIT_COLOR if attacker_id in player_ids else NPC_HIT_COLOR
        prefix = "Critical! " if crit else ""
        name_a = attacker.display_name
        name_t = target.display_name
        text = f"{prefix}{name_a} hits {name_t} for {damage}"
        self.add_chat_message(text, color)

    def _dispatch_prime_cooldown(self, command: Command) -> None:
        entity_id = self._resolve_actor(command.actor)
        if entity_id is None:
            return
        self._combat.prime(entity_id, self._abs_tick)

    def _dispatch_clear_prime(self, command: Command) -> None:
        entity_id = self._resolve_actor(command.actor)
        if entity_id is None:
            return
        self._combat.forget(entity_id)

    def _dispatch_cast(self, command: Command) -> None:
        resolved = self._resolve_cast_args(command)
        if resolved is None:
            return
        actor_id, ability, target_id = resolved
        if self._entity_is_stunned(actor_id):
            return
        self._begin_cast(actor_id, ability, target_id)

    def _begin_cast(self, actor_id: int, ability: Ability, target_id: int) -> None:
        events = self._casting.begin_cast(actor_id, ability, target_id, self._abs_tick)
        for event in events:
            self.emit_event(event)
        if events and ability.cast_time > 0:
            self._log_cast_start(actor_id, ability)

    def _resolve_cast_args(self, command: Command) -> tuple[int, Ability, int] | None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None or len(command.args) < 2:
            return None
        ability = ABILITY_REGISTRY.get(command.args[0])
        if ability is None:
            return None
        target_id = self._resolve_target(actor_id, command.args[1])
        if target_id is None:
            return None
        return actor_id, ability, target_id

    def _log_cast_start(self, caster_id: int, ability: Ability) -> None:
        caster = self._entities.get(caster_id)
        if caster is None:
            return
        msg = f"{caster.display_name} begins casting {ability.name}..."
        self.add_chat_message(msg, _CAST_COLOR)

    def _log_cast_cancelled(self, caster_id: int, ability_name: str) -> None:
        caster = self._entities.get(caster_id)
        if caster is None:
            return
        msg = f"{caster.display_name}'s {ability_name} was interrupted!"
        self.add_chat_message(msg, _CAST_COLOR)

    def _dispatch_interrupt_cast(self, command: Command) -> None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None:
            return
        self._casting.interrupt(actor_id)
        self._purge_cast_events(actor_id)

    def _dispatch_cast_complete(self, event: Event) -> None:
        ability = self._resolve_cast_ability(event)
        target_id = event.target_id
        if ability is None or target_id is None:
            return
        self._casting.interrupt(event.source_id)
        if CAST_REPRIMES_ATTACK:
            self._combat.prime(event.source_id, self._abs_tick, force=True)
        self._log_cast_complete(event.source_id, target_id, ability)
        self._apply_ability_effects(event.source_id, target_id, ability)

    def _resolve_cast_ability(self, event: Event) -> Ability | None:
        """Validate a CAST_COMPLETE event and return the resolved ability, or None."""
        if event.target_id is None or event.payload is None:
            return None
        if event.source_id not in self._entities:
            return None  # caster died before cast completed
        return ABILITY_REGISTRY.get(str(event.payload.get("ability", "")))

    def _apply_ability_effects(
        self, caster_id: int, target_id: int, ability: Ability
    ) -> None:
        for effect in ability.effects:
            self._apply_single_effect(caster_id, target_id, effect)

    def _apply_single_effect(
        self, caster_id: int, target_id: int, effect: object
    ) -> None:
        if isinstance(effect, DamageEffect):
            self._apply_damage_effect(caster_id, target_id, effect)
        elif isinstance(effect, ProjectileEffect):
            self._projectile_sys.spawn(caster_id, target_id, effect)
        else:
            self._apply_nondamage_effect(caster_id, target_id, effect)

    def _apply_nondamage_effect(
        self, caster_id: int, target_id: int, effect: object
    ) -> None:
        if isinstance(effect, KnockbackEffect):
            self._apply_knockback_effect(caster_id, target_id, effect)
        elif isinstance(effect, BackstepEffect):
            self._apply_backstep(caster_id, target_id, effect)
        elif isinstance(effect, ApplyStatusEffect):
            self._apply_status_effect(caster_id, target_id, effect)

    def _apply_damage_effect(
        self, caster_id: int, target_id: int, effect: DamageEffect
    ) -> None:
        target = self._entities.get(target_id)
        caster = self._entities.get(caster_id)
        if target is None or caster is None:
            return
        hp = target.stats.get("health")
        if not isinstance(hp, Pool):
            return
        armor = target.stats.get("armor")
        armor_val = armor.value if armor is not None else 0
        tcp = get_combat_profile(target)
        damage = compute_ability_damage(
            effect.base, effect.damage_type, tcp.armor_type, armor_val
        )
        hp.modify(-damage)
        self._log_ability_hit(caster_id, target_id, damage)
        self._record_blood_splat(caster_id, target_id, drop_count=5, max_dist=5)
        if hp.is_empty:
            self.emit_event(
                Event(
                    event_type=EventType.DEATH,
                    source_id=target_id,
                    target_id=None,
                    resolve_at_tick=self._abs_tick,
                )
            )

    def _apply_knockback_effect(
        self, caster_id: int, target_id: int, effect: KnockbackEffect
    ) -> None:
        if not (
            self.game_map.has_entity(caster_id) and self.game_map.has_entity(target_id)
        ):
            return
        cx, cy = self.game_map.get_entity_position(caster_id)
        tx, ty = self.game_map.get_entity_position(target_id)
        dx = (tx > cx) - (tx < cx)
        dy = (ty > cy) - (ty < cy)
        self._push_entity(target_id, dx, dy, effect.distance)

    def _apply_status_effect(
        self, caster_id: int, target_id: int, effect: ApplyStatusEffect
    ) -> None:
        target = self._entities.get(target_id)
        if target is None:
            return
        target.status_effects = [
            s for s in target.status_effects if s.name != effect.status_name
        ]
        target.status_effects.append(
            StatusInstance(
                name=effect.status_name,
                expires_at=self._abs_tick + effect.duration,
                tick_damage=effect.tick_damage,
                tick_heal=effect.tick_heal,
                dot_interval=effect.dot_interval,
                next_dot_tick=self._abs_tick + effect.dot_interval,
                immobilize=effect.immobilize,
                stun=effect.stun,
                haste=effect.haste,
            )
        )
        self._post_status_hooks(caster_id, target_id, effect)

    def _post_status_hooks(
        self, caster_id: int, target_id: int, effect: ApplyStatusEffect
    ) -> None:
        if effect.stun:
            self._apply_stun_side_effects(target_id)
        if effect.show_message:
            self._log_status_applied(caster_id, target_id, effect.status_name)

    def _apply_stun_side_effects(self, target_id: int) -> None:
        """Interrupt cast and reset attack cooldown when a stun lands."""
        self._casting.interrupt(target_id)
        self._purge_cast_events(target_id)
        self._combat.prime(target_id, self._abs_tick)

    def _apply_backstep(
        self, caster_id: int, target_id: int, effect: BackstepEffect
    ) -> None:
        if not (
            self.game_map.has_entity(caster_id) and self.game_map.has_entity(target_id)
        ):
            return
        cx, cy = self.game_map.get_entity_position(caster_id)
        tx, ty = self.game_map.get_entity_position(target_id)
        dx = (cx > tx) - (cx < tx)
        dy = (cy > ty) - (cy < ty)
        self._push_entity(caster_id, dx, dy, effect.distance)

    # ------------------------------------------------------------------
    # Projectile detonation handler
    # ------------------------------------------------------------------

    def _handle_projectile_detonation(self, det: ProjectileDetonation) -> None:
        """Log a hit, splat blood, apply statuses, and emit DEATH if needed."""
        self._log_ability_hit(det.source_id, det.target_id, det.damage_dealt)
        self._record_blood_splat(det.source_id, det.target_id)
        for effect in det.on_hit_statuses:
            self._apply_status_effect(det.source_id, det.target_id, effect)
        if det.target_died:
            self.emit_event(
                Event(
                    event_type=EventType.DEATH,
                    source_id=det.target_id,
                    target_id=None,
                    resolve_at_tick=self._abs_tick,
                )
            )

    # ------------------------------------------------------------------
    # Mana regeneration
    # ------------------------------------------------------------------

    def _tick_mana_regen(self) -> None:
        """Restore mana for all entities with a positive regen_per_tick."""
        for entity in self._entities.values():
            mana = entity.stats.get("mana")
            if isinstance(mana, Pool) and mana.regen_per_tick > 0:
                mana.modify(mana.regen_per_tick)

    def _log_status_applied(
        self, caster_id: int, target_id: int, status_name: str
    ) -> None:
        caster = self._entities.get(caster_id)
        target = self._entities.get(target_id)
        if caster is None or target is None:
            return
        name = target.display_name
        msg = f"{caster.display_name} afflicts {name} with {status_name}."
        self.add_chat_message(msg, _STATUS_COLOR)

    def _entity_is_stunned(self, entity_id: int) -> bool:
        entity = self._entities.get(entity_id)
        return entity is not None and is_stunned(entity, self._abs_tick)

    def _push_entity(self, entity_id: int, dx: int, dy: int, distance: int) -> None:
        for _ in range(distance):
            if not self._push_step(entity_id, dx, dy):
                return

    def _push_step(self, entity_id: int, dx: int, dy: int) -> bool:
        """Attempt one push step; return False when blocked or entity missing."""
        if not self.game_map.has_entity(entity_id):
            return False
        x, y = self.game_map.get_entity_position(entity_id)
        nx, ny = x + dx, y + dy
        if self.game_map.is_occupied(nx, ny) or not self.game_map.is_walkable(nx, ny):
            return False
        self.game_map.move_entity(entity_id, dx, dy)
        return True

    def _log_cast_complete(
        self, caster_id: int, target_id: int, ability: Ability
    ) -> None:
        caster = self._entities.get(caster_id)
        target = self._entities.get(target_id)
        if caster is None or target is None:
            return
        text = self._cast_complete_text(caster, target, ability)
        player_ids = {p.entity.entity_id for p in self._players.values()}
        color = PLAYER_HIT_COLOR if target_id in player_ids else NPC_HIT_COLOR
        self.add_chat_message(text, color)

    def _cast_complete_text(
        self, caster: GameEntity, target: GameEntity, ability: Ability
    ) -> str:
        if ability.name == "bite":
            return f"{caster.display_name} sinks its teeth into {target.display_name}!"
        return f"{caster.display_name} uses {ability.name} on {target.display_name}!"

    def _log_ability_hit(self, caster_id: int, target_id: int, damage: int) -> None:
        player_ids = {p.entity.entity_id for p in self._players.values()}
        color = PLAYER_HIT_COLOR if target_id in player_ids else NPC_HIT_COLOR
        self.add_chat_message(f"  ({damage} damage)", color)

    def _dispatch_target(self, command: Command) -> None:
        entity_id = self._resolve_actor(command.actor)
        if entity_id is None:
            return
        old_target = self._entity_target(entity_id)
        if command.args and command.args[0] == "next":
            self._targeting.cycle(entity_id)
        else:
            self._targeting.handle(entity_id, self._resolve_new_target(command.args))
        self._maybe_prime_on_target_change(entity_id, old_target)

    def _entity_target(self, entity_id: int) -> int | None:
        entity = self._entities.get(entity_id)
        return entity.target_id if entity else None

    def _maybe_prime_on_target_change(
        self, entity_id: int, old_target: int | None
    ) -> None:
        new_target = self._entity_target(entity_id)
        if new_target is not None and new_target != old_target:
            self._combat.prime(entity_id, self._abs_tick, force=True)

    def _dispatch_spawn(self, command: Command) -> None:
        actor_id = self._resolve_actor(command.actor)
        if actor_id is None:
            return
        if not self._is_game_master(actor_id):
            return
        resolved = self._resolve_spawn_args(command.args, actor_id)
        if resolved is None:
            return
        factory, (x, y) = resolved
        entity_id = self._next_entity_id
        self._next_entity_id += 1
        npc = factory(entity_id)
        self.add_npc(npc)
        self.game_map.place_entity(npc.entity_id, x, y)
        self.add_chat_message(f"[GM] Spawned {npc.display_name} at ({x}, {y})")

    def _is_game_master(self, entity_id: int) -> bool:
        return any(
            p.entity.entity_id == entity_id and p.is_game_master
            for p in self._players.values()
        )

    def _resolve_spawn_args(
        self,
        args: tuple[str, ...],
        actor_id: int,
    ) -> tuple[Callable[[int], Entity], tuple[int, int]] | None:
        if len(args) < 2:
            return None
        factory = self._creature_registry.get(args[0])
        if factory is None:
            return None
        pos = self._resolve_spawn_position(args[1], actor_id)
        if pos is None:
            return None
        return factory, pos

    def _resolve_spawn_position(
        self, pos_arg: str, actor_id: int
    ) -> tuple[int, int] | None:
        if pos_arg == "random":
            return self._random_visible_tile(actor_id)
        return self._parse_spawn_position(pos_arg)

    def _parse_spawn_position(self, pos_arg: str) -> tuple[int, int] | None:
        try:
            x_str, y_str = pos_arg.split(",")
            return int(x_str), int(y_str)
        except ValueError:
            return None

    def _visible_spawn_candidates(
        self, visible: np.ndarray, occupied: frozenset[tuple[int, int]]
    ) -> list[tuple[int, int]]:
        return [
            (x, y)
            for y in range(self.game_map.height)
            for x in range(self.game_map.width)
            if visible[y, x]
            and self.game_map.is_walkable(x, y)
            and (x, y) not in occupied
        ]

    def _random_visible_tile(self, actor_id: int) -> tuple[int, int] | None:
        if not self.game_map.has_entity(actor_id):
            return None
        ax, ay = self.game_map.get_entity_position(actor_id)
        entity = self._entities.get(actor_id)
        sight = (
            _fov.entity_sight(entity)
            if entity is not None
            else _fov.DEFAULT_SIGHT_RANGE
        )
        visible = _fov.compute_fov(self.game_map, ax, ay, sight)
        occupied = frozenset(self.game_map.get_all_positions().values())
        candidates = self._visible_spawn_candidates(visible, occupied)
        if not candidates:
            return None
        return random.choice(candidates)  # noqa: S311 — game logic, not crypto

    def gcd_fraction(self, entity_id: int) -> float | None:
        """Return entity's GCD progress (0.0–1.0) while active, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float | None
            Fraction through the GCD window, or ``None`` when inactive.
        """
        return self._casting.gcd_fraction(entity_id, self._abs_tick)

    def cast_fraction(self, entity_id: int) -> float | None:
        """Return entity's cast progress (0.0–1.0) if casting, else ``None``.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float | None
            Fraction through the cast time, or ``None`` when not casting.
        """
        return self._casting.cast_fraction(entity_id, self._abs_tick)

    def attack_cooldown_fraction(self, entity_id: int) -> float:
        """Return how far through the attack cooldown *entity_id* is (0–1).

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float
            ``0.0`` immediately after an attack; ``1.0`` when ready.
        """
        return self._combat.cooldown_fraction(
            entity_id, self._abs_tick, haste_factor=self._haste_factor(entity_id)
        )

    def ability_cooldown_fraction(self, entity_id: int, ability_name: str) -> float:
        """Return remaining cooldown for *ability_name* (1.0=just used, 0.0=ready).

        Parameters
        ----------
        entity_id : int
            Entity to query.
        ability_name : str
            Ability name.

        Returns
        -------
        float
            0.0 when ready or ability is unknown; otherwise fraction remaining.
        """
        entity = self._entities.get(entity_id)
        if entity is None:
            return 0.0
        ability = entity.abilities.get(ability_name)
        if ability is None:
            return 0.0
        return self._casting.ability_cooldown_fraction(
            entity_id, ability_name, ability.cooldown, self._abs_tick
        )

    def active_statuses(self, entity_id: int) -> list[StatusInstance]:
        """Return the non-expired status effects on *entity_id*.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        list[StatusInstance]
            Status effects whose ``expires_at`` is still in the future.
        """
        entity = self._entities.get(entity_id)
        if entity is None:
            return []
        return [s for s in entity.status_effects if not s.is_expired(self._abs_tick)]

    def has_active_status(self, entity_id: int, status_name: str) -> bool:
        """Return ``True`` when *entity_id* has a non-expired *status_name* status.

        Parameters
        ----------
        entity_id : int
            Entity to query.
        status_name : str
            Status name to look for.

        Returns
        -------
        bool
            ``True`` when at least one matching, non-expired status is found.
        """
        return any(s.name == status_name for s in self.active_statuses(entity_id))

    def _haste_factor(self, entity_id: int) -> float:
        """Return the combined haste multiplier for *entity_id* from active statuses.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        float
            Largest active haste multiplier, or ``1.0`` when none are present.
        """
        factors = [s.haste for s in self.active_statuses(entity_id) if s.haste != 1.0]
        return max(factors) if factors else 1.0

    def _resolve_new_target(self, args: tuple[str, ...]) -> int | None:
        """Parse numeric target arg, or return ``None`` to clear."""
        return int(args[0]) if args else None

    # ------------------------------------------------------------------
    # Event dispatch
    # ------------------------------------------------------------------

    def _drain_events(self) -> None:
        for _ in range(_MAX_EVENT_DEPTH):
            if not self._flush_ready_events():
                break

    def _flush_ready_events(self) -> bool:
        ready = [e for e in self._event_queue if e.resolve_at_tick <= self._abs_tick]
        self._event_queue = [
            e for e in self._event_queue if e.resolve_at_tick > self._abs_tick
        ]
        for event in ready:
            self._process_event(event)
        return bool(ready)

    def _process_event(self, event: Event) -> None:
        handler = self._event_handlers.get(event.event_type)
        if handler is not None:
            handler(event)

    def _dispatch_contact(self, event: Event) -> None:
        if event.payload and event.payload.get("opportunity"):
            self._log_opportunity_attack(event)
        player_ids = {p.entity.entity_id for p in self._players.values()}
        for cmd in self._contact.handle(event):
            if int(cmd.actor) not in player_ids or cmd.command_type in (
                CommandType.PRIME_COOLDOWN,
                CommandType.CLEAR_PRIME,
            ):
                self._command_queue.append(cmd)

    def _log_opportunity_attack(self, event: Event) -> None:
        attacker = self._entities.get(event.source_id)
        target = self._entities.get(event.target_id) if event.target_id else None
        if attacker is None or target is None:
            return
        text = f"{attacker.display_name} strikes {target.display_name} as they flee!"
        self.add_chat_message(text, OPP_ATTACK_COLOR)

    def _dispatch_death(self, event: Event) -> None:
        targeting_dead = [
            eid for eid, e in self._entities.items() if e.target_id == event.source_id
        ]
        player_ids = {p.entity.entity_id for p in self._players.values()}
        self._death.handle(event)
        for eid in targeting_dead:
            self._combat.forget(eid)
            if eid in player_ids:
                self._auto_target_attacker(eid)
        self._purge_cast_events(event.source_id)

    def _auto_target_attacker(self, entity_id: int) -> None:
        """Enqueue a TARGET command if a hostile is already targeting *entity_id*.

        Called after the player's current target dies.  If the entity now has
        no target and there is at least one other entity that has it as its
        ``target_id``, automatically acquire that attacker as the new target.

        Parameters
        ----------
        entity_id : int
            Player entity that just lost its target.
        """
        entity = self._entities.get(entity_id)
        if entity is None or entity.target_id is not None:
            return
        attacker = next(
            (e for e in self._entities.values() if e.target_id == entity_id),
            None,
        )
        if attacker is not None:
            self._command_queue.append(
                make_target_command(entity_id, attacker.entity_id)
            )

    def _purge_cast_events(self, entity_id: int) -> None:
        """Remove any pending cast/channel events for *entity_id* from the queue."""
        purge_types = (EventType.CAST_COMPLETE, EventType.CHANNEL_TICK)
        self._event_queue = [
            e
            for e in self._event_queue
            if not (e.event_type in purge_types and e.source_id == entity_id)
        ]

    # ------------------------------------------------------------------
    # Actor / target resolution
    # ------------------------------------------------------------------

    def _resolve_actor(self, actor: str) -> int | None:
        if actor == "me":
            player = next(iter(self._players.values()), None)
            if player is None:
                return None
            return player.entity.entity_id
        try:
            return int(actor)
        except ValueError:
            return None

    def _resolve_target(self, actor_id: int, arg: str) -> int | None:
        """Resolve a target argument, expanding ``@target`` to the actor's target.

        Parameters
        ----------
        actor_id : int
            Resolved entity ID of the attacker; used to look up ``target_id``
            when *arg* is ``"@target"``.
        arg : str
            Raw target argument from the command.

        Returns
        -------
        int | None
            Resolved target entity ID, or ``None`` if unresolvable.
        """
        if arg == "@target":
            entity = self._entities.get(actor_id)
            return entity.target_id if entity is not None else None
        return self._resolve_actor(arg)
