"""FiveClaw Agent — local MCP client for FiveClaw subscribers."""
__version__ = "1.2.9"
