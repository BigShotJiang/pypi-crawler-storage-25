"""Fruxon API client for executing agents on the Fruxon platform.

Public types (``ExecutionResult``, ``Agent``, ``StreamEvent``, …) live
in :mod:`fruxon.models`. They're re-exported below so existing
``from fruxon.fruxon import ExecutionResult`` callers keep working.
"""

import json
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Iterator
from typing import Any

from fruxon.exceptions import (
    AuthenticationError,
    ForbiddenError,
    FruxonAPIError,
    FruxonConnectionError,
    NotFoundError,
    ValidationError,
)
from fruxon.models import (
    Agent,
    ExecutionRecord,
    ExecutionResult,
    ExecutionTrace,
    Integration,
    StreamEvent,
    Tool,
)

# Re-exported so internal code and direct callers can keep importing from
# ``fruxon.fruxon``. Tests pin these for `isinstance` checks; the public
# import path (``from fruxon import ...``) is the supported one.
__all__ = [
    "Agent",
    "ExecutionRecord",
    "ExecutionResult",
    "ExecutionTrace",
    "FruxonClient",
    "Integration",
    "StreamEvent",
    "Tool",
]

_STATUS_EXCEPTIONS: dict[int, type[FruxonAPIError]] = {
    400: ValidationError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    422: ValidationError,
}


def _detect_actor() -> str | None:
    """Identify the tool making the request, for the ``X-Fruxon-Actor`` header.

    Order of precedence:

    1. ``FRUXON_ACTOR`` env var — explicit override, wins over everything.
    2. Harness-set env vars from known agent IDEs (``CLAUDECODE``,
       ``CURSOR_TRACE_ID``, ``OPENAI_CODEX``, ``BOLT_TRACE_ID``). These are
       set by the host environment, not the user, so detection is
       reliable.
    3. ``cli`` — direct human use of the CLI.

    Returns ``None`` only when called from a non-CLI context (the SDK
    used as a library), so the header is omitted entirely rather than
    misattributed.
    """
    import os
    import sys

    explicit = os.environ.get("FRUXON_ACTOR")
    if explicit:
        return explicit.strip() or None

    # Harness-set env vars — each agent IDE sets exactly one. Order
    # matters only when multiple are set simultaneously (which shouldn't
    # happen in practice); we report whichever we see first.
    for env, name in (
        ("CLAUDECODE", "claude-code"),
        ("CURSOR_TRACE_ID", "cursor"),
        ("OPENAI_CODEX", "codex"),
        ("BOLT_TRACE_ID", "bolt"),
    ):
        if os.environ.get(env):
            return name

    # Default to "cli" only when we're actually being invoked as a CLI
    # (entry-point script is `fruxon` or we're being run as a module),
    # so SDK-as-library use doesn't get falsely tagged.
    argv0 = (sys.argv[0] or "").rsplit("/", 1)[-1]
    if argv0 == "fruxon" or argv0.endswith("/fruxon"):
        return "cli"
    return None


class FruxonClient:
    """Client for the Fruxon platform API."""

    DEFAULT_BASE_URL = "https://api.fruxon.com"

    def __init__(
        self,
        *,
        api_key: str,
        org: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 120.0,
        actor: str | None = None,
    ) -> None:
        self._api_key = api_key
        # Actor: the tool that's making the request, distinct from the
        # authenticated user. Goes out as the X-Fruxon-Actor header on
        # every call so the backend can attribute writes correctly
        # (e.g. "this revision was authored by Claude on hagai's behalf").
        # Defaults to autodetection from the environment — see _detect_actor.
        self._actor = actor or _detect_actor()
        # Stored as ``_org`` to match the user-facing noun. The URL path
        # the backend still uses (``/v1/tenants/...``) is an
        # implementation detail of the server's multi-tenant architecture
        # and isn't exposed in the SDK or CLI surface.
        self._org = org
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        # Local dev backends serve a self-signed cert. Strict verification
        # is correct for everything else; for loopback hosts we'd otherwise
        # need every dev to install the cert into their trust store, which
        # nobody does. Standard CLI escape hatch (k8s/gcloud/docker do the
        # same).
        import ssl
        import urllib.parse as _up

        host = _up.urlparse(self._base_url).hostname or ""
        self._ssl_context: ssl.SSLContext | None = (
            ssl._create_unverified_context()  # noqa: S323 — loopback only
            if host in ("localhost", "127.0.0.1", "::1")
            else None
        )

    def execute(
        self,
        agent: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> ExecutionResult:
        """Execute an agent's currently deployed revision and return the result.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:execute``. Synchronous
        — the whole run completes before this returns. Use
        :meth:`stream` (or :meth:`stream_text`) if you want to surface
        progress while the agent is still running.

        Args:
            agent: The agent identifier.
            parameters: Execution parameters and inputs.
            attachments: File attachments.
            chat_user: Chat user information.
            session_id: Session identifier for multi-turn conversations.
        """
        url = self._agent_url(agent, ":execute")
        body = self._build_execution_body(
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        )
        return _parse_execution_result(self._post_json(url, body))

    def execute_revision(
        self,
        agent: str,
        revision: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> ExecutionResult:
        """Execute a specific revision of an agent, regardless of which one is deployed.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}/revisions/{revision}:execute``.
        Useful for A/B testing or for replaying historical traffic against a
        prior revision. Same auth and parameter contract as :meth:`execute`.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions/{revision}:execute"
        body = self._build_execution_body(
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        )
        return _parse_execution_result(self._post_json(url, body))

    def stream(
        self,
        agent: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> Iterator[StreamEvent]:
        """Execute an agent and yield typed Server-Sent Events as they arrive.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:stream``. Returns an
        iterator of :class:`StreamEvent` objects. Iteration finishes when the
        backend closes the stream — typically after a terminal ``done`` event.

        For the common case of "stream and print the model's text chunks,"
        prefer :meth:`stream_text`, which yields just the concatenable text
        pieces.
        """
        url = self._agent_url(agent, ":stream")
        body = self._build_execution_body(
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        )
        return self._post_sse(url, body)

    def stream_text(
        self,
        agent: str,
        *,
        parameters: dict[str, object] | None = None,
        attachments: list[dict[str, object]] | None = None,
        chat_user: dict[str, object] | None = None,
        session_id: str | None = None,
    ) -> Iterator[str]:
        """Convenience wrapper around :meth:`stream` that yields only text chunks.

        Filters the event stream down to ``text`` events and yields their
        ``chunk`` payload as a string. Use this when you want to mirror the
        chat-style streaming UX without dealing with tool calls, step traces,
        or terminal events.
        """
        for event in self.stream(
            agent,
            parameters=parameters,
            attachments=attachments,
            chat_user=chat_user,
            session_id=session_id,
        ):
            if event.event == "text":
                chunk = event.data.get("chunk")
                if isinstance(chunk, str):
                    yield chunk

    def test(self, agent: str, request: dict[str, object]) -> ExecutionResult:
        """Run a draft flow against an existing agent without publishing it.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:test``. Unlike
        :meth:`execute` — which runs the agent's *deployed* revision —
        this runs an inline draft: ``request`` is the full
        ``AgentTestRequest`` body (the candidate ``flow`` plus its
        ``subAgents``, ``assets``, ``integrationConfigs``, ``llmConfigs``,
        ``baseRevision``, and runtime ``parameters``). The ``agent`` path
        segment scopes the run to that agent — it gates Editor access and
        resolves any masked secrets from ``baseRevision``'s stored configs.

        Returns the same :class:`ExecutionResult` shape as :meth:`execute`.
        The SDK stays deliberately thin here: it posts ``request``
        verbatim rather than modelling the broad, fast-evolving
        ``AgentTestRequest`` schema — the caller assembles the body.
        """
        url = self._agent_url(agent, ":test")
        return _parse_execution_result(self._post_json(url, request))

    def stream_test(self, agent: str, request: dict[str, object]) -> Iterator[StreamEvent]:
        """Streaming counterpart of :meth:`test`.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}:streamTest`` and
        yields the same typed :class:`StreamEvent` objects as
        :meth:`stream`. ``request`` is the ``AgentTestRequest`` body, same
        as :meth:`test`.
        """
        url = self._agent_url(agent, ":streamTest")
        return self._post_sse(url, request)

    def list_agents(self) -> list[Agent]:
        """Fetch every agent in the current org.

        Hits ``GET /v1/tenants/{org}/agents``. Each item is mapped to
        :class:`Agent`, which is intentionally a narrow subset of the API
        payload — we only expose the fields a CLI/SDK caller is likely to
        use (id, display name, enable state, current revision, tags).
        Soft-deleted agents are filtered out client-side.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents"
        raw = self._get_json(url)
        if not isinstance(raw, list):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a list of agents, got a different shape.",
            )
        return [_parse_agent(item) for item in raw if _is_active_agent(item)]

    def get_execution_record(self, agent: str, record_id: str) -> ExecutionRecord:
        """Fetch a single past execution's record.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}/executionRecords/{recordId}``.
        Returns the narrow :class:`ExecutionRecord` view — start/end times,
        token counts, cost, status — for the ``fruxon trace`` surface and
        any user-level diagnostics.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/executionRecords/{record_id}"
        return _parse_execution_record(self._get_json(url))

    def get_execution_trace(self, agent: str, record_id: str) -> dict:
        """Fetch the step-by-step trace for a past execution.

        Hits the ``:trace`` action on the execution record. The trace
        payload is intentionally returned as a raw dict because the
        shape — nested step trees, tool metadata, provider-specific
        fields — is broad and evolves faster than a typed model would
        gracefully handle. Callers wanting structured access should
        peel into the dict; ``fruxon trace`` does so for rendering.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/executionRecords/{record_id}:trace"
        result = self._get_json(url)
        if isinstance(result, dict):
            return result
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an object from the trace endpoint.",
        )

    def get_agent(self, agent: str) -> Agent:
        """Fetch a single agent's metadata by ID.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}``. 404s surface as
        :class:`NotFoundError` so callers can distinguish "no such agent"
        from other failures.
        """
        url = self._agent_url(agent, "")
        return _parse_agent(self._get_json(url))

    def create_agent(self, body: dict[str, object]) -> dict:
        """Provision a new agent shell. Returns the created agent record.

        Hits ``POST /v1/tenants/{tenant}/agents`` with a ``CreateAgent``
        body. The agent starts with no deployed revision — call
        :meth:`create_revision` next, then deploy it. Returns the raw
        server response (typed as :class:`Agent` server-side, but
        passed through as a dict so callers see fields the SDK's narrow
        :class:`Agent` view drops).
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents"
        return self._post_json(url, body)

    def create_revision(self, agent: str, body: dict[str, object]) -> dict:
        """Create a new revision for an existing agent.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}/revisions`` with a
        ``CreateAgentRevision`` body. The revision starts undeployed; call
        ``POST .../revisions/{revision}:deploy`` to make it live.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions"
        return self._post_json(url, body)

    def deploy_revision(self, agent: str, revision: int | str) -> dict:
        """Deploy a revision so subsequent ``run``/``execute`` calls hit it.

        Hits ``POST /v1/tenants/{tenant}/agents/{agent}/revisions/{revision}:deploy``.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions/{revision}:deploy"
        return self._post_json(url, {})

    def get_revision(self, agent: str, revision: int | str) -> dict:
        """Fetch the full body of a single agent revision.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}/revisions/{revision}``.
        Returns the raw revision payload — flow, parameters, integrationConfigs,
        llmConfigs, assets, jobPolicyConfigs, audit fields. Used to seed a new
        revision from an existing one without re-authoring from scratch.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions/{revision}"
        raw = self._get_json(url)
        if not isinstance(raw, dict):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a revision object.",
            )
        return raw

    def get_agent_parameters(self, agent: str, revision: int | str) -> list[str]:
        """Fetch the input parameter names a revision of an agent expects.

        Hits ``GET /v1/tenants/{tenant}/agents/{agent}/revisions/{rev}:parameters``.
        The server returns an ``{"parameters": ["user_query", …]}`` shape — we
        unwrap it to a flat list because callers overwhelmingly want the names,
        not the wrapper object. Missing or non-string entries are filtered out
        so a partial server response doesn't pollute the list.

        Used by ``fruxon agents get`` so users can see which keys to pass to
        ``fruxon run <agent> -p <key>=…`` without having to fail a request to
        learn the right name.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}/revisions/{revision}:parameters"
        raw = self._get_json(url)
        if isinstance(raw, dict):
            params = raw.get("parameters") or []
            if isinstance(params, list):
                return [str(p) for p in params if isinstance(p, str) and p]
        return []

    # ------------------------------------------------------------------ skills

    def list_skills(self) -> list[dict]:
        """List every skill visible to the tenant.

        Hits ``GET /v1/tenants/{tenant}/skills``. Returns the raw
        ``SkillResponse`` shape (id, displayName, description, tools, …)
        — exposed verbatim so the CLI's ``fruxon skills`` commands can
        surface every field the server emits without the SDK becoming a
        bottleneck on schema additions.

        The list contains both system skills (built-in, ids like
        ``fruxon-build-agent`` / ``customer-support``) and tenant-authored
        ones, mixed together — distinguish by the ``type`` field.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/skills"
        raw = self._get_json(url)
        return raw if isinstance(raw, list) else []

    def get_skill(self, skill_id: str) -> dict:
        """Fetch a single skill by id.

        Hits ``GET /v1/tenants/{tenant}/skills/{id}``. The
        ``instructions`` field carries the full markdown procedural
        knowledge — that's what an LLM driving the CLI pipes into its
        context via ``fruxon skills show <id>``.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/skills/{skill_id}"
        raw = self._get_json(url)
        return raw if isinstance(raw, dict) else {}

    # ------------------------------------------------------------------ llm providers

    def list_llm_providers(self) -> list[dict]:
        """List the tenant's available LLM providers (with their models).

        Hits ``GET /v1/tenants/{tenant}/llmProviders``. Each entry is the
        raw provider payload — ``{provider, configMetadata, models}`` — so
        callers can pick a ``provider.id`` and a ``models[i].id`` without
        guessing at model name strings.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/llmProviders"
        raw = self._get_json(url)
        if isinstance(raw, dict):
            items = raw.get("items")
        else:
            items = raw
        if not isinstance(items, list):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a list of LLM providers, got a different shape.",
            )
        return items

    def get_llm_provider(self, provider_id: str) -> dict:
        """Fetch one LLM provider with its full model list.

        Hits ``GET /v1/tenants/{tenant}/llmProviders/{providerId}``.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/llmProviders/{provider_id}"
        raw = self._get_json(url)
        if not isinstance(raw, dict):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected an LLM provider object.",
            )
        return raw

    # ------------------------------------------------------------------ integrations

    def list_integrations(
        self,
        *,
        search: str | None = None,
        types: list[str] | None = None,
        tags: list[str] | None = None,
        all_pages: bool = True,
    ) -> list[Integration]:
        """List the org's integrations.

        Hits ``GET /v1/tenants/{tenant}/integrations``. ``search`` / ``types``
        / ``tags`` map to the server-side filter query params. The endpoint
        is paginated (a ``ListPage`` envelope); by default this walks every
        page so callers see the full org. Each item is mapped to the narrow
        :class:`Integration` view.

        ``all_pages=False`` returns just the first page — useful for callers
        that genuinely want a single page (e.g. previewing the first N
        records). The walker cycles safely: if the server hands back the
        same ``nextPageToken`` twice in a row (a known bug on some
        deployments), we break out instead of looping forever.
        """
        base_params: list[tuple[str, str]] = []
        if search:
            base_params.append(("search", search))
        base_params.extend(("types", t) for t in (types or []))
        base_params.extend(("tags", t) for t in (tags or []))
        base_url = f"{self._base_url}/v1/tenants/{self._org}/integrations"

        items, next_token = self._fetch_page(base_url, base_params, page_token=None)
        if all_pages:
            seen_tokens: set[str] = set()
            while next_token and next_token not in seen_tokens:
                requested_token = next_token
                seen_tokens.add(requested_token)
                more, next_token = self._fetch_page(base_url, base_params, page_token=requested_token)
                # Some server builds echo the same nextPageToken back regardless
                # of the requested token (a pagination bug we want to be resilient
                # to). When that happens we'd otherwise extend ``items`` with a
                # duplicate of page 1 — detect it and break before mutating.
                if next_token == requested_token:
                    break
                if not more:
                    break
                items.extend(more)
        return [_parse_integration(i) for i in items]

    def _fetch_page(
        self,
        base_url: str,
        base_params: list[tuple[str, str]],
        *,
        page_token: str | None,
    ) -> tuple[list, str | None]:
        """Fetch one page of a ``ListPage``-shaped endpoint.

        Returns ``(items, next_page_token)``. The token is ``None`` when
        the server signals the last page. Centralized so list endpoints
        that share the same envelope (integrations, tools, …) don't each
        reimplement the unwrap.

        The server-side ``PagingModelBinder`` reads ``page_token`` /
        ``page_size`` in snake_case; camelCase variants are silently
        ignored, which manifests as the server echoing the same token
        back forever. Sending the snake_case name is the actual fix; the
        cycle-detection in callers is now just defense-in-depth.
        """
        params = list(base_params)
        if page_token:
            params.append(("page_token", page_token))
        url = base_url + ("?" + urllib.parse.urlencode(params) if params else "")
        raw = self._get_json(url)
        if isinstance(raw, dict):
            items = raw.get("items")
            next_token = raw.get("nextPageToken") or None
        else:
            items = raw
            next_token = None
        if not isinstance(items, list):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a list payload, got a different shape.",
            )
        return items, next_token

    def get_integration(self, integration: str) -> Integration:
        """Fetch a single integration by ID.

        Hits ``GET /v1/tenants/{tenant}/integrations/{integration}``. Secret
        credential values are stripped server-side; use
        :meth:`verify_integration` to confirm credentials still work.
        """
        return _parse_integration(self._get_json(self._integration_url(integration)))

    def create_integration(self, body: dict[str, object]) -> Integration:
        """Create an integration.

        Hits ``POST /v1/tenants/{tenant}/integrations``. ``body`` is the
        ``CreateIntegration`` payload (``id``, ``displayName``,
        ``description``, ``configMetadata``); posted verbatim. Returns the
        narrow :class:`Integration` view of the created record.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/integrations"
        return _parse_integration(self._post_json(url, body))

    def update_integration(self, integration: str, body: dict[str, object]) -> Integration:
        """Update an integration.

        Hits ``PUT /v1/tenants/{tenant}/integrations/{integration}`` with the
        ``UpdateIntegration`` body. Omit credential fields to keep existing
        values unchanged.
        """
        return _parse_integration(self._put_json(self._integration_url(integration), body))

    def verify_integration(self, integration: str, body: dict[str, object]) -> dict:
        """Verify an integration's auth configuration can connect.

        Hits ``POST /v1/tenants/{tenant}/integrations/{integration}:verifyConfig``.
        ``body`` is the ``VerifyAuthConfigRequest`` (``authMetadataId``,
        ``authConfig``, ``configParameters``). Returns the raw
        ``{success, error, authorizationUrl}`` result — a failed *check* is a
        result here, not an exception; only transport/HTTP failures raise.
        """
        result = self._post_json(self._integration_url(integration, ":verifyConfig"), body)
        if not isinstance(result, dict):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a verification-result object.",
            )
        return result

    # ------------------------------------------------------------------ integration configs

    def list_integration_configs(self, integration: str) -> list[dict]:
        """List the tenant-level configs registered for an integration.

        Hits ``GET /v1/tenants/{tenant}/integrations/{integration}/configs``.
        Returns the raw config payloads — id, integrationId, displayName,
        parameters, auth metadata (secrets redacted). An agent revision
        references one of these by its ``id`` via ``tenantConfigId`` so the
        revision can reuse credentials without inlining auth.
        """
        url = self._integration_url(integration, "/configs")
        raw = self._get_json(url)
        # Accept either a bare list (older shape) or a ListPage envelope.
        if isinstance(raw, dict):
            items = raw.get("items")
            if items is None:
                items = raw.get("configs")
        else:
            items = raw
        if not isinstance(items, list):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a list of integration configs, got a different shape.",
            )
        return items

    def get_integration_config(self, integration: str, config_id: str) -> dict:
        """Fetch a single tenant-level integration config.

        Hits ``GET /v1/tenants/{tenant}/integrations/{integration}/configs/{configId}``.
        """
        url = self._integration_url(integration, f"/configs/{config_id}")
        raw = self._get_json(url)
        if not isinstance(raw, dict):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected an integration config object.",
            )
        return raw

    # ------------------------------------------------------------------ tools

    def list_tools(
        self,
        integration: str,
        *,
        types: list[str] | None = None,
        all_pages: bool = True,
    ) -> list[Tool]:
        """List the tools registered under an integration.

        Hits ``GET /v1/tenants/{tenant}/integrations/{integration}/tools``.
        ``types`` filters server-side by tool type. Each item is mapped to
        the narrow :class:`Tool` view.

        The endpoint switched to a ``ListPage`` envelope on the backend in
        May 2026; by default this walks ``nextPageToken`` so callers see
        every tool (integrations like GitHub carry 30+, well past the
        server's default page size of 10). Pass ``all_pages=False`` to
        get just the first page.
        """
        base_url = self._tools_url(integration)
        base_params: list[tuple[str, str]] = [("types", t) for t in (types or [])]

        items, next_token = self._fetch_page_with_legacy_fallback(base_url, base_params)
        if all_pages and next_token:
            seen_tokens: set[str] = set()
            while next_token and next_token not in seen_tokens:
                requested_token = next_token
                seen_tokens.add(requested_token)
                more, next_token = self._fetch_page(base_url, base_params, page_token=requested_token)
                if next_token == requested_token or not more:
                    break
                items.extend(more)
        return [_parse_tool(t) for t in items]

    def _fetch_page_with_legacy_fallback(
        self,
        base_url: str,
        base_params: list[tuple[str, str]],
    ) -> tuple[list, str | None]:
        """First-page fetcher that also accepts the legacy ``{tools: [...]}`` shape.

        The tools endpoint was changed from a bare ``{tools: [...]}``
        response to a ``ListPage`` envelope in May 2026; some self-hosted
        deployments may still be running an older build. We try the new
        shape first (via ``_fetch_page``) and only fall back to the
        legacy unwrap if the standard envelope didn't materialise.
        """
        try:
            return self._fetch_page(base_url, base_params, page_token=None)
        except FruxonAPIError as exc:
            if exc.title != "Unexpected response":
                raise
        # Re-issue the GET so we can inspect the raw shape ourselves.
        url = base_url + ("?" + urllib.parse.urlencode(base_params) if base_params else "")
        raw = self._get_json(url)
        if isinstance(raw, dict):
            items = raw.get("tools")
        else:
            items = raw
        if not isinstance(items, list):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a list of tools, got a different shape.",
            )
        return items, None

    def get_tool(self, integration: str, tool: str) -> Tool:
        """Fetch a single tool by its ``(integration, tool)`` composite key.

        Hits ``GET /v1/tenants/{tenant}/integrations/{integration}/tools/{tool}``.
        The same ``tool`` ID under a different integration is a different
        resource.
        """
        return _parse_tool(self._get_json(self._tool_url(integration, tool)))

    def create_tool(self, integration: str, body: dict[str, object]) -> Tool:
        """Create a tool under an integration.

        Hits ``POST /v1/tenants/{tenant}/integrations/{integration}/tools``.
        ``body`` is the ``CreateToolRequest`` payload (``id``,
        ``integrationId``, ``description``, ``descriptor``,
        ``parametersMetadata``, …); posted verbatim.
        """
        return _parse_tool(self._post_json(self._tools_url(integration), body))

    def update_tool(
        self,
        integration: str,
        tool: str,
        body: dict[str, object],
        *,
        python: bool = False,
    ) -> Tool:
        """Update a tool — a wholesale PUT, not a patch.

        Hits ``PUT .../tools/{tool}`` for HTTP/API tools, or
        ``PUT .../tools/{tool}:python`` when ``python=True`` (Python-script
        tools go through a separate route on the backend). Any field omitted
        from ``body`` is reset.
        """
        action = ":python" if python else ""
        return _parse_tool(self._put_json(self._tool_url(integration, tool, action), body))

    def delete_tool(self, integration: str, tool: str) -> None:
        """Hard-delete a tool.

        Hits ``DELETE /v1/tenants/{tenant}/integrations/{integration}/tools/{tool}``.
        Agents that still reference the tool by ID will fail at execution —
        the delete itself doesn't cascade.
        """
        self._delete(self._tool_url(integration, tool))

    def test_tool(self, integration: str, body: dict[str, object]) -> dict:
        """Test-run a tool with the supplied parameters.

        Hits ``POST /v1/tenants/{tenant}/integrations/{integration}/tools:test``.
        ``body`` is the ``ToolTestRequest`` (``descriptor``,
        ``parametersMetadata``, ``parameters``, ``config``, ``configMetadata``).
        Returns the raw ``{response}`` result.
        """
        result = self._post_json(self._tools_url(integration) + ":test", body)
        if not isinstance(result, dict):
            raise FruxonAPIError(
                status=200,
                title="Unexpected response",
                detail="Expected a tool-execution-result object.",
            )
        return result

    # ------------------------------------------------------------------ api keys

    def list_api_keys(self) -> list[dict]:
        """List every API key in the current org.

        Hits ``GET /v1/tenants/{tenant}/apiKeys``. Returns the raw
        payload (id, name, isActive, keyPrefix, scopes, createdAt,
        expiresAt, lastUsedAt, revokedAt, type) so callers can render
        whatever fields they need. Secrets are not present — the raw
        key value is shown only once at mint time.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys"
        raw = self._get_json(url)
        return raw if isinstance(raw, list) else []

    def generate_api_key(self, body: dict[str, object]) -> dict:
        """Mint a new API key. Returns the one-time-reveal payload.

        Hits ``POST /v1/tenants/{tenant}/apiKeys:generate``. The
        response is the only time the raw secret (``apiKey``) crosses
        the wire — store it immediately. Body fields: ``name``,
        ``expirationDays``, ``scopes``, ``preset``, ``type``.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys:generate"
        return self._post_json(url, body)

    def rotate_api_key(self, api_key_id: str, overrides: dict | None = None) -> dict:
        """Rotate a key: mint a replacement, revoke the original.

        Hits ``POST /v1/tenants/{tenant}/apiKeys/{id}:rotate``. Empty
        ``overrides`` (or ``None``) inherits scopes/name/expiry from
        the original — "no changes other than the secret." Pass
        ``{preset|scopes|name|expirationDays}`` to narrow / widen
        permissions, rename, or change lifetime in the same call.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys/{api_key_id}:rotate"
        return self._post_json(url, overrides or {})

    def update_api_key(self, api_key_id: str, body: dict[str, object]) -> dict:
        """Update a key's mutable state (currently only ``isActive``).

        Hits ``PATCH /v1/tenants/{tenant}/apiKeys/{id}``. Use this to
        revoke a key (``{isActive: false}``) or restore it. Scopes
        are intentionally immutable post-mint — to change permissions,
        rotate with ``scopes``/``preset`` overrides.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys/{api_key_id}"
        return self._put_or_patch(url, body, method="PATCH")

    def delete_api_key(self, api_key_id: str) -> None:
        """Hard-delete a key.

        Hits ``DELETE /v1/tenants/{tenant}/apiKeys/{id}``. The audit
        trail survives — events have no FK to the keys table — but
        the key itself is gone. For a reversible revoke, prefer
        :meth:`update_api_key` with ``{isActive: false}``.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys/{api_key_id}"
        self._delete(url)

    def list_api_key_audit_events(self, api_key_id: str, limit: int = 50) -> list[dict]:
        """Fetch the audit timeline for a key, newest-first.

        Hits ``GET /v1/tenants/{tenant}/apiKeys/{id}/auditEvents``.
        Events: ``MINTED`` / ``ROTATED`` / ``REVOKED`` /
        ``USED_WHILE_REVOKED``. Each carries ``createdAt``, ``actor``,
        and a free-form ``details`` JSON string with event-type-
        specific fields (granted scopes on MINTED, replacement
        prefix on ROTATED, remote IP on USED_WHILE_REVOKED).
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys/{api_key_id}/auditEvents?limit={limit}"
        raw = self._get_json(url)
        return raw if isinstance(raw, list) else []

    def get_current_api_key(self) -> dict | None:
        """Fetch the metadata of the API key making this request.

        Hits ``GET /v1/tenants/{tenant}/apiKeys/current``. Returns the
        full ApiKey shape — name, keyPrefix, scopes, isActive,
        expiresAt, lastUsedAt, createdAt, type, etc. — for the key
        carried in the ``X-API-Key`` header.

        Returns ``None`` on 404 (caller authenticated via federation/
        JWT so there's no API key in scope to introspect).
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys/current"
        from fruxon.exceptions import NotFoundError

        try:
            raw = self._get_json(url)
        except NotFoundError:
            return None
        return raw if isinstance(raw, dict) else None

    def list_api_key_scopes(self) -> dict:
        """Fetch the scope vocabulary + presets the server is willing to mint.

        Hits ``GET /v1/tenants/{tenant}/apiKeys/scopes``. Returns the
        full discovery payload — scope list with labels/helpers,
        resource metadata, preset list. Used by the CLI's
        ``fruxon keys scopes`` and ``fruxon keys create --preset``
        validation.
        """
        url = f"{self._base_url}/v1/tenants/{self._org}/apiKeys/scopes"
        raw = self._get_json(url)
        return raw if isinstance(raw, dict) else {}

    def _put_or_patch(self, url: str, body: dict[str, object], method: str) -> dict:
        """Shared HTTP body request for PUT/PATCH. Mirrors :meth:`_post_json`.

        Lives next to the api-keys block because PATCH was first added
        for the ``isActive`` toggle. If a second caller needs PATCH
        for a different resource, factor it out.
        """
        req = self._build_request(url, body, accept="application/json", method=method)
        try:
            with urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e
        # Unreachable but quiets the type checker.
        return {}

    # ------------------------------------------------------------------ internals

    def _agent_url(self, agent: str, action: str) -> str:
        return f"{self._base_url}/v1/tenants/{self._org}/agents/{agent}{action}"

    def _integration_url(self, integration: str, action: str = "") -> str:
        return f"{self._base_url}/v1/tenants/{self._org}/integrations/{integration}{action}"

    def _tools_url(self, integration: str) -> str:
        return f"{self._base_url}/v1/tenants/{self._org}/integrations/{integration}/tools"

    def _tool_url(self, integration: str, tool: str, action: str = "") -> str:
        return f"{self._tools_url(integration)}/{tool}{action}"

    @staticmethod
    def _build_execution_body(
        *,
        parameters: dict[str, object] | None,
        attachments: list[dict[str, object]] | None,
        chat_user: dict[str, object] | None,
        session_id: str | None,
    ) -> dict[str, object]:
        body: dict[str, object] = {}
        if parameters is not None:
            body["parameters"] = parameters
        if attachments is not None:
            body["attachments"] = attachments
        if chat_user is not None:
            body["chatUser"] = chat_user
        if session_id is not None:
            body["sessionId"] = session_id
        return body

    def _post_json(self, url: str, body: dict[str, object]) -> dict:
        req = self._build_request(url, body, accept="application/json")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e

    def _put_json(self, url: str, body: dict[str, object]) -> dict:
        """PUT a JSON body — the update verb for integrations and tools.

        Shares the request builder and error-mapping pipeline with
        :meth:`_post_json`; only the HTTP method differs.
        """
        req = self._build_request(url, body, accept="application/json", method="PUT")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e

    def _delete(self, url: str) -> None:
        """DELETE a resource. No request body, no response body expected
        (the API returns 204); a 2xx is success, anything else maps to
        the usual typed exception."""
        req = urllib.request.Request(
            url,
            headers=self._auth_headers({"Accept": "application/json"}),
            method="DELETE",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context) as resp:
                resp.read()  # drain so the connection can be reused
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e

    def _get_json(self, url: str) -> object:
        """GET an API endpoint and return the parsed JSON body.

        Mirrors :meth:`_post_json` but without a request body and forced
        to GET. Same error-mapping pipeline so callers see the same typed
        exceptions regardless of HTTP method.
        """
        req = urllib.request.Request(
            url,
            headers=self._auth_headers({"Accept": "application/json"}),
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e

    def _post_sse(self, url: str, body: dict[str, object]) -> Iterator[StreamEvent]:
        req = self._build_request(url, body, accept="text/event-stream")
        try:
            resp = urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_context)
        except urllib.error.HTTPError as e:
            _raise_api_error(e)
        except urllib.error.URLError as e:
            raise FruxonConnectionError(str(e.reason)) from e
        return _iter_sse_events(resp)

    def _auth_headers(self, base: dict[str, str]) -> dict[str, str]:
        """Stamp the API key and (when known) the actor onto a header dict.

        Centralized so every code path — POST, GET, DELETE, SSE — sends
        the same attribution metadata. Omitting the actor header when
        it's None keeps the wire clean for direct API users who haven't
        set one.
        """
        out = {**base, "X-API-KEY": self._api_key}
        if self._actor:
            out["X-Fruxon-Actor"] = self._actor
        return out

    def _build_request(
        self,
        url: str,
        body: dict[str, object],
        *,
        accept: str,
        method: str = "POST",
    ) -> urllib.request.Request:
        return urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers=self._auth_headers({"Content-Type": "application/json", "Accept": accept}),
            method=method,
        )


def _iter_sse_events(resp: Any) -> Iterator[StreamEvent]:
    """Parse the SSE response stream into ``StreamEvent`` objects.

    Backend emits events as ``event: <type>\\ndata: <json>\\n\\n``. We
    accumulate ``event:`` / ``data:`` lines until a blank-line separator,
    then yield. The response is closed when iteration ends or when the
    caller breaks early.
    """
    try:
        event_type = "message"
        data_lines: list[str] = []
        for raw in resp:
            line = raw.decode("utf-8").rstrip("\n").rstrip("\r")
            if line == "":
                # Dispatch only if we collected at least an event or data line —
                # heartbeat keep-alives are emitted as blank lines.
                if event_type != "message" or data_lines:
                    payload_raw = "\n".join(data_lines)
                    try:
                        payload = json.loads(payload_raw) if payload_raw else {}
                    except json.JSONDecodeError:
                        payload = {"_raw": payload_raw}
                    yield StreamEvent(
                        event=event_type,
                        data=payload if isinstance(payload, dict) else {"value": payload},
                    )
                event_type = "message"
                data_lines = []
                continue
            if line.startswith(":"):
                # SSE comment / keep-alive — ignore.
                continue
            if line.startswith("event:"):
                event_type = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip(" "))
    finally:
        resp.close()


def _raise_api_error(error: urllib.error.HTTPError) -> None:
    """Parse an HTTP error response and raise the appropriate exception."""
    body: dict | None = None
    try:
        body = json.loads(error.read().decode("utf-8"))
        title = body.get("title") or body.get("message") or "Error"
        detail = body.get("detail") or body.get("details") or ""
    except (json.JSONDecodeError, UnicodeDecodeError):
        title = "Error"
        detail = str(error)

    # 403 + the typed `insufficient_scope` body → richer subclass that
    # carries the structured fields so the CLI can render
    # ``✗ This key can't agents:write (granted: …)`` without parsing
    # prose. The server emits this shape from RequireScopeFilter; any
    # other 403 falls through to the generic ForbiddenError.
    if error.code == 403 and isinstance(body, dict) and body.get("error") == "insufficient_scope":
        from fruxon.exceptions import InsufficientScopeError

        granted = body.get("granted") or []
        if not isinstance(granted, list):
            granted = []
        raise InsufficientScopeError(
            status=error.code,
            title=title,
            detail=detail,
            required=str(body.get("required") or ""),
            granted=[str(s) for s in granted],
            hint=str(body.get("hint") or ""),
        ) from error

    exc_class = _STATUS_EXCEPTIONS.get(error.code, FruxonAPIError)
    raise exc_class(status=error.code, title=title, detail=detail) from error


def _parse_agent(data: object) -> Agent:
    """Map the raw Agent payload into the SDK's narrow Agent dataclass.

    Defaults are deliberately lenient — the server may add or remove
    fields over time, and a missing field shouldn't cause the SDK to
    crash on what's otherwise a perfectly usable response.
    """
    if not isinstance(data, dict):
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an agent object, got a different shape.",
        )
    tags = data.get("tags") or []
    return Agent(
        id=str(data.get("id") or ""),
        display_name=str(data.get("displayName") or ""),
        description=str(data.get("description") or ""),
        enabled=bool(data.get("enabled", False)),
        current_revision=int(data.get("currentRevision") or 0),
        tags=[str(t) for t in tags if isinstance(t, str)],
    )


def _parse_integration(data: object) -> Integration:
    """Map the raw Integration payload to the SDK's narrow dataclass.

    Same lenient-defaults philosophy as :func:`_parse_agent` — a missing
    field shouldn't crash the SDK on an otherwise-usable response.
    """
    if not isinstance(data, dict):
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an integration object, got a different shape.",
        )
    tags = data.get("tags") or []
    return Integration(
        id=str(data.get("id") or ""),
        display_name=str(data.get("displayName") or ""),
        description=str(data.get("description") or ""),
        type=str(data.get("type") or ""),
        tags=[str(t) for t in tags if isinstance(t, str)],
    )


def _parse_tool(data: object) -> Tool:
    """Map the raw Tool / ToolWithPricing payload to the SDK's narrow dataclass."""
    if not isinstance(data, dict):
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected a tool object, got a different shape.",
        )
    return Tool(
        id=str(data.get("id") or ""),
        integration_id=str(data.get("integrationId") or ""),
        display_name=str(data.get("displayName") or ""),
        description=str(data.get("description") or ""),
        tool_type=str(data.get("toolType") or ""),
        action_type=str(data.get("actionType") or ""),
    )


def _is_active_agent(data: object) -> bool:
    """Filter predicate for the list endpoint — drop soft-deleted agents.

    The API returns ``deletedAt`` on agents pending deletion in the grace
    period. Callers of ``list_agents`` overwhelmingly want the *active*
    set, so we hide them by default. Callers that need everything can
    drop down to the raw HTTP layer.
    """
    return isinstance(data, dict) and not data.get("deletedAt")


def _parse_execution_record(data: object) -> ExecutionRecord:
    """Map the raw ``AgentExecutionRecordResponse`` payload to our
    narrower :class:`ExecutionRecord` dataclass.

    The full server response has many fields (delivery status, redaction
    flags, provider-specific data) we don't surface; the parser
    deliberately ignores them so additions on the server side don't
    require an SDK release.
    """
    if not isinstance(data, dict):
        raise FruxonAPIError(
            status=200,
            title="Unexpected response",
            detail="Expected an execution-record object.",
        )
    return ExecutionRecord(
        id=str(data.get("id") or ""),
        agent_id=str(data.get("agentId") or ""),
        agent_revision=int(data.get("agentRevision") or 0),
        status=str(data.get("status") or ""),
        start_time=int(data.get("startTime") or 0),
        end_time=int(data["endTime"]) if data.get("endTime") is not None else None,
        input_tokens=int(data.get("inputTokens") or 0),
        output_tokens=int(data.get("outputTokens") or 0),
        total_cost=float(data.get("totalCost") or 0.0),
    )


def _parse_execution_result(data: dict) -> ExecutionResult:
    """Parse raw API response into an ExecutionResult."""
    trace_data: dict = data.get("trace", {})
    trace = ExecutionTrace(
        agent_id=trace_data.get("agentId", ""),
        agent_revision=trace_data.get("agentRevision", 0),
        duration=trace_data.get("duration", 0),
        input_cost=trace_data.get("inputCost", 0.0),
        output_cost=trace_data.get("outputCost", 0.0),
        total_cost=trace_data.get("totalCost", 0.0),
    )
    return ExecutionResult(
        response=data.get("response", ""),
        trace=trace,
        session_id=data.get("sessionId", ""),
        links=data.get("links", []),
        execution_record_id=data.get("executionRecordId", ""),
    )
