"""``--schema`` support for the write commands.

Every ``--file`` command (``agents test``, ``integrations create``,
``tools create``, …) accepts a structured JSON body whose shape is
defined by a backend DTO — ``AgentTestRequest``, ``CreateIntegration``,
``CreateToolRequest``, etc. A human looks them up in the docs; an LLM
authoring a request on a user's behalf can't. ``--schema`` closes that
gap: it pulls the live OpenAPI document, extracts one DTO together
with the transitive ``$ref`` closure, and prints a self-contained
JSON Schema the caller can read or feed to an LLM.

Sourced from the deployed spec — not bundled — so the schema is always
in lockstep with the server the CLI is talking to. The spec is cached
per-process; the same command can call ``print_schema`` multiple times
without re-fetching.
"""

from __future__ import annotations

import json
import re
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request

import typer

from fruxon import credentials
from fruxon.fruxon import FruxonClient
from fruxon.ui import say_err

_SWAGGER_PATH = "/swagger/v1/swagger.json"
_REF_PREFIX = "#/components/schemas/"
_DEFS_PREFIX = "#/$defs/"

# Per-process cache of the fetched OpenAPI document keyed by base URL.
# Same command invocation may surface multiple schemas (unlikely today,
# but cheap to support), and tests can monkey-patch this dict.
_spec_cache: dict[str, dict] = {}


def print_schema(type_name: str, *, base_url: str | None = None) -> None:
    """Print the JSON Schema for ``type_name`` to stdout, then return.

    The output is a single JSON document whose root is a ``$ref`` to
    ``type_name`` and whose ``$defs`` holds every schema reachable from
    it. Doesn't require auth — the OpenAPI spec is public. Exits 1 with
    a pointed error if the spec can't be fetched or the type isn't in
    it.
    """
    resolved = credentials.resolve_base_url(base_url) or FruxonClient.DEFAULT_BASE_URL
    spec = _fetch_spec(resolved)
    components = (spec.get("components") or {}).get("schemas") or {}
    if type_name not in components:
        say_err(
            f"Type [bold]{type_name}[/bold] is not in the OpenAPI spec.",
            hint=f"Open {resolved}{_SWAGGER_PATH} to see what is.",
        )
        raise typer.Exit(code=1)

    schema = _build_schema(components, type_name)
    json.dump(schema, sys.stdout, indent=2)
    sys.stdout.write("\n")


def _fetch_spec(base_url: str) -> dict:
    if base_url in _spec_cache:
        return _spec_cache[base_url]

    url = f"{base_url}{_SWAGGER_PATH}"
    # Local dev servers run with a self-signed cert; the strict default
    # context rejects them and the user can't act on a cert-verify error.
    # Standard CLI practice (k8s, gcloud, docker) — skip verification for
    # loopback hosts only, never for anything else.
    host = urllib.parse.urlparse(base_url).hostname or ""
    ctx: ssl.SSLContext | None = None
    if host in ("localhost", "127.0.0.1", "::1"):
        ctx = ssl._create_unverified_context()  # noqa: S323 — loopback only

    try:
        with urllib.request.urlopen(url, timeout=10, context=ctx) as resp:  # noqa: S310 — http(s) only
            data = json.load(resp)
    except urllib.error.URLError as exc:
        say_err(
            f"Couldn't fetch the OpenAPI spec from {url}: {exc}",
            hint="Check that the server is reachable, then try again.",
        )
        raise typer.Exit(code=1) from exc
    except json.JSONDecodeError as exc:
        say_err(
            f"OpenAPI spec at {url} is not valid JSON: {exc}",
            hint="The server may be misconfigured — try a different --base-url.",
        )
        raise typer.Exit(code=1) from exc

    _spec_cache[base_url] = data
    return data


def _build_schema(components: dict, root: str) -> dict:
    """Extract ``root`` + transitive ``$ref`` closure as one JSON Schema document.

    Two transforms on the way out:

    1. **Flatten ``allOf`` inheritance.** OpenAPI emits each polymorphic
       variant as ``allOf: [{$ref: Parent}, {properties: …,
       additionalProperties: false}]``. Strict JSON Schema validators
       reject every concrete body for it: the parent branch rejects the
       variant's fields, and the variant branch rejects the parent's
       fields. Resolving the parent ref and merging the two objects into
       one flat schema makes each variant self-contained, so strict
       validation (``jsonschema.validate``) finally agrees with what the
       server actually accepts.
    2. **Rebase refs.** Every ``#/components/schemas/X`` becomes
       ``#/$defs/X`` (including bare-string refs inside
       ``discriminator.mapping``), so the document resolves against
       itself.
    """
    reachable: set[str] = set()
    stack = [root]
    while stack:
        name = stack.pop()
        if name in reachable or name not in components:
            continue
        reachable.add(name)
        for ref in _find_refs(components[name]):
            if ref not in reachable:
                stack.append(ref)

    defs = {
        name: _rewrite_refs(_flatten_allof(components[name], components, variant_name=name))
        for name in sorted(reachable)
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$ref": f"{_DEFS_PREFIX}{root}",
        "$defs": defs,
    }


def _flatten_allof(schema: object, components: dict, *, variant_name: str = "") -> object:
    """Collapse OpenAPI's ``allOf: [{$ref: Base}, {inline}]`` inheritance.

    Returns a new dict where the base's ``properties`` and ``required``
    are merged into the inline object — the inline object wins on key
    conflicts (a variant can override a base field). Carries through the
    base's ``discriminator`` so polymorphic dispatch still works.

    When the base carries a ``discriminator`` and we can recover this
    variant's discriminator value from the mapping, the merged schema
    pins the discriminator property to that value (``const``). Without
    this, a ``oneOf`` over flattened variants is ambiguous: a minimal
    body like ``{"type": "EXIT_POINT", "identifier": "x"}`` validates
    against every variant (none require their distinguishing fields), so
    ``oneOf`` reports "matches more than one." The ``const`` makes each
    variant accept only its own discriminator value, and ``oneOf``
    resolves cleanly.

    Untouched if the schema doesn't match the inheritance pattern.
    """
    if not isinstance(schema, dict):
        return schema
    all_of = schema.get("allOf")
    if not isinstance(all_of, list) or len(all_of) != 2:
        return schema
    base_ref = all_of[0].get("$ref") if isinstance(all_of[0], dict) else None
    if not (isinstance(base_ref, str) and base_ref.startswith(_REF_PREFIX)):
        return schema
    base_name = base_ref[len(_REF_PREFIX) :]
    base = components.get(base_name)
    inline = all_of[1]
    if not isinstance(base, dict) or not isinstance(inline, dict):
        return schema

    merged_props = {**(base.get("properties") or {}), **(inline.get("properties") or {})}
    merged_required = sorted(set((base.get("required") or []) + (inline.get("required") or [])))

    # Pin the discriminator property to this variant's key, so a `oneOf`
    # over the flattened variants picks exactly one match.
    discriminator = base.get("discriminator") or {}
    disc_prop = discriminator.get("propertyName")
    disc_value = _discriminator_value_for(discriminator.get("mapping") or {}, variant_name)
    if disc_prop and disc_value and disc_prop in merged_props:
        merged_props = {**merged_props, disc_prop: {**merged_props[disc_prop], "const": disc_value}}
    out: dict = {
        "type": "object",
        "properties": merged_props,
        # additionalProperties: take the stricter of the two (false if either
        # side says so). Variants are typically the strict ones.
        "additionalProperties": inline.get("additionalProperties", base.get("additionalProperties", True)),
    }
    if merged_required:
        out["required"] = merged_required
    if "discriminator" in base:
        out["discriminator"] = base["discriminator"]
    # Outer-schema description (the variant's own summary) wins; fall back
    # to the base's if the variant didn't add one.
    description = schema.get("description") or base.get("description")
    if description:
        out["description"] = description
    return out


def _discriminator_value_for(mapping: dict, variant_name: str) -> str | None:
    """Reverse-lookup the discriminator key that maps to ``variant_name``."""
    suffix = f"/{variant_name}"
    for key, target in mapping.items():
        if isinstance(target, str) and target.endswith(suffix):
            return key
    return None


def _find_refs(node: object) -> set[str]:
    """Every ``components/schemas`` ref reachable from a node, one level."""
    refs: set[str] = set()
    for match in re.finditer(re.escape(_REF_PREFIX) + r"([A-Za-z0-9_]+)", json.dumps(node)):
        refs.add(match.group(1))
    return refs


def _rewrite_refs(node: object) -> object:
    """Deep-copy ``node`` with every ``components/schemas`` path rebased to ``$defs``.

    Catches both ``$ref`` keys (the obvious case) and OpenAPI's
    ``discriminator.mapping`` values, which are bare path strings —
    not ``$ref`` objects — that would otherwise still point at the
    original document and fail to resolve inside our self-contained one.
    """
    if isinstance(node, dict):
        return {k: _rewrite_refs(v) for k, v in node.items()}
    if isinstance(node, list):
        return [_rewrite_refs(item) for item in node]
    if isinstance(node, str) and node.startswith(_REF_PREFIX):
        return _DEFS_PREFIX + node[len(_REF_PREFIX) :]
    return node
