"""``fruxon keys`` — manage scoped API keys from the terminal.

Closes the agentic loop: an LLM agent driving the CLI (Claude Code,
Cursor) can mint, list, rotate, and revoke its own credentials without
leaving the terminal. Mirrors the dashboard's scope vocabulary —
adding a scope on the backend immediately appears here too because
both consume ``GET /apiKeys/scopes``.

The "raw key shows once" pattern: ``create`` and ``rotate`` print the
secret to stdout exactly once, fenced with a warning. Any subsequent
command that returns key metadata renders only the displayable prefix
(``fx_live_aB3z…``) — the full secret is unrecoverable, by design.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.cli._shared import build_client
from fruxon.exceptions import FruxonError
from fruxon.fruxon import FruxonClient
from fruxon.ui import (
    print_banner,
    resolve_output_format,
    say_err,
    say_info,
    say_ok,
    stderr,
)

keys_app = typer.Typer(
    help="Mint, list, rotate, and revoke scoped API keys.",
    no_args_is_help=True,
)
app.add_typer(keys_app, name="keys")


# ─────────────────────────────────────────────────────────────────────────────
# list
# ─────────────────────────────────────────────────────────────────────────────


@keys_app.command("list")
def keys_list(
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one ID per line, pipe-safe)."
            ),
        ),
    ] = None,
):
    """List every API key in your org.

    Examples:
        fruxon keys list
        fruxon keys list --output json | jq '.[] | select(.isActive)'
        fruxon keys list --output id | xargs -n1 fruxon keys revoke
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output != "id":
            with stderr.status("[bold]Fetching API keys…[/bold]"):
                keys = client.list_api_keys()
        else:
            keys = client.list_api_keys()
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if not keys:
        if output == "json":
            print("[]")
            return
        if output == "id":
            return
        say_info(
            "No API keys yet.",
            hint="Mint one with [bold]fruxon keys create --name <name>[/bold].",
        )
        return

    if output == "id":
        for k in keys:
            kid = k.get("id")
            if kid:
                print(kid)
        return
    if output == "json":
        print(json.dumps(keys, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"keys · {len(keys)}")
    stderr.print()
    stderr.print(_build_keys_table(keys))


# ─────────────────────────────────────────────────────────────────────────────
# create
# ─────────────────────────────────────────────────────────────────────────────


@keys_app.command("create")
def keys_create(
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="Display name for the key (e.g. `ci-deploy`)."),
    ] = None,
    preset: Annotated[
        str | None,
        typer.Option(
            "--preset",
            "-p",
            help=(
                "Named preset (runner / builder / read-only / admin). "
                "Defaults to `runner` when omitted with no --scope."
            ),
        ),
    ] = None,
    scope: Annotated[
        list[str] | None,
        typer.Option("--scope", "-s", help="Add a scope explicitly. Repeatable. Combined with --preset."),
    ] = None,
    expires_in: Annotated[
        int | None,
        typer.Option(
            "--expires-in",
            help="Days until the key expires. Omit for the API default (90 days); pass 0 for never-expire.",
        ),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Mint a new API key.

    The full secret is printed to stdout ONCE — store it immediately
    or pipe it into a secrets manager. Subsequent commands only render
    the short prefix (`fx_live_aB3z…`).

    Examples:
        fruxon keys create --name ci-deploy --preset runner
        fruxon keys create --name laptop --scope agents:execute --scope traces:read
        fruxon keys create --name temp --preset runner --expires-in 7
    """
    if not name or not name.strip():
        say_err(
            "Missing required option [bold]--name[/bold].",
            hint="Pick a name that hints at where the key will live — e.g. `ci-deploy`, `claude-code-laptop`.",
        )
        raise typer.Exit(code=1)

    output = resolve_output_format(output, human_default="text", agent_default="json")
    body: dict[str, object] = {"name": name.strip()}
    if preset:
        body["preset"] = preset
    if scope:
        body["scopes"] = scope
    if expires_in is not None:
        # 0 maps to JSON null = "never expire" per the server contract.
        body["expirationDays"] = None if expires_in == 0 else expires_in

    client = build_client(org, base_url)
    try:
        result = client.generate_api_key(body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    _render_minted_key(result, output)


# ─────────────────────────────────────────────────────────────────────────────
# rotate
# ─────────────────────────────────────────────────────────────────────────────


@keys_app.command("rotate")
def keys_rotate(
    key_id: Annotated[str, typer.Argument(help="ID, prefix, or name of the key to rotate.")],
    preset: Annotated[
        str | None,
        typer.Option(
            "--preset",
            "-p",
            help="Optional new preset for the replacement. Omit to keep the original's scopes.",
        ),
    ] = None,
    scope: Annotated[
        list[str] | None,
        typer.Option(
            "--scope",
            "-s",
            help="Optional new scope (repeatable). Omit to keep the original's scopes.",
        ),
    ] = None,
    name: Annotated[
        str | None,
        typer.Option("--name", help="Optional new name for the replacement."),
    ] = None,
    expires_in: Annotated[
        int | None,
        typer.Option(
            "--expires-in",
            help=(
                "Optional new lifetime in days for the replacement. "
                "Omit to renew for the original window; 0 means never-expire."
            ),
        ),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Mint a replacement key and revoke the original in one call.

    With no overrides, the replacement inherits the original's name,
    scopes, type, and gets a renewed expiry. Pass `--preset`/`--scope`
    to narrow or widen permissions while you're at it — Stripe's
    rotate-and-narrow pattern.

    The full secret of the new key is printed to stdout ONCE.

    Examples:
        fruxon keys rotate <id>
        fruxon keys rotate <id> --preset runner
        fruxon keys rotate <id> --scope agents:execute --scope traces:read
        fruxon keys rotate <id> --expires-in 30
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    overrides: dict[str, object] = {}
    if preset:
        overrides["preset"] = preset
    if scope:
        overrides["scopes"] = scope
    if name:
        overrides["name"] = name
    if expires_in is not None:
        overrides["expirationDays"] = None if expires_in == 0 else expires_in

    client = build_client(org, base_url)
    key_id = _resolve_key_id(client, key_id)
    try:
        result = client.rotate_api_key(key_id, overrides or None)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    _render_minted_key(result, output, verb="Rotated")


# ─────────────────────────────────────────────────────────────────────────────
# revoke / delete
# ─────────────────────────────────────────────────────────────────────────────


@keys_app.command("revoke")
def keys_revoke(
    key_id: Annotated[str, typer.Argument(help="ID, prefix, or name of the key to revoke.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Revoke an API key by flipping it inactive.

    Reversible — the row stays in the keys table with `revokedAt`
    stamped, and the audit log records a REVOKED event. To bring it
    back, use the dashboard (PATCH with isActive=true).

    For irreversible removal, use [bold]fruxon keys delete[/bold].
    """
    client = build_client(org, base_url)
    key_id = _resolve_key_id(client, key_id)
    try:
        client.update_api_key(key_id, {"isActive": False})
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    say_ok(f"Revoked [bold]{key_id}[/bold] — requests using this key will start returning 401.")


@keys_app.command("delete")
def keys_delete(
    key_id: Annotated[str, typer.Argument(help="ID, prefix, or name of the key to delete.")],
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip the confirmation prompt."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Hard-delete an API key. Irreversible.

    For a reversible alternative, use [bold]fruxon keys revoke[/bold].
    The audit trail survives the delete because audit events have no
    foreign key to the keys table.
    """
    client = build_client(org, base_url)
    # Resolve BEFORE the confirmation prompt so the user sees the
    # resolved UUID in the prompt (helps spot "wait that's not the
    # one I meant" when matching by prefix or name).
    key_id = _resolve_key_id(client, key_id)
    if not yes:
        confirm = typer.confirm(
            f"Permanently delete API key {key_id}? (audit trail survives, but the row is gone)",
            default=False,
        )
        if not confirm:
            say_info("Cancelled.")
            raise typer.Exit(code=0)

    try:
        client.delete_api_key(key_id)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    say_ok(f"Deleted [bold]{key_id}[/bold].")


# ─────────────────────────────────────────────────────────────────────────────
# history
# ─────────────────────────────────────────────────────────────────────────────


@keys_app.command("history")
def keys_history(
    key_id: Annotated[str, typer.Argument(help="ID, prefix, or name of the key to fetch history for.")],
    limit: Annotated[int, typer.Option("--limit", help="Max events to return (newest-first).")] = 50,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Show the audit timeline for a key — minted / rotated / revoked / used-while-revoked."""
    output = resolve_output_format(output, human_default="text", agent_default="json")
    client = build_client(org, base_url)
    key_id = _resolve_key_id(client, key_id)
    try:
        events = client.list_api_key_audit_events(key_id, limit=limit)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(events, indent=2))
        return

    if not events:
        say_info(
            "No events for this key.",
            hint="The key hasn't been used or modified since it was minted.",
        )
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"history · {key_id} · {len(events)}")
    stderr.print()
    for event in events:
        _render_event_line(event)


# ─────────────────────────────────────────────────────────────────────────────
# scopes
# ─────────────────────────────────────────────────────────────────────────────


@keys_app.command("scopes")
def keys_scopes(
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: table (default for humans), json, id."),
    ] = None,
):
    """List every scope the server is willing to mint a key against.

    Same data the dashboard's mint dialog renders. Use `--output id` to
    pipe scope strings into `fruxon keys create --scope`.

    Examples:
        fruxon keys scopes
        fruxon keys scopes --output id | grep ^agents
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        body = client.list_api_key_scopes()
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    scopes = body.get("scopes") or []
    presets = body.get("presets") or []

    if output == "id":
        for s in scopes:
            sid = s.get("id") if isinstance(s, dict) else None
            if sid:
                print(sid)
        return
    if output == "json":
        print(json.dumps(body, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"scopes · {len(scopes)}  presets · {len(presets)}")
    stderr.print()
    stderr.print(_build_scopes_table(scopes))
    stderr.print()
    stderr.print(_build_presets_table(presets))


# ─────────────────────────────────────────────────────────────────────────────
# Renderers
# ─────────────────────────────────────────────────────────────────────────────


def _render_minted_key(result: dict, output: str, verb: str = "Created") -> None:
    """Print the one-time reveal of a freshly minted (or rotated) key."""
    if output == "json":
        print(json.dumps(result, indent=2))
        return

    raw_key = result.get("apiKey") or ""
    prefix = result.get("keyPrefix") or ""
    scopes = result.get("scopes") or []
    expires = result.get("expiresAt")
    name = result.get("name") or ""

    stderr.print()
    say_ok(f"{verb} key [bold]{name}[/bold]  ·  {prefix}…")
    stderr.print()
    stderr.print("[yellow]⚠[/yellow]  [bold]Copy this now — you won't see it again:[/bold]")
    # The raw key prints to stdout (not stderr) so `fruxon keys create
    # … > key.txt` works as expected. Everything else is chrome on
    # stderr.
    print(raw_key)
    stderr.print()
    if scopes:
        stderr.print(f"     [dim]Scopes ({len(scopes)}):[/dim] {', '.join(scopes)}")
    if expires:
        from datetime import datetime, timezone

        ts = datetime.fromtimestamp(expires / 1000, tz=timezone.utc)
        stderr.print(f"     [dim]Expires:[/dim] {ts.isoformat()}")
    else:
        stderr.print("     [dim]Expires:[/dim] never")


def _render_event_line(event: dict) -> None:
    """One line per audit event for the text-mode history output."""
    from datetime import datetime, timezone

    event_type = event.get("eventType") or "?"
    created = event.get("createdAt")
    actor = event.get("actor") or "(no actor)"
    details_raw = event.get("details")
    details = None
    if details_raw:
        try:
            details = json.loads(details_raw)
        except (json.JSONDecodeError, TypeError):
            details = None

    ts_str = ""
    if isinstance(created, (int, float)):
        ts = datetime.fromtimestamp(created / 1000, tz=timezone.utc)
        ts_str = ts.isoformat()

    color = {
        "MINTED": "green",
        "ROTATED": "cyan",
        "REVOKED": "yellow",
        "USED_WHILE_REVOKED": "red",
    }.get(event_type, "white")

    stderr.print(f"  [{color}]{event_type:<20}[/{color}] {ts_str}  ·  [dim]{actor}[/dim]")
    if isinstance(details, dict):
        if "scopes" in details and isinstance(details["scopes"], list):
            stderr.print(f"     [dim]scopes:[/dim] {', '.join(details['scopes'])}")
        if "replacementPrefix" in details:
            stderr.print(f"     [dim]→[/dim] {details['replacementPrefix']}…")
        if "reason" in details:
            stderr.print(f"     [dim]reason:[/dim] {details['reason']}")
        if "remoteIp" in details:
            stderr.print(f"     [dim]from:[/dim] {details['remoteIp']}")


def _build_keys_table(keys: list[dict]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=24)
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=18)
    table.add_column("Prefix", style="dim", no_wrap=True)
    table.add_column("Active", no_wrap=True)
    table.add_column("Scopes", style="dim", overflow="ellipsis", max_width=28)
    table.add_column("Last used", style="dim", no_wrap=True)
    for k in keys:
        scopes = k.get("scopes") or []
        scopes_str = f"{len(scopes)} scope{'s' if len(scopes) != 1 else ''}" if scopes else "—"
        active = "[green]yes[/green]" if k.get("isActive") else "[dim]no[/dim]"
        table.add_row(
            str(k.get("id") or ""),
            str(k.get("name") or ""),
            str(k.get("keyPrefix") or ""),
            active,
            scopes_str,
            _ago(k.get("lastUsedAt")),
        )
    return table


def _build_scopes_table(scopes: list[dict]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("Scope", style="bold", no_wrap=True, max_width=28)
    table.add_column("Resource", no_wrap=True, style="dim", max_width=16)
    table.add_column("Action", no_wrap=True, style="dim")
    table.add_column("Label", no_wrap=True, max_width=24)
    table.add_column("Helper", overflow="ellipsis", style="dim", max_width=40)
    for s in scopes:
        if not isinstance(s, dict):
            continue
        table.add_row(
            str(s.get("id") or ""),
            str(s.get("resource") or ""),
            str(s.get("action") or ""),
            str(s.get("label") or ""),
            str(s.get("helper") or ""),
        )
    return table


def _build_presets_table(presets: list[dict]):
    from rich.table import Table

    table = Table(
        title="Presets",
        title_justify="left",
        show_header=True,
        header_style="bold",
        show_edge=False,
        pad_edge=False,
        box=None,
        padding=(0, 1),
    )
    table.add_column("ID", style="bold", no_wrap=True, max_width=12)
    table.add_column("Label", no_wrap=True, max_width=14)
    table.add_column("Tagline", style="dim", no_wrap=True, max_width=28)
    table.add_column("Scopes", style="dim", no_wrap=True)
    for p in presets:
        if not isinstance(p, dict):
            continue
        count = len(p.get("scopes") or [])
        table.add_row(
            str(p.get("id") or ""),
            str(p.get("label") or ""),
            str(p.get("tagline") or ""),
            f"{count} scope{'s' if count != 1 else ''}",
        )
    return table


def _ago(ts_ms: int | None) -> str:
    """Tiny relative-time formatter — keeps the keys-list table self-contained."""
    if not ts_ms:
        return "never"
    from datetime import datetime, timezone

    try:
        delta = datetime.now(tz=timezone.utc) - datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
    except (TypeError, ValueError, OSError):
        return "—"
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    return f"{seconds // 86400}d ago"


def _resolve_key_id(client: FruxonClient, term: str) -> str:
    """Resolve a user-supplied id / prefix / name to a concrete key id.

    UUID-shaped input is returned as-is (fast path — no extra
    round-trip). Otherwise the function fetches the keys list and
    looks for exactly one match against ``keyPrefix`` (prefix
    matching, so ``fx_live_aB3z`` matches the row whose stored
    prefix is ``fx_live_aB3z…``) or ``name`` (exact match — names
    can collide but should be unique within a tenant by convention).

    Exits with a pointed error when the term matches zero or more
    than one key, naming the offenders so the user can pick a more
    specific term.
    """
    if _looks_like_uuid(term):
        return term
    try:
        all_keys = client.list_api_keys()
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    matches = [
        k
        for k in all_keys
        if str(k.get("keyPrefix") or "") == term
        or (k.get("keyPrefix") and term.startswith(str(k["keyPrefix"])))
        or str(k.get("name") or "") == term
    ]
    if len(matches) == 1:
        return str(matches[0]["id"])
    if not matches:
        say_err(
            f"No API key matches [bold]{term}[/bold].",
            hint="Run [bold]fruxon keys list[/bold] to see what's there.",
        )
        raise typer.Exit(code=1)
    options = ", ".join(f"{m.get('name')} ({m.get('keyPrefix')})" for m in matches[:5])
    say_err(
        f"[bold]{term}[/bold] matches {len(matches)} keys: {options}",
        hint="Use the full id (UUID) to disambiguate.",
    )
    raise typer.Exit(code=1)


def _looks_like_uuid(term: str) -> bool:
    """Quick UUID sniff — 8-4-4-4-12 with dashes, or 32 hex chars without.

    Avoids importing :mod:`uuid` for what's a one-line shape check,
    and tolerates the no-dashes form some Fruxon paths use.
    """
    cleaned = term.replace("-", "")
    return len(cleaned) == 32 and all(c in "0123456789abcdefABCDEF" for c in cleaned)


def _hint_for_error(error: FruxonError) -> str | None:
    """Tailored hints for CLI errors. Insufficient-scope renders the structured fix."""
    from fruxon.exceptions import (
        AuthenticationError,
        ForbiddenError,
        InsufficientScopeError,
        NotFoundError,
    )

    if isinstance(error, InsufficientScopeError):
        # The whole point of the typed 403: render the missing scope
        # and the granted set so the user knows exactly what to mint
        # next. This is the most-leveraged error message we ship.
        granted_str = ", ".join(error.granted) if error.granted else "(none)"
        return (
            f"This key can't [bold]{error.required}[/bold]. Granted: [dim]{granted_str}[/dim]\n"
            f"Mint: [bold]fruxon keys create --scope {error.required}[/bold] (or pick a preset that includes it)."
        )
    if isinstance(error, AuthenticationError):
        return "Run [bold]fruxon whoami[/bold] to confirm your key, then [bold]fruxon login[/bold] to refresh."
    if isinstance(error, ForbiddenError):
        return "Your key doesn't grant access to this resource. Confirm with [bold]fruxon whoami[/bold]."
    if isinstance(error, NotFoundError):
        return "Run [bold]fruxon keys list[/bold] to find the right id."
    return None


# Suppress unused-import warnings.
_ = FruxonClient
