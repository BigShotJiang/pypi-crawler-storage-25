"""``fruxon login`` / ``fruxon whoami`` / ``fruxon logout``.

These three commands manage the persistent credentials file under
``~/.fruxon/credentials``. Login is the new-user happy path; whoami is the
"is this set up correctly?" surface; logout is the explicit teardown.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Annotated

import typer

from fruxon import credentials
from fruxon.cli import app
from fruxon.credentials import StoredCredentials
from fruxon.fruxon import FruxonClient
from fruxon.ui import (
    open_browser,
    print_banner,
    redact_key,
    resolve_output_format,
    say_err,
    say_info,
    say_ok,
    say_warn,
    stderr,
)


@app.command()
def login(
    org: Annotated[
        str | None,
        typer.Option(
            "--org",
            help="Default organization to store. Optional — you can also pass --org per command.",
        ),
    ] = None,
    api_key: Annotated[
        str | None,
        typer.Option(
            "--api-key",
            "-k",
            help="Provide the key non-interactively (for scripts). Skips the browser flow.",
        ),
    ] = None,
    base_url: Annotated[
        str | None,
        typer.Option(
            "--base-url",
            help="Override the API base URL (e.g. for staging or self-hosted). Stored across runs.",
        ),
    ] = None,
    no_browser: Annotated[
        bool,
        typer.Option(
            "--no-browser",
            help="Don't try to open the dashboard in a browser. Print the URL for you to open manually.",
        ),
    ] = False,
):
    """Sign in to Fruxon.

    Default flow: opens the dashboard in your browser, you confirm the
    sign-in, the CLI receives a freshly-minted API key, and stores it
    in your OS keychain (Keychain on macOS, libsecret on Linux,
    Credential Manager on Windows). Same pattern Stripe CLI and
    Supabase CLI use — no paste-the-key dance.

    Headless / CI: pass ``--api-key`` to skip the browser entirely.
    Useful in containers, GitHub Actions, etc. — the key gets stored
    the same way, and subsequent commands work identically.

    Examples:
        fruxon login                                         # browser flow
        fruxon login --org acme-corp                         # browser + lock to this org
        fruxon login --api-key fxn_... --org acme-corp       # non-interactive
        fruxon login --base-url https://staging.fruxon.com   # staging
    """
    if stderr.is_terminal:
        print_banner(subtitle="sign in")

    existing = credentials.load()
    if existing.api_key:
        # Surface what's already stored so the user can decide whether to
        # overwrite. Losing a key they can't easily regenerate would be a
        # bad surprise.
        stderr.print()
        say_info(
            "An API key is already stored.",
            hint=(f"[bold]{redact_key(existing.api_key)}[/bold] · org [bold]{existing.org or '—'}[/bold]"),
        )
        # Auto-confirm when --api-key was supplied (scripted callers
        # want the replace to just happen).
        if not api_key:
            keep = typer.confirm("    Replace it?", default=False)
            if not keep:
                say_info("Keeping existing credentials. Nothing changed.")
                raise typer.Exit()

    # Resolve the API key. Two paths:
    #   * ``--api-key`` supplied → headless, skip browser flow entirely.
    #   * No ``--api-key`` → browser flow via :func:`_browser_login`.
    slug_from_grant: str | None = None
    if api_key is None:
        api_key, slug_from_grant = _browser_login(
            no_browser=no_browser,
            override_base_url=base_url or existing.base_url,
        )

    # Preserve previously-stored values when the user didn't change them
    # on this invocation. Lets ``fruxon login`` later refresh just the key
    # without forgetting the org. The browser flow returns the tenant
    # slug (what API routes resolve by); explicit --org still wins.
    new_creds = StoredCredentials(
        api_key=api_key,
        org=org or slug_from_grant or existing.org,
        base_url=base_url or existing.base_url,
    )
    path = credentials.save(new_creds)

    stderr.print()
    say_ok(
        f"Signed in · key [bold]{redact_key(new_creds.api_key or '')}[/bold]",
        hint=_storage_hint(path),
    )
    if new_creds.org:
        say_ok(f"Organization [bold]{new_creds.org}[/bold]")
    else:
        say_warn(
            "No default org stored.",
            hint="Rerun [bold]fruxon login --org <id>[/bold] or pass --org per command.",
        )
    if new_creds.base_url:
        say_ok(f"Base URL [bold]{new_creds.base_url}[/bold]")

    stderr.print()
    stderr.print("    Next: [bold]fruxon run[/bold] <agent>")


def _browser_login(
    *,
    no_browser: bool,
    override_base_url: str | None,
) -> tuple[str, str | None]:
    """Run the Stripe-style browser-poll flow. Returns ``(api_key, tenant_slug?)``.

    Shape of the flow:
      1. POST ``/v1/cliAuth:start`` — get a grant code + verification URL.
      2. Open the URL in the user's browser (or print it for them).
      3. Poll ``GET /v1/cliAuth/{code}`` every ``poll_interval_seconds``
         until approved, expired, or the local timeout fires.
      4. On approval, the response body carries the minted API key +
         tenant context the dashboard picked.

    The second tuple element is the tenant *slug* — the identifier the
    caller stores as ``org``. API routes resolve ``{tenant}`` by slug,
    so the opaque tenant Guid would 404 if stored instead.

    Errors surface as branded ``✗`` lines on stderr and exit 1.
    """
    import time

    from fruxon import cli_auth

    # API base URL the SDK should talk to. Same precedence the rest of
    # the CLI uses (override > stored > default).
    resolved_base = override_base_url or FruxonClient.DEFAULT_BASE_URL

    # 1) Kick off the grant.
    try:
        grant = cli_auth.start_grant(resolved_base)
    except Exception as exc:  # noqa: BLE001 — surface anything here as a clean error
        say_err(
            f"Couldn't start the browser sign-in: {exc}",
            hint="Pass [bold]--api-key[/bold] for the headless flow, or check your network.",
        )
        raise typer.Exit(code=1) from exc

    stderr.print()
    code_fingerprint = f"{grant.grant_code[:4]}…{grant.grant_code[-4:]}"
    say_info(
        f"Opening [link={grant.verification_url}]{grant.verification_url}[/link]",
        hint=f"Verify the code in the browser matches: [bold]{code_fingerprint}[/bold]",
    )
    if not no_browser:
        open_browser(grant.verification_url)

    # 2) Poll until approved / expired / timeout. Total wall-clock cap
    #    comes from the server's stated TTL plus a small slack for
    #    network jitter on the final poll.
    deadline = time.monotonic() + grant.expires_in_seconds + 5
    interval = max(1, grant.poll_interval_seconds)

    stderr.print()
    spinner = stderr.status("[bold]Waiting for browser confirmation…[/bold]") if stderr.is_terminal else None
    if spinner:
        spinner.__enter__()
    try:
        while True:
            if time.monotonic() >= deadline:
                say_err(
                    "Timed out waiting for browser confirmation.",
                    hint="Re-run [bold]fruxon login[/bold] to start over.",
                )
                raise typer.Exit(code=1)

            try:
                result = cli_auth.poll_grant(resolved_base, grant.grant_code)
            except Exception as exc:  # noqa: BLE001 — handled below; rare in practice
                say_err(
                    f"Poll failed: {exc}",
                    hint="Network issue? Re-run [bold]fruxon login[/bold].",
                )
                raise typer.Exit(code=1) from exc

            if isinstance(result, cli_auth.PollApproved):
                return result.api_key, result.tenant_slug
            if isinstance(result, cli_auth.PollExpired):
                say_err(
                    "Sign-in expired before it was approved.",
                    hint="Re-run [bold]fruxon login[/bold] to start over.",
                )
                raise typer.Exit(code=1)
            # PollPending — keep waiting.
            time.sleep(interval)
    finally:
        if spinner:
            spinner.__exit__(None, None, None)


def _storage_hint(path) -> str:
    """Show where the key landed so users know which store they're in.

    Two possible states: ``keyring + ~/.fruxon/credentials (config only)``
    when the OS keychain accepted the secret, or just ``~/.fruxon/credentials``
    when we fell back to the file. Disambiguating matters for users on
    locked-down hosts and for ``fruxon doctor`` to diagnose stale keys.
    """
    if credentials.keyring_is_active():
        return f"OS keychain + [dim]{path}[/dim] (config only)"
    return str(path)


def _fetch_current_key_safely(api_key: str | None, org: str | None, base_url: str | None) -> dict | None:
    """Best-effort call to ``/apiKeys/current`` for whoami enrichment.

    Returns the key's metadata dict on success, ``None`` on any
    failure — missing creds, network error, federation/JWT auth (no
    API key in scope), or anything else. Whoami's job is to answer
    "am I signed in?" with local state; this just decorates the
    answer with what the key can do when we can reach the server.
    """
    if not api_key or not org:
        return None
    try:
        client = FruxonClient(
            api_key=api_key,
            org=org,
            base_url=base_url or FruxonClient.DEFAULT_BASE_URL,
        )
        return client.get_current_api_key()
    except Exception:
        return None


@app.command()
def whoami(
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: text (default for humans), json (machines, default in "
                "agent mode). Under FRUXON_AGENT_MODE / CLAUDECODE / CI the implicit "
                "default flips to json."
            ),
        ),
    ] = None,
):
    """Show the active sign-in state and where each value came from.

    Useful when something feels "off" — different org than expected,
    wrong env var bleeding in, a stale credentials file. Every value
    surfaces its source (flag / env / file / default) so you can chase
    the right place to fix it.
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint="Valid formats: text, json.",
        )
        raise typer.Exit(code=1)

    file_creds = credentials.load()
    api_key = credentials.resolve_api_key(None)
    org = credentials.resolve_org(None)
    base_url = credentials.resolve_base_url(None) or FruxonClient.DEFAULT_BASE_URL

    # Make a best-effort call to /apiKeys/current to surface scopes
    # alongside the local credential state. Treated as enrichment, not
    # core whoami data: a network failure here shouldn't break the
    # ability to ask "am I signed in?". The CLI's primary identity
    # check stays local-only; this just enriches it.
    current_key = _fetch_current_key_safely(api_key, org, base_url)

    if output == "json":
        # Structured shape an agent can branch on without parsing text.
        # Redacted key only — never the raw secret, even when an agent
        # is consuming the output.
        payload = {
            "signed_in": bool(api_key),
            "api_key_redacted": redact_key(api_key) if api_key else None,
            "api_key_source": _source_label("FRUXON_API_KEY", api_key, file_creds.api_key) if api_key else None,
            "org": org,
            "org_source": _source_label("FRUXON_ORG", org, file_creds.org) if org else None,
            "base_url": base_url,
            "base_url_source": _source_label("FRUXON_BASE_URL", base_url, file_creds.base_url),
            "current_key": (
                {
                    "name": current_key.get("name"),
                    "keyPrefix": current_key.get("keyPrefix"),
                    "scopes": current_key.get("scopes") or [],
                    "isActive": current_key.get("isActive"),
                    "expiresAt": current_key.get("expiresAt"),
                    "lastUsedAt": current_key.get("lastUsedAt"),
                }
                if current_key
                else None
            ),
        }
        sys.stdout.write(json.dumps(payload) + "\n")
        sys.stdout.flush()
        return

    if stderr.is_terminal:
        print_banner(subtitle="whoami")

    stderr.print()
    if not api_key:
        say_warn(
            "Not signed in.",
            hint="Run [bold]fruxon login[/bold] to store credentials.",
        )
        return

    say_ok(
        f"API key [bold]{redact_key(api_key)}[/bold]",
        hint=f"from {_source_label('FRUXON_API_KEY', api_key, file_creds.api_key)}",
    )
    if org:
        say_ok(
            f"Organization [bold]{org}[/bold]",
            hint=f"from {_source_label('FRUXON_ORG', org, file_creds.org)}",
        )
    else:
        say_warn(
            "No default org.",
            hint="Pass [bold]--org[/bold] per command, or store one with [bold]fruxon login --org <id>[/bold].",
        )
    say_ok(
        f"Base URL [bold]{base_url}[/bold]",
        hint=f"from {_source_label('FRUXON_BASE_URL', base_url, file_creds.base_url)}",
    )

    # If we successfully called /current, render the key's name +
    # scope count. Full scope list is one extra line so it doesn't
    # bury the credential info above. Omitting on failure keeps
    # whoami useful when the network is unreachable.
    if current_key:
        name = current_key.get("name") or "(unnamed)"
        scopes = current_key.get("scopes") or []
        scope_count = len(scopes)
        say_ok(
            f"Key [bold]{name}[/bold] · {scope_count} scope{'s' if scope_count != 1 else ''}",
            hint=", ".join(scopes) if scopes else "no scopes (key is dead weight)",
        )


def _source_label(env_name: str, active: str | None, from_file: str | None) -> str:
    """Tell the user where a resolved value came from.

    Mirrors the precedence order in :mod:`fruxon.credentials`: env vars
    shadow the file, and the file is the documented persistent source.
    """
    if active is None:
        return "default"
    if os.environ.get(env_name) == active:
        return f"env var [bold]${env_name}[/bold]"
    if from_file == active:
        return "credentials file"
    return "default"


@app.command()
def logout():
    """Forget the stored API key, org, and base URL.

    Removes ``~/.fruxon/credentials``. Environment variables and per-command
    flags continue to work as before — this only clears the file-stored
    fallback.
    """
    if stderr.is_terminal:
        print_banner(subtitle="sign out")

    stderr.print()
    existing = credentials.load()
    if not existing.api_key and not existing.org and not existing.base_url:
        say_info("No stored credentials to remove.")
        return

    # Show what we're about to remove. Each call to say_ok confirms the
    # field that was actually cleared, so the user sees a per-field
    # checklist rather than a single "did stuff" line.
    credentials.clear()
    if existing.api_key:
        say_ok(f"Forgot API key [bold]{redact_key(existing.api_key)}[/bold]")
    if existing.org:
        say_ok(f"Forgot org [bold]{existing.org}[/bold]")
    if existing.base_url:
        say_ok(f"Forgot base URL [bold]{existing.base_url}[/bold]")
