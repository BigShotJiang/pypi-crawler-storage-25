"""``fruxon tools`` — manage the tools inside an integration.

A *tool* is a single callable capability an agent can invoke — an HTTP
endpoint, a Python script. Tools are always integration-scoped: the
``(integration, tool)`` pair is the composite key, so every command here
takes the integration as its required first positional argument. That's
deliberate — the CLI's primary consumer is Claude Code, and an explicit
positional is clearer and less error-prone for an LLM than a hidden
"current integration" context.

Read commands (``list`` / ``get``) take simple flags; write commands
(``create`` / ``update`` / ``test``) take a ``--file`` JSON body, because
the payloads (``CreateToolRequest``, ``Tool``, ``ToolTestRequest``) carry
structured ``descriptor`` / ``parametersMetadata`` objects. ``delete``
needs no body.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.cli._shared import build_client, load_json_body
from fruxon.exceptions import FruxonError
from fruxon.fruxon import Tool
from fruxon.ui import print_banner, resolve_output_format, say_err, say_info, say_ok, stderr

tools_app = typer.Typer(
    help="Manage the tools inside an integration.",
    no_args_is_help=True,
)
app.add_typer(tools_app, name="tools")


# ─────────────────────────────────────────────────────────────────────────────
# list / get
# ─────────────────────────────────────────────────────────────────────────────


@tools_app.command("list")
def tools_list(
    integration: Annotated[str, typer.Argument(help="Integration the tools belong to.")],
    type_: Annotated[
        list[str] | None,
        typer.Option("--type", help="Filter by tool type. Repeatable."),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one ID per line, pipe-safe)."
            ),
        ),
    ] = None,
):
    """List the tools registered under an integration.

    Examples:
        fruxon tools list github
        fruxon tools list github --type API
        fruxon tools list github --output id
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output != "id":
            with stderr.status(f"[bold]Fetching tools for [cyan]{integration}[/cyan]…[/bold]"):
                tools = client.list_tools(integration, types=type_)
        else:
            tools = client.list_tools(integration, types=type_)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if not tools:
        if output == "json":
            print("[]")
            return
        if output == "id":
            return
        say_info(
            f"No tools under [bold]{integration}[/bold] yet.",
            hint=f"Create one with [bold]fruxon tools create {integration} --file <tool.json>[/bold].",
        )
        return

    if output == "id":
        for t in tools:
            print(t.id)
        return
    if output == "json":
        print(json.dumps([_to_dict(t) for t in tools], indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"tools · {integration} · {len(tools)}")
    stderr.print()
    stderr.print(_build_table(tools))


@tools_app.command("get")
def tools_get(
    integration: Annotated[str, typer.Argument(help="Integration the tool belongs to.")],
    tool: Annotated[str, typer.Argument(help="Tool identifier to fetch.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Show one tool's details.

    Examples:
        fruxon tools get github list_commits
        fruxon tools get github list_commits --output json
    """
    output = _resolve_text_json(output)
    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output == "text":
            with stderr.status(f"[bold]Fetching [cyan]{tool}[/cyan]…[/bold]"):
                fetched = client.get_tool(integration, tool)
        else:
            fetched = client.get_tool(integration, tool)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(_to_dict(fetched), indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"tool · {fetched.id}")
    stderr.print()
    say_ok(f"[bold]{fetched.display_name or fetched.id}[/bold]")
    if fetched.description:
        stderr.print(f"     [dim]{fetched.description}[/dim]")
    stderr.print()
    _say_kv("id", fetched.id)
    _say_kv("integration", fetched.integration_id)
    _say_kv("type", fetched.tool_type or "[dim]—[/dim]")
    _say_kv("action", fetched.action_type or "[dim]—[/dim]")


# ─────────────────────────────────────────────────────────────────────────────
# create / update / delete
# ─────────────────────────────────────────────────────────────────────────────


@tools_app.command("create")
def tools_create(
    integration: Annotated[str, typer.Argument(help="Integration to create the tool under.")],
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="CreateToolRequest JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (CreateToolRequest) and exit."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Create a tool under an integration from a JSON definition file.

    `--file` is a CreateToolRequest body: `id`, `integrationId`,
    `description`, `descriptor` (the actual tool definition), and
    `parametersMetadata`. Pass `--schema` to print the request body's
    JSON schema instead of making a request.

    `descriptor` is a discriminated union — pick exactly one variant:
        apiTool    — HTTP endpoint (method, url, headers, response mapping).
        codeTool   — Python source (function called with the tool's params).
        mcpTool    — backed by an MCP server.
    Run `--schema` for the exact shape of each variant.

    Examples:
        fruxon tools create github --file ./list_commits.json
        cat tool.json | fruxon tools create github --file -
        fruxon tools create github --schema > schema.json

    Procedural guides:
        fruxon skills show fruxon-create-integration   # bootstrap from scratch
        fruxon skills show fruxon-use-integrations     # wire into an agent step
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("CreateToolRequest", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = _resolve_text_json(output)
    body = load_json_body(file, what="a CreateToolRequest object (id, integrationId, descriptor, …)")
    client = build_client(org, base_url)
    try:
        result = client.create_tool(integration, body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    _render_write_result(result, output, integration=integration, verb="Created")


@tools_app.command("update")
def tools_update(
    integration: Annotated[str, typer.Argument(help="Integration the tool belongs to.")],
    tool: Annotated[str, typer.Argument(help="Tool identifier to update.")],
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="Tool JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (Tool) and exit."),
    ] = False,
    python: Annotated[
        bool,
        typer.Option("--python", help="The tool is a Python-script tool (uses the :python update route)."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Update a tool from a JSON definition file.

    This is a wholesale replace, not a patch — any field omitted from the
    body is reset. Pass `--python` for Python-script tools; the backend
    routes those through a separate endpoint.

    Examples:
        fruxon tools update github list_commits --file ./list_commits.json
        fruxon tools update github run_report --python --file ./run_report.json
        fruxon tools update github list_commits --schema > schema.json
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("Tool", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = _resolve_text_json(output)
    body = load_json_body(file, what="a Tool object")
    client = build_client(org, base_url)
    try:
        result = client.update_tool(integration, tool, body, python=python)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    _render_write_result(result, output, integration=integration, verb="Updated")


@tools_app.command("delete")
def tools_delete(
    integration: Annotated[str, typer.Argument(help="Integration the tool belongs to.")],
    tool: Annotated[str, typer.Argument(help="Tool identifier to delete.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Delete a tool.

    Hard-deletes the tool definition. Agents that still reference it by
    ID will fail at execution — the delete doesn't cascade.

    Examples:
        fruxon tools delete github list_commits
    """
    client = build_client(org, base_url)
    try:
        client.delete_tool(integration, tool)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    if stderr.is_terminal:
        stderr.print()
    say_ok(f"Deleted tool [bold]{tool}[/bold] from [bold]{integration}[/bold]")


# ─────────────────────────────────────────────────────────────────────────────
# test
# ─────────────────────────────────────────────────────────────────────────────


@tools_app.command("test")
def tools_test(
    integration: Annotated[str, typer.Argument(help="Integration the tool belongs to.")],
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="ToolTestRequest JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (ToolTestRequest) and exit."),
    ] = False,
    param: Annotated[
        list[str] | None,
        typer.Option(
            "--param",
            "-p",
            help=(
                "Runtime parameter — `key=value` (string) or `key:=42` (typed JSON). "
                "Repeatable. Overlays the file's parameters."
            ),
        ),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Test-run a tool with sample parameters — before wiring it into an agent.

    `--file` is a ToolTestRequest body: the `descriptor`,
    `parametersMetadata`, `config`/`configMetadata`, and `parameters`.
    `-p key=value` overlays runtime parameters onto the file's, so the
    file can hold the tool's *shape* and `-p` the inputs for this run.

    Examples:
        fruxon tools test github --file ./list_commits-test.json
        fruxon tools test github --file ./tool.json -p repo=fruxon-sdk
        fruxon tools test github --schema > schema.json
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("ToolTestRequest", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = _resolve_text_json(output)
    body = load_json_body(file, what="a ToolTestRequest object (descriptor, parametersMetadata, config, …)")

    from fruxon.params import ParamError
    from fruxon.params import parse as parse_params

    try:
        flag_params = parse_params(flag_values=param, params_file=None, stdin_input=False)
    except ParamError as exc:
        say_err(str(exc), hint="Run [bold]fruxon tools test --help[/bold] for accepted parameter forms.")
        raise typer.Exit(code=1) from exc
    if flag_params:
        merged = dict(body.get("parameters") or {})
        merged.update(flag_params)
        body["parameters"] = merged

    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output == "text":
            with stderr.status(f"[bold]Testing tool against [cyan]{integration}[/cyan]…[/bold]"):
                result = client.test_tool(integration, body)
        else:
            result = client.test_tool(integration, body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(result, indent=2))
        return

    response = result.get("response")
    if stderr.is_terminal:
        print_banner(subtitle=f"tool test · {integration}")
        stderr.print()
        say_ok("Tool ran")
    # The tool's response is the primary result — it goes to stdout so it
    # stays pipe-safe (`fruxon tools test … > out.txt`).
    print(response if response is not None else "")


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _resolve_text_json(output: str | None) -> str:
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: text, json.")
        raise typer.Exit(code=1)
    return output


def _render_write_result(result: Tool, output: str, *, integration: str, verb: str) -> None:
    if output == "json":
        print(json.dumps(_to_dict(result), indent=2))
        return
    if stderr.is_terminal:
        print_banner(subtitle=f"tool · {result.id}")
    stderr.print()
    say_ok(f"{verb} tool [bold]{result.id}[/bold] under [bold]{integration}[/bold]")
    stderr.print(f"     [dim]Try it:[/dim] fruxon tools test [bold]{integration}[/bold] --file <tool-test.json>")


def _build_table(tools: list[Tool]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=28)
    table.add_column("Type", no_wrap=True)
    table.add_column("Action", no_wrap=True, style="dim")
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=24)
    for t in tools:
        table.add_row(
            t.id,
            t.tool_type or "[dim]—[/dim]",
            t.action_type or "[dim]—[/dim]",
            t.display_name or "",
        )
    return table


def _to_dict(t: Tool) -> dict:
    """Serialize for ``--output json`` — camelCase to match the API payload."""
    return {
        "id": t.id,
        "integrationId": t.integration_id,
        "displayName": t.display_name,
        "description": t.description,
        "toolType": t.tool_type,
        "actionType": t.action_type,
    }


def _say_kv(key: str, value: str) -> None:
    stderr.print(f"     [dim]{key:<12}[/dim] {value}")


def _hint_for_error(error: FruxonError) -> str | None:
    from fruxon.exceptions import AuthenticationError, ForbiddenError, NotFoundError

    if isinstance(error, AuthenticationError):
        return "Run [bold]fruxon whoami[/bold] to confirm your key, then [bold]fruxon login[/bold] to refresh."
    if isinstance(error, ForbiddenError):
        return "Your key doesn't grant access to this resource. Confirm with [bold]fruxon whoami[/bold]."
    if isinstance(error, NotFoundError):
        return "Double-check the integration and tool IDs — [bold]fruxon tools list <integration>[/bold]."
    return None
