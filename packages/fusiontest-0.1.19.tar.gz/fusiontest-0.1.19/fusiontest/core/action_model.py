"""
fusiontest/core/action_model.py

The FusionTest action model: given a screen state + test goal,
returns a ranked list of UI actions to take next.

Supports two backends:
  1. Fine-tuned MPNet (production) — fast, cheap, deterministic
  2. GPT-4o / Claude API (MVP / fallback) — zero fine-tuning needed

The model is framed as a retrieval/ranking problem:
  - Embed the screen state + goal
  - Rank candidate actions by cosine similarity
  - Return top-N actions with confidence scores
"""

from __future__ import annotations

import json
import logging
import os
import random
import time
from dataclasses import dataclass
from typing import Any, Literal

from fusiontest.core.tokens import TokenUsage

logger = logging.getLogger("fusiontest.action_model")

# ── Transient-error classification (provider-agnostic) ────────────────────────


_RATE_LIMIT_TOKENS = (
    "rate limit", "too many requests", "quota", "exhausted", "429",
)
_TRANSIENT_TOKENS = (
    *_RATE_LIMIT_TOKENS,
    "timeout", "timed out", "overloaded", "temporarily unavailable",
    "service unavailable", "connection reset", "bad gateway",
)
_TRANSIENT_STATUS_CODES = {408, 429, 500, 502, 503, 504}
_TRANSIENT_SDK_CLASS_NAMES = {
    # OpenAI SDK (also used by Groq + Ollama via base_url)
    "RateLimitError", "APIConnectionError", "APITimeoutError",
    "InternalServerError", "APIError",
    # Anthropic
    "OverloadedError",
    # Google genai
    "ResourceExhausted", "DeadlineExceeded", "ServiceUnavailable",
}


def _error_status_code(err: Exception) -> int | None:
    """Best-effort extraction of an HTTP status from heterogeneous SDK errors."""
    for attr in ("status_code", "code", "http_status"):
        val = getattr(err, attr, None)
        if isinstance(val, int):
            return val
    # httpx-style: err.response.status_code
    resp = getattr(err, "response", None)
    if resp is not None:
        status = getattr(resp, "status_code", None)
        if isinstance(status, int):
            return status
    return None


def _is_rate_limit(err: Exception) -> bool:
    if err.__class__.__name__ == "RateLimitError":
        return True
    if _error_status_code(err) == 429:
        return True
    msg = str(err).lower()
    return any(tok in msg for tok in _RATE_LIMIT_TOKENS)


def _is_transient_error(err: Exception) -> bool:
    """True if an error is worth falling through to the next backend."""
    if err.__class__.__name__ in _TRANSIENT_SDK_CLASS_NAMES:
        return True
    if _error_status_code(err) in _TRANSIENT_STATUS_CODES:
        return True
    msg = str(err).lower()
    return any(tok in msg for tok in _TRANSIENT_TOKENS)


@dataclass
class Action:
    """A proposed UI action returned by the model."""
    action_type: str          # tap, type, swipe, scroll, back, home, wait
    element_index: int | None # index in the parsed UIElement list
    element_label: str        # human-readable label for logging
    value: str = ""           # text to type, or swipe direction
    confidence: float = 1.0
    reasoning: str = ""       # model's explanation (from LLM backend)

    def __str__(self) -> str:
        base = f"{self.action_type}"
        if self.element_label:
            base += f' on "{self.element_label}"'
        if self.value:
            base += f' → "{self.value}"'
        return f"{base} (conf={self.confidence:.2f})"


ActionBackend = Literal["mpnet", "gpt4o", "claude", "gemini", "ollama", "groq"]

# ── Gemini model auto-detection ───────────────────────────────────────────────

_gemini_model_cache: str | None = None
_GEMINI_PREFERRED = ["flash", "pro"]        # tier preference, newest date wins


def _resolve_gemini_model(genai_module) -> str:
    """Return the best available Gemini model for this API key (cached).

    Preference: newest flash > older flash > newest pro > older pro.
    Sort is DESCENDING by name so '2.5' beats '2.0' beats '1.5'.
    """
    global _gemini_model_cache  # noqa: PLW0603
    if _gemini_model_cache is not None:
        return _gemini_model_cache

    try:
        all_models = [
            m.name.replace("models/", "")
            for m in genai_module.list_models()
            if "generateContent" in (m.supported_generation_methods or [])
            and any(t in m.name.lower() for t in ("flash", "pro"))
            and "gemini" in m.name.lower()
        ]

        # Newest flash first, then newest pro — reverse=True so '2.5' > '2.0' > '1.5'
        flash = sorted([m for m in all_models if "flash" in m.lower()], reverse=True)
        pro   = sorted([m for m in all_models if "flash" not in m.lower()], reverse=True)
        ordered = flash + pro

        if ordered:
            _gemini_model_cache = ordered[0]
            logger.info("Auto-selected Gemini model: %s", _gemini_model_cache)
            return _gemini_model_cache
    except Exception as exc:
        logger.warning("Could not list Gemini models: %s — falling back to gemini-2.5-flash", exc)

    _gemini_model_cache = "gemini-2.5-flash"
    return _gemini_model_cache


# ── Fallback-chain construction ───────────────────────────────────────────────

# Model "" means "resolve the default for this backend at call time"
# (e.g. Gemini auto-resolution, or env-var-driven defaults for Groq/Ollama).
_DEFAULT_CHAIN_MODEL = ""


def _default_model_for_backend(backend: str) -> str:
    if backend == "gpt4o":
        return "gpt-4o"
    if backend == "claude":
        return "claude-sonnet-4-6"
    if backend == "gemini":
        return _DEFAULT_CHAIN_MODEL  # resolved lazily
    if backend == "ollama":
        return os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
    if backend == "groq":
        return os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    return _DEFAULT_CHAIN_MODEL


def _is_ollama_reachable() -> bool:
    import urllib.request
    host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    try:
        urllib.request.urlopen(f"{host}/api/tags", timeout=0.5)  # noqa: S310
        return True
    except Exception:
        return False


def _parse_fallback_chain_env(env_val: str) -> list[tuple[str, str]]:
    """
    Parse FUSIONTEST_FALLBACK_CHAIN.

    Format: comma-separated list of "backend" or "backend:model" tokens.
    Example: "groq:llama-3.3-70b-versatile,groq:llama-3.1-8b-instant,gemini,ollama"
    """
    chain: list[tuple[str, str]] = []
    for raw in env_val.split(","):
        token = raw.strip()
        if not token:
            continue
        if ":" in token:
            backend, model = token.split(":", 1)
            backend = backend.strip()
            model = model.strip()
        else:
            backend = token
            model = _DEFAULT_CHAIN_MODEL
        if backend not in ("gpt4o", "claude", "gemini", "groq", "ollama"):
            logger.warning("Ignoring unknown backend in FUSIONTEST_FALLBACK_CHAIN: %s", backend)
            continue
        chain.append((backend, model))
    return chain


def _build_default_fallback_chain(primary: str) -> list[tuple[str, str]]:
    """
    Build a sensible default chain given the primary backend + available API keys.

    Goals:
      1. Never silently change provider when the user picked Ollama or mpnet.
      2. For Groq primary, fall to Groq's 8B (separate rate-limit bucket) before
         switching provider entirely.
      3. Only include providers where credentials / reachability are present.
    """
    chain: list[tuple[str, str]] = []
    chain.append((primary, _default_model_for_backend(primary)))

    # Honour local-only intent
    if primary in ("mpnet", "ollama"):
        return chain

    # Groq: add the 8B model as the first fallback — separate rate limit bucket
    # and ~15x higher TPM on the free tier than 70B.
    if primary == "groq":
        eight_b = "llama-3.1-8b-instant"
        if _default_model_for_backend("groq") != eight_b:
            chain.append(("groq", eight_b))

    # Cross-provider fallbacks in order of cost / availability
    seen_backends = {primary}

    if "gemini" not in seen_backends and os.getenv("GEMINI_API_KEY"):
        chain.append(("gemini", _DEFAULT_CHAIN_MODEL))
        seen_backends.add("gemini")

    if "groq" not in seen_backends and os.getenv("GROQ_API_KEY"):
        chain.append(("groq", _default_model_for_backend("groq")))
        seen_backends.add("groq")

    if "claude" not in seen_backends and os.getenv("ANTHROPIC_API_KEY"):
        chain.append(("claude", _default_model_for_backend("claude")))
        seen_backends.add("claude")

    # Ollama as last-resort (free, offline). Only if reachable.
    if "ollama" not in seen_backends and _is_ollama_reachable():
        chain.append(("ollama", _default_model_for_backend("ollama")))
        seen_backends.add("ollama")

    return chain


class ActionModel:
    """
    FusionTest's core AI brain.

    Usage:
        model = ActionModel(backend="gpt4o")   # start here for MVP
        actions = model.predict(screen_text, goal, history)
        best = actions[0]
    """

    def __init__(
        self,
        backend: ActionBackend = "gpt4o",
        model_path: str | None = None,
        top_k: int = 3,
        temperature: float = 0.2,
        fallback_chain: list[tuple[str, str]] | None = None,
        max_retries_per_backend: int = 1,
        backoff_seconds: float = 1.0,
    ):
        self.backend = backend
        self.top_k = top_k
        self.temperature = temperature
        self.max_retries_per_backend = max_retries_per_backend
        self.backoff_seconds = backoff_seconds

        # Per-(backend, model) client cache. Lazily populated.
        self._clients: dict[tuple[str, str], Any] = {}

        # Kept for backward compatibility — primary backend's resolved model.
        # Not used by the fallback path; purely informational.
        self._client = None
        self._llm_model: str = _default_model_for_backend(backend) if backend != "mpnet" else ""

        if backend == "mpnet":
            self._load_mpnet(model_path)
            self.fallback_chain: list[tuple[str, str]] = []
            return

        if backend not in ("gpt4o", "claude", "gemini", "ollama", "groq"):
            raise ValueError(f"Unknown backend: {backend}")

        # Build the fallback chain:
        #   1. Explicit constructor arg wins
        #   2. FUSIONTEST_FALLBACK_CHAIN env var
        #   3. Auto-detect based on primary backend + available keys
        if fallback_chain is not None:
            self.fallback_chain = list(fallback_chain)
        else:
            env_chain = os.getenv("FUSIONTEST_FALLBACK_CHAIN", "").strip()
            if env_chain:
                self.fallback_chain = _parse_fallback_chain_env(env_chain)
                if not self.fallback_chain:
                    # Env var was set but produced no usable entries — fall back to default.
                    self.fallback_chain = _build_default_fallback_chain(backend)
            else:
                self.fallback_chain = _build_default_fallback_chain(backend)

        # Ensure the primary backend leads the chain.
        primary_entry = (backend, _default_model_for_backend(backend))
        if not self.fallback_chain or self.fallback_chain[0][0] != backend:
            self.fallback_chain.insert(0, primary_entry)

        logger.info(
            "ActionModel fallback chain: %s",
            " → ".join(f"{b}:{m or 'auto'}" for b, m in self.fallback_chain),
        )

    # ── Public API ─────────────────────────────────────────────────────────────

    def predict(
        self,
        screen_text: str,
        goal: str,
        history: list[str] | None = None,
        invalid_actions: list[str] | None = None,
    ) -> list[Action]:
        """
        Returns top-k ranked Actions for the current screen + goal.

        Token usage for this call is stored on ``self.last_token_usage``
        so the runner can accumulate it without changing the public signature.

        Args:
            screen_text: compact screen state from ScreenParser
            goal: the current test step goal in natural language
            history: list of previously taken action strings (for context)
            invalid_actions: actions already tried and failed (for guardrails)
        """
        history = history or []
        invalid_actions = invalid_actions or []

        if self.backend == "mpnet":
            self.last_token_usage = TokenUsage()
            return self._predict_mpnet(screen_text, goal, history, invalid_actions)
        else:
            return self._predict_llm(screen_text, goal, history, invalid_actions)

    # ── MPNet backend ──────────────────────────────────────────────────────────

    def _load_mpnet(self, model_path: str | None) -> None:
        try:
            from sentence_transformers import SentenceTransformer
            path = model_path or os.getenv("FUSIONTEST_MODEL_PATH", "sentence-transformers/all-mpnet-base-v2")
            logger.info(f"Loading MPNet from: {path}")
            self._encoder = SentenceTransformer(path)
        except ImportError as err:
            raise RuntimeError(
                "MPNet backend requires sentence-transformers: "
                "pip install sentence-transformers"
            ) from err

    def _predict_mpnet(
        self,
        screen_text: str,
        goal: str,
        history: list[str],
        invalid_actions: list[str],
    ) -> list[Action]:
        """
        Embed the goal and each candidate action, rank by cosine similarity.
        Candidate actions are generated from the parsed screen elements.
        """
        import numpy as np

        candidates = self._generate_candidates(screen_text)
        if not candidates:
            return [Action(action_type="wait", element_index=None, element_label="", confidence=0.5)]

        query = self._build_query(goal, history, invalid_actions)
        query_emb = self._encoder.encode(query, normalize_embeddings=True)
        cand_embs = self._encoder.encode(candidates, normalize_embeddings=True)

        scores = np.dot(cand_embs, query_emb)
        top_indices = np.argsort(scores)[::-1][:self.top_k]

        actions = []
        for i in top_indices:
            action = self._parse_candidate(candidates[i], float(scores[i]))
            if str(action) not in invalid_actions:
                actions.append(action)

        return actions if actions else [Action(action_type="back", element_index=None, element_label="", confidence=0.3)]

    def _generate_candidates(self, screen_text: str) -> list[str]:
        """Generate action strings for every interactive element on screen."""
        candidates = []
        for line in screen_text.split("\n"):
            if line.strip().startswith("["):
                parts = line.strip().split()
                idx = int(parts[0].strip("[]"))
                elem_type = parts[1] if len(parts) > 1 else ""
                label = " ".join(p.strip('"') for p in parts[2:] if p.startswith('"'))

                if elem_type in ("button", "link", "list_item", "tab", "menu_item"):
                    candidates.append(f"tap [idx={idx}] {elem_type} \"{label}\"")
                elif elem_type in ("text_field", "text_area", "search_field"):
                    candidates.append(f"type into [idx={idx}] {elem_type} \"{label}\"")
                elif elem_type == "switch":
                    candidates.append(f"toggle [idx={idx}] switch \"{label}\"")
                elif elem_type == "slider":
                    candidates.append(f"adjust [idx={idx}] slider \"{label}\"")
                elif elem_type == "picker":
                    candidates.append(f"select from [idx={idx}] picker \"{label}\"")

        candidates += ["scroll down", "scroll up", "back", "wait"]
        return candidates

    def _parse_candidate(self, candidate: str, score: float) -> Action:
        parts = candidate.split()
        action_type = parts[0]
        idx = None
        label = candidate

        for p in parts:
            if p.startswith("[idx="):
                try:
                    idx = int(p.replace("[idx=", "").replace("]", ""))
                except ValueError:
                    pass

        return Action(
            action_type=action_type,
            element_index=idx,
            element_label=label,
            confidence=score,
        )

    # ── LLM backend (GPT-4o / Claude) ─────────────────────────────────────────

    def _get_client(self, backend: str, model: str) -> tuple[Any, str]:
        """
        Lazily create (and cache) the client for a given backend+model.
        Returns (client, resolved_model). The resolved_model may differ from
        the requested `model` when Gemini auto-resolution is used.
        """
        cache_key = (backend, model)
        if cache_key in self._clients:
            return self._clients[cache_key], model or _default_model_for_backend(backend)

        resolved_model = model or _default_model_for_backend(backend)

        if backend == "gpt4o":
            try:
                from openai import OpenAI
            except ImportError as err:
                raise RuntimeError("GPT-4o backend requires openai: pip install openai") from err
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "OPENAI_API_KEY is not set. Add it to your .env file or run: "
                    "export OPENAI_API_KEY=sk-..."
                )
            client = OpenAI(api_key=api_key)

        elif backend == "claude":
            try:
                import anthropic
            except ImportError as err:
                raise RuntimeError("Claude backend requires anthropic: pip install anthropic") from err
            api_key = os.getenv("ANTHROPIC_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "ANTHROPIC_API_KEY is not set. Add it to your .env file or run: "
                    "export ANTHROPIC_API_KEY=sk-ant-..."
                )
            client = anthropic.Anthropic(api_key=api_key)

        elif backend == "ollama":
            try:
                from openai import OpenAI
            except ImportError as err:
                raise RuntimeError(
                    "Ollama backend requires the openai SDK: pip install openai"
                ) from err
            base_url = os.getenv("OLLAMA_HOST", "http://localhost:11434") + "/v1"
            client = OpenAI(base_url=base_url, api_key="ollama")

        elif backend == "groq":
            try:
                from openai import OpenAI
            except ImportError as err:
                raise RuntimeError("Groq backend requires openai: pip install openai") from err
            api_key = os.getenv("GROQ_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "GROQ_API_KEY is not set. Get a free key at https://console.groq.com "
                    "then: export GROQ_API_KEY=gsk_..."
                )
            client = OpenAI(base_url="https://api.groq.com/openai/v1", api_key=api_key)

        elif backend == "gemini":
            try:
                import google.generativeai as genai
            except ImportError as err:
                raise RuntimeError(
                    "Gemini backend requires google-generativeai.\n"
                    "Install it with:  pip install 'fusiontest[gemini]'\n"
                    "  or:            pip install google-generativeai"
                ) from err
            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "GEMINI_API_KEY is not set. Add it to your .env file or run: "
                    "export GEMINI_API_KEY=AIza..."
                )
            genai.configure(api_key=api_key)
            if not resolved_model:
                resolved_model = _resolve_gemini_model(genai)
            client = genai.GenerativeModel(
                model_name=resolved_model,
                system_instruction=self._SYSTEM_PROMPT_ACTION,
            )

        else:
            raise RuntimeError(f"Unknown backend: {backend}")

        self._clients[cache_key] = client
        return client, resolved_model

    def _predict_llm(
        self,
        screen_text: str,
        goal: str,
        history: list[str],
        invalid_actions: list[str],
    ) -> list[Action]:
        prompt = self._build_llm_prompt(screen_text, goal, history, invalid_actions)
        raw, usage = self._call_llm(prompt)
        self.last_token_usage = usage
        return self._parse_llm_response(raw)

    def _build_llm_prompt(
        self,
        screen_text: str,
        goal: str,
        history: list[str],
        invalid_actions: list[str],
    ) -> str:
        sections = [
            "You are FusionTest, an AI agent that tests mobile and desktop UIs.",
            "Your job: look at the current screen, understand the goal, and decide the single best action to take.",
            "",
            f"CURRENT GOAL: {goal}",
        ]

        if history:
            sections += ["", "ACTIONS TAKEN SO FAR:", *[f"  - {h}" for h in history[-5:]]]

        if invalid_actions:
            sections += ["", "ACTIONS THAT FAILED (do NOT repeat):", *[f"  - {a}" for a in invalid_actions]]

        sections += [
            "",
            screen_text,
            "",
            "IMPORTANT RULES:",
            "- If the goal is purely about VERIFYING or CHECKING that something is visible, and the relevant content IS already visible on screen, use action_type 'done' with a reasoning explaining what you see.",
            "- If the goal requires navigation or interaction, use the appropriate action.",
            "- Match elements FLEXIBLY: if the goal says 'click Visitor Identification' but you see a link like 'Anonymous Visitors Unknown' or a link with href containing 'visitor-identification', those are the same thing. Use the element that's actually on screen.",
            "- When the goal says 'navigate back', use the 'back' action type, not look for a back button.",
            "- Only use 'scroll' if you've already looked at all interactive elements and none match. Don't scroll repeatedly — if no match after one scroll, try tapping the closest match.",
            "- NEVER scroll more than twice for the same goal. If the element isn't visible after scrolling, tap the closest matching element.",
            "",
            "Respond with a JSON array of up to 3 ranked action objects. Each must have:",
            '  { "action_type": "tap|type|swipe|scroll|back|wait|done", "element_index": <int or null>, "element_label": "<string>", "value": "<string or empty>", "confidence": <0-1>, "reasoning": "<one sentence>" }',
            "",
            "action_type 'done' means the goal is already achieved based on what's visible — no further action needed.",
            "",
            "Respond with ONLY the JSON array. No explanation outside the JSON.",
        ]

        return "\n".join(sections)

    _SYSTEM_PROMPT_ACTION = (
        "You are FusionTest, an AI agent that tests UIs by choosing actions. "
        "You MUST respond with ONLY a JSON array of action objects. "
        "No prose, no explanation, no markdown fences — ONLY the raw JSON array. "
        "Example: [{\"action_type\": \"tap\", \"element_index\": 5, \"element_label\": \"Login\", \"value\": \"\", \"confidence\": 0.95, \"reasoning\": \"Click login button\"}]"
    )

    def _call_llm(self, prompt: str) -> tuple[str, TokenUsage]:
        """
        Call the LLM with automatic retry + multi-backend fallthrough.

        Returns (text, TokenUsage) so callers can accumulate token consumption.

        Iterates self.fallback_chain. For each entry:
          - On rate-limit errors: fall through immediately (same-provider
            retry rarely helps when the token bucket is empty).
          - On other transient errors (timeouts, 500s, connection resets):
            retry up to self.max_retries_per_backend with jittered backoff,
            then fall through.
          - On non-transient errors (auth, bad request): raise immediately.

        Only raises if every entry in the chain has been exhausted.
        """
        if not self.fallback_chain:
            # Defensive: should only happen for mpnet backend, which doesn't
            # go through _call_llm. Fall back to the legacy single-shot path.
            return self._call_llm_single(prompt, self.backend,
                                         _default_model_for_backend(self.backend))

        last_error: Exception | None = None
        attempted: list[str] = []

        for idx, (backend, model) in enumerate(self.fallback_chain):
            is_last = idx == len(self.fallback_chain) - 1
            attempted.append(f"{backend}:{model or 'auto'}")

            for attempt in range(self.max_retries_per_backend + 1):
                try:
                    return self._call_llm_single(prompt, backend, model)
                except Exception as err:  # noqa: BLE001
                    last_error = err
                    transient = _is_transient_error(err)
                    rate_limited = _is_rate_limit(err)

                    if not transient:
                        # Non-transient (auth, bad request, etc.) — raise up,
                        # the fallback chain can't help.
                        logger.error(
                            "Non-transient error from %s:%s — %s: %s",
                            backend, model or "auto",
                            err.__class__.__name__, err,
                        )
                        raise

                    # Rate-limit: skip same-provider retries, fall through.
                    if rate_limited:
                        logger.warning(
                            "Rate-limited on %s:%s — falling through to next backend.",
                            backend, model or "auto",
                        )
                        break

                    # Other transient: retry on same provider once with backoff.
                    if attempt < self.max_retries_per_backend:
                        sleep_for = self.backoff_seconds * (2 ** attempt)
                        sleep_for += random.uniform(0, self.backoff_seconds)
                        logger.warning(
                            "Transient error from %s:%s (%s) — retrying in %.1fs",
                            backend, model or "auto",
                            err.__class__.__name__, sleep_for,
                        )
                        time.sleep(sleep_for)
                        continue

                    logger.warning(
                        "Transient error on %s:%s after %d attempt(s) — falling through.",
                        backend, model or "auto", attempt + 1,
                    )

            if is_last:
                break

        logger.error(
            "All fallback backends exhausted (%s). Last error: %s: %s",
            " → ".join(attempted),
            last_error.__class__.__name__ if last_error else "Unknown",
            last_error,
        )
        if last_error is not None:
            raise last_error
        raise RuntimeError("LLM fallback chain is empty")

    def _call_llm_single(self, prompt: str, backend: str, model: str) -> tuple[str, TokenUsage]:
        """Single-shot LLM call against a specific backend + model.

        Returns (text, TokenUsage) so callers can accumulate token consumption.
        """
        client, resolved_model = self._get_client(backend, model)

        if backend in ("gpt4o", "ollama", "groq"):
            resp = client.chat.completions.create(
                model=resolved_model,
                messages=[
                    {"role": "system", "content": self._SYSTEM_PROMPT_ACTION},
                    {"role": "user", "content": prompt},
                ],
                temperature=self.temperature,
                max_tokens=512,
            )
            usage = TokenUsage(
                input_tokens=getattr(getattr(resp, "usage", None), "prompt_tokens", 0) or 0,
                output_tokens=getattr(getattr(resp, "usage", None), "completion_tokens", 0) or 0,
            )
            return resp.choices[0].message.content or "", usage

        if backend == "claude":
            resp = client.messages.create(
                model=resolved_model,
                max_tokens=512,
                system=self._SYSTEM_PROMPT_ACTION,
                messages=[
                    {"role": "user", "content": prompt + "\n\nIMPORTANT: Your entire response must be a JSON array starting with [ and ending with ]. No other text."},
                ],
            )
            usage = TokenUsage(
                input_tokens=getattr(getattr(resp, "usage", None), "input_tokens", 0) or 0,
                output_tokens=getattr(getattr(resp, "usage", None), "output_tokens", 0) or 0,
            )
            return (resp.content[0].text if resp.content else ""), usage

        if backend == "gemini":
            resp = client.generate_content(
                prompt + "\n\nIMPORTANT: Your entire response must be a JSON array starting with [ and ending with ]. No other text.",
                generation_config={"temperature": self.temperature, "max_output_tokens": 512},
            )
            meta = getattr(resp, "usage_metadata", None)
            usage = TokenUsage(
                input_tokens=getattr(meta, "prompt_token_count", 0) or 0,
                output_tokens=getattr(meta, "candidates_token_count", 0) or 0,
            )
            return (resp.text if resp.text else "[]"), usage

        return "[]", TokenUsage()

    def _parse_llm_response(self, raw: str) -> list[Action]:
        import re

        raw = raw.strip()

        # Strip markdown fences if present
        if "```" in raw:
            # Extract content between fences
            parts = raw.split("```")
            for part in parts[1:]:
                cleaned = part.strip()
                if cleaned.startswith("json"):
                    cleaned = cleaned[4:].strip()
                if cleaned.startswith("["):
                    raw = cleaned
                    break

        # Strategy 1: Direct JSON parse
        items = self._try_parse_json_array(raw)

        # Strategy 2: Extract JSON array from prose using bracket matching
        if items is None:
            array_match = re.search(r'\[[\s\S]*\]', raw)
            if array_match:
                items = self._try_parse_json_array(array_match.group(0))

        # Strategy 3: Extract individual JSON objects and wrap them
        if items is None:
            obj_matches = re.findall(r'\{[^{}]*"action_type"\s*:\s*"[^"]+?"[^{}]*\}', raw)
            if obj_matches:
                combined = "[" + ",".join(obj_matches) + "]"
                items = self._try_parse_json_array(combined)

        if items is None:
            logger.warning(f"Failed to parse LLM response as JSON: {raw[:200]}")
            return [Action(action_type="wait", element_index=None, element_label="parse_error", confidence=0.1)]

        actions = []
        for item in items[:self.top_k]:
            if not isinstance(item, dict):
                continue
            actions.append(Action(
                action_type=item.get("action_type", "wait"),
                element_index=item.get("element_index"),
                element_label=item.get("element_label", ""),
                value=item.get("value", ""),
                confidence=float(item.get("confidence", 0.5)),
                reasoning=item.get("reasoning", ""),
            ))

        return actions or [Action(action_type="wait", element_index=None, element_label="", confidence=0.1)]

    @staticmethod
    def _try_parse_json_array(text: str) -> list | None:
        """Try to parse text as a JSON array, return None on failure."""
        try:
            result = json.loads(text.strip())
            if isinstance(result, list):
                return result
        except (json.JSONDecodeError, ValueError):
            pass
        return None

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _build_query(self, goal: str, history: list[str], invalid: list[str]) -> str:
        parts = [f"Goal: {goal}"]
        if history:
            parts.append(f"Last actions: {', '.join(history[-3:])}")
        if invalid:
            parts.append(f"Avoid: {', '.join(invalid)}")
        return ". ".join(parts)
