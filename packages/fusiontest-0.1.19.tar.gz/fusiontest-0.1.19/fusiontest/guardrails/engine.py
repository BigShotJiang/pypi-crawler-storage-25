"""
fusiontest/guardrails/engine.py

Guardrails protect FusionTest from the three main LLM failure modes:
  1. Partially invalid actions (wrong action type for the element)
  2. Completely invalid actions (element doesn't exist)
  3. Loops / repeated actions (model is stuck)

Each check modifies the action or triggers a backtrack before execution.
"""

from __future__ import annotations

import hashlib
import logging
from collections import deque
from dataclasses import dataclass

from fusiontest.core.action_model import Action
from fusiontest.core.screen_parser import UIElement

logger = logging.getLogger("fusiontest.guardrails")


@dataclass
class GuardrailsConfig:
    loop_window: int = 5              # how many recent screen hashes to compare
    max_invalid_retries: int = 3      # before triggering backtrack
    max_backtracks: int = 2           # hard limit on backtracks per goal step
    enable_partial_fix: bool = True   # auto-fix wrong action types
    enable_loop_detection: bool = True
    enable_backtrack: bool = True


@dataclass
class GuardrailsResult:
    action: Action                    # potentially corrected action
    corrected: bool = False           # True if the action was auto-fixed
    should_backtrack: bool = False    # True if we should undo and retry
    should_skip: bool = False         # True if action is a known loop item
    reason: str = ""


class GuardrailsEngine:
    """
    Stateful guardrails engine. One instance per test run.

    Usage:
        engine = GuardrailsEngine(config)
        result = engine.check(proposed_action, elements, screen_text)
        if result.should_backtrack:
            ...  # undo last N actions
        elif not result.should_skip:
            executor.execute(result.action)
    """

    def __init__(self, config: GuardrailsConfig | None = None):
        self.config = config or GuardrailsConfig()
        self._screen_history: deque[str] = deque(maxlen=self.config.loop_window)
        self._action_history: list[str] = []
        self._invalid_streak: int = 0
        self._backtrack_count: int = 0
        self._invalid_actions: set[str] = set()

    # ── Public API ─────────────────────────────────────────────────────────────

    def check(
        self,
        action: Action,
        elements: list[UIElement],
        screen_text: str,
    ) -> GuardrailsResult:
        """
        Run all guardrail checks on a proposed action.
        Returns a GuardrailsResult with the (possibly corrected) action.
        """

        # 1. Loop detection — check if we're cycling
        if self.config.enable_loop_detection:
            loop_result = self._check_loop(action, screen_text)
            if loop_result:
                return loop_result

        # 2. Validate action against real element list
        validity = self._validate_action(action, elements)

        if validity == "valid":
            self._invalid_streak = 0
            return GuardrailsResult(action=action)

        elif validity == "partial":
            if self.config.enable_partial_fix:
                fixed = self._fix_partial(action, elements)
                if fixed:
                    logger.info(f"Guardrails: partial fix {action} → {fixed}")
                    return GuardrailsResult(action=fixed, corrected=True, reason="partial_fix")

        # 3. Completely invalid — track streak and maybe backtrack
        self._invalid_streak += 1
        self._invalid_actions.add(str(action))

        if self._invalid_streak >= self.config.max_invalid_retries:
            if self.config.enable_backtrack and self._backtrack_count < self.config.max_backtracks:
                self._backtrack_count += 1
                self._invalid_streak = 0
                logger.warning(f"Guardrails: triggering backtrack #{self._backtrack_count}")
                return GuardrailsResult(
                    action=action,
                    should_backtrack=True,
                    reason=f"invalid_streak_{self.config.max_invalid_retries}",
                )
            else:
                logger.error("Guardrails: max backtracks reached, giving up on step")
                return GuardrailsResult(
                    action=action,
                    should_skip=True,
                    reason="max_backtracks_exceeded",
                )

        return GuardrailsResult(
            action=action,
            should_skip=True,
            reason=f"invalid_action (streak={self._invalid_streak})",
        )

    def record_screen(self, screen_text: str) -> None:
        """Call this after every screen transition."""
        self._screen_history.append(_hash_screen(screen_text))

    def record_action(self, action: Action) -> None:
        """Call this after every successfully executed action."""
        self._action_history.append(str(action))

    def get_invalid_actions(self) -> list[str]:
        return list(self._invalid_actions)

    def reset_step(self) -> None:
        """Reset all per-goal counters when moving to the next goal step."""
        self._invalid_streak = 0
        self._backtrack_count = 0
        self._invalid_actions.clear()
        self._screen_history.clear()
        self._action_history.clear()

    # ── Internal checks ────────────────────────────────────────────────────────

    def _check_loop(self, action: Action, screen_text: str) -> GuardrailsResult | None:
        screen_hash = _hash_screen(screen_text)
        action_str = str(action)

        # Passive / progressive actions — never loop-detect on these.
        # scroll/swipe are intentionally repeated to reach off-screen content;
        # done/wait are single-use control signals.
        if action.action_type in ("done", "wait", "scroll", "swipe"):
            return None

        # Repeated screen state — we're not making progress.
        # Trigger when the entire window is filled with the same screen hash.
        if list(self._screen_history).count(screen_hash) >= self.config.loop_window:
            logger.warning(f"Guardrails: screen loop detected (hash={screen_hash[:8]})")
            return GuardrailsResult(
                action=action,
                should_backtrack=True,
                reason="screen_loop",
            )

        # Repeated action in last 4 steps — same interactive action 3+ times in a row.
        recent = self._action_history[-4:]
        if recent.count(action_str) >= 3:
            logger.warning(f"Guardrails: action loop detected (consecutive): {action_str}")
            return GuardrailsResult(
                action=action,
                should_skip=True,
                reason="action_loop_consecutive",
            )

        # Repeated action across the full goal history — catches patterns like
        # tap X → scroll → scroll → tap X → scroll → scroll → tap X (still not working).
        # If the same action has been tried 3+ times total and we're still here,
        # it's clearly not making progress.
        if self._action_history.count(action_str) >= 3:
            logger.warning(f"Guardrails: repeated action across goal (3+ total): {action_str}")
            return GuardrailsResult(
                action=action,
                should_skip=True,
                reason="action_loop_repeated",
            )

        return None

    def _validate_action(self, action: Action, elements: list[UIElement]) -> str:
        """Returns 'valid', 'partial', or 'invalid'."""
        if action.action_type in ("back", "home", "wait", "scroll", "swipe", "done"):
            return "valid"  # system actions are always valid

        if action.element_index is None:
            return "invalid"

        matching = [e for e in elements if e.index == action.element_index]
        if not matching:
            # Try matching by label instead
            label_match = [e for e in elements if action.element_label and e.label == action.element_label]
            if not label_match:
                return "invalid"
            matching = label_match

        element = matching[0]

        if not element.enabled or not element.visible:
            return "invalid"

        # Check if action type makes sense for the element type
        if action.action_type == "type" and element.element_type not in (
            "text_field", "text_area", "search_field"
        ):
            return "partial"

        if action.action_type == "tap" and element.element_type == "slider":
            return "partial"

        return "valid"

    def _fix_partial(self, action: Action, elements: list[UIElement]) -> Action | None:
        """Auto-fix a partially invalid action where possible."""
        matching = [e for e in elements if e.index == action.element_index]
        if not matching:
            return None

        element = matching[0]

        # Fix: typing into a non-text element → change to tap
        if action.action_type == "type" and element.element_type not in (
            "text_field", "text_area", "search_field"
        ):
            return Action(
                action_type="tap",
                element_index=element.index,
                element_label=element.label,
                confidence=action.confidence * 0.9,
                reasoning="auto-fixed: type → tap (element is not a text field)",
            )

        # Fix: tapping a slider → use adjust
        if action.action_type == "tap" and element.element_type == "slider":
            return Action(
                action_type="adjust",
                element_index=element.index,
                element_label=element.label,
                value=action.value,
                confidence=action.confidence * 0.9,
                reasoning="auto-fixed: tap → adjust (element is a slider)",
            )

        return None


# ── Helpers ────────────────────────────────────────────────────────────────────

def _hash_screen(screen_text: str) -> str:
    return hashlib.md5(screen_text.encode()).hexdigest()
