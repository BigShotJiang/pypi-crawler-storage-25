"""
Lightweight API client for NetGreener CLI — wraps the REST endpoints needed by the CLI.
"""

import requests
from typing import Any

from .config import get_api_url, load_credentials


class APIError(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class _AuthPreservingSession(requests.Session):
    """Keep Authorization header and HTTP method when following redirects (http→https, 301/307)."""
    def rebuild_auth(self, prepared_request, response):
        pass  # Never strip auth headers on redirects

    def rebuild_method(self, _prepared_request, _response):
        pass  # Never convert POST→GET on 301/302 redirects


class NetGreenerClient:
    def __init__(self, token: str | None = None, base_url: str | None = None, user_id: int | None = None):
        self.base_url = (base_url or get_api_url()) + "/api/v1"
        self._token = token
        self._user_id = user_id
        self._session = _AuthPreservingSession()

    @classmethod
    def from_credentials(cls) -> "NetGreenerClient":
        creds = load_credentials()
        if not creds:
            raise APIError(401, "Not logged in. Run: netgreener login")
        user_id = creds.get("user", {}).get("user_id")
        return cls(token=creds["access_token"], user_id=user_id)

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    def _raise(self, resp: requests.Response) -> None:
        if not resp.ok:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise APIError(resp.status_code, detail)

    def login(self, email: str, password: str) -> dict:
        resp = self._session.post(
            f"{self.base_url}/auth/login",
            json={"email": email, "password": password},
            timeout=15,
        )
        self._raise(resp)
        data = resp.json()
        self._token = data["access_token"]
        return data

    def get_or_create_project(self, name: str, directory: str) -> dict:
        resp = self._session.get(
            f"{self.base_url}/projects/",
            headers=self._headers(),
            timeout=15,
        )
        self._raise(resp)
        projects = resp.json()
        for p in projects:
            if p.get("name") == name:
                return p
        resp = self._session.post(
            f"{self.base_url}/projects/",
            headers=self._headers(),
            json={"name": name, "directory": directory, "language": "Python", "user_id": self._user_id},
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def create_run_session(self, payload: dict) -> dict:
        resp = self._session.post(
            f"{self.base_url}/runsessions",
            headers=self._headers(),
            json=payload,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def update_run_accuracy(self, run_id: int, metrics: dict) -> dict:
        resp = self._session.put(
            f"{self.base_url}/runsessions/{run_id}/accuracy",
            headers=self._headers(),
            json=metrics,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def post_code_patterns_batch(self, patterns: list) -> dict:
        resp = self._session.post(
            f"{self.base_url}/code-patterns/batch",
            headers=self._headers(),
            json={"patterns": patterns},
            timeout=30,
        )
        self._raise(resp)
        return resp.json()

    def post_surrogate_training(self, payload: dict) -> dict:
        resp = self._session.post(
            f"{self.base_url}/surrogate-training/",
            headers=self._headers(),
            json=payload,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def get_llm_config(self) -> dict:
        resp = self._session.get(
            f"{self.base_url}/config/llm/",
            headers=self._headers(),
            timeout=10,
        )
        self._raise(resp)
        return resp.json()

    def post_environmental_impact(self, payload: dict) -> dict:
        resp = self._session.post(
            f"{self.base_url}/environmental-impact",
            headers=self._headers(),
            json=payload,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()
