#!/usr/bin/env python3
import argparse
import os
import platform
import sys
import requests
import json
import re
import subprocess
import tempfile
import pathlib
import shlex
import atexit
import warnings

# Suppress the specific renaming warning from duckduckgo_search
warnings.filterwarnings("ignore", category=RuntimeWarning, message=".*duckduckgo_search.*renamed to ddgs.*")

try:
    from ddgs import DDGS
except ImportError:
    from duckduckgo_search import DDGS

try:
    import readline
except ImportError:
    # Fallback for systems/environments without readline support (e.g., some Windows setups)
    readline = None

from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.live import Live
from rich.text import Text
from rich.markup import escape
from rich.syntax import Syntax
from rich.markdown import Markdown

console = Console()
# Centralized data directory for sessions and logs
ASKME_DIR = pathlib.Path.home() / ".askme"

def apply_patch(filepath, diff_content):
    """Applies a unified diff to a file using the system patch utility."""
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.diff', delete=False) as tmp:
            tmp.write(diff_content)
            tmp_path = tmp.name
        
        # -u treats it as unified diff, -N allows new files
        result = subprocess.run(['patch', '-u', filepath, tmp_path], capture_output=True, text=True)
        os.unlink(tmp_path)
        
        if result.returncode == 0:
            return f"Successfully applied patch to {filepath}."
        else:
            return f"Patch failed:\n{result.stderr}"
    except Exception as e:
        return f"Error applying patch: {e}"

def search_codebase(pattern, path="."):
    """Searches for a pattern in the codebase using grep."""
    try:
        # -r recursive, -n line numbers, -I ignore binary files
        result = subprocess.run(['grep', '-rnI', pattern, path], capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout
        else:
            return "No matches found."
    except Exception as e:
        return f"Error searching codebase: {e}"

def read_file_range(filepath, start_line, end_line):
    """Reads a specific range of lines from a file to save context tokens."""
    try:
        with open(filepath, 'r') as f:
            lines = f.readlines()
            # Adjust to 0-based indexing for the user-provided 1-based line numbers
            content = lines[max(0, start_line-1):end_line]
            return "".join(content)
    except Exception as e:
        return f"Error reading file: {e}"

def run_tests(path="."):
    """Executes pytest on the specified path."""
    try:
        result = subprocess.run(['pytest', '-v', path], capture_output=True, text=True)
        output = result.stdout + result.stderr
        return f"Exit Code: {result.returncode}\n{output}"
    except Exception as e:
        return f"Error running tests: {e}"

def lint_file(filepath):
    """Checks a file for linting errors using flake8."""
    try:
        result = subprocess.run(['flake8', filepath], capture_output=True, text=True)
        if result.returncode == 0:
            return f"✔ No linting errors found in {filepath}."
        return f"✘ Linting errors in {filepath}:\n{result.stdout}"
    except FileNotFoundError:
        return "Error: 'flake8' not found. Please install it."
    except Exception as e:
        return f"Error linting file: {e}"

def analyze_structure(path="."):
    """Provides a high-level summary of classes and functions in the project."""
    summary = []
    try:
        for root, _, files in os.walk(path):
            if '.git' in root or '__pycache__' in root or '.askme' in root: continue
            for file in files:
                if file.endswith(".py"):
                    filepath = os.path.join(root, file)
                    rel_path = os.path.relpath(filepath, path)
                    with open(filepath, "r") as f:
                        lines = f.readlines()
                        classes = [l.split()[1].split('(')[0].strip(':') for l in lines if l.startswith('class ')]
                        functions = [l.split()[1].split('(')[0].strip(':') for l in lines if l.startswith('def ')]
                        if classes or functions:
                            item = f"File: [bold cyan]{rel_path}[/bold cyan]"
                            if classes: item += f"\n  Classes: {', '.join(classes)}"
                            if functions: item += f"\n  Functions: {', '.join(functions)}"
                            summary.append(item)
        return "\n".join(summary) if summary else "No Python structures found."
    except Exception as e:
        return f"Error analyzing structure: {e}"

def web_search(query, max_results=5):
    """Performs a web search using DuckDuckGo."""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
            if not results:
                return "No search results found."
            
            formatted_results = []
            for r in results:
                formatted_results.append(f"Title: {r.get('title')}\nURL: {r.get('href')}\nSnippet: {r.get('body')}\n")
            return "\n".join(formatted_results)
    except Exception as e:
        return f"Error performing web search: {e}"

def web_browse(url):
    """Fetches the content of a web page and returns a clean text summary."""
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            # Remove non-content elements
            for s in soup(['script', 'style', 'nav', 'footer', 'header']):
                s.decompose()
            text = soup.get_text(separator=' ', strip=True)
        except ImportError:
            text = re.sub(r'<[^>]+>', ' ', response.text)
            
        if len(text) > 6000:
            text = text[:3000] + "\n[... CONTENT TRUNCATED ...]\n" + text[-3000:]
        return text.strip()
    except Exception as e:
        return f"Error browsing {url}: {e}"

def summarize_history(history, api_key, model_name, url):
    """Calls the LLM to summarize interaction history into a concise project state."""
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    history_text = "\n".join([f"User: {h['q']}\nAgent: {h['a']}" for h in history])
    summary_prompt = (
        f"Summarize this interaction history into a single concise paragraph describing the current 'State of the Project'. "
        f"Mention key accomplishments and current file states.\n\n[HISTORY]\n{history_text}"
    )
    
    payload = {"model": model_name, "prompt": summary_prompt, "stream": False}
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        return response.json().get("response", "Summary unavailable.")
    except Exception as e:
        return "Summary generation failed."

def log_execution(command, returncode, duration, session="default"):
    """Records execution details to a session log file."""
    log_dir = ".askme/logs"
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"{session}.log")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_path, "a") as f:
        f.write(f"[{timestamp}] CMD: {command} | EXIT: {returncode} | DUR: {duration:.2f}s\n")

def load_history(history_file):
    """Loads conversation history from the specified file."""
    try:
        with open(history_file, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []
    except Exception as e:
        console.print(f"[yellow]Warning: Could not load history: {e}[/yellow]")
        return []

def save_history(history, history_file):
    """Saves the last 10 interactions to maintain project context."""
    # Atomic write to prevent corruption during crashes or interrupts
    temp_fd, temp_path = tempfile.mkstemp(dir=os.path.dirname(history_file), text=True)
    try:
        with os.fdopen(temp_fd, 'w') as f:
            json.dump(history[-10:], f, indent=2)
        os.replace(temp_path, history_file)
    except Exception as e:
        if os.path.exists(temp_path):
            os.unlink(temp_path)
        console.print(f"[red]Error saving history: {e}[/red]")

def get_directory_tree(path=".", prefix="", depth=0, max_depth=2):
    """Generates a visual directory tree string."""
    if depth > max_depth:
        return []
    tree = []
    try:
        items = sorted(os.listdir(path))
        # Filter out common junk and hidden files except history
        items = [i for i in items if not i.startswith('.') or i == '.askme']
        for i, item in enumerate(items):
            connector = "└── " if i == len(items) - 1 else "├── "
            tree.append(f"{prefix}{connector}{item}")
            full_path = os.path.join(path, item)
            if os.path.isdir(full_path):
                extension = "    " if i == len(items) - 1 else "│   "
                tree.extend(get_directory_tree(full_path, prefix + extension, depth + 1))
    except Exception: pass
    return tree

def get_system_context():
    """Gathers environment info to improve agent awareness."""
    return {
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": sys.version.split()[0],
        "cwd": os.getcwd()
    }

def is_dangerous(command):
    """Checks if a command contains potentially destructive operations using regex."""
    dangerous_patterns = [
        r"rm\s+-rf\s+[/.*~]", 
        r"> /dev/sd", r"mkfs", r"chmod\s+-R\s+777", 
        r"dd\s+if=", r":\(\)\{\s+:\|:&\s+\};:",
        r"mv\s+.*\s+/dev/null", r"shutdown", r"reboot",
        r"curl.*\|\s*bash", r"wget.*\|\s*bash"
    ]
    return any(re.search(pattern, command) for pattern in dangerous_patterns)

def is_filesystem_modifying(command):
    """Checks if a command is likely to modify the directory structure."""
    modifiers = ["mkdir", "touch", "rm", "mv", "cp", "git", ">>", ">", "sed", "patch"]
    return any(mod in command for mod in modifiers)

def is_path_safe(command):
    """Prevents directory traversal and access to absolute system paths."""
    # Basic jail: block climbing up or absolute paths that don't start with CWD
    return ".." not in command and not (command.startswith("/") and not command.startswith(os.getcwd()))

def get_current_context():
    """Refreshes the directory tree and system info for the prompt."""
    try:
        tree = get_directory_tree()
        sys_ctx = get_system_context()
        return (
            f"Environment: {sys_ctx['os']} {sys_ctx['os_version']}, Python {sys_ctx['python_version']}\n"
            f"CWD: {sys_ctx['cwd']}\nProject Structure:\n" + "\n".join(tree)
        )
    except Exception:
        return "Unknown directory context."

def load_config():
    """Loads configuration from ~/.askme/config.json."""
    config_path = ASKME_DIR / "config.json"
    if config_path.exists():
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except Exception as e:
            console.print(f"[yellow]Warning: Could not load config: {e}[/yellow]")
    return {}

def list_sessions():
    """Lists all saved session names."""
    session_dir = ASKME_DIR / "sessions"
    if not session_dir.exists():
        console.print("[yellow]No sessions found.[/yellow]")
        return
    
    sessions = [f.stem for f in session_dir.glob("*.json")]
    if not sessions:
        console.print("[yellow]No sessions found.[/yellow]")
        return

    console.print(Panel(
        "\n".join([f"• [bold cyan]{s}[/bold cyan]" for s in sorted(sessions)]),
        title="[bold white]Available Sessions[/bold white]",
        subtitle=f"[dim]Location: {session_dir}[/dim]"
    ))

def pick_session():
    """Interactively pick a session from the list."""
    session_dir = ASKME_DIR / "sessions"
    if not session_dir.exists(): 
        return Prompt.ask("Enter a name for the new session", default="default")
        
    sessions = sorted([f.stem for f in session_dir.glob("*.json")])
    if not sessions: 
        return Prompt.ask("Enter a name for the new session", default="default")
    
    console.print("\n[bold white]Select an existing session:[/bold white]")
    for i, s in enumerate(sessions, 1):
        console.print(f"{i}. [bold cyan]{s}[/bold cyan]")
    console.print(f"{len(sessions)+1}. [italic]Start a new named session[/italic]")
    
    choice = Prompt.ask("Choose a number or type a name", default="1")
    if choice.isdigit():
        idx = int(choice)
        if 1 <= idx <= len(sessions):
            return sessions[idx-1]
    return choice

def main():
    # 1. Setup argument parsing
    parser = argparse.ArgumentParser(description="askme - The Professional CLI AI Agent")
    parser.add_argument("-p", "--prompt", type=str, nargs='+', help="The prompt to send to the model")
    parser.add_argument("-s", "--session", type=str, default="default", help="Session name for the history")
    parser.add_argument("-m", "--model", type=str, default="gemma4:31b-cloud", help="Ollama model to use")
    parser.add_argument("-d", "--dry-run", action="store_true", help="Show proposed commands without executing them")
    parser.add_argument("--persona", type=str, choices=["default", "security", "refactor", "docs"], default="default", help="Agent persona")
    parser.add_argument("--mode", type=str, choices=["safe", "semi-auto", "auto"], default="safe", help="Execution trust level")
    parser.add_argument("-n", "--new", action="store_true", help="Start a fresh session (ignore existing history)")
    parser.add_argument("-l", "--list", action="store_true", help="List all saved sessions")
    parser.add_argument("--pick", action="store_true", help="Interactively pick a session at startup")
    args = parser.parse_args()

    config = load_config()

    # Initialize directory and readline history
    ASKME_DIR.mkdir(parents=True, exist_ok=True)
    if readline:
        readline_history_file = ASKME_DIR / "readline_history"
        if readline_history_file.exists():
            try:
                readline.read_history_file(str(readline_history_file))
            except Exception:
                pass
        # Set history length and register auto-save on exit
        readline.set_history_length(1000)
        atexit.register(readline.write_history_file, str(readline_history_file))

    if args.list:
        list_sessions()
        return

    if args.pick:
        args.session = pick_session()

    # 2. Configuration for Ollama
    api_key = os.getenv("OLLAMA_API_KEY") or config.get("api_key")
    # Prioritize environment variable if set, otherwise use default
    url = os.getenv("OLLAMA_API_URL", config.get("url", "https://ollama.com/api/generate"))

    console.print("[bold blue]Verifying Environment...[/bold blue]")
    
    # Only require API key if the endpoint isn't local
    is_local = "localhost" in url or "127.0.0.1" in url
    if not api_key and not is_local:
        console.print("[bold yellow]OLLAMA_API_KEY not found in environment.[/bold yellow]")
        api_key = Prompt.ask("[bold cyan]Please enter your Ollama API Key[/bold cyan]", password=True)
        if not api_key:
            console.print("[bold red]Error: API Key is required to proceed.[/bold red]")
            return

        # Prompt for model selection if key was missing
        console.print("\n[bold white]Select an AI Model to use:[/bold white]")
        console.print("1. gemma4:31b-cloud (Default)")
        console.print("2. llama3")
        console.print("3. mistral")
        choice = Prompt.ask("Choose a number or type a custom model name", default="1")
        
        if choice == "1": args.model = "gemma4:31b-cloud"
        elif choice == "2": args.model = "llama3"
        elif choice == "3": args.model = "mistral"
        else: args.model = choice
    
    try:
        requests.head(url.rsplit('/', 1)[0], timeout=5)
        console.print(f"[green]✔[/green] OLLAMA_API_KEY detected and endpoint reachable.")
        console.print(f"[green]✔[/green] Using model: [bold cyan]{args.model}[/bold cyan]\n")
    except Exception as e:
        console.print(f"[bold yellow]![/bold yellow] Warning: Connectivity check to {url} failed: {e}\n")

    # 2.1 Define Agent behavior for iterative reasoning
    personas = {
        "default": "You are an iterative CLI Agent. Solve user requests by planning and executing shell commands.",
        "security": "You are a Security Research Agent. Focus on identifying vulnerabilities, insecure configurations, and potential exploits.",
        "refactor": "You are a Refactoring Specialist. Focus on code quality, design patterns, modularity, and clean code principles.",
        "docs": "You are a Documentation Expert. Focus on improving READMEs, docstrings, and overall project documentation clarity."
    }
    
    base_instruction = (
        f"{personas.get(args.persona)}\n"
        "1. For complex requests, start by generating a 'Plan' (TODO list) and update it as you progress.\n"
        "2. Analyze context and provide reasoning before acting.\n"
        "3. For standard execution, use <execute>command</execute>.\n"
        "4. For complex commands with pipes or redirects, use <execute_shell>command</execute_shell>.\n"
        "5. For large files, use <read_range file=\"path\" start=\"line_num\" end=\"line_num\"/>.\n"
        "6. For codebase searches, use <search pattern=\"regex\" path=\"dir\"/>.\n"
        "7. For web search, use <search_web query=\"...\"/>. To read a specific URL, use <browse_web url=\"...\"/>.\n"
        "8. Use <patch file=\"path\">unified diff content</patch> to modify files precisely.\n"
        "9. For QA, use <test path=\"path\"/> (pytest), <lint file=\"path\"/> (flake8), and <analyze/> (project map).\n"
        "10. For state, use <export name=\"K\">V</export> to set and <get_env name=\"K\"/> to read session variables.\n"
        "11. Use command output to decide your next step. When finished, provide a final response."
    )

    # 2.2 Setup Session and Load History
    session_dir = ASKME_DIR / "sessions"
    session_dir.mkdir(parents=True, exist_ok=True)
    history_path = os.path.join(session_dir, f"{args.session}.json")

    if args.new:
        history = []
        console.print(f"[yellow]![/yellow] Starting a fresh session: [bold cyan]{args.session}[/bold cyan]")
    else:
        history = load_history(history_path)

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
        
    session_vars = {} # Maintain environment variables across interactive turns

    # 3. Determine if we are in one-shot or interactive mode
    stdin_prompt = ""
    if not sys.stdin.isatty():
        stdin_prompt = sys.stdin.read().strip()

    if args.prompt or stdin_prompt:
        arg_prompt = " ".join(args.prompt) if args.prompt else ""
        user_prompt = f"{stdin_prompt}\n\n{arg_prompt}".strip()
        run_agent_loop(user_prompt, base_instruction, url, headers, args, history, history_path, api_key, session_vars, args.model)
    else:
        console.print(Panel(
            "[bold cyan]Entering Interactive Mode[/bold cyan]\n"
            "Type [bold red]'exit'[/bold red] to stop.\n"
            "Commands: [bold magenta]/help[/bold magenta], [bold cyan]/sessions[/bold cyan], [bold white]/history[/bold white], [bold red]/raw[/bold red], [bold yellow]/tree[/bold yellow], [bold blue]/ctx[/bold blue], [bold green]/save <name>[/bold green], [bold cyan]/load <name>[/bold cyan]", 
            border_style="blue"
        ))
        while True:
            user_prompt = Prompt.ask("[bold yellow]Query[/bold yellow]")
            if user_prompt.lower() in ["exit", "quit"]:
                break
            
            cmd_parts = user_prompt.strip().split()
            if not cmd_parts: continue
            
            if user_prompt.strip().lower() == "/sessions":
                list_sessions()
                continue

            if user_prompt.strip().lower() == "/help":
                help_text = (
                    "• [bold magenta]/clear[/bold magenta]: Clear conversation history.\n"
                    "• [bold cyan]/sessions[/bold cyan]: List all saved sessions.\n"
                    "• [bold white]/history[/bold white]: View Q&A history of the current session.\n"
                    "• [bold red]/raw[/bold red]: Show the full raw prompt being sent to the LLM.\n"
                    "• [bold cyan]/load <name>[/bold cyan]: Load history from an existing session.\n"
                    "• [bold yellow]/tree[/bold yellow]: View the current project directory structure.\n"
                    "• [bold blue]/ctx[/bold blue]: View environment and project context.\n"
                    "• [bold green]/save <name>[/bold green]: Save current session to a new name.\n"
                    "• [bold red]exit[/bold red]: Close the application."
                )
                console.print(Panel(help_text, title="Available Commands", border_style="magenta"))
                continue

            if user_prompt.strip().lower() == "/raw":
                project_context = get_current_context()
                history_str = "\n".join([f"User: {h['q']}\nAgent: {h['a']}" for h in history])
                raw_prompt = (
                    f"{base_instruction}\n\n"
                    f"[PROJECT CONTEXT]\n{project_context}\n\n"
                    f"[RECENT HISTORY]\n{history_str}\n\n"
                    f"User: <Next Query>"
                )
                console.print(Panel(escape(raw_prompt), title="Full LLM Prompt Construction", border_style="red"))
                continue

            if cmd_parts[0] == "/save" and len(cmd_parts) > 1:
                args.session = cmd_parts[1]
                history_path = os.path.join(session_dir, f"{args.session}.json")
                save_history(history, history_path)
                console.print(f"[bold green]✔ Session saved to {args.session}.json[/bold green]")
                continue

            if cmd_parts[0] == "/load" and len(cmd_parts) > 1:
                target_session = cmd_parts[1]
                target_path = os.path.join(session_dir, f"{target_session}.json")
                if os.path.exists(target_path):
                    history = load_history(target_path)
                    args.session = target_session
                    history_path = target_path
                    console.print(f"[bold green]✔ Loaded session: {target_session}[/bold green]")
                else:
                    console.print(f"[bold red]✘ Session '{target_session}' not found.[/bold red]")
                continue

            if user_prompt.strip().lower() == "/tree":
                console.print(get_current_context())
                continue

            if user_prompt.strip().lower() == "/ctx":
                console.print(Panel(get_current_context(), title="Current Agent Context"))
                continue

            if user_prompt.strip().lower() == "/history":
                if not history:
                    console.print("[yellow]No history in current session.[/yellow]")
                else:
                    history_text = Text()
                    for entry in history:
                        history_text.append("User: ", style="bold cyan")
                        history_text.append(f"{entry['q']}\n")
                        history_text.append("Agent: ", style="bold green")
                        history_text.append(f"{entry['a']}\n\n")
                    console.print(Panel(history_text, title="Current Session History"))
                continue

            if user_prompt.strip().lower() == "/clear":
                history = []
                console.print("[bold green]✔ History cleared for the current session.[/bold green]")
                continue
            
            run_agent_loop(user_prompt, base_instruction, url, headers, args, history, history_path, api_key, session_vars, args.model)

def run_agent_loop(user_prompt, system_instruction, url, headers, args, history, history_path, api_key, session_vars, model_name):
    # Refresh context and summary at the start of every loop turn
    project_context = get_current_context()
    history_str = "\n".join([f"User: {h['q']}\nAgent: {h['a']}" for h in history])
    
    # Trigger summarization if history is long or character count suggests context pressure
    summary_block = ""
    if len(history) >= 10 or len(history_str) > 12000:
        console.print("[dim]Context window is filling up. Generating semantic summary...[/dim]")
        summary = summarize_history(history[:-3], api_key, model_name, url)
        summary_block = f"[PROJECT STATE SUMMARY]\n{summary}\n\n"
        # Keep only the last 3 for immediate conversational context
        history_str = "\n".join([f"User: {h['q']}\nAgent: {h['a']}" for h in history[-3:]])

    current_prompt = f"{system_instruction}\n\n[PROJECT CONTEXT]\n{project_context}\n\n{summary_block}[RECENT HISTORY]\n{history_str}\n\nUser: {user_prompt}"
    all_agent_responses = []
    iteration = 0
    max_iterations = 10
    tree_dirty = False

    total_prompt_tokens = 0
    total_completion_tokens = 0
    start_session_time = datetime.now()

    try:
        while iteration < max_iterations:
            iteration += 1
            payload = {
                "model": model_name, 
                "prompt": current_prompt, 
                "stream": True,
                "options": {
                    "num_ctx": 8192,
                    "temperature": 0.2  # Lower temperature for more precise CLI commands
                }
            }
            response = requests.post(url, headers=headers, json=payload, stream=True)
            response.raise_for_status()
            
            console.print(f"\n[bold cyan] Thinking...[/bold cyan]\n", end="")
            full_content = ""
            for line in response.iter_lines():
                if line:
                    chunk = json.loads(line.decode("utf-8"))
                    if "response" in chunk:
                        token = chunk["response"]
                        # Stream content directly
                        console.print(token, end="", style="italic green", markup=False)
                        full_content += token
                    if chunk.get("done"):
                        total_prompt_tokens += chunk.get("prompt_eval_count", 0)
                        total_completion_tokens += chunk.get("eval_count", 0)
            print()
            all_agent_responses.append(full_content)
            # Add the agent's reasoning to the prompt context for the next step
            current_prompt += f"\nAgent: {full_content}"
            
            # Find all potential tool calls in the response
            tool_calls = []
            for m in re.finditer(r"<execute_shell>(.*?)</execute_shell>", full_content, re.DOTALL):
                tool_calls.append(('shell', m.group(1).strip(), m.start()))
            for m in re.finditer(r"<execute>(.*?)</execute>", full_content, re.DOTALL):
                tool_calls.append(('exec', m.group(1).strip(), m.start()))
            for m in re.finditer(r"<search pattern=['\"](.*?)['\"] path=['\"](.*?)['\"]\s*/>", full_content):
                tool_calls.append(('search', (m.group(1), m.group(2)), m.start()))
            for m in re.finditer(r"<patch file=['\"](.*?)['\"]>(.*?)</patch>", full_content, re.DOTALL):
                tool_calls.append(('patch', (m.group(1), m.group(2)), m.start()))
            for m in re.finditer(r"<read_range file=['\"](.*?)['\"] start=['\"](\d+)['\"] end=['\"](\d+)['\"]\s*/>", full_content):
                tool_calls.append(('read', (m.group(1), int(m.group(2)), int(m.group(3))), m.start()))
            for m in re.finditer(r"<export name=['\"](.*?)['\"]>(.*?)</export>", full_content, re.DOTALL):
                tool_calls.append(('export', (m.group(1), m.group(2).strip()), m.start()))
            for m in re.finditer(r"<test path=['\"](.*?)['\"]\s*/>", full_content):
                tool_calls.append(('test', m.group(1), m.start()))
            for m in re.finditer(r"<lint file=['\"](.*?)['\"]\s*/>", full_content):
                tool_calls.append(('lint', m.group(1), m.start()))
            for m in re.finditer(r"<get_env name=['\"](.*?)['\"]\s*/>", full_content):
                tool_calls.append(('getenv', m.group(1), m.start()))
            for m in re.finditer(r"<analyze\s*/>", full_content):
                tool_calls.append(('analyze', None, m.start()))
            for m in re.finditer(r"<search_web query=['\"](.*?)['\"]\s*/>", full_content):
                tool_calls.append(('web_search', m.group(1), m.start()))
            for m in re.finditer(r"<browse_web url=['\"](.*?)['\"]\s*/>", full_content):
                tool_calls.append(('web_browse', m.group(1), m.start()))

            # Sort tool calls by their appearance in the response
            tool_calls.sort(key=lambda x: x[2])

            if not tool_calls:
                break

            executed_any = False
            for tool_type, data, _ in tool_calls:
                command = None
                use_shell = False

                if tool_type == 'shell':
                    command = data
                    use_shell = True
                elif tool_type == 'exec':
                    command = data
                    use_shell = False
                elif tool_type == 'patch':
                    filepath, diff_content = data
                    res = apply_patch(filepath, diff_content)
                    current_prompt += f"\n[SYSTEM: Patch Result]\n{res}\nNext step:"
                    tree_dirty = True
                    executed_any = True
                    continue
                elif tool_type == 'search':
                    pattern, path = data
                    res = search_codebase(pattern, path)
                    current_prompt += f"\n[SYSTEM: Search Results]\n{res}\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'read':
                    filepath, start, end = data
                    res = read_file_range(filepath, start, end)
                    
                    ext = filepath.split('.')[-1] if '.' in filepath else 'text'
                    syntax = Syntax(res, ext, theme="monokai", line_numbers=True, start_line=start)
                    console.print(Panel(syntax, title=f"File: {filepath} ({start}-{end})"))
                    
                    current_prompt += f"\n[SYSTEM: File Content (Lines {start}-{end}) for {filepath} received.]\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'export':
                    key, val = data
                    session_vars[key] = val.strip()
                    console.print(f"[bold magenta]󱐋 Session Var Set:[/bold magenta] {key}={session_vars[key]}")
                    current_prompt += f"\n[SYSTEM: Environment variable {key} updated.]\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'getenv':
                    key = data
                    val = session_vars.get(key, os.environ.get(key, "Not set"))
                    current_prompt += f"\n[SYSTEM: Environment variable {key}={val}]\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'test':
                    res = run_tests(data)
                    current_prompt += f"\n[SYSTEM: Test Results]\n{res}\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'lint':
                    res = lint_file(data)
                    current_prompt += f"\n[SYSTEM: Lint Results]\n{res}\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'analyze':
                    res = analyze_structure()
                    current_prompt += f"\n[SYSTEM: Project Structure Analysis]\n{res}\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'web_search':
                    res = web_search(data)
                    current_prompt += f"\n[SYSTEM: Web Search Results]\n{res}\nNext step:"
                    executed_any = True
                    continue
                elif tool_type == 'web_browse':
                    res = web_browse(data)
                    current_prompt += f"\n[SYSTEM: Web Page Content]\n{res}\nNext step:"
                    executed_any = True
                    continue

                # The Shield: Safety check for dangerous commands
                if is_dangerous(command) or not is_path_safe(command):
                    console.print(Panel(
                        f"[bold red]SECURITY ALERT:[/bold red] Unsafe command or path detected!\n"
                        f"Command: [bold cyan]{escape(command)}[/bold cyan]\n\n"
                        "Execution blocked for safety.",
                        title="[blink red]SECURITY BLOCK[/blink red]",
                        border_style="bold red"
                    ))
                    if not Confirm.ask("[bold red]Are you absolutely sure you want to run this?[/bold red]", default=False):
                        console.print("[bold yellow]! High-risk execution blocked by user.[/bold yellow]")
                        break

                # Determine if we should auto-execute based on mode
                should_prompt = True
                if args.mode == "auto":
                    should_prompt = False
                elif args.mode == "semi-auto":
                    if not is_filesystem_modifying(command) and not is_dangerous(command):
                        should_prompt = False

                if should_prompt:
                    mode_str = " (SHELL MODE)" if use_shell else ""
                    choice = Prompt.ask(
                        f"\n[bold yellow]󰆍 Agent suggests{mode_str}:[/bold yellow] [bold blue]{escape(command)}[/bold blue]\n[dim]([y]es/[n]o/[e]dit)[/dim]",
                        choices=["y", "n", "e"], default="y"
                    )
                    if choice == "n":
                        console.print("[bold yellow]! Execution skipped by user.[/bold yellow]")
                        break
                    if choice == "e":
                        command = Prompt.ask("[bold cyan]Edit command[/bold cyan]", default=command)
                
                if args.dry_run:
                    console.print(Panel(f"DRY RUN: Would execute [bold cyan]{escape(command)}[/bold cyan]", border_style="yellow"))
                    executed_any = True
                    continue
                
                console.print(Panel(f"Executing: [bold white]{escape(command)}[/bold white]", border_style="blue", title="System"))
                
                output_text = ""
                try:
                    cmd_args = command if use_shell else shlex.split(command)
                    start_time = datetime.now()
                    env = os.environ.copy()
                    env.update(session_vars)

                    process = subprocess.Popen(
                        cmd_args, shell=use_shell, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
                        text=True, bufsize=1, env=env
                    )
                    
                    console.print("[dim]Command Output:[/dim]")
                    with Live(Text(""), refresh_per_second=4) as live:
                        for line in process.stdout:
                            output_text += line
                            display_text = "\n".join(output_text.splitlines()[-10:])
                            live.update(Text(display_text))
                    
                    process.wait(timeout=30)
                    duration = (datetime.now() - start_time).total_seconds()
                    log_execution(command, process.returncode, duration, args.session)
                    
                    if process.returncode == 0:
                        console.print("[bold green]✔ Success.[/bold green]")
                        system_status = "Command result"
                    else:
                        console.print(f"[bold red]✘ Failed with code {process.returncode}[/bold red]")
                        system_status = f"Command failed with exit code {process.returncode}. Analyze the error below."
                    
                    tree_dirty = tree_dirty or is_filesystem_modifying(command)
                except subprocess.TimeoutExpired:
                    process.kill()
                    console.print("[bold red]✘ Command timed out (30s).[/bold red]")
                    output_text += "\n[ERROR: Process terminated due to timeout]"
                    system_status = "Command timed out."
                except Exception as e:
                    console.print(f"[bold red]✘ Execution error:[/bold red] {e}")
                    output_text += f"\n[ERROR: {e}]"
                    system_status = "Execution error"
                
                if len(output_text) > 4000:
                    output_text = output_text[:2000] + "\n... [Output truncated] ...\n" + output_text[-2000:]

                current_prompt += f"\n[SYSTEM: {system_status}]\n{output_text}\nNext step:"
                executed_any = True

            if tree_dirty:
                new_tree = get_directory_tree()
                current_prompt += f"\n[UPDATED PROJECT STRUCTURE]\n" + "\n".join(new_tree)

            if not executed_any:
                break

        if iteration >= max_iterations:
            console.print(Panel("[yellow]Maximum iteration limit reached for this request.[/yellow]", border_style="yellow"))

        # Display Metadata Summary
        end_session_time = datetime.now()
        total_duration = (end_session_time - start_session_time).total_seconds()
        
        summary_text = Text()
        summary_text.append(f"Total Iterations: ", style="bold white")
        summary_text.append(f"{iteration}\n", style="cyan")
        summary_text.append(f"Prompt Tokens: ", style="bold white")
        summary_text.append(f"{total_prompt_tokens} ", style="cyan")
        summary_text.append(f"| Completion Tokens: ", style="bold white")
        summary_text.append(f"{total_completion_tokens}\n", style="cyan")
        summary_text.append(f"Total Time: ", style="bold white")
        summary_text.append(f"{total_duration:.2f}s", style="cyan")

        console.print(Panel(summary_text, title="[bold magenta]Session Metadata[/bold magenta]", border_style="magenta"))

        # Save the cumulative interaction
        history.append({"q": user_prompt, "a": "\n".join(all_agent_responses)})
        save_history(history, history_path)

    except KeyboardInterrupt:
        console.print("\n[bold red]Operation cancelled by user.[/bold red]")
    except Exception as e:
        # Escape exception messages to prevent rich markup errors
        console.print(f"\n[bold red]Error occurred:[/bold red] {escape(str(e))}")

if __name__ == "__main__":
    main()
