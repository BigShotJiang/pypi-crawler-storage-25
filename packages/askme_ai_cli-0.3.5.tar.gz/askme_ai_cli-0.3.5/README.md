# askme-ai-cli

**askme-ai-cli** is a professional-grade, iterative CLI AI agent designed to act as a "doer" in your local development environment. Powered by [Ollama](https://ollama.com/), it combines advanced reasoning with the ability to execute shell commands, analyze project structures, and modify files directly.

## Key Features

- **Iterative Reasoning (ReAct Pattern):** The agent doesn't just provide one-shot answers. It analyzes requests, plans actions, observes command outputs, and refines its steps until the goal is achieved.
- **Local & Private:** Runs entirely on your local machine or private infrastructure using Ollama models (Gemma, Llama 3, Mistral, etc.).
- **Smart Execution Suite:**
    - `<execute>`: Handles standard commands safely.
    - `<execute_shell>`: Supports complex shell operations including pipes (`|`) and redirects (`>`).
    - `<patch>`: Applies unified diffs to files for precise code modifications without overwriting entire files.
- **Context Awareness:** Automatically generates directory trees and maintains a "State of the Project" summary to keep the LLM focused.
- **Security Shield:** Built-in protection against destructive commands (like `rm -rf /`) and unauthorized directory traversal.
- **Rich UI:** A clean, professional terminal interface powered by the `rich` library, featuring live output streaming and session metadata.

## Installation

Ensure you have Python 3.12+ installed, then install via pip:

```bash
pip install askme-ai-cli
```

## Requirements

1. **Ollama:** You must have Ollama installed and running on your system.
2. **Models:** By default, the agent looks for `gemma2:9b` (or your configured default). You can pull it using:
   ```bash
   ollama pull gemma2:9b
   ```
3. **API Key:** Set your `OLLAMA_API_KEY` in your environment or enter it when prompted.

## Usage

### Interactive Mode
Simply run the command to start a conversation with the agent:
```bash
askme
```

### One-Shot Task
Provide a prompt directly from the terminal:
```bash
askme -p "Create a new python script that fetches crypto prices and save it to crypto.py"
```

### Options
- `-m, --model`: Specify a custom Ollama model.
- `-s, --session`: Load or save a specific session history.
- `-d, --dry-run`: View proposed commands without executing them.

## License

This project is licensed under the MIT License.