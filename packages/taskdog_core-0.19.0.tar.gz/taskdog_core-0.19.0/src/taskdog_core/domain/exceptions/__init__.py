"""Domain exceptions."""
