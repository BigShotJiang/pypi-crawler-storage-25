"""Infrastructure layer - External dependencies."""
