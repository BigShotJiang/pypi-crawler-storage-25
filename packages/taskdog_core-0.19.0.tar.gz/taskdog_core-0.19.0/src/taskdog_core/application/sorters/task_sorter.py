"""Sorter for tasks."""

from collections.abc import Callable
from datetime import datetime
from typing import Any

from taskdog_core.domain.entities.task import Task
from taskdog_core.shared.constants import SORT_SENTINEL_FUTURE


class TaskSorter:
    """Sort tasks by multiple criteria.

    Supports sorting by different keys:
    - id: Task ID (ascending by default)
    - priority: Priority level (descending by default - higher priority first)
    - deadline: Deadline date (ascending by default - earlier deadlines first)
    - name: Task name (alphabetical, ascending by default)
    - status: Task status (alphabetical, ascending by default)
    - planned_start: Planned start date (ascending by default)
    - estimated_duration: Estimated duration in hours (ascending by default - shorter tasks first)

    Tasks with None values are sorted last for date/time/numeric fields.
    """

    def sort(
        self, tasks: list[Task], sort_by: str = "deadline", reverse: bool = False
    ) -> list[Task]:
        """Sort tasks by specified key.

        Args:
            tasks: List of tasks to sort
            sort_by: Sort key (id, priority, deadline, name, status, planned_start, estimated_duration)
            reverse: Reverse sort order (default: False)

        Returns:
            Sorted list of tasks

        Raises:
            ValueError: If sort_by is not a valid sort key
        """
        valid_keys = [
            "id",
            "priority",
            "deadline",
            "name",
            "status",
            "planned_start",
            "estimated_duration",
        ]
        if sort_by not in valid_keys:
            raise ValueError(f"Invalid sort_by: {sort_by}. Must be one of {valid_keys}")

        # Get the appropriate sort key function
        key_func = self._get_sort_key_function(sort_by)

        # Sort with the key function
        # Note: For priority, we want higher values first by default (reverse=True internally)
        # The reverse parameter inverts this behavior
        if sort_by == "priority":
            # Priority defaults to descending (reverse=True)
            # If user passes reverse=True, we want ascending (reverse=False)
            return sorted(tasks, key=key_func, reverse=not reverse)
        return sorted(tasks, key=key_func, reverse=reverse)

    def _get_sort_key_function(self, sort_by: str) -> Callable[[Task], Any]:
        """Get the sort key function for the specified sort key.

        Args:
            sort_by: Sort key name

        Returns:
            Function that extracts the sort key from a task
        """
        if sort_by == "id":
            return lambda task: task.id

        if sort_by == "priority":
            # Tasks with None priority are sorted last using tuple key
            # (0, priority) for tasks with priority, (1, 0) for tasks without
            # This ensures None-priority tasks always sort after prioritized tasks
            return lambda task: (
                (0, task.priority) if task.priority is not None else (1, 0)
            )

        if sort_by == "deadline":
            return lambda task: self._parse_date_for_sort(task.deadline)

        if sort_by == "name":
            return lambda task: task.name.lower()  # Case-insensitive sort

        if sort_by == "status":
            return lambda task: task.status.value

        if sort_by == "planned_start":
            return lambda task: self._parse_date_for_sort(task.planned_start)

        if sort_by == "estimated_duration":
            return lambda task: self._parse_numeric_for_sort(task.estimated_duration)

        # This should never happen due to validation in sort(), but required for type checking
        raise ValueError(f"Unsupported sort_by value: {sort_by}")

    def _parse_date_for_sort(self, dt: datetime | None) -> datetime:
        """Prepare datetime for sorting, with None values sorted last.

        Args:
            dt: Datetime object to prepare for sorting (or None)

        Returns:
            datetime object (far future date if None)
        """
        if dt is None:
            return SORT_SENTINEL_FUTURE
        return dt

    def _parse_numeric_for_sort(self, value: float | None) -> float:
        """Prepare numeric value for sorting, with None values sorted last.

        Args:
            value: Numeric value to prepare for sorting (or None)

        Returns:
            float value (infinity if None)
        """
        if value is None:
            return float("inf")
        return value
