"""User-friendly Queue API for SimpleBroker.

This module provides a simplified interface for working with individual message
queues without managing the underlying database connection.
"""

import logging
import threading
import weakref
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Union, cast

from ._backend_plugins import (
    ActivityWaiter,
    BackendAwareRunner,
    BackendPlugin,
    BrokerConnection,
    MultiQueueActivityWaiterHook,
    get_backend_plugin,
)
from ._constants import DEFAULT_DB_NAME, PEEK_BATCH_SIZE, load_config, resolve_config
from ._runner import SQLRunner
from ._targets import ResolvedTarget
from .db import DBConnection
from .metadata import QueueStats
from .project import target_for_directory

logger = logging.getLogger(__name__)

# Load configuration once at module level
_config = load_config()

_FrozenValue = (
    tuple[tuple[str, "_FrozenValue"], ...]
    | tuple["_FrozenValue", ...]
    | str
    | int
    | float
    | bool
    | None
)


@dataclass(frozen=True)
class _ActivityWaiterIdentity:
    plugin: BackendPlugin
    backend_name: str
    target_key: str | None
    backend_options_key: _FrozenValue
    runner_id: int | None
    target_arg: str | None
    backend_options_arg: dict[str, Any] | None
    runner_arg: SQLRunner | None

    @property
    def compatibility_key(self) -> tuple[str, str | None, _FrozenValue, int | None]:
        return (
            self.backend_name,
            self.target_key,
            self.backend_options_key,
            self.runner_id,
        )


def _freeze_for_waiter_identity(value: Any) -> _FrozenValue:
    """Freeze common option structures for backend identity comparison."""

    if isinstance(value, Mapping):
        return tuple(
            (str(key), _freeze_for_waiter_identity(item))
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        )
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_for_waiter_identity(item) for item in value)
    if isinstance(value, set):
        return tuple(
            sorted((_freeze_for_waiter_identity(item) for item in value), key=repr)
        )
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return repr(value)


def _normalize_sqlite_waiter_target(target: str) -> str:
    path = Path(target).expanduser()
    try:
        return str(path.resolve())
    except (OSError, ValueError):
        return str(path)


def _default_target_from_config(config: dict[str, Any]) -> ResolvedTarget:
    """Resolve the implicit Queue target from caller-provided configuration."""

    root = (
        Path(str(config["BROKER_DEFAULT_DB_LOCATION"]))
        if config.get("BROKER_DEFAULT_DB_LOCATION")
        and config.get("BROKER_BACKEND", "sqlite") == "sqlite"
        else Path.cwd()
    )
    return target_for_directory(root, config=config)


class Queue:
    """A user-friendly handle to a specific message queue.

    This class provides a simpler API for working with a single queue.
    By default, uses ephemeral connections (created per operation) for
    maximum safety and minimal lock contention. Set persistent=True for
    performance-critical scenarios where connection overhead matters.
    Persistent Queue handles for the same resolved backend target share
    process-local backend session state. Backends may still create separate
    physical connections per thread or per pool checkout.

    Args:
        name: The name of the queue
        db_path: Path or target for the broker database. ``None`` or ``""``
            resolves the target from configuration.
        persistent: If True, use process-local persistent session state for the
            resolved target. If False (default), use ephemeral connections.
        runner: Optional custom SQLRunner implementation for extensions

    Examples:
        >>> # Default ephemeral mode - recommended for most users
        >>> queue = Queue("tasks")
        >>> queue.write("Process order #123")
        >>> message = queue.read()
        >>> print(message)
        Process order #123

        >>> # Natural string representation
        >>> print(f"Processing {queue}")
        Processing tasks
        >>> logger.info(f"Watching {queue}...")
        INFO: Watching tasks...

        >>> # Debugging representation
        >>> repr(queue)
        Queue('tasks')
        >>> Queue("logs", db_path="/custom/path.db", persistent=True)
        Queue('logs', db_path='/custom/path.db', persistent=True)

        >>> # Persistent mode - for performance-critical code
        >>> with Queue("tasks", persistent=True) as queue:
        ...     for i in range(10000):
        ...         queue.write(f"task_{i}")
    """

    # Type annotations for instance attributes
    conn: DBConnection | None

    def __init__(
        self,
        name: str,
        *,
        db_path: str | ResolvedTarget | None = None,
        persistent: bool = False,
        runner: SQLRunner | None = None,
        config: dict[str, Any] | None = None,
    ):
        """Initialize a Queue instance.

        Args:
            name: The name of the queue
            db_path: Path or target for the broker database. ``None`` or ``""``
                resolves the target from configuration.
            persistent: If True, maintain a persistent connection.
                       If False (default), use ephemeral connections.
            runner: Optional custom SQLRunner implementation for extensions.
                    Injected runners are caller-owned and are reused for the
                    lifetime of this Queue object.
        """
        self.name = name
        self._persistent = persistent
        self._runner = runner
        self._config = resolve_config(config)
        self._uses_config_default_target = db_path is None or db_path == ""
        if self._uses_config_default_target:
            resolved_db_path: str | ResolvedTarget = _default_target_from_config(
                self._config
            )
        else:
            assert db_path is not None
            resolved_db_path = db_path
        self._db_path: str | ResolvedTarget = resolved_db_path
        self._stop_event: threading.Event | None = None

        # Create DBConnection for persistent queues and injected-runner queues.
        # The built-in no-runner path keeps its current "get in, get out"
        # semantics only when persistent=False.
        if persistent or runner is not None:
            self.conn = DBConnection(
                self._db_path,
                runner,
                config=self._config,
                share_in_process=persistent and runner is None,
            )
        else:
            self.conn = None

        # Install finalizer for cleanup
        self._install_finalizer()

        # Cached last generated timestamp (meta.last_ts)
        self._last_ts: int | None = None
        self._activity_waiter: ActivityWaiter | None = None

    @property
    def db_target(self) -> str | ResolvedTarget:
        """Return the configured broker target for this queue."""

        return self._db_path

    @contextmanager
    def get_connection(self) -> Iterator[BrokerConnection]:
        """Get connection for operations - handles both persistent and ephemeral modes.

        This context manager consolidates the connection logic. It yields a
        persistent queue connection/session lease when available, or creates a
        new connection on the fly for the no-runner ephemeral path.

        Yields:
            BrokerConnection: Connection object for database operations
        """
        if self.conn is not None:
            assert self.conn is not None  # Type guard for mypy
            self.conn.set_stop_event(self._stop_event)
            try:
                yield self.conn.get_connection()
            finally:
                self.conn.release_connection_after_use()
        else:
            with DBConnection(self._db_path, self._runner, config=self._config) as conn:
                conn.set_stop_event(self._stop_event)
                yield conn.get_connection()

    def set_stop_event(self, stop_event: threading.Event | None) -> None:
        """Propagate stop event to connections used by this queue."""

        self._stop_event = stop_event
        if self.conn is not None:
            self.conn.set_stop_event(stop_event)

    @property
    def last_ts(self) -> int | None:
        """Return cached meta.last_ts, fetching lazily on first access."""

        if self._last_ts is None:
            try:
                with self.get_connection() as connection:
                    try:
                        self._last_ts = connection.get_cached_last_timestamp()
                    except AttributeError:
                        # Older runners without hint support
                        self._last_ts = connection.refresh_last_timestamp()
            except Exception:
                # Cache remains None; caller can use refresh_last_ts explicitly
                return None

        return self._last_ts

    def refresh_last_ts(self) -> int:
        """Refresh cached last timestamp using a lightweight meta-table read."""

        with self.get_connection() as connection:
            latest = connection.refresh_last_timestamp()
        self._last_ts = latest
        return latest

    def _update_last_ts_hint(self, connection: BrokerConnection) -> None:
        """Update cached last_ts using the connection's generator state."""

        if self._last_ts is None:
            return

        try:
            candidate = connection.get_cached_last_timestamp()
        except AttributeError:
            return
        self._last_ts = candidate

    def _observe_timestamp(self, timestamp: int) -> None:
        """Advance cached last_ts based on an observed message timestamp."""

        if self._last_ts is None or timestamp > self._last_ts:
            self._last_ts = timestamp

    def write(self, message: str) -> None:
        """Write a message to this queue.

        Args:
            message: The message content to write

        Raises:
            QueueNameError: If the queue name is invalid
            MessageError: If the message is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            connection.write(self.name, message)
            self._update_last_ts_hint(connection)

    def generate_timestamp(self) -> int:
        """Generate a broker-compatible timestamp using the underlying database.

        Returns:
            64-bit hybrid timestamp unique within the database.
        """
        with self.get_connection() as connection:
            timestamp = connection.generate_timestamp()
            self._last_ts = timestamp
            return timestamp

    # Convenience alias
    get_ts = generate_timestamp

    def read(
        self,
        *,
        all_messages: bool = False,
        with_timestamps: bool = False,
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        message_id: int | None = None,
    ) -> str | tuple[str, int] | Iterator[str | tuple[str, int]] | None:
        """Read and remove message(s) from the queue (CLI-mirroring method).

        This is the high-level method that mirrors CLI behavior. For more precise
        control, use the granular methods: read_one(), read_many(), read_generator().

        Args:
            all_messages: If True, read all messages as a generator
            with_timestamps: If True, include timestamps in results
            after_timestamp: Only read messages newer than this timestamp
            before_timestamp: Only read messages older than this timestamp
            message_id: Read specific message by ID (cannot be used with other filters)

        Returns:
            Depends on parameters:
            - Single message (str or tuple) if all_messages=False
            - Generator if all_messages=True
            - None if no messages match criteria

        Raises:
            ValueError: If conflicting parameters are provided
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        has_range_filter = after_timestamp is not None or before_timestamp is not None
        if message_id is not None and (all_messages or has_range_filter):
            raise ValueError(
                "message_id cannot be used with all_messages, after_timestamp, "
                "or before_timestamp"
            )

        if message_id is not None:
            # Read specific message by ID
            return self.read_one(
                exact_timestamp=message_id, with_timestamps=with_timestamps
            )
        elif all_messages:
            # Return generator for all messages
            return self.read_generator(
                with_timestamps=with_timestamps,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
            )
        else:
            # Read single message
            if has_range_filter:
                # Need to use generator with limit 1 for range-filter support
                gen = self.read_generator(
                    with_timestamps=with_timestamps,
                    after_timestamp=after_timestamp,
                    before_timestamp=before_timestamp,
                )
                try:
                    return next(gen)
                except StopIteration:
                    return None
            else:
                return self.read_one(with_timestamps=with_timestamps)

    # ========== Granular Read API (maps to internal claim methods) ==========

    def read_one(
        self, *, exact_timestamp: int | None = None, with_timestamps: bool = False
    ) -> str | tuple[str, int] | None:
        """Read and remove exactly one message from the queue.

        This method provides exactly-once delivery semantics: the message is
        committed before being returned.

        Args:
            exact_timestamp: If provided, read only message with this timestamp
            with_timestamps: If True, return (message, timestamp) tuple

        Returns:
            Message string or (message, timestamp) tuple if with_timestamps=True,
            None if queue is empty or message not found

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            return connection.claim_one(
                self.name,
                exact_timestamp=exact_timestamp,
                with_timestamps=with_timestamps,
            )

    def read_many(
        self,
        limit: int,
        *,
        with_timestamps: bool = False,
        delivery_guarantee: Literal["exactly_once", "at_least_once"] = "exactly_once",
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
    ) -> list[str] | list[tuple[str, int]]:
        """Read and remove multiple messages from the queue.

        Args:
            limit: Maximum number of messages to read
            with_timestamps: If True, return list of (message, timestamp) tuples
            delivery_guarantee: Delivery contract for materializing messages.
                Materialized batch APIs commit before returning, so
                ``"at_least_once"`` is satisfied by the stricter exactly-once
                behavior. Use ``read_generator()`` when you need retry-on-stop
                batch processing.
            after_timestamp: Only read messages newer than this timestamp
            before_timestamp: Only read messages older than this timestamp

        Returns:
            list of messages or list of (message, timestamp) tuples if with_timestamps=True

        Raises:
            ValueError: If limit < 1
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            return connection.claim_many(
                self.name,
                limit,
                with_timestamps=with_timestamps,
                delivery_guarantee=delivery_guarantee,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
            )

    def read_generator(
        self,
        *,
        with_timestamps: bool = False,
        delivery_guarantee: Literal["exactly_once", "at_least_once"] = "exactly_once",
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        exact_timestamp: int | None = None,
    ) -> Iterator[str | tuple[str, int]]:
        """Generator that reads and removes messages from the queue.

        This is memory-efficient for processing large queues.

        Args:
            with_timestamps: If True, yield (message, timestamp) tuples
            delivery_guarantee: Delivery semantics
                - exactly_once: Process one message at a time (safer, slower)
                - at_least_once: Commit each batch after it is fully yielded
            after_timestamp: Only read messages newer than this timestamp
            before_timestamp: Only read messages older than this timestamp
            exact_timestamp: Only read message with this exact timestamp

        Yields:
            Messages or (message, timestamp) tuples if with_timestamps=True

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            yield from connection.claim_generator(
                self.name,
                with_timestamps=with_timestamps,
                delivery_guarantee=delivery_guarantee,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
                exact_timestamp=exact_timestamp,
            )

    def peek(
        self,
        *,
        all_messages: bool = False,
        with_timestamps: bool = False,
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        message_id: int | None = None,
    ) -> str | tuple[str, int] | Iterator[str | tuple[str, int]] | None:
        """View message(s) without removing them from the queue (CLI-mirroring method).

        This is the high-level method that mirrors CLI behavior. For more precise
        control, use the granular methods: peek_one(), peek_many(), peek_generator().

        Args:
            all_messages: If True, peek at all messages as a generator
            with_timestamps: If True, include timestamps in results
            after_timestamp: Only peek at messages newer than this timestamp
            before_timestamp: Only peek at messages older than this timestamp
            message_id: Peek at specific message by ID (cannot be used with other filters)

        Returns:
            Depends on parameters:
            - Single message (str or tuple) if all_messages=False
            - Generator if all_messages=True
            - None if no messages match criteria

        Raises:
            ValueError: If conflicting parameters are provided
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        has_range_filter = after_timestamp is not None or before_timestamp is not None
        if message_id is not None and (all_messages or has_range_filter):
            raise ValueError(
                "message_id cannot be used with all_messages, after_timestamp, "
                "or before_timestamp"
            )

        if message_id is not None:
            # Peek at specific message by ID
            return self.peek_one(
                exact_timestamp=message_id, with_timestamps=with_timestamps
            )
        elif all_messages:
            # Return generator for all messages
            return self.peek_generator(
                with_timestamps=with_timestamps,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
            )
        else:
            # Peek at single message
            if has_range_filter:
                # Need to use generator with limit 1 for range-filter support
                gen = self.peek_generator(
                    with_timestamps=with_timestamps,
                    after_timestamp=after_timestamp,
                    before_timestamp=before_timestamp,
                )
                try:
                    return next(gen)
                except StopIteration:
                    return None
            else:
                return self.peek_one(with_timestamps=with_timestamps)

    # ========== Granular Peek API ==========

    def peek_one(
        self, *, exact_timestamp: int | None = None, with_timestamps: bool = False
    ) -> str | tuple[str, int] | None:
        """Peek at exactly one message without removing it from the queue.

        Args:
            exact_timestamp: If provided, peek only at message with this timestamp
            with_timestamps: If True, return (message, timestamp) tuple

        Returns:
            Message string or (message, timestamp) tuple if with_timestamps=True,
            None if queue is empty or message not found

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            return connection.peek_one(
                self.name,
                exact_timestamp=exact_timestamp,
                with_timestamps=with_timestamps,
            )

    def peek_many(
        self,
        limit: int = PEEK_BATCH_SIZE,
        *,
        with_timestamps: bool = False,
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
    ) -> list[str] | list[tuple[str, int]]:
        """Peek at multiple messages without removing them from the queue.

        Args:
            limit: Maximum number of messages to peek at (default: 1000)
            with_timestamps: If True, return list of (message, timestamp) tuples
            after_timestamp: Only peek at messages newer than this timestamp
            before_timestamp: Only peek at messages older than this timestamp

        Returns:
            list of messages or list of (message, timestamp) tuples if with_timestamps=True

        Raises:
            ValueError: If limit < 1
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            return connection.peek_many(
                self.name,
                limit,
                with_timestamps=with_timestamps,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
            )

    def peek_generator(
        self,
        *,
        with_timestamps: bool = False,
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        exact_timestamp: int | None = None,
    ) -> Iterator[str | tuple[str, int]]:
        """Generator that peeks at messages without removing them from the queue.

        This is memory-efficient for viewing large queues.

        Args:
            with_timestamps: If True, yield (message, timestamp) tuples
            after_timestamp: Only peek at messages newer than this timestamp
            before_timestamp: Only peek at messages older than this timestamp
            exact_timestamp: Only peek at message with this exact timestamp

        Yields:
            Messages or (message, timestamp) tuples if with_timestamps=True

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            yield from connection.peek_generator(
                self.name,
                with_timestamps=with_timestamps,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
                exact_timestamp=exact_timestamp,
            )

    def move(
        self,
        destination: Union[str, "Queue"],
        *,
        message_id: int | None = None,
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        all_messages: bool = False,
    ) -> dict[str, Any] | None | list[dict[str, Any]] | Iterator[dict[str, Any]]:
        """Move messages from this queue to another (CLI-mirroring method).

        This is the high-level method that mirrors CLI behavior. For more precise
        control, use the granular methods: move_one(), move_many(), move_generator().

        Args:
            destination: Target queue (name or Queue instance).
            message_id: If provided, move only this specific message.
            after_timestamp: If provided, only move messages newer than this timestamp.
            before_timestamp: If provided, only move messages older than this timestamp.
            all_messages: If True, move all messages. Cannot be used with message_id.

        Returns:
            Depends on parameters:
            - Single dict with 'message' and 'timestamp' if moving one message
            - list of dicts if moving many messages with limit
            - Generator of dicts if all_messages=True
            - None if no messages to move

        Raises:
            ValueError: If source and destination are the same, or if conflicting options are used.
            QueueNameError: If queue names are invalid
            OperationalError: If the database is locked/busy
        """
        # Get destination queue name
        dest_name = destination.name if isinstance(destination, Queue) else destination

        # Check for same source and destination
        if self.name == dest_name:
            raise ValueError("Source and destination queues cannot be the same")

        # Check for conflicting options
        has_range_filter = after_timestamp is not None or before_timestamp is not None
        if message_id is not None and (all_messages or has_range_filter):
            raise ValueError(
                "message_id cannot be used with all_messages, after_timestamp, "
                "or before_timestamp"
            )

        if message_id is not None:
            # Move specific message by ID
            result = self.move_one(
                dest_name,
                exact_timestamp=message_id,
                require_unclaimed=False,  # Allow moving claimed messages by ID
                with_timestamps=True,
            )
            if result:
                return {"message": result[0], "timestamp": result[1]}
            return None
        elif all_messages:
            # Return generator for all messages
            def dict_generator() -> Iterator[dict[str, Any]]:
                for result in self.move_generator(
                    dest_name,
                    with_timestamps=True,
                    after_timestamp=after_timestamp,
                    before_timestamp=before_timestamp,
                ):
                    msg, ts = cast(tuple[str, int], result)
                    yield {"message": msg, "timestamp": ts}

            return dict_generator()
        else:
            # Move single message
            if has_range_filter:
                # Use generator with single iteration for range-filter support
                gen = self.move_generator(
                    dest_name,
                    with_timestamps=True,
                    after_timestamp=after_timestamp,
                    before_timestamp=before_timestamp,
                )
                try:
                    result = next(gen)
                    msg, ts = cast(tuple[str, int], result)
                    return {"message": msg, "timestamp": ts}
                except StopIteration:
                    return None
            else:
                result = self.move_one(dest_name, with_timestamps=True)
                if result:
                    return {"message": result[0], "timestamp": result[1]}
                return None

    # ========== Granular Move API ==========

    def move_one(
        self,
        destination: Union[str, "Queue"],
        *,
        exact_timestamp: int | None = None,
        require_unclaimed: bool = True,
        with_timestamps: bool = False,
    ) -> str | tuple[str, int] | None:
        """Move exactly one message from this queue to another.

        Atomic operation with exactly-once semantics.

        Args:
            destination: Target queue (name or Queue instance)
            exact_timestamp: If provided, move only message with this timestamp
            require_unclaimed: If True (default), only move unclaimed messages.
                             If False, move any message (including claimed).
            with_timestamps: If True, return (message, timestamp) tuple

        Returns:
            Message string or (message, timestamp) tuple if with_timestamps=True,
            None if no messages to move or message not found

        Raises:
            ValueError: If source and destination are the same
            QueueNameError: If queue names are invalid
            OperationalError: If the database is locked/busy
        """
        dest_name = destination.name if isinstance(destination, Queue) else destination
        if self.name == dest_name:
            raise ValueError("Source and destination queues cannot be the same")

        with self.get_connection() as connection:
            return connection.move_one(
                self.name,
                dest_name,
                exact_timestamp=exact_timestamp,
                require_unclaimed=require_unclaimed,
                with_timestamps=with_timestamps,
            )

    def move_many(
        self,
        destination: Union[str, "Queue"],
        limit: int,
        *,
        with_timestamps: bool = False,
        delivery_guarantee: Literal["exactly_once", "at_least_once"] = "exactly_once",
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        require_unclaimed: bool = True,
    ) -> list[str] | list[tuple[str, int]]:
        """Move multiple messages from this queue to another.

        Atomic materialized batch move operation.

        Args:
            destination: Target queue (name or Queue instance)
            limit: Maximum number of messages to move
            with_timestamps: If True, return list of (message, timestamp) tuples
            delivery_guarantee: Delivery contract for materializing messages.
                Materialized batch APIs commit before returning, so
                ``"at_least_once"`` is satisfied by the stricter exactly-once
                behavior. Use ``move_generator()`` when you need retry-on-stop
                batch processing.
            after_timestamp: Only move messages newer than this timestamp
            before_timestamp: Only move messages older than this timestamp
            require_unclaimed: If True (default), only move unclaimed messages

        Returns:
            list of messages or list of (message, timestamp) tuples if with_timestamps=True

        Raises:
            ValueError: If source and destination are the same or limit < 1
            QueueNameError: If queue names are invalid
            OperationalError: If the database is locked/busy
        """
        dest_name = destination.name if isinstance(destination, Queue) else destination
        if self.name == dest_name:
            raise ValueError("Source and destination queues cannot be the same")

        with self.get_connection() as connection:
            return connection.move_many(
                self.name,
                dest_name,
                limit,
                with_timestamps=with_timestamps,
                delivery_guarantee=delivery_guarantee,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
                require_unclaimed=require_unclaimed,
            )

    def move_generator(
        self,
        destination: Union[str, "Queue"],
        *,
        with_timestamps: bool = False,
        delivery_guarantee: Literal["exactly_once", "at_least_once"] = "exactly_once",
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        exact_timestamp: int | None = None,
    ) -> Iterator[str | tuple[str, int]]:
        """Generator that moves messages from this queue to another.

        Args:
            destination: Target queue (name or Queue instance)
            with_timestamps: If True, yield (message, timestamp) tuples
            delivery_guarantee: Delivery semantics
                - exactly_once: Process one message at a time (safer, slower)
                - at_least_once: Commit each batch after it is fully yielded
            after_timestamp: Only move messages newer than this timestamp
            before_timestamp: Only move messages older than this timestamp
            exact_timestamp: Only move message with this exact timestamp

        Yields:
            Messages or (message, timestamp) tuples if with_timestamps=True

        Raises:
            ValueError: If source and destination are the same
            QueueNameError: If queue names are invalid
            OperationalError: If the database is locked/busy
        """
        dest_name = destination.name if isinstance(destination, Queue) else destination
        if self.name == dest_name:
            raise ValueError("Source and destination queues cannot be the same")

        with self.get_connection() as connection:
            yield from connection.move_generator(
                self.name,
                dest_name,
                with_timestamps=with_timestamps,
                delivery_guarantee=delivery_guarantee,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
                exact_timestamp=exact_timestamp,
            )

    def delete(self, *, message_id: int | None = None) -> bool:
        """Delete messages from this queue.

        Args:
            message_id: If provided, delete only the message with this specific ID.
                       If None, delete all messages in the queue.

        Returns:
            True if any messages were deleted, False otherwise.
            When message_id is provided, returns True only if that specific message was found and deleted.

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            if message_id is not None:
                return connection.delete_message_ids(self.name, [message_id]) > 0
            else:
                # Delete all messages in the queue
                return connection.delete(self.name) > 0

    def delete_many(self, message_ids: Sequence[int]) -> int:
        """Physically delete exact message IDs from this queue.

        Claimed and unclaimed messages are both eligible for deletion. Missing
        IDs and IDs belonging to other queues are ignored.

        Args:
            message_ids: Message IDs to delete from this queue.

        Returns:
            Number of messages physically deleted.

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            return connection.delete_message_ids(self.name, message_ids)

    def __enter__(self) -> "Queue":
        """Enter the context manager."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit the context manager and close the runner."""
        self.close()

    def __str__(self) -> str:
        """Human-readable string representation.

        Returns just the queue name for natural usage in logs and messages.

        Examples:
            >>> queue = Queue("tasks")
            >>> print(f"Processing {queue}")
            Processing tasks
            >>> logger.info(f"Watching {queue}")
            INFO: Watching tasks
        """
        return self.name

    def __repr__(self) -> str:
        """Developer-friendly representation for debugging.

        Returns a string that could recreate the object (when possible).

        Examples:
            >>> Queue("tasks")
            Queue('tasks')
            >>> Queue("logs", db_path="/var/db/app.db")
            Queue('logs', db_path='/var/db/app.db')
        """
        parts = [f"'{self.name}'"]

        db_repr = (
            self._db_path.target
            if isinstance(self._db_path, ResolvedTarget)
            else self._db_path
        )
        if not self._uses_config_default_target and db_repr != DEFAULT_DB_NAME:
            parts.append(f"db_path='{db_repr}'")
        if self._persistent:
            parts.append("persistent=True")

        return f"Queue({', '.join(parts)})"

    def has_pending(self, after_timestamp: int | None = None) -> bool:
        """Check if this queue has pending (unclaimed) messages.

        Args:
            after_timestamp: If provided, only check for messages newer than this timestamp.

        Returns:
            True if there are unclaimed messages, False otherwise.

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            return connection.has_pending_messages(self.name, after_timestamp)

    def exists(self) -> bool:
        """Return whether this queue has any messages, including claimed rows."""
        with self.get_connection() as connection:
            return connection.queue_exists(self.name)

    def stats(self) -> QueueStats:
        """Return pending, claimed, and total counts for this queue."""
        with self.get_connection() as connection:
            return connection.get_queue_stat(self.name)

    def get_data_version(self) -> int | None:
        """Get the database data version for change detection.

        Returns:
            Integer version if available, None for non-SQLite backends or errors.

        Notes:
            This is SQLite-specific and used for efficient polling to detect
            when the database has been modified by other processes.
        """
        with self.get_connection() as connection:
            return connection.get_data_version()

    def create_activity_waiter(
        self,
        *,
        stop_event: threading.Event,
    ) -> ActivityWaiter | None:
        """Create or reuse a backend-native waiter for watcher wakeups."""
        if self._activity_waiter is not None:
            return self._activity_waiter

        identity = self._activity_waiter_identity()

        waiter = identity.plugin.create_activity_waiter(
            target=identity.target_arg,
            backend_options=identity.backend_options_arg,
            runner=identity.runner_arg,
            queue_name=self.name,
            stop_event=stop_event,
        )
        if waiter is not None:
            self._activity_waiter = waiter
        return waiter

    def _activity_waiter_identity(self) -> _ActivityWaiterIdentity:
        """Return backend identity and hook arguments for activity waiters."""

        if self._runner is not None:
            if isinstance(self._runner, BackendAwareRunner):
                plugin = self._runner.backend_plugin
                backend_name = plugin.name
            elif isinstance(self._db_path, ResolvedTarget):
                plugin = self._db_path.plugin
                backend_name = self._db_path.backend_name
            else:
                plugin = get_backend_plugin("sqlite")
                backend_name = "sqlite"
            return _ActivityWaiterIdentity(
                plugin=plugin,
                backend_name=backend_name,
                target_key=None,
                backend_options_key=None,
                runner_id=id(self._runner),
                target_arg=None,
                backend_options_arg=None,
                runner_arg=self._runner,
            )

        if isinstance(self._db_path, ResolvedTarget):
            plugin = self._db_path.plugin
            target = self._db_path.target
            target_key = (
                _normalize_sqlite_waiter_target(target)
                if self._db_path.backend_name == "sqlite"
                else target
            )
            backend_options = dict(self._db_path.backend_options)
            return _ActivityWaiterIdentity(
                plugin=plugin,
                backend_name=self._db_path.backend_name,
                target_key=f"resolved:{target_key}",
                backend_options_key=_freeze_for_waiter_identity(backend_options),
                runner_id=None,
                target_arg=target,
                backend_options_arg=backend_options,
                runner_arg=None,
            )

        target = str(self._db_path)
        return _ActivityWaiterIdentity(
            plugin=get_backend_plugin("sqlite"),
            backend_name="sqlite",
            target_key=f"plain:{_normalize_sqlite_waiter_target(target)}",
            backend_options_key=_freeze_for_waiter_identity({}),
            runner_id=None,
            target_arg=target,
            backend_options_arg=None,
            runner_arg=None,
        )

    def stream_messages(
        self,
        *,
        peek: bool = False,
        all_messages: bool = True,
        after_timestamp: int | None = None,
        before_timestamp: int | None = None,
        batch_processing: bool = False,
        commit_interval: int = 1,
    ) -> Iterator[tuple[str, int]]:
        """Stream messages with timestamps from the queue.

        This is an iterator that yields messages as they are retrieved from the database.
        It's more memory-efficient than read_all for large queues.

        Args:
            peek: If True, don't remove messages from queue
            all_messages: If True, stream all available messages. If False, yield at
                         most one message.
            after_timestamp: Only retrieve messages newer than this timestamp
            before_timestamp: Only retrieve messages older than this timestamp
            batch_processing: If True and peek=False, allow at-least-once batch
                             processing. If False, consume one message at a time.
            commit_interval: Batch size for at-least-once processing when
                            batch_processing=True and peek=False. Ignored otherwise.

        Yields:
            tuples of (message_body, timestamp)

        Raises:
            QueueNameError: If the queue name is invalid
            OperationalError: If the database is locked/busy
        """
        with self.get_connection() as connection:
            if peek:
                if all_messages:
                    # Type assertion after we know with_timestamps=True yields tuple[str, int]
                    for result in connection.peek_generator(
                        self.name,
                        with_timestamps=True,
                        after_timestamp=after_timestamp,
                        before_timestamp=before_timestamp,
                    ):
                        yield result  # type: ignore[misc]
                else:
                    generator = connection.peek_generator(
                        self.name,
                        with_timestamps=True,
                        after_timestamp=after_timestamp,
                        before_timestamp=before_timestamp,
                    )
                    try:
                        result = next(generator)
                    except StopIteration:
                        return
                    else:
                        assert isinstance(result, tuple)
                        yield result
                    finally:
                        close_generator = getattr(generator, "close", None)
                        if callable(close_generator):
                            close_generator()
                return

            if not all_messages:
                generator = connection.claim_generator(
                    self.name,
                    with_timestamps=True,
                    delivery_guarantee="exactly_once",
                    after_timestamp=after_timestamp,
                    before_timestamp=before_timestamp,
                )
                try:
                    result = next(generator)
                except StopIteration:
                    return
                else:
                    assert isinstance(result, tuple)
                    yield result
                finally:
                    close_generator = getattr(generator, "close", None)
                    if callable(close_generator):
                        close_generator()
                return

            delivery_guarantee: Literal["exactly_once", "at_least_once"] = (
                "at_least_once"
                if batch_processing and commit_interval > 1
                else "exactly_once"
            )
            batch_size = (
                commit_interval if delivery_guarantee == "at_least_once" else None
            )

            # Type assertion after we know with_timestamps=True yields tuple[str, int]
            for result in connection.claim_generator(
                self.name,
                with_timestamps=True,
                delivery_guarantee=delivery_guarantee,
                batch_size=batch_size,
                after_timestamp=after_timestamp,
                before_timestamp=before_timestamp,
            ):
                yield result  # type: ignore[misc]

    def cleanup_connections(self) -> None:
        """Clean up active database handles without releasing the queue lease.

        Watchers use this during stop/error recovery. The queue remains usable
        afterward; call close() to release persistent session ownership.
        """
        if self.conn:
            self.conn.cleanup()
        if self._activity_waiter is not None:
            self._activity_waiter.close()
            self._activity_waiter = None
        if hasattr(self, "_watcher_conn"):
            self._watcher_conn.cleanup()
            delattr(self, "_watcher_conn")

    def close(self) -> None:
        """Close the queue and release resources.

        This is called automatically when using the queue as a context manager.
        In ephemeral mode, this is a no-op as connections are closed after each
        operation.
        """
        if self._activity_waiter is not None:
            self._activity_waiter.close()
            self._activity_waiter = None
        if self.conn:
            if hasattr(self, "_finalizer"):
                self._finalizer.detach()
            self.conn.close()

    # ========== Persistent Mode Helpers ==========

    def _install_finalizer(self) -> None:
        """Install weakref finalizer for cleanup."""

        def cleanup(
            conn: DBConnection | None,
            config: dict[str, Any] | None,
            watcher_conn_attr: str,
        ) -> None:
            """Cleanup function called by finalizer."""
            if config is None:
                config = _config
            try:
                if conn:
                    conn.close()
                # Note: watcher_conn cleanup happens in cleanup_connections
            except Exception as e:
                if config.get("BROKER_LOGGING_ENABLED", True):
                    logger.warning(f"Error during Queue finalizer cleanup: {e}")

        # Install finalizer with reference to connection
        self._finalizer = weakref.finalize(
            self, cleanup, self.conn, self._config, "_watcher_conn"
        )


def create_activity_waiter_for_queues(
    queues: Sequence[Queue],
    *,
    stop_event: threading.Event,
) -> ActivityWaiter | None:
    """Create one backend-native waiter for activity across multiple queues."""

    queue_list = list(queues)
    if not queue_list:
        raise ValueError("queues cannot be empty")

    identities = [queue._activity_waiter_identity() for queue in queue_list]
    first_identity = identities[0]
    first_key = first_identity.compatibility_key
    for identity in identities[1:]:
        if identity.compatibility_key != first_key:
            raise ValueError("queues cannot safely share one activity waiter")

    queue_names = tuple(dict.fromkeys(queue.name for queue in queue_list))
    create_waiter = getattr(
        first_identity.plugin,
        "create_activity_waiter_for_queues",
        None,
    )
    if create_waiter is None:
        return None
    if not callable(create_waiter):
        raise TypeError("backend create_activity_waiter_for_queues must be callable")

    hook = cast(MultiQueueActivityWaiterHook, create_waiter)
    return hook(
        target=first_identity.target_arg,
        backend_options=first_identity.backend_options_arg,
        runner=first_identity.runner_arg,
        queue_names=queue_names,
        stop_event=stop_event,
    )


# ~
