from .klock import *

__doc__ = klock.__doc__
if hasattr(klock, "__all__"):
    __all__ = klock.__all__