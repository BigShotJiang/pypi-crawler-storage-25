Search files using ripgrep.
