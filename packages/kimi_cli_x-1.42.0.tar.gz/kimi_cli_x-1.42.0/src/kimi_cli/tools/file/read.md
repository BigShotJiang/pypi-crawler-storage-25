Read text files.
