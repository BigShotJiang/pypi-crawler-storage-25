# -*- coding:utf-8 -*-
##############################################################
# Created Date: Sunday, February 4th 2024
# Contact Info: luoxiangyong01@gmail.com
# Author/Copyright: Mr. Xiangyong Luo
##############################################################


from ._google_numpy_docstring import (show_docstring_headers,
                                      show_docstring_google,
                                      show_docstring_numpy
                                      )

from ._password_generator import generate_password

from ._import_package import (
    import_package,
    get_active_python_env,
    is_module_importable,
    get_user_defined_func,
    get_user_defined_module,
    get_user_imported_module,
    is_user_defined_func)

from ._dependency_requires_decorator import requires
from ._func_time_decorator import func_running_time, func_time
from ._run_parallel_decorator import run_parallel
from ._end_of_life_decorator import end_of_life
from ._count_code_size import count_lines_of_code
from ._time_out import timeout, timeout_linux
from ._convert_py_to_dll import cvt_py_to_dll


__all__ = [
    # _google_numpy_docstring
    "show_docstring_headers",
    "show_docstring_google",
    "show_docstring_numpy",

    # _password_generator
    "generate_password",

    # _import_package
    "import_package",
    "get_active_python_env",
    "is_module_importable",
    "get_user_defined_func",
    "get_user_defined_module",
    "get_user_imported_module",
    "is_user_defined_func",

    # _decorator_dependency_requires
    "requires",

    # _decorator_func_time
    "func_running_time",
    "func_time",

    # _decorator_run_parallel
    "run_parallel",

    # _decorator_end_of_life
    "end_of_life",

    # _count_code_size
    "count_lines_of_code",

    # _time_out
    "timeout",
    "timeout_linux",

    # _convert_py_to_dll
    "cvt_py_to_dll"
]
