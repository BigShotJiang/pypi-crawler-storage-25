package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/evidence"
	"github.com/meshclaw/meshclaw/internal/fleet"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/policy"
	"github.com/meshclaw/meshclaw/internal/provision"
	"github.com/meshclaw/meshclaw/internal/runtime"
	"github.com/meshclaw/meshclaw/internal/workers"
	"github.com/meshclaw/meshclaw/internal/workflow"
	"github.com/meshclaw/meshclaw/internal/workspace"
)

type mcpRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
	ID      interface{}     `json:"id,omitempty"`
}

type mcpResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	Result  interface{} `json:"result,omitempty"`
	Error   *mcpError   `json:"error,omitempty"`
	ID      interface{} `json:"id,omitempty"`
}

type mcpError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type mcpTool struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	InputSchema mcpInputSchema `json:"inputSchema"`
}

type mcpInputSchema struct {
	Type       string                 `json:"type"`
	Properties map[string]mcpProperty `json:"properties"`
	Required   []string               `json:"required,omitempty"`
}

type mcpProperty struct {
	Type        string      `json:"type"`
	Description string      `json:"description"`
	Default     interface{} `json:"default,omitempty"`
}

func cmdMCP() error {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}
		var req mcpRequest
		if err := json.Unmarshal([]byte(line), &req); err != nil {
			continue
		}
		if req.ID == nil {
			continue
		}
		resp := handleMCP(req)
		out, _ := json.Marshal(resp)
		fmt.Println(string(out))
	}
	return scanner.Err()
}

func handleMCP(req mcpRequest) mcpResponse {
	switch req.Method {
	case "initialize":
		return mcpResponse{
			JSONRPC: "2.0",
			Result: map[string]interface{}{
				"protocolVersion": "2024-11-05",
				"capabilities":    map[string]interface{}{"tools": map[string]interface{}{}},
				"serverInfo":      map[string]string{"name": "meshclaw-mcp", "version": "0.1.0"},
			},
			ID: req.ID,
		}
	case "tools/list":
		return mcpResponse{JSONRPC: "2.0", Result: map[string]interface{}{"tools": mcpTools()}, ID: req.ID}
	case "tools/call":
		var params struct {
			Name      string                 `json:"name"`
			Arguments map[string]interface{} `json:"arguments"`
		}
		if err := json.Unmarshal(req.Params, &params); err != nil {
			return mcpResponse{JSONRPC: "2.0", Error: &mcpError{Code: -32602, Message: err.Error()}, ID: req.ID}
		}
		result, err := callMCPTool(params.Name, params.Arguments)
		if err != nil {
			return mcpResponse{JSONRPC: "2.0", Error: &mcpError{Code: -32000, Message: err.Error()}, ID: req.ID}
		}
		data, _ := json.MarshalIndent(result, "", "  ")
		return mcpResponse{
			JSONRPC: "2.0",
			Result: map[string]interface{}{
				"content": []map[string]string{{"type": "text", "text": string(data)}},
			},
			ID: req.ID,
		}
	default:
		return mcpResponse{JSONRPC: "2.0", Error: &mcpError{Code: -32601, Message: "unknown method: " + req.Method}, ID: req.ID}
	}
}

func mcpTools() []mcpTool {
	return []mcpTool{
		{Name: "meshclaw.server_list", Description: "List known servers and Tailscale-first connection facts.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.workers", Description: "List model operators, Matrix room surfaces, MeshClaw MCP, and vssh execution workers.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.workspace_list", Description: "List known workspaces: server, folder, owner/model, branch, purpose, and recent activity.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.workspace_add", Description: "Register or update a workspace location used by a model or human operator.", InputSchema: objectSchema(map[string]mcpProperty{
			"id":      {Type: "string", Description: "Stable workspace id"},
			"host":    {Type: "string", Description: "Host name, or local"},
			"path":    {Type: "string", Description: "Absolute workspace path"},
			"owner":   {Type: "string", Description: "Current owner/model/operator"},
			"purpose": {Type: "string", Description: "Why this workspace exists"},
			"branch":  {Type: "string", Description: "Git branch or working lane"},
			"source":  {Type: "string", Description: "Frontend/source, e.g. codex-app, claude-web, matrix"},
		}, []string{"id", "host", "path"})},
		{Name: "meshclaw.workspace_activity", Description: "Record what an operator/model did in a workspace and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"id":       {Type: "string", Description: "Workspace id"},
			"actor":    {Type: "string", Description: "Actor, e.g. codex, claude, local-llm, human"},
			"action":   {Type: "string", Description: "Action name, e.g. edit, review, deploy, scan"},
			"summary":  {Type: "string", Description: "Short activity summary"},
			"evidence": {Type: "string", Description: "Optional evidence URL/path/id"},
		}, []string{"id", "actor", "action", "summary"})},
		{Name: "meshclaw.capability_list", Description: "List models, APIs, services, and provisioner capabilities without revealing secrets.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.monitor_check", Description: "Check fleet health through vssh facts first and return alerts.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.fleet_scan", Description: "Run a policy-checked fleet diagnostic scan and store one evidence bundle.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts":        {Type: "string", Description: "Optional comma-separated inventory hosts"},
			"security":     {Type: "boolean", Description: "Run security snapshots", Default: true},
			"hygiene":      {Type: "boolean", Description: "Run redacted hygiene scans", Default: true},
			"logs":         {Type: "boolean", Description: "Run warning/error log scans", Default: true},
			"max_parallel": {Type: "number", Description: "Maximum hosts scanned in parallel", Default: 3},
		}, nil)},
		{Name: "meshclaw.autoheal_plan", Description: "Convert current fleet alerts into read-only or auto-safe actions.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.autoheal_apply_safe", Description: "Apply bounded non-destructive autoheal actions and store evidence.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.evidence_list", Description: "List recent stored evidence records.", InputSchema: objectSchema(map[string]mcpProperty{"limit": {Type: "number", Description: "Maximum records to return", Default: 20}}, nil)},
		{Name: "meshclaw.policy_check", Description: "Decide whether a subject can perform an action on a resource.", InputSchema: objectSchema(map[string]mcpProperty{
			"subject":  {Type: "string", Description: "Operator subject, e.g. codex, claude, local-llm, automation"},
			"action":   {Type: "string", Description: "Action name, e.g. read_state, run_command, provision_server"},
			"resource": {Type: "string", Description: "Resource name, e.g. server, secret, provider"},
			"context":  {Type: "string", Description: "Optional command or extra context"},
		}, []string{"subject", "action", "resource"})},
		{Name: "meshclaw.policy_show", Description: "Return the active MeshClaw policy config without revealing secrets.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.matrix_plan", Description: "Return the supported Matrix bridge role: ops room, approval channel, notification channel, and optional MCP surface.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw.ops_dispatch", Description: "Route a Matrix/Open WebUI/Codex/Claude-style message to a MeshClaw ops result.", InputSchema: objectSchema(map[string]mcpProperty{
			"source":  {Type: "string", Description: "Source surface, e.g. matrix, openwebui, codex, claude"},
			"message": {Type: "string", Description: "Natural-language or command-like message"},
		}, []string{"source", "message"})},
		{Name: "meshclaw.provision_plan", Description: "Plan temporary VPS/server capacity without creating resources.", InputSchema: objectSchema(map[string]mcpProperty{
			"purpose":        {Type: "string", Description: "Why temporary capacity is needed"},
			"budget_usd":     {Type: "number", Description: "Maximum budget cap in USD", Default: 0},
			"ttl_hours":      {Type: "number", Description: "Time-to-live for temporary capacity", Default: 6},
			"required_class": {Type: "string", Description: "Capacity class, e.g. small-vps, gpu, storage", Default: "small-vps"},
			"provider":       {Type: "string", Description: "Provider capability id", Default: "provider-api"},
			"region":         {Type: "string", Description: "Preferred region", Default: "nearest-available"},
		}, []string{"purpose"})},
		{Name: "meshclaw.run_evidence", Description: "Run a policy-checked command and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"command": {Type: "string", Description: "Command to execute"},
		}, []string{"host", "command"})},
		{Name: "meshclaw.job_start", Description: "Start a long-running vssh daemon job and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"command": {Type: "string", Description: "Command to run asynchronously"},
		}, []string{"host", "command"})},
		{Name: "meshclaw.job_status", Description: "Return vssh daemon job status and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"id":   {Type: "string", Description: "Job id"},
		}, []string{"host", "id"})},
		{Name: "meshclaw.job_logs", Description: "Return vssh daemon job logs and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":       {Type: "string", Description: "Inventory host name"},
			"id":         {Type: "string", Description: "Job id"},
			"tail_bytes": {Type: "number", Description: "Return only the last N bytes", Default: 0},
		}, []string{"host", "id"})},
		{Name: "meshclaw.job_cancel", Description: "Cancel a running vssh daemon job and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"id":   {Type: "string", Description: "Job id"},
		}, []string{"host", "id"})},
		{Name: "meshclaw.artifact_collect", Description: "Collect remote artifact metadata/content through vssh and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":      {Type: "string", Description: "Inventory host name"},
			"path":      {Type: "string", Description: "Remote file or directory path"},
			"max_bytes": {Type: "number", Description: "Maximum file bytes to return before base64 encoding", Default: 1048576},
		}, []string{"host", "path"})},
		{Name: "meshclaw.disk_investigate", Description: "Collect read-only disk evidence for a host/path.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"path": {Type: "string", Description: "Absolute path to inspect", Default: "/"},
		}, []string{"host"})},
		{Name: "meshclaw.data_clean_plan", Description: "Find raw/intermediate/checkpoint cleanup candidates while preserving clean/final outputs.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"path": {Type: "string", Description: "Absolute project path to inspect"},
		}, []string{"host", "path"})},
		{Name: "meshclaw.data_clean_apply", Description: "Apply a manifest generated by data_clean_plan.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":     {Type: "string", Description: "Inventory host name"},
			"manifest": {Type: "string", Description: "Manifest path produced by data_clean_plan"},
		}, []string{"host", "manifest"})},
		{Name: "meshclaw.analyze_logs", Description: "Collect warning/error log evidence from system journal or a log file.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":   {Type: "string", Description: "Inventory host name"},
			"source": {Type: "string", Description: "system, journal, syslog, or an absolute log path", Default: "system"},
		}, []string{"host"})},
		{Name: "meshclaw.security_check", Description: "Collect a read-only security snapshot: users, listeners, failed logins, sudoers, updates.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw.hygiene_scan_host", Description: "Scan likely remote logs/config files for redacted secret and PII leak evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw.service_check", Description: "Collect read-only systemd status, unit config, and recent logs for a service.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"service": {Type: "string", Description: "Systemd service name"},
		}, []string{"host", "service"})},
		{Name: "meshclaw.service_quarantine", Description: "Disable a flapping service only when its ExecStart target is missing.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"service": {Type: "string", Description: "Systemd service name"},
		}, []string{"host", "service"})},
		{Name: "meshclaw.service_remove", Description: "Stop/disable a local systemd service, remove its unit, and optionally remove its matching WorkingDirectory.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"service": {Type: "string", Description: "Systemd service name"},
			"path":    {Type: "string", Description: "Optional absolute WorkingDirectory to remove when it matches the unit"},
		}, []string{"host", "service"})},
	}
}

func objectSchema(properties map[string]mcpProperty, required []string) mcpInputSchema {
	if properties == nil {
		properties = map[string]mcpProperty{}
	}
	return mcpInputSchema{Type: "object", Properties: properties, Required: required}
}

func callMCPTool(name string, args map[string]interface{}) (interface{}, error) {
	switch name {
	case "meshclaw.server_list":
		return inventory.DefaultNodes(), nil
	case "meshclaw.workers":
		return workers.DefaultWorkers(), nil
	case "meshclaw.workspace_list":
		list, path, err := workspace.List()
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"path": path, "workspaces": list}, nil
	case "meshclaw.workspace_add":
		ws := workspace.Workspace{
			ID:      stringArg(args, "id"),
			Host:    stringArg(args, "host"),
			Path:    stringArg(args, "path"),
			Owner:   stringArg(args, "owner"),
			Purpose: stringArg(args, "purpose"),
			Branch:  stringArg(args, "branch"),
			Source:  stringArg(args, "source"),
		}
		saved, path, err := workspace.Upsert(ws)
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"path": path, "workspace": saved}, nil
	case "meshclaw.workspace_activity":
		record, err := workspace.RecordActivity(workspace.Activity{
			WorkspaceID: stringArg(args, "id"),
			Actor:       stringArg(args, "actor"),
			Action:      stringArg(args, "action"),
			Summary:     stringArg(args, "summary"),
			Evidence:    stringArg(args, "evidence"),
		})
		return map[string]interface{}{"evidence": record}, err
	case "meshclaw.capability_list":
		return capability.DefaultCapabilities(), nil
	case "meshclaw.monitor_check":
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		states := m.CheckAll()
		return monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}, nil
	case "meshclaw.fleet_scan":
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "fleet_scan", Resource: "server"})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		opts := fleet.Options{
			Hosts:       splitCSV(stringArg(args, "hosts")),
			Security:    boolArg(args, "security", true),
			Hygiene:     boolArg(args, "hygiene", true),
			Logs:        boolArg(args, "logs", true),
			MaxParallel: intArg(args, "max_parallel", 3),
		}
		report, scanErr := fleet.Scan(opts)
		if scanErr != nil {
			return nil, scanErr
		}
		record, storeErr := evidence.Store("fleet-scan", "fleet", fleetScanSummary(report), report)
		return map[string]interface{}{"policy": decision, "report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw.autoheal_plan":
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		m.CheckAll()
		return monitor.NewAutoHealer(m).Plan(), nil
	case "meshclaw.autoheal_apply_safe":
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		m.CheckAll()
		actions := monitor.NewAutoHealer(m).CheckAndHeal()
		record, storeErr := evidence.Store("autoheal-apply-safe", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
		return map[string]interface{}{"actions": actions, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw.evidence_list":
		return evidence.List(intArg(args, "limit", 20))
	case "meshclaw.policy_check":
		return policy.Evaluate(policy.Request{
			Subject:  stringArg(args, "subject"),
			Action:   stringArg(args, "action"),
			Resource: stringArg(args, "resource"),
			Context:  stringArg(args, "context"),
		}), nil
	case "meshclaw.policy_show":
		cfg, path, err := policy.LoadConfig()
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"path": path, "policy": cfg}, nil
	case "meshclaw.matrix_plan":
		return map[string]interface{}{
			"role": "Matrix is an operations room, approval channel, notification channel, and optional MCP command surface. It is not the assistant brain.",
			"flow": []string{
				"human or AI operator posts an ops request in Matrix",
				"Matrix bridge normalizes the request into a MeshClaw MCP/CLI tool call",
				"MeshClaw policy decides allow, require_approval, or deny",
				"MeshClaw executes only allowed tools through vssh/runtime",
				"Matrix bridge posts concise results and evidence links back to the room",
			},
		}, nil
	case "meshclaw.ops_dispatch":
		return dispatchOpsMessage(stringArg(args, "source"), stringArg(args, "message"))
	case "meshclaw.provision_plan":
		req := provision.Request{
			Purpose:       stringArg(args, "purpose"),
			Provider:      stringArg(args, "provider"),
			Region:        stringArg(args, "region"),
			BudgetUSD:     floatArg(args, "budget_usd", 0),
			TTLHours:      intArg(args, "ttl_hours", 6),
			RequiredClass: stringArg(args, "required_class"),
		}
		plan := provision.NewPlan(req)
		record, err := evidence.Store("provision-plan", "provider", req.Purpose, plan)
		return map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.run_evidence":
		host := stringArg(args, "host")
		command := stringArg(args, "command")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "run_command", Resource: "server", Context: command})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result := runtime.NewRunner().RunEvidence(host, command)
		record, err := evidence.Store("run-evidence", host, command, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.job_start":
		host := stringArg(args, "host")
		command := stringArg(args, "command")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "run_command", Resource: "server", Context: command})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result, runErr := runtime.NewRunner().VSSHJSON("job-start", host, command)
		record, storeErr := evidence.Store("job-start", host, command, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw.job_status":
		return mcpVSSHJobRead("job-status", "job_status", args)
	case "meshclaw.job_logs":
		host := stringArg(args, "host")
		id := stringArg(args, "id")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "job_logs", Resource: "server", Context: id})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		params := []string{"job-logs", host, id}
		if tail := intArg(args, "tail_bytes", 0); tail > 0 {
			params = append(params, fmt.Sprintf("%d", tail))
		}
		result, runErr := runtime.NewRunner().VSSHJSON(params...)
		record, storeErr := evidence.Store("job-logs", host, id, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw.job_cancel":
		host := stringArg(args, "host")
		id := stringArg(args, "id")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "job_cancel", Resource: "server", Context: id})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result, runErr := runtime.NewRunner().VSSHJSON("job-cancel", host, id)
		record, storeErr := evidence.Store("job-cancel", host, id, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw.artifact_collect":
		host := stringArg(args, "host")
		path := stringArg(args, "path")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "artifact_collect", Resource: "server", Context: path})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		params := []string{"artifact-collect", host, path}
		if maxBytes := intArg(args, "max_bytes", 0); maxBytes > 0 {
			params = append(params, fmt.Sprintf("%d", maxBytes))
		}
		result, runErr := runtime.NewRunner().VSSHJSON(params...)
		record, storeErr := evidence.Store("artifact-collect", host, path, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw.disk_investigate":
		host := stringArg(args, "host")
		path := stringArg(args, "path")
		if path == "" {
			path = "/"
		}
		command := fmt.Sprintf("df -h %s && sudo du -xhd1 %s 2>/dev/null | sort -h | tail -40", shellQuote(path), shellQuote(path))
		result := runtime.NewRunner().RunEvidence(host, command)
		record, err := evidence.Store("disk-investigate", host, path, result)
		return map[string]interface{}{"result": result, "evidence": record, "store_error": errString(err), "time": time.Now().UTC()}, nil
	case "meshclaw.data_clean_plan":
		host := stringArg(args, "host")
		path := stringArg(args, "path")
		report := workflow.DataCleanPlan(host, path)
		record, err := evidence.Store("data-clean-plan", host, path, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.data_clean_apply":
		host := stringArg(args, "host")
		manifest := stringArg(args, "manifest")
		report := workflow.DataCleanApply(host, manifest)
		record, err := evidence.Store("data-clean-apply", host, manifest, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.analyze_logs":
		host := stringArg(args, "host")
		source := stringArg(args, "source")
		if source == "" {
			source = "system"
		}
		report := workflow.AnalyzeLogs(host, source)
		record, err := evidence.Store("analyze-logs", host, source, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.security_check":
		host := stringArg(args, "host")
		report := workflow.SecurityCheck(host)
		record, err := evidence.Store("security-check", host, "read-only snapshot", report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.hygiene_scan_host":
		host := stringArg(args, "host")
		report := hygiene.ScanHost(host)
		record, err := evidence.Store("hygiene-scan-host", host, report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.service_check":
		host := stringArg(args, "host")
		service := stringArg(args, "service")
		report := workflow.ServiceCheck(host, service)
		record, err := evidence.Store("service-check", host, service, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.service_quarantine":
		host := stringArg(args, "host")
		service := stringArg(args, "service")
		report := workflow.ServiceQuarantine(host, service)
		record, err := evidence.Store("service-quarantine", host, service, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw.service_remove":
		host := stringArg(args, "host")
		service := stringArg(args, "service")
		path := stringArg(args, "path")
		report := workflow.ServiceRemove(host, service, path)
		record, err := evidence.Store("service-remove", host, service, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	default:
		return nil, fmt.Errorf("unknown tool: %s", name)
	}
}

func mcpVSSHJobRead(command, action string, args map[string]interface{}) (interface{}, error) {
	host := stringArg(args, "host")
	id := stringArg(args, "id")
	decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: action, Resource: "server", Context: id})
	if decision.Decision != policy.Allow {
		return map[string]interface{}{"policy": decision, "success": false}, nil
	}
	result, runErr := runtime.NewRunner().VSSHJSON(command, host, id)
	record, storeErr := evidence.Store(command, host, id, result)
	return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
}

func stringArg(args map[string]interface{}, key string) string {
	if value, ok := args[key].(string); ok {
		return value
	}
	return ""
}

func intArg(args map[string]interface{}, key string, fallback int) int {
	switch value := args[key].(type) {
	case float64:
		return int(value)
	case int:
		return value
	default:
		return fallback
	}
}

func boolArg(args map[string]interface{}, key string, fallback bool) bool {
	if value, ok := args[key].(bool); ok {
		return value
	}
	return fallback
}

func floatArg(args map[string]interface{}, key string, fallback float64) float64 {
	switch value := args[key].(type) {
	case float64:
		return value
	case int:
		return float64(value)
	default:
		return fallback
	}
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}
