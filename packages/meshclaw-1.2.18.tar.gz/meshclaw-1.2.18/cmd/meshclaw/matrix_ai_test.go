package main

import "testing"

func TestShouldRouteMatrixAIToTool(t *testing.T) {
	tests := []struct {
		name    string
		message string
		want    bool
	}{
		{name: "workspace lookup ko", message: "워크스페이스 보여줘", want: true},
		{name: "server status ko", message: "서버 상태 보여줘", want: true},
		{name: "policy lookup ko", message: "정책 보여줘", want: true},
		{name: "evidence lookup ko", message: "최근 기록 보여줘", want: true},
		{name: "workers lookup ko", message: "작업자 목록 확인", want: true},
		{name: "fleet lookup en", message: "show fleet status", want: true},
		{name: "workspace lookup en", message: "list workspaces", want: true},
		{name: "conceptual policy question", message: "운영정책이 뭔데?", want: false},
		{name: "conceptual workspace question", message: "워크스페이스라는 개념이 뭐야?", want: false},
		{name: "casual chat", message: "음 지금 방향이 좀 애매한데", want: false},
		{name: "dangerous action is not read lookup", message: "서버들에 rm -rf 실행해", want: false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := shouldRouteMatrixAIToTool(tt.message); got != tt.want {
				t.Fatalf("shouldRouteMatrixAIToTool(%q)=%v want %v", tt.message, got, tt.want)
			}
		})
	}
}
