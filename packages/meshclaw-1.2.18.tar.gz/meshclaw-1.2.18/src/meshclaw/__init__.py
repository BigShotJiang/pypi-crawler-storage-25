"""Python entrypoint package for the MeshClaw ServerOps control plane."""

__version__ = "1.2.11"
