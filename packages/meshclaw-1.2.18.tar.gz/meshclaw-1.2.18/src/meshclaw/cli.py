from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    binary = find_meshclaw_binary()
    if binary is None:
        print(
            "meshclaw Go binary is not installed. Build it with:\n"
            "  go install github.com/meshclaw/meshclaw/cmd/meshclaw@latest\n"
            "or set MESHCLAW_BIN=/path/to/meshclaw",
            file=sys.stderr,
        )
        return 127
    completed = subprocess.run([binary, *sys.argv[1:]])
    return completed.returncode


def find_meshclaw_binary() -> str | None:
    configured = os.environ.get("MESHCLAW_BIN")
    if configured and os.access(configured, os.X_OK):
        return configured

    current = Path(sys.argv[0]).resolve()
    path = os.environ.get("PATH", "")
    for directory in path.split(os.pathsep):
        candidate = Path(directory) / "meshclaw"
        if not candidate.exists() or not os.access(candidate, os.X_OK):
            continue
        try:
            if candidate.resolve() == current:
                continue
        except OSError:
            continue
        return str(candidate)

    fallback = shutil.which("meshclaw")
    if fallback:
        try:
            if Path(fallback).resolve() != current:
                return fallback
        except OSError:
            return fallback
    return None


if __name__ == "__main__":
    raise SystemExit(main())
