package workflow

import (
	"fmt"
	"strings"

	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/runtime"
)

type Finding struct {
	Severity string `json:"severity"`
	Title    string `json:"title"`
	Evidence string `json:"evidence"`
	Next     string `json:"next"`
}

type Report struct {
	Name     string    `json:"name"`
	Host     string    `json:"host"`
	Status   string    `json:"status"`
	Findings []Finding `json:"findings"`
}

func ServiceCheck(host, service string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("service-check", host)
	}
	command := fmt.Sprintf(`echo "---status---"
systemctl status %s --no-pager 2>/dev/null || true
echo "---unit---"
systemctl cat %s 2>/dev/null || true
echo "---logs---"
sudo journalctl -u %s -n 120 --no-pager 2>/dev/null || true`, shellQuote(service), shellQuote(service), shellQuote(service))
	result := runtime.NewRunner().RunEvidence(host, command)
	if !result.Success {
		return Report{
			Name:   "service-check",
			Host:   host,
			Status: "failed",
			Findings: []Finding{{
				Severity: "error",
				Title:    "Service check command failed",
				Evidence: truncate(result.Stderr+result.Stdout, 1200),
				Next:     "Run doctor and verify systemd/journal access.",
			}},
		}
	}
	output := strings.TrimSpace(result.Stdout)
	severity := "info"
	title := "Service snapshot collected"
	status := "ok"
	lower := strings.ToLower(output)
	if strings.Contains(lower, "active: inactive (dead)") && strings.Contains(lower, "disabled") {
		title = "Service is inactive and disabled"
	} else if strings.Contains(lower, "failed") || strings.Contains(lower, "inactive") {
		severity = "warning"
		title = "Service has failed or inactive evidence"
		status = "findings"
	}
	return Report{
		Name:   "service-check",
		Host:   host,
		Status: status,
		Findings: []Finding{{
			Severity: severity,
			Title:    title,
			Evidence: truncate(output, 4000),
			Next:     "Use restart only after reviewing unit config and recent logs.",
		}},
	}
}

func ServiceQuarantine(host, service string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("service-quarantine", host)
	}
	command := fmt.Sprintf(`set -eu
service=%s
exec_line=$(systemctl show "$service" -p ExecStart --value 2>/dev/null)
exec_path=$(printf '%%s\n' "$exec_line" | sed -n 's/.* path=\([^ ;]*\).*/\1/p' | head -1)
missing_arg=$(printf '%%s\n' "$exec_line" | sed -n 's/.* argv\[\]=[^ ]* \([^ ;]*\).*/\1/p' | head -1)
echo "service=$service"
echo "exec_line=$exec_line"
echo "exec_path=$exec_path"
if [ -z "$exec_path" ]; then
  echo "no ExecStart path parsed; refusing quarantine"
  exit 2
fi
if [ -n "$missing_arg" ]; then
  echo "arg_path=$missing_arg"
  if [ -e "$missing_arg" ]; then
    echo "ExecStart argument exists; refusing quarantine"
    exit 3
  fi
elif [ -e "$exec_path" ]; then
  echo "ExecStart exists; refusing quarantine"
  exit 3
fi
sudo systemctl disable --now "$service"
systemctl is-enabled "$service" 2>/dev/null || true
systemctl is-active "$service" 2>/dev/null || true`, shellQuote(service))
	result := runtime.NewRunner().RunEvidence(host, command)
	severity := "info"
	title := "Broken service quarantined"
	status := "ok"
	next := "Run service-check to confirm it no longer flaps."
	if !result.Success {
		severity = "warning"
		title = "Service quarantine did not apply"
		status = "blocked"
		next = "Review evidence; quarantine is refused unless ExecStart is missing."
	}
	return Report{
		Name:   "service-quarantine",
		Host:   host,
		Status: status,
		Findings: []Finding{{
			Severity: severity,
			Title:    title,
			Evidence: truncate(result.Stdout+result.Stderr, 3000),
			Next:     next,
		}},
	}
}

func ServiceRemove(host, service, path string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("service-remove", host)
	}
	if path != "" && !strings.HasPrefix(path, "/") {
		return Report{
			Name:   "service-remove",
			Host:   host,
			Status: "invalid_path",
			Findings: []Finding{{
				Severity: "error",
				Title:    "Path must be absolute",
				Evidence: path,
				Next:     "Use an absolute service working directory path.",
			}},
		}
	}
	command := fmt.Sprintf(`set -eu
service=%s
remove_path=%s
unit_path=$(systemctl show "$service" -p FragmentPath --value 2>/dev/null || true)
workdir=$(systemctl show "$service" -p WorkingDirectory --value 2>/dev/null || true)
active=$(systemctl is-active "$service" 2>/dev/null || true)
enabled=$(systemctl is-enabled "$service" 2>/dev/null || true)
echo "service=$service"
echo "unit_path=$unit_path"
echo "workdir=$workdir"
echo "active_before=$active"
echo "enabled_before=$enabled"
if [ -z "$unit_path" ] || [ "$unit_path" = "n/a" ]; then
  if [ -z "$remove_path" ] || [ ! -e "$remove_path" ]; then
    echo "already_absent=true"
    exit 0
  fi
  echo "unit not found but remove path still exists; refusing remove"
  exit 2
fi
if [ -n "$remove_path" ]; then
  case "$remove_path" in
    /|/root|/home|/var|/usr|/etc|/opt|/srv|/tmp)
      echo "refusing broad path: $remove_path"
      exit 3
      ;;
  esac
  if [ "$workdir" != "$remove_path" ]; then
    echo "remove path does not match service WorkingDirectory"
    exit 4
  fi
fi
sudo systemctl disable --now "$service" 2>/dev/null || true
if printf '%%s\n' "$unit_path" | grep -q '^/etc/systemd/system/'; then
  sudo rm -f -- "$unit_path"
else
  echo "not removing non-local unit path: $unit_path"
fi
sudo systemctl daemon-reload
if [ -n "$remove_path" ] && [ -e "$remove_path" ]; then
  sudo rm -rf -- "$remove_path"
fi
echo "active_after=$(systemctl is-active "$service" 2>/dev/null || true)"
echo "enabled_after=$(systemctl is-enabled "$service" 2>/dev/null || true)"
if [ -n "$remove_path" ]; then
  [ ! -e "$remove_path" ] && echo "path_removed=true"
fi`, shellQuote(service), shellQuote(path))
	result := runtime.NewRunner().RunEvidence(host, command)
	status := "ok"
	severity := "info"
	title := "Service removed"
	if !result.Success {
		status = "failed"
		severity = "error"
		title = "Service remove failed"
	}
	return Report{
		Name:   "service-remove",
		Host:   host,
		Status: status,
		Findings: []Finding{{
			Severity: severity,
			Title:    title,
			Evidence: truncate(result.Stdout+result.Stderr, 5000),
			Next:     "Run service-check and monitor-check to verify removal.",
		}},
	}
}

func DataCleanPlan(host, path string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("data-clean-plan", host)
	}
	if !strings.HasPrefix(path, "/") {
		return Report{
			Name:   "data-clean-plan",
			Host:   host,
			Status: "invalid_path",
			Findings: []Finding{{
				Severity: "error",
				Title:    "Path must be absolute",
				Evidence: path,
				Next:     "Use an absolute project path.",
			}},
		}
	}
	command := fmt.Sprintf(`set -eu
root=%s
manifest=/tmp/meshclaw-data-clean-plan-$(hostname)-$(date -u +%%Y%%m%%dT%%H%%M%%SZ).txt
: > "$manifest"
find "$root" -xdev \( \
  -path "*/venv" -o -path "*/venv_*" -o -path "*/.venv" -o -path "*/node_modules" \
\) -prune -o \( \
  -type d \( -name "checkpoint-*" -o -name "checkpoints" -o -name "checkpoints_*" -o -name "__pycache__" -o -name ".pytest_cache" \) \
  -o -type f \( \
    -name "*checkpoint*" -o -name "*ckpt*" -o -name "*epoch*.pt" -o -name "*_light.txt" -o -name "*_pure.txt" \
    -o -name "*_mixed*.txt" -o -name "*_combined*.txt" -o -name "*_combined*.jsonl" \
    -o -name "*_new.jsonl" -o -name "chunk_*.npy" -o -name "*raw*.jsonl" -o -name "*raw*.txt" \
  \) \
\) -print | while IFS= read -r p; do
  case "$p" in
    *clean*|*final*|*/final_model.pt|*/jamovec_final.pt) continue ;;
  esac
  printf '%%s\n' "$p"
done | sort -u > "$manifest"
echo "manifest=$manifest"
while IFS= read -r p; do [ -e "$p" ] && du -sh "$p" 2>/dev/null || true; done < "$manifest" | sort -h
echo "count=$(wc -l < "$manifest")"`, shellQuote(path))
	result := runtime.NewRunner().RunEvidence(host, command)
	status := "ok"
	severity := "info"
	title := "Data cleanup plan collected"
	if !result.Success {
		status = "failed"
		severity = "error"
		title = "Data cleanup plan failed"
	}
	return Report{
		Name:   "data-clean-plan",
		Host:   host,
		Status: status,
		Findings: []Finding{{
			Severity: severity,
			Title:    title,
			Evidence: truncate(result.Stdout+result.Stderr, 5000),
			Next:     "Run data-clean-apply only after confirming the manifest keeps clean/final outputs.",
		}},
	}
}

func DataCleanApply(host, manifest string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("data-clean-apply", host)
	}
	if !strings.HasPrefix(manifest, "/tmp/meshclaw-data-clean-plan-") {
		return Report{
			Name:   "data-clean-apply",
			Host:   host,
			Status: "invalid_manifest",
			Findings: []Finding{{
				Severity: "error",
				Title:    "Refusing untrusted manifest path",
				Evidence: manifest,
				Next:     "Use a manifest generated by data-clean-plan.",
			}},
		}
	}
	command := fmt.Sprintf(`set -eu
manifest=%s
if [ ! -f "$manifest" ]; then
  echo "missing manifest: $manifest"
  exit 2
fi
backup="$HOME/meshclaw-data-clean-applied-$(date -u +%%Y%%m%%dT%%H%%M%%SZ).txt"
cp "$manifest" "$backup"
before=$(df -BG / | awk 'NR==2{print $3" used, "$4" free, "$5}')
count=0
while IFS= read -r p; do
  [ -e "$p" ] || continue
  case "$p" in
    *clean*|*final*|*/final_model.pt|*/jamovec_final.pt)
      echo "refuse_preserved_name $p"
      continue
      ;;
  esac
  rm -rf -- "$p"
  count=$((count+1))
done < "$manifest"
after=$(df -BG / | awk 'NR==2{print $3" used, "$4" free, "$5}')
echo "backup=$backup"
echo "deleted_count=$count"
echo "before=$before"
echo "after=$after"`, shellQuote(manifest))
	result := runtime.NewRunner().RunEvidence(host, command)
	status := "ok"
	severity := "info"
	title := "Data cleanup manifest applied"
	if !result.Success {
		status = "failed"
		severity = "error"
		title = "Data cleanup apply failed"
	}
	return Report{
		Name:   "data-clean-apply",
		Host:   host,
		Status: status,
		Findings: []Finding{{
			Severity: severity,
			Title:    title,
			Evidence: truncate(result.Stdout+result.Stderr, 5000),
			Next:     "Run disk-investigate and monitor-check to verify reclaimed space.",
		}},
	}
}

func AnalyzeLogs(host, source string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("analyze-logs", host)
	}
	command := `if command -v journalctl >/dev/null 2>&1; then
  sudo journalctl -p warning..alert -n 120 --no-pager 2>/dev/null
elif [ -f /var/log/syslog ]; then
  sudo tail -200 /var/log/syslog 2>/dev/null | egrep -i 'error|warn|fail|critical|panic' | tail -120
elif [ -f /var/log/messages ]; then
  sudo tail -200 /var/log/messages 2>/dev/null | egrep -i 'error|warn|fail|critical|panic' | tail -120
else
  echo "no supported system log source found"
fi`
	if source != "system" && source != "syslog" && source != "journal" {
		command = fmt.Sprintf("sudo tail -200 %s 2>/dev/null | egrep -i 'error|warn|fail|critical|panic' | tail -120", shellQuote(source))
	}
	result := runtime.NewRunner().RunEvidence(host, command)
	if !result.Success {
		return Report{
			Name:   "analyze-logs",
			Host:   host,
			Status: "failed",
			Findings: []Finding{{
				Severity: "error",
				Title:    "Log analysis command failed",
				Evidence: truncate(result.Stderr+result.Stdout, 1200),
				Next:     "Run doctor and verify read access to the requested log source.",
			}},
		}
	}
	output := strings.TrimSpace(result.Stdout)
	status := "ok"
	severity := "info"
	title := "No warning/error log evidence found"
	next := "Continue normal monitoring."
	if output != "" && output != "no supported system log source found" {
		status = "findings"
		severity = "warning"
		title = "Recent warning/error log evidence found"
		next = "Review cited lines and run a targeted service check if the same unit repeats."
	}
	return Report{
		Name:   "analyze-logs",
		Host:   host,
		Status: status,
		Findings: []Finding{{
			Severity: severity,
			Title:    title,
			Evidence: truncate(output, 3000),
			Next:     next,
		}},
	}
}

func SecurityCheck(host string) Report {
	if _, ok := inventory.Find(host); !ok {
		return unknownNodeReport("security-check", host)
	}
	command := `echo "host=$(hostname)"
echo "---users-with-shell---"
awk -F: '$7 !~ /(false|nologin)$/ {print $1 ":" $3 ":" $7}' /etc/passwd 2>/dev/null
echo "---ssh-listeners---"
(ss -tulpen 2>/dev/null || netstat -tulpen 2>/dev/null) | egrep '(:22|:80|:443|LISTEN)' || true
echo "---failed-logins---"
(sudo journalctl _COMM=sshd -p info -n 80 --no-pager 2>/dev/null || sudo tail -120 /var/log/auth.log 2>/dev/null || true) | egrep -i 'failed|invalid|authentication failure' | tail -30 || true
echo "---sudoers-risk---"
sudo grep -R "NOPASSWD\|ALL=(ALL:ALL) ALL" /etc/sudoers /etc/sudoers.d 2>/dev/null || true
echo "---updates---"
if command -v apt-get >/dev/null 2>&1; then apt-get -s upgrade 2>/dev/null | awk '/^[0-9]+ upgraded/ {print}'; fi`
	result := runtime.NewRunner().RunEvidence(host, command)
	if !result.Success {
		return Report{
			Name:   "security-check",
			Host:   host,
			Status: "failed",
			Findings: []Finding{{
				Severity: "error",
				Title:    "Security check command failed",
				Evidence: truncate(result.Stderr+result.Stdout, 1200),
				Next:     "Run doctor and verify SSH/sudo read access.",
			}},
		}
	}
	output := strings.TrimSpace(result.Stdout)
	findings := securityFindings(output)
	return Report{
		Name:     "security-check",
		Host:     host,
		Status:   "findings",
		Findings: findings,
	}
}

func securityFindings(output string) []Finding {
	sections := splitSections(output)
	findings := []Finding{{
		Severity: "info",
		Title:    "Users with login shells",
		Evidence: truncate(sections["users-with-shell"], 1000),
		Next:     "Review unexpected interactive users.",
	}}
	listeners := strings.TrimSpace(sections["ssh-listeners"])
	findings = append(findings, Finding{
		Severity: "warning",
		Title:    "Open listeners",
		Evidence: truncate(listeners, 2000),
		Next:     "Confirm public listeners are intentional; prefer Tailscale-only for admin surfaces.",
	})
	failed := strings.TrimSpace(sections["failed-logins"])
	if failed == "" {
		findings = append(findings, Finding{
			Severity: "info",
			Title:    "No recent failed SSH login evidence",
			Evidence: "empty failed-login section",
			Next:     "Continue monitoring.",
		})
	} else {
		findings = append(findings, Finding{
			Severity: "warning",
			Title:    "Recent failed login evidence",
			Evidence: truncate(failed, 1500),
			Next:     "Consider rate limiting, key-only SSH, and closing public SSH where possible.",
		})
	}
	sudoers := strings.TrimSpace(sections["sudoers-risk"])
	if sudoers == "" {
		findings = append(findings, Finding{
			Severity: "info",
			Title:    "No sudoers risk pattern found",
			Evidence: "empty sudoers-risk section",
			Next:     "Continue monitoring.",
		})
	} else {
		findings = append(findings, Finding{
			Severity: "warning",
			Title:    "Sudoers review required",
			Evidence: truncate(sudoers, 1500),
			Next:     "Review NOPASSWD and broad ALL grants.",
		})
	}
	updates := strings.TrimSpace(sections["updates"])
	if updates == "" {
		updates = "no apt upgrade summary found"
	}
	findings = append(findings, Finding{
		Severity: "info",
		Title:    "Update summary",
		Evidence: truncate(updates, 1000),
		Next:     "Schedule updates if packages are pending.",
	})
	return findings
}

func splitSections(output string) map[string]string {
	sections := map[string]string{}
	current := "root"
	for _, line := range strings.Split(output, "\n") {
		if strings.HasPrefix(line, "---") && strings.HasSuffix(line, "---") {
			current = strings.Trim(line, "-")
			sections[current] = ""
			continue
		}
		sections[current] += line + "\n"
	}
	return sections
}

func unknownNodeReport(name, host string) Report {
	return Report{
		Name:   name,
		Host:   host,
		Status: "unknown_node",
		Findings: []Finding{{
			Severity: "error",
			Title:    "Unknown node",
			Evidence: host,
			Next:     "Add the node to inventory before running this workflow.",
		}},
	}
}

func shellQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", "'\\''") + "'"
}

func truncate(value string, max int) string {
	value = strings.TrimSpace(value)
	if len(value) <= max {
		return value
	}
	if max <= 3 {
		return value[:max]
	}
	return value[:max-3] + "..."
}
