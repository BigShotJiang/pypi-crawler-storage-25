package monitor

import (
	"os"
	"path/filepath"
	"testing"
)

func TestNodeStateFromVSSHFacts(t *testing.T) {
	state := nodeStateFromVSSHFacts("d1", "100.64.0.1", &vsshServerInfo{
		Memory: &vsshMemoryInfo{Total: 1000, Used: 250},
		Load:   &vsshLoadInfo{Load1: 1.5, CPUs: 4},
		Disk: []vsshDiskInfo{
			{MountPoint: "/data", UsePercent: "80%"},
			{MountPoint: "/", UsePercent: "42%"},
		},
		GPU: []vsshGPUInfo{{Utilization: 33, MemoryUsed: 2, MemoryTotal: 4}},
	})

	if !state.Online {
		t.Fatal("expected online state")
	}
	if state.Memory != 25 {
		t.Fatalf("memory=%f", state.Memory)
	}
	if state.Disk != 42 {
		t.Fatalf("disk=%f", state.Disk)
	}
	if state.CPU != 1.5 {
		t.Fatalf("cpu=%f", state.CPU)
	}
	if state.GPUUsage != 33 {
		t.Fatalf("gpu=%f", state.GPUUsage)
	}
	if state.GPUMemory != 50 {
		t.Fatalf("gpu memory=%f", state.GPUMemory)
	}
}

func TestRootDiskPercentFallsBackToFirstDisk(t *testing.T) {
	got := rootDiskPercent([]vsshDiskInfo{{MountPoint: "/mnt", UsePercent: "77%"}})
	if got != 77 {
		t.Fatalf("got=%f", got)
	}
}

func TestDefaultConfigKeepsSSHUsersWhenConfigOmitsSSHUsers(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	configDir := filepath.Join(home, ".meshclaw")
	if err := os.MkdirAll(configDir, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(configDir, "nodes.json"), []byte(`{"nodes":{"d1":{"ip":"100.64.0.1","user":"dell"}}}`), 0600); err != nil {
		t.Fatal(err)
	}

	cfg := DefaultConfig()
	if cfg.SSHUsers == nil {
		t.Fatal("SSHUsers is nil")
	}
	if cfg.SSHUsers["d1"] != "dell" {
		t.Fatalf("d1 user = %q, want dell", cfg.SSHUsers["d1"])
	}
}
