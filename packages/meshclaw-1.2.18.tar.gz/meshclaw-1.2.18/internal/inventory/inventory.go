package inventory

type Node struct {
	Name      string   `json:"name"`
	Role      string   `json:"role"`
	Location  string   `json:"location"`
	WireIP    string   `json:"wire_ip"`
	Tailscale string   `json:"tailscale"`
	LAN       string   `json:"lan"`
	User      string   `json:"user"`
	Tags      []string `json:"tags"`
}

func DefaultNodes() []Node {
	return []Node{
		{Name: "d1", Role: "ai-workload", Location: "yangpyeong", WireIP: "10.98.78.53", Tailscale: "100.111.86.6", LAN: "192.168.50.26", User: "dell", Tags: []string{"linux"}},
		{Name: "d2", Role: "docker-host", Location: "seoul", WireIP: "10.98.45.37", Tailscale: "100.87.223.22", User: "dragon", Tags: []string{"linux"}},
		{Name: "g1", Role: "gpu-server", Location: "seoul", WireIP: "10.98.32.103", Tailscale: "100.111.32.108", LAN: "192.168.50.44", User: "dragon", Tags: []string{"linux", "gpu"}},
		{Name: "g2", Role: "app-server", Location: "seoul", WireIP: "10.98.6.139", Tailscale: "100.79.178.87", LAN: "192.168.50.151", User: "dragon", Tags: []string{"linux"}},
		{Name: "g3", Role: "docker-host", Location: "yangpyeong", WireIP: "10.98.229.244", Tailscale: "100.109.151.29", LAN: "192.168.50.13", User: "dragon", Tags: []string{"linux"}},
		{Name: "g4", Role: "docker-host", Location: "yangpyeong", WireIP: "10.98.83.180", Tailscale: "100.112.139.84", LAN: "192.168.50.27", User: "dragon", Tags: []string{"linux"}},
		{Name: "s2", Role: "nas", Location: "yangpyeong", WireIP: "10.98.217.98", Tailscale: "100.82.76.16", LAN: "192.168.50.101", User: "dragon", Tags: []string{"synology"}},
		{Name: "v1", Role: "relay", Location: "vps", WireIP: "10.98.45.83", Tailscale: "100.98.183.63", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "v2", Role: "relay", Location: "vps", WireIP: "10.98.51.148", Tailscale: "100.69.133.24", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "v3", Role: "relay", Location: "vps", WireIP: "10.98.193.29", Tailscale: "100.122.226.75", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "v4", Role: "relay", Location: "vps", WireIP: "10.98.26.104", Tailscale: "100.113.142.122", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "v5", Role: "relay", Location: "vps", WireIP: "10.98.122.151", Tailscale: "100.65.56.82", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "c1", Role: "server", Location: "vps", WireIP: "10.98.144.211", Tailscale: "100.98.225.110", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "c2", Role: "server", Location: "vps", WireIP: "10.98.52.216", Tailscale: "100.74.74.11", User: "root", Tags: []string{"linux", "vps"}},
		{Name: "macmini", Role: "desktop-worker", Location: "seoul", WireIP: "10.98.65.187", Tailscale: "100.119.221.40", User: "odt", Tags: []string{"macos"}},
	}
}

func Find(name string) (Node, bool) {
	for _, node := range DefaultNodes() {
		if node.Name == name {
			return node, true
		}
	}
	return Node{}, false
}
