package capability

type Kind string

const (
	KindModel       Kind = "model"
	KindAPI         Kind = "api"
	KindService     Kind = "service"
	KindProvisioner Kind = "provisioner"
)

type SecretPolicy string

const (
	SecretNone          SecretPolicy = "none"
	SecretUseOnly       SecretPolicy = "use_without_reveal"
	SecretApprovalGated SecretPolicy = "approval_gated"
)

type Capability struct {
	ID           string       `json:"id"`
	Kind         Kind         `json:"kind"`
	Provider     string       `json:"provider"`
	Host         string       `json:"host,omitempty"`
	Description  string       `json:"description"`
	Capabilities []string     `json:"capabilities"`
	Status       string       `json:"status"`
	SecretPolicy SecretPolicy `json:"secret_policy"`
	Policy       string       `json:"policy"`
}

func DefaultCapabilities() []Capability {
	return []Capability{
		{
			ID:           "vssh-native",
			Kind:         KindService,
			Provider:     "vssh",
			Host:         "m1",
			Description:  "Fleet execution through vssh-native over Tailscale/private routes, with SSH fallback for legacy nodes.",
			Capabilities: []string{"server_list", "fleet_status", "server_info", "run", "fleet_exec"},
			Status:       "available",
			SecretPolicy: SecretNone,
			Policy:       "raw execution is policy-gated",
		},
		{
			ID:           "g1-ollama",
			Kind:         KindModel,
			Provider:     "ollama",
			Host:         "g1",
			Description:  "Local GPU model endpoint candidate.",
			Capabilities: []string{"chat", "summarize", "local_only"},
			Status:       "needs_probe",
			SecretPolicy: SecretNone,
			Policy:       "preferred for private data when healthy",
		},
		{
			ID:           "openai-api",
			Kind:         KindAPI,
			Provider:     "openai",
			Description:  "External model API capability placeholder.",
			Capabilities: []string{"chat", "embeddings", "vision"},
			Status:       "configured_elsewhere",
			SecretPolicy: SecretUseOnly,
			Policy:       "external data policy applies",
		},
		{
			ID:           "temporary-vps",
			Kind:         KindProvisioner,
			Provider:     "provider-api",
			Description:  "Approved temporary server capacity hook placeholder.",
			Capabilities: []string{"provision_plan", "provision_server", "bootstrap_server", "deprovision_server"},
			Status:       "plan_only",
			SecretPolicy: SecretApprovalGated,
			Policy:       "cost-incurring actions require explicit approval",
		},
	}
}
