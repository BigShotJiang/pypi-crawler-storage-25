package aichat

import (
	"strings"
	"testing"
)

func TestCleanResponseRemovesDecorativeEmoji(t *testing.T) {
	input := "### ⚙️ 판단\n안녕하세요 😊\n- 다음 행동"
	got := CleanResponse(input)
	if strings.Contains(got, "⚙") || strings.Contains(got, "😊") {
		t.Fatalf("expected decorative emoji removed, got %q", got)
	}
	if !strings.Contains(got, "판단") || !strings.Contains(got, "다음 행동") {
		t.Fatalf("expected content preserved, got %q", got)
	}
}
