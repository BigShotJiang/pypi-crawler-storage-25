package matrixops

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type Config struct {
	Homeserver     string   `json:"homeserver"`
	UserID         string   `json:"user_id"`
	AccessToken    string   `json:"access_token"`
	RoomID         string   `json:"room_id"`
	CommandPrefix  string   `json:"command_prefix,omitempty"`
	AmbientChat    bool     `json:"ambient_chat,omitempty"`
	IgnoreCommands bool     `json:"ignore_commands,omitempty"`
	IgnoredUsers   []string `json:"ignored_users,omitempty"`
}

type Client struct {
	config     Config
	httpClient *http.Client
}

type DispatchFunc func(source, message string) (map[string]interface{}, error)
type ReplyFunc func(message string) (string, error)

type SyncResponse struct {
	NextBatch string `json:"next_batch"`
	Rooms     struct {
		Join map[string]JoinedRoom `json:"join"`
	} `json:"rooms"`
}

type JoinedRoom struct {
	Timeline struct {
		Events []Event `json:"events"`
	} `json:"timeline"`
}

type Event struct {
	Type    string  `json:"type"`
	Sender  string  `json:"sender"`
	EventID string  `json:"event_id"`
	Content Content `json:"content"`
}

type Content struct {
	MsgType string `json:"msgtype"`
	Body    string `json:"body"`
}

type SyncResult struct {
	NextBatch string   `json:"next_batch"`
	Handled   []string `json:"handled"`
	Ignored   int      `json:"ignored"`
}

func DefaultConfigPath() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(home, ".meshclaw", "matrix.json"), nil
}

func LoadConfig() (Config, string, error) {
	if path := strings.TrimSpace(os.Getenv("MESHCLAW_MATRIX_CONFIG")); path != "" {
		cfg, err := readConfig(path)
		return cfg, path, err
	}
	path, err := DefaultConfigPath()
	if err != nil {
		return Config{}, "", err
	}
	if _, err := os.Stat(path); err == nil {
		cfg, err := readConfig(path)
		return cfg, path, err
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return Config{}, "", err
	}
	fallback := filepath.Join(home, ".argos", "matrix.json")
	cfg, err := readConfig(fallback)
	return cfg, fallback, err
}

func readConfig(path string) (Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return Config{}, err
	}
	var cfg Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return Config{}, err
	}
	cfg.Homeserver = strings.TrimRight(strings.TrimSpace(cfg.Homeserver), "/")
	cfg.UserID = strings.TrimSpace(cfg.UserID)
	cfg.AccessToken = strings.TrimSpace(cfg.AccessToken)
	cfg.RoomID = strings.TrimSpace(cfg.RoomID)
	if cfg.CommandPrefix == "" {
		cfg.CommandPrefix = "!"
	}
	if cfg.Homeserver == "" || cfg.AccessToken == "" || cfg.RoomID == "" {
		return Config{}, fmt.Errorf("matrix config requires homeserver, access_token, and room_id")
	}
	return cfg, nil
}

func SaveConfig(path string, cfg Config) error {
	if path == "" {
		var err error
		path, err = DefaultConfigPath()
		if err != nil {
			return err
		}
	}
	if cfg.CommandPrefix == "" {
		cfg.CommandPrefix = "!"
	}
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	data, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(data, '\n'), 0600)
}

func NewClient(cfg Config) *Client {
	return &Client{config: cfg, httpClient: &http.Client{Timeout: 35 * time.Second}}
}

func (c *Client) SendText(ctx context.Context, body string) error {
	txnID := fmt.Sprintf("meshclaw-%d", time.Now().UnixNano())
	endpoint := fmt.Sprintf("%s/_matrix/client/v3/rooms/%s/send/m.room.message/%s",
		c.config.Homeserver,
		url.PathEscape(c.config.RoomID),
		url.PathEscape(txnID),
	)
	payload := Content{MsgType: "m.text", Body: body}
	return c.doJSON(ctx, http.MethodPut, endpoint, payload, nil)
}

func (c *Client) Sync(ctx context.Context, since string, timeout time.Duration) (SyncResponse, error) {
	endpoint, err := url.Parse(c.config.Homeserver + "/_matrix/client/v3/sync")
	if err != nil {
		return SyncResponse{}, err
	}
	query := endpoint.Query()
	if since != "" {
		query.Set("since", since)
	}
	query.Set("timeout", fmt.Sprintf("%d", timeout.Milliseconds()))
	endpoint.RawQuery = query.Encode()

	var response SyncResponse
	if err := c.doJSON(ctx, http.MethodGet, endpoint.String(), nil, &response); err != nil {
		return SyncResponse{}, err
	}
	return response, nil
}

func (c *Client) SyncOnce(ctx context.Context, since string, dispatch DispatchFunc) (SyncResult, error) {
	response, err := c.Sync(ctx, since, 2*time.Second)
	if err != nil {
		return SyncResult{}, err
	}
	result := SyncResult{NextBatch: response.NextBatch}
	room, ok := response.Rooms.Join[c.config.RoomID]
	if !ok {
		return result, nil
	}
	for _, event := range room.Timeline.Events {
		if !shouldHandle(c.config, event) {
			result.Ignored++
			continue
		}
		reply, err := HandleMessage(c.config, event.Content.Body, dispatch)
		if err != nil {
			reply = "MeshClaw error: " + err.Error()
		}
		if err := c.SendText(ctx, reply); err != nil {
			return result, err
		}
		result.Handled = append(result.Handled, event.EventID)
	}
	return result, nil
}

func (c *Client) SyncOnceReply(ctx context.Context, since string, reply ReplyFunc) (SyncResult, error) {
	response, err := c.Sync(ctx, since, 2*time.Second)
	if err != nil {
		return SyncResult{}, err
	}
	result := SyncResult{NextBatch: response.NextBatch}
	room, ok := response.Rooms.Join[c.config.RoomID]
	if !ok {
		return result, nil
	}
	for _, event := range room.Timeline.Events {
		if !shouldHandle(c.config, event) {
			result.Ignored++
			continue
		}
		text, err := reply(event.Content.Body)
		if err != nil {
			text = "AI bridge error: " + err.Error()
		}
		for _, chunk := range SplitMessage(text, 3500) {
			if err := c.SendText(ctx, chunk); err != nil {
				return result, err
			}
		}
		result.Handled = append(result.Handled, event.EventID)
	}
	return result, nil
}

func (c *Client) Bridge(ctx context.Context, dispatch DispatchFunc) error {
	prime, err := c.Sync(ctx, "", 1*time.Second)
	if err != nil {
		return err
	}
	since := prime.NextBatch
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		result, err := c.SyncOnce(ctx, since, dispatch)
		if err != nil {
			time.Sleep(5 * time.Second)
			continue
		}
		if result.NextBatch != "" {
			since = result.NextBatch
		}
	}
}

func (c *Client) BridgeReply(ctx context.Context, reply ReplyFunc) error {
	prime, err := c.Sync(ctx, "", 1*time.Second)
	if err != nil {
		return err
	}
	since := prime.NextBatch
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		result, err := c.SyncOnceReply(ctx, since, reply)
		if err != nil {
			time.Sleep(5 * time.Second)
			continue
		}
		if result.NextBatch != "" {
			since = result.NextBatch
		}
	}
}

func HandleMessage(cfg Config, message string, dispatch DispatchFunc) (string, error) {
	message = normalizeCommand(cfg, message)
	result, err := dispatch("matrix", message)
	if err != nil {
		return "", err
	}
	return FormatResult(result), nil
}

func shouldHandle(cfg Config, event Event) bool {
	if event.Type != "m.room.message" || event.Content.MsgType != "m.text" {
		return false
	}
	if cfg.UserID != "" && event.Sender == cfg.UserID {
		return false
	}
	for _, ignored := range cfg.IgnoredUsers {
		if strings.TrimSpace(ignored) == event.Sender {
			return false
		}
	}
	body := strings.TrimSpace(event.Content.Body)
	if body == "" {
		return false
	}
	prefix := cfg.CommandPrefix
	if prefix == "" {
		prefix = "!"
	}
	lower := strings.ToLower(body)
	if cfg.AmbientChat {
		if cfg.IgnoreCommands && strings.HasPrefix(body, prefix) {
			return false
		}
		return true
	}
	return strings.HasPrefix(body, prefix) ||
		strings.HasPrefix(lower, "meshclaw ") ||
		strings.Contains(lower, "meshclaw") ||
		isIntroBody(lower)
}

func SplitMessage(text string, max int) []string {
	text = strings.TrimSpace(text)
	if text == "" {
		return []string{"(empty response)"}
	}
	if max <= 0 || len(text) <= max {
		return []string{text}
	}
	var chunks []string
	for len(text) > max {
		cut := strings.LastIndex(text[:max], "\n")
		if cut < max/2 {
			cut = strings.LastIndex(text[:max], " ")
		}
		if cut < max/2 {
			cut = max
		}
		chunks = append(chunks, strings.TrimSpace(text[:cut]))
		text = strings.TrimSpace(text[cut:])
	}
	if text != "" {
		chunks = append(chunks, text)
	}
	return chunks
}

func normalizeCommand(cfg Config, message string) string {
	message = strings.TrimSpace(message)
	prefix := cfg.CommandPrefix
	if prefix == "" {
		prefix = "!"
	}
	if strings.HasPrefix(message, prefix) {
		return message
	}
	lower := strings.ToLower(message)
	if strings.HasPrefix(lower, "meshclaw ") {
		return strings.TrimSpace(message[len("meshclaw "):])
	}
	return message
}

func isIntroBody(lower string) bool {
	lower = strings.TrimSpace(lower)
	switch lower {
	case "hi", "hello", "hey", "안녕", "안녕하세요", "넌 누구지?", "너 누구야?", "누구야?", "who are you?", "대화는 불가능한거야?", "대화 가능해?", "뭐 할 수 있어?", "사용법":
		return true
	default:
		return strings.Contains(lower, "대화 가능") ||
			strings.Contains(lower, "대화는 불가능") ||
			strings.Contains(lower, "뭐 할 수") ||
			strings.Contains(lower, "무엇을 할 수") ||
			strings.Contains(lower, "사용법") ||
			strings.Contains(lower, "도움말")
	}
}

func FormatResult(result map[string]interface{}) string {
	route, _ := result["route"].(string)
	switch route {
	case "intro":
		payload := asMap(result["result"])
		commands := asSlice(payload["commands"])
		lines := []string{
			fmt.Sprint(payload["name"]),
			fmt.Sprint(payload["role"]),
			fmt.Sprint(payload["conversation"]),
			"",
			"Commands:",
		}
		for _, command := range commands {
			lines = append(lines, "- "+fmt.Sprint(command))
		}
		return strings.Join(lines, "\n")
	case "chat":
		payload := asMap(result["result"])
		lines := []string{fmt.Sprint(payload["reply"])}
		try := asSlice(payload["try"])
		if len(try) > 0 {
			lines = append(lines, "", "이렇게 말해도 돼:")
			for _, item := range try {
				lines = append(lines, "- "+fmt.Sprint(item))
			}
		}
		return strings.Join(lines, "\n")
	case "workers":
		items := asMapSlice(result["result"])
		if len(items) == 0 {
			return formatJSONBlock(result, 6000)
		}
		var lines []string
		lines = append(lines, "MeshClaw workers")
		for _, m := range items {
			id, _ := m["id"].(string)
			status, _ := m["status"].(string)
			surface, _ := m["surface"].(string)
			lines = append(lines, fmt.Sprintf("- %s: %s (%s)", id, status, surface))
		}
		return strings.Join(lines, "\n")
	case "workspace_list":
		return formatWorkspaceList(result)
	case "workspace_add":
		return "Workspace registered.\n" + formatJSONBlock(result["result"], 2500)
	case "monitor_check":
		return formatMonitor(result)
	case "policy_summary":
		return "MeshClaw policy\n" + formatJSONBlock(result["result"], 2500)
	case "evidence_list":
		return "Recent evidence\n" + formatJSONBlock(result["result"], 4500)
	default:
		return formatJSONBlock(result, 6000)
	}
}

func FormatExplainedResult(result map[string]interface{}) string {
	route, _ := result["route"].(string)
	switch route {
	case "workspace_list":
		return explainWorkspaceList(result)
	case "monitor_check":
		return explainMonitor(result)
	case "policy_summary":
		return "MeshClaw 실제 정책 요약입니다.\n\n" + FormatResult(result) + "\n\n해석:\n- 이 값은 현재 정책 파일을 요약한 것입니다.\n- 실제 허용/승인/차단 판단은 개별 action/resource 기준으로 policy-check를 해야 정확합니다.\n\n다음 행동:\n- 특정 작업 권한을 확인하려면 `policy-check <subject> <action> <resource>` 형태로 확인하는 것이 맞습니다."
	case "evidence_list":
		return "MeshClaw 실제 evidence 목록입니다.\n\n" + FormatResult(result) + "\n\n해석:\n- 최근 실행, 조회, 스캔 결과가 evidence로 남습니다.\n- 운영 판단은 말보다 evidence 기준으로 추적하는 것이 안전합니다."
	default:
		return "MeshClaw 실제 조회 결과입니다.\n\n" + FormatResult(result)
	}
}

func formatWorkspaceList(result map[string]interface{}) string {
	payload := asMap(result["result"])
	items := asMapSlice(payload["workspaces"])
	if len(items) == 0 {
		return "No workspaces registered."
	}
	lines := []string{"MeshClaw workspaces"}
	for _, m := range items {
		lines = append(lines, fmt.Sprintf("- %v: %v:%v owner=%v purpose=%v", m["id"], m["host"], m["path"], m["owner"], m["purpose"]))
	}
	sort.Strings(lines[1:])
	return strings.Join(lines, "\n")
}

func explainWorkspaceList(result map[string]interface{}) string {
	payload := asMap(result["result"])
	items := asMapSlice(payload["workspaces"])
	if len(items) == 0 {
		return "MeshClaw 실제 워크스페이스 조회 결과입니다.\n\n현재 등록된 워크스페이스가 없습니다.\n\n해석:\n- Codex, Claude, Open WebUI, Matrix 작업이 어느 서버/폴더에서 진행되는지 추적하려면 workspace 등록이 먼저 필요합니다.\n\n다음 행동:\n- 현재 프로젝트를 등록하려면 `현재 워크스페이스 등록` 또는 `workspace-add`를 사용하면 됩니다."
	}
	lines := []string{
		"MeshClaw 실제 워크스페이스 조회 결과입니다.",
		"",
		fmt.Sprintf("현재 등록된 워크스페이스는 %d개입니다.", len(items)),
		"",
		"목록:",
	}
	itemLines := make([]string, 0, len(items))
	for _, m := range items {
		line := fmt.Sprintf("- %v: %v:%v", m["id"], m["host"], m["path"])
		if owner := strings.TrimSpace(fmt.Sprint(m["owner"])); owner != "" {
			line += fmt.Sprintf(" owner=%s", owner)
		}
		if purpose := strings.TrimSpace(fmt.Sprint(m["purpose"])); purpose != "" {
			line += fmt.Sprintf(" purpose=%s", purpose)
		}
		itemLines = append(itemLines, line)
	}
	sort.Strings(itemLines)
	lines = append(lines, itemLines...)
	lines = append(lines,
		"",
		"해석:",
		"- 워크스페이스는 모델/사람이 실제 작업하는 서버와 폴더의 위치 기록입니다.",
		"- 지금 기준으로 MeshClaw 본 프로젝트는 local:/Users/dragon/meshclaw 쪽에 등록되어 있습니다.",
		"- owner 값은 마지막 등록 주체를 나타내므로, 실제 현재 작업자와 다를 수 있습니다. 작업 시작/종료 이벤트를 더 기록하면 정확도가 올라갑니다.",
		"",
		"다음 행동:",
		"- 다른 서버의 프로젝트 폴더도 등록하면 Matrix에서 '누가 어디서 뭘 하는지'를 더 잘 추적할 수 있습니다.",
		"- 작업자가 바뀔 때 `workspace-activity`를 남기면 evidence와 연결됩니다.",
	)
	return strings.Join(lines, "\n")
}

func formatMonitor(result map[string]interface{}) string {
	payload := asMap(result["result"])
	states := asMap(payload["states"])
	alerts := asSlice(payload["alerts"])
	return fmt.Sprintf("Fleet status: nodes=%d alerts=%d\n%s", len(states), len(alerts), formatJSONBlock(payload, 5000))
}

func explainMonitor(result map[string]interface{}) string {
	payload := asMap(result["result"])
	states := asMap(payload["states"])
	alerts := asSlice(payload["alerts"])
	offline := 0
	highDisk := []string{}
	highMem := []string{}
	for name, raw := range states {
		state := asMap(raw)
		if online, ok := state["online"].(bool); ok && !online {
			offline++
		}
		if disk, ok := numberValue(state["disk"]); ok && disk >= 80 {
			highDisk = append(highDisk, fmt.Sprintf("%s %.1f%%", name, disk))
		}
		if mem, ok := numberValue(state["memory"]); ok && mem >= 80 {
			highMem = append(highMem, fmt.Sprintf("%s %.1f%%", name, mem))
		}
	}
	sort.Strings(highDisk)
	sort.Strings(highMem)
	lines := []string{
		"MeshClaw 실제 서버 상태 조회 결과입니다.",
		"",
		fmt.Sprintf("요약: nodes=%d offline=%d alerts=%d", len(states), offline, len(alerts)),
	}
	if len(highDisk) > 0 {
		lines = append(lines, "디스크 주의: "+strings.Join(highDisk, ", "))
	}
	if len(highMem) > 0 {
		lines = append(lines, "메모리 주의: "+strings.Join(highMem, ", "))
	}
	lines = append(lines,
		"",
		"해석:",
		"- 이 결과는 현재 MeshClaw monitor/fleet 조회에서 나온 실제 상태입니다.",
		"- 디스크 80% 이상, 메모리 80% 이상, offline 노드는 우선 확인 대상입니다.",
		"- CPU 값이 0으로 보이면 해당 facts 수집 방식이 아직 load/cpu를 충분히 채우지 못했을 수 있으므로 vssh facts 개선 대상으로 봐야 합니다.",
		"",
		"다음 행동:",
		"- 디스크가 높은 노드는 `disk-investigate <host> /`로 원인을 확인합니다.",
		"- 로그 문제가 의심되면 `analyze-logs <host> system`으로 최근 오류를 봅니다.",
		"- 개인정보/시크릿 누출이 걱정되면 `hygiene-scan-host <host>`를 실행합니다.",
	)
	return strings.Join(lines, "\n")
}

func numberValue(value interface{}) (float64, bool) {
	switch v := value.(type) {
	case float64:
		return v, true
	case float32:
		return float64(v), true
	case int:
		return float64(v), true
	case int64:
		return float64(v), true
	case json.Number:
		out, err := v.Float64()
		return out, err == nil
	default:
		return 0, false
	}
}

func asMap(value interface{}) map[string]interface{} {
	if out, ok := value.(map[string]interface{}); ok {
		return out
	}
	data, err := json.Marshal(value)
	if err != nil {
		return map[string]interface{}{}
	}
	var out map[string]interface{}
	if err := json.Unmarshal(data, &out); err != nil {
		return map[string]interface{}{}
	}
	return out
}

func asMapSlice(value interface{}) []map[string]interface{} {
	if out, ok := value.([]map[string]interface{}); ok {
		return out
	}
	data, err := json.Marshal(value)
	if err != nil {
		return nil
	}
	var out []map[string]interface{}
	if err := json.Unmarshal(data, &out); err != nil {
		return nil
	}
	return out
}

func asSlice(value interface{}) []interface{} {
	if out, ok := value.([]interface{}); ok {
		return out
	}
	data, err := json.Marshal(value)
	if err != nil {
		return nil
	}
	var out []interface{}
	if err := json.Unmarshal(data, &out); err != nil {
		return nil
	}
	return out
}

func formatJSONBlock(value interface{}, max int) string {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return fmt.Sprint(value)
	}
	text := string(data)
	if max > 0 && len(text) > max {
		text = text[:max] + "\n... truncated ..."
	}
	return "```json\n" + text + "\n```"
}

func (c *Client) doJSON(ctx context.Context, method, endpoint string, payload interface{}, out interface{}) error {
	var body *bytes.Reader
	if payload == nil {
		body = bytes.NewReader(nil)
	} else {
		data, err := json.Marshal(payload)
		if err != nil {
			return err
		}
		body = bytes.NewReader(data)
	}
	req, err := http.NewRequestWithContext(ctx, method, endpoint, body)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+c.config.AccessToken)
	req.Header.Set("Content-Type", "application/json")
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		data, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return fmt.Errorf("matrix %s %s: %s %s", method, endpoint, resp.Status, strings.TrimSpace(string(data)))
	}
	if out == nil {
		return nil
	}
	return json.NewDecoder(resp.Body).Decode(out)
}
