package matrixops

import (
	"strings"
	"testing"
)

func TestShouldHandleAmbientAndIgnoredUsers(t *testing.T) {
	cfg := Config{
		UserID:         "@ops-ai:example",
		CommandPrefix:  "@ops-ai",
		AmbientChat:    true,
		IgnoreCommands: true,
		IgnoredUsers:   []string{"@dev:example"},
	}

	tests := []struct {
		name  string
		event Event
		want  bool
	}{
		{
			name:  "ambient human chat",
			event: Event{Type: "m.room.message", Sender: "@dragon:example", Content: Content{MsgType: "m.text", Body: "운영 안정화"}},
			want:  true,
		},
		{
			name:  "ignore own message",
			event: Event{Type: "m.room.message", Sender: "@ops-ai:example", Content: Content{MsgType: "m.text", Body: "hello"}},
			want:  false,
		},
		{
			name:  "ignore tool bot",
			event: Event{Type: "m.room.message", Sender: "@dev:example", Content: Content{MsgType: "m.text", Body: "MeshClaw workers"}},
			want:  false,
		},
		{
			name:  "ignore command intended for mention prefix",
			event: Event{Type: "m.room.message", Sender: "@dragon:example", Content: Content{MsgType: "m.text", Body: "@ops-ai help"}},
			want:  false,
		},
		{
			name:  "ignore non text",
			event: Event{Type: "m.room.message", Sender: "@dragon:example", Content: Content{MsgType: "m.image", Body: "image"}},
			want:  false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := shouldHandle(cfg, tt.event); got != tt.want {
				t.Fatalf("shouldHandle()=%v want %v", got, tt.want)
			}
		})
	}
}

func TestSplitMessage(t *testing.T) {
	chunks := SplitMessage("alpha beta gamma delta", 10)
	if len(chunks) < 2 {
		t.Fatalf("expected split chunks, got %v", chunks)
	}
	for _, chunk := range chunks {
		if len(chunk) > 10 {
			t.Fatalf("chunk too long: %q", chunk)
		}
	}
}

func TestFormatExplainedWorkspaceList(t *testing.T) {
	text := FormatExplainedResult(map[string]interface{}{
		"route": "workspace_list",
		"result": map[string]interface{}{
			"workspaces": []map[string]interface{}{
				{"id": "meshclaw-local", "host": "local", "path": "/Users/dragon/meshclaw", "owner": "codex", "purpose": "serverops"},
			},
		},
	})
	for _, want := range []string{"실제 워크스페이스", "해석", "다음 행동", "meshclaw-local"} {
		if !strings.Contains(text, want) {
			t.Fatalf("expected %q in explained workspace output: %s", want, text)
		}
	}
}

func TestFormatExplainedMonitor(t *testing.T) {
	text := FormatExplainedResult(map[string]interface{}{
		"route": "monitor_check",
		"result": map[string]interface{}{
			"states": map[string]interface{}{
				"d1": map[string]interface{}{"online": true, "disk": 87.2, "memory": 12.5},
				"g1": map[string]interface{}{"online": false, "disk": 10.0, "memory": 8.0},
			},
			"alerts": []interface{}{"disk"},
		},
	})
	for _, want := range []string{"실제 서버 상태", "offline=1", "디스크 주의", "다음 행동"} {
		if !strings.Contains(text, want) {
			t.Fatalf("expected %q in explained monitor output: %s", want, text)
		}
	}
}
