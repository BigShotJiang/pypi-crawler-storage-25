package policy

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestEvaluateConfiguredPolicyOverridesBuiltIn(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "policy.json")
	data := `{
  "version": "1",
  "rules": [
    {
      "id": "deny-codex-fleet-scan",
      "subject": "codex",
      "action": "fleet_scan",
      "resource": "server",
      "decision": "deny",
      "reason": "test override"
    }
  ]
}`
	if err := os.WriteFile(path, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("MESHCLAW_POLICY_FILE", path)

	result := Evaluate(Request{Subject: "codex", Action: "fleet_scan", Resource: "server"})
	if result.Decision != Deny {
		t.Fatalf("decision = %q, want deny", result.Decision)
	}
	if result.Source != "config" || result.RuleID != "deny-codex-fleet-scan" {
		t.Fatalf("result = %#v, want config rule metadata", result)
	}
}

func TestEvaluateUsesDefaultPresetWhenConfigFileIsMissing(t *testing.T) {
	t.Setenv("MESHCLAW_POLICY_FILE", filepath.Join(t.TempDir(), "missing.json"))

	result := Evaluate(Request{Subject: "codex", Action: "fleet_scan", Resource: "server"})
	if result.Decision != Allow {
		t.Fatalf("decision = %q, want allow", result.Decision)
	}
	if result.Source != "config" {
		t.Fatalf("source = %q, want config", result.Source)
	}
}

func TestContextRuleMatchesSubstring(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "policy.json")
	data := `{
  "version": "1",
  "rules": [
    {
      "id": "block-shadow",
      "action": "run_command",
      "resource": "server",
      "context": "/etc/shadow",
      "decision": "deny"
    }
  ]
}`
	if err := os.WriteFile(path, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("MESHCLAW_POLICY_FILE", path)

	result := Evaluate(Request{Subject: "operator", Action: "run_command", Resource: "server", Context: "cat /etc/shadow"})
	if result.Decision != Deny || result.RuleID != "block-shadow" {
		t.Fatalf("result = %#v, want configured deny", result)
	}
}

func TestDevOpsPresetAllowsLocalReadOnlyButGatesMutatingActions(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "policy.json")
	data, err := json.Marshal(PresetConfig("devops"))
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("MESHCLAW_POLICY_FILE", path)

	readOnly := Evaluate(Request{Subject: "local-llm", Action: "fleet_scan", Resource: "server"})
	if readOnly.Decision != Allow {
		t.Fatalf("readOnly decision = %q, want allow", readOnly.Decision)
	}

	mutating := Evaluate(Request{Subject: "local-llm", Action: "run_command", Resource: "server", Context: "systemctl restart nginx"})
	if mutating.Decision != RequireApproval {
		t.Fatalf("mutating decision = %q, want require_approval", mutating.Decision)
	}
}
