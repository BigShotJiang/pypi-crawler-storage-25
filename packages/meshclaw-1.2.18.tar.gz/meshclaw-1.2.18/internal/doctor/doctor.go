package doctor

import (
	"fmt"

	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/runtime"
)

func Check(host string) string {
	node, ok := inventory.Find(host)
	if !ok {
		return fmt.Sprintf("unknown node: %s\n", host)
	}

	runner := runtime.NewRunner()
	out, err := runner.Run(host, "hostname && whoami && uptime")
	if err == nil {
		return fmt.Sprintf("%s OK\npath=vssh-native-first\nremote=%s\nlegacy_wire=%s\n%s", host, preferredRemote(node), node.WireIP, out)
	}

	return fmt.Sprintf(`%s DEGRADED
role=%s
location=%s
tailscale=%s
legacy_wire=%s
lan=%s

execution probe failed:
%v

next checks:
- verify Tailscale reachability and MagicDNS/IP
- verify vsshd is running on the target for sshd-free execution
- if vsshd is unavailable, verify sshd and SSH user/key for fallback
- install the monitoring agent for continuous evidence collection
- use legacy Wire only as fallback
`, node.Name, node.Role, node.Location, node.Tailscale, node.WireIP, node.LAN, err)
}

func preferredRemote(node inventory.Node) string {
	if node.Tailscale != "" {
		return node.Tailscale
	}
	if node.WireIP != "" {
		return node.WireIP
	}
	if node.LAN != "" {
		return node.LAN
	}
	return node.Name
}
