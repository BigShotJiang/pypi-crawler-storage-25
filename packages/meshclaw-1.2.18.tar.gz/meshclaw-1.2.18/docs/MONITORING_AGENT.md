# Monitoring Agent

MeshClaw's monitoring agent is not a conversational assistant.

It is a long-running server-operations sensor:

```text
monitor-agent
  -> discover inventory/Tailscale nodes
  -> collect fleet state
  -> detect alerts
  -> optionally scan redacted hygiene findings
  -> store evidence
  -> let Codex/Claude/local LLM decide the next action through MCP
```

## Command

```sh
meshclaw monitor-agent 5m
meshclaw monitor-agent 10m --hygiene
```

The interval argument is optional and accepts Go duration syntax such as `30s`,
`1m`, or `5m`. Intervals below `10s` are refused.

`--hygiene` adds a conservative remote scan for likely log/config leaks. The
remote command redacts matched values before evidence is stored.

## Role

The monitor agent owns observation, not conversation.

It should eventually run on three surfaces:

- central controller: fleet-wide monitor and evidence writer
- node-local daemon: local facts, logs, hygiene checks, and vssh readiness
- MCP/CLI: on-demand status and remediation workflows

## Direction

The preferred execution substrate is:

```text
Tailscale/private route -> vssh server -> structured evidence
```

SSH remains a compatibility fallback only while a node does not have vssh
native daemon coverage.

The controller loop is:

```text
observe -> detect -> plan -> policy gate -> apply -> verify -> evidence
```

This is the MeshClaw equivalent of a Kubernetes controller loop, but aimed at
mixed real servers rather than only container workloads.

`fleet-scan` is the on-demand batch form of the same idea. It runs monitor,
security, log, and redacted hygiene checks across selected hosts and stores one
evidence bundle that Codex, Claude, or a local MCP client can inspect.
