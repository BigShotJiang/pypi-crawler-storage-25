# Productization Plan

MeshClaw should productize the existing MeshPOP pieces instead of rebuilding
them.

## Product Stack

```text
AI operators
  Codex mobile / Claude / Open WebUI local models
    -> MeshClaw MCP
       -> inventory
       -> capability vault
       -> policy
       -> capacity and budget
       -> doctor
       -> audit/evidence
       -> provisioners
       -> vssh-native / monitor-agent / vault / meshdb
```

## Existing Components To Reuse

| Component | Path | Product Role |
| --- | --- | --- |
| vssh runtime | `/Users/dragon/meshpop-repos/vssh` | sshd-free structured execution, RPC, facts, and evidence |
| MeshClaw runtime adapter | this repo | vssh-native first, SSH fallback for legacy nodes |
| mpop | `/Users/dragon/meshpop-repos/mpop-go` | agentless fleet status and metrics |
| meshpop-mcp | `/Users/dragon/meshpop-repos/meshpop-mcp` | legacy MCP bridge reference |
| vault-go | `/Users/dragon/meshpop-repos/vault-go` | future use-only secret and API capability layer |
| meshdb-go | `/Users/dragon/meshpop-repos/meshdb-go` | optional evidence/history/search backend |
| mesh-event | `/Users/dragon/meshpop-repos/mesh-event` | append-only event/evidence model |
| wire | `/Users/dragon/meshpop-repos/wire` | optional advanced Wire backend; not the default first product |

## Packaging

The public install story should be:

```sh
pip install meshclaw
```

`meshclaw` should execute through vssh-native first and use SSH only as a
legacy fallback.

Default networking should be Tailscale-first:

```text
1. Tailscale / MagicDNS / 100.x IP + vssh server
2. OpenSSH over reachable addresses as fallback
3. monitor-agent for continuous fleet evidence
4. optional custom Wire backend
```

## MeshClaw Product Boundary

MeshClaw is not a skill marketplace and not a personal assistant. It exposes
infrastructure facts and safe actions:

- nodes
- services
- model endpoints
- API capabilities
- policy checks
- budget/cost gates
- provision plans
- safe execution
- evidence and audit

AI operators own planning and conversation.

## Provisioning Direction

VPS/GPU rental can become an agent-facing capability:

```text
capacity_list
provision_plan
provision_server      approval-gated
bootstrap_server
attach_to_mesh
run_workload
collect_results
deprovision_server    approval-gated or automatic on TTL
```

Rules:

- planning is allowed without approval
- cost-incurring actions require explicit approval
- secrets are use-only and never revealed by default
- temporary servers must get TTL, owner, purpose, and teardown policy
- every provision/deprovision action emits evidence

## First Product Milestone

1. Make `meshclaw mcp` wrap the working `meshpop-mcp` tools.
2. Promote capability vault schema to JSON/YAML config.
3. Add policy checks for command risk, external API use, and provisioning cost.
4. Add `provision_plan` as a dry-run tool.
5. Keep actual server rental behind an approval gate.
6. Add PyPI packaging after the CLI/MCP shape stabilizes.
