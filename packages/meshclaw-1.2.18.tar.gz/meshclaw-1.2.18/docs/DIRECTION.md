# Direction

MeshClaw is being rebuilt as a non-conversational infrastructure capability
control plane.

The previous personal-assistant direction is closed. Codex mobile, Claude,
ChatGPT, and similar tools are the conversation layer. MeshClaw should not talk
to the user as a persona. It should answer operator tool calls with current
state, available capabilities, policy decisions, diagnostics, actions,
provisioning hooks, and evidence.

## Product Position

Kubernetes manages workloads after applications are shaped for a cluster.
MeshClaw manages the servers that already exist.

Target users:

- people with several VPS, home servers, GPU boxes, NAS devices, and Docker hosts
- people for whom Kubernetes is too heavy
- people who want AI operators to run safe, auditable server operations
- people who need repeatable operations across mixed Linux, macOS, Synology,
  VPS, GPU, and Docker hosts
- people who want AI operators to decide when local capacity is enough and when
  approved temporary capacity should be rented

## Layering

```text
Codex / Claude
  -> MeshClaw MCP
  -> MeshClaw Core
     -> inventory
     -> workspace registry
     -> capability vault
     -> capacity/budget
     -> policy
     -> doctor
     -> log analysis
     -> security checks
     -> hygiene auto-healing
     -> audit/evidence
     -> runbooks
     -> provisioners
     -> vssh-native runtime
  -> fleet / models / APIs / temporary capacity
```

## Network Rule

Tailscale is the default fleet network. It is already installed, operational,
and easier to reason about from Codex mobile and desktop. MeshClaw should prefer
Tailscale IPs for inventory, monitoring, SSH execution, and agent callbacks.

The preferred execution dependency is `Tailscale/private route + vssh server`.
Tailscale provides reachability; vssh provides sshd-free structured execution,
RPC, and evidence.

SSH remains a fallback only for nodes without vssh daemon coverage. Those nodes
need `Tailscale + sshd + SSH key/user mapping` until vssh is installed.

Wire is legacy compatibility. Keep it as an optional fallback for old nodes or
historical tooling, but do not build the MVP around Wire transport, Wire
discovery, or Matrix/Wire-first assumptions.

## Design Rules

- No assistant persona.
- No user-facing general conversation.
- Prefer structured operations over raw shell.
- Keep raw shell available, but policy-gated.
- Make `doctor` explain causes before suggesting actions.
- Make log analysis evidence-first: cite files, time ranges, and commands.
- Make security checks conservative, but let hygiene auto-heal safe fixes:
  chmod, redaction, quarantine, and bounded cleanup.
- Require approval for destructive hygiene actions: deletion, key rotation,
  database edits, provider revocation, and service restarts.
- Store enough evidence for later review.
- Keep the first product small enough to use daily.
- Treat Codex and Claude as brains/operators, not competitors.
- Treat vssh-native over Tailscale/private network as the execution substrate.
- Treat SSH as compatibility fallback, not the product value.
- Keep Wire as fallback compatibility, not the default path.
- Treat Open WebUI/local models as another operator class using the same MCP.
- Treat secrets as use-only capabilities, not values to reveal.
- Require explicit approval for cost-incurring provisioning.
- Store operator permissions in policy config so Codex, Claude, local LLMs,
  and automations can get different decisions from the same MeshClaw runtime.

## First Milestone

1. Inventory is the source of truth for nodes and roles.
2. Workspace registry tracks server/folder/branch ownership across Codex,
   Claude, local LLMs, Matrix, and humans.
3. Capability vault lists usable models, APIs, services, and provisioners
   without revealing secrets.
4. `status` reflects fleet inventory and live monitor state.
5. `doctor <node>` explains path failures: Tailscale, sshd, SSH user/key, and
   service.
6. `run <node> <cmd>` uses vssh-native first and SSH only as fallback.
7. MCP exposes only safe, high-signal tools first:
   `server_list`, `workers`, `workspace_list`, `workspace_add`,
   `workspace_activity`, `fleet_status`, `server_info`, `capability_list`,
   `policy_check`, `policy_show`, `doctor`, `analyze_logs`, `security_check`,
   `hygiene_plan`, `hygiene_apply`, `monitor_check`, `fleet_scan`, `autoheal_plan`,
   `autoheal_apply_safe`, `disk_investigate`, `data_clean_plan`,
   `data_clean_apply`, `service_check`, `service_quarantine`, `run`,
   `service_remove`, `provision_plan`, `fleet_exec`.
8. Provisioning starts as plan-only:
   `capacity_list`, `provision_plan`, and later approval-gated
   `provision_server`, `bootstrap_server`, `deprovision_server`.

## Matrix Role

Matrix can be useful as a shared operations room where people and AI operators
discuss incidents, receive notifications, approve risky actions, and see concise
evidence. It can also expose a narrow command surface that calls MeshClaw MCP
tools. It must not become the primary brain or a personal assistant. Any Matrix
integration should call the same MeshClaw API/MCP tools and post results;
natural-language planning remains with Codex, Claude, ChatGPT, local LLMs, or
human operators.
