# Recovery Refactor

MeshClaw broke because it expanded into a general assistant. This refactor keeps
only the parts that make MeshClaw useful as an infrastructure control layer.

## Product Rule

```text
Codex / Claude / Open WebUI talk and plan.
MeshClaw decides permissions, exposes state, records evidence, and gates actions.
vssh-native executes the default path; SSH remains compatibility fallback.
```

## Keep

| Area | Existing Source | New Role |
| --- | --- | --- |
| Remote execution | `/Users/dragon/meshpop-repos/vssh` + MeshClaw runtime adapter | vssh-native first execution with SSH fallback |
| Fleet status | `/Users/dragon/meshpop-repos/mpop-go` | Agentless status backend |
| MCP bridge | `/Users/dragon/meshpop-repos/meshpop-mcp` | Immediate MCP compatibility layer |
| Agent/controller | `/Users/dragon/meshpop-repos/argos-devops` | Monitoring, fan-out, auto-heal, controller |
| Log analysis | `/Users/dragon/devops-log-analyzer-cli` | Evidence-first log analysis engine |
| Secrets/API vault | `/Users/dragon/meshpop-repos/vault-go` | Use-only secret and API capability broker |
| Evidence/audit | `/Users/dragon/meshpop-repos/mesh-event` and old auditlog | Append-only action record |
| Search/history | `/Users/dragon/meshpop-repos/meshdb-go` | Optional evidence/history search |

## Drop

- General assistant personality
- Matrix-first chat UX
- mail/calendar/browser lifestyle assistant features
- skill marketplace
- model router as a MeshClaw-owned brain
- Codex/Claude replacement behavior

## Refactor Order

1. Make vssh-native over Tailscale preserve evidence for every command.
2. Rename/import `argos-devops` as `meshclaw-agent` and `meshclaw-controller`.
3. Put all actions behind `policy_check(subject, action, resource, context)`.
4. Add audit/evidence for status, execution, remediation, hygiene, and approval.
5. Connect log analysis and security/hygiene workflows to the agent data.
6. Add plan/apply split for remediation and provisioning.
7. Package only after MCP/CLI behavior is stable.

## First Product Surface

```text
meshclaw mcp
meshclaw status
meshclaw monitor-check
meshclaw monitor-agent [interval]
meshclaw autoheal-plan
meshclaw autoheal-apply-safe
meshclaw disk-investigate <node> [path]
meshclaw data-clean-plan <node> <path>
meshclaw data-clean-apply <node> <manifest>
meshclaw analyze-logs <node> <source>
meshclaw security-check <node>
meshclaw service-check <node> <service>
meshclaw service-quarantine <node> <service>
meshclaw capabilities
meshclaw run-evidence <node> <cmd>
meshclaw hygiene-plan <node>
```

## Safety Model

Safe auto-heal:

- chmod exposed secret files
- redact/quarantine leaked log segments
- clean bounded cache/temp/journal data
- collect and attach evidence

Approval required:

- delete original data
- rotate keys
- revoke provider credentials
- edit databases
- restart services
- provision or deprovision paid servers
