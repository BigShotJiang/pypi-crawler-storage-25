from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import r2_score
from dpv_monopeak import extract_dpv_features


@dataclass
class DPVScan:
    v: np.ndarray
    i: np.ndarray
    concentration_M: float


@dataclass
class PredictionResult:
    concentration_M: float
    status: str   # "below_lod" | "detected" | "quantifiable"
    ci: tuple     # (lower_M, upper_M) at 95%


class CalibrationModel:
    """
    Univariate DPV calibration model.

    Parameters
    ----------
    feature : str  — dpv-monopeak feature to calibrate on (default "Height")
    log_x   : bool — None = auto-detect from dynamic range (>1000× → log scale)
    """

    def __init__(self, feature: str = "Height", log_x: bool | None = None):
        self.feature = feature
        self.log_x   = log_x

        self.r2      = None
        self.rmsecv  = None
        self.lod_M   = None
        self.loq_M   = None

        self._b0      = None
        self._b1      = None
        self._sy_x    = None
        self._x_mean  = None
        self._x_ss    = None
        self._n       = None
        self._x_train = None   # transformed x used in fit (for plotting)
        self._y_train = None   # feature values used in fit (for plotting)
        self._is_fit  = False

    def _to_x(self, c: float) -> float:
        return np.log10(c) if self.log_x else c

    def _from_x(self, x: float) -> float:
        return 10.0 ** x if self.log_x else x

    def fit(self, scans: list[DPVScan]) -> "CalibrationModel":
        """
        Fit calibration model from a list of DPVScan objects.

        Parameters
        ----------
        scans : list of DPVScan

        Returns
        -------
        self
        """
        concentrations = np.array([s.concentration_M for s in scans], dtype=float)

        if self.log_x is None:
            self.log_x = (concentrations.max() / concentrations.min()) > 1000

        x_vals, y_vals = [], []
        for scan in scans:
            feats = extract_dpv_features(scan.v, scan.i)
            if feats is None:
                continue
            x_vals.append(self._to_x(scan.concentration_M))
            y_vals.append(feats[self.feature])

        x = np.array(x_vals)
        y = np.array(y_vals)
        n = len(x)

        # OLS — Lavagnini & Magno (2007) Eq. 3-4
        x_mean = x.mean()
        x_ss   = np.sum((x - x_mean) ** 2)
        b1     = np.sum((x - x_mean) * y) / x_ss
        b0     = y.mean() - b1 * x_mean

        # Residual standard deviation — Lavagnini & Magno (2007) Eq. 5
        residuals = y - (b0 + b1 * x)
        sy_x = np.sqrt(np.sum(residuals ** 2) / (n - 2))

        self.r2 = r2_score(y, b0 + b1 * x)

        # RMSECV — leave-one-out
        loo_errors = []
        for i in range(n):
            x_loo  = np.delete(x, i)
            y_loo  = np.delete(y, i)
            b1_loo = np.sum((x_loo - x_loo.mean()) * y_loo) / np.sum((x_loo - x_loo.mean()) ** 2)
            b0_loo = y_loo.mean() - b1_loo * x_loo.mean()
            x_pred = (y[i] - b0_loo) / b1_loo
            loo_errors.append((x[i] - x_pred) ** 2)
        self.rmsecv = np.sqrt(np.mean(loo_errors))

        # LOD / LOQ — Lavagnini & Magno (2007) Section V, Miller & Miller (1988)
        self.lod_M = self._from_x(3  * sy_x / b1)
        self.loq_M = self._from_x(10 * sy_x / b1)

        self._b0      = b0
        self._b1      = b1
        self._sy_x    = sy_x
        self._x_mean  = x_mean
        self._x_ss    = x_ss
        self._n       = n
        self._x_train = x
        self._y_train = y
        self._is_fit  = True

        return self

    def predict(
        self,
        v: np.ndarray,
        i: np.ndarray,
        m: int = 1,
        alpha: float = 0.05,
    ) -> PredictionResult:
        """
        Predict concentration from a raw DPV scan.

        Parameters
        ----------
        v     : voltage array
        i     : current array
        m     : number of replicates averaged in the scan (default 1)
        alpha : significance level for confidence interval (default 0.05 → 95%)

        Returns
        -------
        PredictionResult
        """
        if not self._is_fit:
            raise RuntimeError("Call .fit() before .predict()")

        feats = extract_dpv_features(v, i)
        if feats is None:
            raise ValueError("No valid Faradaic peak found in scan.")

        # Inverse regression — Lavagnini & Magno (2007) Section III.C
        y0 = feats[self.feature]
        x0 = (y0 - self._b0) / self._b1

        # Confidence interval — Lavagnini & Magno (2007) Eq. 10-11
        t  = stats.t.ppf(1 - alpha / 2, df=self._n - 2)
        se = self._sy_x / abs(self._b1) * np.sqrt(
            1 / m + 1 / self._n + (x0 - self._x_mean) ** 2 / self._x_ss
        )
        ci_x = (x0 - t * se, x0 + t * se)

        conc_M = self._from_x(x0)
        ci_M   = (self._from_x(ci_x[0]), self._from_x(ci_x[1]))

        if conc_M < self.lod_M:
            status = "below_lod"
        elif conc_M < self.loq_M:
            status = "detected"
        else:
            status = "quantifiable"

        return PredictionResult(concentration_M=conc_M, status=status, ci=ci_M)

    def __repr__(self) -> str:
        if not self._is_fit:
            return f"CalibrationModel(feature={self.feature!r}, not fitted)"
        return (
            f"CalibrationModel(feature={self.feature!r}, log_x={self.log_x}, "
            f"R²={self.r2:.4f}, RMSECV={self.rmsecv:.4f}, "
            f"LOD={self.lod_M:.2e} M, LOQ={self.loq_M:.2e} M)"
        )


def load_palmsens_xlsx(
    path: str,
    keyword: str = "cort",
    conc_pattern: str = r"(\d+(?:\.\d+)?)\s*(pM|nM|uM|mM)",
) -> list[DPVScan]:
    """
    Load DPV scans from a PSTrace multi-curve Excel export.

    Expects PSTrace format: scan names in row 0, units in row 1,
    paired V/I columns, 81 data points per scan.

    Parameters
    ----------
    path         : path to .xlsx file
    keyword      : filter scans containing this string (case-insensitive)
    conc_pattern : regex to extract concentration value and unit from scan name

    Returns
    -------
    list of DPVScan
    """
    _units = {"pm": 1e-12, "nm": 1e-9, "um": 1e-6, "mm": 1e-3}

    def _parse_conc(label: str) -> float | None:
        m = re.search(conc_pattern, label, re.IGNORECASE)
        if not m:
            return None
        value, unit = float(m.group(1)), m.group(2).lower()
        return value * _units[unit]

    raw = pd.read_excel(path, header=None)
    scans = []
    for col in range(0, raw.shape[1], 2):
        name = str(raw.iloc[0, col])
        if keyword.lower() not in name.lower():
            continue
        data = raw.iloc[2:, col : col + 2].dropna()
        data.columns = ["V", "I"]
        data = data.apply(pd.to_numeric, errors="coerce").dropna()
        if len(data) != 81:
            continue
        conc = _parse_conc(name)
        if conc is None:
            continue
        scans.append(DPVScan(v=data["V"].values, i=data["I"].values, concentration_M=conc))
    return scans
