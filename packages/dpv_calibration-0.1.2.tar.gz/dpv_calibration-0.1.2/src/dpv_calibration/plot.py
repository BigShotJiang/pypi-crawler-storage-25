from __future__ import annotations

import numpy as np

from ._core import CalibrationModel

try:
    import matplotlib.pyplot as plt
    from matplotlib.axes import Axes
    _HAS_MPL = True
except ImportError:
    _HAS_MPL = False


def plot_calibration(
    model: CalibrationModel,
    ax: "Axes | None" = None,
    alpha: float = 0.05,
    show_lod_loq: bool = False,
) -> "Axes":
    """
    Plot a fitted CalibrationModel: scatter of training points, OLS line,
    95% confidence band, and LOD/LOQ markers.

    Parameters
    ----------
    model : CalibrationModel
        A fitted model (must have called .fit() first).
    ax : matplotlib Axes, optional
        Axes to draw into. If None, a new figure is created.
    alpha : float
        Significance level for the confidence band (default 0.05 → 95%).

    Returns
    -------
    matplotlib Axes

    Raises
    ------
    ImportError
        If matplotlib is not installed. Install with:
        ``pip install "dpv-calibration[plot]"``
    RuntimeError
        If the model has not been fitted.
    """
    if not _HAS_MPL:
        raise ImportError(
            "matplotlib is required for plotting. "
            'Install it with: pip install "dpv-calibration[plot]"'
        )
    if not model._is_fit:
        raise RuntimeError("Call .fit() before plot_calibration().")

    from scipy import stats  # lazy import — only needed when plotting

    if ax is None:
        _, ax = plt.subplots(figsize=(7, 5))

    x_train = model._x_train
    y_train = model._y_train

    # ── fitted line and confidence band over the calibration range ───────────
    pad = 0.1 * (x_train.max() - x_train.min())
    x_line = np.linspace(x_train.min() - pad, x_train.max() + pad, 300)
    y_line = model._b0 + model._b1 * x_line

    # Confidence band — Lavagnini & Magno (2007) Eq. 9b
    t = stats.t.ppf(1 - alpha / 2, df=model._n - 2)
    half_band = t * model._sy_x * np.sqrt(
        1 / model._n + (x_line - model._x_mean) ** 2 / model._x_ss
    )

    ax.fill_between(x_line, y_line - half_band, y_line + half_band,
                    alpha=0.15, color="steelblue", label=f"{int((1-alpha)*100)}% confidence band")
    ax.plot(x_line, y_line, color="steelblue", linewidth=2, label="OLS fit")

    # ── training scatter ──────────────────────────────────────────────────────
    ax.scatter(x_train, y_train, color="steelblue", edgecolors="white",
               linewidths=0.8, zorder=4, s=50, label="calibration points")

    # ── LOD / LOQ vertical lines ──────────────────────────────────────────────
    if show_lod_loq:
        x_lod = model._to_x(model.lod_M)
        x_loq = model._to_x(model.loq_M)
        ax.axvline(x_lod, color="orange", linewidth=1.5, linestyle="--",
                label=f"LOD = {model.lod_M:.2e} M")
        ax.axvline(x_loq, color="red",    linewidth=1.5, linestyle="--",
                label=f"LOQ = {model.loq_M:.2e} M")

    # ── axes labels ───────────────────────────────────────────────────────────
    if model.log_x:
        ax.set_xlabel("log₁₀(Concentration / M)")
    else:
        ax.set_xlabel("Concentration (M)")
    ax.set_ylabel(model.feature)

    # ── stats annotation ──────────────────────────────────────────────────────
    ax.text(
        0.97, 0.05,
        f"R² = {model.r2:.4f}\nRMSECV = {model.rmsecv:.4f}",
        transform=ax.transAxes,
        ha="right", va="bottom",
        fontsize=9,
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="lightgray", alpha=0.8),
    )

    ax.legend(fontsize=8, frameon=False)
    ax.spines[["top", "right"]].set_visible(False)

    if ax.figure is not None:
        ax.figure.tight_layout()

    return ax
