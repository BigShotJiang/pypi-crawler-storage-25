# dpv-calibration — Mathematical Reference

All equations follow Lavagnini, I. & Magno, F. (2007). *A statistical overview on univariate calibration, inverse regression, and detection limits: application to gas chromatography/mass spectrometry technique.* Mass Spectrometry Reviews, 26, 1–18. https://doi.org/10.1002/mas.20100

---

## 1. Calibration Function

The univariate calibration function is a straight line relating analyte concentration $x$ to instrumental response $y$ (Lavagnini & Magno, 2007, Eq. 1):

$$\hat{y} = b_0 + b_1 x$$

where $b_0$ is the intercept, $b_1$ is the slope, and $\hat{y}$ is the predicted response. In `dpv-calibration`, $y$ is the extracted DPV peak feature (default: `Height` in µA) and $x$ is the analyte concentration in molar units.

**Log transformation.** When the concentration range spans more than three decades ($c_{\max}/c_{\min} > 1000$), $x$ is replaced by $x' = \log_{10}(c)$ before fitting. This linearizes the response over wide dynamic ranges. All fitting operations are performed in log space. Results are back-transformed via $c = 10^{x'}$ before returning to the user. This is auto-detected from the input data unless overridden via `log_x`.

---

## 2. OLS Parameter Estimates

Parameters $b_0$ and $b_1$ are estimated by ordinary least squares (Lavagnini & Magno, 2007, Eq. 3–4):

$$b_1 = \frac{\sum_{i=1}^{n}(x_i - \bar{x})\, y_i}{\sum_{i=1}^{n}(x_i - \bar{x})^2} \tag{Eq. 4}$$

$$b_0 = \bar{y} - b_1 \bar{x} \tag{Eq. 3}$$

where $\bar{x} = \frac{1}{n}\sum x_i$ and $\bar{y} = \frac{1}{n}\sum y_i$ are the sample means, and $n$ is the total number of calibration points. OLS minimizes the sum of squared residuals $\sum(y_i - \hat{y}_i)^2$.

---

## 3. Residual Standard Deviation

The residual standard deviation $s_{y/x}$ estimates the measurement noise $\sigma$ around the fitted line (Lavagnini & Magno, 2007, Eq. 5):

$$s_{y/x} = \sqrt{\frac{\sum_{i=1}^{n}(y_i - \hat{y}_i)^2}{n - 2}} \tag{Eq. 5}$$

where $(y_i - \hat{y}_i)$ is the residual for observation $i$ — the difference between the measured response and the value predicted by the fitted line. The denominator $n - 2$ reflects two degrees of freedom consumed by estimating $b_0$ and $b_1$. $s_{y/x}$ is the primary diagnostic of fit quality and the foundation for LOD, LOQ, and prediction confidence intervals.

---

## 4. Inverse Regression — `CalibrationModel.predict()`

The analytical application of the calibration curve is **inverse regression**: given a new instrumental response $y_0$ from an unknown sample, estimate the concentration $\hat{x}_0$ (Lavagnini & Magno, 2007, Section III.C):

$$\hat{x}_0 = \frac{y_0 - b_0}{b_1} \tag{Eq. 10, simplified}$$

Internally, `predict()` calls `extract_dpv_features` on the raw scan to obtain $y_0$, then applies this equation. If `log_x=True`, the result is back-transformed: $c = 10^{\hat{x}_0}$.

**Variance of the predicted concentration.** The uncertainty of $\hat{x}_0$ has two contributions: uncertainty in the fitted line ($b_0$, $b_1$) and uncertainty of the new measurement. From Lavagnini & Magno (2007), Eq. 10:

$$s^2_{\hat{x}_0} = \frac{s^2_{y/x}}{b_1^2} \left( \frac{1}{m} + \frac{1}{n} + \frac{(\hat{x}_0 - \bar{x})^2}{\sum_{i=1}^{n}(x_i - \bar{x})^2} \right)$$

where $m$ is the number of replicate measurements of the unknown sample (default $m = 1$). The third term inside the parentheses causes predictions far from the center of the calibration range to have wider confidence intervals — a physically meaningful property.

**Confidence interval.** The $(1 - \alpha) \times 100\%$ confidence interval on the true concentration is (Lavagnini & Magno, 2007, Eq. 11):

$$\hat{x}_0 \pm t_{(1 - \alpha/2,\; n-2)} \cdot s_{\hat{x}_0} \tag{Eq. 11}$$

where $t_{(1-\alpha/2,\; n-2)}$ is the critical value of Student's $t$-distribution at $n - 2$ degrees of freedom. Default $\alpha = 0.05$ gives a 95% confidence interval. When `log_x=True`, the confidence bounds are back-transformed asymmetrically: $\left[10^{\hat{x}_0^-},\; 10^{\hat{x}_0^+}\right]$.

---

## 5. Limit of Detection — `CalibrationModel.lod_M`

The limit of detection is the lowest concentration at which the analyte signal can be reliably distinguished from background noise (Lavagnini & Magno, 2007, Section V; Miller & Miller, 1988).

The net signal at the detection limit equals three times the residual standard deviation:

$$L_D = 3 \cdot s_{y/x}$$

Converted to the concentration domain via the calibration slope:

$$x_D = \frac{3 \cdot s_{y/x}}{b_1}$$

The factor of 3 corresponds to type I and type II error rates of $\alpha = \beta = 0.05$ under a Gaussian noise assumption, since $2 \times 1.645 \approx 3.29 \approx 3$ (Lavagnini & Magno, 2007, p. 14).

When `log_x=True`:

$$\text{LOD} = 10^{x_D}$$

Concentrations below LOD are indistinguishable from noise. `PredictionResult.status` returns `"below_lod"` when the predicted concentration falls below this threshold.

---

## 6. Limit of Quantification — `CalibrationModel.loq_M`

The limit of quantification is the lowest concentration at which the analyte can be reliably measured with sufficient precision for quantitative reporting (Lavagnini & Magno, 2007, Section III.D; Oppenheimer et al., 1983):

$$x_Q = \frac{10 \cdot s_{y/x}}{b_1}$$

When `log_x=True`:

$$\text{LOQ} = 10^{x_Q}$$

Between LOD and LOQ, analyte presence can be confirmed but concentration cannot be reliably quantified. Above LOQ, the calibration curve produces valid quantitative estimates. `PredictionResult.status` returns `"detected"` between LOD and LOQ, and `"quantifiable"` above LOQ.

---

## 7. RMSECV - Leave-One-Out Cross Validation

RMSECV is the standard chemometric error estimate for calibration models (Martens & Næs, 1989). Unlike $R^2$ computed on training data, RMSECV simulates prediction of new samples by withholding each calibration point in turn.

For each point $i = 1, \ldots, n$:

1. Remove point $i$ from the dataset
2. Refit $b_0^{(-i)},\; b_1^{(-i)}$ on the remaining $n - 1$ points using Eq. 3–4
3. Predict the withheld point: $\hat{x}_i^{(-i)} = (y_i - b_0^{(-i)}) / b_1^{(-i)}$
4. Compute squared error: $(x_i - \hat{x}_i^{(-i)})^2$

$$\text{RMSECV} = \sqrt{\frac{1}{n} \sum_{i=1}^{n} \left(x_i - \hat{x}_i^{(-i)}\right)^2}$$

When `log_x=True`, RMSECV is in units of decades of concentration. An RMSECV of 0.5 means predictions are off by half a decade on average. RMSECV is not back-transformed since it is a symmetric error metric defined in fitting space.

---

## 8. R²

$$R^2 = 1 - \frac{\sum(y_i - \hat{y}_i)^2}{\sum(y_i - \bar{y})^2}$$

Reported for convention. Lavagnini & Magno (2007, Section III.A) explicitly caution that $R^2$ close to unity does not necessarily indicate a correct linear model and can lead to misinterpretation. The primary diagnostic of fit quality is $s_{y/x}$ and the residual plot.

---

## 9. Prediction Status

Each `PredictionResult` carries a `status` field summarizing where the predicted concentration falls relative to the model's detection limits:

| Status | Condition | Interpretation |
|---|---|---|
| `"below_lod"` | $c < \text{LOD}$ | Signal indistinguishable from noise |
| `"detected"` | $\text{LOD} \leq c < \text{LOQ}$ | Presence confirmed, quantity unreliable |
| `"quantifiable"` | $c \geq \text{LOQ}$ | Valid quantitative measurement |

---

## References

Lavagnini, I. & Magno, F. (2007). A statistical overview on univariate calibration, inverse regression, and detection limits: application to gas chromatography/mass spectrometry technique. *Mass Spectrometry Reviews*, 26, 1–18. https://doi.org/10.1002/mas.20100