"""FastMCP lifespan: creates and tears down all shared server resources."""

from __future__ import annotations

import asyncio
import sys
from contextlib import asynccontextmanager, suppress
from pathlib import Path
from typing import TYPE_CHECKING

import aiosqlite
import structlog

from procontext import __version__
from procontext.cache import Cache
from procontext.config import Settings, registry_additional_info_path, registry_paths
from procontext.fetch.client import build_http_client
from procontext.fetch.processors import build_html_processor_pipeline
from procontext.fetch.security import build_allowlist
from procontext.fetch.service import Fetcher
from procontext.registry import (
    build_indexes,
    load_registry,
    load_registry_additional_info,
    load_registry_state,
)
from procontext.schedulers import (
    run_cache_cleanup_scheduler,
    run_cache_startup_cleanup,
    run_registry_startup_check,
    run_registry_update_scheduler,
)
from procontext.state import AppState

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from mcp.server.fastmcp import FastMCP

log = structlog.get_logger()


class _StdoutGuard:
    """Drop-in replacement for ``sys.stdout`` that blocks writes.

    In stdio mode, stdout is owned by the MCP JSON-RPC stream.  Any write
    from application code (``print()``, ``sys.stdout.write()``, stray
    ``logging.StreamHandler``) would corrupt the protocol.  This guard is
    installed after MCP has captured ``sys.stdout.buffer`` for its own use,
    so the protocol transport is unaffected.

    The ``buffer`` property delegates to the real binary stream so that
    low-level code that bypasses ``sys.stdout.write()`` still works.
    """

    def write(self, data: str) -> int:
        raise RuntimeError(
            "Attempted write to stdout, which is reserved for the MCP JSON-RPC "
            "stream in stdio mode. Use structlog (writes to stderr) instead."
        )

    def flush(self) -> None:
        pass

    @property
    def buffer(self) -> object:
        return sys.__stdout__.buffer if sys.__stdout__ else None


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncGenerator[AppState, None]:
    """Create and tear down all shared resources for the server's lifetime."""
    settings = Settings()

    log.info(
        "server_starting",
        version=__version__,
        transport=settings.server.transport,
    )

    registry_path, registry_state_path = registry_paths(settings)
    additional_info_path = registry_additional_info_path(settings)

    # Registry availability is guaranteed by main() before the server starts.
    registry = load_registry(
        local_registry_path=registry_path,
        local_state_path=registry_state_path,
    )
    if registry is None:
        raise RuntimeError(
            "Registry unavailable at server startup — this should have been caught before "
            "the server started. This is a bug."
        )

    entries, version = registry
    registry_state = load_registry_state(registry_state_path)
    additional_info = load_registry_additional_info(
        local_additional_info_path=additional_info_path,
        registry_state=registry_state,
    )
    log.info(
        "registry_loaded",
        source="disk",
        entries=len(entries),
        version=version,
        path=str(registry_path),
    )
    indexes = build_indexes(entries)

    http_client = build_http_client(settings.fetcher)
    allowlist = build_allowlist(entries, extra_domains=settings.fetcher.extra_allowed_domains)

    db_path = Path(settings.cache.db_path).expanduser()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(db_path))
    cache = Cache(db)
    await cache.init_db()

    # Restore domains discovered in previous sessions so cache hits remain
    # reachable across restarts when allowlist_expansion is "discovered".
    if settings.fetcher.allowlist_expansion == "discovered":
        cached_domains = await cache.load_discovered_domains()
        if cached_domains:
            allowlist = allowlist | cached_domains
            log.info("allowlist_restored_from_cache", domain_count=len(cached_domains))

    html_processor_pipeline = build_html_processor_pipeline(settings.fetcher.html_processors)
    fetcher = Fetcher(
        http_client,
        settings.fetcher,
        html_processor_pipeline=html_processor_pipeline,
    )

    state = AppState(
        settings=settings,
        indexes=indexes,
        registry_version=version,
        registry_path=registry_path,
        registry_state_path=registry_state_path,
        registry_additional_info_path=additional_info_path,
        registry_additional_info_download_url=(
            registry_state.additional_info_download_url if registry_state is not None else None
        ),
        registry_additional_info_checksum=(
            registry_state.additional_info_checksum if registry_state is not None else None
        ),
        http_client=http_client,
        cache=cache,
        fetcher=fetcher,
        allowlist=allowlist,
        md_probe_base_urls=frozenset(
            additional_info.useful_md_probe_base_urls if additional_info is not None else []
        ),
    )

    # In stdio mode, install the stdout guard to prevent accidental writes
    # that would corrupt the MCP JSON-RPC stream. This runs *after* the MCP
    # transport has already captured sys.stdout.buffer for its own use.
    original_stdout = sys.stdout
    if settings.server.transport == "stdio":
        sys.stdout = _StdoutGuard()  # type: ignore[assignment]

    if settings.server.transport == "http":
        registry_update_task = asyncio.create_task(run_registry_update_scheduler(state))
        cache_cleanup_task = asyncio.create_task(run_cache_cleanup_scheduler(state))
    else:
        registry_update_task = asyncio.create_task(run_registry_startup_check(state))
        cache_cleanup_task = asyncio.create_task(run_cache_startup_cleanup(state))

    log.info(
        "server_started",
        version=__version__,
        transport=settings.server.transport,
        registry_entries=len(state.indexes.by_id),
        registry_version=state.registry_version,
    )

    try:
        yield state
    finally:
        sys.stdout = original_stdout
        registry_update_task.cancel()
        cache_cleanup_task.cancel()
        with suppress(asyncio.CancelledError):
            await registry_update_task
        with suppress(asyncio.CancelledError):
            await cache_cleanup_task
        await http_client.aclose()
        await db.close()
        log.info("server_stopping")
