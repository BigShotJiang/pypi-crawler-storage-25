"""Tests for MCPSecurityMiddleware (Phase 4 — HTTP transport).

Each test exercises the middleware directly via httpx's ASGI transport so no
real server is started.  The inner app is a trivial 200-OK echo that never
runs if the middleware short-circuits.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import httpx
import pytest

from procontext.config import Settings
from procontext.mcp.http_transport import (
    SUPPORTED_PROTOCOL_VERSIONS,
    MCPSecurityMiddleware,
    run_http_server,
)

if TYPE_CHECKING:
    from starlette.types import ASGIApp, Receive, Scope, Send


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _ok_app(scope: Scope, receive: Receive, send: Send) -> None:
    """Minimal ASGI app that always returns 200 OK."""
    await send({"type": "http.response.start", "status": 200, "headers": []})
    await send({"type": "http.response.body", "body": b"ok"})


def _client(app: ASGIApp) -> httpx.AsyncClient:
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://localhost",
    )


# ---------------------------------------------------------------------------
# Auth disabled (default)
# ---------------------------------------------------------------------------


async def test_auth_disabled_allows_any_request() -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp")
    assert response.status_code == 200


async def test_auth_disabled_allows_request_with_auth_header() -> None:
    """Even if a client sends a bearer token, it is ignored when auth is off."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Authorization": "Bearer whatever"})
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# Auth enabled
# ---------------------------------------------------------------------------


async def test_auth_enabled_correct_key_passes() -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=True, auth_key="secret-key")
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Authorization": "Bearer secret-key"})
    assert response.status_code == 200


async def test_auth_enabled_wrong_key_returns_401() -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=True, auth_key="secret-key")
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Authorization": "Bearer wrong-key"})
    assert response.status_code == 401


async def test_auth_enabled_missing_header_returns_401() -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=True, auth_key="secret-key")
    async with _client(app) as client:
        response = await client.get("/mcp")
    assert response.status_code == 401


async def test_auth_enabled_malformed_header_returns_401() -> None:
    """Header present but not in 'Bearer <key>' format."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=True, auth_key="secret-key")
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Authorization": "secret-key"})
    assert response.status_code == 401


# ---------------------------------------------------------------------------
# Origin validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "origin",
    [
        "http://localhost",
        "http://localhost:8080",
        "https://localhost",
        "https://localhost:9000",
        "http://127.0.0.1",
        "http://127.0.0.1:3000",
        "http://[::1]",
        "http://[::1]:8080",
    ],
)
async def test_origin_localhost_allowed(origin: str) -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Origin": origin})
    assert response.status_code == 200


@pytest.mark.parametrize(
    "origin",
    [
        "https://evil.com",
        "http://attacker.localhost.evil.com",
        "http://192.168.1.1",
        "http://0.0.0.0",
    ],
)
async def test_origin_external_blocked(origin: str) -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Origin": origin})
    assert response.status_code == 403


async def test_no_origin_header_allowed() -> None:
    """CLI tools and non-browser clients don't send Origin — must be allowed."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp")
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# Protocol version validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("version", sorted(SUPPORTED_PROTOCOL_VERSIONS))
async def test_known_protocol_version_allowed(version: str) -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"MCP-Protocol-Version": version})
    assert response.status_code == 200


async def test_unknown_protocol_version_blocked() -> None:
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"MCP-Protocol-Version": "1999-01-01"})
    assert response.status_code == 400


async def test_absent_protocol_version_allowed() -> None:
    """Clients that omit the header are not rejected."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp")
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# Loopback edge cases and check ordering
# ---------------------------------------------------------------------------


async def test_non_loopback_ipv6_origin_blocked() -> None:
    """Only IPv6 loopback is allowed; other IPv6 hosts remain blocked."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Origin": "http://[2001:db8::1]:8080"})
    assert response.status_code == 403


@pytest.mark.parametrize(
    "origin",
    [
        "ftp://localhost",
        "ws://localhost",
    ],
)
async def test_non_http_scheme_origin_blocked(origin: str) -> None:
    """Only http/https schemes are accepted in Origin headers."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Origin": origin})
    assert response.status_code == 403


@pytest.mark.parametrize(
    "origin",
    [
        "http://localhost?redirect=evil.com",
        "http://localhost#fragment",
    ],
)
async def test_origin_with_query_or_fragment_blocked(origin: str) -> None:
    """Origins with query strings or fragments are not valid and must be rejected."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Origin": origin})
    assert response.status_code == 403


async def test_origin_with_no_hostname_blocked() -> None:
    """An origin that parses to no hostname is rejected."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=False)
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Origin": "http://"})
    assert response.status_code == 403


# ---------------------------------------------------------------------------
# HTTP server startup
# ---------------------------------------------------------------------------


def test_run_http_server_generates_auth_key_and_logs_warning() -> None:
    fake_mcp = MagicMock()
    fake_http_app = MagicMock()
    fake_mcp.streamable_http_app.return_value = fake_http_app
    settings = Settings(
        server={
            "transport": "http",
            "host": "127.0.0.1",
            "port": 8081,
            "auth_enabled": True,
            "auth_key": "",
        }
    )

    fake_log = MagicMock()
    fake_log.bind.return_value = fake_log

    with (
        patch("procontext.mcp.http_transport.log", fake_log),
        patch(
            "procontext.mcp.http_transport.secrets.token_urlsafe",
            return_value="generated-key",
        ) as mock_key,
        patch("procontext.mcp.http_transport.uvicorn.run") as mock_uvicorn_run,
    ):
        run_http_server(fake_mcp, settings)

    mock_key.assert_called_once_with(32)
    fake_log.bind.assert_called_once_with(transport="http")
    fake_log.warning.assert_called_once_with(
        "http_auth_key_auto_generated",
        auth_key="generated-key",
    )
    fake_mcp.streamable_http_app.assert_called_once_with()
    mock_uvicorn_run.assert_called_once()

    secured_app = mock_uvicorn_run.call_args.args[0]
    assert isinstance(secured_app, MCPSecurityMiddleware)
    assert secured_app.app is fake_http_app
    assert secured_app.auth_enabled is True
    assert secured_app.auth_key == "generated-key"
    assert mock_uvicorn_run.call_args.kwargs["host"] == "127.0.0.1"
    assert mock_uvicorn_run.call_args.kwargs["port"] == 8081
    assert mock_uvicorn_run.call_args.kwargs["log_config"] is None


def test_run_http_server_logs_when_auth_disabled() -> None:
    fake_mcp = MagicMock()
    fake_http_app = MagicMock()
    fake_mcp.streamable_http_app.return_value = fake_http_app
    settings = Settings(
        server={
            "transport": "http",
            "host": "0.0.0.0",
            "port": 9090,
            "auth_enabled": False,
            "auth_key": "",
        }
    )

    fake_log = MagicMock()
    fake_log.bind.return_value = fake_log

    with (
        patch("procontext.mcp.http_transport.log", fake_log),
        patch("procontext.mcp.http_transport.secrets.token_urlsafe") as mock_key,
        patch("procontext.mcp.http_transport.uvicorn.run") as mock_uvicorn_run,
    ):
        run_http_server(fake_mcp, settings)

    mock_key.assert_not_called()
    fake_log.bind.assert_called_once_with(transport="http")
    fake_log.warning.assert_called_once_with("http_auth_disabled")
    mock_uvicorn_run.assert_called_once()

    secured_app = mock_uvicorn_run.call_args.args[0]
    assert isinstance(secured_app, MCPSecurityMiddleware)
    assert secured_app.app is fake_http_app
    assert secured_app.auth_enabled is False
    assert secured_app.auth_key is None
    assert mock_uvicorn_run.call_args.kwargs["host"] == "0.0.0.0"
    assert mock_uvicorn_run.call_args.kwargs["port"] == 9090


async def test_bearer_lowercase_returns_401() -> None:
    """'bearer' (lowercase) does not match 'Bearer ' prefix check — returns 401."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=True, auth_key="secret-key")
    async with _client(app) as client:
        response = await client.get("/mcp", headers={"Authorization": "bearer secret-key"})
    assert response.status_code == 401


async def test_auth_checked_before_origin() -> None:
    """With auth enabled, a bad key returns 401 even if origin would be forbidden."""
    app = MCPSecurityMiddleware(_ok_app, auth_enabled=True, auth_key="key")
    async with _client(app) as client:
        response = await client.get(
            "/mcp",
            headers={"Authorization": "Bearer wrong", "Origin": "https://evil.com"},
        )
    assert response.status_code == 401
