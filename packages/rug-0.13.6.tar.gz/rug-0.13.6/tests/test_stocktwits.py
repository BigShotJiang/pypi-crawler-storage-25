import os
import sys

sys.path.insert(0, os.path.abspath("../rug"))

from datetime import date

from rug import StockTwits


def test_get_earnings_calendar():
    api = StockTwits()
    earnings = api.get_earnings_calendar()

    assert type(earnings) is list
    assert type(earnings[0]) is dict
    assert list(earnings[0].keys()) == ["date", "symbol", "when"]
    assert type(earnings[0]["date"]) is date
