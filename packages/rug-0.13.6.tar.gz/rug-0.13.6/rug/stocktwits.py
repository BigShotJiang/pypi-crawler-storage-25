import re
import time
from datetime import date

import chompjs

from .base import BaseAPI
from .exceptions import DataException, HttpException


class StockTwits(BaseAPI):
    def get_earnings_calendar(self):
        """
        Fetches upcomming earnings annoucements within next 14 days.

        Each earning dict has the following structure:

        - date
        - symbol
        - when (BEFORE_OPEN or AFTER_CLOSE)

        :return: List of earning objects.
        :rtype: list
        """

        try:
            response = self._get(
                "https://stockanalysis.com/stocks/earnings-calendar/",
                headers={"User-Agent": self.user_agent},
            )
        except Exception as e:
            raise HttpException from e

        html = response.text
        finds = re.findall("(data: \[.*\])", html)
        data = []

        # No earnings whatsoever.
        if not len(finds):
            return data

        try:
            js_obj = chompjs.parse_js_object(finds[0])
        except Exception as e:
            raise DataException(
                f"Couldn't parse JS data object for {self.symbol}"
            ) from e

        for earning in js_obj[1]["data"]["earnings"]:
            for day in earning["days"]:
                for symbol in day["symbols"]:
                    data.append(
                        {
                            "date": date(*time.strptime(day["date"], "%Y-%m-%d")[:3]),
                            "symbol": symbol["s"],
                            "when": (
                                "BEFORE_OPEN" if "bmo" == symbol["t"] else "AFTER_CLOSE"
                            ),
                        }
                    )

        return data
