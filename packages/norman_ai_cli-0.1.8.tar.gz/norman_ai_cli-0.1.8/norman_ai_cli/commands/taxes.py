"""Tax commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, confirm_action, dry_run_guard

app = typer.Typer(name="taxes", help="Tax reports and compliance")

REPORT_TABLE = TableConfig(
    columns=[
        ("publicId", "ID"),
        ("taxType", "Type"),
        ("reportPeriod", "Period"),
        ("status", "Status"),
        ("totalTax", "Tax Amount"),
    ],
    wide_columns=[("createdAt", "Created"), ("submittedAt", "Submitted")],
    title="Tax Reports",
)


@app.command()
@handle_errors
def reports() -> None:
    """List all tax reports."""
    client = get_api_client()
    result = client.get("api/v1/taxes/reports/")
    get_formatter().output(result, REPORT_TABLE)


@app.command()
@handle_errors
def report(
    report_id: str = typer.Argument(..., help="Report ID"),
) -> None:
    """Get a specific tax report."""
    client = get_api_client()
    result = client.get(f"api/v1/taxes/reports/{report_id}/")
    get_formatter().output(result)


@app.command()
@handle_errors
def validate(
    tax_number: str = typer.Option(..., "--number", help="Tax number to validate"),
    region: str = typer.Option(..., "--region", help="Region code (e.g. DE, EU)"),
) -> None:
    """Validate a tax number."""
    client = get_api_client()
    result = client.post("api/v1/taxes/check-tax-number/", {"taxNumber": tax_number, "regionCode": region})
    get_formatter().output(result)


@app.command()
@handle_errors
def preview(
    report_id: str = typer.Argument(..., help="Report ID"),
) -> None:
    """Generate a Finanzamt preview for a tax report."""
    client = get_api_client()
    result = client.post(f"api/v1/taxes/reports/{report_id}/generate-preview-url/")
    get_formatter().output(result)


@app.command()
@handle_errors
def submit(
    report_id: str = typer.Argument(..., help="Report ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Submit a tax report to the Finanzamt."""
    from norman_ai_cli.app import state
    confirm_action(f"Submit tax report {report_id}? This cannot be undone.", no_input=state.no_input or yes)

    if dry_run_guard(state.dry_run, "POST", f"reports/{report_id}/submit-report/", None):
        return

    client = get_api_client()
    result = client.post(f"api/v1/taxes/reports/{report_id}/submit-report/")
    get_formatter().output(result)


@app.command()
@handle_errors
def states() -> None:
    """List available tax states."""
    client = get_api_client()
    result = client.get("api/v1/taxes/states/")
    get_formatter().output(result)


@app.command()
@handle_errors
def settings() -> None:
    """Show company tax settings."""
    client = get_api_client()
    result = client.get("api/v1/taxes/tax-settings/")
    get_formatter().output(result)


@app.command()
@handle_errors
def stats() -> None:
    """Get company tax statistics."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/company-tax-statistic/")
    get_formatter().output(result)


@app.command("vat-next")
@handle_errors
def vat_next() -> None:
    """Get the next VAT report deadline and amount."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/vat-next-report-amount/")
    get_formatter().output(result)
