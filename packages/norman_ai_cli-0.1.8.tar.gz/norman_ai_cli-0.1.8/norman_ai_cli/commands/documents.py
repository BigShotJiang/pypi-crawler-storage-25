"""Document and attachment commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors

app = typer.Typer(name="documents", help="Document and receipt management")

DOC_TABLE = TableConfig(
    columns=[
        ("publicId", "ID"),
        ("fileName", "File"),
        ("attachmentType", "Type"),
        ("brandName", "Brand"),
        ("linked", "Linked"),
    ],
    wide_columns=[("amount", "Amount"), ("createdAt", "Created")],
    title="Documents",
)


@app.command("list")
@handle_errors
def list_documents(
    name: Optional[str] = typer.Option(None, "--name", help="Search by file name"),
    linked: Optional[bool] = typer.Option(None, "--linked/--unlinked", help="Filter by link status"),
    doc_type: Optional[str] = typer.Option(None, "--type", help="Attachment type"),
    brand: Optional[str] = typer.Option(None, "--brand", help="Brand name"),
) -> None:
    """List documents/attachments."""
    client = get_api_client()
    params = {}
    if name: params["fileName"] = name
    if linked is not None: params["linked"] = linked
    if doc_type: params["attachmentType"] = doc_type
    if brand: params["brandName"] = brand

    result = client.get(f"api/v1/companies/{client.company_id}/attachments/", **params)
    get_formatter().output(result, DOC_TABLE)


@app.command()
@handle_errors
def upload(
    file_path: str = typer.Argument(..., help="Local file path or URL to upload"),
    cashflow_type: Optional[str] = typer.Option(None, "--type", help="INCOME or EXPENSE"),
    description: Optional[str] = typer.Option(None, "-d", help="Description"),
) -> None:
    """Upload a document/receipt."""
    from norman_ai_cli.app import state
    from norman_ai_cli.utils import dry_run_guard

    data = {"filePath": file_path}
    if cashflow_type: data["cashflowType"] = cashflow_type
    if description: data["description"] = description

    if dry_run_guard(state.dry_run, "POST", "attachments/", data):
        return

    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/attachments/",
        {"filePaths": [file_path], "cashflowType": cashflow_type},
    )
    get_formatter().output(result)


@app.command("upload-bulk")
@handle_errors
def upload_bulk(
    files: list[str] = typer.Argument(..., help="File paths or URLs"),
    cashflow_type: Optional[str] = typer.Option(None, "--type", help="INCOME or EXPENSE"),
) -> None:
    """Upload multiple documents at once."""
    client = get_api_client()
    data = {"filePaths": files}
    if cashflow_type: data["cashflowType"] = cashflow_type

    result = client.post(
        f"api/v1/companies/{client.company_id}/attachments/bulk/", data
    )
    get_formatter().output(result)


@app.command()
@handle_errors
def link(
    attachment_id: str = typer.Argument(..., help="Attachment ID"),
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
) -> None:
    """Link a document to a transaction."""
    client = get_api_client()
    result = client.post(
        f"api/v1/companies/{client.company_id}/attachments/{attachment_id}/link-transaction/",
        {"transactionId": transaction_id},
    )
    get_formatter().success(f"Document {attachment_id} linked to transaction {transaction_id}.")
