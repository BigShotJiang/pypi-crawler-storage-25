"""Tax registration commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter
from norman_ai_cli.utils import handle_errors

app = typer.Typer(name="registration", help="Tax registration and setup")


@app.command()
@handle_errors
def choices(
    choice_type: str = typer.Argument(
        ...,
        help="Type: civil-status, genders, religions, income-taxation-methods, "
             "profession-founding-articles, tax-states, profit-detections, bank-account-owners",
    ),
) -> None:
    """Get available options for tax registration fields."""
    client = get_api_client()
    result = client.get(f"api/v1/choices/{choice_type}/")
    get_formatter().output(result)


@app.command()
@handle_errors
def offices(
    search: Optional[str] = typer.Option(None, "-s", "--search", help="Search term"),
) -> None:
    """List German tax offices."""
    client = get_api_client()
    params = {}
    if search: params["search"] = search
    result = client.get(f"api/v1/companies/{client.company_id}/tax-registration/offices/", **params)
    get_formatter().output(result)


@app.command()
@handle_errors
def status() -> None:
    """Get current tax registration status."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/tax-registration/")
    get_formatter().output(result)
