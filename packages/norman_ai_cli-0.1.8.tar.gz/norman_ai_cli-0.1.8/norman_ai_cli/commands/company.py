"""Company commands."""

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter, TableConfig
from norman_ai_cli.utils import handle_errors, dry_run_guard

app = typer.Typer(name="company", help="Company information and settings")


@app.command()
@handle_errors
def details() -> None:
    """Show company details."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/")
    get_formatter().output(result)


@app.command()
@handle_errors
def balance() -> None:
    """Show current company balance."""
    client = get_api_client()
    result = client.get(f"api/v1/companies/{client.company_id}/balance/")
    accounts = result.get("results", [])
    total = sum(float(a.get("balance", 0)) for a in accounts if a.get("status") == "ACTIVE")
    currency = accounts[0].get("currency", "EUR") if accounts else "EUR"

    fmt = get_formatter()
    fmt.output({
        "total_balance": f"{total:.2f} {currency}",
        "active_accounts": len([a for a in accounts if a.get("status") == "ACTIVE"]),
        "accounts": [
            {"name": a.get("accountName", ""), "balance": a.get("balance", "0"), "iban": a.get("iban", "")}
            for a in accounts if a.get("status") == "ACTIVE"
        ],
    })


@app.command()
@handle_errors
def update(
    name: str = typer.Option(None, help="Company name"),
    phone: str = typer.Option(None, help="Phone number"),
    vat_id: str = typer.Option(None, "--vat-id", help="VAT ID"),
    tax_id: str = typer.Option(None, "--tax-id", help="Tax ID"),
    address: str = typer.Option(None, help="Street address"),
    city: str = typer.Option(None, help="City"),
    zip_code: str = typer.Option(None, "--zip", help="ZIP code"),
) -> None:
    """Update company details."""
    from norman_ai_cli.app import state
    data = {}
    if name: data["name"] = name
    if phone: data["phone"] = phone
    if vat_id: data["vatId"] = vat_id
    if tax_id: data["taxId"] = tax_id
    if address: data["address"] = address
    if city: data["city"] = city
    if zip_code: data["zipCode"] = zip_code

    if not data:
        get_formatter().error({"error": "No fields to update. Use --help to see options."})
        return

    if dry_run_guard(state.dry_run, "PATCH", f"companies/{{}}", data):
        return

    client = get_api_client()
    result = client.patch(f"api/v1/companies/{client.company_id}/", data)
    get_formatter().output(result)


@app.command()
@handle_errors
def categories(
    cashflow_type: str = typer.Option(None, "--type", help="Filter: INCOME or EXPENSE"),
) -> None:
    """List company categories (chart of accounts)."""
    client = get_api_client()
    params = {}
    if cashflow_type:
        params["cashflowType"] = cashflow_type
    result = client.get("api/v1/accounting/company-categories/", **params)
    get_formatter().output(result, TableConfig(
        columns=[("code", "Code"), ("name", "Name"), ("cashflowType", "Type")],
        title="Company Categories",
    ))


@app.command("datev-export")
@handle_errors
def datev_export(
    date_from: str = typer.Option(..., "--from", help="Start date (YYYY-MM-DD)"),
    date_to: str = typer.Option(..., "--to", help="End date (YYYY-MM-DD)"),
) -> None:
    """Trigger a DATEV export for a date range."""
    from norman_ai_cli.app import state
    data = {"dateFrom": date_from, "dateTo": date_to, "includeDocuments": True}

    if dry_run_guard(state.dry_run, "POST", "datev-export/", data):
        return

    client = get_api_client()
    result = client.post(f"api/v1/companies/{client.company_id}/accounting/datev-export/", data)
    get_formatter().output(result)
