"""Tax advisor commands."""

from typing import Optional

import typer

from norman_ai_cli.client import get_api_client
from norman_ai_cli.output import get_formatter
from norman_ai_cli.utils import handle_errors, dry_run_guard

app = typer.Typer(name="advisor", help="Tax advisor tools")


@app.command()
@handle_errors
def overview(
    company_id: str = typer.Argument(..., help="Client company ID"),
) -> None:
    """Get a financial overview for a client company."""
    client = get_api_client()
    result = client.get(f"api/v1/tax-advisor/clients/{company_id}/overview/")
    get_formatter().output(result)


@app.command("missing-docs")
@handle_errors
def missing_docs(
    company_id: str = typer.Argument(..., help="Client company ID"),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date"),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date"),
) -> None:
    """List transactions missing documents for a client."""
    client = get_api_client()
    params = {}
    if from_date: params["dateFrom"] = from_date
    if to_date: params["dateTo"] = to_date
    result = client.get(f"api/v1/tax-advisor/clients/{company_id}/missing-documents/", **params)
    get_formatter().output(result)


@app.command()
@handle_errors
def compliance(
    company_id: str = typer.Argument(..., help="Client company ID"),
) -> None:
    """Check tax compliance status for a client."""
    client = get_api_client()
    result = client.get(f"api/v1/tax-advisor/clients/{company_id}/tax-compliance/")
    get_formatter().output(result)


@app.command()
@handle_errors
def ping(
    company_id: str = typer.Argument(..., help="Client company ID"),
    transaction_ids: list[str] = typer.Argument(..., help="Transaction IDs to request docs for"),
) -> None:
    """Send document request reminders to a client."""
    from norman_ai_cli.app import state
    if dry_run_guard(state.dry_run, "POST", f"clients/{company_id}/ping/", {"transactionIds": transaction_ids}):
        return

    client = get_api_client()
    result = client.post(
        f"api/v1/tax-advisor/clients/{company_id}/ping/",
        {"transactionIds": transaction_ids},
    )
    get_formatter().success("Document request sent.")
