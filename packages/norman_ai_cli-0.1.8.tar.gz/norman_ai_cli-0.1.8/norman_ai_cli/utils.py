"""Shared utilities for norman-ai CLI."""

import functools
import sys
from typing import Callable

import typer
from rich.console import Console

from norman_ai_cli.output import get_formatter

console = Console(stderr=True)


def handle_errors(func: Callable) -> Callable:
    """Decorator: catch exceptions and output formatted errors."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except SystemExit:
            raise
        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted.[/dim]")
            sys.exit(130)
        except Exception as e:
            fmt = get_formatter()
            fmt.error({"error": str(e)})
    return wrapper


def confirm_action(message: str, no_input: bool = False) -> None:
    """Ask for confirmation. In --no-input mode, proceed without asking."""
    if no_input:
        return
    if not typer.confirm(message):
        raise typer.Abort()


def dry_run_guard(dry_run: bool, method: str, path: str, data: dict | None = None) -> bool:
    """If --dry-run, print what would happen and return True (skip execution)."""
    if not dry_run:
        return False
    fmt = get_formatter()
    preview = {"dry_run": True, "method": method, "path": path}
    if data:
        preview["body"] = data
    fmt.output(preview)
    return True
