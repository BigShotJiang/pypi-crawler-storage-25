#!/usr/bin/env python
"""Allow running as `python -m norman_ai_cli`."""

from norman_ai_cli.app import main

if __name__ == "__main__":
    main()
