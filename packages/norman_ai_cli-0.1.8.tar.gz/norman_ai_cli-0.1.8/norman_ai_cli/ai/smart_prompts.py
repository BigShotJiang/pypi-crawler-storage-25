"""Smart prompts — pre-built templates for common financial tasks.

Inspired by the frontend's SmartPrompts component. These are used in two ways:
1. `norman-ai prompts` — show available prompts interactively
2. Smart prompt suggestions in chat mode
"""

from dataclasses import dataclass, field
from typing import Optional

from rich.console import Console
from rich.prompt import Prompt, IntPrompt
from rich.table import Table


@dataclass
class PromptField:
    """An interactive field in a smart prompt template."""
    name: str
    label: str
    field_type: str = "text"  # text, number, date, select
    options: list[str] = field(default_factory=list)
    default: Optional[str] = None


@dataclass
class SmartPrompt:
    """A pre-built prompt template."""
    key: str
    label: str
    template: str
    fields: list[PromptField] = field(default_factory=list)
    category: str = "general"


# ── Prompt definitions ───────────────────────────────────────────────────

SMART_PROMPTS: list[SmartPrompt] = [
    # Transactions
    SmartPrompt(
        key="make_transaction",
        label="Create a transaction",
        template="Create a {type} transaction: {description}, amount {amount} EUR, VAT {vat}%, date {date}",
        fields=[
            PromptField("type", "Type", "select", options=["expense", "revenue"]),
            PromptField("description", "Description", "text"),
            PromptField("amount", "Amount", "number"),
            PromptField("vat", "VAT Rate", "select", options=["19", "7", "0"], default="19"),
            PromptField("date", "Date", "date"),
        ],
        category="transactions",
    ),
    SmartPrompt(
        key="last_month_transactions",
        label="Last month's transactions",
        template="Give me a quick rundown of last month's transactions",
        category="transactions",
    ),
    SmartPrompt(
        key="unfinalized",
        label="Unfinalized transactions",
        template="Show me the unfinalized transactions for this month",
        category="transactions",
    ),
    SmartPrompt(
        key="categorize",
        label="Categorize transactions",
        template="Help me categorize my uncategorized transactions",
        category="transactions",
    ),
    # Invoices
    SmartPrompt(
        key="issue_invoice",
        label="Create an invoice",
        template="Create an invoice for client {client} for {amount} EUR for {service_type}",
        fields=[
            PromptField("client", "Client name", "text"),
            PromptField("amount", "Amount", "number"),
            PromptField("service_type", "Type", "select", options=["services", "goods"], default="services"),
        ],
        category="invoices",
    ),
    SmartPrompt(
        key="previous_invoices",
        label="Previous month invoices",
        template="Show the list of invoices for the previous month",
        category="invoices",
    ),
    SmartPrompt(
        key="send_reminder",
        label="Send payment reminder",
        template="Send an overdue payment reminder for invoice {invoice_id}",
        fields=[PromptField("invoice_id", "Invoice ID or number", "text")],
        category="invoices",
    ),
    # Clients
    SmartPrompt(
        key="create_client",
        label="Create a client",
        template="Create a new {type} client: {name}, email {email}",
        fields=[
            PromptField("type", "Type", "select", options=["business", "person"]),
            PromptField("name", "Client name", "text"),
            PromptField("email", "Email", "text"),
        ],
        category="clients",
    ),
    SmartPrompt(
        key="list_clients",
        label="List all clients",
        template="Provide a list of my clients",
        category="clients",
    ),
    # Tax
    SmartPrompt(
        key="tax_deadline",
        label="Next tax deadline",
        template="When's my next tax deadline?",
        category="tax",
    ),
    SmartPrompt(
        key="tax_report",
        label="Review tax reports",
        template="Review my tax reports for {period}",
        fields=[PromptField("period", "Period (e.g. Q1 2025, March 2025)", "text")],
        category="tax",
    ),
    SmartPrompt(
        key="tax_deductions",
        label="Find tax deductions",
        template="Scan my transactions for the past {period} for potentially missed tax deductions",
        fields=[PromptField("period", "Period (e.g. 3 months, 2025)", "text", default="3 months")],
        category="tax",
    ),
    # Financial overview
    SmartPrompt(
        key="financial_overview",
        label="Financial overview",
        template="Give me a complete financial overview of my business",
        category="overview",
    ),
    SmartPrompt(
        key="expense_report",
        label="Expense report",
        template="Generate an expense breakdown report for {period}",
        fields=[PromptField("period", "Period (e.g. March 2025, Q1 2025)", "text")],
        category="overview",
    ),
    SmartPrompt(
        key="monthly_reconciliation",
        label="Monthly reconciliation",
        template="Start monthly reconciliation for {month}",
        fields=[PromptField("month", "Month (e.g. March 2025)", "text")],
        category="overview",
    ),
    # Documents
    SmartPrompt(
        key="find_receipts",
        label="Find missing receipts",
        template="Find missing receipts for my recent transactions",
        category="documents",
    ),
    # Bills (coming soon)
    # SmartPrompt(
    #     key="pay_bill",
    #     label="Pay a bill",
    #     template="Pay the bill from {vendor} for {amount} EUR",
    #     fields=[
    #         PromptField("vendor", "Vendor name", "text"),
    #         PromptField("amount", "Amount", "number"),
    #     ],
    #     category="bills",
    # ),
]


def _fill_template(prompt: SmartPrompt) -> str | None:
    """Interactively fill in a smart prompt's fields. Returns the filled prompt or None if cancelled."""
    console = Console()

    if not prompt.fields:
        return prompt.template

    values = {}
    console.print(f"\n[bold]{prompt.label}[/bold]")
    console.print(f"[dim]{prompt.template}[/dim]\n")

    for f in prompt.fields:
        try:
            if f.field_type == "select" and f.options:
                console.print(f"[bold]{f.label}:[/bold]")
                for i, opt in enumerate(f.options):
                    console.print(f"  {i + 1}. {opt}")
                choice = Prompt.ask("Choice", choices=[str(i + 1) for i in range(len(f.options))], default="1")
                values[f.name] = f.options[int(choice) - 1]
            elif f.field_type == "number":
                val = Prompt.ask(f"[bold]{f.label}[/bold]", default=f.default)
                values[f.name] = val
            elif f.field_type == "date":
                val = Prompt.ask(f"[bold]{f.label}[/bold] (YYYY-MM-DD)", default=f.default)
                values[f.name] = val
            else:
                val = Prompt.ask(f"[bold]{f.label}[/bold]", default=f.default)
                values[f.name] = val
        except (KeyboardInterrupt, EOFError):
            return None

    result = prompt.template
    for key, val in values.items():
        result = result.replace(f"{{{key}}}", str(val))
    return result


def show_smart_prompts() -> None:
    """Show available smart prompts and let user pick one to run."""
    console = Console()

    # Group by category
    categories = {}
    for p in SMART_PROMPTS:
        categories.setdefault(p.category, []).append(p)

    category_labels = {
        "transactions": "Transactions",
        "invoices": "Invoices",
        "clients": "Clients",
        "tax": "Tax",
        "overview": "Financial Overview",
        "documents": "Documents",
        "bills": "Bills",
    }

    # Display all prompts
    table = Table(title="Smart Prompts", show_lines=False)
    table.add_column("#", style="dim", width=4)
    table.add_column("Category", style="cyan")
    table.add_column("Prompt", style="bold")
    table.add_column("Fields", style="dim")

    flat_list = []
    for cat, prompts in categories.items():
        for p in prompts:
            flat_list.append(p)
            fields_str = ", ".join(f.label for f in p.fields) if p.fields else "-"
            table.add_row(
                str(len(flat_list)),
                category_labels.get(cat, cat),
                p.label,
                fields_str,
            )

    console.print(table)
    console.print()

    # Let user pick
    try:
        choice = IntPrompt.ask(
            "Select a prompt to run (or 0 to cancel)",
            default=0,
        )
    except (KeyboardInterrupt, EOFError):
        return

    if choice == 0 or choice > len(flat_list):
        return

    selected = flat_list[choice - 1]
    filled = _fill_template(selected)

    if not filled:
        console.print("[dim]Cancelled.[/dim]")
        return

    console.print(f"\n[bold green]Running:[/bold green] {filled}\n")

    # Execute via the AI agent
    import asyncio
    from norman_ai_cli.ai.agent import run_one_shot
    asyncio.run(run_one_shot(filled))
