"""AI Agent — connects to Norman's hosted AI assistant via HTTP streaming API."""

import json
import logging
from typing import AsyncIterator

import requests

from norman_ai_cli.ai.streaming import stream_sse_to_terminal
from norman_ai_cli.config import get_token, get_company_id, get_environment
from norman_ai_cli.client import get_api_client, _get_api_base_url

logger = logging.getLogger(__name__)


def _fetch_company_info() -> dict | None:
    """Fetch company details for prompt context."""
    try:
        client = get_api_client()
        result = client.get(f"api/v1/companies/{client.company_id}/")
        if "error" not in result:
            return result
    except Exception:
        pass
    return None


def _build_api_url(path: str) -> str:
    """Build full API URL."""
    base = _get_api_base_url()
    return f"{base.rstrip('/')}/{path.lstrip('/')}"


async def run_one_shot(prompt: str, model: str = "gpt-4.1") -> None:
    """Run a one-shot AI query via the hosted streaming API."""
    token = get_token()
    company_id = get_company_id()

    if not token:
        from rich.console import Console
        Console(stderr=True).print("[red]Not authenticated.[/red] Run [bold]norman-ai auth login[/bold] first.")
        return

    url = _build_api_url("api/v1/assistant/ask-assistant-stream/")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": "NormanAI-CLI/0.1.0",
        "X-Requested-With": "XMLHttpRequest",
    }
    if company_id:
        headers["X-Company-Id"] = company_id

    payload = {
        "messageContent": prompt,
        "companyId": company_id,
    }

    await stream_sse_to_terminal(url, headers, payload)


async def run_chat_turn(
    prompt: str,
    history: list[dict],
    thread_id: str | None = None,
) -> tuple[str, str | None]:
    """Run a single chat turn via the hosted streaming API.

    Returns (response_text, thread_id).
    """
    token = get_token()
    company_id = get_company_id()

    url = _build_api_url("api/v1/assistant/ask-assistant-stream/")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": "NormanAI-CLI/0.1.0",
        "X-Requested-With": "XMLHttpRequest",
    }
    if company_id:
        headers["X-Company-Id"] = company_id

    payload = {
        "messageContent": prompt,
        "companyId": company_id,
    }

    response_text = await stream_sse_to_terminal(url, headers, payload)
    return response_text, thread_id
