"""Terminal streaming renderer — reads SSE from Norman's hosted AI API."""

import json
import sys

import requests
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.spinner import Spinner

console = Console()


async def stream_sse_to_terminal(url: str, headers: dict, payload: dict) -> str:
    """Stream SSE response from Norman API to terminal with live rendering.

    Shows a thinking spinner while waiting, then streams markdown as it arrives.
    Returns the accumulated response text.
    """
    accumulated = ""
    got_first_token = False

    try:
        # Show spinner immediately while connecting
        with Live(
            Spinner("dots", text="[dim]Working...[/dim]"),
            console=console,
            refresh_per_second=12,
        ) as live:
            with requests.post(url, headers=headers, json=payload, stream=True, timeout=120) as resp:
                if resp.status_code == 401:
                    live.stop()
                    console.print("[red]Session expired.[/red] Run [bold]norman-ai auth login[/bold]")
                    return ""
                if resp.status_code == 403:
                    live.stop()
                    console.print("[red]Access denied.[/red] Check your subscription.")
                    return ""
                if resp.status_code != 200:
                    live.stop()
                    console.print(f"[red]API error ({resp.status_code}):[/red] {resp.text[:200]}")
                    return ""

                for line in resp.iter_lines(decode_unicode=True):
                    if not line or not line.strip():
                        continue

                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        got_first_token = True
                        accumulated += line
                        live.update(Markdown(accumulated))
                        continue

                    chunk_type = chunk.get("type", "")

                    if chunk_type == "text_delta":
                        delta = chunk.get("delta", "")
                        if delta:
                            got_first_token = True
                            accumulated += delta
                            live.update(Markdown(accumulated))

                    elif chunk_type == "completion":
                        final = chunk.get("final_message", "")
                        if final:
                            accumulated = final
                        got_first_token = True
                        live.update(Markdown(accumulated))

                    elif chunk_type == "error":
                        error_msg = chunk.get("message", "Something went wrong")
                        live.stop()
                        console.print(f"  [red]Error:[/red] {error_msg}")
                        return accumulated

                    elif chunk_type == "action_card":
                        card = chunk.get("card", {})
                        action = card.get("type", card.get("action", ""))
                        if action and not got_first_token:
                            friendly = action.replace("_", " ").title()
                            live.update(Spinner("dots", text=f"[dim]{friendly}...[/dim]"))

                    else:
                        if isinstance(chunk, str):
                            got_first_token = True
                            accumulated += chunk
                            live.update(Markdown(accumulated))

    except requests.exceptions.ConnectionError:
        console.print("[red]Cannot connect to Norman API.[/red] Check your network.")
    except requests.exceptions.Timeout:
        console.print("[red]Request timed out.[/red]")
    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted.[/dim]")

    if not accumulated:
        console.print("  [dim]No response.[/dim]")

    return accumulated
