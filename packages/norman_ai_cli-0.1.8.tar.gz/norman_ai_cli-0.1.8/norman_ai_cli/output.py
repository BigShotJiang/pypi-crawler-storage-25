"""Output formatting for norman-ai CLI.

Supports table (rich), JSON, and agent modes.
Auto-detects piped stdout → JSON.
"""

import json
import sys
from dataclasses import dataclass, field
from typing import Any, Optional

from rich.console import Console
from rich.table import Table


@dataclass
class TableConfig:
    """Configuration for table output."""
    columns: list[tuple[str, str]]  # (key, header_label)
    wide_columns: list[tuple[str, str]] = field(default_factory=list)  # Extra columns for --wide
    title: Optional[str] = None
    results_key: Optional[str] = "results"  # Key for paginated list data


class OutputFormatter:
    """Formats API responses for terminal output."""

    def __init__(self, mode: Optional[str] = None, wide: bool = False):
        if mode:
            self.mode = mode
        elif not sys.stdout.isatty():
            self.mode = "json"
        else:
            self.mode = "table"
        self.wide = wide
        self.console = Console(stderr=True) if self.mode in ("json", "agent") else Console()

    def output(self, data: Any, table_config: Optional[TableConfig] = None) -> None:
        """Output data in the configured format."""
        if isinstance(data, dict) and "error" in data:
            self.error(data)
            return

        if self.mode == "json":
            print(json.dumps(data, indent=2, default=str, ensure_ascii=False))
        elif self.mode == "agent":
            print(json.dumps({"status": "success", "data": data}, default=str, ensure_ascii=False))
        else:
            if table_config:
                self._render_table(data, table_config)
            else:
                self._render_dict(data)

    def error(self, data: Any) -> None:
        """Output an error."""
        if self.mode in ("json", "agent"):
            envelope = {"status": "error"}
            if isinstance(data, dict):
                envelope.update(data)
            else:
                envelope["error"] = str(data)
            print(json.dumps(envelope, default=str, ensure_ascii=False))
            sys.exit(1)
        else:
            msg = data.get("error", data) if isinstance(data, dict) else str(data)
            self.console.print(f"[red]Error:[/red] {msg}")
            detail = data.get("detail") if isinstance(data, dict) else None
            if detail:
                self.console.print(f"[dim]{detail}[/dim]")
            sys.exit(1)

    def success(self, message: str) -> None:
        """Output a success message."""
        if self.mode in ("json", "agent"):
            print(json.dumps({"status": "success", "message": message}, ensure_ascii=False))
        else:
            self.console.print(f"[green]{message}[/green]")

    def info(self, message: str) -> None:
        """Print info to stderr (visible in all modes)."""
        Console(stderr=True).print(f"[dim]{message}[/dim]")

    def _render_table(self, data: Any, config: TableConfig) -> None:
        """Render data as a rich table."""
        # Extract rows from paginated or direct list
        if isinstance(data, dict) and config.results_key and config.results_key in data:
            rows = data[config.results_key]
        elif isinstance(data, list):
            rows = data
        else:
            self._render_dict(data)
            return

        if not rows:
            self.console.print("[dim]No results.[/dim]")
            return

        table = Table(title=config.title, show_lines=False)
        columns = config.columns + (config.wide_columns if self.wide else [])
        for _, header in columns:
            table.add_column(header)

        for row in rows:
            values = []
            for key, _ in columns:
                val = row.get(key, "")
                if isinstance(val, dict):
                    val = val.get("name", val.get("id", str(val)))
                values.append(str(val) if val is not None else "")
            table.add_row(*values)

        count = data.get("count") if isinstance(data, dict) else len(rows)
        self.console.print(table)
        if count and count > len(rows):
            self.console.print(f"[dim]Showing {len(rows)} of {count} results[/dim]")

    def _render_dict(self, data: Any) -> None:
        """Render a single object as key-value pairs."""
        if not isinstance(data, dict):
            self.console.print(str(data))
            return

        table = Table(show_header=False, show_lines=False, pad_edge=False)
        table.add_column("Key", style="bold cyan", no_wrap=True)
        table.add_column("Value")

        for key, value in data.items():
            if isinstance(value, (dict, list)):
                value = json.dumps(value, indent=2, default=str, ensure_ascii=False)
            table.add_row(key, str(value) if value is not None else "")

        self.console.print(table)


# Global formatter instance — set by app.py callback
_formatter: Optional[OutputFormatter] = None


def set_formatter(fmt: OutputFormatter) -> None:
    global _formatter
    _formatter = fmt


def get_formatter() -> OutputFormatter:
    global _formatter
    if _formatter is None:
        _formatter = OutputFormatter()
    return _formatter
