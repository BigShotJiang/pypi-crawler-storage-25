"""Receipt/invoice scanning — upload files for OCR recognition."""

import os
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests
import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from norman_ai_cli.client import get_api_client, _get_api_base_url
from norman_ai_cli.config import get_token, get_company_id
from norman_ai_cli.output import get_formatter
from norman_ai_cli.utils import handle_errors

console = Console()

ALLOWED_EXTENSIONS = {".png", ".jpeg", ".jpg", ".pdf", ".xml", ".webp", ".docx", ".doc", ".tiff", ".bmp"}


def _validate_file(path: str) -> Path:
    """Validate file exists and has allowed extension."""
    p = Path(path).expanduser().resolve()
    if not p.exists():
        console.print(f"[red]File not found:[/red] {path}")
        raise typer.Exit(1)
    if p.suffix.lower() not in ALLOWED_EXTENSIONS:
        console.print(f"[red]Unsupported file type:[/red] {p.suffix}")
        console.print(f"[dim]Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}[/dim]")
        raise typer.Exit(1)
    if p.stat().st_size > 10 * 1024 * 1024:
        console.print("[red]File too large.[/red] Max 10 MB.")
        raise typer.Exit(1)
    return p


def _render_scan_result(data: dict, interactive_off: bool = False) -> None:
    """Render OCR scan results as a nice table."""
    args = data.get("args", {})
    attachment = (data.get("custom_function_result_data") or {}).get("attachment", {})
    response_text = ""
    for r in data.get("response", []):
        for c in r.get("content", []):
            if c.get("type") == "text":
                response_text = c.get("text", {}).get("value", "")

    doc_type = args.get("type", attachment.get("type", "document")).upper()
    brand = args.get("brandName", attachment.get("brandName", ""))
    amount = args.get("total", "")
    if not amount and attachment.get("amountOriginal"):
        amount = f"{attachment['amountOriginal']} {attachment.get('currencyOriginal', 'EUR')}"
    vat = args.get("vatAmount", "")
    vat_pct = args.get("vatPercentage", attachment.get("vatRate", ""))
    date = args.get("date", "")
    if not date and attachment.get("valueDate"):
        date = attachment["valueDate"][:10]
    number = args.get("number", attachment.get("attachmentNumber", ""))
    description = args.get("description", attachment.get("description", ""))
    currency = args.get("currency", attachment.get("currencyOriginal", "EUR"))
    country = args.get("supplierCountry", attachment.get("supplierCountry", ""))
    sale_type = args.get("saleType", attachment.get("saleType", ""))
    attachment_id = attachment.get("publicId", "")

    # Build result table
    table = Table(show_header=False, show_lines=False, pad_edge=False, box=None)
    table.add_column("Field", style="dim", no_wrap=True, min_width=14)
    table.add_column("Value", style="bold")

    if doc_type:
        table.add_row("Type", doc_type)
    if brand:
        table.add_row("Merchant", brand)
    if amount:
        table.add_row("Amount", str(amount))
    if vat:
        vat_str = str(vat)
        if vat_pct:
            vat_str += f" ({vat_pct}%)"
        table.add_row("VAT", vat_str)
    elif vat_pct:
        table.add_row("VAT Rate", f"{vat_pct}%")
    if date:
        table.add_row("Date", str(date))
    if number:
        table.add_row("Number", str(number))
    if description:
        table.add_row("Description", str(description))
    if currency:
        table.add_row("Currency", currency)
    if country:
        table.add_row("Country", country)
    if sale_type:
        table.add_row("Sale Type", sale_type)
    if attachment_id:
        table.add_row("Attachment ID", f"[dim]{attachment_id}[/dim]")

    console.print()
    console.print(Panel(table, title="[bold green]Scanned[/bold green]", border_style="green", padding=(1, 2)))

    # Show AI message if available (filter out web-only references)
    if response_text:
        filtered = response_text
        web_phrases = [
            "Receipt Reconciliation panel",
            "panel on the right",
            "here in chat",
            "in the sidebar",
            "on the right side",
        ]
        for phrase in web_phrases:
            # Remove sentences containing web-only phrases
            sentences = filtered.split(". ")
            sentences = [s for s in sentences if phrase.lower() not in s.lower()]
            filtered = ". ".join(sentences)
        filtered = filtered.strip().rstrip(".")
        if filtered:
            console.print(f"\n  [dim]{filtered}.[/dim]")

    # Show suggested transactions
    suggested = (data.get("custom_function_result_data") or {}).get("suggestedTransactions", [])
    attached = (data.get("custom_function_result_data") or {}).get("attachedTransaction")
    if attached:
        console.print(f"\n  [green]Linked to transaction:[/green] {attached.get('publicId', attached)}")
    elif suggested:
        console.print(f"\n  [yellow]Suggested transactions:[/yellow]")
        for tx in suggested[:3]:
            desc = tx.get("description", "")
            amt = tx.get("amount", "")
            console.print(f"    {tx.get('publicId', '')} — {desc} ({amt})")

    # Offer to create transaction if not already linked
    is_linked = bool(attached) or "linked" in response_text.lower() or "matched" in response_text.lower()
    if not is_linked and not interactive_off:
        _offer_create_transaction(data)


def _offer_create_transaction(data: dict) -> None:
    """Offer to create a transaction from scanned data."""
    from rich.prompt import Confirm

    args = data.get("args", {})
    attachment = (data.get("custom_function_result_data") or {}).get("attachment", {})

    # Extract amount
    amount_str = args.get("total", "")
    if not amount_str and attachment.get("amountOriginal"):
        amount_str = str(attachment["amountOriginal"])
    if not amount_str:
        return

    # Parse numeric amount
    try:
        amount = float(amount_str.replace("€", "").replace(",", ".").strip())
    except (ValueError, AttributeError):
        return

    description = args.get("description", attachment.get("description", ""))
    brand = args.get("brandName", attachment.get("brandName", ""))
    if not description and brand:
        description = brand
    if not description:
        return

    vat_rate = args.get("vatPercentage", attachment.get("vatRate"))
    country = args.get("supplierCountry", attachment.get("supplierCountry", "DE"))
    currency = args.get("currency", attachment.get("currencyOriginal", "EUR"))
    sale_type = args.get("saleType", attachment.get("saleType", ""))
    date = args.get("date", "")
    if not date and attachment.get("valueDate"):
        date = attachment["valueDate"][:10]
    attachment_id = attachment.get("publicId", "")

    console.print()
    if not Confirm.ask("  [bold]Create transaction from this receipt?[/bold]", default=True):
        return

    # Create the transaction
    from norman_ai_cli.client import get_api_client
    client = get_api_client()

    tx_data = {
        "amount": -abs(amount),
        "description": description,
        "cashflowType": "EXPENSE",
        "supplierCountry": country,
        "currency": currency,
        "valueDate": date or datetime.now().strftime("%Y-%m-%d"),
        "saleType": sale_type or "",
        "company": client.company_id,
    }
    if vat_rate is not None:
        try:
            tx_data["vatRate"] = int(vat_rate)
        except (ValueError, TypeError):
            pass

    with Live(Spinner("dots", text="[dim]Creating transaction...[/dim]"), console=console, refresh_per_second=12):
        result = client.post(
            f"api/v1/companies/{client.company_id}/accounting/transactions/", tx_data
        )

    if "error" in result:
        console.print(f"  [red]Failed:[/red] {result['error']}")
        return

    tx_id = result.get("publicId", "")
    if not tx_id:
        console.print(f"  [green]Transaction created![/green]")
        return

    # Link attachment to transaction
    if attachment_id:
        link_result = client.post(
            f"api/v1/companies/{client.company_id}/attachments/{attachment_id}/link-transaction/",
            {"transactionId": tx_id},
        )

    # Show transaction details
    tx_table = Table(show_header=False, show_lines=False, pad_edge=False, box=None)
    tx_table.add_column("Field", style="dim", no_wrap=True, min_width=14)
    tx_table.add_column("Value", style="bold")

    # Parse currency — API may return dict like {"fullName": "Euro", "isoCode": "EUR"}
    tx_currency = result.get("currency", currency)
    if isinstance(tx_currency, dict):
        tx_currency = tx_currency.get("isoCode", tx_currency.get("fullName", "EUR"))

    # Parse date — strip time portion
    tx_date = result.get("valueDate", date) or ""
    if isinstance(tx_date, str) and "T" in tx_date:
        tx_date = tx_date.split("T")[0]

    tx_table.add_row("ID", tx_id)
    tx_table.add_row("Description", result.get("description", description))
    tx_table.add_row("Amount", f"{result.get('amount', amount)} {tx_currency}")
    if result.get("vatRate") is not None:
        tx_table.add_row("VAT", f"{result.get('vatRate')}%")
    tx_table.add_row("Date", tx_date)
    tx_table.add_row("Status", result.get("status", "UNVERIFIED"))
    if attachment_id:
        tx_table.add_row("Receipt", "[green]Linked[/green]")

    console.print()
    console.print(Panel(tx_table, title="[bold cyan]Transaction Created[/bold cyan]", border_style="cyan", padding=(1, 2)))


def _render_bulk_transactions(transactions: list) -> None:
    """Render bulk scan results as a table."""
    table = Table(title="Transactions Created", show_lines=False)
    table.add_column("#", style="dim", width=3)
    table.add_column("Description", min_width=30)
    table.add_column("Amount", justify="right")
    table.add_column("ID", style="dim")

    for i, tx in enumerate(transactions, 1):
        if isinstance(tx, dict):
            desc = tx.get("description", "")
            amount = tx.get("amount", "")
            currency = tx.get("currency", "EUR")
            if isinstance(currency, dict):
                currency = currency.get("isoCode", "EUR")
            tx_id = tx.get("id", tx.get("publicId", ""))
            table.add_row(str(i), desc, f"{amount} {currency}", str(tx_id))
        else:
            table.add_row(str(i), str(tx), "", "")

    console.print()
    console.print(table)


@handle_errors
def scan_files(
    files: list[str],
    cashflow_type: Optional[str] = None,
) -> None:
    """Scan one or more receipt/invoice files with OCR."""
    token = get_token()
    company_id = get_company_id()
    base_url = _get_api_base_url()

    if not token:
        console.print("[red]Not authenticated.[/red] Run [bold]norman-ai auth login[/bold]")
        raise typer.Exit(1)

    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "NormanAI-CLI/0.1.0",
        "X-Requested-With": "XMLHttpRequest",
    }
    if company_id:
        headers["X-Company-Id"] = company_id

    # Validate all files first
    paths = [_validate_file(f) for f in files]

    if len(paths) == 1:
        # Single file — use upload-retrieval for full OCR + AI response
        _scan_single(paths[0], headers, base_url, company_id)
    else:
        # Multiple files — use bulk upload
        _scan_bulk(paths, headers, base_url, company_id, cashflow_type)


def _scan_single(path: Path, headers: dict, base_url: str, company_id: str) -> None:
    """Scan a single file with full OCR recognition."""
    url = f"{base_url.rstrip('/')}/api/v1/assistant/upload-retrieval/"

    console.print(f"  [dim]Scanning {path.name}...[/dim]")

    with Live(Spinner("dots", text="[dim]Recognizing...[/dim]"), console=console, refresh_per_second=12) as live:
        with open(path, "rb") as f:
            resp = requests.post(
                url,
                headers=headers,
                files={"file": (path.name, f)},
                data={"is_mobile": "false", "skip_agent": "false"},
                timeout=120,
            )

    if resp.status_code != 200:
        console.print(f"[red]Upload failed ({resp.status_code}):[/red] {resp.text[:200]}")
        return

    data = resp.json()
    _render_scan_result(data)


def _scan_bulk(paths: list[Path], headers: dict, base_url: str, company_id: str, cashflow_type: Optional[str]) -> None:
    """Scan multiple files via bulk upload."""
    url = f"{base_url.rstrip('/')}/api/v1/accounting/transactions/upload-documents/"

    console.print(f"  [dim]Uploading {len(paths)} files...[/dim]")

    file_handles = []
    try:
        for p in paths:
            fh = open(p, "rb")
            file_handles.append(("files", (p.name, fh)))

        data = {}
        if cashflow_type:
            data["cashflow_type"] = cashflow_type

        with Live(Spinner("dots", text=f"[dim]Uploading {len(paths)} files...[/dim]"), console=console, refresh_per_second=12) as live:
            resp = requests.post(url, headers=headers, files=file_handles, data=data, timeout=120)

        if resp.status_code != 200 and resp.status_code != 201:
            console.print(f"[red]Upload failed ({resp.status_code}):[/red] {resp.text[:200]}")
            return

        result = resp.json()

        # Result may contain transactions directly or a jobId for polling
        job_id = result.get("jobId")
        transactions = result if isinstance(result, list) else result.get("results", result.get("transactions", []))

        if job_id:
            # Poll for completion
            status_url = f"{url}{job_id}/status/"
            console.print()

            status = {}
            with Live(
                Spinner("dots", text="[dim]Processing files...[/dim]"),
                console=console,
                refresh_per_second=4,
            ) as live:
                for _ in range(60):
                    time.sleep(2)
                    status_resp = requests.get(status_url, headers=headers, timeout=30)
                    if status_resp.status_code != 200:
                        break
                    status = status_resp.json()
                    total = status.get("totalFiles", 0)
                    processed = status.get("processedFiles", 0)
                    failed = status.get("failedFiles", 0)
                    job_status = status.get("status", "")

                    live.update(Spinner(
                        "dots",
                        text=f"[dim]Processing... {processed}/{total} files done[/dim]",
                    ))

                    if job_status in ("COMPLETED", "FAILED"):
                        break

            console.print()
            console.print(f"  [green]Done![/green] {status.get('processedFiles', 0)}/{status.get('totalFiles', 0)} files processed")
            if status.get("failedFiles"):
                console.print(f"  [yellow]{status['failedFiles']} files failed[/yellow]")

            transactions = status.get("createdTransactions", [])

        # Render transactions as a nice table
        if isinstance(transactions, list) and transactions:
            _render_bulk_transactions(transactions)
        elif isinstance(transactions, int) and transactions > 0:
            console.print(f"  [green]{transactions} transactions created[/green]")

    finally:
        for _, (_, fh) in file_handles:
            fh.close()
