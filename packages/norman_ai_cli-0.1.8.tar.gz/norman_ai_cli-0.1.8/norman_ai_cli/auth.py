"""Authentication commands for norman-ai CLI."""

import secrets
import socket
import sys
import threading
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urljoin, urlparse, parse_qs, urlencode

import requests
import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.spinner import Spinner
from rich.live import Live

from norman_ai_cli import __version__
from norman_ai_cli.config import load_config, save_config, clear_config, get_token
from norman_ai_cli.output import get_formatter
from norman_ai_cli.utils import handle_errors

app = typer.Typer(name="auth", help="Authentication management")
console = Console(stderr=True)

# OAuth Application for CLI (public client, no secret needed)
CLI_CLIENT_ID = "norman-ai-cli"
CLI_SCOPES = "read write"


def _get_base_url(environment: str | None = None) -> str:
    env = environment or load_config().get("environment", "production")
    if env == "production":
        return "https://api.norman.finance/"
    return "https://sandbox.norman.finance/"


def _get_frontend_url(environment: str | None = None) -> str:
    env = environment or load_config().get("environment", "production")
    if env == "production":
        return "https://app.norman.finance/"
    return "https://dev.norman.finance/"


def _find_free_port() -> int:
    """Find a free port on localhost for the OAuth callback server."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth authorization code."""

    authorization_code: str | None = None
    error: str | None = None
    state: str | None = None

    def do_GET(self) -> None:
        """Handle the OAuth callback redirect."""
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if "code" in params:
            _OAuthCallbackHandler.authorization_code = params["code"][0]
            _OAuthCallbackHandler.state = params.get("state", [None])[0]
            self._send_success_page()
        elif "error" in params:
            _OAuthCallbackHandler.error = params["error"][0]
            self._send_error_page(params.get("error_description", ["Authorization denied"])[0])
        else:
            self._send_error_page("No authorization code received")

    def _send_success_page(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(b"""<!DOCTYPE html><html><head><title>Norman AI CLI</title>
        <style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;
        min-height:100vh;margin:0;background:#fafafa;color:#111}
        .card{text-align:center;padding:48px;background:#fff;border-radius:16px;
        box-shadow:0 2px 8px rgba(0,0,0,0.08);max-width:400px}
        h1{font-size:24px;margin:0 0 8px}p{color:#666;margin:0}
        </style></head><body><div class="card">
        <h1>Authenticated!</h1>
        <p>You can close this tab and return to your terminal.</p>
        </div></body></html>""")

    def _send_error_page(self, message: str) -> None:
        self.send_response(400)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(f"""<!DOCTYPE html><html><head><title>Norman AI CLI</title>
        <style>body{{font-family:system-ui;display:flex;align-items:center;justify-content:center;
        min-height:100vh;margin:0;background:#fafafa;color:#111}}
        .card{{text-align:center;padding:48px;background:#fff;border-radius:16px;
        box-shadow:0 2px 8px rgba(0,0,0,0.08);max-width:400px}}
        h1{{font-size:24px;margin:0 0 8px;color:#e11}}p{{color:#666;margin:0}}
        </style></head><body><div class="card">
        <h1>Authentication failed</h1>
        <p>{message}</p>
        </div></body></html>""".encode())

    def log_message(self, format, *args) -> None:
        """Suppress default request logging."""
        pass


@app.command()
@handle_errors
def login(
    api_key: bool = typer.Option(False, "--api-key", help="Authenticate with an API key"),
    password: bool = typer.Option(False, "--password", help="Use email/password instead of browser OAuth"),
    no_browser: bool = typer.Option(False, "--no-browser", help="Print login URL instead of opening browser"),
    environment: str = typer.Option(None, "--env", help="Environment: production or sandbox"),
) -> None:
    """Log in to Norman Finance.

    Default: opens browser for OAuth login.
    Use --password for email/password login.
    Use --api-key to authenticate with an API key.
    """
    cfg = load_config()
    if environment:
        cfg["environment"] = environment

    if api_key:
        _login_api_key(cfg)
    elif password:
        _login_credentials(cfg)
    else:
        _login_oauth(cfg, no_browser=no_browser)


# ── OAuth browser login ──────────────────────────────────────────────────


def _login_oauth(cfg: dict, no_browser: bool = False) -> None:
    """Authenticate via OAuth browser flow."""
    base_url = _get_base_url(cfg.get("environment"))
    frontend_url = _get_frontend_url(cfg.get("environment"))

    # Start local callback server
    port = _find_free_port()
    redirect_uri = f"http://127.0.0.1:{port}/callback"
    state = secrets.token_urlsafe(32)

    # Reset handler state
    _OAuthCallbackHandler.authorization_code = None
    _OAuthCallbackHandler.error = None
    _OAuthCallbackHandler.state = None

    server = HTTPServer(("127.0.0.1", port), _OAuthCallbackHandler)

    # Build authorization URL
    auth_params = {
        "client_id": CLI_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "scope": CLI_SCOPES,
        "state": state,
    }
    authorize_url = urljoin(base_url, f"api/v1/oauth/authorize/?{urlencode(auth_params)}")

    if no_browser:
        console.print(f"\nOpen this URL in your browser:\n\n[bold]{authorize_url}[/bold]\n")
    else:
        console.print("Opening browser...")
        webbrowser.open(authorize_url)

    # Wait for the callback (timeout after 120 seconds)
    server.timeout = 120
    try:
        while _OAuthCallbackHandler.authorization_code is None and _OAuthCallbackHandler.error is None:
            server.handle_request()
    except KeyboardInterrupt:
        console.print("\n[dim]Login cancelled.[/dim]")
        server.server_close()
        raise typer.Exit(1)
    finally:
        server.server_close()

    # Check for errors
    if _OAuthCallbackHandler.error:
        console.print(f"[red]Login failed:[/red] {_OAuthCallbackHandler.error}")
        raise typer.Exit(1)

    code = _OAuthCallbackHandler.authorization_code
    received_state = _OAuthCallbackHandler.state

    # Verify state
    if received_state != state:
        console.print("[red]Security error: state mismatch. Login aborted.[/red]")
        raise typer.Exit(1)

    # Exchange authorization code for tokens
    try:
        resp = requests.post(
            urljoin(base_url, "api/v1/oauth/token/"),
            data={
                "grant_type": "authorization_code",
                "code": code,
                "client_id": CLI_CLIENT_ID,
                "redirect_uri": redirect_uri,
            },
            timeout=30,
        )
        resp.raise_for_status()
        token_data = resp.json()
    except requests.exceptions.HTTPError as e:
        detail = ""
        if e.response is not None:
            try:
                detail = e.response.json()
            except Exception:
                detail = e.response.text
        console.print(f"[red]Token exchange failed:[/red] {detail or e}")
        raise typer.Exit(1)
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Connection error:[/red] {e}")
        raise typer.Exit(1)

    cfg["auth_method"] = "oauth"
    cfg["access_token"] = token_data.get("access_token")
    cfg["refresh_token"] = token_data.get("refresh_token")
    cfg["api_key"] = None

    # Fetch company info
    _fetch_and_set_company(cfg)
    save_config(cfg)


# ── API key login ────────────────────────────────────────────────────────


def _login_api_key(cfg: dict) -> None:
    """Authenticate with an API key."""
    key = Prompt.ask("Enter your Norman API key")
    if not key.strip():
        console.print("[red]API key cannot be empty.[/red]")
        raise typer.Exit(1)

    # Verify the key works
    base_url = _get_base_url(cfg.get("environment"))
    headers = {"Authorization": f"Bearer {key.strip()}", "User-Agent": "NormanAI-CLI/0.1.0"}
    try:
        resp = requests.get(urljoin(base_url, "api/v1/companies/"), headers=headers, timeout=30)
        resp.raise_for_status()
    except requests.exceptions.HTTPError:
        console.print("[red]Invalid API key.[/red]")
        raise typer.Exit(1)
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Connection error:[/red] {e}")
        raise typer.Exit(1)

    cfg["auth_method"] = "api_key"
    cfg["api_key"] = key.strip()
    cfg["access_token"] = None
    cfg["refresh_token"] = None

    _fetch_and_set_company(cfg)
    save_config(cfg)


# ── Email/password login ─────────────────────────────────────────────────


def _login_credentials(cfg: dict) -> None:
    """Authenticate with email/password (JWT)."""
    email = Prompt.ask("Email")
    password_value = Prompt.ask("Password", password=True)

    if not email or not password_value:
        console.print("[red]Email and password are required.[/red]")
        raise typer.Exit(1)

    base_url = _get_base_url(cfg.get("environment"))
    username = email.split("@")[0]

    try:
        resp = requests.post(
            urljoin(base_url, "api/v1/auth/token/"),
            json={"username": username, "email": email, "password": password_value},
            timeout=30,
        )
        resp.raise_for_status()
        auth_data = resp.json()
    except requests.exceptions.HTTPError as e:
        if e.response is not None and e.response.status_code == 400:
            console.print("[red]Invalid credentials.[/red]")
        else:
            console.print(f"[red]Authentication failed:[/red] {e}")
        raise typer.Exit(1)
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Connection error:[/red] {e}")
        raise typer.Exit(1)

    cfg["auth_method"] = "login"
    cfg["access_token"] = auth_data.get("access")
    cfg["refresh_token"] = auth_data.get("refresh")
    cfg["api_key"] = None

    _fetch_and_set_company(cfg)
    save_config(cfg)


# ── Shared helpers ───────────────────────────────────────────────────────


def _print_banner() -> None:
    """Print the Norman banner on successful login."""
    from norman_ai_cli.app import BANNER
    console.print(BANNER.format(version=__version__))


def _print_onboarding() -> None:
    """Print quick-start tips after login."""
    console.print("  [dim]Try these to get started:[/dim]\n")
    console.print("  [bold]norman-ai ask[/bold] [cyan]\"What are my expenses this month?\"[/cyan]")
    console.print("  [bold]norman-ai chat[/bold]              [dim]Interactive AI session[/dim]")
    console.print("  [bold]norman-ai company balance[/bold]   [dim]Check your balance[/dim]")
    console.print("  [bold]norman-ai --help[/bold]            [dim]See all commands[/dim]")
    console.print()


def _fetch_and_set_company(cfg: dict) -> None:
    """Fetch company info and set company_id in config."""
    token = cfg.get("api_key") or cfg.get("access_token")
    if not token:
        return

    base_url = _get_base_url(cfg.get("environment"))
    headers = {"Authorization": f"Bearer {token}", "User-Agent": "NormanAI-CLI/0.1.0"}
    try:
        resp = requests.get(urljoin(base_url, "api/v1/companies/"), headers=headers, timeout=30)
        resp.raise_for_status()
        companies = resp.json().get("results", [])
        _print_banner()
        if companies:
            cfg["company_id"] = companies[0].get("publicId")
            company_name = companies[0].get("name", "Unknown")
            console.print(f"  Welcome back, [bold]{company_name}[/bold]!\n")
        else:
            console.print(f"  [green]Authenticated![/green]\n")
        _print_onboarding()
    except Exception:
        _print_banner()
        console.print(f"  [green]Authenticated![/green]\n")
        _print_onboarding()


# ── Other commands ───────────────────────────────────────────────────────


@app.command()
@handle_errors
def logout() -> None:
    """Clear stored credentials."""
    clear_config()
    console.print("[green]Logged out.[/green]")


@app.command()
@handle_errors
def status() -> None:
    """Show current authentication status."""
    fmt = get_formatter()
    token = get_token()

    if not token:
        fmt.error({"error": "Not authenticated. Run: norman-ai auth login"})
        return

    cfg = load_config()
    from norman_ai_cli.client import get_api_client
    client = get_api_client()

    result = client.get("api/v1/companies/")
    companies = result.get("results", [])

    info = {
        "auth_method": cfg.get("auth_method", "unknown"),
        "environment": cfg.get("environment", "production"),
        "company_id": client.company_id or "none",
    }

    if companies:
        active = next((c for c in companies if c.get("publicId") == client.company_id), companies[0])
        info["company_name"] = active.get("name", "Unknown")
        info["company_type"] = active.get("companyType", "Unknown")
        info["total_companies"] = len(companies)

    fmt.output(info)


@app.command("switch-company")
@handle_errors
def switch_company() -> None:
    """Switch the active company."""
    from norman_ai_cli.client import get_api_client
    client = get_api_client()
    result = client.get("api/v1/companies/")
    companies = result.get("results", [])

    if not companies:
        console.print("[yellow]No companies found.[/yellow]")
        raise typer.Exit(1)

    if len(companies) == 1:
        console.print("[dim]Only one company available.[/dim]")
        return

    console.print("[bold]Available companies:[/bold]")
    for i, c in enumerate(companies):
        marker = " [green]*[/green]" if c.get("publicId") == client.company_id else ""
        console.print(f"  {i + 1}. {c.get('name', 'Unknown')}{marker}")

    choice = Prompt.ask("Select company", choices=[str(i + 1) for i in range(len(companies))])
    selected = companies[int(choice) - 1]

    cfg = load_config()
    cfg["company_id"] = selected.get("publicId")
    save_config(cfg)
    console.print(f"[green]Switched to:[/green] [bold]{selected.get('name')}[/bold]")
