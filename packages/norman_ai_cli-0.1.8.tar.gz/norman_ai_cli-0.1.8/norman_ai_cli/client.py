"""API client factory for norman-ai CLI.

Wraps NormanAPI from the MCP package, bypassing MCP-specific context.
"""

import os
import sys
import logging
import requests
from typing import Any, Dict, Optional
from urllib.parse import urljoin

from norman_ai_cli.config import get_token, get_company_id, get_environment, load_config

logger = logging.getLogger(__name__)


def _get_api_base_url() -> str:
    """Get API base URL based on environment."""
    env = get_environment()
    if env == "production":
        return "https://api.norman.finance/"
    return "https://sandbox.norman.finance/"


class CLIClient:
    """Lightweight API client for CLI commands. No MCP dependencies."""

    def __init__(
        self,
        access_token: Optional[str] = None,
        company_id: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 60,
    ):
        self.access_token = access_token
        self.company_id = company_id
        self.base_url = base_url or _get_api_base_url()
        self.timeout = timeout

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an authenticated API request."""
        url = urljoin(self.base_url, path)

        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "User-Agent": "NormanAI-CLI/0.1.0",
            "X-Requested-With": "XMLHttpRequest",
        }
        if self.company_id:
            headers["X-Company-Id"] = self.company_id

        if params is None:
            params = {}
        if self.company_id and "companyId" not in params:
            params["companyId"] = self.company_id

        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                json=json_data,
                files=files,
                timeout=self.timeout,
            )
            response.raise_for_status()
            if response.content:
                return response.json()
            return {}
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else 0
            detail = None
            if e.response is not None:
                try:
                    detail = e.response.json()
                except (ValueError, AttributeError):
                    detail = e.response.text
            return {"error": f"HTTP {status}: {e}", "status_code": status, "detail": detail}
        except requests.exceptions.ConnectionError:
            return {"error": "Cannot connect to Norman API. Check your network."}
        except requests.exceptions.Timeout:
            return {"error": "Request timed out."}
        except requests.exceptions.RequestException as e:
            return {"error": f"Request failed: {e}"}

    def get(self, path: str, **params: Any) -> Dict[str, Any]:
        """Shortcut for GET requests."""
        filtered = {k: v for k, v in params.items() if v is not None}
        return self.request("GET", path, params=filtered)

    def post(self, path: str, data: Optional[Dict[str, Any]] = None, **params: Any) -> Dict[str, Any]:
        """Shortcut for POST requests."""
        filtered = {k: v for k, v in params.items() if v is not None}
        return self.request("POST", path, params=filtered, json_data=data)

    def put(self, path: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Shortcut for PUT requests."""
        return self.request("PUT", path, json_data=data)

    def patch(self, path: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Shortcut for PATCH requests."""
        return self.request("PATCH", path, json_data=data)

    def delete(self, path: str) -> Dict[str, Any]:
        """Shortcut for DELETE requests."""
        return self.request("DELETE", path)


def get_api_client() -> CLIClient:
    """Factory: create an authenticated CLI client from stored config/env."""
    token = get_token()
    if not token:
        from rich.console import Console
        Console(stderr=True).print("[red]Not authenticated.[/red] Run [bold]norman-ai auth login[/bold] first.")
        sys.exit(1)

    company_id = get_company_id()
    client = CLIClient(access_token=token, company_id=company_id)

    # If no company ID, try to fetch it
    if not company_id:
        result = client.request("GET", "api/v1/companies/")
        companies = result.get("results", [])
        if companies:
            client.company_id = companies[0].get("publicId")
        else:
            from rich.console import Console
            Console(stderr=True).print("[yellow]Warning:[/yellow] No companies found for this account.")

    return client
