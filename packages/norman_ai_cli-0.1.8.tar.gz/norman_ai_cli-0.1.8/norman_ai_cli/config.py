"""Configuration management for norman-ai CLI.

Stores credentials and settings in ~/.norman-ai/config.json with 0600 permissions.
"""

import json
import os
from pathlib import Path
from typing import Any, Optional


CONFIG_DIR = Path.home() / ".norman-ai"
CONFIG_FILE = CONFIG_DIR / "config.json"
THREADS_DIR = CONFIG_DIR / "threads"

DEFAULT_CONFIG = {
    "auth_method": None,  # "oauth", "api_key", or "login"
    "access_token": None,
    "refresh_token": None,
    "api_key": None,
    "company_id": None,
    "environment": "production",
}


def _ensure_config_dir() -> None:
    """Create config directory with secure permissions if it doesn't exist."""
    CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    THREADS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    """Load configuration from disk. Returns defaults if no config exists."""
    if not CONFIG_FILE.exists():
        return DEFAULT_CONFIG.copy()
    try:
        return {**DEFAULT_CONFIG, **json.loads(CONFIG_FILE.read_text())}
    except (json.JSONDecodeError, OSError):
        return DEFAULT_CONFIG.copy()


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to disk with secure permissions."""
    _ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    os.chmod(CONFIG_FILE, 0o600)


def get_token() -> Optional[str]:
    """Get the best available auth token. Priority: env > config."""
    # 1. API key from env
    api_key = os.environ.get("NORMAN_API_KEY")
    if api_key:
        return api_key

    # 2. Config file
    cfg = load_config()
    if cfg.get("api_key"):
        return cfg["api_key"]
    if cfg.get("access_token"):
        return cfg["access_token"]

    return None


def get_company_id() -> Optional[str]:
    """Get company ID from env or config."""
    env_id = os.environ.get("NORMAN_COMPANY_ID")
    if env_id:
        return env_id
    return load_config().get("company_id")


def get_environment() -> str:
    """Get environment from env or config."""
    env = os.environ.get("NORMAN_ENVIRONMENT")
    if env:
        return env
    return load_config().get("environment", "production")


def clear_config() -> None:
    """Remove stored credentials."""
    if CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
