#!/bin/bash
# Build and publish norman-ai-cli to PyPI
# Usage: ./build.sh [--publish]

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

echo "Copying norman_ai_cli package..."
rm -rf "$SCRIPT_DIR/norman_ai_cli"
cp -r "$REPO_ROOT/norman_ai_cli" "$SCRIPT_DIR/norman_ai_cli"

echo "Building..."
cd "$SCRIPT_DIR"
pip3 install --quiet hatchling build
python3 -m build

if [ "$1" = "--publish" ]; then
    echo "Publishing to PyPI..."
    pip3 install --quiet twine
    twine upload dist/*
    echo "Published!"
else
    echo ""
    echo "Built successfully. Files in dist/:"
    ls -la dist/
    echo ""
    echo "To publish: ./build.sh --publish"
    echo "Or manually: twine upload dist/*"
fi
