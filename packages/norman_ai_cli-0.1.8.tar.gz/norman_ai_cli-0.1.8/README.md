# Norman AI CLI

**Agentic accounting & taxes from the terminal.**

Norman AI is a command-line tool that gives you terminal access to invoices, transactions, tax reports, clients, documents, and more — plus an AI agent that handles complex workflows in natural language.

## Installation

```bash
pip install norman-ai-cli
```

## Quick Start

```bash
# Log in (opens browser)
norman-ai auth login

# Check your balance
norman-ai company balance

# Ask AI anything
norman-ai ask "What are my expenses this month?"

# Create an invoice
norman-ai ask "Create an invoice for Acme Corp, 2500 EUR for consulting"

# Interactive chat
norman-ai chat

# List transactions as JSON
norman-ai transactions list --json
```

## Features

- **60+ CLI commands** — invoices, transactions, clients, taxes, bills, documents, categories
- **AI Agent** — natural language queries with autonomous multi-step workflows
- **Smart Prompts** — pre-built templates for common tasks
- **Multiple output formats** — table, JSON, agent mode (auto-detect piped vs TTY)
- **OAuth login** — secure browser-based authentication
- **Agent-ready** — `--agent` mode, piping, `--no-input` for CI/CD

## Authentication

Three ways to log in:

```bash
# OAuth (recommended) — opens browser
norman-ai auth login

# Email/password
norman-ai auth login --password

# API key (for CI/CD)
norman-ai auth login --api-key
```

## Command Groups

| Group | Description |
|-------|-------------|
| `auth` | Login, logout, status, switch company |
| `ask` | One-shot AI agent query |
| `chat` | Interactive AI chat session |
| `company` | Company details, balance, DATEV export |
| `transactions` | List, create, update, categorize, verify |
| `invoices` | List, create, send, remind, e-invoice XML |
| `clients` | List, create, update, delete |
| `taxes` | Reports, VAT next, stats, submit, validate |
| `bills` | List, create, scan, pay, payment orders |
| `documents` | List, upload, link to transactions |
| `categories` | SKR search, AI suggest, create |
| `advisor` | Tax advisor tools (overview, compliance, ping) |

## Global Flags

| Flag | Description |
|------|-------------|
| `--json` | Output as JSON |
| `--table` | Force table output |
| `--wide` | Show all columns |
| `--agent` | Machine-readable JSON (auto when piped) |
| `--quiet` | Suppress progress |
| `--no-input` | Disable prompts (CI/scripts) |
| `--dry-run` | Preview without executing |
| `--debug` | Verbose logging |
| `--env` | production or sandbox |

## AI Agent Integration

Norman AI works with Claude Code, Cursor, and any MCP-compatible client:

```bash
# Claude Code
claude mcp add norman-finance -- npx @anthropic-ai/remote-mcp-server https://mcp.norman.finance/mcp

# Pipe to other tools
norman-ai transactions list --json | jq '.results[].amount'

# CI/CD
NORMAN_API_KEY="your-key" norman-ai invoices list --no-input --json
```

## Documentation

Full documentation: [app.norman.finance/norman-cli/docs](https://app.norman.finance/norman-cli/docs)

## License

MIT — Norman AI GmbH
