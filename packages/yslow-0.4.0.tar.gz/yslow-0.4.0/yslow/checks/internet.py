import statistics

from ..models import ProbeResult
from ..probe import probe

TARGETS = [
    ("1.1.1.1", 443, "Cloudflare DNS"),
    ("8.8.8.8", 443, "Google DNS"),
    ("208.67.222.222", 443, "OpenDNS"),
]

PROBE_COUNT = 5


LABEL = "ISP/internet:"


def summary(results: list[ProbeResult]) -> str:
    """One-line summary for the internet check."""
    lbl = f"{LABEL:14s}"
    reachable = [r for r in results if r.reachable]
    if not reachable:
        return f"{lbl}all targets unreachable"
    avg_rtt = statistics.mean(r.avg for r in reachable)
    max_loss = max(r.loss_pct for r in reachable)
    max_jitter = max(r.jitter for r in reachable)
    return (
        f"{lbl}{avg_rtt:5.1f} ms rtt, {max_loss:.0f}% loss, {max_jitter:4.1f} ms jitter"
    )


def run() -> list[ProbeResult]:
    """Check latency to internet targets and return results."""
    results = []
    for host, port, label in TARGETS:
        r = probe(host, label, PROBE_COUNT, port=port, method="tcp")
        results.append(r)
    return results
