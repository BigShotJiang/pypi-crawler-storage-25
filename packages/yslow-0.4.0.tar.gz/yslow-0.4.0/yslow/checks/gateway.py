from ..models import ProbeResult
from ..net import get_default_gateway, find_gateway_probe_method
from ..probe import probe

PROBE_COUNT = 5


LABEL = "LAN:"


def summary(result: ProbeResult | None) -> str:
    """One-line summary for the LAN check."""
    lbl = f"{LABEL:14s}"
    if result is None:
        return f"{lbl}no gateway detected"
    if not result.reachable:
        return f"{lbl}gateway {result.host} unreachable"
    return (
        f"{lbl}{result.avg:5.1f} ms rtt, {result.loss_pct:.0f}% loss, "
        f"{result.jitter:4.1f} ms jitter"
    )


def run() -> ProbeResult | None:
    """Check gateway latency and return the result."""
    gw = get_default_gateway()
    if not gw:
        return None

    method, port = find_gateway_probe_method(gw)
    if method == "none":
        return None

    return probe(gw, f"Gateway ({gw})", PROBE_COUNT, port=port, method=method)
