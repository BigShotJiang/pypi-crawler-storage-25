"""Entry point for `python -m yslow`."""

from yslow import main

if __name__ == "__main__":
    main()
