from yslow.ui.common import format_ago


class TestFormatAgo:
    def test_seconds(self):
        assert format_ago(30) == "30s ago"

    def test_minutes(self):
        assert format_ago(120) == "2m ago"

    def test_rounds_to_nearest_minute(self):
        assert format_ago(90) == "2m ago"

    def test_hours(self):
        assert format_ago(3660) == "1h 1m ago"

    def test_zero(self):
        assert format_ago(0) == "0s ago"
