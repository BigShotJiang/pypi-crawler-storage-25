Ran out of time / quota to finish this, so putting a note to pick up later.

Had a session to plan out a wifi check. Going to use `pyroute2` to get 
information about the wifi link (like `iw dev wlp1s0 station dump`).

Going to start with just wifi signal strength as an indication of quality
so that we can get going. Will have to determine the thresholds.

Also need to write a 'driver' ? I guess right now that's just a check like
dns.py, but maybe there's a concept here for "fetch me the raw data" since
I'm thinking a little about how it will work on a mac.
