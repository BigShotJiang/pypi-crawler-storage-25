# 2026-03-22 — UI status header rework and diagnosis cleanup

## What changed

### UI status header
- Replaced the old `problem` / `unstable` / `stable` header with a conversational format:
  - `Is it slow?` on its own line (dim)
  - Answer on next line: `● YES!` (red) / `● Sorta?` (yellow) / `● Nope!` (green)
- Added section headers: `Why?` before issue list, `Details` before probe results
- Removed gateway address from the LAN details line (was showing `(gateway 192.168.1.1)`)

### Diagnosis: combined gateway-latency and gateway-jitter
- Old: separate `gateway-latency` and `gateway-jitter` issues with different descriptions
- New: single `gateway-quality` issue ("LAN: unstable wifi/LAN connection") that includes whichever details are relevant (rtt, jitter, or both) in the value string
- `gateway-loss` remains separate since packet loss is a distinct symptom

### Snapshot tests
- Fixed `--snapshot-update` flag: comparison tests now skip when updating instead of failing before the update test runs
- Added snapshot update command to CLAUDE.md quick reference

## Open questions
- None
