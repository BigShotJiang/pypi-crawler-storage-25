# Data model cleanup — 2026-03-22

## What we did

### Promoted IssueRecord to a proper model
- Moved `IssueRecord` from `ui/watch.py` to `models.py` — it's a domain concept (aggregation of issues across check results), not a UI concern.
- Added `IssueRecord.from_results(list[CheckResult])` static method, moving the aggregation logic out of `WatchState`.
- `WatchState.issue_history()` now delegates to `IssueRecord.from_results()`.

### Added dataflow documentation
- Created `docs/dataflow.md` documenting the full pipeline: probes → diagnosis → CheckResult → IssueRecord → UI.
- Covers all four model types and how they relate.

## Context

Working toward unifying the redundant display sections (issue history, probe summary, session summary). Understanding and cleaning up the data model is the first step — the display redundancy noted in the 2026-03-21 session is still open.
