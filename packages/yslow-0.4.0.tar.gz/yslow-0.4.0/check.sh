#!/usr/bin/env bash
set -e

run() {
    local label="$1"
    shift
    if ! output=$("$@" 2>&1); then
        echo "=== $label FAILED ==="
        echo "$output"
        exit 1
    fi
}

run "ruff format" uv run ruff format --check .
run "ruff check" uv run ruff check .
run "ty" uv run ty check
run "pytest" uv run pytest -q "$@"

echo "All checks passed."
