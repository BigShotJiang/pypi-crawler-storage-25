# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.


## Bash / Python execution policy

- Do not run multiline Python via `python -c "..."`.
- Do not put comments (`# ...`) inside quoted shell arguments.
- For Python snippets longer than one line, write a temporary script file first, then run it with `uv run python <script>`.
- Prefer `scripts/tmp_*.py` or `/tmp/*.py` over inline `python -c`.
- Avoid multiline Bash commands when a single script file can express the logic.

## Commands

```bash
# 개발 환경 설치
uv sync

# CLI 실행 (venv 활성화 후)
uv run gpc lookup US12514139B2
uv run gpc lookup US20250350789 --format text
uv run gpc fields

# 모듈로 직접 실행
uv run python -m google_patent_cli lookup US12514139B2

# 빌드 (wheel + sdist)
uv run hatchling build

# PyPI 업로드
uv run twine upload dist/*
```

테스트 파일은 현재 없음.

## 아키텍처

`src/google_patent_cli/` 아래 5개 모듈이 파이프라인으로 연결된다.

```
cli.py  →  fetcher.py  →  parser.py  →  formatter.py
              ↑
           config.py
```

- **cli.py** — Click 엔트리포인트. `main` 그룹 아래 `lookup`, `fields`, `configure` 명령. `--field` / `--fields` / `--format` / `--output-dir` 옵션 처리.
- **fetcher.py** — `fetch_html()`: `requests`로 Google Patents 페이지 HTML 반환. 특허번호 정규화(`normalize_for_url`)가 여기 있음 — US 공개번호 6자리 시퀀스를 7자리로 변환하는 로직.
- **parser.py** — `parse_all()`: BeautifulSoup으로 HTML을 파싱하여 필드 dict 반환. 각 필드마다 private 함수(`_parse_*`, `_dc_date`)로 분리.
- **formatter.py** — `render()`: dict → JSON / text / TSV 문자열. `save_to_dir()`로 파일 저장. `FIELD_ORDER`가 출력 순서를 결정.
- **config.py** — `~/.patent-cli.toml` 읽기/쓰기. `get_request_kwargs()`가 `requests.get()`에 전달할 `proxies`, `verify` kwargs를 반환.

## 주요 규칙

- `formatter.py`의 `FIELD_ORDER`와 `_LABELS`에 필드를 추가해야 `gpc fields`와 text/TSV 출력에 반영된다.
- `parser.py`에서 새 필드를 파싱할 때는 `parse_all()` 반환 dict에도 추가해야 한다.
- `tomllib`은 Python 3.11 표준 라이브러리이며 read-only — TOML 쓰기는 `config.py`의 `_dump_toml()`이 직접 구현한다.
- Google Patents는 정적 HTML에 메타데이터를 `<meta name="DC.*">`, `<meta name="citation_*">` 태그로 포함한다. 동적 렌더링이 필요한 필드(이미지 등)는 현재 지원하지 않는다.
