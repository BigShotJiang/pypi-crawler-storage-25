import json
import sys
from pathlib import Path

# 출력 시 필드 표시 순서
FIELD_ORDER = [
    "publication_number",
    "number_without_kind",
    "application_number",
    "kind_code",
    "country",
    "title",
    "abstract",
    "inventors",
    "assignee",
    "filing_date",
    "publication_date",
    "cpc_codes",
    "claims",
    "description",
    "patent_url",
    "backward_citations",
    "backward_citations_family",
    "non_patent_citations",
    "forward_citations",
    "forward_citations_family",
    "similar_documents",
    "family_applications",
]

# 사람이 읽기 편한 레이블
_LABELS = {
    "publication_number":  "Publication Number",
    "number_without_kind": "Number (no kind)",
    "application_number":  "Application Number",
    "kind_code":           "Kind Code",
    "country":             "Country",
    "title":               "Title",
    "abstract":            "Abstract",
    "inventors":           "Inventors",
    "assignee":            "Assignee",
    "filing_date":         "Filing Date",
    "publication_date":    "Publication Date",
    "cpc_codes":           "CPC Codes",
    "claims":              "Claims",
    "description":         "Description",
    "patent_url":                "Patent URL",
    "backward_citations":        "Backward Citations",
    "backward_citations_family": "Backward Citations (Family)",
    "non_patent_citations":      "Non-Patent Citations",
    "forward_citations":         "Forward Citations",
    "forward_citations_family":  "Forward Citations (Family)",
    "similar_documents":         "Similar Documents",
    "family_applications":       "Family Applications (Worldwide)",
}


def _serialize_citation(c: dict) -> str:
    """citation dict → 한 줄 compact 문자열."""
    pub = c.get("publication_number", "")
    marker = ""
    if c.get("cited_by_examiner"):
        marker += "*"
    if c.get("cited_by_third_party"):
        marker += "†"
    if marker:
        pub = f"{pub}{marker}"
    parts = [pub]
    priority = c.get("priority_date", "")
    pub_date = c.get("publication_date", "")
    if priority or pub_date:
        parts.append(f"({priority} / {pub_date})")
    assignee = c.get("assignee", "")
    if assignee:
        parts.append(assignee)
    title = c.get("title", "")
    if title:
        parts.append(title)
    return " | ".join(parts)


def _serialize_non_patent(c: dict) -> str:
    """non-patent citation dict → 한 줄 compact 문자열."""
    title = c.get("title", "")
    marker = ""
    if c.get("cited_by_examiner"):
        marker += "*"
    if c.get("cited_by_third_party"):
        marker += "†"
    return f"[{marker}] {title}" if marker else title


def _serialize_similar(c: dict) -> str:
    """similar document dict → 한 줄 compact 문자열."""
    pub = c.get("publication_number", "")
    pub_date = c.get("publication_date", "")
    title = c.get("title", "")
    parts = [pub]
    if pub_date:
        parts.append(f"({pub_date})")
    if title:
        parts.append(title)
    return " | ".join(parts)


_CITATION_FIELDS = {"backward_citations", "backward_citations_family", "forward_citations", "forward_citations_family"}
_NON_PATENT_FIELDS = {"non_patent_citations"}
_SIMILAR_FIELDS = {"similar_documents"}
_FAMILY_APP_FIELDS = {"family_applications"}


def _serialize_family_application(a: dict) -> str:
    """family_application dict → 한 줄 compact 문자열."""
    parts = []
    if a.get("patent_number"):
        parts.append(a["patent_number"])
    if a.get("country_code"):
        parts.append(a["country_code"])
    if a.get("application_number"):
        parts.append(a["application_number"])
    if a.get("filing_date"):
        parts.append(a["filing_date"])
    if a.get("legal_status_cat") or a.get("legal_status"):
        status = f"{a.get('legal_status_cat', '')} / {a.get('legal_status', '')}".strip(" /")
        parts.append(status)
    return " | ".join(parts)


def _serialize_value(v: object, field_key: str = "") -> str:
    """list → 세미콜론 구분 문자열, None → 빈 문자열."""
    if v is None:
        return ""
    if isinstance(v, list):
        if field_key in _CITATION_FIELDS:
            return "; ".join(_serialize_citation(x) for x in v if isinstance(x, dict))
        if field_key in _NON_PATENT_FIELDS:
            return "; ".join(_serialize_non_patent(x) for x in v if isinstance(x, dict))
        if field_key in _SIMILAR_FIELDS:
            return "; ".join(_serialize_similar(x) for x in v if isinstance(x, dict))
        if field_key in _FAMILY_APP_FIELDS:
            return "; ".join(_serialize_family_application(x) for x in v if isinstance(x, dict))
        return "; ".join(str(x) for x in v)
    return str(v)


def select_fields(data: dict, fields: list[str] | None) -> dict:
    """fields 목록이 주어지면 해당 필드만, 없으면 전체 반환."""
    if not fields:
        return data
    return {f: data.get(f) for f in fields}


def print_json(data: dict) -> None:
    print(render(data, "json"))


def print_text(data: dict) -> None:
    print(render(data, "text"))


def print_tsv(data: dict) -> None:
    print(render(data, "tsv"))


def print_field(value: object, field_key: str = "") -> None:
    """--field 단일 값 출력: plain string, 리스트는 줄바꿈 구분."""
    if value is None:
        return
    if isinstance(value, list):
        if value and isinstance(value[0], dict):
            print(json.dumps(value, ensure_ascii=False, indent=2))
        else:
            for item in value:
                print(item)
    else:
        print(value)


def print_error(message: str, patent_number: str) -> None:
    print(json.dumps({"error": message, "patent_number": patent_number}, ensure_ascii=False))


_FMT_EXT = {"json": ".json", "text": ".txt", "tsv": ".tsv"}


def render(data: dict, fmt: str) -> str:
    """출력 데이터를 문자열로 렌더링."""
    if fmt == "json":
        return json.dumps(data, ensure_ascii=False, indent=2)
    if fmt == "text":
        lines = []
        label_width = max((len(_LABELS.get(k, k)) for k in data), default=20)
        for key in FIELD_ORDER:
            if key not in data:
                continue
            lines.append(f"{_LABELS.get(key, key):<{label_width}} : {_serialize_value(data[key], key)}")
        for key in data:
            if key not in FIELD_ORDER:
                lines.append(f"{_LABELS.get(key, key):<{label_width}} : {_serialize_value(data[key], key)}")
        return "\n".join(lines)
    if fmt == "tsv":
        keys = [k for k in FIELD_ORDER if k in data] + [k for k in data if k not in FIELD_ORDER]
        return "\t".join(keys) + "\n" + "\t".join(_serialize_value(data[k], k) for k in keys)
    return ""


def save_to_dir(data: dict, fmt: str, output_dir: str, patent_number: str) -> Path:
    """output_dir에 {patent_number}{ext} 파일로 저장 후 경로 반환."""
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    ext = _FMT_EXT.get(fmt, ".json")
    filepath = directory / f"{patent_number}{ext}"
    # text/tsv는 BOM 포함 UTF-8로 저장해 Windows 앱(메모장, Excel)이 인코딩을 올바르게 인식
    encoding = "utf-8-sig" if fmt in ("text", "tsv") else "utf-8"
    filepath.write_text(render(data, fmt), encoding=encoding)
    return filepath
