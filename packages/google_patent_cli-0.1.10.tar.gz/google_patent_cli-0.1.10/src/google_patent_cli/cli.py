import logging
import sys

import click

if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

from . import config as cfg
from .fetcher import fetch_html, fetch_pdf, fetch_image, PatentNotFoundError, FetchError
from .parser import parse_all, parse_image_urls
from .formatter import (
    FIELD_ORDER,
    select_fields,
    print_json,
    print_text,
    print_tsv,
    print_field,
    print_error,
    save_to_dir,
)

_FORMATS = ("json", "text", "tsv")


@click.group()
@click.version_option(package_name="google-patent-cli", prog_name="gpc")
@click.option('--verbose', '-v', is_flag=True, default=False,
              help='Print progress and debug logs to stderr.')
@click.pass_context
def main(ctx: click.Context, verbose: bool) -> None:
    """Google Patents CLI — fetch patent metadata by patent number.

    \b
    Commands:
      lookup      Fetch metadata for a patent number
      download    Download the patent PDF
      images      Download high-resolution figure images
      fields      List all available output fields
      configure   Set proxy / CA-cert options

    \b
    Quick start:
      gpc lookup US12514139B2
      gpc lookup US20250350789 --format text
      gpc lookup US20250350789 --fields title,assignee
      gpc download US9735861 --output-dir ./pdfs
      gpc images US11125686B2 --output-dir ./figs
      gpc fields
    """
    ctx.ensure_object(dict)
    ctx.obj['verbose'] = verbose

    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(stream=sys.stderr, level=level,
                        format='%(levelname)s %(message)s')


@main.command()
@click.argument('patent_number')
@click.option('--format', '-f', 'fmt',
              type=click.Choice(_FORMATS, case_sensitive=False),
              default='json', show_default=True,
              help='Output format: json (default), text, or tsv.')
@click.option('--field', 'single_field', default=None, metavar='FIELD',
              help='Print a single field value as plain text (overrides --format).')
@click.option('--fields', 'multi_fields', default=None, metavar='F1,F2,...',
              multiple=True,
              help='Comma-separated field list. Repeatable: --fields title --fields abstract')
@click.option('--timeout', '-t', default=15, show_default=True,
              help='HTTP request timeout in seconds.')
@click.option('--output-dir', '-o', default=None, metavar='DIR',
              help='Save result to DIR; filename is derived from the patent number.')
@click.pass_context
def lookup(
    ctx: click.Context,
    patent_number: str,
    fmt: str,
    single_field: str | None,
    multi_fields: tuple[str, ...],
    timeout: int,
    output_dir: str | None,
) -> None:
    """Fetch Google Patents metadata for PATENT_NUMBER.

    \b
    Examples:
      gpc lookup US20250350789
      gpc lookup US12514139B2 --format text
      gpc lookup US20250350789 --field title
      gpc lookup US20250350789 --fields title,assignee,filing_date
      gpc lookup US20250350789 --format tsv
      gpc lookup US12514139B2 --output-dir ./output
      gpc lookup US12514139B2 --format text --output-dir ./output
    """
    logger = logging.getLogger(__name__)
    logger.debug("lookup: %s", patent_number)

    request_kwargs = cfg.get_request_kwargs(cfg.load())

    try:
        html = fetch_html(patent_number, timeout=timeout, **request_kwargs)
    except PatentNotFoundError:
        print_error("Patent not found", patent_number)
        sys.exit(1)
    except FetchError as e:
        print_error(f"Network error: {e}", patent_number)
        sys.exit(1)

    data = parse_all(html)

    # --field: 단일 값 plain 출력
    if single_field:
        if single_field not in data:
            click.echo(f"Unknown field: {single_field!r}. Run 'patent fields' for available fields.",
                       err=True)
            sys.exit(1)
        print_field(data[single_field])
        return

    # --fields: 선택 필드만 남기기 (콤마 구분 또는 반복 옵션 모두 지원)
    if multi_fields:
        fields_list = [f.strip() for token in multi_fields for f in token.split(',') if f.strip()]
    else:
        fields_list = None
    if fields_list:
        unknown = [f for f in fields_list if f not in data]
        if unknown:
            click.echo(f"Unknown field(s): {', '.join(unknown)}. Run 'patent fields' for available fields.",
                       err=True)
            sys.exit(1)
    output = select_fields(data, fields_list)

    if fmt == 'json':
        print_json(output)
    elif fmt == 'text':
        print_text(output)
    elif fmt == 'tsv':
        print_tsv(output)

    if output_dir:
        saved = save_to_dir(output, fmt, output_dir, patent_number)
        click.echo(f"Saved: {saved}", err=True)


@main.command()
@click.argument('patent_number')
@click.option('--output-dir', '-o', default='.', show_default=True, metavar='DIR',
              help='Directory to save the PDF.')
@click.option('--timeout', '-t', default=60, show_default=True,
              help='HTTP request timeout in seconds.')
@click.pass_context
def download(
    ctx: click.Context,
    patent_number: str,
    output_dir: str,
    timeout: int,
) -> None:
    """Download the patent PDF for PATENT_NUMBER (saved as <number>.pdf).

    \b
    Examples:
      gpc download US9735861
      gpc download US9735861 --output-dir ./pdfs
    """
    import os
    logger = logging.getLogger(__name__)
    request_kwargs = cfg.get_request_kwargs(cfg.load())

    try:
        html = fetch_html(patent_number, timeout=15, **request_kwargs)
    except PatentNotFoundError:
        print_error("Patent not found", patent_number)
        sys.exit(1)
    except FetchError as e:
        print_error(f"Network error: {e}", patent_number)
        sys.exit(1)

    data = parse_all(html)
    pdf_url = data.get("pdf_url")
    if not pdf_url:
        click.echo("Error: PDF link not found for this patent.", err=True)
        sys.exit(1)

    pub_number = data.get("publication_number") or patent_number.upper().replace("-", "")
    filename = f"{pub_number}.pdf"
    dest = os.path.join(output_dir, filename)

    os.makedirs(output_dir, exist_ok=True)
    logger.debug("PDF URL: %s", pdf_url)
    click.echo(f"Downloading: {pdf_url}", err=True)

    try:
        fetch_pdf(pdf_url, dest, timeout=timeout, **request_kwargs)
    except FetchError as e:
        print_error(f"PDF download failed: {e}", patent_number)
        sys.exit(1)

    click.echo(f"Saved: {dest}")


@main.command()
@click.argument('patent_number')
@click.option('--output-dir', '-o', default='.', show_default=True, metavar='DIR',
              help='Directory to save images.')
@click.option('--timeout', '-t', default=30, show_default=True,
              help='HTTP request timeout in seconds per image.')
@click.pass_context
def images(
    ctx: click.Context,
    patent_number: str,
    output_dir: str,
    timeout: int,
) -> None:
    """Download high-resolution figure images for PATENT_NUMBER.

    \b
    Files are saved as fig01.png, fig02.png, ...

    \b
    Examples:
      gpc images US11125686B2
      gpc images KR102355140B1 --output-dir ./figs
    """
    import os
    logger = logging.getLogger(__name__)
    request_kwargs = cfg.get_request_kwargs(cfg.load())

    try:
        html = fetch_html(patent_number, timeout=15, **request_kwargs)
    except PatentNotFoundError:
        print_error("Patent not found", patent_number)
        sys.exit(1)
    except FetchError as e:
        print_error(f"Network error: {e}", patent_number)
        sys.exit(1)

    data = parse_all(html)
    pub_number = data.get("publication_number") or patent_number.upper().replace("-", "")

    urls = parse_image_urls(html)
    if not urls:
        click.echo("No figure images found.", err=True)
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)
    click.echo(f"Found {len(urls)} figure image(s) for {pub_number}.", err=True)

    for i, url in enumerate(urls, start=1):
        filename = f"fig{i:02d}.png"
        dest = os.path.join(output_dir, filename)
        logger.debug("Image URL: %s", url)
        click.echo(f"  [{i}/{len(urls)}] {filename}", err=True)
        try:
            fetch_image(url, dest, timeout=timeout, **request_kwargs)
            click.echo(f"Saved: {dest}")
        except FetchError as e:
            click.echo(f"  Warning: failed to download image {i}: {e}", err=True)


@main.command()
def fields() -> None:
    """List all available output fields and their labels."""
    from .formatter import _LABELS
    for key in FIELD_ORDER:
        label = _LABELS.get(key, key)
        click.echo(f"  {key:<25} {label}")


@main.command()
def configure() -> None:
    """Interactively set proxy and CA-cert options and save to config file.

    \b
    Config file: ~/.patent-cli.toml
    Press Enter with no value to skip a field.
    Existing values are shown as defaults.
    """
    existing = cfg.load()
    proxy_cfg = existing.get("proxy", {})
    ssl_cfg = existing.get("ssl", {})

    click.echo("Google Patent CLI — Configuration")
    click.echo("─" * 40)
    click.echo(f"Config file: {cfg.CONFIG_PATH}")
    click.echo()

    https_proxy = click.prompt(
        "HTTPS proxy URL",
        default=proxy_cfg.get("https", ""),
        show_default=bool(proxy_cfg.get("https")),
    ).strip()

    http_proxy = click.prompt(
        "HTTP  proxy URL",
        default=proxy_cfg.get("http", ""),
        show_default=bool(proxy_cfg.get("http")),
    ).strip()

    ca_bundle = click.prompt(
        "CA bundle file path",
        default=ssl_cfg.get("ca_bundle", ""),
        show_default=bool(ssl_cfg.get("ca_bundle")),
    ).strip()

    new_config: dict = {}
    if https_proxy or http_proxy:
        new_config["proxy"] = {}
        if https_proxy:
            new_config["proxy"]["https"] = https_proxy
        if http_proxy:
            new_config["proxy"]["http"] = http_proxy
    if ca_bundle:
        new_config["ssl"] = {"ca_bundle": ca_bundle}

    if not new_config:
        click.echo("\nNo values entered — config file not saved.")
        return

    cfg.save(new_config)
    click.echo(f"\nConfig saved: {cfg.CONFIG_PATH}")

    click.echo()
    if new_config.get("proxy"):
        for k, v in new_config["proxy"].items():
            click.echo(f"  proxy.{k} = {v}")
    if new_config.get("ssl"):
        click.echo(f"  ssl.ca_bundle = {new_config['ssl']['ca_bundle']}")
