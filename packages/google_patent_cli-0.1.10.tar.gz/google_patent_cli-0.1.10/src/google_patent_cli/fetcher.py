import re
import logging

import requests

logger = logging.getLogger(__name__)

_BASE_URL = "https://patents.google.com/patent"

# 공개번호 6자리 시퀀스: US + 연도(4) + 시퀀스(6) + 선택적 kind code
_PUB_6DIGIT_RE = re.compile(r'^(US)(\d{4})(\d{6})([A-Z]\d*)?$')


class PatentNotFoundError(Exception):
    pass


class FetchError(Exception):
    pass


def normalize_for_url(patent_number: str) -> str:
    """특허번호를 Google Patents URL용 형식으로 정규화.

    공개번호 6자리 시퀀스(US20250350789 형식 중 시퀀스가 6자리인 것)를
    7자리로 변환한다. 나머지는 그대로 반환.
    """
    clean = re.sub(r'[^A-Z0-9]', '', patent_number.upper())
    m = _PUB_6DIGIT_RE.match(clean)
    if m:
        country, year, seq6, kind = m.groups()
        return f"{country}{year}{seq6.zfill(7)}{kind or ''}"
    return clean


def fetch_html(
    patent_number: str,
    timeout: int = 15,
    proxies: dict | None = None,
    verify: str | bool = True,
) -> str:
    """Google Patents 페이지 HTML을 반환.

    Args:
        proxies: requests 프록시 dict (예: {"https": "http://proxy:8080"}).
                 None이면 환경변수(HTTPS_PROXY 등)로 fallback.
        verify:  CA 번들 경로 또는 True(기본 검증) / False(검증 비활성).
                 True이면 환경변수(REQUESTS_CA_BUNDLE)로 fallback.

    Raises:
        PatentNotFoundError: 404 응답
        FetchError: 네트워크 오류 또는 기타 HTTP 오류
    """
    normalized = normalize_for_url(patent_number)
    url = f"{_BASE_URL}/{normalized}"
    logger.debug("GET %s", url)

    try:
        headers = {"User-Agent": "Mozilla/5.0 (compatible; patent-cli/1.0)"}
        resp = requests.get(
            url,
            headers=headers,
            timeout=timeout,
            proxies=proxies,
            verify=verify,
        )
        resp.raise_for_status()
        resp.encoding = 'utf-8'
        return resp.text
    except requests.HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            raise PatentNotFoundError(patent_number) from e
        raise FetchError(str(e)) from e
    except requests.RequestException as e:
        raise FetchError(str(e)) from e


def fetch_image(
    image_url: str,
    dest_path: str,
    timeout: int = 30,
    proxies: dict | None = None,
    verify: str | bool = True,
) -> None:
    """이미지를 다운로드하여 파일에 저장.

    Raises:
        FetchError: 네트워크 오류 또는 HTTP 오류
    """
    logger.debug("GET %s", image_url)
    try:
        headers = {"User-Agent": "Mozilla/5.0 (compatible; patent-cli/1.0)"}
        resp = requests.get(
            image_url,
            headers=headers,
            timeout=timeout,
            proxies=proxies,
            verify=verify,
            stream=True,
        )
        resp.raise_for_status()
        with open(dest_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                f.write(chunk)
    except requests.RequestException as e:
        raise FetchError(str(e)) from e


def fetch_pdf(
    pdf_url: str,
    dest_path: str,
    timeout: int = 60,
    proxies: dict | None = None,
    verify: str | bool = True,
) -> None:
    """PDF를 스트리밍으로 다운로드하여 파일에 저장.

    Raises:
        FetchError: 네트워크 오류 또는 HTTP 오류
    """
    logger.debug("GET %s", pdf_url)
    try:
        headers = {"User-Agent": "Mozilla/5.0 (compatible; patent-cli/1.0)"}
        resp = requests.get(
            pdf_url,
            headers=headers,
            timeout=timeout,
            proxies=proxies,
            verify=verify,
            stream=True,
        )
        resp.raise_for_status()
        with open(dest_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                f.write(chunk)
    except requests.RequestException as e:
        raise FetchError(str(e)) from e
