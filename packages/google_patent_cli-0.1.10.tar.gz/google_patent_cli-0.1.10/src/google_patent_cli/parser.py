import re
from collections import OrderedDict
from bs4 import BeautifulSoup, Tag


def parse_all(html: str) -> dict:
    """Google Patents HTML에서 모든 필드를 파싱하여 dict 반환."""
    soup = BeautifulSoup(html, 'html.parser')

    pub_number, number_without_kind, kind_code = _parse_pub_number(html)
    app_number = _parse_app_number(html)
    country = pub_number[:2] if pub_number and pub_number[:2].isalpha() else None

    inventors = _parse_inventors(soup)
    contributors = _parse_dc_contributors(soup)

    return {
        "publication_number":        pub_number,
        "number_without_kind":       number_without_kind,
        "application_number":        app_number,
        "kind_code":                 kind_code,
        "country":                   country,
        "title":                     _parse_title(soup),
        "abstract":                  _parse_abstract(soup),
        "inventors":                 inventors,
        "assignee":                  _parse_assignee(soup, inventors, contributors),
        "filing_date":               _dc_date(soup, "dateSubmitted"),
        "publication_date":          _dc_date(soup, "issue"),
        "cpc_codes":                 _parse_cpc_codes(soup),
        "claims":                    _parse_claims(soup),
        "description":               _parse_description(soup),
        "pdf_url":                   _parse_pdf_url(soup),
        "patent_url":                f"https://patents.google.com/patent/{pub_number}" if pub_number else None,
        "backward_citations":        _parse_patent_citation_rows(soup, "backwardReferencesOrig"),
        "backward_citations_family": _parse_patent_citation_rows(soup, "backwardReferencesFamily"),
        "non_patent_citations":      _parse_non_patent_citations(soup),
        "forward_citations":         _parse_patent_citation_rows(soup, "forwardReferencesOrig"),
        "forward_citations_family":  _parse_patent_citation_rows(soup, "forwardReferencesFamily"),
        "similar_documents":         _parse_similar_documents(soup),
        "family_applications":       _parse_family_applications(soup),
    }


# ── 번호 파싱 ──────────────────────────────────────────────────────────────────

_CANONICAL_RE = re.compile(
    r'<link\s[^>]*rel="canonical"\s[^>]*href="https://patents\.google\.com/patent/([^/]+)/',
    re.IGNORECASE,
)
_META_APP_RE = re.compile(
    r'<meta\s[^>]*name="citation_patent_application_number"\s[^>]*content="([^"]+)"',
    re.IGNORECASE,
)


def _parse_pub_number(html: str) -> tuple[str | None, str | None, str | None]:
    """canonical URL에서 (publication_number, number_without_kind, kind_code) 반환."""
    m = _CANONICAL_RE.search(html)
    if not m:
        return None, None, None
    raw = m.group(1).upper()
    km = re.match(r'^([A-Z]{2})(\d+)([A-Z]\d?)?$', raw)
    if not km:
        return None, None, None
    country, digits, kind = km.group(1), km.group(2), km.group(3) or ''
    pub = f"{country}{digits}{kind}"
    without = f"{country}{digits}"
    return pub, without, kind or None


def _parse_app_number(html: str) -> str | None:
    """citation_patent_application_number 메타태그에서 출원번호 반환 (예: US19203048)."""
    m = _META_APP_RE.search(html)
    if not m:
        return None
    parts = m.group(1).split(':', 1)
    if len(parts) != 2:
        return None
    country = parts[0].strip().upper()
    digits = re.sub(r'[^0-9]', '', parts[1])
    if not country or not digits:
        return None
    return f"{country}{digits}"


# ── 서지사항 파싱 ──────────────────────────────────────────────────────────────

def _meta(soup: BeautifulSoup, name: str) -> str | None:
    tag = soup.find('meta', attrs={'name': name})
    if tag and isinstance(tag, Tag):
        return tag.get('content') or None  # type: ignore[return-value]
    return None


def _parse_title(soup: BeautifulSoup) -> str | None:
    for name in ('DC.title', 'citation_title'):
        val = _meta(soup, name)
        if val:
            return val.strip()
    # <title> 태그 fallback ("특허명 - Google Patents" 형식에서 앞부분만)
    title_tag = soup.find('title')
    if title_tag and title_tag.string:
        text = title_tag.string.strip()
        if ' - Google Patents' in text:
            return text.replace(' - Google Patents', '').strip()
        return text
    return None


def _parse_abstract(soup: BeautifulSoup) -> str | None:
    # <section itemprop="abstract"> 구조: 내부 div.abstract에 실제 텍스트
    section = soup.find(attrs={'itemprop': 'abstract'})
    if section and isinstance(section, Tag):
        inner = section.find(class_='abstract')
        target = inner if inner and isinstance(inner, Tag) else section
        text = target.get_text(separator=' ', strip=True)
        if text:
            return text

    # <div class="abstract"> 직접 사용하는 구조 fallback
    tag = soup.find(class_='abstract')
    if tag and isinstance(tag, Tag):
        text = tag.get_text(separator=' ', strip=True)
        if text:
            return text

    # meta description fallback (보통 잘림)
    val = _meta(soup, 'description')
    return val.strip() if val else None


def _parse_inventors(soup: BeautifulSoup) -> list[str]:
    # citation_author 메타태그 (한 명당 하나씩 반복)
    tags = soup.find_all('meta', attrs={'name': 'citation_author'})
    inventors = [t.get('content', '').strip() for t in tags if t.get('content')]
    if inventors:
        return inventors

    # itemprop="inventor" fallback
    tags = soup.find_all(attrs={'itemprop': 'inventor'})
    return [t.get_text(strip=True) for t in tags if t.get_text(strip=True)]


def _parse_dc_contributors(soup: BeautifulSoup) -> list[str]:
    """DC.contributor 메타태그 전체 목록 반환 (발명자 + 출원인 혼재)."""
    return [
        t.get('content', '').strip()
        for t in soup.find_all('meta', attrs={'name': 'DC.contributor'})
        if t.get('content', '').strip()
    ]


def _parse_assignee(
    soup: BeautifulSoup,
    inventors: list[str],
    contributors: list[str],
) -> str | None:
    # DC.contributor 중 발명자 이름에 없는 항목 → 출원인
    inventor_set = set(inventors)
    for name in contributors:
        if name not in inventor_set:
            return name
    return None


# ── 분류 ──────────────────────────────────────────────────────────────────────

_CPC_FULL_RE = re.compile(r'^[A-H]\d{2}[A-Z]\d+/\d+')


def _parse_cpc_codes(soup: BeautifulSoup) -> list[str]:
    """CPC 코드 목록 반환 (풀 코드만, 중복 제거, 예: A01B33/08)."""
    seen: set[str] = set()
    result: list[str] = []
    for li in soup.find_all('li', itemprop='classifications'):
        if not isinstance(li, Tag):
            continue
        if not li.find('meta', itemprop='IsCPC', content='true'):
            continue
        code_tag = li.find(itemprop='Code')
        if not code_tag:
            continue
        code = code_tag.get_text(strip=True)
        if _CPC_FULL_RE.match(code) and code not in seen:
            seen.add(code)
            result.append(code)
    return result


# ── 청구항 / 상세설명 ──────────────────────────────────────────────────────────

_CLAIM_SPACE_RE = re.compile(r'(\d+)\s+\.\s+')  # "1 . " → "1. "


def _parse_claims(soup: BeautifulSoup) -> list[str]:
    """청구항 목록 반환. 독립항(claim) + 종속항(claim-dependent) 순서 유지."""
    # US 스타일: <div class="claims"> 바로 아래 div.claim / div.claim-dependent
    container = soup.find('div', class_='claims')
    # KR/기타 스타일: <section itemprop="claims"> → <ol class="claims">
    if not container or not isinstance(container, Tag):
        section = soup.find(attrs={'itemprop': 'claims'})
        if section and isinstance(section, Tag):
            container = section.find('ol', class_='claims')
    if not container or not isinstance(container, Tag):
        return []
    result = []
    for child in container.children:
        if not isinstance(child, Tag):
            continue
        classes = child.get('class') or []
        if not ('claim' in classes or 'claim-dependent' in classes):
            continue
        text = child.get_text(separator=' ', strip=True)
        text = _CLAIM_SPACE_RE.sub(r'\1. ', text)
        text = re.sub(r' {2,}', ' ', text)
        if not text:
            continue
        # 텍스트에 번호가 없으면(KR 등) num 속성에서 가져와 앞에 붙인다
        if not re.match(r'^\d+\.', text):
            inner = child.find(class_='claim', attrs={'num': True})
            if inner and isinstance(inner, Tag):
                num = str(int(inner['num']))  # "01" → "1"
                text = f"{num}. {text}"
        result.append(text)
    return result


_SMART_QUOTE_TABLE = str.maketrans({
    '‘': "'", '’': "'",
    '‚': "'", '‛': "'",
    '“': "'", '”': "'",
    '„': "'", '‟': "'",
    '′': "'", '″': "'",
    '–': '-', '—': '-',
    '…': '...',
})


def _parse_description(soup: BeautifulSoup) -> str | None:
    """Return the full description as a clean, flat string."""
    tag = soup.find(class_='description') or soup.find(itemprop='description')
    if not tag or not isinstance(tag, Tag):
        return None
    text = tag.get_text(separator=' ', strip=True)
    text = re.sub(r'\s+', ' ', text).strip()
    # "FIG. 5 B ," → "FIG. 5B," — rejoin figure/table ref tokens split by DOM
    text = re.sub(r'\b(FIGS?|TABLES?)\.\s*(\d+)\s+([A-Z])\b', r'\1. \2\3', text)
    # "44 AL" / "44 BR" → "44AL" / "44BR" — reference numeral letter suffixes
    text = re.sub(r'(\d+)\s+([A-Z]{1,2})(?=[^a-z])', r'\1\2', text)
    # remove stray space before comma/period/semicolon that follows a word char
    text = re.sub(r'(\w)\s+([,;])', r'\1\2', text)
    text = text.translate(_SMART_QUOTE_TABLE)
    return text or None


# ── 날짜 ──────────────────────────────────────────────────────────────────────

def _parse_pdf_url(soup: BeautifulSoup) -> str | None:
    tag = soup.find('a', itemprop='pdfLink')
    if tag and isinstance(tag, Tag):
        href = tag.get('href', '').strip()
        return href or None
    return None


def _dc_date(soup: BeautifulSoup, scheme: str) -> str | None:
    """DC.date[scheme=<scheme>] 메타태그에서 날짜 반환."""
    tag = soup.find('meta', attrs={'name': 'DC.date', 'scheme': scheme})
    if tag and isinstance(tag, Tag):
        val = tag.get('content', '').strip()
        return val or None
    return None


# ── Citations ─────────────────────────────────────────────────────────────────

def _citation_marker(tr: Tag) -> tuple[bool, bool]:
    """(cited_by_examiner, cited_by_third_party) 반환."""
    cited_by_examiner = bool(tr.find(itemprop='examinerCited'))
    cited_by_third_party = bool(tr.find(itemprop='thirdPartyCited'))
    if not cited_by_third_party:
        for span in tr.find_all('span'):
            if span.get_text(strip=True) == '†':
                cited_by_third_party = True
                break
    return cited_by_examiner, cited_by_third_party


def _parse_patent_citation_rows(soup: BeautifulSoup, itemprop_value: str) -> list[dict]:
    """backwardReferences / backwardReferencesFamily / forwardReferences 공통 파서."""
    result = []
    for tr in soup.find_all('tr', itemprop=itemprop_value):
        if not isinstance(tr, Tag):
            continue
        pub_tag = tr.find(itemprop='publicationNumber')
        pub = pub_tag.get_text(strip=True) if pub_tag else None

        priority_tag = tr.find(itemprop='priorityDate')
        priority = priority_tag.get_text(strip=True) if priority_tag else None

        pub_date_tag = tr.find(itemprop='publicationDate')
        pub_date = pub_date_tag.get_text(strip=True) if pub_date_tag else None

        assignee_tag = tr.find(itemprop='assigneeOriginal')
        assignee = assignee_tag.get_text(strip=True) if assignee_tag else None

        title_tag = tr.find(itemprop='title')
        title = title_tag.get_text(strip=True) if title_tag else None

        examiner, third_party = _citation_marker(tr)

        entry: dict = {"publication_number": pub}
        if priority:
            entry["priority_date"] = priority
        if pub_date:
            entry["publication_date"] = pub_date
        if assignee:
            entry["assignee"] = assignee
        if title:
            entry["title"] = title
        entry["cited_by_examiner"] = examiner
        entry["cited_by_third_party"] = third_party

        result.append(entry)
    return result


def _parse_non_patent_citations(soup: BeautifulSoup) -> list[dict]:
    result = []
    for tr in soup.find_all('tr', itemprop='detailedNonPatentLiterature'):
        if not isinstance(tr, Tag):
            continue
        title_tag = tr.find(itemprop='title')
        title = title_tag.get_text(strip=True).replace('"', '') if title_tag else None
        if not title:
            continue
        examiner, third_party = _citation_marker(tr)
        result.append({
            "title": title,
            "cited_by_examiner": examiner,
            "cited_by_third_party": third_party,
        })
    return result


def _parse_family_applications(soup: BeautifulSoup) -> list[dict]:
    """li[itemprop=applicationsByYear] → li[itemprop=application] 파싱."""
    result = []
    for li_app in soup.find_all("li", itemprop="application"):
        if not isinstance(li_app, Tag):
            continue
        filing = li_app.find("span", itemprop="filingDate")
        country = li_app.find("span", itemprop="countryCode")
        app_num = li_app.find("span", itemprop="applicationNumber")
        status_cat = li_app.find("span", itemprop="legalStatusCat")
        status = li_app.find("span", itemprop="legalStatus")
        link = li_app.find("a", href=True)

        patent_number = None
        if link:
            parts = link["href"].strip("/").split("/")
            if len(parts) >= 2:
                patent_number = parts[1]

        entry: dict = {}
        if filing:
            entry["filing_date"] = filing.get_text(strip=True)
        if country:
            entry["country_code"] = country.get_text(strip=True)
        if app_num:
            entry["application_number"] = app_num.get_text(strip=True)
        if patent_number:
            entry["patent_number"] = patent_number
        if status_cat:
            entry["legal_status_cat"] = status_cat.get_text(strip=True)
        if status:
            entry["legal_status"] = status.get_text(strip=True)
        result.append(entry)
    return result


_IMAGE_URL_RE = re.compile(
    r'https://patentimages\.storage\.googleapis\.com'
    r'/[a-f0-9]{2}/[a-f0-9]{2}/[a-f0-9]{2}/[a-f0-9]+'
    r'/([^/"]+\.png)'
)


def parse_image_urls(html: str) -> list[str]:
    """HTML에서 고해상도 이미지 URL 목록 반환.

    동일 파일명이 2번 이상 등장할 때 마지막 URL을 고해상도로 간주한다.
    1번만 등장하는 파일(썸네일 전용, PDF에 없는 수식 이미지 등)은 제외한다.
    """
    seen: OrderedDict[str, list[str]] = OrderedDict()
    for m in _IMAGE_URL_RE.finditer(html):
        filename = m.group(1)
        seen.setdefault(filename, []).append(m.group(0))
    return [urls[-1] for urls in seen.values()]


def _parse_similar_documents(soup: BeautifulSoup) -> list[dict]:
    result = []
    for tr in soup.find_all('tr', itemprop='similarDocuments'):
        if not isinstance(tr, Tag):
            continue

        date_tag = tr.find(itemprop='publicationDate')
        pub_date = date_tag.get_text(strip=True) if date_tag else None

        title_tag = tr.find(itemprop='title')
        title = title_tag.get_text(strip=True) if title_tag else None

        pub_tag = tr.find(itemprop='publicationNumber')
        if pub_tag:
            pub = pub_tag.get_text(strip=True)
            entry: dict = {"publication_number": pub}
            if pub_date:
                entry["publication_date"] = pub_date
            if title:
                entry["title"] = title
        else:
            scholar_id_tag = tr.find(itemprop='scholarID')
            if not scholar_id_tag:
                continue
            scholar_id = scholar_id_tag.get("content", "")
            authors_tag = tr.find(itemprop='scholarAuthors')
            authors = authors_tag.get_text(strip=True) if authors_tag else None
            entry = {"scholar_id": scholar_id}
            if authors:
                entry["authors"] = authors
            if pub_date:
                entry["publication_date"] = pub_date
            if title:
                entry["title"] = title

        result.append(entry)
    return result
