"""
테스트 픽스처 특허들의 인용 개수를 표 형식으로 출력한다.
브라우저에서 직접 확인한 결과와 비교용.

실행:
  uv run python scripts/citation_counts.py
  uv run python scripts/citation_counts.py --live   # 실시간 fetch (픽스처 없는 특허 포함)
"""
from __future__ import annotations

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from google_patent_cli.parser import parse_all

FIXTURES_DIR = Path(__file__).parent.parent / "tests" / "fixtures"

# 픽스처 파일 → (특허번호, Google Patents URL)
FIXTURE_PATENTS = [
    ("KR101335518B1",  "KR101335518"),
    ("KR102355140B1",  "KR102355140B1"),
    ("US11408725B2",   "US11408725B2"),
    ("US12514139B2",   "US12514139B2"),
    ("EP3945307B1",    "EP3945307B1"),
    ("JP7117677B2",    "JP7117677B2"),
    ("CN114002190B",   "CN114002190B"),
]

# 픽스처 없이 실시간 fetch할 추가 특허
LIVE_EXTRA = [
    "EP3303985A1",
    "EP3303985A4",
]

CITATION_FIELDS = [
    "backward_citations",
    "backward_citations_family",
    "non_patent_citations",
    "forward_citations",
    "forward_citations_family",
]

COL_LABELS = {
    "backward_citations":        "BW_orig",
    "backward_citations_family": "BW_family",
    "non_patent_citations":      "NPC",
    "forward_citations":         "FW_orig",
    "forward_citations_family":  "FW_family",
}

GP_URL = "https://patents.google.com/patent/{pid}/en"


def count(parsed: dict, field: str) -> int:
    val = parsed.get(field)
    if isinstance(val, list):
        return len(val)
    return 0


def load_fixture(fixture_name: str) -> dict:
    path = FIXTURES_DIR / f"{fixture_name}.html"
    html = path.read_text(encoding="utf-8")
    return parse_all(html)


def load_live(patent_id: str) -> dict:
    from google_patent_cli.fetcher import fetch_html
    return parse_all(fetch_html(patent_id))


def print_table(rows: list[tuple]) -> None:
    # rows: (patent_id, source, counts_dict, url)
    col_w = 20
    num_w = 10

    header = f"{'특허번호':<{col_w}} {'소스':<8}" + "".join(
        f"{COL_LABELS[f]:>{num_w}}" for f in CITATION_FIELDS
    ) + f"  {'URL'}"
    print(header)
    print("-" * len(header))

    prev_country = None
    for patent_id, source, counts, url in rows:
        country = patent_id[:2]
        if prev_country and country != prev_country:
            print()  # 국가별 빈 줄 구분
        prev_country = country

        nums = "".join(f"{counts[f]:>{num_w}}" for f in CITATION_FIELDS)
        print(f"{patent_id:<{col_w}} {source:<8}{nums}  {url}")

    print()
    print(f"{'필드 설명':}")
    print(f"  BW_orig   = backward_citations        (backwardReferencesOrig,   심사관 직접 인용)")
    print(f"  BW_family = backward_citations_family (backwardReferencesFamily, 패밀리간 backward 인용)")
    print(f"  NPC       = non_patent_citations      (비특허문헌 인용)")
    print(f"  FW_orig   = forward_citations         (forwardReferencesOrig,    이 특허를 직접 인용한 특허)")
    print(f"  FW_family = forward_citations_family  (forwardReferencesFamily,  패밀리간 forward 인용)")
    print(f"  ※ 브라우저 'Cited By (N)' = FW_orig + FW_family")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true", help="실시간 fetch (느림)")
    args = ap.parse_args()

    rows = []

    for patent_id, fixture_name in FIXTURE_PATENTS:
        try:
            parsed = load_fixture(fixture_name)
            source = "fixture"
        except FileNotFoundError:
            if args.live:
                print(f"[fetch] {patent_id}...", end=" ", flush=True)
                parsed = load_live(patent_id)
                source = "live"
                print("완료")
            else:
                print(f"[건너뜀] {patent_id} (픽스처 없음, --live 옵션 사용)")
                continue

        counts = {f: count(parsed, f) for f in CITATION_FIELDS}
        url = GP_URL.format(pid=patent_id)
        rows.append((patent_id, source, counts, url))

    if args.live:
        for patent_id in LIVE_EXTRA:
            print(f"[fetch] {patent_id}...", end=" ", flush=True)
            parsed = load_live(patent_id)
            source = "live"
            print("완료")
            counts = {f: count(parsed, f) for f in CITATION_FIELDS}
            url = GP_URL.format(pid=patent_id)
            rows.append((patent_id, source, counts, url))

    print()
    print_table(rows)


if __name__ == "__main__":
    main()
