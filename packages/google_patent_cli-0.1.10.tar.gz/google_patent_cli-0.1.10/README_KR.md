# google-patent-cli

Google Patents에서 특허 메타데이터를 조회하는 커맨드라인 도구입니다.

## 설치

```bash
# pipx (권장 — 격리된 환경)
pipx install google-patent-cli

# uv
uv tool install google-patent-cli

# pip
pip install google-patent-cli
```

> **Windows 사용자**: 설치 후 `gpc` 명령이 인식되지 않으면 `pipx ensurepath` 실행 후 터미널을 재시작하세요.

## 업데이트

```bash
# pipx
pipx upgrade google-patent-cli

# uv
uv tool upgrade google-patent-cli

# pip
pip install --upgrade google-patent-cli
```

## 사용법

### 특허 조회

```bash
# 기본 (JSON 출력)
gpc lookup US20250350789

# 텍스트 형식
gpc lookup US12514139B2 --format text

# TSV 형식
gpc lookup US20250350789 --format tsv

# 단일 필드만 출력
gpc lookup US20250350789 --field title

# 여러 필드 선택
gpc lookup US20250350789 --fields title,assignee,filing_date

# 파일로 저장
gpc lookup US12514139B2 --output-dir ./output
gpc lookup US12514139B2 --format text --output-dir ./output
```

### 특허 PDF 다운로드

```bash
# 현재 폴더에 US9735861B2.pdf로 저장
gpc download US9735861

# 특정 폴더에 저장
gpc download US9735861 --output-dir ./pdfs
```

### 도면 이미지 다운로드

고해상도 도면 이미지를 fig01.png, fig02.png, ... 형식으로 저장합니다.

```bash
# 현재 폴더에 저장
gpc images US11125686B2

# 특정 폴더에 저장
gpc images KR102355140B1 --output-dir ./figs
```

US, KR, JP, EP, CN 특허 모두 지원합니다.

### 사용 가능한 필드 목록

```bash
gpc fields
```

| 필드명 | 설명 |
|--------|------|
| `publication_number` | 공개번호 (예: US12514139B2) |
| `number_without_kind` | Kind code 제외 번호 |
| `application_number` | 출원번호 |
| `kind_code` | Kind code (예: B2, A1) |
| `country` | 국가 코드 |
| `title` | 발명의 명칭 |
| `abstract` | 요약 |
| `inventors` | 발명자 목록 |
| `assignee` | 출원인 / 양수인 |
| `filing_date` | 출원일 |
| `publication_date` | 공개일 |
| `cpc_codes` | CPC 분류 코드 목록 |
| `claims` | 청구항 목록 |
| `description` | 상세설명 전문 |
| `pdf_url` | PDF 다운로드 URL |
| `patent_url` | Google Patents 페이지 URL (kind code 포함) |
| `backward_citations` | Patent Citations (backward) — 이 특허가 인용한 특허 목록. 각 항목: `publication_number`, `priority_date`, `publication_date`, `assignee`, `title`, `cited_by_examiner` (`*`), `cited_by_third_party` (`†`) |
| `backward_citations_family` | Family to Family Citations — `backward_citations`와 동일한 구조 |
| `non_patent_citations` | Non-Patent Citations — 각 항목: `title`, `cited_by_examiner`, `cited_by_third_party` |
| `forward_citations` | Cited By (forward) — 이 특허를 인용한 특허 목록. `backward_citations`와 동일한 구조 |
| `forward_citations_family` | Cited By (Family) — `backward_citations`와 동일한 구조 |
| `similar_documents` | Similar Documents — 각 항목: `publication_number`, `publication_date`, `title` |
| `family_applications` | Worldwide Applications — 각 항목: `filing_date`, `country_code`, `application_number`, `patent_number`, `legal_status_cat`, `legal_status` |

### 프록시 / SSL 설정

사내 네트워크나 프록시 환경에서는 설정 파일을 사용합니다.

```bash
gpc configure
```

설정은 `~/.patent-cli.toml` 에 저장됩니다.

```toml
[proxy]
https = "http://proxy.example.com:8080"
http  = "http://proxy.example.com:8080"

[ssl]
ca_bundle = "/path/to/ca-bundle.crt"
```

### 옵션

```
gpc lookup --help

Options:
  -f, --format [json|text|tsv]  출력 형식 (기본: json)
  --field FIELD                  단일 필드 값만 출력
  --fields F1,F2,...             쉼표 구분 필드 목록
  -t, --timeout INTEGER          HTTP 타임아웃 (초, 기본: 15)
  -o, --output-dir DIR           결과 파일 저장 폴더
  -v, --verbose                  디버그 로그 출력
```

## 제거

```bash
# pipx
pipx uninstall google-patent-cli

# uv
uv tool uninstall google-patent-cli

# pip
pip uninstall google-patent-cli
```

## python -m 으로 실행

```bash
python -m google_patent_cli lookup US12514139B2
```

## 면책 조항

이 도구는 Google Patents 공개 웹 페이지를 스크래핑합니다.
Google 이용 약관을 준수하여 사용하세요.
과도한 요청은 IP 차단으로 이어질 수 있습니다.

## 라이선스

MIT
