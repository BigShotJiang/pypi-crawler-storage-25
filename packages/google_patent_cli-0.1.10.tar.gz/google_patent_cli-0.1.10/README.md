# google-patent-cli

A command-line tool to fetch patent metadata from Google Patents.

## Installation

```bash
# pipx (recommended — isolated environment)
pipx install google-patent-cli

# uv
uv tool install google-patent-cli

# pip
pip install google-patent-cli
```

> **Windows users**: If the `gpc` command is not recognized after installation, run `pipx ensurepath` and restart your terminal.

## Update

```bash
# pipx
pipx upgrade google-patent-cli

# uv
uv tool upgrade google-patent-cli

# pip
pip install --upgrade google-patent-cli
```

## Usage

### Fetch a patent

```bash
# Default output (JSON)
gpc lookup US20250350789

# Text format
gpc lookup US12514139B2 --format text

# TSV format
gpc lookup US20250350789 --format tsv

# Single field
gpc lookup US20250350789 --field title

# Multiple fields
gpc lookup US20250350789 --fields title,assignee,filing_date

# Save to file
gpc lookup US12514139B2 --output-dir ./output
gpc lookup US12514139B2 --format text --output-dir ./output
```

### Download patent PDF

```bash
# Save to current directory as US9735861B2.pdf
gpc download US9735861

# Save to a specific directory
gpc download US9735861 --output-dir ./pdfs
```

### Download figure images

Downloads high-resolution figure images (fig01.png, fig02.png, ...).

```bash
# Save to current directory
gpc images US11125686B2

# Save to a specific directory
gpc images KR102355140B1 --output-dir ./figs
```

Works with US, KR, JP, EP, and CN patents.

### List available fields

```bash
gpc fields
```

| Field | Description |
|-------|-------------|
| `publication_number` | Publication number (e.g. US12514139B2) |
| `number_without_kind` | Publication number without kind code |
| `application_number` | Application number |
| `kind_code` | Kind code (e.g. B2, A1) |
| `country` | Country code |
| `title` | Title of the invention |
| `abstract` | Abstract |
| `inventors` | List of inventors |
| `assignee` | Assignee / applicant |
| `filing_date` | Filing date |
| `publication_date` | Publication date |
| `cpc_codes` | CPC classification codes |
| `claims` | List of claims |
| `description` | Full description text |
| `pdf_url` | PDF download URL |
| `patent_url` | Google Patents page URL (with kind code) |
| `backward_citations` | Patent Citations — patents cited by this patent. Each entry includes `publication_number`, `priority_date`, `publication_date`, `assignee`, `title`, `cited_by_examiner` (`*`), `cited_by_third_party` (`†`) |
| `backward_citations_family` | Family to Family Citations — same structure as `backward_citations` |
| `non_patent_citations` | Non-Patent Citations — each entry includes `title`, `cited_by_examiner`, `cited_by_third_party` |
| `forward_citations` | Cited By — patents that cite this patent. Same structure as `backward_citations` |
| `forward_citations_family` | Cited By (Family) — same structure as `backward_citations` |
| `similar_documents` | Similar Documents — each entry includes `publication_number`, `publication_date`, `title` |
| `family_applications` | Worldwide Applications — each entry includes `filing_date`, `country_code`, `application_number`, `patent_number`, `legal_status_cat`, `legal_status` |

### Proxy / SSL configuration

For corporate networks or proxy environments:

```bash
gpc configure
```

Settings are saved to `~/.patent-cli.toml`:

```toml
[proxy]
https = "http://proxy.example.com:8080"
http  = "http://proxy.example.com:8080"

[ssl]
ca_bundle = "/path/to/ca-bundle.crt"
```

### Options

```
gpc lookup --help

Options:
  -f, --format [json|text|tsv]  Output format (default: json)
  --field FIELD                  Print a single field value
  --fields F1,F2,...             Comma-separated list of fields to include
  -t, --timeout INTEGER          HTTP timeout in seconds (default: 15)
  -o, --output-dir DIR           Directory to save output file
  -v, --verbose                  Print debug logs to stderr
```

## Uninstall

```bash
# pipx
pipx uninstall google-patent-cli

# uv
uv tool uninstall google-patent-cli

# pip
pip uninstall google-patent-cli
```

## Run as a module

```bash
python -m google_patent_cli lookup US12514139B2
```

## Disclaimer

This tool scrapes Google Patents public web pages.
Please comply with Google's Terms of Service.
Excessive requests may result in IP blocking.

## License

MIT
