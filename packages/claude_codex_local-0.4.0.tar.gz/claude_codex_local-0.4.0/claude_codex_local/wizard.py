#!/usr/bin/env python3
"""
Interactive first-run wizard for claude-codex-local.

Implements the 8-step flow from PRD v1.2 §4.1:

  2.1 Discover environment (harnesses, engines, llmfit, disk)
  2.2 Install missing components (guided sub-process)
  2.3 Pick preferences (primary harness + engine)
  2.4 Pick a model (user-first, optional find-model helper)
  2.5 Smoke test engine + model
  2.6 Wire up harness (isolated settings.json / launch config)
  2.7 Verify launch command end-to-end
  2.8 Generate personalized guide.md

The wizard is idempotent and resumable: state is checkpointed to
`.claude-codex-local/wizard-state.json` after every completed step.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import stat
import subprocess
import sys
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from claude_codex_local import bridge as pb

console = Console()

STATE_DIR = pb.STATE_DIR
STATE_FILE = STATE_DIR / "wizard-state.json"
GUIDE_PATH = Path.cwd() / "guide.md"


# ---------------------------------------------------------------------------
# WizardState — the single source of truth for wizard progress
# ---------------------------------------------------------------------------


@dataclass
class WireResult:
    argv: list[str]
    env: dict[str, str]
    effective_tag: str


@dataclass
class WizardState:
    # which steps have completed successfully
    completed_steps: list[str] = field(default_factory=list)
    # full machine profile from last discover pass
    profile: dict[str, Any] = field(default_factory=dict)
    # user's primary + secondary selections
    primary_harness: str = ""  # "claude" | "codex"
    secondary_harnesses: list[str] = field(default_factory=list)
    primary_engine: str = ""  # "ollama" | "lmstudio" | "llamacpp"
    secondary_engines: list[str] = field(default_factory=list)
    # model pick
    model_name: str = ""  # raw user input or find-model selection
    model_source: str = ""  # "direct" | "find-model"
    engine_model_tag: str = ""  # engine-specific tag (e.g. qwen3-coder:30b)
    model_candidate: dict[str, Any] = field(
        default_factory=dict
    )  # llmfit candidate metadata when available
    # launch command the wizard wired up
    launch_command: list[str] = field(default_factory=list)
    # serialized WireResult: {"argv": [...], "env": {...}, "effective_tag": "..."}
    wire_result: dict[str, Any] | None = None
    # alias install metadata
    helper_script_path: str = ""
    shell_rc_path: str = ""
    alias_names: list[str] = field(default_factory=list)
    # smoke test + verify outputs
    smoke_test_result: dict[str, Any] = field(default_factory=dict)
    verify_result: dict[str, Any] = field(default_factory=dict)

    def save(self) -> None:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(asdict(self), indent=2) + "\n")

    @classmethod
    def load(cls) -> WizardState:
        if not STATE_FILE.exists():
            return cls()
        try:
            data = json.loads(STATE_FILE.read_text())
            return cls(**data)
        except Exception:
            return cls()

    def mark(self, step: str) -> None:
        if step not in self.completed_steps:
            self.completed_steps.append(step)
        self.save()


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def header(title: str) -> None:
    console.print()
    console.print(Panel.fit(f"[bold cyan]{title}[/bold cyan]", border_style="cyan"))


def ok(msg: str) -> None:
    console.print(f"[green]✓[/green] {msg}")


def warn(msg: str) -> None:
    console.print(f"[yellow]![/yellow] {msg}")


def fail(msg: str) -> None:
    console.print(f"[red]✗[/red] {msg}")


def info(msg: str) -> None:
    console.print(f"[dim]·[/dim] {msg}")


# ---------------------------------------------------------------------------
# Step 2.1 — Discover environment
# ---------------------------------------------------------------------------


def step_2_1_discover(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.1 — Discover environment")
    profile = pb.machine_profile()
    state.profile = profile

    tools = profile["tools"]
    presence = profile["presence"]
    disk = profile.get("disk", {})

    table = Table(show_header=True, header_style="bold")
    table.add_column("Component")
    table.add_column("Status")
    table.add_column("Detail", overflow="fold")

    def row(name: str, info: dict[str, Any]) -> None:
        if info.get("present"):
            table.add_row(name, "[green]found[/green]", info.get("version", "") or "-")
        else:
            table.add_row(name, "[red]missing[/red]", info.get("error", "") or "-")

    row("claude (harness)", tools["claude"])
    row("codex (harness)", tools["codex"])
    row("ollama (engine)", tools["ollama"])
    row("lmstudio (engine)", tools["lmstudio"])
    row("llama.cpp (engine)", tools["llamacpp"])
    row("huggingface-cli (model downloader)", tools.get("huggingface_cli", {}))
    row("llmfit", tools["llmfit"])
    console.print(table)

    free_gib = disk.get("free_gib", "?")
    total_gib = disk.get("total_gib", "?")
    info(f"Free disk on state dir: {free_gib} GiB of {total_gib} GiB")

    if presence["has_minimum"]:
        ok(f"Found harnesses: {', '.join(presence['harnesses'])}")
        ok(f"Found engines: {', '.join(presence['engines'])}")
        ok("llmfit is available")
        state.mark("2.1")
        return True

    # Missing pieces — fall through to step 2.2
    if not presence["harnesses"]:
        warn("No harness found (need claude or codex)")
    if not presence["engines"]:
        warn("No engine found (need ollama, lmstudio, or llama.cpp)")
    if not presence["llmfit"]:
        warn("llmfit is not installed")
    return False


# ---------------------------------------------------------------------------
# Step 2.2 — Install missing components
# ---------------------------------------------------------------------------

INSTALL_HINTS: dict[str, dict[str, str]] = {
    "claude": {
        "name": "Claude Code CLI",
        "cmd": "npm install -g @anthropic-ai/claude-code",
        "url": "https://docs.claude.com/claude-code",
    },
    "codex": {
        "name": "Codex CLI",
        "cmd": "npm install -g @openai/codex",
        "url": "https://github.com/openai/codex",
    },
    "ollama": {
        "name": "Ollama",
        "cmd": "curl -fsSL https://ollama.com/install.sh | sh",
        "url": "https://ollama.com",
    },
    "lmstudio": {
        "name": "LM Studio",
        "cmd": "# Download from https://lmstudio.ai, then: npx lmstudio install-cli",
        "url": "https://lmstudio.ai",
    },
    "llamacpp": {
        "name": "llama.cpp",
        "cmd": "brew install llama.cpp   # or build from https://github.com/ggml-org/llama.cpp",
        "url": "https://github.com/ggml-org/llama.cpp",
    },
    "huggingface-cli": {
        "name": "Hugging Face CLI",
        "cmd": "pip install 'huggingface_hub[cli]'",
        "url": "https://huggingface.co/docs/huggingface_hub/guides/cli",
    },
    "llmfit": {
        "name": "llmfit",
        "cmd": "See docs/poc-bootstrap.md for the install script",
        "url": "https://github.com/AlexsJones/llmfit",
    },
}


def step_2_2_install_missing(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.2 — Install missing components")
    presence = state.profile.get("presence", {})

    missing: list[str] = []
    if not presence.get("harnesses"):
        missing.append("HARNESS (claude or codex)")
    if not presence.get("engines"):
        missing.append("ENGINE (ollama, lmstudio, or llamacpp)")
    if not presence.get("llmfit"):
        missing.append("llmfit")

    if not missing:
        info("Nothing missing.")
        state.mark("2.2")
        return True

    console.print(f"Missing categories: [red]{', '.join(missing)}[/red]")

    # Offer install hints for each missing category
    if not presence.get("harnesses"):
        _show_install_hint("claude")
        _show_install_hint("codex")
    if not presence.get("engines"):
        _show_install_hint("ollama")
        _show_install_hint("lmstudio")
        _show_install_hint("llamacpp")
    if not presence.get("llmfit"):
        _show_install_hint("llmfit")

    if non_interactive:
        fail("Cannot install missing components in --non-interactive mode.")
        return False

    console.print()
    proceed = questionary.confirm(
        "After installing the missing pieces in another terminal, ready to re-probe?",
        default=True,
    ).ask()
    if not proceed:
        fail("Setup cancelled by user.")
        return False

    # Re-probe
    state.profile = pb.machine_profile()
    if state.profile["presence"]["has_minimum"]:
        ok("Minimum requirements now satisfied.")
        state.mark("2.2")
        return True
    fail("Still missing required components. Install them and re-run the wizard.")
    return False


def _show_install_hint(key: str) -> None:
    hint = INSTALL_HINTS.get(key)
    if not hint:
        return
    console.print(f"\n[bold]{hint['name']}[/bold] → {hint['url']}")
    console.print(f"    [cyan]{hint['cmd']}[/cyan]")


_LLMFIT_INSTALL_SCRIPT = """\
REPO='AlexsJones/llmfit'
BINARY='llmfit'
OS=$(uname -s)
ARCH=$(uname -m)
case "$OS" in
  Linux) OS='unknown-linux-musl' ;;
  Darwin) OS='apple-darwin' ;;
  *) echo "Unsupported OS: $OS" >&2; exit 1 ;;
esac
case "$ARCH" in
  x86_64|amd64) ARCH='x86_64' ;;
  aarch64|arm64) ARCH='aarch64' ;;
  *) echo "Unsupported arch: $ARCH" >&2; exit 1 ;;
esac
PLATFORM="${ARCH}-${OS}"
TAG=$(curl -fsSI "https://github.com/${REPO}/releases/latest" | grep -i '^location:' | head -1 | sed 's|.*/tag/||' | tr -d '\\r\\n')
ASSET="${BINARY}-${TAG}-${PLATFORM}.tar.gz"
URL="https://github.com/${REPO}/releases/download/${TAG}/${ASSET}"
TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
curl -fsSL "$URL" -o "$TMPDIR/$ASSET"
if curl -fsSL --max-time 10 "${URL}.sha256" -o "$TMPDIR/${ASSET}.sha256"; then
  (cd "$TMPDIR" && sha256sum -c "${ASSET}.sha256")
fi
tar -xzf "$TMPDIR/$ASSET" -C "$TMPDIR"
install -d "$HOME/.local/bin"
install -m 0755 "$TMPDIR/$BINARY" "$HOME/.local/bin/$BINARY"
export PATH="$HOME/.local/bin:$PATH"
llmfit --version
"""


def _ensure_tool(key: str) -> bool:
    """
    Offer to install a tool by key (matching INSTALL_HINTS).
    For tools with a runnable install command (ollama, llamacpp, claude, codex,
    huggingface-cli) the command is executed directly.
    For tools requiring manual steps (lmstudio) the hint is shown and the user
    is asked to confirm when done, then the profile is re-probed.
    Returns True when the tool is detected as present after the attempt.
    """
    detect_cmd = {
        "claude": "claude",
        "codex": "codex",
        "ollama": "ollama",
        "lmstudio": "lms",
        "llamacpp": "llama-server",
    }.get(key, key)

    if pb.command_version(detect_cmd).get("present"):
        return True

    _show_install_hint(key)

    # lmstudio requires a manual GUI download — can't script it.
    if key == "lmstudio":
        proceed = questionary.confirm(
            "Install LM Studio manually (see link above), then confirm when ready to re-probe?",
            default=True,
        ).ask()
        if not proceed:
            return False
        return pb.command_version(detect_cmd).get("present", False)

    # All other tools have a runnable one-liner.
    hint = INSTALL_HINTS.get(key, {})
    cmd_str = hint.get("cmd", "")
    install = questionary.confirm(
        f"Run install command now?  [{cmd_str}]",
        default=True,
    ).ask()
    if not install:
        return False

    try:
        subprocess.run(["bash", "-c", cmd_str], check=True)
    except subprocess.CalledProcessError as exc:
        fail(f"Install failed: {exc}")
        return False

    if not pb.command_version(detect_cmd).get("present"):
        warn(
            f"{key} still not found after install. "
            "You may need to open a new terminal or add its bin directory to PATH."
        )
        return False

    ok(f"{key} installed successfully.")
    return True


def _ensure_llmfit() -> bool:
    """
    Check if llmfit is present. If not, offer to install it via the official
    bootstrap script. Returns True if llmfit is available after the check/install.
    """
    if pb.command_version("llmfit").get("present"):
        return True

    warn("llmfit is not installed.")
    _show_install_hint("llmfit")
    install = questionary.confirm(
        "Install llmfit now via the official bootstrap script?",
        default=True,
    ).ask()
    if not install:
        return False

    try:
        subprocess.run(["bash", "-c", _LLMFIT_INSTALL_SCRIPT], check=True)
    except subprocess.CalledProcessError as exc:
        fail(f"llmfit install failed: {exc}")
        return False

    # Add ~/.local/bin to PATH for this process so the re-check finds it.
    local_bin = str(Path.home() / ".local" / "bin")
    if local_bin not in os.environ.get("PATH", ""):
        os.environ["PATH"] = local_bin + os.pathsep + os.environ.get("PATH", "")

    if not pb.command_version("llmfit").get("present"):
        warn(
            "llmfit still not found after install. "
            "Ensure ~/.local/bin is on your PATH, then re-run the wizard with --resume."
        )
        return False

    ok("llmfit installed successfully.")
    return True


# ---------------------------------------------------------------------------
# Step 2.3 — Pick preferences
# ---------------------------------------------------------------------------


_ALL_HARNESSES = ["claude", "codex"]
_ALL_ENGINES = ["ollama", "lmstudio", "llamacpp"]


def step_2_3_pick_preferences(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.3 — Pick preferences")
    presence = state.profile["presence"]
    harnesses = presence["harnesses"]
    engines = presence["engines"]

    # Harness pick
    if non_interactive:
        if not harnesses:
            fail("No harness installed. Cannot continue in non-interactive mode.")
            return False
        state.primary_harness = harnesses[0]
        state.secondary_harnesses = harnesses[1:]
        ok(f"Non-interactive: picking [bold]{state.primary_harness}[/bold] as primary harness")
    else:
        # Show all known harnesses; mark uninstalled ones.
        harness_choices = [
            questionary.Choice(
                h if h in harnesses else f"{h}  [not installed]",
                value=h,
            )
            for h in _ALL_HARNESSES
        ]
        while True:
            choice = questionary.select(
                "Which harness do you want as primary?",
                choices=harness_choices,
                default=harnesses[0] if harnesses else _ALL_HARNESSES[0],
            ).ask()
            if choice is None:
                return False
            if choice not in harnesses:
                if not _ensure_tool(choice):
                    warn(
                        f"{choice} is still not available. Please pick another or install it first."
                    )
                    continue
                # Refresh presence after install.
                state.profile = pb.machine_profile()
                harnesses = state.profile["presence"]["harnesses"]
            state.primary_harness = choice
            state.secondary_harnesses = [h for h in harnesses if h != choice]
            break

    # Engine pick
    if non_interactive:
        if not engines:
            fail("No engine installed. Cannot continue in non-interactive mode.")
            return False
        default_engine = _default_engine(engines, state.profile)
        state.primary_engine = default_engine
        state.secondary_engines = [e for e in engines if e != default_engine]
        ok(f"Non-interactive: picking [bold]{state.primary_engine}[/bold] as primary engine")
    else:
        # Show all known engines; mark uninstalled ones.
        engine_choices = [
            questionary.Choice(
                e if e in engines else f"{e}  [not installed]",
                value=e,
            )
            for e in _ALL_ENGINES
        ]
        default_engine = _default_engine(engines, state.profile) if engines else _ALL_ENGINES[0]
        while True:
            choice = questionary.select(
                "Which engine do you want as primary?",
                choices=engine_choices,
                default=default_engine,
            ).ask()
            if choice is None:
                return False
            if choice not in engines:
                if not _ensure_tool(choice):
                    warn(
                        f"{choice} is still not available. Please pick another or install it first."
                    )
                    continue
                # Refresh presence after install.
                state.profile = pb.machine_profile()
                engines = state.profile["presence"]["engines"]
            state.primary_engine = choice
            state.secondary_engines = [e for e in engines if e != choice]
            break

    ok(f"Primary: [bold]{state.primary_harness}[/bold] + [bold]{state.primary_engine}[/bold]")
    if state.secondary_harnesses or state.secondary_engines:
        info(
            f"Fallbacks: harnesses={state.secondary_harnesses or '-'} engines={state.secondary_engines or '-'}"
        )
    state.mark("2.3")
    return True


def _default_engine(engines: list[str], profile: dict[str, Any]) -> str:
    """
    Pick a sensible default engine.

    Rules:
      1. Prefer an engine that already has a coding model installed *and* is
         ready to serve (ollama server running, lmstudio server running).
      2. On Apple Silicon, prefer lmstudio when it's ready.
      3. Otherwise fall back to ollama, then whatever's first.
    """
    ollama_ready = "ollama" in engines and bool(profile.get("ollama", {}).get("models"))
    lms_data = profile.get("lmstudio", {})
    lms_ready = (
        "lmstudio" in engines
        and lms_data.get("server_running", False)
        and bool(lms_data.get("models"))
    )
    is_apple_silicon = profile.get("host", {}).get("system") == "Darwin" and profile.get(
        "host", {}
    ).get("machine") in ("arm64", "aarch64")
    if is_apple_silicon and lms_ready:
        return "lmstudio"
    if ollama_ready:
        return "ollama"
    if is_apple_silicon and "lmstudio" in engines:
        return "lmstudio"
    if "ollama" in engines:
        return "ollama"
    return engines[0]


# ---------------------------------------------------------------------------
# Step 2.4 — Pick a model (user-first, optional find-model helper)
# ---------------------------------------------------------------------------


def step_2_4_pick_model(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.4 — Pick a model")
    engine = state.primary_engine

    if non_interactive:
        # Non-interactive: go straight through find-model (prefers installed models).
        candidate = _find_model_auto(engine, state.profile)
        if not candidate:
            fail("Non-interactive find-model failed and no direct model was provided.")
            return False
        state.model_name = candidate["display"]
        state.engine_model_tag = candidate["tag"]
        state.model_source = "find-model"
        state.model_candidate = candidate.get("candidate") or {}
        ok(f"Non-interactive pick: [bold]{state.engine_model_tag}[/bold]")
    else:
        while True:
            mode = questionary.select(
                "How do you want to choose the model?",
                choices=[
                    questionary.Choice("I'll type a specific model name", value="direct"),
                    questionary.Choice("Help me pick (llmfit recommendation)", value="find-model"),
                    questionary.Choice("Cancel setup", value="cancel"),
                ],
            ).ask()
            if mode is None or mode == "cancel":
                fail("Setup cancelled by user.")
                return False
            if mode == "direct":
                name = questionary.text(
                    f"Model name for engine '{engine}' (e.g. qwen3-coder:30b):",
                ).ask()
                if not name:
                    continue
                state.model_name = name.strip()
                state.engine_model_tag = _map_to_engine(name.strip(), engine) or name.strip()
                state.model_source = "direct"
            else:
                picked = _find_model_interactive(engine)
                if not picked:
                    continue
                state.model_name = picked["display"]
                state.engine_model_tag = picked["tag"]
                state.model_source = "find-model"
                state.model_candidate = picked.get("candidate") or {}

            if _handle_model_presence(state):
                break

    state.mark("2.4")
    return True


def _map_to_engine(user_input: str, engine: str) -> str | None:
    """Map a free-form user model name to the engine's naming scheme."""
    if engine == "ollama":
        # If it already looks like an ollama tag, keep it.
        if ":" in user_input and "/" not in user_input:
            return user_input
        return pb.hf_name_to_ollama_tag(user_input)
    if engine == "lmstudio":
        # LM Studio accepts hub names directly.
        if "/" in user_input:
            return user_input
        return pb.hf_name_to_lms_hub(user_input)
    return user_input


def _find_model_auto(engine: str, profile: dict[str, Any] | None = None) -> dict[str, Any] | None:
    """
    Non-interactive model pick. Prefers a model that is *already installed* for
    the chosen engine over a new download, because downloads in non-interactive
    mode are almost always unwanted.
    """
    profile = profile or pb.machine_profile()

    # 1. Already-installed model for this engine — most useful default.
    if engine == "ollama":
        installed = [
            m["name"] for m in profile.get("ollama", {}).get("models", []) if m.get("local")
        ]
        # Prefer recognisable coding models first.
        for preferred in (
            "qwen3-coder",
            "qwen2.5-coder",
            "deepseek-coder",
            "codellama",
            "gemma4",
            "qwen3.5",
        ):
            for name in installed:
                if preferred in name.lower():
                    return {
                        "display": name,
                        "tag": name,
                        "score": None,
                        "candidate": {"name": name},
                    }
        if installed:
            return {
                "display": installed[0],
                "tag": installed[0],
                "score": None,
                "candidate": {"name": installed[0]},
            }
    elif engine == "lmstudio":
        lms_models = profile.get("lmstudio", {}).get("models", [])
        for m in lms_models:
            path = m.get("path", "")
            if any(p in path.lower() for p in ("coder", "code")):
                return {"display": path, "tag": path, "score": None, "candidate": {"name": path}}
        if lms_models:
            path = lms_models[0]["path"]
            return {"display": path, "tag": path, "score": None, "candidate": {"name": path}}

    # 2. Fall back to llmfit's top candidate that maps to this engine.
    candidates = pb.llmfit_coding_candidates()
    for c in candidates:
        tag = _candidate_tag(c, engine)
        if tag:
            return {"display": c["name"], "tag": tag, "score": c.get("score"), "candidate": c}
    return None


def _find_model_interactive(engine: str) -> dict[str, Any] | None:
    if not _ensure_llmfit():
        return None
    info("Running llmfit to rank coding models for this machine...")
    candidates = pb.llmfit_coding_candidates()
    if not candidates:
        fail("llmfit returned no coding candidates.")
        return None

    choices: list[questionary.Choice] = []
    items: list[dict[str, Any]] = []
    for c in candidates[:15]:
        tag = _candidate_tag(c, engine)
        if not tag:
            continue
        label = (
            f"{c['name']:60s}  score={c.get('score'):>3}  "
            f"fit={c.get('fit_level', '?'):<12s}  ~{c.get('estimated_tps', '?')} tok/s"
        )
        items.append({"display": c["name"], "tag": tag, "score": c.get("score"), "candidate": c})
        choices.append(questionary.Choice(label, value=len(items) - 1))

    if not choices:
        fail(f"No candidates map to engine '{engine}'. Try another engine or a direct model name.")
        return None

    idx = questionary.select(
        f"Pick a model for {engine}:",
        choices=choices,
    ).ask()
    if idx is None:
        return None
    return items[idx]


def _candidate_tag(c: dict[str, Any], engine: str) -> str | None:
    if engine == "ollama":
        return c.get("ollama_tag")
    if engine == "lmstudio":
        return c.get("lms_hub_name") or c.get("lms_mlx_path")
    if engine == "llamacpp":
        # llama.cpp consumes GGUF hf references; fall back to the raw name.
        return c.get("name")
    return c.get("name")


def _handle_model_presence(state: WizardState) -> bool:
    """
    Check whether the chosen model is already on disk, and if not, handle the
    disk-aware download branches. Returns True when the step should move on.
    """
    engine = state.primary_engine
    tag = state.engine_model_tag
    if _model_already_installed(engine, tag, state.profile):
        ok(f"Model [bold]{tag}[/bold] is already installed on this machine.")
        return True

    size_bytes = _estimate_model_size(state)
    free_bytes = state.profile.get("disk", {}).get("free_bytes", 0)
    size_gib = size_bytes / (1024**3) if size_bytes else None
    free_gib = free_bytes / (1024**3) if free_bytes else 0

    if size_gib is not None:
        info(f"Estimated model size: {size_gib:.1f} GiB. Free disk: {free_gib:.1f} GiB.")
    else:
        info(f"Estimated model size: unknown. Free disk: {free_gib:.1f} GiB.")

    fits = size_gib is None or size_gib < free_gib * 0.9

    if not fits:
        warn(
            f"Model does not comfortably fit in free disk space ({size_gib:.1f} GiB needed, {free_gib:.1f} GiB free)."
        )
        cont = questionary.confirm(
            "Free up space and continue with this model?",
            default=False,
        ).ask()
        if not cont:
            return False  # re-ask

    confirm = questionary.confirm(
        f"Download '{tag}' via {engine} now?",
        default=True,
    ).ask()
    if not confirm:
        return False  # re-ask

    return _download_model(state)


def _model_already_installed(engine: str, tag: str, profile: dict[str, Any]) -> bool:
    if engine == "ollama":
        return any(m.get("name") == tag for m in profile.get("ollama", {}).get("models", []))
    if engine == "lmstudio":
        return any(m.get("path") == tag for m in profile.get("lmstudio", {}).get("models", []))
    return False  # llama.cpp: treat as not cached — user manages GGUFs manually


def _estimate_model_size(state: WizardState) -> int | None:
    """
    Best-effort byte estimate for the chosen model, via llmfit.

    Order of preference:
      1. Already-captured llmfit candidate (find-model path)
      2. `llmfit info <model_name>` lookup (direct-input path)
    Returns None when llmfit is unavailable or the lookup is ambiguous.
    """
    if state.model_candidate:
        size = pb.llmfit_estimate_size_bytes(state.model_candidate)
        if size:
            return size
    # Direct input or candidate was missing size fields — try a fresh lookup.
    if state.model_name:
        return pb.llmfit_estimate_size_bytes(state.model_name)
    return None


def _download_gguf_via_hf_cli(repo_id: str) -> dict:
    """
    Download a GGUF model from Hugging Face Hub using huggingface-cli.

    repo_id may be:
      - A bare repo like "bartowski/Qwen2.5-Coder-7B-Instruct-GGUF"
        (downloads entire repo; huggingface-cli picks the right files)
      - A repo + filename like "org/repo filename.gguf"
        (downloads the specific file)

    Returns {"ok": bool, "path": str|None}.
    """
    if not pb.huggingface_cli_detect().get("present"):
        warn("huggingface-cli is not installed.")
        _show_install_hint("huggingface-cli")
        install = questionary.confirm(
            "Install huggingface_hub[cli] now via pip?",
            default=True,
        ).ask()
        if install:
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "huggingface_hub[cli]"],
                    check=True,
                )
            except subprocess.CalledProcessError as exc:
                fail(f"pip install failed: {exc}")
                return {"ok": False, "path": None}
        if not pb.huggingface_cli_detect().get("present"):
            warn(
                "huggingface-cli still not found after install attempt.\n"
                "Re-run the wizard with --resume once it is available."
            )
            return {"ok": False, "path": None}

    # Split "repo_id filename.gguf" if the caller passed both in one string.
    parts = repo_id.split(None, 1)
    hf_repo = parts[0]
    filename = parts[1] if len(parts) > 1 else None

    console.print(f"\n[cyan]Downloading {repo_id} from Hugging Face Hub...[/cyan]")
    result = pb.huggingface_download_gguf(hf_repo, filename=filename)
    if result["ok"]:
        ok(f"Downloaded to: {result['path']}")
    else:
        fail(f"Hugging Face download failed: {result['error']}")
    return result


def _download_model(state: WizardState) -> bool:
    engine = state.primary_engine
    tag = state.engine_model_tag
    llamacpp_model_path: str | None = None
    console.print(f"\n[cyan]Downloading {tag} via {engine}...[/cyan]")
    try:
        if engine == "ollama":
            subprocess.run(["ollama", "pull", tag], check=True)
        elif engine == "lmstudio":
            lms = pb.lms_binary()
            if not lms:
                fail("lms CLI not found")
                return False
            subprocess.run([lms, "get", tag, "-y"], check=True)
        elif engine == "llamacpp":
            hf_result = _download_gguf_via_hf_cli(tag)
            if not hf_result["ok"]:
                return False
            llamacpp_model_path = hf_result.get("path")
    except subprocess.CalledProcessError as exc:
        fail(f"Download failed: {exc}")
        return False
    if engine != "llamacpp":
        ok(f"Downloaded {tag}")
    # Refresh profile so 2.5 sees the new model; preserve llamacpp_model_path
    # since machine_profile() never returns that key.
    state.profile = pb.machine_profile()
    if engine == "llamacpp" and llamacpp_model_path:
        state.profile["llamacpp_model_path"] = llamacpp_model_path
    return True


# ---------------------------------------------------------------------------
# Step 2.5 — Smoke test engine + model
# ---------------------------------------------------------------------------


def step_2_5_smoke_test(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.5 — Smoke test engine + model")
    engine = state.primary_engine
    tag = state.engine_model_tag
    info(f"Running minimal prompt through {engine} / {tag}...")

    if engine == "ollama":
        result = pb.smoke_test_ollama_model(tag)
    elif engine == "lmstudio":
        # Ensure server is up + model loaded
        if not pb.lms_info().get("server_running"):
            info("Starting LM Studio server...")
            pb.lms_start_server()
        pb.lms_load_model(tag)
        result = pb.smoke_test_lmstudio_model(tag)
    elif engine == "llamacpp":
        # llama.cpp server must be started manually by the user with the GGUF model loaded.
        llamacpp_status = pb.llamacpp_info()
        if not llamacpp_status.get("server_running"):
            model_path = state.profile.get("llamacpp_model_path", "<path/to/model.gguf>")
            warn(
                f"llama.cpp server is not running on port {llamacpp_status['server_port']}. "
                f"Start it with: llama-server --port {llamacpp_status['server_port']} "
                f"--model {model_path}"
            )
            result = {"ok": False, "error": "llama.cpp server not running"}
        else:
            result = pb.smoke_test_llamacpp_model(tag)
    else:
        warn(f"Smoke test for engine '{engine}' not implemented — skipping.")
        result = {"ok": True, "response": "(skipped)"}

    state.smoke_test_result = result
    if not result.get("ok"):
        fail(f"Smoke test failed: {result.get('error') or result.get('response')}")
        return False

    ok(f"Smoke test passed: {str(result.get('response', ''))[:80]}")

    # Report throughput (tokens/second) and let the user react if it's slow.
    if not _report_smoke_test_speed(result, non_interactive=non_interactive):
        return False

    state.mark("2.5")
    return True


def _format_tokens_per_second(tps: float) -> str:
    """Human-readable tokens/second string (e.g. '~15.3 tok/s')."""
    return f"~{tps:.1f} tok/s"


def _speed_verdict(tps: float) -> tuple[str, Callable[[str], None]]:
    """
    Classify a tokens/second value and return a label + printer function.

    Thresholds:
      - < 10 tok/s  → slow
      - 10–30 tok/s → acceptable
      - > 30 tok/s  → fast
    """
    if tps < 10:
        return ("slow — may feel sluggish for interactive use", warn)
    if tps < 30:
        return ("acceptable for most interactive coding tasks", info)
    return ("fast — should feel snappy", ok)


def _report_smoke_test_speed(result: dict[str, Any], non_interactive: bool = False) -> bool:
    """
    Display the measured throughput and offer to re-pick the model when it's slow.

    Returns True if the wizard should keep this model and continue, or False
    if the user wants to go back and pick a different model (interactive only).
    """
    tps = result.get("tokens_per_second")
    completion_tokens = result.get("completion_tokens")
    duration_seconds = result.get("duration_seconds")

    if not isinstance(tps, int | float) or tps <= 0:
        # No measurement available (e.g. Ollama CLI fallback) — do not block.
        if duration_seconds is not None:
            info(f"Inference duration: ~{float(duration_seconds):.2f}s (throughput unavailable)")
        return True

    verdict, printer = _speed_verdict(float(tps))
    detail_bits = [_format_tokens_per_second(float(tps))]
    if isinstance(completion_tokens, int) and completion_tokens > 0:
        detail_bits.append(f"{completion_tokens} tokens")
    if isinstance(duration_seconds, int | float) and duration_seconds > 0:
        detail_bits.append(f"in {float(duration_seconds):.2f}s")
    printer(f"Model speed: {' | '.join(detail_bits)} — {verdict}")
    info("Speed guide: <10 tok/s slow · 10–30 acceptable · 30+ fast")

    if float(tps) < 10:
        if non_interactive:
            warn("Speed is below 10 tok/s but continuing (non-interactive mode).")
            return True
        keep_going = questionary.confirm(
            "Model throughput is below 10 tok/s. Keep this model and continue anyway?",
            default=True,
        ).ask()
        if keep_going is False:
            info("Go back and pick a different model, then re-run the wizard.")
            return False
    return True


# ---------------------------------------------------------------------------
# Step 2.6 — Wire up harness with isolated settings
# ---------------------------------------------------------------------------


def step_2_6_wire_harness(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.6 — Wire up harness")
    harness = state.primary_harness
    engine = state.primary_engine
    tag = state.engine_model_tag

    pb.ensure_state_dirs()

    if harness == "claude":
        result = _wire_claude(engine, tag)
    elif harness == "codex":
        result = _wire_codex(engine, tag)
    else:
        fail(f"Unknown harness: {harness}")
        return False

    if result is None:
        return False

    state.wire_result = {
        "argv": result.argv,
        "env": result.env,
        "effective_tag": result.effective_tag,
    }
    state.engine_model_tag = result.effective_tag
    alias_short = "cc" if harness == "claude" else "cx"
    state.launch_command = [alias_short]
    ok(f"Harness wired. argv: [bold]{' '.join(shlex.quote(x) for x in result.argv)}[/bold]")
    state.mark("2.6")
    return True


def _model_known_incompatible_with_claude_code(tag: str) -> bool:
    t = tag.lower()
    return "qwen3" in t


def _wire_claude(engine: str, tag: str) -> WireResult | None:
    """
    Build a WireResult for the Claude harness against the chosen engine.

    For Ollama we delegate to `ollama launch claude` which sets the right env
    vars internally and execs the user's real `claude` binary against the
    user's real `~/.claude`. For LM Studio / llama.cpp we set the inline env
    explicitly because `ollama launch` does not apply.
    """
    if _model_known_incompatible_with_claude_code(tag):
        warn(
            f"Model '{tag}' is known to misbehave with Claude Code. Claude Code sends\n"
            "a `thinking` payload that Qwen3 reasoning models interpret as an\n"
            "unterminated <think> block, blowing the context budget. Recommended\n"
            "alternatives: gemma3:27b, qwen2.5-coder:32b."
        )

    if engine == "ollama":
        # Trailing "--" is important: the helper script appends "$@" after
        # this argv, and `ollama launch` would otherwise eat any user flag
        # (e.g. `cc -p "hi"` -> `ollama launch` rejects `-p`). The `--`
        # tells `ollama launch` to forward everything after it to `claude`.
        return WireResult(
            argv=["ollama", "launch", "claude", "--model", tag, "--"],
            env={},
            effective_tag=tag,
        )
    if engine == "lmstudio":
        env = {
            "ANTHROPIC_BASE_URL": f"http://localhost:{pb.LMS_SERVER_PORT}",
            "ANTHROPIC_API_KEY": "lmstudio",  # pragma: allowlist secret
            "ANTHROPIC_AUTH_TOKEN": "lmstudio",  # pragma: allowlist secret
            "ANTHROPIC_CUSTOM_MODEL_OPTION": tag,
            "ANTHROPIC_CUSTOM_MODEL_OPTION_NAME": f"Local (lmstudio) {tag}",
            "ANTHROPIC_CUSTOM_MODEL_OPTION_DESCRIPTION": (
                f"Local model served by lmstudio at http://localhost:{pb.LMS_SERVER_PORT}"
            ),
            "CLAUDE_CODE_ATTRIBUTION_HEADER": "0",
            "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
        }
        return WireResult(argv=["claude", "--model", tag], env=env, effective_tag=tag)
    if engine == "llamacpp":
        base_url = f"http://localhost:{pb.LLAMACPP_SERVER_PORT}"
        env = {
            "ANTHROPIC_BASE_URL": base_url,
            "ANTHROPIC_API_KEY": "sk-local",  # pragma: allowlist secret
            "ANTHROPIC_AUTH_TOKEN": "sk-local",  # pragma: allowlist secret
            "ANTHROPIC_CUSTOM_MODEL_OPTION": tag,
            "ANTHROPIC_CUSTOM_MODEL_OPTION_NAME": f"Local (llamacpp) {tag}",
            "ANTHROPIC_CUSTOM_MODEL_OPTION_DESCRIPTION": (
                f"Local model served by llamacpp at {base_url}"
            ),
            "CLAUDE_CODE_ATTRIBUTION_HEADER": "0",
            "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
        }
        return WireResult(argv=["claude", "--model", tag], env=env, effective_tag=tag)
    fail(f"Unknown engine for Claude wire-up: {engine}")
    return None


def _wire_codex(engine: str, tag: str) -> WireResult | None:
    if engine == "ollama":
        # Known limitation: `--oss --local-provider=ollama` are codex
        # subcommand options, not top-level options. They work in
        # interactive mode (no subcommand), which is the common case.
        # `cx exec "<prompt>"` (one-shot) will hit a ChatGPT-account
        # error because the flags land before the `exec` subcommand.
        # Workaround for one-shot use: run
        #   ollama launch codex --model <tag> -- exec --oss \
        #     --local-provider=ollama --skip-git-repo-check "<prompt>"
        # directly instead of via the alias.
        return WireResult(
            argv=[
                "ollama",
                "launch",
                "codex",
                "--model",
                tag,
                "--",
                "--oss",
                "--local-provider=ollama",
            ],
            env={},
            effective_tag=tag,
        )
    if engine == "lmstudio":
        env = {
            "OPENAI_BASE_URL": f"http://localhost:{pb.LMS_SERVER_PORT}/v1",
            "OPENAI_API_KEY": "lmstudio",  # pragma: allowlist secret
        }
        return WireResult(argv=["codex", "-m", tag], env=env, effective_tag=tag)
    if engine == "llamacpp":
        env = {
            "OPENAI_BASE_URL": f"http://localhost:{pb.LLAMACPP_SERVER_PORT}/v1",
            "OPENAI_API_KEY": "sk-local",  # pragma: allowlist secret
        }
        return WireResult(argv=["codex", "-m", tag], env=env, effective_tag=tag)
    fail(f"Unknown engine for Codex wire-up: {engine}")
    return None


# ---------------------------------------------------------------------------
# Step 2.65 — Helper script + shell aliases
# ---------------------------------------------------------------------------


# Legacy fence (pre-#16) used a single shared block for whichever harness
# was set up last. Kept for one-shot migration to the per-harness format.
_LEGACY_ALIAS_BLOCK_RE = re.compile(
    r"^# >>> claude-codex-local >>>.*?^# <<< claude-codex-local <<<\n?",
    re.DOTALL | re.MULTILINE,
)


def _harness_alias_block_re(harness: str) -> re.Pattern[str]:
    """
    Per-harness fenced block regex. Each harness owns its own block so
    installing cx does not overwrite a previously installed cc block
    (and vice versa). See issue #16.
    """
    tag = re.escape(harness)
    return re.compile(
        rf"^# >>> claude-codex-local:{tag} >>>.*?^# <<< claude-codex-local:{tag} <<<\n?",
        re.DOTALL | re.MULTILINE,
    )


def _infer_harness_from_legacy_block(block_text: str) -> str:
    """
    Guess which harness owns a legacy (pre-#16) alias block by inspecting its
    contents. Returns "claude" or "codex". Defaults to "claude" when the block
    is ambiguous — the caller is about to rewrite the block anyway, so the
    worst case is that an ambiguous legacy block is replaced with a fresh
    claude block for the current install (no data loss).
    """
    if "alias cx=" in block_text or "alias codex-local=" in block_text:
        return "codex"
    return "claude"


def _migrate_legacy_alias_block(existing: str) -> str:
    """
    If the rc file still contains a pre-#16 unified alias block, rewrap it in
    the per-harness fence so a subsequent per-harness replace/append leaves it
    alone when it belongs to a different harness. Idempotent.
    """
    match = _LEGACY_ALIAS_BLOCK_RE.search(existing)
    if not match:
        return existing
    legacy = match.group(0)
    harness = _infer_harness_from_legacy_block(legacy)
    # Rewrap: swap the top/bottom fence lines, preserve everything in between.
    migrated = legacy.replace(
        "# >>> claude-codex-local >>>",
        f"# >>> claude-codex-local:{harness} >>>",
        1,
    ).replace(
        "# <<< claude-codex-local <<<",
        f"# <<< claude-codex-local:{harness} <<<",
        1,
    )
    return existing[: match.start()] + migrated + existing[match.end() :]


def _write_helper_script(harness: str, result: WireResult) -> Path:
    """
    Write a small bash helper that exports any inline env and execs the
    wire-result argv. Returns the absolute path to the helper.
    """
    pb.ensure_state_dirs()
    name = "cc" if harness == "claude" else "cx"
    path = pb.STATE_DIR / "bin" / name

    lines = [
        "#!/usr/bin/env bash",
        "# Managed by claude-codex-local wizard. Re-run the wizard to update.",
        "set -e",
    ]
    if result.env:
        for key, value in result.env.items():
            lines.append(f"export {key}={shlex.quote(value)}")
    quoted_argv = " ".join(shlex.quote(part) for part in result.argv)
    lines.append(f'exec {quoted_argv} "$@"')
    body = "\n".join(lines) + "\n"
    path.write_text(body)
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def _alias_block(script_path: Path, harness: str) -> tuple[str, list[str]]:
    quoted_path = shlex.quote(str(script_path))
    names = ["cc", "claude-local"] if harness == "claude" else ["cx", "codex-local"]
    body_lines = [
        f"# >>> claude-codex-local:{harness} >>>",
        "# Managed by claude-codex-local wizard. Re-run the wizard to update,",
        "# or delete this block to remove the aliases.",
    ]
    for n in names:
        body_lines.append(f"alias {n}={quoted_path}")
    body_lines.append(f"# <<< claude-codex-local:{harness} <<<")
    return "\n".join(body_lines) + "\n", names


def _detect_shell_rc() -> Path | None:
    shell = os.environ.get("SHELL", "")
    home = Path.home()
    if shell.endswith("zsh") or "zsh" in shell:
        rc = home / ".zshrc"
        if not rc.exists():
            rc.touch()
        return rc
    if shell.endswith("bash") or "bash" in shell:
        rc = home / ".bashrc"
        if rc.exists():
            return rc
        bp = home / ".bash_profile"
        if bp.exists():
            return bp
        rc.touch()
        return rc
    return None


def _install_shell_aliases(
    script_path: Path, harness: str, non_interactive: bool
) -> tuple[Path | None, list[str]]:
    block, names = _alias_block(script_path, harness)
    rc_path = _detect_shell_rc()
    if rc_path is None:
        warn("Unsupported shell — please add the following to your shell rc manually:")
        console.print(block)
        return None, names

    if not non_interactive:
        proceed = questionary.confirm(f"Install aliases into {rc_path}?", default=True).ask()
        if not proceed:
            info("Skipped alias install. Add this block manually to enable the aliases:")
            console.print(block)
            return None, names

    existing = rc_path.read_text() if rc_path.exists() else ""
    # One-shot migration: rewrap any legacy unified block in its per-harness
    # fence so the replace/append logic below only touches the current
    # harness's block (fixes #16).
    existing = _migrate_legacy_alias_block(existing)
    harness_re = _harness_alias_block_re(harness)
    if harness_re.search(existing):
        new_text = harness_re.sub(block, existing, count=1)
    else:
        sep = "" if existing.endswith("\n") or not existing else "\n"
        prefix = "\n" if existing else ""
        new_text = existing + sep + prefix + block
    rc_path.write_text(new_text)
    ok(f"Installed aliases into {rc_path}: {', '.join(names)}")
    return rc_path, names


def step_2_65_install_aliases(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.65 — Install helper script + shell aliases")
    if not state.wire_result:
        fail("No wire result on state — run step 2.6 first.")
        return False
    result = WireResult(
        argv=list(state.wire_result.get("argv", [])),
        env=dict(state.wire_result.get("env", {})),
        effective_tag=state.wire_result.get("effective_tag", ""),
    )
    harness = state.primary_harness
    script_path = _write_helper_script(harness, result)
    state.helper_script_path = str(script_path)
    ok(f"Wrote helper script: [bold]{script_path}[/bold]")

    rc_path, names = _install_shell_aliases(script_path, harness, non_interactive)
    state.alias_names = names
    state.shell_rc_path = str(rc_path) if rc_path else ""
    state.mark("2.65")
    return True


# ---------------------------------------------------------------------------
# Step 2.7 — Verify launch command end-to-end
# ---------------------------------------------------------------------------


def step_2_7_verify(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.7 — Verify launch command end-to-end")
    harness = state.primary_harness
    engine = state.primary_engine
    tag = state.engine_model_tag
    if not state.wire_result:
        fail("No wire result on state — run step 2.6 first.")
        return False
    wire_env: dict[str, str] = dict(state.wire_result.get("env", {}))

    if harness == "claude":
        if engine == "ollama":
            cmd = [
                "ollama",
                "launch",
                "claude",
                "--model",
                tag,
                "--",
                "-p",
                "Reply with exactly READY",
                "--model",
                tag,
            ]
        else:
            cmd = list(state.wire_result["argv"]) + ["-p", "Reply with exactly READY"]
    elif harness == "codex":
        if engine == "ollama":
            cmd = [
                "ollama",
                "launch",
                "codex",
                "--model",
                tag,
                "--",
                "exec",
                "--skip-git-repo-check",
                "--oss",
                "--local-provider=ollama",
                "Reply with exactly READY",
            ]
        else:
            cmd = [
                "codex",
                "exec",
                "--skip-git-repo-check",
                "-m",
                tag,
                "Reply with exactly READY",
            ]
    else:
        fail(f"Unknown harness: {harness}")
        return False

    info(f"Running: {' '.join(shlex.quote(x) for x in cmd)}")
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env={**os.environ, **wire_env},
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        fail("Verify command timed out after 5 minutes.")
        return False

    output = (proc.stdout or "") + (proc.stderr or "")
    ready = "READY" in output.upper()
    state.verify_result = {
        "ok": ready,
        "returncode": proc.returncode,
        "stdout_tail": (proc.stdout or "")[-800:],
        "stderr_tail": (proc.stderr or "")[-800:],
    }
    state.save()
    if not ready:
        fail(f"Verify failed (rc={proc.returncode}). See wizard-state.json for details.")
        if proc.stderr:
            console.print(f"[dim]{proc.stderr[-400:]}[/dim]")
        if proc.stdout:
            console.print(f"[dim]{proc.stdout[-400:]}[/dim]")
        return False
    ok("End-to-end verify succeeded (got READY).")
    state.mark("2.7")
    return True


# ---------------------------------------------------------------------------
# Step 2.8 — Generate personalized guide.md
# ---------------------------------------------------------------------------

GUIDE_TEMPLATE = """\
# Local coding guide (generated)

This file was generated by `claude-codex-local` on your machine.

## What was set up

- **Harness**: `{harness}`
- **Engine**: `{engine}`
- **Model**: `{model}`
- **Aliases**: `{alias_short}`, `{alias_long}` (installed in `{shell_rc}`)
- **Helper script**: `{helper_script}`

## Daily use

> **First time after setup?** Reload your shell so the new alias is on
> your `PATH` — run `source {shell_rc}` or open a new terminal. You only
> need to do this once per shell session.

Then run:

```bash
{alias_short}
```

That's it. The alias execs `{helper_script}`, which either runs
`ollama launch {harness}` (Ollama path) or sets the right env vars and
execs `{harness}` directly (LM Studio / llama.cpp path).

Your real `~/.claude` and `~/.codex` are used as-is, so all your skills,
statusline, agents, plugins, and MCP servers keep working.

You can still pass extra args: `{alias_short} -p "what does foo.py do?"`.
{codex_limitation}
## Troubleshooting

- **`{alias_short}: command not found`?** Open a new terminal or run
  `source {shell_rc}`.
- **Engine not responding?** Re-run the wizard smoke test:
  ```bash
  claude-codex-local doctor
  ```
- **Want to switch models?** Re-run the wizard:
  ```bash
  python3 -m wizard
  ```

## Return to official mode

Your global `~/.claude` and `~/.codex` are unchanged. Run `claude` or
`codex` directly (without `{alias_short}`) to use the cloud backend.

## Rollback

Each harness (claude / codex) has its own fenced block, so you can remove
just this one without touching any other harness you may have set up.

To wipe only this harness:

1. Delete the fenced block for `{harness}` from `{shell_rc}` (between the
   `# >>> claude-codex-local:{harness} >>>` and
   `# <<< claude-codex-local:{harness} <<<` markers).
2. `rm -f {helper_script}`
3. `rm -f {guide_path}`

To wipe the local bridge entirely (both harnesses, if installed):

1. Delete every `# >>> claude-codex-local:<harness> >>>` block from
   `{shell_rc}`.
2. `rm -rf {state_dir}`
3. `rm -f {guide_path}`
"""


def step_2_8_generate_guide(state: WizardState, non_interactive: bool = False) -> bool:
    header("Step 2.8 — Generate personalized guide.md")
    alias_names = state.alias_names or (
        ["cc", "claude-local"] if state.primary_harness == "claude" else ["cx", "codex-local"]
    )
    alias_short = alias_names[0]
    alias_long = alias_names[1] if len(alias_names) > 1 else alias_names[0]
    codex_limitation = ""
    if state.primary_harness == "codex" and state.primary_engine == "ollama":
        tag = state.engine_model_tag
        codex_limitation = (
            f"\n"
            f'> **Known limitation**: `{alias_short} exec "prompt"` does not work\n'
            f"> for one-shot runs. The `--oss --local-provider=ollama` flags in the\n"
            f"> alias are top-level options and land before the `exec` subcommand,\n"
            f"> which Codex rejects with a ChatGPT-account error. Interactive\n"
            f"> `{alias_short}` works fine. For one-shot use, run directly:\n"
            f"> ```bash\n"
            f"> ollama launch codex --model {tag} -- exec --oss "
            f'--local-provider=ollama --skip-git-repo-check "<prompt>"\n'
            f"> ```\n"
        )
    content = GUIDE_TEMPLATE.format(
        harness=state.primary_harness,
        engine=state.primary_engine,
        model=state.engine_model_tag,
        alias_short=alias_short,
        alias_long=alias_long,
        shell_rc=state.shell_rc_path or "(your shell rc)",
        helper_script=state.helper_script_path or "(helper script)",
        state_dir=pb.STATE_DIR,
        guide_path=GUIDE_PATH,
        codex_limitation=codex_limitation,
    )
    GUIDE_PATH.write_text(content)
    ok(f"Wrote [bold]{GUIDE_PATH}[/bold]")
    state.mark("2.8")
    return True


# ---------------------------------------------------------------------------
# Wizard driver
# ---------------------------------------------------------------------------

STEPS: list[tuple[str, str, Callable[[WizardState, bool], bool]]] = [
    ("2.1", "Discover environment", step_2_1_discover),
    ("2.2", "Install missing components", step_2_2_install_missing),
    ("2.3", "Pick preferences", step_2_3_pick_preferences),
    ("2.4", "Pick a model", step_2_4_pick_model),
    ("2.5", "Smoke test engine + model", step_2_5_smoke_test),
    ("2.6", "Wire up harness", step_2_6_wire_harness),
    ("2.65", "Install helper script + shell aliases", step_2_65_install_aliases),
    ("2.7", "Verify launch command", step_2_7_verify),
    ("2.8", "Generate guide.md", step_2_8_generate_guide),
]


def run_wizard(
    *,
    resume: bool = False,
    non_interactive: bool = False,
    start_step: str | None = None,
    force_harness: str | None = None,
    force_engine: str | None = None,
) -> int:
    state = WizardState.load() if resume else WizardState()
    if resume and state.completed_steps:
        info(f"Resuming. Already completed: {', '.join(state.completed_steps)}")
    if force_harness:
        state.primary_harness = force_harness
    if force_engine:
        state.primary_engine = force_engine

    for step_id, title, fn in STEPS:
        if resume and step_id in state.completed_steps and step_id != start_step:
            continue
        # Honor forced harness/engine by skipping the picker.
        if step_id == "2.3" and state.primary_harness and state.primary_engine:
            ok(
                f"Using forced picks: harness=[bold]{state.primary_harness}[/bold] engine=[bold]{state.primary_engine}[/bold]"
            )
            state.mark("2.3")
            continue
        # Step 2.2 is conditional: only run if 2.1 failed presence check.
        if step_id == "2.2" and state.profile.get("presence", {}).get("has_minimum"):
            continue
        ok_step = fn(state, non_interactive)
        if not ok_step:
            fail(f"Step {step_id} ({title}) did not complete. Re-run with --resume to continue.")
            return 1

    alias_short = (
        state.alias_names[0]
        if state.alias_names
        else ("cc" if state.primary_harness == "claude" else "cx")
    )
    console.print()
    console.print(
        Panel.fit(
            f"[bold green]Setup complete![/bold green]\n\n"
            f"Reload your shell so the new alias is picked up:\n"
            f"  [cyan]source ~/.zshrc[/cyan]  (or [cyan]~/.bashrc[/cyan], or open a new terminal)\n\n"
            f"Then run: [cyan]{alias_short}[/cyan]\n\n"
            f"See [bold]{GUIDE_PATH}[/bold] for the full guide.",
            border_style="green",
        )
    )
    return 0


def run_doctor() -> int:
    """
    Read-only triage command. Prints the current wizard state and re-checks
    presence of the tools/models the wizard selected. Exit 0 when healthy,
    1 when regressions are detected.
    """
    header("doctor — wizard state + presence re-check")

    if not STATE_FILE.exists():
        warn(f"No wizard state found at {STATE_FILE}. Run `bin/claude-codex-local setup` first.")
        return 1

    state = WizardState.load()

    # --- Stored wizard state ---
    state_table = Table(title="Stored wizard state", show_header=False, box=None)
    state_table.add_column("key", style="bold")
    state_table.add_column("value")
    state_table.add_row("state file", str(STATE_FILE))
    state_table.add_row("completed steps", ", ".join(state.completed_steps) or "(none)")
    state_table.add_row("harness", state.primary_harness or "(unset)")
    state_table.add_row("engine", state.primary_engine or "(unset)")
    state_table.add_row("model (raw)", state.model_name or "(unset)")
    state_table.add_row("engine tag", state.engine_model_tag or "(unset)")
    state_table.add_row("model source", state.model_source or "(unset)")
    state_table.add_row(
        "launch command",
        " ".join(shlex.quote(x) for x in state.launch_command)
        if state.launch_command
        else "(unset)",
    )
    last_verify = state.verify_result.get("ok")
    state_table.add_row(
        "last verify",
        "[green]ok[/green]"
        if last_verify
        else ("[red]failed[/red]" if state.verify_result else "(never run)"),
    )
    console.print(state_table)
    console.print()

    # --- Live presence re-check ---
    info("Re-running machine presence check...")
    profile = pb.machine_profile()
    presence = profile.get("presence", {})

    issues: list[str] = []

    check_table = Table(title="Presence re-check", show_header=True)
    check_table.add_column("component")
    check_table.add_column("expected")
    check_table.add_column("status")

    def add_row(name: str, expected: str, ok_flag: bool, detail: str = "") -> None:
        mark = "[green]✓[/green]" if ok_flag else "[red]✗[/red]"
        check_table.add_row(name, expected, f"{mark} {detail}".strip())
        if not ok_flag:
            issues.append(f"{name}: {detail or 'missing'}")

    # Harness
    harnesses = presence.get("harnesses", []) or []
    if state.primary_harness:
        add_row(
            "harness",
            state.primary_harness,
            state.primary_harness in harnesses,
            "found"
            if state.primary_harness in harnesses
            else f"not in PATH (have: {harnesses or 'none'})",
        )

    # Engine
    engines = presence.get("engines", []) or []
    if state.primary_engine:
        add_row(
            "engine",
            state.primary_engine,
            state.primary_engine in engines,
            "found"
            if state.primary_engine in engines
            else f"not installed (have: {engines or 'none'})",
        )

    # Model presence on the engine
    if state.engine_model_tag and state.primary_engine:
        installed = _model_already_installed(state.primary_engine, state.engine_model_tag, profile)
        add_row(
            f"{state.primary_engine} model",
            state.engine_model_tag,
            installed,
            "installed" if installed else "missing — re-run wizard to re-create/pull",
        )

    # Helper script (cc / cx)
    if state.helper_script_path:
        script_path = Path(state.helper_script_path)
        add_row(
            "helper script",
            state.helper_script_path,
            script_path.exists(),
            "present" if script_path.exists() else "missing — re-run step 2.65",
        )

    # guide.md
    add_row(
        "guide.md",
        str(GUIDE_PATH),
        GUIDE_PATH.exists(),
        "present" if GUIDE_PATH.exists() else "missing — re-run step 2.8",
    )

    console.print(check_table)
    console.print()

    if issues:
        fail(f"{len(issues)} issue(s) detected:")
        for i in issues:
            console.print(f"  [red]•[/red] {i}")
        console.print()
        info("Suggested fix: `bin/claude-codex-local setup --resume`")
        return 1

    ok("All checks passed.")
    return 0


def run_find_model_standalone() -> int:
    """Exposed as `claude-codex-local find-model` — no setup, just a recommendation."""
    header("find-model — llmfit coding-model recommendation")
    profile = pb.machine_profile()
    if not profile["presence"]["llmfit"]:
        if not _ensure_llmfit():
            return 1
        # Refresh profile after successful install.
        profile = pb.machine_profile()
    engines = profile["presence"]["engines"] or ["ollama"]
    engine = engines[0]
    info(f"Ranking models for engine: {engine}")
    picked = _find_model_interactive(engine)
    if picked:
        console.print(f"\n[bold]You picked:[/bold] {picked['display']}")
        console.print(f"[bold]Engine tag:[/bold] {picked['tag']}")
        return 0
    return 1


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(prog="claude-codex-local")
    sub = parser.add_subparsers(dest="cmd")

    setup = sub.add_parser("setup", help="Run the interactive first-run wizard (default)")
    setup.add_argument("--resume", action="store_true", help="Resume from last checkpointed step")
    setup.add_argument(
        "--non-interactive", action="store_true", help="Auto-pick defaults (CI/script use)"
    )
    setup.add_argument("--harness", choices=("claude", "codex"), help="Force primary harness")
    setup.add_argument(
        "--engine", choices=("ollama", "lmstudio", "llamacpp"), help="Force primary engine"
    )

    sub.add_parser("find-model", help="Show an llmfit-driven coding model recommendation")
    sub.add_parser("doctor", help="Triage: pretty-print wizard state + re-run presence check")

    args = parser.parse_args()
    cmd = args.cmd or "setup"
    if cmd == "setup":
        return run_wizard(
            resume=getattr(args, "resume", False),
            non_interactive=getattr(args, "non_interactive", False),
            force_harness=getattr(args, "harness", None),
            force_engine=getattr(args, "engine", None),
        )
    if cmd == "find-model":
        return run_find_model_standalone()
    if cmd == "doctor":
        return run_doctor()
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
