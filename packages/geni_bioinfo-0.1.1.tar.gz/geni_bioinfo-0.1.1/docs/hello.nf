nextflow.enable.dsl = 2

process echoMessage {
  container 'ubuntu:22.04'

  input:
  val msg

  script:
  """
  echo "${msg}"
  """
}

workflow {
  echoMessage(params.message)
}
