# API Endpoints

## Summary Table

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Server health check |
| POST | `/auth/login` | Authenticate and obtain JWT token |
| POST | `/auth/refresh` | Refresh access token using refresh token |
| POST | `/auth/logout` | Revoke current session |
| POST | `/auth/activate` | Activate account and set password |
| POST | `/auth/forgot-password` | Request a password reset email |
| POST | `/auth/reset-password` | Reset password using token from email |
| POST | `/workflows` | Upload or update a workflow version |
| GET | `/workflows` | List workflows (latest version of each) |
| GET | `/workflows/:name` | Get workflow by name (`?version=` for a specific version) |
| GET | `/workflows/:name/versions` | List all versions of a workflow |
| DELETE | `/workflows/:name` | Delete a workflow and all its versions |
| DELETE | `/workflows/:name/versions/:version` | Delete a specific workflow version |
| POST | `/submissions` | Create a submission |
| GET | `/submissions` | List submissions |
| GET | `/submissions/:id` | Get submission by ID |
| PATCH | `/submissions/:id` | Update submission tags |
| GET | `/submissions/:id/tasks` | List tasks for a submission |
| POST | `/submissions/:id/cancel` | Cancel a submission |
| POST | `/submissions/:id/retry` | Retry a failed submission |
| GET | `/tasks` | List tasks for the tenant |
| GET | `/tasks/:id` | Get a single task by ID |
| POST | `/tags` | Create a tag |
| GET | `/tags` | List tags |
| PATCH | `/tags/:name` | Rename a tag |
| DELETE | `/tags/:name` | Delete a tag |
| GET | `/instances` | List EC2 instances |
| GET | `/instances/:id` | Get instance by ID |
| GET | `/submission-logs` | Get submission-level logs |
| GET | `/task-logs` | Get task logs |
| GET | `/activity-logs` | List activity logs |
| GET | `/costs/summary` | Tenant cost totals |
| GET | `/costs/submission` | Per-submission cost breakdown |
| GET | `/costs/environment` | Cost grouped by environment |
| GET | `/costs/queue` | Cost grouped by queue |
| GET | `/costs/instance-type` | Cost grouped by EC2 instance type + market type |
| GET | `/costs/engine` | Cost grouped by engine |
| GET | `/costs/execution-mode` | Cost grouped by execution mode |
| GET | `/costs/instance` | Cost per individual EC2 instance with filters |
| GET | `/costs/over-time` | Cost bucketed by time period |
| GET | `/costs/task` | Per-task cost breakdown |
| GET | `/costs/tag/:name` | Cost grouped by submission tag values |
| POST | `/costs/sync` | Trigger CUR actual-cost sync (requires `tenant:settings`) |
| POST | `/admin/environments` | Create an environment |
| GET | `/admin/environments` | List environments |
| GET | `/admin/environments/:id` | Get environment by ID |
| DELETE | `/admin/environments/:id` | Delete an environment |
| POST | `/admin/queues` | Create a queue |
| GET | `/admin/queues` | List queues |
| GET | `/admin/queues/:id` | Get queue by ID |
| DELETE | `/admin/queues/:id` | Delete a queue |
| POST | `/admin/queues/:id/update-ami` | Update AMI for an active queue |
| POST | `/admin/engines` | Create an engine |
| GET | `/admin/engines` | List engines |
| GET | `/admin/engines/:id` | Get engine by ID |
| DELETE | `/admin/engines/:id` | Delete an engine |
| POST | `/admin/storages` | Create a storage |
| GET | `/admin/storages` | List storages |
| GET | `/admin/storages/:id` | Get storage by ID |
| DELETE | `/admin/storages/:id` | Delete a storage |
| POST | `/admin/plugins` | Create a plugin |
| GET | `/admin/plugins` | List plugins |
| GET | `/admin/plugins/:id` | Get plugin by ID |
| DELETE | `/admin/plugins/:id` | Delete a plugin |
| POST | `/admin/registries` | Create an ECR registry |
| GET | `/admin/registries` | List registries |
| GET | `/admin/registries/:id` | Get registry by ID |
| DELETE | `/admin/registries/:id` | Delete a registry |
| GET | `/admin/registries/:id/auth` | Get ECR authorization credentials |
| GET | `/admin/registries/:id/images` | List images in a registry |
| GET | `/admin/registries/:id/images/:imageId` | Get image details |
| POST | `/admin/users` | Create a user |
| GET | `/admin/users` | List users (`?tenantId=` required for platform principals) |
| GET | `/admin/users/:id` | Get user by ID |
| PUT | `/admin/users/:id/role` | Set a user's RBAC role |
| DELETE | `/admin/users/:id` | Delete a user |
| POST | `/admin/api-tokens` | Create an API token |
| GET | `/admin/api-tokens` | List API tokens |
| GET | `/admin/api-tokens/:id` | Get API token by ID |
| DELETE | `/admin/api-tokens/:id` | Revoke an API token |
| POST | `/admin/api-tokens/revoke-batch` | Batch revoke API tokens |
| POST | `/support/tenants` | Create a tenant |
| GET | `/support/tenants` | List all tenants |
| GET | `/support/tenants/:id` | Get tenant by ID |
| PUT | `/support/tenants/:id/enable` | Enable a tenant |
| PUT | `/support/tenants/:id/disable` | Disable a tenant |
| DELETE | `/support/tenants/:id` | Delete a tenant |

---

## Authentication

> Two authorization schemes are supported:
> - `Authorization: Bearer <access-token>` — short-lived JWT (15 min)
> - `X-API-Key: <api-token>` — static API token (prefix `geni_`)

### Login

Rate limited to 5 requests per 15 minutes per email address.

```bash
curl -X POST http://localhost:3000/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email": "admin@acme.io", "password": "MyP@ssw0rd123"}'
```

**Response `200`**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4...",
  "expiresIn": 900
}
```

**Response `401`**
```json
{ "error": "Invalid email or password" }
```

**Response `403`**
```json
{ "error": "Account is disabled" }
```

---

### JWT Flow — Refresh Access Token

Access tokens expire after 15 minutes. Use the refresh token to obtain a new pair. The refresh token is **rotated** on every use (30-day session). Rate limited to 20 requests per 15 minutes per token.

```bash
curl -X POST http://localhost:3000/auth/refresh \
  -H 'Content-Type: application/json' \
  -d '{"refreshToken": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4..."}'
```

**Response `200`**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "bmV3UmVmcmVzaFRva2Vu...",
  "expiresIn": 900
}
```

**Response `401`**
```json
{ "error": "Invalid refresh token" }
```

---

### Logout

Revokes the current session. Requires an active JWT session (`Bearer` token only).

```bash
curl -X POST http://localhost:3000/auth/logout \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

---

### User Activation

New users are created without a password. An activation token is emailed to them. Use this endpoint to set the initial password and receive a session.

Passwords must be at least 12 characters and contain at least one uppercase letter, one lowercase letter, and one digit.

```bash
curl -X POST http://localhost:3000/auth/activate \
  -H 'Content-Type: application/json' \
  -d '{"token": "<activation-token>", "password": "MyP@ssw0rd123"}'
```

**Response `200`**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4...",
  "expiresIn": 900
}
```

**Response `400`**
```json
{ "error": "Invalid or already used activation token" }
```

**Response `403`**
```json
{ "error": "Account is disabled" }
```

---

### Reset Password — Request Email

Always returns `200` to prevent email enumeration.

```bash
curl -X POST http://localhost:3000/auth/forgot-password \
  -H 'Content-Type: application/json' \
  -d '{"email": "user@acme.io"}'
```

**Response `200`**
```json
{ "message": "If that email exists, a reset link has been sent" }
```

---

### Reset Password — Set New Password

Uses the token from the reset email. On success, all existing sessions are revoked and a new session is issued.

```bash
curl -X POST http://localhost:3000/auth/reset-password \
  -H 'Content-Type: application/json' \
  -d '{"token": "<reset-token>", "password": "MyP@ssw0rd123"}'
```

**Response `200`**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4...",
  "expiresIn": 900
}
```

**Response `400`**
```json
{ "error": "Reset token has expired" }
```

---

## Administration

### Manage Users

Requires the corresponding session permission (e.g. `users:invite` to create, `users:read` to list). API tokens cannot call these endpoints.

RBAC roles are fixed enums: `support`, `admin`, `analyst`, `viewer` (see `specs/rbac-permissions.md`).

#### Create User

New users receive an activation email (no password in the request body). Default `role` is `analyst`.

Body fields:
- `name` — required
- `email` — required
- `tenantId` — required when called by a `support` user
- `role` — optional; `support` role only for platform-level users; non-support roles require a tenant

```bash
curl -X POST http://localhost:3000/admin/users \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"name": "Analyst", "email": "analyst@acme.io"}'
```

Platform principal (`support` user): include `tenantId` for the target tenant.

```bash
curl -X POST http://localhost:3000/admin/users \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"name": "Analyst", "email": "analyst@acme.io", "tenantId": "a1b2c3d4-...", "role": "analyst"}'
```

**Response `201`** — user object including `role`, `tenantId`, `name`, `email`, etc.

#### List Users

Tenant principals: lists own tenant. Platform principals: **must** pass `?tenantId=<uuid>`.

```bash
curl 'http://localhost:3000/admin/users?tenantId=c3d4e5f6-a7b8-9012-cdef-012345678901' \
  -H 'Authorization: Bearer <access-token>'
```

#### Get User

```bash
curl http://localhost:3000/admin/users/a1b2c3d4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — user object.

#### Set User Role

`PUT /admin/users/:id/role` — requires `roles:assign`. Session auth only. Admins cannot assign the `support` role.

```bash
curl -X PUT http://localhost:3000/admin/users/a1b2c3d4-.../role \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"role": "analyst"}'
```

**Response `200`**
```json
{ "id": "a1b2c3d4-...", "role": "analyst" }
```

#### Delete User

```bash
curl -X DELETE http://localhost:3000/admin/users/a1b2c3d4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

---

### Manage API Tokens

Rate limited: 5 token creation requests per hour per principal. Session authentication only (`Bearer` token).

API tokens use a fixed `automation` role. Optional `environment_id` restricts submissions to that environment.

#### Create API Token

Body fields:
- `name` — required, max 255 characters
- `role` — required, must be the literal value `automation`
- `description` — optional, max 255 characters
- `expires_at` — optional, ISO 8601, max 1 year from now; defaults to 1 year
- `environment_id` — optional UUID; restricts submissions to that environment

```bash
curl -X POST http://localhost:3000/admin/api-tokens \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "ci-pipeline",
    "role": "automation",
    "description": "Used by CI/CD to submit workflows",
    "environment_id": "d4e5f6a7-b8c9-0123-def0-123456789012",
    "expires_at": "2027-04-09T00:00:00.000Z"
  }'
```

**Response `201`** — the `token` field is shown **only once** (header `X-Token-Warning: show-once`). `environment_id` may be `null`.

#### List API Tokens

```bash
curl http://localhost:3000/admin/api-tokens \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — array of token metadata objects (no full token value).

#### Get API Token

```bash
curl http://localhost:3000/admin/api-tokens/b1c2d3e4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — token metadata object.

#### Revoke API Token

```bash
curl -X DELETE http://localhost:3000/admin/api-tokens/b1c2d3e4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

#### Batch Revoke API Tokens

```bash
curl -X POST http://localhost:3000/admin/api-tokens/revoke-batch \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"ids": ["b1c2d3e4-...", "c2d3e4f5-..."]}'
```

**Response `204`** — no body.

---

### Manage Environments

Cloud resource groups in target AWS accounts. Create and delete operations are **asynchronous** — poll `GET /admin/environments/:id` to track `status`.

#### Create Environment

Body fields:
- `name` — required
- `cloudId` — required, 12-digit AWS account ID
- `cloudRegion` — required
- `identityToAssume` — required, IAM role ARN (`arn:aws:iam::<account-id>:role/<role-name>`); account ID must match `cloudId`
- `availabilityZones` — optional, integer 2–4, default 2

```bash
curl -X POST http://localhost:3000/admin/environments \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "production",
    "cloudId": "123456789012",
    "cloudRegion": "us-east-1",
    "identityToAssume": "arn:aws:iam::123456789012:role/GeniRole",
    "availabilityZones": 2
  }'
```

**Response `202`**
```json
{
  "id": "d4e5f6a7-b8c9-0123-def0-123456789012",
  "name": "production",
  "cloudId": "123456789012",
  "cloudRegion": "us-east-1",
  "identityToAssume": "arn:aws:iam::123456789012:role/GeniRole",
  "cloudProvider": "aws",
  "availabilityZones": 2,
  "status": "CREATING",
  "error": null,
  "stackName": null,
  "executionsBucketName": null,
  "instanceQueueUrl": null,
  "createdAt": "2026-04-09T12:00:00.000Z",
  "updatedAt": null
}
```

#### List Environments

Query params:
- `status` — optional filter
- `tenantId` — optional, only for `support` role users

```bash
curl "http://localhost:3000/admin/environments?status=ACTIVE" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "d4e5f6a7-b8c9-0123-def0-123456789012",
      "name": "production",
      "cloudId": "123456789012",
      "cloudRegion": "us-east-1",
      "identityToAssume": "arn:aws:iam::123456789012:role/GeniRole",
      "cloudProvider": "aws",
      "availabilityZones": 2,
      "status": "ACTIVE",
      "error": null,
      "stackName": "geni-env-production-acme",
      "executionsBucketName": "geni-executions-production-acme",
      "instanceQueueUrl": "https://sqs.us-east-1.amazonaws.com/123456789012/geni-queue-ec2-acme",
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": "2026-04-09T12:05:00.000Z"
    }
  ]
}
```

#### Get Environment

```bash
curl http://localhost:3000/admin/environments/d4e5f6a7-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Delete Environment

Validates that no active queues, engines, or storages exist. If there is no CloudFormation stack the delete is immediate (returns `200`); otherwise, the delete is enqueued and returns `202`.

```bash
curl -X DELETE http://localhost:3000/admin/environments/d4e5f6a7-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `202`** — environment object with `status: "DELETING"`.

---

### Manage Engines

Nextflow or Cromwell execution engines deployed in target accounts. Async operations — poll `status`.

#### Create Engine

Body fields:
- `name` — required
- `environmentId` — required, UUID
- `engine` — optional, `nextflow` or `cromwell`, default `nextflow`
- `engineVersion` — optional, string, default `25.10.4`
- `retryAttempts` — optional, integer >= 0, default 5
- `s3Buckets` — optional, array of `{bucketName, prefix?, permissionMode}`

```bash
curl -X POST http://localhost:3000/admin/engines \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "nextflow-engine-prod",
    "environmentId": "d4e5f6a7-b8c9-0123-def0-123456789012",
    "engine": "nextflow",
    "engineVersion": "25.10.4"
  }'
```

**Response `202`**
```json
{
  "id": "e5f6a7b8-c9d0-1234-ef01-234567890123",
  "name": "nextflow-engine-prod",
  "environmentId": "d4e5f6a7-b8c9-0123-def0-123456789012",
  "engine": "nextflow",
  "engineVersion": "25.10.4",
  "status": "CREATING",
  "error": null,
  "stackName": null,
  "createdAt": "2026-04-09T12:00:00.000Z",
  "updatedAt": null
}
```

#### List Engines

Query params:
- `status` — optional filter

```bash
curl "http://localhost:3000/admin/engines?status=ACTIVE" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "e5f6a7b8-c9d0-1234-ef01-234567890123",
      "name": "nextflow-engine-prod",
      "environmentId": "d4e5f6a7-...",
      "environment": { "id": "d4e5f6a7-...", "name": "prod-environment" },
      "engine": "nextflow",
      "engineVersion": "25.10.4",
      "status": "ACTIVE",
      "error": null,
      "stackName": "geni-engine-nextflow-engine-prod-acme",
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": "2026-04-09T12:04:00.000Z"
    }
  ]
}
```

#### Get Engine

```bash
curl http://localhost:3000/admin/engines/e5f6a7b8-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Delete Engine

```bash
curl -X DELETE http://localhost:3000/admin/engines/e5f6a7b8-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `202`** — engine object with `status: "DELETING"`.

---

### Manage Queues

AWS Batch compute environments and job queues in target accounts. Async operations — poll `status`.

#### Create Queue

Body fields:
- `name` — required
- `environmentId` — required, UUID
- `executionMode` — optional, `spot` or `on-demand`, default `spot`
- `instanceTypes` — optional, string array, default `['optimal']`
- `maxvCpus` — optional, integer, default 256
- `storageSizeGb` — optional, integer, default 500
- `volumeIops` — optional, integer 3000–80000
- `volumeThroughput` — optional, integer 125–2000; must not exceed `volumeIops × 0.25`
- `ebsAutoscalingEnabled` — optional, boolean, default true

```bash
curl -X POST http://localhost:3000/admin/queues \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "batch-queue-spot",
    "environmentId": "d4e5f6a7-b8c9-0123-def0-123456789012",
    "executionMode": "spot",
    "instanceTypes": ["m5.xlarge", "m5.2xlarge"],
    "maxvCpus": 256
  }'
```

**Response `202`**
```json
{
  "id": "f6a7b8c9-d0e1-2345-f012-345678901234",
  "name": "batch-queue-spot",
  "environmentId": "d4e5f6a7-...",
  "executionMode": "spot",
  "instanceTypes": ["m5.xlarge", "m5.2xlarge"],
  "maxvCpus": 256,
  "status": "CREATING",
  "error": null,
  "stackName": null,
  "createdAt": "2026-04-09T12:00:00.000Z",
  "updatedAt": null
}
```

#### List Queues

Query params:
- `status` — optional filter

```bash
curl "http://localhost:3000/admin/queues?status=ACTIVE" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "f6a7b8c9-d0e1-2345-f012-345678901234",
      "name": "batch-queue-spot",
      "environmentId": "d4e5f6a7-...",
      "environment": { "id": "d4e5f6a7-...", "name": "prod-environment" },
      "executionMode": "spot",
      "instanceTypes": ["m5.xlarge", "m5.2xlarge"],
      "maxvCpus": 256,
      "status": "ACTIVE",
      "error": null,
      "stackName": "geni-queue-batch-queue-spot-acme",
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": "2026-04-09T12:06:00.000Z"
    }
  ]
}
```

#### Get Queue

```bash
curl http://localhost:3000/admin/queues/f6a7b8c9-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Delete Queue

```bash
curl -X DELETE http://localhost:3000/admin/queues/f6a7b8c9-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `202`** — queue object with `status: "DELETING"`.

#### Update Queue AMI

Queue must be ACTIVE with an existing CloudFormation stack. Updates the AMI and optionally adjusts volume parameters.

Body fields:
- `volumeIops` — optional, integer
- `volumeThroughput` — optional, integer

```bash
curl -X POST http://localhost:3000/admin/queues/f6a7b8c9-.../update-ami \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"volumeIops": 4000, "volumeThroughput": 250}'
```

**Response `202`** — queue object.

---

### Manage Storages

S3 buckets provisioned in target accounts. Async operations — poll `status`.

#### Create Storage

Body fields:
- `name` — required
- `environmentId` — required, UUID
- `permissionMode` — optional, `read-write`, `read-only`, or `write-only`, default `read-write`

```bash
curl -X POST http://localhost:3000/admin/storages \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "results-bucket",
    "environmentId": "d4e5f6a7-b8c9-0123-def0-123456789012",
    "permissionMode": "read-write"
  }'
```

**Response `202`**
```json
{
  "id": "a7b8c9d0-e1f2-3456-0123-456789012345",
  "name": "results-bucket",
  "environmentId": "d4e5f6a7-...",
  "permissionMode": "read-write",
  "status": "CREATING",
  "bucketName": null,
  "bucketArn": null,
  "stackName": null,
  "error": null,
  "createdAt": "2026-04-09T12:00:00.000Z",
  "updatedAt": null
}
```

#### List Storages

Query params:
- `status` — optional filter
- `environmentId` — optional UUID filter

```bash
curl "http://localhost:3000/admin/storages?environmentId=d4e5f6a7-..." \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "a7b8c9d0-e1f2-3456-0123-456789012345",
      "name": "results-bucket",
      "environmentId": "d4e5f6a7-...",
      "environment": { "id": "d4e5f6a7-...", "name": "prod-environment" },
      "permissionMode": "read-write",
      "status": "ACTIVE",
      "bucketName": "geni-storage-results-bucket-acme",
      "bucketArn": "arn:aws:s3:::geni-storage-results-bucket-acme",
      "stackName": "geni-storage-results-bucket-acme",
      "error": null,
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": "2026-04-09T12:03:00.000Z"
    }
  ]
}
```

#### Get Storage

```bash
curl http://localhost:3000/admin/storages/a7b8c9d0-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Delete Storage

```bash
curl -X DELETE http://localhost:3000/admin/storages/a7b8c9d0-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `202`** — storage object with `status: "DELETING"`.

---

### Manage Plugins

Optional add-ons deployed into the client AWS account as ECS Fargate services. Currently supports `sentieon-license-server`. Async operations — poll `status`.

#### Create Plugin

Body fields:
- `name` — required
- `type` — required, `sentieon-license-server`
- `environmentId` — required, UUID
- `config` — required object:
  - `fqdn` — required, fully-qualified domain name bound to the license
  - `desiredCount` — optional, integer >= 1, default 1
  - `licenseFileBase64` — required, base64-encoded Sentieon license file

```bash
curl -X POST http://localhost:3000/admin/plugins \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "sentieon-prod",
    "type": "sentieon-license-server",
    "environmentId": "d4e5f6a7-b8c9-0123-def0-123456789012",
    "config": {
      "fqdn": "licsrvr.sentieon.example.com",
      "desiredCount": 1,
      "licenseFileBase64": "<base64-encoded-license-file>"
    }
  }'
```

**Response `202`** — plugin object with `status: "PENDING"`.

#### List Plugins

Query params:
- `status` — optional filter
- `type` — optional filter

```bash
curl "http://localhost:3000/admin/plugins?status=ACTIVE&type=sentieon-license-server" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "shortId": "a1b2c3d4",
      "name": "sentieon-prod",
      "type": "sentieon-license-server",
      "environmentId": "d4e5f6a7-...",
      "environment": { "id": "d4e5f6a7-...", "name": "prod-environment" },
      "config": { "fqdn": "licsrvr.sentieon.example.com", "desiredCount": 1 },
      "status": "ACTIVE",
      "stackName": "geni-plugin-sentieon-prod-a1b2c3d4",
      "clusterArn": "arn:aws:ecs:us-east-1:123456789012:cluster/...",
      "serviceArn": "arn:aws:ecs:us-east-1:123456789012:service/...",
      "loadBalancerDns": "internal-nlb-xxx.elb.us-east-1.amazonaws.com",
      "error": null,
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": "2026-04-09T12:10:00.000Z"
    }
  ]
}
```

#### Get Plugin

```bash
curl http://localhost:3000/admin/plugins/a1b2c3d4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Delete Plugin

```bash
curl -X DELETE http://localhost:3000/admin/plugins/a1b2c3d4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `202`** — plugin object with `status: "DELETING"`.

---

### Manage Images

ECR container registries and image tracking in target accounts.

#### Create Registry

Body fields:
- `name` — required
- `imageTagMutability` — optional, `MUTABLE` or `IMMUTABLE`, default `IMMUTABLE`

```bash
curl -X POST http://localhost:3000/admin/registries \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"name": "bioinfo-tools", "imageTagMutability": "IMMUTABLE"}'
```

**Response `201`**
```json
{
  "id": "b8c9d0e1-f2a3-4567-1234-567890123456",
  "tenantId": "c3d4e5f6-...",
  "name": "bioinfo-tools",
  "imageTagMutability": "IMMUTABLE",
  "status": "ACTIVE",
  "repositoryUri": "123456789012.dkr.ecr.us-east-1.amazonaws.com/acme/bioinfo-tools",
  "repositoryArn": "arn:aws:ecr:us-east-1:123456789012:repository/acme/bioinfo-tools",
  "error": null,
  "createdAt": "2026-04-09T12:00:00.000Z",
  "updatedAt": null
}
```

#### List Registries

Query params:
- `status` — optional filter

```bash
curl http://localhost:3000/admin/registries \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "b8c9d0e1-f2a3-4567-1234-567890123456",
      "tenantId": "c3d4e5f6-...",
      "name": "bioinfo-tools",
      "imageTagMutability": "IMMUTABLE",
      "status": "ACTIVE",
      "repositoryUri": "123456789012.dkr.ecr.us-east-1.amazonaws.com/acme/bioinfo-tools",
      "repositoryArn": "arn:aws:ecr:us-east-1:123456789012:repository/acme/bioinfo-tools",
      "error": null,
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": null
    }
  ]
}
```

#### Get Registry

```bash
curl http://localhost:3000/admin/registries/b8c9d0e1-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Delete Registry

```bash
curl -X DELETE http://localhost:3000/admin/registries/b8c9d0e1-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — registry object with `status: "DELETED"`.

#### Get ECR Push Credentials

Requires `cloud-resources:create` permission. Credentials expire in approximately 12 hours.

```bash
curl http://localhost:3000/admin/registries/b8c9d0e1-.../auth \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "proxyEndpoint": "https://123456789012.dkr.ecr.us-east-1.amazonaws.com",
  "username": "AWS",
  "password": "eyJwYXlsb2FkIjoiQ...",
  "expiresAt": "2026-04-10T00:00:00.000Z"
}
```

#### List Images in Registry

```bash
curl http://localhost:3000/admin/registries/b8c9d0e1-.../images \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "c9d0e1f2-a3b4-5678-2345-678901234567",
      "registryId": "b8c9d0e1-...",
      "tag": "1.0.0",
      "digest": "sha256:abc123...",
      "sizeBytes": "123456789",
      "status": "ACTIVE",
      "rejectionReason": null,
      "pushedAt": "2026-04-09T10:00:00.000Z",
      "createdAt": "2026-04-09T10:00:00.000Z",
      "updatedAt": null,
      "imageUri": "123456789012.dkr.ecr.us-east-1.amazonaws.com/acme/bioinfo-tools:1.0.0"
    }
  ]
}
```

#### Get Image Details

```bash
curl http://localhost:3000/admin/registries/b8c9d0e1-.../images/c9d0e1f2-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

---

## Operation

### Manage Workflows

#### Register Workflow

Upload a Nextflow `.nf` script or a `.zip` archive. This operation upserts the workflow and version. Field constraints:
- `name` — 1–64 characters, alphanumeric, hyphens, or underscores (`[a-zA-Z0-9_-]`)
- `version` — 1–32 characters, alphanumeric, dots, hyphens, or underscores (`[a-zA-Z0-9._-]`)
- `engine` — optional, `nextflow` or `cromwell`, default `nextflow`
- `fileType` — required, `TEXT` or `ZIP`
- `alertTimeSeconds` — optional integer
- `cancelTimeSeconds` — optional integer
- `file` — required binary upload

```bash
curl -X POST http://localhost:3000/workflows \
  -H 'Authorization: Bearer <access-token>' \
  -F 'name=variant-calling' \
  -F 'version=v1.2.0' \
  -F 'engine=nextflow' \
  -F 'fileType=TEXT' \
  -F 'alertTimeSeconds=3600' \
  -F 'cancelTimeSeconds=7200' \
  -F 'file=@pipeline.nf'
```

**Response `201`**
```json
{
  "name": "variant-calling",
  "version": "v1.2.0",
  "fileType": "TEXT",
  "latest": true,
  "engine": "nextflow",
  "alertTimeSeconds": 3600,
  "cancelTimeSeconds": 7200,
  "createdAt": "2026-04-09T12:00:00.000Z"
}
```

#### List Workflows

Returns the latest version of each workflow.

```bash
curl http://localhost:3000/workflows \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "name": "variant-calling",
      "version": "v1.2.0",
      "fileType": "TEXT",
      "latest": true,
      "engine": "nextflow",
      "alertTimeSeconds": 3600,
      "cancelTimeSeconds": 7200,
      "createdAt": "2026-04-09T12:00:00.000Z"
    }
  ]
}
```

#### Get Workflow

Query params:
- `version` — optional; returns latest if omitted

```bash
# Latest version
curl http://localhost:3000/workflows/variant-calling \
  -H 'Authorization: Bearer <access-token>'

# Specific version
curl "http://localhost:3000/workflows/variant-calling?version=v1.1.0" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### List Workflow Versions

```bash
curl http://localhost:3000/workflows/variant-calling/versions \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    { "version": "v1.2.0", "fileType": "TEXT", "latest": true, "createdAt": "2026-04-09T12:00:00.000Z" },
    { "version": "v1.1.0", "fileType": "TEXT", "latest": false, "createdAt": "2026-03-01T10:00:00.000Z" }
  ]
}
```

#### Delete Workflow

Deletes the workflow and all its versions. Also removes the files from S3.

```bash
curl -X DELETE http://localhost:3000/workflows/variant-calling \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

#### Delete Workflow Version

Deletes a single version. If it was the `latest`, the next most-recent version is promoted. If no versions remain, the workflow record is also deleted.

```bash
curl -X DELETE http://localhost:3000/workflows/variant-calling/versions/v1.1.0 \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

---

### Manage Submissions

#### Submit Workflow

Upload a parameters file (`.json`, `.yaml`, or `.yml`) together with the run configuration. Multipart form fields:
- `workflowName` — required
- `workflowVersion` — optional; uses latest if omitted
- `engineId` — required UUID
- `queueId` — required UUID
- `output` — required, must start with `s3://`
- `alertTimeSeconds` — optional integer
- `cancelTimeSeconds` — optional integer
- `tag` — optional, repeatable, format `key=value`; tags must be pre-registered
- `params` — required file upload (`.json`, `.yaml`, or `.yml`)

When using an environment-scoped API token, the engine must belong to that token's environment.

```bash
curl -X POST http://localhost:3000/submissions \
  -H 'Authorization: Bearer <access-token>' \
  -F 'workflowName=variant-calling' \
  -F 'workflowVersion=v1.2.0' \
  -F 'engineId=e5f6a7b8-c9d0-1234-ef01-234567890123' \
  -F 'queueId=f6a7b8c9-d0e1-2345-f012-345678901234' \
  -F 'output=s3://geni-executions-production-acme/outputs/run-001' \
  -F 'alertTimeSeconds=3600' \
  -F 'cancelTimeSeconds=7200' \
  -F 'tag=project=alpha' \
  -F 'params=@params.json'
```

**Response `202`**
```json
{
  "submissionId": "d0e1f2a3-b4c5-6789-3456-789012345678",
  "jobId": "abc12345-1234-1234-1234-abcdef012345",
  "status": "SUBMITTED",
  "workflowName": "variant-calling",
  "workflowVersion": "v1.2.0",
  "engineId": "e5f6a7b8-...",
  "queueId": "f6a7b8c9-...",
  "environmentId": "d4e5f6a7-...",
  "output": "s3://geni-executions-production-acme/outputs/run-001",
  "alertTimeSeconds": 3600,
  "cancelTimeSeconds": 7200
}
```

#### List Submissions

Query params:
- `status` — optional, case-insensitive
- `tag` — optional, one or many `key=value`
- `limit` — optional, integer 1–1000
- `sort` — optional, `started`, `stopped`, or `updated`, default `updated`
- `sortOrder` — optional, `asc` or `desc`, default `desc`

Environment-scoped API tokens automatically filter to that token's environment.

```bash
curl "http://localhost:3000/submissions?status=RUNNING" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "submissionId": "d0e1f2a3-b4c5-6789-3456-789012345678",
      "jobId": "abc12345-1234-1234-1234-abcdef012345",
      "jobName": "geni-variant-calling-20260409",
      "status": "RUNNING",
      "statusReason": null,
      "workflowVersionId": "e1f2a3b4-...",
      "workflowName": "variant-calling",
      "workflowVersion": "v1.2.0",
      "nfWorkDir": "s3://geni-executions-production-acme/work/d0e1f2a3",
      "output": "s3://geni-executions-production-acme/outputs/run-001",
      "engineId": "e5f6a7b8-...",
      "engine": { "id": "e5f6a7b8-...", "name": "prod-engine" },
      "queueId": "f6a7b8c9-...",
      "queue": { "id": "f6a7b8c9-...", "name": "prod-queue" },
      "environmentId": "d4e5f6a7-...",
      "alertTimeSeconds": 3600,
      "cancelTimeSeconds": 7200,
      "alertSentAt": null,
      "cancelSentAt": null,
      "startedAt": "2026-04-09T12:01:00.000Z",
      "stoppedAt": null,
      "durationMs": 60000,
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": "2026-04-09T12:01:00.000Z"
    }
  ]
}
```

#### Get Submission

```bash
curl http://localhost:3000/submissions/d0e1f2a3-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item. Returns `404` if not found or outside the token's environment scope.

#### Update Submission Tags

Requires `submissions:create`. All tags in the body must be pre-registered.

Body fields (all optional):
- `addTags` — array of `{key, value}` to add
- `editTags` — array of `{key, value}` to update existing tag values
- `removeTags` — array of tag key strings to remove

```bash
curl -X PATCH http://localhost:3000/submissions/d0e1f2a3-... \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{
    "addTags": [{"key": "project", "value": "beta"}],
    "removeTags": ["team"]
  }'
```

**Response `204`** — no body.

#### Cancel Submission

Submission must be in `SUBMITTED` or `RUNNING` status.

```bash
curl -X POST http://localhost:3000/submissions/d0e1f2a3-.../cancel \
  -H 'Authorization: Bearer <access-token>'
```

**Response `202`**
```json
{
  "submissionId": "d0e1f2a3-b4c5-6789-3456-789012345678",
  "message": "Cancel request accepted"
}
```

**Response `409`** — if the submission is not in a cancellable state.

#### Retry Submission

Submission must be in `FAILED` status. If `engineId` or `queueId` are omitted the originals are reused.

Body fields (all optional):
- `engineId` — UUID of the engine to use
- `queueId` — UUID of the queue to use

```bash
curl -X POST http://localhost:3000/submissions/d0e1f2a3-.../retry \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{}'
```

**Response `202`**
```json
{
  "submissionId": "d0e1f2a3-b4c5-6789-3456-789012345678",
  "message": "Retry request accepted"
}
```

---

### List Tasks

#### List Tasks for a Submission

```bash
curl http://localhost:3000/submissions/d0e1f2a3-.../tasks \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — `{items: [...tasks]}`.

#### List All Tasks

Query params:
- `submissionId` — optional UUID filter
- `status` — optional, case-insensitive
- `limit` — optional, integer 1–1000
- `sort` — optional, `started`, `stopped`, or `updated`, default `updated`
- `sortOrder` — optional, `asc` or `desc`, default `desc`

```bash
curl "http://localhost:3000/tasks?status=FAILED" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "e1f2a3b4-c5d6-7890-4567-890123456789",
      "submissionId": "d0e1f2a3-...",
      "jobId": "def67890-5678-5678-5678-defabc012345",
      "jobName": "VARIANT_CALLING:BWA_MEM (sample1)",
      "status": "SUCCEEDED",
      "statusReason": null,
      "exitCode": 0,
      "vcpus": 4,
      "memory": 8192,
      "containerInstanceArn": "arn:aws:ecs:us-east-1:123456789012:container-instance/...",
      "instanceId": "f2a3b4c5-...",
      "instance": { "id": "f2a3b4c5-...", "instanceType": "m5.xlarge" },
      "createdAt": "2026-04-09T12:01:00.000Z",
      "startedAt": "2026-04-09T12:02:00.000Z",
      "stoppedAt": "2026-04-09T12:15:00.000Z",
      "durationMs": 780000,
      "runnableDurationMs": 60000,
      "executionDurationMs": 720000,
      "updatedAt": "2026-04-09T12:15:00.000Z"
    }
  ]
}
```

#### Get Task

```bash
curl http://localhost:3000/tasks/e1f2a3b4-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as task list item.

---

### Manage Tags

Tags must be registered before they can be applied to submissions.

#### Create Tag

Body fields:
- `name` — required, 1–63 characters, must start with alphanumeric, allows `.`, `_`, `-`

```bash
curl -X POST http://localhost:3000/tags \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"name": "project"}'
```

**Response `201`**
```json
{
  "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "name": "project",
  "createdAt": "2026-04-09T12:00:00.000Z"
}
```

**Response `409`** — duplicate tag name.

#### List Tags

```bash
curl http://localhost:3000/tags \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    { "id": "a1b2c3d4-...", "name": "project", "createdAt": "2026-04-09T12:00:00.000Z" },
    { "id": "b2c3d4e5-...", "name": "team", "createdAt": "2026-04-09T12:00:00.000Z" }
  ]
}
```

#### Rename Tag

Path param is the current tag name. Body contains the new name.

```bash
curl -X PATCH http://localhost:3000/tags/project \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"name": "project-name"}'
```

**Response `200`** — updated tag object.

#### Delete Tag

```bash
curl -X DELETE http://localhost:3000/tags/project \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

---

### List Instances

EC2 instances launched by Batch workers, including cost data.

Query params:
- `status` — optional filter
- `environmentId` — optional UUID filter
- `queueId` — optional UUID filter
- `submissionId` — optional UUID filter
- `limit` — optional, integer 1–1000

```bash
# All instances for a submission
curl "http://localhost:3000/instances?submissionId=d0e1f2a3-..." \
  -H 'Authorization: Bearer <access-token>'

# All running instances in an environment
curl "http://localhost:3000/instances?status=RUNNING&environmentId=d4e5f6a7-..." \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "f2a3b4c5-d6e7-8901-5678-901234567890",
      "ec2InstanceId": "i-0abc123def456789",
      "instanceType": "m5.xlarge",
      "marketType": "spot",
      "status": "COST_CALCULATED",
      "environmentId": "d4e5f6a7-...",
      "queueId": "f6a7b8c9-...",
      "launchTime": "2026-04-09T12:02:00.000Z",
      "terminationTime": "2026-04-09T12:20:00.000Z",
      "durationSeconds": 1080,
      "cost": {
        "pricePerHour": 0.0518,
        "ec2Cost": 0.0155,
        "volumeCost": 0.0006,
        "totalCost": 0.0161,
        "estimated": true,
        "syncedAt": null
      },
      "volumes": [
        {
          "id": "v-uuid",
          "volumeId": "vol-0abc123",
          "sizeGb": 30,
          "volumeType": "gp3",
          "iops": 3000,
          "throughput": 125,
          "cost": null
        }
      ],
      "error": null,
      "createdAt": "2026-04-09T12:02:00.000Z",
      "updatedAt": "2026-04-09T12:25:00.000Z"
    }
  ]
}
```

#### Get Instance Detail

Includes linked `volumes` and `tasks` arrays.

```bash
curl http://localhost:3000/instances/f2a3b4c5-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — instance object with `volumes` array and an added `tasks` array (same task shape as above).

---

### Costs

Requires `analytics:read` permission (roles: `admin`, `analyst`, `viewer`, `support`). API tokens (`automation` role) do not have access. All GET endpoints return `503` if the analytics service (DuckDB) is temporarily unavailable.

Common optional query parameters shared by most GET /costs/* endpoints: `from` (ISO 8601), `to` (ISO 8601), `submissionStatus`.

#### Summary

```bash
curl "http://localhost:3000/costs/summary?from=2026-01-01T00:00:00Z&to=2026-02-01T00:00:00Z" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "totalInstanceCost": 138.20,
  "totalEbsCost": 5.90,
  "totalEcsCost": 2.40,
  "totalCost": 146.50,
  "fullyEstimated": false,
  "anyEstimated": false,
  "instanceCount": 87,
  "submissionCount": 12
}
```

`anyEstimated: true` means at least one instance's cost is still estimated (pre-CUR sync). `fullyEstimated: true` means all instances are still estimated.

#### By Submission

Query params: `from`, `to`, `submissionStatus`, `limit` (1–200, default 50), `offset` (default 0), `id` (optional, one or many submission UUIDs).

```bash
curl "http://localhost:3000/costs/submission?limit=10&offset=0" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "submissionId": "d0e1f2a3-b4c5-6789-3456-789012345678",
      "submissionStatus": "SUCCEEDED",
      "taskCost": 18.50,
      "ecsCost": 0.48,
      "totalCost": 18.98,
      "syncedAt": "2026-01-02T10:00:00.000Z"
    }
  ]
}
```

#### By Environment

Query params: `from`, `to`, `submissionStatus`.

```bash
curl "http://localhost:3000/costs/environment" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "environmentId": "d4e5f6a7-b8c9-0123-def0-123456789012",
      "environmentName": "production",
      "instanceCost": 116.40,
      "ebsCost": 5.00,
      "ecsCost": 1.90,
      "totalCost": 123.30,
      "fullyEstimated": false,
      "anyEstimated": false,
      "instanceCount": 74
    }
  ]
}
```

#### By Queue

Query params: `from`, `to`, `submissionStatus`.

```bash
curl "http://localhost:3000/costs/queue" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "queueId": "f6a7b8c9-d0e1-2345-f012-345678901234",
      "queueName": "batch-queue-spot",
      "instanceCost": 95.20,
      "ebsCost": 3.90,
      "ecsCost": 1.40,
      "totalCost": 100.50,
      "fullyEstimated": false,
      "anyEstimated": false,
      "instanceCount": 60
    }
  ]
}
```

#### By Instance Type

Query params: `from`, `to`, `submissionStatus`.

```bash
curl "http://localhost:3000/costs/instance-type" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "instanceType": "r6i.4xlarge",
      "marketType": "spot",
      "instanceCost": 72.80,
      "ebsCost": 3.00,
      "totalCost": 75.80,
      "fullyEstimated": false,
      "anyEstimated": false,
      "instanceCount": 42
    }
  ]
}
```

#### By Engine

Query params: `from`, `to`, `submissionStatus`.

```bash
curl "http://localhost:3000/costs/engine" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "engineId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "engineName": "nextflow-prod",
      "instanceCost": 106.90,
      "ebsCost": 4.60,
      "ecsCost": 2.00,
      "totalCost": 113.50,
      "fullyEstimated": false,
      "anyEstimated": false,
      "instanceCount": 65
    }
  ]
}
```

#### By Execution Mode

Query params: `from`, `to`, `submissionStatus`.

```bash
curl "http://localhost:3000/costs/execution-mode" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "executionMode": "spot",
      "instanceCost": 92.00,
      "ebsCost": 3.90,
      "ecsCost": 1.70,
      "totalCost": 97.60,
      "fullyEstimated": false,
      "anyEstimated": false,
      "instanceCount": 58
    }
  ]
}
```

#### Over Time

Query params: `from`, `to`, `submissionStatus`, `interval` (required, `day`, `week`, or `month`, default `day`).

```bash
curl "http://localhost:3000/costs/over-time?interval=month&from=2026-01-01T00:00:00Z" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "interval": "month",
  "items": [
    {
      "period": "2026-01-01T00:00:00.000Z",
      "instanceCost": 138.20,
      "ebsCost": 5.90,
      "ecsCost": 2.40,
      "totalCost": 146.50,
      "fullyEstimated": false,
      "anyEstimated": false,
      "instanceCount": 87
    }
  ]
}
```

#### By Instance

Per-row cost data for each EC2 instance. Does not accept `from`/`to`/`submissionStatus` from the common set. Supports: `from`, `to`, `submissionStatus`, `environmentId`, `engineId`, `queueId`, `instanceType`, `executionMode` (`spot` or `on-demand`), `limit` (1–200, default 50), `offset` (default 0).

```bash
curl "http://localhost:3000/costs/instance?environmentId=d4e5f6a7-...&executionMode=spot" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "instanceId": "f2a3b4c5-d6e7-8901-5678-901234567890",
      "instanceType": "m5.xlarge",
      "marketType": "spot",
      "environmentId": "d4e5f6a7-...",
      "environmentName": "production",
      "queueId": "f6a7b8c9-...",
      "queueName": "batch-queue-spot",
      "instanceCost": 0.0155,
      "ebsCost": 0.0006,
      "totalCost": 0.0161,
      "estimated": false,
      "syncedAt": "2026-01-02T10:00:00.000Z",
      "terminationTime": "2026-04-09T12:20:00.000Z"
    }
  ]
}
```

#### By Task

Per-task cost data from the `task_costs` table (populated by CUR sync). Does not accept `from`/`to`/`submissionStatus`. Params: `submissionId` (optional UUID), `id` (optional, one or many task UUIDs), `limit` (1–200, default 50), `offset` (default 0).

```bash
curl "http://localhost:3000/costs/task?submissionId=d0e1f2a3-..." \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "taskId": "e1f2a3b4-c5d6-7890-4567-890123456789",
      "jobName": "VARIANT_CALLING:BWA_MEM (sample1)",
      "submissionId": "d0e1f2a3-...",
      "status": "SUCCEEDED",
      "vcpus": 4,
      "durationMs": 780000,
      "cost": 0.0043,
      "syncedAt": "2026-01-02T10:00:00.000Z"
    }
  ]
}
```

#### By Tag

Cost breakdown grouped by the values of a submission tag. Accepts only `from` and `to` (no `submissionStatus`). Path param `name` is case-insensitive.

```bash
curl "http://localhost:3000/costs/tag/project?from=2026-01-01T00:00:00Z" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "tagName": "project",
  "items": [
    { "tagValue": "alpha", "submissionCount": 5, "totalCost": 42.10 },
    { "tagValue": "beta",  "submissionCount": 3, "totalCost": 18.50 }
  ]
}
```

#### Trigger CUR Sync

Requires `tenant:settings` permission. Enqueues an immediate CUR actual-cost sync job and returns the BullMQ job ID. Pass `"reset": true` to clear all existing cost data before syncing.

```bash
curl -X POST "http://localhost:3000/costs/sync" \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"reset": false}'
```

**Response `202`**
```json
{ "jobId": "42" }
```

---

### List Submission and Task Logs

#### Submission Logs

Query params:
- `submissionId` — required UUID
- `limit` — optional, integer 1–1000; returns last N lines when provided
- `since` — optional, ISO 8601; returns entries after this timestamp

```bash
curl "http://localhost:3000/submission-logs?submissionId=d0e1f2a3-..." \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "a3b4c5d6-e7f8-9012-6789-012345678901",
      "submissionId": "d0e1f2a3-...",
      "timestamp": "2026-04-09T12:01:30.000Z",
      "message": "Nextflow pipeline started",
      "createdAt": "2026-04-09T12:01:30.000Z"
    }
  ]
}
```

#### Task Logs

At least one of `submissionId` or `taskId` is required.

Query params:
- `submissionId` — optional UUID
- `taskId` — optional UUID
- `limit` — optional, integer 1–1000
- `since` — optional, ISO 8601

```bash
# All task logs for a submission
curl "http://localhost:3000/task-logs?submissionId=d0e1f2a3-..." \
  -H 'Authorization: Bearer <access-token>'

# Logs for a specific task
curl "http://localhost:3000/task-logs?submissionId=d0e1f2a3-...&taskId=e1f2a3b4-..." \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "b4c5d6e7-f8a9-0123-7890-123456789012",
      "taskId": "e1f2a3b4-...",
      "jobName": "VARIANT_CALLING:BWA_MEM (sample1)",
      "timestamp": "2026-04-09T12:02:00.000Z",
      "message": "[Task/1] Submitted process > VARIANT_CALLING:BWA_MEM (sample1)",
      "createdAt": "2026-04-09T12:02:00.000Z"
    }
  ]
}
```

> `jobName` is included when fetching all task logs for a submission; omitted when filtering by `taskId`.

#### Activity Logs

Requires `users:read`. Tenant-scoped users see only their own tenant's activity.

Query params:
- `action` — optional filter
- `entityType` — optional filter
- `entityId` — optional filter
- `principalId` — optional UUID filter
- `limit` — optional, integer 1–1000

```bash
curl "http://localhost:3000/activity-logs?entityType=Submission" \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "c5d6e7f8-a9b0-1234-8901-234567890123",
      "principalId": "a1b2c3d4-...",
      "principal": {
        "id": "a1b2c3d4-...",
        "type": "USER",
        "user": { "email": "admin@acme.io" }
      },
      "action": "CREATE",
      "entityType": "Submission",
      "entityId": "d0e1f2a3-...",
      "details": null,
      "createdAt": "2026-04-09T12:00:00.000Z"
    }
  ]
}
```

---

## Support

Endpoints for system-level administration. Require the `support` role (`tenant:settings` and related permissions).

### Manage Tenants

Tenant creation requires a display `name` and a `contactEmail`. The backend derives a stable, cloud-safe `slug` from the name used for tenant-scoped S3 prefixes, ECR repository prefixes, and similar cloud resource identifiers.

#### Create Tenant

```bash
curl -X POST http://localhost:3000/support/tenants \
  -H 'Authorization: Bearer <access-token>' \
  -H 'Content-Type: application/json' \
  -d '{"name": "Acme Corp", "contactEmail": "admin@acme.io"}'
```

**Response `201`**
```json
{
  "id": "c3d4e5f6-a7b8-9012-cdef-012345678901",
  "name": "Acme Corp",
  "slug": "acme-corp",
  "contactEmail": "admin@acme.io",
  "status": "ACTIVE",
  "createdAt": "2026-04-09T12:00:00.000Z",
  "updatedAt": null
}
```

#### List Tenants

```bash
curl http://localhost:3000/support/tenants \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`**
```json
{
  "items": [
    {
      "id": "c3d4e5f6-a7b8-9012-cdef-012345678901",
      "name": "Acme Corp",
      "slug": "acme-corp",
      "contactEmail": "admin@acme.io",
      "status": "ACTIVE",
      "createdAt": "2026-04-09T12:00:00.000Z",
      "updatedAt": null
    }
  ]
}
```

#### Get Tenant

```bash
curl http://localhost:3000/support/tenants/c3d4e5f6-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — same shape as list item.

#### Enable Tenant

```bash
curl -X PUT http://localhost:3000/support/tenants/c3d4e5f6-.../enable \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — tenant object with `status: "ACTIVE"`.

#### Disable Tenant

```bash
curl -X PUT http://localhost:3000/support/tenants/c3d4e5f6-.../disable \
  -H 'Authorization: Bearer <access-token>'
```

**Response `200`** — tenant object with `status: "DISABLED"`.

#### Delete Tenant

Only allowed if no environments or workflows exist for the tenant.

```bash
curl -X DELETE http://localhost:3000/support/tenants/c3d4e5f6-... \
  -H 'Authorization: Bearer <access-token>'
```

**Response `204`** — no body.

**Response `409`** — if environments or workflows still exist.

---

## Authorization Model

Human users have one of four roles stored on the principal (`support`, `admin`, `analyst`, `viewer`). Effective permissions come from a static matrix in `backend/src/permissions.ts`.

API tokens are not role-based: they receive the fixed `automation` role with a set of workflow and submission permissions. Optional `environment_id` on the token restricts submissions to that environment. API tokens use the `X-API-Key` header and cannot access session-only admin routes (users, API token management, etc.).

See `specs/rbac-permissions.md` for the full permission matrix.
