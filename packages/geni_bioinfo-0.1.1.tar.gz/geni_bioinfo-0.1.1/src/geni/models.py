from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class User:
    """A platform user returned by ``/admin/users``."""

    id: str
    principal_id: str
    email: str
    status: str
    created_at: str
    name: Optional[str] = None
    tenant_id: Optional[str] = None
    role: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "User":
        return cls(
            id=d["id"],
            principal_id=d["principalId"],
            email=d["email"],
            status=d["status"],
            created_at=d["createdAt"],
            name=d.get("name"),
            tenant_id=d.get("tenantId"),
            role=d.get("role"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class Environment:
    """A cloud environment returned by ``/admin/environments``."""

    id: str
    name: str
    cloud_id: str
    cloud_region: str
    identity_to_assume: str
    cloud_provider: str
    availability_zones: int
    status: str
    created_at: str
    error: Optional[str] = None
    stack_name: Optional[str] = None
    executions_bucket_name: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Environment":
        return cls(
            id=d["id"],
            name=d["name"],
            cloud_id=d["cloudId"],
            cloud_region=d["cloudRegion"],
            identity_to_assume=d["identityToAssume"],
            cloud_provider=d["cloudProvider"],
            availability_zones=d["availabilityZones"],
            status=d["status"],
            created_at=d["createdAt"],
            error=d.get("error"),
            stack_name=d.get("stackName"),
            executions_bucket_name=d.get("executionsBucketName"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class Engine:
    """A Nextflow engine returned by ``/admin/engines``."""

    id: str
    name: str
    environment_id: str
    engine: str
    engine_version: str
    status: str
    created_at: str
    error: Optional[str] = None
    stack_name: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Engine":
        return cls(
            id=d["id"],
            name=d["name"],
            environment_id=d["environmentId"],
            engine=d["engine"],
            engine_version=d["engineVersion"],
            status=d["status"],
            created_at=d["createdAt"],
            error=d.get("error"),
            stack_name=d.get("stackName"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class Queue:
    """A job queue returned by ``/admin/queues``."""

    id: str
    name: str
    environment_id: str
    execution_mode: str
    instance_types: List[str]
    max_vcpus: int
    status: str
    created_at: str
    storage_size_gb: Optional[int] = None
    error: Optional[str] = None
    stack_name: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Queue":
        return cls(
            id=d["id"],
            name=d["name"],
            environment_id=d["environmentId"],
            execution_mode=d["executionMode"],
            instance_types=d["instanceTypes"],
            max_vcpus=d["maxvCpus"],
            status=d["status"],
            created_at=d["createdAt"],
            storage_size_gb=d.get("storageSizeGb"),
            error=d.get("error"),
            stack_name=d.get("stackName"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class Storage:
    """A cloud storage resource returned by ``/admin/storages``."""

    id: str
    name: str
    environment_id: str
    permission_mode: str
    status: str
    created_at: str
    bucket_name: Optional[str] = None
    bucket_arn: Optional[str] = None
    stack_name: Optional[str] = None
    error: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Storage":
        return cls(
            id=d["id"],
            name=d["name"],
            environment_id=d["environmentId"],
            permission_mode=d["permissionMode"],
            status=d["status"],
            created_at=d["createdAt"],
            bucket_name=d.get("bucketName"),
            bucket_arn=d.get("bucketArn"),
            stack_name=d.get("stackName"),
            error=d.get("error"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class WorkflowVersion:
    """A registered workflow version returned by ``/workflows`` endpoints."""

    name: str
    version: str
    engine: str
    file_type: str
    latest: bool
    created_at: Optional[str] = None
    alert_time_seconds: Optional[int] = None
    cancel_time_seconds: Optional[int] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "WorkflowVersion":
        return cls(
            name=d["name"],
            version=d["version"],
            engine=d["engine"],
            file_type=d["fileType"],
            latest=d["latest"],
            created_at=d.get("createdAt"),
            alert_time_seconds=d.get("alertTimeSeconds"),
            cancel_time_seconds=d.get("cancelTimeSeconds"),
        )


@dataclass
class WorkflowVersionSummary:
    """A brief workflow version entry returned by ``GET /workflows/{name}/versions``."""

    version: str
    file_type: str
    latest: bool
    created_at: str

    @classmethod
    def _from_dict(cls, d: dict) -> "WorkflowVersionSummary":
        return cls(
            version=d["version"],
            file_type=d["fileType"],
            latest=d["latest"],
            created_at=d["createdAt"],
        )


@dataclass
class Submission:
    """A workflow submission returned by ``/submissions`` endpoints."""

    submission_id: str
    status: str
    engine_id: str
    queue_id: str
    environment_id: str
    job_id: Optional[str] = None
    job_name: Optional[str] = None
    status_reason: Optional[str] = None
    workflow_version_id: Optional[str] = None
    workflow_name: Optional[str] = None
    workflow_version: Optional[str] = None
    nf_work_dir: Optional[str] = None
    output: Optional[str] = None
    alert_time_seconds: Optional[int] = None
    cancel_time_seconds: Optional[int] = None
    alert_sent_at: Optional[str] = None
    cancel_sent_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Submission":
        return cls(
            submission_id=d["submissionId"],
            status=d["status"],
            engine_id=d["engineId"],
            queue_id=d["queueId"],
            environment_id=d["environmentId"],
            job_id=d.get("jobId"),
            job_name=d.get("jobName"),
            status_reason=d.get("statusReason"),
            workflow_version_id=d.get("workflowVersionId"),
            workflow_name=d.get("workflowName"),
            workflow_version=d.get("workflowVersion"),
            nf_work_dir=d.get("nfWorkDir"),
            output=d.get("output"),
            alert_time_seconds=d.get("alertTimeSeconds"),
            cancel_time_seconds=d.get("cancelTimeSeconds"),
            alert_sent_at=d.get("alertSentAt"),
            cancel_sent_at=d.get("cancelSentAt"),
            created_at=d.get("createdAt"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class SubmissionAccepted:
    """Initial response returned when a submission is created via ``POST /submissions``."""

    submission_id: str
    status: str
    engine_id: str
    queue_id: str
    environment_id: str
    output: str
    job_id: Optional[str] = None
    job_name: Optional[str] = None
    workflow_name: Optional[str] = None
    workflow_version: Optional[str] = None
    alert_time_seconds: Optional[int] = None
    cancel_time_seconds: Optional[int] = None
    created_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "SubmissionAccepted":
        return cls(
            submission_id=d["submissionId"],
            status=d["status"],
            engine_id=d["engineId"],
            queue_id=d["queueId"],
            environment_id=d["environmentId"],
            output=d["output"],
            job_id=d.get("jobId"),
            job_name=d.get("jobName"),
            workflow_name=d.get("workflowName"),
            workflow_version=d.get("workflowVersion"),
            alert_time_seconds=d.get("alertTimeSeconds"),
            cancel_time_seconds=d.get("cancelTimeSeconds"),
            created_at=d.get("createdAt"),
        )


@dataclass
class Task:
    """A batch task belonging to a submission, returned by ``/tasks``."""

    id: str
    submission_id: str
    job_id: str
    status: str
    job_name: Optional[str] = None
    status_reason: Optional[str] = None
    exit_code: Optional[int] = None
    vcpus: Optional[int] = None
    memory: Optional[int] = None
    instance_id: Optional[str] = None
    created_at: Optional[str] = None
    started_at: Optional[str] = None
    stopped_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Task":
        return cls(
            id=d["id"],
            submission_id=d["submissionId"],
            job_id=d["jobId"],
            status=d["status"],
            job_name=d.get("jobName"),
            status_reason=d.get("statusReason"),
            exit_code=d.get("exitCode"),
            vcpus=d.get("vcpus"),
            memory=d.get("memory"),
            instance_id=d.get("instanceId"),
            created_at=d.get("createdAt"),
            started_at=d.get("startedAt"),
            stopped_at=d.get("stoppedAt"),
            updated_at=d.get("updatedAt"),
        )


@dataclass
class TaskLog:
    """A single log entry for a task, returned by ``/task-logs``."""

    id: str
    task_id: str
    timestamp: str
    message: str
    created_at: str

    @classmethod
    def _from_dict(cls, d: dict) -> "TaskLog":
        return cls(
            id=d["id"],
            task_id=d["taskId"],
            timestamp=d["timestamp"],
            message=d["message"],
            created_at=d["createdAt"],
        )


@dataclass
class SubmissionLog:
    """A single Nextflow log entry for a submission, returned by ``/submission-logs``."""

    id: str
    submission_id: str
    timestamp: str
    message: str
    created_at: str

    @classmethod
    def _from_dict(cls, d: dict) -> "SubmissionLog":
        return cls(
            id=d["id"],
            submission_id=d["submissionId"],
            timestamp=d["timestamp"],
            message=d["message"],
            created_at=d["createdAt"],
        )


@dataclass
class CancelResult:
    """Confirmation returned when a submission is cancelled via ``POST /submissions/{id}/cancel``."""

    submission_id: str
    message: str

    @classmethod
    def _from_dict(cls, d: dict) -> "CancelResult":
        return cls(
            submission_id=d["submissionId"],
            message=d["message"],
        )


@dataclass
class RetryResult:
    """Confirmation returned when a submission is retried via ``POST /submissions/{id}/retry``."""

    submission_id: str
    message: str

    @classmethod
    def _from_dict(cls, d: dict) -> "RetryResult":
        return cls(
            submission_id=d["submissionId"],
            message=d["message"],
        )


@dataclass
class Tag:
    """A registered tag returned by ``/tags`` endpoints."""

    id: str
    name: str
    created_at: str

    @classmethod
    def _from_dict(cls, d: dict) -> "Tag":
        return cls(
            id=d["id"],
            name=d["name"],
            created_at=d["createdAt"],
        )
