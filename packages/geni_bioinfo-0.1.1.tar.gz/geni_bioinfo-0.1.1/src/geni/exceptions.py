from __future__ import annotations


class GeniError(Exception):
    """Base for all geni-workflows errors."""


class GeniConfigError(GeniError):
    """Missing or invalid configuration."""


class GeniAuthError(GeniError):
    """Authentication or authorization failure (401/403, or login not called)."""


class GeniNotFoundError(GeniError):
    """Requested resource not found (404)."""


class GeniAPIError(GeniError):
    """Unexpected HTTP error from the API."""

    def __init__(
        self,
        message: str,
        status_code: int,
        method: str,
        url: str,
        response_body: str,
    ) -> None:
        """Create a GeniAPIError.

        Args:
            message: Human-readable error description.
            status_code: HTTP status code returned by the API.
            method: HTTP method of the failed request (e.g. ``"GET"``).
            url: Full URL of the failed request.
            response_body: Raw response body text from the API.

        Attributes:
            status_code: HTTP status code.
            method: HTTP method.
            url: Request URL.
            response_body: Raw response body.
        """
        super().__init__(message)
        self.status_code = status_code
        self.method = method
        self.url = url
        self.response_body = response_body
