from __future__ import annotations

import os
from typing import List, Optional, Union

import requests

from .exceptions import GeniAPIError, GeniAuthError, GeniConfigError, GeniNotFoundError
from .models import (
    CancelResult,
    Engine,
    Environment,
    Queue,
    RetryResult,
    Storage,
    Submission,
    SubmissionAccepted,
    SubmissionLog,
    Tag,
    Task,
    TaskLog,
    User,
    WorkflowVersion,
    WorkflowVersionSummary,
)

DEFAULT_API_URL = "https://workflows-api.geni-bioinfo.com.br"


class GeniClient:
    def __init__(self, api_url: Optional[str] = None) -> None:
        """Create a GENI API client.

        Args:
            api_url: Base URL of the GENI Workflows API. Defaults to the
                ``GENI_API_URL`` environment variable, or
                ``https://workflows-api.geni-bioinfo.com.br`` if neither is set.
        """
        self._api_url = (
            api_url or os.environ.get("GENI_API_URL") or DEFAULT_API_URL
        ).rstrip("/")
        self._headers: dict[str, str] = {}

    def auth_login(self, email: str, password: str) -> None:
        """Authenticate with email and password (JWT).

        Fetches a short-lived JWT from the API and stores it for subsequent
        requests. Call this once before any other method.

        Args:
            email: The account email address.
            password: The account password.

        Raises:
            GeniAuthError: If the credentials are invalid or the login request fails.
        """
        resp = requests.post(
            self._url("auth/login"),
            json={"email": email, "password": password},
        )
        if not resp.ok:
            body = resp.text
            try:
                body = resp.json().get("error", body)
            except Exception:
                pass
            raise GeniAuthError(f"Login failed ({resp.status_code}): {body}")
        self._headers = {"Authorization": f"Bearer {resp.json()['accessToken']}"}

    def auth_token(self, token: str) -> None:
        """Authenticate with a static API token.

        Stores the token as an ``X-API-Key`` header for subsequent requests.
        Use this instead of ``auth_login`` when you have a long-lived API key.

        Args:
            token: A static API key issued by the GENI platform.
        """
        self._headers = {"X-API-Key": token}

    def _url(self, path: str) -> str:
        return f"{self._api_url}/{path.lstrip('/')}"

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        data: Optional[dict] = None,
        files: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        if not self._headers:
            raise GeniConfigError(
                "Call auth_login() or auth_token() before making requests."
            )

        url = self._url(path)
        filtered_params = (
            {k: v for k, v in params.items() if v is not None} if params else None
        )

        resp = requests.request(
            method,
            url,
            headers=self._headers,
            json=json,
            data=data,
            files=files,
            params=filtered_params,
        )

        if not resp.ok:
            body = resp.text
            message = body
            try:
                payload = resp.json()
                message = payload.get("error") or payload.get("message") or body
            except Exception:
                pass

            if resp.status_code in (401, 403):
                raise GeniAuthError(f"Auth failed ({resp.status_code}): {message}")
            if resp.status_code == 404:
                raise GeniNotFoundError(f"Not found: {message}")
            raise GeniAPIError(
                message=f"HTTP {resp.status_code}: {message}",
                status_code=resp.status_code,
                method=method,
                url=url,
                response_body=body,
            )

        if resp.status_code == 204 or not resp.content:
            return {}
        return resp.json()

    # ── Admin ────────────────────────────────────────────────────────────────

    def user_list(self) -> List[User]:
        """List all platform users (admin only).

        Returns:
            A list of ``User`` objects.

        Raises:
            GeniAuthError: If not authenticated or the account lacks admin privileges.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("GET", "/admin/users")
        return [User._from_dict(u) for u in data.get("items", [])]

    def environment_list(self, status: Optional[str] = None) -> List[Environment]:
        """List cloud environments (admin only).

        Args:
            status: Optional filter. One of ``PENDING``, ``CREATING``, ``ACTIVE``,
                ``FAILED``, ``DELETING``, or ``DELETED`` (case-insensitive).

        Returns:
            A list of ``Environment`` objects.

        Raises:
            GeniAuthError: If not authenticated or the account lacks admin privileges.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET",
            "/admin/environments",
            params={"status": status.upper() if status else None},
        )
        return [Environment._from_dict(e) for e in data.get("items", [])]

    def engine_list(self, status: Optional[str] = None) -> List[Engine]:
        """List Nextflow engines (admin only).

        Args:
            status: Optional filter. One of ``PENDING``, ``CREATING``, ``ACTIVE``,
                ``FAILED``, ``DELETING``, or ``DELETED`` (case-insensitive).

        Returns:
            A list of ``Engine`` objects.

        Raises:
            GeniAuthError: If not authenticated or the account lacks admin privileges.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET",
            "/admin/engines",
            params={"status": status.upper() if status else None},
        )
        return [Engine._from_dict(e) for e in data.get("items", [])]

    def queue_list(self, status: Optional[str] = None) -> List[Queue]:
        """List job queues (admin only).

        Args:
            status: Optional filter. One of ``PENDING``, ``CREATING``, ``ACTIVE``,
                ``FAILED``, ``DELETING``, or ``DELETED`` (case-insensitive).

        Returns:
            A list of ``Queue`` objects.

        Raises:
            GeniAuthError: If not authenticated or the account lacks admin privileges.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET",
            "/admin/queues",
            params={"status": status.upper() if status else None},
        )
        return [Queue._from_dict(q) for q in data.get("items", [])]

    def storage_list(self, status: Optional[str] = None) -> List[Storage]:
        """List cloud storage resources (admin only).

        Args:
            status: Optional filter. One of ``PENDING``, ``CREATING``, ``ACTIVE``,
                ``FAILED``, ``DELETING``, or ``DELETED`` (case-insensitive).

        Returns:
            A list of ``Storage`` objects.

        Raises:
            GeniAuthError: If not authenticated or the account lacks admin privileges.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET",
            "/admin/storages",
            params={"status": status.upper() if status else None},
        )
        return [Storage._from_dict(s) for s in data.get("items", [])]

    # ── Workflows ────────────────────────────────────────────────────────────

    def workflow_create(
        self,
        name: str,
        version: str,
        file_path: str,
        file_type: Optional[str] = None,
        engine: str = "nextflow",
        alert_time_seconds: Optional[int] = None,
        cancel_time_seconds: Optional[int] = None,
    ) -> WorkflowVersion:
        """Upload a workflow file and register a new version.

        The file type is inferred automatically from the file extension
        (``TEXT`` for ``.nf`` or ``.wdl``, ``ZIP`` for ``.zip``) unless
        ``file_type`` is provided explicitly.

        Args:
            name: Workflow name. Creates a new workflow if it does not exist,
                or adds a version to an existing one.
            version: Version string, e.g. ``"v1.0.0"``. 1–32 characters:
                alphanumeric, dots, hyphens, or underscores.
            file_path: Local path to a ``.nf`` script or ``.zip`` archive.
            file_type: ``"TEXT"`` or ``"ZIP"``. Inferred from the file extension
                when omitted.
            engine: Workflow engine. Defaults to ``"nextflow"``.
            alert_time_seconds: Send an alert if the submission runs longer than
                this many seconds. ``None`` disables the alert.
            cancel_time_seconds: Automatically cancel the submission if it runs
                longer than this many seconds. ``None`` disables auto-cancel.

        Returns:
            A ``WorkflowVersion`` representing the newly registered version.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
            OSError: If ``file_path`` cannot be opened.
        """
        if file_type is None:
            file_type = "ZIP" if file_path.lower().endswith(".zip") else "TEXT"
        form: dict = {
            "name": name,
            "version": version,
            "fileType": file_type,
            "engine": engine,
        }
        if alert_time_seconds is not None:
            form["alertTimeSeconds"] = str(alert_time_seconds)
        if cancel_time_seconds is not None:
            form["cancelTimeSeconds"] = str(cancel_time_seconds)

        with open(file_path, "rb") as fh:
            files = {
                "file": (os.path.basename(file_path), fh, "application/octet-stream")
            }
            data = self._request("POST", "/workflows", data=form, files=files)
        return WorkflowVersion._from_dict(data)

    def workflow_list(self) -> List[WorkflowVersion]:
        """List all registered workflow versions.

        Returns all versions across all workflows accessible to the
        authenticated account.

        Returns:
            A list of ``WorkflowVersion`` objects.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("GET", "/workflows")
        return [WorkflowVersion._from_dict(w) for w in data.get("items", [])]

    def workflow_versions(self, name: str) -> List[WorkflowVersionSummary]:
        """List all versions of a workflow.

        Args:
            name: Workflow name.

        Returns:
            A list of ``WorkflowVersionSummary`` objects, ordered with the
            latest version marked by ``latest=True``.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no workflow with that name exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("GET", f"/workflows/{name}/versions")
        return [WorkflowVersionSummary._from_dict(v) for v in data.get("items", [])]

    # ── Submissions ──────────────────────────────────────────────────────────

    def submission_create(
        self,
        workflow_name: str,
        engine_id: str,
        queue_id: str,
        output: str,
        params_path: str,
        workflow_version: Optional[str] = None,
        alert_time_seconds: Optional[int] = None,
        cancel_time_seconds: Optional[int] = None,
        tags: Optional[dict] = None,
    ) -> SubmissionAccepted:
        """Submit a workflow for execution.

        Args:
            workflow_name: Name of a registered workflow.
            engine_id: ID of the engine to run on (see ``engine_list()``).
            queue_id: ID of the job queue to use (see ``queue_list()``).
            output: Cloud storage path where results will be written (e.g. an
                S3 URI such as ``"s3://my-bucket/runs/run-001"``).
            params_path: Local path to a YAML or JSON parameters file that will
                be passed to the workflow.
            workflow_version: Specific version to run. Defaults to the latest
                registered version when omitted.
            alert_time_seconds: Send an alert if the submission runs longer than
                this many seconds. ``None`` disables the alert.
            cancel_time_seconds: Automatically cancel if the submission runs
                longer than this many seconds. ``None`` disables auto-cancel.
            tags: Optional mapping of tag key to value, e.g.
                ``{"project": "alpha", "team": "genomics"}``. Tags must be
                pre-registered via ``tag_create()``.

        Returns:
            A ``SubmissionAccepted`` object with the new submission ID and
            initial status.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If the workflow name or IDs do not exist.
            GeniAPIError: On unexpected HTTP errors.
            OSError: If ``params_path`` cannot be opened.
        """
        form: dict = {
            "workflowName": workflow_name,
            "engineId": engine_id,
            "queueId": queue_id,
            "output": output,
        }
        if workflow_version is not None:
            form["workflowVersion"] = workflow_version
        if alert_time_seconds is not None:
            form["alertTimeSeconds"] = str(alert_time_seconds)
        if cancel_time_seconds is not None:
            form["cancelTimeSeconds"] = str(cancel_time_seconds)
        if tags:
            form["tag"] = [f"{k}={v}" for k, v in tags.items()]

        with open(params_path, "rb") as fh:
            files = {
                "params": (
                    os.path.basename(params_path),
                    fh,
                    "application/octet-stream",
                )
            }
            data = self._request("POST", "/submissions", data=form, files=files)
        return SubmissionAccepted._from_dict(data)

    def submission_list(
        self,
        status: Optional[str] = None,
        tags: Optional[dict] = None,
        limit: Optional[int] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
    ) -> List[Submission]:
        """List workflow submissions.

        Args:
            status: Optional filter. One of ``SUBMITTED``, ``RUNNING``,
                ``SUCCEEDED``, ``FAILED``, or ``CANCELLED`` (case-insensitive).
            tags: Optional mapping of tag key to value to filter by, e.g.
                ``{"project": "alpha"}``.
            limit: Maximum number of results to return (1–1000).
            sort: Field to sort by. One of ``"started"``, ``"stopped"``,
                ``"updated"`` (default: ``"updated"``).
            sort_order: Sort direction. One of ``"asc"`` or ``"desc"``
                (default: ``"desc"``).

        Returns:
            A list of ``Submission`` objects.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
        """
        params: dict = {
            "status": status.upper() if status else None,
            "limit": limit,
            "sort": sort,
            "sortOrder": sort_order,
        }
        if tags:
            params["tag"] = [f"{k}={v}" for k, v in tags.items()]
        data = self._request("GET", "/submissions", params=params)
        return [Submission._from_dict(s) for s in data.get("items", [])]

    def submission_get(self, id: str) -> Submission:
        """Fetch a single submission by ID.

        Args:
            id: The submission UUID.

        Returns:
            The ``Submission`` with the given ID.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no submission with that ID exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("GET", f"/submissions/{id}")
        return Submission._from_dict(data)

    def task_list(
        self,
        submission_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Task]:
        """List tasks, optionally filtered by submission and/or status.

        Args:
            submission_id: When provided, return only tasks that belong to this
                submission UUID.
            status: Optional filter. One of ``SUBMITTED``, ``RUNNING``,
                ``SUCCEEDED``, ``FAILED``, or ``CANCELLED`` (case-insensitive).

        Returns:
            A list of ``Task`` objects.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET",
            "/tasks",
            params={
                "submissionId": submission_id,
                "status": status.upper() if status else None,
            },
        )
        return [Task._from_dict(t) for t in data.get("items", [])]

    def task_get(self, id: str) -> Task:
        """Fetch a single task by ID.

        Args:
            id: The task UUID.

        Returns:
            The ``Task`` with the given ID.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no task with that ID exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("GET", f"/tasks/{id}")
        return Task._from_dict(data)

    def task_logs(
        self, submission_id: str, task_id: str, text: bool = False
    ) -> Union[List[TaskLog], str]:
        """Fetch log entries for a specific task.

        Args:
            submission_id: UUID of the parent submission.
            task_id: UUID of the task.
            text: When ``True``, return all log messages joined into a single
                newline-separated string instead of a list of ``TaskLog`` objects.

        Returns:
            A list of ``TaskLog`` objects, or a plain string when ``text=True``.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET",
            "/task-logs",
            params={"submissionId": submission_id, "taskId": task_id},
        )
        items = [TaskLog._from_dict(item) for item in data.get("items", [])]
        if text:
            return "\n".join(item.message for item in items)
        return items

    def submission_logs(
        self, submission_id: str, text: bool = False
    ) -> Union[List[SubmissionLog], str]:
        """Fetch Nextflow log entries for a submission.

        Args:
            submission_id: UUID of the submission.
            text: When ``True``, return all log messages joined into a single
                newline-separated string instead of a list of ``SubmissionLog``
                objects.

        Returns:
            A list of ``SubmissionLog`` objects, or a plain string when
            ``text=True``.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request(
            "GET", "/submission-logs", params={"submissionId": submission_id}
        )
        items = [SubmissionLog._from_dict(item) for item in data.get("items", [])]
        if text:
            return "\n".join(item.message for item in items)
        return items

    def submission_cancel(self, id: str) -> CancelResult:
        """Cancel a running submission.

        Args:
            id: The submission UUID to cancel.

        Returns:
            A ``CancelResult`` confirming the cancellation request.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no submission with that ID exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("POST", f"/submissions/{id}/cancel")
        return CancelResult._from_dict(data)

    def submission_retry(
        self,
        id: str,
        engine_id: Optional[str] = None,
        queue_id: Optional[str] = None,
    ) -> RetryResult:
        """Retry a failed submission.

        Args:
            id: The submission UUID to retry.
            engine_id: Engine to use. Defaults to the original engine when omitted.
            queue_id: Queue to use. Defaults to the original queue when omitted.

        Returns:
            A ``RetryResult`` confirming the retry request.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no submission with that ID exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        body: dict = {}
        if engine_id is not None:
            body["engineId"] = engine_id
        if queue_id is not None:
            body["queueId"] = queue_id
        data = self._request("POST", f"/submissions/{id}/retry", json=body or None)
        return RetryResult._from_dict(data)

    def submission_update_tags(
        self,
        id: str,
        add: Optional[List[dict]] = None,
        edit: Optional[List[dict]] = None,
        remove: Optional[List[str]] = None,
    ) -> None:
        """Update tags on a submission.

        Each tag in ``add`` and ``edit`` must be a dict with ``"key"`` and
        ``"value"`` string fields. Tags must be pre-registered via
        ``tag_create()``.

        Args:
            id: The submission UUID.
            add: Tags to add, e.g. ``[{"key": "project", "value": "alpha"}]``.
            edit: Tags to update (must already exist on the submission).
            remove: Tag keys to remove, e.g. ``["project"]``.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no submission with that ID exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        body: dict = {}
        if add is not None:
            body["addTags"] = add
        if edit is not None:
            body["editTags"] = edit
        if remove is not None:
            body["removeTags"] = remove
        self._request("PATCH", f"/submissions/{id}", json=body)

    # ── Tags ─────────────────────────────────────────────────────────────────

    def tag_list(self) -> List[Tag]:
        """List all registered tags.

        Returns:
            A list of ``Tag`` objects.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("GET", "/tags")
        return [Tag._from_dict(t) for t in data.get("items", [])]

    def tag_create(self, name: str) -> Tag:
        """Register a new tag.

        Args:
            name: Tag name. 1–63 characters, must start with alphanumeric;
                allows ``.``, ``_``, ``-``.

        Returns:
            The created ``Tag``.

        Raises:
            GeniAuthError: If not authenticated.
            GeniAPIError: On unexpected HTTP errors (409 if name already exists).
        """
        data = self._request("POST", "/tags", json={"name": name})
        return Tag._from_dict(data)

    def tag_rename(self, name: str, new_name: str) -> Tag:
        """Rename an existing tag.

        Args:
            name: Current tag name.
            new_name: New tag name.

        Returns:
            The updated ``Tag``.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no tag with that name exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        data = self._request("PATCH", f"/tags/{name}", json={"name": new_name})
        return Tag._from_dict(data)

    def tag_delete(self, name: str) -> None:
        """Delete a tag.

        Args:
            name: Tag name to delete.

        Raises:
            GeniAuthError: If not authenticated.
            GeniNotFoundError: If no tag with that name exists.
            GeniAPIError: On unexpected HTTP errors.
        """
        self._request("DELETE", f"/tags/{name}")
