"""
AlterAuthProvider — FastMCP OAuthProvider that makes any MCP server a full
OAuth 2.0 Authorization Server backed by Alter's hosted IDP flow.

When a developer does::

    auth = AlterAuthProvider(vault, base_url="http://localhost:8000/mcp",
                             providers={"google": ["gmail.readonly"]})
    mcp = FastMCP("my-server", auth=auth)

...Claude Code (or any spec-compliant MCP client) can discover, register,
authorize, and obtain tokens without `mcp-remote` or any other shim.

The authorize flow proxies through Alter's existing /sdk/auth/* endpoints
(session creation + polling) via a browser bridge page, then issues opaque
tokens that map back to the IDP's JWT for downstream identity resolution.
"""

from __future__ import annotations

import json
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from fastmcp.server.auth.auth import (
    AccessToken,
    OAuthProvider,
)
from mcp.server.auth.provider import (
    AuthorizationCode,
    AuthorizationParams,
    AuthorizeError,
    RefreshToken,
)
from mcp.server.auth.settings import (
    ClientRegistrationOptions,
    RevocationOptions,
)
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route

from alter_sdk.exceptions import AlterSDKError, AlterValueError

if TYPE_CHECKING:
    from collections.abc import Callable

    from starlette.requests import Request

    from alter_sdk.client import AlterVault

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Token lifetime constants
# ---------------------------------------------------------------------------
AUTH_CODE_EXPIRY_SECONDS = 5 * 60  # 5 minutes
ACCESS_TOKEN_EXPIRY_SECONDS = 60 * 60  # 1 hour
REFRESH_TOKEN_EXPIRY_SECONDS = 24 * 60 * 60  # 24 hours
BRIDGE_TIMEOUT_SECONDS = 10 * 60  # 10 minutes

# Store size caps — prevent unbounded memory growth under multi-tenant load.
# A production MCP server serves many concurrent users; without caps a
# misbehaving client could exhaust memory by spamming /register or /authorize.
MAX_CLIENTS = 10_000
MAX_PENDING_AUTHS = 10_000
MAX_TOKEN_PAIRS = 100_000


# ---------------------------------------------------------------------------
# Internal data classes for in-memory token storage
# ---------------------------------------------------------------------------


@dataclass
class _PendingAuth:
    """Tracks an in-flight authorization (between authorize → token exchange)."""

    session_token: str
    auth_url: str
    client_id: str
    redirect_uri: str
    state: str | None
    code_challenge: str
    scopes: list[str]
    created_at: float = field(default_factory=time.time)
    idp_jwt: str | None = None  # Set when bridge polling completes


@dataclass
class _TokenMapping:
    """Maps an opaque access token to the IDP JWT + metadata."""

    idp_jwt: str
    client_id: str
    scopes: list[str]
    expires_at: int


@dataclass
class _RefreshMapping:
    """Maps an opaque refresh token to metadata for rotation."""

    idp_jwt: str
    client_id: str
    scopes: list[str]
    expires_at: int
    access_token: str  # The corresponding access token (for revocation)


# ---------------------------------------------------------------------------
# AlterAuthProvider
# ---------------------------------------------------------------------------


class AlterAuthProvider(OAuthProvider):
    """FastMCP OAuthProvider backed by Alter's hosted IDP auth flow.

    Subclasses FastMCP's :class:`OAuthProvider` to implement the full
    OAuthAuthorizationServerProvider protocol. Discovery, registration,
    authorization, token exchange, refresh, and revocation all work
    automatically — no IDP credentials needed in the MCP server's env.

    The authorize flow uses a browser bridge page that:
    1. Opens the IDP login in a popup (URL from Alter backend)
    2. Polls Alter backend for completion
    3. Redirects back to the client's redirect_uri with an auth code

    Usage::

        from alter_sdk import AlterVault
        from alter_sdk.mcp import AlterAuthProvider
        from fastmcp import FastMCP

        vault = AlterVault(api_key="alter_key_...")
        auth = AlterAuthProvider(vault, base_url="http://localhost:8000/mcp",
                                 providers={"google": ["gmail.readonly"]})
        mcp = FastMCP("Gmail", auth=auth)
    """

    def __init__(
        self,
        vault: AlterVault,
        *,
        base_url: str = "",
        providers: dict[str, list[str]] | None = None,
    ) -> None:
        """Initialize the OAuth auth provider.

        Args:
            vault: AlterVault client instance (for backend auth session calls)
            base_url: Public URL where this MCP server is mounted. Required for
                      OAuth metadata discovery. E.g. "http://localhost:8000/mcp".
            providers: Map of provider_id → required scopes for Alter Connect
                       (used by :meth:`create_auth_url`). E.g.,
                       ``{"google": ["gmail.readonly"], "github": ["repo"]}``
        """
        super().__init__(
            base_url=base_url or "http://localhost:8000",
            client_registration_options=ClientRegistrationOptions(enabled=True),
            revocation_options=RevocationOptions(enabled=True),
        )
        self._vault = vault
        self._providers = providers or {}

        # In-memory stores (single-process, acceptable for MCP servers)
        self._clients: dict[str, OAuthClientInformationFull] = {}
        self._client_registered_at: dict[str, float] = {}  # client_id → time.time()
        self._pending_auths: dict[str, _PendingAuth] = {}
        self._access_tokens: dict[str, _TokenMapping] = {}
        self._refresh_tokens: dict[str, _RefreshMapping] = {}
        # Bidirectional access↔refresh for revocation
        self._access_to_refresh: dict[str, str] = {}
        self._refresh_to_access: dict[str, str] = {}

        # Callback for ContextVar integration (set via set_token_callback)
        self._user_token_setter: Callable[[str], None] | None = None

    def set_token_callback(self, callback: Callable[[str], None]) -> None:
        """Register a callback invoked with the IDP JWT on each verified token.

        Used by AlterFastAPI to set the user token in a ContextVar so the
        shared vault instance resolves identity on subsequent requests.

        Args:
            callback: Function accepting an IDP JWT string.
        """
        self._user_token_setter = callback

    # ------------------------------------------------------------------
    # Alter Connect helper (preserved from original API)
    # ------------------------------------------------------------------

    async def create_auth_url(self, **kwargs: Any) -> str:  # noqa: ARG002
        """Create an Alter Connect URL for provider OAuth authorization.

        This is **not** part of the OAuth server protocol — it is exposed
        as an Alter-specific helper so the host application can kick off an
        Alter Connect session for provider consent.
        """
        if not self._providers:
            raise AlterValueError("No providers configured for AlterAuthProvider")

        allowed_providers = list(self._providers.keys())

        required_scopes: dict[str, list[str]] = {}
        for provider_id, scopes in self._providers.items():
            if scopes:
                required_scopes[provider_id] = list(scopes)

        session = await self._vault.create_connect_session(
            allowed_providers=allowed_providers,
            required_scopes=required_scopes if required_scopes else None,
        )
        return session.connect_url

    # ------------------------------------------------------------------
    # OAuthAuthorizationServerProvider protocol implementation
    # ------------------------------------------------------------------

    async def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        """Look up a registered client by ID."""
        return self._clients.get(client_id)

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        """Register a new dynamic OAuth client."""
        if client_info.client_id is None:
            raise ValueError("client_id is required for client registration")
        # Allow re-registration of existing clients (RFC 7591) but cap new ones
        if client_info.client_id not in self._clients and len(self._clients) >= MAX_CLIENTS:
            self._sweep_expired()
            if len(self._clients) >= MAX_CLIENTS:
                raise ValueError("Client registration at capacity")
        self._clients[client_info.client_id] = client_info
        self._client_registered_at[client_info.client_id] = time.time()

    async def authorize(
        self,
        client: OAuthClientInformationFull,
        params: AuthorizationParams,
    ) -> str:
        """Handle the /authorize endpoint.

        Creates an Alter auth session and returns a redirect to the bridge
        page, which handles the IDP popup flow and polls for completion.
        """
        if client.client_id is None or client.client_id not in self._clients:
            raise AuthorizeError(
                error="unauthorized_client",
                error_description="Client not registered.",
            )

        # Evict expired entries before checking capacity
        self._sweep_expired()

        if len(self._pending_auths) >= MAX_PENDING_AUTHS:
            raise AuthorizeError(
                error="temporarily_unavailable",
                error_description="Too many pending authorizations. Try again later.",
            )

        # Create an auth session on the Alter backend
        try:
            session_data = await self._vault._create_auth_session_raw()  # noqa: SLF001
        except AlterSDKError as e:
            raise AuthorizeError(
                error="server_error",
                error_description=f"Failed to create auth session: {e.message}",
            ) from e

        auth_url: str = session_data["auth_url"]
        session_token: str = session_data["session_token"]

        # Generate a unique pending code that identifies this auth flow
        pending_code = secrets.token_urlsafe(32)

        scopes_list = params.scopes if params.scopes is not None else []

        self._pending_auths[pending_code] = _PendingAuth(
            session_token=session_token,
            auth_url=auth_url,
            client_id=client.client_id,
            redirect_uri=str(params.redirect_uri),
            state=params.state,
            code_challenge=params.code_challenge,
            scopes=scopes_list,
        )

        # Return redirect to the bridge page
        base = str(self.base_url).rstrip("/") if self.base_url else ""
        return f"{base}/auth-bridge?pending={pending_code}"

    async def load_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: str,
    ) -> AuthorizationCode | None:
        """Load and validate an authorization code."""
        pending = self._pending_auths.get(authorization_code)
        if pending is None:
            return None
        if pending.client_id != client.client_id:
            return None
        if pending.idp_jwt is None:
            # Auth flow hasn't completed yet
            return None
        if time.time() - pending.created_at > AUTH_CODE_EXPIRY_SECONDS:
            del self._pending_auths[authorization_code]
            return None

        return AuthorizationCode(
            code=authorization_code,
            client_id=pending.client_id,
            redirect_uri=pending.redirect_uri,  # type: ignore[arg-type]
            redirect_uri_provided_explicitly=True,
            scopes=pending.scopes,
            expires_at=pending.created_at + AUTH_CODE_EXPIRY_SECONDS,
            code_challenge=pending.code_challenge,
        )

    async def exchange_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: AuthorizationCode,
    ) -> OAuthToken:
        """Exchange an authorization code for access + refresh tokens."""
        # Evict expired tokens and check capacity before consuming the code
        self._sweep_expired()

        if len(self._access_tokens) >= MAX_TOKEN_PAIRS:
            from mcp.server.auth.provider import TokenError

            raise TokenError(
                error="invalid_request",
                error_description="Token store at capacity. Try again later.",
            )

        pending = self._pending_auths.pop(authorization_code.code, None)
        if pending is None or pending.idp_jwt is None:
            from mcp.server.auth.provider import TokenError

            raise TokenError(
                error="invalid_grant",
                error_description="Authorization code not found or not completed.",
            )

        if client.client_id is None:
            from mcp.server.auth.provider import TokenError

            raise TokenError(error="invalid_client", error_description="Client ID required")

        # Issue opaque tokens
        access_token_value = f"alter_at_{secrets.token_urlsafe(32)}"
        refresh_token_value = f"alter_rt_{secrets.token_urlsafe(32)}"

        access_expires_at = int(time.time()) + ACCESS_TOKEN_EXPIRY_SECONDS
        refresh_expires_at = int(time.time()) + REFRESH_TOKEN_EXPIRY_SECONDS

        self._access_tokens[access_token_value] = _TokenMapping(
            idp_jwt=pending.idp_jwt,
            client_id=client.client_id,
            scopes=pending.scopes,
            expires_at=access_expires_at,
        )
        self._refresh_tokens[refresh_token_value] = _RefreshMapping(
            idp_jwt=pending.idp_jwt,
            client_id=client.client_id,
            scopes=pending.scopes,
            expires_at=refresh_expires_at,
            access_token=access_token_value,
        )
        self._access_to_refresh[access_token_value] = refresh_token_value
        self._refresh_to_access[refresh_token_value] = access_token_value

        return OAuthToken(
            access_token=access_token_value,
            token_type="Bearer",
            expires_in=ACCESS_TOKEN_EXPIRY_SECONDS,
            refresh_token=refresh_token_value,
            scope=" ".join(pending.scopes) if pending.scopes else None,
        )

    async def load_access_token(self, token: str) -> AccessToken | None:  # type: ignore[override]
        """Load and verify an opaque access token.

        If valid, also calls _user_token_setter to set the IDP JWT in
        the ContextVar so downstream vault.request() calls resolve identity.
        """
        mapping = self._access_tokens.get(token)
        if mapping is None:
            return None
        if mapping.expires_at < int(time.time()):
            self._revoke_internal(access_token_str=token)
            return None

        # Set the IDP JWT for downstream identity resolution
        if self._user_token_setter is not None:
            self._user_token_setter(mapping.idp_jwt)

        return AccessToken(
            token=token,
            client_id=mapping.client_id,
            scopes=mapping.scopes,
            expires_at=mapping.expires_at,
        )

    async def load_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: str,
    ) -> RefreshToken | None:
        """Load and validate a refresh token."""
        mapping = self._refresh_tokens.get(refresh_token)
        if mapping is None:
            return None
        if mapping.client_id != client.client_id:
            return None
        if mapping.expires_at < int(time.time()):
            self._revoke_internal(refresh_token_str=refresh_token)
            return None

        return RefreshToken(
            token=refresh_token,
            client_id=mapping.client_id,
            scopes=mapping.scopes,
            expires_at=mapping.expires_at,
        )

    async def exchange_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: RefreshToken,
        scopes: list[str],
    ) -> OAuthToken:
        """Exchange a refresh token for new access + refresh tokens (rotation)."""
        mapping = self._refresh_tokens.get(refresh_token.token)
        if mapping is None:
            from mcp.server.auth.provider import TokenError

            raise TokenError(
                error="invalid_grant",
                error_description="Refresh token not found.",
            )

        if client.client_id is None:
            from mcp.server.auth.provider import TokenError

            raise TokenError(error="invalid_client", error_description="Client ID required")

        # Validate scope subset
        original_scopes = set(mapping.scopes)
        requested_scopes = set(scopes) if scopes else original_scopes
        if not requested_scopes.issubset(original_scopes):
            from mcp.server.auth.provider import TokenError

            raise TokenError(
                error="invalid_scope",
                error_description="Requested scopes exceed those authorized.",
            )

        final_scopes = list(requested_scopes) if scopes else mapping.scopes
        idp_jwt = mapping.idp_jwt

        # Revoke old pair
        self._revoke_internal(refresh_token_str=refresh_token.token)

        # Issue new pair
        new_access_value = f"alter_at_{secrets.token_urlsafe(32)}"
        new_refresh_value = f"alter_rt_{secrets.token_urlsafe(32)}"

        access_expires_at = int(time.time()) + ACCESS_TOKEN_EXPIRY_SECONDS
        refresh_expires_at = int(time.time()) + REFRESH_TOKEN_EXPIRY_SECONDS

        self._access_tokens[new_access_value] = _TokenMapping(
            idp_jwt=idp_jwt,
            client_id=client.client_id,
            scopes=final_scopes,
            expires_at=access_expires_at,
        )
        self._refresh_tokens[new_refresh_value] = _RefreshMapping(
            idp_jwt=idp_jwt,
            client_id=client.client_id,
            scopes=final_scopes,
            expires_at=refresh_expires_at,
            access_token=new_access_value,
        )
        self._access_to_refresh[new_access_value] = new_refresh_value
        self._refresh_to_access[new_refresh_value] = new_access_value

        return OAuthToken(
            access_token=new_access_value,
            token_type="Bearer",
            expires_in=ACCESS_TOKEN_EXPIRY_SECONDS,
            refresh_token=new_refresh_value,
            scope=" ".join(final_scopes) if final_scopes else None,
        )

    async def revoke_token(self, token: AccessToken | RefreshToken) -> None:
        """Revoke an access or refresh token (and its counterpart)."""
        if isinstance(token, AccessToken):
            self._revoke_internal(access_token_str=token.token)
        elif isinstance(token, RefreshToken):
            self._revoke_internal(refresh_token_str=token.token)

    # ------------------------------------------------------------------
    # Routes — override to add bridge page endpoints
    # ------------------------------------------------------------------

    def get_routes(self, mcp_path: str | None = None) -> list[Route]:
        """Get all OAuth routes plus custom bridge page endpoints."""
        routes = super().get_routes(mcp_path)

        # Add bridge page route
        routes.append(
            Route(
                "/auth-bridge",
                endpoint=self._bridge_page_handler,
                methods=["GET"],
            ),
        )
        # Add bridge poll endpoint (JSON API for the bridge JS)
        routes.append(
            Route(
                "/auth-bridge/poll",
                endpoint=self._bridge_poll_handler,
                methods=["GET"],
            ),
        )

        return routes

    # ------------------------------------------------------------------
    # Bridge page handlers
    # ------------------------------------------------------------------

    async def _bridge_page_handler(self, request: Request) -> HTMLResponse:
        """Serve the auth bridge HTML page.

        Opens IDP login in a popup, polls for completion, then redirects
        the parent window to the client's redirect_uri with the auth code.
        """
        pending_code = request.query_params.get("pending", "")
        pending = self._pending_auths.get(pending_code)

        if not pending:
            return HTMLResponse(
                content="<html><body><h1>Invalid or expired auth session</h1></body></html>",
                status_code=400,
            )

        # Check timeout
        if time.time() - pending.created_at > BRIDGE_TIMEOUT_SECONDS:
            del self._pending_auths[pending_code]
            return HTMLResponse(
                content="<html><body><h1>Auth session expired</h1></body></html>",
                status_code=400,
            )

        # Build the bridge page HTML — all dynamic values via json.dumps for XSS safety
        auth_url_json = json.dumps(pending.auth_url)
        pending_code_json = json.dumps(pending_code)
        redirect_uri_json = json.dumps(pending.redirect_uri)
        state_json = json.dumps(pending.state)
        timeout_ms_json = json.dumps(BRIDGE_TIMEOUT_SECONDS * 1000)
        # Poll endpoint is relative to the base URL
        base = str(self.base_url).rstrip("/") if self.base_url else ""
        poll_url_json = json.dumps(f"{base}/auth-bridge/poll")

        bridge_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Alter — Authenticating</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               display: flex; align-items: center; justify-content: center;
               min-height: 100vh; margin: 0; background: #fafafa; }}
        .container {{ text-align: center; padding: 2rem; }}
        .spinner {{ width: 40px; height: 40px; border: 4px solid #e0e0e0;
                   border-top-color: #333; border-radius: 50%;
                   animation: spin 0.8s linear infinite; margin: 1rem auto; }}
        @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
        .error {{ color: #d32f2f; margin-top: 1rem; }}
        a {{ color: #1976d2; }}
    </style>
</head>
<body>
<div class="container">
    <div class="spinner" id="spinner"></div>
    <p id="status">Opening login window...</p>
    <p id="fallback" style="display:none">
        Popup blocked?
        <a id="manual-link" href="#" target="_blank"
           rel="noopener">Click here to log in</a>
    </p>
    <p id="error" class="error" style="display:none"></p>
</div>
<script>
(function() {{
    var authUrl = {auth_url_json};
    var pendingCode = {pending_code_json};
    var redirectUri = {redirect_uri_json};
    var state = {state_json};
    var pollUrl = {poll_url_json};
    var popup = null;
    var pollInterval = null;

    // Try to open popup
    try {{
        popup = window.open(authUrl, 'alter_auth', 'width=500,height=700,left=200,top=100');
    }} catch(e) {{}}

    if (!popup || popup.closed) {{
        document.getElementById('fallback').style.display = 'block';
        document.getElementById('manual-link').href = authUrl;
    }}

    document.getElementById('status').textContent = 'Waiting for login to complete...';

    // Poll for completion
    pollInterval = setInterval(function() {{
        fetch(pollUrl + '?pending=' + encodeURIComponent(pendingCode))
            .then(function(r) {{ return r.json(); }})
            .then(function(data) {{
                if (data.status === 'completed') {{
                    clearInterval(pollInterval);
                    if (popup && !popup.closed) popup.close();
                    document.getElementById('spinner').style.display = 'none';
                    document.getElementById('status').textContent =
                        'Login complete! Redirecting...';
                    // Build redirect with auth code
                    var sep = redirectUri.indexOf('?') >= 0 ? '&' : '?';
                    var target = redirectUri + sep + 'code=' + encodeURIComponent(data.code);
                    if (state) target += '&state=' + encodeURIComponent(state);
                    window.location.href = target;
                }} else if (data.status === 'error') {{
                    clearInterval(pollInterval);
                    if (popup && !popup.closed) popup.close();
                    document.getElementById('spinner').style.display = 'none';
                    document.getElementById('status').style.display = 'none';
                    document.getElementById('error').style.display = 'block';
                    document.getElementById('error').textContent =
                        'Authentication failed: ' +
                        (data.error_message || 'Unknown error');
                }} else if (data.status === 'expired') {{
                    clearInterval(pollInterval);
                    if (popup && !popup.closed) popup.close();
                    document.getElementById('spinner').style.display = 'none';
                    document.getElementById('status').style.display = 'none';
                    document.getElementById('error').style.display = 'block';
                    document.getElementById('error').textContent =
                        'Session expired. Please try again.';
                }}
            }})
            .catch(function() {{ /* retry on next interval */ }});
    }}, 2000);

    // Timeout — matches server-side BRIDGE_TIMEOUT_SECONDS
    setTimeout(function() {{
        clearInterval(pollInterval);
        document.getElementById('spinner').style.display = 'none';
        document.getElementById('status').style.display = 'none';
        document.getElementById('error').style.display = 'block';
        document.getElementById('error').textContent = 'Login timed out. Please try again.';
    }}, {timeout_ms_json});
}})();
</script>
</body>
</html>"""
        return HTMLResponse(content=bridge_html)

    async def _bridge_poll_handler(self, request: Request) -> JSONResponse:  # noqa: PLR0911
        """JSON endpoint polled by the bridge page JS.

        Forwards the poll to the Alter backend via vault._poll_auth_session_raw.
        When the IDP login completes, stores the IDP JWT and returns the auth
        code to the bridge page so it can redirect to the client.
        """
        pending_code = request.query_params.get("pending", "")
        pending = self._pending_auths.get(pending_code)

        if not pending:
            return JSONResponse(
                {"status": "error", "error_message": "Invalid or expired session"},
                status_code=400,
            )

        # If we already have the IDP JWT, the auth code is ready
        if pending.idp_jwt is not None:
            return JSONResponse({"status": "completed", "code": pending_code})

        # Check timeout
        if time.time() - pending.created_at > BRIDGE_TIMEOUT_SECONDS:
            del self._pending_auths[pending_code]
            return JSONResponse({"status": "expired"})

        # Poll the Alter backend — only swallow transient SDK/network errors
        try:
            poll_data = await self._vault._poll_auth_session_raw(pending.session_token)  # noqa: SLF001
        except AlterSDKError as e:
            logger.warning("Bridge poll failed (transient): %s", e, exc_info=True)
            return JSONResponse({"status": "pending"})

        poll_status = poll_data.get("status")

        if poll_status == "completed":
            user_token = poll_data.get("user_token")
            if not user_token:
                return JSONResponse(
                    {"status": "error", "error_message": "No user token returned"},
                )
            # Store the IDP JWT — the auth code is now ready for exchange
            pending.idp_jwt = user_token
            return JSONResponse({"status": "completed", "code": pending_code})

        if poll_status == "error":
            error_msg = poll_data.get("error_message", "Authentication failed")
            # Clean up
            del self._pending_auths[pending_code]
            return JSONResponse({"status": "error", "error_message": error_msg})

        if poll_status == "expired":
            del self._pending_auths[pending_code]
            return JSONResponse({"status": "expired"})

        # Still pending
        return JSONResponse({"status": "pending"})

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _revoke_internal(
        self,
        access_token_str: str | None = None,
        refresh_token_str: str | None = None,
    ) -> None:
        """Remove a token pair and clean up bidirectional maps."""
        if access_token_str:
            self._access_tokens.pop(access_token_str, None)
            associated_refresh = self._access_to_refresh.pop(access_token_str, None)
            if associated_refresh:
                self._refresh_tokens.pop(associated_refresh, None)
                self._refresh_to_access.pop(associated_refresh, None)

        if refresh_token_str:
            self._refresh_tokens.pop(refresh_token_str, None)
            associated_access = self._refresh_to_access.pop(refresh_token_str, None)
            if associated_access:
                self._access_tokens.pop(associated_access, None)
                self._access_to_refresh.pop(associated_access, None)

    def _sweep_expired(self) -> None:
        """Remove expired entries from all stores (passive eviction).

        Called during authorize(), exchange_authorization_code(), and
        register_client() to prevent unbounded memory growth in
        long-running multi-tenant servers.
        """
        now = time.time()

        # Sweep expired pending auths (keyed by pending_code)
        expired_pending = [
            code
            for code, pa in self._pending_auths.items()
            if now - pa.created_at > BRIDGE_TIMEOUT_SECONDS
        ]
        for code in expired_pending:
            del self._pending_auths[code]

        # Sweep expired access tokens (and their refresh counterparts)
        expired_access = [
            token for token, mapping in self._access_tokens.items() if mapping.expires_at < int(now)
        ]
        for token in expired_access:
            self._revoke_internal(access_token_str=token)

        # Sweep expired refresh tokens (that weren't already cleaned above)
        expired_refresh = [
            token
            for token, mapping in self._refresh_tokens.items()
            if mapping.expires_at < int(now)
        ]
        for token in expired_refresh:
            self._revoke_internal(refresh_token_str=token)

        # Sweep stale clients — registered > 24h ago with no active tokens
        active_client_ids = {m.client_id for m in self._access_tokens.values()}
        active_client_ids.update(m.client_id for m in self._refresh_tokens.values())
        stale_clients = [
            cid
            for cid, registered_at in self._client_registered_at.items()
            if now - registered_at > REFRESH_TOKEN_EXPIRY_SECONDS and cid not in active_client_ids
        ]
        for cid in stale_clients:
            self._clients.pop(cid, None)
            self._client_registered_at.pop(cid, None)
