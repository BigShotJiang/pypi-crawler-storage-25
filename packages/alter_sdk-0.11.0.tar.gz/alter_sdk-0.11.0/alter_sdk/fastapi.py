"""
AlterFastAPI — FastAPI integration for Alter Vault.

Eliminates ContextVar + Bearer extraction boilerplate by providing a
FastAPI dependency that automatically captures the user's JWT from the
Authorization header and makes it available to the SDK's identity
resolution layer.

Usage::

    from alter_sdk.fastapi import AlterFastAPI
    from fastapi import Depends, FastAPI

    alter = AlterFastAPI(api_key="alter_key_...", caller="my-app")
    app = FastAPI()

    @app.post("/chat")
    async def chat(vault = Depends(alter)):
        resp = await vault.request("GET", url, provider="google")
        return resp.json()

    @app.get("/connect")
    async def connect(vault = Depends(alter)):
        session = await vault.create_connect_session(
            allowed_providers=["google"],
        )
        return {"connect_url": session.connect_url}

For MCP integration, use ``alter.auth_provider()``::

    from fastmcp import FastMCP

    auth = alter.auth_provider(providers={"google": GMAIL_SCOPES})
    mcp = FastMCP("Gmail", auth=auth)
"""

from __future__ import annotations

import logging
from contextvars import ContextVar
from typing import Any

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from alter_sdk.client import AlterVault
from alter_sdk.exceptions import AlterSDKError

logger = logging.getLogger(__name__)

# Internal ContextVar — hidden from SDK users. AlterFastAPI.__call__
# sets it per-request; the user_token_getter lambda reads it.
_user_token: ContextVar[str | None] = ContextVar("alter_fastapi_user_token", default=None)

_bearer_scheme = HTTPBearer()


class AlterFastAPI:
    """FastAPI integration for AlterVault.

    Creates a shared :class:`AlterVault` instance with automatic Bearer
    token capture. Use as a FastAPI dependency via ``Depends(alter)``.

    The class is callable — FastAPI's ``Depends()`` invokes ``__call__``
    on each request, which extracts the ``Authorization: Bearer <token>``
    header via ``HTTPBearer`` and stores it in a task-scoped ``ContextVar``
    for the SDK's ``user_token_getter``.

    Args:
        api_key: Alter Vault API key (starts with ``alter_key_``)
        caller: Caller identifier for audit attribution
        **kwargs: Additional keyword arguments passed to :class:`AlterVault`
    """

    def __init__(
        self,
        api_key: str,
        *,
        caller: str | None = None,
        **kwargs: Any,
    ) -> None:
        if "user_token_getter" in kwargs:
            raise AlterSDKError(
                message="Do not pass user_token_getter to AlterFastAPI — "
                "token capture is handled automatically via FastAPI dependency injection.",
            )

        self._vault = AlterVault(
            api_key=api_key,
            caller=caller,
            user_token_getter=lambda: _user_token.get() or "",  # SDK raises AlterSDKError on empty
            **kwargs,
        )

    @property
    def vault(self) -> AlterVault:
        """The underlying :class:`AlterVault` instance."""
        return self._vault

    async def __call__(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),  # noqa: B008
    ) -> AlterVault:
        """FastAPI dependency — extract Bearer token and return vault.

        FastAPI's ``HTTPBearer`` handles header parsing and returns 401
        if the Authorization header is missing or not Bearer-prefixed.
        """
        _user_token.set(credentials.credentials)
        return self._vault

    def set_user_token(self, token: str) -> None:
        """Manually set the user token for the current request context.

        Use this in MCP auth providers or other non-FastAPI paths that
        need to set identity for the same vault instance.
        """
        _user_token.set(token)

    def auth_provider(
        self,
        *,
        base_url: str = "",
        providers: dict[str, list[str]] | None = None,
    ) -> Any:
        """Create an MCP auth provider that auto-captures tokens.

        Returns an :class:`AlterAuthProvider` instance whose
        ``load_access_token`` stores the validated IDP JWT so the shared
        vault instance can resolve identity on subsequent
        ``vault.request()`` calls.

        Args:
            base_url: Public URL where the MCP server is mounted. Required
                      for OAuth metadata discovery (e.g. "http://localhost:8000/mcp").
            providers: Map of provider_id → required scopes for Connect
                       (e.g., ``{"google": ["gmail.readonly"]}``).

        Raises:
            ImportError: If ``alter-sdk[mcp]`` is not installed.
        """
        try:
            from alter_sdk.mcp import AlterAuthProvider
        except ImportError as exc:
            raise ImportError(
                "alter-sdk[mcp] is required for auth_provider(). "
                "Install with: pip install 'alter-sdk[mcp]'",
            ) from exc

        provider = AlterAuthProvider(
            self._vault,
            base_url=base_url,
            providers=providers,
        )
        provider.set_token_callback(self.set_user_token)
        return provider
