"""
Main Alter Vault SDK client.

Provides the AlterVault class for OAuth token management with
zero token exposure — tokens are retrieved and injected automatically,
never returned to the caller.
"""

import asyncio
import contextlib
import hashlib
import hmac as hmac_mod
import json as json_mod
import logging
import os
import re
import secrets
import sys
import time
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, NamedTuple
from urllib.parse import quote
from uuid import UUID

import httpx

from alter_sdk._context import get_current_audit_context
from alter_sdk.exceptions import (
    AlterSDKError,
    AlterValueError,
    BackendError,
    ConnectConfigError,
    ConnectDeniedError,
    ConnectFlowError,
    ConnectTimeoutError,
    CredentialRevokedError,
    GrantDeletedError,
    GrantExpiredError,
    GrantNotFoundError,
    GrantRevokedError,
    NetworkError,
    PolicyViolationError,
    ProviderAPIError,
    ScopeReauthRequiredError,
    TimeoutError,
    TokenRefreshInProgressError,
)
from alter_sdk.models import (
    APICallAuditLog,
    AuthResult,
    ConnectResult,
    ConnectSession,
    GrantInfo,
    GrantListResult,
    RevokeGrantResult,
)
from alter_sdk.providers.enums import CallerType, HttpMethod

logger = logging.getLogger(__name__)

# SDK version — single source of truth is alter_sdk.__version__
# Imported lazily to avoid circular import; set in _sdk_user_agent().
_SDK_USER_AGENT: str | None = None

# Context dict bounds — MUST match
# apps/backend/app/core/middleware/actor_middleware.py exactly. The
# backend silently rejects context payloads that exceed these bounds
# (so audit logs would be missing context entirely). Validating SDK-side
# turns that silent drop into a loud AlterValueError so the caller can
# fix their context shape.
_MAX_CONTEXT_LENGTH = 4096
_MAX_CONTEXT_KEYS = 20
_MAX_CONTEXT_KEY_LENGTH = 64
_MAX_CONTEXT_VALUE_LENGTH = 512


def _validate_and_serialize_context(
    context: "dict[str, str] | None",
) -> "str | None":
    """Validate the SDK contract for the ``context`` dict and return JSON.

    The contract is ``dict[str, str]`` with bounded length, key count,
    key length, value length, and total serialized size. Mirrors the
    backend's middleware exactly so the backend will accept the result.

    Returns ``None`` if ``context`` is None or empty (no header sent).

    Raises:
        AlterValueError: If the context fails any contract check.
    """
    if context is None:
        return None
    if not isinstance(context, dict):
        raise AlterValueError(
            f"context must be a dict[str, str], got {type(context).__name__}",
        )
    if not context:
        return None
    if len(context) > _MAX_CONTEXT_KEYS:
        raise AlterValueError(
            f"context has too many keys ({len(context)}); max is {_MAX_CONTEXT_KEYS}",
        )
    for k, v in context.items():
        if not isinstance(k, str):
            raise AlterValueError(
                f"context keys must be str, got {type(k).__name__}",
            )
        if len(k) > _MAX_CONTEXT_KEY_LENGTH:
            raise AlterValueError(
                f"context key {k[:32]!r} exceeds max length "
                f"({len(k)} > {_MAX_CONTEXT_KEY_LENGTH})",
            )
        if not isinstance(v, str):
            raise AlterValueError(
                f"context value for key {k!r} must be str, got {type(v).__name__}",
            )
        if len(v) > _MAX_CONTEXT_VALUE_LENGTH:
            raise AlterValueError(
                f"context value for key {k!r} exceeds max length "
                f"({len(v)} > {_MAX_CONTEXT_VALUE_LENGTH})",
            )
    try:
        encoded = json_mod.dumps(context, separators=(",", ":"))
    except (TypeError, ValueError) as e:
        raise AlterValueError(
            f"context could not be serialized to JSON: {e}",
        ) from e
    if len(encoded) > _MAX_CONTEXT_LENGTH:
        raise AlterValueError(
            f"context serialized to {len(encoded)} bytes, exceeds "
            f"{_MAX_CONTEXT_LENGTH} byte limit",
        )
    return encoded


def _sdk_user_agent() -> str:
    """Return the SDK User-Agent string, cached after first call."""
    global _SDK_USER_AGENT  # noqa: PLW0603
    if _SDK_USER_AGENT is None:
        from alter_sdk import __version__

        _SDK_USER_AGENT = f"alter-sdk-python/{__version__}"
    return _SDK_USER_AGENT


class _TokenResult(NamedTuple):
    """Internal result from __get_token — replaces a bare 9-element tuple."""

    injection_header: str
    header_value: str
    grant_id: str
    provider_id: str | None
    injection_format: str
    additional_credentials: dict[str, str] | None
    access_token: str
    additional_injections: list[dict[str, str]] | None
    scope_mismatch: bool


# HTTP status codes as constants
HTTP_FORBIDDEN = 403
HTTP_NOT_FOUND = 404
HTTP_CONFLICT = 409
HTTP_GONE = 410
HTTP_BAD_REQUEST = 400
HTTP_UNAUTHORIZED = 401
HTTP_BAD_GATEWAY = 502
HTTP_INTERNAL_SERVER_ERROR = 500
HTTP_SERVICE_UNAVAILABLE = 503

# Request/Response size limits
MAX_BODY_SIZE_BYTES = 10000  # 10KB max for audit log bodies
HTTP_CLIENT_ERROR_START = 400  # HTTP status codes >= 400 are errors

# Actor header validation
MAX_ACTOR_STRING_LENGTH = 255  # Max length for actor string parameters
MAX_CONTEXT_HEADER_SIZE = 4096  # Max size for X-Alter-Context header
_SAFE_HEADER_PATTERN = re.compile(r"^[\x20-\x7E]+$")  # Printable ASCII only

# URL scheme validation
_ALLOWED_URL_SCHEMES = ("https://", "http://")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SECURITY LAYER 4: Module-private mutable state storage.
#
# HTTP clients, cached actor ID, closed flag, and audit tasks are stored
# in this module-level dict instead of on AlterVault instances. This
# prevents rogue agents from using object.__setattr__() to tamper with
# HTTP clients or other critical mutable state.
#
# Key: id(instance)  Value: dict with alter_client, provider_client, etc.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_THIS_FILE = str(Path(__file__).resolve())
# NOTE: _instance_state is importable by any code that does
# `from alter_sdk.client import _instance_state`. Full mitigation
# (closure-based API key injection) is too invasive for this pass.
# The __getattribute__ guard + leading-underscore convention is the
# accepted bar; the primary secrets (HTTP clients) are keyed by
# id(instance) which is ephemeral.
_instance_state: dict[int, dict[str, Any]] = {}


class AlterVault:
    """
    Main SDK class for Alter Vault OAuth token management.

    This class handles:
    - Executing API requests to any OAuth provider with automatic token injection
    - Audit logging of API calls
    - Actor tracking for AI agents and backend services

    Tokens are retrieved and injected automatically — never exposed to callers.

    Example:
        ```python
        from alter_sdk import AlterVault, Provider, HttpMethod

        vault = AlterVault(api_key="alter_key_...")

        # Make API request (token injected automatically)
        response = await vault.request(
            HttpMethod.GET,
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
            grant_id="grant-uuid-here",
        )
        events = response.json()

        # Clean up
        await vault.close()
        ```
    """

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SECURITY LAYER 1: Prevent subclassing
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def __init_subclass__(cls, **kwargs: Any) -> None:
        raise TypeError(
            "AlterVault cannot be subclassed. This restriction prevents security bypasses.",
        )

    # Only immutable configuration on the instance.
    # HTTP clients and mutable state live in _instance_state (module-private).
    __slots__ = (
        "base_url",
        "_caller",
        "_caller_type",
        "_initialized",
    )

    def __init__(
        self,
        api_key: str,
        *,
        timeout: float = 30.0,
        caller: str | None = None,
        caller_type: CallerType | str = CallerType.AGENT,
        # JWT Identity Resolution (optional)
        user_token_getter: Callable[[], str | Awaitable[str]] | None = None,
    ) -> None:
        """
        Initialize Alter Vault client.

        Args:
            api_key: Alter Vault API key (starts with "alter_key_")
            timeout: HTTP request timeout in seconds
            caller: Caller identifier for audit attribution (e.g., "email-assistant", "cursor")
            caller_type: Type of caller — ``CallerType.AGENT`` (default, shows in
                Agents tab) or ``CallerType.SERVICE`` (backend infrastructure,
                excluded from Agents tab). Accepts enum or plain string.
            user_token_getter: Async/sync callable that returns a user JWT for identity resolution

        Raises:
            AlterSDKError: If api_key is invalid
            AlterValueError: If caller_type is not a valid CallerType value
        """
        # Validate inputs
        if user_token_getter is not None and not callable(user_token_getter):
            raise AlterSDKError(message="user_token_getter must be callable")
        self._validate_init_params(api_key)
        if caller is not None:
            self._validate_actor_string(caller, "caller")

        # Validate and normalize caller_type
        try:
            resolved_caller_type = CallerType(caller_type)
        except ValueError as e:
            raise AlterValueError(
                f"caller_type must be one of: {', '.join(ct.value for ct in CallerType)}. "
                f"Got: {caller_type!r}",
            ) from e

        # SECURITY LAYER 3: API key string is NOT stored as instance attribute.
        self.base_url = os.environ.get(
            "ALTER_BASE_URL",
            "https://backend.alterauth.com",
        ).rstrip("/")
        self._validate_base_url(self.base_url)

        # Caller identifier and type (immutable on instance)
        self._caller = caller
        self._caller_type = resolved_caller_type

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # HTTP CLIENT ARCHITECTURE - TWO SEPARATE CLIENTS FOR SECURITY
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        #
        # We maintain TWO separate HTTP clients to prevent credential leakage:
        #
        # alter_client  → Alter backend (has x-api-key + actor headers)
        # provider_client → External APIs (NO secrets, Bearer token per-request)
        #
        # SECURITY LAYER 4: Clients stored in module-private _instance_state,
        # NOT on the instance. This prevents object.__setattr__() attacks.

        # Shared connection pool settings for performance
        try:
            import h2  # type: ignore  # noqa: F401

            _http2_enabled = True
        except Exception:
            _http2_enabled = False

        _shared_limits = httpx.Limits(
            max_keepalive_connections=20,
            max_connections=100,
            keepalive_expiry=30.0,
        )

        user_agent = _sdk_user_agent()

        # CLIENT 1: Alter Backend Client
        # Auth: x-api-key + X-Alter-* actor headers
        # Target: Alter Vault backend only
        # SECURITY LAYER 3: api_key used here then discarded (not stored on self)
        alter_headers = self.__build_alter_client_headers(api_key)

        alter_client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=alter_headers,
            timeout=timeout,
            limits=_shared_limits,
            http2=_http2_enabled,
        )

        # CLIENT 2: Provider API Client
        # Auth: OAuth Bearer token (added per-request)
        # Target: External APIs (Google, Stripe, GitHub, etc.)
        # SECURITY: NO x-api-key header!
        try:
            provider_client = httpx.AsyncClient(
                headers={
                    "User-Agent": user_agent,
                },
                timeout=timeout,
                limits=_shared_limits,
                http2=_http2_enabled,
            )
        except Exception:
            # Best-effort cleanup if provider client creation fails.
            # If an event loop is running, schedule async cleanup.
            # Otherwise, __del__ will handle cleanup when GC runs.
            with contextlib.suppress(Exception):
                loop = asyncio.get_running_loop()
                _task = loop.create_task(alter_client.aclose())  # noqa: RUF006
            raise

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # SECURITY LAYER 4: Store HTTP clients and mutable state in module-private
        # dict, NOT on instance. This prevents rogue agents from using
        # object.__setattr__() to replace HTTP clients or tamper with state.
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        _instance_state[id(self)] = {
            "alter_client": alter_client,
            "provider_client": provider_client,
            "cached_actor_id": None,
            "closed": False,
            "audit_tasks": set(),
            # HMAC signing: derive a purpose-specific signing key from the API key
            # using AWS SigV4 pattern: HMAC-SHA256(api_key, "alter-signing-v1").
            # This provides cryptographic separation between authentication and signing.
            "hmac_key": hmac_mod.new(
                api_key.encode("utf-8"),
                b"alter-signing-v1",
                hashlib.sha256,
            ).digest(),
            # JWT Identity Resolution: callable that returns user token
            "user_token_getter": user_token_getter,
        }

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # SECURITY LAYER 2: Freeze instance — must be LAST in __init__
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        self._initialized = True

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SECURITY LAYER 5: Attribute access guard for name-mangled methods.
    #
    # Python name-mangling transforms self.__method() to
    # self._AlterVault__method() at compile time. External code can bypass
    # this by calling vault._AlterVault__method() directly.
    #
    # This __getattribute__ guard intercepts such accesses and only allows
    # them from within this module (same file). External callers get
    # AttributeError.
    #
    # Bypass vectors (accepted risk):
    # - object.__getattribute__(vault, name) still works
    # - Python's compile(code, _THIS_FILE, "exec") can forge co_filename
    # Both require deliberate effort and raise the bar significantly.
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def __getattribute__(self, name: str) -> Any:
        if name.startswith("_AlterVault__"):
            frame = sys._getframe(1)  # noqa: SLF001
            caller_file = str(Path(frame.f_code.co_filename).resolve())
            if caller_file != _THIS_FILE:
                raise AttributeError(
                    f"Access to internal attribute '{name}' is restricted. "
                    "Use request() for API calls.",
                )
        return super().__getattribute__(name)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SECURITY LAYER 2: Prevent attribute mutation after init
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def __setattr__(self, name: str, value: Any) -> None:
        if getattr(self, "_initialized", False):
            raise AttributeError(
                f"AlterVault instances are immutable: cannot set '{name}'",
            )
        super().__setattr__(name, value)

    def __delattr__(self, name: str) -> None:
        raise AttributeError(
            f"AlterVault instances are immutable: cannot delete '{name}'",
        )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Module-private state accessor (name-mangled + __getattribute__ guarded)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    @property
    def __state(self) -> dict[str, Any]:
        """Access module-private mutable state for this instance."""
        state = _instance_state.get(id(self))
        if state is None:
            raise AlterSDKError(
                "SDK instance has been closed or corrupted. Create a new AlterVault instance.",
            )
        return state

    def __del__(self) -> None:
        """Clean up module-private state and HTTP clients on garbage collection."""
        state = _instance_state.pop(id(self), None)
        if state and not state.get("closed"):
            # Best-effort: schedule async client cleanup if an event loop is running.
            # If no loop is running (e.g., at interpreter shutdown), clients are
            # abandoned — their underlying connections will be closed by the OS.
            with contextlib.suppress(Exception):
                loop = asyncio.get_running_loop()
                _t1 = loop.create_task(state["alter_client"].aclose())  # noqa: RUF006
                _t2 = loop.create_task(state["provider_client"].aclose())  # noqa: RUF006

    @staticmethod
    def _validate_actor_string(
        value: str | None,
        name: str,
        max_length: int = MAX_ACTOR_STRING_LENGTH,
    ) -> None:
        """Validate an actor string parameter for length and safe characters."""
        if value is None:
            return
        if len(value) > max_length:
            raise AlterSDKError(
                f"{name} exceeds max length ({max_length}): {len(value)}",
            )
        if not _SAFE_HEADER_PATTERN.match(value):
            raise AlterSDKError(
                f"{name} contains invalid characters (only printable ASCII allowed)",
            )

    @staticmethod
    def _validate_init_params(
        api_key: str,
    ) -> None:
        """Validate constructor parameters. Raises AlterSDKError on invalid input."""
        if not api_key:
            raise AlterSDKError("api_key is required")
        if not api_key.startswith("alter_key_"):
            raise AlterSDKError("api_key must start with 'alter_key_'")

    @staticmethod
    def _validate_base_url(base_url: str) -> None:
        """Validate the resolved Alter backend base URL.

        - Must be a non-empty string
        - Must use https:// in production
        - http:// is only permitted for localhost / 127.0.0.1 (dev convenience);
          in that case we log a warning so the reduced safety posture is
          visible in logs
        - Any other scheme (file://, javascript:, data:, etc.) is rejected to
          prevent supply-chain URL redirect / scheme-smuggling attacks when
          ALTER_BASE_URL is sourced from an environment or config system.
        """
        if not base_url or not isinstance(base_url, str):
            raise AlterSDKError("ALTER_BASE_URL must be a non-empty string")
        lowered = base_url.lower()
        if lowered.startswith("https://"):
            return
        if lowered.startswith("http://"):
            # Permit http only for local development loopback addresses.
            host_start = len("http://")
            host = lowered[host_start:].split("/", 1)[0].split(":", 1)[0]
            if host in ("localhost", "127.0.0.1", "::1"):
                logger.warning(
                    "ALTER_BASE_URL uses http://%s; this is only safe for local development",
                    host,
                )
                return
            raise AlterSDKError(
                "ALTER_BASE_URL must use https:// in production "
                "(http:// is only permitted for localhost)",
            )
        raise AlterSDKError(
            f"ALTER_BASE_URL must start with https:// (got scheme in {base_url[:32]!r})",
        )

    def __build_alter_client_headers(self, api_key: str) -> dict[str, str]:
        """
        Build default headers for the Alter backend HTTP client.

        Includes x-api-key for authentication and X-Alter-Caller header
        for actor tracking (if configured). These headers are only sent to
        the Alter backend, never to external providers.

        SECURITY: api_key is passed as parameter, NOT read from self.
        """
        headers: dict[str, str] = {
            "x-api-key": api_key,
            "User-Agent": _sdk_user_agent(),
        }

        # Caller identity headers
        if self._caller:
            headers["X-Alter-Caller"] = self._caller
            headers["X-Alter-Caller-Type"] = self._caller_type.value

        return headers

    def __compute_hmac_headers(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
    ) -> dict[str, str]:
        """
        Compute HMAC-SHA256 signature headers for an Alter backend request.

        String-to-sign format: METHOD\\nPATH_WITH_SORTED_QUERY\\nTIMESTAMP\\nNONCE\\nCONTENT_HASH

        The path should include sorted query parameters if present (e.g. "/sdk/endpoint?a=1&b=2").
        Currently all SDK→backend calls are POSTs without query params, so the path is clean.

        Returns dict with X-Alter-Timestamp, X-Alter-Nonce, X-Alter-Content-SHA256,
        and X-Alter-Signature headers.
        """
        state = self.__state
        hmac_key: bytes = state["hmac_key"]

        timestamp = str(int(time.time()))
        nonce = secrets.token_hex(16)
        content_hash = hashlib.sha256(body or b"").hexdigest()
        string_to_sign = f"{method.upper()}\n{path}\n{timestamp}\n{nonce}\n{content_hash}"

        signature = hmac_mod.new(
            hmac_key,
            string_to_sign.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        return {
            "X-Alter-Timestamp": timestamp,
            "X-Alter-Nonce": nonce,
            "X-Alter-Content-SHA256": content_hash,
            "X-Alter-Signature": signature,
        }

    def __get_actor_request_headers(
        self,
        context: dict[str, str] | None = None,
    ) -> dict[str, str]:
        """
        Build per-request headers for actor tracking and context.

        Includes cached actor_id (for fast path) and JSON-encoded context.
        """
        headers: dict[str, str] = {}

        # Include cached actor_id for fast path (skip DB registration)
        state = self.__state
        cached_actor_id = state["cached_actor_id"]
        if cached_actor_id:
            headers["X-Alter-Actor-ID"] = cached_actor_id

        # Context header (JSON-encoded dict). Validation runs SDK-side so
        # the caller gets a loud AlterValueError instead of the backend
        # silently dropping the context and producing audit logs without
        # caller-supplied metadata.
        context_json = _validate_and_serialize_context(context)
        if context_json is not None:
            headers["X-Alter-Context"] = context_json

        return headers

    def __cache_actor_id_from_response(self, response: httpx.Response) -> None:
        """
        Cache actor_id from response header for subsequent requests.

        The backend returns X-Alter-Actor-ID after registering the actor.
        SDK caches this to include in future requests, allowing the backend
        to skip database lookups (fast path).
        """
        actor_id = response.headers.get("X-Alter-Actor-ID")
        state = self.__state
        if actor_id and not state["cached_actor_id"]:
            try:
                UUID(actor_id)
            except ValueError:
                logger.warning(
                    "Invalid actor_id in response header (not a UUID), ignoring: %s",
                    actor_id,
                )
                return
            state["cached_actor_id"] = actor_id
            logger.debug("Cached actor_id from backend: %s", actor_id)
        elif actor_id and state["cached_actor_id"] and actor_id != state["cached_actor_id"]:
            logger.warning(
                "Backend returned different actor_id (%s) than cached (%s), ignoring",
                actor_id,
                state["cached_actor_id"],
            )

    @staticmethod
    def _safe_parse_json(response: httpx.Response) -> dict[str, Any]:
        """Parse JSON from response, returning empty dict on failure.

        FastAPI wraps HTTPException.detail in ``{"detail": ...}``.  When the
        inner detail is a dict we unwrap it so callers can access error fields
        (``error``, ``message``, ``details``) directly.
        """
        try:
            data: dict[str, Any] = response.json()
        except Exception:
            return {"message": response.text[:500] if response.text else "Unknown error"}
        # Unwrap FastAPI HTTPException envelope
        if "detail" in data and isinstance(data["detail"], dict):
            return data["detail"]
        return data

    def _raise_grant_expired(self, error_data: dict[str, Any]) -> None:
        """Raise GrantExpiredError from error data."""
        raise GrantExpiredError(
            message=error_data.get("message", "Grant expired per TTL policy"),
            details=error_data.get("details", {}),
        )

    def _raise_policy_violation(self, error_data: dict[str, Any]) -> None:
        """Raise PolicyViolationError from error data."""
        raise PolicyViolationError(
            message=error_data.get("message", "Access denied by policy"),
            policy_error=error_data.get("error"),
            details=error_data.get("details", {}),
        )

    def _raise_grant_deleted(self, error_data: dict[str, Any]) -> None:
        """Raise GrantDeletedError from error data."""
        default_msg = "Grant has been deleted. A new grant_id will be issued on re-authorization."
        raise GrantDeletedError(
            message=error_data.get("message", default_msg),
            details=error_data,
        )

    def _raise_grant_not_found(self, error_data: dict[str, Any]) -> None:
        """Raise GrantNotFoundError from error data."""
        raise GrantNotFoundError(
            message=error_data.get(
                "message",
                "OAuth grant not found for the given grant_id",
            ),
            details=error_data,
        )

    def _raise_grant_revoked(self, error_data: dict[str, Any]) -> None:
        """Raise GrantRevokedError from error data."""
        raise GrantRevokedError(
            message=error_data.get(
                "message",
                "Grant has been revoked. User must re-authorize.",
            ),
            grant_id=error_data.get("grant_id"),
            details=error_data,
        )

    def _raise_credential_revoked(self, error_data: dict[str, Any]) -> None:
        """Raise CredentialRevokedError from error data."""
        raise CredentialRevokedError(
            message=error_data.get(
                "message",
                "Underlying OAuth connection has been revoked. User must re-authorize.",
            ),
            grant_id=error_data.get("grant_id"),
            details=error_data,
        )

    def _handle_forbidden(self, error_data: dict[str, Any]) -> None:
        """Handle HTTP 403 responses — always raises."""
        error_code = error_data.get("error")
        if error_code == "grant_expired":
            self._raise_grant_expired(error_data)
        if error_code == "grant_revoked":
            self._raise_grant_revoked(error_data)
        if error_code == "credential_revoked":
            self._raise_credential_revoked(error_data)
        if error_code == "scope_mismatch":
            details = error_data.get("details", {})
            raise ScopeReauthRequiredError(
                message=error_data.get(
                    "message",
                    "Grant is missing required scopes",
                ),
                grant_id=details.get("grant_id"),
                provider_id=details.get("provider_id"),
                status_code=HTTP_FORBIDDEN,
                details=details,
            )
        self._raise_policy_violation(error_data)

    def _handle_error_response(self, response: httpx.Response) -> None:
        """
        Handle HTTP error responses from backend.

        Raises appropriate exceptions based on status code.
        Uses _safe_parse_json to avoid crashes on non-JSON responses.
        """
        if response.status_code == HTTP_FORBIDDEN:
            self._handle_forbidden(self._safe_parse_json(response))

        if response.status_code == HTTP_CONFLICT:
            error_data = self._safe_parse_json(response)
            if error_data.get("error") == "token_refresh_in_progress":
                raise TokenRefreshInProgressError(
                    message=error_data.get(
                        "message",
                        "Token refresh in progress. Retry after a short delay.",
                    ),
                    grant_id=error_data.get("grant_id"),
                    details=error_data,
                )
            raise BackendError(
                message=error_data.get("message", f"Conflict (HTTP {response.status_code})"),
                details=error_data,
            )

        if response.status_code == HTTP_GONE:
            error_data = self._safe_parse_json(response)
            self._raise_grant_deleted(error_data)

        if response.status_code == HTTP_NOT_FOUND:
            error_data = self._safe_parse_json(response)
            self._raise_grant_not_found(error_data)

        if response.status_code in (HTTP_BAD_REQUEST, HTTP_BAD_GATEWAY):
            error_data = self._safe_parse_json(response)
            error_code = error_data.get("error")
            if error_code == "grant_revoked":
                self._raise_grant_revoked(error_data)
            if error_code == "credential_revoked":
                self._raise_credential_revoked(error_data)
            raise BackendError(
                message=error_data.get("message", f"Backend error {response.status_code}"),
                details=error_data,
            )

        if response.status_code == HTTP_UNAUTHORIZED:
            error_data = self._safe_parse_json(response)
            raise BackendError(
                message=error_data.get("message", "Unauthorized — check your API key"),
                details=error_data,
            )

        if response.status_code in (HTTP_INTERNAL_SERVER_ERROR, HTTP_SERVICE_UNAVAILABLE):
            error_data = self._safe_parse_json(response)
            raise BackendError(
                message=error_data.get(
                    "message",
                    f"Backend unavailable (HTTP {response.status_code})",
                ),
                details=error_data,
            )

        # Catch-all for any other error status codes
        if response.status_code >= HTTP_CLIENT_ERROR_START:
            error_data = self._safe_parse_json(response)
            raise BackendError(
                message=error_data.get(
                    "message",
                    f"Unexpected backend error (HTTP {response.status_code})",
                ),
                details=error_data,
            )

    # INTERNAL — name-mangled, protected by __getattribute__ guard.
    # Returns enriched tuple; token exists only as a transient local variable,
    # never as a named attribute.
    async def __get_user_token(self) -> str:
        """Get user token from user_token_getter (sync or async callable)."""
        state = self.__state
        getter = state.get("user_token_getter")
        if getter is None:
            raise AlterSDKError(
                message="user_token_getter is required for provider-based resolution. "
                "Pass user_token_getter to AlterVault constructor.",
            )
        result = getter()
        # Support both sync and async callables
        if asyncio.iscoroutine(result) or asyncio.isfuture(result):
            result = await result
        if not isinstance(result, str) or not result:
            raise AlterSDKError(
                message="user_token_getter must return a non-empty string",
            )
        return result

    async def __get_token(
        self,
        grant_id: str | None = None,
        reason: str | None = None,
        request_metadata: dict[str, str] | None = None,
        context: dict[str, str] | None = None,
        provider: str | None = None,
        account: str | None = None,
    ) -> _TokenResult:
        actor_headers = self.__get_actor_request_headers(
            context=context,
        )

        state = self.__state
        alter_client = state["alter_client"]

        sdk_path = "/sdk/token"

        if provider is not None:
            # Identity resolution mode
            user_token = await self.__get_user_token()
            request_body: dict[str, Any] = {
                "provider_id": provider,
                "user_token": user_token,
                "reason": reason,
                "request": request_metadata,
            }
            if account:
                request_body["account"] = account
        else:
            request_body = {
                "grant_id": grant_id,
                "reason": reason,
                "request": request_metadata,
            }
        # Serialize once with compact separators to ensure the bytes we sign
        # match exactly what httpx sends (httpx uses compact separators internally).
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            GrantNotFoundError,
            GrantRevokedError,
            CredentialRevokedError,
            ScopeReauthRequiredError,
            BackendError,
        ):
            raise

        except Exception as e:
            raise BackendError(
                message=f"Failed to retrieve token: {e}",
                details={"grant_id": grant_id, "error": str(e)},
            ) from e
        else:
            token_data = response.json()
            # SECURITY: Extract only what's needed. Token exists only as local variable.
            # No TokenResponse object is created — no .access_token attribute to discover.
            access_token = token_data["access_token"]
            resp_grant_id = str(token_data["grant_id"])
            resp_provider_id = token_data.get("provider_id") or None

            # Dynamic injection metadata — supports API keys, bot tokens, etc.
            injection_header = token_data.get("injection_header", "Authorization")
            injection_format = token_data.get("injection_format", "Bearer {token}")

            # Validate backend-supplied header name (defense-in-depth against CRLF)
            # Must start with a letter, then alphanumeric + hyphens (matches Node SDK)
            if not injection_header or not re.match(r"^[A-Za-z][A-Za-z0-9-]*$", injection_header):
                raise BackendError(
                    message="Backend returned an invalid injection_header",
                    details={"grant_id": str(grant_id)},
                )

            # Validate injection_format for CRLF (defense-in-depth)
            if any(c in injection_format for c in ("\r", "\n", "\x00")):
                raise BackendError(
                    message="Backend returned invalid injection_format "
                    "(contains control characters)",
                    details={"grant_id": str(grant_id)},
                )

            # Extract additional_credentials for multi-part auth (e.g. AWS SigV4)
            additional_credentials = token_data.get("additional_credentials")

            # Extract additional injection rules for multi-header / query param auth
            additional_injections = token_data.get("additional_injections")

            # Extract scope_mismatch and return it in the tuple so it flows
            # through the call stack — avoids per-instance shared state that
            # would be racy under concurrent async requests on the same client.
            scope_mismatch = token_data.get("scope_mismatch", False)

            # Replace only first occurrence to prevent double token leakage
            header_value = injection_format.replace("{token}", access_token, 1)

            logger.debug("Retrieved token for grant %s", grant_id)
            return _TokenResult(
                injection_header=injection_header,
                header_value=header_value,
                grant_id=resp_grant_id,
                provider_id=resp_provider_id,
                injection_format=injection_format,
                additional_credentials=additional_credentials,
                access_token=access_token,
                additional_injections=additional_injections,
                scope_mismatch=scope_mismatch,
            )

    async def __log_api_call(
        self,
        grant_id: UUID,
        provider_id: str,
        method: str,
        url: str,
        request_headers: dict[str, str] | None = None,
        request_body: Any | None = None,
        response_status: int = 0,
        response_headers: dict[str, str] | None = None,
        response_body: Any | None = None,
        latency_ms: int = 0,
        reason: str | None = None,
        context: dict[str, str] | None = None,
    ) -> None:
        """
        Log an API call to the backend audit endpoint (INTERNAL).

        This method NEVER raises exceptions to avoid crashing the application
        if audit logging fails.
        """
        try:
            audit_log = APICallAuditLog(
                grant_id=grant_id,
                provider_id=provider_id,
                method=method,
                url=url,
                request_headers=request_headers,
                request_body=request_body,
                response_status=response_status,
                response_headers=response_headers,
                response_body=response_body,
                latency_ms=latency_ms,
                reason=reason,
                context=context,
            )

            sanitized = audit_log.sanitize()

            actor_headers = self.__get_actor_request_headers(
                context=context,
            )
            sdk_path = "/sdk/oauth/audit/api-call"
            body_bytes = json_mod.dumps(sanitized, separators=(",", ":")).encode("utf-8")
            hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
            merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

            state = self.__state
            alter_client = state["alter_client"]
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            response.raise_for_status()

            logger.debug("Logged API call to %s", url)

        except Exception as e:
            # NEVER raise - log warning and continue
            logger.warning("Failed to log API call (non-fatal): %s", e)

    @staticmethod
    def _safe_decode_body(body: bytes, max_bytes: int = MAX_BODY_SIZE_BYTES) -> str:
        """Decode raw bytes for audit logging, truncating large payloads."""
        if len(body) == 0:
            return ""
        if len(body) > max_bytes:
            return f"<binary body: {len(body)} bytes>"
        try:
            return body.decode("utf-8")
        except (UnicodeDecodeError, ValueError):
            return f"<binary body: {len(body)} bytes>"

    @staticmethod
    def _safe_response_body(response: httpx.Response, max_bytes: int = MAX_BODY_SIZE_BYTES) -> str:
        """Extract response body for audit logging without decoding large/binary payloads."""
        content_length = len(response.content)
        if content_length == 0:
            return ""
        # Skip decode for large responses (e.g. binary file downloads)
        if content_length > max_bytes:
            return f"<response too large: {content_length} bytes>"
        try:
            text = response.text
        except Exception:
            return f"<binary response: {content_length} bytes>"
        if len(text) > max_bytes:
            return text[:max_bytes] + "..."
        return text

    def __schedule_audit_log(
        self,
        **kwargs: Any,
    ) -> None:
        """Schedule audit logging as a background task (true fire-and-forget)."""
        try:
            task = asyncio.create_task(self.__log_api_call(**kwargs))
            state = self.__state
            state["audit_tasks"].add(task)
            task.add_done_callback(state["audit_tasks"].discard)
        except Exception:
            # Audit logging is non-fatal — never crash the SDK for telemetry failures.
            pass

    @staticmethod
    def _resolve_injection_value(
        value_source: str,
        access_token: str,
        additional_creds: dict[str, str] | None,
    ) -> str | None:
        """Resolve a value_source to the actual value for injection.

        Args:
            value_source: "token" or "additional_credentials.<field>"
            access_token: The main credential value
            additional_creds: Additional credentials from vault

        Returns:
            The resolved value, or None if not available.
        """
        if value_source == "token":
            return access_token
        if value_source.startswith("additional_credentials."):
            field = value_source[len("additional_credentials.") :]
            if additional_creds and field in additional_creds:
                return additional_creds[field]
            return None
        return None

    @staticmethod
    def _apply_additional_injections(
        rules: list[dict[str, str]],
        raw_access_token: str,
        additional_creds: dict[str, str] | None,
        request_headers: dict[str, str],
        query_params: dict[str, Any] | None,
    ) -> tuple[dict[str, str], dict[str, Any] | None]:
        """Apply additional injection rules to headers and query params."""
        for rule in rules:
            value = AlterVault._resolve_injection_value(
                rule["value_source"],
                raw_access_token,
                additional_creds,
            )
            if not value:
                continue
            # Defense-in-depth: validate key format
            if not re.match(r"^[A-Za-z][A-Za-z0-9\-_]*$", rule["key"]):
                continue
            if rule["target"] == "header":
                request_headers[rule["key"]] = value
            elif rule["target"] == "query_param":
                query_params = {**(query_params or {}), rule["key"]: value}
        return request_headers, query_params

    @staticmethod
    def _build_audit_headers(
        request_headers: dict[str, str],
        header_name: str,
        is_sigv4: bool,
        additional_injections: list[dict[str, str]] | None,
    ) -> dict[str, str]:
        """Strip injected credential headers before passing to audit log."""
        _sigv4_sensitive = {
            "authorization",
            "x-amz-date",
            "x-amz-content-sha256",
            "x-amz-security-token",
        }
        strip_headers = _sigv4_sensitive if is_sigv4 else {header_name.lower()}
        if additional_injections and not is_sigv4:
            for rule in additional_injections:
                if rule["target"] == "header":
                    strip_headers.add(rule["key"].lower())
        return {k: v for k, v in request_headers.items() if k.lower() not in strip_headers}

    @staticmethod
    def _build_request_headers(
        *,
        extra_headers: dict[str, str] | None,
        header_name: str,
        header_value: str,
        raw_injection_format: str,
        additional_creds: dict[str, str] | None,
        raw_access_token: str,
        method_str: str,
        url: str,
        json: dict[str, Any] | None,
        body: bytes | None = None,
    ) -> tuple[dict[str, str], bytes | None, bool]:
        """Build request headers with credential injection.

        Returns (headers, sigv4_body_bytes, is_sigv4).
        """
        request_headers = extra_headers.copy() if extra_headers else {}
        sigv4_body_bytes: bytes | None = None

        is_sigv4 = (
            raw_injection_format.startswith("AWS4-HMAC-SHA256") and additional_creds is not None
        )
        if is_sigv4:
            if additional_creds is None:
                raise BackendError(
                    message="AWS SigV4 credential missing additional_credentials from backend.",
                )
            from alter_sdk._aws_sig_v4 import sign_aws_request

            access_key_id = raw_access_token
            if body is not None:
                sigv4_body_bytes = body
            elif json is not None:
                sigv4_body_bytes = json_mod.dumps(json).encode("utf-8")
                request_headers.setdefault("Content-Type", "application/json")

            secret_key = additional_creds.get("secret_key")
            if not secret_key:
                raise BackendError(
                    message="AWS SigV4 credential is missing secret_key in additional_credentials. "
                    "Re-store the credential with both Access Key ID and Secret Access Key.",
                )
            aws_headers = sign_aws_request(
                method=method_str,
                url=url,
                headers=request_headers,
                body=sigv4_body_bytes,
                access_key_id=access_key_id,
                secret_key=secret_key,
                region=additional_creds.get("region"),
                service=additional_creds.get("service"),
            )
            request_headers.update(aws_headers)
        else:
            header_name_lower = header_name.lower()
            if extra_headers and any(k.lower() == header_name_lower for k in extra_headers):
                logger.warning(
                    "extra_headers contains '%s' which will be overwritten "
                    "with the auto-injected credential",
                    header_name,
                )
            request_headers[header_name] = header_value

        request_headers.setdefault("User-Agent", _sdk_user_agent())
        return request_headers, sigv4_body_bytes, is_sigv4

    async def request(
        self,
        method: HttpMethod | str,
        url: str,
        *,
        grant_id: str | None = None,
        provider: str | None = None,
        account: str | None = None,
        json: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        query_params: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        reason: str | None = None,
        context: dict[str, str] | None = None,
        scope: list[str] | None = None,
        constraints: dict[str, Any] | None = None,
        body: bytes | None = None,
    ) -> httpx.Response:
        """
        Execute an HTTP request to a provider API with automatic token injection.

        Supports two resolution modes:
        1. Direct: vault.request(HttpMethod.GET, "https://...", grant_id="grant-id")
        2. Identity: vault.request(HttpMethod.GET, "https://...", provider="google")

        Identity mode requires user_token_getter configured in constructor.

        This is the single entry point for all provider API calls. The SDK:
        1. Fetches an OAuth token from Alter backend (never exposed)
        2. Injects the token as a Bearer header
        3. Calls the provider API
        4. Logs the call for audit (fire-and-forget, always enabled)
        5. Returns the raw response

        Audit context resolution: if ``context`` is ``None``, the SDK uses the
        ambient audit context set by a framework integration decorator (e.g.
        ``@alter.tool()`` or ``@alter_tool()``) on the current asyncio Task.
        Passing ``context=`` explicitly always overrides the ambient value.

        Code-level policy (``scope`` and ``constraints``) is a reserved surface
        — the backend does not yet enforce it. Passing a non-None value for
        either parameter raises ``NotImplementedError``. The parameter is
        exposed so callers can adopt the final API shape without breakage
        once backend enforcement lands.
        """
        # Code-level policy is a reserved SDK surface pending backend
        # enforcement. Raise loudly so callers don't silently assume their
        # restrictions are being honored.
        if scope is not None:
            raise AlterValueError(
                "scope= is reserved for a future release — the backend does "
                "not currently enforce code-level scope restrictions. Pass "
                "scope=None (or omit) for now.",
            )
        if constraints is not None:
            raise AlterValueError(
                "constraints= is reserved for a future release — the backend "
                "does not currently enforce code-level constraint restrictions. "
                "Pass constraints=None (or omit) for now.",
            )

        # Fall back to the ambient audit context set by an integration
        # decorator (MCP / LangChain) if the caller did not pass one.
        if context is None:
            context = get_current_audit_context()

        return await self.__execute_request(
            grant_id=grant_id,
            method=method,
            url=url,
            provider=provider,
            account=account,
            json=json,
            extra_headers=extra_headers,
            query_params=query_params,
            path_params=path_params,
            reason=reason,
            context=context,
            body=body,
            _raw_provider_response=False,
        )

    # INTERNAL — name-mangled to _AlterVault__execute_request,
    # protected by __getattribute__ guard. Only callable from client.py.
    # Used by boto3_client() bridge to skip ProviderAPIError wrapping
    # (botocore parses AWS errors natively).
    async def __execute_request(  # noqa: PLR0912, PLR0915
        self,
        *,
        grant_id: str | None = None,
        method: HttpMethod | str,
        url: str,
        provider: str | None = None,
        account: str | None = None,
        json: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        query_params: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        reason: str | None = None,
        context: dict[str, str] | None = None,
        body: bytes | None = None,
        _raw_provider_response: bool = False,
    ) -> httpx.Response:
        """Internal request execution — name-mangled, __getattribute__ guarded."""
        # Validate resolution mode
        if grant_id is None and provider is None:
            raise AlterSDKError(message="Provide grant_id or provider")
        if grant_id is not None and provider is not None:
            raise AlterSDKError(message="Cannot provide both grant_id and provider")
        if json is not None and body is not None:
            raise AlterSDKError(message="Cannot provide both 'json' and 'body'")
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        method_str = method.value if isinstance(method, HttpMethod) else str(method).upper()

        # Validate URL scheme to prevent SSRF (token sent to arbitrary destinations)
        url_lower = url.lower()
        if not any(url_lower.startswith(scheme) for scheme in _ALLOWED_URL_SCHEMES):
            raise AlterSDKError(
                f"URL must start with https:// or http://, got: {url[:50]}",
            )

        # Apply path_params to URL template (URL-encode values for safety)
        if path_params:
            encoded_params = {k: quote(str(v), safe="") for k, v in path_params.items()}
            try:
                url = url.format(**encoded_params)
            except (KeyError, ValueError) as e:
                raise AlterSDKError(
                    f"Invalid URL template or missing path_params: {e}. "
                    f"URL: {url}, path_params: {path_params}",
                ) from e

        # Get token internally — returns _TokenResult for credential injection.
        # Token is NEVER exposed as a named attribute or object field.
        token_result = await self.__get_token(
            grant_id=grant_id,
            reason=reason,
            request_metadata={"method": method_str, "url": url},
            context=context,
            provider=provider,
            account=account,
        )

        # Build headers and execute provider request
        request_headers, sigv4_body_bytes, is_sigv4 = self._build_request_headers(
            extra_headers=extra_headers,
            header_name=token_result.injection_header,
            header_value=token_result.header_value,
            raw_injection_format=token_result.injection_format,
            additional_creds=token_result.additional_credentials,
            raw_access_token=token_result.access_token,
            method_str=method_str,
            url=url,
            json=json,
            body=body,
        )

        # Apply additional injection rules (multi-header, query param auth).
        # Skipped for SigV4 — extra headers would invalidate the signature.
        if token_result.additional_injections and not is_sigv4:
            request_headers, query_params = self._apply_additional_injections(
                token_result.additional_injections,
                token_result.access_token,
                token_result.additional_credentials,
                request_headers,
                query_params,
            )

        # Execute request using provider client (NO x-api-key!)
        provider_client = state["provider_client"]

        # Pre-compute audit fields available before the request fires.
        audit_headers = self._build_audit_headers(
            request_headers,
            token_result.injection_header,
            is_sigv4,
            token_result.additional_injections,
        )
        audit_request_body: dict[str, Any] | str | None
        if json is not None:
            audit_request_body = json
        elif body is not None:
            audit_request_body = self._safe_decode_body(body)
        else:
            audit_request_body = None

        start_time = time.time()
        try:
            # Determine content to send:
            # 1. sigv4_body_bytes: pre-serialized for SigV4 signature match
            # 2. body: raw bytes from boto3 bridge or caller
            # 3. json: dict for httpx to serialize
            if sigv4_body_bytes is not None:
                send_content, send_json = sigv4_body_bytes, None
            elif body is not None:
                send_content, send_json = body, None
            else:
                send_content, send_json = None, json

            response = await provider_client.request(
                method=method_str,
                url=url,
                content=send_content,
                json=send_json,
                headers=request_headers,
                params=query_params,
            )

            latency_ms = int((time.time() - start_time) * 1000)

            # Schedule audit log as fire-and-forget background task
            self.__schedule_audit_log(
                grant_id=token_result.grant_id,
                provider_id=token_result.provider_id or "",
                method=method_str,
                url=url,
                request_headers=audit_headers,
                request_body=audit_request_body,
                response_status=response.status_code,
                response_headers=dict(response.headers),
                response_body=self._safe_response_body(response),
                latency_ms=latency_ms,
                reason=reason,
                context=context,
            )

            # Check for HTTP errors (skipped when raw response requested,
            # e.g. boto3 bridge — botocore parses AWS errors itself).
            if not _raw_provider_response and response.status_code >= HTTP_CLIENT_ERROR_START:
                # When a provider returns 403 and scope_mismatch was flagged on
                # the grant, raise ScopeReauthRequiredError so the developer
                # knows re-authorization is needed — not just a generic 403.
                if response.status_code == HTTP_FORBIDDEN and token_result.scope_mismatch:
                    raise ScopeReauthRequiredError(
                        message=(
                            "Provider API returned 403 and the grant's scopes "
                            "don't match the provider config. The user needs to "
                            "re-authorize to grant updated permissions."
                        ),
                        grant_id=str(token_result.grant_id),
                        provider_id=token_result.provider_id or "",
                        status_code=response.status_code,
                        response_body=self._safe_response_body(response),
                        details={
                            "grant_id": str(token_result.grant_id),
                            "provider_id": token_result.provider_id or "",
                            "method": method_str,
                            "url": url,
                        },
                    )
                raise ProviderAPIError(  # noqa: TRY301
                    message=f"Provider API returned error {response.status_code}",
                    status_code=response.status_code,
                    response_body=self._safe_response_body(response),
                    details={
                        "grant_id": grant_id,
                        "method": method_str,
                        "url": url,
                    },
                )

            return response  # noqa: TRY300

        except ProviderAPIError:
            raise
        except httpx.TimeoutException as e:
            latency_ms = int((time.time() - start_time) * 1000)
            self.__schedule_audit_log(
                grant_id=token_result.grant_id,
                provider_id=token_result.provider_id,
                method=method_str,
                url=url,
                request_headers=audit_headers,
                request_body=audit_request_body,
                response_status=0,
                response_headers=None,
                response_body=f"<transport error: timeout after {latency_ms}ms>",
                latency_ms=latency_ms,
                reason=reason,
                context=context,
            )
            raise TimeoutError(
                message=f"Provider API request timed out: {e}",
                details={
                    "grant_id": grant_id,
                    "method": method_str,
                    "url": url,
                    "error": str(e),
                },
            ) from e
        except httpx.HTTPError as e:
            latency_ms = int((time.time() - start_time) * 1000)
            self.__schedule_audit_log(
                grant_id=token_result.grant_id,
                provider_id=token_result.provider_id,
                method=method_str,
                url=url,
                request_headers=audit_headers,
                request_body=audit_request_body,
                response_status=0,
                response_headers=None,
                response_body=f"<transport error: {e}>",
                latency_ms=latency_ms,
                reason=reason,
                context=context,
            )
            raise NetworkError(
                message=f"Failed to call provider API: {e}",
                details={
                    "grant_id": grant_id,
                    "method": method_str,
                    "url": url,
                    "error": str(e),
                },
            ) from e

    async def list_grants(
        self,
        *,
        provider_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> GrantListResult:
        """
        List OAuth grants for this app.

        Returns paginated grant metadata (no tokens).
        Useful for discovering which services a user has granted access to.

        Args:
            provider_id: Filter by provider (e.g., "google"). None for all.
            limit: Maximum number of grants to return (default 100).
            offset: Offset for pagination (default 0).

        Returns:
            GrantListResult with grants list and pagination metadata.

        Raises:
            AlterSDKError: If SDK instance is closed.
            PolicyViolationError: If access is denied by policy.
            NetworkError: If connection to backend fails.
            TimeoutError: If request to backend times out.
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/oauth/grants/list"
        request_body: dict[str, Any] = {
            "provider_id": provider_id,
            "limit": limit,
            "offset": offset,
        }
        # Auto-include user_token if getter is configured
        if state.get("user_token_getter") is not None:
            try:
                user_token = await self.__get_user_token()
                request_body["user_token"] = user_token
            except AlterSDKError as e:
                logger.warning(
                    "user_token_getter failed in list_grants, "
                    "falling back to un-scoped listing: %s",
                    e,
                )
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            GrantNotFoundError,
            GrantRevokedError,
            CredentialRevokedError,
            BackendError,
            AlterSDKError,
        ):
            raise

        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to list grants: {e}",
            ) from e
        else:
            data = response.json()
            grants = [GrantInfo(**c) for c in data["grants"]]
            return GrantListResult(
                grants=grants,
                total=data["total"],
                limit=data["limit"],
                offset=data["offset"],
                has_more=data["has_more"],
            )

    async def revoke_grant(
        self,
        grant_id: str,
        *,
        reason: str | None = None,
    ) -> RevokeGrantResult:
        """
        Revoke an OAuth grant.

        Permanently revokes the specified grant. The grant's tokens are deleted
        from Vault and the grant status is set to "revoked". This action cannot
        be undone — the user must re-authorize via Alter Connect to restore access.

        Args:
            grant_id: ID of the grant to revoke.
            reason: Optional reason for revocation (stored in audit log).

        Returns:
            RevokeGrantResult confirming the revocation.

        Raises:
            AlterSDKError: If SDK instance is closed.
            GrantNotFoundError: If grant does not exist or is not active.
            NetworkError: If connection to backend fails.
            TimeoutError: If request to backend times out.
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = f"/sdk/oauth/grants/{grant_id}/revoke"
        request_body: dict[str, Any] = {}
        if reason is not None:
            request_body["reason"] = reason

        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            GrantNotFoundError,
            GrantRevokedError,
            BackendError,
            AlterSDKError,
        ):
            raise

        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to revoke grant: {e}",
            ) from e
        else:
            data = response.json()
            return RevokeGrantResult(
                success=data["success"],
                message=data["message"],
                grant_id=data["grant_id"],
                revoked_at=data["revoked_at"],
            )

    async def create_connect_session(
        self,
        *,
        allowed_providers: list[str] | None = None,
        return_url: str | None = None,
        allowed_origin: str | None = None,
        metadata: dict[str, Any] | None = None,
        grant_policy: dict[str, Any] | None = None,
        required_scopes: dict[str, list[str]] | None = None,
    ) -> ConnectSession:
        """
        Create a Connect session for initiating OAuth flows.

        Returns a URL the user can open in their browser to authorize access.

        Args:
            allowed_providers: Restrict to specific providers (e.g., ["google"]).
            return_url: URL to redirect after OAuth completion.
            allowed_origin: Allowed origin for postMessage communication.
            metadata: Request metadata for audit (e.g., ip_address, user_agent).
            grant_policy: Optional TTL bounds for the grant. Keys:
                ``max_ttl_seconds`` (max duration user can pick) and
                ``default_ttl_seconds`` (pre-selected duration).
            required_scopes: Optional per-provider scope ceiling. Map of
                ``provider_id`` → list of OAuth scope strings. When set,
                the OAuth authorization URL for that provider is built
                with these scopes instead of the app-level default. Each
                scope MUST be in the app's configured allowlist for that
                provider — the backend rejects any attempt to widen
                beyond what the Dev Portal has authorized (400 with
                ``scope_not_allowed``). Use this to request a narrower
                scope set per session than the app's configured default
                (e.g., an MCP server asking only for ``gmail.readonly``
                when the Dev Portal also has ``gmail.send`` configured).

        Returns:
            ConnectSession with connect_url, session_token, and expiry info.

        Raises:
            AlterSDKError: If SDK instance is closed.
            NetworkError: If connection to backend fails.
            TimeoutError: If request to backend times out.
            BackendError: If the backend rejects the request (e.g.,
                ``scope_not_allowed`` when a requested scope is not in
                the app's Dev Portal allowlist).
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/oauth/connect/session"
        request_body: dict[str, Any] = {
            "allowed_providers": allowed_providers,
            "return_url": return_url,
            "allowed_origin": allowed_origin,
            "metadata": metadata,
        }
        if grant_policy is not None:
            request_body["grant_policy"] = grant_policy
        if required_scopes is not None:
            request_body["required_scopes"] = required_scopes
        # Auto-include user_token if getter is configured
        if state.get("user_token_getter") is not None:
            try:
                user_token = await self.__get_user_token()
                request_body["user_token"] = user_token
            except AlterSDKError as e:
                logger.warning(
                    "user_token_getter failed in create_connect_session, "
                    "session will not have identity tagging: %s",
                    e,
                )
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            GrantNotFoundError,
            GrantRevokedError,
            CredentialRevokedError,
            BackendError,
            AlterSDKError,
        ):
            raise

        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to create connect session: {e}",
            ) from e
        else:
            data = response.json()
            return ConnectSession(**data)

    async def connect(  # noqa: PLR0912
        self,
        *,
        providers: list[str] | None = None,
        timeout: int = 300,
        poll_interval: float = 2.0,
        open_browser: bool = True,
        grant_policy: dict[str, Any] | None = None,
    ) -> list[ConnectResult]:
        """
        Open OAuth in the user's browser and wait for completion.

        This is the headless connect flow for CLI tools, Jupyter notebooks,
        and backend scripts. It creates a Connect session, opens the browser,
        and polls until the user completes OAuth.

        Args:
            providers: Restrict to specific providers (e.g., ["google"]).
            timeout: Max seconds to wait for completion (default 300 = 5 min).
                Note: the TypeScript SDK's equivalent option takes milliseconds
                (default ``300000``). The two SDKs intentionally differ in unit
                because each follows its ecosystem's standard sleep/poll idiom.
            poll_interval: Seconds between poll requests (default 2). Also a
                seconds-valued float here; the TypeScript SDK uses milliseconds.
            open_browser: If True, opens the URL in the default browser.
                         If False, prints the URL for the user to open manually.
            grant_policy: Optional TTL bounds for the grant. Keys:
                ``max_ttl_seconds`` (max duration user can pick) and
                ``default_ttl_seconds`` (pre-selected duration).

        Returns:
            List of ConnectResult objects (one per connected provider in multi-provider flow).

        Raises:
            ConnectTimeoutError: If the user doesn't complete OAuth within timeout.
            ConnectFlowError: If the user denies authorization or provider returns error.
            AlterSDKError: If SDK instance is closed or session creation fails.
            NetworkError: If connection to backend fails.
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        # Create a Connect session (reuses existing method)
        session = await self.create_connect_session(
            allowed_providers=providers,
            grant_policy=grant_policy,
        )

        # Open browser or print URL
        if open_browser:
            try:
                import webbrowser

                logger.info("Opening browser for OAuth authorization...")
                webbrowser.open(session.connect_url)
            except Exception:
                # Fallback: print URL if browser can't be opened (e.g., headless server)
                logger.info("Open this URL to authorize: %s", session.connect_url)
        else:
            logger.info("Open this URL to authorize: %s", session.connect_url)

        # Poll until completion, error, or timeout
        deadline = time.time() + timeout
        while time.time() < deadline:
            await asyncio.sleep(poll_interval)

            poll_result = await self.__poll_session(session.session_token)
            poll_status = poll_result.get("status")

            if poll_status == "completed":
                connections_data = poll_result.get("grants", [])
                results = []
                for c in connections_data:
                    kwargs: dict[str, Any] = {
                        "grant_id": c.get("grant_id", ""),
                        "provider_id": c.get("provider_id", ""),
                        "account_identifier": c.get("account_identifier"),
                        "scopes": c.get("scopes", []),
                    }
                    if c.get("grant_policy") is not None:
                        from alter_sdk.models import GrantPolicy

                        kwargs["grant_policy"] = GrantPolicy(
                            **c["grant_policy"],
                        )
                    results.append(ConnectResult(**kwargs))
                return results

            if poll_status == "error":
                error_data = poll_result.get("error", {})
                error_code = error_data.get("error_code", "unknown_error")
                error_message = error_data.get("error_message", "OAuth flow failed")
                error_details = {"error_code": error_code}

                if error_code == "connect_denied":
                    raise ConnectDeniedError(message=error_message, details=error_details)
                if error_code in (
                    "connect_config_error",
                    "invalid_redirect_uri",
                    "invalid_client",
                    "unauthorized_client",
                ):
                    raise ConnectConfigError(message=error_message, details=error_details)

                raise ConnectFlowError(message=error_message, details=error_details)

            if poll_status == "expired":
                raise ConnectFlowError(
                    message="Connect session expired before OAuth was completed",
                )

            if poll_status != "pending":
                raise ConnectFlowError(
                    message=f"Unexpected poll status from server: {poll_status}",
                    details={"status": poll_status},
                )

        raise ConnectTimeoutError(
            message=f"OAuth flow did not complete within {timeout} seconds. "
            "The user may not have finished authorizing in the browser.",
            details={"timeout": timeout},
        )

    async def __poll_session(self, session_token: str) -> dict[str, Any]:
        """
        Poll the Connect session for completion status (INTERNAL).

        Makes an HMAC-signed POST to the poll endpoint.

        Args:
            session_token: Session token from create_connect_session()

        Returns:
            Response dict with status, optional grant/error data.
        """
        state = self.__state
        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/oauth/connect/session/poll"
        request_body = {"session_token": session_token}
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )
            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)
        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e
        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e
        except (
            PolicyViolationError,
            GrantNotFoundError,
            GrantRevokedError,
            CredentialRevokedError,
            BackendError,
            AlterSDKError,
        ):
            raise
        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to poll connect session: {e}",
            ) from e
        else:
            return response.json()  # type: ignore[no-any-return]

    async def authenticate(self, *, timeout: float = 300.0) -> AuthResult:  # noqa: PLR0912, PLR0915
        """
        Trigger IDP login for end user via browser.

        Opens the app's configured IDP login page in the user's default browser.
        Polls for completion and returns the user's IDP JWT token.

        After authenticate() completes, the returned user_token is automatically
        used for subsequent request() calls that use identity resolution
        (provider= parameter).

        Args:
            timeout: Maximum seconds to wait for user to complete login (default: 300)

        Returns:
            AuthResult with user_token (IDP JWT) and user_info

        Raises:
            AlterSDKError: If no IDP is configured or auth fails
            ConnectTimeoutError: If user doesn't complete login within timeout
        """
        import webbrowser

        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        # Step 1: Create auth session
        sdk_path = "/sdk/auth/session"
        body_bytes = b"{}"
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )
            self.__cache_actor_id_from_response(response)

            if response.status_code != httpx.codes.CREATED:
                error_detail: dict[str, Any] = {}
                if response.headers.get("content-type", "").startswith("application/json"):
                    error_detail = response.json()
                msg = (
                    error_detail.get("detail", {}).get("message")
                    if isinstance(error_detail.get("detail"), dict)
                    else str(error_detail.get("detail", response.text))
                )
                raise AlterSDKError(  # noqa: TRY301
                    message=f"Failed to create auth session: {msg}",
                )

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e
        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e
        except AlterSDKError:
            raise
        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to create auth session: {e}",
            ) from e

        session_data = response.json()
        auth_url: str = session_data["auth_url"]
        session_token: str = session_data["session_token"]

        # Step 2: Open browser
        try:
            logger.info("Opening browser for IDP authentication...")
            webbrowser.open(auth_url)
        except Exception:
            logger.info("Open this URL to authenticate: %s", auth_url)

        # Step 3: Poll for completion
        poll_path = "/sdk/auth/poll"
        poll_body_dict = {"session_token": session_token}
        poll_body_bytes = json_mod.dumps(poll_body_dict, separators=(",", ":")).encode("utf-8")
        deadline = time.time() + timeout

        while time.time() < deadline:
            await asyncio.sleep(2.0)

            poll_hmac = self.__compute_hmac_headers("POST", poll_path, poll_body_bytes)
            poll_headers = {
                **actor_headers,
                **poll_hmac,
                "Content-Type": "application/json",
            }

            try:
                poll_resp = await alter_client.post(
                    poll_path,
                    content=poll_body_bytes,
                    headers=poll_headers,
                )
                self.__cache_actor_id_from_response(poll_resp)
            except (httpx.ConnectError, httpx.TimeoutException):
                # Retry on transient network errors
                continue
            except Exception:
                continue

            if poll_resp.status_code != httpx.codes.OK:
                continue  # Retry on transient server errors

            poll_data: dict[str, Any] = poll_resp.json()
            poll_status = poll_data.get("status")

            if poll_status == "completed":
                user_token = poll_data.get("user_token")
                if not user_token:
                    raise AlterSDKError(
                        message="Authentication completed but no user token "
                        "was returned by the IDP",
                    )
                user_info = poll_data.get("user_info", {})

                # Store user_token as the token getter for subsequent requests
                state["user_token_getter"] = lambda _t=user_token: _t

                return AuthResult(
                    user_token=user_token,
                    user_info=user_info,
                )

            if poll_status == "error":
                error_msg = poll_data.get("error_message", "Authentication failed")
                raise AlterSDKError(message=f"Authentication failed: {error_msg}")

            if poll_status == "expired":
                raise AlterSDKError(message="Authentication session expired")

            # status == "pending" -> continue polling

        raise ConnectTimeoutError(
            message=f"Authentication timed out after {timeout}s. "
            "The user may not have completed login in the browser.",
            details={"timeout": timeout},
        )

    async def verify_user_token(self, token: str) -> str | None:  # noqa: PLR0911 - every return is a distinct fail-closed path
        """Verify an IDP-issued JWT against the app's configured identity provider.

        This is the canonical entry point for SDK integrations (e.g. the
        MCP ``AlterAuthProvider``) that need to validate an incoming bearer
        token before treating the request as authenticated. It is a thin
        HMAC-signed wrapper over the backend's ``POST /sdk/auth/verify-token``
        endpoint, which delegates to the production ``JWTValidationService``
        (signature, issuer, audience, expiry, JWKS rotation, clock skew).

        Fail-closed semantics:

        - Empty or whitespace-only token → ``None``
        - SDK instance closed → ``None``
        - Backend returns 200 → verified ``sub`` (string)
        - Backend returns 401 → ``None`` (invalid token)
        - Backend returns 400 (no IDP configured) → ``None``
        - Network error, 5xx, malformed response → ``None``

        This method never raises on verification failure — it returns
        ``None`` so FastMCP-style callers can translate that into a 401.
        Callers MUST treat ``None`` as "reject the request."

        SECURITY: The backend deliberately returns ONLY the verified
        ``sub`` claim, never the full JWT payload. Custom IdP claims
        (email, groups, etc.) are PII and not needed for authentication
        — receiving them here would risk SDK consumers logging them
        downstream.

        Args:
            token: Bearer JWT received from the SDK caller's client.

        Returns:
            The verified ``sub`` claim on success, or ``None`` if the
            token cannot be trusted for any reason.
        """
        if not token or not token.strip():
            return None

        state = _instance_state.get(id(self))
        if state is None or state["closed"]:
            logger.warning(
                "verify_user_token called on closed AlterVault instance",
            )
            return None

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/auth/verify-token"
        body_dict = {"token": token}
        body_bytes = json_mod.dumps(body_dict, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {
            **actor_headers,
            **hmac_headers,
            "Content-Type": "application/json",
        }

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.RequestError) as e:
            # Network failure — fail closed, never treat as authenticated.
            logger.warning(
                "verify-token network error, rejecting token: %s",
                type(e).__name__,
            )
            return None

        with contextlib.suppress(Exception):  # cascade-isolated metric path
            self.__cache_actor_id_from_response(response)

        if response.status_code == httpx.codes.OK:
            try:
                data = response.json()
            except (json_mod.JSONDecodeError, ValueError):
                logger.warning(
                    "verify-token returned 200 with malformed JSON, rejecting",
                )
                return None
            # Postcondition: validate required fields the server promised.
            if not isinstance(data, dict):
                return None
            sub = data.get("sub")
            if not isinstance(sub, str) or not sub.strip():
                return None
            return sub

        if response.status_code == httpx.codes.UNAUTHORIZED:
            # Intended path for invalid/expired/wrong-issuer tokens.
            return None

        # Any other status (400 no IDP, 5xx, unexpected) → fail closed
        # with an operator-visible warning.
        logger.warning(
            "verify-token unexpected response (status=%d), rejecting token",
            response.status_code,
        )
        return None

    async def _create_auth_session_raw(self) -> dict[str, Any]:
        """Create an auth session on the Alter backend (internal).

        POST /sdk/auth/session → {auth_url, session_token, expires_in}.
        Used by AlterAuthProvider's OAuth authorize flow.

        Returns:
            Dict with keys: auth_url (str), session_token (str), expires_in (int).

        Raises:
            AlterSDKError: If the SDK is closed or the backend rejects the request.
            NetworkError: If the backend is unreachable.
            TimeoutError: If the request times out.
        """
        state = _instance_state.get(id(self))
        if state is None or state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/auth/session"
        body_bytes = b"{}"
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )
        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e
        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        with contextlib.suppress(Exception):
            self.__cache_actor_id_from_response(response)

        if response.status_code != httpx.codes.CREATED:
            error_detail: dict[str, Any] = {}
            if response.headers.get("content-type", "").startswith("application/json"):
                error_detail = response.json()
            msg = (
                error_detail.get("detail", {}).get("message")
                if isinstance(error_detail.get("detail"), dict)
                else str(error_detail.get("detail", response.text))
            )
            raise AlterSDKError(
                message=f"Failed to create auth session: {msg}",
            )

        data: dict[str, Any] = response.json()
        # Postcondition: validate required fields the backend promised
        if not isinstance(data.get("auth_url"), str) or not isinstance(
            data.get("session_token"),
            str,
        ):
            raise AlterSDKError(
                message="Auth session response missing required fields (auth_url, session_token)",
            )
        return data

    async def _poll_auth_session_raw(self, session_token: str) -> dict[str, Any]:
        """Poll an auth session for completion (internal, single attempt).

        POST /sdk/auth/poll → {status, user_token?, user_info?, error_message?}.
        Used by AlterAuthProvider's bridge page polling endpoint.

        Args:
            session_token: The session token from _create_auth_session_raw.

        Returns:
            Dict with at minimum a 'status' key ('pending', 'completed', 'error', 'expired').
            On 'completed', also contains 'user_token' and optionally 'user_info'.

        Raises:
            AlterSDKError: If the SDK is closed.
            NetworkError: If the backend is unreachable.
            TimeoutError: If the request times out.
        """
        state = _instance_state.get(id(self))
        if state is None or state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        poll_path = "/sdk/auth/poll"
        poll_body_dict = {"session_token": session_token}
        poll_body_bytes = json_mod.dumps(poll_body_dict, separators=(",", ":")).encode("utf-8")
        poll_hmac = self.__compute_hmac_headers("POST", poll_path, poll_body_bytes)
        poll_headers = {
            **actor_headers,
            **poll_hmac,
            "Content-Type": "application/json",
        }

        try:
            poll_resp = await alter_client.post(
                poll_path,
                content=poll_body_bytes,
                headers=poll_headers,
            )
        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e
        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        with contextlib.suppress(Exception):
            self.__cache_actor_id_from_response(poll_resp)

        if poll_resp.status_code != httpx.codes.OK:
            raise AlterSDKError(
                message=f"Auth session poll failed (status={poll_resp.status_code})",
            )

        data: dict[str, Any] = poll_resp.json()
        # Postcondition: validate the 'status' field exists
        if not isinstance(data.get("status"), str):
            raise AlterSDKError(
                message="Auth session poll response missing required 'status' field",
            )
        return data

    async def close(self) -> None:
        """Close HTTP clients and release resources."""
        state = _instance_state.get(id(self))
        if state is None or state["closed"]:
            return
        state["closed"] = True

        # Wait for any pending audit tasks before closing clients
        if state["audit_tasks"]:
            await asyncio.gather(*state["audit_tasks"], return_exceptions=True)
        try:
            await state["alter_client"].aclose()
        finally:
            await state["provider_client"].aclose()

    async def boto3_client(
        self,
        service_name: str,
        *,
        grant_id: str,
        region_name: str | None = None,
        timeout: float | None = None,
        reason: str | None = None,
        context: dict[str, str] | None = None,
    ) -> Any:
        """Create a boto3 client that routes all requests through Alter Vault.

        Every AWS API call made by the returned client flows through
        ``vault.request()`` for credential retrieval, SigV4 signing,
        policy enforcement, and audit logging.

        Requires ``boto3`` to be installed::

            pip install 'alter-sdk[aws]'

        Usage::

            client = await vault.boto3_client("s3", grant_id=conn_id)
            objects = await asyncio.to_thread(
                client.list_objects_v2, Bucket="my-bucket",
            )

        Args:
            service_name: AWS service name (e.g. ``"s3"``, ``"dynamodb"``).
            grant_id: Alter Vault grant ID for AWS credentials.
            region_name: AWS region (default ``"us-east-1"``).
            timeout: Total wall-clock timeout in seconds for each call, covering
                both token retrieval and the HTTP request (default: client timeout + 5s buffer).
            reason: Audit reason applied to all requests from this client.
            context: Caller-provided context for audit correlation.

        Returns:
            A boto3 service client with all requests routed through Alter Vault.

        Important:
            The returned boto3 client holds a strong reference to this
            ``AlterVault`` instance (via internal closures).  This means
            ``__del__``-based cleanup will NOT fire while the boto3 client
            exists.  Always call ``vault.close()`` explicitly or use
            ``async with AlterVault(...) as vault:`` to ensure resources
            are released.

        Note:
            Responses are fully buffered in memory. For large payloads
            (e.g. ``s3.get_object()`` on multi-GB files), use
            ``vault.request()`` with httpx streaming instead.

        Raises:
            AlterSDKError: If ``boto3`` is not installed or vault is closed.
        """
        try:
            import boto3  # type: ignore[reportMissingImports]
            import botocore  # type: ignore[reportMissingImports]
            from botocore.config import Config  # type: ignore[reportMissingImports]
        except ImportError:
            raise AlterSDKError(
                message="boto3 is required for boto3_client(). "
                "Install with: pip install 'alter-sdk[aws]'",
            ) from None

        from alter_sdk._boto3_bridge import AlterVaultBoto3Handler

        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        # The thread-level timeout (future.result) must exceed the httpx
        # timeout (provider_client) so that httpx fires first with a typed
        # alter_sdk.TimeoutError rather than a raw concurrent.futures
        # TimeoutError propagating unhandled through botocore.  The +5s
        # buffer accounts for token retrieval overhead on top of the
        # provider request itself.
        _timeout_buffer = 5.0
        if timeout is not None:
            effective_timeout = timeout + _timeout_buffer
        elif state["provider_client"].timeout.read is not None:
            effective_timeout = state["provider_client"].timeout.read + _timeout_buffer
        else:
            effective_timeout = 30.0 + _timeout_buffer

        loop = asyncio.get_running_loop()

        # Closures created here have access to name-mangled methods
        # because this code lives in client.py (passes __getattribute__ guard).
        # The caller identity and per-request context dict are forwarded
        # on every request for audit correlation.
        #
        # NOTE: Both closures capture `self`, keeping the AlterVault instance
        # alive while the boto3 client exists.  This is intentional — the
        # handler needs a live vault.  Callers must call vault.close().
        async def _vault_request(
            method: str,
            url: str,
            body: bytes | None,
            headers: dict[str, str],
        ) -> httpx.Response:
            return await self.__execute_request(
                grant_id=grant_id,
                method=method,
                url=url,
                body=body,
                extra_headers=headers,
                reason=reason,
                context=context,
                _raw_provider_response=True,
            )

        def _is_closed() -> bool:
            s = _instance_state.get(id(self))
            return s is None or s["closed"]

        handler = AlterVaultBoto3Handler(
            request_fn=_vault_request,
            timeout=effective_timeout,
            is_closed_fn=_is_closed,
            loop=loop,
        )

        # Isolated session: avoids inheriting event hooks (before-call,
        # after-call, etc.) from the caller's global boto3 default session,
        # which may conflict in AI-agent or moto-patched environments.
        #
        # Dummy credentials: boto3 requires non-empty credential strings even
        # with signature_version=UNSIGNED.  These are never signed, never
        # transmitted, and never used for authentication — the before-send
        # handler intercepts all requests before botocore's HTTP transport.
        # They will appear in botocore debug logs, which is expected.
        client = boto3.Session().client(
            service_name,
            aws_access_key_id="alter-vault-managed",
            aws_secret_access_key="alter-vault-managed",
            region_name=region_name or "us-east-1",
            config=Config(
                signature_version=botocore.UNSIGNED,
                retries={"max_attempts": 0},
            ),
        )
        client.meta.events.register("before-send", handler)
        return client

    async def __aenter__(self) -> "AlterVault":
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Async context manager exit."""
        await self.close()
