"""
alter_tool() — LangChain tool decorator with Alter Vault integration.

Produces a real ``langchain_core.tools.StructuredTool`` that:

1. Accepts LangChain's ``config`` kwarg (a ``RunnableConfig``-like dict) via
   signature injection — the user's function does NOT need to declare
   ``**kwargs`` or ``config=`` to receive it.
2. Extracts ``run_id`` and ``thread_id`` from that config and sets an
   ambient audit ``ContextVar``. Any ``vault.request()`` call made from
   inside the tool function (or any helper it calls) picks up the audit
   metadata automatically — no manual forwarding required.
3. Catches ``GrantNotFoundError`` and converts it into a human-readable
   string containing a fresh Alter Connect URL.
4. Catches ``ScopeReauthRequiredError`` and converts it into a re-auth
   message.
5. Catches ``BackendError`` with ``ambiguous_grant`` and lists the
   available accounts so the LLM can ask the user which one to use.

The returned ``StructuredTool`` can be passed directly to a LangChain
agent or a LangGraph node — it behaves identically to a tool produced by
LangChain's native ``@tool`` decorator.

Code-level policy note
----------------------
``scope`` and ``constraints`` are a reserved API surface. The backend does
not currently enforce code-level policy restrictions, so passing a non-None
value for either will cause the wrapped function's first ``vault.request``
call to raise ``NotImplementedError``. The parameters are accepted here so
that tool authors can adopt the final API shape today without breakage
once backend enforcement lands. The values are also stored on
``tool.metadata`` (keys ``alter_scope`` / ``alter_constraints``) for
introspection by downstream agent frameworks.
"""

from __future__ import annotations

import inspect
import logging
from collections.abc import Callable  # — used at runtime in TypeVar bound
from copy import deepcopy
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, TypeVar

from alter_sdk._context import _alter_context_var
from alter_sdk.exceptions import BackendError, GrantNotFoundError, ScopeReauthRequiredError

if TYPE_CHECKING:
    from alter_sdk.client import AlterVault

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

# Bound for ``str(run_id)`` / ``str(thread_id)`` coercion. LangChain
# permits arbitrary types for these IDs (UUID, str, int, custom
# objects), and a pathological ``__repr__`` could blow past the
# X-Alter-Context value limit. Cap the coerced string defensively so
# the validator in client.py never has to.
_MAX_RUN_ID_LENGTH = 256


def alter_tool(  # noqa: PLR0915 - closure-based decorator with cohesive setup
    vault: AlterVault,
    provider: str,
    *,
    scope: list[str] | None = None,
    constraints: dict[str, Any] | None = None,
    name: str | None = None,
    description: str | None = None,
) -> Callable[[F], Any]:
    """Decorator that wraps an async function as a LangChain ``StructuredTool``
    with Alter Vault integration.

    The returned tool:

    - Is a real ``langchain_core.tools.StructuredTool`` — pass it directly to
      a LangChain agent, LangGraph node, or any ``Runnable`` pipeline.
    - Accepts LangChain's ``config`` kwarg transparently. ``run_id`` is read
      from ``config["run_id"]`` first and then from
      ``config["metadata"]["run_id"]`` as a fallback. ``thread_id`` is read
      from ``config["configurable"]["thread_id"]``.
    - Sets an ambient audit ``ContextVar`` with ``{"tool": <tool_name>,
      "framework": "langchain", "run_id": ..., "thread_id": ...}``. Any
      ``vault.request()`` call made from inside the wrapped function (or any
      helper it calls) will use this dict as its default audit context.
    - Catches ``GrantNotFoundError`` and returns a message containing a
      fresh Alter Connect URL.
    - Catches ``ScopeReauthRequiredError`` and returns a re-auth message.

    Args:
        vault: AlterVault client instance.
        provider: OAuth provider ID (e.g. ``"google"``, ``"github"``).
        scope: Reserved — list of code-level scopes the tool requires.
            Currently raises ``NotImplementedError`` on the tool's first
            ``vault.request()`` call because backend enforcement is not
            yet implemented. Also stored on ``tool.metadata["alter_scope"]``.
        constraints: Reserved — dict of code-level constraints the tool
            requires. Same ``NotImplementedError`` behavior as ``scope``.
            Also stored on ``tool.metadata["alter_constraints"]``.
        name: Tool name (defaults to function name).
        description: Tool description (defaults to function docstring).

    Returns:
        A decorator that, when applied to an async function, returns a
        ``StructuredTool`` ready for direct use with LangChain.

    Raises:
        ImportError: If ``langchain-core`` is not installed. Install with
            ``pip install 'alter-sdk[langchain]'``.
        TypeError: If the decorated function is not a coroutine function.

    Usage::

        @alter_tool(vault, provider="google")
        async def list_emails(query: str) -> str:
            \"\"\"List emails matching a query.\"\"\"
            response = await vault.request(
                "GET",
                "https://gmail.googleapis.com/gmail/v1/users/me/messages",
                provider="google",
            )
            return response.text

        # list_emails is now a StructuredTool — pass it to a LangChain agent:
        from langchain.agents import create_react_agent
        agent = create_react_agent(llm, tools=[list_emails])
    """
    try:
        from langchain_core.runnables import RunnableConfig
        from langchain_core.tools import StructuredTool
    except ImportError as e:
        raise ImportError(
            "alter_tool requires langchain-core. "
            "Install with: pip install 'alter-sdk[langchain]'",
        ) from e

    def decorator(fn: F) -> Any:  # noqa: PLR0915 - closure builds wrapper + metadata in one place
        if not inspect.iscoroutinefunction(fn):
            raise TypeError(
                f"@alter_tool requires an async function, got "
                f"{type(fn).__name__}. Define the tool as `async def`.",
            )

        # Reject user parameter names that collide with LangChain's
        # reserved injection kwargs. The wrapper pops ``config`` and
        # ``callbacks`` from kwargs before delegating to the user function,
        # so a user-declared parameter with either name would silently be
        # clobbered (or worse, receive a LangChain RunnableConfig the user
        # didn't expect). Fail loudly at decoration time instead.
        reserved_params = ("config", "callbacks")
        fn_params = inspect.signature(fn).parameters
        for reserved in reserved_params:
            if reserved in fn_params:
                raise TypeError(
                    f"@alter_tool cannot wrap {fn.__name__!r}: the "
                    f"parameter name {reserved!r} is reserved by LangChain "
                    f"(RunnableConfig injection) and would collide with "
                    f"user input. Rename the parameter (e.g. to "
                    f"{reserved}_ or tool_{reserved}) and try again.",
                )

        tool_name = name or fn.__name__
        tool_description = description or fn.__doc__ or f"Alter tool: {tool_name}"

        async def _alter_coroutine(*args: Any, **kwargs: Any) -> Any:  # noqa: PLR0912
            # LangChain injects `config` when the coroutine declares a
            # parameter annotated with `RunnableConfig` (see signature
            # override below). Also pop `callbacks` if LangChain injects
            # it — we don't use it but we must strip it so the user's
            # function doesn't need to declare it.
            config = kwargs.pop("config", None)
            kwargs.pop("callbacks", None)

            run_id: Any = None
            thread_id: Any = None
            if isinstance(config, dict):
                # LangChain's `ensure_config()` strips user-supplied
                # `run_id` from the top level of RunnableConfig, so the
                # LangChain-idiomatic way to propagate a user-defined
                # run identifier is via `config["metadata"]["run_id"]`.
                # We still check the top-level key first to support
                # direct (non-StructuredTool) callers.
                run_id = config.get("run_id")
                if run_id is None:
                    metadata = config.get("metadata")
                    if isinstance(metadata, dict):
                        run_id = metadata.get("run_id")

                configurable = config.get("configurable")
                if isinstance(configurable, dict):
                    thread_id = configurable.get("thread_id")

            # Build the ambient audit context for this call. Only include
            # keys with actual values — the backend's context dict is
            # JSON-encoded and bounded, so we don't want to waste bytes on
            # nulls. Coerce run_id/thread_id via str() but cap the length
            # so a pathological __repr__ implementation can't blow past
            # the per-value limit enforced by the SDK and backend
            # validators.
            audit_context: dict[str, str] = {
                "tool": tool_name,
                "framework": "langchain",
            }
            if run_id is not None:
                audit_context["run_id"] = str(run_id)[:_MAX_RUN_ID_LENGTH]
            if thread_id is not None:
                audit_context["thread_id"] = str(thread_id)[:_MAX_RUN_ID_LENGTH]

            # Set the ambient ContextVar so every vault.request() made from
            # inside the wrapped function picks up audit correlation.
            # contextvars is copy-on-write per asyncio Task, so concurrent
            # tool calls (e.g. under asyncio.gather) do not leak context.
            token = _alter_context_var.set(audit_context)
            try:
                return await fn(*args, **kwargs)

            except GrantNotFoundError:
                # Log sanitized — never serialize the exception body into the
                # tool return value because GrantNotFoundError may carry
                # internal details (grant hints, backend URLs, request ids).
                logger.info(
                    "No grant found in tool=%s (provider=%s)",
                    tool_name,
                    provider,
                )
                try:
                    session = await vault.create_connect_session(
                        allowed_providers=[provider],
                    )
                except Exception:  # — cascade isolation
                    logger.exception(
                        "Failed to create Connect session in tool=%s (provider=%s)",
                        tool_name,
                        provider,
                    )
                    return f"Authorization required for {provider}. Please try again later."
                return (
                    f"Authorization required for {provider}. "
                    f"Please visit: {session.connect_url}"
                )

            except ScopeReauthRequiredError:
                logger.info(
                    "Scope mismatch in tool=%s (provider=%s)",
                    tool_name,
                    provider,
                )
                return (
                    f"Additional permissions needed for {provider}. "
                    f"Please re-authorize with the required scopes."
                )

            except BackendError as exc:
                if exc.details.get("error") == "ambiguous_grant":
                    raw_accounts = exc.details.get("account_identifiers", [])
                    # Normalize: None or non-list → empty list; str → single-item list
                    if isinstance(raw_accounts, str):
                        raw_accounts = [raw_accounts]
                    elif not isinstance(raw_accounts, list):
                        raw_accounts = []
                    accounts = [str(a) for a in raw_accounts]
                    account_list = ", ".join(accounts) if accounts else "<no accounts>"
                    logger.info(
                        "Ambiguous grant in tool=%s (provider=%s, account_count=%d)",
                        tool_name,
                        provider,
                        len(accounts),
                    )
                    return (
                        f"Multiple accounts are connected for {provider}. "
                        f"Please specify which account to use: {account_list}"
                    )
                raise

            finally:
                _alter_context_var.reset(token)

        # Build a synthetic signature on the coroutine: `fn`'s parameters
        # plus a keyword-only `config: RunnableConfig` parameter. LangChain
        # detects injectable config params by their TYPE annotation, and
        # the presence of this parameter also excludes it from the
        # auto-generated args_schema.
        fn_sig = inspect.signature(fn)
        config_param = inspect.Parameter(
            "config",
            kind=inspect.Parameter.KEYWORD_ONLY,
            default=None,
            annotation=RunnableConfig,
        )
        _alter_coroutine.__signature__ = fn_sig.replace(  # type: ignore[attr-defined]
            parameters=[*fn_sig.parameters.values(), config_param],
        )
        _alter_coroutine.__name__ = tool_name
        _alter_coroutine.__qualname__ = getattr(fn, "__qualname__", tool_name)
        _alter_coroutine.__doc__ = tool_description
        _alter_coroutine.__module__ = getattr(fn, "__module__", __name__)
        # Copy annotations so StructuredTool's schema inference sees fn's types.
        annotations = dict(getattr(fn, "__annotations__", {}))
        annotations["config"] = RunnableConfig
        _alter_coroutine.__annotations__ = annotations

        # Build the real StructuredTool. `coroutine=` makes it async-only;
        # langchain-core auto-generates `args_schema` from the coroutine's
        # (overridden) signature, excluding the injected `config` param.
        tool = StructuredTool.from_function(
            coroutine=_alter_coroutine,
            name=tool_name,
            description=tool_description,
        )

        # Store scope/constraints on the tool's metadata field for
        # introspection by downstream agent frameworks. `BaseTool.metadata`
        # is an optional dict exactly for this purpose.
        #
        # Defensive copies: store an immutable tuple for ``alter_scope``
        # and a deepcopy + read-only proxy for ``alter_constraints`` so
        # that downstream code (and the caller's own post-decoration
        # mutations) cannot leak into the metadata stored on the tool.
        if tool.metadata is None:
            tool.metadata = {}
        tool.metadata["alter_scope"] = tuple(scope) if scope is not None else None
        tool.metadata["alter_constraints"] = (
            MappingProxyType(deepcopy(constraints)) if constraints is not None else None
        )

        return tool

    return decorator
