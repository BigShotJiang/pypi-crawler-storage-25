"""
Alter Vault Python SDK

OAuth token management with policy enforcement and automatic token injection.

Zero Token Exposure Architecture:
- Tokens are NEVER exposed to developers
- SDK handles all token operations internally
- Developers only see API results, never credentials
"""

from alter_sdk.client import AlterVault
from alter_sdk.exceptions import (
    AlterSDKError,
    AlterValueError,
    BackendError,
    ConnectConfigError,
    ConnectDeniedError,
    ConnectFlowError,
    ConnectTimeoutError,
    CredentialRevokedError,
    GrantDeletedError,
    GrantExpiredError,
    GrantNotFoundError,
    GrantRevokedError,
    NetworkError,
    PolicyViolationError,
    ProviderAPIError,
    ReAuthRequiredError,
    ScopeReauthRequiredError,
    TimeoutError,
    TokenRefreshInProgressError,
)
from alter_sdk.models import (
    APICallAuditLog,
    AuthResult,
    ConnectResult,
    ConnectSession,
    GrantInfo,
    GrantListResult,
    GrantPolicy,
    RevokeGrantResult,
    TokenResponse,
)
from alter_sdk.providers.enums import CallerType, HttpMethod, Provider

__version__ = "0.11.0"

# Optional framework integrations — imported lazily to avoid hard
# dependencies on fastapi/fastmcp/langchain when not installed.
# Users import directly: ``from alter_sdk.fastapi import AlterFastAPI``

__all__ = [
    "AlterVault",
    "AuthResult",
    "CallerType",
    "HttpMethod",
    "Provider",
    "TokenResponse",
    "APICallAuditLog",
    "GrantInfo",
    "ConnectResult",
    "ConnectSession",
    "GrantListResult",
    "GrantPolicy",
    "RevokeGrantResult",
    "AlterSDKError",
    "AlterValueError",
    "BackendError",
    "ReAuthRequiredError",
    "ConnectFlowError",
    "ConnectDeniedError",
    "ConnectConfigError",
    "ConnectTimeoutError",
    "PolicyViolationError",
    "GrantDeletedError",
    "GrantExpiredError",
    "GrantNotFoundError",
    "GrantRevokedError",
    "CredentialRevokedError",
    "ProviderAPIError",
    "ScopeReauthRequiredError",
    "NetworkError",
    "TimeoutError",
    "TokenRefreshInProgressError",
]
