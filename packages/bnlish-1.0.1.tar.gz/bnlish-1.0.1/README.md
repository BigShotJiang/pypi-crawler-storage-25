# Bnlish

English to Bengali transliteration library

## Description

Banglish is a Python library that provides transliteration from English (Roman script) to Bengali (Bangla script). It includes comprehensive character mappings for vowels, consonants, and vowel signs (kar), as well as a dictionary of common words.

## Features

- **Bidirectional transliteration**: English to Bengali and Bengali to English
- Character-by-character transliteration with compound consonant support
- Support for Bengali vowels, consonants, and vowel signs
- Extensive common words dictionary (200+ words)
- Simple and easy-to-use API
- Word suggestions for incomplete typing

## Installation

```bash
pip install bnlish
```

## Usage

### Three-Way Transliteration

Your Banglish library now supports three-way conversion between English, Banglish, and Bengali:

```python
# Import all conversion functions
import banglish as bnlish

# 1. English to Banglish
english_text = "I am very good today"
banglish_text = bnlish.en_to_banglish(english_text)
print(banglish_text)  # Output: 

# 2. Banglish to English  
banglish_text = "ridoye tomar kirtan baje"
english_text = bnlish.banglish_to_en(banglish_text)
print(english_text)  # Output: 

# 3. Banglish to Bengali
banglish_text = "ridoye tomar kirtan baje"
bengali_text = bnlish.banglish_to_bn(banglish_text)
print(bengali_text)  # Output: হৃদয়ে তোমার কীর্তন বাজে

# 4. Bengali to Banglish
bengali_text = "হৃদয়ে তোমার কীর্তন বাজে"
banglish_text = bnlish.bn_to_banglish(bengali_text)
print(banglish_text)  # Output: ridoye tomar kirtan baje
```

### Advanced Usage

```python
# For more control, use the translator class
import banglish as bnlish
translator = bnlish.BanglishTranslator()

# Direct method calls
print(translator.to_banglish("tumi kemon acho"))  # English to Bengali
print(translator.to_banglish_from_bengali("তুমি কেমন আছো"))  # Bengali to English

# Word suggestions
suggestions = translator.suggest("bha")
print(suggestions)  # [{'english': 'bhalo', 'bangla': 'ভালো'}, ...]
```

**Alternative imports (also available):**
```python
from bnlish import translate, bengali_to_banglish  # Same functions, different names
```

## Requirements

- Python 3.7+
- regex >= 2023.0.0

## Development

### Install development dependencies

```bash
pip install -e .[dev]
```

### Run tests

```bash
pytest
```

### Code formatting

```bash
black .
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Author

Debashish Roy <thedeba@icloud.com>

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

