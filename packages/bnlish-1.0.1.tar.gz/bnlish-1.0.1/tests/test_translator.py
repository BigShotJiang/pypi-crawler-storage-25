import unittest
from banglish import BanglishTranslator

class TestBasicTranslation(unittest.TestCase):
    def setUp(self):
        self.translator = BanglishTranslator()
    
    def test_simple_words(self):
        """Test basic word translation"""
        test_cases = [
            ('ami', 'আমি'),
            ('bhalo', 'ভালো'),
            ('khabo', 'খাবো'),
        ]
        
        for english, expected in test_cases:
            with self.subTest(word=english):
                result = self.translator.to_banglish(english)
                self.assertEqual(result, expected)
    
    def test_sentences(self):
        """Test sentence translation"""
        text = "ami bhat khabo"
        result = self.translator.to_banglish(text)
        self.assertIn('আমি', result)
        self.assertIn('খাবো', result)
    
    def test_suggestions(self):
        """Test word suggestions"""
        suggestions = self.translator.suggest('bha')
        self.assertTrue(len(suggestions) > 0)
        self.assertTrue(any(s['english'].startswith('bha') for s in suggestions))

class TestEdgeCases(unittest.TestCase):
    def setUp(self):
        self.translator = BanglishTranslator()
    
    def test_empty_string(self):
        self.assertEqual(self.translator.to_banglish(""), "")
    
    def test_numbers(self):
        result = self.translator.to_banglish("123")
        self.assertEqual(result, "123")
    
    def test_mixed_content(self):
        result = self.translator.to_banglish("ami 2 ta boi porbo")
        self.assertIn('আমি', result)
        self.assertIn('2', result)

if __name__ == '__main__':
    unittest.main()