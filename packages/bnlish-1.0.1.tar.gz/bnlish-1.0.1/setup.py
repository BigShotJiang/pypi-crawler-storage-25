from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="bnlish",
    version="1.0.1",
    author="Debashish Roy",
    author_email="thedeba@icloud.com",
    description="English to Bengali transliteration library",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/thedeba/banglish",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Natural Language :: Bengali",
    ],
    python_requires=">=3.7",
    install_requires=[
        "regex>=2023.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov",
            "black",
        ],
    },
)
