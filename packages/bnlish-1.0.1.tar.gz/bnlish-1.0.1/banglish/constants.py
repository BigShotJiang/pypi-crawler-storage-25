# Language constants
DIALECTS = ['standard', 'dhaka', 'chittagong', 'sylhet', 'khulna']

# Processing modes
TRANSLITERATION_MODES = {
    'strict': 'Exact character matching',
    'phonetic': 'Sound-based matching',
    'intelligent': 'AI-powered matching'
}

# Unicode ranges
BENGALI_UNICODE_START = 0x0980
BENGALI_UNICODE_END = 0x09FF

# Common patterns
BENGALI_PUNCTUATION = ['।', 'ঃ', '?', '!', ',', ';']
JOINT_LETTERS = ['ক্ষ', 'জ্ঞ', 'ঞ্চ', 'চ্ছ', 'ষ্ণ', 'দ্ধ']