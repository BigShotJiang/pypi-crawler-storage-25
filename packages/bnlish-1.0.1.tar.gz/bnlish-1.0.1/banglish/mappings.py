# Basic character mappings
BENGALI_VOWELS = {
    'অ': 'o', 'আ': 'a', 'ই': 'i', 'ঈ': 'ee',
    'উ': 'u', 'ঊ': 'oo', 'ঋ': 'ri',
    'এ': 'e', 'ঐ': 'oi', 'ও': 'o', 'ঔ': 'ou'
}

BENGALI_CONSONANTS = {
    'ক': 'k','খ': 'kh','গ': 'g','ঘ': 'gh','ঙ': 'ng',
    'চ': 'ch','ছ': 'chh','জ': 'j','ঝ': 'jh','ঞ': 'n',
    'ট': 't','ঠ': 'th','ড': 'd','ঢ': 'dh','ণ': 'n',
    'ত': 't','থ': 'th','দ': 'd','ধ': 'dh','ন': 'n',
    'প': 'p','ফ': 'ph','ব': 'b','ভ': 'bh','ম': 'm',
    'য': 'y','য়': 'y','র': 'r','ল': 'l','শ': 'sh',
    'ষ': 'sh','স': 's','হ': 'h'
}


# Kar (vowel signs)
KAR_MAPPING = {
    'া': 'a', 'ি': 'i', 'ী': 'ee', 'ু': 'u',
    'ূ': 'oo', 'ৃ': 'ri', 'ে': 'e', 'ৈ': 'oi',
    'ো': 'o', 'ৌ': 'ou'
}

# Compound consonant mappings
COMPOUND_CONSONANTS = {

    # Common conjuncts
    'ক্ষ': 'kkh', 'জ্ঞ': 'gg', 'ত্র': 'tr', 'দ্ব': 'dw',

    # st / sk / sp family
    'স্ত': 'st', 'স্থ': 'sth', 'স্ট': 'st', 'স্ট্র': 'str', 'স্ক': 'sk', 'স্ক্র': 'skr', 'স্প': 'sp', 'স্প্র': 'spr', 'স্ফ': 'sph', 'স্ম': 'sm', 'স্ন': 'sn', 'স্ব': 'sw',

    # nt / nd family
    'ন্ত': 'nt', 'ন্ত্র': 'ntr', 'ন্ত্ব': 'ntw', 'ন্দ': 'nd', 'ন্ধ': 'ndh', 'ন্দ্র': 'ndr', 'ন্ধ্র': 'ndhr',

    # mp / mb family
    'ম্প': 'mp', 'ম্ভ': 'mbh', 'ম্ব': 'mb', 'ম্ব্র': 'mbr',

    # ng / nk family
    'ঙ্গ': 'ng', 'ঙ্গা': 'nga', 'ঙ্গী': 'ngi', 'ঙ্ক': 'nk', 'ঙ্খ': 'nkh', 'ঙ্গ্র': 'ngr',

    # ch / j family
    'চ্ছ': 'cch', 'চ্ছ্ব': 'cchw', 'জ্জ': 'jj', 'জ্জ্ব': 'jjw', 'ঞ্জ': 'nj', 'ঞ্জ্ঞ': 'ngg',

    # k / g family
    'ক্ত': 'kt', 'ক্ত্র': 'ktr', 'ক্ত্ব': 'ktw', 'গ্ন': 'gn', 'গ্ধ': 'gdh', 'গ্ধ্ব': 'gdhw', 'গ্ম': 'gm', 'গ্ল': 'gl', 'গ্র': 'gr',

    # kr / pr / br / dr
    'ক্র': 'kr', 'ক্র্য': 'kry', 'প্র': 'pr', 'প্র্য': 'pry', 'প্ল': 'pl', 'ব্র': 'br', 'ব্ল': 'bl', 'ভ্র': 'bhr', 'দ্র': 'dr', 'দ্ভ': 'dbh', 'দ্ম': 'dm',

    # t / th / d family
    'ত্ত': 'tt', 'ত্থ': 'tth', 'ত্ম': 'tm', 'ত্ন': 'tn', 'দ্দ': 'dd', 'দ্ধ': 'ddh', 'দ্য': 'dy',

    # sh / sr family
    'শ্র': 'shr', 'শ্চ': 'shch', 'শ্ন': 'shn', 'ষ্ক': 'shk', 'ষ্ট': 'sht', 'ষ্ঠ': 'shth', 'ষ্ণ': 'shn', 'স্র': 'sr',

    # h family
    'হ্ম': 'hm', 'হ্ন': 'hn', 'হ্ল': 'hl',

    # r-phala / y-phala style
    'র্ক': 'rk', 'র্ঘ': 'rgh', 'র্গ': 'rg', 'র্চ': 'rch', 'র্জ': 'rj', 'র্থ': 'rth', 'র্দ': 'rd', 'র্ধ': 'rdh', 'র্ন': 'rn', 'র্প': 'rp', 'র্ফ': 'rph', 'র্ব': 'rb', 'র্ভ': 'rbh', 'র্ম': 'rm', 'র্ল': 'rl', 'র্ষ': 'rsh', 'র্স': 'rs', 'র্হ': 'rh',

    # miscellaneous
    'ল্ক': 'lk', 'ল্গ': 'lg', 'ল্প': 'lp', 'ল্ব': 'lb', 'র্গ্য': 'rgy', 'ব্য': 'by', 'ভ্য': 'bhy', 'ম্য': 'my', 'ন্য': 'ny', 'ল্য': 'ly', 'র্য': 'ry'
}

# Common words dictionary
COMMON_WORDS = {

    # Basic pronouns
    'ami': 'আমি', 'amra': 'আমরা', 'tumi': 'তুমি', 'tomra': 'তোমরা', 'apni': 'আপনি', 'apnara': 'আপনারা', 'she': 'সে', 'tara': 'তারা',

    # Common verbs
    'achi': 'আছি', 'aso': 'আসো', 'asen': 'আসেন', 'ashbo': 'আসব', 'ashchi': 'আসছি', 'jabo': 'যাবো', 'jacchi': 'যাচ্ছি', 'gelam': 'গেলাম', 'korbo': 'করবো', 'korchi': 'করছি', 'korte': 'করতে', 'koro': 'করো', 'koren': 'করেন', 'khabo': 'খাবো', 'khacchi': 'খাচ্ছি', 'khelam': 'খেলাম', 'dekho': 'দেখো', 'dekhen': 'দেখেন', 'shuno': 'শুনো', 'bolchi': 'বলছি', 'bolbo': 'বলবো', 'bolen': 'বলেন', 'paro': 'পারো', 'parbo': 'পারবো', 'chai': 'চাই', 'lagbe': 'লাগবে', 'hobe': 'হবে', 'holo': 'হলো', 'chilam': 'ছিলাম', 'thakbo': 'থাকবো',

    # Common nouns
    'bhat': 'ভাত', 'pani': 'পানি', 'ghor': 'ঘর', 'bari': 'বাড়ি', 'school': 'স্কুল', 'college': 'কলেজ', 'boi': 'বই', 'khela': 'খেলা', 'gaan': 'গান', 'golpo': 'গল্প', 'bondhu': 'বন্ধু', 'manush': 'মানুষ', 'chele': 'ছেলে', 'meye': 'মেয়ে', 'rasta': 'রাস্তা', 'gari': 'গাড়ি', 'mobile': 'মোবাইল', 'computer': 'কম্পিউটার', 'internet': 'ইন্টারনেট', 'kaj': 'কাজ', 'chakri': 'চাকরি', 'bazar': 'বাজার', 'dokaan': 'দোকান',

    # Feelings / expressions
    'bhalo': 'ভালো', 'kharap': 'খারাপ', 'shundor': 'সুন্দর', 'moja': 'মজা', 'koshto': 'কষ্ট', 'bhoy': 'ভয়', 'rag': 'রাগ', 'valo': 'ভালো', 'valoachi': 'ভালোআছি',

    # Greetings
    'assalamu alaikum': 'আসসালামু আলাইকুম', 'walaikum assalam': 'ওয়ালাইকুম আসসালাম', 'hello': 'হ্যালো', 'hi': 'হাই', 'bye': 'বাই', 'allah hafez': 'আল্লাহ হাফেজ', 'khoda hafez': 'খোদা হাফেজ',

    # Courtesy
    'dhonnobad': 'ধন্যবাদ', 'thanks': 'থ্যাংকস', 'sorry': 'সরি', 'plz': 'প্লিজ', 'please': 'প্লিজ', 'welcome': 'স্বাগতম', 'shukria': 'শুক্রিয়া',

    # Religious / cultural
    'inshallah': 'ইনশাআল্লাহ', 'alhamdulillah': 'আলহামদুলিল্লাহ', 'mashallah': 'মাশাআল্লাহ', 'subhanallah': 'সুবহানাল্লাহ', 'astagfirullah': 'আস্তাগফিরুল্লাহ',

    # Music / poetry style words
    'hridoye': 'হৃদয়ে', 'tomar': 'তোমার', 'amar': 'আমার', 'kirtan': 'কীর্তন', 'baje': 'বাজে', 'kshama': 'ক্ষমা', 'kshomo': 'ক্ষম', 'dinanath': 'দীননাথ', 'priyo': 'প্রিয়', 'bhalobasha': 'ভালোবাসা', 'mon': 'মন', 'shopno': 'স্বপ্ন', 'jibon': 'জীবন', 'mrityu': 'মৃত্যু',

    # Question words
    'ki': 'কি', 'keno': 'কেন', 'kothay': 'কোথায়', 'kokhon': 'কখন', 'kivabe': 'কিভাবে', 'karon': 'কারণ',

    # Days / time
    'aj': 'আজ', 'kal': 'কাল', 'shokal': 'সকাল', 'dupur': 'দুপুর', 'bikal': 'বিকাল', 'raat': 'রাত',

    # Numbers
    'ek': 'এক', 'dui': 'দুই', 'tin': 'তিন', 'char': 'চার', 'pach': 'পাঁচ', 'choy': 'ছয়', 'sat': 'সাত', 'aat': 'আট', 'noy': 'নয়', 'dosh': 'দশ',

    # Family
    'ma': 'মা', 'baba': 'বাবা', 'vai': 'ভাই', 'bhai': 'ভাই', 'bon': 'বোন', 'apu': 'আপু', 'dada': 'দাদা', 'dadi': 'দাদি', 'nana': 'নানা', 'nani': 'নানি', 'chacha': 'চাচা', 'mama': 'মামা', 'khalu': 'খালু', 'fufu': 'ফুফু',

    # Daily conversation
    'accha': 'আচ্ছা', 'thik': 'ঠিক', 'thikache': 'ঠিকআছে', 'nah': 'না', 'na': 'না', 'haan': 'হ্যাঁ', 'ji': 'জি', 'oke': 'ওকে', 'achha': 'আচ্ছা', 'bujhsi': 'বুঝছি', 'bujhlam': 'বুঝলাম', 'janina': 'জানিনা', 'jani': 'জানি', 'monehoy': 'মনে হয়', 'ashole': 'আসলে', 'ekdom': 'একদম',

    # Food
    'mangsho': 'মাংস', 'mach': 'মাছ', 'dim': 'ডিম', 'dudh': 'দুধ', 'cha': 'চা', 'coffee': 'কফি', 'mishti': 'মিষ্টি', 'roti': 'রুটি', 'dal': 'ডাল', 'sobji': 'সবজি', 'polao': 'পোলাও', 'biriyani': 'বিরিয়ানি',

    # Nature
    'akash': 'আকাশ', 'mati': 'মাটি', 'nodhi': 'নদী', 'bristi': 'বৃষ্টি', 'rod': 'রোদ', 'batas': 'বাতাস', 'gach': 'গাছ', 'ful': 'ফুল', 'pakhi': 'পাখি', 'pahar': 'পাহাড়', 'shagor': 'সাগর',

    # Emotions
    'hashi': 'হাসি', 'kanna': 'কান্না', 'valobashi': 'ভালোবাসি', 'misskorchi': 'মিসকরছি', 'monkharap': 'মনখারাপ', 'khushi': 'খুশি', 'utsob': 'উৎসব',

    # Technology
    'facebook': 'ফেসবুক', 'youtube': 'ইউটিউব', 'google': 'গুগল', 'chatgpt': 'চ্যাটজিপিটি', 'message': 'মেসেজ', 'call': 'কল', 'video': 'ভিডিও', 'photo': 'ফটো', 'camera': 'ক্যামেরা', 'charger': 'চার্জার', 'wifi': 'ওয়াইফাই',

    # Travel / places
    'station': 'স্টেশন', 'airport': 'এয়ারপোর্ট', 'bus': 'বাস', 'train': 'ট্রেন', 'rickshaw': 'রিকশা', 'hotel': 'হোটেল', 'hospital': 'হাসপাতাল', 'park': 'পার্ক', 'mosjid': 'মসজিদ', 'mondir': 'মন্দির',

    # Internet slang
    'lol': 'লল', 'bro': 'ব্রো', 'sis': 'সিস', 'omg': 'ওএমজি', 'wtf': 'ডব্লিউটিএফ', 'idk': 'আইডিকে', 'tbh': 'টিবিএইচ',

    # Romantic
    'jan': 'জান', 'sona': 'সোনা', 'pran': 'প্রাণ', 'kolija': 'কলিজা', 'pagol': 'পাগল', 'maya': 'মায়া',

    # Misc
    'bangladesh': 'বাংলাদেশ', 'kolkata': 'কলকাতা', 'dhaka': 'ঢাকা', 'india': 'ইন্ডিয়া', 'bangla': 'বাংলা', 'banglish': 'বাংলিশ', 'vasha': 'ভাষা', 'bhasha': 'ভাষা', 'lekha': 'লেখা', 'pora': 'পড়া', 'shikkha': 'শিক্ষা', 'biggan': 'বিজ্ঞান', 'projukti': 'প্রযুক্তি'
}

# English to Banglish word mappings
ENGLISH_TO_BANGLISH = {
    # Basic pronouns
    'i': 'ami', 'we': 'amra', 'you': 'tumi', 'he': 'se', 'she': 'se', 'they': 'tara',
    
    # Basic verbs
    'am': 'achi', 'are': 'acho', 'is': 'ache', 'was': 'chilam', 'were': 'chilen', 
    'have': 'ache', 'has': 'ache', 'had': 'chilo',
    'do': 'kori', 'does': 'koren', 'did': 'korlam',
    'go': 'jabo', 'goes': 'jay', 'went': 'gelam', 'will': 'jabo',
    'come': 'ashbo', 'comes': 'asen', 'came': 'ashlam',
    'eat': 'khabo', 'eats': 'khaben', 'ate': 'kheyechilam',
    'see': 'dekhi', 'sees': 'dekhen', 'saw': 'dekhlam',
    'know': 'jani', 'knows': 'janen', 'knew': 'janlam',
    'think': 'boli', 'thinks': 'balen', 'thought': 'bolam',
    'want': 'chai', 'wants': 'chay', 'wanted': 'chilam',
    'can': 'parbo', 'could': 'parbam', 'will': 'jabo', 'would': 'jabo',
    
    # Basic adjectives
    'good': 'bhalo', 'bad': 'kharap', 'big': 'boro', 'small': 'choto', 
    'nice': 'bhalo', 'beautiful': 'shundor', 'happy': 'khushi', 'sad': 'koshto',
    'well': 'bhalo', 'fine': 'bhalo', 'ok': 'thik', 'okay': 'thik',
    
    # Basic nouns
    'man': 'manush', 'woman': 'meye', 'boy': 'chele', 'girl': 'meye',
    'house': 'ghor', 'home': 'ghor', 'book': 'boi', 'books': 'boi',
    'water': 'pani', 'food': 'khabar', 'rice': 'bhat', 'money': 'taka',
    'friend': 'bondhu', 'family': 'paribar', 'love': 'bhalobasha',
    
    # Question words
    'what': 'ki', 'where': 'kothay', 'when': 'kokhon', 'why': 'keno', 
    'how': 'kivabe', 'who': 'ke', 'which': 'kon',
    
    # Prepositions/conjunctions
    'and': 'ar', 'or': 'oba', 'but': 'kintu', 'if': 'jodi', 'because': 'karon',
    'to': 'te', 'for': 'jonno', 'with': 'sathe', 'from': 'theke', 'at': 'te',
    'in': 'moddhe', 'on': 'upor', 'under': 'niche',
    
    # Common phrases
    'hello': 'namaskar', 'hi': 'namaskar', 'bye': 'biday', 'thanks': 'dhonnobad',
    'please': 'doya kore', 'sorry': 'dukkhito', 'excuse': 'khoma',
    
    # Time
    'today': 'aj', 'tomorrow': 'kal', 'yesterday': 'gotokal', 'now': 'ekhon',
    'morning': 'sokal', 'evening': 'sondha', 'night': 'raat', 'day': 'din',
    
    # Numbers
    'one': 'ek', 'two': 'dui', 'three': 'tin', 'four': 'char', 'five': 'pach',
    'ten': 'dosh', 'hundred': 'shoto', 'thousand': 'hazar',

    # Family & Relationship 
    'father': 'baba', 'mother': 'ma', 'brother': 'bhai', 'sister': 'bon', 'uncle': 'chacha', 'aunt': 'khala', 'son': 'chele', 'daughter': 'meye', 'wife': 'bou', 'husband': 'shami',

    # Colors
    'red': 'lal', 'blue': 'nil', 'green': 'sobuj', 'yellow': 'holud', 'black': 'kalo', 'white': 'sada',

    # Weather
    'rain': 'brishti', 'sun': 'rod', 'wind': 'batash', 'cloud': 'megh', 'river': 'nodi', 'flower': 'ful', 'tree': 'gach', 'bird': 'pakhi',

    # Emotions
    'angry': 'rag', 'tired': 'klanto', 'excited': 'utshahito', 'confused': 'bivhranto', 'afraid': 'bhoy', 'lonely': 'eka', 'cry': 'kanna', 'smile': 'hashi',

    # Internet/Tech
    'internet': 'internet', 'computer': 'computer', 'mobile': 'mobile', 'phone': 'phone', 'message': 'message', 'call': 'call', 'video': 'video', 'photo': 'photo', 'email': 'email', 'password': 'password',

    # Places
    'school': 'school', 'college': 'college', 'university': 'bishobidyaloy', 'market': 'bazar', 'hospital': 'hospital', 'mosque': 'mosjid', 'temple': 'mondir', 'road': 'rasta', 'city': 'shohor', 'village': 'gram',

    # 

    # Common Actions
    'write': 'likhi', 'read': 'pori', 'listen': 'shuni', 'speak': 'boli', 'sleep': 'ghumai', 'wake': 'uthi', 'walk': 'hati', 'run': 'douri', 'play': 'kheli', 'study': 'porashona kori',
}
