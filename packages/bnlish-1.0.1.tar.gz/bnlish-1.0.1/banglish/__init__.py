"""
Banglish - English to Bengali Transliteration Library
"""

from .translator import BanglishTranslator
from .utils import TextProcessor
from .mappings import ENGLISH_TO_BANGLISH, COMMON_WORDS

__version__ = "0.1.0"
__author__ = "Your Name"
__all__ = ['BanglishTranslator', 'TextProcessor', 'bengali_to_banglish', 'banglish_to_bn', 'bn_to_banglish', 'english_to_banglish', 'banglish_to_english', 'en_to_banglish', 'banglish_to_en']

# Convenience functions
def translate(text):
    """Quick translation function"""
    translator = BanglishTranslator()
    return translator.to_banglish(text)

def suggest(text):
    """Get word suggestions"""
    translator = BanglishTranslator()
    return translator.suggest(text)

def bengali_to_banglish(text):
    """Convert Bengali text to Banglish"""
    translator = BanglishTranslator()
    return translator.to_banglish_from_bengali(text)

def english_to_banglish(text):
    """Convert standard English to Banglish (Roman script Bengali)"""
    words = text.lower().split()
    result = []
    
    for word in words:
        # Remove punctuation for mapping lookup
        clean_word = word.strip('.,!?;:')
        punctuation = word[len(clean_word):] if len(word) > len(clean_word) else ''
        
        # Check if word exists in English to Banglish mappings
        if clean_word in ENGLISH_TO_BANGLISH:
            result.append(ENGLISH_TO_BANGLISH[clean_word] + punctuation)
        else:
            # If no mapping found, keep original word
            result.append(word)
    
    return ' '.join(result)

def banglish_to_english(text):
    """Convert Banglish to standard English"""
    words = text.lower().split()
    result = []
    
    for word in words:
        # Remove punctuation for mapping lookup
        clean_word = word.strip('.,!?;:')
        punctuation = word[len(clean_word):] if len(word) > len(clean_word) else ''
        
        # Check if word exists in COMMON_WORDS (Banglish to Bengali mappings)
        # Create reverse mapping from Banglish to English
        found = False
        for english_word, bengali_word in COMMON_WORDS.items():
            if english_word == clean_word:
                # This is already Banglish, convert to English
                # Create reverse lookup from ENGLISH_TO_BANGLISH
                for eng, banglish in ENGLISH_TO_BANGLISH.items():
                    if banglish == clean_word:
                        result.append(eng + punctuation)
                        found = True
                        break
                if found:
                    break
        
        if not found:
            # If no mapping found, keep original word
            result.append(word)
    
    return ' '.join(result)

# User-friendly aliases
banglish_to_bn = translate
bn_to_banglish = bengali_to_banglish
en_to_banglish = english_to_banglish
banglish_to_en = banglish_to_english