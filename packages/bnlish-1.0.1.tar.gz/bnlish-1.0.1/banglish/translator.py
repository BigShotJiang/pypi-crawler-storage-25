from .mappings import (BENGALI_VOWELS, BENGALI_CONSONANTS, 
                       KAR_MAPPING, COMMON_WORDS, COMPOUND_CONSONANTS)
from .utils import TextProcessor

class BanglishTranslator:
    def __init__(self):
        self.processor = TextProcessor()
        self._build_reverse_mappings()
        self._build_bengali_to_english_mappings()
    
    def _build_reverse_mappings(self):
        """Build reverse mappings for Bengali to Banglish"""
        self.english_to_bengali = {}
        
        # Vowels reverse mapping
        for bangla, english in BENGALI_VOWELS.items():
            self.english_to_bengali[english] = bangla
        
        # Consonants reverse mapping
        for bangla, english in BENGALI_CONSONANTS.items():
            self.english_to_bengali[english] = bangla
        
        # Compound consonants reverse mapping
        for bangla, english in COMPOUND_CONSONANTS.items():
            self.english_to_bengali[english] = bangla
    
    def _build_bengali_to_english_mappings(self):
        """Build Bengali to English mappings for reverse transliteration"""
        self.bengali_to_english = {}
        
        # Vowels mapping
        for bangla, english in BENGALI_VOWELS.items():
            self.bengali_to_english[bangla] = english
        
        # Consonants mapping
        for bangla, english in BENGALI_CONSONANTS.items():
            self.bengali_to_english[bangla] = english
        
        # Compound consonants mapping
        for bangla, english in COMPOUND_CONSONANTS.items():
            self.bengali_to_english[bangla] = english
        
        # Kar (vowel signs) mapping
        for bangla, english in KAR_MAPPING.items():
            self.bengali_to_english[bangla] = english
    
    def to_banglish(self, text):
        """English text to Banglish/Bengali conversion"""
        text = self.processor.normalize_text(text)
        words = text.split()
        result = []
        
        for word in words:
            # First check common words dictionary
            if word in COMMON_WORDS:
                result.append(COMMON_WORDS[word])
                continue
            
            # Process character by character
            bangla_word = self._convert_word(word)
            result.append(bangla_word)
        
        return ' '.join(result)
    
    def _convert_word(self, word):
        """Single word conversion with syllable handling"""
        # Implementation of character-by-character conversion
        converted = ""
        i = 0
        
        while i < len(word):
            matched = False
            
            # Try matching longer patterns first (3 chars, then 2, then 1)
            for length in [3, 2, 1]:
                if i + length <= len(word):
                    chunk = word[i:i+length]
                    if chunk in self.english_to_bengali:
                        converted += self.english_to_bengali[chunk]
                        i += length
                        matched = True
                        break
            
            if not matched:
                converted += word[i]
                i += 1
        
        return converted
    
    def to_bengali(self, banglish_text):
        """Banglish text to proper Bengali conversion"""
        return self.to_banglish(banglish_text)
    
    def to_banglish_from_bengali(self, bengali_text):
        """Bengali text to Banglish conversion"""
        text = self.processor.normalize_text(bengali_text)
        words = text.split()
        result = []
        
        for word in words:
            # First check reverse common words dictionary
            converted_word = self._convert_bengali_word(word)
            result.append(converted_word)
        
        return ' '.join(result)
    
    def _convert_bengali_word(self, word):
        """Single Bengali word to Banglish conversion"""
        # Check if word exists in COMMON_WORDS values
        for english, bengali in COMMON_WORDS.items():
            if bengali == word:
                return english
        
        # Process character by character using reverse mappings
        converted = ""
        i = 0
        
        while i < len(word):
            matched = False
            
            # Try matching longer patterns first (compound consonants, then regular)
            for length in [3, 2, 1]:
                if i + length <= len(word):
                    chunk = word[i:i+length]
                    if chunk in self.bengali_to_english:
                        converted += self.bengali_to_english[chunk]
                        i += length
                        matched = True
                        break
            
            if not matched:
                converted += word[i]
                i += 1
        
        return converted
    
    def suggest(self, partial_word):
        """Word suggestions for incomplete typing"""
        suggestions = []
        partial = partial_word.lower()
        
        for word in COMMON_WORDS:
            if word.startswith(partial):
                suggestions.append({
                    'english': word,
                    'bangla': COMMON_WORDS[word]
                })
        
        return suggestions[:5]  # Top 5 suggestions