import re
import unicodedata

class TextProcessor:
    @staticmethod
    def normalize_text(text):
        """Unicode normalize kora"""
        return unicodedata.normalize('NFC', text.lower().strip())
    
    @staticmethod
    def split_syllables(word):
        """Word ke syllable e convert kora"""
        vowels = 'aeiou'
        syllables = []
        current = ""
        
        for char in word:
            current += char
            if char in vowels:
                syllables.append(current)
                current = ""
        
        if current:
            syllables.append(current)
        
        return syllables
    
    @staticmethod
    def is_bengali(char):
        """Check if character is Bengali"""
        return '\u0980' <= char <= '\u09FF'
    
    @staticmethod
    def clean_banglish(text):
        """Banglish text clean kora"""
        # Extra spaces remove
        text = re.sub(r'\s+', ' ', text).strip()
        # Special characters handle
        text = text.replace('।', '.').replace('ঃ', ':')
        return text