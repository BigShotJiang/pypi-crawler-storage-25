from __future__ import annotations

import argparse
from .config import (
    DEFAULT_BACKUP_DIR,
    DEFAULT_COOLDOWN_DISPLAY_LIMIT,
    DEFAULT_CODEX_HOME,
    load_config,
)


def get_parser() -> argparse.ArgumentParser:
    config = load_config()

    def _get_default(key: str, fallback: str | int | float | bool | None) -> str | int | float | bool | None:
        return config.get(key, fallback)

    parser = argparse.ArgumentParser(prog="codex-manager")
    subparsers = parser.add_subparsers(dest="command")

    cooldown_parser = subparsers.add_parser(
        "cooldown",
        help="Show weekly availability from backup metadata, optionally merged with live Codex status.",
    )
    cooldown_parser.add_argument(
        "--backup-dir",
        default=str(DEFAULT_BACKUP_DIR),
        help="Directory containing backup archives and metadata.",
    )
    cooldown_parser.add_argument(
        "--live",
        action="store_true",
        help="Query current live account via /status and merge with stored backups.",
    )
    cooldown_parser.add_argument(
        "--status-command",
        help="Shell command that prints parseable Codex status text for --live mode.",
    )
    cooldown_parser.add_argument(
        "--codex-command",
        default="codex --no-alt-screen",
        help="Command used to launch Codex for live tmux capture in --live mode.",
    )
    cooldown_parser.add_argument(
        "--tmux-session-name",
        default="codexmgr_capture",
        help="Temporary tmux session name used for live status capture in --live mode.",
    )
    cooldown_parser.add_argument(
        "--tmux-cols",
        type=int,
        default=120,
        help="tmux capture width for live status capture in --live mode.",
    )
    cooldown_parser.add_argument(
        "--tmux-rows",
        type=int,
        default=40,
        help="tmux capture height for live status capture in --live mode.",
    )
    cooldown_parser.add_argument(
        "--startup-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the Codex prompt in --live mode.",
    )
    cooldown_parser.add_argument(
        "--status-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the status panel in --live mode.",
    )
    cooldown_parser.add_argument(
        "--limit",
        type=int,
        default=DEFAULT_COOLDOWN_DISPLAY_LIMIT,
        help="Maximum number of accounts to display.",
    )

    recommend_parser = subparsers.add_parser(
        "recommend",
        help="Recommend the best account to use next from backup metadata, optionally merged with live Codex status.",
    )
    recommend_parser.add_argument(
        "--backup-dir",
        default=str(DEFAULT_BACKUP_DIR),
        help="Directory containing backup archives and metadata.",
    )
    recommend_parser.add_argument(
        "--live",
        action="store_true",
        help="Query current live account via /status and merge with stored backups.",
    )
    recommend_parser.add_argument(
        "--status-command",
        help="Shell command that prints parseable Codex status text for --live mode.",
    )
    recommend_parser.add_argument(
        "--reference-year",
        type=int,
        help="Year used when the status text omits the year in reset time.",
    )
    recommend_parser.add_argument(
        "--codex-command",
        default="codex --no-alt-screen",
        help="Command used to launch Codex for live tmux capture in --live mode.",
    )
    recommend_parser.add_argument(
        "--tmux-session-name",
        default="codexmgr_capture",
        help="Temporary tmux session name used for live status capture in --live mode.",
    )
    recommend_parser.add_argument(
        "--tmux-cols",
        type=int,
        default=120,
        help="tmux capture width for live status capture in --live mode.",
    )
    recommend_parser.add_argument(
        "--tmux-rows",
        type=int,
        default=40,
        help="tmux capture height for live status capture in --live mode.",
    )
    recommend_parser.add_argument(
        "--startup-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the Codex prompt in --live mode.",
    )
    recommend_parser.add_argument(
        "--status-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the status panel in --live mode.",
    )

    status_parser = subparsers.add_parser(
        "status-parse",
        help="Parse Codex /status text or tmux helper output into exact backup metadata.",
    )
    status_parser.add_argument(
        "--input-file",
        help="Read status text from a file instead of stdin.",
    )
    status_parser.add_argument(
        "--status-command",
        help="Shell command that prints parseable Codex status text.",
    )
    status_parser.add_argument(
        "--reference-year",
        type=int,
        help="Year used when the status text omits the year in reset time.",
    )
    status_parser.add_argument(
        "--codex-command",
        default="codex --no-alt-screen",
        help="Command used to launch Codex for live tmux capture.",
    )
    status_parser.add_argument(
        "--tmux-session-name",
        default="codexmgr_capture",
        help="Temporary tmux session name used for live status capture.",
    )
    status_parser.add_argument(
        "--tmux-cols",
        type=int,
        default=120,
        help="tmux capture width for live status capture.",
    )
    status_parser.add_argument(
        "--tmux-rows",
        type=int,
        default=40,
        help="tmux capture height for live status capture.",
    )
    status_parser.add_argument(
        "--startup-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the Codex prompt.",
    )
    status_parser.add_argument(
        "--status-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the status panel.",
    )

    backup_parser = subparsers.add_parser(
        "backup",
        help="Create a live Codex backup named from exact /status reset time.",
    )
    backup_parser.add_argument(
        "--source-dir",
        default=str(DEFAULT_CODEX_HOME),
        help="Codex home directory to archive.",
    )
    backup_parser.add_argument(
        "--backup-dir",
        default=str(DEFAULT_BACKUP_DIR),
        help="Directory where backup archives and metadata are written.",
    )
    backup_parser.add_argument(
        "--status-file",
        help="Read Codex status text from a file instead of capturing it live.",
    )
    backup_parser.add_argument(
        "--status-command",
        help="Shell command that prints parseable Codex status text.",
    )
    backup_parser.add_argument(
        "--reference-year",
        type=int,
        help="Year used when the status text omits the year in reset time.",
    )
    backup_parser.add_argument(
        "--codex-command",
        default="codex --no-alt-screen",
        help="Command used to launch Codex for live tmux capture.",
    )
    backup_parser.add_argument(
        "--tmux-session-name",
        default="codexmgr_capture",
        help="Temporary tmux session name used for live status capture.",
    )
    backup_parser.add_argument(
        "--tmux-cols",
        type=int,
        default=120,
        help="tmux capture width for live status capture.",
    )
    backup_parser.add_argument(
        "--tmux-rows",
        type=int,
        default=40,
        help="tmux capture height for live status capture.",
    )
    backup_parser.add_argument(
        "--startup-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the Codex prompt.",
    )
    backup_parser.add_argument(
        "--status-timeout-seconds",
        type=float,
        default=20.0,
        help="Seconds to wait for the status panel.",
    )
    backup_parser.add_argument(
        "--include-tmp",
        action="store_true",
        help="Include tmp and .tmp directories in the archive.",
    )
    backup_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Compute paths and metadata without creating files.",
    )
    backup_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing archive if the computed name already exists.",
    )
    backup_parser.add_argument(
        "--auth-only",
        action="store_true",
        help="Only backup auth.json, config.toml, installation_id, etc. instead of the full state.",
    )
    backup_parser.add_argument(
        "--prune-first",
        action="store_true",
        help="Run prune on runtime state before taking the backup.",
    )

    restore_parser = subparsers.add_parser(
        "restore",
        help="Restore a Codex backup archive into a target Codex home directory.",
    )
    restore_parser.add_argument(
        "--from-archive",
        help="Path to a specific Codex backup archive.",
    )
    restore_parser.add_argument(
        "--email",
        help="Restore from the latest symlink for this email.",
    )
    restore_parser.add_argument(
        "--backup-dir",
        default=str(_get_default("backup_dir", str(DEFAULT_BACKUP_DIR))),
        help="Directory containing backup archives and metadata.",
    )
    restore_parser.add_argument(
        "--dest-dir",
        default=str(_get_default("codex_home", str(DEFAULT_CODEX_HOME))),
        help="Codex home directory to restore into.",
    )
    restore_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and stage the restore without changing the destination.",
    )
    restore_parser.add_argument(
        "--force",
        action="store_true",
        help="Delete an existing destination instead of moving it aside to a timestamped .bak path.",
    )

    list_backups_parser = subparsers.add_parser(
        "list-backups",
        help="List available Codex backup archives with metadata.",
    )
    list_backups_parser.add_argument(
        "--backup-dir",
        default=str(_get_default("backup_dir", str(DEFAULT_BACKUP_DIR))),
        help="Directory containing backup archives and metadata.",
    )
    list_backups_parser.add_argument(
        "--email",
        help="Filter backups for a specific email.",
    )
    list_backups_parser.add_argument(
        "--latest-per-email",
        action="store_true",
        help="Only show the latest backup for each email.",
    )
    list_backups_parser.add_argument(
        "--ready",
        action="store_true",
        help="Only show backups whose cooldown has expired.",
    )
    list_backups_parser.add_argument(
        "--sort",
        choices=["reset_at", "session_start_at", "created_at"],
        default="created_at",
        help="Sort backups by the specified field.",
    )
    list_backups_parser.add_argument(
        "--json",
        action="store_true",
        help="Output the list as JSON.",
    )

    prune_backups_parser = subparsers.add_parser(
        "prune-backups",
        help="Delete old backup archives.",
    )
    prune_backups_parser.add_argument(
        "--backup-dir",
        default=str(_get_default("backup_dir", str(DEFAULT_BACKUP_DIR))),
        help="Directory containing backup archives and metadata.",
    )
    prune_backups_parser.add_argument(
        "--keep",
        type=int,
        help="Number of most recent backups to keep.",
    )
    prune_backups_parser.add_argument(
        "--keep-latest-per-email",
        action="store_true",
        help="Keep only the latest backup per email, pruning all older ones.",
    )
    prune_backups_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be removed without deleting anything.",
    )

    profile_parser = subparsers.add_parser(
        "profile",
        help="Export or import the complete codex manager profile state.",
    )
    profile_parser.add_argument(
        "action",
        choices=["export", "import"],
        help="Action to perform: export or import.",
    )
    profile_parser.add_argument(
        "file",
        help="Path to the profile archive (.tar.gz) to export to or import from.",
    )

    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Verify dependencies, directories, and status parser.",
    )
    doctor_parser.add_argument(
        "--source-dir",
        default=str(_get_default("codex_home", str(DEFAULT_CODEX_HOME))),
        help="Codex home directory to check.",
    )
    doctor_parser.add_argument(
        "--backup-dir",
        default=str(_get_default("backup_dir", str(DEFAULT_BACKUP_DIR))),
        help="Directory containing backup archives and metadata to check.",
    )

    prune_parser = subparsers.add_parser(
        "prune",
        help="Remove Codex runtime state while preserving auth.json and account identity.",
    )
    prune_parser.add_argument(
        "--source-dir",
        default=str(_get_default("codex_home", str(DEFAULT_CODEX_HOME))),
        help="Codex home directory to prune.",
    )
    prune_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be removed without deleting anything.",
    )

    use_parser = subparsers.add_parser(
        "use",
        help="Switch to a backed-up account. Default is auth-only; --clean performs a clean-state restore.",
    )
    use_parser.add_argument(
        "--from-archive",
        help="Path to a specific Codex backup archive.",
    )
    use_parser.add_argument(
        "--email",
        help="Use the latest backup symlink for this email.",
    )
    use_parser.add_argument(
        "--backup-dir",
        default=str(_get_default("backup_dir", str(DEFAULT_BACKUP_DIR))),
        help="Directory containing backup archives and metadata.",
    )
    use_parser.add_argument(
        "--dest-dir",
        default=str(_get_default("codex_home", str(DEFAULT_CODEX_HOME))),
        help="Codex home directory to restore into.",
    )
    use_parser.add_argument(
        "--clean",
        action="store_true",
        help="Prune runtime state and then do a full restore for a clean start.",
    )
    use_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would happen without modifying the destination.",
    )
    use_parser.add_argument(
        "--force",
        action="store_true",
        help="Reserved for future full-restore switching behavior; auth-only switching does not replace the whole destination.",
    )

    sync_parser = subparsers.add_parser(
        "sync",
        help="Sync backups to or from an S3-compatible bucket.",
    )
    sync_parser.add_argument(
        "direction",
        choices=["push", "pull"],
        help="Direction to sync: 'push' to upload, 'pull' to download.",
    )
    sync_parser.add_argument(
        "--bucket-name",
        required=True,
        help="Name of the S3 bucket to sync with.",
    )
    sync_parser.add_argument(
        "--endpoint-url",
        help="S3 endpoint URL (e.g. for Backblaze B2). Defaults to AWS_ENDPOINT_URL env var.",
    )
    sync_parser.add_argument(
        "--access-key",
        help="AWS access key ID. Defaults to AWS_ACCESS_KEY_ID env var.",
    )
    sync_parser.add_argument(
        "--secret-key",
        help="AWS secret access key. Defaults to AWS_SECRET_ACCESS_KEY env var.",
    )
    sync_parser.add_argument(
        "--backup-dir",
        default=str(_get_default("backup_dir", str(DEFAULT_BACKUP_DIR))),
        help="Directory containing backup archives and metadata.",
    )
    sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would happen without actually syncing.",
    )

    return parser
