"""
Patera application class
"""

# mypy: check-untyped-defs = True
import importlib
import os
import inspect
from collections.abc import AsyncIterator, Iterable
from enum import StrEnum
from pathlib import Path
from typing import (
    Any,
    Callable,
    Generic,
    List,
    Mapping,
    Optional,
    Type,
    TypeVar,
    cast,
    AsyncIterable,
    Union,
)
import aiofiles
from loguru import logger
from loguru._logger import Logger
from werkzeug.exceptions import NotFound, MethodNotAllowed

from jinja2 import (
    Environment,
    FileSystemLoader,
    select_autoescape,
    StrictUndefined,
    Undefined,
)

from .ctx import current_request, CurrentContextProxy
from .exceptions.http_exceptions import HtmlAborterException
from .http_statuses import HttpStatus
from .http_methods import HttpMethod
from .request import Request
from .response import Response
from .utilities import (
    get_app_root_path,
    run_sync_or_async,
    _extract_response_type,
    find_python_files_by_name,
    encode_response_headers,
)
from .router import Router
from .static import Static
from .open_api import OpenAPIController
from .controller import path
from .logger import DefaultLogger
from .ctx import request_context
from .controller import Controller
from .exceptions import ExceptionHandler
from .configuration_base import BaseConfig
from .middleware import MiddlewareBase, AppCallableType
from .cli import CLIController
from .logging.logger_config_base import LoggerBase
from .logging.inmemory_buffer import InMemoryLogBuffer
from .injectable import Injectable
from .serializers import SerializerRegistry
from .response_renderer import ResponseRenderer

logger.remove()

PATERA_ASCIIART: str = r"""
  _____        _______ ______ _____
 |  __ \ /\   |__   __|  ____|  __ \     /\
 | |__) /  \     | |  | |__  | |__) |   /  \
 |  ___/ /\ \    | |  |  __| |  _  /   / /\ \
 | |  / ____ \   | |  | |____| | \ \  / ____ \
 |_| /_/    \_\  |_|  |______|_|  \_\/_/    \_\
A Fast, Simple, and Productive Python Web Framework
"""

PATERA_VERSION: str = "0.111.x"


def print_startup_message(
    host: str,
    port: int,
    debug_mode: bool,
    *,
    app_name: str = "Application",
    scheme: str = "http",
) -> None:
    url = f"{scheme}://{host}:{port}"

    mode_label = "DEVELOPMENT" if debug_mode else "PRODUCTION"

    print()
    print("═" * 64)
    print(f"  {app_name} is running")
    print("─" * 64)
    print(f"  Mode:    {mode_label}")
    print(f"  Host:    {host}")
    print(f"  Port:    {port}")
    print(f"  URL:     \033]8;;{url}\033\\{url}\033]8;;\033\\")
    print("═" * 64)
    print()


T = TypeVar("T", bound="Patera[Any]")
ConfT = TypeVar("ConfT", bound=BaseConfig)


def app_path(url_path: Optional[str] = None) -> Callable[[Type[T]], Type[T]]:
    def decorator(cls: Type[T]) -> Type[T]:
        setattr(cls, "_base_url_path", url_path)
        return cls

    return decorator


def app(import_name: str, configs: Type[ConfT]) -> Callable[[Type[T]], Type[T]]:
    def decorator(cls: Type[T]) -> Type[T]:
        setattr(cls, "_app_configs", {"import_name": import_name, "configs": configs})
        return cls

    return decorator


def on_startup(func: Callable) -> Callable:
    """
    Decorated methods will run in alphabetical order on app startup
    """
    setattr(func, "_on_startup_method", True)
    return func


def on_shutdown(func: Callable) -> Callable:
    """
    Decorated methods will run in alphabetical order on app shutdown
    """
    setattr(func, "_on_shutdown_method", True)
    return func


class ScopeType(StrEnum):
    LIFESPAN = "lifespan"
    HTTP = "http"
    WEBSOCKET = "websocket"


class MissingAppConfigurations(Exception):
    def __init__(
        self,
        msg: str = (
            "Missing application configurations. "
            "Please make sure to use the @app_configs "
            "decorator with appropriate arguments."
        ),
    ):
        super().__init__(msg)


class MissingImportModule(Exception):
    def __init__(self, msg: str):
        super().__init__(msg)


class WrongModuleLoadType(Exception):
    def __init__(self, msg: str):
        super().__init__(msg)


def validate_config(config_type: type[ConfT]) -> ConfT:
    if not inspect.isclass(config_type) or not issubclass(config_type, BaseConfig):
        raise MissingAppConfigurations(
            "Configs must be a subclass of patera.BaseConfig."
        )

    try:
        config_factory = cast(Callable[[], ConfT], config_type)
        return config_factory()
    except Exception as e:
        raise MissingAppConfigurations(
            f"Could not instantiate config class {config_type.__name__}: {e}"
        ) from e


def inherits_from(class_obj_or_instance, base_name: str) -> bool:
    # Checks inheritance via string comparison
    if inspect.isclass(class_obj_or_instance):
        return any(base.__name__ == base_name for base in class_obj_or_instance.__mro__)
    return any(
        base.__name__ == base_name for base in class_obj_or_instance.__class__.__mro__
    )


class Patera(Injectable, Generic[ConfT]):
    """Patera class implementation. Used to create a new application instance"""

    def __init__(self, cli_mode: bool = False):
        """Init function"""
        app_configs = getattr(self.__class__, "_app_configs", None)

        if app_configs is None:
            raise MissingAppConfigurations()

        import_name = cast(str, app_configs.get("import_name"))
        config_type = cast(type[ConfT], app_configs.get("configs"))
        if not inspect.isclass(config_type) or not issubclass(config_type, BaseConfig):
            raise MissingAppConfigurations(
                "Missing valid configs object in @app_configs. "
                "Configuration class must inherit from patera.BaseConfig"
            )
        self._this_path = os.path.dirname(__file__)
        self._app_base_url: str = getattr(self.__class__, "_base_url_path", "")
        self._is_built: bool = False
        self._root_path: str = get_app_root_path(import_name)
        self._configs: ConfT = validate_config(cast(type[ConfT], config_type))
        static_dir = self._configs.STATIC_DIR.lstrip("/\\")
        self._static_files_path: str = os.path.join(self._root_path, static_dir)
        self._templates_path: str = os.path.join(
            self._root_path, self._configs.TEMPLATES_DIR
        )

        self._all_templates_paths: list[str] = [self._templates_path]

        self._url_for_alias: dict[str, str] = {
            self._configs.STATIC_CONTROLLER_NAME: "Static.get"
        }
        self._logger_sink_ids: list[int] = []

        # creates Jinja2 environment for entire app
        self._jinja_environment: Environment = Environment(
            loader=None,
            autoescape=select_autoescape(["html", "xml"]),
            undefined=StrictUndefined if self._configs.TEMPLATES_STRICT else Undefined,
            auto_reload=self._configs.AUTO_RELOAD,
            enable_async=True,
        )
        self.response_serializers: SerializerRegistry = SerializerRegistry()
        self.response_serializers.register_defaults()
        self.response_renderer: ResponseRenderer = ResponseRenderer(
            self.response_serializers
        )

        sink_id = DefaultLogger(self).configure()
        self._logger_sink_ids.append(sink_id)

        self._router: Router = Router(self._configs.STRICT_SLASHES)
        self._socket_router: Router = Router(self._configs.STRICT_SLASHES)
        self._logger: Logger = cast(Logger, logger)

        self.log_buffer: InMemoryLogBuffer = InMemoryLogBuffer(
            maxlen=self._configs.IN_MEMORY_LOG_BUFFER_SIZE
        )
        # Capture everything (TRACE and above) in the in-memory log buffer
        self._log_buffer_sink_id = logger.add(
            self.log_buffer, level="TRACE", enqueue=True, backtrace=True, diagnose=False
        )
        self._logger_sink_ids.append(self._log_buffer_sink_id)

        self._app: AppCallableType = self._base_app
        self._middleware: list[Callable] = []
        self._middleware_classes: dict[int, Type[MiddlewareBase]] = {}
        self._controllers: dict[str, "Controller"] = {}
        self._cli_controllers: dict[str, "CLIController"] = {}
        self._exception_handlers: dict[str, Callable] = {}
        self._json_spec: Optional[dict] = None
        self._db_name_configs_map: dict[str, str] = {}

        self._extensions: dict[str, Injectable] = {}
        self.global_context_methods: list[Callable] = []

        self._on_startup_methods: list[Callable] = []
        self._on_shutdown_methods: list[Callable] = []

        self._get_startup_methods()
        self._get_shutdown_methods()

        self._resolve_injections()
        self._load_controllers_exc_handlers_middleware(cli_mode)
        if not cli_mode:
            self._enable_cors()

        self._jinja_environment.loader = FileSystemLoader(self._all_templates_paths)

    def _load_controllers_exc_handlers_middleware(self, cli_mode: bool = False) -> None:
        app_root: Path = Path(self._root_path)

        _cli_controller_folders: list[str] = ["cli", "cli_controllers"]
        _additional_cli_controller_folders = self._configs.CLI_CONTROLLER_FOLDERS
        if _additional_cli_controller_folders is None:
            _additional_cli_controller_folders = []
        _cli_controller_folders.extend(_additional_cli_controller_folders)
        for folder in _cli_controller_folders:
            folder_path = app_root / folder
            files = find_python_files_by_name(folder_path, ["cli", "cli_controller"])
            self._load_detected_module(files, CLIController)

        if cli_mode:
            return

        _logger_folders: list[str] = ["logging", "loggers"]
        _additional_logger_folders = self._configs.LOGGER_FOLDERS
        if _additional_logger_folders is None:
            _additional_logger_folders = []
        _logger_folders.extend(_additional_logger_folders)
        for folder in _logger_folders:
            folder_path = app_root / folder
            files = find_python_files_by_name(folder_path, ["logger", "log_sink"])
            self._load_detected_module(files, LoggerBase)

        _controller_folders: list[str] = [
            "api",
            "public",
            "controllers",
            "routers",
            "routes",
        ]
        _additional_controller_folders = self._configs.CONTROLLER_FOLDERS
        if _additional_controller_folders is None:
            _additional_controller_folders = []
        _controller_folders.extend(_additional_controller_folders)
        for folder in _controller_folders:
            folder_path = app_root / folder
            files = find_python_files_by_name(
                folder_path, ["api", "controller", "public", "router", "routes"]
            )
            self._load_detected_module(files, Controller)

        _exception_handler_folders: list[str] = ["exceptions"]
        _additional_exception_handler_folders = self._configs.EXCEPTION_HANDLER_FOLDERS
        if _additional_exception_handler_folders is None:
            _additional_exception_handler_folders = []
        _exception_handler_folders.extend(_additional_exception_handler_folders)
        for folder in _exception_handler_folders:
            folder_path = app_root / folder
            files = find_python_files_by_name(
                folder_path, ["handler", "exception_controller", "controller"]
            )
            self._load_detected_module(files, ExceptionHandler)

        _middleware_folders: list[str] = ["middleware", "middlewares"]
        _additional_middleware_folders = self._configs.MIDDLEWARE_FOLDERS
        if _additional_middleware_folders is None:
            _additional_middleware_folders = []
        _middleware_folders.extend(_additional_middleware_folders)
        for folder in _middleware_folders:
            folder_path = app_root / folder
            files = find_python_files_by_name(folder_path, ["middleware", "mw"])
            self._load_detected_module(files, MiddlewareBase)
            for order_key in sorted(self._middleware_classes.keys()):
                mw_class = self._middleware_classes[order_key]
                self._middleware.append(
                    lambda app, next_app, mdlwr_class=mw_class: mdlwr_class(
                        app, next_app
                    )
                )

    def _load_detected_module(self, file_paths: List[Path], load_class: Type) -> None:
        """
        Tries to load implementations (controllers, exc. handlers, middleware, loggers)
        """
        app_root = Path(self._root_path)
        root_package = app_root.name
        for file_path in file_paths:
            relative_path = file_path.relative_to(app_root)
            module_path = relative_path.with_suffix("")
            import_path = f"{root_package}.{'.'.join(module_path.parts)}"
            module = importlib.import_module(import_path)
            for _, obj in inspect.getmembers(
                module,
                lambda _obj: inspect.isclass(_obj) and issubclass(_obj, load_class),
            ):
                ignore: bool = getattr(obj, "_ignore", False)
                dev_only: bool = getattr(obj, "_development", False)
                if ignore or (dev_only and not self._configs.DEBUG):
                    continue
                if issubclass(obj, Controller) and obj is not Controller:
                    self.logger.info(f"Registering controller: {obj.__name__}")
                    self.register_controller(obj)
                    continue
                elif issubclass(obj, CLIController) and obj is not CLIController:
                    self.logger.info(f"Registering CLI controller: {obj.__name__}")
                    obj_inst = obj(self)
                    self.register_cli_controller(obj_inst)
                    continue
                elif issubclass(obj, MiddlewareBase) and obj is not MiddlewareBase:
                    self.logger.info(f"Registering middleware: {obj.__name__}")
                    order = getattr(obj, "_order", 0)
                    order_keys = self._middleware_classes.keys()
                    if order in order_keys:
                        order = max(order_keys) + 1
                        self.logger.warning(
                            f"For middleware {obj.__name__}: Order {getattr(obj, '_order', 0)} is already taken, assigned order {order} instead."
                        )
                    self._middleware_classes[order] = obj
                    continue
                elif issubclass(obj, ExceptionHandler) and obj is not ExceptionHandler:
                    self.logger.info(f"Registering exception handler: {obj.__name__}")
                    self.register_exception_handler(obj)
                    continue
                elif issubclass(obj, LoggerBase) and obj is not LoggerBase:
                    self.logger.info(f"Registering logger sink: {obj.__name__}")
                    sink_id = obj(self).configure()
                    self._logger_sink_ids.append(sink_id)
                    continue

    def _resolve_dependency(self, target_type: type[Any]) -> Any:
        value = self._extensions.get(target_type.__name__, None)
        if value is None:
            value = target_type(self)
            self._extensions[value.configs_name] = value
            self._extensions[target_type.__name__] = value

        return value

    def _resolve_config_var(
        self,
        config_name: str,
        declared_type: type[Any],
    ) -> Any:
        value = self.app.get_conf(config_name)

        if isinstance(value, declared_type):
            return value

        try:
            return declared_type(value)
        except Exception as exc:
            raise TypeError(
                f"Config variable {config_name!r} must be of type "
                f"{declared_type.__name__}, got {type(value).__name__}"
            ) from exc

    def _enable_cors(self):
        cors_enabled: bool = self._configs.CORS_ENABLED
        if not cors_enabled:
            return

        # pylint: disable-next=C0415
        from .cors.cors_mw import CORSMiddleware

        self.logger.info(f"Registering middleware: {CORSMiddleware.__name__}")
        self._middleware.append(
            # pylint: disable-next=W0108
            lambda app, next_app: CORSMiddleware(app, next_app)
        )

    def _get_startup_methods(self):
        methods = []
        for name in dir(self):
            method = getattr(self, name)
            if callable(method) and getattr(method, "_on_startup_method", False):
                methods.append((name, method))
        methods.sort(key=lambda x: x[0])  # by method name
        self._on_startup_methods = [m for _, m in methods]

    def _get_shutdown_methods(self):
        methods = []
        for name in dir(self):
            method = getattr(self, name)
            if callable(method) and getattr(method, "_on_shutdown_method", False):
                methods.append((name, method))
        methods.sort(key=lambda x: x[0])  # by method name
        self._on_shutdown_methods = [m for _, m in methods]

    def get_conf(self, config_name: str, default: Any = None) -> Any:
        """
        Returns app configuration with provided config_name.
        Raises error if configuration is not found.
        """
        if config_name and "." in config_name:
            return self._get_nested_config(config_name, default)
        value = getattr(self._configs, config_name, default)
        if value is None:
            return default
        return value

    def _get_nested_config(self, config_name: str, default: Any = None) -> Any:
        names: list[str] = config_name.split(".")  # names/paths of entire config tree
        first_name = names.pop(0)  # start of nested config
        last_name = names.pop()  # name of final level config
        config = self.get_conf(first_name)  # top level/start
        if config is None:
            return default
        for name in names:
            config = getattr(config, name, None)
            if config is None:
                return default
        value = getattr(config, last_name, default)
        if value is None:
            return default
        return value

    def add_global_context_method(self, func: Callable):
        """
        Adds global context method to global_context_methods array
        """
        self.global_context_methods.append(func)

    async def _base_app(self, req: Request) -> Response:
        """
        The bare-bones application without any middleware.
        Calls the route handler directly.
        """
        if req.response.expected_body_type() is None:
            expected = _extract_response_type(req.route_handler)
            req.response._set_expected_body_type(expected)
        res: Response = await req.route_handler.__self__(req.route_handler, req)  # type: ignore
        return res

    async def abort_route_not_found(
        self, send, req: Request, path_data: Mapping[str, Any]
    ):
        """
        Aborts request because route was not found
        """
        ##Does a NotFound exception handler exist? If yes, runs it and sends the response, else sends generic 404 response
        handler: Callable | None = (
            self._exception_handlers.get(NotFound.__name__, None) or None
        )
        if handler:
            res: Response = await run_sync_or_async(
                handler, req, NotFound("Endpoint not found", response=req.res)
            )
            response_type = res.expected_body_type()
            return await self.send_response(res, send, response_type)
        ##sends generic response if custom handler not available
        self._log_response(req, HttpStatus.NOT_FOUND)
        await send(
            {
                "type": "http.response.start",
                "status": 404,
                "headers": [(b"content-type", b"application/json")],
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": b'{ "status": "error", "message": "Endpoint not found" }',
            }
        )

    async def _iterate_stream(
        self,
        iterable: Union[AsyncIterable[bytes], Iterable[bytes]],
    ) -> AsyncIterator[bytes]:
        """
        Normalizes async/sync iterables into an async iterator of bytes.
        Accepts bytes/bytearray/str chunks and encodes/normalizes to bytes.
        """

        async def _aiter_from_sync(sync_iter: Iterable[bytes]) -> AsyncIterator[bytes]:
            for chunk in sync_iter:
                yield self._normalize_chunk(chunk)

        if hasattr(iterable, "__aiter__"):
            async for chunk in iterable:  # type: ignore[attr-defined]
                yield self._normalize_chunk(chunk)
        else:
            async for chunk in _aiter_from_sync(iterable):  # type: ignore[arg-type]
                yield chunk

    def _normalize_chunk(self, chunk: Any) -> bytes:
        if isinstance(chunk, (bytes, bytearray)):
            return bytes(chunk)
        if isinstance(chunk, str):
            return chunk.encode("utf-8")
        raise TypeError(
            f"Streaming chunks must be bytes, bytearray or str, got {type(chunk)!r}"
        )

    async def send_response(
        self, res: Response, send, response_type: Optional[Type[Any]] = None
    ):
        """
        Sends response.

        Serialization is delegated to the response renderer / serializer registry.
        This method focuses on transport concerns:
        - zero-copy responses
        - streaming responses
        - normal ASGI start/body sending
        """
        self.response_renderer.apply_default_content_type(res)
        self._log_response(res.request, res.status_code)
        if res.zero_copy is not None:
            self.response_renderer.finalize_headers(
                res, body_bytes=None, is_streaming=True
            )

            await send(
                {
                    "type": "http.response.start",
                    "status": int(res.status_code),
                    "headers": encode_response_headers(res),
                }
            )

            params = res.zero_copy
            file_path = params["file_path"]
            start = params["start"]
            length = params["length"]

            chunk_size = 1 * 1024 * 1024
            remaining = length

            async with aiofiles.open(file_path, "rb") as f:
                await f.seek(start)
                while remaining > 0:
                    to_read = min(remaining, chunk_size)
                    chunk = await f.read(to_read)
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    await send(
                        {
                            "type": "http.response.body",
                            "body": chunk,
                            "more_body": remaining > 0,
                        }
                    )
            return

        if res.is_streaming:
            self.response_renderer.finalize_headers(
                res, body_bytes=None, is_streaming=True
            )

            await send(
                {
                    "type": "http.response.start",
                    "status": int(res.status_code),
                    "headers": encode_response_headers(res),
                }
            )

            stream_iter = res.stream_iterable
            if stream_iter is None:
                await send(
                    {"type": "http.response.body", "body": b"", "more_body": False}
                )
                return

            async for chunk in self._iterate_stream(stream_iter):
                await send(
                    {
                        "type": "http.response.body",
                        "body": chunk,
                        "more_body": True,
                    }
                )

            await send(
                {
                    "type": "http.response.body",
                    "body": b"",
                    "more_body": False,
                }
            )
            return

        body_bytes = await self.response_renderer.render_body(res, response_type)
        self.response_renderer.finalize_headers(
            res, body_bytes=body_bytes, is_streaming=False
        )

        await send(
            {
                "type": "http.response.start",
                "status": int(res.status_code),
                "headers": encode_response_headers(res),
            }
        )

        await send(
            {
                "type": "http.response.body",
                "body": body_bytes or b"",
                "more_body": False,
            }
        )

    async def _lifespan_app(self, _, receive, send):
        """This loop will listen for 'startup' and 'shutdown'"""
        while True:
            message = await receive()

            if message["type"] == "lifespan.startup":
                for method in self._on_startup_methods:
                    await run_sync_or_async(method)
                await send({"type": "lifespan.startup.complete"})

            elif message["type"] == "lifespan.shutdown":
                for method in self._on_shutdown_methods:
                    await run_sync_or_async(method)
                for logger_sink_id in self._logger_sink_ids:
                    self.logger.remove(logger_sink_id)
                await send({"type": "lifespan.shutdown.complete"})
                return  # Exit the lifespan loop

    async def _handle_http_request(self, scope, receive, send):
        """
        Handles http requests
        """
        method: str = scope["method"].upper()
        url_path: str = scope["path"]
        self._log_request(scope, method, url_path)

        route_handler, path_kwargs = self.router.match(url_path, method)
        req = self.request_class(
            scope, receive, send, self, path_kwargs, cast(Callable, route_handler)
        )
        if not route_handler:
            return await self.abort_route_not_found(send, req, path_kwargs)

        try:
            with request_context(
                app=self,
                request=req,
                controller=route_handler.__self__,  # type: ignore
            ):  # type: ignore
                try:
                    res: Response = await self._app(req)
                    if not isinstance(res, Response):
                        # pylint: disable-next=W0719
                        raise Exception(
                            "Return object of request handlers must be an instance of Response"
                        )
                    response_type: Optional[Type[Any]] = (
                        req.response.expected_body_type()
                    )
                    return await self.send_response(res, send, response_type)
                except HtmlAborterException as exc:
                    res = (await req.res.html(exc.template, context=exc.data)).status(
                        exc.status_code
                    )
                    return await self.send_response(res, send, None)
                # pylint: disable-next=W0718
                except Exception as exc:
                    handler = (
                        self._exception_handlers.get(exc.__class__.__name__, None)
                        or None
                    )
                    if not handler:
                        # pylint: disable-next=W0719
                        raise
                    res = await run_sync_or_async(handler, req, exc)
                    response_type = res.expected_body_type() or exc.__class__
                    return await self.send_response(res, send, response_type)
        # pylint: disable-next=W0718
        except Exception as exc:
            # Catches every error and returns internal server error message
            # if the app is in production (DEBUG = False)
            # else reraises the error
            if not self.configs.DEBUG:
                res = req.res.json(
                    {
                        "status": "error",
                        "message": "Internal server error",
                    }
                ).status(HttpStatus.INTERNAL_SERVER_ERROR)
                self.logger.critical(
                    f"Unhandled critical error: ({req.method}) {req.path}, {req.route_parameters}"
                )
                return await self.send_response(res, send, exc.__class__)
            raise

    def _log_request(self, scope, method: str, url_path: str) -> None:
        """
        Logs incoming request
        """
        self.logger.info(
            f"HTTP request. CLIENT: {(scope.get('client') or ('-', ''))[0]}, SCHEME: {scope['scheme']}, METHOD: {method}, PATH: {url_path}, QUERY_STRING: {scope['query_string'].decode('utf-8')}"
        )

    def _log_response(self, req: Request, status_code: int) -> None:
        """
        Logs outgoing response
        """
        self.logger.info(
            f"HTTP response. CLIENT: {(req.scope.get('client') or ('-', ''))[0]}, SCHEME: {req.scope['scheme']}, METHOD: {req.method}, PATH: {req.path}, STATUS_CODE: {status_code}"
        )

    def register_static_controller(self, base_path: str):
        static_controller_dec = path(f"{base_path}", open_api_spec=False)
        static_controller = static_controller_dec(Static)
        self.register_controller(static_controller, with_base_path=False)  # type: ignore

    def register_openapi_controller(self):
        openapi_controller_dec = path(self.configs.OPEN_API_URL, open_api_spec=False)
        openapi_controller = openapi_controller_dec(OpenAPIController)
        self.register_controller(openapi_controller)

    def build(self) -> None:
        """
        Build the final app by wrapping self._app in all middleware.
        Apply them in reverse order so the first middleware in the list
        is the outermost layer.
        """
        print(PATERA_ASCIIART)
        self.register_static_controller(self.configs.STATIC_URL)
        if self.configs.OPEN_API:
            self.build_openapi_spec()
            self.register_openapi_controller()
        built_app: AppCallableType = self._base_app
        for factory in reversed(self._middleware):
            built_app = factory(self, built_app)
        self._app = built_app
        self._is_built = True
        print_startup_message(
            host=self.configs.HOST,
            port=self.configs.PORT,
            debug_mode=self.configs.DEBUG,
            app_name=self.app_name,
        )

    def add_extension(self, extension: Injectable):
        """
        Adds extension to extension map
        """
        if self._extensions.get(extension.__class__.__name__, None) is not None:
            return
        self._extensions[extension.configs_name] = extension
        self._extensions[extension.__class__.__name__] = extension

    def _add_route_function(
        self, method: str, url_path: str, func: Callable, endpoint_name: str
    ):
        """
        Adds the function to the Router.
        Raises DuplicateRoutePath if a route with the same (method, path) is already registered.
        """
        try:
            if method == HttpMethod.SOCKET.value:
                self._socket_router.add_route(url_path, func, [method], endpoint_name)
            else:
                self.router.add_route(url_path, func, [method], endpoint_name)
        except Exception as e:
            raise e

    def register_controller(
        self, *ctrls: "type[Controller]", with_base_path: bool = True
    ):
        """Registers controller class with application"""
        base_path: str = self._app_base_url if with_base_path else ""
        for ctrl in ctrls:
            dev_only: bool = getattr(ctrl, "_development", False)
            ignore: bool = getattr(ctrl, "_ignore", False)
            if ignore or (dev_only and not self.configs.DEBUG):
                continue
            ctrl_path: str = getattr(ctrl, "_controller_path")
            ctrl_open_api_spec = getattr(ctrl, "_include_open_api_spec")
            ctrl_open_api_tags = getattr(ctrl, "_open_api_tags", None)
            ctrl_instance = ctrl(
                self, ctrl_path, ctrl_open_api_spec, ctrl_open_api_tags
            )

            self._controllers[ctrl_instance.path] = ctrl_instance
            endpoint_methods: dict[str, dict[str, str | Callable]] = (
                ctrl_instance.get_endpoint_methods()
            )
            for http_method, endpoints in endpoint_methods.items():
                for url_path, method in endpoints.items():
                    method_name: Callable = method["method"].__name__  # type: ignore
                    # handler: Callable = getattr(ctrl_instance, method_name) # type: ignore
                    endpoint_name: str = (
                        f"{ctrl_instance.__class__.__name__}.{method_name}"
                    )
                    self._add_route_function(
                        http_method,
                        base_path + ctrl_instance.path + url_path,
                        cast(Callable, cast(dict, method)["method"]),
                        endpoint_name,
                    )

    def register_cli_controller(self, ctrl: CLIController) -> None:
        self._cli_controllers[ctrl.ctrl_name] = ctrl

    def register_exception_handler(self, *handlers: "type[ExceptionHandler]"):
        """Registers exception controller with application"""
        for handler in handlers:
            handler_instance = handler(self)
            handled_exceptions = handler_instance.get_exception_mapping()
            self._exception_handlers.update(handled_exceptions)

    def url_for(self, endpoint: str, **values) -> str:
        """
        Returns url for endpoint method
        :param endpoint: the name of the endpoint handler method namespaced
        with the controller name
        :param values: dynamic route parameters
        :return: url (string) for endpoint
        """
        endpoint = self._url_for_alias.get(endpoint, endpoint)
        adapter = self.router.url_map.bind("")  # Binds map to base url
        # If a value starts with a forward slash, systems like MacOS/Linux treat it as an absolute path
        try:
            return adapter.build(endpoint, values)
        except NotFound as exc:
            raise ValueError(f"Endpoint '{endpoint}' does not exist.") from exc
        except MethodNotAllowed as exc:
            raise ValueError(
                f"Endpoint '{endpoint}' exists but does not allow the method."
            ) from exc
        except Exception as exc:
            raise ValueError(
                f"Error building URL for endpoint '{endpoint}': {exc}"
            ) from exc

    def build_openapi_spec(self):
        """Builds open api spec"""
        # pylint: disable-next=C0415
        from .open_api import build_openapi

        self._json_spec = build_openapi(
            self._controllers,
            title=self.app_name,
            version=self.version,
            openapi_version="3.0.3",
            servers=[f"http://localhost:{self._configs.PORT}"],
        )

    def add_on_startup_method(self, func: Callable):
        """
        Adds method to on_startup collection
        """
        self._on_startup_methods.append(func)

    def add_on_shutdown_method(self, func: Callable):
        """
        Adds method to on_shutdown collection
        """
        self._on_shutdown_methods.append(func)

    def register_alias(self, alias: str, endpoint: str):
        """
        Registers an alias for an endpoint name.
        Useful for url_for lookups.
        """
        self._url_for_alias[alias] = endpoint

    def run_cli(self, command_name: str, *args, **kwargs) -> None:
        """
        Executes the registered CLI commands.
        """
        if command_name is None or ":" not in command_name:
            print(
                "Invalid command name. Command name must be of the format CLIController:Command"
            )
            return
        ctrl_name, command = command_name.split(":", 1)
        ctrl = cast(CLIController, self._cli_controllers.get(ctrl_name, None))
        if ctrl is None:
            print(f"ERROR: CLI controller with name {ctrl_name} was not found")
            return

        method = ctrl.find_method(command)
        if method is None:
            print(
                f"CLI method with name {command} in controller {ctrl_name} not found."
            )
            return
        ctrl.run_command(method, *args, **kwargs)
        return

    def add_template_path(self, path: str):
        """Adds a template path"""
        self._all_templates_paths.append(path)

    @property
    def json_spec(self) -> dict | None:
        return self._json_spec

    @property
    def router(self) -> Router:
        """Router instance property of the app"""
        return self._router

    @property
    def configs(self) -> ConfT:
        """
        Returns configuration dictionary
        """
        return self._configs

    @property
    def root_path(self) -> str:
        """
        Returns root path of application
        """
        return self._root_path

    @property
    def app(self):
        """
        Returns self
        For compatibility with the Controller class
        which contains the app object on the app property
        """
        return self

    @property
    def static_files_path(self) -> str:
        """Static files paths"""
        return self._static_files_path

    @property
    def version(self) -> str:
        return self._configs.VERSION

    @property
    def app_name(self) -> str:
        return self._configs.APP_NAME

    @property
    def logger(self) -> Logger:
        return self._logger

    @property
    def jinja_environment(self) -> Environment:
        return self._jinja_environment

    @property
    def request_class(self) -> Type[Request]:
        """
        Returns the Request class used by the application.
        Can be overridden in configs to provide a custom Request subclass.
        """
        return self.configs.REQUEST_CLASS

    @property
    def response_class(self) -> Type[Response]:
        """
        Returns the Response class used by the application.
        Can be overridden in configs to provide a custom Response subclass.
        """
        return self.configs.RESPONSE_CLASS

    @property
    def extensions(self) -> "dict[str, Injectable]":
        """Returns dictionary with all registered extensions"""
        return self._extensions

    @property
    def current_request(self) -> CurrentContextProxy:
        return current_request

    async def __call__(self, scope, receive, send):
        """
        Once built, __call__ just delegates to the fully wrapped app.
        """
        if not self._is_built:
            self.build()
        if scope["type"] == ScopeType.LIFESPAN.value:
            return await self._lifespan_app(scope, receive, send)
        if scope["type"] == ScopeType.HTTP.value:
            return await self._handle_http_request(scope, receive, send)
        if scope["type"] == ScopeType.WEBSOCKET.value:
            return await self._handle_websocket_request(scope, receive, send)
        raise ValueError(f"Unsupported scope type {scope['type']}")

    async def _handle_websocket_request(self, scope, receive, send):
        """
        Handles websocket requests
        """
        method: str = "SOCKET"
        url_path: str = scope["path"]
        self._log_request(scope, method, url_path)

        route_handler, path_kwargs = self._socket_router.match(url_path, method)
        if not route_handler:
            await send({"type": "websocket.close", "code": 1000})
            return
        req = Request(
            scope, receive, send, self, path_kwargs, cast(Callable, route_handler)
        )
        try:
            with request_context(
                app=self,
                request=req,
                controller=route_handler.__self__,  # type: ignore
            ):  # type: ignore
                await run_sync_or_async(route_handler, req, **path_kwargs)
        # pylint: disable-next=W0718
        except Exception as exc:
            await send(
                {
                    "type": "websocket.close",
                    "code": 1011,
                    "reason": "Internal server error",
                }
            )
            self.logger.critical(
                f"Unhandled critical error in websocket: ({req.method}) {req.path}, {req.route_parameters}: {exc}"
            )
            raise exc
