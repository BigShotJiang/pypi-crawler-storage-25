"""CORS module"""
