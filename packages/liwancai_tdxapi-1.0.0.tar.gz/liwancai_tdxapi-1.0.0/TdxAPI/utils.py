from typing import Any, Optional, List
from .config import (
    MARKET_SZ, MARKET_SH, MARKET_BJ,
    PERIOD_MAP,
    TRADING_START_HOUR, TRADING_START_MINUTE,
    TRADING_END_HOUR, TRADING_END_MINUTE,
)
from .models import TdxRequest, API_PARAMS_INFO


def OK(data: Any, msg: str = "成功") -> dict:
    return {"code": 200, "msg": msg, "data": data}


def ERROR(msg: str, code: int = 500, data: Any = None) -> dict:
    return {"code": code, "msg": msg, "data": data}


def parse_market_from_code(code: str) -> int:
    code = code.strip()
    if code.startswith(('6', '688', '689')):
        return MARKET_SH
    if code.startswith(('0', '3')):
        return MARKET_SZ
    if code.startswith(('920', '43', '83', '87')):
        return MARKET_BJ
    return MARKET_SH


def period_to_category(period: int | str) -> int:
    return PERIOD_MAP.get(period, 4)


def is_trading_time(dt=None) -> bool:
    if dt is None:
        from datetime import datetime
        dt = datetime.now()
    if dt.weekday() >= 5:
        return False
    total_minutes = dt.hour * 60 + dt.minute
    trading_start = TRADING_START_HOUR * 60 + TRADING_START_MINUTE
    trading_end = TRADING_END_HOUR * 60 + TRADING_END_MINUTE
    return trading_start <= total_minutes <= trading_end


def validate_required_fields(path: str, request: TdxRequest, required_fields: List[str]) -> Optional[dict]:
    missing = []
    for field in required_fields:
        value = getattr(request, field, None)
        if value is None or (isinstance(value, str) and value.strip() == ""):
            missing.append(field)
        elif isinstance(value, list):
            if len(value) == 0:
                missing.append(field)
            elif field == "codes" and len(value) > 0 and (value[0] is None or (isinstance(value[0], str) and value[0].strip() == "")):
                return ERROR(f"codes 列表的第一个元素不能为空", code=400)
    if missing:
        params_info = API_PARAMS_INFO.get(path, {})
        missing_info = [f"{f}({params_info.get(f, f)})" for f in missing]
        return ERROR(f"缺少必填参数: {', '.join(missing_info)}", code=400)
    return None
