from typing import Any, Optional, List, Union
from pydantic import BaseModel, Field


class ResponseModel(BaseModel):
    code: int
    msg: str
    data: Optional[Any] = None


class TdxRequest(BaseModel):
    period: Optional[Union[int, str]] = Field(1440, description="周期: 1/5/15/30/60/120/1440/1441/1442/1443, 字符串'1'表示扩展1分钟线")
    market: Optional[int] = Field(None, description="市场: 0=深圳, 1=上海, 2=北京, 不传则自动根据代码判断")
    codes: Optional[List[str]] = Field(None, description="股票/指数代码列表")
    start: Optional[int] = Field(0, description="起始偏移位置")
    count: Optional[int] = Field(100, description="请求数量")
    fq: Optional[int] = Field(1, description="复权: 0=不复权, 1=前复权, 2=后复权")
    trade_date: Optional[int] = Field(None, description="交易日期, 格式: YYYYMMDD, 如: 20260421")


API_PARAMS_INFO = {
    "/code-kline": {
        "period": "周期(整数1/5/15/30/60/120/1440/1441/1442/1443, 字符串'1'表示扩展1分钟线)",
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]",
        "start": "起始偏移(不传则自动分页获取全部)",
        "count": "数量",
        "fq": "复权(0=未复权,1=前复权,2=后复权)"
    },
    "/code-index": {
        "period": "周期(1/5/15/30/60/120/1440/1441/1442/1443)",
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "指数代码列表，如[000001]",
        "start": "起始偏移(不传则自动分页获取全部)",
        "count": "数量"
    },
    "/quotes": {
        "codes": "股票代码列表，如[600519,000858]"
    },
    "/code-count": {
        "market": "市场(0=深圳,1=上海,2=北京)"
    },
    "/stock-list": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "start": "起始偏移"
    },
    "/minute": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]"
    },
    "/days-minute": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]",
        "trade_date": "交易日期(YYYYMMDD整数)"
    },
    "/tick1": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]",
        "start": "起始偏移",
        "count": "数量"
    },
    "/days-tick1": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]",
        "start": "起始偏移",
        "count": "数量",
        "trade_date": "交易日期(YYYYMMDD整数)"
    },
    "/finance": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]"
    },
    "/xdxr": {
        "market": "市场(0=深圳,1=上海,2=北京)",
        "codes": "股票代码列表，如[600519]"
    },
}
