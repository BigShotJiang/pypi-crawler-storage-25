from fastapi import APIRouter
from ..models import TdxRequest
from ..utils import OK, ERROR, validate_required_fields, parse_market_from_code
from . import get_client, ensure_connection

router = APIRouter()


@router.post("/minute", summary="获取当日分时数据", description="获取个股当日分时走势数据")
async def get_minute(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/minute", request, ["codes"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    try:
        data = get_client().get_minute_time_data(market=market, code=code)
        return OK(data)
    except Exception as e:
        return ERROR(f"获取分时数据失败: {str(e)}")


@router.post("/days-minute", summary="获取历史分时数据", description="获取个股历史某一交易日的分时走势数据")
async def get_days_minute(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/days-minute", request, ["codes", "trade_date"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    try:
        data = get_client().get_history_minute_time_data(
            market=market,
            code=code,
            date=request.trade_date
        )
        return OK(data)
    except Exception as e:
        return ERROR(f"获取历史分时数据失败: {str(e)}")
