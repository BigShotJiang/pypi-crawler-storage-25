from fastapi import APIRouter
from ..models import TdxRequest
from ..utils import OK, ERROR, validate_required_fields, parse_market_from_code
from . import get_client, ensure_connection

router = APIRouter()


@router.post("/finance", summary="获取财务信息", description="获取个股财务数据信息")
async def get_finance_info(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/finance", request, ["codes"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    try:
        info = get_client().get_finance_info(market=market, code=code)
        return OK(info)
    except Exception as e:
        return ERROR(f"获取财务信息失败: {str(e)}")


@router.post("/xdxr", summary="获取除权除息信息", description="获取个股历史除权除息信息")
async def get_xdxr_info(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/xdxr", request, ["codes"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    try:
        info = get_client().get_xdxr_info(market=market, code=code)
        return OK(info)
    except Exception as e:
        return ERROR(f"获取除权除息信息失败: {str(e)}")
