from fastapi import APIRouter
from ..models import TdxRequest
from ..utils import OK, ERROR, validate_required_fields, parse_market_from_code
from . import get_client, ensure_connection

router = APIRouter()


@router.post("/tick1", summary="获取当日逐笔成交", description="获取个股当日逐笔成交明细数据")
async def get_tick1(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/tick1", request, ["codes"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    try:
        data = get_client().get_transaction_data(
            market=market,
            code=code,
            start=request.start or 0,
            count=request.count or 2000
        )
        return OK(data)
    except Exception as e:
        return ERROR(f"获取逐笔成交失败: {str(e)}")


@router.post("/days-tick1", summary="获取历史逐笔成交", description="获取个股历史某一交易日的逐笔成交明细数据")
async def get_days_tick1(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/days-tick1", request, ["codes", "trade_date"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    try:
        data = get_client().get_history_transaction_data(
            market=market,
            code=code,
            start=request.start or 0,
            count=request.count or 2000,
            date=request.trade_date
        )
        return OK(data)
    except Exception as e:
        return ERROR(f"获取历史逐笔成交失败: {str(e)}")
