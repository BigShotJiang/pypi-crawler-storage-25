from fastapi import APIRouter
from ..utils import OK, ERROR, is_trading_time
from . import get_client

router = APIRouter()


@router.get("/health", summary="健康检查", description="检查TDX服务连接状态、连接池状态和交易时间")
async def health_check():
    try:
        client = get_client()
        connected = client.is_connected()
        stats = client.pool_stats() if connected else None
        return OK({
            "connected": connected,
            "pool_stats": stats,
            "is_trading_time": is_trading_time()
        })
    except Exception as e:
        return ERROR(f"健康检查失败: {str(e)}")


@router.get("/constants", summary="获取常量定义", description="获取接口使用的常量定义，包括市场、周期、复权类型")
async def get_constants():
    from ..config import MARKET_SZ, MARKET_SH, MARKET_BJ, FQ_NONE, FQ_QFQ, FQ_HFQ
    constants = {
        "markets": {
            "MARKET_SZ": MARKET_SZ,
            "MARKET_SH": MARKET_SH,
            "MARKET_BJ": MARKET_BJ
        },
        "periods": {
            "1MIN": 1,
            "5MIN": 5,
            "15MIN": 15,
            "30MIN": 30,
            "60MIN": 60,
            "120MIN": 120,
            "DAILY": 1440,
            "WEEKLY": 1441,
            "MONTHLY": 1442,
            "QUARTERLY": 1443
        },
        "fq_types": {
            "FQ_NONE": FQ_NONE,
            "FQ_QFQ": FQ_QFQ,
            "FQ_HFQ": FQ_HFQ
        }
    }
    return OK(constants)
