from fastapi import APIRouter
from ..models import TdxRequest
from ..utils import OK, ERROR, validate_required_fields, parse_market_from_code
from . import get_client, ensure_connection

router = APIRouter()


@router.post("/quotes", summary="获取实时行情", description="批量获取股票/指数的实时行情数据")
async def get_security_quotes(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/quotes", request, ["codes"])
    if err:
        return err
    stocks = [(parse_market_from_code(code), code) for code in request.codes]
    try:
        quotes = get_client().get_security_quotes(stocks)
        return OK(quotes)
    except Exception as e:
        return ERROR(f"获取行情失败: {str(e)}")


@router.post("/code-count", summary="获取证券数量", description="获取指定市场的证券总数")
async def get_code_count(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    try:
        from ..config import MARKET_SH
        count = get_client().get_security_count(request.market or MARKET_SH)
        return OK(count)
    except Exception as e:
        return ERROR(f"获取证券数量失败: {str(e)}")


@router.post("/stock-list", summary="获取证券列表", description="获取指定市场的证券列表，支持分页")
async def get_stock_list(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    try:
        from ..config import MARKET_SH
        securities = get_client().get_security_list(market=request.market or MARKET_SH, start=request.start or 0)
        return OK(securities)
    except Exception as e:
        return ERROR(f"获取证券列表失败: {str(e)}")
