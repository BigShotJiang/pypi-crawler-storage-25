import time
from tdxrs import TdxHqClient
from ..utils import is_trading_time
from ..config import NON_TRADING_RECONNECT_INTERVAL

client = TdxHqClient()
client.set_auto_retry(False)
client.set_cache_ttl(120)
client.set_connect_timeout(5.0)

LAST_RECONNECT_TIME = 0


def get_client() -> TdxHqClient:
    return client


def ensure_connection() -> bool:
    global LAST_RECONNECT_TIME
    if client.is_connected():
        return True
    now = time.time()
    if is_trading_time():
        try:
            client.disconnect()
            client.connect_to_any(timeout=5.0)
            LAST_RECONNECT_TIME = now
            return client.is_connected()
        except Exception as e:
            print(f"交易时间重连失败: {e}")
            return False
    else:
        if now - LAST_RECONNECT_TIME >= NON_TRADING_RECONNECT_INTERVAL:
            try:
                client.disconnect()
                client.connect_to_any(timeout=5.0)
                LAST_RECONNECT_TIME = now
                return client.is_connected()
            except Exception as e:
                print(f"非交易时间重连失败: {e}")
                return False
        else:
            print(f"非交易时间重连冷却中，下次重连需等待 {int(NON_TRADING_RECONNECT_INTERVAL - (now - LAST_RECONNECT_TIME))} 秒")
            return False


def init_client():
    try:
        client.connect_to_any(timeout=5.0)
        print("TDX 初始化连接成功")
    except Exception as e:
        print(f"TDX 连接初始化失败: {e}")


from .system import router as system_router
from .kline import router as kline_router
from .quotes import router as quotes_router
from .minute import router as minute_router
from .tick import router as tick_router
from .finance import router as finance_router
__all__ = [
    "get_client",
    "ensure_connection",
    "init_client",
    "system_router",
    "kline_router",
    "quotes_router",
    "minute_router",
    "tick_router",
    "finance_router",
]
