from fastapi import APIRouter
from ..models import TdxRequest
from ..utils import OK, ERROR, validate_required_fields, parse_market_from_code, period_to_category
from . import get_client, ensure_connection
from ..config import KLINE_EXHQ_1MIN, FQ_QFQ

router = APIRouter()


@router.post("/code-kline", summary="获取个股K线", description="获取个股K线数据，不传start参数则自动分页获取全部；period=字符串'1'表示扩展1分钟线")
async def get_code_kline(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/code-kline", request, ["codes"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    if request.period == "1":
        category = KLINE_EXHQ_1MIN
    else:
        category = period_to_category(request.period or 1440)
    try:
        if request.start is None:
            bars = get_client().get_security_bars_all(
                category=category,
                market=market,
                code=code,
                count=request.count or 100,
                fq=request.fq or FQ_QFQ
            )
        else:
            bars = get_client().get_security_bars(
                category=category,
                market=market,
                code=code,
                start=request.start,
                count=request.count or 100,
                fq=request.fq or FQ_QFQ
            )
        return OK(bars)
    except Exception as e:
        return ERROR(f"获取K线失败: {str(e)}")


@router.post("/code-index", summary="获取指数K线", description="获取指数K线数据，不传start参数则自动分页获取全部")
async def get_code_index(request: TdxRequest):
    if not ensure_connection():
        return ERROR("TDX 连接失败")
    err = validate_required_fields("/code-index", request, ["codes"])
    if err:
        return err
    code = request.codes[0]
    market = request.market if request.market is not None else parse_market_from_code(code)
    category = period_to_category(request.period or 1440)
    try:
        if request.start is None:
            bars = get_client().get_index_bars_all(
                category=category,
                market=market,
                code=code,
                count=request.count or 100,
                fq=0
            )
        else:
            bars = get_client().get_index_bars(
                category=category,
                market=market,
                code=code,
                start=request.start,
                count=request.count or 100,
                fq=0
            )
        return OK(bars)
    except Exception as e:
        return ERROR(f"获取指数K线失败: {str(e)}")
