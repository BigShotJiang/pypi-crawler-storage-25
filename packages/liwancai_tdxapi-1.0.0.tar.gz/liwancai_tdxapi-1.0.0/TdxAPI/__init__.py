from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routes import (
    init_client,
    get_client,
    ensure_connection,
    system_router,
    kline_router,
    quotes_router,
    minute_router,
    tick_router,
    finance_router,
)


def create_app() -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        init_client()
        yield

    app = FastAPI(
        title="TDX 行情数据接口",
        description="基于通达信数据源的股票/指数行情数据API服务",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        license={"name": "MIT License"},
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(system_router, prefix="/tdx", tags=["系统"])
    app.include_router(kline_router, prefix="/tdx", tags=["K线"])
    app.include_router(quotes_router, prefix="/tdx", tags=["行情"])
    app.include_router(minute_router, prefix="/tdx", tags=["分时"])
    app.include_router(tick_router, prefix="/tdx", tags=["逐笔"])
    app.include_router(finance_router, prefix="/tdx", tags=["财务"])

    return app


app = create_app()

__all__ = [
    "create_app",
    "app",
    "init_client",
    "get_client",
    "ensure_connection",
    "system_router",
    "kline_router",
    "quotes_router",
    "minute_router",
    "tick_router",
    "finance_router",
]