# CLAUDE.md — CruciHiL Project Context

> This file is the authoritative reference for Claude working on this codebase.
> Read it fully at the start of every session. Update it when the project evolves.
> If this file conflicts with any other document, this file wins — then update the other doc.

---

## What We Are Building

**CruciHiL** is a bulletproof, easy-to-use Hardware-in-the-Loop (HiL) testing platform.
It catches firmware regressions before they reach the field.

The core value: write a test in Python in minutes, run it against simulation before hardware exists, run it against real hardware with zero test changes, see results in CI/CD automatically, ask an AI what broke and why.

**Website:** crucihil.io  
**GitHub:** github.com/crucihil  
**Stack:** Python 3.11+, asyncio, FastAPI, PostgreSQL, React, FastMCP, Docker

---

## Bigger Objective

Build a commercially viable HiL testing platform that competes on developer experience and AI capability — not on legacy feature parity with dSPACE/Vector.

**Target market (in order):**
1. AV startups and robotics companies — greenfield, move fast, shorter procurement
2. Tier 2 automotive suppliers — some legacy tooling, but open to better options
3. Tier 1 suppliers — existing dSPACE/Vector investment, complementary positioning

**Positioning:**
- For greenfield teams: full replacement for dSPACE/NI toolchain
- For teams with existing hardware: orchestration and AI layer on top of their hardware

**Pricing model:**
- Self-hosted free up to 2 rigs (open source core)
- Professional: ~$800/month/rig (cloud-managed)
- Enterprise: custom (on-premise control plane, SSO, SLA)

---

## Architecture — The Layer Model

CruciHiL has 6 layers. Every architectural decision maps to one of these layers.
See `docs/ARCHITECTURE.md` for the full specification.

```
Layer 6 — Interfaces        Web Dashboard · CLI · CI/CD webhooks
Layer 5 — AI Interface      MCP Server (FastMCP) — vendor-agnostic
Layer 4 — Cloud Control     FastAPI + PostgreSQL — orchestration and history
Layer 3 — Local Agent       Test runner · YAML executor · result reporter
Layer 2 — Rig HAL           rig.can / rig.sim / rig.someip / rig.doip / rig.ecu
Layer 1 — Hardware          CAN · Ethernet · GPIO · Power · Qualcomm / Nvidia ECUs
```

**Key architectural decisions (do not revisit without strong reason):**

- Agent ↔ cloud transport: **WebSocket** (persistent, bidirectional, agent connects outbound)
- MCP server: **separate service** in the same Docker Compose stack
- Result storage: **dual layer** — local SQLite cache first, sync to PostgreSQL on connect
- Fault injection: **FaultDescriptor pattern** — methods return descriptors, not coroutines
- Test authoring: **Python-first** with YAML manifest for metadata — YAML handles signal-level setup/teardown/fault metadata; Python handles assertion logic
- YAML manifest format: **v2 schema** — one YAML = one suite; per-test `hw_variants`, `suite_types`, `enabled`, `priority`, `depends_on`, `repeat`, `requirements`, `ticket`, `faults`, `record`, `params`
- SOME/IP Phase 0: **Events + Fields only** — Methods (RPC) deferred to Phase 1
- DoIP Phase 0: **routing activation + UDS + entity discovery** — gateway routing Phase 1
- AI: **BYOK, provider-agnostic, no custom model** — Claude/GPT/Gemini/Copilot all supported; MCP tools provide domain context, general-purpose LLM provides reasoning
- AI rig setup: **three paths** — manual TOML (Path A), `crucihil init` wizard (Path B), AI-assisted discovery (Path C); all produce the same TOML
- Discovery fallback: **four levels** — full auto → partial → conversation → custom backend stub; always works, even with no probing
- AI file writes: **confirm-on-first-write** — explicit user approval on first write per session; auto-accept with session token thereafter
- Custom backends: **module path in TOML** — `backend = "myorg.rig_io_board"` resolved via `importlib`; any class implementing the relevant ABC works
- `[rig.udp]` / `[rig.uds]`: **deferred to Phase 1** — required by AV/robotics teams and diagnostic workflows respectively

---

## Project Structure

```
crucihil/                    ← Python package root
├── hal/                     ← Layer 2: Hardware Abstraction
│   ├── rig.py               ← Rig class — top-level fixture
│   ├── backends/
│   │   ├── base.py          ← Abstract backend interfaces (ABCs)
│   │   ├── registry.py      ← Backend name → class mapping
│   │   ├── virtual/         ← In-process simulation backends
│   │   ├── socketcan/       ← Real CAN (Linux SocketCAN)
│   │   ├── vsomeip/         ← Real SOME/IP (vsomeip wrapper)
│   │   ├── peak/            ← PEAK PCAN adapters
│   │   └── python_doip/     ← DoIP via python-doip
│   ├── namespaces/          ← rig.can, rig.sim, rig.someip etc.
│   ├── bse/                 ← Bus Simulation Engine
│   │   ├── engine.py
│   │   ├── scheduler.py     ← Per-message asyncio task scheduler
│   │   ├── signal_store.py  ← Signal state, defaults, routing metadata
│   │   ├── router.py        ← CAN vs SOME/IP transport routing
│   │   └── loader.py        ← DBC loader, transport inference
│   ├── config/              ← TOML loader + Pydantic validation
│   └── models/
│       ├── results.py       ← TestResult, ExpectResult, FaultDescriptor
│       ├── frames.py        ← CANFrame, SOMEIPEvent, DoIPResponse
│       └── exceptions.py    ← Full exception hierarchy
├── agent/                   ← Layer 3: Local Agent
│   ├── agent.py             ← Main process, WebSocket client
│   ├── runner/              ← Test execution engine
│   ├── manifest/            ← YAML schema, loader, validator
│   ├── reporter/            ← JUnit XML, HTML, JSON reporters
│   └── cache/               ← SQLite result cache + sync
├── server/                  ← Layer 4: Cloud Control Plane
│   ├── main.py              ← FastAPI app factory
│   ├── api/v1/              ← REST endpoints
│   ├── api/ws/              ← WebSocket agent endpoint
│   ├── models/              ← SQLAlchemy + Pydantic models
│   ├── services/            ← Business logic
│   └── db/                  ← Session management + migrations
├── mcp/                     ← Layer 5: MCP Server
│   ├── server.py            ← FastMCP app factory, 11 tools registered
│   ├── client.py            ← httpx async client (JWT cache + refresh)
│   └── tools/
│       ├── rigs.py          ← list_rigs, get_rig_config
│       ├── runs.py          ← list_runs, get_run_summary, run_test_suite, cancel_run
│       ├── results.py       ← get_results, get_signal_trace, describe_failure
│       ├── signals.py       ← list_signals (cantools DBC parse)
│       └── suites.py        ← list_tests (YAML manifest parse)
├── ai/                      ← AI provider abstraction
│   └── provider.py          ← Claude, OpenAI, Gemini, Copilot
└── cli/                     ← Layer 6: CLI
    └── main.py

dashboard/                   ← Layer 6: React web dashboard
docs/
├── ARCHITECTURE.md          ← Full system architecture
├── RIG_INTERFACE_SPEC.md    ← Complete Rig HAL API spec
└── ADR/                     ← Architecture Decision Records

rigs/
├── virtual.toml             ← Virtual simulation rig (no hardware)
└── example_orin.toml        ← Example Nvidia Orin config

tests/
├── unit/                    ← Unit tests for each module
├── integration/             ← Integration tests (virtual backend)
└── e2e/                     ← End-to-end tests against real hardware

tasks/
├── todo.md                  ← Active task plan
└── lessons.md               ← Running lessons log
```

---

## Rig HAL — The Most Important Layer

The Rig HAL (Layer 2) is the foundation everything else builds on. Getting it wrong cascades to every layer above it. The complete spec is in `docs/RIG_INTERFACE_SPEC.md`. Key things to know:

**The `Rig` object is injected by the framework — never constructed in test code.**

```python
async def test_engine_startup(rig: Rig):
    await rig.can.send(message="EngineControl", fields={"throttle": 50})
    result = await rig.can.expect(signal="EngineRPM", condition=lambda v: v > 800, timeout=2.0)
    assert result.passed, result.fail_msg
```

**Fault injection uses the FaultDescriptor pattern — methods return descriptors, not coroutines.**

```python
# CORRECT
async with rig.fault.inject(rig.fault.can_dropout(arb_id=0x100, duration=2.0)):
    await asyncio.sleep(2.0)

# WRONG — can_dropout() does not return a coroutine
await rig.fault.can_dropout(arb_id=0x100, duration=2.0)  # BROKEN
```

**The sim override context manager always restores, even on exception.**

**Signals are identified as `"MessageName.SignalName"` — works for CAN and SOME/IP identically.**

**The blocked/fail distinction is load-bearing:**
- `blocked` = rig is sick (hardware/setup issue). Does NOT count against pass rate.
- `fail` = firmware is sick (assertion failed). Counts against pass rate.
- Never use `fail` for precondition failures — use `raise BlockedError(msg)`.

---

## Critical Rules — Never Violate These

**R1 — Test code never contains hardware details.**
No "socketcan", no "vsomeip", no IP addresses, no "SA8775". These go in TOML.

**R2 — The Signal Store is populated once from the DBC — never inside the decode loop.**
Building metadata per frame produces entries proportional to log length. Build from `db.messages` after `load_file()`.

**R3 — All network/hardware I/O called from a Qt or asyncio context must be in a coroutine.**
Never block the event loop. No `time.sleep()`. No synchronous HTTP calls.

**R4 — Fault methods return FaultDescriptors, never coroutines.**
This is not negotiable. Passing a coroutine to a context manager executes it immediately.

**R5 — remove/cleanup operations must use explicit tracked collections.**
Never infer "this item belongs to feature X" by type. Track explicitly, remove explicitly.

**R6 — Timeouts in rig TOML, not test code.**
Boot times, connection timeouts, flash timeouts — all platform-specific values go in TOML.

**R7 — Never use timestamp as a join key for CAN data.**
CAN logs have duplicate timestamps routinely. Use `frame_idx` (monotonic integer).

**R8 — Teardown always runs.**
Every context manager `__aexit__` returns `False` (never suppress exceptions) and always executes cleanup unconditionally.

**R9 — Validate configuration at startup, not at runtime.**
Pydantic schemas catch bad TOML at rig init. Tests should never fail because of a config error.

**R10 — cantools.database.load_file() is the only DBC loader.**
Never use `Database().add_dbc_file()`. Use the canonical API.

---

## Workflow Orchestration

### 1. Plan Mode Default
Enter plan mode for ANY non-trivial task (3+ steps or architectural decisions).
If something goes sideways: STOP and re-plan. Don't keep pushing.
Write detailed specs upfront. Reduce ambiguity before touching code.

### 2. Subagent Strategy
Use subagents to keep the main context clean.
Offload research, exploration, and parallel analysis.
One task per subagent for focused execution.

### 3. Self-Improvement Loop
After ANY correction: update `tasks/lessons.md` with the pattern.
Write rules that prevent the same mistake.
Review `tasks/lessons.md` at the start of every session.

### 4. Verification Before Done
Never mark a task complete without proving it works.
Ask: "Would a staff engineer at Rivian approve this?"
Run tests. Check logs. Demonstrate correctness.

### 5. Demand Elegance (Balanced)
For non-trivial changes: pause and ask "is there a more elegant solution?"
If a fix feels hacky: implement the elegant solution from scratch.
Skip this for simple, obvious fixes — don't over-engineer.

### 6. Autonomous Bug Fixing
When given a bug report: fix it. Don't ask for hand-holding.
Point at logs, errors, failing tests — then resolve them.

---

## Task Management

1. **Plan First** — write plan to `tasks/todo.md` with checkable items
2. **Verify Plan** — check in before starting large implementations
3. **Track Progress** — mark items complete as you go
4. **Explain Changes** — high-level summary at each step
5. **Document Results** — add review section to `tasks/todo.md`
6. **Capture Lessons** — update `tasks/lessons.md` after any correction

---

## Core Principles

- **Simplicity First** — make every change as simple as possible. Minimal impact.
- **No Laziness** — find root causes. No temporary fixes. Senior engineer standard.
- **Minimal Impact** — touch only what's necessary. Don't introduce new failure modes.
- **Correctness over Cleverness** — a boring correct solution beats an interesting broken one.
- **Verify API Contracts** — check library documentation before using an API. Don't guess.

---

## Implementation Phases

### Phase 0 (Weeks 1–8) — Foundation ✅ COMPLETE
Goal: one test running end-to-end against virtual simulation.

- [x] HAL module structure + backend ABCs
- [x] Virtual backends: CAN, SOME/IP, DoIP, Power, GPIO
- [x] BSE: DBC loader, Signal Store, Scheduler, Router
- [x] Exception hierarchy (all of it, upfront)
- [x] Rig TOML config loader with Pydantic validation
- [x] Test runner: discovery, fixture injection, lifecycle
- [x] Result model: TestResult, ExpectResult, FaultDescriptor
- [x] JUnit XML reporter
- [x] CLI: `crucihil run`
- [x] YAML manifest schema and loader (v2 schema)
- [x] Virtual rig TOML
- [x] One end-to-end test passing (98 tests, all green)

### Phase 1 (Weeks 8–20) — MVP ✅ COMPLETE
Goal: one real engineer running real tests on real hardware.

- [x] SocketCAN backend
- [x] vsomeip wrapper backend
- [x] python-doip backend
- [x] Full fault injection
- [x] `crucihil agent start` + local SQLite cache
- [ ] First design partner running tests (requires real hardware)
- [x] PEAK CAN backend
- [x] `crucihil init` — interactive setup wizard (Path B rig setup)
- [x] JSON Schema for rig TOML + YAML manifest (editor autocomplete)
- [x] `[rig.udp]` transport section
- [x] `[rig.uds]` transport section
- [x] Custom backend module path support (`importlib` extension point)

### Phase 2 (Weeks 20–40) — Platform
Goal: web dashboard, cloud control plane, first paying customer.

- [x] FastAPI control plane + PostgreSQL (173 tests passing)
  - `crucihil/server/` — config, ORM models, Alembic, services, REST API, WS endpoint
  - Auth: API key → SHA-256 hash, JWT (HS256), 1-hour expiry
  - Sync: `POST /api/v1/results/sync` idempotent batch upsert
  - WebSocket: `/ws/agent` JWT auth, agent_hello + result handlers + connection registry
- [x] WebSocket agent ↔ cloud protocol + result sync (207 tests passing)
- [x] MCP server — 11 tools, FastMCP 3.x, standalone process (249 tests passing)
  - `crucihil/mcp/` — client, server, tools/rigs, runs, results, signals, suites
  - `POST /api/v1/runs` — create queued run + push to agent via WS
  - `describe_failure` — single-call failure context for AI root-cause analysis
  - Config: `CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` env vars
- [ ] JWT auth + RBAC
- [x] React dashboard — 7 pages (Login/Dashboard/Rigs/RigDetail/Runs/RunDetail/Settings), React 18 + TS strict + Vite 5, live WebSocket streaming, zero TS errors (249 tests passing)
- [x] Docker Compose self-hosting stack — `setup.sh` bootstrap (v1+v2 compat), `dev.sh` local dev, `fly.server.toml` / `fly.mcp.toml` / `dashboard/vercel.json` / `.github/workflows/deploy.yml`
- [x] Run detail enrichment — filter bar, source code panel, JUnit XML + HTML report download, queued run redelivery on reconnect (333 tests passing)
- [x] Production rig deployment — `systemd/crucihil-agent@.service` template unit, `scripts/install-agent.sh` installer
- [ ] First paid customer
- [ ] AI-assisted rig setup (Path C): `crucihil discover` → AI generates TOML → confirm-on-first-write
- [ ] Confirm-on-first-write security model for AI file writes
- [ ] `crucihil discover` CLI command

### Phase 3 (Weeks 40–72) — Intelligence
Goal: AI differentiation, enterprise readiness, $10k MRR.

- [ ] AI failure analysis + coverage gap detection
- [ ] `generate_test_suite` MCP tool — YAML suite + Python stub from natural language
- [ ] Pass/fail trend monitoring + regression alerting via MCP
- [ ] AI conversational fallback for rig setup (Level 3/4 graceful degradation)
- [ ] CANvas MCP integration (the flywheel)
- [ ] SOME/IP Methods
- [ ] dSPACE + NI adapters
- [ ] SSO, audit logs, on-premise option
- [ ] Kubernetes Helm chart

---

## CANvas + CruciHiL Flywheel

CANvas (CAN log visualization) and CruciHiL together are more powerful than either alone.

A CruciHiL test run records signal traces. A CANvas MCP server can query those traces. An AI can call both MCP servers in sequence to give an engineer:

*"BrakePressure dropped to 0 at t=14.2s, 200ms before the test timeout. EngineData was at 500ms cadence instead of 10ms — bus load was 94%. The signal missed its arbitration window. This pattern matches 3 previous failures on rig-2."*

This workflow doesn't exist anywhere in the market today. It's the strategic moat.

---

## Lessons Learned

See `tasks/lessons.md` for the full running log. Key rules derived from mistakes:

**Fault descriptors, not coroutines.** `rig.fault.can_dropout()` returns a descriptor. Passing a coroutine to a context manager executes it immediately — wrong lifecycle.

**Signal Store from DBC, not from frames.** Building `signals_index` inside the per-frame decode loop creates metadata duplication proportional to log length. Build once from `db.messages`.

**frame_idx, not timestamp as join key.** CAN logs have duplicate timestamps routinely. Use a monotonic integer assigned at parse time.

**override() always restores.** `__aexit__` must restore signal state unconditionally. Return `False` — never suppress exceptions.

**Backend swap contract is complete.** All five backends (CAN, SOME/IP, DoIP, Power, GPIO) must have ABCs defined. Asymmetric contracts cause subtle bugs when a new backend is added.

**Configuration errors at startup, not runtime.** Pydantic validates TOML on rig init. A test that fails because of a config typo should never be marked `fail`.

**Teardown always runs.** Wrap in try/finally in the runner. Hardware left in unknown state between tests is a rig health issue, not a test issue.

**Verify before done.** Never mark a task complete without running the code. "It should work" is not verification.

**SQLite `:memory:` requires `StaticPool`.** Without `poolclass=StaticPool`, each connection opens a separate in-memory database. `create_all` runs on one connection; test queries hit a different empty one. Always use `StaticPool` for shared in-memory test databases.

**Inject the engine before TestClient starts.** `dependency_overrides[get_db]` only affects endpoint code — not the app's `lifespan`. Call `set_engine(test_engine)` before creating the `TestClient` so `create_all()` in the lifespan uses the test database. Call `reset_engine()` in `finally:` to clean up.

---

## Key External Dependencies

| Library | Version | Purpose |
|---|---|---|
| python-can | >=4.3.0 | CAN bus interface, ASC/BLF file reading |
| cantools | >=39.0.0 | DBC parsing — use `cantools.database.load_file()` |
| python-someip | latest | Virtual SOME/IP backend |
| python-doip | latest | DoIP transport |
| fastapi | >=0.110 | Control plane REST API |
| fastmcp | latest | MCP server |
| pydantic | >=2.0 | Config validation, request/response schemas |
| pydantic-settings | >=2.0 | BaseSettings for server config (env vars + .env file) |
| sqlalchemy | >=2.0 | ORM for PostgreSQL and SQLite |
| alembic | latest | Database migrations |
| psycopg2-binary | >=2.9 | PostgreSQL driver (sync; used by SQLAlchemy) |
| passlib[bcrypt] | >=1.7 | Password/key hashing (used for API key hashing) |
| python-jose[cryptography] | latest | JWT issue + verify (HS256) |
| websockets | >=12.0 | Agent ↔ cloud WebSocket |
| pytest | >=8.0 | Test runner foundation |
| httpx | latest | FastAPI TestClient (dev dependency) |
| asyncio | stdlib | Async everywhere |

---

## Open Questions (Decide Before Implementing)

All previously open questions from the architecture doc are now decided:

| Question | Decision |
|---|---|
| Agent ↔ cloud transport | WebSocket — persistent, agent connects outbound |
| MCP server placement | Separate service, same Docker Compose stack |
| Result storage on agent | SQLite cache, sync on reconnect |
| CANvas MCP — local or cloud? | Local-only for Phase 0/1 |
| Auth for MCP | API key per client, passed in config |
| SOME/IP Phase 0 scope | Events + Fields only. Methods in Phase 1 |
| DoIP Phase 0 scope | Routing activation + UDS + discovery |
| YAML manifest format | v2 schema — one YAML per suite, rich per-test metadata |
| Test authoring split | YAML = metadata + signal steps; Python = assertion logic |
| BYOK AI model | No custom model. MCP provides context; general LLM reasons |
| Rig setup wizard | `crucihil init` (Phase 1) — guided prompts → TOML |
| AI rig setup | Phase 2: `crucihil discover` + AI generates TOML via MCP |
| Discovery fallback | 4-level graceful degradation — always works |
| AI file write security | Confirm-on-first-write; auto-accept with session token |
| Custom backend extension | Module path in TOML, resolved via `importlib` |
| `[rig.udp]` / `[rig.uds]` | Phase 1 — deferred, accepted debt |

---

## Do NOT Build Yet

These will come up. Say no until the trigger condition is met.

- ❌ Custom hardware of any kind
- ❌ Your own CI/CD pipeline UI — integrate with GitHub/GitLab
- ❌ dSPACE/NI adapters before Phase 3
- ❌ ARXML/FIDL parsing before Phase 2/3
- ❌ Mobile app
- ❌ Kubernetes before Phase 3
- ❌ MCP conversation history before real usage patterns are understood
- ❌ Local model option before enterprise customer with data policy requirement
- ❌ LIN/FlexRay before customer request
