#!/usr/bin/env bash
# install-agent.sh — Install CruciHiL rig agent as a systemd service
#
# Run this on each HiL rig machine that needs to connect to the cloud control plane.
#
# Usage:
#   sudo ./install-agent.sh \
#     --rig rigs/thinkpad_hardware.toml \
#     --server https://your-server.example.com \
#     --key crucihil-abcdef123456
#
# What it does:
#   1. Creates /opt/crucihil with venv + package install
#   2. Copies the TOML rig config to /opt/crucihil/rigs/
#   3. Writes the env file to /etc/crucihil/<name>.env (chmod 600)
#   4. Installs systemd/crucihil-agent.service as a template unit
#   5. Enables and starts crucihil-agent@<name>
#
# Requirements:
#   - Python 3.11+ on the rig machine
#   - systemd (any modern Linux)
#   - Root / sudo access

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'

step() { echo -e "\n${BOLD}${BLUE}▸${NC}${BOLD} $*${NC}"; }
ok()   { echo -e "  ${GREEN}✓${NC} $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC} $*"; }
die()  { echo -e "\n  ${RED}✗ Error:${NC} $*\n" >&2; exit 1; }

# ── Parse args ─────────────────────────────────────────────────────────────────
RIG_TOML=""
SERVER_URL=""
API_KEY=""
INSTALL_DIR="/opt/crucihil"
CRUCIHIL_USER="crucihil"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --rig)    RIG_TOML="$2";    shift 2 ;;
    --server) SERVER_URL="$2";  shift 2 ;;
    --key)    API_KEY="$2";     shift 2 ;;
    --dir)    INSTALL_DIR="$2"; shift 2 ;;
    --user)   CRUCIHIL_USER="$2"; shift 2 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ -n "$RIG_TOML" ]]    || die "--rig <path-to-toml> is required"
[[ -n "$SERVER_URL" ]]  || die "--server <url> is required"
[[ -n "$API_KEY" ]]     || die "--key <api-key> is required"
[[ -f "$RIG_TOML" ]]    || die "Rig config not found: $RIG_TOML"
[[ $EUID -eq 0 ]]       || die "Run with sudo"

# Extract rig name from TOML
RIG_NAME=$(python3 -c "
import tomllib, sys
with open('$RIG_TOML', 'rb') as f:
    d = tomllib.load(f)
print(d['rig']['name'])
" 2>/dev/null) || die "Could not read rig.name from $RIG_TOML (requires Python 3.11+)"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo ""
echo -e "${BOLD}${BLUE}  CruciHiL Agent Installer${NC}"
echo -e "  Rig: ${BOLD}${RIG_NAME}${NC}  →  ${SERVER_URL}"
echo ""

# ── 1. Create system user ──────────────────────────────────────────────────────
step "Creating system user '$CRUCIHIL_USER'"
if id "$CRUCIHIL_USER" &>/dev/null; then
  ok "User already exists"
else
  useradd --system --no-create-home --shell /bin/false "$CRUCIHIL_USER"
  ok "Created user $CRUCIHIL_USER"
fi

# ── 2. Install package ─────────────────────────────────────────────────────────
step "Installing CruciHiL to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR/rigs"

if [[ ! -d "$INSTALL_DIR/.venv" ]]; then
  python3 -m venv "$INSTALL_DIR/.venv"
  ok "Created venv"
fi

"$INSTALL_DIR/.venv/bin/pip" install --quiet --upgrade pip
if [[ -f "$PROJECT_ROOT/pyproject.toml" ]]; then
  "$INSTALL_DIR/.venv/bin/pip" install --quiet "$PROJECT_ROOT"
  ok "Installed from local source"
else
  "$INSTALL_DIR/.venv/bin/pip" install --quiet crucihil
  ok "Installed from PyPI"
fi

chown -R "$CRUCIHIL_USER:$CRUCIHIL_USER" "$INSTALL_DIR"

# ── 3. Copy rig config ─────────────────────────────────────────────────────────
step "Copying rig config"
cp "$RIG_TOML" "$INSTALL_DIR/rigs/${RIG_NAME}.toml"
chown "$CRUCIHIL_USER:$CRUCIHIL_USER" "$INSTALL_DIR/rigs/${RIG_NAME}.toml"
ok "Copied to $INSTALL_DIR/rigs/${RIG_NAME}.toml"

# ── 4. Write env file ──────────────────────────────────────────────────────────
step "Writing env file"
mkdir -p /etc/crucihil
cat > "/etc/crucihil/${RIG_NAME}.env" <<EOF
CRUCIHIL_BASE_URL=${SERVER_URL}
CRUCIHIL_API_KEY=${API_KEY}
EOF
chmod 600 "/etc/crucihil/${RIG_NAME}.env"
chown root:root "/etc/crucihil/${RIG_NAME}.env"
ok "Written to /etc/crucihil/${RIG_NAME}.env (chmod 600)"

# ── 5. Install systemd unit ────────────────────────────────────────────────────
step "Installing systemd service"
cp "$SCRIPT_DIR/../systemd/crucihil-agent.service" \
   "/etc/systemd/system/crucihil-agent@.service"
systemctl daemon-reload
ok "Installed crucihil-agent@.service template"

systemctl enable "crucihil-agent@${RIG_NAME}"
systemctl restart "crucihil-agent@${RIG_NAME}"
ok "Enabled and started crucihil-agent@${RIG_NAME}"

# ── Done ───────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}  ✓ Agent installed!${NC}"
echo ""
echo -e "  Check status :  systemctl status crucihil-agent@${RIG_NAME}"
echo -e "  View logs    :  journalctl -u crucihil-agent@${RIG_NAME} -f"
echo -e "  Stop         :  systemctl stop crucihil-agent@${RIG_NAME}"
echo -e "  Uninstall    :  systemctl disable --now crucihil-agent@${RIG_NAME}"
echo ""
