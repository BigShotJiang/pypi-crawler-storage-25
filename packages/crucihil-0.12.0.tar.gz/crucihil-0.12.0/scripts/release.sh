#!/usr/bin/env bash
# Usage: ./scripts/release.sh 0.2.0
set -euo pipefail

# Always run from repo root regardless of where the script is invoked from
cd "$(git rev-parse --show-toplevel)"

VERSION="${1:-}"
if [[ -z "$VERSION" ]]; then
  echo "Usage: $0 <version>  (e.g. $0 0.2.0)" >&2
  exit 1
fi
TAG="v${VERSION}"

# Validate semver format
if ! [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "error: version must be x.y.z (got '$VERSION')" >&2
  exit 1
fi

# Must be on main with a clean tree
BRANCH=$(git rev-parse --abbrev-ref HEAD)
if [[ "$BRANCH" != "main" ]]; then
  echo "error: must be on main branch (currently on '$BRANCH')" >&2
  exit 1
fi

if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "error: working tree has uncommitted changes — commit or stash first" >&2
  exit 1
fi

# Check tag doesn't already exist
if git rev-parse "$TAG" &>/dev/null; then
  echo "error: tag $TAG already exists" >&2
  exit 1
fi

echo "Cutting release $TAG …"

# Bump version in pyproject.toml
sed -i "s/^version = \".*\"/version = \"$VERSION\"/" pyproject.toml
echo "  ✓ pyproject.toml → $VERSION"

git add pyproject.toml
git commit -m "chore: bump version to $VERSION"
echo "  ✓ committed version bump"

git tag "$TAG"
echo "  ✓ tagged $TAG"

git push origin main
git push origin "$TAG"
echo "  ✓ pushed — GitHub Actions will publish to PyPI and create the release"
echo ""
echo "  Watch: https://github.com/crucihil/crucihil/actions"
