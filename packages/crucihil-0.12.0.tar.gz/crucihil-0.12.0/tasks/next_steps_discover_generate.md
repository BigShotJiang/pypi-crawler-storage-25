# CruciHiL — AI Features Implementation Brief
## `crucihil discover` (quality completion) + `generate_test_suite` (AI-powered)

---

## Your role

You are a **distinguished engineer** implementing production features on a commercial
HiL testing platform. This means:

- Read every file before touching it. Understand what exists before adding anything.
- Write the full thing correctly the first time. No half-measures, no stubs left in.
- Every new code path gets a test. Zero regressions — the existing **362 tests** must
  still pass when you are done.
- Keep things simple. The smallest correct implementation beats a clever one.
- Keep documentation in sync. When you change a public function signature or CLI flag,
  update the docstring and `README.md` in the same commit.
- **Self-review before every commit.** Run `git diff --staged`, read every line of your
  own diff, and look for bugs, off-by-ones, missing edge cases, or logic that doesn't
  match this spec before pressing enter on `git commit`. Fix what you find.
- Verify before declaring done. Run the test suite. Confirm features work end-to-end.

---

## Model selection guidance

Pick the right tool for the job — don't default to the most expensive model:

| Task type | Model to use |
|---|---|
| Grep, search, quick read, single-file mechanical change | `claude-haiku-4-5-20251001` |
| Writing code, tests, refactoring, multi-file implementation | `claude-sonnet-4-6` (default) |
| Architecture planning, complex debugging across many files, subtle design decisions | `claude-opus-4-7` |

Most of this task is Sonnet-level work. Only reach for Opus if you hit a genuinely
complex design decision that requires deep reasoning across the whole codebase.

---

## What CruciHiL is

CruciHiL is a Hardware-in-the-Loop (HiL) testing platform for firmware teams. Stack:
Python 3.10+, asyncio, FastAPI, PostgreSQL, React 18, FastMCP, Docker.

Working directory: `/home/dparikh/workspace/crucihil`
Activate venv before running anything: `source .venv/bin/activate`

**Layer model (context only — don't revisit):**
```
Layer 6 — CLI / Web Dashboard
Layer 5 — MCP Server (FastMCP)
Layer 4 — Cloud Control Plane (FastAPI + PostgreSQL)
Layer 3 — Local Agent (test runner)
Layer 2 — Rig HAL (rig.can / rig.sim / rig.fault / rig.ecu)
Layer 1 — Hardware (CAN, Ethernet, GPIO, Power)
```

---

## Current state — what already exists

### `crucihil discover` — exists but incomplete

| File | What it does |
|---|---|
| `crucihil/cli/main.py` lines ~294–490 | `discover` command: probe → describe → AI → confirm → write |
| `crucihil/discover/probe.py` | Probes CAN interfaces, USB adapters, Ethernet, installed packages |
| `crucihil/discover/ai_client.py` | BYOK AI client: Anthropic (Claude) + OpenAI (GPT) via httpx |
| `tests/unit/discover/test_probe.py` | Probe unit tests — all passing |
| `tests/unit/discover/test_ai_client.py` | AI client unit tests — all passing |

**What's missing / broken:**
1. Generated TOML is **never validated** against `RigConfig` Pydantic schema before writing.
   A malformed AI response silently writes a broken TOML file.
2. **No Gemini support.** Many users have `GOOGLE_API_KEY`. Only Anthropic and OpenAI work today.
3. **No CLI integration test.** The full discover flow (probe → AI → confirm → write) has zero
   test coverage. Only the underlying modules are unit-tested.
4. **AI output may include markdown fences.** The system prompt says "no fences" but models
   sometimes wrap output in ` ```toml ``` `. These must be stripped before validation.
5. **Default Anthropic model is stale.** `_ANTHROPIC_MODEL = "claude-sonnet-4-6"` — update to
   `"claude-sonnet-4-6"` (keep Sonnet as default for discover; it's sufficient for TOML gen).
   Make it overridable via `--model` flag.

### `generate_test_suite` MCP tool — exists as static scaffold only

| File | What it does |
|---|---|
| `crucihil/mcp/tools/suites.py` | `list_tests` + `generate_test_suite` (static templates) |
| `tests/unit/mcp/test_tools_suites.py` | 9 tests — all passing |

**What it currently does:**
- Takes `suite_name`, `description`, `rig_name`, `output_dir`
- Writes a YAML manifest with one placeholder test and a Python `pass` stub
- Zero AI involvement

**What it needs to do:**
- Accept an optional `context_items: list[str] | None` — a **broad, free-form list** of
  anything the engineer wants tests for. This is intentionally not limited to CAN signals.
  Examples of valid context items:
  - CAN signals: `"EngineData.RPM"`, `"BrakePressure.Value"`
  - Camera/sensor: `"camera_front.fps"`, `"lidar.point_cloud_rate"`
  - GPS/GNSS: `"gps.latitude"`, `"gnss.fix_quality"`, `"gnss_lock_time_seconds"`
  - Power modes: `"power_mode: sleep/active/standby"`, `"12v_rail voltage"`
  - Fault scenarios: `"can_dropout on EngineData"`, `"power glitch recovery"`
  - Integration flows: `"ECU startup sequence"`, `"shutdown and drain cycle"`
  - Any other string that describes what the test should cover
- When `context_items` is provided AND an AI key is available in env: use the BYOK
  `AIClient` to generate **real assertion stubs** referencing the provided context.
- When no AI key or no context items: fall back to static templates. No error, no crash.
- New parameter: `ai_provider: str | None = None` (auto-detected from env if None)

---

## What you are building

### Feature 1 — `crucihil discover` quality completion

**1a. Strip markdown fences from AI output**

In `crucihil/cli/main.py`, add `_strip_fences()` and call it on AI output before
displaying or validating:

```python
def _strip_fences(text: str) -> str:
    import re
    text = re.sub(r"^```[a-zA-Z]*\n?", "", text.strip())
    text = re.sub(r"\n?```$", "", text)
    return text.strip()
```

**1b. Validate generated TOML against RigConfig**

Add `_validate_toml(toml_content: str) -> list[str]` in `crucihil/cli/main.py`:

```python
def _validate_toml(toml_content: str) -> list[str]:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib
    from pydantic import ValidationError
    from crucihil.hal.config.schema import RigConfig

    try:
        data = tomllib.loads(toml_content)
    except Exception as exc:
        return [f"TOML syntax error: {exc}"]
    try:
        RigConfig(**data)
        return []
    except ValidationError as exc:
        return [f"  • {e['loc']}: {e['msg']}" for e in exc.errors()]
    except Exception as exc:
        return [f"Validation error: {exc}"]
```

After generating TOML (AI or stub path):
- Run `_validate_toml(toml_content)`
- If errors: print them clearly with a `⚠ Warning` header, show the TOML, then still
  offer to write — the engineer may want to edit manually. Never silently block the write.
- If clean: show the TOML with a `✓ Valid` line before asking to write.

**1c. Add Google Gemini as a third provider**

In `crucihil/discover/ai_client.py`:
- Add `_GEMINI_MODEL = "gemini-2.0-flash"` constant
- Add `_call_gemini(self, user_message: str) -> str`:
  - Endpoint: `POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}`
  - Headers: `{"content-type": "application/json"}`
  - Body: `{"contents": [{"parts": [{"text": f"{_SYSTEM_PROMPT}\n\n---\n\n{user_message}"}]}]}`
  - Response path: `resp.json()["candidates"][0]["content"]["parts"][0]["text"]`
  - Gemini has no separate system role in the basic REST API — prepend the system prompt
    to the user message with a separator, as shown above.
- Update `detect_provider()` to check `GOOGLE_API_KEY` third (after Anthropic, OpenAI)
- Update `complete()` dispatch to call `_call_gemini` for provider `"gemini"`
- Update `--provider` flag help text to list all three: `anthropic`, `openai`, `gemini`

**1d. Add `--model` CLI flag to `discover`**

Add `model: Optional[str] = typer.Option(None, "--model", help="...")` to the `discover`
command. Pass it through to `AIClient(provider, api_key, model=model)`. Document the
defaults in the help text per provider.

**1e. CLI integration tests**

Add `tests/unit/discover/test_discover_cli.py`. Use `typer.testing.CliRunner` — do not
make real network calls, mock `httpx.post` for any AI path.

Required tests (≥8):
- `test_no_ai_writes_stub_toml` — `--no-ai --describe "..."` writes a file, content parses as TOML
- `test_validate_good_toml_returns_empty` — `_validate_toml()` returns `[]` for a minimal valid TOML
- `test_validate_missing_rig_section_returns_errors` — missing `[rig]` block → non-empty error list
- `test_validate_syntax_error_returns_error` — invalid TOML syntax → error string with "syntax"
- `test_strip_fences_removes_backtick_block` — strips ` ```toml\n...\n``` `
- `test_strip_fences_is_idempotent_on_clean_toml` — clean TOML passes through unchanged
- `test_gemini_provider_detection` — `GOOGLE_API_KEY` set only → `detect_provider()` returns `("gemini", key)`
- `test_anthropic_takes_priority_over_gemini` — both keys set → `detect_provider()` returns `"anthropic"`

Also add Gemini call tests to `tests/unit/discover/test_ai_client.py`:
- `test_gemini_complete_returns_text` — mocked httpx response, correct response path
- `test_gemini_sends_key_as_query_param` — verify `?key=...` in the URL

---

### Feature 2 — AI-powered `generate_test_suite` MCP tool

**2a. Rename `signals` → `context_items` and extend signature**

In `crucihil/mcp/tools/suites.py`:

```python
async def generate_test_suite(
    suite_name: str,
    description: str,
    rig_name: str = "Virtual_Sim",
    output_dir: str = "tests/suites",
    context_items: list[str] | None = None,   # NEW — see docstring for examples
    ai_provider: str | None = None,           # NEW — auto-detected from env if None
) -> dict:
    """Scaffold a YAML suite manifest and matching Python test stubs.

    When context_items is provided and an AI API key is available in the
    environment (ANTHROPIC_API_KEY, OPENAI_API_KEY, or GOOGLE_API_KEY),
    the Python stubs are AI-generated with real assertions. Otherwise
    static placeholder stubs are written.

    context_items is intentionally broad — it can contain any mix of:
      - CAN signal names:        "EngineData.RPM", "BrakePressure.Value"
      - Camera / sensor feeds:   "camera_front.fps", "lidar.point_cloud_rate"
      - GPS / GNSS:              "gps.latitude", "gnss.fix_quality"
      - Power modes / rails:     "power_mode: sleep/active/standby", "12v_rail voltage"
      - Fault scenarios:         "can_dropout on EngineData", "power glitch recovery"
      - Integration flows:       "ECU startup sequence", "shutdown and drain cycle"
      - Any plain description:   "verify camera latency under 50ms"
    """
```

**2b. AI prompt for test generation**

Add `_TEST_GEN_SYSTEM_PROMPT` as a module-level constant in `suites.py`:

```
You are a CruciHiL test engineer. Generate async Python HiL test functions.

RULES:
1. Each function: `async def test_<name>(rig: Rig) -> None`.
2. Use the CruciHiL rig API appropriate to each context item:
   - CAN signals:    rig.can.expect / rig.can.send / rig.sim.set / rig.sim.start_scheduling
   - Fault tests:    async with rig.fault.inject(rig.fault.can_dropout(...)):
   - Power/GPIO:     Leave as commented TODOs — no rig.power namespace exists yet
   - Sensor/camera/GPS/GNSS: Leave as descriptive assert stubs with clear TODO comments
     explaining what the engineer should wire up (e.g. "TODO: read from rig.udp or custom backend")
   - Integration flows: Combine rig calls with asyncio.sleep for timing
3. Assert with: `assert result.passed, result.fail_msg` for rig.can.expect calls.
   For non-rig assertions use: `assert <condition>, "<failure message>"`
4. No hardware details in test code (no interface names, IPs, CAN bus names).
5. Use context item names as-is. Do not invent new signal names.
6. Output ONLY the function bodies. No imports. Start with `async def test_`.
7. One function per context item concept. Keep each function focused and short.
8. For context items outside the rig.can API, write a clear TODO comment instead of
   leaving a bare pass. The engineer must know exactly what to fill in.
```

User message format:
```
Suite: {suite_name}
Description: {description}
Target rig: {rig_name}
Test context: {", ".join(context_items)}

Generate async test functions. For each context item, write a function that
covers presence/range/fault or whatever is appropriate for that item type.
```

**2c. AI fallback and file structure**

Logic:
```python
if context_items:
    provider_info = detect_provider() if ai_provider is None else (ai_provider, os.getenv(...))
    if provider_info:
        try:
            client = AIClient(provider_info[0], provider_info[1])
            ai_functions = client.complete(_build_test_gen_message(...))
            py_body = ai_functions
        except Exception:
            py_body = None  # fall back
    else:
        py_body = None
else:
    py_body = None
```

If `py_body` is None: use the existing static template (current code path, unchanged).
If `py_body` is set: substitute it into the Python file in place of the static template.

Also update the YAML manifest: parse function names from `py_body` using
`re.findall(r"^async def (test_\w+)", py_body, re.MULTILINE)` and add one
YAML test entry per function. Derive `id` from the function name (strip `test_` prefix),
`name` from the id with underscores replaced by spaces.

**2d. New and updated tests**

Add ≥5 new tests to `tests/unit/mcp/test_tools_suites.py`:

- `test_generate_context_items_no_key_falls_back` — pass `context_items=[...]`, no env key set;
  verify Python file has the static `pass` stub
- `test_generate_context_items_with_ai_key_calls_ai` — mock `AIClient.complete` to return
  two function stubs; verify both appear in the written Python file
- `test_generate_ai_failure_falls_back_gracefully` — mock `AIClient.complete` to raise;
  verify result has no `"error"` key and Python file exists with static content
- `test_generate_yaml_entries_match_ai_functions` — when AI returns 2 functions, YAML has 2 test entries
- `test_generate_broad_context_items_accepted` — pass GPS, camera, and power strings as
  context_items; verify no error (AI not called — just confirming param acceptance)

---

## Key files to read before touching anything

| File | Why |
|---|---|
| `crucihil/cli/main.py` (lines 294–490) | Full `discover` command — understand before editing |
| `crucihil/discover/ai_client.py` | Extend with Gemini; model defaults |
| `crucihil/discover/probe.py` | ProbeResult model — used by `_build_user_message` |
| `crucihil/hal/config/schema.py` | `RigConfig` — used in `_validate_toml` |
| `crucihil/mcp/tools/suites.py` | Current `generate_test_suite` — extend, don't rewrite |
| `tests/unit/discover/test_ai_client.py` | Pattern for mocking httpx AI calls |
| `tests/unit/mcp/test_tools_suites.py` | Pattern for MCP tool tests |

---

## Critical rules (never violate)

- **R1** — Test code never contains hardware details (no interface names, IPs, etc.)
- **R4** — Fault methods return FaultDescriptors, never coroutines
- AI fallback is always silent. Missing key or failed call → static template, never an error.
- Never prompt for a key inside the MCP tool — it runs headless, reads env only.
- TOML validation shows errors but still offers write. Never silently block.
- Keep documentation in sync. Update docstrings and README when you change public APIs.

---

## AI provider summary

| Provider | Env var | Default model | API endpoint |
|---|---|---|---|
| Anthropic | `ANTHROPIC_API_KEY` | `claude-sonnet-4-6` | `https://api.anthropic.com/v1/messages` |
| OpenAI | `OPENAI_API_KEY` | `gpt-4o` | `https://api.openai.com/v1/chat/completions` |
| Gemini | `GOOGLE_API_KEY` | `gemini-2.0-flash` | `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}` |

Detection priority: Anthropic > OpenAI > Gemini. `--provider` overrides auto-detection.

Gemini body: `{"contents": [{"parts": [{"text": "<system>\n\n---\n\n<user>"}]}]}`
Gemini response path: `resp.json()["candidates"][0]["content"]["parts"][0]["text"]`

---

## Commit strategy

4 logical commits in this order. **Self-review your staged diff before each one.**

1. `feat(discover): TOML validation, fence stripping, Gemini provider, --model flag`
   — `crucihil/discover/ai_client.py`, `crucihil/cli/main.py`

2. `test(discover): CLI integration tests — validation, fences, Gemini detection`
   — `tests/unit/discover/test_discover_cli.py`, `tests/unit/discover/test_ai_client.py`

3. `feat(mcp): AI-powered generate_test_suite with broad context_items support`
   — `crucihil/mcp/tools/suites.py`

4. `test(mcp): AI-assisted generate_test_suite tests`
   — `tests/unit/mcp/test_tools_suites.py`

Update `README.md` in commit 1 (new `--model` flag on `discover`) and commit 3
(new `context_items` parameter on `generate_test_suite` in the MCP tools table).

---

## Verification checklist — do not declare done until all pass

```bash
# 1. Full test suite — zero regressions, ≥13 new tests total
source .venv/bin/activate
pytest tests/ -q

# 2. Discover --no-ai smoke test (no API key needed)
crucihil discover --no-ai \
  --describe "PEAK PCAN USB on can0, Nvidia Orin over DoIP on eth0" \
  --output-dir /tmp/test_rigs
# Verify file written, content is valid TOML

# 3. Validation helper — confirm it catches a bad TOML
python -c "
from crucihil.cli.main import _validate_toml
errors = _validate_toml('[rig]\n# missing required fields')
assert errors, 'Expected validation errors'
print('PASS — errors:', errors[:1])
"

# 4. generate_test_suite static path
python -c "
import asyncio
from crucihil.mcp.tools.suites import generate_test_suite
r = asyncio.run(generate_test_suite('brake_check', 'Verify brake pressure', output_dir='/tmp'))
assert 'error' not in r
print('PASS:', r['yaml_path'])
"

# 5. generate_test_suite with broad context_items, no AI key (should fall back)
python -c "
import asyncio, os
for k in ('ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'GOOGLE_API_KEY'):
    os.environ.pop(k, None)
from crucihil.mcp.tools.suites import generate_test_suite
r = asyncio.run(generate_test_suite(
    'sensor_check', 'Check sensor health', output_dir='/tmp',
    context_items=['camera_front.fps', 'gps.latitude', 'power_mode: sleep/active', 'ECU startup sequence']
))
assert 'error' not in r
print('PASS — fell back to template:', r['py_path'])
"
```

---

## What NOT to build

- No Gemini SDK dependency — `httpx.post` only, like the other providers.
- No `--retry` flag on `discover` — one shot with fallback is the right UX.
- No UI or dashboard changes — CLI and MCP only.
- No confirm-on-first-write session tokens — `typer.confirm()` is sufficient; tokens are Phase 3.
- Do not make `context_items` required — the tool must work without them.
- Do not add a `rig.power` namespace — power control is YAML `setup:` steps only; generated
  tests for power context should leave descriptive TODO comments, not API calls.
