# CruciHiL — Phase 2 Step 6: Customer Readiness

> Feed this file into Claude to implement the next phase.
> Read CLAUDE.md, tasks/todo.md, and tasks/lessons.md before doing anything.

---

## What Phase 2 Steps 1–5 built (committed, 249 tests passing)

**Backend — `crucihil/server/` (FastAPI on :8000)**
```
POST /api/v1/auth/token      API key → JWT (HS256, 1h expiry)
GET/POST  /api/v1/rigs       list, create rig (returns one-time api_key)
GET       /api/v1/rigs/:id
GET/POST  /api/v1/runs       list, create-queued
POST      /api/v1/runs/:id/cancel
POST      /api/v1/results/sync   idempotent batch upsert
GET       /api/v1/results?run_id=...
WS /ws/agent?token=<jwt>     agent_hello / result / ping
WS /ws/viewer?token=<jwt>&run_id=<id>  dashboard live streaming
```
Auth: one API key per rig (SHA-256 stored, JWT issued). No user concept yet.
JWT payload: `{ sub: rig_name, rig_id, iat, exp }`

**Agent** — `crucihil/agent/`: JWT auth, result streaming, 30s heartbeat, SQLite cache, offline sync.

**MCP** — `crucihil/mcp/`: 11 tools, FastMCP 3.x, stdio or SSE on :8001.

**Dashboard** — `dashboard/` (React 18 + TypeScript strict + Vite 5):
- Routes: `/login`, `/`, `/rigs`, `/rigs/:id`, `/runs`, `/runs/:id`, `/settings`
- Auth: `crucihil_jwt` in localStorage, Axios interceptor, 401 → /login
- Live results: `useRunStream` hook via `/ws/viewer`
- Status badges, RigOnlineIndicator, progress bar, run cancellation

**Deployment configs** — `fly.server.toml`, `fly.mcp.toml`, `dashboard/vercel.json`, `.github/workflows/deploy.yml`

**Scripts** — `setup.sh` (full bootstrap, docker-compose v1+v2), `dev.sh` (backend + Vite HMR)

---

## Step 6 — Four tracks

### Track D: Local virtual rig testing ✅ COMPLETE (implemented first — unblocks all other work)
### Track A: Rig registration UI + RBAC (enables multi-user customers)
### Track B: `crucihil discover` (AI-assisted rig setup — Path C)
### Track C: Production deployment (Fly.io + Vercel one-time setup)

---

## Track D: Local Virtual Rig Testing (No Hardware Required) ✅ COMPLETE

### Why
Without real hardware, the only way to develop and test CruciHiL end-to-end locally is via the virtual rig. Three gaps prevented this from working:
1. The agent ignored `run_suite` commands from the server (the TODO comment was never implemented)
2. The agent could only read cloud config from the rig TOML (read-only in Docker), not env vars
3. Run status never transitioned from `queued → running → pass/fail`

### D1 — Agent: handle `run_suite` WS command ✅

`crucihil/agent/agent.py` now handles `run_suite` messages from the server:
- Resolves suite path relative to `cwd()` (same as DBC path resolution)
- Spawns a background asyncio task per run (non-blocking WS loop)
- Streams results back via `on_result()` → `{"type": "result", ...}`
- Sends `run_start` when execution begins, `run_complete` when it ends
- Supports `cancel_run` to cancel an in-flight run

Also handles `cancel_run` command by cancelling the background task.

### D2 — Agent: env var cloud config override ✅

`CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` environment variables now take priority over `[rig.cloud]` in the TOML. This allows Docker Compose to inject cloud config without modifying the read-only TOML.

Priority order:
1. `CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` env vars (highest)
2. `[rig.cloud]` section in the rig TOML

### D3 — Server: run lifecycle WS handlers ✅

`crucihil/server/api/ws/agent.py` now handles two new message types:
- `run_start` → marks the run row `status = "running"` (was stuck at "queued" forever)
- `run_complete` → calls `finalize_run()` which computes pass/fail/blocked counts and sets terminal status

### D4 — Docker Compose: agent cloud config ✅

`docker-compose.yml` agent service now receives:
```yaml
environment:
  CRUCIHIL_BASE_URL: http://server:8000
  CRUCIHIL_API_KEY: ${CRUCIHIL_API_KEY}
```

This connects the virtual rig agent to the local server automatically when started via Docker Compose.

### D5 — dev.sh: `--agent` flag ✅

`./dev.sh --agent` now starts the virtual rig agent alongside the backend:
```
./dev.sh --agent        # backend + virtual agent + dashboard
./dev.sh --backend --agent   # backend + virtual agent only
```

The flag checks that `CRUCIHIL_API_KEY` is set in `.env` (populated by `./setup.sh`).

### Local dev workflow (no hardware)

```bash
# One-time setup
./setup.sh              # starts db+server, registers default rig, writes CRUCIHIL_API_KEY to .env

# Daily dev
./dev.sh --agent        # starts db+server+mcp+agent+dashboard
# → Dashboard at http://localhost:5173
# → Virtual rig agent connected and ready for test runs

# Run tests directly (no server needed)
source .venv/bin/activate
crucihil run --suite tests/suites/engine_functions.py --rig rigs/virtual.toml

# Run tests via MCP (Claude can trigger runs)
# Use the crucihil MCP tools: run_test_suite, get_results, describe_failure
```

### Definition of done ✅
- [x] `run_suite` command from server triggers a real test run on the virtual rig
- [x] Results stream back to the dashboard via WebSocket
- [x] Run status transitions: queued → running → pass/fail/blocked
- [x] Agent gets cloud config from env vars (Docker Compose compatible)
- [x] `./dev.sh --agent` starts the full local stack
- [x] `./setup.sh` workflow unchanged (still registers the rig, sets CRUCIHIL_API_KEY)
- [x] All 249 existing tests pass

---

## Track A: Rig Registration UI + RBAC

### Why
Currently: creating a rig requires a raw `curl` call. API key is shown once in JSON with no UI. A customer's first experience is the command line before the dashboard even loads. Fix this.

### A1 — Server: add `role` to JWT and admin middleware

Extend `crucihil/server/services/auth.py`:

```python
# JWT payload gains a `role` field
payload = {
    "sub": rig_name,
    "rig_id": rig_id,
    "role": rig_role,  # "admin" | "viewer"
    "iat": now,
    "exp": now + settings.JWT_EXPIRY_SECONDS,
}
```

`RigRow` gets a `role` column:
```python
role: Mapped[str] = mapped_column(String(16), nullable=False, default="admin")
```

Add a new Alembic migration `0002_rig_role.py`.

Add `get_admin_rig` dependency (raises 403 if `role != "admin"`):
```python
def get_admin_rig(current: RigRow = Depends(get_current_rig)) -> RigRow:
    if current.role != "admin":
        raise HTTPException(403, "Admin role required")
    return current
```

Protect write endpoints with `get_admin_rig`:
- `POST /api/v1/rigs` — requires admin
- `POST /api/v1/runs` — requires admin
- `POST /api/v1/runs/:id/cancel` — requires admin
- `DELETE /api/v1/rigs/:id` — requires admin (add this endpoint)

Read-only endpoints remain accessible to both roles:
- `GET /api/v1/rigs`, `GET /api/v1/runs`, `GET /api/v1/results` — any authenticated JWT

### A2 — Server: add `POST /api/v1/rigs/:id/viewers` endpoint

Allow an admin rig to generate viewer API keys (limited-scope JWTs):
```
POST /api/v1/rigs/:id/viewers   { "name": "ci-readonly" }
→ { viewer_key: "crucihil-viewer-...", role: "viewer" }
```

A viewer key authenticates as the same `rig_id` but with `role: "viewer"` in the JWT. It can GET everything but cannot create runs, cancel runs, or register rigs.

Store viewer keys in a new `viewer_keys` table:
```
id (int PK), rig_id (FK), name (str), api_key_hash (str), created_at (float), revoked (bool)
```

Add `DELETE /api/v1/rigs/:id/viewers/:viewer_id` to revoke.

### A3 — Dashboard: Register Rig modal

Add a "Register Rig" button to `RigsPage`. On click, open a modal:

```
┌─────────────────────────────────────────┐
│  Register a Rig                         │
│                                         │
│  Name  [my-bench-001             ]      │
│                                         │
│  [ Register ]                           │
└─────────────────────────────────────────┘
```

On success, show the API key in a one-time display modal:

```
┌─────────────────────────────────────────┐
│  ✓ Rig registered                       │
│                                         │
│  API Key (shown once — copy now):       │
│  ┌─────────────────────────────────┐    │
│  │ crucihil-rig-abc123...          │    │
│  └─────────────────────────────────┘    │
│  [ Copy to clipboard ]                  │
│                                         │
│  Add to your rig TOML:                  │
│  [rig.cloud]                            │
│  api_key = "crucihil-rig-abc123..."     │
│                                         │
│  [ Done — I've saved the key ]          │
└─────────────────────────────────────────┘
```

Key details:
- `useMutation` from TanStack Query for the POST
- Modal state: `idle | registering | key_shown`
- Once "Done" is clicked the modal closes; the key is gone forever
- The RigsPage query is invalidated so the new rig appears immediately
- Use `navigator.clipboard.writeText()` for the copy button

### A4 — Dashboard: role-aware UI

Decode the `role` claim from the JWT stored in localStorage:
```typescript
// src/hooks/useAuth.ts — expose role
interface AuthContextValue {
  token: string | null
  isAuthenticated: boolean
  role: 'admin' | 'viewer' | null
  login: (token: string) => void
  logout: () => void
}
```

Hide admin-only actions when `role !== 'admin'`:
- "Register Rig" button on RigsPage
- "Cancel" button on RunDetailPage
- (Future) "Delete" rig button

### A5 — Tests

Add to `tests/integration/server/test_rbac.py`:
- Viewer JWT can GET rigs/runs/results
- Viewer JWT gets 403 on POST /api/v1/runs
- Viewer JWT gets 403 on POST /api/v1/rigs
- Admin JWT can do all of the above
- Alembic migration runs cleanly on a fresh SQLite DB

---

## Track B: `crucihil discover` — AI-Assisted Rig Setup (Path C)

### Why
Path A (manual TOML) takes 20+ minutes for a new user. Path B (`crucihil init` wizard) takes 5 minutes but requires knowing exact interface names. Path C uses AI to generate the TOML from a natural language description of the hardware — target: under 2 minutes, zero prior knowledge required.

### B1 — New CLI command

Add to `crucihil/cli/main.py`:
```
crucihil discover [--output <path>] [--rig-name <name>] [--ai-provider <claude|openai|gemini>]
```

### B2 — Hardware probe (`crucihil/agent/discover/probe.py`)

Gather hardware facts automatically:

```python
@dataclass
class HardwareSnapshot:
    # CAN interfaces
    can_interfaces: list[str]         # from `ip link show type can`
    pcan_devices: list[str]           # from `ls /dev/pcan*` if available
    # Network
    eth_interfaces: list[str]         # from `ip link show` (non-loopback, non-CAN)
    # Platform hints
    platform: str                     # Linux, etc.
    kernel: str                       # uname -r
    # DBC files found
    dbc_files: list[Path]             # glob("**/*.dbc", CWD)
```

Probe functions (all wrapped in try/except — never crash on missing tools):
- `probe_can_interfaces()` — `ip link show type can` stdout parsing
- `probe_pcan_devices()` — glob `/dev/pcan*`
- `probe_eth_interfaces()` — `ip -j link show` JSON parsing
- `probe_dbc_files()` — `glob("**/*.dbc")` from CWD (depth ≤ 3)

### B3 — AI TOML generator (`crucihil/agent/discover/generator.py`)

Use `crucihil/ai/provider.py` (already exists) to call the configured AI provider:

```python
async def generate_rig_toml(
    snapshot: HardwareSnapshot,
    rig_name: str,
    provider: AIProvider,
) -> str:
    """Ask the AI to generate a rig TOML from the hardware snapshot."""
    prompt = build_discovery_prompt(snapshot, rig_name)
    response = await provider.complete(prompt)
    return extract_toml_block(response)
```

The prompt must include:
- The full `RigConfig` Pydantic schema (from `crucihil/hal/config/schema.py`)
- The discovered hardware snapshot
- Examples of valid TOML configs (from `rigs/virtual.toml` and `rigs/example_orin.toml`)
- Instructions to use `"virtual"` for any interface not found
- Instruction to output only the TOML block, no prose

`extract_toml_block()` strips markdown fences and extracts the TOML content.
Validate the result with `RigConfig.model_validate(tomllib.loads(toml_str))` before writing.

### B4 — Confirm-on-first-write security model

```python
async def confirm_and_write(path: Path, content: str) -> bool:
    """Show a diff-style preview, require explicit yes."""
    print(f"\nAI-generated TOML for {path}:\n")
    print(content)
    print(f"\nWrite to {path}? [y/N] ", end="", flush=True)
    answer = input().strip().lower()
    if answer == "y":
        path.write_text(content)
        return True
    return False
```

The first write per session requires `y`. Subsequent writes (in the same process, via a session flag) auto-accept. This is the "confirm-on-first-write" security model from CLAUDE.md.

### B5 — CLI integration

Full `crucihil discover` flow:
```
$ crucihil discover --rig-name bench-001

  CruciHiL Rig Discovery
  ─────────────────────────────────────

  ▸ Probing hardware...
    ✓ CAN interfaces: vcan0, can0
    ✓ Ethernet: eth0, eth1
    ✓ DBC files: defs/vehicle_can.dbc
    · No PCAN devices found

  ▸ Generating TOML via AI (claude-sonnet-4-6)...

  AI-generated rig config:
  ─────────────────────────────────────
  [rig]
  name = "bench-001"
  ...

  ─────────────────────────────────────
  Write to rigs/bench-001.toml? [y/N] y
  ✓ Written to rigs/bench-001.toml

  Validate: crucihil run --suite tests/suites/smoke.yaml --rig rigs/bench-001.toml
```

### B6 — AI provider config

`crucihil discover` reads the AI provider from (in priority order):
1. `--ai-provider` CLI flag
2. `CRUCIHIL_AI_PROVIDER` env var
3. Auto-detect: if `ANTHROPIC_API_KEY` is set → Claude; if `OPENAI_API_KEY` is set → OpenAI; else error

`crucihil/ai/provider.py` already has the provider abstraction. Wire `crucihil discover` to it.

Default model: `claude-sonnet-4-6` (from CLAUDE.md guidance).

### B7 — Tests

`tests/unit/agent/test_discover.py`:
- `probe_can_interfaces()` parses `ip link show type can` stdout correctly
- `probe_dbc_files()` finds DBC files within depth limit
- `extract_toml_block()` strips markdown fences correctly
- `confirm_and_write()` writes on "y", skips on "n", skips on empty input
- `generate_rig_toml()` (mocked AI) → validates with `RigConfig.model_validate`

---

## Track C: Production Deployment (one-time, manual)

This is not code — it's the human steps to get `crucihil-server.fly.dev` and `app.crucihil.io` live. Document these in `README.md` under a "Production Deployment" heading (not "Self-Hosting"). The deployment config files already exist (`fly.server.toml`, `fly.mcp.toml`, `dashboard/vercel.json`).

### C1 — Fly.io setup (run once)

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Authenticate
fly auth login

# Create Postgres (managed, shared-cpu-1x, cheapest tier)
fly postgres create --name crucihil-db --region iad --vm-size shared-cpu-1x

# Create and deploy server
fly apps create crucihil-server
fly postgres attach crucihil-db --app crucihil-server  # sets DATABASE_URL secret automatically
fly secrets set SECRET_KEY="$(openssl rand -hex 32)" --app crucihil-server
fly deploy --config fly.server.toml --app crucihil-server

# Register a production rig and get its API key
curl -s -X POST https://crucihil-server.fly.dev/api/v1/rigs \
     -H 'Content-Type: application/json' \
     -d '{"name":"production"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['api_key'])"

# Create and deploy MCP
fly apps create crucihil-mcp
fly secrets set CRUCIHIL_API_KEY="<key from above>" --app crucihil-mcp
fly deploy --config fly.mcp.toml --app crucihil-mcp
```

### C2 — Vercel setup (run once, via vercel.com UI)

Two projects connected to this GitHub repo:

**Project 1 — crucihil-website:**
- Root directory: `website/`
- Framework: Other (static HTML)
- Build command: (none)
- Output directory: `./`
- Domains: `crucihil.io`, `www.crucihil.io`

**Project 2 — crucihil-dashboard:**
- Root directory: `dashboard/`
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Environment variable: `VITE_API_BASE_URL = https://crucihil-server.fly.dev`
- Domains: `app.crucihil.io`

### C3 — GitHub Actions secrets

Add to GitHub repo settings → Secrets:
- `FLY_API_TOKEN` — from `fly auth token`

The `.github/workflows/deploy.yml` file already exists and wires: pytest → Fly deploy → Vercel (auto).

### C4 — Verify production

```bash
curl https://crucihil-server.fly.dev/openapi.json | jq .info    # → 200 with version
curl -I https://crucihil-mcp.fly.dev/sse                        # → 200
# Visit https://app.crucihil.io — should show the login page
```

---

## Implementation order

For a solo sprint, the recommended order:

1. **Track C first** (30 min) — get production URLs live while writing code
2. **Track A** (2–3 days) — RBAC + rig registration UI is the customer-facing blocker
3. **Track B** (2–3 days) — `crucihil discover` is the differentiator for new-user conversion
4. Merge both to main → GitHub Actions deploys automatically

---

## Definition of done

### Track A
- [ ] `role` column exists in `rigs` table (migration 0002)
- [ ] Viewer JWT gets 403 on all write endpoints
- [ ] Admin JWT can register rigs, create runs, cancel runs
- [ ] Dashboard shows "Register Rig" button only to admins
- [ ] One-time API key modal closes and key is unrecoverable after "Done"
- [ ] All existing 249 tests still pass + ≥15 new RBAC tests

### Track B
- [ ] `crucihil discover` command exists and shows in `crucihil --help`
- [ ] Probe functions don't crash on machines without CAN interfaces
- [ ] AI-generated TOML validates against `RigConfig` schema before write
- [ ] Confirm-on-first-write prompts user on first write, auto-accepts on second
- [ ] Generated TOML loads without `ConfigurationError` on a clean rig
- [ ] Unit tests for all probe + extraction functions

### Track C
- [ ] `https://crucihil-server.fly.dev/openapi.json` returns 200
- [ ] `https://crucihil-mcp.fly.dev/sse` returns 200
- [ ] `https://app.crucihil.io` loads the login page
- [ ] GitHub Actions `deploy.yml` passes on main

---

## Key files to read before starting

- `crucihil/server/services/auth.py` — JWT issue/verify, API key hash
- `crucihil/server/api/deps.py` — `get_current_rig` dependency
- `crucihil/server/models/rig.py` — `RigRow` ORM model
- `crucihil/server/db/migrations/versions/0001_initial.py` — migration style
- `crucihil/agent/init/wizard.py` — existing Path B wizard (model for Path C)
- `crucihil/ai/provider.py` — AI provider abstraction
- `crucihil/hal/config/schema.py` — `RigConfig` Pydantic model
- `dashboard/src/contexts/AuthContext.tsx` — JWT decode, login/logout
- `dashboard/src/hooks/useAuth.ts` — auth hook (extend to expose `role`)

---

## Notes for the implementer

**Do NOT build yet:**
- Multi-tenant (org isolation) — wait until you have 2+ paying customers who need it
- SSO / OAuth — overkill for Phase 2
- Audit logs — Phase 3 enterprise feature
- Email notifications — Phase 3
- LIN/FlexRay backends — only on customer request

**Keep the RBAC simple:**
Two roles only: `admin` (full access, the rig API key holder) and `viewer` (read-only, CI tokens). No ABAC, no permission matrices, no UI role editor. The rig owner is always admin; viewer keys are created by the admin.

**`crucihil discover` scope:**
Generate a TOML only — don't try to validate it against live hardware in this step. The `crucihil run --rig <path>` command already validates at startup. Just generate, confirm, and write.
