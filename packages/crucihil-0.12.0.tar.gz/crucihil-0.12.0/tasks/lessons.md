# CruciHiL — Lessons Learned Log

Running log of mistakes, corrections, and non-obvious decisions made during development.
Read this at the start of every session. Add to it after any correction.

---

## Phase 0 Lessons

### L1 — Python version mismatch (tomllib)

**What happened:** `pyproject.toml` said `requires-python = ">=3.11"` but the venv is Python 3.10.12. `tomllib` is stdlib only in 3.11+. Tests failed with `ModuleNotFoundError: No module named 'tomllib'`.

**Fix:** Added compat shim to `config/loader.py`:
```python
try:
    import tomllib
except ImportError:
    import tomli as tomllib  # Python < 3.11
```
Also relaxed `requires-python` to `>=3.10` to match the actual environment.

**Rule:** Always verify the actual venv Python version before using stdlib modules added in recent releases. Check `sys.version_info` or `.venv/bin/python --version`.

---

### L2 — DBC path resolution relative to TOML location, not CWD

**What happened:** `BusSimEngine` resolved `defs/vehicle_can.dbc` relative to the TOML file's directory (`rigs/`), producing path `rigs/defs/vehicle_can.dbc` which doesn't exist. DBC lives at project root: `defs/vehicle_can.dbc`.

**Fix:** Changed `BusSimEngine.__init__` `base_dir` default from `"."` to `None`, resolving as `Path.cwd()` when `None`. Removed the `base_dir=self._config_path.parent` argument from `Rig._setup_bse()`.

**Rule:** DBC paths in TOML are always relative to project root (CWD when running `crucihil run`), never relative to the TOML file. The BSE `base_dir` always defaults to `Path.cwd()`.

---

### L3 — Typer single-command app does not create subcommands

**What happened:** Defined one `@app.command()` function named `run`. Calling `crucihil run --suite ...` failed with "Got unexpected extra argument (run)" — typer treated `run` as a positional arg to the root command, not a subcommand.

**Fix:** Added a second command (`version`) so typer switches to multi-command mode and exposes named subcommands (`crucihil run`, `crucihil version`).

**Rule:** Typer only activates subcommand routing when there are ≥2 commands registered. A single `@app.command()` makes the function the root default. Add at minimum a `version` command to enable subcommand mode.

---

### L4 — BSE has `_schedulers` (plural), not `_scheduler` (singular)

**What happened:** Integration test asserted `rig._bse._scheduler._tasks.get("EngineData")` — `AttributeError: 'BusSimEngine' object has no attribute '_scheduler'`.

**Fix:** Corrected to `rig._bse._schedulers` (dict keyed by CAN interface name), then iterated `.active_messages()` per scheduler.

**Rule:** BSE has one `MessageScheduler` per CAN interface, stored in `_schedulers: dict[str, MessageScheduler]`. Each scheduler has `active_messages() -> list[str]` and `_tasks: dict[str, asyncio.Task]`.

---

### L5 — YAML step format is single-key mapping; validate early

**What happened:** YAML steps like `- sim.set: { signal: "...", value: 0 }` are single-key dicts. When a test YAML had two keys in one step (typo), the error surfaced only at runtime as a cryptic `StopIteration`.

**Fix:** Added explicit validation in `_parse_steps()` — raise `ConfigurationError` if a step dict doesn't have exactly one key. Error shows the offending step and file path.

**Rule:** Validate YAML structure at load time (R9). Single-key mapping format must be caught explicitly. `len(item) != 1` is the check.

---

### L6 — FaultDescriptor must never be a coroutine (R4 is real)

**What happened:** In early design, `can_dropout()` was defined as `async def`. Calling it inside `async with rig.fault.inject(rig.fault.can_dropout(...)):` executed the coroutine immediately (Python evaluates function args before calling `inject()`), bypassing the injection lifecycle.

**Fix:** All `rig.fault.*()` methods are plain sync functions returning `FaultDescriptor` dataclasses. `inject()` is the only entry point that activates them.

**Verification:** `test_not_awaitable` in `tests/unit/test_models.py` asserts `not inspect.isawaitable(fd)` on every descriptor.

---

### L7 — Signal Store must be built from DBC, not from decoded frames

**What happened:** Earlier design populated `signals_index` inside the per-frame CAN callback. This created duplicate metadata entries proportional to log length (O(frames × signals)), causing memory growth and slow lookups on longer runs.

**Fix:** `SignalStore.build_from_dbc(db)` is called once after `cantools.database.load_file()`. The per-frame callback calls only `update_from_decoded()` to update live values — no metadata creation.

**Rule (R2):** Signal Store is populated once from the DBC. The decode loop only updates values, never creates schema entries.

---

### L8 — `asyncio.get_running_loop().create_task()` for non-blocking frame delivery

**What happened:** `VirtualCANBackend.send()` initially called callbacks synchronously in sequence. A callback that did blocking work (e.g. waiting for a queue) would deadlock the sender.

**Fix:** Delivery to each registered callback is wrapped in `asyncio.get_running_loop().create_task(cb(frame))`. Each callback runs as an independent task — sender does not wait for delivery to complete.

**Rule (R3):** No blocking calls in the event loop. CAN frame dispatch to listeners is always `create_task`, never `await cb(frame)` directly.

---

### L9 — `__aexit__` must return False, never suppress exceptions (R8)

**What happened:** An early `SimNamespace.override()` implementation returned `True` from `__aexit__` in the finally block, which suppressed any exception raised inside the `async with` block.

**Fix:** All context managers return `False` from `__aexit__`. Cleanup runs unconditionally in `finally:`, but exceptions propagate to the caller.

**Rule (R8):** Teardown always runs AND exceptions always propagate. `return False` in every `__aexit__`. Never `return True` unless you have an explicit, documented reason to swallow the exception.

---

---

## Phase 1 Lessons

### L11 — DoIP backends must be connected at rig.connect() time, not deferred

**What happened:** `VirtualDoIPBackend.connected` was False when `rig.ecu.ecu_main.flash()` was called because `_setup_backends` created the backend but left `connect()` deferred with a comment "deferred to rig.ecu.connect() per ECU".

**Fix:** Call `doip.connect(ip=..., port=13400, source_address=0x0E00, timeout=5.0)` in `_setup_backends` for each ethernet interface, immediately after instantiation. The tester source address (0x0E00 per ISO 13400-2) is fixed — per-ECU target addresses go in `uds_request(target_address=...)`.

**Rule:** All backends are connected in `Rig._setup_backends()`. Never leave a backend unconnected and assume the namespace will call `connect()` later — the namespace has no lifecycle management role.

---

### L12 — SQLAlchemy Declarative API reserves the column name `metadata`

**What happened:** `_TestResultRow.metadata = Column(Text, ...)` in `cache.py` raised `InvalidRequestError: Attribute name 'metadata' is reserved when using the Declarative API`.

**Fix:** Renamed to `extra_meta`. The `_row_to_result()` function reads `row.extra_meta` and maps it back to `TestResult.metadata`.

**Rule:** Never name a SQLAlchemy ORM column `metadata`, `registry`, or other SQLAlchemy internal names. Check the SQLAlchemy reserved list before naming ORM attributes.

---

### L13 — VirtualCANBackend needs `block_arb_id` / `unblock_arb_id` for fault tests

**What happened:** `test_can_dropout_blocks_send` failed because `FaultNamespace._activate` calls `hasattr(backend, "block_arb_id")` — and VirtualCANBackend didn't have that method, so no dropout happened even against the virtual backend.

**Fix:** Added `block_arb_id`, `unblock_arb_id`, and a `_blocked_arb_ids` set to `VirtualCANBackend`. Also added the check in `send()`: `if arb_id in self._blocked_arb_ids: return`.

**Rule:** Fault injection support is part of the backend contract for CAN backends — not just for real hardware. Virtual backends must implement dropout so CI tests can verify the full fault injection lifecycle.

---

### L14 — ECU flash `_request_download` must handle empty virtual response payload

**What happened:** `VirtualDoIPBackend` returns an empty payload for 0x34 RequestDownload (default positive ACK with no data). The flash code then raised `FlashError("0x34 response too short")`.

**Fix:** Added a graceful fallback: if the response payload is empty, use a default `maxBlockLen = 128`. This allows flash to complete successfully in CI with the virtual backend.

**Rule:** When decoding optional response fields from hardware, always provide a safe default rather than failing hard. Real hardware will return proper values; virtual backends return minimal stubs.

---

---

## Phase 2 Step 2 Lessons

### L17 — SQLite `create_all()` does not add new columns to existing tables

**What happened:** Adding `synced_at` column to `_TestResultRow` works for fresh databases (via `create_all()`), but existing `results.db` files on disk have no such column. Queries against the old schema fail with `OperationalError: no such column: synced_at`.

**Fix:** Added `_migrate_schema(engine)` called after `create_all()` in `ResultCache.open()`. It runs `ALTER TABLE test_results ADD COLUMN synced_at REAL` inside a try/except — the exception is swallowed silently when the column already exists (SQLite raises an error, not a warning, on duplicate columns).

**Rule:** Whenever a new column is added to any SQLite ORM model, add a corresponding `ALTER TABLE … ADD COLUMN` in a migration helper. Never rely on `create_all()` to evolve an existing schema.

---

### L18 — runner callback (`on_result`) belongs in the caller, not the runner

**What happened:** Early design considered putting the cache write inside `run_suite()` directly. This would have coupled the runner to the cache — a lower-level module importing a higher-level one, inverting the dependency hierarchy.

**Fix:** `run_suite()` accepts an `on_result: Callable[[TestResult], Awaitable[None]] | None` parameter. The agent provides the callback; the CLI provides `None`. The runner stays pure — it executes tests and fires the callback; it does not know what the callback does.

**Rule:** The runner (Layer 3) must not import the cache or the agent. Side effects after test completion belong in the caller (agent, CLI, future MCP trigger). Pass a callback; never couple the runner to a specific destination.

---

## Phase 2 Lessons

### L15 — SQLite `:memory:` requires `StaticPool` for shared in-memory databases in tests

**What happened:** FastAPI `TestClient` integration tests got `OperationalError: no such table: rigs` even though `Base.metadata.create_all(engine)` ran successfully. Root cause: SQLite `:memory:` opens a **new, separate database per connection**. The `db_engine` fixture created the schema in one connection; the test client's `get_db` override opened a different connection (and therefore a different empty database).

**Fix:** Use `StaticPool` from `sqlalchemy.pool`:
```python
from sqlalchemy.pool import StaticPool
engine = create_engine(
    "sqlite:///:memory:",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
```
`StaticPool` forces all connections to reuse the same underlying connection — so `create_all` and all subsequent queries share one in-memory database.

**Rule:** Always use `poolclass=StaticPool` for SQLite `:memory:` test engines. Apply to both `unit/server/` and `integration/server/` conftest fixtures.

---

### L16 — FastAPI lifespan needs the test engine injected before `TestClient` starts

**What happened:** Even with `dependency_overrides[get_db]` wired to the test's SQLite engine, the app's `lifespan` still called `get_engine()` which returned the global engine (pointed at PostgreSQL), causing `OperationalError: could not connect to server`.

**Fix:** Added `set_engine()` to `db/session.py` that replaces the global `_engine` and clears `_SessionLocal`. The `client` fixture calls `set_engine(db_engine)` **before** creating the `TestClient`, and `reset_engine()` in `finally:` to clean up:
```python
set_engine(db_engine)          # wire lifespan + session factory to test DB
app = create_app()
app.dependency_overrides[get_db] = override_get_db
with TestClient(app) as c:
    yield c
# finally: reset_engine()
```

**Rule:** When testing FastAPI apps with lifespan that touch the database, override the engine **at the module level** (not just via dependency injection) before the TestClient starts. Dependency overrides only affect endpoint dependencies — not lifespan code.

---

### L10 — `TestSuite` dataclass name conflicts with pytest collection

**What happened:** `TestSuite` in `manifest/schema.py` triggered `PytestCollectionWarning: cannot collect test class 'TestSuite' because it has a __init__ constructor`. Pytest sees any class starting with `Test` as a potential test class.

**Fix:** Added `filterwarnings = ["ignore::pytest.PytestCollectionWarning"]` to `[tool.pytest.ini_options]` in `pyproject.toml`. The name `TestSuite` is architecturally correct (from the spec) so the warning is suppressed rather than renaming the class.

**Rule:** If a domain class name starts with `Test`, suppress the collection warning in pytest config. Don't rename domain types to work around tooling conventions.

---

## Phase 2 Step 6 Lessons

### L19 — WebSocket ack ordering matters: ack before redelivery, then `continue`

**What happened:** Added `_redeliver_queued_runs()` to push missed `run_suite` messages on `agent_hello`. The existing loop sent ack at the **end** of the loop body. With redelivery inserted before the ack, the agent received `run_suite` before `ack`, causing the test assertion `ack["type"] == "ack"` to fail (it got a `run_suite` message instead).

**Fix:** For the `agent_hello` branch: send ack first, then redeliver, then `continue` (skipping the default ack at loop bottom):
```python
if msg_type == "agent_hello":
    _handle_hello(factory, rig_id, msg)
    await websocket.send_text(json.dumps({"type": "ack", "msg_type": msg_type}))
    await _redeliver_queued_runs(websocket, factory, rig_id)
    continue  # skip default ack — already sent above
```

**Rule:** In WebSocket handlers with a default ack at the end of the loop, any branch that deviates from the default must `continue` after its custom send sequence. Acks always precede follow-up pushes.

---

### L20 — `set -euo pipefail` + non-zero Docker exit kills multi-rig script before native agent section

**What happened:** `dev.sh` used `set -euo pipefail`. When `docker compose up -d agent` failed (stale network reference), the script exited immediately — never reaching the native agent registration or startup sections for `--rig` arguments.

**Fix:** Wrapped Docker agent start in a conditional:
```bash
if $DC --profile agent up -d --force-recreate agent; then
    ok "Docker agent started"
else
    warn "Docker agent failed to start — continuing with native rigs"
fi
```

**Rule:** In bash scripts with `set -e`, always wrap optional or potentially-failing commands in `if ... ; then ... else ... fi`. Never assume Docker Compose commands succeed — container environments change (stale networks, port conflicts, image changes). Isolate failures so the rest of the script runs.

---

### L21 — Queued run re-registration recovery: 409 means stale DB entry, not a real conflict

**What happened:** When `CRUCIHIL_RIG_KEY_THINKPAD_HARDWARE` was missing from `.env` (key lost), `dev.sh` tried to register the rig again. The server returned 409 (rig name already exists). The script had no handler for 409, so it exited without a key — the native agent started in local-only mode.

**Fix:** `_register_or_load_rig_key()` detects 409, uses the admin JWT from `CRUCIHIL_API_KEY` to `DELETE /api/v1/rigs/<name>`, then re-registers to get a fresh key. The key is written to `.env`.

**Rule:** A 409 on rig registration means the name is taken in the DB but the key is gone locally. The correct recovery is DELETE + re-register (not fail). This requires the admin key (`CRUCIHIL_API_KEY`) to be available — document that `setup.sh` must run before `dev.sh --rig`.

---

### L22 — `dev.sh` argument parsing: double-loop causes `--rig <path>` path to hit `*) die`

**What happened:** The script had both a `for arg in "$@"` loop (early detection of flags) and a `while [[ $# -gt 0 ]]` loop (main parsing). The `for` loop iterated over all positional args including the TOML path that follows `--rig`. The path didn't match any known flag, hitting `*) die "Unknown option: $arg"`.

**Fix:** Deleted the entire `for` loop. The single `while [[ $# -gt 0 ]]` loop with `shift 2` for two-argument flags is the correct pattern.

**Rule:** Never mix `for arg in "$@"` and `while [[ $# -gt 0 ]]; do shift` in the same arg-parsing section. The `for` loop iterates all args regardless of `shift` calls. Use only the `while` + `shift` pattern for flags that consume the next argument.

---

### L23 — `local` in main script body fails under `set -e`; venv not in PATH for scripts

**What happened:** `dev.sh` had `local sentinel=".native_agent_${rig_name}.run"` at the top level of a `for` loop (not inside a function). `local` outside a function exits with code 1. However, the earlier `if ! command_exists crucihil; then continue; fi` check fired first because `dev.sh` runs in a shell that hasn't sourced the venv, so `crucihil` isn't in PATH. Native agents were silently skipped — no error shown, script kept running for Docker/dashboard sections.

**Fix:** (1) Removed `local` keyword from `sentinel=` assignment. (2) Replaced `command_exists crucihil` check with a two-step resolution: prefer `.venv/bin/crucihil` (relative to script dir), fall back to `crucihil` in PATH. Scripts run without an activated venv as long as the project venv is in the standard location.

**Rule:** Shell scripts that call project CLIs must resolve the binary from the project venv by absolute path (`.venv/bin/<cmd>`), not rely on PATH. PATH-based `command -v` fails silently when run without venv activation. Never use `local` outside a bash function — it's not just a style issue, it exits with code 1.
