# CruciHiL — Active Task Plan

## Phase 0 — Foundation ✅ COMPLETE

**Goal:** one real test running end-to-end against virtual simulation  
**Status:** All items shipped and verified. 98 tests passing.

### Completed items

- [x] HAL module structure + backend ABCs (`crucihil/hal/backends/base.py`)
- [x] Virtual backends: CAN, SOME/IP Events/Fields, DoIP, Power, GPIO (`crucihil/hal/backends/virtual/`)
- [x] BSE: DBC loader, Signal Store, Message Scheduler, Transport Router (`crucihil/hal/bse/`)
- [x] Exception hierarchy (`crucihil/hal/models/exceptions.py`)
- [x] Rig TOML config loader with Pydantic validation (`crucihil/hal/config/`)
- [x] Namespaces: `rig.can`, `rig.sim`, `rig.fault` (`crucihil/hal/namespaces/`)
- [x] Result models: `TestResult`, `ExpectResult`, `FaultDescriptor` (`crucihil/hal/models/results.py`)
- [x] Rig top-level fixture (`crucihil/hal/rig.py`)
- [x] Vehicle CAN DBC + virtual rig TOML (`defs/vehicle_can.dbc`, `rigs/virtual.toml`)
- [x] YAML v2 manifest schema + loader (`crucihil/agent/manifest/`)
- [x] Test runner: 6-step lifecycle, filtering, depends_on (`crucihil/agent/runner/`)
- [x] JUnit XML reporter (`crucihil/agent/reporter/junit.py`)
- [x] CLI: `crucihil run` + `crucihil version` (`crucihil/cli/main.py`)
- [x] Sample test suite + plain test functions (`tests/suites/`)
- [x] 98 unit + integration tests all passing

### Key architectural decisions locked in Phase 0

- FaultDescriptor pattern (R4) — fault methods return descriptors, not coroutines
- Signal Store built once from DBC at startup (R2) — never inside decode loop
- `frame_idx` monotonic int as CAN join key — never timestamp (R7)
- `base_dir = Path.cwd()` for DBC path resolution (project root, not TOML location)
- tomllib compat shim: `try: import tomllib / except ImportError: import tomli as tomllib`
- pytest-asyncio strict mode configured in `pyproject.toml`
- `requires-python = ">=3.10"` (running 3.10.12 in `.venv`)

---

## Phase 1 — MVP ✅ COMPLETE

**Goal:** one real engineer running real tests on real hardware  
**Status:** All items shipped. 129 tests passing (98 original + 31 new Phase 1 tests).

### Completed items

- [x] SocketCAN backend (`crucihil/hal/backends/socketcan/can.py`) — real CAN via Linux SocketCAN
  - Uses python-can with asyncio receive loop via `run_in_executor`
  - `block_arb_id` / `unblock_arb_id` for CAN dropout fault injection
- [x] PEAK CAN backend (`crucihil/hal/backends/peak/can.py`) — PCAN-USB adapters
  - Lazy import, fails gracefully with BackendError if pcan not installed
- [x] vsomeip wrapper backend (`crucihil/hal/backends/vsomeip/someip.py`)
  - Lazy import, fails gracefully if vsomeip bindings not installed
  - Events + Fields only (Methods deferred to Phase 2)
- [x] python-doip real backend (`crucihil/hal/backends/python_doip/doip.py`)
  - Uses `doipclient` library (lazy import, BackendError if not installed)
- [x] Backend registry updated — all real backends registered, custom module path support
  - Dotted `"module.path:ClassName"` syntax falls through to `importlib`
- [x] CAN dropout fault injection wired for all backends with `block_arb_id`
  - VirtualCANBackend and SocketCANBackend both support it
  - FaultNamespace detects `hasattr(backend, "block_arb_id")` — backend-agnostic
- [x] `rig.ecu` namespace with `flash()` via DoIP UDS 0x34/0x36/0x37
  - `crucihil/hal/namespaces/ecu.py` — ECUProxy + ECUNamespace
  - UDS RequestDownload / TransferData / RequestTransferExit sequence
  - `reset()` convenience method (0x11 ECUReset)
  - DoIP backends now connected at rig.connect() time (0x0E00 tester address)
- [x] HTML reporter (`crucihil/agent/reporter/html.py`)
  - Self-contained, zero external dependencies, all CSS/JS inlined
  - Pass rate badge, per-test expandable detail, sortable table
  - `crucihil run --html <path>` flag added to CLI
- [x] Local SQLite result cache (`crucihil/agent/cache/cache.py`)
  - SQLAlchemy ORM, 30-day pruning, write/query/close lifecycle
- [x] `crucihil agent start` command + `crucihil/agent/agent.py`
  - Persistent daemon — loads rig, opens cache, WebSocket client stub
  - Local-only mode when no `--cloud` URL given
- [x] `crucihil init` wizard (`crucihil/agent/init/wizard.py`)
  - Auto-detects CAN interfaces via `ip link show type can`
  - Prompts for Ethernet, power backend, DBC path
  - Validates generated TOML before writing
- [x] `[rig.udp]` + `[rig.uds]` TOML sections
  - Pydantic schema: `UDPInterfaceConfig`, `UDSConfig`
  - ABCs: `AbstractUDPBackend`, `AbstractUDSBackend` in `base.py`
  - Virtual stubs: `virtual/udp.py`, `virtual/uds.py`
  - Registry entries: `"virtual_udp"`, `"virtual_uds"`
- [x] JSON Schema for rig TOML + YAML manifest
  - `schemas/rig_config.schema.json` — generated from Pydantic RigConfig
  - `schemas/suite_manifest.schema.json` — hand-authored from dataclass spec
- [x] 31 new Phase 1 integration tests, all passing

### Phase 1 definition of done — status

- [ ] At least one real engineer (not the author) runs `crucihil run` against a physical ECU
- [x] SocketCAN, DoIP, and PEAK backends pass their own integration tests (mocked/simulated)
- [x] `crucihil agent start` connects to a stub cloud endpoint without crashing
- [x] SQLite cache writes a result row after every test
- [x] `crucihil init` produces a valid TOML that loads without ConfigurationError

---

## Phase 2 — Platform (Weeks 20–40)

**Goal:** web dashboard, cloud control plane, first paying customer.  
**Current status:** All tracks complete except first paid customer (394 tests).

### Step 1 — FastAPI control plane + PostgreSQL ✅ COMPLETE

- [x] `crucihil/server/config.py` — pydantic-settings (DATABASE_URL, SECRET_KEY, JWT params)
- [x] `crucihil/server/models/` — ORM models: RigRow, TestRunRow, TestResultRow
- [x] `crucihil/server/db/session.py` — engine factory, `set_engine`/`reset_engine` for tests
- [x] `alembic.ini` + `crucihil/server/db/migrations/versions/0001_initial.py`
- [x] `crucihil/server/services/auth.py` — API key hash (SHA-256), JWT (HS256)
- [x] `crucihil/server/services/result_sync.py` — upsert_run, batch_upsert (ON CONFLICT DO NOTHING), finalize_run
- [x] `crucihil/server/api/v1/` — auth, rigs, runs, results routers + router aggregator
- [x] `crucihil/server/api/ws/agent.py` — WS /ws/agent, agent_hello + result handlers
- [x] `crucihil/server/main.py` — FastAPI app factory with CORS and lifespan
- [x] 44 new tests (unit + integration) — SQLite StaticPool, no real PostgreSQL needed in CI
- [x] Total: 173 tests passing

### Step 2 — WebSocket agent ↔ cloud protocol ✅ COMPLETE

- [x] Replace WebSocket stub in `crucihil/agent/agent.py` with full protocol
  - JWT auth on connect: `POST /api/v1/auth/token` on startup, store token
  - Result streaming: `on_result()` callback sends `{"type": "result", ...}` after every test
  - Offline sync flush: on (re)connect, batch-POST SQLite cache via `/api/v1/results/sync`
  - JWT refresh: renew 5 min before expiry (background `_auth_loop` task)
  - Heartbeat: `{"type": "ping"}` every 30s (`_heartbeat_loop` task)
- [x] `crucihil/agent/cache/sync.py` — `flush_unsynced()` helper (reads cache, groups by run_id, POSTs, marks synced)
- [x] `crucihil/agent/cache/cache.py` — `synced_at` column, `query_unsynced()`, `mark_synced()`
- [x] `crucihil/hal/config/schema.py` — `CloudConfig` model, `cloud: CloudConfig | None` on `RigConfig`
- [x] `crucihil/agent/runner/runner.py` — `on_result` callback parameter on `run_suite()`
- [x] `crucihil/server/api/ws/agent.py` — `ping` handler updates `last_seen_at`
- [x] `crucihil/cli/main.py` — removed `--cloud` flag; cloud config comes from `[rig.cloud]` TOML section
- [x] 34 new tests (unit/agent + integration/agent) — 207 total passing

### Step 3 — MCP server ✅ COMPLETE

- [x] `crucihil/mcp/server.py` — FastMCP 3.x server, 11 tools registered, starts via `python -m crucihil.mcp.server`
- [x] `crucihil/mcp/client.py` — httpx async client with JWT cache + auto-refresh
- [x] `crucihil/mcp/tools/rigs.py` — `list_rigs`, `get_rig_config`
- [x] `crucihil/mcp/tools/runs.py` — `list_runs`, `get_run_summary`, `run_test_suite`, `cancel_run`
- [x] `crucihil/mcp/tools/results.py` — `get_results`, `get_signal_trace`, `describe_failure`
- [x] `crucihil/mcp/tools/signals.py` — `list_signals` (cantools DBC parse, local filesystem)
- [x] `crucihil/mcp/tools/suites.py` — `list_tests` (YAML manifest parse, local filesystem)
- [x] `crucihil/server/api/v1/runs.py` — added `POST /api/v1/runs` (create queued run + WS push)
- [x] `crucihil/server/api/ws/agent.py` — connection registry + `push_to_agent()` for server→agent push
- [x] 42 new tests — 249 total passing
- Config: `CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` env vars

### Step 4 — Docker Compose self-hosting stack ✅ COMPLETE

- [x] `Dockerfile.server` — multi-stage build (base: system+pip deps; app: crucihil/ + alembic.ini)
- [x] `Dockerfile.mcp` — same base; CMD: `python -m crucihil.mcp.server`
- [x] `Dockerfile.agent` — same base; CMD: `crucihil agent --rig /rigs/virtual.toml`
- [x] `docker-compose.yml` — db (postgres:16), server (port 8000), mcp (port 8001), agent (profile: agent)
- [x] `docker-compose.override.yml` — dev overrides: source mounts, uvicorn --reload, db port exposed
- [x] `.env.example` — all required vars documented
- [x] `crucihil/mcp/server.py` — `CRUCIHIL_MCP_TRANSPORT` env var: `stdio` (default) or `sse`
- [x] README self-hosting section — full bootstrap flow documented
- [x] All 249 tests still passing (no server code changes)

### Step 5 — React dashboard ✅ COMPLETE

- [x] `dashboard/` — React 18 + TypeScript strict + Vite 5; `vite build` passes zero TS errors
- [x] 7 pages: Login, Dashboard, Rigs, RigDetail, Runs, RunDetail, Settings
- [x] Auth: API key → JWT in localStorage; Axios interceptor + 401 redirect; session-expired banner
- [x] React Query polling: 15s on dashboard, 5s on active runs, stops on terminal status
- [x] `useRunStream` hook: WebSocket `/ws/viewer?token=…&run_id=…` for live results; silent fallback
- [x] `StatusBadge` (pass/fail/blocked/skip/queued/running with animations)
- [x] `RigOnlineIndicator` using `differenceInSeconds` against 90s threshold
- [x] Run cancellation button (calls `POST /api/v1/runs/{id}/cancel`)
- [x] Progress bar on RunDetailPage — live update via WS
- [x] Loading skeletons + error states on all pages
- [x] `Dockerfile.dashboard` + `docker-compose.override.yml` dashboard service
- [x] `dashboard/vercel.json` SPA routing config
- [x] `fly.server.toml` / `fly.mcp.toml` — Fly.io deployment configs
- [x] `.github/workflows/deploy.yml` — pytest → Fly deploy → Vercel auto-deploys
- [x] Server: `/ws/viewer` endpoint + `broadcast_result()` fan-out
- [x] `dev.sh` — starts backend via Docker + Vite HMR natively (Ctrl-C stops everything)
- [x] `setup.sh` — fixed to support both `docker compose` (v2) and `docker-compose` (v1)
- [x] All 249 tests still passing

### Step 6 — Customer readiness

#### Track D — Local virtual rig development ✅ COMPLETE (255 → 261 tests)

- [x] Agent: env var cloud config (`CRUCIHIL_BASE_URL` + `CRUCIHIL_API_KEY` override `[rig.cloud]` TOML)
- [x] Agent: `run_suite` WS command handler + `run_start`/`run_complete` lifecycle messages
- [x] Server WS: `run_start` → sets status=running; `run_complete` → calls finalize_run
- [x] `docker-compose.yml`: `CRUCIHIL_API_KEY` env var passed to agent service
- [x] `dev.sh`: `--agent` flag starts virtual rig agent alongside backend + dashboard
- [x] 6 new agent integration tests (255 → 261 passing)

#### Track A — RBAC + Rig Registration UI ✅ COMPLETE (261 → 278 tests)

- [x] Alembic migration 0002: `role` column on `rigs` table + `viewer_keys` table
- [x] `ViewerKeyRow` ORM model (`crucihil/server/models/viewer_key.py`)
- [x] `RigRow.role` column (default: `"admin"`)
- [x] `issue_jwt()` extended with `role` param; `generate_viewer_key()` added
- [x] `/api/v1/auth/token`: tries rig keys (role=rig.role), then viewer keys (role="viewer")
- [x] `deps.py`: shared `_decode_token` dep + `get_admin_rig` (403 if not admin)
- [x] `POST /api/v1/rigs`: dual auth (REGISTRATION_TOKEN OR admin JWT); new rig gets role="admin"
- [x] `DELETE /api/v1/rigs/{name}`: requires admin JWT; 204 No Content
- [x] `POST /api/v1/rigs/{name}/viewers`: create viewer key; returns key once
- [x] `DELETE /api/v1/rigs/{name}/viewers/{id}`: revoke viewer key
- [x] `POST /api/v1/runs`, `POST /api/v1/runs/{id}/cancel`: require admin JWT
- [x] Dashboard `AuthContext`: `role: 'admin' | 'viewer' | null` extracted from JWT
- [x] Dashboard `RigsPage`: "Register Rig" button + two-step modal (admin only)
- [x] Dashboard `RunDetailPage`: Cancel button gated on `role === 'admin'`
- [x] 23 RBAC integration tests — all green; TypeScript: zero errors
- [x] Total: 278 tests passing

#### Track B — `crucihil discover` CLI (AI-assisted rig setup) ✅ COMPLETE
- [x] `crucihil discover` command — probes interfaces, calls AI, generates TOML
- [x] TOML validation against RigConfig schema before write (warnings shown, write not blocked)
- [x] Markdown fence stripping on AI output (`_strip_fences`)
- [x] Gemini (gemini-2.0-flash) as third AI provider via `GOOGLE_API_KEY`
- [x] `--model` CLI flag to override default model per provider
- [x] Confirm-on-first-write via `typer.confirm()` (session token deferred to Phase 3)
- [x] CLI integration tests: validation, fence stripping, Gemini detection (379 tests total)

#### Track C — Production deployment ✅ COMPLETE
- [x] Fly.io + Vercel one-time setup
- [ ] First paid customer

#### Track E — User auth UX ✅ COMPLETE (379 → 394 tests)

- [x] `POST /api/v1/setup` — first-time org bootstrap endpoint (org name + admin email + password)
- [x] `SetupPage` at `/setup` — sign-up flow for new deployments; auto-logs in, redirects on 409
- [x] Git hash in dashboard sidebar — `VITE_GIT_HASH` env var, `execSync` with explicit repo-root cwd, `'dev'` fallback; injected in `dev.sh` and `docker-compose.override.yml`
- [x] Alembic migration 0004 — `password_reset_token_hash` + `password_reset_token_expires_at` on `users`
- [x] `generate_password_reset_token` / `hash_password_reset_token` in `services/auth.py`
- [x] `send_password_reset_email` in `services/email.py` (Resend when key present, stdout fallback)
- [x] `POST /api/v1/auth/forgot-password` — always 200, rate-limited 5/5 min, no email enumeration
- [x] `GET /api/v1/auth/password-reset/{token}` — validate token, return email (does not consume)
- [x] `POST /api/v1/auth/reset-password` — consume token, set new password, return user JWT
- [x] `ForgotPasswordPage` at `/forgot-password` — email form → success state; 429 surfaced
- [x] `ResetPasswordPage` at `/reset-password?token=…` — validates on mount, expired-link state, password+confirm, auto-redirect on success
- [x] "Forgot your password?" link on `LoginPage`
- [x] 12 new integration tests covering happy path, single-use token, expiry, enumeration resistance, rate limiting, JWT type

---

## Phase 3 — Intelligence (Weeks 40–72)

**Goal:** AI differentiation, enterprise readiness, $10k MRR.

- [x] `generate_test_suite` MCP tool — YAML suite + Python stubs from natural language
  - `context_items: list[str]` — accepts CAN signals, camera, GPS, power, fault scenarios, integration flows
  - AI-generated assertions when key available; silent fallback to static template
  - YAML entries auto-derived from AI function names
  - 5 new tests (17 total in test_tools_suites.py)
- [ ] AI failure analysis + coverage gap detection
- [ ] Pass/fail trend monitoring + regression alerting via MCP
- [ ] AI conversational fallback for rig setup (Level 3/4 graceful degradation)
- [ ] `crucihil discover` Path C — `crucihil discover` → AI generates TOML → confirm-on-first-write session tokens
- [ ] CANvas MCP integration (the flywheel)
- [ ] SOME/IP Methods
- [ ] dSPACE + NI adapters
- [ ] SSO, audit logs, on-premise option
- [ ] Kubernetes Helm chart
- [ ] First paid customer
