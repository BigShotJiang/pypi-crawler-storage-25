# CruciHiL — RBAC + Rig Registration UI Implementation Brief

## Your role

You are a principal/distinguished engineer implementing a production feature on a
real commercial product. Operate at that level throughout:

- Read every file before touching it. Understand what exists before adding anything.
- No half-measures. Write the full thing correctly the first time.
- Tests are not optional. Every new endpoint and every new code path gets a test.
- Zero regressions. The existing 333 tests must still pass when you are done.
- Verify before declaring done. Run the test suite. Check TypeScript. Confirm the
  feature works end-to-end in the browser.
- Prefer the elegant solution. If something feels like a hack, stop and redesign.
- When in doubt about a design decision, resolve it explicitly — don't paper over it.

Use **claude-opus-4-7** (model ID: `claude-opus-4-7`) for this task. It is the most
capable model and this feature touches auth, security, DB migrations, API design, and
frontend simultaneously.

---

## What you are building

**RBAC + Rig Registration UI** — Phase 2, Track A.

Today every JWT is equally privileged. A CI token that can read results can also cancel
runs or delete rigs. There is no way to give a read-only viewer access without also
giving them write access. Rig registration requires a raw `curl` command with a static
server secret. None of this is acceptable for a multi-team production tool.

This track adds two roles (`admin` / `viewer`), enforces them on write endpoints,
lets admins register rigs from the dashboard, and lets admins issue read-only viewer
keys for CI pipelines that should never be able to mutate state.

---

## Project context you must understand before writing a line

**Stack:** Python 3.11, FastAPI, SQLAlchemy 2.x (mapped_column style), Alembic,
PostgreSQL in prod / SQLite StaticPool in tests, React 18 + TypeScript strict + Vite 5,
Tailwind CSS, React Query v5, Axios.

**Working directory:** `/home/dparikh/workspace/crucihil`

**Activate the venv before running anything:**
```bash
source .venv/bin/activate
```

**Run tests:**
```bash
pytest tests/ -q                                          # full suite (333 baseline)
pytest tests/integration/server/test_rbac.py -v          # new RBAC tests
```

**TypeScript check:**
```bash
cd dashboard && npx tsc --noEmit
```

**Key existing patterns to reuse (read these files first):**

| File | What to learn from it |
|---|---|
| `crucihil/server/api/deps.py` | `get_current_rig` — the dep you are extending |
| `crucihil/server/services/auth.py` | `generate_api_key`, `hash_api_key`, `verify_api_key`, `issue_jwt` — all reusable |
| `crucihil/server/api/v1/rigs.py` | `verify_registration_token`, `_to_detail`, `RigDetail` — extend, don't rewrite |
| `crucihil/server/api/v1/auth.py` | The token endpoint you must extend to handle viewer keys |
| `crucihil/server/models/rig.py` | SQLAlchemy 2.x `Mapped` + `mapped_column` style — match exactly |
| `crucihil/server/db/migrations/versions/0001_initial.py` | Alembic migration style — match exactly |
| `tests/integration/server/conftest.py` | `registered_rig`, `auth_headers`, `db_session` fixtures |
| `tests/integration/server/test_runs_api.py` | Integration test pattern — test against real SQLite |
| `dashboard/src/contexts/AuthContext.tsx` | `isExpired()` JWT parse — extend to also extract `role` |
| `dashboard/src/pages/RigsPage.tsx` | `RegisterRigModal` already exists — update it, don't rewrite |
| `dashboard/src/pages/RunDetailPage.tsx` | Cancel button location — wrap with role check |

**Critical constraint:** The test database is SQLite (StaticPool in-memory). Alembic
migrations do NOT run in tests — `Base.metadata.create_all(engine)` does. That means
the new `role` column on `RigRow` and the new `viewer_keys` table must appear in the
ORM models (so `create_all` picks them up), and the Alembic migration is for production
PostgreSQL only. Do NOT try to run migrations in test setup.

---

## Exact specification

### 1. Database migration — `crucihil/server/db/migrations/versions/0002_rig_role.py`

```python
revision = "0002"
down_revision = "0001"

def upgrade():
    op.add_column("rigs", sa.Column("role", sa.String(16),
                  nullable=False, server_default="admin"))
    op.create_table(
        "viewer_keys",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("rig_id", sa.String(36),
                  sa.ForeignKey("rigs.id"), nullable=False),
        sa.Column("name", sa.String(256), nullable=False),
        sa.Column("api_key_hash", sa.Text, nullable=False),
        sa.Column("created_at", sa.Float, nullable=False),
        sa.Column("revoked", sa.Boolean,
                  nullable=False, server_default="false"),
    )

def downgrade():
    op.drop_table("viewer_keys")
    op.drop_column("rigs", "role")
```

### 2. New ORM model — `crucihil/server/models/viewer_key.py`

Match the SQLAlchemy 2.x mapped_column style from `rig.py` exactly.
Fields: `id` (Integer PK autoincrement), `rig_id` (String(36), FK rigs.id),
`name` (String(256)), `api_key_hash` (Text), `created_at` (Float, default=time.time),
`revoked` (Boolean, default=False).

Import `ViewerKeyRow` in `crucihil/server/main.py` alongside `RigRow` and `TestRunRow`
so Alembic's autogenerate and `create_all` both see it.

### 3. RigRow — add `role` column

In `crucihil/server/models/rig.py`, add:
```python
role: Mapped[str] = mapped_column(String(16), nullable=False, default="admin")
```

### 4. Auth service extensions — `crucihil/server/services/auth.py`

Extend `issue_jwt(rig_name, rig_id, role="admin")` — add `role` to the payload.
Existing callers pass no `role` arg and get `"admin"` by default. Do not break them.

Add `generate_viewer_key() -> str`:
```python
def generate_viewer_key() -> str:
    return "crucihil-viewer-" + secrets.token_hex(24)
```

Reuse existing `hash_api_key()` and `verify_api_key()` for viewer keys — the hashing
logic is identical.

### 5. Token endpoint — `crucihil/server/api/v1/auth.py`

`POST /api/v1/auth/token` currently only looks up rig API keys. Extend it to:

1. Check the submitted key against `rigs.api_key_hash` — if match, issue JWT with
   `role=rig.role` (will be "admin" for all existing rigs).
2. If no rig match, check `viewer_keys` (where `revoked=False`) against
   `viewer_key.api_key_hash` — if match, issue JWT with `role="viewer"`,
   `sub=rig.name`, `rig_id=rig.id` (from the viewer key's `rig_id`).
3. If neither matches → 401.

The JWT payload shape does not change for rig keys — only `role` is added.

### 6. Dependency refactor — `crucihil/server/api/deps.py`

Current `get_current_rig` decodes the JWT and fetches the rig in one function.
Refactor to a shared private dep so `role` is available without decoding twice:

```python
def _decode_token(credentials: Annotated[HTTPAuthorizationCredentials,
                  Depends(HTTPBearer())]) -> dict:
    try:
        return decode_jwt(credentials.credentials)
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

def get_current_rig(
    payload: Annotated[dict, Depends(_decode_token)],
    db: Annotated[Session, Depends(get_db)],
) -> RigRow:
    rig = db.get(RigRow, payload.get("rig_id"))
    if rig is None:
        raise HTTPException(status_code=401, detail="Rig not found")
    return rig

def get_admin_rig(
    payload: Annotated[dict, Depends(_decode_token)],
    rig: Annotated[RigRow, Depends(get_current_rig)],
) -> RigRow:
    if payload.get("role", "viewer") != "admin":
        raise HTTPException(status_code=403, detail="Admin role required")
    return rig
```

`get_current_rig` remains on all read endpoints (GET). `get_admin_rig` replaces it
on write endpoints.

### 7. Rigs API — `crucihil/server/api/v1/rigs.py`

**POST /api/v1/rigs** — dual auth. Replace `verify_registration_token` with a new
`require_rig_create` dependency that accepts either:
- `Authorization: Bearer <REGISTRATION_TOKEN>` (static server secret — setup.sh path)
- `Authorization: Bearer <admin-JWT>` (dashboard path)

Implementation hint: try `decode_jwt(token)` first; if it succeeds and role=="admin",
allow. Otherwise compare against `settings.registration_token`.

New rig always created with `role="admin"`. Response body must include `role` field.

**`RigDetail` Pydantic model** — add `role: str`.

**`_to_detail(rig)`** — include `role: rig.role`.

**New: DELETE /api/v1/rigs/{rig_name}** — `Depends(get_admin_rig)`, 204 No Content.
Deletes by `name` (not id). Returns 404 if not found.

**New: POST /api/v1/rigs/{rig_name}/viewers** — `Depends(get_admin_rig)`.
- Body: `{"name": "ci-readonly"}`
- Generates viewer key, stores hash in `viewer_keys`
- Returns 201: `{"viewer_id": int, "name": str, "viewer_key": str, "role": "viewer"}`
- The raw key is shown once only — never retrievable again.

**New: DELETE /api/v1/rigs/{rig_name}/viewers/{viewer_id}** — `Depends(get_admin_rig)`.
Sets `revoked=True`. Returns 204.

### 8. Runs API — `crucihil/server/api/v1/runs.py`

- `POST /api/v1/runs` → change `Depends(get_current_rig)` to `Depends(get_admin_rig)`
- `POST /api/v1/runs/{run_id}/cancel` → same change

Read endpoints (GET) stay on `get_current_rig` — viewers can read.

### 9. Dashboard: AuthContext — `dashboard/src/contexts/AuthContext.tsx`

The file already has `isExpired(token)` which parses the JWT payload with
`JSON.parse(atob(token.split('.')[1]))`. Extend the same pattern:

```typescript
function getRole(token: string): 'admin' | 'viewer' | null {
  try {
    const payload = JSON.parse(atob(token.split('.')[1])) as { role?: string }
    return payload.role === 'admin' ? 'admin'
         : payload.role === 'viewer' ? 'viewer'
         : null
  } catch { return null }
}
```

Add `role: 'admin' | 'viewer' | null` to the context value interface and provider.
Compute it from the stored token the same way `isAuthenticated` is computed.

### 10. Dashboard: types — `dashboard/src/types/api.ts`

Add `role: string` to `RigDetail`.

### 11. Dashboard: RigsPage — `dashboard/src/pages/RigsPage.tsx`

A `RegisterRigModal` component already exists in this file. It currently calls
`api.post('/api/v1/rigs', { name })` and shows the API key on success.
The modal is already wired to the "Register Rig" button.

Changes needed:
- Import `useAuth` and read `role` from it.
- Gate the "Register Rig" button: only render it when `role === 'admin'`.
- The existing modal logic (two-step: form → key shown) is already correct — do not
  rewrite it, just verify it works with the new server response shape.

### 12. Dashboard: RunDetailPage — `dashboard/src/pages/RunDetailPage.tsx`

Import `useAuth`, destructure `role`. Find the Cancel button and wrap it:
```tsx
{role === 'admin' && run.status === 'running' && (
  <button onClick={handleCancel} ...>Cancel</button>
)}
```

---

## Tests — `tests/integration/server/test_rbac.py`

Write ≥17 tests. Use the existing `conftest.py` fixtures (`client`, `registered_rig`,
`auth_headers`, `db_session`). Study `test_runs_api.py` for the fixture patterns.

You will need a helper fixture that creates a viewer key for a rig and returns both
the raw key and a token obtained by POSTing it to `/api/v1/auth/token`.

Required test cases:

```
# Read access — both roles
test_admin_can_get_rigs
test_admin_can_get_runs
test_viewer_can_get_rigs
test_viewer_can_get_runs

# Write access — admin only
test_admin_can_post_run
test_admin_can_cancel_run          # seed a running run first
test_admin_can_delete_rig
test_admin_can_create_rig_with_jwt # POST /rigs with admin JWT (not reg token)

# Write access — viewer blocked
test_viewer_blocked_post_run       # 403
test_viewer_blocked_cancel_run     # 403
test_viewer_blocked_delete_rig     # 403
test_viewer_blocked_create_rig     # 403

# Viewer key lifecycle
test_viewer_key_auth_works         # POST /auth/token with viewer key → 200
test_viewer_key_revoke             # DELETE viewers/:id → 204, then token → 401
test_new_rig_has_admin_role        # registered rig.role == "admin"
test_registration_token_still_works # REGISTRATION_TOKEN → POST /rigs → 201
test_viewer_key_in_jwt             # viewer JWT payload has role=="viewer"
```

---

## Commit strategy

Make 4 logical commits in this order:

1. `feat(server): RBAC migration, ViewerKeyRow model, role on RigRow`
   — files: migration 0002, viewer_key.py, rig.py, main.py

2. `feat(server): admin/viewer roles on auth, deps, rigs, and runs endpoints`
   — files: auth.py (service), deps.py, api/v1/auth.py, rigs.py, runs.py

3. `feat(dashboard): role in AuthContext, admin-only Register Rig and Cancel buttons`
   — files: AuthContext.tsx, types/api.ts, RigsPage.tsx, RunDetailPage.tsx

4. `test(server): RBAC integration tests — ≥17 cases`
   — files: test_rbac.py

---

## Verification checklist — do not declare done until all pass

```bash
# 1. Full test suite — zero regressions, ≥17 new RBAC tests
source .venv/bin/activate
pytest tests/ -q
pytest tests/integration/server/test_rbac.py -v

# 2. TypeScript — zero errors
cd dashboard && npx tsc --noEmit

# 3. Manual browser checks (./dev.sh to start stack)
#    a. Login with default-rig API key
#       → "Register Rig" button IS visible in RigsPage
#       → Cancel button IS visible on a running run
#
#    b. Create a viewer key:
#       POST /api/v1/rigs/default-rig/viewers {"name":"ci-viewer"}
#       Copy the viewer_key from the response
#
#    c. Login with the viewer key
#       → "Register Rig" button is NOT visible
#       → Cancel button is NOT visible
#
#    d. With viewer JWT, curl POST /api/v1/runs → 403
#
#    e. Revoke the viewer key:
#       DELETE /api/v1/rigs/default-rig/viewers/{id}
#       Then POST /api/v1/auth/token with the viewer key → 401
```

---

## What NOT to do

- Do not add a user/password system. API keys only.
- Do not add a superuser / platform-admin concept. The two roles are `admin` and
  `viewer`, scoped per rig. That is the entire role model.
- Do not change the JWT algorithm or expiry.
- Do not rename `get_current_rig` — existing callers that don't need admin access
  keep using it.
- Do not rewrite `RegisterRigModal` — it already exists and works. Only add the
  role gate on the button that opens it.
- Do not add UI for listing or revoking viewer keys in the dashboard (that is Phase 3).
  The revoke endpoint just needs to exist and be tested.
