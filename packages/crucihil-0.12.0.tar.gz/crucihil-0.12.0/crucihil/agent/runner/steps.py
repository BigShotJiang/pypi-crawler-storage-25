"""Execute declarative YAML setup/teardown steps against a live Rig.

Actions supported:

    sim.set        { signal: "Msg.Sig", value: 0.0 }
    sim.start      EngineData           (string arg → target)
    sim.stop       EngineData
    sim.start_all  (no args)
    power.on       ecu_main             (string arg → target)
    power.off      ecu_main
    gpio.set       { pin: ignition_enable, value: true }

Unknown actions raise ValueError — caught by the runner and marked as blocked.
"""

from __future__ import annotations

from crucihil.agent.manifest.schema import SetupStep
from crucihil.hal.rig import Rig


async def execute_step(rig: Rig, step: SetupStep) -> None:
    """Execute one declarative setup/teardown step.

    Raises:
        ValueError: If the action is unknown.
        KeyError:   If a referenced signal or resource doesn't exist.
    """
    action = step.action
    p = step.params

    if action == "sim.set":
        await rig.sim.set(p["signal"], p["value"])

    elif action == "sim.start":
        rig.sim.start(p["target"])

    elif action == "sim.stop":
        rig.sim.stop(p["target"])

    elif action == "sim.start_all":
        rig.sim.start_all()

    elif action == "power.on":
        rail = p["target"]
        backend = rig._power_backends.get(rail)
        if backend is None:
            raise KeyError(f"Power rail '{rail}' not in rig config")
        await backend.on()

    elif action == "power.off":
        rail = p["target"]
        backend = rig._power_backends.get(rail)
        if backend is None:
            raise KeyError(f"Power rail '{rail}' not in rig config")
        await backend.off()

    elif action == "gpio.set":
        pin = p["pin"]
        value = bool(p["value"])
        for backend in rig._gpio_backends.values():
            if hasattr(backend, "_pins") and pin in getattr(backend, "_pins", {}):
                await backend.set(pin, value)
                return
        raise KeyError(f"GPIO pin '{pin}' not found in any backend")

    else:
        raise ValueError(f"Unknown step action: '{action}'")


__all__ = ["execute_step"]
