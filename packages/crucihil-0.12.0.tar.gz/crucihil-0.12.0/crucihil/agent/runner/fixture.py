"""Dynamic import of test functions from module paths.

Test functions declared in YAML are resolved here:
    module: tests.engine
    function: test_engine_startup

They must be plain async callables with signature:
    async def test_engine_startup(rig: Rig, **kwargs) -> None: ...

They raise AssertionError on failure, BlockedError on precondition failure,
and any other exception is treated as an infrastructure error.
"""

from __future__ import annotations

import importlib
from typing import Callable

from crucihil.hal.models.exceptions import ConfigurationError


def import_test_function(module_path: str, function_name: str) -> Callable:
    """Import and return the callable at module_path.function_name.

    Args:
        module_path:   Python dotted module path, e.g. "tests.engine"
        function_name: Name of the callable in that module.

    Raises:
        ConfigurationError: If the module can't be imported or the function
                            doesn't exist.
    """
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        raise ConfigurationError(
            f"Cannot import test module '{module_path}': {exc}"
        ) from exc

    if not hasattr(module, function_name):
        raise ConfigurationError(
            f"Module '{module_path}' has no function '{function_name}'"
        )

    fn = getattr(module, function_name)
    if not callable(fn):
        raise ConfigurationError(
            f"'{module_path}.{function_name}' is not callable"
        )
    return fn


__all__ = ["import_test_function"]
