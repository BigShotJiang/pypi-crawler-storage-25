"""Test suite execution engine — Layer 3 core.

Lifecycle per test (guaranteed ordering):
    1. FILTER   — enabled, hw_variants, suite_types, tags, depends_on
    2. SETUP    — declarative YAML steps; failure → blocked (not fail)
    3. EXECUTE  — call module.function(rig, **params) with timeout
    4. TEARDOWN — always runs, even if setup or execute raised (R8)
    5. RECORD   — write TestResult

Status semantics (load-bearing — see results.py):
    pass    — all assertions passed
    fail    — AssertionError from test function
    blocked — precondition / setup failed (rig sick, not firmware)
    error   — unexpected exception from framework or test infra
    skip    — filtered out before execution
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import Any

from crucihil.agent.manifest.schema import TestSpec, TestSuite
from crucihil.agent.runner.fixture import import_test_function
from crucihil.agent.runner.steps import execute_step
from crucihil.hal.models.exceptions import BlockedError, ConfigurationError
from crucihil.hal.models.results import TestResult
from crucihil.hal.rig import Rig

_log = logging.getLogger(__name__)


async def run_suite(
    suite: TestSuite,
    rig: Rig,
    *,
    run_id: str | None = None,
    filter_tags: set[str] | None = None,
    filter_suite_types: set[str] | None = None,
    on_result: Callable[[TestResult], Awaitable[None]] | None = None,
) -> list[TestResult]:
    """Execute all tests in a suite and return their results.

    Args:
        suite:              Loaded and validated TestSuite.
        rig:                Connected Rig (caller is responsible for connect/disconnect).
        run_id:             Unique run identifier. Generated if not provided.
        filter_tags:        Only run tests whose tags overlap this set.
        filter_suite_types: Only run tests whose suite_types overlap this set.

    Returns:
        One TestResult per test in suite order (including skipped tests).
    """
    run_id = run_id or str(uuid.uuid4())
    results: list[TestResult] = []
    passed_ids: set[str] = set()
    failed_ids: set[str] = set()

    for spec in suite.tests:
        result = await _run_one(
            spec,
            suite,
            rig,
            run_id=run_id,
            passed_ids=passed_ids,
            failed_ids=failed_ids,
            filter_tags=filter_tags,
            filter_suite_types=filter_suite_types,
        )
        results.append(result)
        if on_result is not None:
            await on_result(result)

        if result.status == "pass":
            passed_ids.add(spec.id)
        elif result.status in ("fail", "error", "blocked"):
            failed_ids.add(spec.id)

    return results


async def _run_one(
    spec: TestSpec,
    suite: TestSuite,
    rig: Rig,
    *,
    run_id: str,
    passed_ids: set[str],
    failed_ids: set[str],
    filter_tags: set[str] | None,
    filter_suite_types: set[str] | None,
) -> TestResult:

    # ── 1. FILTER ──────────────────────────────────────────────────────────────

    skip_reason = _should_skip(spec, suite, rig, failed_ids, filter_tags, filter_suite_types)
    if skip_reason is not None:
        _log.info("[SKIP] %s — %s", spec.id, skip_reason)
        return _make_result(spec, suite, run_id, "skip", 0.0, logs=[f"skipped: {skip_reason}"])

    # ── 2–4. SETUP / EXECUTE / TEARDOWN ────────────────────────────────────────

    status = "pass"
    errors: list[str] = []
    logs: list[str] = []
    started_at = time.monotonic()

    # If no module+function, treat as a setup-only smoke test (no assertion step)
    fn: Any = None
    source_code: str | None = None
    if spec.module and spec.function:
        try:
            fn = import_test_function(spec.module, spec.function)
            try:
                source_code = inspect.getsource(fn)
            except OSError:
                pass
        except ConfigurationError as exc:
            return _make_result(
                spec, suite, run_id, "blocked", 0.0,
                errors=[str(exc)], logs=logs,
            )

    # SETUP
    for step in spec.setup:
        try:
            await execute_step(rig, step)
        except Exception as exc:
            _log.warning("[BLOCKED] %s setup step '%s' failed: %s", spec.id, step.action, exc)
            return _make_result(
                spec, suite, run_id, "blocked",
                time.monotonic() - started_at,
                errors=[f"setup '{step.action}' failed: {exc}"],
                logs=logs,
            )

    # EXECUTE (inside a try/finally so teardown always runs)
    try:
        if fn is not None:
            _log.info("[RUN ] %s", spec.id)
            try:
                await asyncio.wait_for(
                    fn(rig, **spec.params),
                    timeout=spec.timeout,
                )
            except asyncio.TimeoutError:
                status = "fail"
                errors.append(f"Timed out after {spec.timeout}s")
            except AssertionError as exc:
                status = "fail"
                errors.append(str(exc) or "AssertionError (no message)")
            except BlockedError as exc:
                status = "blocked"
                errors.append(str(exc))
            except Exception as exc:
                status = "error"
                errors.append(f"{type(exc).__name__}: {exc}")
        else:
            _log.info("[RUN ] %s (setup-only)", spec.id)

    finally:
        # TEARDOWN — R8: always runs, errors logged but status unchanged
        for step in spec.teardown:
            try:
                await execute_step(rig, step)
            except Exception as exc:
                logs.append(f"teardown '{step.action}' warning: {exc}")

    duration = time.monotonic() - started_at
    level = logging.INFO if status == "pass" else logging.WARNING
    _log.log(level, "[%-7s] %s (%.3fs)", status.upper(), spec.id, duration)

    return _make_result(spec, suite, run_id, status, duration, errors=errors, logs=logs, source_code=source_code)


def _should_skip(
    spec: TestSpec,
    suite: TestSuite,
    rig: Rig,
    failed_ids: set[str],
    filter_tags: set[str] | None,
    filter_suite_types: set[str] | None,
) -> str | None:
    """Return a skip reason string, or None if the test should run."""

    if not spec.enabled:
        return spec.skip_reason or "disabled"

    # hw_variants — empty list means "runs on any rig"
    effective_variants = spec.hw_variants or suite.defaults.hw_variants
    if effective_variants and rig.config.name not in effective_variants:
        return f"hw_variant '{rig.config.name}' not in {effective_variants}"

    # suite_types filter from CLI --suite-type flag
    if filter_suite_types:
        effective_types = spec.suite_types or suite.defaults.suite_types
        if not filter_suite_types.intersection(effective_types):
            return f"suite_type filter {filter_suite_types} not in {effective_types}"

    # tags filter from CLI --tags flag
    if filter_tags:
        if not filter_tags.intersection(spec.tags):
            return f"tag filter {filter_tags} not matched by {spec.tags}"

    # depends_on — skip if any dependency did not pass
    for dep in spec.depends_on:
        if dep in failed_ids:
            return f"depends_on '{dep}' failed"

    return None


def _make_result(
    spec: TestSpec,
    suite: TestSuite,
    run_id: str,
    status: str,
    duration: float,
    *,
    errors: list[str] | None = None,
    logs: list[str] | None = None,
    source_code: str | None = None,
) -> TestResult:
    now = time.time()
    meta: dict[str, Any] = {
        "tags": spec.tags,
        "priority": spec.priority,
        "requirements": spec.requirements,
        "ticket": spec.ticket,
        "hw_variants": spec.hw_variants,
        "suite_types": spec.suite_types,
        "module": spec.module,
        "function": spec.function,
        "params": spec.params,
    }
    if source_code is not None:
        meta["source_code"] = source_code
    return TestResult(
        test_id=spec.id,
        run_id=run_id,
        suite_name=suite.suite.name,
        status=status,  # type: ignore[arg-type]
        duration=duration,
        started_at=now - duration,
        completed_at=now,
        errors=errors or [],
        logs=logs or [],
        metadata=meta,
    )


__all__ = ["run_suite"]
