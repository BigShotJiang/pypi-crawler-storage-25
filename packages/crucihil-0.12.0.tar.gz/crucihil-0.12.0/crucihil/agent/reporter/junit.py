"""JUnit XML reporter for CruciHiL test results.

Produces output compatible with pytest's JUnit format — works with
GitHub Actions, Jenkins, GitLab CI, and any tool that consumes JUnit XML.

Schema: https://github.com/junit-team/junit5/blob/main/platform-tests/...
        (subset used here — enough for all major CI systems)
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Sequence

from crucihil.agent.manifest.schema import TestSuite
from crucihil.hal.models.results import TestResult


def write_junit_xml(
    results: Sequence[TestResult],
    suite: TestSuite,
    output_path: str | Path,
) -> None:
    """Write results to a JUnit XML file.

    Args:
        results:     Ordered list of TestResult (one per test in the suite).
        suite:       The suite that was run (for metadata).
        output_path: File path to write. Parent directory must exist.
    """
    output_path = Path(output_path)

    total = len(results)
    failures = sum(1 for r in results if r.status == "fail")
    errors = sum(1 for r in results if r.status == "error")
    skipped = sum(1 for r in results if r.status in ("skip",))
    blocked = sum(1 for r in results if r.status == "blocked")
    elapsed = sum(r.duration for r in results)

    root = ET.Element("testsuites")
    ts = ET.SubElement(root, "testsuite")
    ts.set("name", suite.suite.name)
    ts.set("tests", str(total))
    ts.set("failures", str(failures))
    ts.set("errors", str(errors))
    ts.set("skipped", str(skipped + blocked))
    ts.set("time", f"{elapsed:.3f}")
    ts.set("version", suite.suite.version)

    for result in results:
        tc = ET.SubElement(ts, "testcase")
        tc.set("name", result.test_id)
        tc.set("classname", suite.suite.name)
        tc.set("time", f"{result.duration:.3f}")

        if result.status == "skip":
            skip_el = ET.SubElement(tc, "skipped")
            msg = result.logs[0] if result.logs else "skipped"
            skip_el.set("message", msg)

        elif result.status == "blocked":
            skip_el = ET.SubElement(tc, "skipped")
            msg = result.errors[0] if result.errors else "blocked"
            skip_el.set("message", f"blocked: {msg}")

        elif result.status == "fail":
            fail_el = ET.SubElement(tc, "failure")
            msg = result.errors[0] if result.errors else "assertion failed"
            fail_el.set("message", msg)
            fail_el.text = "\n".join(result.errors)

        elif result.status == "error":
            err_el = ET.SubElement(tc, "error")
            msg = result.errors[0] if result.errors else "error"
            err_el.set("message", msg)
            err_el.text = "\n".join(result.errors)

        if result.logs:
            sys_out = ET.SubElement(tc, "system-out")
            sys_out.text = "\n".join(result.logs)

    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    output_path.write_bytes(
        b'<?xml version="1.0" encoding="utf-8"?>\n'
        + ET.tostring(root, encoding="unicode").encode("utf-8")
    )


def summary_line(results: Sequence[TestResult]) -> str:
    """Return a one-line summary string for CLI output."""
    total = len(results)
    counts = {s: 0 for s in ("pass", "fail", "blocked", "error", "skip")}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1

    parts = [f"{total} tests"]
    if counts["pass"]:
        parts.append(f"{counts['pass']} passed")
    if counts["fail"]:
        parts.append(f"{counts['fail']} failed")
    if counts["blocked"]:
        parts.append(f"{counts['blocked']} blocked")
    if counts["error"]:
        parts.append(f"{counts['error']} error")
    if counts["skip"]:
        parts.append(f"{counts['skip']} skipped")
    return "  ".join(parts)


__all__ = ["write_junit_xml", "summary_line"]
