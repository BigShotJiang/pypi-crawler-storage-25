"""Self-contained HTML reporter for CruciHiL test results.

Produces a single .html file with no external dependencies — all CSS and
JavaScript is inlined.  Suitable for emailing, archiving, and sharing.

Features:
  - Suite-level summary with pass rate badge
  - Per-test expandable detail (click to reveal errors and logs)
  - Status colour coding: pass=green, fail=red, blocked=amber, error=orange, skip=grey
  - Duration column sortable in the browser (JS sort)
  - Responsive layout — readable on any screen width
"""

from __future__ import annotations

import html as _html
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from crucihil.agent.manifest.schema import TestSuite
from crucihil.hal.models.results import TestResult

# ── Inline CSS ─────────────────────────────────────────────────────────────────

_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace;
       background: #f5f5f5; color: #222; font-size: 14px; }
header { background: #1a1a2e; color: #eee; padding: 20px 32px; }
header h1 { font-size: 22px; font-weight: 600; margin-bottom: 4px; }
header .meta { font-size: 12px; color: #aaa; }
.summary { display: flex; gap: 16px; padding: 20px 32px; flex-wrap: wrap; }
.badge { border-radius: 8px; padding: 12px 20px; min-width: 100px; text-align: center;
         box-shadow: 0 1px 3px rgba(0,0,0,.15); }
.badge .num { font-size: 28px; font-weight: 700; }
.badge .lbl { font-size: 11px; text-transform: uppercase; letter-spacing: 1px; margin-top: 2px; }
.pass-bg   { background: #d4edda; color: #155724; }
.fail-bg   { background: #f8d7da; color: #721c24; }
.blocked-bg{ background: #fff3cd; color: #856404; }
.error-bg  { background: #fde8cc; color: #7c3f00; }
.skip-bg   { background: #e2e3e5; color: #383d41; }
.total-bg  { background: #d1ecf1; color: #0c5460; }
table { width: 100%; border-collapse: collapse; margin: 0 32px; width: calc(100% - 64px); }
th { background: #2d2d44; color: #eee; padding: 10px 12px; text-align: left;
     font-size: 12px; text-transform: uppercase; letter-spacing: .5px; cursor: pointer; }
th:hover { background: #3d3d5a; }
td { padding: 9px 12px; border-bottom: 1px solid #e0e0e0; vertical-align: top; }
tr:hover td { background: #f0f0f8; }
.status { font-weight: 700; font-size: 11px; text-transform: uppercase;
          padding: 3px 8px; border-radius: 4px; display: inline-block; }
.s-pass   { background: #d4edda; color: #155724; }
.s-fail   { background: #f8d7da; color: #721c24; }
.s-blocked{ background: #fff3cd; color: #856404; }
.s-error  { background: #fde8cc; color: #7c3f00; }
.s-skip   { background: #e2e3e5; color: #383d41; }
.dur { font-family: monospace; color: #555; }
.detail { display: none; background: #1e1e2e; color: #cdd6f4; padding: 12px 16px;
          border-radius: 6px; margin-top: 6px; white-space: pre-wrap; font-family: monospace;
          font-size: 12px; max-height: 300px; overflow-y: auto; }
.expand-btn { cursor: pointer; color: #5e81ac; font-size: 11px; text-decoration: underline; }
footer { text-align: center; color: #aaa; font-size: 11px; padding: 24px; }
"""

# ── Inline JS ──────────────────────────────────────────────────────────────────

_JS = """
function toggleDetail(id) {
  var el = document.getElementById(id);
  el.style.display = el.style.display === 'block' ? 'none' : 'block';
}
function sortTable(col) {
  var table = document.getElementById('results');
  var rows = Array.from(table.querySelectorAll('tbody tr'));
  var asc = table.getAttribute('data-sort-col') === String(col) &&
            table.getAttribute('data-sort-dir') !== 'asc';
  rows.sort(function(a, b) {
    var av = a.cells[col].getAttribute('data-val') || a.cells[col].textContent;
    var bv = b.cells[col].getAttribute('data-val') || b.cells[col].textContent;
    var an = parseFloat(av), bn = parseFloat(bv);
    if (!isNaN(an) && !isNaN(bn)) return asc ? an - bn : bn - an;
    return asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });
  var tbody = table.querySelector('tbody');
  rows.forEach(function(r) { tbody.appendChild(r); });
  table.setAttribute('data-sort-col', col);
  table.setAttribute('data-sort-dir', asc ? 'asc' : 'desc');
}
"""


def write_html_report(
    results: Sequence[TestResult],
    suite: "TestSuite",
    output_path: str | Path,
) -> None:
    """Write a self-contained HTML report to output_path.

    Args:
        results:     Ordered list of TestResult.
        suite:       The suite that was run (for metadata).
        output_path: File path to write. Parent directory must exist.
    """
    output_path = Path(output_path)
    content = _render(results, suite)
    output_path.write_text(content, encoding="utf-8")


def _render(results: Sequence[TestResult], suite: "TestSuite") -> str:
    total = len(results)
    counts = {s: 0 for s in ("pass", "fail", "blocked", "error", "skip")}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1

    elapsed_total = sum(r.duration for r in results)
    generated_at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    pass_rate = (counts["pass"] / total * 100) if total else 0.0

    # ── Summary badges ─────────────────────────────────────────────────────────
    badges = "".join([
        _badge(str(total),          "Total",   "total"),
        _badge(str(counts["pass"]), "Passed",  "pass"),
        _badge(str(counts["fail"]), "Failed",  "fail"),
        _badge(str(counts["blocked"]), "Blocked", "blocked"),
        _badge(str(counts["error"]), "Error",  "error"),
        _badge(str(counts["skip"]), "Skipped", "skip"),
        _badge(f"{pass_rate:.0f}%", "Pass Rate", "pass" if pass_rate >= 100 else ("fail" if pass_rate < 80 else "blocked")),
    ])

    # ── Results table rows ─────────────────────────────────────────────────────
    rows_html = ""
    for idx, r in enumerate(results):
        status_cls = f"s-{r.status}"
        detail_id = f"d{idx}"
        has_detail = bool(r.errors or r.logs)

        detail_content = ""
        if r.errors:
            detail_content += "ERRORS:\n" + "\n".join(r.errors)
        if r.logs:
            if detail_content:
                detail_content += "\n\nLOGS:\n"
            else:
                detail_content += "LOGS:\n"
            detail_content += "\n".join(r.logs)

        expand_html = (
            f'<br><span class="expand-btn" onclick="toggleDetail(\'{detail_id}\')">'
            f"▶ details</span>"
            f'<div class="detail" id="{detail_id}">{_html.escape(detail_content)}</div>'
            if has_detail else ""
        )

        rows_html += (
            f"<tr>"
            f'<td>{_html.escape(r.test_id)}{expand_html}</td>'
            f'<td><span class="status {status_cls}">{r.status}</span></td>'
            f'<td class="dur" data-val="{r.duration:.4f}">{r.duration:.3f}s</td>'
            f'<td>{_html.escape(r.suite_name)}</td>'
            f"</tr>\n"
        )

    suite_version = getattr(suite.suite, "version", "?") if hasattr(suite, "suite") else "?"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CruciHiL — {_html.escape(suite.suite.name)}</title>
<style>{_CSS}</style>
</head>
<body>
<header>
  <h1>CruciHiL Test Report — {_html.escape(suite.suite.name)}</h1>
  <div class="meta">v{_html.escape(suite_version)} &nbsp;·&nbsp; Generated {generated_at} &nbsp;·&nbsp; {elapsed_total:.2f}s total</div>
</header>
<div class="summary">{badges}</div>
<table id="results">
  <thead>
    <tr>
      <th onclick="sortTable(0)">Test ID ⇅</th>
      <th onclick="sortTable(1)">Status ⇅</th>
      <th onclick="sortTable(2)">Duration ⇅</th>
      <th onclick="sortTable(3)">Suite ⇅</th>
    </tr>
  </thead>
  <tbody>
{rows_html}  </tbody>
</table>
<footer>CruciHiL · crucihil.io</footer>
<script>{_JS}</script>
</body>
</html>"""


def _badge(value: str, label: str, status: str) -> str:
    cls = f"{status}-bg"
    return (
        f'<div class="badge {cls}">'
        f'<div class="num">{_html.escape(value)}</div>'
        f'<div class="lbl">{_html.escape(label)}</div>'
        f"</div>"
    )


__all__ = ["write_html_report"]
