"""CruciHiL local agent daemon.

Lifecycle:
  1. Load rig TOML and connect to all backends.
  2. Open SQLite result cache.
  3. If [rig.cloud] is configured (or CRUCIHIL_BASE_URL + CRUCIHIL_API_KEY env vars):
       a. Obtain JWT via POST /api/v1/auth/token.
       b. Connect to WebSocket — send agent_hello, flush unsynced SQLite cache.
       c. Stream results as they complete.
       d. Refresh JWT 5 min before expiry (background).
       e. Send heartbeat ping every 30s.
  4. If no cloud config: run in local-only mode (cache writes only).
  5. Graceful shutdown on SIGINT / SIGTERM.

Cloud config priority (highest → lowest):
  1. CRUCIHIL_BASE_URL + CRUCIHIL_API_KEY environment variables
  2. [rig.cloud] section in the rig TOML
"""

from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
import os
import signal
import time
from pathlib import Path
from typing import Optional

import httpx

from crucihil.agent.cache.cache import ResultCache
from crucihil.agent.cache.sync import flush_unsynced
from crucihil.hal.config.schema import CloudConfig
from crucihil.hal.models.results import TestResult
from crucihil.hal.rig import Rig

_log = logging.getLogger(__name__)

_WS_RECONNECT_DELAY = 5.0


async def _resolve_api_key(cloud: "CloudConfig", rig_name: str) -> "CloudConfig":
    """Return cloud config with a valid api_key, registering on first boot if needed."""
    from crucihil.agent.credentials import load_api_key, save_api_key

    # 1. Already have a key in config — use it directly
    if cloud.api_key:
        return cloud

    # 2. Check local credentials store (persisted from a previous registration)
    stored = load_api_key(cloud.url, rig_name)
    if stored:
        _log.info("Loaded API key from credentials store for rig '%s'", rig_name)
        return cloud.model_copy(update={"api_key": stored})

    # 3. First boot — use registration_token to self-register
    if not cloud.registration_token:
        _log.warning(
            "No api_key or registration_token in [rig.cloud] — running without cloud"
        )
        return cloud

    _log.info("First boot: registering rig '%s' with %s …", rig_name, cloud.url)
    async with httpx.AsyncClient(timeout=15.0) as http:
        resp = await http.post(
            f"{cloud.url}/api/v1/rigs",
            json={"name": rig_name, "role": "admin"},
            headers={"Authorization": f"Bearer {cloud.registration_token}"},
        )
        resp.raise_for_status()
        api_key: str = resp.json()["api_key"]

    save_api_key(cloud.url, rig_name, api_key)
    _log.info("Rig '%s' registered — API key saved locally", rig_name)
    return cloud.model_copy(update={"api_key": api_key})
_HEARTBEAT_INTERVAL = 30.0
_JWT_REFRESH_CHECK_INTERVAL = 60.0
_JWT_REFRESH_MARGIN = 300.0  # refresh 5 min before expiry


class LocalAgent:
    """Persistent daemon that manages rig connection, result storage, and cloud sync.

    Create via LocalAgent.create() then call await agent.run() to block until
    SIGINT/SIGTERM.
    """

    def __init__(
        self,
        rig: Rig,
        cache: ResultCache,
        cloud: Optional[CloudConfig],
    ) -> None:
        self._rig = rig
        self._cache = cache
        self._cloud = cloud

        self._token: Optional[str] = None
        self._token_expires_at: float = 0.0  # triggers immediate fetch on startup

        self._ws = None   # active websockets.WebSocketClientProtocol | None
        self._running = False

        # run_id → asyncio.Task for in-flight test runs
        self._active_runs: dict[str, asyncio.Task] = {}  # type: ignore[type-arg]

        self._http = httpx.AsyncClient(timeout=10.0)

    @classmethod
    async def create(
        cls,
        rig_path: Path,
        cache_path: Path,
    ) -> "LocalAgent":
        """Factory: load rig, open cache, return ready-to-run agent.

        Cloud config is resolved from (highest priority first):
          1. CRUCIHIL_BASE_URL + CRUCIHIL_API_KEY environment variables
          2. [rig.cloud] section in the rig TOML

        Raises:
            CruciHiLError: If the rig TOML is invalid or backends fail to connect.
        """
        rig = Rig.from_toml(rig_path)
        await rig.connect()
        _log.info("Rig '%s' connected", rig.config.name)

        # Env var override takes priority over TOML cloud section
        env_url = os.environ.get("CRUCIHIL_BASE_URL", "").strip()
        env_key = os.environ.get("CRUCIHIL_API_KEY", "").strip()
        if env_url and env_key:
            cloud: Optional[CloudConfig] = CloudConfig(url=env_url, api_key=env_key)
            _log.info("Cloud config from env vars: %s", env_url)
        else:
            cloud = rig.config.cloud

        if cloud is not None:
            cloud = await _resolve_api_key(cloud, rig.config.name)

        cache = ResultCache.open(cache_path)
        return cls(rig, cache, cloud)

    async def run(self) -> None:
        """Block until shutdown signal received."""
        self._running = True
        loop = asyncio.get_running_loop()

        _log.info(
            "Agent running — rig='%s'  cloud=%s",
            self._rig.config.name,
            self._cloud.url if self._cloud else "none (local-only mode)",
        )

        tasks: list[asyncio.Task] = []  # type: ignore[type-arg]
        if self._cloud:
            tasks = [
                asyncio.create_task(self._auth_loop(), name="auth"),
                asyncio.create_task(self._websocket_loop(), name="ws-client"),
                asyncio.create_task(self._heartbeat_loop(), name="heartbeat"),
            ]
        else:
            _log.info("No cloud config — running in local-only mode")

        def _stop() -> None:
            _log.info("Shutdown signal received — stopping agent")
            self._running = False
            for t in tasks:
                t.cancel()
            for task in list(self._active_runs.values()):
                task.cancel()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _stop)

        try:
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
            else:
                while self._running:
                    await asyncio.sleep(1.0)
        finally:
            await self._shutdown()

    # ── Result callback (passed to run_suite as on_result) ─────────────────────

    async def on_result(self, result: TestResult) -> None:
        """Called after each test completes: cache write + optional WS stream."""
        self._cache.write(result)

        if self._ws is not None:
            try:
                await self._ws.send(json.dumps({
                    "type": "result",
                    "run_id": result.run_id,
                    "result": dataclasses.asdict(result),
                }))
            except Exception as exc:
                _log.debug("WS result send failed (will sync on reconnect): %s", exc)

    # ── JWT auth ───────────────────────────────────────────────────────────────

    async def _auth_loop(self) -> None:
        """Periodically refresh the JWT — fires immediately on startup."""
        while self._running:
            if time.time() >= self._token_expires_at - _JWT_REFRESH_MARGIN:
                await self._refresh_token()
            await asyncio.sleep(_JWT_REFRESH_CHECK_INTERVAL)

    async def _refresh_token(self) -> None:
        assert self._cloud is not None
        try:
            resp = await self._http.post(
                f"{self._cloud.url}/api/v1/auth/token",
                json={"api_key": self._cloud.api_key},
            )
            resp.raise_for_status()
            data = resp.json()
            self._token = data["access_token"]
            self._token_expires_at = time.time() + data["expires_in"]
            _log.info("JWT obtained/refreshed (expires in %ds)", data["expires_in"])
        except Exception as exc:
            _log.warning("JWT refresh failed: %s — will retry in %ds", exc, int(_JWT_REFRESH_CHECK_INTERVAL))

    # ── WebSocket loop ─────────────────────────────────────────────────────────

    async def _websocket_loop(self) -> None:
        try:
            import websockets
        except ImportError:
            _log.warning("websockets not installed — cannot connect to cloud")
            return

        assert self._cloud is not None
        base = self._cloud.url.replace("https://", "wss://").replace("http://", "ws://")

        while self._running:
            # Wait until auth loop has obtained a token
            if not self._token:
                await asyncio.sleep(1.0)
                continue

            ws_url = f"{base}/ws/agent?token={self._token}"
            try:
                _log.info("Connecting to cloud: %s", ws_url)
                async with websockets.connect(  # type: ignore[attr-defined]
                    ws_url,
                    open_timeout=10,
                ) as ws:
                    self._ws = ws
                    _log.info("Cloud WebSocket connected")
                    await self._on_ws_connected(ws)
                    await self._handle_ws(ws)
            except Exception as exc:
                if self._running:
                    _log.warning(
                        "Cloud WebSocket disconnected: %s — retrying in %.0fs",
                        exc, _WS_RECONNECT_DELAY,
                    )
                    await asyncio.sleep(_WS_RECONNECT_DELAY)
            finally:
                self._ws = None

    async def _on_ws_connected(self, ws) -> None:
        """Run on every (re)connect: send hello, flush unsynced cache."""
        assert self._cloud is not None
        await ws.send(json.dumps({
            "type": "agent_hello",
            "rig": self._rig.config.name,
            "version": "0.1.0",
        }))
        synced = await flush_unsynced(
            self._cache,
            self._http,
            self._token,
            self._cloud.url,
            self._rig.config.name,
        )
        if synced:
            _log.info("Flushed %d unsynced results to cloud on connect", synced)

    async def _handle_ws(self, ws) -> None:
        """Process incoming messages from the cloud control plane."""
        async for raw in ws:
            if not self._running:
                break
            try:
                msg = json.loads(raw)
                msg_type = msg.get("type", "")
                _log.debug("WS message received: %s", msg_type)

                if msg_type == "run_suite":
                    await self._dispatch_run(msg)
                elif msg_type == "cancel_run":
                    self._cancel_run(msg.get("run_id", ""))
                else:
                    _log.debug("WS unhandled message type: %s", msg_type)

            except (json.JSONDecodeError, KeyError) as exc:
                _log.warning("Malformed WS message: %s", exc)

    # ── Run dispatch ───────────────────────────────────────────────────────────

    async def _dispatch_run(self, msg: dict) -> None:  # type: ignore[type-arg]
        """Spawn a background task to execute a test suite from a run_suite command."""
        run_id = msg.get("run_id", "")
        suite_path_str = msg.get("suite_path", "")
        if not run_id or not suite_path_str:
            _log.warning("run_suite message missing run_id or suite_path")
            return

        if run_id in self._active_runs:
            _log.warning("Run %s already active — ignoring duplicate", run_id)
            return

        suite_path = Path(suite_path_str)
        if not suite_path.is_absolute():
            suite_path = Path.cwd() / suite_path

        tags_list = msg.get("tags") or []
        filter_tags: set[str] | None = set(tags_list) if tags_list else None

        suite_type = msg.get("suite_type")
        filter_suite_types: set[str] | None = {suite_type} if suite_type else None

        _log.info("Dispatching run %s — suite=%s", run_id, suite_path)
        task = asyncio.create_task(
            self._execute_run(run_id, suite_path, filter_tags, filter_suite_types),
            name=f"run-{run_id}",
        )
        self._active_runs[run_id] = task
        task.add_done_callback(lambda _: self._active_runs.pop(run_id, None))

    def _cancel_run(self, run_id: str) -> None:
        """Cancel an in-flight run by run_id."""
        task = self._active_runs.get(run_id)
        if task is not None:
            _log.info("Cancelling run %s", run_id)
            task.cancel()
        else:
            _log.debug("cancel_run: run %s not found in active runs", run_id)

    async def _execute_run(
        self,
        run_id: str,
        suite_path: Path,
        filter_tags: set[str] | None,
        filter_suite_types: set[str] | None,
    ) -> None:
        """Load suite, execute it, stream results, notify server of lifecycle."""
        import sys
        from crucihil.agent.manifest.loader import load_suite
        from crucihil.agent.runner.runner import run_suite
        from crucihil.hal.models.exceptions import CruciHiLError

        # Add the suite's project root to sys.path so test modules can be
        # imported regardless of the agent's working directory.
        # Covers both flat layouts (suite at root) and the scaffold convention
        # where suites live in <root>/suites/ and tests in <root>/tests/.
        resolved = suite_path.resolve()
        for candidate in (resolved.parent.parent, resolved.parent):
            s = str(candidate)
            if s not in sys.path:
                sys.path.insert(0, s)

        # Load the suite manifest
        try:
            suite = load_suite(suite_path)
        except (CruciHiLError, FileNotFoundError, Exception) as exc:
            _log.error("Failed to load suite %s: %s", suite_path, exc)
            await self._send_run_error(run_id, str(exc))
            return

        # Notify server: run is starting
        await self._send_ws({
            "type": "run_start",
            "run_id": run_id,
            "suite_name": suite.suite.name,
            "started_at": time.time(),
        })

        completed_at = time.time()
        try:
            await run_suite(
                suite,
                self._rig,
                run_id=run_id,
                filter_tags=filter_tags,
                filter_suite_types=filter_suite_types,
                on_result=self.on_result,
            )
        except asyncio.CancelledError:
            _log.info("Run %s was cancelled", run_id)
        except Exception as exc:
            _log.error("Run %s raised unexpected error: %s", run_id, exc)
        finally:
            completed_at = time.time()

        # Notify server: run is complete (triggers finalize_run on server)
        await self._send_ws({
            "type": "run_complete",
            "run_id": run_id,
            "completed_at": completed_at,
        })
        _log.info("Run %s complete", run_id)

    async def _send_run_error(self, run_id: str, error: str) -> None:
        await self._send_ws({
            "type": "run_complete",
            "run_id": run_id,
            "completed_at": time.time(),
            "error": error,
        })

    async def _send_ws(self, msg: dict) -> None:  # type: ignore[type-arg]
        """Send a JSON message over the WebSocket if connected."""
        if self._ws is not None:
            try:
                await self._ws.send(json.dumps(msg))
            except Exception as exc:
                _log.debug("WS send failed: %s", exc)

    # ── Heartbeat ─────────────────────────────────────────────────────────────

    async def _heartbeat_loop(self) -> None:
        while self._running:
            await asyncio.sleep(_HEARTBEAT_INTERVAL)
            if self._ws is not None:
                try:
                    await self._ws.send(json.dumps({"type": "ping"}))
                    _log.debug("Heartbeat ping sent")
                except Exception as exc:
                    _log.debug("Heartbeat send failed: %s", exc)

    # ── Shutdown ──────────────────────────────────────────────────────────────

    async def _shutdown(self) -> None:
        _log.info("Disconnecting rig and closing cache")
        try:
            await self._http.aclose()
        except Exception as exc:
            _log.warning("HTTP client close error: %s", exc)
        try:
            await self._rig.disconnect()
        except Exception as exc:
            _log.warning("Rig disconnect error: %s", exc)
        try:
            self._cache.close()
        except Exception as exc:
            _log.warning("Cache close error: %s", exc)


__all__ = ["LocalAgent"]
