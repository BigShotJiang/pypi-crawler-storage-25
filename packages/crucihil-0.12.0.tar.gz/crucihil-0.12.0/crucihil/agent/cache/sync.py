"""Cloud sync helper — flushes unsynced SQLite results to the cloud REST API.

Called on every (re)connect so the cloud always has the full picture even if
the agent was offline for a while.  The server's ON CONFLICT DO NOTHING
guarantee makes replaying the full cache safe.
"""

from __future__ import annotations

import dataclasses
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import httpx
    from crucihil.agent.cache.cache import ResultCache

_log = logging.getLogger(__name__)


async def flush_unsynced(
    cache: "ResultCache",
    http: "httpx.AsyncClient",
    token: str,
    base_url: str,
    rig_name: str,
) -> int:
    """POST all unsynced SQLite rows to POST /api/v1/results/sync.

    Groups rows by run_id so each POST corresponds to one test run.
    Marks rows synced only after the server accepts them.

    Returns:
        Total number of result rows successfully synced.
    """
    unsynced = cache.query_unsynced()
    if not unsynced:
        return 0

    # Group by run_id preserving insertion order
    by_run: dict[str, list[tuple[int, object]]] = {}
    for row_id, result in unsynced:
        by_run.setdefault(result.run_id, []).append((row_id, result))

    total = 0
    headers = {"Authorization": f"Bearer {token}"}

    for run_id, items in by_run.items():
        row_ids = [i[0] for i in items]
        results = [i[1] for i in items]
        first = results[0]

        payload = {
            "run_id": run_id,
            "rig_name": rig_name,
            "suite_name": first.suite_name,
            "started_at": first.started_at,
            "triggered_by": "agent",
            "results": [dataclasses.asdict(r) for r in results],
        }

        try:
            resp = await http.post(
                f"{base_url}/api/v1/results/sync",
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
        except Exception as exc:
            _log.warning("Sync failed for run_id=%s: %s — will retry on next connect", run_id, exc)
            continue

        cache.mark_synced(row_ids)
        total += len(row_ids)
        _log.debug("Synced %d results for run_id=%s", len(row_ids), run_id)

    if total:
        _log.info("Sync flush complete: %d results synced", total)
    return total


__all__ = ["flush_unsynced"]
