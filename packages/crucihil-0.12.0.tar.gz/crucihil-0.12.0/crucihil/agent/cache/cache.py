"""Local SQLite result cache — writes TestResult rows after every test.

Schema mirrors the cloud PostgreSQL test_results table so that sync (Phase 2)
is a straight INSERT ... ON CONFLICT DO NOTHING against the remote.

30-day automatic pruning happens at cache open time — old rows are deleted
before any new rows are written.

Usage:
    cache = ResultCache.open("~/.crucihil/results.db")
    cache.write(result)
    recent = cache.query(limit=50)
    cache.close()
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Sequence

from sqlalchemy import (
    Column,
    Float,
    Index,
    Integer,
    String,
    Text,
    create_engine,
    delete,
    select,
    text,
    update,
)
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from crucihil.hal.models.results import TestResult

_log = logging.getLogger(__name__)

_RETENTION_DAYS = 30


# ── ORM model ──────────────────────────────────────────────────────────────────

class _Base(DeclarativeBase):
    pass


class _TestResultRow(_Base):
    __tablename__ = "test_results"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    test_id     = Column(String(256), nullable=False, index=True)
    run_id      = Column(String(64),  nullable=False, index=True)
    suite_name  = Column(String(256), nullable=False)
    status      = Column(String(16),  nullable=False)
    duration    = Column(Float,       nullable=False)
    started_at  = Column(Float,       nullable=False)
    completed_at= Column(Float,       nullable=False)
    errors      = Column(Text,        nullable=False, default="[]")
    logs        = Column(Text,        nullable=False, default="[]")
    signals     = Column(Text,        nullable=False, default="{}")
    extra_meta  = Column(Text,        nullable=False, default="{}")
    synced_at   = Column(Float,       nullable=True)

    __table_args__ = (
        Index("ix_test_results_started_at", "started_at"),
    )


# ── Public API ─────────────────────────────────────────────────────────────────

class ResultCache:
    """SQLite-backed result cache.  Thread-safe — SQLAlchemy manages connections."""

    def __init__(self, engine, session_factory) -> None:
        self._engine = engine
        self._Session = session_factory

    @classmethod
    def open(cls, db_path: str | Path = "~/.crucihil/results.db") -> "ResultCache":
        """Open (or create) the SQLite result cache at db_path.

        Creates the parent directory and schema if they do not exist.
        Prunes results older than 30 days on open.

        Args:
            db_path: Path to the SQLite file.  Tilde is expanded.
        """
        db_path = Path(db_path).expanduser().resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)

        engine = create_engine(
            f"sqlite:///{db_path}",
            connect_args={"check_same_thread": False},
        )
        _Base.metadata.create_all(engine)
        _migrate_schema(engine)

        factory = sessionmaker(bind=engine, expire_on_commit=False)
        cache = cls(engine, factory)
        cache._prune()
        _log.debug("ResultCache opened: %s", db_path)
        return cache

    def write(self, result: TestResult) -> None:
        """Persist a TestResult row.  Called after every test completes."""
        row = _TestResultRow(
            test_id     = result.test_id,
            run_id      = result.run_id,
            suite_name  = result.suite_name,
            status      = result.status,
            duration    = result.duration,
            started_at  = result.started_at,
            completed_at= result.completed_at,
            errors      = json.dumps(result.errors),
            logs        = json.dumps(result.logs),
            signals     = json.dumps(result.signals),
            extra_meta  = json.dumps(result.metadata),
        )
        with self._Session() as session:
            session.add(row)
            session.commit()
        _log.debug("Cached result: %s [%s]", result.test_id, result.status)

    def query(
        self,
        suite_name: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[TestResult]:
        """Return recent TestResult objects from the cache.

        Args:
            suite_name: Filter by suite name (exact match).
            status:     Filter by status (e.g. "fail").
            limit:      Maximum rows to return, most-recent-first.
        """
        with self._Session() as session:
            stmt = select(_TestResultRow).order_by(
                _TestResultRow.started_at.desc()
            )
            if suite_name:
                stmt = stmt.where(_TestResultRow.suite_name == suite_name)
            if status:
                stmt = stmt.where(_TestResultRow.status == status)
            stmt = stmt.limit(limit)
            rows = session.scalars(stmt).all()

        return [_row_to_result(r) for r in rows]

    def query_unsynced(self, limit: int = 1000) -> list[tuple[int, TestResult]]:
        """Return (row_id, TestResult) for all rows not yet synced to the cloud."""
        with self._Session() as session:
            stmt = (
                select(_TestResultRow)
                .where(_TestResultRow.synced_at.is_(None))
                .order_by(_TestResultRow.started_at.asc())
                .limit(limit)
            )
            rows = session.scalars(stmt).all()
        return [(r.id, _row_to_result(r)) for r in rows]

    def mark_synced(self, row_ids: list[int]) -> None:
        """Set synced_at = now for the given SQLite row IDs."""
        if not row_ids:
            return
        now = time.time()
        with self._Session() as session:
            session.execute(
                update(_TestResultRow)
                .where(_TestResultRow.id.in_(row_ids))
                .values(synced_at=now)
            )
            session.commit()
        _log.debug("Marked %d results as synced", len(row_ids))

    def close(self) -> None:
        """Dispose the connection pool."""
        self._engine.dispose()
        _log.debug("ResultCache closed")

    # ── Private helpers ────────────────────────────────────────────────────────

    def _prune(self) -> None:
        """Delete results older than RETENTION_DAYS."""
        cutoff = time.time() - _RETENTION_DAYS * 86400
        with self._Session() as session:
            deleted = session.execute(
                delete(_TestResultRow).where(_TestResultRow.started_at < cutoff)
            )
            if deleted.rowcount:
                _log.info("Pruned %d results older than %d days", deleted.rowcount, _RETENTION_DAYS)
            session.commit()


def _migrate_schema(engine) -> None:
    """Add columns introduced after initial schema creation (existing DBs)."""
    with engine.connect() as conn:
        try:
            conn.execute(text("ALTER TABLE test_results ADD COLUMN synced_at REAL"))
            conn.commit()
        except Exception:
            pass  # Column already exists


def _row_to_result(row: _TestResultRow) -> TestResult:
    return TestResult(
        test_id     = row.test_id,
        run_id      = row.run_id,
        suite_name  = row.suite_name,
        status      = row.status,        # type: ignore[arg-type]
        duration    = row.duration,
        started_at  = row.started_at,
        completed_at= row.completed_at,
        errors      = json.loads(row.errors or "[]"),
        logs        = json.loads(row.logs or "[]"),
        signals     = json.loads(row.signals or "{}"),
        metadata    = json.loads(row.extra_meta or "{}"),
    )


__all__ = ["ResultCache"]
