"""Data model for the CruciHiL YAML v2 suite manifest.

One YAML file = one TestSuite.  Fields are validated at load time (R9).

Schema mirrors the canonical example in docs/ARCHITECTURE.md.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class SetupStep:
    """One declarative step in a setup or teardown block.

    action: "sim.set" | "sim.start" | "sim.stop" | "sim.start_all"
            | "power.on" | "power.off" | "gpio.set"
    params: keyword args for the action, e.g. {"signal": "EngineData.RPM", "value": 0}
            Simple-arg actions use {"target": "<name>"}.
    """
    action: str
    params: dict[str, Any]


@dataclass
class FaultSpec:
    """One fault declaration in a test's `faults` block.

    fault_type: matches FaultDescriptor.fault_type ("can_dropout", etc.)
    params:     forwarded to rig.fault.<factory>(**params)
    """
    fault_type: str
    params: dict[str, Any]


@dataclass
class RecordSpec:
    """Signal recording config for a test."""
    signals: list[str] = field(default_factory=list)


@dataclass
class TestSpec:
    """A single test entry inside a suite."""

    id: str

    # Display
    name: str = ""
    description: str = ""

    # Targeting
    enabled: bool = True
    skip_reason: str | None = None
    hw_variants: list[str] = field(default_factory=list)
    suite_types: list[str] = field(default_factory=list)
    priority: Literal["critical", "high", "medium", "low"] = "medium"

    # Scheduling
    timeout: float = 30.0
    depends_on: list[str] = field(default_factory=list)
    repeat: int = 1

    # Traceability
    tags: list[str] = field(default_factory=list)
    requirements: list[str] = field(default_factory=list)
    ticket: str | None = None

    # Lifecycle steps
    setup: list[SetupStep] = field(default_factory=list)
    teardown: list[SetupStep] = field(default_factory=list)
    faults: list[FaultSpec] = field(default_factory=list)
    record: RecordSpec = field(default_factory=RecordSpec)

    # Python implementation
    module: str | None = None
    function: str | None = None
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class HardwareRequirements:
    """Hardware checked at runner startup (R9)."""
    required: list[str] = field(default_factory=list)
    optional: list[str] = field(default_factory=list)


@dataclass
class DefinitionsSpec:
    """DBC / descriptor files referenced in the suite."""
    can_dbc: str | None = None
    eth_dbc: str | None = None


@dataclass
class SuiteDefaults:
    """Default values inherited by every test unless overridden."""
    hw_variants: list[str] = field(default_factory=list)
    suite_types: list[str] = field(default_factory=lambda: ["regression"])
    timeout: float = 30.0
    retries: int = 0
    setup_timeout: float = 15.0
    enabled: bool = True


@dataclass
class SuiteMetadata:
    name: str
    version: str = "1.0.0"
    description: str = ""


@dataclass
class TestSuite:
    """Fully-validated in-memory representation of a crucihil_suite.yaml file."""
    suite: SuiteMetadata
    hardware: HardwareRequirements = field(default_factory=HardwareRequirements)
    definitions: DefinitionsSpec = field(default_factory=DefinitionsSpec)
    defaults: SuiteDefaults = field(default_factory=SuiteDefaults)
    tests: list[TestSpec] = field(default_factory=list)


__all__ = [
    "SetupStep",
    "FaultSpec",
    "RecordSpec",
    "TestSpec",
    "HardwareRequirements",
    "DefinitionsSpec",
    "SuiteDefaults",
    "SuiteMetadata",
    "TestSuite",
]
