"""Load and validate a CruciHiL YAML v2 suite manifest.

Validation happens here — before any hardware is touched (R9).
A ConfigurationError from this module marks the run as blocked, not fail.

YAML step format:
    - sim.set:   { signal: "EngineData.RPM", value: 0 }
    - sim.start: EngineData          # string arg → params={"target": "EngineData"}
    - power.on:  ecu_main
    - gpio.set:  { pin: ignition_enable, value: true }

YAML fault format:
    - can_dropout: { arb_id: 0x200, duration: 1.0 }
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from crucihil.hal.models.exceptions import ConfigurationError
from crucihil.agent.manifest.schema import (
    DefinitionsSpec,
    FaultSpec,
    HardwareRequirements,
    RecordSpec,
    SetupStep,
    SuiteDefaults,
    SuiteMetadata,
    TestSpec,
    TestSuite,
)


def load_suite(path: str | Path) -> TestSuite:
    """Load and validate a YAML suite manifest.

    Args:
        path: Path to the .yaml file.

    Returns:
        Fully-validated TestSuite.

    Raises:
        ConfigurationError: On missing file, parse error, or invalid schema.
    """
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"Suite manifest not found: {path}")

    try:
        raw = yaml.safe_load(path.read_text())
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"YAML parse error in {path}: {exc}") from exc

    if not isinstance(raw, dict):
        raise ConfigurationError(f"Suite manifest must be a YAML mapping: {path}")

    return _parse_suite(raw, path)


def _parse_suite(raw: dict[str, Any], path: Path) -> TestSuite:
    if "suite" not in raw:
        raise ConfigurationError(f"Missing required 'suite' key in {path}")

    suite_meta = _parse_suite_metadata(raw["suite"], path)
    hardware = _parse_hardware(raw.get("hardware", {}))
    definitions = _parse_definitions(raw.get("definitions", {}))
    defaults = _parse_defaults(raw.get("defaults", {}))

    raw_tests = raw.get("tests", [])
    if not isinstance(raw_tests, list):
        raise ConfigurationError(f"'tests' must be a list in {path}")

    tests = [_parse_test(t, defaults, i, path) for i, t in enumerate(raw_tests)]
    _validate_depends_on(tests, path)

    return TestSuite(
        suite=suite_meta,
        hardware=hardware,
        definitions=definitions,
        defaults=defaults,
        tests=tests,
    )


def _parse_suite_metadata(raw: Any, path: Path) -> SuiteMetadata:
    if not isinstance(raw, dict):
        raise ConfigurationError(f"'suite' must be a mapping in {path}")
    if "name" not in raw:
        raise ConfigurationError(f"'suite.name' is required in {path}")
    return SuiteMetadata(
        name=raw["name"],
        version=str(raw.get("version", "1.0.0")),
        description=str(raw.get("description", "")),
    )


def _parse_hardware(raw: Any) -> HardwareRequirements:
    if not isinstance(raw, dict):
        return HardwareRequirements()
    return HardwareRequirements(
        required=list(raw.get("required", [])),
        optional=list(raw.get("optional", [])),
    )


def _parse_definitions(raw: Any) -> DefinitionsSpec:
    if not isinstance(raw, dict):
        return DefinitionsSpec()
    return DefinitionsSpec(
        can_dbc=raw.get("can_dbc"),
        eth_dbc=raw.get("eth_dbc"),
    )


def _parse_defaults(raw: Any) -> SuiteDefaults:
    if not isinstance(raw, dict):
        return SuiteDefaults()
    return SuiteDefaults(
        hw_variants=list(raw.get("hw_variants", [])),
        suite_types=list(raw.get("suite_types", ["regression"])),
        timeout=float(raw.get("timeout", 30.0)),
        retries=int(raw.get("retries", 0)),
        setup_timeout=float(raw.get("setup_timeout", 15.0)),
        enabled=bool(raw.get("enabled", True)),
    )


def _parse_test(raw: Any, defaults: SuiteDefaults, idx: int, path: Path) -> TestSpec:
    if not isinstance(raw, dict):
        raise ConfigurationError(f"Test entry {idx} must be a mapping in {path}")
    if "id" not in raw:
        raise ConfigurationError(f"Test entry {idx} missing required 'id' field in {path}")

    test_id = raw["id"]

    # Fields with defaults inherited from suite defaults
    hw_variants = list(raw.get("hw_variants", defaults.hw_variants))
    suite_types = list(raw.get("suite_types", defaults.suite_types))
    timeout = float(raw.get("timeout", defaults.timeout))
    enabled = bool(raw.get("enabled", defaults.enabled))

    setup = _parse_steps(raw.get("setup", []), f"test '{test_id}' setup", path)
    teardown = _parse_steps(raw.get("teardown", []), f"test '{test_id}' teardown", path)
    faults = _parse_faults(raw.get("faults", []), test_id, path)

    record_raw = raw.get("record", {}) or {}
    record = RecordSpec(signals=list(record_raw.get("signals", [])))

    return TestSpec(
        id=test_id,
        name=str(raw.get("name", test_id)),
        description=str(raw.get("description", "")),
        enabled=enabled,
        skip_reason=raw.get("skip_reason"),
        hw_variants=hw_variants,
        suite_types=suite_types,
        priority=raw.get("priority", "medium"),
        timeout=timeout,
        depends_on=list(raw.get("depends_on", [])),
        repeat=int(raw.get("repeat", 1)),
        tags=list(raw.get("tags", [])),
        requirements=list(raw.get("requirements", [])),
        ticket=raw.get("ticket"),
        setup=setup,
        teardown=teardown,
        faults=faults,
        record=record,
        module=raw.get("module"),
        function=raw.get("function"),
        params=dict(raw.get("params", {})),
    )


def _parse_steps(raw: Any, context: str, path: Path) -> list[SetupStep]:
    if not isinstance(raw, list):
        raise ConfigurationError(f"'{context}' must be a list in {path}")
    steps = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict) or len(item) != 1:
            raise ConfigurationError(
                f"Step {i} in {context} must be a single-key mapping "
                f"like '- sim.set: {{...}}' (got {item!r}) in {path}"
            )
        action, args = next(iter(item.items()))
        if isinstance(args, str):
            params: dict[str, Any] = {"target": args}
        elif args is None:
            params = {}
        elif isinstance(args, dict):
            params = args
        else:
            raise ConfigurationError(
                f"Step '{action}' args must be a string or mapping, got {type(args).__name__} in {path}"
            )
        steps.append(SetupStep(action=action, params=params))
    return steps


def _parse_faults(raw: Any, test_id: str, path: Path) -> list[FaultSpec]:
    if not isinstance(raw, list):
        raise ConfigurationError(f"'faults' in test '{test_id}' must be a list in {path}")
    faults = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict) or len(item) != 1:
            raise ConfigurationError(
                f"Fault {i} in test '{test_id}' must be a single-key mapping "
                f"like '- can_dropout: {{...}}' (got {item!r}) in {path}"
            )
        fault_type, params = next(iter(item.items()))
        if params is None:
            params = {}
        elif not isinstance(params, dict):
            raise ConfigurationError(
                f"Fault '{fault_type}' params must be a mapping in test '{test_id}' in {path}"
            )
        faults.append(FaultSpec(fault_type=fault_type, params=params))
    return faults


def _validate_depends_on(tests: list[TestSpec], path: Path) -> None:
    ids = {t.id for t in tests}
    for test in tests:
        for dep in test.depends_on:
            if dep not in ids:
                raise ConfigurationError(
                    f"Test '{test.id}' depends_on '{dep}' which is not in the suite in {path}"
                )


__all__ = ["load_suite"]
