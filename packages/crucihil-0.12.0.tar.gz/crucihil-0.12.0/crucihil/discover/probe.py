"""Hardware discovery probes for 'crucihil discover'.

Probes the local system for CAN interfaces, USB adapters, Ethernet interfaces,
and installed Python packages relevant to HiL testing.  All probes are
best-effort: failures return empty lists, never raise.
"""

from __future__ import annotations

import importlib.metadata
import re
import subprocess
import sys
from dataclasses import dataclass, field

# USB vendor strings that identify known CAN/HiL adapters.
_USB_ADAPTER_PATTERNS: dict[str, str] = {
    "peak system":        "PEAK PCAN adapter (use backend=\"peak\")",
    "vector informatik":  "Vector CAN adapter",
    "kvaser":             "Kvaser CAN adapter",
    "ems wünsche":        "EMS CAN adapter",
    "ems wuensche":       "EMS CAN adapter",
    "national instruments": "NI-CAN adapter",
    "lawicel":            "Lawicel CANUSB adapter",
}

# Python packages relevant to CruciHiL backends.
_RELEVANT_PACKAGES = [
    "python-can",
    "cantools",
    "python-someip",
    "doipclient",
    "pcan",
]


@dataclass
class ProbeResult:
    platform: str = ""
    can_interfaces: list[str] = field(default_factory=list)
    usb_adapters: list[str] = field(default_factory=list)
    eth_interfaces: list[str] = field(default_factory=list)
    python_packages: list[str] = field(default_factory=list)

    def is_empty(self) -> bool:
        return not (self.can_interfaces or self.usb_adapters or self.eth_interfaces)

    def to_text(self) -> str:
        lines = [f"Platform: {self.platform}"]
        if self.can_interfaces:
            lines.append(f"CAN interfaces: {', '.join(self.can_interfaces)}")
        else:
            lines.append("CAN interfaces: none detected")
        if self.usb_adapters:
            lines.append(f"USB CAN adapters: {', '.join(self.usb_adapters)}")
        if self.eth_interfaces:
            lines.append(f"Ethernet interfaces: {', '.join(self.eth_interfaces)}")
        if self.python_packages:
            lines.append(f"Installed packages: {', '.join(self.python_packages)}")
        return "\n".join(lines)


def probe() -> ProbeResult:
    """Run all hardware probes and return a combined ProbeResult."""
    return ProbeResult(
        platform=_probe_platform(),
        can_interfaces=_probe_can(),
        usb_adapters=_probe_usb(),
        eth_interfaces=_probe_eth(),
        python_packages=_probe_packages(),
    )


# ── individual probes ──────────────────────────────────────────────────────────

def _probe_platform() -> str:
    import platform
    return f"{platform.system()} {platform.machine()}"


def _probe_can() -> list[str]:
    if sys.platform != "linux":
        return []
    try:
        out = subprocess.run(
            ["ip", "link", "show", "type", "can"],
            capture_output=True, text=True, timeout=2,
        ).stdout
        ifaces: list[str] = []
        for line in out.splitlines():
            m = re.match(r"^\d+:\s+(\S+?)[@:]", line)
            if m:
                ifaces.append(m.group(1))
        return ifaces
    except Exception:
        return []


def _probe_usb() -> list[str]:
    try:
        out = subprocess.run(
            ["lsusb"], capture_output=True, text=True, timeout=2,
        ).stdout
        found: list[str] = []
        lower = out.lower()
        for pattern, label in _USB_ADAPTER_PATTERNS.items():
            if pattern in lower and label not in found:
                found.append(label)
        return found
    except Exception:
        return []


def _probe_eth() -> list[str]:
    if sys.platform != "linux":
        return []
    try:
        out = subprocess.run(
            ["ip", "-br", "link", "show", "up"],
            capture_output=True, text=True, timeout=2,
        ).stdout
        ifaces: list[str] = []
        for line in out.splitlines():
            parts = line.split()
            if not parts:
                continue
            name = parts[0]
            if name != "lo" and not name.startswith("veth") and not name.startswith("docker"):
                ifaces.append(name)
        return ifaces
    except Exception:
        return []


def _probe_packages() -> list[str]:
    found: list[str] = []
    for pkg in _RELEVANT_PACKAGES:
        try:
            importlib.metadata.version(pkg)
            found.append(pkg)
        except importlib.metadata.PackageNotFoundError:
            pass
    return found
