"""Thin BYOK AI client for 'crucihil discover'.

Supports Anthropic (Claude) and OpenAI (GPT) via direct httpx calls.
No extra packages required — httpx is already a core CruciHiL dependency.
"""

from __future__ import annotations

import os

import httpx

_ANTHROPIC_MODEL = "claude-sonnet-4-6"
_OPENAI_MODEL = "gpt-4o"
_GEMINI_MODEL = "gemini-2.0-flash"

_SYSTEM_PROMPT = """\
You are a CruciHiL rig configuration expert. CruciHiL is a hardware-in-the-loop
testing platform for firmware teams.

Your task: generate a complete, valid CruciHiL rig TOML configuration.

── TOML SCHEMA (virtual rig reference — do NOT copy virtual backends verbatim) ──

[rig]
name         = "my_rig"        # identifier — letters/numbers/underscores only
platform     = "orin_nx"       # target hardware platform label
spec_version = "1.0"
backend      = "hardware"      # "hardware" for real HW, "virtual" for simulation

[rig.can.<key>]
interface = "can0"             # Linux interface name (can0, can1, vcan0, …)
bitrate   = 500000             # nominal bitrate in bps
fd        = false              # CAN-FD enabled?
backend   = "socketcan"        # "socketcan" | "peak" | "virtual"

[rig.ethernet.<key>]
interface      = "eth0"
ip             = "169.254.0.1"
someip_backend = "python-someip"
doip_backend   = "python-doip"

[rig.power.<key>]
backend = "virtual_power"      # "virtual_power" | "gpio_relay" | "bench_psu"
default = "on"

[rig.gpio]
# ignition_enable = { pin = 22, direction = "out", default = false, backend = "virtual_gpio" }

[rig.ecus.<key>]
name            = "Main_ECU"
logical_address = 0x0001       # DoIP logical address of the ECU
transport       = "doip"
doip_interface  = "eth0"       # key from [rig.ethernet]
boot_timeout    = 10.0         # seconds to wait for ECU boot

[rig.definitions]
can_dbc = "defs/vehicle_can.dbc"   # path relative to project root

── BACKEND SELECTION RULES ──
- CAN via SocketCAN (can0, can1, vcan0): backend = "socketcan"
- CAN via PEAK PCAN USB: backend = "peak"
- CAN via Vector adapter: backend = "socketcan" (uses PCAN/Vector kernel driver on Linux)
- Unknown CAN adapter: backend = "virtual" with # TODO: comment
- Ethernet DoIP: doip_backend = "python-doip"
- No DoIP hardware found: omit [rig.ecus] section
- No GPIO hardware found: leave [rig.gpio] section empty or omit it

── OUTPUT RULES ──
1. Output ONLY the TOML content — no markdown fences, no explanation, no preamble.
2. Start with a # comment line describing the rig.
3. Add # TODO: comments where a value needs manual verification by the user.
4. Use "hardware" backend in [rig] when real hardware is present; "virtual" when unsure.
5. The output must be syntactically valid TOML that passes a standard TOML parser.
6. Keep boot_timeout realistic: ~0.1s for virtual, ~8–30s for real embedded targets.
"""


class AIClient:
    """Minimal BYOK AI client — Anthropic or OpenAI, no extra dependencies."""

    def __init__(self, provider: str, api_key: str, model: str | None = None) -> None:
        self.provider = provider.lower()
        self.api_key = api_key
        if model:
            self.model = model
        elif self.provider == "anthropic":
            self.model = _ANTHROPIC_MODEL
        elif self.provider == "gemini":
            self.model = _GEMINI_MODEL
        else:
            self.model = _OPENAI_MODEL

    def complete(self, user_message: str) -> str:
        """Send a single-turn request and return the response text."""
        if self.provider == "anthropic":
            return self._call_anthropic(user_message)
        if self.provider == "gemini":
            return self._call_gemini(user_message)
        return self._call_openai(user_message)

    def _call_anthropic(self, user_message: str) -> str:
        resp = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": self.model,
                "max_tokens": 2048,
                "system": _SYSTEM_PROMPT,
                "messages": [{"role": "user", "content": user_message}],
            },
            timeout=60.0,
        )
        resp.raise_for_status()
        return resp.json()["content"][0]["text"].strip()

    def _call_gemini(self, user_message: str) -> str:
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model}:generateContent?key={self.api_key}"
        )
        resp = httpx.post(
            url,
            headers={"content-type": "application/json"},
            json={"contents": [{"parts": [{"text": f"{_SYSTEM_PROMPT}\n\n---\n\n{user_message}"}]}]},
            timeout=60.0,
        )
        resp.raise_for_status()
        return resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()

    def _call_openai(self, user_message: str) -> str:
        resp = httpx.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "content-type": "application/json",
            },
            json={
                "model": self.model,
                "max_tokens": 2048,
                "messages": [
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": user_message},
                ],
            },
            timeout=60.0,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()


def detect_provider() -> tuple[str, str] | None:
    """Return (provider, api_key) from environment variables, or None."""
    if key := os.environ.get("ANTHROPIC_API_KEY", ""):
        return ("anthropic", key)
    if key := os.environ.get("OPENAI_API_KEY", ""):
        return ("openai", key)
    if key := os.environ.get("GOOGLE_API_KEY", ""):
        return ("gemini", key)
    return None
