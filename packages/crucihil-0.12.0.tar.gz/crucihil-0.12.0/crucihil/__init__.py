"""CruciHiL — Hardware-in-the-Loop testing platform."""
