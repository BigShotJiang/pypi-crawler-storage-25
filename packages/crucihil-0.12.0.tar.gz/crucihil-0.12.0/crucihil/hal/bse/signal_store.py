"""Signal Store — single source of truth for live signal values.

Built once from the DBC database at startup (R2 — never inside the decode
loop).  Both the BSE and namespaces read/write through this object.

Signal naming convention: "MessageName.SignalName"
This key format works identically for CAN and SOME/IP signals (R1).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import cantools.database


@dataclass(frozen=True)
class SignalMeta:
    """Immutable metadata for one signal, extracted from the DBC at load time."""

    key: str            # "MessageName.SignalName"
    signal_name: str
    message_name: str
    arb_id: int
    unit: str | None
    min_val: float | None
    max_val: float | None
    initial: float
    transport: str      # "can" | "ethernet"


class SignalStore:
    """Thread-safe (asyncio-safe) store for signal metadata and live values.

    Lifecycle:
        store = SignalStore()
        store.build_from_dbc(db)   # called once by BusSimEngine at startup
        store.set("EngineRPM.n", 800.0)
        val = store.get("EngineRPM.n")
    """

    def __init__(self) -> None:
        self._meta: dict[str, SignalMeta] = {}
        self._values: dict[str, float] = {}

    # ── Build from DBC ─────────────────────────────────────────────────────────

    def build_from_dbc(
        self,
        db: "cantools.database.Database",
        transport: str = "can",
    ) -> None:
        """Populate signal metadata and initial values from a cantools Database.

        Must be called once per database, before any test code runs (R2).
        Idempotent — calling a second time with the same DB is a no-op for
        existing signals.

        Args:
            db:        Loaded cantools Database (from bse/loader.py).
            transport: "can" or "ethernet" label for all signals in this DB.
        """
        for msg in db.messages:
            for sig in msg.signals:
                key = f"{msg.name}.{sig.name}"
                if key in self._meta:
                    continue  # idempotent
                initial = float(sig.initial) if sig.initial is not None else 0.0
                self._meta[key] = SignalMeta(
                    key=key,
                    signal_name=sig.name,
                    message_name=msg.name,
                    arb_id=msg.frame_id,
                    unit=sig.unit or None,
                    min_val=float(sig.minimum) if sig.minimum is not None else None,
                    max_val=float(sig.maximum) if sig.maximum is not None else None,
                    initial=initial,
                    transport=transport,
                )
                self._values[key] = initial

    # ── Value access ───────────────────────────────────────────────────────────

    def get(self, signal: str) -> float:
        """Return the current value for a signal.

        Args:
            signal: "MessageName.SignalName"

        Raises:
            KeyError: If the signal is not registered.
        """
        try:
            return self._values[signal]
        except KeyError:
            raise KeyError(
                f"Unknown signal {signal!r}. "
                f"Known: {sorted(self._values)[:10]}{'...' if len(self._values) > 10 else ''}"
            ) from None

    def set(self, signal: str, value: float) -> None:
        """Update the live value for a signal.

        Args:
            signal: "MessageName.SignalName"
            value:  New value (in physical units, post-scaling).

        Raises:
            KeyError: If the signal is not registered.
        """
        if signal not in self._meta:
            raise KeyError(f"Unknown signal {signal!r}")
        self._values[signal] = value

    def meta(self, signal: str) -> SignalMeta:
        """Return metadata for a signal."""
        try:
            return self._meta[signal]
        except KeyError:
            raise KeyError(f"Unknown signal {signal!r}") from None

    # ── Batch access ───────────────────────────────────────────────────────────

    def signals_for_message(self, message_name: str) -> list[str]:
        """Return all signal keys belonging to a message."""
        return [k for k, m in self._meta.items() if m.message_name == message_name]

    def messages(self) -> set[str]:
        """Return all message names that have at least one signal registered."""
        return {m.message_name for m in self._meta.values()}

    def snapshot(self) -> dict[str, float]:
        """Return a shallow copy of all current values."""
        return dict(self._values)

    def update_from_decoded(self, message_name: str, decoded: dict[str, Any]) -> None:
        """Update signal values from a decoded CAN frame.

        Called by the CAN namespace listener after DBC decoding.

        Args:
            message_name: DBC message name.
            decoded:      {signal_name: physical_value} from cantools decode().
        """
        for sig_name, value in decoded.items():
            key = f"{message_name}.{sig_name}"
            if key in self._meta:
                self._values[key] = float(value)


__all__ = ["SignalStore", "SignalMeta"]
