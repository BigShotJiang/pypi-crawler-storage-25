"""Bus Simulation Engine — orchestrates DBC loading, signal state, and scheduling.

The engine is the single object the Rig creates and passes to the namespaces.
It owns:
  - The cantools Database (loaded once at connect time)
  - The SignalStore (signal values + metadata)
  - The MessageScheduler (periodic frame transmission per backend)
  - The MessageRouter (arb_id → backend dispatch)

Lifecycle:
    engine = BusSimEngine(config, can_backends)
    await engine.start()       # loads DBC, starts scheduled messages
    ...
    await engine.stop()        # cancels all tasks, cleans up
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from crucihil.hal.bse.loader import load_dbc
from crucihil.hal.bse.router import MessageRouter
from crucihil.hal.bse.scheduler import MessageScheduler
from crucihil.hal.bse.signal_store import SignalStore
from crucihil.hal.models.results import MessageStatus

if TYPE_CHECKING:
    import cantools.database
    from crucihil.hal.backends.base import AbstractCANBackend
    from crucihil.hal.config.schema import DefinitionsConfig

_log = logging.getLogger(__name__)


class BusSimEngine:
    """Lifecycle-managed BSE.  Created by the Rig, used by the namespaces."""

    def __init__(
        self,
        definitions: "DefinitionsConfig",
        can_backends: dict[str, "AbstractCANBackend"],
        *,
        base_dir: Path | str | None = None,
    ) -> None:
        """
        Args:
            definitions:  [rig.definitions] config section (DBC paths).
            can_backends: interface_name → AbstractCANBackend instances.
            base_dir:     Root directory for resolving relative DBC paths.
                          Defaults to Path.cwd() — i.e. the directory from
                          which `crucihil run` is invoked (the project root).
        """
        self._definitions = definitions
        self._can_backends = can_backends
        self._base_dir = Path(base_dir) if base_dir is not None else Path.cwd()

        self._db: "cantools.database.Database | None" = None
        self._signal_store = SignalStore()
        self._router: MessageRouter | None = None
        self._schedulers: dict[str, MessageScheduler] = {}  # interface → scheduler
        self._started = False

    # ── Public API ─────────────────────────────────────────────────────────────

    @property
    def signal_store(self) -> SignalStore:
        return self._signal_store

    @property
    def db(self) -> "cantools.database.Database | None":
        return self._db

    @property
    def router(self) -> MessageRouter:
        if self._router is None:
            raise RuntimeError("BusSimEngine not started — call await engine.start() first")
        return self._router

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Load DBC files, build signal store, and prepare schedulers.

        Does NOT start any periodic messages — call sim_start() per message
        (via rig.sim.start()) or start_all_cyclic() to auto-start everything.
        """
        if self._started:
            return

        if self._definitions.can_dbc:
            dbc_path = self._base_dir / self._definitions.can_dbc
            _log.info("BSE: loading DBC %s", dbc_path)
            self._db = load_dbc(dbc_path)
            self._signal_store.build_from_dbc(self._db, transport="can")
            _log.info(
                "BSE: loaded %d messages, %d signals",
                len(self._db.messages),
                sum(len(m.signals) for m in self._db.messages),
            )

        self._router = MessageRouter(self._can_backends, self._db)

        # Create one scheduler per CAN backend
        for iface, backend in self._can_backends.items():
            if self._db is not None:
                self._schedulers[iface] = MessageScheduler(
                    self._db, self._signal_store, backend
                )

        # Register a frame listener on every backend to decode incoming frames
        for backend in self._can_backends.values():
            backend.add_listener(self._on_frame)

        self._started = True

    async def stop(self) -> None:
        """Cancel all scheduled tasks and remove listeners.  Safe to call twice."""
        for sched in self._schedulers.values():
            await sched.stop_all()
        for backend in self._can_backends.values():
            backend.remove_listener(self._on_frame)
        self._started = False

    # ── Simulation control (called by rig.sim namespace) ──────────────────────

    def sim_start(self, message_name: str) -> None:
        """Start periodic transmission of a specific DBC message."""
        for sched in self._schedulers.values():
            sched.start(message_name)

    def sim_stop(self, message_name: str) -> None:
        """Stop periodic transmission of a specific DBC message."""
        for sched in self._schedulers.values():
            sched.stop(message_name)

    def start_all_cyclic(self) -> None:
        """Start all DBC messages that have a cycle_time defined."""
        if self._db is None:
            return
        for msg in self._db.messages:
            if msg.cycle_time:
                self.sim_start(msg.name)

    def message_status(self) -> list[MessageStatus]:
        """Return status for every DBC message — used by rig.sim.status()."""
        if self._db is None:
            return []
        statuses = []
        for msg in self._db.messages:
            sched = next(iter(self._schedulers.values()), None)
            active = sched is not None and msg.name in (sched.active_messages() if sched else [])
            period_ms = float(msg.cycle_time) if msg.cycle_time else 0.0
            tx = sched.tx_count(msg.name) if sched else 0
            statuses.append(MessageStatus(
                name=msg.name,
                active=active,
                period_ms=period_ms,
                last_tx=None,
                tx_count=tx,
                transport="can",
            ))
        return statuses

    # ── Frame listener (decode incoming CAN frames → signal store) ─────────────

    async def _on_frame(self, frame: "Any") -> None:
        """Decode an incoming CAN frame and update the signal store."""
        if self._db is None:
            return
        try:
            msg = self._db.get_message_by_frame_id(frame.arb_id)
            decoded = msg.decode(frame.data, decode_choices=False)
            self._signal_store.update_from_decoded(msg.name, decoded)
        except (KeyError, Exception):
            pass  # unknown arb_id or decode failure — silently ignore


__all__ = ["BusSimEngine"]
