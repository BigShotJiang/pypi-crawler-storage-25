"""Message Scheduler — periodic asyncio tasks for BSE simulation.

One asyncio.Task per active DBC message.  Each task sleeps for the message's
cycle time, encodes current signal values, and sends the frame via the backend.

Start/stop of individual messages is exposed to rig.sim.start() / .stop().
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from crucihil.hal.bse.signal_store import SignalStore
from crucihil.hal.models.exceptions import BackendError

if TYPE_CHECKING:
    import cantools.database
    from crucihil.hal.backends.base import AbstractCANBackend

_log = logging.getLogger(__name__)

_DEFAULT_PERIOD_S = 0.010   # 10 ms fallback when DBC has no cycle_time


class MessageScheduler:
    """Manages one asyncio.Task per active cyclic CAN message.

    The scheduler encodes signal values from the SignalStore at each tick,
    so a rig.sim.set() call mid-cycle takes effect on the very next frame.
    """

    def __init__(
        self,
        db: "cantools.database.Database",
        signal_store: SignalStore,
        backend: "AbstractCANBackend",
    ) -> None:
        self._db = db
        self._store = signal_store
        self._backend = backend
        self._tasks: dict[str, asyncio.Task] = {}   # message_name → Task
        self._tx_counts: dict[str, int] = {}         # message_name → frame count

    # ── Public API ─────────────────────────────────────────────────────────────

    def start(self, message_name: str) -> None:
        """Start periodic transmission of a DBC message.

        No-op if the message is already running.

        Raises:
            KeyError: If message_name is not in the loaded DBC.
        """
        if message_name in self._tasks:
            return
        msg = self._db.get_message_by_name(message_name)   # raises KeyError if unknown
        self._tx_counts[message_name] = 0
        self._tasks[message_name] = asyncio.create_task(
            self._run(msg),
            name=f"bse:{message_name}",
        )

    def stop(self, message_name: str) -> None:
        """Stop periodic transmission of a message.  No-op if not running."""
        if task := self._tasks.pop(message_name, None):
            task.cancel()

    async def stop_all(self) -> None:
        """Cancel all running tasks and wait for them to finish."""
        tasks = list(self._tasks.values())
        self._tasks.clear()
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def tx_count(self, message_name: str) -> int:
        """Number of frames transmitted for a message since start()."""
        return self._tx_counts.get(message_name, 0)

    def active_messages(self) -> list[str]:
        return list(self._tasks.keys())

    def period_ms(self, message_name: str) -> float:
        """Nominal cycle time in milliseconds from the DBC."""
        msg = self._db.get_message_by_name(message_name)
        return float(msg.cycle_time) if msg.cycle_time else _DEFAULT_PERIOD_S * 1000

    # ── Internal ───────────────────────────────────────────────────────────────

    async def _run(self, msg: "cantools.database.Message") -> None:
        period = (
            msg.cycle_time / 1000.0 if msg.cycle_time else _DEFAULT_PERIOD_S
        )
        while True:
            try:
                signals = {
                    sig.name: self._store.get(f"{msg.name}.{sig.name}")
                    for sig in msg.signals
                }
                data = bytes(msg.encode(signals))
                await self._backend.send(msg.frame_id, data)
                self._tx_counts[msg.name] = self._tx_counts.get(msg.name, 0) + 1
            except (BackendError, asyncio.CancelledError):
                raise
            except Exception as exc:
                _log.warning("BSE scheduler error for %s: %s", msg.name, exc)
            await asyncio.sleep(period)


__all__ = ["MessageScheduler"]
