"""Bus Simulation Engine (BSE) — Layer 2 simulation core.

The BSE owns the DBC database, signal state, and message scheduling.
It sits above the backends and below the namespaces.

Entry point: BusSimEngine
"""

from crucihil.hal.bse.engine import BusSimEngine

__all__ = ["BusSimEngine"]
