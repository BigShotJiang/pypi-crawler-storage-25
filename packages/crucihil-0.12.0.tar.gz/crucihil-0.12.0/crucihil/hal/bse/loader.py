"""DBC file loader — thin wrapper around cantools.

R10: cantools.database.load_file() is the ONLY DBC loader.
     Never use Database().add_dbc_file().
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import cantools.database

from crucihil.hal.models.exceptions import ConfigurationError

if TYPE_CHECKING:
    import cantools


def load_dbc(path: str | Path) -> "cantools.database.Database":
    """Load a DBC file and return a cantools Database.

    Args:
        path: Path to the .dbc file.

    Returns:
        A fully-loaded cantools Database object.

    Raises:
        ConfigurationError: If the file does not exist or cannot be parsed.
    """
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"DBC file not found: {path}")
    try:
        return cantools.database.load_file(str(path))
    except Exception as exc:
        raise ConfigurationError(f"Failed to parse DBC {path}: {exc}") from exc


__all__ = ["load_dbc"]
