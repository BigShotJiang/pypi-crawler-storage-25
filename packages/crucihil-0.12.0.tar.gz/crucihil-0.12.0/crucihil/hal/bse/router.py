"""Message Router — maps arb_id / message_name to the correct backend.

Phase 0 scope: CAN-only routing.  SOME/IP routing (arb_id → eth backend) is
Phase 1 once we have a SOME/IP descriptor parser.

The router is intentionally stateless beyond its constructor args — all
routing decisions are lookups, never mutations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import cantools.database
    from crucihil.hal.backends.base import AbstractCANBackend


class MessageRouter:
    """Routes DBC messages to the appropriate CAN backend.

    In Phase 0 there is typically one CAN backend per interface.  The router
    picks the backend based on the message's DBC bus name annotation, falling
    back to the primary (first) backend if no match.
    """

    def __init__(
        self,
        can_backends: dict[str, "AbstractCANBackend"],
        db: "cantools.database.Database | None" = None,
    ) -> None:
        """
        Args:
            can_backends: interface_name → backend instance.
            db:           Optional loaded DBC for bus-name based routing.
        """
        self._can_backends = can_backends
        # arb_id → interface_name, built from DBC bus annotations if available
        self._arb_id_to_interface: dict[int, str] = {}

        if db is not None:
            self._build_routing_table(db)

    def _build_routing_table(self, db: "cantools.database.Database") -> None:
        """Build arb_id → interface mapping from DBC bus_name annotations."""
        for msg in db.messages:
            if msg.bus_name and msg.bus_name in self._can_backends:
                self._arb_id_to_interface[msg.frame_id] = msg.bus_name

    # ── Lookup ─────────────────────────────────────────────────────────────────

    def can_backend_for_arb_id(self, arb_id: int) -> "AbstractCANBackend | None":
        """Return the CAN backend responsible for the given arbitration ID."""
        if arb_id in self._arb_id_to_interface:
            return self._can_backends.get(self._arb_id_to_interface[arb_id])
        return self._primary_can_backend()

    def can_backend_for_interface(
        self, interface: str
    ) -> "AbstractCANBackend | None":
        """Return the CAN backend for an explicit interface name."""
        return self._can_backends.get(interface)

    def all_can_backends(self) -> list["AbstractCANBackend"]:
        return list(self._can_backends.values())

    def _primary_can_backend(self) -> "AbstractCANBackend | None":
        """Return the first registered CAN backend (lexicographically by name)."""
        if not self._can_backends:
            return None
        return self._can_backends[min(self._can_backends)]


__all__ = ["MessageRouter"]
