"""CruciHiL backend implementations.

Each sub-package implements the ABCs from base.py for a specific hardware
or simulation target.  The Rig HAL never references concrete backend classes
— only the ABCs.  Resolution from name string → class happens in registry.py.
"""
