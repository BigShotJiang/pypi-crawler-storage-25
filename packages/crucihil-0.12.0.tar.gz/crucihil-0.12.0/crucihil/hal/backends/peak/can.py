"""PEAK CAN backend — PCAN-USB and PCAN-PCIe adapters via python-can.

This backend is identical in structure to SocketCANBackend but uses python-can's
'pcan' interface instead of 'socketcan'.  Requires the PEAK driver and
python-can[pcan] installed.  Fails gracefully with BackendError if unavailable.

Fault injection:
    block_arb_id / unblock_arb_id — same dropout mechanism as SocketCAN.
"""

from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor

from crucihil.hal.backends.base import AbstractCANBackend, CANFrameCallback
from crucihil.hal.models.exceptions import BackendError
from crucihil.hal.models.frames import CANFrame

_log = logging.getLogger(__name__)


class PEAKCANBackend(AbstractCANBackend):
    """CAN backend for PEAK PCAN adapters (PCAN-USB, PCAN-PCIe, etc.)."""

    def __init__(self) -> None:
        self._interface: str = ""
        self._connected: bool = False
        self._bus: object = None
        self._listeners: list[CANFrameCallback] = []
        self._blocked_arb_ids: set[int] = set()
        self._recv_task: asyncio.Task | None = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="peak-rx")

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self, interface: str, bitrate: int, fd: bool = False) -> None:
        try:
            import can
        except ImportError as exc:
            raise BackendError(
                "python-can is not installed. Run: pip install python-can"
            ) from exc

        self._interface = interface
        try:
            self._bus = can.Bus(
                channel=interface,
                interface="pcan",
                bitrate=bitrate,
                fd=fd,
            )
        except Exception as exc:
            raise BackendError(
                f"PEAK CAN failed to open '{interface}': {exc}. "
                "Ensure PEAK drivers are installed and the device is connected."
            ) from exc

        self._connected = True
        self._recv_task = asyncio.get_running_loop().create_task(
            self._receive_loop(), name=f"peak-rx-{interface}"
        )
        _log.debug("PEAK CAN '%s' connected at %d bps", interface, bitrate)

    async def disconnect(self) -> None:
        self._connected = False
        if self._recv_task and not self._recv_task.done():
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
        self._recv_task = None
        if self._bus is not None:
            import can
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(self._executor, self._bus.shutdown)  # type: ignore[attr-defined]
            self._bus = None
        self._executor.shutdown(wait=False)
        self._listeners.clear()

    # ── Frame I/O ──────────────────────────────────────────────────────────────

    async def send(self, arb_id: int, data: bytes) -> None:
        if not self._connected or self._bus is None:
            raise BackendError(
                f"PEAKCANBackend ('{self._interface}') is not connected"
            )
        if arb_id in self._blocked_arb_ids:
            return
        try:
            import can
        except ImportError as exc:
            raise BackendError("python-can not installed") from exc

        msg = can.Message(
            arbitration_id=arb_id,
            data=data,
            is_extended_id=(arb_id > 0x7FF),
        )
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(self._executor, self._bus.send, msg)  # type: ignore[attr-defined]
        except Exception as exc:
            raise BackendError(f"PEAK CAN send failed: {exc}") from exc

    # ── Listener registration ──────────────────────────────────────────────────

    def add_listener(self, cb: CANFrameCallback) -> None:
        if cb not in self._listeners:
            self._listeners.append(cb)

    def remove_listener(self, cb: CANFrameCallback) -> None:
        try:
            self._listeners.remove(cb)
        except ValueError:
            pass

    # ── Fault injection hooks ──────────────────────────────────────────────────

    def block_arb_id(self, arb_id: int) -> None:
        self._blocked_arb_ids.add(arb_id)

    def unblock_arb_id(self, arb_id: int) -> None:
        self._blocked_arb_ids.discard(arb_id)

    # ── Internal receive loop ──────────────────────────────────────────────────

    async def _receive_loop(self) -> None:
        loop = asyncio.get_running_loop()
        while self._connected and self._bus is not None:
            try:
                msg = await loop.run_in_executor(
                    self._executor,
                    lambda: self._bus.recv(timeout=0.05),  # type: ignore[union-attr]
                )
            except Exception as exc:
                if self._connected:
                    _log.warning("PEAK CAN '%s' recv error: %s", self._interface, exc)
                break
            if msg is None:
                continue
            if msg.arbitration_id in self._blocked_arb_ids:
                continue
            frame = CANFrame(
                arb_id=msg.arbitration_id,
                data=bytes(msg.data),
                timestamp=msg.timestamp,
                interface=self._interface,
            )
            for cb in list(self._listeners):
                loop.create_task(cb(frame))
