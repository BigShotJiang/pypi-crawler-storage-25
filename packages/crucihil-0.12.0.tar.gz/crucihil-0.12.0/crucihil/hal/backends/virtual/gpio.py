"""Virtual GPIO backend — in-memory pin simulation.

setup_pin() is called once per configured pin by the Rig during connect().
Input pins can be driven externally via drive_input() for test scaffolding.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from crucihil.hal.backends.base import AbstractGPIOBackend
from crucihil.hal.models.exceptions import GPIOError


@dataclass
class _PinState:
    direction: Literal["in", "out"]
    level: bool


class VirtualGPIOBackend(AbstractGPIOBackend):
    """In-process GPIO controller.  One instance handles all virtual GPIO pins."""

    def __init__(self) -> None:
        self._pins: dict[str, _PinState] = {}
        self._connected: bool = False

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False
        self._pins.clear()

    # ── Pin setup ──────────────────────────────────────────────────────────────

    async def setup_pin(
        self,
        name: str,
        pin: int,
        direction: str,
        default: bool,
    ) -> None:
        if direction not in ("in", "out"):
            raise GPIOError(f"Pin {name!r}: direction must be 'in' or 'out', got {direction!r}")
        self._pins[name] = _PinState(direction=direction, level=default)  # type: ignore[arg-type]

    # ── I/O ────────────────────────────────────────────────────────────────────

    async def set(self, name: str, high: bool) -> None:
        pin = self._pin(name)
        if pin.direction != "out":
            raise GPIOError(f"Cannot set input pin {name!r}")
        pin.level = high

    async def read(self, name: str) -> bool:
        return self._pin(name).level

    # ── Virtual-only helpers ───────────────────────────────────────────────────

    def drive_input(self, name: str, high: bool) -> None:
        """Externally drive an input pin — for fault injection and test scaffolding."""
        pin = self._pin(name)
        if pin.direction != "in":
            raise GPIOError(f"Cannot drive output pin {name!r} as input")
        pin.level = high

    # ── Private ────────────────────────────────────────────────────────────────

    def _pin(self, name: str) -> _PinState:
        try:
            return self._pins[name]
        except KeyError:
            raise GPIOError(
                f"Unknown GPIO pin {name!r}. "
                f"Configured pins: {sorted(self._pins)}"
            ) from None
