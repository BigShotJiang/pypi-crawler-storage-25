"""Virtual UDS backend — in-process diagnostic stub.

Phase 1 placeholder.  Returns a positive response for every request by default.
Register handlers via register_handler() for service-specific test fixtures.
Real UDS backends (ISO-TP over CAN, UDS over raw Ethernet) are Phase 2.
"""

from __future__ import annotations

from collections.abc import Callable

from crucihil.hal.backends.base import AbstractUDSBackend
from crucihil.hal.models.exceptions import BackendError, DoIPNegativeResponseError

UDSHandler = Callable[[bytes], bytes]


class VirtualUDSBackend(AbstractUDSBackend):
    """In-process UDS stub.  One instance per [rig.uds] config."""

    def __init__(self) -> None:
        self._connected: bool = False
        # service_id → handler
        self._handlers: dict[int, UDSHandler] = {}

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def request(
        self,
        service_id: int,
        payload: bytes,
        timeout: float,
    ) -> bytes:
        if not self._connected:
            raise BackendError("VirtualUDSBackend not connected")

        if service_id in self._handlers:
            return self._handlers[service_id](payload)

        # Default: positive empty response
        return b""

    def register_handler(self, service_id: int, handler: UDSHandler) -> None:
        """Register a test-fixture handler for a specific UDS service.

        Args:
            service_id: UDS service byte (e.g. 0x22).
            handler:    Called with request payload (without service byte),
                        returns response payload bytes.  Raise
                        DoIPNegativeResponseError to simulate NRC responses.
        """
        self._handlers[service_id] = handler
