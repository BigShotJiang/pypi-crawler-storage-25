"""Virtual DoIP backend — synthetic UDS responses.

By default every UDS request gets a positive response with an empty payload.
Register a handler via register_handler() to return service-specific data.

Example (in test scaffolding or conftest):

    backend = rig._doip_backends["eth0"]
    backend.register_handler(0x0001, 0x22, lambda payload: b"\\xF1\\x90" + b"VIRTVIN00000000000")
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

from crucihil.hal.backends.base import AbstractDoIPBackend
from crucihil.hal.models.exceptions import DoIPError
from crucihil.hal.models.frames import DoIPEntity, DoIPEntityStatus, DoIPResponse

# Handler signature: (uds_payload: bytes) -> response_payload: bytes
UDSHandler = Callable[[bytes], bytes]


class VirtualDoIPBackend(AbstractDoIPBackend):
    """In-process DoIP / UDS simulator.  One instance per Ethernet interface."""

    # Default UDS entities available for discovery
    _DEFAULT_VIN = "VIRTVIN00000000000"

    def __init__(self) -> None:
        self._connected: bool = False
        self._source_address: int = 0x0E00
        # (target_address, service_id) → handler
        self._handlers: dict[tuple[int, int], UDSHandler] = {}

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(
        self,
        ip: str,
        port: int,
        source_address: int,
        timeout: float,
    ) -> None:
        self._source_address = source_address
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    # ── UDS transport ──────────────────────────────────────────────────────────

    async def uds_request(
        self,
        target_address: int,
        payload: bytes,
        timeout: float,
    ) -> DoIPResponse:
        if not self._connected:
            raise DoIPError("VirtualDoIPBackend not connected")
        if not payload:
            raise DoIPError("UDS payload must not be empty")

        service_id = payload[0]
        key = (target_address, service_id)

        if key in self._handlers:
            response_payload = self._handlers[key](payload[1:])
            return DoIPResponse(
                service_id=service_id + 0x40,
                payload=response_payload,
                positive=True,
            )

        # Default: positive ACK with empty payload
        return DoIPResponse(
            service_id=service_id + 0x40,
            payload=b"",
            positive=True,
        )

    # ── Discovery ──────────────────────────────────────────────────────────────

    async def discover(self, timeout: float) -> list[DoIPEntity]:
        return [
            DoIPEntity(
                vin=self._DEFAULT_VIN,
                logical_address=0x0001,
                eid=b"\x00" * 6,
                gid=b"\xFF" * 6,
                ip="127.0.0.1",
                port=13400,
            )
        ]

    async def entity_status(
        self,
        target_address: int,
        timeout: float,
    ) -> DoIPEntityStatus:
        return DoIPEntityStatus(
            node_type=0,
            max_concurrent_sockets=3,
            currently_open_sockets=1,
        )

    # ── Virtual-only helpers ───────────────────────────────────────────────────

    def register_handler(
        self,
        target_address: int,
        service_id: int,
        handler: UDSHandler,
    ) -> None:
        """Register a custom UDS response handler for testing.

        Args:
            target_address: ECU logical address.
            service_id:     UDS service byte (e.g. 0x22 for ReadDataByIdentifier).
            handler:        Called with request payload (without service byte),
                            returns response payload bytes.
        """
        self._handlers[(target_address, service_id)] = handler
