"""Virtual UDP backend — in-memory datagram transport stub.

Phase 1 placeholder.  Datagrams sent via send() are not delivered anywhere —
they are discarded.  Incoming datagrams can be injected via inject() for
testing purposes.  Real UDP backends are Phase 2.
"""

from __future__ import annotations

import asyncio
from collections import deque

from crucihil.hal.backends.base import AbstractUDPBackend
from crucihil.hal.models.exceptions import BackendError, CANTimeoutError


class VirtualUDPBackend(AbstractUDPBackend):
    """In-memory UDP stub.  One instance per [rig.udp.<name>] entry."""

    def __init__(self) -> None:
        self._interface: str = ""
        self._connected: bool = False
        self._inbox: deque[tuple[bytes, str, int]] = deque()

    async def connect(self, interface: str, ip: str, port: int) -> None:
        self._interface = interface
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False
        self._inbox.clear()

    async def send(self, data: bytes, dest_ip: str, dest_port: int) -> None:
        if not self._connected:
            raise BackendError("VirtualUDPBackend not connected")

    async def receive(self, timeout: float) -> tuple[bytes, str, int]:
        if not self._connected:
            raise BackendError("VirtualUDPBackend not connected")
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            if self._inbox:
                return self._inbox.popleft()
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                raise CANTimeoutError(
                    f"VirtualUDPBackend: no datagram within {timeout}s"
                )
            await asyncio.sleep(min(0.01, remaining))

    def inject(self, data: bytes, source_ip: str = "127.0.0.1", source_port: int = 9999) -> None:
        """Inject a datagram into the receive queue — for testing."""
        self._inbox.append((data, source_ip, source_port))
