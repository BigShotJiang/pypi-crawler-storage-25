"""Virtual power backend — in-memory power rail simulation.

Tracks on/off state and a simulated voltage.  Used for power-cycle fault
injection and ECU boot sequencing in virtual tests.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractPowerBackend
from crucihil.hal.models.exceptions import PowerError


class VirtualPowerBackend(AbstractPowerBackend):
    """In-process power rail.  One instance per configured power rail."""

    _NOMINAL_VOLTAGE = 12.0     # volts
    _OFF_VOLTAGE = 0.0          # volts

    def __init__(self, default: str = "off") -> None:
        """
        Args:
            default: Initial state — "on" | "off" (from TOML, never test code R6).
        """
        self._on: bool = default == "on"
        self._voltage: float = self._NOMINAL_VOLTAGE if self._on else self._OFF_VOLTAGE
        self._connected: bool = False

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    # ── Rail control ───────────────────────────────────────────────────────────

    async def on(self) -> None:
        self._on = True
        self._voltage = self._NOMINAL_VOLTAGE

    async def off(self) -> None:
        self._on = False
        self._voltage = self._OFF_VOLTAGE

    async def read_voltage(self) -> float:
        return self._voltage

    async def set_voltage(self, voltage: float) -> None:
        """Set the simulated output voltage (bench PSU path / fault injection)."""
        if voltage < 0.0:
            raise PowerError(f"Voltage must be non-negative, got {voltage}")
        self._voltage = voltage
        self._on = voltage > 0.0

    # ── Virtual-only helpers ───────────────────────────────────────────────────

    @property
    def is_on(self) -> bool:
        return self._on
