"""Virtual (in-process) backend implementations.

No hardware required. All state is in-memory. Used for:
  - CI/CD pipelines without physical rigs
  - Local development before hardware exists
  - Fast unit/integration tests
"""
