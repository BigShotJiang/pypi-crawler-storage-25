"""Virtual SOME/IP backend — in-process service simulation.

Services are always "available" in virtual mode.  Events are injected by the
BSE via inject_event().  Fields are backed by an in-memory dict.
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from typing import Any

from crucihil.hal.backends.base import AbstractSOMEIPBackend, SOMEIPEventCallback
from crucihil.hal.models.frames import SOMEIPEvent, SOMEIPServiceInfo


class VirtualSOMEIPBackend(AbstractSOMEIPBackend):
    """In-process SOME/IP service simulator.  One instance per Ethernet interface."""

    def __init__(self) -> None:
        self._interface: str = ""
        self._connected: bool = False
        # (service_id, event_id) → [callbacks]
        self._listeners: defaultdict[tuple[int, int], list[SOMEIPEventCallback]] = (
            defaultdict(list)
        )
        # (service_id, instance_id, field_id) → raw bytes
        self._fields: dict[tuple[int, int, int], bytes] = {}

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self, interface: str, ip: str) -> None:
        self._interface = interface
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False
        self._listeners.clear()
        self._fields.clear()

    # ── Service discovery ──────────────────────────────────────────────────────

    async def find_service(
        self,
        service_id: int,
        instance_id: int,
        timeout: float,
    ) -> SOMEIPServiceInfo:
        """Virtual services are always available — return immediately."""
        return SOMEIPServiceInfo(
            service_id=service_id,
            instance_id=instance_id,
            endpoint=("127.0.0.1", 30509),
            available=True,
        )

    async def subscribe(
        self,
        service_id: int,
        instance_id: int,
        eventgroup_id: int,
    ) -> None:
        """No-op in virtual mode — subscriptions are always granted."""

    # ── Fields ─────────────────────────────────────────────────────────────────

    async def get_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        timeout: float,
    ) -> bytes:
        """Return the current in-memory field value, or 4 zero bytes if unset."""
        return self._fields.get((service_id, instance_id, field_id), b"\x00\x00\x00\x00")

    async def set_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        value: bytes,
    ) -> None:
        self._fields[(service_id, instance_id, field_id)] = value

    # ── Listeners ──────────────────────────────────────────────────────────────

    def add_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        key = (service_id, event_id)
        if cb not in self._listeners[key]:
            self._listeners[key].append(cb)

    def remove_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        key = (service_id, event_id)
        try:
            self._listeners[key].remove(cb)
        except ValueError:
            pass

    # ── Virtual-only helpers ───────────────────────────────────────────────────

    def inject_event(self, event: SOMEIPEvent) -> None:
        """Push a simulated event to all registered listeners.

        Called by the BSE scheduler to deliver periodic SOME/IP events.
        Listeners are called as asyncio tasks so injection is non-blocking.
        """
        key = (event.service_id, event.event_id)
        callbacks = list(self._listeners.get(key, []))
        if not callbacks:
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return  # no running loop — called outside async context, silently drop
        for cb in callbacks:
            loop.create_task(cb(event))
