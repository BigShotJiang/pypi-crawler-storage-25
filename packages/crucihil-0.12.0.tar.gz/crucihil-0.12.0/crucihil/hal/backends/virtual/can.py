"""Virtual CAN backend — in-process pub/sub bus.

send() delivers a CANFrame to every registered listener as an asyncio task,
mirroring the asynchronous delivery of a real CAN interface.  This means a
frame sent by the BSE scheduler is visible to rig.can.expect() on the very
next await point.
"""

from __future__ import annotations

import asyncio
import time

from crucihil.hal.backends.base import AbstractCANBackend, CANFrameCallback
from crucihil.hal.models.exceptions import BackendError
from crucihil.hal.models.frames import CANFrame


class VirtualCANBackend(AbstractCANBackend):
    """In-process CAN bus.  One instance per logical CAN interface."""

    def __init__(self) -> None:
        self._interface: str = ""
        self._connected: bool = False
        self._listeners: list[CANFrameCallback] = []
        self._blocked_arb_ids: set[int] = set()

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self, interface: str, bitrate: int, fd: bool = False) -> None:
        self._interface = interface
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False
        self._listeners.clear()

    # ── Frame I/O ──────────────────────────────────────────────────────────────

    async def send(self, arb_id: int, data: bytes) -> None:
        if not self._connected:
            raise BackendError(
                f"VirtualCANBackend ({self._interface!r}) is not connected"
            )
        if arb_id in self._blocked_arb_ids:
            return
        frame = CANFrame(
            arb_id=arb_id,
            data=data,
            timestamp=time.monotonic(),
            interface=self._interface,
        )
        loop = asyncio.get_running_loop()
        for cb in list(self._listeners):
            loop.create_task(cb(frame))

    # ── Listener registration ──────────────────────────────────────────────────

    def add_listener(self, cb: CANFrameCallback) -> None:
        if cb not in self._listeners:
            self._listeners.append(cb)

    def remove_listener(self, cb: CANFrameCallback) -> None:
        try:
            self._listeners.remove(cb)
        except ValueError:
            pass

    # ── Fault injection hooks ──────────────────────────────────────────────────

    def block_arb_id(self, arb_id: int) -> None:
        """Suppress TX for arb_id — called by FaultNamespace.can_dropout."""
        self._blocked_arb_ids.add(arb_id)

    def unblock_arb_id(self, arb_id: int) -> None:
        """Restore normal operation for arb_id."""
        self._blocked_arb_ids.discard(arb_id)

    # ── Virtual-only helpers ───────────────────────────────────────────────────

    async def inject(self, arb_id: int, data: bytes) -> None:
        """Inject a frame from outside the bus — used by fault injection and BSE.

        Equivalent to send() but bypasses the connected-check so that fault
        injection can still deliver frames while the bus is "dropped".
        """
        frame = CANFrame(
            arb_id=arb_id,
            data=data,
            timestamp=time.monotonic(),
            interface=self._interface,
        )
        loop = asyncio.get_running_loop()
        for cb in list(self._listeners):
            loop.create_task(cb(frame))
