"""Abstract backend interfaces (ABCs) for all five hardware abstraction layers.

Every concrete backend — virtual, SocketCAN, vsomeip, PEAK, python-doip, etc.
— must implement the relevant ABC here.  The Rig HAL only references these
ABCs, never concrete classes.  This is the Backend Swap Contract (CLAUDE.md).

Design rules:
- All I/O methods are async coroutines (R3).
- connect() / disconnect() are explicit lifecycle calls managed by Rig.
- Listener registration (add_listener / add_event_listener) is synchronous
  because it modifies in-memory state only.
- Backends are instantiated one-per-resource:
    one AbstractCANBackend  per CAN interface
    one AbstractSOMEIPBackend per Ethernet interface
    one AbstractDoIPBackend per Ethernet interface
    one AbstractPowerBackend per power rail
    one AbstractGPIOBackend per GPIO controller (may manage many pins)

Adding a new hardware adapter requires:
  1. Implement the relevant ABC
  2. Register in backends/registry.py
  3. Tests require zero changes
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable

from crucihil.hal.models.frames import (
    CANFrame,
    DoIPEntity,
    DoIPEntityStatus,
    DoIPResponse,
    SOMEIPEvent,
    SOMEIPServiceInfo,
)

# Type alias for async frame callbacks
CANFrameCallback = Callable[[CANFrame], Awaitable[None]]
SOMEIPEventCallback = Callable[[SOMEIPEvent], Awaitable[None]]


# ── CAN backend ────────────────────────────────────────────────────────────────

class AbstractCANBackend(ABC):
    """Raw CAN frame I/O for a single physical interface.

    The namespace (rig.can) wraps this with DBC encoding/decoding, signal
    tracking, and the expect/assert_stable/record higher-level API.  This ABC
    only handles raw bytes — no cantools dependency here.
    """

    @abstractmethod
    async def connect(self, interface: str, bitrate: int, fd: bool = False) -> None:
        """Open the CAN interface and begin receiving frames.

        Args:
            interface: OS interface name, e.g. "can0".
            bitrate:   Nominal bitrate in bits/second.
            fd:        True for CAN-FD support.
        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the interface.  Must be safe to call even if connect() failed."""

    @abstractmethod
    async def send(self, arb_id: int, data: bytes) -> None:
        """Transmit a raw CAN frame on this interface.

        Args:
            arb_id: Arbitration ID.
            data:   Payload bytes (≤8 classic CAN, ≤64 CAN-FD).
        """

    @abstractmethod
    def add_listener(self, cb: CANFrameCallback) -> None:
        """Register an async callback invoked for every received frame.

        The callback is called with a fully-populated CANFrame.
        frame_idx assignment is the namespace's responsibility, not the backend's.
        """

    @abstractmethod
    def remove_listener(self, cb: CANFrameCallback) -> None:
        """Deregister a previously registered listener."""


# ── SOME/IP backend ────────────────────────────────────────────────────────────

class AbstractSOMEIPBackend(ABC):
    """SOME/IP service interaction for a single Ethernet interface.

    Phase 0 scope: Events and Fields only.  Methods (request/response RPC)
    are Phase 1.
    """

    @abstractmethod
    async def connect(self, interface: str, ip: str) -> None:
        """Initialise the SOME/IP stack on this interface/IP.

        Args:
            interface: OS interface name, e.g. "eth0".
            ip:        Local IP address to bind to.
        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Shut down the SOME/IP stack.  Safe to call if connect() failed."""

    @abstractmethod
    async def find_service(
        self,
        service_id: int,
        instance_id: int,
        timeout: float,
    ) -> SOMEIPServiceInfo:
        """Wait for a service to announce itself via SOME/IP-SD.

        Raises:
            SOMEIPTimeoutError: If the service does not appear within timeout.
        """

    @abstractmethod
    async def subscribe(
        self,
        service_id: int,
        instance_id: int,
        eventgroup_id: int,
    ) -> None:
        """Send an event-group subscription request.

        Raises:
            SOMEIPError: If the subscription is rejected.
        """

    @abstractmethod
    async def get_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        timeout: float,
    ) -> bytes:
        """Read a SOME/IP field value (GET).

        Returns raw serialized bytes — deserialization is the namespace's job.

        Raises:
            SOMEIPTimeoutError: If no response arrives within timeout.
            SOMEIPError:        On protocol-level error.
        """

    @abstractmethod
    async def set_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        value: bytes,
    ) -> None:
        """Write a SOME/IP field value (SET).

        Args:
            value: Raw serialized bytes — serialization is the namespace's job.

        Raises:
            SOMEIPError: On protocol-level error.
        """

    @abstractmethod
    def add_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        """Register an async callback for a specific event.

        The callback is invoked for every received event matching
        (service_id, event_id).
        """

    @abstractmethod
    def remove_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        """Deregister a previously registered event listener."""


# ── DoIP backend ───────────────────────────────────────────────────────────────

class AbstractDoIPBackend(ABC):
    """DoIP transport for a single Ethernet interface.

    Phase 0 scope: routing activation, UDS transport, entity discovery.
    DoIP gateway routing is Phase 1.
    """

    @abstractmethod
    async def connect(
        self,
        ip: str,
        port: int,
        source_address: int,
        timeout: float,
    ) -> None:
        """Establish a DoIP session and perform routing activation.

        Args:
            ip:             DoIP gateway IP address.
            port:           TCP port (standard: 13400).
            source_address: Tester's logical address.
            timeout:        Seconds to wait for routing activation response.

        Raises:
            DoIPError: If routing activation fails.
        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the DoIP TCP session.  Safe to call if connect() failed."""

    @abstractmethod
    async def uds_request(
        self,
        target_address: int,
        payload: bytes,
        timeout: float,
    ) -> DoIPResponse:
        """Send a UDS PDU and wait for the response.

        Args:
            target_address: ECU logical address.
            payload:        Full UDS request bytes (service ID + data).
            timeout:        Seconds to wait for a response.

        Returns:
            DoIPResponse with positive=True on positive response,
            positive=False + nrc set on negative response.

        Raises:
            CANTimeoutError: If no response arrives within timeout.
            DoIPError:       On transport-level failure.
        """

    @abstractmethod
    async def discover(self, timeout: float) -> list[DoIPEntity]:
        """Broadcast a vehicle announcement request and collect responses.

        Args:
            timeout: Seconds to collect announcements.

        Returns:
            List of discovered DoIPEntity objects (may be empty).
        """

    @abstractmethod
    async def entity_status(
        self,
        target_address: int,
        timeout: float,
    ) -> DoIPEntityStatus:
        """Query an entity's DoIP status.

        Raises:
            DoIPError: If the entity does not respond.
        """


# ── Power backend ──────────────────────────────────────────────────────────────

class AbstractPowerBackend(ABC):
    """Power rail control for a single rail (e.g. "ecu_main", "12v_supply").

    One instance per rail, created and configured by the Rig from TOML.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Open connection to the power hardware (relay board, bench PSU, etc.)."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Release the hardware connection.  Safe to call if connect() failed."""

    @abstractmethod
    async def on(self) -> None:
        """Apply power to this rail."""

    @abstractmethod
    async def off(self) -> None:
        """Remove power from this rail."""

    @abstractmethod
    async def read_voltage(self) -> float:
        """Read the current rail voltage in volts.

        Returns:
            Measured voltage.  Virtual backend returns a simulated value.
        """

    @abstractmethod
    async def set_voltage(self, voltage: float) -> None:
        """Set the output voltage (bench PSU only; fault injection path).

        Raises:
            PowerError: If the backend does not support voltage control
                        (e.g. a GPIO relay — only on/off).
        """


# ── GPIO backend ───────────────────────────────────────────────────────────────

class AbstractGPIOBackend(ABC):
    """Digital I/O controller.

    One instance per backend type (e.g. one VirtualGPIOBackend handles all
    virtual GPIO pins).  The Rig calls setup_pin() once per configured pin
    during rig.connect(), before any test code runs.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Initialise the GPIO hardware or simulation."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Release GPIO resources.  Safe to call if connect() failed."""

    @abstractmethod
    async def setup_pin(
        self,
        name: str,
        pin: int,
        direction: str,
        default: bool,
    ) -> None:
        """Configure one pin.  Called by the Rig during startup.

        Args:
            name:      Logical name from TOML (e.g. "ignition_enable").
            pin:       Physical pin number on the controller.
            direction: "in" | "out".
            default:   Initial state for output pins.
        """

    @abstractmethod
    async def set(self, name: str, high: bool) -> None:
        """Drive an output pin high or low.

        Args:
            name: Logical pin name (must have direction="out").
            high: True = drive high, False = drive low.

        Raises:
            GPIOError: If the pin is not configured or direction is "in".
        """

    @abstractmethod
    async def read(self, name: str) -> bool:
        """Read the current state of a pin.

        Args:
            name: Logical pin name.

        Returns:
            True if the pin is high, False if low.

        Raises:
            GPIOError: If the pin is not configured.
        """


# ── UDP backend ────────────────────────────────────────────────────────────────

class AbstractUDPBackend(ABC):
    """UDP datagram transport.

    Phase 1 placeholder — virtual stub only.  Real UDP backends are Phase 2.
    Intended for AV/robotics teams that use raw UDP for sensor data and
    custom protocols.
    """

    @abstractmethod
    async def connect(self, interface: str, ip: str, port: int) -> None:
        """Bind to the local IP/port and begin receiving datagrams."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Unbind.  Safe to call if connect() failed."""

    @abstractmethod
    async def send(self, data: bytes, dest_ip: str, dest_port: int) -> None:
        """Send a UDP datagram to dest_ip:dest_port."""

    @abstractmethod
    async def receive(self, timeout: float) -> tuple[bytes, str, int]:
        """Wait for a datagram and return (data, source_ip, source_port).

        Raises:
            CANTimeoutError: If no datagram arrives within timeout.
        """


# ── UDS backend ────────────────────────────────────────────────────────────────

class AbstractUDSBackend(ABC):
    """Standalone UDS transport (not via DoIP).

    Phase 1 placeholder — virtual stub only.  Real backends (ISO-TP over CAN,
    UDS over raw Ethernet) are Phase 2.  UDS over DoIP is handled by
    AbstractDoIPBackend + the ECU namespace.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Open the UDS channel."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the UDS channel.  Safe to call if connect() failed."""

    @abstractmethod
    async def request(
        self,
        service_id: int,
        payload: bytes,
        timeout: float,
    ) -> bytes:
        """Send a UDS service request and return the positive response payload.

        Args:
            service_id: UDS service byte (e.g. 0x22 for ReadDataByIdentifier).
            payload:    Request data bytes (without service byte).
            timeout:    Seconds to wait for a response.

        Returns:
            Positive response payload bytes (without the positive response SID).

        Raises:
            DoIPNegativeResponseError: On NRC response.
            CANTimeoutError:           If no response arrives within timeout.
        """


# ── Public re-export ───────────────────────────────────────────────────────────

__all__ = [
    "CANFrameCallback",
    "SOMEIPEventCallback",
    "AbstractCANBackend",
    "AbstractSOMEIPBackend",
    "AbstractDoIPBackend",
    "AbstractPowerBackend",
    "AbstractGPIOBackend",
    "AbstractUDPBackend",
    "AbstractUDSBackend",
]
