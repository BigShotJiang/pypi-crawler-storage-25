"""python-doip backend — real DoIP over TCP using the doipclient library.

Requires: pip install doipclient

Phase 1 scope: routing activation, UDS request/response, entity discovery.
DoIP gateway routing is Phase 2.

If doipclient is not installed, BackendError is raised at connect() time with
a clear install instruction — the test is then marked 'blocked', not 'fail'.
"""

from __future__ import annotations

import asyncio
import logging

from crucihil.hal.backends.base import AbstractDoIPBackend
from crucihil.hal.models.exceptions import BackendError, CANTimeoutError, DoIPError
from crucihil.hal.models.frames import DoIPEntity, DoIPEntityStatus, DoIPResponse

_log = logging.getLogger(__name__)


def _require_doipclient():
    try:
        import doipclient
        return doipclient
    except ImportError as exc:
        raise BackendError(
            "doipclient not installed. Run: pip install doipclient\n"
            "Alternatively use backend='python-doip' (virtual) for CI without hardware."
        ) from exc


class PythonDoIPBackend(AbstractDoIPBackend):
    """DoIP backend using the doipclient library over TCP.

    One instance per Ethernet interface.  The TCP connection is established in
    connect(), which performs routing activation before returning.
    """

    def __init__(self) -> None:
        self._connected: bool = False
        self._client = None
        self._ip: str = ""
        self._port: int = 13400
        self._source_address: int = 0x0E00

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(
        self,
        ip: str,
        port: int,
        source_address: int,
        timeout: float,
    ) -> None:
        doipclient = _require_doipclient()
        self._ip = ip
        self._port = port
        self._source_address = source_address

        loop = asyncio.get_running_loop()
        try:
            self._client = await loop.run_in_executor(
                None,
                lambda: doipclient.DoIPClient(
                    ecu_ip_address=ip,
                    ecu_logical_address=source_address,
                    tcp_port=port,
                    activation_type=doipclient.RoutingActivationRequest.ActivationType.Default,
                    auto_reconnect_tcp=True,
                ),
            )
            self._connected = True
            _log.debug("DoIP connected to %s:%d (source=0x%04X)", ip, port, source_address)
        except Exception as exc:
            raise DoIPError(
                f"DoIP routing activation to {ip}:{port} failed: {exc}"
            ) from exc

    async def disconnect(self) -> None:
        self._connected = False
        if self._client is not None:
            loop = asyncio.get_running_loop()
            try:
                await loop.run_in_executor(None, self._client.close)
            except Exception as exc:
                _log.warning("DoIP close error: %s", exc)
            self._client = None

    # ── UDS transport ──────────────────────────────────────────────────────────

    async def uds_request(
        self,
        target_address: int,
        payload: bytes,
        timeout: float,
    ) -> DoIPResponse:
        if not self._connected or self._client is None:
            raise DoIPError("PythonDoIPBackend not connected")

        loop = asyncio.get_running_loop()
        try:
            raw = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: self._client.send_doip_payload(  # type: ignore[attr-defined]
                        target_address, payload
                    ),
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            raise CANTimeoutError(
                f"DoIP UDS request to 0x{target_address:04X} timed out after {timeout}s"
            )
        except Exception as exc:
            raise DoIPError(f"DoIP UDS transport error: {exc}") from exc

        if raw is None or len(raw) == 0:
            raise DoIPError("DoIP returned empty response payload")

        service_id = raw[0]
        positive = (service_id & 0x40) != 0 or service_id == (payload[0] + 0x40)
        nrc = raw[1] if not positive and len(raw) > 1 else None

        return DoIPResponse(
            service_id=service_id,
            payload=bytes(raw[1:]),
            positive=positive,
            nrc=nrc,
        )

    # ── Discovery ──────────────────────────────────────────────────────────────

    async def discover(self, timeout: float) -> list[DoIPEntity]:
        doipclient = _require_doipclient()
        loop = asyncio.get_running_loop()
        try:
            results = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: doipclient.DoIPClient.get_entity(
                        ecu_ip_address=self._ip,
                        udp_port=13400,
                    ),
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            return []
        except Exception as exc:
            _log.warning("DoIP discover error: %s", exc)
            return []

        if results is None:
            return []

        entities = results if isinstance(results, list) else [results]
        out: list[DoIPEntity] = []
        for e in entities:
            try:
                out.append(DoIPEntity(
                    vin=getattr(e, "vin", ""),
                    logical_address=getattr(e, "logical_address", 0),
                    eid=bytes(getattr(e, "eid", b"\x00" * 6)),
                    gid=bytes(getattr(e, "gid", b"\xFF" * 6)),
                    ip=self._ip,
                    port=self._port,
                ))
            except Exception:
                continue
        return out

    async def entity_status(
        self,
        target_address: int,
        timeout: float,
    ) -> DoIPEntityStatus:
        if not self._connected or self._client is None:
            raise DoIPError("PythonDoIPBackend not connected")
        loop = asyncio.get_running_loop()
        try:
            resp = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: self._client.request_entity_status(),  # type: ignore[attr-defined]
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            raise DoIPError(f"entity_status timed out for 0x{target_address:04X}")
        except Exception as exc:
            raise DoIPError(f"entity_status failed: {exc}") from exc

        return DoIPEntityStatus(
            node_type=getattr(resp, "node_type", 0),
            max_concurrent_sockets=getattr(resp, "max_concurrent_tcp_sockets", 3),
            currently_open_sockets=getattr(resp, "currently_open_sockets", 0),
        )
