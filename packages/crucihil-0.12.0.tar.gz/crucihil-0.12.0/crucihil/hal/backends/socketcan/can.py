"""SocketCAN backend — real CAN via Linux SocketCAN using python-can.

One instance per CAN interface.  Frames are received in a background asyncio
task via run_in_executor so the event loop is never blocked (R3).

Fault injection:
    block_arb_id(arb_id)   — suppress TX and RX for that arb_id
    unblock_arb_id(arb_id) — restore normal operation
These are called by FaultNamespace when a can_dropout descriptor is activated.
"""

from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor

from crucihil.hal.backends.base import AbstractCANBackend, CANFrameCallback
from crucihil.hal.models.exceptions import BackendError
from crucihil.hal.models.frames import CANFrame

try:
    import can
except ImportError as _e:
    raise BackendError(
        "python-can is not installed. Run: pip install python-can"
    ) from _e

_log = logging.getLogger(__name__)


class SocketCANBackend(AbstractCANBackend):
    """Real CAN backend using Linux SocketCAN via python-can.

    Requires the vcan or physical CAN interface to exist before connect() is
    called.  In CI, use 'ip link add vcan0 type vcan && ip link set vcan0 up'
    to create a virtual CAN interface for loopback tests.
    """

    def __init__(self) -> None:
        self._interface: str = ""
        self._connected: bool = False
        self._bus: "can.BusABC | None" = None
        self._listeners: list[CANFrameCallback] = []
        self._blocked_arb_ids: set[int] = set()
        self._recv_task: asyncio.Task | None = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="socketcan-rx")

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self, interface: str, bitrate: int, fd: bool = False) -> None:
        self._interface = interface
        try:
            self._bus = can.Bus(
                channel=interface,
                interface="socketcan",
                bitrate=bitrate,
                fd=fd,
            )
        except Exception as exc:
            raise BackendError(
                f"SocketCAN failed to open '{interface}': {exc}"
            ) from exc

        self._connected = True
        self._recv_task = asyncio.get_running_loop().create_task(
            self._receive_loop(), name=f"socketcan-rx-{interface}"
        )
        _log.debug("SocketCAN '%s' connected at %d bps", interface, bitrate)

    async def disconnect(self) -> None:
        self._connected = False
        if self._recv_task and not self._recv_task.done():
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
        self._recv_task = None
        if self._bus is not None:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(self._executor, self._bus.shutdown)
            self._bus = None
        self._executor.shutdown(wait=False)
        self._listeners.clear()
        _log.debug("SocketCAN '%s' disconnected", self._interface)

    # ── Frame I/O ──────────────────────────────────────────────────────────────

    async def send(self, arb_id: int, data: bytes) -> None:
        if not self._connected or self._bus is None:
            raise BackendError(
                f"SocketCANBackend ('{self._interface}') is not connected"
            )
        if arb_id in self._blocked_arb_ids:
            _log.debug("CAN dropout active — suppressed TX arb_id=0x%X", arb_id)
            return
        msg = can.Message(
            arbitration_id=arb_id,
            data=data,
            is_extended_id=(arb_id > 0x7FF),
        )
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(self._executor, self._bus.send, msg)
        except Exception as exc:
            raise BackendError(f"SocketCAN send failed: {exc}") from exc

    # ── Listener registration ──────────────────────────────────────────────────

    def add_listener(self, cb: CANFrameCallback) -> None:
        if cb not in self._listeners:
            self._listeners.append(cb)

    def remove_listener(self, cb: CANFrameCallback) -> None:
        try:
            self._listeners.remove(cb)
        except ValueError:
            pass

    # ── Fault injection hooks ──────────────────────────────────────────────────

    def block_arb_id(self, arb_id: int) -> None:
        """Suppress TX and RX for arb_id — called by FaultNamespace.can_dropout."""
        self._blocked_arb_ids.add(arb_id)
        _log.debug("SocketCAN '%s': blocking arb_id=0x%X", self._interface, arb_id)

    def unblock_arb_id(self, arb_id: int) -> None:
        """Restore normal operation for arb_id."""
        self._blocked_arb_ids.discard(arb_id)
        _log.debug("SocketCAN '%s': unblocking arb_id=0x%X", self._interface, arb_id)

    # ── Internal receive loop ──────────────────────────────────────────────────

    async def _receive_loop(self) -> None:
        """Background task: poll the socket and deliver frames to listeners."""
        loop = asyncio.get_running_loop()
        while self._connected and self._bus is not None:
            try:
                msg = await loop.run_in_executor(
                    self._executor,
                    lambda: self._bus.recv(timeout=0.05),  # type: ignore[union-attr]
                )
            except Exception as exc:
                if self._connected:
                    _log.warning("SocketCAN '%s' recv error: %s", self._interface, exc)
                break

            if msg is None:
                continue
            if msg.arbitration_id in self._blocked_arb_ids:
                continue

            frame = CANFrame(
                arb_id=msg.arbitration_id,
                data=bytes(msg.data),
                timestamp=msg.timestamp,
                interface=self._interface,
            )
            for cb in list(self._listeners):
                loop.create_task(cb(frame))
