"""Backend registry — resolves backend name strings to concrete classes.

Usage (by the Rig and config loader):

    from crucihil.hal.backends.registry import resolve_can_backend
    BackendClass = resolve_can_backend("virtual")
    instance = BackendClass()
    await instance.connect(interface="can0", bitrate=500000)

All imports are lazy (via importlib) so that optional backend dependencies
(vsomeip, doipclient, PEAK SDK) are not required unless actually used.

Custom backends:
    Any name containing a "." is treated as a dotted module path and resolved
    via importlib.  The class name must be the last segment after a final ":":
        "myorg.rig_io_board:MyCANBackend"
    If no ":" is present, the module is imported and the resolved class must be
    named in the known map or the import itself is expected to export a single
    concrete class.

To add a new built-in backend:
    1. Implement the relevant ABC in a new sub-package.
    2. Add the mapping entry in the _*_BACKENDS dict below.
    3. Tests require zero changes.
"""

from __future__ import annotations

import importlib
from typing import Any

from crucihil.hal.models.exceptions import ConfigurationError





def _lazy(module: str, cls: str) -> Any:
    """Import ``module`` and return its ``cls`` attribute, deferred until called."""
    mod = importlib.import_module(module)
    return getattr(mod, cls)


def _resolve_custom(name: str) -> Any:
    """Resolve a dotted 'module.path:ClassName' custom backend string.

    The class is imported at call time and NOT validated here.  The Rig
    validates ABC compliance at connect() time (R9).

    Examples:
        "myorg.rig_io_board:MyCANBackend"  → imports myorg.rig_io_board, returns MyCANBackend
        "myorg.rig_io_board"               → imports myorg.rig_io_board, returns .Backend
    """
    if ":" in name:
        module_path, cls_name = name.rsplit(":", 1)
    else:
        parts = name.rsplit(".", 1)
        module_path = name
        cls_name = parts[-1] if len(parts) > 1 else None

    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        raise ConfigurationError(
            f"Cannot import custom backend module '{module_path}': {exc}"
        ) from exc

    if cls_name:
        if not hasattr(mod, cls_name):
            raise ConfigurationError(
                f"Custom backend module '{module_path}' has no class '{cls_name}'"
            )
        return getattr(mod, cls_name)

    # No class name given — expect a 'Backend' attribute or single exported class
    for attr in ("Backend", "CANBackend", "SOMEIPBackend", "DoIPBackend"):
        if hasattr(mod, attr):
            return getattr(mod, attr)

    raise ConfigurationError(
        f"Custom backend module '{module_path}' does not export a recognisable "
        "class.  Use the 'module.path:ClassName' syntax."
    )


# ── Backend maps: name → (module_path, class_name) ────────────────────────────

_CAN_BACKENDS: dict[str, tuple[str, str]] = {
    "virtual":   ("crucihil.hal.backends.virtual.can",        "VirtualCANBackend"),
    "socketcan": ("crucihil.hal.backends.socketcan.can",       "SocketCANBackend"),
    "peak":      ("crucihil.hal.backends.peak.can",            "PEAKCANBackend"),
}

_SOMEIP_BACKENDS: dict[str, tuple[str, str]] = {
    "python-someip": ("crucihil.hal.backends.virtual.someip",  "VirtualSOMEIPBackend"),
    "vsomeip":       ("crucihil.hal.backends.vsomeip.someip",  "VsomeipBackend"),
}

_DOIP_BACKENDS: dict[str, tuple[str, str]] = {
    "virtual":     ("crucihil.hal.backends.virtual.doip",      "VirtualDoIPBackend"),
    "python-doip": ("crucihil.hal.backends.python_doip.doip",  "PythonDoIPBackend"),
}

_POWER_BACKENDS: dict[str, tuple[str, str]] = {
    "virtual_power": ("crucihil.hal.backends.virtual.power",   "VirtualPowerBackend"),
    "gpio_relay":    ("crucihil.hal.backends.real.power",      "GPIORelayPowerBackend"),
    "bench_psu":     ("crucihil.hal.backends.real.power",      "BenchPSUPowerBackend"),
}

_GPIO_BACKENDS: dict[str, tuple[str, str]] = {
    "virtual_gpio": ("crucihil.hal.backends.virtual.gpio",     "VirtualGPIOBackend"),
    "linux_gpio":   ("crucihil.hal.backends.real.gpio",        "LinuxGPIOBackend"),
}


# ── Resolver functions ─────────────────────────────────────────────────────────

def resolve_can_backend(name: str) -> type:
    """Return the CAN backend class for the given backend name string.

    Raises:
        ConfigurationError: If the name is not registered and not a dotted path.
    """
    if name in _CAN_BACKENDS:
        return _lazy(*_CAN_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown CAN backend: {name!r}. "
        f"Available: {sorted(_CAN_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


def resolve_someip_backend(name: str) -> type:
    """Return the SOME/IP backend class for the given name string."""
    if name in _SOMEIP_BACKENDS:
        return _lazy(*_SOMEIP_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown SOME/IP backend: {name!r}. "
        f"Available: {sorted(_SOMEIP_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


def resolve_doip_backend(name: str) -> type:
    """Return the DoIP backend class for the given name string."""
    if name in _DOIP_BACKENDS:
        return _lazy(*_DOIP_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown DoIP backend: {name!r}. "
        f"Available: {sorted(_DOIP_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


def resolve_power_backend(name: str) -> type:
    """Return the power backend class for the given name string."""
    if name in _POWER_BACKENDS:
        return _lazy(*_POWER_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown power backend: {name!r}. "
        f"Available: {sorted(_POWER_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


def resolve_gpio_backend(name: str) -> type:
    """Return the GPIO backend class for the given name string."""
    if name in _GPIO_BACKENDS:
        return _lazy(*_GPIO_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown GPIO backend: {name!r}. "
        f"Available: {sorted(_GPIO_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


_UDP_BACKENDS: dict[str, tuple[str, str]] = {
    "virtual_udp": ("crucihil.hal.backends.virtual.udp", "VirtualUDPBackend"),
}

_UDS_BACKENDS: dict[str, tuple[str, str]] = {
    "virtual_uds": ("crucihil.hal.backends.virtual.uds", "VirtualUDSBackend"),
}


def resolve_udp_backend(name: str) -> type:
    """Return the UDP backend class for the given name string."""
    if name in _UDP_BACKENDS:
        return _lazy(*_UDP_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown UDP backend: {name!r}. "
        f"Available: {sorted(_UDP_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


def resolve_uds_backend(name: str) -> type:
    """Return the UDS backend class for the given name string."""
    if name in _UDS_BACKENDS:
        return _lazy(*_UDS_BACKENDS[name])
    if "." in name:
        return _resolve_custom(name)
    raise ConfigurationError(
        f"Unknown UDS backend: {name!r}. "
        f"Available: {sorted(_UDS_BACKENDS)} or a dotted 'module.path:ClassName'."
    )


__all__ = [
    "resolve_can_backend",
    "resolve_someip_backend",
    "resolve_doip_backend",
    "resolve_power_backend",
    "resolve_gpio_backend",
    "resolve_udp_backend",
    "resolve_uds_backend",
]
