"""vsomeip wrapper backend — real SOME/IP via vsomeip Python bindings.

vsomeip is a system-level dependency (C++ library + Python bindings).  This
backend fails gracefully with BackendError if the bindings are not installed.

Phase 1 scope: Events and Fields only.  Methods (RPC) are Phase 2.
"""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict

from crucihil.hal.backends.base import AbstractSOMEIPBackend, SOMEIPEventCallback
from crucihil.hal.models.exceptions import BackendError, SOMEIPError, SOMEIPTimeoutError
from crucihil.hal.models.frames import SOMEIPEvent, SOMEIPServiceInfo

_log = logging.getLogger(__name__)


def _require_vsomeip():
    try:
        import vsomeip  # noqa: F401
        return vsomeip
    except ImportError as exc:
        raise BackendError(
            "vsomeip Python bindings not found. Install vsomeip and its Python "
            "bindings for your platform. See docs/ARCHITECTURE.md §vsomeip."
        ) from exc


class VsomeipBackend(AbstractSOMEIPBackend):
    """SOME/IP backend wrapping the vsomeip C++ stack Python bindings.

    The vsomeip application is created at connect() time and destroyed at
    disconnect().  One VsomeipBackend instance per Ethernet interface.
    """

    def __init__(self) -> None:
        self._interface: str = ""
        self._ip: str = ""
        self._connected: bool = False
        self._app = None
        # (service_id, event_id) → [callbacks]
        self._listeners: defaultdict[tuple[int, int], list[SOMEIPEventCallback]] = (
            defaultdict(list)
        )
        # (service_id, instance_id, field_id) → asyncio.Future (set on GET response)
        self._pending_gets: dict[tuple[int, int, int], asyncio.Future] = {}

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self, interface: str, ip: str) -> None:
        vsomeip = _require_vsomeip()
        self._interface = interface
        self._ip = ip
        try:
            self._app = vsomeip.application("crucihil")
            self._app.init()
            self._app.register_message_handler(
                vsomeip.ANY_SERVICE,
                vsomeip.ANY_INSTANCE,
                vsomeip.ANY_METHOD,
                self._on_message,
            )
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._app.start)
            self._connected = True
            _log.debug("vsomeip backend connected on %s/%s", interface, ip)
        except Exception as exc:
            raise BackendError(f"vsomeip connect failed: {exc}") from exc

    async def disconnect(self) -> None:
        self._connected = False
        if self._app is not None:
            try:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, self._app.stop)
            except Exception as exc:
                _log.warning("vsomeip stop error: %s", exc)
            self._app = None
        self._listeners.clear()
        self._pending_gets.clear()

    # ── Service discovery ──────────────────────────────────────────────────────

    async def find_service(
        self,
        service_id: int,
        instance_id: int,
        timeout: float,
    ) -> SOMEIPServiceInfo:
        if not self._connected or self._app is None:
            raise BackendError("VsomeipBackend not connected")
        fut: asyncio.Future[SOMEIPServiceInfo] = asyncio.get_running_loop().create_future()

        def _on_availability(svc, inst, available):
            if svc == service_id and inst == instance_id and available:
                if not fut.done():
                    fut.set_result(SOMEIPServiceInfo(
                        service_id=svc,
                        instance_id=inst,
                        endpoint=(self._ip, 0),
                        available=True,
                    ))

        self._app.register_availability_handler(service_id, instance_id, _on_availability)
        self._app.request_service(service_id, instance_id)
        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            raise SOMEIPTimeoutError(
                f"Service 0x{service_id:04X}/0x{instance_id:04X} not found within {timeout}s"
            )
        finally:
            try:
                self._app.release_service(service_id, instance_id)
            except Exception:
                pass

    async def subscribe(
        self,
        service_id: int,
        instance_id: int,
        eventgroup_id: int,
    ) -> None:
        if not self._connected or self._app is None:
            raise BackendError("VsomeipBackend not connected")
        try:
            self._app.subscribe(service_id, instance_id, eventgroup_id)
        except Exception as exc:
            raise SOMEIPError(f"vsomeip subscribe failed: {exc}") from exc

    # ── Fields ─────────────────────────────────────────────────────────────────

    async def get_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        timeout: float,
    ) -> bytes:
        if not self._connected or self._app is None:
            raise BackendError("VsomeipBackend not connected")
        import vsomeip
        key = (service_id, instance_id, field_id)
        fut: asyncio.Future[bytes] = asyncio.get_running_loop().create_future()
        self._pending_gets[key] = fut
        try:
            req = self._app.create_request()
            req.set_service(service_id)
            req.set_instance(instance_id)
            req.set_method(field_id)
            self._app.send(req)
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            raise SOMEIPTimeoutError(
                f"GET field 0x{field_id:04X} on service 0x{service_id:04X} timed out"
            )
        finally:
            self._pending_gets.pop(key, None)

    async def set_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        value: bytes,
    ) -> None:
        if not self._connected or self._app is None:
            raise BackendError("VsomeipBackend not connected")
        try:
            import vsomeip
            req = self._app.create_request(False)  # fire-and-forget
            req.set_service(service_id)
            req.set_instance(instance_id)
            req.set_method(field_id)
            payload = self._app.create_payload()
            payload.set_data(list(value))
            req.set_payload(payload)
            self._app.send(req)
        except Exception as exc:
            raise SOMEIPError(f"vsomeip SET field failed: {exc}") from exc

    # ── Listeners ──────────────────────────────────────────────────────────────

    def add_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        key = (service_id, event_id)
        if cb not in self._listeners[key]:
            self._listeners[key].append(cb)

    def remove_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        key = (service_id, event_id)
        try:
            self._listeners[key].remove(cb)
        except ValueError:
            pass

    # ── Internal message handler ───────────────────────────────────────────────

    def _on_message(self, message) -> None:
        """Called by vsomeip on every incoming message (runs in vsomeip thread)."""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            return

        service_id = message.get_service()
        event_id = message.get_method()
        payload = bytes(message.get_payload().get_data())

        key = (service_id, event_id)

        # Resolve pending GET futures
        pending = self._pending_gets.get(key)
        if pending and not pending.done():
            loop.call_soon_threadsafe(pending.set_result, payload)
            return

        # Deliver to event listeners
        event = SOMEIPEvent(
            service_id=service_id,
            instance_id=message.get_instance(),
            event_id=event_id,
            payload=payload,
        )
        callbacks = list(self._listeners.get(key, []))
        for cb in callbacks:
            loop.call_soon_threadsafe(
                loop.create_task, cb(event)  # type: ignore[arg-type]
            )
