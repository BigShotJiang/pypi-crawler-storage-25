"""TOML config loader for rig configurations.

Single entry point: load_rig_config(path).

Validation is done by Pydantic at load time (R9 — validate at startup, not
runtime).  A bad TOML file raises ConfigurationError before any test runs.
"""

from __future__ import annotations

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]  # Python < 3.11
from pathlib import Path

from crucihil.hal.config.schema import RigConfig
from crucihil.hal.models.exceptions import ConfigurationError


def load_rig_config(path: str | Path) -> RigConfig:
    """Load and validate a rig TOML file.

    Args:
        path: Path to the .toml file (absolute or relative to CWD).

    Returns:
        Validated RigConfig instance.

    Raises:
        ConfigurationError: If the file cannot be read, is not valid TOML,
                            or fails Pydantic validation.
    """
    path = Path(path)

    try:
        with open(path, "rb") as f:
            raw = tomllib.load(f)
    except FileNotFoundError:
        raise ConfigurationError(f"Rig config file not found: {path}")
    except tomllib.TOMLDecodeError as exc:
        raise ConfigurationError(f"Invalid TOML in {path}: {exc}") from exc

    if "rig" not in raw:
        raise ConfigurationError(
            f"{path}: missing top-level [rig] section"
        )

    try:
        return RigConfig.model_validate(raw["rig"])
    except Exception as exc:
        raise ConfigurationError(
            f"{path}: rig config validation failed — {exc}"
        ) from exc


__all__ = ["load_rig_config"]
