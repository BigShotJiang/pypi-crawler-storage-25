"""CruciHiL rig configuration — TOML loading and Pydantic validation.

Entry point:

    from crucihil.hal.config import load_rig_config
    config = load_rig_config("rigs/virtual.toml")
"""

from crucihil.hal.config.loader import load_rig_config
from crucihil.hal.config.schema import (
    CANInterfaceConfig,
    DefinitionsConfig,
    ECUConfig,
    EthernetInterfaceConfig,
    GPIOPinConfig,
    PowerRailConfig,
    RigConfig,
)

__all__ = [
    "load_rig_config",
    "RigConfig",
    "CANInterfaceConfig",
    "EthernetInterfaceConfig",
    "PowerRailConfig",
    "GPIOPinConfig",
    "ECUConfig",
    "DefinitionsConfig",
]
