"""Pydantic models for rig TOML configuration.

Validated at rig.connect() time — never at test runtime (R9).
A ConfigurationError raised here marks the test as 'blocked', not 'fail'.

TOML structure mirrored here (see rigs/virtual.toml for the canonical example):

    [rig]
    name         = "Virtual_Sim"
    platform     = "virtual"
    spec_version = "1.0"
    backend      = "virtual"

    [rig.can.can0]
    interface = "can0"
    bitrate   = 500000
    backend   = "virtual"

    [rig.ethernet.eth0]
    interface      = "eth0"
    ip             = "127.0.0.1"
    someip_backend = "python-someip"
    doip_backend   = "python-doip"

    [rig.power.ecu_main]
    backend = "virtual_power"
    default = "on"

    [rig.gpio]
    ignition_enable = { pin = 22, direction = "out", default = false }

    [rig.ecus.ecu_main]
    name            = "Virtual_ECU"
    logical_address = 0x0001
    transport       = "doip"
    doip_interface  = "eth0"
    power_rail      = "ecu_main"
    boot_timeout    = 0.1

    [rig.definitions]
    can_dbc = "defs/vehicle_can.dbc"
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class CANInterfaceConfig(BaseModel):
    """Config for a single CAN interface entry under [rig.can.<name>]."""

    interface: str          # OS interface name (e.g. "can0")
    bitrate: int            # nominal bitrate in bits/second
    fd: bool = False        # True for CAN-FD
    backend: str            # e.g. "virtual", "socketcan", "peak"

    @field_validator("bitrate")
    @classmethod
    def _bitrate_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError(f"bitrate must be positive, got {v}")
        return v


class EthernetInterfaceConfig(BaseModel):
    """Config for a single Ethernet interface entry under [rig.ethernet.<name>]."""

    interface: str          # OS interface name (e.g. "eth0")
    ip: str                 # local IP address to bind to
    someip_backend: str     # e.g. "python-someip", "vsomeip"
    doip_backend: str       # e.g. "python-doip"


class PowerRailConfig(BaseModel):
    """Config for a single power rail entry under [rig.power.<name>]."""

    backend: str                            # e.g. "virtual_power", "gpio_relay", "bench_psu"
    default: Literal["on", "off"] = "off"  # initial state on rig.connect()

    # gpio_relay backend fields
    gpio_pin: int | None = None

    # bench_psu backend fields
    port: str | None = None                 # serial port, e.g. "/dev/ttyUSB0"
    model: str | None = None               # e.g. "keysight_e3631a"


class GPIOPinConfig(BaseModel):
    """Config for a single GPIO pin entry under [rig.gpio]."""

    pin: int
    direction: Literal["in", "out"]
    default: bool = False               # initial state for output pins
    backend: str = "virtual_gpio"       # defaults to virtual; overridden for real HW


class ECUConfig(BaseModel):
    """Config for a single ECU entry under [rig.ecus.<name>]."""

    name: str                                           # human-readable name
    logical_address: int                                # UDS logical address
    transport: Literal["doip", "can_isotp"]
    doip_interface: str | None = None                   # ethernet interface key
    can_interface: str | None = None                    # CAN interface key (can_isotp)
    power_rail: str | None = None                       # power rail key
    boot_timeout: float = Field(default=5.0, gt=0.0)   # in TOML, never test code (R6)

    @model_validator(mode="after")
    def _transport_interface_required(self) -> ECUConfig:
        if self.transport == "doip" and self.doip_interface is None:
            raise ValueError(
                f"ECU with transport='doip' must specify doip_interface"
            )
        if self.transport == "can_isotp" and self.can_interface is None:
            raise ValueError(
                f"ECU with transport='can_isotp' must specify can_interface"
            )
        return self


class UDPInterfaceConfig(BaseModel):
    """Config for a UDP interface entry under [rig.udp.<name>].

    Phase 1 placeholder — virtual stub only.  Real UDP transport is Phase 2.
    """

    interface: str          # OS interface name (e.g. "eth0")
    ip: str                 # local IP to bind
    port: int = 0           # 0 = ephemeral
    backend: str = "virtual_udp"


class UDSConfig(BaseModel):
    """Config for the UDS diagnostic channel under [rig.uds].

    Phase 1 placeholder — virtual stub only.  Real UDS backends are Phase 2.
    UDS over DoIP is already handled by [rig.ethernet] + [rig.ecus].
    """

    backend: str = "virtual_uds"
    timeout: float = Field(default=2.0, gt=0.0)   # default request timeout in seconds


class DefinitionsConfig(BaseModel):
    """Bus definition files referenced in [rig.definitions]."""

    can_dbc: str | None = None      # path to CAN DBC file
    eth_dbc: str | None = None      # path to Ethernet (SOME/IP) DBC/descriptor file


class CloudConfig(BaseModel):
    """Optional cloud control plane connection config under [rig.cloud].

    If absent, the agent runs in local-only mode with no changes to behavior.

    First-boot auto-registration: set registration_token instead of api_key.
    The agent registers itself, stores the resulting api_key in
    ~/.crucihil/credentials.toml, and loads it automatically on every
    subsequent start.
    """

    url: str
    api_key: str = ""
    registration_token: str = ""  # used once; api_key is persisted after first boot


class RigConfig(BaseModel):
    """Top-level rig configuration — validated from raw["rig"] in the TOML file.

    This is the single source of truth for all hardware parameters.
    Tests never read this object — the framework resolves everything (R1).
    """

    name: str
    platform: str
    spec_version: str = "1.0"
    backend: Literal["hardware", "virtual"]

    # Per-interface sections — keys are the interface names used in TOML
    can: dict[str, CANInterfaceConfig] = Field(default_factory=dict)
    ethernet: dict[str, EthernetInterfaceConfig] = Field(default_factory=dict)
    power: dict[str, PowerRailConfig] = Field(default_factory=dict)
    gpio: dict[str, GPIOPinConfig] = Field(default_factory=dict)
    ecus: dict[str, ECUConfig] = Field(default_factory=dict)
    udp: dict[str, UDPInterfaceConfig] = Field(default_factory=dict)
    uds: UDSConfig | None = None
    definitions: DefinitionsConfig = Field(default_factory=DefinitionsConfig)
    cloud: CloudConfig | None = None

    @model_validator(mode="after")
    def _ecu_references_exist(self) -> RigConfig:
        """Validate that ECU interface/power references point to configured resources."""
        for ecu_name, ecu in self.ecus.items():
            if ecu.doip_interface and ecu.doip_interface not in self.ethernet:
                raise ValueError(
                    f"ECU '{ecu_name}' references doip_interface "
                    f"'{ecu.doip_interface}' which is not in [rig.ethernet]"
                )
            if ecu.can_interface and ecu.can_interface not in self.can:
                raise ValueError(
                    f"ECU '{ecu_name}' references can_interface "
                    f"'{ecu.can_interface}' which is not in [rig.can]"
                )
            if ecu.power_rail and ecu.power_rail not in self.power:
                raise ValueError(
                    f"ECU '{ecu_name}' references power_rail "
                    f"'{ecu.power_rail}' which is not in [rig.power]"
                )
        return self


__all__ = [
    "RigConfig",
    "CANInterfaceConfig",
    "EthernetInterfaceConfig",
    "PowerRailConfig",
    "GPIOPinConfig",
    "ECUConfig",
    "UDPInterfaceConfig",
    "UDSConfig",
    "DefinitionsConfig",
    "CloudConfig",
]
