"""CruciHiL exception hierarchy.

All exceptions raised by the framework, HAL, and backends are subclasses of
CruciHiLError. This makes it trivial to catch framework exceptions without
accidentally swallowing unrelated Python errors.

Hierarchy:

    CruciHiLError
    ├── BlockedError          — precondition not met; rig/setup issue
    ├── TestTimeoutError      — test exceeded its configured timeout
    ├── SetupError            — suite/test setup failed
    ├── TeardownError         — teardown failed (logged, does not change status)
    ├── ConfigurationError    — invalid TOML/YAML or missing required config
    ├── BackendError          — backend unavailable or unsupported operation
    └── HardwareError         — base for all bus/hardware errors
        ├── CANError
        │   └── CANTimeoutError
        ├── SOMEIPError
        │   └── SOMEIPTimeoutError
        ├── DoIPError
        │   └── DoIPNegativeResponseError
        ├── PowerError
        ├── GPIOError
        └── FlashError
"""

from __future__ import annotations


# ── Base ───────────────────────────────────────────────────────────────────────

class CruciHiLError(Exception):
    """Base for all CruciHiL exceptions."""


# ── Test execution ─────────────────────────────────────────────────────────────

class BlockedError(CruciHiLError):
    """Precondition not met — rig or setup issue.

    Marks the test as ``blocked``, not ``fail``.  A blocked result does NOT
    count against the pass rate and triggers a rig health alert.

    Use this when the rig itself cannot satisfy the precondition for the test
    (e.g. ECU did not boot, required service is unreachable).  Never raise
    BlockedError for a firmware assertion failure — that is a ``fail``.
    """


class TestTimeoutError(CruciHiLError):
    """Test exceeded its configured timeout."""


class SetupError(CruciHiLError):
    """Suite or test setup failed.

    Treated as ``blocked`` — the test never ran, so it cannot be ``fail``.
    """


class TeardownError(CruciHiLError):
    """Teardown failed.

    Logged and surfaced in the result, but does not change the test status.
    Teardown errors indicate a rig health concern, not a firmware defect.
    """


# ── Hardware ───────────────────────────────────────────────────────────────────

class HardwareError(CruciHiLError):
    """Base for all hardware-related errors."""


class CANError(HardwareError):
    """CAN bus error."""


class CANTimeoutError(CANError):
    """Expected CAN message or signal not received within timeout."""


class SOMEIPError(HardwareError):
    """SOME/IP protocol error."""


class SOMEIPTimeoutError(SOMEIPError):
    """Expected SOME/IP event not received within timeout."""


class DoIPError(HardwareError):
    """DoIP transport error."""


class DoIPNegativeResponseError(DoIPError):
    """ECU returned a UDS negative response (NRC).

    Attributes:
        nrc:        Negative Response Code (e.g. 0x22 = conditionsNotCorrect).
        service_id: UDS service ID that triggered the negative response.
    """

    def __init__(self, nrc: int, service_id: int, message: str = "") -> None:
        self.nrc = nrc
        self.service_id = service_id
        super().__init__(
            message or f"NRC 0x{nrc:02X} for service 0x{service_id:02X}"
        )


class PowerError(HardwareError):
    """Power rail error — voltage out of range, rail fault."""


class GPIOError(HardwareError):
    """GPIO error — direction mismatch, pin not in config, unexpected state."""


class FlashError(HardwareError):
    """Firmware flash failed."""


# ── Framework ──────────────────────────────────────────────────────────────────

class ConfigurationError(CruciHiLError):
    """Invalid rig TOML, YAML manifest, or missing required configuration.

    Raised at rig initialisation time (R9 — validate at startup, not runtime).
    A test that fails because of a config error is ``blocked``, not ``fail``.
    """


class BackendError(CruciHiLError):
    """Backend not available, failed to connect, or unsupported operation."""


# ── Public re-export ───────────────────────────────────────────────────────────

__all__ = [
    "CruciHiLError",
    # Test execution
    "BlockedError",
    "TestTimeoutError",
    "SetupError",
    "TeardownError",
    # Hardware
    "HardwareError",
    "CANError",
    "CANTimeoutError",
    "SOMEIPError",
    "SOMEIPTimeoutError",
    "DoIPError",
    "DoIPNegativeResponseError",
    "PowerError",
    "GPIOError",
    "FlashError",
    # Framework
    "ConfigurationError",
    "BackendError",
]
