"""CruciHiL result models.

These are the data structures returned to test code and persisted to storage.
All are plain dataclasses — no external dependencies beyond stdlib.

Key design rules baked in:
- FaultDescriptor is a plain dataclass (R4 — fault methods return descriptors,
  never coroutines).
- TestResult.status distinguishes 'blocked' from 'fail' — this is load-bearing
  for CI/CD pass rate calculations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


# ── Expect / assert results ────────────────────────────────────────────────────

@dataclass
class ExpectResult:
    """Returned by rig.can.expect(), rig.someip.expect(), and assert_stable().

    Never raises on condition failure — the caller asserts on .passed.
    """

    passed: bool
    value: Any                          # value when condition met, or last seen value on timeout
    elapsed: float                      # seconds from first observation to condition met
    samples: list[tuple[float, Any]]    # (timestamp, value) pairs observed during the wait
    signal: str                         # signal name, e.g. "EngineRPM" or "VehicleSpeed.Speed"
    condition: str                      # string repr of condition callable (for logging/storage)
    fail_msg: str | None                # caller-provided failure message
    interface: str                      # which bus/interface observed this signal


# ── Fault descriptor ───────────────────────────────────────────────────────────

@dataclass
class FaultDescriptor:
    """Plain dataclass returned by rig.fault.*() methods.

    Does NOT execute anything. rig.fault.inject() activates it.

    This is load-bearing: passing a coroutine to a context manager would
    execute it immediately, bypassing the injection lifecycle (R4).

    Attributes:
        fault_type:  Identifies which fault to activate (e.g. "can_dropout").
        params:      Fault parameters (arb_id, duration, interface, etc.).
        started_at:  Set by inject() when the fault is activated. None before.
        ended_at:    Set by inject().__aexit__ when the fault is deactivated.
    """

    fault_type: str
    params: dict[str, Any]
    started_at: float | None = None
    ended_at: float | None = None


# ── Test result ────────────────────────────────────────────────────────────────

@dataclass
class TestResult:
    """Written to local SQLite cache and synced to cloud after each test.

    Status semantics (the blocked/fail distinction is load-bearing):
        pass    — all assertions passed
        fail    — an assertion failed; firmware is sick; counts against pass rate
        blocked — precondition not met; rig is sick; does NOT count against pass rate
        error   — framework/infrastructure error; does NOT count against pass rate
        skip    — explicitly skipped (hardware unavailable)
    """

    test_id: str
    run_id: str
    suite_name: str
    status: Literal["pass", "fail", "blocked", "error", "skip"]
    duration: float                     # seconds
    started_at: float                   # Unix timestamp
    completed_at: float                 # Unix timestamp
    signals: dict[str, list[tuple[float, float]]] = field(default_factory=dict)
    # ^ recorded signal traces: signal_name → [(timestamp, value), ...]
    errors: list[str] = field(default_factory=list)
    logs: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    # ^ tags, hardware labels, YAML params injected at runtime


# ── Bus measurement results ────────────────────────────────────────────────────

@dataclass
class BusLoad:
    """Returned by rig.can.measure_load()."""

    utilisation: float      # 0.0 – 1.0
    frame_count: int
    error_count: int
    interface: str
    window: float           # measurement window in seconds


@dataclass
class CycleTiming:
    """Returned by rig.can.measure_cycle_time()."""

    message: str
    mean_ms: float
    min_ms: float
    max_ms: float
    jitter_ms: float        # max_ms - min_ms
    sample_count: int


# ── Simulation status ──────────────────────────────────────────────────────────

@dataclass
class MessageStatus:
    """Status of one message in the Bus Simulation Engine.

    Returned inside rig.sim.status().messages dict.
    """

    name: str
    active: bool
    period_ms: float
    last_tx: float | None   # Unix timestamp of last transmission, None if never sent
    tx_count: int
    transport: str          # "can" | "ethernet"


# ── Public re-export ───────────────────────────────────────────────────────────

__all__ = [
    "ExpectResult",
    "FaultDescriptor",
    "TestResult",
    "BusLoad",
    "CycleTiming",
    "MessageStatus",
]
