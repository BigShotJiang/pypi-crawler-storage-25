"""CruciHiL frame and protocol-data models.

Raw data structures passed between backends, namespaces, and test code.
All are plain dataclasses — no external dependencies.

R7 compliance: CANFrame carries frame_idx (monotonic integer) as the
canonical join key.  Never join CAN data on timestamp — duplicates are
routine on live buses.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ── CAN ────────────────────────────────────────────────────────────────────────

@dataclass
class CANFrame:
    """A single CAN (or CAN-FD) frame.

    Produced by the CAN backend on reception, or constructed by the namespace
    when encoding a DBC message for transmission.

    Attributes:
        arb_id:    Arbitration ID (11-bit or 29-bit extended).
        data:      Frame payload bytes (up to 8 for classic CAN, 64 for CAN-FD).
        timestamp: Seconds since test start (or epoch for offline logs).
        interface: Backend interface name, e.g. "can0".
        frame_idx: Monotonic integer assigned by the CAN namespace at
                   reception time.  Use as join key — never use timestamp (R7).
        fields:    Decoded signal values populated by the namespace after
                   DBC decoding.  Empty dict for raw frames.
    """

    arb_id: int
    data: bytes
    timestamp: float
    interface: str
    frame_idx: int = 0
    fields: dict[str, Any] = field(default_factory=dict)

    @property
    def raw(self) -> bytes:
        """Alias for .data — matches the API surface in RIG_INTERFACE_SPEC."""
        return self.data


# ── SOME/IP ────────────────────────────────────────────────────────────────────

@dataclass
class SOMEIPEvent:
    """A SOME/IP event notification received from a service.

    Attributes:
        service_id:   SOME/IP service identifier.
        event_id:     Event identifier within the service (0x8000+ range).
        payload:      Raw serialized payload bytes.
        timestamp:    Seconds since test start.
        instance_id:  Service instance identifier.
        eventgroup_id: Event group this event belongs to.
    """

    service_id: int
    event_id: int
    payload: bytes
    timestamp: float
    instance_id: int = 0
    eventgroup_id: int = 0


@dataclass
class SOMEIPServiceInfo:
    """Information about a discovered SOME/IP service.

    Returned by rig.someip.find_service().

    Attributes:
        service_id:  SOME/IP service identifier.
        instance_id: Service instance identifier.
        endpoint:    (ip, port) where the service is reachable.
        available:   True if the service is currently announcing itself.
    """

    service_id: int
    instance_id: int
    endpoint: tuple[str, int]
    available: bool


# ── DoIP ───────────────────────────────────────────────────────────────────────

@dataclass
class DoIPResponse:
    """Response to a UDS-over-DoIP request.

    Attributes:
        service_id: UDS service ID from the response (0x40 + request SID for
                    positive responses, 0x7F for negative).
        payload:    Response payload bytes (excludes service ID byte).
        positive:   True if the ECU returned a positive response.
        nrc:        Negative Response Code when positive=False.  None otherwise.
    """

    service_id: int
    payload: bytes
    positive: bool
    nrc: int | None = None


@dataclass
class DoIPEntity:
    """A DoIP entity discovered via vehicle announcement or entity status.

    Returned in the list from rig.doip.discover().

    Attributes:
        vin:             Vehicle Identification Number (17 chars).
        logical_address: ECU logical address (UDS target address).
        eid:             Entity identifier (6 bytes).
        gid:             Group identifier (6 bytes).
        ip:              IP address of the DoIP gateway.
        port:            UDP/TCP port (typically 13400).
    """

    vin: str
    logical_address: int
    eid: bytes
    gid: bytes
    ip: str
    port: int


@dataclass
class DoIPEntityStatus:
    """Response to a DoIP entity status request.

    Returned by rig.doip.entity_status().
    """

    node_type: int
    max_concurrent_sockets: int
    currently_open_sockets: int


# ── Public re-export ───────────────────────────────────────────────────────────

__all__ = [
    "CANFrame",
    "SOMEIPEvent",
    "SOMEIPServiceInfo",
    "DoIPResponse",
    "DoIPEntity",
    "DoIPEntityStatus",
]
