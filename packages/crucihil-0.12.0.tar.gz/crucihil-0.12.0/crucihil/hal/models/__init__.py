"""CruciHiL HAL models — results, frames, exceptions."""
