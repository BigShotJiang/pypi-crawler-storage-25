"""Rig — top-level fixture injected into every test function.

The Rig is the single object that test code receives.  It exposes namespaces
(rig.can, rig.sim, rig.fault, ...) and manages the full lifecycle of all
backends and the BSE.

Test code never constructs a Rig.  The framework creates and injects it:

    async def test_engine_startup(rig: Rig):
        await rig.can.send(message="EngineControl", fields={"throttle": 50})
        result = await rig.can.expect("EngineData.RPM", lambda v: v > 800, timeout=2.0)
        assert result.passed, result.fail_msg

Hardware details (interface names, backends, DBC paths) live in the TOML
config — never in test code (R1).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from crucihil.hal.backends.registry import (
    resolve_can_backend,
    resolve_doip_backend,
    resolve_gpio_backend,
    resolve_power_backend,
    resolve_someip_backend,
)
from crucihil.hal.backends.virtual.gpio import VirtualGPIOBackend
from crucihil.hal.backends.virtual.power import VirtualPowerBackend
from crucihil.hal.bse.engine import BusSimEngine
from crucihil.hal.config.loader import load_rig_config
from crucihil.hal.config.schema import RigConfig
from crucihil.hal.namespaces.can import CANNamespace
from crucihil.hal.namespaces.ecu import ECUNamespace, ECUProxy
from crucihil.hal.namespaces.fault import FaultNamespace
from crucihil.hal.namespaces.sim import SimNamespace
from crucihil.hal.models.exceptions import ConfigurationError, SetupError, TeardownError

if TYPE_CHECKING:
    from crucihil.hal.backends.base import (
        AbstractCANBackend,
        AbstractDoIPBackend,
        AbstractSOMEIPBackend,
    )

_log = logging.getLogger(__name__)


class Rig:
    """Hardware-in-the-Loop test fixture.

    Attributes:
        can:   CAN bus send / receive / expect / record API.
        sim:   Bus simulation control (set signal values, start/stop messages).
        fault: Fault injection (can_dropout, power_cycle, gpio_stuck, ...).
        config: The loaded RigConfig (read-only metadata — not for test logic).
    """

    def __init__(self, config: RigConfig, config_path: Path) -> None:
        self.config = config
        self._config_path = config_path

        # Populated during connect()
        self._can_backends: dict[str, AbstractCANBackend] = {}
        self._someip_backends: dict[str, AbstractSOMEIPBackend] = {}
        self._doip_backends: dict[str, AbstractDoIPBackend] = {}
        self._power_backends: dict[str, VirtualPowerBackend] = {}
        self._gpio_backends: dict[str, VirtualGPIOBackend] = {}

        self._bse: BusSimEngine | None = None

        # Public namespace attributes — set during connect()
        self.can: CANNamespace
        self.sim: SimNamespace
        self.fault: FaultNamespace
        self.ecu: ECUNamespace

        self._connected = False

    # ── Factory ────────────────────────────────────────────────────────────────

    @classmethod
    def from_toml(cls, path: str | Path) -> "Rig":
        """Create a Rig from a TOML config file.

        Args:
            path: Path to the rig .toml file.

        Raises:
            ConfigurationError: On invalid TOML or schema validation failure.
        """
        path = Path(path)
        config = load_rig_config(path)
        return cls(config, path)

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Initialise all backends, load the DBC, and build the namespaces.

        Must be called before any test code runs.  Raises SetupError on
        failure — this marks the test as 'blocked', not 'fail' (R9 + spec).
        """
        if self._connected:
            return
        try:
            await self._setup_backends()
            await self._setup_bse()
            self._setup_namespaces()
            self._connected = True
        except Exception as exc:
            raise SetupError(f"Rig.connect() failed: {exc}") from exc

    async def disconnect(self) -> None:
        """Tear down all backends and cancel BSE tasks.

        Always runs, even if some teardown steps fail (R8).
        """
        errors: list[str] = []

        if self._bse:
            try:
                await self._bse.stop()
            except Exception as exc:
                errors.append(f"BSE stop: {exc}")

        for name, backend in list(self._can_backends.items()):
            try:
                await backend.disconnect()
            except Exception as exc:
                errors.append(f"CAN {name}: {exc}")

        for name, backend in list(self._someip_backends.items()):
            try:
                await backend.disconnect()
            except Exception as exc:
                errors.append(f"SOME/IP {name}: {exc}")

        for name, backend in list(self._doip_backends.items()):
            try:
                await backend.disconnect()
            except Exception as exc:
                errors.append(f"DoIP {name}: {exc}")

        for name, backend in list(self._power_backends.items()):
            try:
                await backend.disconnect()
            except Exception as exc:
                errors.append(f"Power {name}: {exc}")

        for name, backend in list(self._gpio_backends.items()):
            try:
                await backend.disconnect()
            except Exception as exc:
                errors.append(f"GPIO {name}: {exc}")

        self._connected = False

        if errors:
            raise TeardownError(
                f"Rig.disconnect() had {len(errors)} error(s): {'; '.join(errors)}"
            )

    # ── Async context manager ──────────────────────────────────────────────────

    async def __aenter__(self) -> "Rig":
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> bool:
        await self.disconnect()
        return False    # R8 — never suppress exceptions

    # ── Private setup ──────────────────────────────────────────────────────────

    async def _setup_backends(self) -> None:
        """Instantiate and connect all backends specified in the TOML config."""
        # CAN backends
        for iface_name, iface_cfg in self.config.can.items():
            cls = resolve_can_backend(iface_cfg.backend)
            backend = cls()
            await backend.connect(
                interface=iface_cfg.interface,
                bitrate=iface_cfg.bitrate,
                fd=iface_cfg.fd,
            )
            self._can_backends[iface_name] = backend
            _log.debug("CAN backend '%s' connected (%s)", iface_name, iface_cfg.backend)

        # Ethernet (SOME/IP + DoIP) backends
        for iface_name, iface_cfg in self.config.ethernet.items():
            someip_cls = resolve_someip_backend(iface_cfg.someip_backend)
            someip = someip_cls()
            await someip.connect(interface=iface_cfg.interface, ip=iface_cfg.ip)
            self._someip_backends[iface_name] = someip

            doip_cls = resolve_doip_backend(iface_cfg.doip_backend)
            doip = doip_cls()
            # Connect the DoIP session.  The tester source address is fixed
            # at 0x0E00 per ISO 13400-2.  Per-ECU target addresses are used
            # in uds_request() calls, not here.
            await doip.connect(
                ip=iface_cfg.ip,
                port=13400,
                source_address=0x0E00,
                timeout=5.0,
            )
            self._doip_backends[iface_name] = doip
            _log.debug("Ethernet backends '%s' connected", iface_name)

        # Power backends
        for rail_name, rail_cfg in self.config.power.items():
            cls = resolve_power_backend(rail_cfg.backend)
            # Pass default on/off state to virtual backend
            if issubclass(cls, VirtualPowerBackend):
                backend = cls(default=rail_cfg.default)
            else:
                backend = cls()
            await backend.connect()
            self._power_backends[rail_name] = backend
            _log.debug("Power backend '%s' connected", rail_name)

        # GPIO — one backend instance per unique backend type
        gpio_instances: dict[str, VirtualGPIOBackend] = {}
        for pin_name, pin_cfg in self.config.gpio.items():
            if pin_cfg.backend not in gpio_instances:
                cls = resolve_gpio_backend(pin_cfg.backend)
                instance = cls()
                await instance.connect()
                gpio_instances[pin_cfg.backend] = instance
            gpio = gpio_instances[pin_cfg.backend]
            await gpio.setup_pin(
                name=pin_name,
                pin=pin_cfg.pin,
                direction=pin_cfg.direction,
                default=pin_cfg.default,
            )

        # Expose GPIO backends by backend-type key (one per type)
        self._gpio_backends = gpio_instances

    async def _setup_bse(self) -> None:
        """Create and start the Bus Simulation Engine."""
        self._bse = BusSimEngine(
            definitions=self.config.definitions,
            can_backends=self._can_backends,
            # base_dir defaults to Path.cwd() — project root when running crucihil run
        )
        await self._bse.start()

    def _setup_namespaces(self) -> None:
        """Create namespace objects and attach them as rig attributes."""
        assert self._bse is not None

        self.can = CANNamespace(
            backends=self._can_backends,
            signal_store=self._bse.signal_store,
            db=self._bse.db,
            router=self._bse.router,
        )
        self.sim = SimNamespace(engine=self._bse)
        self.fault = FaultNamespace(
            can_backends=self._can_backends,
            power_backends=self._power_backends,  # type: ignore[arg-type]
            gpio_backends=self._gpio_backends,    # type: ignore[arg-type]
        )
        self.ecu = self._setup_ecu_namespace()


    def _setup_ecu_namespace(self) -> ECUNamespace:
        """Create ECUProxy objects for every ECU configured in the TOML."""
        proxies: dict[str, ECUProxy] = {}
        for ecu_name, ecu_cfg in self.config.ecus.items():
            if ecu_cfg.transport == "doip" and ecu_cfg.doip_interface:
                backend = self._doip_backends.get(ecu_cfg.doip_interface)
                if backend is not None:
                    proxies[ecu_name] = ECUProxy(
                        ecu_name=ecu_name,
                        ecu_config=ecu_cfg,
                        doip_backend=backend,
                    )
        return ECUNamespace(proxies)


__all__ = ["Rig"]
