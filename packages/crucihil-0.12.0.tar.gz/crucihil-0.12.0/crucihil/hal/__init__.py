"""CruciHiL HAL — Layer 2: Hardware Abstraction."""
