"""rig.ecu namespace — ECU lifecycle and firmware flash API.

Provides rig.ecu.<name>.flash() for UDS-based firmware download via DoIP.
The UDS upload sequence follows ISO 14229-1:
    0x34 RequestDownload  → server acknowledges, returns maxBlockLen
    0x36 TransferData     → repeated until all blocks sent
    0x37 RequestTransferExit → server confirms completion

Usage:
    result = await rig.ecu.ecu_main.flash(firmware_path)
    assert result.success, result.error

Test code never specifies IP addresses or transport — those come from TOML (R1).
"""

from __future__ import annotations

import asyncio
import logging
import struct
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from crucihil.hal.models.exceptions import DoIPError, FlashError
from crucihil.hal.models.frames import DoIPResponse

if TYPE_CHECKING:
    from crucihil.hal.backends.base import AbstractDoIPBackend
    from crucihil.hal.config.schema import ECUConfig

_log = logging.getLogger(__name__)

# UDS service IDs
_SID_REQUEST_DOWNLOAD = 0x34
_SID_TRANSFER_DATA    = 0x36
_SID_TRANSFER_EXIT    = 0x37
_SID_ECU_RESET        = 0x11


@dataclass
class FlashResult:
    """Returned by ECUProxy.flash()."""
    success: bool
    duration: float             # seconds
    bytes_transferred: int
    block_count: int
    error: str | None = None


class ECUProxy:
    """Represents a single ECU accessible via DoIP.

    Created by ECUNamespace — one per configured ECU in the TOML.
    Test code references it as rig.ecu.<name> (e.g. rig.ecu.ecu_main).
    """

    def __init__(
        self,
        ecu_name: str,
        ecu_config: "ECUConfig",
        doip_backend: "AbstractDoIPBackend",
    ) -> None:
        self._name = ecu_name
        self._cfg = ecu_config
        self._doip = doip_backend

    async def flash(
        self,
        firmware_path: str | Path,
        memory_address: int = 0x00000000,
        compression: int = 0x00,
        encrypting: int = 0x00,
        block_size: int | None = None,
        timeout: float | None = None,
    ) -> FlashResult:
        """Flash a firmware image to the ECU via UDS over DoIP.

        Implements the standard UDS download sequence:
            0x34 RequestDownload
            0x36 TransferData  (repeated for each block)
            0x37 RequestTransferExit

        Args:
            firmware_path:   Path to the binary firmware image.
            memory_address:  Target flash start address (default 0x0).
            compression:     Compression method nibble for 0x34 (default 0x00 = none).
            encrypting:      Encrypting method nibble for 0x34 (default 0x00 = none).
            block_size:      Bytes per transfer block.  If None, uses maxBlockLen
                             returned by the ECU in the 0x34 response.
            timeout:         Per-UDS-request timeout in seconds.  Defaults to
                             rig TOML boot_timeout as a proxy for flash timeout.

        Returns:
            FlashResult with success=True on completion.

        Raises:
            FlashError: On UDS NRC, timeout, or transport error.
        """
        firmware_path = Path(firmware_path)
        if not firmware_path.exists():
            raise FlashError(f"Firmware file not found: {firmware_path}")

        firmware = firmware_path.read_bytes()
        target = self._cfg.logical_address
        if timeout is None:
            timeout = self._cfg.boot_timeout

        start = time.monotonic()
        _log.info(
            "Flashing ECU '%s' (0x%04X) — %d bytes from %s",
            self._name, target, len(firmware), firmware_path.name,
        )

        try:
            # ── Step 1: RequestDownload (0x34) ─────────────────────────────────
            max_block_len = await self._request_download(
                target, memory_address, len(firmware),
                compression, encrypting, timeout,
            )
            effective_block = block_size or max_block_len

            # ── Step 2: TransferData (0x36) ────────────────────────────────────
            block_count = await self._transfer_data(
                target, firmware, effective_block, timeout,
            )

            # ── Step 3: RequestTransferExit (0x37) ─────────────────────────────
            await self._request_transfer_exit(target, timeout)

        except (FlashError, DoIPError) as exc:
            elapsed = time.monotonic() - start
            return FlashResult(
                success=False,
                duration=elapsed,
                bytes_transferred=0,
                block_count=0,
                error=str(exc),
            )

        elapsed = time.monotonic() - start
        _log.info(
            "Flash complete: ECU '%s' — %d blocks, %.1fs",
            self._name, block_count, elapsed,
        )
        return FlashResult(
            success=True,
            duration=elapsed,
            bytes_transferred=len(firmware),
            block_count=block_count,
        )

    # ── UDS sequence steps ─────────────────────────────────────────────────────

    async def _request_download(
        self,
        target: int,
        address: int,
        data_length: int,
        compression: int,
        encrypting: int,
        timeout: float,
    ) -> int:
        """Send 0x34 RequestDownload and return maxBlockLen from the ECU."""
        data_format = (compression & 0x0F) << 4 | (encrypting & 0x0F)
        # Address and length length nibbles (each 4 bytes → nibble = 0x44)
        addr_and_len_format = 0x44
        payload = bytes([
            _SID_REQUEST_DOWNLOAD,
            data_format,
            addr_and_len_format,
        ]) + struct.pack(">I", address) + struct.pack(">I", data_length)

        resp = await self._doip.uds_request(target, payload, timeout)
        _check_positive(resp, _SID_REQUEST_DOWNLOAD)

        # Response: [0x74, lengthOfMaxBlockLen_nibble, maxBlockLen bytes...]
        # If the response payload is empty (e.g. virtual backend), use a
        # conservative default of 128 bytes so flash still works in CI.
        _DEFAULT_BLOCK = 128
        if len(resp.payload) == 0:
            _log.debug("0x34 response has no payload — using default maxBlockLen=%d", _DEFAULT_BLOCK)
            return _DEFAULT_BLOCK
        if len(resp.payload) < 2:
            _log.debug("0x34 response short — using default maxBlockLen=%d", _DEFAULT_BLOCK)
            return _DEFAULT_BLOCK
        len_nibble = (resp.payload[0] >> 4) & 0x0F
        if len_nibble == 0 or len(resp.payload) < 1 + len_nibble:
            _log.debug("0x34 maxBlockLen nibble invalid — using default=%d", _DEFAULT_BLOCK)
            return _DEFAULT_BLOCK
        max_block_bytes = resp.payload[1 : 1 + len_nibble]
        max_block_len = int.from_bytes(max_block_bytes, "big")
        _log.debug("0x34 OK — maxBlockLen=%d", max_block_len)
        return max_block_len

    async def _transfer_data(
        self,
        target: int,
        firmware: bytes,
        block_size: int,
        timeout: float,
    ) -> int:
        """Send all 0x36 TransferData blocks.  Returns number of blocks sent."""
        offset = 0
        block_index = 1
        while offset < len(firmware):
            chunk = firmware[offset : offset + block_size]
            payload = bytes([_SID_TRANSFER_DATA, block_index & 0xFF]) + chunk
            resp = await self._doip.uds_request(target, payload, timeout)
            _check_positive(resp, _SID_TRANSFER_DATA)
            offset += len(chunk)
            block_index += 1
            _log.debug(
                "0x36 block %d/%d sent (%d bytes)",
                block_index - 1,
                (len(firmware) + block_size - 1) // block_size,
                len(chunk),
            )
        return block_index - 1

    async def _request_transfer_exit(self, target: int, timeout: float) -> None:
        """Send 0x37 RequestTransferExit and verify positive response."""
        resp = await self._doip.uds_request(
            target, bytes([_SID_TRANSFER_EXIT]), timeout
        )
        _check_positive(resp, _SID_TRANSFER_EXIT)
        _log.debug("0x37 TransferExit OK")

    async def reset(
        self,
        reset_type: int = 0x01,
        timeout: float = 2.0,
    ) -> None:
        """Send 0x11 ECUReset and wait for the ECU to restart.

        Args:
            reset_type: 0x01 = hardReset, 0x02 = keyOffOnReset, 0x03 = softReset.
            timeout:    Seconds to wait for a response before the ECU stops responding.
        """
        try:
            await self._doip.uds_request(
                self._cfg.logical_address,
                bytes([_SID_ECU_RESET, reset_type]),
                timeout,
            )
        except DoIPError:
            pass  # ECU may not send a response before resetting — expected


def _check_positive(resp: DoIPResponse, service_id: int) -> None:
    if not resp.positive:
        nrc = resp.nrc or 0
        raise FlashError(
            f"UDS service 0x{service_id:02X} returned NRC 0x{nrc:02X}"
        )


class ECUNamespace:
    """Provides rig.ecu.<name> access to individual ECUProxy objects.

    Attribute access (rig.ecu.ecu_main) resolves to the matching ECUProxy.
    Created by the Rig during connect(); test code never instantiates this.
    """

    def __init__(self, proxies: dict[str, ECUProxy]) -> None:
        self._proxies = proxies
        for name, proxy in proxies.items():
            setattr(self, name, proxy)

    def __getattr__(self, name: str) -> ECUProxy:
        try:
            return self._proxies[name]
        except KeyError:
            raise AttributeError(
                f"rig.ecu has no ECU named '{name}'. "
                f"Configured ECUs: {sorted(self._proxies)}"
            )


__all__ = ["ECUNamespace", "ECUProxy", "FlashResult"]
