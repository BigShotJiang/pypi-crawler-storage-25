"""rig.can namespace — the CAN bus API surface for test code.

All methods accept signal names as "MessageName.SignalName" (R1).
No hardware details (interface names, backend types) appear in test code.
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from typing import Any, Callable, TYPE_CHECKING

from crucihil.hal.bse.signal_store import SignalStore
from crucihil.hal.models.exceptions import CANTimeoutError, BlockedError
from crucihil.hal.models.frames import CANFrame
from crucihil.hal.models.results import BusLoad, CycleTiming, ExpectResult

if TYPE_CHECKING:
    import cantools.database
    from crucihil.hal.backends.base import AbstractCANBackend
    from crucihil.hal.bse.router import MessageRouter


class CANNamespace:
    """Provides rig.can.*  methods to test code.

    Created by the Rig; test code never instantiates this directly.
    """

    def __init__(
        self,
        backends: dict[str, "AbstractCANBackend"],
        signal_store: SignalStore,
        db: "cantools.database.Database | None",
        router: "MessageRouter",
        primary_interface: str = "",
    ) -> None:
        self._backends = backends
        self._store = signal_store
        self._db = db
        self._router = router
        self._primary = primary_interface or (min(backends) if backends else "")
        self._frame_counter: int = 0
        # arb_id → list of asyncio.Queue for receive() waiters
        self._receive_queues: defaultdict[int, list[asyncio.Queue]] = defaultdict(list)
        # Register our frame listener on every backend
        for backend in backends.values():
            backend.add_listener(self._on_frame)

    # ── Send ───────────────────────────────────────────────────────────────────

    async def send(
        self,
        message: str,
        fields: dict[str, Any],
        interface: str | None = None,
    ) -> None:
        """Encode and send a DBC message by name.

        Args:
            message:   DBC message name (e.g. "EngineControl").
            fields:    Signal name → physical value (e.g. {"throttle": 50}).
            interface: CAN interface name.  Defaults to the primary interface.

        Raises:
            BlockedError:  If the DBC is not loaded or the message is unknown.
            CANTimeoutError: On backend send failure.
        """
        if self._db is None:
            raise BlockedError("No DBC loaded — cannot encode message by name")
        try:
            msg_obj = self._db.get_message_by_name(message)
        except KeyError:
            raise BlockedError(f"Unknown DBC message: {message!r}") from None

        data = bytes(msg_obj.encode(fields))
        backend = self._resolve_backend(interface or self._primary)
        await backend.send(msg_obj.frame_id, data)

    async def send_raw(
        self,
        arb_id: int,
        data: bytes,
        interface: str | None = None,
    ) -> None:
        """Send a raw CAN frame without DBC encoding.

        Args:
            arb_id:    Arbitration ID.
            data:      Raw payload bytes.
            interface: CAN interface name.  Defaults to primary.
        """
        backend = self._resolve_backend(interface or self._primary)
        await backend.send(arb_id, data)

    # ── Receive ────────────────────────────────────────────────────────────────

    async def receive(
        self,
        arb_id: int,
        timeout: float = 1.0,
        interface: str | None = None,
    ) -> CANFrame:
        """Wait for a specific CAN frame and return it decoded.

        Args:
            arb_id:  Arbitration ID to wait for.
            timeout: Seconds before CANTimeoutError is raised.

        Returns:
            CANFrame with .fields populated from DBC decode if DB is loaded.

        Raises:
            CANTimeoutError: If no matching frame arrives within timeout.
        """
        q: asyncio.Queue[CANFrame] = asyncio.Queue()
        self._receive_queues[arb_id].append(q)
        try:
            return await asyncio.wait_for(q.get(), timeout=timeout)
        except asyncio.TimeoutError:
            raise CANTimeoutError(
                f"Timeout waiting for arb_id=0x{arb_id:X} after {timeout}s"
            ) from None
        finally:
            try:
                self._receive_queues[arb_id].remove(q)
            except ValueError:
                pass

    async def receive_raw(
        self,
        arb_id: int,
        timeout: float = 1.0,
        interface: str | None = None,
    ) -> CANFrame:
        """Wait for a raw CAN frame (no DBC decoding)."""
        return await self.receive(arb_id, timeout, interface)

    # ── Expect / assert ────────────────────────────────────────────────────────

    async def expect(
        self,
        signal: str,
        condition: Callable[[float], bool],
        timeout: float = 1.0,
        fail_msg: str | None = None,
    ) -> ExpectResult:
        """Poll the signal store until condition is True or timeout expires.

        Args:
            signal:    "MessageName.SignalName"
            condition: Callable that receives the current value and returns bool.
            timeout:   Seconds before the result is marked failed.
            fail_msg:  Optional message to surface in the result on failure.

        Returns:
            ExpectResult — never raises on condition failure.
            The caller does: assert result.passed, result.fail_msg
        """
        start = time.monotonic()
        samples: list[tuple[float, float]] = []
        interface = "can"

        try:
            meta = self._store.meta(signal)
            interface = meta.transport
        except KeyError:
            return ExpectResult(
                passed=False,
                value=None,
                elapsed=0.0,
                samples=[],
                signal=signal,
                condition=repr(condition),
                fail_msg=fail_msg or f"Unknown signal {signal!r}",
                interface=interface,
            )

        poll_interval = 0.005   # 5 ms polling — fast enough for 10 ms CAN messages
        last_value: float = 0.0

        while True:
            elapsed = time.monotonic() - start
            try:
                val = self._store.get(signal)
            except KeyError:
                break

            last_value = val
            samples.append((elapsed, val))

            if condition(val):
                return ExpectResult(
                    passed=True,
                    value=val,
                    elapsed=elapsed,
                    samples=samples,
                    signal=signal,
                    condition=repr(condition),
                    fail_msg=None,
                    interface=interface,
                )

            if elapsed >= timeout:
                break

            await asyncio.sleep(poll_interval)

        return ExpectResult(
            passed=False,
            value=last_value,
            elapsed=time.monotonic() - start,
            samples=samples,
            signal=signal,
            condition=repr(condition),
            fail_msg=fail_msg or f"Signal {signal!r} did not meet condition within {timeout}s",
            interface=interface,
        )

    async def assert_stable(
        self,
        signal: str,
        tolerance: float,
        window: float = 0.1,
        timeout: float = 1.0,
        fail_msg: str | None = None,
    ) -> ExpectResult:
        """Assert a signal stays within ±tolerance for a continuous window.

        Args:
            signal:    "MessageName.SignalName"
            tolerance: Maximum allowed deviation from the first observed value.
            window:    Continuous observation window in seconds.
            timeout:   Total time to wait for the stable window to appear.
        """
        start = time.monotonic()
        samples: list[tuple[float, float]] = []
        poll = 0.005
        interface = "can"

        try:
            meta = self._store.meta(signal)
            interface = meta.transport
        except KeyError:
            return ExpectResult(
                passed=False, value=None, elapsed=0.0, samples=[],
                signal=signal, condition=f"stable±{tolerance}",
                fail_msg=fail_msg or f"Unknown signal {signal!r}",
                interface=interface,
            )

        window_start: float | None = None
        window_base: float | None = None

        while True:
            elapsed = time.monotonic() - start
            val = self._store.get(signal)
            samples.append((elapsed, val))

            if window_base is None:
                window_base = val
                window_start = elapsed
            elif abs(val - window_base) > tolerance:
                # Drift detected — reset window
                window_base = val
                window_start = elapsed
            elif elapsed - window_start >= window:  # type: ignore[operator]
                return ExpectResult(
                    passed=True, value=val, elapsed=elapsed, samples=samples,
                    signal=signal, condition=f"stable±{tolerance}",
                    fail_msg=None, interface=interface,
                )

            if elapsed >= timeout:
                break
            await asyncio.sleep(poll)

        return ExpectResult(
            passed=False, value=self._store.get(signal), elapsed=time.monotonic() - start,
            samples=samples, signal=signal, condition=f"stable±{tolerance}",
            fail_msg=fail_msg or f"Signal {signal!r} not stable within ±{tolerance} over {window}s",
            interface=interface,
        )

    # ── Record ─────────────────────────────────────────────────────────────────

    async def record(
        self,
        signals: list[str],
        duration: float,
    ) -> dict[str, list[tuple[float, float]]]:
        """Record signal values over a duration.

        Returns:
            signal_name → [(elapsed_s, value), ...]
        """
        results: dict[str, list[tuple[float, float]]] = {s: [] for s in signals}
        start = time.monotonic()
        poll = 0.005
        while True:
            elapsed = time.monotonic() - start
            for sig in signals:
                try:
                    results[sig].append((elapsed, self._store.get(sig)))
                except KeyError:
                    pass
            if elapsed >= duration:
                break
            await asyncio.sleep(poll)
        return results

    # ── Bus health ─────────────────────────────────────────────────────────────

    async def measure_load(
        self,
        interface: str | None = None,
        window: float = 1.0,
    ) -> BusLoad:
        """Measure CAN bus load over a time window.

        Virtual backend always returns 0 load (no real bit-time counting).
        """
        iface = interface or self._primary
        return BusLoad(
            utilisation=0.0,
            frame_count=0,
            error_count=0,
            interface=iface,
            window=window,
        )

    async def measure_cycle_time(
        self,
        message: str,
        samples: int = 10,
        timeout: float = 5.0,
    ) -> CycleTiming:
        """Measure the real cycle time of a CAN message by observing N frames.

        Raises:
            BlockedError: If the DBC is not loaded or the message is unknown.
            CANTimeoutError: If fewer than 2 frames arrive within timeout.
        """
        if self._db is None:
            raise BlockedError("No DBC loaded")
        try:
            msg_obj = self._db.get_message_by_name(message)
        except KeyError:
            raise BlockedError(f"Unknown message: {message!r}") from None

        timestamps: list[float] = []
        deadline = time.monotonic() + timeout

        while len(timestamps) < samples and time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            try:
                frame = await self.receive(msg_obj.frame_id, timeout=min(remaining, 1.0))
                timestamps.append(frame.timestamp)
            except CANTimeoutError:
                break

        if len(timestamps) < 2:
            raise CANTimeoutError(
                f"Fewer than 2 frames of {message!r} received within {timeout}s"
            )

        intervals = [
            (timestamps[i + 1] - timestamps[i]) * 1000
            for i in range(len(timestamps) - 1)
        ]
        return CycleTiming(
            message=message,
            mean_ms=sum(intervals) / len(intervals),
            min_ms=min(intervals),
            max_ms=max(intervals),
            jitter_ms=max(intervals) - min(intervals),
            sample_count=len(intervals),
        )

    # ── Internal ───────────────────────────────────────────────────────────────

    async def _on_frame(self, frame: CANFrame) -> None:
        """Backend listener — assigns frame_idx, decodes, delivers to waiters."""
        self._frame_counter += 1
        frame.frame_idx = self._frame_counter

        # Decode into frame.fields if DBC is available
        if self._db is not None:
            try:
                msg_obj = self._db.get_message_by_frame_id(frame.arb_id)
                frame.fields = dict(msg_obj.decode(frame.data, decode_choices=False))
            except (KeyError, Exception):
                pass

        # Deliver to any receive() waiters for this arb_id
        for q in list(self._receive_queues.get(frame.arb_id, [])):
            await q.put(frame)

    def _resolve_backend(self, interface: str) -> "AbstractCANBackend":
        if interface not in self._backends:
            raise BlockedError(
                f"No CAN backend for interface {interface!r}. "
                f"Available: {sorted(self._backends)}"
            )
        return self._backends[interface]


__all__ = ["CANNamespace"]
