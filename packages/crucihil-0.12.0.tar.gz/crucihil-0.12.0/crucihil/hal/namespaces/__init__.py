"""HAL namespaces — rig.can, rig.sim, rig.someip, rig.fault, etc.

Namespaces are the user-facing API surface injected into test functions as
attributes of the Rig object.  They wrap backends + BSE with the higher-level
send/expect/assert_stable/record API defined in RIG_INTERFACE_SPEC.md.
"""
