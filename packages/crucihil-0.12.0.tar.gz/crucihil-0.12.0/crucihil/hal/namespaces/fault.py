"""rig.fault namespace — fault injection API for test code.

Fault methods return FaultDescriptors — they never execute anything (R4).
rig.fault.inject() is the only entry point that activates a fault.

Usage:

    async with rig.fault.inject(rig.fault.can_dropout(arb_id=0x100, duration=2.0)):
        await asyncio.sleep(2.0)
    # Fault removed, bus restored

WRONG (executes immediately, bypasses lifecycle):
    await rig.fault.can_dropout(...)    # TypeError — not a coroutine
"""

from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, AsyncIterator

from crucihil.hal.models.results import FaultDescriptor

if TYPE_CHECKING:
    from crucihil.hal.backends.base import AbstractCANBackend, AbstractPowerBackend, AbstractGPIOBackend


class FaultNamespace:
    """Provides rig.fault.*  methods to test code.

    Created by the Rig; test code never instantiates this directly.
    """

    def __init__(
        self,
        can_backends: "dict[str, AbstractCANBackend]",
        power_backends: "dict[str, AbstractPowerBackend]",
        gpio_backends: "dict[str, AbstractGPIOBackend]",
    ) -> None:
        self._can = can_backends
        self._power = power_backends
        self._gpio = gpio_backends

    # ── Descriptor factories (R4 — return descriptors, never coroutines) ───────

    def can_dropout(
        self,
        arb_id: int,
        duration: float,
        interface: str | None = None,
    ) -> FaultDescriptor:
        """Simulate CAN frame dropout — suppress TX and RX of arb_id."""
        return FaultDescriptor(
            fault_type="can_dropout",
            params={"arb_id": arb_id, "duration": duration, "interface": interface},
        )

    def can_noise(
        self,
        arb_id: int,
        bit_error_rate: float = 0.01,
        interface: str | None = None,
    ) -> FaultDescriptor:
        """Inject random bit errors into a specific CAN message."""
        return FaultDescriptor(
            fault_type="can_noise",
            params={"arb_id": arb_id, "bit_error_rate": bit_error_rate, "interface": interface},
        )

    def power_cycle(
        self,
        rail: str,
        off_duration: float = 0.1,
    ) -> FaultDescriptor:
        """Power-cycle a rail: off for off_duration seconds, then on."""
        return FaultDescriptor(
            fault_type="power_cycle",
            params={"rail": rail, "off_duration": off_duration},
        )

    def gpio_stuck(
        self,
        pin: str,
        level: bool,
        duration: float,
    ) -> FaultDescriptor:
        """Force a GPIO input pin to a stuck level for duration seconds."""
        return FaultDescriptor(
            fault_type="gpio_stuck",
            params={"pin": pin, "level": level, "duration": duration},
        )

    def voltage_drop(
        self,
        rail: str,
        voltage: float,
        duration: float,
    ) -> FaultDescriptor:
        """Drop a power rail to a specific voltage for duration seconds."""
        return FaultDescriptor(
            fault_type="voltage_drop",
            params={"rail": rail, "voltage": voltage, "duration": duration},
        )

    # ── Injection context manager ──────────────────────────────────────────────

    @asynccontextmanager
    async def inject(self, descriptor: FaultDescriptor) -> AsyncIterator[FaultDescriptor]:
        """Activate a fault descriptor and deactivate it on exit.

        Always deactivates, even if the body raises (R8).

        Usage:
            async with rig.fault.inject(rig.fault.can_dropout(0x100, 2.0)) as fd:
                await asyncio.sleep(2.0)
                # fd.started_at is set
            # fd.ended_at is set, fault removed
        """
        descriptor.started_at = time.monotonic()
        await self._activate(descriptor)
        try:
            yield descriptor
        finally:
            # R8 — __aexit__ returns False (never suppresses exceptions)
            await self._deactivate(descriptor)
            descriptor.ended_at = time.monotonic()

    # ── Activation / deactivation ──────────────────────────────────────────────

    async def _activate(self, d: FaultDescriptor) -> None:
        ft = d.fault_type
        p = d.params

        if ft == "can_dropout":
            arb_id = p["arb_id"]
            target_iface = p.get("interface")
            for iface_name, backend in self._can.items():
                if target_iface and iface_name != target_iface:
                    continue
                if hasattr(backend, "block_arb_id"):
                    backend.block_arb_id(arb_id)  # type: ignore[union-attr]

        elif ft == "power_cycle":
            rail = p["rail"]
            if backend := self._power.get(rail):
                await backend.off()
                await asyncio.sleep(p.get("off_duration", 0.1))
                await backend.on()

        elif ft == "voltage_drop":
            rail = p["rail"]
            if backend := self._power.get(rail):
                await backend.set_voltage(p["voltage"])

        elif ft == "gpio_stuck":
            pin = p["pin"]
            level = p["level"]
            for gpio in self._gpio.values():
                if hasattr(gpio, "drive_input"):
                    try:
                        gpio.drive_input(pin, level)  # type: ignore[union-attr]
                        break
                    except Exception:
                        pass

    async def _deactivate(self, d: FaultDescriptor) -> None:
        ft = d.fault_type
        p = d.params

        if ft == "can_dropout":
            arb_id = p["arb_id"]
            target_iface = p.get("interface")
            for iface_name, backend in self._can.items():
                if target_iface and iface_name != target_iface:
                    continue
                if hasattr(backend, "unblock_arb_id"):
                    backend.unblock_arb_id(arb_id)  # type: ignore[union-attr]

        elif ft == "voltage_drop":
            rail = p["rail"]
            if backend := self._power.get(rail):
                # Restore nominal — VirtualPowerBackend knows its nominal
                await backend.set_voltage(12.0)

        elif ft == "gpio_stuck":
            pin = p["pin"]
            for gpio in self._gpio.values():
                if hasattr(gpio, "drive_input"):
                    try:
                        gpio.drive_input(pin, False)  # type: ignore[union-attr]
                        break
                    except Exception:
                        pass


__all__ = ["FaultNamespace"]
