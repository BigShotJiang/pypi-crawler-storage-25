"""rig.sim namespace — Bus Simulation Engine control surface for test code.

Lets tests drive simulated signal values and control which messages are
being transmitted.  The sim override context manager always restores (R8).

Example:

    await rig.sim.set("VehicleSpeed.Speed", 120.0)
    async with rig.sim.override("EngineData.RPM", 0.0):
        result = await rig.can.expect("EngineData.RPM", lambda v: v == 0.0, timeout=0.5)
        assert result.passed
    # RPM restored to its pre-override value here, even on exception
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING, AsyncIterator

from crucihil.hal.bse.signal_store import SignalStore
from crucihil.hal.models.results import MessageStatus

if TYPE_CHECKING:
    from crucihil.hal.bse.engine import BusSimEngine


@dataclass
class SimStatus:
    """Returned by rig.sim.status()."""

    messages: list[MessageStatus]
    signal_count: int
    active_count: int


class SimNamespace:
    """Provides rig.sim.*  methods to test code.

    Created by the Rig; test code never instantiates this directly.
    """

    def __init__(self, engine: "BusSimEngine") -> None:
        self._engine = engine

    # ── Signal control ─────────────────────────────────────────────────────────

    async def set(self, signal: str, value: float) -> None:
        """Set a signal value in the simulation.

        The new value takes effect on the next scheduled frame transmission
        (typically within one cycle time).

        Args:
            signal: "MessageName.SignalName"
            value:  Physical value in signal units.

        Raises:
            KeyError: If the signal is not in the loaded DBC.
        """
        self._engine.signal_store.set(signal, value)

    @asynccontextmanager
    async def override(
        self,
        signal: str,
        value: float,
    ) -> AsyncIterator[None]:
        """Temporarily override a signal value, restoring it on exit.

        Always restores the original value, even if the body raises (R8).

        Usage:
            async with rig.sim.override("EngineData.RPM", 0.0):
                ...  # signal is forced to 0.0 here
            # signal is restored here
        """
        original = self._engine.signal_store.get(signal)
        self._engine.signal_store.set(signal, value)
        try:
            yield
        finally:
            # R8 — teardown always runs, never suppresses exceptions
            self._engine.signal_store.set(signal, original)

    # ── Message scheduling ────────────────────────────────────────────────────

    def start(self, message_name: str) -> None:
        """Start periodic transmission of a DBC message.

        No-op if already running.
        """
        self._engine.sim_start(message_name)

    def stop(self, message_name: str) -> None:
        """Stop periodic transmission of a DBC message."""
        self._engine.sim_stop(message_name)

    def start_all(self) -> None:
        """Start all cyclic messages defined in the DBC."""
        self._engine.start_all_cyclic()

    # ── Status ─────────────────────────────────────────────────────────────────

    def status(self) -> SimStatus:
        """Return current simulation status — message activity and signal count."""
        messages = self._engine.message_status()
        active = sum(1 for m in messages if m.active)
        return SimStatus(
            messages=messages,
            signal_count=len(self._engine.signal_store.snapshot()),
            active_count=active,
        )


__all__ = ["SimNamespace", "SimStatus"]
