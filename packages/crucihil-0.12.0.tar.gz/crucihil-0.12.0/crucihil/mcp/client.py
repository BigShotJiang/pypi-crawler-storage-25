"""HTTP client for the CruciHiL REST API.

Wraps httpx.AsyncClient with JWT auth (API key → token exchange + refresh).
All methods return plain dicts — no Pydantic models cross the module boundary.

Usage:
    from crucihil.mcp.client import get_client, init_client
    init_client(base_url="http://localhost:8000", api_key="chk_...")
    client = get_client()
    rigs = await client.list_rigs()
"""

from __future__ import annotations

import time
from typing import Any

import httpx

_MAX_SIGNAL_SAMPLES = 100


class CruciHilClient:
    def __init__(self, base_url: str, api_key: str) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._token: str | None = None
        self._token_expiry: float = 0.0

    async def _ensure_token(self) -> str:
        if self._token and time.time() < self._token_expiry - 300:
            return self._token
        async with httpx.AsyncClient() as hc:
            resp = await hc.post(
                f"{self._base_url}/api/v1/auth/token",
                json={"api_key": self._api_key},
            )
            resp.raise_for_status()
            data = resp.json()
        self._token = data["access_token"]
        self._token_expiry = time.time() + data.get("expires_in", 3600)
        return self._token

    async def _headers(self) -> dict[str, str]:
        token = await self._ensure_token()
        return {"Authorization": f"Bearer {token}"}

    async def _get(self, path: str, params: dict | None = None) -> Any:
        headers = await self._headers()
        async with httpx.AsyncClient() as hc:
            resp = await hc.get(
                f"{self._base_url}{path}",
                headers=headers,
                params=params or {},
            )
            resp.raise_for_status()
            return resp.json()

    async def _post(self, path: str, body: dict) -> Any:
        headers = await self._headers()
        async with httpx.AsyncClient() as hc:
            resp = await hc.post(
                f"{self._base_url}{path}",
                headers=headers,
                json=body,
            )
            resp.raise_for_status()
            return resp.json()

    # --- Rig operations ---

    async def list_rigs(self) -> list[dict]:
        return await self._get("/api/v1/rigs")

    async def get_rig(self, rig_name: str) -> dict | None:
        try:
            return await self._get(f"/api/v1/rigs/{rig_name}")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return None
            raise

    async def register_rig(self, name: str) -> dict:
        return await self._post("/api/v1/rigs", {"name": name})

    # --- Run operations ---

    async def list_runs(
        self,
        rig_name: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if rig_name:
            params["rig_name"] = rig_name
        return await self._get("/api/v1/runs", params=params)

    async def get_run(self, run_id: str) -> dict | None:
        try:
            return await self._get(f"/api/v1/runs/{run_id}")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return None
            raise

    async def create_run(
        self,
        rig_name: str,
        suite_path: str,
        tags: list[str] | None = None,
        suite_type: str | None = None,
    ) -> dict:
        return await self._post("/api/v1/runs", {
            "rig_name": rig_name,
            "suite_path": suite_path,
            "tags": tags or [],
            "suite_type": suite_type,
            "triggered_by": "mcp",
        })

    async def cancel_run(self, run_id: str) -> dict:
        return await self._post(f"/api/v1/runs/{run_id}/cancel", {})

    # --- Result operations ---

    async def list_results(
        self,
        run_id: str | None = None,
        status: str | None = None,
        limit: int = 200,
    ) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if run_id:
            params["run_id"] = run_id
        if status:
            params["status"] = status
        return await self._get("/api/v1/results", params=params)

    async def get_result_detail(self, result_id: int) -> dict | None:
        try:
            return await self._get(f"/api/v1/results/{result_id}")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return None
            raise


# --- Module-level singleton ---

_client: CruciHilClient | None = None


def init_client(base_url: str, api_key: str) -> None:
    """Initialize the module-level client. Call once at startup from server.py."""
    global _client
    _client = CruciHilClient(base_url=base_url, api_key=api_key)


def get_client() -> CruciHilClient:
    """Return the initialized client. Raises if init_client() has not been called."""
    if _client is None:
        raise RuntimeError(
            "CruciHiL MCP client not initialized. "
            "Call init_client(base_url, api_key) before using tools."
        )
    return _client


__all__ = ["CruciHilClient", "init_client", "get_client"]
