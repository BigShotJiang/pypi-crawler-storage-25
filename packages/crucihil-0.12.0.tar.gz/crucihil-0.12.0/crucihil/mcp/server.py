"""CruciHiL MCP server.

A standalone FastMCP process that exposes CruciHiL capabilities to any
MCP-compatible AI client (Claude, Copilot, Cursor).

Start with:
    python -m crucihil.mcp.server

Environment variables required:
    CRUCIHIL_BASE_URL  — HTTP(S) base URL of the control plane (e.g. http://localhost:8000)
    CRUCIHIL_API_KEY   — API key issued by the control plane for this MCP client

The MCP server authenticates to the REST API using the API key.
The MCP server itself is unauthenticated — it runs inside the Docker Compose
internal network and the network boundary is the auth boundary.
"""

from __future__ import annotations

import os

from fastmcp import FastMCP

from crucihil.mcp.tools.rigs import get_rig_config, list_rigs, register_rig
from crucihil.mcp.tools.results import describe_failure, get_results, get_signal_trace
from crucihil.mcp.tools.runs import cancel_run, get_run_summary, list_runs, run_test_suite
from crucihil.mcp.tools.signals import list_signals
from crucihil.mcp.tools.suites import generate_test_suite, list_tests

mcp = FastMCP(
    name="CruciHiL",
    instructions=(
        "CruciHiL is a Hardware-in-the-Loop testing platform. "
        "Use these tools to query rig state, run test suites, analyze failures, and scaffold new tests. "
        "Start with list_rigs to see available rigs, then list_runs to see recent runs. "
        "For failure analysis, call describe_failure — it returns all context in one call. "
        "To onboard a new rig: call register_rig to get an API key, then instruct the user to run "
        "'crucihil discover' on the bench machine to generate the rig TOML. "
        "To scaffold a new test suite: call generate_test_suite with a description."
    ),
)

mcp.add_tool(list_rigs)
mcp.add_tool(get_rig_config)
mcp.add_tool(register_rig)
mcp.add_tool(list_runs)
mcp.add_tool(get_run_summary)
mcp.add_tool(run_test_suite)
mcp.add_tool(cancel_run)
mcp.add_tool(get_results)
mcp.add_tool(get_signal_trace)
mcp.add_tool(describe_failure)
mcp.add_tool(list_signals)
mcp.add_tool(list_tests)
mcp.add_tool(generate_test_suite)

if __name__ == "__main__":
    from crucihil.mcp.client import init_client

    base_url = os.environ.get("CRUCIHIL_BASE_URL", "")
    api_key = os.environ.get("CRUCIHIL_API_KEY", "")
    transport = os.environ.get("CRUCIHIL_MCP_TRANSPORT", "stdio")

    if not base_url:
        raise SystemExit("CRUCIHIL_BASE_URL environment variable is required")
    if not api_key:
        raise SystemExit("CRUCIHIL_API_KEY environment variable is required")

    init_client(base_url=base_url, api_key=api_key)

    if transport == "sse":
        mcp.run(transport="sse", host="0.0.0.0", port=8001)
    else:
        mcp.run()
