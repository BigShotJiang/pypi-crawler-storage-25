"""MCP tools for rig management.

list_rigs     — list all registered rigs with connection status
get_rig_config — get one rig's connection metadata and hardware summary
"""

from __future__ import annotations

import httpx

from crucihil.mcp.client import get_client


async def list_rigs() -> list[dict]:
    """List all registered rigs with connection status.

    Returns name, id, connected, last_seen_at, version, created_at, and
    any extra hardware metadata stored when the rig was registered.
    """
    client = get_client()
    try:
        rigs = await client.list_rigs()
    except httpx.HTTPStatusError as exc:
        return [{"error": f"API error {exc.response.status_code}", "detail": exc.response.text}]
    return [
        {
            "name": r["name"],
            "id": r["id"],
            "connected": r["connected"],
            "last_seen_at": r.get("last_seen_at"),
            "version": r.get("version"),
            "created_at": r["created_at"],
            "extra_meta": r.get("extra_meta", {}),
        }
        for r in rigs
    ]


async def get_rig_config(rig_name: str) -> dict:
    """Get connection metadata and hardware summary for a rig.

    Returns the rig's connectivity status and any extra metadata stored at
    registration time (typically a hardware summary from the agent).

    Args:
        rig_name: Exact name of the rig as registered in the control plane.
    """
    client = get_client()
    try:
        rig = await client.get_rig(rig_name)
    except httpx.HTTPStatusError as exc:
        return {"error": f"API error {exc.response.status_code}", "rig_name": rig_name}

    if rig is None:
        return {"error": "rig not found", "rig_name": rig_name}

    return {
        "rig_name": rig["name"],
        "rig_id": rig["id"],
        "connected": rig["connected"],
        "last_seen_at": rig.get("last_seen_at"),
        "version": rig.get("version"),
        "created_at": rig["created_at"],
        "hardware_summary": rig.get("extra_meta", {}),
    }


async def register_rig(rig_name: str) -> dict:
    """Register a new rig with the control plane and return its API key.

    The API key is shown ONCE and cannot be retrieved again — save it immediately.
    Use it to connect the rig agent:

        export CRUCIHIL_API_KEY=<returned key>
        export CRUCIHIL_BASE_URL=http://your-server:8000
        crucihil agent --rig rigs/<rig_name>.toml

    To generate the rig TOML, run on the bench machine:

        crucihil discover --describe "your hardware description"

    Args:
        rig_name: Unique name for the rig (letters, numbers, hyphens — e.g. "orin-bench-01").
    """
    client = get_client()
    try:
        data = await client.register_rig(rig_name)
    except httpx.HTTPStatusError as exc:
        try:
            detail = exc.response.json().get("detail", exc.response.text)
        except Exception:
            detail = exc.response.text
        return {"error": f"Registration failed ({exc.response.status_code})", "detail": detail}

    rig = data.get("rig", {})
    return {
        "rig_name": rig.get("name", rig_name),
        "rig_id": rig.get("id"),
        "role": rig.get("role", "admin"),
        "api_key": data.get("api_key"),
        "next_steps": [
            f"Save the api_key — it will not be shown again.",
            f"On the bench machine, generate the rig TOML:",
            f"  crucihil discover --describe 'your hardware'",
            f"  # or: crucihil init  (interactive wizard)",
            f"Start the agent:",
            f"  export CRUCIHIL_API_KEY={data.get('api_key', '<key>')}",
            f"  export CRUCIHIL_BASE_URL=<your server URL>",
            f"  crucihil agent --rig rigs/{rig.get('name', rig_name)}.toml",
        ],
    }


__all__ = ["list_rigs", "get_rig_config", "register_rig"]
