"""MCP tools for test run management.

list_runs       — list recent runs (optionally filtered by rig)
get_run_summary — single run with pass rate and duration
run_test_suite  — create a queued run and push to the connected agent
cancel_run      — mark a running run as cancelled
"""

from __future__ import annotations

import httpx

from crucihil.mcp.client import get_client


async def list_runs(rig_name: str | None = None, limit: int = 20) -> list[dict]:
    """List recent test runs, optionally filtered by rig name.

    Args:
        rig_name: Filter to runs from this rig. Pass None for all rigs.
        limit:    Maximum number of runs to return (default 20, max 500).
    """
    client = get_client()
    try:
        runs = await client.list_runs(rig_name=rig_name, limit=limit)
    except httpx.HTTPStatusError as exc:
        return [{"error": f"API error {exc.response.status_code}", "detail": exc.response.text}]
    return [
        {
            "run_id": r["id"],
            "suite_name": r["suite_name"],
            "status": r["status"],
            "total": r["total"],
            "passed": r["passed"],
            "failed": r["failed"],
            "blocked": r["blocked"],
            "errored": r["errored"],
            "skipped": r["skipped"],
            "started_at": r["started_at"],
            "completed_at": r.get("completed_at"),
        }
        for r in runs
    ]


async def get_run_summary(run_id: str) -> dict:
    """Get a full summary of one test run including pass rate and duration.

    Args:
        run_id: The UUID of the run to retrieve.
    """
    client = get_client()
    try:
        run = await client.get_run(run_id)
    except httpx.HTTPStatusError as exc:
        return {"error": f"API error {exc.response.status_code}", "run_id": run_id}

    if run is None:
        return {"error": "run not found", "run_id": run_id}

    total = run["total"]
    pass_rate = run["passed"] / total if total > 0 else 0.0
    duration_s = None
    if run.get("completed_at") and run.get("started_at"):
        duration_s = round(run["completed_at"] - run["started_at"], 3)

    return {
        "run_id": run["id"],
        "rig_id": run["rig_id"],
        "suite_name": run["suite_name"],
        "status": run["status"],
        "started_at": run["started_at"],
        "completed_at": run.get("completed_at"),
        "duration_s": duration_s,
        "total": total,
        "passed": run["passed"],
        "failed": run["failed"],
        "blocked": run["blocked"],
        "errored": run["errored"],
        "skipped": run["skipped"],
        "pass_rate": round(pass_rate, 4),
        "triggered_by": run.get("triggered_by"),
    }


async def run_test_suite(
    rig_name: str,
    suite_path: str,
    tags: list[str] | None = None,
    suite_type: str | None = None,
) -> dict:
    """Create a queued test run and push it to the connected agent.

    The control plane creates the run record immediately. If the agent is
    connected via WebSocket, it receives a run_suite command right away.
    Poll get_run_summary(run_id) to track progress.

    Args:
        rig_name:   Name of the rig to run tests on.
        suite_path: Path to the YAML suite manifest (e.g. "tests/suites/engine_validation.yaml").
        tags:       Optional list of tags to filter which tests run.
        suite_type: Optional suite type filter ("smoke", "regression", etc.).
    """
    client = get_client()
    try:
        result = await client.create_run(
            rig_name=rig_name,
            suite_path=suite_path,
            tags=tags,
            suite_type=suite_type,
        )
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text
        try:
            detail = exc.response.json().get("detail", detail)
        except Exception:
            pass
        return {
            "error": f"API error {exc.response.status_code}",
            "detail": detail,
            "rig_name": rig_name,
            "suite_path": suite_path,
        }
    return result


async def cancel_run(run_id: str) -> dict:
    """Cancel a running test run.

    Only runs with status "running" can be cancelled. The cancellation
    signal is stored in the database; the agent will stop after the
    current test completes.

    Args:
        run_id: The UUID of the run to cancel.
    """
    client = get_client()
    try:
        result = await client.cancel_run(run_id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            return {"error": "run not found", "run_id": run_id}
        if exc.response.status_code == 409:
            detail = exc.response.json().get("detail", "already in terminal state")
            return {"error": detail, "run_id": run_id}
        return {"error": f"API error {exc.response.status_code}", "run_id": run_id}
    return {"detail": result.get("detail", "cancellation requested"), "run_id": run_id}


__all__ = ["list_runs", "get_run_summary", "run_test_suite", "cancel_run"]
