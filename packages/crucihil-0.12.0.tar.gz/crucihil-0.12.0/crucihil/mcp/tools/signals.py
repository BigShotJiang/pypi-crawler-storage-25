"""MCP tools for CAN/SOME-IP signal introspection.

list_signals — parse a DBC file and return signal metadata for all messages.
               Uses cantools via crucihil.hal.bse.loader (R10 compliance).
"""

from __future__ import annotations

from crucihil.hal.bse.loader import load_dbc
from crucihil.hal.models.exceptions import ConfigurationError


async def list_signals(dbc_path: str) -> dict:
    """Parse a DBC file and return metadata for every signal.

    Returns signal name, message name, bit length, scaling, range, unit,
    and whether the signal has named enum values (choices).

    The DBC path is relative to the working directory when the MCP server is
    started — typically the project root. It matches the path in [rig.definitions]
    can_dbc in the rig TOML.

    Args:
        dbc_path: Path to the .dbc file (e.g. "defs/vehicle_can.dbc").
    """
    try:
        db = load_dbc(dbc_path)
    except ConfigurationError as exc:
        return {"error": str(exc), "dbc_path": dbc_path}

    signals = []
    for msg in db.messages:
        for sig in msg.signals:
            choices: dict | None = None
            if sig.choices:
                choices = {str(k): str(v) for k, v in sig.choices.items()}
            signals.append({
                "signal_name": sig.name,
                "message_name": msg.name,
                "message_id": f"0x{msg.frame_id:X}",
                "bit_length": sig.length,
                "factor": float(sig.scale) if sig.scale is not None else 1.0,
                "offset": float(sig.offset) if sig.offset is not None else 0.0,
                "min_val": float(sig.minimum) if sig.minimum is not None else None,
                "max_val": float(sig.maximum) if sig.maximum is not None else None,
                "unit": sig.unit or "",
                "interface": "CAN",
                "choices": choices,
            })

    return {
        "dbc_path": dbc_path,
        "message_count": len(db.messages),
        "signal_count": len(signals),
        "signals": signals,
    }


__all__ = ["list_signals"]
