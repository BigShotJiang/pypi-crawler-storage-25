"""CruciHiL CLI — entry point for all crucihil commands.

Commands:
  run        Run a test suite against a rig.
  agent      Start a persistent local agent daemon.
  init       Interactive wizard to create a new rig TOML.
  discover   AI-assisted rig setup — probes hardware and generates a TOML.
  stub       Generate missing Python stubs for a YAML suite manifest.
  version    Show CruciHiL version.

Exit codes:
  0  success / all tests passed
  1  one or more tests failed or errored
  2  framework error (bad config, missing files, setup failure)
"""

from __future__ import annotations

import asyncio
import logging
import re
import sys
from pathlib import Path
from typing import Optional

import typer

from crucihil.agent.manifest.loader import load_suite
from crucihil.agent.reporter.junit import summary_line, write_junit_xml
from crucihil.agent.reporter.html import write_html_report
from crucihil.agent.runner.runner import run_suite
from crucihil.hal.models.exceptions import CruciHiLError
from crucihil.hal.rig import Rig

app = typer.Typer(
    name="crucihil",
    help="CruciHiL — bulletproof HiL testing for firmware teams.",
    add_completion=False,
    no_args_is_help=True,
)


# ── version ────────────────────────────────────────────────────────────────────

@app.command()
def version() -> None:
    """Show CruciHiL version."""
    import importlib.metadata
    try:
        v = importlib.metadata.version("crucihil")
    except importlib.metadata.PackageNotFoundError:
        v = "0.1.0-dev"
    typer.echo(f"crucihil {v}")


# ── run ────────────────────────────────────────────────────────────────────────

@app.command()
def run(
    suite_path: Path = typer.Option(
        ..., "--suite", "-s",
        help="Path to YAML suite manifest.",
        exists=True,
        dir_okay=False,
    ),
    rig_path: Path = typer.Option(
        ..., "--rig", "-r",
        help="Path to rig TOML config.",
        exists=True,
        dir_okay=False,
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="Write JUnit XML results to this path.",
    ),
    html_output: Optional[Path] = typer.Option(
        None, "--html",
        help="Write self-contained HTML report to this path.",
    ),
    tags: Optional[str] = typer.Option(
        None, "--tags",
        help="Comma-separated tags — run only tests that match at least one.",
    ),
    suite_type: Optional[str] = typer.Option(
        None, "--suite-type",
        help="Comma-separated suite types — run only tests that match at least one.",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="Show per-test status during the run.",
    ),
) -> None:
    """Run a CruciHiL test suite against a rig."""

    log_level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(levelname)-8s %(name)s: %(message)s",
        stream=sys.stderr,
    )

    # Add cwd and the directory containing the suite to sys.path so that
    # 'module: tests.smoke' resolves against the user's project root.
    cwd = str(Path.cwd())
    suite_parent = str(suite_path.resolve().parent.parent)
    for p in (cwd, suite_parent):
        if p not in sys.path:
            sys.path.insert(0, p)

    filter_tags: set[str] | None = None
    if tags:
        filter_tags = {t.strip() for t in tags.split(",") if t.strip()}

    filter_types: set[str] | None = None
    if suite_type:
        filter_types = {t.strip() for t in suite_type.split(",") if t.strip()}

    # ── Load manifest ──────────────────────────────────────────────────────────
    try:
        test_suite = load_suite(suite_path)
    except CruciHiLError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=2)

    typer.echo(
        f"Suite  : {test_suite.suite.name} v{test_suite.suite.version}"
        f"  ({len(test_suite.tests)} tests)"
    )
    typer.echo(f"Rig    : {rig_path}")

    # ── Run ────────────────────────────────────────────────────────────────────
    try:
        results = asyncio.run(
            _run_async(test_suite, rig_path, filter_tags, filter_types, verbose)
        )
    except CruciHiLError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=2)
    except Exception as exc:
        typer.echo(f"unexpected error: {type(exc).__name__}: {exc}", err=True)
        raise typer.Exit(code=2)

    # ── Print per-test summary ─────────────────────────────────────────────────
    _print_results(results, verbose)

    # ── Write JUnit XML ────────────────────────────────────────────────────────
    if output:
        write_junit_xml(results, test_suite, output)
        typer.echo(f"\nJUnit  : {output}")

    # ── Write HTML report ──────────────────────────────────────────────────────
    if html_output:
        write_html_report(results, test_suite, html_output)
        typer.echo(f"HTML   : {html_output}")

    # ── Final summary line ─────────────────────────────────────────────────────
    typer.echo(f"\n{summary_line(results)}")

    failed = any(r.status in ("fail", "error") for r in results)
    raise typer.Exit(code=1 if failed else 0)


async def _run_async(suite, rig_path, filter_tags, filter_types, verbose):
    rig = Rig.from_toml(rig_path)
    async with rig:
        return await run_suite(
            suite,
            rig,
            filter_tags=filter_tags,
            filter_suite_types=filter_types,
        )


def _print_results(results, verbose: bool) -> None:
    STATUS_ICON = {
        "pass":    "✓",
        "fail":    "✗",
        "blocked": "⊘",
        "error":   "!",
        "skip":    "–",
    }
    typer.echo("")
    for r in results:
        icon = STATUS_ICON.get(r.status, "?")
        line = f"  {icon} [{r.status.upper():<7}] {r.test_id}  ({r.duration:.3f}s)"
        if r.errors and (verbose or r.status not in ("skip", "blocked")):
            line += f"\n           {r.errors[0]}"
        typer.echo(line)


# ── agent ──────────────────────────────────────────────────────────────────────

@app.command()
def agent(
    rig_path: Path = typer.Option(
        ..., "--rig", "-r",
        help="Path to rig TOML config.",
        exists=True,
        dir_okay=False,
    ),
    cache_path: Path = typer.Option(
        Path("~/.crucihil/results.db"), "--cache",
        help="Path to local SQLite result cache.",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="Enable debug logging.",
    ),
) -> None:
    """Start the CruciHiL local agent daemon.

    Loads the rig, connects to all backends, and starts listening for test run
    commands.  Cloud connection is configured via the \\[rig.cloud] section in
    the rig TOML.  Without it, runs in local-only mode (no cloud sync).

    On first boot with a registration_token set, the agent self-registers and
    saves the API key to ~/.crucihil/credentials.toml automatically.

    Press Ctrl-C to stop.
    """
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        stream=sys.stderr,
    )

    typer.echo(f"Starting agent — rig: {rig_path}")

    try:
        asyncio.run(_agent_async(rig_path, cache_path.expanduser()))
    except KeyboardInterrupt:
        typer.echo("\nAgent stopped.")
    except CruciHiLError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=2)
    except Exception as exc:
        typer.echo(f"unexpected error: {type(exc).__name__}: {exc}", err=True)
        raise typer.Exit(code=2)


async def _agent_async(
    rig_path: Path,
    cache_path: Path,
) -> None:
    from crucihil.agent.agent import LocalAgent
    local_agent = await LocalAgent.create(rig_path, cache_path)
    await local_agent.run()


# ── deregister ─────────────────────────────────────────────────────────────────

@app.command()
def deregister(
    rig_name: str = typer.Argument(help="Rig name to remove from local credentials."),
    server_url: str = typer.Option(
        "https://crucihil-server.fly.dev", "--server",
        help="Server URL the rig was registered with.",
    ),
) -> None:
    """Remove a rig's saved API key from the local credentials store.

    Run this after deleting a rig from the dashboard to clean up
    ~/.crucihil/credentials.toml.  Does not affect the cloud — delete
    the rig from the dashboard first.
    """
    from crucihil.agent.credentials import remove_api_key

    if not remove_api_key(server_url, rig_name):
        typer.echo(f"No saved credentials found for '{rig_name}' at {server_url}.")
        raise typer.Exit(code=1)

    typer.echo(f"✓ Removed credentials for '{rig_name}' from ~/.crucihil/credentials.toml")


# ── init ───────────────────────────────────────────────────────────────────────

@app.command()
def init(
    output_dir: Path = typer.Option(
        Path("rigs"), "--output-dir", "-d",
        help="Directory to write the new rig TOML to.",
    ),
) -> None:
    """Interactive wizard — create a new rig TOML configuration.

    Prompts for rig name, CAN interfaces (auto-detected from 'ip link'),
    Ethernet interfaces, power backend, and GPIO backend.  Writes a valid
    TOML that can be used immediately with 'crucihil run'.
    """
    from crucihil.agent.init.wizard import run_wizard
    run_wizard(output_dir)


# ── discover ───────────────────────────────────────────────────────────────────

@app.command()
def discover(
    output_dir: Path = typer.Option(
        Path("rigs"), "--output-dir", "-d",
        help="Directory to write the generated rig TOML.",
    ),
    provider: Optional[str] = typer.Option(
        None, "--provider", "-p",
        help="AI provider: 'anthropic', 'openai', or 'gemini'. Auto-detected from env if omitted.",
    ),
    describe: Optional[str] = typer.Option(
        None, "--describe",
        help="Hardware description passed to the AI (skips interactive prompt).",
    ),
    no_ai: bool = typer.Option(
        False, "--no-ai",
        help="Skip AI — generate a minimal stub TOML from probe results only.",
    ),
    model: Optional[str] = typer.Option(
        None, "--model",
        help=(
            "AI model override. Defaults per provider: "
            "claude-sonnet-4-6 (anthropic), gpt-4o (openai), gemini-2.0-flash (gemini)."
        ),
    ),
) -> None:
    """AI-assisted rig setup — probe hardware, generate a rig TOML.

    Probes the local system for CAN interfaces, USB adapters, and Ethernet
    interfaces, then asks an AI to produce a ready-to-use rig TOML.  You
    review the result and confirm before anything is written to disk.

    API key lookup order:
      1. ANTHROPIC_API_KEY env var  (uses Anthropic)
      2. OPENAI_API_KEY env var     (uses OpenAI)
      3. GOOGLE_API_KEY env var     (uses Gemini)
      4. Interactive prompt

    To skip the AI entirely and get a stub TOML:  --no-ai
    """
    from crucihil.discover.probe import probe, ProbeResult
    from crucihil.discover.ai_client import AIClient, detect_provider

    typer.echo("")
    typer.echo("╔══════════════════════════════════════════════╗")
    typer.echo("║  CruciHiL — AI Rig Discovery                ║")
    typer.echo("╚══════════════════════════════════════════════╝")
    typer.echo("")

    # ── Phase 1: probe ─────────────────────────────────────────────────────────
    typer.echo("Probing system for hardware...")
    result = probe()
    typer.echo("")
    typer.echo("── Probe results ───────────────────────────────")
    typer.echo(result.to_text())
    typer.echo("────────────────────────────────────────────────")
    typer.echo("")

    if result.is_empty():
        typer.echo(
            "No hardware detected automatically.  "
            "Describe your setup below and the AI will generate a TOML from scratch.",
        )

    # ── Phase 2: hardware description ──────────────────────────────────────────
    if describe is None:
        describe = typer.prompt(
            "Describe your hardware (ECU type, CAN buses, Ethernet, power — or leave blank)",
            default="",
        )

    # ── Phase 3: generate TOML ─────────────────────────────────────────────────
    if no_ai:
        toml_content = _stub_toml(result, describe)
    else:
        client = _resolve_ai_client(provider, model)
        typer.echo("\nGenerating configuration...")
        try:
            toml_content = _strip_fences(client.complete(_build_user_message(result, describe)))
        except Exception as exc:
            typer.echo(f"AI call failed: {exc}", err=True)
            typer.echo("Falling back to stub TOML.", err=True)
            toml_content = _stub_toml(result, describe)

    # ── Phase 4: show + validate + confirm-on-first-write ──────────────────────
    typer.echo("")
    typer.echo("── Generated rig TOML ──────────────────────────")
    typer.echo(toml_content)
    typer.echo("────────────────────────────────────────────────")

    errors = _validate_toml(toml_content)
    if errors:
        typer.echo("\n⚠ Warning — TOML validation errors:")
        for e in errors:
            typer.echo(f"  {e}")
        typer.echo("You may still write the file and edit it manually.")
    else:
        typer.echo("\n✓ Valid TOML")

    rig_name = _extract_rig_name(toml_content)
    output_path = Path(output_dir) / f"{rig_name}.toml"

    typer.echo("")
    if typer.confirm(f"Write to {output_path}?", default=False):
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(toml_content, encoding="utf-8")
        typer.echo(f"\n✓ Written to {output_path}")
        typer.echo(f"\nTest it:")
        typer.echo(f"  crucihil run --suite <suite.yaml> --rig {output_path}")
    else:
        typer.echo("\nNot written — copy the TOML above and save it manually.")


def _resolve_ai_client(provider_flag: Optional[str], model: Optional[str] = None):
    from crucihil.discover.ai_client import AIClient, detect_provider

    if provider_flag:
        api_key = typer.prompt(f"API key for {provider_flag}", hide_input=True)
        return AIClient(provider_flag, api_key, model=model)

    env_pair = detect_provider()
    if env_pair:
        prov, key = env_pair
        typer.echo(f"Using {prov} (from environment)")
        return AIClient(prov, key, model=model)

    # Interactive fallback
    prov = typer.prompt("AI provider [anthropic/openai/gemini]", default="anthropic")
    api_key = typer.prompt(f"API key for {prov}", hide_input=True)
    return AIClient(prov, api_key, model=model)


def _build_user_message(result, describe: str) -> str:
    lines = ["Hardware probe results from the target machine:", result.to_text()]
    if describe.strip():
        lines += ["", "User hardware description:", describe.strip()]
    else:
        lines += ["", "User hardware description: not provided"]
    lines += ["", "Generate the CruciHiL rig TOML for this system."]
    return "\n".join(lines)


def _stub_toml(result, describe: str) -> str:
    """Generate a minimal TOML from probe results — no AI required."""
    lines = [
        "# rig TOML — generated by 'crucihil discover --no-ai'",
        "# Review and edit all # TODO: entries before use.",
        "",
        "[rig]",
        'name         = "discovered_rig"',
        'platform     = "custom"  # TODO: set your platform name',
        'spec_version = "1.0"',
        'backend      = "hardware"',
        "",
    ]
    if result.can_interfaces:
        for iface in result.can_interfaces:
            key = iface.replace("-", "_")
            backend = "peak" if result.usb_adapters and "PEAK" in " ".join(result.usb_adapters) else "socketcan"
            lines += [
                f"[rig.can.{key}]",
                f'interface = "{iface}"',
                "bitrate   = 500000  # TODO: verify bitrate",
                "fd        = false",
                f'backend   = "{backend}"',
                "",
            ]
    else:
        lines += [
            "[rig.can.can0]",
            'interface = "can0"  # TODO: set your CAN interface',
            "bitrate   = 500000",
            "fd        = false",
            'backend   = "socketcan"',
            "",
        ]
    if result.eth_interfaces:
        for iface in result.eth_interfaces[:1]:
            key = iface.replace("-", "_")
            lines += [
                f"[rig.ethernet.{key}]",
                f'interface      = "{iface}"',
                'ip             = "169.254.0.1"  # TODO: set ECU-facing IP',
                'someip_backend = "python-someip"',
                'doip_backend   = "python-doip"',
                "",
            ]
    lines += [
        "[rig.power.ecu_main]",
        'backend = "virtual_power"  # TODO: set real power backend',
        'default = "off"',
        "",
        "[rig.definitions]",
        'can_dbc = "defs/vehicle_can.dbc"  # TODO: set path to your DBC',
    ]
    if describe.strip():
        lines.insert(2, f"# Hardware description: {describe.strip()}")
    return "\n".join(lines)


def _strip_fences(text: str) -> str:
    """Remove markdown code fences that AI models sometimes wrap TOML output in."""
    text = re.sub(r"^```[a-zA-Z]*\n?", "", text.strip())
    text = re.sub(r"\n?```$", "", text)
    return text.strip()


def _validate_toml(toml_content: str) -> list[str]:
    """Validate TOML content against RigConfig schema. Returns list of error strings."""
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]
    from pydantic import ValidationError
    from crucihil.hal.config.schema import RigConfig

    try:
        data = tomllib.loads(toml_content)
    except Exception as exc:
        return [f"TOML syntax error: {exc}"]
    if "rig" not in data:
        return ["Missing [rig] section"]
    try:
        RigConfig.model_validate(data["rig"])
        return []
    except ValidationError as exc:
        return [f"  • {e['loc']}: {e['msg']}" for e in exc.errors()]
    except Exception as exc:
        return [f"Validation error: {exc}"]


def _extract_rig_name(toml_content: str) -> str:
    """Pull name = "..." from the [rig] block, fall back to 'discovered_rig'."""
    for line in toml_content.splitlines():
        m = re.match(r'^\s*name\s*=\s*["\']([^"\']+)["\']', line)
        if m:
            return re.sub(r"[^A-Za-z0-9_\-]", "_", m.group(1))
    return "discovered_rig"


# ── stub ───────────────────────────────────────────────────────────────────────

@app.command()
def stub(
    suite_path: Path = typer.Option(
        ..., "--suite", "-s",
        help="Path to the YAML suite manifest to sync stubs for.",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Show what would be written without touching any files.",
    ),
) -> None:
    """Generate missing Python stub functions for a YAML suite manifest.

    Reads every module/function pair in the suite, checks whether the
    function exists in the Python file, and appends a typed stub for
    each missing one.

    Example — after adding a new test entry to regression.yaml:

      crucihil stub --suite suites/regression.yaml
    """
    _run_stub(suite_path.resolve(), dry_run)


def _run_stub(suite_path: Path, dry_run: bool) -> None:
    try:
        suite_obj = load_suite(suite_path)
    except Exception as exc:
        typer.echo(f"✗ Could not load suite: {exc}", err=True)
        raise typer.Exit(2)

    # Project root: parent of the directory containing the YAML
    # (covers <root>/suites/<name>.yaml convention; falls back to suite dir)
    project_root = suite_path.parent.parent
    if not (project_root / "tests").exists():
        project_root = suite_path.parent

    # Collect missing functions grouped by module path
    # module_path → list of (function_name, test_id, description)
    from collections import defaultdict
    missing: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    present: list[str] = []

    for test in suite_obj.tests:
        if not test.module or not test.function:
            continue
        py_file = project_root / Path(test.module.replace(".", "/")).with_suffix(".py")
        if py_file.exists():
            src = py_file.read_text()
            # Check for function definition (handles both async def and def)
            import re as _re
            if _re.search(rf"^(async\s+)?def\s+{_re.escape(test.function)}\s*\(", src, _re.MULTILINE):
                present.append(f"{test.module}.{test.function}")
                continue
        desc = getattr(test, "description", None) or getattr(test, "name", None) or test.id
        missing[test.module].append((test.function, test.id, desc or ""))

    if not missing:
        typer.echo(f"✓ All functions already exist — nothing to stub.")
        return

    for module_path, fns in missing.items():
        py_file = project_root / Path(module_path.replace(".", "/")).with_suffix(".py")
        stubs: list[str] = []
        for fn_name, test_id, desc in fns:
            stubs.append(_make_stub(fn_name, desc))

        stub_block = "\n".join(stubs)

        if dry_run:
            typer.echo(f"\n── {py_file} (dry run) ──")
            typer.echo(stub_block)
            continue

        if py_file.exists():
            existing = py_file.read_text()
            # Ensure file ends with a newline before appending
            if not existing.endswith("\n"):
                existing += "\n"
            py_file.write_text(existing + "\n" + stub_block)
            for fn_name, _, _ in fns:
                typer.echo(f"  + {module_path}.{fn_name}  →  {py_file}")
        else:
            # Create the file from scratch with the right header
            header = _stub_file_header(module_path)
            py_file.parent.mkdir(parents=True, exist_ok=True)
            # Ensure __init__.py exists so the package is importable
            init = py_file.parent / "__init__.py"
            if not init.exists():
                init.write_text("")
            py_file.write_text(header + "\n" + stub_block)
            for fn_name, _, _ in fns:
                typer.echo(f"  + {module_path}.{fn_name}  →  {py_file}  (new file)")

    if present:
        typer.echo(f"\n  (skipped {len(present)} existing function{'s' if len(present) != 1 else ''})")


def _make_stub(fn_name: str, description: str) -> str:
    desc_line = description.rstrip(".")
    return (
        f"async def {fn_name}(rig: Rig) -> None:\n"
        f'    """{desc_line}."""\n'
        f"    # TODO: implement\n"
        f"    pass\n"
    )


def _stub_file_header(module_path: str) -> str:
    return (
        f'"""Tests for {module_path}."""\n'
        f"\n"
        f"from crucihil.hal.rig import Rig\n"
        f"from crucihil.hal.models.exceptions import BlockedError\n"
        f"\n"
    )


# ── scaffold ───────────────────────────────────────────────────────────────────

_ADAPTER_TYPES = ["can", "power", "gpio", "doip", "someip", "udp", "uds"]
_EXAMPLE_NAMES = ["hello_world", "can_signals", "fault_injection"]

@app.command()
def scaffold(
    rig_path: Optional[Path] = typer.Option(
        None, "--rig", "-r",
        help="Path to rig TOML — generates a full test project (suites/ + tests/).",
        exists=False,
        dir_okay=False,
    ),
    adapter: Optional[str] = typer.Option(
        None, "--adapter", "-a",
        help=f"Generate a custom backend stub. One of: {', '.join(_ADAPTER_TYPES)}",
    ),
    name: Optional[str] = typer.Option(
        None, "--name", "-n",
        help="Class name for the adapter (e.g. 'RelayBoard' → RelayBoardBackend). "
             "Defaults to 'Custom<Type>'.",
    ),
    example: Optional[str] = typer.Option(
        None, "--example", "-e",
        help=f"Drop a self-contained runnable example. One of: {', '.join(_EXAMPLE_NAMES)}",
    ),
    output_dir: Path = typer.Option(
        Path("."), "--output-dir", "-d",
        help="Directory to write generated files into.",
    ),
) -> None:
    """Scaffold a test project, a custom backend adapter, or a runnable example.

    Test project (from a rig TOML):

      crucihil scaffold --rig rigs/my_rig.toml

      Reads the TOML, generates suites/smoke.yaml, suites/regression.yaml,
      tests/smoke.py, and tests/regression.py tailored to your hardware.

    Runnable examples (no hardware required):

      crucihil scaffold --example hello_world     # minimal — proves install works
      crucihil scaffold --example can_signals     # send signals, assert with rig.can.expect()
      crucihil scaffold --example fault_injection # inject CAN dropout, verify recovery

    Custom backend adapter:

      crucihil scaffold --adapter power --name RelayBoard
      crucihil scaffold --adapter can   --name MyCAN

      Generates a Python class stub implementing the HAL ABC for that type.
      Reference it in your TOML via: backend = "mypackage.relay_board.RelayBoardBackend"

    Adapter types: can, power, gpio, doip, someip, udp, uds
    """
    if example:
        _scaffold_example(example, Path(output_dir))
    elif adapter:
        _scaffold_adapter(adapter, name, Path(output_dir))
    elif rig_path:
        _scaffold_project(rig_path, Path(output_dir))
    else:
        typer.echo(
            "error: provide --rig, --example, or --adapter.",
            err=True,
        )
        typer.echo(f"  examples:      {', '.join(_EXAMPLE_NAMES)}", err=True)
        typer.echo(f"  adapter types: {', '.join(_ADAPTER_TYPES)}", err=True)
        raise typer.Exit(code=2)


def _scaffold_example(example_name: str, output_dir: Path) -> None:
    example_name = example_name.lower().strip()
    if example_name not in _EXAMPLE_NAMES:
        typer.echo(
            f"error: unknown example '{example_name}'. "
            f"Choose from: {', '.join(_EXAMPLE_NAMES)}",
            err=True,
        )
        raise typer.Exit(code=2)

    out = output_dir / "examples" / example_name
    out.mkdir(parents=True, exist_ok=True)
    (out / "rigs").mkdir(exist_ok=True)
    (out / "suites").mkdir(exist_ok=True)
    (out / "tests").mkdir(exist_ok=True)

    writers = {
        "hello_world":    _example_hello_world,
        "can_signals":    _example_can_signals,
        "fault_injection": _example_fault_injection,
    }
    run_cmd = writers[example_name](out)

    typer.echo(f"\n✓ Example written to {out.resolve()}/")
    typer.echo("")
    typer.echo("Run it now:")
    typer.echo(f"  cd {out.resolve()}")
    typer.echo(f"  {run_cmd}")


# ── Example: hello_world ───────────────────────────────────────────────────────

def _example_hello_world(out: Path) -> str:
    (out / "rigs" / "virtual.toml").write_text(
        '# Minimal virtual rig — no hardware required.\n'
        '[rig]\n'
        'name         = "hello_rig"\n'
        'platform     = "virtual"\n'
        'spec_version = "1.0"\n'
        'backend      = "virtual"\n'
        '\n'
        '[rig.power.ecu_main]\n'
        'backend = "virtual_power"\n'
        'default = "off"\n',
        encoding="utf-8",
    )

    (out / "suites" / "hello.yaml").write_text(
        '# hello_world suite — verifies CruciHiL is installed and working.\n'
        '# Run: crucihil run --suite suites/hello.yaml --rig rigs/virtual.toml -v\n'
        '\n'
        'suite:\n'
        '  name: hello_world\n'
        '  version: "1.0.0"\n'
        '  description: Minimal smoke test — proves the framework is installed correctly\n'
        '\n'
        'defaults:\n'
        '  timeout: 10.0\n'
        '  suite_types: [smoke]\n'
        '\n'
        'tests:\n'
        '  - id: framework_works\n'
        '    name: Framework works\n'
        '    description: The simplest possible test — always passes if crucihil is installed\n'
        '    tags: [hello, smoke]\n'
        '    priority: critical\n'
        '    module: tests.hello\n'
        '    function: test_framework_works\n'
        '\n'
        '  - id: power_cycle\n'
        '    name: Power cycle (virtual)\n'
        '    description: Cycle the virtual power rail — no hardware needed\n'
        '    tags: [hello, power]\n'
        '    priority: high\n'
        '    setup:\n'
        '      - power.off: ecu_main\n'
        '      - power.on: ecu_main\n'
        '    module: tests.hello\n'
        '    function: test_power_cycle\n',
        encoding="utf-8",
    )

    (out / "tests" / "__init__.py").write_text("", encoding="utf-8")
    (out / "tests" / "hello.py").write_text(
        '"""Hello World — the simplest CruciHiL tests.\n'
        '\n'
        'These tests run against a virtual rig with no hardware.\n'
        'They demonstrate the basic test function signature and the\n'
        'YAML setup/teardown → Python assertion split.\n'
        '"""\n'
        '\n'
        'from crucihil.hal.rig import Rig\n'
        '\n'
        '\n'
        'async def test_framework_works(rig: Rig) -> None:\n'
        '    """Verify CruciHiL loaded and the rig connected without errors.\n'
        '\n'
        '    The `rig` object is injected by the framework — you never\n'
        '    instantiate it yourself.  If this test passes, your installation\n'
        '    is working correctly.\n'
        '    """\n'
        '    assert rig is not None\n'
        '    assert rig.config.name == "hello_rig"\n'
        '\n'
        '\n'
        'async def test_power_cycle(rig: Rig) -> None:\n'
        '    """The YAML setup: block ran power.off then power.on before this ran.\n'
        '\n'
        '    In a real test you would assert that the ECU recovered — e.g. a\n'
        '    heartbeat signal appeared on the CAN bus.  Here we just confirm the\n'
        '    rig is still healthy after the power cycle.\n'
        '    """\n'
        '    assert rig is not None\n',
        encoding="utf-8",
    )

    _write_example_files(out, "hello.yaml")
    return "crucihil run --suite suites/hello.yaml --rig rigs/virtual.toml -v"


# ── Example: can_signals ───────────────────────────────────────────────────────

_EXAMPLE_DBC = """\
VERSION ""

NS_ :

BS_:

BU_:

BO_ 100 EngineData: 8 ECU1
 SG_ RPM : 0|16@1+ (0.25,0) [0|8000] "rpm" Vector__XXX
 SG_ CoolantTemp : 16|8@1+ (1,-40) [-40|215] "degC" Vector__XXX
 SG_ ThrottlePos : 24|8@1+ (0.4,0) [0|100] "%" Vector__XXX

BO_ 200 VehicleSpeed: 4 ECU1
 SG_ SpeedKph : 0|16@1+ (0.1,0) [0|300] "kph" Vector__XXX

"""


def _example_can_signals(out: Path) -> str:
    (out / "defs").mkdir(exist_ok=True)
    (out / "defs" / "example.dbc").write_text(_EXAMPLE_DBC, encoding="utf-8")

    (out / "rigs" / "virtual.toml").write_text(
        '# Virtual rig with a CAN bus and example DBC.\n'
        '[rig]\n'
        'name         = "can_demo_rig"\n'
        'platform     = "virtual"\n'
        'spec_version = "1.0"\n'
        'backend      = "virtual"\n'
        '\n'
        '[rig.can.can0]\n'
        'interface = "can0"\n'
        'bitrate   = 500000\n'
        'fd        = false\n'
        'backend   = "virtual"\n'
        '\n'
        '[rig.power.ecu_main]\n'
        'backend = "virtual_power"\n'
        'default = "off"\n'
        '\n'
        '[rig.definitions]\n'
        'can_dbc = "defs/example.dbc"\n',
        encoding="utf-8",
    )

    (out / "suites" / "can_signals.yaml").write_text(
        '# can_signals suite — demonstrates rig.can.expect() with the BSE simulator.\n'
        '#\n'
        '# The BSE (Bus Simulation Engine) reads the DBC, encodes signal values\n'
        '# into CAN frames, and transmits them on the virtual bus.  rig.can.expect()\n'
        '# listens for those frames and checks conditions against decoded signal values.\n'
        '#\n'
        '# Run: crucihil run --suite suites/can_signals.yaml --rig rigs/virtual.toml -v\n'
        '\n'
        'suite:\n'
        '  name: can_signals_demo\n'
        '  version: "1.0.0"\n'
        '  description: Demonstrates signal simulation and CAN assertions\n'
        '\n'
        'defaults:\n'
        '  timeout: 10.0\n'
        '  suite_types: [smoke]\n'
        '\n'
        'tests:\n'
        '  - id: signal_visible_on_bus\n'
        '    name: Signal visible on CAN bus\n'
        '    description: Set RPM via sim, verify it appears on the virtual bus\n'
        '    tags: [can, signals]\n'
        '    priority: critical\n'
        '    setup:\n'
        '      - sim.set:   { signal: "EngineData.RPM", value: 2500.0 }\n'
        '      - sim.start: EngineData\n'
        '    teardown:\n'
        '      - sim.stop: EngineData\n'
        '    module: tests.can_signals\n'
        '    function: test_signal_visible_on_bus\n'
        '    params:\n'
        '      expected_rpm: 2500.0\n'
        '\n'
        '  - id: signal_range_check\n'
        '    name: Signal stays within range\n'
        '    description: Verify RPM is within the valid operating range [0, 8000]\n'
        '    tags: [can, signals, range]\n'
        '    priority: high\n'
        '    setup:\n'
        '      - sim.set:   { signal: "EngineData.RPM", value: 1500.0 }\n'
        '      - sim.start: EngineData\n'
        '    teardown:\n'
        '      - sim.stop: EngineData\n'
        '    module: tests.can_signals\n'
        '    function: test_signal_range_check\n'
        '\n'
        '  - id: multiple_signals\n'
        '    name: Multiple signals in one message\n'
        '    description: Set multiple signals in EngineData, assert each one\n'
        '    tags: [can, signals]\n'
        '    priority: medium\n'
        '    setup:\n'
        '      - sim.set: { signal: "EngineData.RPM",         value: 3000.0 }\n'
        '      - sim.set: { signal: "EngineData.CoolantTemp", value: 90.0 }\n'
        '      - sim.set: { signal: "EngineData.ThrottlePos", value: 25.0 }\n'
        '      - sim.start: EngineData\n'
        '    teardown:\n'
        '      - sim.stop: EngineData\n'
        '    module: tests.can_signals\n'
        '    function: test_multiple_signals\n',
        encoding="utf-8",
    )

    (out / "tests" / "__init__.py").write_text("", encoding="utf-8")
    (out / "tests" / "can_signals.py").write_text(
        '"""CAN signals example — demonstrates rig.can.expect() with the BSE simulator.\n'
        '\n'
        'How it works:\n'
        '  1. The YAML suite sets signal values via sim.set and starts the message\n'
        '     scheduler with sim.start.\n'
        '  2. The BSE encodes the signal values into CAN frames and transmits them\n'
        '     on the virtual bus at the DBC-defined cycle time.\n'
        '  3. rig.can.expect() listens for those frames, decodes each one with\n'
        '     cantools, and checks the condition lambda against the signal value.\n'
        '  4. The test passes when the condition returns True, or fails on timeout.\n'
        '"""\n'
        '\n'
        'from crucihil.hal.rig import Rig\n'
        '\n'
        '\n'
        'async def test_signal_visible_on_bus(rig: Rig, expected_rpm: float = 2500.0) -> None:\n'
        '    """Verify that the simulated RPM signal appears on the virtual CAN bus.\n'
        '\n'
        '    The YAML setup ran sim.set + sim.start before this function was called.\n'
        '    The BSE is now transmitting EngineData frames with RPM = 2500.\n'
        '    """\n'
        '    result = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: abs(v - expected_rpm) < 1.0,  # within 0.25 rpm resolution\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert result.passed, (\n'
        '        f"Expected RPM ≈ {expected_rpm}, got: {result.fail_msg}"\n'
        '    )\n'
        '\n'
        '\n'
        'async def test_signal_range_check(rig: Rig) -> None:\n'
        '    """Verify RPM stays within the valid operating range defined in the DBC."""\n'
        '    result = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: 0.0 <= v <= 8000.0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert result.passed, f"RPM out of range [0, 8000]: {result.fail_msg}"\n'
        '\n'
        '\n'
        'async def test_multiple_signals(rig: Rig) -> None:\n'
        '    """Assert three signals from the same CAN message in sequence."""\n'
        '    import asyncio\n'
        '\n'
        '    rpm_result = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: abs(v - 3000.0) < 1.0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert rpm_result.passed, f"RPM: {rpm_result.fail_msg}"\n'
        '\n'
        '    coolant_result = await rig.can.expect(\n'
        '        signal="EngineData.CoolantTemp",\n'
        '        condition=lambda v: abs(v - 90.0) < 1.0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert coolant_result.passed, f"CoolantTemp: {coolant_result.fail_msg}"\n'
        '\n'
        '    throttle_result = await rig.can.expect(\n'
        '        signal="EngineData.ThrottlePos",\n'
        '        condition=lambda v: abs(v - 25.0) < 1.0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert throttle_result.passed, f"ThrottlePos: {throttle_result.fail_msg}"\n',
        encoding="utf-8",
    )

    _write_example_files(out, "can_signals.yaml")
    return "crucihil run --suite suites/can_signals.yaml --rig rigs/virtual.toml -v"


# ── Example: fault_injection ───────────────────────────────────────────────────

def _example_fault_injection(out: Path) -> str:
    (out / "defs").mkdir(exist_ok=True)
    (out / "defs" / "example.dbc").write_text(_EXAMPLE_DBC, encoding="utf-8")

    (out / "rigs" / "virtual.toml").write_text(
        '# Virtual rig for fault injection demo.\n'
        '[rig]\n'
        'name         = "fault_demo_rig"\n'
        'platform     = "virtual"\n'
        'spec_version = "1.0"\n'
        'backend      = "virtual"\n'
        '\n'
        '[rig.can.can0]\n'
        'interface = "can0"\n'
        'bitrate   = 500000\n'
        'fd        = false\n'
        'backend   = "virtual"\n'
        '\n'
        '[rig.power.ecu_main]\n'
        'backend = "virtual_power"\n'
        'default = "off"\n'
        '\n'
        '[rig.definitions]\n'
        'can_dbc = "defs/example.dbc"\n',
        encoding="utf-8",
    )

    (out / "suites" / "fault_injection.yaml").write_text(
        '# fault_injection suite — demonstrates the FaultDescriptor pattern.\n'
        '#\n'
        '# Key rule: fault methods return FaultDescriptors, NOT coroutines.\n'
        '#   CORRECT: async with rig.fault.inject(rig.fault.can_dropout(...)):\n'
        '#   WRONG:   await rig.fault.can_dropout(...)   <-- TypeError\n'
        '#\n'
        '# Run: crucihil run --suite suites/fault_injection.yaml --rig rigs/virtual.toml -v\n'
        '\n'
        'suite:\n'
        '  name: fault_injection_demo\n'
        '  version: "1.0.0"\n'
        '  description: Demonstrates fault injection API and sim.override()\n'
        '\n'
        'defaults:\n'
        '  timeout: 15.0\n'
        '  suite_types: [regression]\n'
        '\n'
        'tests:\n'
        '  - id: can_dropout_api\n'
        '    name: CAN dropout — correct FaultDescriptor API\n'
        '    description: >\n'
        '      Demonstrates the can_dropout FaultDescriptor pattern.\n'
        '      Verifies signal present before and after the fault window.\n'
        '      On real hardware: add assertion inside the context manager.\n'
        '    tags: [fault, can]\n'
        '    priority: high\n'
        '    setup:\n'
        '      - sim.set:   { signal: "EngineData.RPM", value: 800.0 }\n'
        '      - sim.start: EngineData\n'
        '    teardown:\n'
        '      - sim.stop: EngineData\n'
        '    module: tests.fault_injection\n'
        '    function: test_can_dropout_api\n'
        '\n'
        '  - id: power_cycle_signal_check\n'
        '    name: Power cycle then signal check\n'
        '    description: >\n'
        '      Power-cycles ecu_main in setup, then verifies the simulated bus\n'
        '      is still healthy.  Pattern for real ECU cold-boot tests.\n'
        '    tags: [fault, power]\n'
        '    priority: high\n'
        '    setup:\n'
        '      - sim.set:   { signal: "EngineData.RPM", value: 1200.0 }\n'
        '      - sim.start: EngineData\n'
        '      - power.off: ecu_main\n'
        '      - power.on:  ecu_main\n'
        '    teardown:\n'
        '      - sim.stop: EngineData\n'
        '    module: tests.fault_injection\n'
        '    function: test_power_cycle_and_signal_check\n'
        '\n'
        '  - id: sim_override\n'
        '    name: sim.override() — temporary signal injection\n'
        '    description: >\n'
        '      Demonstrates rig.sim.override() to temporarily replace a signal\n'
        '      value and automatically restore it after the context manager exits.\n'
        '    tags: [sim, signals]\n'
        '    priority: medium\n'
        '    setup:\n'
        '      - sim.set:   { signal: "EngineData.RPM", value: 800.0 }\n'
        '      - sim.start: EngineData\n'
        '    teardown:\n'
        '      - sim.stop: EngineData\n'
        '    module: tests.fault_injection\n'
        '    function: test_sim_override\n',
        encoding="utf-8",
    )

    (out / "tests" / "__init__.py").write_text("", encoding="utf-8")
    (out / "tests" / "fault_injection.py").write_text(
        '"""Fault injection example — demonstrates the FaultDescriptor pattern.\n'
        '\n'
        'Critical rule (R4): fault methods return FaultDescriptors, not coroutines.\n'
        '\n'
        '  CORRECT:\n'
        '    async with rig.fault.inject(rig.fault.can_dropout(arb_id=100, duration=1.0)):\n'
        '        await asyncio.sleep(1.0)\n'
        '\n'
        '  WRONG — can_dropout() returns a descriptor, not a coroutine:\n'
        '    await rig.fault.can_dropout(arb_id=100, duration=1.0)  # TypeError\n'
        '\n'
        'Virtual vs real hardware behaviour:\n'
        '  rig.can.expect() polls the in-memory signal store (populated by sim.set).\n'
        '  On virtual backends, can_dropout blocks frame TX but the store retains its\n'
        '  last value, so the "signal absent during dropout" assertion only fires on\n'
        '  real hardware where fresh frame delivery drives store updates.\n'
        '  This example tests what IS verifiable in virtual mode: correct API usage,\n'
        '  signal present before fault, and signal present after fault.\n'
        '"""\n'
        '\n'
        'import asyncio\n'
        'from crucihil.hal.rig import Rig\n'
        '\n'
        '\n'
        'async def test_can_dropout_api(rig: Rig) -> None:\n'
        '    """Demonstrate correct FaultDescriptor usage for CAN dropout.\n'
        '\n'
        '    Virtual mode: verifies signal is present before and after the fault\n'
        '    window (store-based).  Real hardware: add an assertion INSIDE the\n'
        '    context manager verifying the signal disappears during the window.\n'
        '    """\n'
        '    # Verify signal is live before the fault\n'
        '    before = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: v > 0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert before.passed, f"Signal not visible before fault: {before.fail_msg}"\n'
        '\n'
        '    # Apply dropout — FaultDescriptor pattern, NOT a coroutine\n'
        '    async with rig.fault.inject(rig.fault.can_dropout(arb_id=100, duration=0.3)):\n'
        '        await asyncio.sleep(0.3)\n'
        '        # On real hardware, add assertion here that signal is absent:\n'
        '        # dropped = await rig.can.expect(signal="EngineData.RPM",\n'
        '        #     condition=lambda v: v is not None, timeout=0.1)\n'
        '        # assert not dropped.passed, "ECU should not be transmitting during dropout"\n'
        '\n'
        '    # Verify signal is restored after the fault window\n'
        '    await asyncio.sleep(0.05)\n'
        '    after = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: v > 0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert after.passed, f"Signal not restored after fault: {after.fail_msg}"\n'
        '\n'
        '\n'
        'async def test_power_cycle_and_signal_check(rig: Rig) -> None:\n'
        '    """Power was cycled in YAML setup; verify signal is still present.\n'
        '\n'
        '    The YAML setup ran:\n'
        '      sim.set + sim.start  (start BSE transmission at 1200 RPM)\n'
        '      power.off + power.on (simulated power cycle)\n'
        '\n'
        '    On real hardware you would wait for a boot heartbeat here.\n'
        '    """\n'
        '    result = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: v > 0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert result.passed, (\n'
        '        f"Bus not healthy after power cycle: {result.fail_msg}"\n'
        '    )\n'
        '\n'
        '\n'
        'async def test_sim_override(rig: Rig) -> None:\n'
        '    """Demonstrate rig.sim to inject a specific value for one test.\n'
        '\n'
        '    sim.override() temporarily replaces a signal value for the duration\n'
        '    of the context manager, then restores it — even if the test fails.\n'
        '    Use this to test how firmware responds to specific signal conditions.\n'
        '    """\n'
        '    # First verify the baseline set in YAML setup (800 RPM)\n'
        '    baseline = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: abs(v - 800.0) < 1.0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert baseline.passed, f"Baseline RPM wrong: {baseline.fail_msg}"\n'
        '\n'
        '    # Override to a different value for this section of the test\n'
        '    async with rig.sim.override("EngineData.RPM", 5500.0):\n'
        '        high_rpm = await rig.can.expect(\n'
        '            signal="EngineData.RPM",\n'
        '            condition=lambda v: abs(v - 5500.0) < 1.0,\n'
        '            timeout=3.0,\n'
        '        )\n'
        '        assert high_rpm.passed, f"Override not applied: {high_rpm.fail_msg}"\n'
        '\n'
        '    # After the context manager, value is restored to 800\n'
        '    restored = await rig.can.expect(\n'
        '        signal="EngineData.RPM",\n'
        '        condition=lambda v: abs(v - 800.0) < 1.0,\n'
        '        timeout=3.0,\n'
        '    )\n'
        '    assert restored.passed, f"Override not restored: {restored.fail_msg}"\n'
        '\n'
        '\n'
        '# NOTE: test_power_cycle_and_signal_check is triggered via YAML setup:\n'
        '# power.off / power.on run before the function executes.\n',
        encoding="utf-8",
    )

    _write_example_files(out, "fault_injection.yaml")
    return "crucihil run --suite suites/fault_injection.yaml --rig rigs/virtual.toml -v"


def _write_example_files(out: Path, suite_file: str) -> None:
    """Print written files."""
    for p in sorted(out.rglob("*")):
        if p.is_file():
            typer.echo(f"  wrote {p.relative_to(out.parent.parent)}")


def _scaffold_project(rig_path: Path, output_dir: Path) -> None:
    from crucihil.hal.config.loader import load_rig_config
    from crucihil.hal.models.exceptions import ConfigurationError

    if not rig_path.exists():
        typer.echo(f"error: rig TOML not found: {rig_path}", err=True)
        raise typer.Exit(code=2)

    try:
        cfg = load_rig_config(rig_path)
    except ConfigurationError as exc:
        typer.echo(f"error reading rig TOML: {exc}", err=True)
        raise typer.Exit(code=2)

    out = output_dir
    suites_dir = out / "suites"
    tests_dir = out / "tests"
    suites_dir.mkdir(parents=True, exist_ok=True)
    tests_dir.mkdir(parents=True, exist_ok=True)

    _write_scaffold(cfg, out, suites_dir, tests_dir, rig_path)

    typer.echo(f"\n✓ Scaffold written to {out.resolve()}/")
    typer.echo("")
    typer.echo("Next steps:")
    typer.echo(f"  1. Edit tests/smoke.py and tests/regression.py — fill in the TODOs")
    typer.echo(f"  2. Run smoke suite:")
    typer.echo(f"       crucihil run --suite suites/smoke.yaml --rig {rig_path} -v")
    typer.echo(f"  3. Run regression suite:")
    typer.echo(f"       crucihil run --suite suites/regression.yaml --rig {rig_path} -v")


def _scaffold_adapter(adapter_type: str, name: Optional[str], output_dir: Path) -> None:
    adapter_type = adapter_type.lower().strip()
    if adapter_type not in _ADAPTER_TYPES:
        typer.echo(
            f"error: unknown adapter type '{adapter_type}'. "
            f"Choose from: {', '.join(_ADAPTER_TYPES)}",
            err=True,
        )
        raise typer.Exit(code=2)

    # Derive class name and file name
    if name:
        raw = name.strip()
        # PascalCase the name
        # Preserve existing capitalisation (e.g. PeakUSB stays PeakUSB),
        # but capitalise the first char if it isn't already.
        parts = re.split(r"[_\-\s]+", raw)
        class_base = "".join(p[0].upper() + p[1:] if p else "" for p in parts)
    else:
        class_base = f"Custom{adapter_type.capitalize()}"

    suffix = "Backend"
    class_name = class_base if class_base.endswith(suffix) else f"{class_base}{suffix}"

    # snake_case file name
    snake = _to_snake(class_name)
    file_name = f"{snake}.py"

    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / file_name

    content = _build_adapter_stub(adapter_type, class_name)
    out_path.write_text(content, encoding="utf-8")

    typer.echo(f"\n  wrote {out_path}")
    typer.echo(f"\n✓ Adapter stub: {out_path.resolve()}")
    typer.echo("")

    # Print the TOML snippet
    toml_key = "backend"
    module_path = f"mypackage.{snake.removesuffix('_backend')}.{class_name}"
    typer.echo("Reference it in your rig TOML:")
    typer.echo("")
    _toml_snippet(adapter_type, module_path)
    typer.echo("")
    typer.echo(f"  Then: crucihil run --suite suites/smoke.yaml --rig <rig>.toml -v")


def _toml_snippet(adapter_type: str, module_path: str) -> None:
    snippets = {
        "can":    f'  [rig.can.can0]\n  interface = "can0"\n  bitrate   = 500000\n  backend   = "{module_path}"',
        "power":  f'  [rig.power.ecu_main]\n  backend = "{module_path}"\n  default = "off"',
        "gpio":   f'  [rig.gpio]\n  ignition_enable = {{ pin = 22, direction = "out", default = false, backend = "{module_path}" }}',
        "doip":   f'  [rig.ethernet.eth0]\n  interface    = "eth0"\n  ip           = "169.254.0.1"\n  doip_backend = "{module_path}"',
        "someip": f'  [rig.ethernet.eth0]\n  interface      = "eth0"\n  ip             = "169.254.0.1"\n  someip_backend = "{module_path}"',
        "udp":    f'  [rig.udp.eth0]\n  interface = "eth0"\n  ip        = "169.254.0.1"\n  backend   = "{module_path}"',
        "uds":    f'  [rig.uds]\n  backend = "{module_path}"',
    }
    typer.echo(snippets.get(adapter_type, f'  backend = "{module_path}"'))


def _build_adapter_stub(adapter_type: str, class_name: str) -> str:
    builders = {
        "can":    _adapter_can,
        "power":  _adapter_power,
        "gpio":   _adapter_gpio,
        "doip":   _adapter_doip,
        "someip": _adapter_someip,
        "udp":    _adapter_udp,
        "uds":    _adapter_uds,
    }
    return builders[adapter_type](class_name)


def _adapter_power(cls: str) -> str:
    return f'''"""Custom power backend — {cls}.

Reference in rig TOML:
    [rig.power.ecu_main]
    backend = "mypackage.{_to_snake(cls)}.{cls}"
    default = "off"
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractPowerBackend
from crucihil.hal.models.exceptions import PowerError


class {cls}(AbstractPowerBackend):
    """Controls a single power rail via custom hardware.

    One instance is created per [rig.power.<name>] entry that references
    this backend.  The Rig calls connect() before any test runs and
    disconnect() in teardown — always, even if a test fails.
    """

    def __init__(self) -> None:
        # TODO: add fields for any hardware-specific config, e.g.:
        # self._port: str = ""
        pass

    async def connect(self) -> None:
        """Open the connection to the power hardware (relay board, bench PSU, etc.)."""
        # TODO: open serial port, USB connection, etc.
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Release the hardware connection.  Safe to call even if connect() failed."""
        # TODO: close cleanly — never raise here
        pass

    async def on(self) -> None:
        """Apply power to the rail (e.g. close relay, enable PSU output)."""
        # TODO: send command to your hardware
        raise NotImplementedError("on() not implemented")

    async def off(self) -> None:
        """Remove power from the rail (e.g. open relay, disable PSU output)."""
        # TODO: send command to your hardware
        raise NotImplementedError("off() not implemented")

    async def read_voltage(self) -> float:
        """Return the current rail voltage in volts.

        If your hardware cannot measure voltage, return a fixed nominal value.
        """
        # TODO: query voltage from hardware, or return a fixed nominal:
        return 12.0

    async def set_voltage(self, voltage: float) -> None:
        """Set the output voltage.

        Raise PowerError if your hardware is a simple relay (on/off only).
        Implement this for bench PSUs that support variable voltage.
        """
        raise PowerError(f"{{type(self).__name__}} does not support voltage control")
'''


def _adapter_can(cls: str) -> str:
    return f'''"""Custom CAN backend — {cls}.

Reference in rig TOML:
    [rig.can.can0]
    interface = "can0"
    bitrate   = 500000
    backend   = "mypackage.{_to_snake(cls)}.{cls}"

This backend handles raw byte-level CAN I/O only.  Signal encoding/decoding
(DBC, cantools) is handled by the framework — you never see signal names here,
only arb_id + data bytes.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractCANBackend, CANFrameCallback
from crucihil.hal.models.frames import CANFrame


class {cls}(AbstractCANBackend):
    """Raw CAN frame I/O for a single hardware interface.

    The framework wraps this with DBC decoding and the high-level
    rig.can.expect() / rig.can.send() API — you only implement raw I/O here.
    """

    def __init__(self) -> None:
        self._listeners: list[CANFrameCallback] = []
        # TODO: add fields for your hardware state, e.g.:
        # self._handle: Any = None

    async def connect(self, interface: str, bitrate: int, fd: bool = False) -> None:
        """Open the CAN interface and begin receiving.

        Args:
            interface: OS interface name, e.g. "can0".
            bitrate:   Nominal bitrate in bits/second (e.g. 500000).
            fd:        True if CAN-FD is required (64-byte payloads).
        """
        # TODO: open your hardware adapter with the given interface + bitrate
        # Then start a background receive loop and call self._dispatch(frame)
        # for every received frame.
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Close the interface.  Safe to call even if connect() failed."""
        # TODO: stop receive loop, close hardware
        pass

    async def send(self, arb_id: int, data: bytes) -> None:
        """Transmit a raw CAN frame.

        Args:
            arb_id: Arbitration ID (11-bit standard or 29-bit extended).
            data:   Payload bytes — up to 8 bytes for classic CAN, 64 for FD.
        """
        # TODO: write the frame to your hardware
        raise NotImplementedError("send() not implemented")

    def add_listener(self, cb: CANFrameCallback) -> None:
        """Register an async callback invoked for every received frame."""
        self._listeners.append(cb)

    def remove_listener(self, cb: CANFrameCallback) -> None:
        """Deregister a previously registered listener."""
        if cb in self._listeners:
            self._listeners.remove(cb)

    async def _dispatch(self, frame: CANFrame) -> None:
        """Notify all registered listeners.  Call this from your receive loop."""
        for cb in list(self._listeners):
            await cb(frame)
'''


def _adapter_gpio(cls: str) -> str:
    return f'''"""Custom GPIO backend — {cls}.

Reference in rig TOML:
    [rig.gpio]
    ignition_enable = {{ pin = 22, direction = "out", default = false, backend = "mypackage.{_to_snake(cls)}.{cls}" }}

One backend instance may manage multiple pins (all pins that reference this
backend class share the same instance).  setup_pin() is called once per pin
during rig.connect() before any test runs.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractGPIOBackend
from crucihil.hal.models.exceptions import GPIOError


class {cls}(AbstractGPIOBackend):
    """Digital I/O for a custom GPIO controller.

    Pin names are the logical names from the TOML (e.g. "ignition_enable"),
    not physical numbers.  The framework maps them via setup_pin().
    """

    def __init__(self) -> None:
        self._pins: dict[str, dict] = {{}}  # name -> {{pin, direction, value}}
        # TODO: add hardware connection state, e.g.:
        # self._bus: Any = None

    async def connect(self) -> None:
        """Initialise the GPIO controller hardware."""
        # TODO: open connection to the controller
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Release GPIO resources.  Safe to call even if connect() failed."""
        # TODO: close connection cleanly
        pass

    async def setup_pin(self, name: str, pin: int, direction: str, default: bool) -> None:
        """Configure one pin.  Called by the Rig during startup for each TOML entry.

        Args:
            name:      Logical name (e.g. "ignition_enable") — used in set/read calls.
            pin:       Physical pin number on the controller board.
            direction: "in" for input, "out" for output.
            default:   Initial state for output pins (True = high, False = low).
        """
        self._pins[name] = {{"pin": pin, "direction": direction, "value": default}}
        # TODO: configure the physical pin on your hardware
        if direction == "out":
            # TODO: set the pin to its default state
            pass

    async def set(self, name: str, high: bool) -> None:
        """Drive an output pin high or low.

        Raises:
            GPIOError: If the pin is not configured or is an input.
        """
        info = self._pins.get(name)
        if info is None:
            raise GPIOError(f"GPIO pin '{{name}}' is not configured")
        if info["direction"] != "out":
            raise GPIOError(f"GPIO pin '{{name}}' is an input — cannot drive it")
        # TODO: set the physical pin to 'high' on your hardware
        self._pins[name]["value"] = high

    async def read(self, name: str) -> bool:
        """Read the current state of a pin (input or output).

        Returns:
            True if the pin is high, False if low.

        Raises:
            GPIOError: If the pin is not configured.
        """
        info = self._pins.get(name)
        if info is None:
            raise GPIOError(f"GPIO pin '{{name}}' is not configured")
        # TODO: read the physical pin state from your hardware
        return info["value"]  # placeholder — replace with real hardware read
'''


def _adapter_doip(cls: str) -> str:
    return f'''"""Custom DoIP backend — {cls}.

Reference in rig TOML:
    [rig.ethernet.eth0]
    interface    = "eth0"
    ip           = "169.254.0.1"
    doip_backend = "mypackage.{_to_snake(cls)}.{cls}"

DoIP (Diagnostics over IP) transports UDS diagnostic requests to ECUs
over Ethernet.  This ABC covers routing activation, UDS transport, and
entity discovery.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractDoIPBackend
from crucihil.hal.models.frames import DoIPEntity, DoIPEntityStatus, DoIPResponse
from crucihil.hal.models.exceptions import DoIPError


class {cls}(AbstractDoIPBackend):
    """DoIP transport for a single Ethernet interface."""

    def __init__(self) -> None:
        # TODO: add connection state fields
        pass

    async def connect(
        self,
        ip: str,
        port: int,
        source_address: int,
        timeout: float,
    ) -> None:
        """Establish a DoIP TCP session and perform routing activation.

        Args:
            ip:             DoIP gateway IP address.
            port:           TCP port (standard: 13400).
            source_address: Tester's logical address (e.g. 0x0E00).
            timeout:        Seconds to wait for routing activation response.

        Raises:
            DoIPError: If routing activation fails or times out.
        """
        # TODO: open TCP connection to ip:port, send routing activation request
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Close the DoIP TCP session.  Safe to call even if connect() failed."""
        # TODO: close TCP socket
        pass

    async def uds_request(
        self,
        target_address: int,
        payload: bytes,
        timeout: float,
    ) -> DoIPResponse:
        """Send a UDS PDU to an ECU and wait for the response.

        Args:
            target_address: ECU logical address (from [rig.ecus]).
            payload:        Full UDS request bytes (service ID + data).
            timeout:        Seconds to wait for response.

        Returns:
            DoIPResponse with positive=True on positive response,
            positive=False + nrc set on negative response code.

        Raises:
            DoIPError:       On transport-level failure.
        """
        # TODO: wrap payload in DoIP diagnostic message, send, wait for response
        raise NotImplementedError("uds_request() not implemented")

    async def discover(self, timeout: float) -> list[DoIPEntity]:
        """Broadcast a vehicle announcement request and collect responses.

        Returns:
            List of discovered DoIPEntity objects (may be empty if nothing responds).
        """
        # TODO: send DoIP vehicle announcement request, collect responses for `timeout` seconds
        return []

    async def entity_status(
        self,
        target_address: int,
        timeout: float,
    ) -> DoIPEntityStatus:
        """Query an entity's DoIP status (e.g. max payload, open sockets).

        Raises:
            DoIPError: If the entity does not respond within timeout.
        """
        # TODO: send DoIP entity status request, parse response
        raise NotImplementedError("entity_status() not implemented")
'''


def _adapter_someip(cls: str) -> str:
    return f'''"""Custom SOME/IP backend — {cls}.

Reference in rig TOML:
    [rig.ethernet.eth0]
    interface      = "eth0"
    ip             = "169.254.0.1"
    someip_backend = "mypackage.{_to_snake(cls)}.{cls}"

Phase 0 scope: Events and Fields only.  SOME/IP Methods (request/response
RPC) are Phase 1.  Event listeners are called by the framework as services
publish events.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractSOMEIPBackend, SOMEIPEventCallback
from crucihil.hal.models.frames import SOMEIPEvent, SOMEIPServiceInfo
from crucihil.hal.models.exceptions import SOMEIPError, SOMEIPTimeoutError


class {cls}(AbstractSOMEIPBackend):
    """SOME/IP service interaction for a single Ethernet interface."""

    def __init__(self) -> None:
        self._listeners: dict[tuple[int, int], list[SOMEIPEventCallback]] = {{}}
        # TODO: add SOME/IP stack state

    async def connect(self, interface: str, ip: str) -> None:
        """Initialise the SOME/IP stack on this interface/IP.

        Args:
            interface: OS interface name, e.g. "eth0".
            ip:        Local IP address to bind to.
        """
        # TODO: start the SOME/IP stack (e.g. vsomeip daemon, custom socket)
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Shut down the SOME/IP stack.  Safe to call even if connect() failed."""
        pass

    async def find_service(
        self,
        service_id: int,
        instance_id: int,
        timeout: float,
    ) -> SOMEIPServiceInfo:
        """Wait for a service to announce itself via SOME/IP-SD.

        Raises:
            SOMEIPTimeoutError: If the service does not appear within timeout.
        """
        # TODO: listen for SOME/IP service discovery announcements
        raise NotImplementedError("find_service() not implemented")

    async def subscribe(
        self,
        service_id: int,
        instance_id: int,
        eventgroup_id: int,
    ) -> None:
        """Send an event-group subscription request.

        Raises:
            SOMEIPError: If the subscription is rejected.
        """
        # TODO: send SubscribeEventgroup via SOME/IP-SD
        raise NotImplementedError("subscribe() not implemented")

    async def get_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        timeout: float,
    ) -> bytes:
        """Read a SOME/IP field value (GET request).

        Returns raw serialized bytes — deserialization is the framework's job.

        Raises:
            SOMEIPTimeoutError: If no response arrives within timeout.
        """
        # TODO: send SOME/IP GET request, return raw response payload bytes
        raise NotImplementedError("get_field() not implemented")

    async def set_field(
        self,
        service_id: int,
        instance_id: int,
        field_id: int,
        value: bytes,
    ) -> None:
        """Write a SOME/IP field value (SET request).

        Args:
            value: Raw serialized bytes — serialization is the framework's job.
        """
        # TODO: send SOME/IP SET request
        raise NotImplementedError("set_field() not implemented")

    def add_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        """Register an async callback for a specific (service_id, event_id) pair."""
        key = (service_id, event_id)
        self._listeners.setdefault(key, []).append(cb)

    def remove_event_listener(
        self,
        service_id: int,
        event_id: int,
        cb: SOMEIPEventCallback,
    ) -> None:
        """Deregister a previously registered event listener."""
        key = (service_id, event_id)
        if key in self._listeners and cb in self._listeners[key]:
            self._listeners[key].remove(cb)

    async def _dispatch_event(self, event: SOMEIPEvent) -> None:
        """Notify all listeners for this event.  Call from your receive loop."""
        for cb in list(self._listeners.get((event.service_id, event.event_id), [])):
            await cb(event)
'''


def _adapter_udp(cls: str) -> str:
    return f'''"""Custom UDP backend — {cls}.

Reference in rig TOML:
    [rig.udp.eth0]
    interface = "eth0"
    ip        = "169.254.0.1"
    backend   = "mypackage.{_to_snake(cls)}.{cls}"

Phase 1 placeholder — intended for AV/robotics teams using raw UDP for
sensor data or custom application protocols.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractUDPBackend
from crucihil.hal.models.exceptions import CANTimeoutError  # reused for transport timeouts


class {cls}(AbstractUDPBackend):
    """Raw UDP datagram transport."""

    def __init__(self) -> None:
        # TODO: add socket/transport state
        pass

    async def connect(self, interface: str, ip: str, port: int) -> None:
        """Bind to the local IP/port and begin receiving datagrams.

        Args:
            interface: OS interface name (for binding to the correct NIC).
            ip:        Local IP address to bind to.
            port:      Local port (0 = ephemeral / OS-assigned).
        """
        # TODO: create asyncio UDP socket, bind to ip:port
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Unbind and close the socket.  Safe to call even if connect() failed."""
        pass

    async def send(self, data: bytes, dest_ip: str, dest_port: int) -> None:
        """Send a UDP datagram to dest_ip:dest_port."""
        # TODO: transmit datagram
        raise NotImplementedError("send() not implemented")

    async def receive(self, timeout: float) -> tuple[bytes, str, int]:
        """Wait for a datagram and return (data, source_ip, source_port).

        Raises:
            CANTimeoutError: If no datagram arrives within timeout seconds.
        """
        # TODO: await recv with asyncio.wait_for
        raise NotImplementedError("receive() not implemented")
'''


def _adapter_uds(cls: str) -> str:
    return f'''"""Custom UDS backend — {cls}.

Reference in rig TOML:
    [rig.uds]
    backend = "mypackage.{_to_snake(cls)}.{cls}"

Standalone UDS transport (not via DoIP).  Use this for UDS over raw
ISO-TP/CAN or over a custom Ethernet framing that isn't standard DoIP.
For UDS over DoIP, use the [rig.ethernet] + [rig.ecus] sections instead.
"""

from __future__ import annotations

from crucihil.hal.backends.base import AbstractUDSBackend
from crucihil.hal.models.exceptions import DoIPNegativeResponseError, CANTimeoutError


class {cls}(AbstractUDSBackend):
    """Standalone UDS diagnostic channel."""

    def __init__(self) -> None:
        # TODO: add transport state (serial, socket, CAN handle, etc.)
        pass

    async def connect(self) -> None:
        """Open the UDS channel."""
        # TODO: establish the underlying transport
        raise NotImplementedError("connect() not implemented")

    async def disconnect(self) -> None:
        """Close the UDS channel.  Safe to call even if connect() failed."""
        pass

    async def request(
        self,
        service_id: int,
        payload: bytes,
        timeout: float,
    ) -> bytes:
        """Send a UDS service request and return the positive response payload.

        Args:
            service_id: UDS service byte (e.g. 0x22 = ReadDataByIdentifier).
            payload:    Request data bytes (without the service byte).
            timeout:    Seconds to wait for a response.

        Returns:
            Positive response payload bytes (without the positive response SID byte).

        Raises:
            DoIPNegativeResponseError: On NRC (negative response code).
            CANTimeoutError:           If no response arrives within timeout.
        """
        # TODO: frame the request, send over your transport, await response
        raise NotImplementedError("request() not implemented")
'''


def _to_snake(class_name: str) -> str:
    # PeakUSBBackend → peak_usb_backend  (handles consecutive caps correctly)
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", class_name)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    return s.lower()


def _write_scaffold(cfg, out: Path, suites_dir: Path, tests_dir: Path, rig_path: Path) -> None:
    """Write all scaffold files based on the rig config."""
    rig_name = cfg.name
    has_can = bool(cfg.can)
    has_power = bool(cfg.power)
    has_gpio = bool(cfg.gpio)
    has_ecus = bool(cfg.ecus)
    has_someip = bool(cfg.ethernet)
    has_dbc = cfg.definitions.can_dbc is not None

    power_rails = list(cfg.power.keys())
    gpio_pins = list(cfg.gpio.keys())
    can_ifaces = list(cfg.can.keys())
    ecus = list(cfg.ecus.keys())

    # ── tests/__init__.py ──────────────────────────────────────────────────────
    init_path = tests_dir / "__init__.py"
    if not init_path.exists():
        init_path.write_text("", encoding="utf-8")

    # ── tests/smoke.py ────────────────────────────────────────────────────────
    smoke_py = _build_smoke_py(rig_name, power_rails, gpio_pins, can_ifaces, ecus, has_dbc)
    (tests_dir / "smoke.py").write_text(smoke_py, encoding="utf-8")

    # ── tests/regression.py ───────────────────────────────────────────────────
    regression_py = _build_regression_py(rig_name, power_rails, gpio_pins, can_ifaces, ecus, has_dbc, has_someip)
    (tests_dir / "regression.py").write_text(regression_py, encoding="utf-8")

    # ── suites/smoke.yaml ─────────────────────────────────────────────────────
    smoke_yaml = _build_smoke_yaml(rig_name, power_rails, gpio_pins, can_ifaces, ecus)
    (suites_dir / "smoke.yaml").write_text(smoke_yaml, encoding="utf-8")

    # ── suites/regression.yaml ────────────────────────────────────────────────
    regression_yaml = _build_regression_yaml(rig_name, power_rails, gpio_pins, can_ifaces, ecus)
    (suites_dir / "regression.yaml").write_text(regression_yaml, encoding="utf-8")

    for p in [
        tests_dir / "smoke.py",
        tests_dir / "regression.py",
        suites_dir / "smoke.yaml",
        suites_dir / "regression.yaml",
    ]:
        typer.echo(f"  wrote {p.relative_to(out)}")


def _build_smoke_py(rig_name: str, power_rails: list, gpio_pins: list, can_ifaces: list, ecus: list, has_dbc: bool) -> str:
    lines = [
        '"""Smoke tests — quick health checks that run in under 30 seconds.',
        "",
        "How tests work:",
        "  - Each function receives a `rig: Rig` object injected by the framework.",
        "  - Power, GPIO, and sim setup is declared in the YAML suite (setup/teardown).",
        "  - Python functions contain only assertions — use rig.can.expect(), rig.sim, etc.",
        "  - raise AssertionError (or `assert`) → test status = 'fail'",
        "  - raise BlockedError('msg') → test status = 'blocked' (precondition, not firmware bug)",
        '"""',
        "",
        "from crucihil.hal.rig import Rig",
        "from crucihil.hal.models.exceptions import BlockedError",
        "",
        "",
    ]

    # Power cycle smoke — YAML setup handles power.off/on, Python verifies ECU recovered
    if power_rails and ecus:
        rail = power_rails[0]
        ecu = ecus[0]
        lines += [
            f"async def test_power_cycle_{rail}(rig: Rig) -> None:",
            f'    """Power was cycled in YAML setup. Verify {ecu} is responsive afterward."""',
            f"    # The YAML suite's setup: block already ran power.off then power.on.",
            f"    # TODO: assert that the ECU is alive, e.g. check a heartbeat signal:",
            f"    # result = await rig.can.expect(",
            f"    #     signal='HeartbeatMessage.AliveCounter',  # TODO: set signal",
            f"    #     condition=lambda v: v is not None,",
            f"    #     timeout=5.0,",
            f"    # )",
            f"    # assert result.passed, f'{ecu} did not recover after power cycle: {{result.fail_msg}}'",
            f"    pass  # placeholder — replace with real assertion",
            "",
            "",
        ]
    elif power_rails:
        rail = power_rails[0]
        lines += [
            f"async def test_power_cycle_{rail}(rig: Rig) -> None:",
            f'    """Power was cycled in YAML setup. Verify rig is healthy afterward."""',
            f"    # TODO: add an assertion that confirms the rig recovered",
            f"    pass  # placeholder",
            "",
            "",
        ]

    # CAN smoke test
    if can_ifaces and has_dbc:
        iface = can_ifaces[0]
        lines += [
            f"async def test_can_{iface}_alive(rig: Rig) -> None:",
            f'    """Verify at least one CAN message is received on {iface} within 2 seconds."""',
            f"    # TODO: replace with a signal from your DBC file",
            f"    result = await rig.can.expect(",
            f"        signal='YourMessage.YourSignal',  # TODO: set signal name",
            f"        condition=lambda v: v is not None,",
            f"        timeout=2.0,",
            f"    )",
            f"    assert result.passed, f'No CAN traffic seen: {{result.fail_msg}}'",
            "",
            "",
        ]
    elif can_ifaces:
        iface = can_ifaces[0]
        lines += [
            f"async def test_can_{iface}_alive(rig: Rig) -> None:",
            f'    """Verify CAN bus is alive — add can_dbc to [rig.definitions] in the TOML first."""',
            f"    # TODO: add  can_dbc = 'defs/vehicle.dbc'  to [rig.definitions] in {rig_name}.toml",
            f"    # Then set a real signal name below:",
            f"    result = await rig.can.expect(",
            f"        signal='YourMessage.YourSignal',  # TODO: set real signal",
            f"        condition=lambda v: v is not None,",
            f"        timeout=2.0,",
            f"    )",
            f"    assert result.passed, result.fail_msg",
            "",
            "",
        ]

    # ECU connectivity
    if ecus:
        ecu = ecus[0]
        lines += [
            f"async def test_ecu_{ecu}_responds(rig: Rig) -> None:",
            f'    """Verify {ecu} responds to a diagnostic request."""',
            f"    # TODO: uncomment and adapt to your ECU's UDS services",
            f"    # response = await rig.ecu['{ecu}'].uds.ecu_reset(reset_type=0x01)",
            f"    # assert response.positive, f'{ecu} did not acknowledge reset: {{response}}'",
            f"    pass  # placeholder — remove when real assertion is in place",
            "",
            "",
        ]

    if not any([power_rails, gpio_pins, can_ifaces, ecus]):
        lines += [
            "async def test_rig_connects(rig: Rig) -> None:",
            '    """Verify the rig connects without errors (virtual backend health check)."""',
            "    assert rig is not None",
            "    # TODO: add hardware-specific assertions once hardware is defined in the TOML",
            "",
        ]

    return "\n".join(lines)


def _build_regression_py(rig_name: str, power_rails: list, gpio_pins: list, can_ifaces: list, ecus: list, has_dbc: bool, has_someip: bool) -> str:
    lines = [
        '"""Regression tests — full test coverage run on every CI push.',
        "",
        "Key patterns:",
        "  - Power/GPIO control goes in the YAML suite setup:/teardown: blocks.",
        "  - Python functions receive the rig AFTER setup runs — assert the result.",
        "  - params: in the YAML are forwarded as keyword args to the function.",
        '"""',
        "",
        "from crucihil.hal.rig import Rig",
        "from crucihil.hal.models.exceptions import BlockedError",
        "",
        "",
    ]

    if power_rails and ecus:
        ecu = ecus[0]
        lines += [
            f"async def test_{ecu}_cold_boot(rig: Rig, boot_timeout: float = 10.0) -> None:",
            f'    """Verify {ecu} boots and produces bus traffic after a cold power cycle.',
            f"",
            f"    The YAML suite's setup: block powers off then on before this function runs.",
            f"    This function asserts the ECU is alive within boot_timeout seconds.",
            f'    """',
            f"    # TODO: wait for a signal that proves the ECU is alive:",
            f"    # result = await rig.can.expect(",
            f"    #     signal='HeartbeatMessage.AliveCounter',  # TODO: set your signal",
            f"    #     condition=lambda v: v is not None,",
            f"    #     timeout=boot_timeout,",
            f"    # )",
            f"    # assert result.passed, f'{ecu} did not produce traffic within {{boot_timeout}}s: {{result.fail_msg}}'",
            f"    pass  # placeholder — replace with real assertion",
            "",
            "",
        ]

    if can_ifaces and has_dbc:
        lines += [
            "async def test_signal_range(rig: Rig) -> None:",
            '    """Verify a critical signal stays within expected bounds under normal conditions."""',
            "    # TODO: replace with your signal name and expected range",
            "    result = await rig.can.expect(",
            "        signal='YourMessage.YourSignal',  # TODO: set signal",
            "        condition=lambda v: 0 <= v <= 1000,  # TODO: set bounds",
            "        timeout=5.0,",
            "    )",
            "    assert result.passed, result.fail_msg",
            "",
            "",
        ]

    if can_ifaces and not has_dbc:
        lines += [
            "async def test_signal_range(rig: Rig) -> None:",
            '    """Verify a critical signal stays within expected bounds under normal conditions."""',
            "    # TODO: add a DBC to [rig.definitions] can_dbc and replace the stub below",
            "    # result = await rig.can.expect(",
            "    #     signal='YourMessage.YourSignal',  # TODO: set signal",
            "    #     condition=lambda v: 0 <= v <= 1000,  # TODO: set bounds",
            "    #     timeout=5.0,",
            "    # )",
            "    # assert result.passed, result.fail_msg",
            "    pass  # placeholder — uncomment once you have a DBC",
            "",
            "",
        ]

    if can_ifaces:
        lines += [
            "async def test_fault_can_dropout(rig: Rig) -> None:",
            '    """Verify the ECU handles a 1-second CAN dropout gracefully.',
            "",
            "    FaultDescriptor pattern — fault.can_dropout() returns a descriptor,",
            "    not a coroutine. Use it as an async context manager via fault.inject().",
            '    """',
            "    import asyncio",
            "    # TODO: replace 0x100 with the arbitration ID of the message under test",
            "    async with rig.fault.inject(rig.fault.can_dropout(arb_id=0x100, duration=1.0)):",
            "        await asyncio.sleep(1.0)",
            "    # TODO: verify the ECU recovered — check a signal returned to nominal",
            "    pass",
            "",
            "",
        ]

    if has_someip:
        lines += [
            "async def test_someip_event_received(rig: Rig) -> None:",
            '    """Verify a SOME/IP event is received from the ECU within 3 seconds."""',
            "    # TODO: replace with your SOME/IP service/instance/event path",
            "    result = await rig.someip.expect(",
            "        signal='YourService.YourEvent',  # TODO: set signal",
            "        condition=lambda v: v is not None,",
            "        timeout=3.0,",
            "    )",
            "    assert result.passed, result.fail_msg",
            "",
            "",
        ]

    if not any([power_rails and ecus, can_ifaces, has_someip]):
        lines += [
            "async def test_placeholder(rig: Rig) -> None:",
            '    """Placeholder — replace with a real regression test."""',
            "    # CAN:     result = await rig.can.expect(signal='Msg.Sig', condition=lambda v: v > 0, timeout=2.0)",
            "    #          assert result.passed, result.fail_msg",
            "    # SOME/IP: result = await rig.someip.expect(signal='Svc.Event', condition=..., timeout=3.0)",
            "    # Fault:   async with rig.fault.inject(rig.fault.can_dropout(arb_id=0x100, duration=1.0)):",
            "    # Block:   raise BlockedError('precondition not met — rig not ready')",
            "    assert True  # TODO: write your test",
            "",
        ]

    return "\n".join(lines)


def _build_smoke_yaml(rig_name: str, power_rails: list, gpio_pins: list, can_ifaces: list, ecus: list) -> str:
    lines = [
        f"# Smoke suite — quick rig health checks for {rig_name}",
        f"# Run: crucihil run --suite suites/smoke.yaml --rig rigs/{rig_name}.toml -v",
        "",
        "suite:",
        f"  name: {rig_name}_smoke",
        '  version: "1.0.0"',
        f"  description: Quick health checks for {rig_name}",
        "",
        "defaults:",
        "  timeout: 30.0",
        "  suite_types: [smoke]",
        "  hw_variants: []",
        "",
        "tests:",
    ]

    if power_rails and ecus:
        rail = power_rails[0]
        ecu = ecus[0]
        lines += [
            f"  - id: power_cycle_{rail}",
            f"    name: Power cycle {rail}",
            f"    description: Cycle {rail} power and verify {ecu} is responsive afterward",
            f"    tags: [smoke, power]",
            f"    priority: critical",
            f"    setup:",
            f"      - power.off: {rail}",
            f"      - power.on: {rail}",
            f"    module: tests.smoke",
            f"    function: test_power_cycle_{rail}",
            "",
        ]
    elif power_rails:
        rail = power_rails[0]
        lines += [
            f"  - id: power_cycle_{rail}",
            f"    name: Power cycle {rail}",
            f"    description: Verify {rail} power rail can be toggled",
            f"    tags: [smoke, power]",
            f"    priority: critical",
            f"    setup:",
            f"      - power.off: {rail}",
            f"      - power.on: {rail}",
            f"    module: tests.smoke",
            f"    function: test_power_cycle_{rail}",
            "",
        ]

    if can_ifaces:
        iface = can_ifaces[0]
        lines += [
            f"  - id: can_{iface}_alive",
            f"    name: CAN {iface} alive",
            f"    description: Verify CAN traffic seen on {iface}",
            f"    tags: [smoke, can]",
            f"    priority: critical",
            f"    module: tests.smoke",
            f"    function: test_can_{iface}_alive",
            "",
        ]

    if ecus:
        ecu = ecus[0]
        lines += [
            f"  - id: ecu_{ecu}_responds",
            f"    name: ECU {ecu} responds",
            f"    description: Verify {ecu} responds to diagnostic request",
            f"    tags: [smoke, ecu]",
            f"    priority: critical",
            f"    module: tests.smoke",
            f"    function: test_ecu_{ecu}_responds",
            "",
        ]

    if not any([power_rails, can_ifaces, ecus]):
        lines += [
            "  - id: rig_connects",
            "    name: Rig connects",
            "    description: Verify the rig initialises without errors",
            "    tags: [smoke]",
            "    priority: critical",
            "    module: tests.smoke",
            "    function: test_rig_connects",
            "",
        ]

    return "\n".join(lines)


def _build_regression_yaml(rig_name: str, power_rails: list, gpio_pins: list, can_ifaces: list, ecus: list) -> str:
    lines = [
        f"# Regression suite — full coverage for {rig_name}",
        f"# Run: crucihil run --suite suites/regression.yaml --rig rigs/{rig_name}.toml -v",
        "",
        "suite:",
        f"  name: {rig_name}_regression",
        '  version: "1.0.0"',
        f"  description: Regression tests for {rig_name}",
        "",
        "defaults:",
        "  timeout: 60.0",
        "  suite_types: [regression]",
        "  hw_variants: []",
        "",
        "tests:",
    ]

    if power_rails and ecus:
        ecu = ecus[0]
        rail = power_rails[0]
        lines += [
            f"  - id: {ecu}_cold_boot",
            f"    name: Cold boot {ecu}",
            f"    description: Verify {ecu} starts cleanly after a cold power cycle",
            f"    tags: [regression, boot, power]",
            f"    priority: critical",
            f"    timeout: 30.0",
            f"    setup:",
            f"      - power.off: {rail}",
            f"      - power.on: {rail}",
            f"    module: tests.regression",
            f"    function: test_{ecu}_cold_boot",
            f"    params:",
            f"      boot_timeout: 10.0",
            "",
        ]

    if can_ifaces:
        lines += [
            "  - id: signal_range",
            "    name: Signal within expected range",
            "    description: Verify a critical signal stays within bounds under normal conditions",
            "    tags: [regression, can, signals]",
            "    priority: high",
            "    module: tests.regression",
            "    function: test_signal_range",
            "",
            "  - id: fault_can_dropout",
            "    name: CAN dropout fault injection",
            "    description: Verify the ECU handles a 1-second CAN dropout gracefully",
            "    tags: [regression, fault, can]",
            "    priority: high",
            "    module: tests.regression",
            "    function: test_fault_can_dropout",
            "",
        ]

    if not any([power_rails and ecus, can_ifaces]):
        lines += [
            "  - id: placeholder",
            "    name: Placeholder regression test",
            "    description: Replace with your first real regression test",
            "    tags: [regression]",
            "    priority: medium",
            "    module: tests.regression",
            "    function: test_placeholder",
            "",
        ]

    return "\n".join(lines)


__all__ = ["app"]
