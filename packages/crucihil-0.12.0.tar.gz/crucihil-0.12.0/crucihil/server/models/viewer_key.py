"""ViewerKeyRow ORM model — read-only API keys issued by an admin rig."""

from __future__ import annotations

import time

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from crucihil.server.models.base import Base


class ViewerKeyRow(Base):
    __tablename__ = "viewer_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    rig_id: Mapped[str] = mapped_column(String(36), ForeignKey("rigs.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    api_key_hash: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[float] = mapped_column(Float, nullable=False, default=time.time)
    revoked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


__all__ = ["ViewerKeyRow"]
