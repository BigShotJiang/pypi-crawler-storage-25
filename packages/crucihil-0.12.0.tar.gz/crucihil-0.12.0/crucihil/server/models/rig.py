"""RigRow ORM model — one row per registered rig."""

from __future__ import annotations

import time
import uuid

from sqlalchemy import Boolean, Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from crucihil.server.models.base import Base


class RigRow(Base):
    __tablename__ = "rigs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    org_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("orgs.id", ondelete="SET NULL"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(256), nullable=False, unique=True)
    api_key_hash: Mapped[str] = mapped_column(Text, nullable=False)
    role: Mapped[str] = mapped_column(String(16), nullable=False, default="admin")
    last_seen_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    connected: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    version: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[float] = mapped_column(Float, nullable=False, default=time.time)
    extra_meta: Mapped[str] = mapped_column(Text, nullable=False, default="{}")

    runs: Mapped[list["TestRunRow"]] = relationship(  # noqa: F821
        "TestRunRow", back_populates="rig", cascade="all, delete-orphan"
    )


__all__ = ["RigRow"]
