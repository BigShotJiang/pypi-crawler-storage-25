"""Single DeclarativeBase shared by all ORM models and Alembic env.py."""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


__all__ = ["Base"]
