"""OrgRow ORM model — one row per customer organisation."""

from __future__ import annotations

import time
import uuid

from sqlalchemy import Float, String
from sqlalchemy.orm import Mapped, mapped_column

from crucihil.server.models.base import Base


class OrgRow(Base):
    __tablename__ = "orgs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    slug: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    created_at: Mapped[float] = mapped_column(Float, nullable=False, default=time.time)


__all__ = ["OrgRow"]
