"""TestResultRow ORM model — mirrors the SQLite cache schema exactly.

Column names match cache.py so that sync is INSERT ... ON CONFLICT DO NOTHING
with no field mapping required on the agent side.

Note: Uses JSON (not JSONB) so the same model works with both PostgreSQL and
SQLite (used in tests). The Alembic migration uses JSONB for PostgreSQL.
"""

from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from crucihil.server.models.base import Base


class TestResultRow(Base):
    __tablename__ = "test_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    test_id: Mapped[str] = mapped_column(String(256), nullable=False)
    run_id: Mapped[str] = mapped_column(String(64), ForeignKey("test_runs.id", ondelete="CASCADE"), nullable=False, index=True)
    suite_name: Mapped[str] = mapped_column(String(256), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    duration: Mapped[float] = mapped_column(Float, nullable=False)
    started_at: Mapped[float] = mapped_column(Float, nullable=False)
    completed_at: Mapped[float] = mapped_column(Float, nullable=False)
    errors: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    logs: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    signals: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    extra_meta: Mapped[str] = mapped_column(Text, nullable=False, default="{}")

    run: Mapped["TestRunRow"] = relationship("TestRunRow", back_populates="results")  # noqa: F821

    __table_args__ = (
        UniqueConstraint("test_id", "run_id", name="uq_test_results_test_run"),
        Index("ix_test_results_started_at", "started_at"),
        Index("ix_test_results_status", "status"),
    )


__all__ = ["TestResultRow"]
