"""TestRunRow ORM model — one row per crucihil run invocation."""

from __future__ import annotations

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from crucihil.server.models.base import Base


class TestRunRow(Base):
    __tablename__ = "test_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)  # run_id from agent
    rig_id: Mapped[str] = mapped_column(String(36), ForeignKey("rigs.id", ondelete="CASCADE"), nullable=False, index=True)
    suite_name: Mapped[str] = mapped_column(String(256), nullable=False)
    started_at: Mapped[float] = mapped_column(Float, nullable=False, index=True)
    completed_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="running")
    total: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    passed: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    failed: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    blocked: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    errored: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    skipped: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    triggered_by: Mapped[str | None] = mapped_column(String(32), nullable=True)

    rig: Mapped["RigRow"] = relationship("RigRow", back_populates="runs")  # noqa: F821
    results: Mapped[list["TestResultRow"]] = relationship(  # noqa: F821
        "TestResultRow", back_populates="run", cascade="all, delete-orphan"
    )


__all__ = ["TestRunRow"]
