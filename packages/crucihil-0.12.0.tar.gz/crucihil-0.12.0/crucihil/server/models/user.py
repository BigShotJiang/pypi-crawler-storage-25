"""UserRow ORM model — one row per human user."""

from __future__ import annotations

import time
import uuid

from sqlalchemy import Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from crucihil.server.models.base import Base


class UserRow(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    org_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("orgs.id", ondelete="CASCADE"), nullable=False
    )
    email: Mapped[str] = mapped_column(String(320), nullable=False, unique=True)
    # Null until the user accepts their invite and sets a password.
    password_hash: Mapped[str | None] = mapped_column(Text, nullable=True)
    role: Mapped[str] = mapped_column(String(16), nullable=False, default="member")
    invite_token_hash: Mapped[str | None] = mapped_column(Text, nullable=True)
    invite_token_expires_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    joined_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[float] = mapped_column(Float, nullable=False, default=time.time)
    password_reset_token_hash: Mapped[str | None] = mapped_column(Text, nullable=True)
    password_reset_token_expires_at: Mapped[float | None] = mapped_column(Float, nullable=True)


__all__ = ["UserRow"]
