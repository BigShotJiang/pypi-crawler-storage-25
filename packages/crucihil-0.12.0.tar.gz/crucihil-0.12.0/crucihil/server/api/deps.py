"""FastAPI dependency functions shared across routers."""

from __future__ import annotations

import secrets
from typing import Annotated, Any

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy.orm import Session

from crucihil.server.db.session import get_db
from crucihil.server.models.rig import RigRow
from crucihil.server.models.user import UserRow
from crucihil.server.services.auth import decode_jwt

_bearer = HTTPBearer(auto_error=True)

_AUTH_ERR = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Invalid or expired token",
    headers={"WWW-Authenticate": "Bearer"},
)


def _decode_token(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(_bearer)],
) -> dict[str, Any]:
    """Decode and verify the Bearer JWT. Raises 401 on failure.

    Single shared sub-dep so a request decodes the JWT exactly once even
    when multiple deps compose it.
    """
    try:
        return decode_jwt(credentials.credentials)
    except (JWTError, KeyError):
        raise _AUTH_ERR


# ── Machine token deps (rig agents, MCP, CI viewer keys) ──────────────────────
# These are UNCHANGED — all existing callers and tests continue to work.

def verify_registration_token(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(_bearer)],
) -> None:
    """Verify the static REGISTRATION_TOKEN for rig bootstrap via setup.sh."""
    from crucihil.server.config import get_settings

    settings = get_settings()
    if not secrets.compare_digest(
        credentials.credentials, settings.REGISTRATION_TOKEN
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid registration token",
            headers={"WWW-Authenticate": "Bearer"},
        )


def get_current_rig(
    payload: Annotated[dict[str, Any], Depends(_decode_token)],
    db: Annotated[Session, Depends(get_db)],
) -> RigRow:
    """Return the RigRow for a rig/viewer JWT. Raises 401 if rig not found."""
    rig_id = payload.get("rig_id")
    if not rig_id:
        raise _AUTH_ERR
    rig = db.get(RigRow, rig_id)
    if rig is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Rig not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return rig


def get_admin_rig(
    payload: Annotated[dict[str, Any], Depends(_decode_token)],
    rig: Annotated[RigRow, Depends(get_current_rig)],
) -> RigRow:
    """Like get_current_rig but requires role == 'admin'. Raises 403 for viewers."""
    if payload.get("role", "viewer") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )
    return rig


# ── Human user deps (dashboard email/password login) ──────────────────────────

def get_current_user(
    payload: Annotated[dict[str, Any], Depends(_decode_token)],
    db: Annotated[Session, Depends(get_db)],
) -> UserRow:
    """Return the UserRow for a user JWT (type=='user'). Raises 401 otherwise."""
    if payload.get("type") != "user":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User login required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user = db.get(UserRow, payload.get("sub"))
    if user is None:
        raise _AUTH_ERR
    return user


def require_admin_user(
    user: Annotated[UserRow, Depends(get_current_user)],
) -> UserRow:
    """Like get_current_user but requires role == 'admin'. Raises 403 for members."""
    if user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )
    return user


# ── Hybrid deps (accept both human users and machine tokens) ──────────────────
# Used in commit 4 to replace get_current_rig on shared read/write endpoints.

def get_any_authenticated(
    payload: Annotated[dict[str, Any], Depends(_decode_token)],
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, Any]:
    """Accept any valid JWT — user, rig, or viewer — and verify the entity exists."""
    token_type = payload.get("type", "rig")  # default 'rig' for pre-migration tokens
    if token_type == "user":
        if db.get(UserRow, payload.get("sub")) is None:
            raise _AUTH_ERR
    else:
        rig_id = payload.get("rig_id") or payload.get("sub")
        if not rig_id or db.get(RigRow, rig_id) is None:
            raise _AUTH_ERR
    return payload


def get_write_access(
    payload: Annotated[dict[str, Any], Depends(_decode_token)],
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, Any]:
    """Accept write-capable tokens: user (admin|member) or admin rig. Reject viewers."""
    token_type = payload.get("type", "rig")
    role = payload.get("role", "viewer")

    if token_type == "user":
        if role not in ("admin", "member"):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Write access required")
        if db.get(UserRow, payload.get("sub")) is None:
            raise _AUTH_ERR
    else:
        if role != "admin":
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin role required")
        rig_id = payload.get("rig_id") or payload.get("sub")
        if not rig_id or db.get(RigRow, rig_id) is None:
            raise _AUTH_ERR

    return payload


def get_admin_principal(
    payload: Annotated[dict[str, Any], Depends(_decode_token)],
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, Any]:
    """Accept admin-level tokens: user(admin) or admin rig. Reject member and viewer."""
    token_type = payload.get("type", "rig")
    role = payload.get("role", "viewer")

    if role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin role required")

    if token_type == "user":
        if db.get(UserRow, payload.get("sub")) is None:
            raise _AUTH_ERR
    else:
        rig_id = payload.get("rig_id") or payload.get("sub")
        if not rig_id or db.get(RigRow, rig_id) is None:
            raise _AUTH_ERR

    return payload


__all__ = [
    "get_db",
    "get_current_rig",
    "get_admin_rig",
    "verify_registration_token",
    "get_current_user",
    "require_admin_user",
    "get_any_authenticated",
    "get_write_access",
    "get_admin_principal",
]
