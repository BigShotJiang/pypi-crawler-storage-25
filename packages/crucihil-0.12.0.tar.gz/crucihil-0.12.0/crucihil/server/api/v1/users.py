"""Org user management endpoints.

POST   /api/v1/orgs/{slug}/invites           — invite a new member (admin only)
GET    /api/v1/orgs/{slug}/users             — list members (admin only)
DELETE /api/v1/orgs/{slug}/users/{user_id}   — remove member (admin only, not self)
"""

from __future__ import annotations

import time
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from crucihil.server.api.deps import get_db, require_admin_user
from crucihil.server.config import get_settings
from crucihil.server.models.org import OrgRow
from crucihil.server.models.user import UserRow
from crucihil.server.services.auth import generate_invite_token, hash_invite_token
from crucihil.server.services.email import send_invite_email

router = APIRouter(prefix="/orgs", tags=["orgs"])

_INVITE_TTL_SECONDS = 72 * 3600  # 72 hours


class InviteRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    role: str = Field(default="member", pattern="^(admin|member)$")


class UserSummary(BaseModel):
    id: str
    email: str
    role: str
    joined_at: float | None
    created_at: float


def _get_org_or_404(slug: str, db: Session) -> OrgRow:
    org = db.execute(select(OrgRow).where(OrgRow.slug == slug)).scalar_one_or_none()
    if org is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Org not found")
    return org


def _assert_same_org(user: UserRow, org: OrgRow) -> None:
    if user.org_id != org.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")


@router.post("/{slug}/invites", status_code=status.HTTP_201_CREATED)
def invite_user(
    slug: str,
    body: InviteRequest,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[UserRow, Depends(require_admin_user)],
) -> dict:
    """Invite a new user to the org. Sends a Resend email with a one-time accept link."""
    org = _get_org_or_404(slug, db)
    _assert_same_org(admin, org)

    email = body.email.lower().strip()
    if db.execute(select(UserRow).where(UserRow.email == email)).scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this email already exists.",
        )

    raw_token = generate_invite_token()
    now = time.time()
    user = UserRow(
        org_id=org.id,
        email=email,
        password_hash=None,
        role=body.role,
        invite_token_hash=hash_invite_token(raw_token),
        invite_token_expires_at=now + _INVITE_TTL_SECONDS,
        joined_at=None,
        created_at=now,
    )
    db.add(user)
    db.commit()

    settings = get_settings()
    invite_url = f"{settings.APP_URL}/accept-invite?token={raw_token}"
    send_invite_email(to_email=email, org_name=org.name, invite_url=invite_url)

    return {"detail": "Invite sent.", "email": email, "role": body.role}


@router.get("/{slug}/users", response_model=list[UserSummary])
def list_users(
    slug: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[UserRow, Depends(require_admin_user)],
) -> list[UserSummary]:
    """List all members of an org. Admin only."""
    org = _get_org_or_404(slug, db)
    _assert_same_org(admin, org)

    rows = db.execute(
        select(UserRow).where(UserRow.org_id == org.id).order_by(UserRow.created_at.asc())
    ).scalars().all()
    return [
        UserSummary(id=r.id, email=r.email, role=r.role, joined_at=r.joined_at, created_at=r.created_at)
        for r in rows
    ]


@router.delete("/{slug}/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_user(
    slug: str,
    user_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[UserRow, Depends(require_admin_user)],
) -> None:
    """Remove a user from the org. Admin cannot remove their own account."""
    org = _get_org_or_404(slug, db)
    _assert_same_org(admin, org)

    if admin.id == user_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Cannot remove your own account.",
        )

    target = db.get(UserRow, user_id)
    if target is None or target.org_id != org.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    db.delete(target)
    db.commit()
