"""Auth endpoints.

POST /api/v1/auth/token                — machine auth: exchange API key for JWT (unchanged)
POST /api/v1/auth/login                — human auth: email + password → user JWT
GET  /api/v1/auth/invite/{token}       — validate an invite token (returns email + org name)
POST /api/v1/auth/invite/accept        — accept an invite, set password, return user JWT
POST /api/v1/auth/forgot-password      — request a password-reset link (always 200, no enumeration)
GET  /api/v1/auth/password-reset/{tok} — validate a reset token (returns email)
POST /api/v1/auth/reset-password       — consume reset token, set new password, return JWT
"""

from __future__ import annotations

import time
from collections import defaultdict
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from crucihil.server.config import get_settings
from crucihil.server.api.deps import get_db
from crucihil.server.models.org import OrgRow  # noqa: F401 (used in validate_invite + accept)
from crucihil.server.models.rig import RigRow
from crucihil.server.models.user import UserRow
from crucihil.server.models.viewer_key import ViewerKeyRow
from crucihil.server.services.auth import (
    hash_invite_token,
    hash_password,
    hash_password_reset_token,
    generate_password_reset_token,
    issue_jwt,
    issue_user_jwt,
    verify_api_key,
    verify_password,
)
from crucihil.server.services.email import send_password_reset_email

router = APIRouter(prefix="/auth", tags=["auth"])

# ── Rate limiter for POST /auth/login ─────────────────────────────────────────
# Keyed by normalised email. In-memory — sufficient for single-instance deploys.
# Replace with Redis for multi-instance or high-traffic scenarios.

_login_attempts: dict[str, list[float]] = defaultdict(list)
_RATE_WINDOW = 60    # seconds
_RATE_MAX = 5        # max attempts per window per email


def _check_rate_limit(email: str) -> None:
    now = time.time()
    key = email.lower()
    _login_attempts[key] = [t for t in _login_attempts[key] if now - t < _RATE_WINDOW]
    if len(_login_attempts[key]) >= _RATE_MAX:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many login attempts. Try again in a minute.",
        )
    _login_attempts[key].append(now)


def _reset_rate_limiter() -> None:
    """Clear all rate-limit state. Called from tests only."""
    _login_attempts.clear()


# Lazily computed bcrypt hash for constant-time failure when email is not found.
# Prevents timing-based email enumeration. Computed on first login attempt so it
# does not run during module import / test collection.
_DUMMY_HASH: str | None = None


def _get_dummy_hash() -> str:
    global _DUMMY_HASH
    if _DUMMY_HASH is None:
        _DUMMY_HASH = hash_password("crucihil-dummy-noenum")
    return _DUMMY_HASH

_INVALID_CREDS = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Invalid email or password.",
)

# ── Schemas ───────────────────────────────────────────────────────────────────


class TokenRequest(BaseModel):
    api_key: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int


class LoginRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=128)


class InviteInfo(BaseModel):
    email: str
    org_name: str


class AcceptInviteRequest(BaseModel):
    token: str
    password: str = Field(min_length=8, max_length=128)


# ── Machine auth (unchanged) ──────────────────────────────────────────────────


@router.post("/token", response_model=TokenResponse)
def get_token(
    body: TokenRequest,
    db: Annotated[Session, Depends(get_db)],
) -> TokenResponse:
    """Exchange an API key for a JWT. Tries rig keys then viewer keys.

    Returns 401 for any invalid or revoked key — deliberately non-specific.
    """
    for row in db.execute(select(RigRow)).scalars().all():
        if verify_api_key(body.api_key, row.api_key_hash):
            token_data = issue_jwt(rig_name=row.name, rig_id=row.id, role=row.role)
            return TokenResponse(**token_data)

    for vk in db.execute(
        select(ViewerKeyRow).where(ViewerKeyRow.revoked == False)  # noqa: E712
    ).scalars().all():
        if verify_api_key(body.api_key, vk.api_key_hash):
            rig = db.get(RigRow, vk.rig_id)
            if rig is None:
                continue
            token_data = issue_jwt(rig_name=rig.name, rig_id=rig.id, role="viewer")
            return TokenResponse(**token_data)

    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")


# ── Human auth ────────────────────────────────────────────────────────────────


@router.post("/login", response_model=TokenResponse)
def login(
    body: LoginRequest,
    db: Annotated[Session, Depends(get_db)],
) -> TokenResponse:
    """Email + password → user JWT.

    Rate-limited to 5 attempts per 60 s per email.
    Returns the same 401 whether the email is unknown or the password is wrong
    to prevent email enumeration via error messages or response timing.
    """
    email = body.email.lower().strip()
    _check_rate_limit(email)

    user = db.execute(select(UserRow).where(UserRow.email == email)).scalar_one_or_none()

    if user is None or user.password_hash is None:
        # Run bcrypt verify on a dummy hash so response time matches a real attempt,
        # preventing timing-based email enumeration.
        verify_password(body.password, _get_dummy_hash())
        raise _INVALID_CREDS

    if not verify_password(body.password, user.password_hash):
        raise _INVALID_CREDS

    org = db.get(OrgRow, user.org_id)
    org_slug = org.slug if org else ""
    token_data = issue_user_jwt(user_id=user.id, org_id=user.org_id, org_slug=org_slug, role=user.role)
    return TokenResponse(**token_data)


@router.get("/invite/{token}", response_model=InviteInfo)
def validate_invite(
    token: str,
    db: Annotated[Session, Depends(get_db)],
) -> InviteInfo:
    """Validate an invite token and return the invitee's email and org name.

    Does NOT consume the token. Use POST /auth/invite/accept to accept.
    Returns 404 for missing, expired, or already-accepted tokens (no enumeration).
    """
    token_hash = hash_invite_token(token)
    user = db.execute(
        select(UserRow).where(UserRow.invite_token_hash == token_hash)
    ).scalar_one_or_none()

    if user is None or user.invite_token_expires_at is None or user.invite_token_expires_at < time.time():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Invite not found or expired.")

    org = db.get(OrgRow, user.org_id)
    if org is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Invite not found or expired.")

    return InviteInfo(email=user.email, org_name=org.name)


@router.post("/invite/accept", response_model=TokenResponse)
def accept_invite(
    body: AcceptInviteRequest,
    db: Annotated[Session, Depends(get_db)],
) -> TokenResponse:
    """Accept an invite: set a password and return a user JWT.

    The invite token is cleared immediately on success — it cannot be reused.
    Returns 404 for missing, expired, or already-accepted tokens.
    """
    token_hash = hash_invite_token(body.token)
    user = db.execute(
        select(UserRow).where(UserRow.invite_token_hash == token_hash)
    ).scalar_one_or_none()

    if user is None or user.invite_token_expires_at is None or user.invite_token_expires_at < time.time():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Invite not found or expired.")

    user.password_hash = hash_password(body.password)
    user.invite_token_hash = None
    user.invite_token_expires_at = None
    user.joined_at = time.time()
    db.commit()

    org = db.get(OrgRow, user.org_id)
    org_slug = org.slug if org else ""
    token_data = issue_user_jwt(user_id=user.id, org_id=user.org_id, org_slug=org_slug, role=user.role)
    return TokenResponse(**token_data)


# ── Password reset ─────────────────────────────────────────────────────────────

_RESET_TTL = 3600  # 1 hour

_reset_attempts: dict[str, list[float]] = defaultdict(list)
_RESET_RATE_WINDOW = 300
_RESET_RATE_MAX = 5


def _check_reset_rate_limit(email: str) -> None:
    now = time.time()
    key = email.lower()
    _reset_attempts[key] = [t for t in _reset_attempts[key] if now - t < _RESET_RATE_WINDOW]
    if len(_reset_attempts[key]) >= _RESET_RATE_MAX:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many reset attempts. Try again later.",
        )
    _reset_attempts[key].append(now)


def _reset_reset_rate_limiter() -> None:
    """Clear all reset rate-limit state. Called from tests only."""
    _reset_attempts.clear()


class ForgotPasswordRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)


class PasswordResetInfo(BaseModel):
    email: str


class ResetPasswordRequest(BaseModel):
    token: str
    password: str = Field(min_length=8, max_length=128)


_RESET_SENT_MSG = "If an account exists with that email address, a reset link has been sent."


@router.post("/forgot-password", status_code=status.HTTP_200_OK)
def forgot_password(
    body: ForgotPasswordRequest,
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, str]:
    """Request a password-reset link.

    Always returns 200 — never reveals whether the email exists.
    Rate-limited to 5 requests per 5 minutes per email.
    """
    email = body.email.lower().strip()
    _check_reset_rate_limit(email)

    user = db.execute(select(UserRow).where(UserRow.email == email)).scalar_one_or_none()

    if user is not None and user.password_hash is not None:
        raw_token = generate_password_reset_token()
        user.password_reset_token_hash = hash_password_reset_token(raw_token)
        user.password_reset_token_expires_at = time.time() + _RESET_TTL
        db.commit()

        settings = get_settings()
        reset_url = f"{settings.APP_URL}/reset-password?token={raw_token}"
        send_password_reset_email(to_email=email, reset_url=reset_url)

    return {"message": _RESET_SENT_MSG}


@router.get("/password-reset/{token}", response_model=PasswordResetInfo)
def validate_password_reset(
    token: str,
    db: Annotated[Session, Depends(get_db)],
) -> PasswordResetInfo:
    """Validate a password-reset token and return the email.

    Does NOT consume the token. Returns 404 for missing, expired, or used tokens.
    """
    token_hash = hash_password_reset_token(token)
    user = db.execute(
        select(UserRow).where(UserRow.password_reset_token_hash == token_hash)
    ).scalar_one_or_none()

    if (
        user is None
        or user.password_reset_token_expires_at is None
        or user.password_reset_token_expires_at < time.time()
    ):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Reset link not found or expired.")

    return PasswordResetInfo(email=user.email)


@router.post("/reset-password", response_model=TokenResponse)
def reset_password(
    body: ResetPasswordRequest,
    db: Annotated[Session, Depends(get_db)],
) -> TokenResponse:
    """Consume a reset token, set a new password, and return a user JWT.

    The token is cleared immediately on success — it cannot be reused.
    Returns 404 for missing, expired, or already-used tokens.
    """
    token_hash = hash_password_reset_token(body.token)
    user = db.execute(
        select(UserRow).where(UserRow.password_reset_token_hash == token_hash)
    ).scalar_one_or_none()

    if (
        user is None
        or user.password_reset_token_expires_at is None
        or user.password_reset_token_expires_at < time.time()
    ):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Reset link not found or expired.")

    user.password_hash = hash_password(body.password)
    user.password_reset_token_hash = None
    user.password_reset_token_expires_at = None
    db.commit()

    org = db.get(OrgRow, user.org_id)
    org_slug = org.slug if org else ""
    token_data = issue_user_jwt(user_id=user.id, org_id=user.org_id, org_slug=org_slug, role=user.role)
    return TokenResponse(**token_data)
