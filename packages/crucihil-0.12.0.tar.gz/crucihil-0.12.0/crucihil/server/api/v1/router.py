"""Aggregate all v1 sub-routers into one APIRouter."""

from fastapi import APIRouter

from crucihil.server.api.v1 import auth, results, rigs, runs, setup, users

router = APIRouter(prefix="/api/v1")
router.include_router(setup.router)
router.include_router(auth.router)
router.include_router(rigs.router)
router.include_router(runs.router)
router.include_router(results.router)
router.include_router(users.router)

__all__ = ["router"]
