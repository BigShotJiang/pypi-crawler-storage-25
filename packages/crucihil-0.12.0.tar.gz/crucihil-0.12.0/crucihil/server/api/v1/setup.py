"""POST /api/v1/setup — one-time bootstrap to create the first org and admin user."""

from __future__ import annotations

import re
import time
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from crucihil.server.api.deps import get_db
from crucihil.server.models.org import OrgRow
from crucihil.server.models.user import UserRow
from crucihil.server.services.auth import hash_password, issue_user_jwt

router = APIRouter(tags=["setup"])


class SetupRequest(BaseModel):
    org_name: str = Field(min_length=2, max_length=256)
    admin_email: str = Field(min_length=3, max_length=320)
    admin_password: str = Field(min_length=8, max_length=128)


class SetupResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    org_slug: str


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "org"


@router.post("/setup", response_model=SetupResponse, status_code=status.HTTP_201_CREATED)
def setup(
    body: SetupRequest,
    db: Annotated[Session, Depends(get_db)],
) -> SetupResponse:
    """Bootstrap: create the first org and admin user.

    Only succeeds when no organisations exist. Returns 409 on all subsequent calls
    to prevent accidental re-initialisation.
    """
    count = db.execute(select(func.count()).select_from(OrgRow)).scalar_one()
    if count > 0:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Platform already set up. Use /auth/login.",
        )

    email = body.admin_email.lower().strip()
    slug = _slugify(body.org_name)

    # Guarantee slug uniqueness on the off-chance of a naming collision.
    if db.execute(select(OrgRow).where(OrgRow.slug == slug)).scalar_one_or_none():
        slug = f"{slug}-{uuid.uuid4().hex[:6]}"

    org = OrgRow(name=body.org_name, slug=slug, created_at=time.time())
    db.add(org)
    db.flush()  # populate org.id before the user FK references it

    user = UserRow(
        org_id=org.id,
        email=email,
        password_hash=hash_password(body.admin_password),
        role="admin",
        joined_at=time.time(),
        created_at=time.time(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token_data = issue_user_jwt(user_id=user.id, org_id=org.id, org_slug=org.slug, role="admin")
    return SetupResponse(**token_data, org_slug=org.slug)
