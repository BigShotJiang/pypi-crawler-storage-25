"""Test run endpoints.

GET  /api/v1/runs — list recent runs.
GET  /api/v1/runs/{run_id} — single run summary.
POST /api/v1/runs — create a new queued run (triggered by MCP server).
POST /api/v1/runs/{run_id}/cancel — mark run as cancelled.
GET  /api/v1/runs/{run_id}/report.xml — JUnit XML report.
GET  /api/v1/runs/{run_id}/report.html — HTML report.
"""

from __future__ import annotations

import html
import json
import time
import uuid
import xml.etree.ElementTree as ET
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import HTMLResponse, Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from crucihil.server.api.deps import get_any_authenticated, get_db, get_write_access
from crucihil.server.models.result import TestResultRow
from crucihil.server.models.rig import RigRow
from crucihil.server.models.run import TestRunRow

router = APIRouter(prefix="/runs", tags=["runs"])


class RunSummary(BaseModel):
    id: str
    rig_id: str
    suite_name: str
    started_at: float
    completed_at: float | None
    status: str
    total: int
    passed: int
    failed: int
    blocked: int
    errored: int
    skipped: int
    triggered_by: str | None


def _to_summary(row: TestRunRow) -> RunSummary:
    return RunSummary(
        id=row.id,
        rig_id=row.rig_id,
        suite_name=row.suite_name,
        started_at=row.started_at,
        completed_at=row.completed_at,
        status=row.status,
        total=row.total,
        passed=row.passed,
        failed=row.failed,
        blocked=row.blocked,
        errored=row.errored,
        skipped=row.skipped,
        triggered_by=row.triggered_by,
    )


@router.get("", response_model=list[RunSummary])
def list_runs(
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_any_authenticated)],
    rig_name: str | None = Query(None),
    suite_name: str | None = Query(None),
    run_status: str | None = Query(None, alias="status"),
    limit: int = Query(50, le=500),
) -> list[RunSummary]:
    stmt = select(TestRunRow).order_by(TestRunRow.started_at.desc()).limit(limit)
    if rig_name:
        rig_row = db.execute(select(RigRow).where(RigRow.name == rig_name)).scalar_one_or_none()
        if rig_row is None:
            return []
        stmt = stmt.where(TestRunRow.rig_id == rig_row.id)
    if suite_name:
        stmt = stmt.where(TestRunRow.suite_name == suite_name)
    if run_status:
        stmt = stmt.where(TestRunRow.status == run_status)
    rows = db.execute(stmt).scalars().all()
    return [_to_summary(r) for r in rows]


@router.get("/{run_id}", response_model=RunSummary)
def get_run(
    run_id: str,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_any_authenticated)],
) -> RunSummary:
    row = db.get(TestRunRow, run_id)
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
    return _to_summary(row)


class CreateRunRequest(BaseModel):
    rig_name: str
    suite_path: str
    tags: list[str] = []
    suite_type: str | None = None
    triggered_by: str = "mcp"


class CreateRunResponse(BaseModel):
    run_id: str
    rig_name: str
    suite_name: str
    status: str
    agent_notified: bool


@router.post("", response_model=CreateRunResponse, status_code=status.HTTP_201_CREATED)
async def create_run(
    body: CreateRunRequest,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_write_access)],
) -> CreateRunResponse:
    """Create a queued test run and attempt delivery to the connected agent.

    The agent_notified field indicates whether the WebSocket push succeeded.
    If the agent is not connected, the run stays queued until the agent polls.
    """
    from crucihil.server.api.ws.agent import push_to_agent

    rig_row = db.execute(select(RigRow).where(RigRow.name == body.rig_name)).scalar_one_or_none()
    if rig_row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rig not found")

    run_id = str(uuid.uuid4())
    run = TestRunRow(
        id=run_id,
        rig_id=rig_row.id,
        suite_name=body.suite_path,
        started_at=time.time(),
        status="queued",
        triggered_by=body.triggered_by,
    )
    db.add(run)
    db.commit()

    notified = await push_to_agent(rig_row.id, {
        "type": "run_suite",
        "run_id": run_id,
        "suite_path": body.suite_path,
        "tags": body.tags,
        "suite_type": body.suite_type,
    })

    return CreateRunResponse(
        run_id=run_id,
        rig_name=body.rig_name,
        suite_name=body.suite_path,
        status="queued",
        agent_notified=notified,
    )


@router.post("/{run_id}/cancel", status_code=status.HTTP_202_ACCEPTED)
def cancel_run(
    run_id: str,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_write_access)],
) -> dict:
    """Signal that a run should be cancelled.

    Step 1: stores the signal in the DB status field.
    Step 2 will deliver a cancel message to the agent via WebSocket.
    """
    row = db.get(TestRunRow, run_id)
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
    if row.status not in ("running",):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Run is already in terminal state: {row.status}",
        )
    row.status = "cancelled"
    db.commit()
    return {"detail": "cancellation requested"}


def _build_junit_xml(run: TestRunRow, results: list[TestResultRow]) -> str:
    ts = ET.Element("testsuite")
    ts.set("name", run.suite_name)
    ts.set("tests", str(run.total))
    ts.set("failures", str(run.failed))
    ts.set("errors", str(run.errored))
    ts.set("skipped", str(run.skipped))
    ts.set("time", f"{sum(r.duration for r in results):.3f}")
    ts.set("timestamp", time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(run.started_at)))

    for r in results:
        tc = ET.SubElement(ts, "testcase")
        tc.set("name", r.test_id)
        tc.set("classname", r.suite_name)
        tc.set("time", f"{r.duration:.3f}")
        if r.status == "failed":
            errors: list[str] = json.loads(r.errors or "[]")
            f = ET.SubElement(tc, "failure")
            f.set("message", errors[0] if errors else "assertion failed")
            f.text = "\n".join(errors)
        elif r.status == "errored":
            errors = json.loads(r.errors or "[]")
            e = ET.SubElement(tc, "error")
            e.set("message", errors[0] if errors else "error")
            e.text = "\n".join(errors)
        elif r.status in ("skipped", "blocked"):
            ET.SubElement(tc, "skipped")

    ET.indent(ts, space="  ")
    return '<?xml version="1.0" encoding="utf-8"?>\n' + ET.tostring(ts, encoding="unicode")


def _build_html_report(run: TestRunRow, results: list[TestResultRow]) -> str:
    STATUS_COLOR = {
        "passed": "#22c55e",
        "failed": "#ef4444",
        "errored": "#f97316",
        "blocked": "#a855f7",
        "skipped": "#6b7280",
    }
    rows_html = []
    for r in results:
        errors: list[str] = json.loads(r.errors or "[]")
        meta: dict = json.loads(r.extra_meta or "{}")
        tags = meta.get("tags") or []
        color = STATUS_COLOR.get(r.status, "#6b7280")
        err_html = ""
        if errors:
            err_html = f'<div class="err">{html.escape(errors[0])}</div>'
        tags_html = " ".join(f'<span class="tag">{html.escape(t)}</span>' for t in tags)
        rows_html.append(
            f'<tr>'
            f'<td class="tid">{html.escape(r.test_id)}</td>'
            f'<td><span class="badge" style="background:{color}">{html.escape(r.status)}</span></td>'
            f'<td>{r.duration:.2f}s</td>'
            f'<td>{tags_html}</td>'
            f'<td>{err_html}</td>'
            f'</tr>'
        )

    total_duration = sum(r.duration for r in results)
    started = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(run.started_at))
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Report: {html.escape(run.suite_name)}</title>
<style>
  body {{ font-family: Inter, system-ui, sans-serif; margin: 0; background: #0f172a; color: #e2e8f0; }}
  .header {{ padding: 24px 32px; border-bottom: 1px solid #1e293b; }}
  h1 {{ margin: 0 0 4px; font-size: 1.4rem; }}
  .meta {{ font-size: 0.85rem; color: #94a3b8; }}
  .summary {{ display: flex; gap: 16px; padding: 16px 32px; background: #1e293b; }}
  .stat {{ text-align: center; }}
  .stat .val {{ font-size: 1.6rem; font-weight: 700; }}
  .stat .lbl {{ font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; }}
  table {{ width: 100%; border-collapse: collapse; }}
  th {{ padding: 10px 16px; text-align: left; font-size: 0.75rem; text-transform: uppercase; color: #94a3b8; border-bottom: 1px solid #1e293b; }}
  td {{ padding: 10px 16px; border-bottom: 1px solid #1e293b; font-size: 0.875rem; vertical-align: top; }}
  .tid {{ font-family: monospace; color: #93c5fd; }}
  .badge {{ display: inline-block; padding: 2px 8px; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; color: #fff; }}
  .tag {{ display: inline-block; margin: 1px 2px; padding: 1px 6px; border-radius: 4px; font-size: 0.7rem; background: #334155; color: #94a3b8; }}
  .err {{ margin-top: 4px; font-family: monospace; font-size: 0.8rem; color: #fca5a5; }}
</style>
</head>
<body>
<div class="header">
  <h1>{html.escape(run.suite_name)}</h1>
  <div class="meta">Started {html.escape(started)} &middot; Duration {total_duration:.1f}s &middot; Run {html.escape(run.id)}</div>
</div>
<div class="summary">
  <div class="stat"><div class="val">{run.total}</div><div class="lbl">Total</div></div>
  <div class="stat"><div class="val" style="color:#22c55e">{run.passed}</div><div class="lbl">Passed</div></div>
  <div class="stat"><div class="val" style="color:#ef4444">{run.failed}</div><div class="lbl">Failed</div></div>
  <div class="stat"><div class="val" style="color:#f97316">{run.errored}</div><div class="lbl">Errored</div></div>
  <div class="stat"><div class="val" style="color:#a855f7">{run.blocked}</div><div class="lbl">Blocked</div></div>
  <div class="stat"><div class="val" style="color:#6b7280">{run.skipped}</div><div class="lbl">Skipped</div></div>
</div>
<table>
  <thead><tr><th>Test ID</th><th>Status</th><th>Duration</th><th>Tags</th><th>Error</th></tr></thead>
  <tbody>{"".join(rows_html)}</tbody>
</table>
</body>
</html>"""


@router.get("/{run_id}/report.xml")
def get_run_report_xml(
    run_id: str,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_any_authenticated)],
) -> Response:
    run = db.get(TestRunRow, run_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
    results = db.execute(
        select(TestResultRow)
        .where(TestResultRow.run_id == run_id)
        .order_by(TestResultRow.started_at.asc())
    ).scalars().all()
    xml_content = _build_junit_xml(run, list(results))
    filename = f"{run.suite_name.replace('/', '_')}_{run_id[:8]}.xml"
    return Response(
        content=xml_content,
        media_type="application/xml",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{run_id}/report.html")
def get_run_report_html(
    run_id: str,
    db: Annotated[Session, Depends(get_db)],
    _auth: Annotated[dict, Depends(get_any_authenticated)],
) -> HTMLResponse:
    run = db.get(TestRunRow, run_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
    results = db.execute(
        select(TestResultRow)
        .where(TestResultRow.run_id == run_id)
        .order_by(TestResultRow.started_at.asc())
    ).scalars().all()
    html_content = _build_html_report(run, list(results))
    return HTMLResponse(content=html_content)
