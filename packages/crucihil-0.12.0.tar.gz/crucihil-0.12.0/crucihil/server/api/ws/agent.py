"""WebSocket endpoint for agent ↔ cloud communication.

URL: ws://<host>/ws/agent?token=<jwt>

Protocol messages (agent → cloud):
  {"type": "agent_hello", "rig": "<name>", "version": "<ver>"}
  {"type": "result", "run_id": "<uuid>", "result": {<TestResult dict>}}
  {"type": "ping"}

Protocol messages (cloud → agent):
  {"type": "ack", "msg_type": "<echoed type>"}
  {"type": "run_suite", "run_id": "<uuid>", "suite_path": "...", "tags": [...], "suite_type": "..."}

Dashboard viewer URL: ws://<host>/ws/viewer?token=<jwt>&run_id=<run_id>
Receives:
  {"type": "result", "run_id": "<uuid>", "result": {<TestResult dict>}}
"""

from __future__ import annotations

import json
import logging
import time

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status
from jose import JWTError
from sqlalchemy import select

from crucihil.server.db.session import get_session_factory
from crucihil.server.models.rig import RigRow
from crucihil.server.models.run import TestRunRow
from crucihil.server.services.auth import decode_jwt
from crucihil.server.services.result_sync import batch_upsert_results, finalize_run, recompute_run_counts, upsert_run

_log = logging.getLogger(__name__)

router = APIRouter(prefix="/ws", tags=["ws"])

# Registry of active agent WebSocket connections: rig_id → WebSocket.
# Used by POST /api/v1/runs to push run_suite commands to connected agents.
_connections: dict[str, WebSocket] = {}

# Dashboard viewer connections: run_id → set of WebSocket connections.
# Populated by /ws/viewer; broadcast_result fans out to these on each result.
_run_viewers: dict[str, set[WebSocket]] = {}


async def push_to_agent(rig_id: str, message: dict) -> bool:  # type: ignore[type-arg]
    """Push a JSON message to the agent with the given rig_id.

    Returns True if the message was delivered, False if the agent is not connected.
    """
    ws = _connections.get(rig_id)
    if ws is None:
        return False
    try:
        await ws.send_json(message)
        return True
    except Exception:
        _connections.pop(rig_id, None)
        return False


async def broadcast_result(run_id: str, message: dict) -> None:  # type: ignore[type-arg]
    """Broadcast a result message to all dashboard viewers watching run_id."""
    viewers = set(_run_viewers.get(run_id, set()))  # snapshot to avoid mutation during iter
    dead: set[WebSocket] = set()
    for ws in viewers:
        try:
            await ws.send_json(message)
        except Exception:
            dead.add(ws)
    # Clean up dead connections
    bucket = _run_viewers.get(run_id)
    if bucket is not None:
        bucket -= dead


async def _auth_ws(websocket: WebSocket) -> tuple[str, str] | None:
    """Extract and verify JWT from ?token= query param.

    Returns (rig_name, rig_id) or None if auth fails (closes the WS).
    """
    token = websocket.query_params.get("token")
    if not token:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return None
    try:
        payload = decode_jwt(token)
        return payload["sub"], payload["rig_id"]
    except (JWTError, KeyError):
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return None


@router.websocket("/agent")
async def agent_ws(websocket: WebSocket) -> None:
    """Accept agent WebSocket connections.

    Auth: JWT in ?token= query param.
    On connect: update rig.connected + last_seen_at.
    On disconnect: clear rig.connected.
    """
    creds = await _auth_ws(websocket)
    if creds is None:
        return

    rig_name, rig_id = creds
    await websocket.accept()
    _log.info("Agent connected: rig=%s", rig_name)

    factory = get_session_factory()

    def _mark_connected(connected: bool) -> None:
        with factory() as db:
            rig = db.get(RigRow, rig_id)
            if rig:
                rig.connected = connected
                rig.last_seen_at = time.time()
                db.commit()

    _mark_connected(True)
    _connections[rig_id] = websocket

    try:
        async for raw in websocket.iter_text():
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                _log.warning("WS bad JSON from rig=%s", rig_name)
                continue

            msg_type = msg.get("type", "")
            _log.debug("WS msg type=%s rig=%s", msg_type, rig_name)

            if msg_type == "agent_hello":
                _handle_hello(factory, rig_id, msg)
                # Ack first so the agent knows hello was received, then push queued runs.
                await websocket.send_text(json.dumps({"type": "ack", "msg_type": msg_type}))
                await _redeliver_queued_runs(websocket, factory, rig_id)
                continue  # skip the default ack at end of loop
            elif msg_type == "result":
                result_run_id = _handle_result(factory, rig_id, msg)
                if result_run_id is not None:
                    await broadcast_result(
                        result_run_id,
                        {"type": "result", "run_id": result_run_id, "result": msg.get("result", {})},
                    )
            elif msg_type == "run_start":
                _handle_run_start(factory, msg)
            elif msg_type == "run_complete":
                _handle_run_complete(factory, msg)
            elif msg_type == "ping":
                _handle_ping(factory, rig_id)
            else:
                _log.debug("WS unknown msg type=%s rig=%s", msg_type, rig_name)

            await websocket.send_text(json.dumps({"type": "ack", "msg_type": msg_type}))

    except WebSocketDisconnect:
        _log.info("Agent disconnected: rig=%s", rig_name)
    finally:
        _connections.pop(rig_id, None)
        _mark_connected(False)


@router.websocket("/viewer")
async def viewer_ws(websocket: WebSocket) -> None:
    """Accept dashboard viewer WebSocket connections.

    Auth: JWT in ?token= query param (same API key JWT as agents use).
    Subscribes to live result broadcasts for a specific run_id.
    Does NOT affect rig.connected or the agent connection registry.

    URL: ws://<host>/ws/viewer?token=<jwt>&run_id=<run_id>
    """
    creds = await _auth_ws(websocket)
    if creds is None:
        return

    run_id = websocket.query_params.get("run_id", "")
    if not run_id:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    await websocket.accept()

    if run_id not in _run_viewers:
        _run_viewers[run_id] = set()
    _run_viewers[run_id].add(websocket)
    _log.debug("Viewer subscribed: run_id=%s", run_id)

    try:
        async for _ in websocket.iter_text():
            pass  # keep alive; dashboard does not send messages
    except WebSocketDisconnect:
        pass
    finally:
        bucket = _run_viewers.get(run_id)
        if bucket is not None:
            bucket.discard(websocket)
            if not bucket:
                _run_viewers.pop(run_id, None)
        _log.debug("Viewer unsubscribed: run_id=%s", run_id)


def _handle_hello(factory: object, rig_id: str, msg: dict) -> None:  # type: ignore[type-arg]
    with factory() as db:  # type: ignore[operator]
        rig = db.get(RigRow, rig_id)
        if rig:
            rig.version = msg.get("version")
            rig.last_seen_at = time.time()
            db.commit()


async def _redeliver_queued_runs(websocket: WebSocket, factory: object, rig_id: str) -> None:
    """Push any queued runs for this rig to the freshly-connected agent.

    Called on every agent_hello so that runs queued while the agent was offline
    (or missed due to a brief disconnect) are automatically re-delivered.
    The agent ignores duplicate run_suite messages for runs already in-flight.
    """
    with factory() as db:  # type: ignore[operator]
        runs = db.execute(
            select(TestRunRow)
            .where(TestRunRow.rig_id == rig_id)
            .where(TestRunRow.status == "queued")
            .order_by(TestRunRow.started_at.asc())
        ).scalars().all()

    for run in runs:
        try:
            await websocket.send_json({
                "type": "run_suite",
                "run_id": run.id,
                "suite_path": run.suite_name,
            })
            _log.info("Re-delivered queued run %s to reconnected agent (rig=%s)", run.id, rig_id)
        except Exception as exc:
            _log.warning("Failed to re-deliver run %s: %s", run.id, exc)
            break


def _handle_ping(factory: object, rig_id: str) -> None:
    with factory() as db:  # type: ignore[operator]
        rig = db.get(RigRow, rig_id)
        if rig:
            rig.last_seen_at = time.time()
            db.commit()


def _handle_run_start(factory: object, msg: dict) -> None:  # type: ignore[type-arg]
    """Mark a queued run as running when the agent begins execution."""
    run_id = msg.get("run_id")
    if not run_id:
        return
    with factory() as db:  # type: ignore[operator]
        run = db.get(TestRunRow, run_id)
        if run and run.status == "queued":
            run.status = "running"
            db.commit()


def _handle_run_complete(factory: object, msg: dict) -> None:  # type: ignore[type-arg]
    """Finalize a run when the agent signals completion."""
    run_id = msg.get("run_id")
    if not run_id:
        return
    completed_at = msg.get("completed_at")
    with factory() as db:  # type: ignore[operator]
        finalize_run(db, run_id, completed_at=completed_at)
        db.commit()


def _handle_result(factory: object, rig_id: str, msg: dict) -> str | None:  # type: ignore[type-arg]
    """Persist result to DB. Returns run_id if successful, None otherwise."""
    run_id = msg.get("run_id")
    result = msg.get("result")
    if not run_id or not result:
        return None
    with factory() as db:  # type: ignore[operator]
        rig = db.get(RigRow, rig_id)
        if rig is None:
            return None
        upsert_run(
            db,
            run_id=run_id,
            rig_id=rig_id,
            suite_name=result.get("suite_name", ""),
            started_at=result.get("started_at", time.time()),
            triggered_by="agent",
        )
        batch_upsert_results(db, run_id=run_id, results=[result])
        recompute_run_counts(db, run_id)
        db.commit()
    return run_id
