"""Alembic environment — connects to the database and runs migrations."""

from __future__ import annotations

import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from crucihil.server.models.base import Base
# Import all models so their tables are registered on Base.metadata
import crucihil.server.models.org      # noqa: F401
import crucihil.server.models.user     # noqa: F401
import crucihil.server.models.rig      # noqa: F401
import crucihil.server.models.run      # noqa: F401
import crucihil.server.models.result   # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def get_url() -> str:
    url = os.environ.get(
        "DATABASE_URL",
        config.get_main_option("sqlalchemy.url", "postgresql://crucihil:crucihil@localhost/crucihil"),
    )
    # Fly.io sets postgres:// but SQLAlchemy 1.4+ requires postgresql://
    return url.replace("postgres://", "postgresql://", 1)


def run_migrations_offline() -> None:
    context.configure(
        url=get_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    config.set_main_option("sqlalchemy.url", get_url())
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
