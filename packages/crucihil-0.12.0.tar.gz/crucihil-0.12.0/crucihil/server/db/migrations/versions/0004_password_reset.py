"""Add password_reset_token_hash and password_reset_token_expires_at to users.

Revision ID: 0004
Revises: 0003
Create Date: 2026-05-02
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.engine.reflection import Inspector

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = Inspector.from_engine(bind)
    existing_cols = {c["name"] for c in inspector.get_columns("users")}

    if "password_reset_token_hash" not in existing_cols:
        op.add_column("users", sa.Column("password_reset_token_hash", sa.Text, nullable=True))

    if "password_reset_token_expires_at" not in existing_cols:
        op.add_column("users", sa.Column("password_reset_token_expires_at", sa.Float, nullable=True))


def downgrade() -> None:
    op.drop_column("users", "password_reset_token_expires_at")
    op.drop_column("users", "password_reset_token_hash")
