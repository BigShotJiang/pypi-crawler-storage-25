"""Add orgs and users tables; add org_id to rigs.

Revision ID: 0003
Revises: 0002
Create Date: 2026-04-30
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.engine.reflection import Inspector

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = Inspector.from_engine(bind)
    tables = inspector.get_table_names()

    if "orgs" not in tables:
        op.create_table(
            "orgs",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("name", sa.String(256), nullable=False),
            sa.Column("slug", sa.String(128), nullable=False),
            sa.Column("created_at", sa.Float, nullable=False),
            sa.UniqueConstraint("slug", name="uq_orgs_slug"),
        )

    if "users" not in tables:
        op.create_table(
            "users",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column(
                "org_id",
                sa.String(36),
                sa.ForeignKey("orgs.id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("email", sa.String(320), nullable=False),
            sa.Column("password_hash", sa.Text, nullable=True),
            sa.Column("role", sa.String(16), nullable=False, server_default="member"),
            sa.Column("invite_token_hash", sa.Text, nullable=True),
            sa.Column("invite_token_expires_at", sa.Float, nullable=True),
            sa.Column("joined_at", sa.Float, nullable=True),
            sa.Column("created_at", sa.Float, nullable=False),
            sa.UniqueConstraint("email", name="uq_users_email"),
        )
        op.create_index("ix_users_org_id", "users", ["org_id"])
        op.create_index("ix_users_email", "users", ["email"])

    existing_rig_cols = {c["name"] for c in inspector.get_columns("rigs")}
    if "org_id" not in existing_rig_cols:
        op.add_column(
            "rigs",
            sa.Column(
                "org_id",
                sa.String(36),
                sa.ForeignKey("orgs.id", ondelete="SET NULL"),
                nullable=True,
            ),
        )
        op.create_index("ix_rigs_org_id", "rigs", ["org_id"])


def downgrade() -> None:
    bind = op.get_bind()
    inspector = Inspector.from_engine(bind)

    if "org_id" in {c["name"] for c in inspector.get_columns("rigs")}:
        op.drop_index("ix_rigs_org_id", table_name="rigs")
        op.drop_column("rigs", "org_id")

    op.drop_table("users")
    op.drop_table("orgs")
