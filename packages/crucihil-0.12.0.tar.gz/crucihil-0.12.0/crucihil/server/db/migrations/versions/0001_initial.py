"""Initial schema: rigs, test_runs, test_results.

Revision ID: 0001
Revises:
Create Date: 2026-04-27
"""

from alembic import op
import sqlalchemy as sa

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "rigs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(256), nullable=False),
        sa.Column("api_key_hash", sa.Text, nullable=False),
        sa.Column("last_seen_at", sa.Float, nullable=True),
        sa.Column("connected", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("version", sa.String(64), nullable=True),
        sa.Column("created_at", sa.Float, nullable=False),
        sa.Column("extra_meta", sa.Text, nullable=False, server_default="{}"),
        sa.UniqueConstraint("name", name="uq_rigs_name"),
    )

    op.create_table(
        "test_runs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("rig_id", sa.String(36), sa.ForeignKey("rigs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("suite_name", sa.String(256), nullable=False),
        sa.Column("started_at", sa.Float, nullable=False),
        sa.Column("completed_at", sa.Float, nullable=True),
        sa.Column("status", sa.String(16), nullable=False, server_default="running"),
        sa.Column("total", sa.Integer, nullable=False, server_default="0"),
        sa.Column("passed", sa.Integer, nullable=False, server_default="0"),
        sa.Column("failed", sa.Integer, nullable=False, server_default="0"),
        sa.Column("blocked", sa.Integer, nullable=False, server_default="0"),
        sa.Column("errored", sa.Integer, nullable=False, server_default="0"),
        sa.Column("skipped", sa.Integer, nullable=False, server_default="0"),
        sa.Column("triggered_by", sa.String(32), nullable=True),
    )
    op.create_index("ix_test_runs_rig_id", "test_runs", ["rig_id"])
    op.create_index("ix_test_runs_started_at", "test_runs", ["started_at"])

    op.create_table(
        "test_results",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("test_id", sa.String(256), nullable=False),
        sa.Column("run_id", sa.String(64), sa.ForeignKey("test_runs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("suite_name", sa.String(256), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("duration", sa.Float, nullable=False),
        sa.Column("started_at", sa.Float, nullable=False),
        sa.Column("completed_at", sa.Float, nullable=False),
        sa.Column("errors", sa.Text, nullable=False, server_default="[]"),
        sa.Column("logs", sa.Text, nullable=False, server_default="[]"),
        sa.Column("signals", sa.Text, nullable=False, server_default="{}"),
        sa.Column("extra_meta", sa.Text, nullable=False, server_default="{}"),
        sa.UniqueConstraint("test_id", "run_id", name="uq_test_results_test_run"),
    )
    op.create_index("ix_test_results_run_id", "test_results", ["run_id"])
    op.create_index("ix_test_results_started_at", "test_results", ["started_at"])
    op.create_index("ix_test_results_status", "test_results", ["status"])


def downgrade() -> None:
    op.drop_table("test_results")
    op.drop_table("test_runs")
    op.drop_table("rigs")
