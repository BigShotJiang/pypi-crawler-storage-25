"""Add role column to rigs; add viewer_keys table.

Revision ID: 0002
Revises: 0001
Create Date: 2026-04-28
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.engine.reflection import Inspector

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = Inspector.from_engine(bind)

    # Idempotent: create_all() may have already applied parts of this schema
    existing_cols = {c["name"] for c in inspector.get_columns("rigs")}
    if "role" not in existing_cols:
        op.add_column(
            "rigs",
            sa.Column("role", sa.String(16), nullable=False, server_default="admin"),
        )

    if "viewer_keys" not in inspector.get_table_names():
        op.create_table(
            "viewer_keys",
            sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
            sa.Column("rig_id", sa.String(36), sa.ForeignKey("rigs.id", ondelete="CASCADE"), nullable=False),
            sa.Column("name", sa.String(256), nullable=False),
            sa.Column("api_key_hash", sa.Text, nullable=False),
            sa.Column("created_at", sa.Float, nullable=False),
            sa.Column("revoked", sa.Boolean, nullable=False, server_default="false"),
        )
        op.create_index("ix_viewer_keys_rig_id", "viewer_keys", ["rig_id"])


def downgrade() -> None:
    op.drop_table("viewer_keys")
    op.drop_column("rigs", "role")
