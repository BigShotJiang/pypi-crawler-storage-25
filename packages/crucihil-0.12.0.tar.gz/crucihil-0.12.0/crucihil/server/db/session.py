"""SQLAlchemy engine and session factory.

get_engine() is called once at app startup (lifespan).
get_db() is a FastAPI dependency that yields a session per request.
"""

from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from crucihil.server.config import get_settings

_engine: Engine | None = None
_SessionLocal: sessionmaker | None = None


def get_engine(database_url: str | None = None) -> Engine:
    global _engine
    if _engine is None:
        url = database_url or get_settings().DATABASE_URL
        url = url.replace("postgres://", "postgresql://", 1)
        connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
        _engine = create_engine(url, connect_args=connect_args)
    return _engine


def get_session_factory(engine: Engine | None = None) -> sessionmaker:
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(
            bind=engine or get_engine(),
            autocommit=False,
            autoflush=False,
            expire_on_commit=False,
        )
    return _SessionLocal


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency — yields one Session per request, always closes."""
    factory = get_session_factory()
    with factory() as session:
        yield session


def set_engine(engine: Engine) -> None:
    """Override the global engine — used in tests to inject SQLite."""
    global _engine, _SessionLocal
    if _engine and _engine is not engine:
        _engine.dispose()
    _engine = engine
    _SessionLocal = None  # force recreation against new engine


def reset_engine() -> None:
    """Dispose the engine and session factory — used in tests to swap databases."""
    global _engine, _SessionLocal
    if _engine:
        _engine.dispose()
    _engine = None
    _SessionLocal = None


__all__ = ["get_engine", "get_session_factory", "get_db", "set_engine", "reset_engine"]
