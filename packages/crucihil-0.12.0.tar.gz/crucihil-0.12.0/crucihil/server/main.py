"""FastAPI application factory.

Usage:
    uvicorn crucihil.server.main:app --host 0.0.0.0 --port 8000

The app creates all SQLite/PostgreSQL tables on startup via create_all()
(for development/testing).  In production, run Alembic migrations instead.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from collections.abc import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from crucihil.server.api.v1.router import router as v1_router
from crucihil.server.api.ws.agent import router as ws_router
from crucihil.server.config import get_settings
from crucihil.server.db.session import get_engine
from crucihil.server.models.base import Base
# Import all models so they register on Base.metadata before create_all()
import crucihil.server.models.org         # noqa: F401
import crucihil.server.models.user        # noqa: F401
import crucihil.server.models.rig         # noqa: F401
import crucihil.server.models.run         # noqa: F401
import crucihil.server.models.result      # noqa: F401
import crucihil.server.models.viewer_key  # noqa: F401


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    engine = get_engine()
    Base.metadata.create_all(engine)
    yield
    engine.dispose()


def create_app() -> FastAPI:
    settings = get_settings()

    application = FastAPI(
        title="CruciHiL Control Plane",
        version="0.1.0",
        lifespan=lifespan,
    )

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    application.include_router(v1_router)
    application.include_router(ws_router)

    return application


app = create_app()

__all__ = ["app", "create_app"]
