"""Batch upsert service for agent → cloud result sync.

The sync contract:
- test_runs rows: INSERT ... ON CONFLICT (id) DO UPDATE — always keep latest counts
- test_results rows: INSERT ... ON CONFLICT (test_id, run_id) DO NOTHING — idempotent replay
"""

from __future__ import annotations

import json
import time
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from crucihil.server.models.result import TestResultRow
from crucihil.server.models.run import TestRunRow


def upsert_run(
    session: Session,
    *,
    run_id: str,
    rig_id: str,
    suite_name: str,
    started_at: float,
    triggered_by: str | None = None,
) -> TestRunRow:
    """Create the test_runs row if it doesn't exist, or return the existing one."""
    row = session.get(TestRunRow, run_id)
    if row is None:
        row = TestRunRow(
            id=run_id,
            rig_id=rig_id,
            suite_name=suite_name,
            started_at=started_at,
            status="running",
            triggered_by=triggered_by,
        )
        session.add(row)
        session.flush()
    return row


def batch_upsert_results(
    session: Session,
    *,
    run_id: str,
    results: list[dict[str, Any]],
) -> int:
    """Insert result rows, skipping any (test_id, run_id) that already exist.

    Returns the count of newly inserted rows.
    """
    inserted = 0
    for r in results:
        row = TestResultRow(
            test_id=r["test_id"],
            run_id=run_id,
            suite_name=r.get("suite_name", ""),
            status=r["status"],
            duration=r["duration"],
            started_at=r["started_at"],
            completed_at=r["completed_at"],
            errors=json.dumps(r.get("errors", [])),
            logs=json.dumps(r.get("logs", [])),
            signals=json.dumps(r.get("signals", {})),
            extra_meta=json.dumps(r.get("metadata", {})),
        )
        session.merge(row) if False else None  # not used; explicit upsert below
        # Use raw INSERT ... ON CONFLICT to avoid fetching then inserting
        stmt = text(
            "INSERT INTO test_results "
            "(test_id, run_id, suite_name, status, duration, started_at, "
            " completed_at, errors, logs, signals, extra_meta) "
            "VALUES (:test_id, :run_id, :suite_name, :status, :duration, "
            "        :started_at, :completed_at, :errors, :logs, :signals, :extra_meta) "
            "ON CONFLICT (test_id, run_id) DO NOTHING"
        )
        result = session.execute(stmt, {
            "test_id": r["test_id"],
            "run_id": run_id,
            "suite_name": r.get("suite_name", ""),
            "status": r["status"],
            "duration": r["duration"],
            "started_at": r["started_at"],
            "completed_at": r["completed_at"],
            "errors": json.dumps(r.get("errors", [])),
            "logs": json.dumps(r.get("logs", [])),
            "signals": json.dumps(r.get("signals", {})),
            "extra_meta": json.dumps(r.get("metadata", {})),
        })
        inserted += result.rowcount
    return inserted


def recompute_run_counts(session: Session, run_id: str) -> None:
    """Update test_runs counts from the actual test_results rows."""
    stmt = text(
        "UPDATE test_runs SET "
        "  total   = (SELECT COUNT(*) FROM test_results WHERE run_id = :run_id), "
        "  passed  = (SELECT COUNT(*) FROM test_results WHERE run_id = :run_id AND status = 'pass'), "
        "  failed  = (SELECT COUNT(*) FROM test_results WHERE run_id = :run_id AND status = 'fail'), "
        "  blocked = (SELECT COUNT(*) FROM test_results WHERE run_id = :run_id AND status = 'blocked'), "
        "  errored = (SELECT COUNT(*) FROM test_results WHERE run_id = :run_id AND status = 'error'), "
        "  skipped = (SELECT COUNT(*) FROM test_results WHERE run_id = :run_id AND status = 'skip') "
        "WHERE id = :run_id"
    )
    session.execute(stmt, {"run_id": run_id})


def finalize_run(session: Session, run_id: str, completed_at: float | None = None) -> None:
    """Mark a run complete and compute its final status from result counts."""
    recompute_run_counts(session, run_id)
    run = session.get(TestRunRow, run_id)
    if run is None:
        return
    run.completed_at = completed_at or time.time()
    if run.failed > 0:
        run.status = "fail"
    elif run.blocked > 0 and run.passed == 0:
        run.status = "blocked"
    elif run.errored > 0 and run.passed == 0:
        run.status = "error"
    else:
        run.status = "pass"


__all__ = [
    "upsert_run",
    "batch_upsert_results",
    "recompute_run_counts",
    "finalize_run",
]
