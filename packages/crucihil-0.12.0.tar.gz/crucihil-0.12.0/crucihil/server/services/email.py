"""Email delivery via Resend.

If RESEND_API_KEY is set, sends real email through the Resend API.
If not set (local dev / CI), logs the invite URL to stdout so the flow
can be exercised without SMTP or a paid account.
"""

from __future__ import annotations

import logging

from crucihil.server.config import get_settings

logger = logging.getLogger(__name__)

_INVITE_HTML = """\
<!DOCTYPE html>
<html>
<body style="font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:40px">
  <div style="max-width:480px;margin:0 auto">
    <h2 style="color:#fff;margin-bottom:8px">You've been invited to {org_name}</h2>
    <p style="color:#94a3b8;margin-bottom:24px">
      Click the button below to accept your invitation and set your password.
      This link expires in 72 hours.
    </p>
    <a href="{invite_url}"
       style="display:inline-block;background:#f97316;color:#fff;padding:12px 24px;
              border-radius:6px;text-decoration:none;font-weight:600">
      Accept invitation
    </a>
    <p style="color:#64748b;font-size:12px;margin-top:32px">
      If you weren't expecting this invitation, you can safely ignore this email.
    </p>
  </div>
</body>
</html>
"""


def send_invite_email(*, to_email: str, org_name: str, invite_url: str) -> None:
    """Send an org invite email.

    Falls back to stdout logging when RESEND_API_KEY is not configured.
    """
    settings = get_settings()

    if not settings.RESEND_API_KEY:
        logger.warning(
            "RESEND_API_KEY not set — invite URL for %s: %s",
            to_email,
            invite_url,
        )
        return

    import resend  # deferred so the package is optional in non-email contexts

    resend.api_key = settings.RESEND_API_KEY
    resend.Emails.send({
        "from": settings.RESEND_FROM,
        "to": [to_email],
        "subject": f"You've been invited to {org_name} on CruciHiL",
        "html": _INVITE_HTML.format(org_name=org_name, invite_url=invite_url),
    })


_RESET_HTML = """\
<!DOCTYPE html>
<html>
<body style="font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:40px">
  <div style="max-width:480px;margin:0 auto">
    <h2 style="color:#fff;margin-bottom:8px">Reset your CruciHiL password</h2>
    <p style="color:#94a3b8;margin-bottom:24px">
      Click the button below to set a new password.
      This link expires in 1 hour. If you didn't request a reset, you can safely ignore this email.
    </p>
    <a href="{reset_url}"
       style="display:inline-block;background:#f97316;color:#fff;padding:12px 24px;
              border-radius:6px;text-decoration:none;font-weight:600">
      Reset password
    </a>
    <p style="color:#64748b;font-size:12px;margin-top:32px">
      This link expires in 1 hour and can only be used once.
    </p>
  </div>
</body>
</html>
"""


def send_password_reset_email(*, to_email: str, reset_url: str) -> None:
    """Send a password-reset email.

    Falls back to stdout logging when RESEND_API_KEY is not configured.
    """
    settings = get_settings()

    if not settings.RESEND_API_KEY:
        logger.warning(
            "RESEND_API_KEY not set — password reset URL for %s: %s",
            to_email,
            reset_url,
        )
        return

    import resend  # deferred so the package is optional in non-email contexts

    resend.api_key = settings.RESEND_API_KEY
    resend.Emails.send({
        "from": settings.RESEND_FROM,
        "to": [to_email],
        "subject": "Reset your CruciHiL password",
        "html": _RESET_HTML.format(reset_url=reset_url),
    })


__all__ = ["send_invite_email", "send_password_reset_email"]
