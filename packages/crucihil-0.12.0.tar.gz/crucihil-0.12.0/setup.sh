#!/usr/bin/env bash
# setup.sh — CruciHiL self-hosting bootstrap
#
# Automates the full self-hosting setup in one command:
#   1. Validates prerequisites (docker, docker compose)
#   2. Creates and configures .env (generates SECRET_KEY automatically)
#   3. Starts db + server, waits for health
#   4. Registers a default rig, saves API key to .env
#   5. Starts all services (control plane + MCP server)
#
# Usage:
#   ./setup.sh               Full bootstrap (idempotent — safe to re-run)
#   ./setup.sh --restart     Restart all services without re-registration
#   ./setup.sh --status      Show service status and health
#   ./setup.sh --clean       Stop and remove containers (volumes kept)
#   ./setup.sh --help        Show this message

set -euo pipefail

# ── Colors ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

# ── Logging ────────────────────────────────────────────────────────────────────
step() { echo -e "\n${BOLD}${BLUE}▸${NC}${BOLD} $*${NC}"; }
ok()   { echo -e "  ${GREEN}✓${NC} $*"; }
info() { echo -e "  ${CYAN}·${NC} $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC} $*"; }
die()  { echo -e "\n  ${RED}✗ Error:${NC} $*\n" >&2; exit 1; }

# ── Banner ─────────────────────────────────────────────────────────────────────
banner() {
  echo ""
  echo -e "${BOLD}${BLUE}  CruciHiL${NC} — Hardware-in-the-Loop Testing"
  echo -e "  ${DIM}Self-hosting setup${NC}"
  echo ""
}

usage() {
  echo "Usage: $0 [option]"
  echo ""
  echo "  (none)      Full bootstrap — configure env, start services, register rig"
  echo "  --restart   Restart all services without re-registration"
  echo "  --status    Show service health and port bindings"
  echo "  --clean     Stop containers and remove them (volumes are kept)"
  echo "  --help      Show this help"
  echo ""
  echo "The bootstrap is idempotent: it skips steps already completed."
  exit 0
}

# ── Utilities ──────────────────────────────────────────────────────────────────
command_exists() { command -v "$1" >/dev/null 2>&1; }

# Detect docker compose command: v2 plugin ("docker compose") or v1 standalone ("docker-compose")
detect_compose() {
  if docker compose version >/dev/null 2>&1; then
    echo "docker compose"
  elif command_exists docker-compose; then
    echo "docker-compose"
  else
    die "Neither 'docker compose' (v2) nor 'docker-compose' (v1) found.\n  Install: https://docs.docker.com/compose/install/"
  fi
}

http_get() {
  if command_exists curl; then
    curl -sf "$1" 2>/dev/null
  elif command_exists wget; then
    wget -qO- "$1" 2>/dev/null
  else
    die "Neither curl nor wget found. Install one to continue."
  fi
}

http_post_json() {
  local url="$1" data="$2" auth_header="${3:-}"
  if command_exists curl; then
    if [[ -n "$auth_header" ]]; then
      curl -sf -X POST "$url" -H 'Content-Type: application/json' -H "$auth_header" -d "$data"
    else
      curl -sf -X POST "$url" -H 'Content-Type: application/json' -d "$data"
    fi
  elif command_exists wget; then
    if [[ -n "$auth_header" ]]; then
      wget -qO- --method=POST \
           --header='Content-Type: application/json' \
           --header="$auth_header" \
           --body-data="$data" "$url"
    else
      wget -qO- --method=POST \
           --header='Content-Type: application/json' \
           --body-data="$data" "$url"
    fi
  else
    die "Neither curl nor wget found."
  fi
}

extract_json_field() {
  local json="$1" field="$2"
  if command_exists python3; then
    echo "$json" | python3 -c \
      "import sys, json; d=json.load(sys.stdin); print(d.get('$field',''))" 2>/dev/null \
      && return 0
  fi
  # AWK fallback (no PCRE needed)
  echo "$json" | awk -F"\"${field}\":\"" '{print $2}' | awk -F'"' '{print $1}'
}

update_env_var() {
  local key="$1" value="$2"
  if grep -q "^${key}=" .env 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" .env
  else
    echo "${key}=${value}" >> .env
  fi
}

generate_secret() {
  if command_exists python3; then
    python3 -c "import secrets; print(secrets.token_hex(32))" && return
  fi
  if command_exists openssl; then
    openssl rand -hex 32 && return
  fi
  # Last-resort fallback using /dev/urandom
  LC_ALL=C tr -dc 'a-f0-9' </dev/urandom | head -c 64
}

# ── Parse args ─────────────────────────────────────────────────────────────────
MODE="bootstrap"
for arg in "$@"; do
  case "$arg" in
    --restart) MODE="restart" ;;
    --status)  MODE="status"  ;;
    --clean)   MODE="clean"   ;;
    --help|-h) usage           ;;
    *) die "Unknown option: $arg  (try --help)" ;;
  esac
done

banner

# Detect compose for status/clean/restart modes (bootstrap detects it later)
DC=$(detect_compose)

# ── Status ─────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "status" ]]; then
  step "Container status"
  $DC ps
  echo ""
  info "Control plane : http://localhost:8000/docs"
  info "MCP server    : http://localhost:8001/sse"
  info "Dashboard     : http://localhost:5173 (if running via dev.sh)"

  step "Rig connectivity"
  [[ -f .env ]] && { set -a; source .env; set +a; }
  API_KEY="${CRUCIHIL_API_KEY:-}"
  if [[ -z "$API_KEY" ]]; then
    warn "CRUCIHIL_API_KEY not set — cannot check rig status"
  else
    TOKEN_JSON=$(http_post_json "http://localhost:8000/api/v1/auth/token" \
      "{\"api_key\":\"${API_KEY}\"}") 2>/dev/null || true
    TOKEN=$(extract_json_field "${TOKEN_JSON:-}" "access_token" 2>/dev/null) || true
    if [[ -z "${TOKEN:-}" ]]; then
      warn "Server not reachable — start it with ./setup.sh --restart"
    else
      RIGS_JSON=$(if command_exists curl; then
        curl -sf -H "Authorization: Bearer $TOKEN" "http://localhost:8000/api/v1/rigs"
      else
        wget -qO- --header="Authorization: Bearer $TOKEN" "http://localhost:8000/api/v1/rigs"
      fi) 2>/dev/null || true
      echo "${RIGS_JSON:-[]}" | python3 -c "
import sys, json, time
rigs = json.load(sys.stdin)
if not rigs:
    print('  No rigs registered.')
    sys.exit(0)
for r in rigs:
    connected = r.get('connected', False)
    icon  = '\033[0;32m●\033[0m' if connected else '\033[2m○\033[0m'
    state = 'online ' if connected else 'offline'
    last  = r.get('last_seen_at')
    age   = ''
    if last:
        secs = int(time.time() - last)
        age = f'{secs}s ago' if secs < 60 else f'{secs//60}m ago' if secs < 3600 else f'{secs//3600}h ago'
    ver = r.get('version') or ''
    print(f'  {icon}  {r[\"name\"]:30}  {state}  {age:12}  {ver}')
"
    fi
  fi
  echo ""
  exit 0
fi

# ── Clean ──────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "clean" ]]; then
  step "Stopping and removing containers"
  $DC down
  ok "Done. Data volumes are retained."
  info "Run './setup.sh' to start again."
  exit 0
fi

# ── Restart ────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "restart" ]]; then
  step "Restarting services"
  $DC down
  $DC up -d
  ok "Services restarted"
  $DC ps
  exit 0
fi

# ── Full bootstrap ─────────────────────────────────────────────────────────────

# 1. Prerequisites ──────────────────────────────────────────────────────────────
step "Checking prerequisites"
command_exists docker \
  || die "docker not found.\n  Install: https://docs.docker.com/get-docker/"
DC=$(detect_compose)
ok "docker $(docker --version | awk '{print $3}' | tr -d ',')"
ok "$DC ($(${DC} version --short 2>/dev/null || echo 'detected'))"

# 2. Configure .env ─────────────────────────────────────────────────────────────
step "Configuring environment"
if [[ ! -f .env ]]; then
  [[ -f .env.example ]] || die ".env.example not found. Run from the CruciHiL project root."
  cp .env.example .env
  ok "Created .env from .env.example"
fi

# Generate SECRET_KEY if still at default
if grep -q "change-me-in-production" .env 2>/dev/null; then
  SECRET_KEY=$(generate_secret)
  update_env_var "SECRET_KEY" "$SECRET_KEY"
  ok "Generated SECRET_KEY"
fi

# Generate REGISTRATION_TOKEN if still at default
if grep -q "^REGISTRATION_TOKEN=CHANGE_ME" .env 2>/dev/null || ! grep -q "^REGISTRATION_TOKEN=" .env 2>/dev/null; then
  REGISTRATION_TOKEN=$(generate_secret)
  update_env_var "REGISTRATION_TOKEN" "$REGISTRATION_TOKEN"
  ok "Generated REGISTRATION_TOKEN"
fi

# Warn about default password (safe to ignore in dev, must change for prod)
if grep -q "^POSTGRES_PASSWORD=changeme" .env 2>/dev/null; then
  warn "POSTGRES_PASSWORD is 'changeme' — change it in .env before exposing this server."
fi

# Source the configured values
set -a; source .env; set +a

# 3. Start db + server ─────────────────────────────────────────────────────────
step "Starting database and control plane"
$DC up -d db server
ok "Containers started"

info "Waiting for server at http://localhost:8000 ..."
ATTEMPTS=0
until http_get "http://localhost:8000/openapi.json" >/dev/null 2>&1; do
  ATTEMPTS=$((ATTEMPTS + 1))
  if [[ $ATTEMPTS -ge 40 ]]; then
    echo ""
    die "Server unhealthy after 2 minutes.\nCheck logs: docker compose logs server"
  fi
  printf "."
  sleep 3
done
echo ""
ok "Server is healthy (alembic migrations applied)"

# 4. Register rig + API key ─────────────────────────────────────────────────────
step "Registering rig"
EXISTING_KEY="${CRUCIHIL_API_KEY:-}"

if [[ -z "$EXISTING_KEY" ]] || grep -q "^CRUCIHIL_API_KEY=$" .env 2>/dev/null; then
  REG_TOKEN="${REGISTRATION_TOKEN:-}"
  [[ -n "$REG_TOKEN" ]] || die "REGISTRATION_TOKEN not set in .env — cannot register rig."
  RESPONSE=$(http_post_json "http://localhost:8000/api/v1/rigs" '{"name":"default-rig"}' "Authorization: Bearer ${REG_TOKEN}") \
    || die "Rig registration failed.\nCheck: docker compose logs server"

  API_KEY=$(extract_json_field "$RESPONSE" "api_key")
  [[ -n "$API_KEY" ]] || die "Could not parse api_key.\nServer returned: $RESPONSE"

  update_env_var "CRUCIHIL_API_KEY" "$API_KEY"
  ok "Rig 'default-rig' registered"
  info "API key written to .env"
else
  ok "CRUCIHIL_API_KEY already set — skipping rig registration"
fi

# 5. Start all services ─────────────────────────────────────────────────────────
step "Starting all services"
# Reload env to pick up the new API key
set -a; source .env; set +a
$DC up -d
ok "All services running"

# ── Done ───────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}  ✓ CruciHiL is running!${NC}"
echo ""
echo -e "  ${BOLD}Control plane :${NC}  http://localhost:8000"
echo -e "  ${BOLD}API docs      :${NC}  http://localhost:8000/docs"
echo -e "  ${BOLD}MCP server    :${NC}  http://localhost:8001/sse"
echo ""
echo -e "  ${BOLD}Claude Desktop${NC} — add to claude_desktop_config.json:"
echo -e '  { "mcpServers": { "crucihil": { "url": "http://localhost:8001/sse" } } }'
echo ""
echo -e "  ${BOLD}Dashboard dev server:${NC}"
echo -e "  ./dev.sh"
echo ""
echo -e "  ${BOLD}Start the virtual agent:${NC}"
echo -e "  $DC --profile agent up -d"
echo ""
echo -e "  ${DIM}Run './setup.sh --status' to check service health.${NC}"
echo ""
