# CruciHiL — Complete System Architecture

**Version:** 1.2  
**Status:** Authoritative — update this document before changing the system  
**Scope:** Full platform — all layers from hardware to AI interface  
**Last updated:** 2026-04 (Phase 2 Step 2 — agent ↔ cloud protocol complete)

---

## Table of Contents

1. [Product Vision](#1-product-vision)
2. [Architectural Principles](#2-architectural-principles)
3. [System Layer Model](#3-system-layer-model)
4. [Layer 1 — Hardware](#4-layer-1--hardware)
5. [Layer 2 — Hardware Abstraction (Rig HAL)](#5-layer-2--hardware-abstraction-rig-hal)
6. [Layer 3 — Test Orchestration (Local Agent)](#6-layer-3--test-orchestration-local-agent)
7. [Test Code Ownership Model](#7-test-code-ownership-model)
8. [Layer 4 — Cloud Control Plane](#8-layer-4--cloud-control-plane)
9. [Layer 5 — AI Interface (MCP)](#9-layer-5--ai-interface-mcp)
10. [Layer 6 — Interfaces (Dashboard, CLI)](#10-layer-6--interfaces-dashboard-cli)
11. [Cross-Cutting Concerns](#11-cross-cutting-concerns)
12. [CANvas Integration Flywheel](#12-canvas-integration-flywheel)
13. [Deployment Architecture](#13-deployment-architecture)
14. [Data Architecture](#14-data-architecture)
15. [Security Model](#15-security-model)
16. [Technology Stack](#16-technology-stack)
17. [Implementation Phases](#17-implementation-phases)
18. [Known Gaps and Accepted Debt](#18-known-gaps-and-accepted-debt)

---

## 1. Product Vision

CruciHiL is a **bulletproof, easy-to-use HiL testing platform** that catches regressions before firmware reaches the field. It provides everything a team needs to go from a test file to a dashboard result — test execution, hardware abstraction, CI/CD integration, reporting, and AI-powered analysis — with zero infrastructure burden.

**Target users:** Embedded and automotive engineers at AV startups, robotics companies, and Tier 2 suppliers. Engineers who write Python, know CAN, and are tired of building test infrastructure instead of testing systems.

**Core value proposition:**
- Write a test in Python in minutes, not days
- Run it against sim before hardware exists
- Run it against real hardware with zero test changes
- See results in CI/CD automatically
- Ask an AI what broke and why

---

## 2. Architectural Principles

These principles are immutable. Any design decision that violates them requires explicit justification and team sign-off.

**P1 — Tests express intent, not implementation**
Test code never contains hardware details. No "SocketCAN", no "vsomeip", no IP addresses. These are configuration concerns.

**P2 — Backend swap is one config line**
The same test runs against virtual simulation and real hardware. No test changes. The rig TOML declares the backend.

**P3 — Async everywhere, no exceptions**
All I/O operations are coroutines. CAN timing, network I/O, and hardware polling require it. The sync API surface is zero.

**P4 — Hardware identified by role, never by silicon**
`ecu_main`, not `SA8775`. Platform differences live in TOML, not test code.

**P5 — Explicit failures, no silent swallowing**
Every timeout raises a named exception. Missing config is caught at startup. No operation silently fails.

**P6 — Teardown always runs**
Hardware is always left in a known state. `__aexit__` runs regardless of exceptions.

**P7 — Single source of truth per layer**
The REST API is the source of truth for the control plane. The local agent is the source of truth for hardware state. No duplicated logic between layers.

**P8 — Resilience by default**
The local agent functions without a cloud connection. Results are cached locally and synced on reconnect. A broken internet connection never stops a test run.

**P9 — Vendor-agnostic AI**
MCP servers are model-agnostic. Swap Claude for Gemini or GPT without touching backend logic.

**P10 — Per-client isolation**
Every customer deployment is fully isolated — separate control plane, database, and credentials. No shared infrastructure between customers.

---

## 3. System Layer Model

```
┌──────────────────────────────────────────────────────────────────┐
│  Layer 6 — Interfaces                                            │
│  Web Dashboard (React)  ·  CLI (crucihil)  ·  CI/CD webhooks    │
└──────────────────────────────────┬───────────────────────────────┘
                                   │ HTTP / WebSocket
┌──────────────────────────────────▼───────────────────────────────┐
│  Layer 5 — AI Interface                                          │
│  MCP Server (FastMCP)                                            │
│  Tools: list_tests · run_test · get_results · rig_status ·      │
│         get_history · cancel_test · query_signals                │
│  Provider abstraction: Claude · GPT · Gemini · Copilot          │
└──────────────────────────────────┬───────────────────────────────┘
                                   │ Internal REST
┌──────────────────────────────────▼───────────────────────────────┐
│  Layer 4 — Cloud Control Plane                                   │
│  FastAPI web server  ·  PostgreSQL  ·  Auth/RBAC                 │
│  Test registry  ·  Rig registry  ·  Run orchestration           │
│  Results DB  ·  Firmware artifact registry                       │
└──────────────────────────────────┬───────────────────────────────┘
                                   │ WebSocket (persistent)
                                   │ TLS, mutual auth
┌──────────────────────────────────▼───────────────────────────────┐
│  Layer 3 — Local Agent                                           │
│  Test runner  ·  YAML manifest executor  ·  Result reporter      │
│  SQLite cache (offline resilience)  ·  Firmware flasher          │
└──────────────────────────────────┬───────────────────────────────┘
                                   │ Python API
┌──────────────────────────────────▼───────────────────────────────┐
│  Layer 2 — Hardware Abstraction (Rig HAL)                        │
│  rig.can · rig.sim · rig.someip · rig.doip                       │
│  rig.ecu · rig.power · rig.gpio · rig.fault                      │
│  Backend registry: virtual ↔ SocketCAN ↔ vsomeip ↔ PEAK        │
└──────────────────────────────────┬───────────────────────────────┘
                                   │ Hardware drivers
┌──────────────────────────────────▼───────────────────────────────┐
│  Layer 1 — Hardware                                              │
│  CAN interfaces · Ethernet · GPIO · Power supplies               │
│  Qualcomm SA8775/SA8255 · Nvidia Orin/Thor · Any Linux ECU       │
└──────────────────────────────────────────────────────────────────┘
```

Each layer has one responsibility and communicates with adjacent layers only through defined interfaces. No layer skips another.

---

## 4. Layer 1 — Hardware

### Supported platforms

CruciHiL is platform-agnostic at the test layer. Platform differences are expressed in rig configuration only.

| Platform | CAN | Ethernet | Notes |
|---|---|---|---|
| Qualcomm SA8775P | CAN-FD native / SPI | 1000BASE-T1 | ADAS domain controller |
| Qualcomm SA8255P | CAN-FD native | 1000BASE-T1 | Cockpit domain |
| Nvidia Orin NX/AGX | CAN-FD via Jetson IO | 1000BASE-T1 | AV compute |
| Nvidia Thor | CAN-FD | 2.5GBASE-T1 | Next-gen AV |
| Generic Linux ECU | SocketCAN | Standard NIC | Development boards |
| Raspberry Pi 4 | MCP2515 via SPI | Standard NIC | Cheapest real HW dev target |

### Protocol support roadmap

| Protocol | Phase 0 | Phase 1 | Phase 2 |
|---|---|---|---|
| CAN / CAN-FD | ✓ | ✓ | ✓ |
| SOME/IP Events + Fields | ✓ | ✓ | ✓ |
| SOME/IP Methods (RPC) | — | ✓ | ✓ |
| DoIP (routing activation + UDS) | ✓ | ✓ | ✓ |
| DoIP gateway routing | — | ✓ | ✓ |
| LIN (LDF-based) | — | — | ✓ |
| FlexRay | — | — | ✓ |
| ARXML / FIDL definition loading | — | — | ✓ |

---

## 5. Layer 2 — Hardware Abstraction (Rig HAL)

The Rig HAL is the most important layer in the system. It is what makes tests hardware-agnostic. See `RIG_INTERFACE_SPEC.md` for the complete API surface.

### Module structure

```
crucihil/
└── hal/
    ├── rig.py              # Rig class — top-level fixture
    ├── backends/
    │   ├── base.py         # Abstract backend interfaces (ABCs)
    │   ├── virtual/        # In-process simulation backends
    │   │   ├── can.py
    │   │   ├── someip.py
    │   │   ├── doip.py
    │   │   ├── power.py
    │   │   └── gpio.py
    │   ├── socketcan/      # Real CAN hardware
    │   │   └── can.py
    │   ├── vsomeip/        # Real SOME/IP hardware
    │   │   └── someip.py
    │   ├── peak/           # PEAK PCAN adapters
    │   │   └── can.py
    │   └── python_doip/    # DoIP via python-doip
    │       └── doip.py
    ├── namespaces/
    │   ├── can.py          # rig.can implementation
    │   ├── sim.py          # rig.sim implementation (BSE)
    │   ├── someip.py       # rig.someip implementation
    │   ├── doip.py         # rig.doip implementation
    │   ├── ecu.py          # rig.ecu implementation
    │   ├── power.py        # rig.power implementation
    │   ├── gpio.py         # rig.gpio implementation
    │   └── fault.py        # rig.fault implementation
    ├── bse/
    │   ├── engine.py       # Bus Simulation Engine core
    │   ├── scheduler.py    # Per-message asyncio task scheduler
    │   ├── signal_store.py # Signal state, defaults, routing
    │   ├── router.py       # CAN vs SOME/IP routing by DBC transport attribute
    │   └── loader.py       # DBC loader, transport inference
    ├── config/
    │   ├── rig_config.py   # TOML loader, validation, backend resolution
    │   └── schemas.py      # Pydantic models for rig TOML validation
    └── models/
        ├── results.py      # TestResult, ExpectResult, FaultDescriptor
        ├── frames.py       # CANFrame, SOMEIPEvent, DoIPResponse
        └── exceptions.py   # Full exception hierarchy
```

### Backend abstract interfaces

Every backend implements one of these ABCs. The Rig HAL never knows which concrete backend is active.

```python
# crucihil/hal/backends/base.py

from abc import ABC, abstractmethod
from crucihil.hal.models.frames import CANFrame, SOMEIPEvent, DoIPResponse


class CANBackend(ABC):
    @abstractmethod
    async def connect(self, interface: str, bitrate: int) -> None: ...
    @abstractmethod
    async def disconnect(self) -> None: ...
    @abstractmethod
    async def send(self, frame: CANFrame) -> None: ...
    @abstractmethod
    async def receive(self, timeout: float) -> CANFrame: ...
    @abstractmethod
    async def set_bitrate(self, bitrate: int) -> None: ...


class SOMEIPBackend(ABC):
    @abstractmethod
    async def connect(self, interface: str, ip: str) -> None: ...
    @abstractmethod
    async def disconnect(self) -> None: ...
    @abstractmethod
    async def start_service(self, service_id: int, instance_id: int,
                             port: int) -> None: ...
    @abstractmethod
    async def stop_service(self, service_id: int, instance_id: int) -> None: ...
    @abstractmethod
    async def publish_event(self, service_id: int, event_id: int,
                             payload: bytes) -> None: ...
    @abstractmethod
    async def subscribe(self, service_id: int, instance_id: int,
                        eventgroup_id: int) -> None: ...
    @abstractmethod
    async def receive_event(self, timeout: float) -> SOMEIPEvent: ...


class DoIPBackend(ABC):
    @abstractmethod
    async def connect(self, ip: str, port: int,
                      logical_address: int) -> None: ...
    @abstractmethod
    async def disconnect(self) -> None: ...
    @abstractmethod
    async def send_uds(self, payload: bytes,
                       timeout: float) -> DoIPResponse: ...
    @abstractmethod
    async def discover(self, timeout: float) -> list[dict]: ...


class PowerBackend(ABC):
    @abstractmethod
    async def on(self, rail: str) -> None: ...
    @abstractmethod
    async def off(self, rail: str) -> None: ...
    @abstractmethod
    async def read_voltage(self, rail: str) -> float: ...


class GPIOBackend(ABC):
    @abstractmethod
    async def set(self, pin: str, high: bool) -> None: ...
    @abstractmethod
    async def read(self, pin: str) -> bool: ...
```

### Backend registration

Backends are registered by name and resolved from rig TOML at startup. No hardcoded backend selection anywhere in the codebase.

```python
# crucihil/hal/backends/registry.py

BACKEND_REGISTRY: dict[str, type] = {
    # CAN
    "virtual":   VirtualCANBackend,
    "socketcan": SocketCANBackend,
    "peak":      PEAKCANBackend,
    # SOME/IP
    "python-someip": PythonSOMEIPBackend,
    "vsomeip":       VSOMEIPBackend,
    # DoIP
    "python-doip": PythonDoIPBackend,
    # Power
    "gpio_relay": GPIORelayPowerBackend,
    "bench_psu":  BenchPSUPowerBackend,
    "virtual_power": VirtualPowerBackend,
    # GPIO
    "rpi_gpio":     RPiGPIOBackend,
    "virtual_gpio": VirtualGPIOBackend,
}

def resolve_backend(name: str) -> type:
    if name not in BACKEND_REGISTRY:
        raise ConfigurationError(
            f"Unknown backend '{name}'. "
            f"Available: {list(BACKEND_REGISTRY.keys())}"
        )
    return BACKEND_REGISTRY[name]
```

### Bus Simulation Engine (BSE)

The BSE is the restbus simulation component. It is the CruciHiL equivalent of dSPACE restbus simulation — but open source, Python-native, and controllable via a clean API.

```
BSE Internal Architecture:

DBC Loader
  └── cantools.database.load_file()
  └── Transport inference (BA_ attributes → CAN or SOME/IP)
  └── Signal Store population (once per load, not per frame)
          │
          ▼
Signal Store
  ├── signal_name → SignalDefinition(message, transport, interface,
  │                                  default, min, max, factor, offset)
  └── message_name → MessageState(active, period_ms, last_tx, signals)
          │
          ▼
Message Scheduler
  ├── One asyncio.Task per active message
  ├── Fires at period_ms interval
  ├── Reads current values from Signal Store
  ├── Encodes frame (cantools or SOME/IP serializer)
  └── Dispatches to correct backend via Router
          │
          ▼
Transport Router
  ├── CAN messages → CANBackend.send()
  └── SOME/IP messages → SOMEIPBackend.publish_event()
```

**Critical design decisions in the BSE:**

The Signal Store is populated once from the DBC at load time — never inside the per-frame dispatch loop. This was a bug in an earlier design that caused metadata duplication proportional to log length.

The `rig.sim.override()` context manager always restores signal state in `__aexit__`, even on exception. This is guaranteed by the implementation:

```python
async def __aexit__(self, exc_type, exc_val, exc_tb):
    # Always restore — regardless of whether an exception occurred
    for signal, original_value in self._saved_values.items():
        await self._store.set_signal(signal, original_value)
    return False  # Never suppress exceptions
```

---

## 6. Layer 3 — Test Orchestration (Local Agent)

The local agent runs on the machine physically connected to the HiL rig. It executes test suites, manages the rig lifecycle, and reports results to the cloud control plane.

### Responsibilities

- Discover and execute test suites from YAML manifests
- Inject the `Rig` fixture into test functions
- Manage test lifecycle (setup → precondition → stimulus → measure → teardown)
- Cache results in local SQLite when cloud is unreachable
- Sync cached results to cloud on reconnect
- Maintain a persistent WebSocket connection to the control plane
- Report rig health heartbeat every 30 seconds

### Module structure

```
crucihil/
└── agent/
    ├── agent.py            # Main agent process — WebSocket client + runner
    ├── runner/
    │   ├── runner.py       # Test suite execution engine
    │   ├── discovery.py    # Find test functions from YAML manifest
    │   ├── fixture.py      # Rig fixture injection
    │   └── lifecycle.py    # setup/teardown guarantees
    ├── manifest/
    │   ├── schema.py       # YAML manifest Pydantic schema
    │   ├── loader.py       # Load and validate YAML manifests
    │   └── validator.py    # Pre-run validation (rig has required hardware?)
    ├── reporter/
    │   ├── reporter.py     # Format and dispatch results
    │   ├── junit.py        # JUnit XML output
    │   ├── html.py         # HTML report generation
    │   └── json.py         # Structured JSON output
    └── cache/
        ├── cache.py        # Local SQLite result cache (synced_at column, query_unsynced, mark_synced)
        └── sync.py         # flush_unsynced() — groups by run_id, POSTs to /results/sync, marks synced
```

### YAML manifest schema

One YAML file = one test suite. Multiple tests per file. Every field is validated at load time before any hardware is touched (R9).

**Authoring split:** YAML handles the 80% case — signal-level send/expect/assert patterns, setup/teardown, fault injection metadata. Python handles complex logic: branching, loops, custom calculations. A test's `module` + `function` fields point to a Python function that receives only `rig: Rig` — no imports, no fixture boilerplate.

YAML suites can be written by hand, generated by `crucihil init --suite`, or generated by the AI via the MCP `generate_test_suite()` tool.

```yaml
# crucihil_suite.yaml — canonical schema v2

suite:
  name: engine_validation           # required — unique suite name
  version: "1.0.0"                  # semver — for schema compatibility tracking
  description: "Engine ECU validation suite"

hardware:                           # checked at runner startup (R9 — validate at startup)
  required:
    - ecu_main
    - can0
  optional:
    - can1                          # tests that need can1 are skipped if absent

definitions:
  can_dbc: "defs/vehicle_can.dbc"
  eth_dbc: "defs/vehicle_eth.dbc"

defaults:                           # inherited by every test unless overridden
  hw_variants: [virtual]            # which rig config names this suite can run on
  suite_types: [regression]         # smoke | regression | fault_injection | hil
  timeout: 30.0
  retries: 0                        # retries on error (not on fail — fail is definitive)
  setup_timeout: 15.0
  enabled: true

tests:

  - id: engine_startup              # required — unique within this suite
    name: "ECU boots and reaches idle RPM"
    description: "Verify ECU reaches idle RPM within boot_timeout of ignition"

    # ── Targeting ──────────────────────────────────────────────────────────
    enabled: true
    hw_variants: [virtual, orin_dev, orin_prod]   # rig config names that can run this test
    suite_types: [smoke, regression]              # run with: crucihil run --suite smoke
    priority: critical                            # critical | high | medium | low

    # ── Scheduling ─────────────────────────────────────────────────────────
    timeout: 20.0                                 # overrides suite default (R6)
    depends_on: []                                # skip if any listed test id failed
    repeat: 1                                     # >1 = flakiness / timing reliability

    # ── Traceability ───────────────────────────────────────────────────────
    tags: [engine, startup, safety]
    requirements: [REQ-ENG-001, REQ-ENG-002]      # spec / FMEA traceability
    ticket: PROJ-42                               # Jira / Linear / GitHub issue ref

    # ── Setup / teardown steps ─────────────────────────────────────────────
    setup:
      - sim.set:   { signal: "EngineData.RPM",       value: 0 }
      - sim.set:   { signal: "EngineData.CoolantTemp", value: 20 }
      - sim.start: EngineData
      - power.on:  ecu_main
      - gpio.set:  { pin: ignition_enable, value: true }

    teardown:
      - gpio.set:  { pin: ignition_enable, value: false }
      - sim.stop:  EngineData

    # ── Signal recording ───────────────────────────────────────────────────
    record:
      signals: [EngineData.RPM, EngineData.CoolantTemp]  # captured on every run

    # ── Python impl ────────────────────────────────────────────────────────
    module: tests.engine            # Python module path
    function: test_engine_startup   # receives only rig: Rig — no boilerplate
    params:                         # injected as **kwargs
      expected_rpm: 800


  - id: can_dropout_recovery
    name: "ECU recovers within 3s after 1s CAN dropout"
    enabled: true
    hw_variants: [virtual, orin_dev]
    suite_types: [fault_injection, regression]
    priority: high
    timeout: 15.0
    tags: [fault, can, recovery]
    depends_on: [engine_startup]    # skip if engine_startup failed

    # ── Fault injection (declared in YAML, activated by framework) ─────────
    faults:
      - can_dropout: { arb_id: 0x200, duration: 1.0 }

    setup:
      - sim.set:   { signal: "EngineData.RPM", value: 1500 }
      - sim.start: EngineData

    record:
      signals: [EngineData.RPM]

    module: tests.engine
    function: test_can_dropout_recovery


  - id: engine_startup_cold         # same function, different params
    name: "Cold-start: ECU reaches reduced idle RPM"
    enabled: true
    hw_variants: [virtual, orin_dev]
    suite_types: [regression]
    priority: high
    depends_on: []
    module: tests.engine
    function: test_engine_startup
    params:
      expected_rpm: 600             # cold-start threshold is lower
      startup_timeout: 15.0


  - id: vehicle_speed_range
    enabled: false                  # explicitly disabled — skip_reason required
    skip_reason: "Blocked on fw-412 — speed signal not implemented in v2.1"
    name: "Vehicle speed stays within 0–327 km/h spec"
    hw_variants: [virtual, orin_prod]
    suite_types: [regression, hil]
    priority: medium
    module: tests.vehicle
    function: test_vehicle_speed_range
```

**Per-test field reference:**

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | string | ✅ | Unique within suite. Used in `depends_on` and result storage. |
| `name` | string | — | Human-readable name for reports. |
| `enabled` | bool | — | Default `true`. Set `false` + `skip_reason` to disable. |
| `skip_reason` | string | if disabled | Explains why. Links to ticket. Shown in report. |
| `hw_variants` | list | — | Rig config names that can run this test. Runner skips if current rig not listed. |
| `suite_types` | list | — | `smoke` \| `regression` \| `fault_injection` \| `hil`. Filter with `--suite`. |
| `priority` | string | — | `critical` \| `high` \| `medium` \| `low`. CI can fail on `critical` only. |
| `timeout` | float | — | Seconds. Overrides `defaults.timeout`. (R6) |
| `depends_on` | list | — | Test ids. Skip this test if any dependency failed or was blocked. |
| `repeat` | int | — | Run N times. Flakiness detection, timing reliability validation. |
| `tags` | list | — | Free-form. For filtering and report grouping. |
| `requirements` | list | — | Spec / FMEA IDs. Surfaced in HTML report traceability matrix. |
| `ticket` | string | — | Jira / Linear / GitHub issue. Linked in HTML report. |
| `setup` | list | — | Declarative steps run before the test function. |
| `teardown` | list | — | Always runs, even if setup or function raised. (R8) |
| `faults` | list | — | Fault injection active for the duration of the test. |
| `record.signals` | list | — | Signals captured on every run (feeds CANvas + AI analysis). |
| `module` | string | — | Python module path to the assertion function. |
| `function` | string | — | Function name. Receives `rig: Rig` + `**params`. |
| `params` | dict | — | Injected as `**kwargs` into the function. |

### Test lifecycle — guaranteed ordering

```
For each test in suite:

1. VALIDATE    — check hardware requirements against rig config
                 raise BlockedError if requirements unmet

2. SETUP       — call suite-level setup if defined
                 raise BlockedError (not fail) if setup errors

3. PRECONDITION — call test setup / preconditions
                  raise BlockedError if preconditions not met

4. EXECUTE     — run the test function body
                 any AssertionError → status = fail
                 any CruciHiLError  → status = error
                 any other exception → status = error

5. TEARDOWN    — ALWAYS runs, even if steps 1-4 raised
                 hardware returned to known state
                 errors in teardown are logged but don't change test status

6. REPORT      — write result to local SQLite cache
                 attempt sync to cloud control plane
                 emit JUnit XML entry
```

### Agent ↔ cloud transport

**Decision: WebSocket with local SQLite cache for offline resilience.**

Rationale:
- Persistent bidirectional connection — cloud can push commands, agent pushes results
- Agent connects outbound (no inbound ports needed — works through firewalls and NAT)
- No polling overhead
- Native Python support (`websockets`, FastAPI native)
- Handles real-time test status streaming for dashboard naturally

```
Agent startup sequence:

1. Load rig config, validate (ConfigurationError → exit)
2. Connect all hardware backends
3. Open local SQLite result cache
4. If [rig.cloud] present: POST /api/v1/auth/token with api_key → store JWT + expiry
5. Connect WebSocket /ws/agent?token=<jwt>
6. Send agent_hello (rig name + version)
7. POST /api/v1/results/sync with all unsynced SQLite rows (grouped by run_id)
8. Start background tasks: JWT refresh (5 min margin), heartbeat ping (30s)
9. Wait for test run commands (Step 3+) / stream results as they complete

If [rig.cloud] is absent:
  → local-only mode: cache writes work, no WS connection attempted

If WebSocket drops:
1. Continue running any in-progress test suite (on_result writes to SQLite)
2. Reconnect loop with fixed 5s delay
3. On reconnect: re-auth if token expired, re-send agent_hello, flush unsynced SQLite

JWT refresh (background):
  Check every 60s; refresh if within 5 min of expiry
  On failure: log warning, keep old token, retry on next tick

Result flow (Phase 2 Step 2+):
  run_suite(on_result=agent.on_result)
    └── after each test: agent.on_result(result)
          ├── cache.write(result)        ← always, regardless of WS state
          └── ws.send({"type": "result", ...})  ← only if connected; silent skip on error
```

---

## 7. Test Code Ownership Model

This is one of the most important distinctions in the entire platform. Understanding it prevents architectural confusion when onboarding customers.

### Framework vs. customer code

CruciHiL ships the **runner**. Customers write the **tests**. This is the same relationship as pytest and your test files.

```
What CruciHiL owns and ships:
  Layer 2 — HAL (rig.can, rig.sim, rig.someip, rig.doip, rig.ecu, rig.power, rig.gpio, rig.fault)
  Layer 3 — Local Agent (runner, fixture injection, YAML schema, reporters)
  Layer 4 — Cloud Control Plane
  Layer 5 — MCP Server
  Layer 6 — Dashboard + CLI

What the customer owns and writes:
  Test functions  (.py files using the CruciHiL HAL)
  Suite manifests (.yaml files declaring which tests are in each suite)
  Rig configs     (.toml files declaring their hardware)
```

CruciHiL never tells the customer what to test or how to organise their test files. It provides the infrastructure that makes tests easy to write, run, and report on.

### Recommended customer repo structure

```
customer-firmware-repo/
├── crucihil_suite.yaml          ← suite manifest (source of truth for test discovery)
├── rigs/
│   ├── virtual.toml             ← virtual sim rig (no hardware needed)
│   ├── orin_devkit.toml         ← Nvidia Orin development kit
│   └── sa8775_bench.toml        ← Qualcomm SA8775 test bench
└── tests/
    ├── smoke/                   ← fast, run on every PR (< 5 min)
    │   ├── test_power_on.py
    │   ├── test_can_comms.py
    │   └── test_ecu_ready.py
    ├── regression/              ← full suite, run nightly
    │   ├── test_engine_startup.py
    │   ├── test_brake_response.py
    │   └── test_battery_management.py
    ├── fault_injection/         ← ISO 26262 FMEA validation
    │   ├── test_can_dropout.py
    │   └── test_sensor_loss.py
    └── hardware_specific/       ← tests that only run on specific platforms
        ├── orin/
        │   └── test_gpu_inference.py
        └── sa8775/
            └── test_safety_island.py
```

### Test discovery — manifest-driven, not folder-driven

The CruciHiL agent discovers tests by reading the YAML manifest — **not** by scanning folders. This is intentional.

**Why this matters:**
- The manifest is the explicit source of truth for what is in a suite
- The same test function can appear in multiple suites (smoke and regression)
- Tests can be organised in any folder structure that makes sense for the project
- Adding a new test file has no effect until it is referenced in the manifest

```yaml
# crucihil_suite.yaml — customer owns this file

suite:
  name: vehicle_adas_validation
  version: "1.0.0"

hardware:
  required: [ecu_main, can0, eth0]

definitions:
  can_dbc: "defs/vehicle_can.dbc"
  eth_dbc: "defs/vehicle_eth.dbc"

tests:
  - id: power_on
    module: tests.smoke.test_power_on
    function: test_ecu_power_on
    tags: [smoke, regression]

  - id: can_comms
    module: tests.smoke.test_can_comms
    function: test_can_heartbeat
    tags: [smoke, regression]

  - id: engine_startup
    module: tests.regression.test_engine_startup
    function: test_engine_startup
    tags: [regression]
    params:
      expected_rpm: 800
      startup_timeout: 10.0

  - id: engine_startup_cold
    module: tests.regression.test_engine_startup
    function: test_engine_startup
    tags: [regression]
    params:
      expected_rpm: 600
      startup_timeout: 15.0

  - id: gpu_inference_latency
    module: tests.hardware_specific.orin.test_gpu_inference
    function: test_inference_latency
    tags: [regression, orin-only]
    hardware: [gpu0]
```

### Running specific suites via tags

```bash
# Smoke only — fast, every PR
crucihil run --suite crucihil_suite.yaml --tags smoke --rig rigs/virtual.toml

# Full regression — nightly against real hardware
crucihil run --suite crucihil_suite.yaml --tags regression --rig rigs/orin_devkit.toml

# Platform-specific subset
crucihil run --suite crucihil_suite.yaml --tags orin-only --rig rigs/orin_devkit.toml

# Fault injection — ISO 26262 validation
crucihil run --suite crucihil_suite.yaml --tags fault-injection --rig rigs/sa8775_bench.toml
```

### CI/CD integration pattern

```yaml
# .github/workflows/hil.yml

jobs:
  smoke-virtual:
    steps:
      - run: crucihil run --suite crucihil_suite.yaml --tags smoke
                          --rig rigs/virtual.toml --output junit.xml

  regression-hardware:
    if: github.event_name == 'schedule'
    steps:
      - run: crucihil run --suite crucihil_suite.yaml --tags regression
                          --rig rigs/orin_devkit.toml --output junit.xml
```

---

## 8. Layer 4 — Cloud Control Plane

The control plane is a stateless Python FastAPI service backed by PostgreSQL. It orchestrates test runs, maintains the rig registry, stores historical results, and serves the dashboard API.

### Module structure

```
crucihil/
└── server/
    ├── main.py             # FastAPI app factory + CORS + lifespan (create_all on startup)
    ├── config.py           # pydantic-settings: DATABASE_URL, SECRET_KEY, JWT params
    ├── api/
    │   ├── deps.py         # get_db, get_current_rig (JWT verify → RigRow)
    │   ├── v1/
    │   │   ├── router.py       # Aggregates all v1 sub-routers under /api/v1
    │   │   ├── auth.py         # POST /api/v1/auth/token (API key → JWT)
    │   │   ├── rigs.py         # GET/POST/DELETE /api/v1/rigs
    │   │   ├── runs.py         # GET /api/v1/runs, POST /api/v1/runs/{id}/cancel
    │   │   └── results.py      # GET /api/v1/results, POST /api/v1/results/sync
    │   └── ws/
    │       └── agent.py        # WS /ws/agent?token=<jwt>
    ├── models/
    │   ├── base.py         # Single DeclarativeBase() shared by all ORM models + Alembic
    │   ├── rig.py          # RigRow — id (UUID str), name, api_key_hash, connected, version
    │   ├── run.py          # TestRunRow — id (run_id from agent), rig_id FK, counts
    │   └── result.py       # TestResultRow — mirrors SQLite cache exactly, UNIQUE(test_id, run_id)
    ├── services/
    │   ├── auth.py         # generate_api_key, hash/verify, issue_jwt, decode_jwt (HS256)
    │   └── result_sync.py  # upsert_run, batch_upsert_results (ON CONFLICT DO NOTHING), finalize_run
    └── db/
        ├── session.py      # get_engine, get_session_factory, get_db, set_engine, reset_engine
        └── migrations/
            ├── env.py          # Alembic env — imports Base + all models for create_all
            └── versions/
                └── 0001_initial.py  # Hand-written: creates rigs, test_runs, test_results + indexes
```

**Migration from spec to actual:** The original architecture doc described `tests.py`, `firmware.py`, `schemas.py`, and per-entity service files. The Phase 2 Step 1 implementation is leaner — no firmware table, no separate schemas module (Pydantic models are inline in routers), services merged into `auth.py` and `result_sync.py`. This is intentional: premature service decomposition adds indirection without benefit at this stage.

### REST API surface (Step 1 — implemented)

```
Authentication (no JWT required):
  POST   /api/v1/auth/token           # exchange API key → JWT (HS256, 1-hour expiry)

Rigs (JWT required):
  GET    /api/v1/rigs                 # list all rigs
  GET    /api/v1/rigs/{rig_name}      # single rig detail (connected, last_seen_at, version)
  POST   /api/v1/rigs                 # register rig — returns raw API key ONCE
  DELETE /api/v1/rigs/{rig_name}      # deregister

Runs (JWT required):
  GET    /api/v1/runs                 # list runs (filter: rig_name, suite_name, status, limit)
  GET    /api/v1/runs/{run_id}        # single run with pass/fail counts
  POST   /api/v1/runs/{run_id}/cancel # signal cancel (status → "cancelled"; WS delivery in Step 2)

Results (JWT required):
  GET    /api/v1/results              # list (filter: run_id, suite_name, status, limit)
  GET    /api/v1/results/{result_id}  # full result with signals/logs
  POST   /api/v1/results/sync         # batch upsert from agent (idempotent — ON CONFLICT DO NOTHING)

WebSocket:
  WS     /ws/agent?token=<jwt>        # agent connection; handles agent_hello + result messages

Planned (Step 2+):
  POST   /api/v1/runs                 # trigger run from dashboard/CI
  GET    /api/v1/dashboard/summary    # pass rates, rig utilisation, trends
  POST   /api/v1/firmware             # firmware artifact upload (Phase 2 later)
```

### RBAC model

Two roles with clear separation:

| Permission | Admin | Developer |
|---|---|---|
| View test results | ✓ (all) | ✓ (own team) |
| Trigger test runs | ✓ | ✓ |
| Cancel test runs | ✓ | ✓ (own) |
| Configure rig hardware | ✓ | — |
| Manage user accounts | ✓ | — |
| Upload firmware | ✓ | ✓ |
| View aggregate metrics | ✓ | ✓ |
| View other teams' data | ✓ | — |

RBAC is enforced by middleware on every API endpoint — not by UI visibility alone.

### PostgreSQL schema (Step 1 — implemented)

Three tables implemented in `0001_initial.py`. Schema is intentionally flat (Float for timestamps, Text for JSON) so the same ORM models work against SQLite in CI tests without dialect switching.

```sql
-- Rig registry
CREATE TABLE rigs (
    id            TEXT(36)    PRIMARY KEY,   -- UUID str (gen_random_uuid() in prod)
    name          TEXT(256)   NOT NULL UNIQUE,
    api_key_hash  TEXT        NOT NULL,       -- SHA-256 hex; raw key shown once, never stored
    last_seen_at  FLOAT8,                     -- Unix timestamp; updated on WS connect
    connected     BOOLEAN     NOT NULL DEFAULT FALSE,
    version       TEXT(64),                   -- agent version from agent_hello
    created_at    FLOAT8      NOT NULL,
    extra_meta    TEXT        NOT NULL DEFAULT '{}'  -- JSON; tags, location, hw_type
);

-- Test run summaries (one per crucihil run invocation)
CREATE TABLE test_runs (
    id            TEXT(64)    PRIMARY KEY,    -- run_id UUID from agent (same as SQLite cache)
    rig_id        TEXT(36)    NOT NULL REFERENCES rigs(id) ON DELETE CASCADE,
    suite_name    TEXT(256)   NOT NULL,
    started_at    FLOAT8      NOT NULL,
    completed_at  FLOAT8,
    status        TEXT(16)    NOT NULL DEFAULT 'running',
    total         INTEGER     NOT NULL DEFAULT 0,
    passed        INTEGER     NOT NULL DEFAULT 0,
    failed        INTEGER     NOT NULL DEFAULT 0,
    blocked       INTEGER     NOT NULL DEFAULT 0,
    errored       INTEGER     NOT NULL DEFAULT 0,
    skipped       INTEGER     NOT NULL DEFAULT 0,
    triggered_by  TEXT(32)                   -- "ci" | "agent" | "dashboard"
);
CREATE INDEX ix_test_runs_rig_id     ON test_runs(rig_id);
CREATE INDEX ix_test_runs_started_at ON test_runs(started_at);

-- Individual test results — mirrors SQLite cache schema exactly
CREATE TABLE test_results (
    id            BIGSERIAL   PRIMARY KEY,
    test_id       TEXT(256)   NOT NULL,
    run_id        TEXT(64)    NOT NULL REFERENCES test_runs(id) ON DELETE CASCADE,
    suite_name    TEXT(256)   NOT NULL,
    status        TEXT(16)    NOT NULL,
    duration      FLOAT8      NOT NULL,
    started_at    FLOAT8      NOT NULL,
    completed_at  FLOAT8      NOT NULL,
    errors        TEXT        NOT NULL DEFAULT '[]',   -- JSON array
    logs          TEXT        NOT NULL DEFAULT '[]',   -- JSON array
    signals       TEXT        NOT NULL DEFAULT '{}',   -- JSON object
    extra_meta    TEXT        NOT NULL DEFAULT '{}',   -- JSON object (not "metadata" — reserved by SQLAlchemy)
    UNIQUE (test_id, run_id)   -- sync idempotency key: ON CONFLICT DO NOTHING
);
CREATE INDEX ix_test_results_run_id     ON test_results(run_id);
CREATE INDEX ix_test_results_started_at ON test_results(started_at);
CREATE INDEX ix_test_results_status     ON test_results(status);
```

**Key invariants:**
- `UNIQUE(test_id, run_id)` — the agent can replay its entire SQLite cache on reconnect, zero duplicates
- `run_id` in `test_results` matches `id` in `test_runs` matches `run_id` in the SQLite cache — same UUID, no mapping
- Counts (`total`, `passed`, `failed`, …) in `test_runs` are recomputed from `test_results` via `recompute_run_counts()` after every sync batch — never trusted from the agent directly

**Planned additions (later Phase 2):**
- `test_suites` table — suite manifest registry
- `firmware_artifacts` table — firmware upload/tracking
- `dashboard/summary` computed views

---

## 8. Layer 5 — AI Interface (MCP)

The MCP server exposes CruciHiL functionality to any AI model through the Model Context Protocol. It is a separate service that calls the control plane's REST API.

**Decision: MCP server runs as a separate service in the same Docker Compose stack.**

Rationale: Different lifecycle, different scaling, independent versioning. Shares Docker network with the web server — internal calls are localhost.

### Module structure

```
crucihil/
└── mcp/
    ├── server.py           # FastMCP server definition
    ├── tools/
    │   ├── tests.py        # list_tests, run_test, get_test_status
    │   ├── results.py      # get_test_results, get_test_history
    │   ├── rigs.py         # list_rigs, get_rig_hardware_config
    │   └── control.py      # cancel_test
    ├── client.py           # Internal REST client to control plane
    └── auth.py             # MCP → control plane authentication
```

### MCP tool definitions

```python
# crucihil/mcp/tools/tests.py

@mcp.tool()
async def list_available_tests(
    rig_id: str | None = None,
    tags: list[str] | None = None
) -> list[dict]:
    """
    List all registered test suites.
    Optionally filter by rig_id (suites compatible with that rig's hardware)
    or by tags.
    Returns: [{id, name, version, description, tags, hardware_required}]
    """

@mcp.tool()
async def run_test(
    suite_name: str,
    rig_id: str,
    fw_hash: str | None = None,
    params: dict | None = None
) -> dict:
    """
    Start a test run. Returns immediately with a run_id.
    Use get_test_status(run_id) to poll for completion.
    Returns: {run_id, status, rig_id, suite_name, started_at}
    """

@mcp.tool()
async def get_test_status(run_id: str) -> dict:
    """
    Get the current status of a test run.
    Returns: {run_id, status, progress, passed, failed, blocked, total}
    """

@mcp.tool()
async def get_test_results(run_id: str) -> dict:
    """
    Get full results for a completed test run.
    Returns: {run_id, status, duration, summary, tests: [{id, status, duration,
              errors, logs}]}
    """

@mcp.tool()
async def list_rigs() -> list[dict]:
    """
    List all registered rigs and their current status.
    Returns: [{id, name, platform, status, hardware_summary}]
    """

@mcp.tool()
async def get_rig_hardware_config(rig_id: str) -> dict:
    """
    Get the hardware configuration for a specific rig.
    Returns: {can_interfaces, ethernet_interfaces, ecus, power_rails, gpio_pins}
    """

@mcp.tool()
async def cancel_test(run_id: str) -> dict:
    """
    Cancel a running test. Teardown will still execute on the agent.
    Returns: {run_id, status: "cancelled"}
    """

@mcp.tool()
async def get_test_history(
    suite_name: str | None = None,
    rig_id: str | None = None,
    status: str | None = None,
    limit: int = 20,
    since: str | None = None   # ISO datetime
) -> list[dict]:
    """
    Query historical test runs with filters.
    Returns: [{run_id, suite_name, rig_id, status, duration, started_at}]
    """

# ── AI-specific tools (Phase 2–3) ─────────────────────────────────────────────

@mcp.tool()
async def list_signals(
    rig_id: str,
    transport: str | None = None,     # "can" | "ethernet" | None = all
    message: str | None = None,       # filter by DBC message name
) -> list[dict]:
    """
    List all signals available on a rig, sourced from the loaded DBC/descriptor
    files.  Returns: [{key, signal_name, message_name, unit, min, max,
    cycle_time_ms, transport}]

    Used by AI to write accurate expect() conditions — correct signal keys,
    value ranges, and cycle times.  Without this tool the AI guesses; with it
    the AI generates tests that work on first run.
    """

@mcp.tool()
async def discover_hardware(agent_id: str) -> dict:
    """
    Trigger hardware discovery on the local agent.

    Agent probes:
      - CAN interfaces:   ip link show type can  → name, state, bitrate
      - DoIP entities:    VehicleIdentificationRequest broadcast → VIN, addr, IP
      - GPIO:             /sys/class/gpio/
      - Serial ports:     /dev/ttyUSB*, /dev/ttyACM*
      - Ethernet:         ip link show
      - PEAK adapters:    PCAN API (if installed)

    Returns: {can_interfaces, doip_entities, gpio_pins, serial_ports,
              ethernet_interfaces}

    If any probe fails the result still returns — partial discovery is valid.
    The AI asks follow-up questions for anything that couldn't be detected.
    """

@mcp.tool()
async def generate_rig_config(
    discovery: dict,
    name: str,
    answers: dict | None = None,      # AI follow-up question answers from user
) -> str:
    """
    Generate a rig TOML from a hardware discovery report + optional user answers.
    Returns a TOML string ready to write to rigs/<name>.toml via write_file().

    Flow:
      1. AI calls discover_hardware()
      2. AI asks 2-3 clarifying questions (GPIO pin roles, primary CAN bus, etc.)
      3. User answers in natural language
      4. AI calls generate_rig_config(discovery, name, answers)
      5. AI calls write_file("rigs/<name>.toml", toml_string, confirm=True)
      6. Agent writes after user approves
    """

@mcp.tool()
async def generate_test_suite(
    rig_id: str,
    description: str,
    suite_types: list[str] | None = None,
    signals: list[str] | None = None,
) -> dict:
    """
    Generate a YAML suite manifest + Python stub file from a natural language
    description.  Internally calls list_signals() and get_rig_hardware_config()
    to ground the generation in real signal names, ranges, and hardware.

    Returns: {yaml_path, yaml_content, python_path, python_content}

    The AI writes both files via write_file().  The Python stub contains
    correctly-named functions with rig: Rig parameter and TODO comments.
    The user fills in assertion logic; the AI has already wired the signal
    names, timeout values, and setup/teardown steps.
    """

@mcp.tool()
async def write_file(
    path: str,
    content: str,
    confirm: bool = True,
) -> dict:
    """
    Write content to a file on the local agent machine.

    Security model:
      - confirm=True (default): first write of the session requires explicit
        user approval before the agent writes to disk.
      - Subsequent writes in the same session auto-accept (session token issued
        after first confirmation).
      - confirm=False: skip confirmation — only for programmatic pipelines
        where a human already approved the session (e.g. CI workflow).

    Returns: {path, written: bool, confirmed_by: "user" | "session" | "pipeline"}
    """
```

### Multi-vendor AI provider abstraction

```python
# crucihil/ai/provider.py

from abc import ABC, abstractmethod

class AIProvider(ABC):
    @abstractmethod
    async def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        system: str | None = None
    ) -> str: ...

class AnthropicProvider(AIProvider):
    def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514"):
        self._client = anthropic.AsyncAnthropic(api_key=api_key)
        self._model = model

    async def chat(self, messages, tools=None, system=None) -> str:
        response = await self._client.messages.create(
            model=self._model,
            messages=messages,
            tools=tools or [],
            system=system or "",
            max_tokens=2048
        )
        return response.content[0].text

class OpenAIProvider(AIProvider): ...
class GeminiProvider(AIProvider): ...
class CopilotProvider(AIProvider): ...

def create_provider(vendor: str, api_key: str, model: str) -> AIProvider:
    providers = {
        "claude":  AnthropicProvider,
        "openai":  OpenAIProvider,
        "gemini":  GeminiProvider,
        "copilot": CopilotProvider,
    }
    if vendor not in providers:
        raise ConfigurationError(f"Unknown AI vendor: {vendor}")
    return providers[vendor](api_key=api_key, model=model)
```

### Example AI workflow

```
Engineer: "Run the power management smoke tests on rig-2 with 
          firmware abc123 and tell me what happened."

AI model calls MCP tools in sequence:
  1. list_rigs()
     → confirms rig-2 is online and available

  2. list_available_tests(rig_id="rig-2", tags=["smoke"])
     → confirms power_management_smoke suite exists

  3. run_test(suite_name="power_management_smoke",
              rig_id="rig-2", fw_hash="abc123")
     → returns run_id="run_456"

  4. get_test_status(run_id="run_456")  [polls until complete]
     → status: "complete"

  5. get_test_results(run_id="run_456")
     → 12 passed, 2 failed

AI responds:
  "12 of 14 tests passed. Two failures:
   - test_deep_sleep_recovery: timed out at 4,200ms (expected < 3,000ms)
   - test_wakeup_gpio_edge: fault_indicator signal not detected
   
   The deep sleep timeout suggests the ECU is taking longer to wake
   than expected — this matches the pattern from rig-2's last 3 runs.
   The GPIO failure may be related: if the ECU is slow to wake, 
   the fault indicator edge may fire outside the observation window.
   I'd recommend checking the wakeup_timeout config on rig-2's TOML."
```

### AI-Assisted Rig Setup (Phase 2)

**Decision: No custom AI model. The MCP tools provide context; a general-purpose LLM provides reasoning.**

General-purpose LLMs (Claude, GPT-4, Gemini) already know Python, YAML, CAN/DoIP/UDS protocol specs, and TOML. They do not know the user's specific rig hardware, DBC signals, or test history. The MCP tools bridge exactly that gap. Training a custom model would cost millions, take months, and produce something strictly worse than what BYOK delivers today.

**Three rig setup paths — all produce the same TOML:**

```
Path A: Manual                Path B: CLI Wizard            Path C: AI (MCP)
──────────────────────        ──────────────────────        ────────────────────────
User writes TOML by hand  →   crucihil init (prompts)   →   AI discovers + generates
Hard, error-prone             Guided, 5-minute flow         Near-zero user input
```

**Path C — AI-assisted discovery flow:**

```
1. User physically connects hardware (CAN cables, Ethernet, power, GPIO)

2. User: "crucihil discover"  OR  tells AI: "set up my rig"

3. Agent probes hardware → sends discovery report to cloud:
   {
     "can":   [{"iface": "can0", "bitrate": 500000},
               {"iface": "can1", "bitrate": 1000000}],
     "doip":  [{"vin": "1HGBH41JXM", "address": 0x0001, "ip": "192.168.1.10"}],
     "gpio":  {"detected_pins": [22, 24, 27]},
     "serial": ["/dev/ttyUSB0"],
     "dbc_files": ["defs/vehicle_can.dbc"]
   }

4. AI asks 2-3 clarifying questions:
   "I found 2 CAN interfaces and 1 DoIP ECU. What is this rig called?"
   "Which GPIO pins are ignition, reset, and fault indicator?"
   "Is /dev/ttyUSB0 a bench PSU or a relay board?"

5. AI calls generate_rig_config(discovery, name="orin_dev", answers={...})
   → TOML string generated

6. AI calls write_file("rigs/orin_dev.toml", toml, confirm=True)
   → User sees the TOML diff and confirms

7. AI runs a rig health check:
   "can0: ✅  bus active, 43% load
    DoIP 0x0001: ✅  responding to entity status
    GPIO ignition_enable: ✅  toggle OK
    can1: ⚠️  bus-off — check termination"

8. Rig is ready. Zero manual TOML editing.
```

**Graceful degradation — discovery always works, even when probing fails:**

```
Level 1: Full auto-discovery
  Agent probes all interfaces → AI generates complete TOML → user confirms.

Level 2: Partial discovery
  Agent finds CAN but not the USB relay board →
  AI: "I found can0 and can1. What hardware controls your GPIO —
       Linux sysfs, a USB relay board, Raspberry Pi over SSH, or custom?"
  User answers → AI generates the missing section.

Level 3: Nothing detected (Windows, VM, remote agent, unfamiliar hardware)
  AI starts from scratch via conversation:
  User: "Two CAN at 500k and 1M, Orin over DoIP at 192.168.1.10,
         CH340 USB relay for power"
  AI → generates complete TOML from the description alone.

Level 4: Truly unknown hardware
  AI: "Is there a Python library for it?  If so, what's the install name —
       I'll generate a backend stub implementing AbstractGPIOBackend."
  User gets a working ABC skeleton in under a minute.
```

**File-write security model:**

```
First write of session → agent sends diff to user → user confirms → file written
                         session_token issued

Subsequent writes      → auto-accepted (session_token present)

confirm=False          → CI/pipeline mode only — human already approved session
```

**Extensible interface schema — custom backends via module path:**

The TOML `backend` field accepts a fully-qualified Python module path for hardware that CruciHiL does not natively support. No changes to the platform repo required.

```toml
[rig.gpio.custom_pcb]
backend = "myorg.rig_io_board"    # importlib resolves this at connect() time
port    = "/dev/ttyACM0"
pins    = { ecu_reset = 0, kl15 = 1, kl30 = 2 }

[rig.gpio.rpi_hat]
backend  = "rpi_gpio_ssh"
host     = "192.168.1.50"
key_file = "~/.ssh/rig_rpi"
pins     = { fault_indicator = 22, brake_active = 27 }
```

Any class that implements the relevant ABC (`AbstractGPIOBackend`, `AbstractCANBackend`, etc.) works as a drop-in. The AI can generate the stub.

**Phase note:** `[rig.udp]` and `[rig.uds]` are first-class sections planned for Phase 1. UDP is required by AV/robotics teams for proprietary ECU protocols. UDS ISO-TP over CAN is required for diagnostic workflows. Both follow the same extensible backend model.

---

## 9. Layer 6 — Interfaces

### CLI

```bash
# Test execution
crucihil run --suite smoke --rig rigs/virtual.toml
crucihil run --suite regression --rig rigs/orin_dev.toml --fw builds/v2.1.bin

# Results
crucihil results --run-id run_456
crucihil history --suite power_management --limit 10

# Rig management  
crucihil rigs list
crucihil rigs status rig-2
crucihil rigs reserve rig-2 --duration 60m

# Agent management
crucihil agent --rig rigs/orin_dev.toml   # cloud URL + key come from [rig.cloud] in TOML
crucihil agent status
```

### Web Dashboard

```
Dashboard structure:

/                       # Overview: pass rates, rig status, recent runs
/runs                   # All test runs with filters
/runs/:id               # Single run detail: per-test results, signal traces
/rigs                   # Rig registry, live status
/rigs/:id               # Rig detail: hardware config, utilisation, history
/suites                 # Test suite registry
/suites/:id             # Suite detail: tests, history, flakiness
/firmware               # Firmware artifact registry
/settings               # API key config, AI provider, notifications
```

### CI/CD integration

The CLI + JUnit XML output provides free integration with every CI system:

```yaml
# .github/workflows/hil.yml
name: HiL Smoke Tests
on: [push]
jobs:
  hil-smoke:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run HiL smoke suite
        run: |
          crucihil run \
            --suite smoke \
            --rig rigs/ci_virtual.toml \
            --output junit.xml
      - name: Publish results
        uses: actions/upload-artifact@v4
        with:
          name: hil-results
          path: junit.xml
```

---

## 10. Cross-Cutting Concerns

### Exception hierarchy

```python
# crucihil/hal/models/exceptions.py

class CruciHiLError(Exception):
    """Base for all CruciHiL exceptions."""

# Test execution exceptions
class BlockedError(CruciHiLError):
    """Precondition not met — hardware not in required state.
    Does NOT count as a test failure. Triggers rig health alert."""

class TestTimeoutError(CruciHiLError):
    """Test exceeded its configured timeout."""

class SetupError(CruciHiLError):
    """Suite or test setup failed. Marks test as blocked."""

class TeardownError(CruciHiLError):
    """Teardown failed. Logged but does not change test status."""

# Hardware exceptions
class HardwareError(CruciHiLError):
    """Base for hardware-related errors."""

class CANError(HardwareError):
    """CAN bus error — bus-off, timeout, frame corruption."""

class CANTimeoutError(CANError):
    """Expected CAN message/signal not received within timeout."""

class SOMEIPError(HardwareError):
    """SOME/IP error — service unavailable, subscription failed."""

class SOMEIPTimeoutError(SOMEIPError):
    """Expected SOME/IP event not received within timeout."""

class DoIPError(HardwareError):
    """DoIP transport error."""

class DoIPNegativeResponseError(DoIPError):
    """ECU returned a negative UDS response."""
    def __init__(self, nrc: int, message: str):
        self.nrc = nrc
        super().__init__(message)

class PowerError(HardwareError):
    """Power rail error — voltage out of range, rail fault."""

class GPIOError(HardwareError):
    """GPIO error — pin direction mismatch, unexpected state."""

class FlashError(HardwareError):
    """ECU firmware flash failed."""

# Framework exceptions
class ConfigurationError(CruciHiLError):
    """Invalid rig configuration or YAML manifest."""

class BackendError(CruciHiLError):
    """Backend not available or failed to initialise."""
```

### Observability and logging

```python
# Every CruciHiL operation emits structured log events.
# Log levels:

# DEBUG   — internal framework events (frame sent, signal value polled)
# INFO    — test lifecycle events (test started, assertion passed)
# WARNING — non-fatal issues (signal at boundary, rig slow to respond)
# ERROR   — test failures and hardware errors
# CRITICAL — framework errors that prevent test execution

# Log output:
# - stdout (structured JSON by default, human-readable with --log-format pretty)
# - test_output/{run_id}/run.log (full log for every run)
# - test_output/{run_id}/signals/ (recorded signal traces)

# Log format (JSON):
{
  "timestamp": "2025-01-15T14:23:01.234Z",
  "level": "INFO",
  "test_id": "engine_startup",
  "run_id": "run_456",
  "event": "assertion_passed",
  "signal": "EngineRPM",
  "value": 823.0,
  "elapsed_ms": 342
}
```

### API versioning

```
All REST API endpoints are versioned: /api/v1/...
All MCP tools include a schema_version field in responses.
Rig TOML files include a spec_version field.
YAML manifests include a version field.

Breaking changes require a new API version (v2).
Additive changes (new fields, new endpoints) are backward compatible.

The HAL Python API follows semver.
Tests written against HAL v0.x are not guaranteed to work with v1.x.
Tests written against HAL v1.x are guaranteed to work with v1.y for y > x.
```

### Fault descriptor pattern

Faults are described by plain objects, not coroutines. This was a critical bug in the original spec — passing coroutines to a context manager would execute them immediately.

```python
# Correct pattern — FaultDescriptor is a plain dataclass
@dataclass
class FaultDescriptor:
    fault_type: str
    params: dict
    started_at: float | None = None

# rig.fault methods return descriptors, not coroutines
dropout = rig.fault.can_dropout(arb_id=0x100, duration=2.0)
# dropout is a FaultDescriptor, not a coroutine

# inject() takes descriptors and activates them
async with rig.fault.inject(dropout):
    # fault is active here
    await asyncio.sleep(2.0)
# fault is deactivated — always, even on exception

# For immediate one-shot faults, use execute():
await rig.fault.execute(rig.fault.can_error_frame(interface="can0"))
```

---

## 11. CANvas Integration Flywheel

CANvas (CAN log visualization) and CruciHiL together form a flywheel — two products that are better together.

```
CruciHiL runs a test → failure at t=14.2s
        │
        ▼
CruciHiL MCP: get_test_results(run_id)
        │
        ▼
Signal trace recorded during test → stored in test_results.signals
        │
        ▼
CANvas MCP: get_signal_timeline(
              signal="BrakePressure",
              log=run_signal_trace,
              window=(14.0, 16.5)
            )
        │
        ▼
AI: "BrakePressure dropped to 0 at t=14.2s, 200ms before the
     test timeout. EngineData was transmitting at 500ms cadence
     instead of its nominal 10ms — bus load was 94%. The pressure
     signal likely missed its arbitration window. This pattern
     matches 3 previous failures on rig-2."
```

This workflow doesn't exist in the market. dSPACE can't do it. Vector can't do it. It requires both products working together through a shared AI interface.

### Integration architecture

```
CANvas MCP Server          CruciHiL MCP Server
       │                          │
       │   Shared signal format   │
       └──────────┬───────────────┘
                  │
             AI Model
```

Signal traces produced by CruciHiL test runs are in the same `.asc` format that CANvas ingests. No conversion layer needed. The AI model calls both MCP servers in sequence.

---

## 12. Deployment Architecture

### Self-hosted (primary model)

```
Per-client Docker Compose stack:

services:
  web:          # FastAPI control plane
  mcp:          # MCP server
  db:           # PostgreSQL
  redis:        # WebSocket pub/sub, task queue (Phase 2)
  nginx:        # Reverse proxy, TLS termination

Local machine (per rig):
  crucihil-agent  # Connects outbound to web service
```

```yaml
# docker-compose.yml
version: "3.9"
services:
  web:
    image: crucihil/server:${VERSION}
    environment:
      - DATABASE_URL=postgresql://...
      - JWT_SECRET=${JWT_SECRET}
      - AGENT_WS_SECRET=${AGENT_WS_SECRET}
    ports: ["8080:8080"]
    depends_on: [db]

  mcp:
    image: crucihil/mcp:${VERSION}
    environment:
      - CRUCIHIL_API_URL=http://web:8080
      - CRUCIHIL_API_KEY=${MCP_API_KEY}
    ports: ["8765:8765"]
    depends_on: [web]

  db:
    image: postgres:16
    volumes: ["pgdata:/var/lib/postgresql/data"]
    environment:
      - POSTGRES_DB=crucihil
      - POSTGRES_PASSWORD=${DB_PASSWORD}

volumes:
  pgdata:
```

### Multi-tenant provisioning

```
Provisioning orchestrator (internal admin tool):
  1. Admin enters client name, tier, rig count
  2. Generates unique JWT_SECRET, DB_PASSWORD, AGENT_WS_SECRET
  3. Creates per-client docker-compose.yml from template
  4. Deploys to client's server (SSH + docker compose up)
  5. Returns: dashboard URL, agent download link, API credentials

Per client:
  - Unique subdomain: client-name.crucihil.io
  - Isolated PostgreSQL database
  - Isolated Docker network
  - Separate credentials — no cross-client access possible
```

### Known gaps in multi-tenant model (accepted debt)

- No automated backup strategy — clients are responsible for DB backup in self-hosted model
- No automatic database migrations on upgrade — admin must run `crucihil migrate` manually
- No disaster recovery playbook — document this before first enterprise customer

---

## 13. Data Architecture

### Result storage — dual layer

```
Local agent (SQLite):
  - All results written here first, synchronously
  - Survives cloud connection loss
  - Retained for 30 days, then pruned
  - Schema mirrors cloud DB for easy sync

Cloud DB (PostgreSQL):
  - Source of truth for dashboard and historical queries
  - Receives results from agent via WebSocket sync
  - Retained indefinitely
  - synced_from_cache=true marks results that arrived via cache
```

### Signal trace storage

Signal traces (recorded CAN/SOME-IP data during tests) are large. They are stored as compressed `.asc` files, not in the database.

```
Storage locations:
  Local agent:    test_output/{run_id}/signals/
  Cloud:          Object storage (S3/R2) — URL stored in test_results.signals
  
Compression:      gzip, ~10:1 ratio for typical CAN logs
Retention:        30 days by default, configurable per tier
```

---

## 14. Security Model

### Agent ↔ cloud authentication

```
- Agent uses a pre-shared secret (AGENT_WS_SECRET) for WebSocket auth
- Secret is provisioned at install time, stored in agent config
- Rotate via: crucihil agent rotate-secret
- All WebSocket traffic over TLS
```

### User authentication

```
- JWT tokens, 1 hour expiry
- Refresh tokens, 30 day expiry
- Tokens signed with HS256 (HMAC-SHA256)
- Phase 2: SAML/OIDC for enterprise SSO
```

### API key (MCP)

```
- API key per client for MCP → control plane calls
- API key scoped to read-only or read-write
- Passed in Authorization header
- Rotate without downtime via key rotation endpoint
```

### Data isolation

```
- Every database query includes client_id filter via SQLAlchemy event hooks
- No query can return data from a different client
- Verified by integration tests that attempt cross-client queries
```

---

## 15. Technology Stack

| Layer | Technology | Rationale |
|---|---|---|
| HAL / Agent | Python 3.11+, asyncio | Engineers know it, async required for hardware I/O |
| CAN backend (virtual) | asyncio queues | Zero dependencies, fast, deterministic |
| CAN backend (real) | python-can + SocketCAN | Industry standard, broad hardware support |
| CAN backend (PEAK) | python-can PEAK driver | Common in automotive labs |
| SOME/IP (virtual) | python-someip | Pure Python, no system deps |
| SOME/IP (real) | vsomeip + Python wrapper | Production-grade, handles SD automatically |
| DoIP | python-doip | Minimal, covers Phase 0 scope |
| DBC parsing | cantools | Canonical Python CAN library |
| Rig config | TOML + Pydantic | Readable, validated, typed |
| Test manifests | YAML + Pydantic | Readable by non-programmers |
| Control plane | FastAPI + PostgreSQL | Async, typed, fast |
| WebSocket | FastAPI native (Starlette) | Built-in, no extra deps |
| MCP server | FastMCP | Official Python MCP library |
| Dashboard | React + Recharts + Tailwind | Modern, componentized |
| Auth | JWT (python-jose) | Stateless, standard |
| Migrations | Alembic | Standard SQLAlchemy migration tool |
| Containers | Docker + Docker Compose | Simple self-hosting story |
| CI/CD | GitHub Actions | Where engineers already work |
| Local cache | SQLite via SQLAlchemy | Zero ops, file-based, reliable |

---

## 16. Implementation Phases

### Phase 0 — Foundation (Weeks 1–8) ✅ COMPLETE
*Goal: one real test running end-to-end against virtual simulation*

- [x] HAL module structure and backend ABCs
- [x] Virtual backends: CAN, SOME/IP Events/Fields, DoIP, Power, GPIO
- [x] BSE: DBC loader, Signal Store, Message Scheduler, Transport Router
- [x] Exception hierarchy
- [x] Rig TOML config loader with Pydantic validation
- [x] Test runner: discovery, fixture injection, lifecycle guarantees
- [x] Result model: TestResult, ExpectResult, FaultDescriptor
- [x] JUnit XML reporter
- [x] CLI: `crucihil run`
- [x] YAML manifest schema and loader (v2 schema)
- [x] Virtual rig TOML
- [x] One end-to-end test passing against virtual backend (98 tests, all green)
- [x] Repo scaffold: CLAUDE.md, tasks/, tests/

### Phase 1 — MVP (Weeks 8–20) ✅ COMPLETE
*Goal: one real engineer running real tests on real hardware*

- [x] SocketCAN backend — Linux SocketCAN via python-can with asyncio receive loop + `block_arb_id` for fault injection
- [x] vsomeip wrapper backend — lazy import, fails gracefully if vsomeip not installed; Events + Fields scope
- [x] python-doip backend — uses `doipclient` library, lazy import, all blocking calls via `run_in_executor`
- [x] Full fault injection across all buses — `block_arb_id`/`unblock_arb_id` on virtual + socketcan + peak; `hasattr` check for backend-agnostic activation
- [x] HTML report generation — self-contained (all CSS/JS inlined), pass-rate badge, sortable table, expandable per-test detail; `--html` CLI flag
- [x] `rig.ecu.flash()` via DoIP — full UDS 0x34/0x36/0x37 sequence; graceful empty-response fallback for virtual backend
- [x] PEAK CAN backend — same structure as socketcan, uses `interface='pcan'`; lazy import
- [x] `crucihil agent start` command — persistent daemon, SIGINT/SIGTERM handlers, WebSocket cloud stub; local-only mode when no `--cloud` URL given
- [x] Local SQLite result cache — SQLAlchemy Declarative ORM, `extra_meta` column (not `metadata` — SQLAlchemy reserved), 30-day pruning on open
- [x] `crucihil init` — auto-detects CAN via `ip link show type can`, Ethernet, prompts for power/DBC; validates generated TOML before writing
- [x] JSON Schema for rig TOML — generated via `RigConfig.model_json_schema()` (Pydantic v2); written to `schemas/rig_config.schema.json`
- [x] JSON Schema for YAML manifest — hand-authored (TestSuite is a dataclass, not Pydantic); written to `schemas/suite_manifest.schema.json`
- [x] `[rig.udp]` TOML section — `UDPInterfaceConfig` Pydantic model; `AbstractUDPBackend` ABC; `VirtualUDPBackend` with inject() for test fixtures; registered as `"virtual_udp"`
- [x] `[rig.uds]` TOML section — `UDSConfig` Pydantic model; `AbstractUDSBackend` ABC; `VirtualUDSBackend` with handler registry; registered as `"virtual_uds"`
- [x] Custom backend module path support — `_resolve_custom()` handles `"module.path:ClassName"` and `"module.path"` syntax; falls through to importlib when name not in registry
- [ ] First design partner running tests against physical ECU (requires real hardware — not yet verified

### Phase 2 — Platform (Weeks 20–40)
*Goal: web dashboard, cloud control plane, first paying customer*

**Step 1 — FastAPI control plane + PostgreSQL ✅ COMPLETE (173 tests)**
- [x] FastAPI app factory + CORS + lifespan (`server/main.py`)
- [x] pydantic-settings config (`server/config.py`)
- [x] ORM models: `RigRow`, `TestRunRow`, `TestResultRow` (`server/models/`)
- [x] SQLAlchemy session factory with `set_engine()`/`reset_engine()` for test injection
- [x] Alembic setup + hand-written `0001_initial.py` migration
- [x] Auth service: API key gen/hash (SHA-256), JWT issue/verify (HS256)
- [x] Result sync service: `upsert_run`, `batch_upsert_results` (`ON CONFLICT DO NOTHING`), `finalize_run`
- [x] REST endpoints: `/api/v1/auth/token`, `/api/v1/rigs`, `/api/v1/runs`, `/api/v1/results/sync`
- [x] WebSocket endpoint `/ws/agent` — JWT auth, `agent_hello` + `result` handlers
- [x] 44 new tests (unit + integration) — SQLite `StaticPool` in-memory, no PostgreSQL required in CI

**Step 2 — WebSocket agent ↔ cloud protocol ✅ COMPLETE (207 tests)**
- [x] `[rig.cloud]` TOML section (`CloudConfig`: `url` + `api_key`); absent → local-only, zero behavior change
- [x] JWT auth on startup: agent `POST /api/v1/auth/token`, stores token + expiry
- [x] `on_result` callback on `run_suite()`: fires after each test, writes to SQLite + streams via WS
- [x] Offline sync flush: on every (re)connect, `flush_unsynced()` groups SQLite rows by `run_id`, POSTs to `/results/sync`, marks `synced_at`
- [x] `synced_at` column in SQLite cache; schema migration handles existing DBs
- [x] JWT refresh: background `_auth_loop` checks every 60s, refreshes 5 min before expiry
- [x] Heartbeat: `{"type": "ping"}` every 30s; server `_handle_ping` updates `last_seen_at`
- [x] Server `ping` handler added to `/ws/agent`
- [x] `--cloud` CLI flag removed; cloud config lives in TOML only
- [x] 34 new tests (unit/agent + integration/agent)

**Step 3 — MCP server**
- [ ] MCP server — 7 core tools + `list_signals`, `discover_hardware`, `generate_rig_config`, `write_file`

**Step 4 — Docker Compose**
- [ ] Docker Compose self-hosting stack (web + db + mcp)

**Step 5 — React dashboard**
- [ ] React dashboard (run history, rig status, per-test detail)
- [ ] Flaky test detection

**Step 6 — Customer**
- [ ] First paid customer
- [ ] AI-assisted rig setup (Path C): `crucihil discover` → AI generates TOML → confirm-on-first-write
- [ ] `crucihil discover` CLI command

### Phase 3 — Intelligence (Weeks 40–72)
*Goal: AI differentiation, enterprise readiness, $10k MRR*

- [ ] AI failure analysis (failure → root cause suggestion)
- [ ] Test coverage gap detection
- [ ] `generate_test_suite` MCP tool — full YAML suite manifest + Python stub file from a natural language description; grounds generation in real signal names and ranges via `list_signals`
- [ ] Pass/fail trend monitoring via MCP — `get_test_history` + AI produces weekly trend summaries and alerts on regressions
- [ ] AI conversational fallback for rig setup — when hardware probe returns nothing, AI walks the user through declaring interfaces in plain English; no discovery required
- [ ] Anomaly detection on signal traces
- [ ] CANvas MCP integration
- [ ] SOME/IP Methods (request/response)
- [ ] dSPACE adapter (complementary play)
- [ ] NI VeriStand adapter
- [ ] SSO (SAML/OIDC)
- [ ] Audit logs
- [ ] On-premise control plane option
- [ ] Kubernetes Helm chart

---

## 17. Known Gaps and Accepted Debt

These are deliberate deferrals, not oversights. Each has a stated trigger for when to address it.

| Gap | Accepted until | Trigger to address |
|---|---|---|
| Parser loads all frames into memory | Phase 1 | Log file > 500MB |
| No automated DB backup | Phase 2 end | First enterprise customer |
| No DB migration automation | Phase 2 end | First enterprise customer |
| No disaster recovery playbook | Phase 2 end | First enterprise customer |
| ARXML / FIDL definition loading | Phase 3 | Customer with Autosar stack |
| SOME/IP Methods | Phase 2 | Customer needs service RPC |
| LIN / FlexRay support | Phase 3 | Customer request |
| Kubernetes + Helm | Phase 3 | Customer with k8s requirement |
| DoIP gateway routing | Phase 2 | Multi-ECU topology needed |
| Local model option (air-gap) | Phase 3 | Enterprise customer with data policy |
| MCP conversation history | Phase 3 | Usage patterns understood |
| `[rig.udp]` transport section | Phase 1 | AV/robotics customer with proprietary UDP protocol |
| `[rig.uds]` transport section | Phase 1 | Customer needing ISO-TP UDS over CAN outside DoIP |
| `crucihil init` setup wizard | Phase 1 | Onboarding friction report from first design partner |
| JSON Schema for rig TOML + YAML manifest | Phase 1 | Editor integration requested by any user |
