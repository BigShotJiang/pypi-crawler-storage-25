# CruciHiL — Rig Interface Specification

**Version:** 1.0  
**Status:** Authoritative — update this before changing the HAL API  
**Scope:** Phase 0 protocol surface (CAN, SOME/IP Events/Fields, DoIP minimal)  
**Platforms:** Qualcomm SA8775/SA8255, Nvidia Orin/Thor, any Linux-based ECU

---

## Table of Contents

1. [Design Principles](#1-design-principles)
2. [The Rig Object](#2-the-rig-object)
3. [rig.can — CAN Bus Interface](#3-rigcan--can-bus-interface)
4. [rig.sim — Bus Simulation Engine](#4-rigsim--bus-simulation-engine)
5. [rig.someip — SOME/IP Interface](#5-rigsomeip--someip-interface)
6. [rig.doip — DoIP Interface](#6-rigdoip--doip-interface)
7. [rig.ecu — ECU Operations](#7-rigecu--ecu-operations)
8. [rig.power — Power Rail Control](#8-rigpower--power-rail-control)
9. [rig.gpio — Digital I/O](#9-riggpio--digital-io)
10. [rig.fault — Fault Injection](#10-rigfault--fault-injection)
11. [Result Model](#11-result-model)
12. [Exception Hierarchy](#12-exception-hierarchy)
13. [Rig Configuration (TOML)](#13-rig-configuration-toml)
14. [Backend Swap Contract](#14-backend-swap-contract)
15. [Platform Agnosticism](#15-platform-agnosticism)
16. [Complete Example Test](#16-complete-example-test)
17. [Phase 1+ Deferred Items](#17-phase-1-deferred-items)

---

## 1. Design Principles

**P1 — Tests express intent, not implementation**
Test code never contains hardware details. No "SocketCAN", no "vsomeip", no IP addresses. These are rig configuration concerns, not test concerns.

**P2 — Backend swap is one config line**
The same test runs against a virtual simulation backend and a real hardware rig. No test code changes. No conditional logic. The rig TOML declares the backend — tests never interrogate it.

**P3 — Async everywhere**
All rig operations are coroutines. There is no synchronous API surface. Tests are `async def` functions. This is non-negotiable — CAN timing, SOME/IP event cadences, and hardware polling all require async.

**P4 — Hardware identified by role, never by silicon**
An ECU is `ecu_main`, not `SA8775`. Platform differences live in TOML, not test code. The same test suite runs on Qualcomm SA8775 and Nvidia Orin by pointing at a different TOML file.

**P5 — Explicit over silent**
Timeouts raise named exceptions with clear messages. Wrong configuration is caught at rig init, not at test runtime. No operation silently swallows an error.

**P6 — Teardown always runs**
Hardware is always left in a known state. Every context manager's `__aexit__` runs regardless of exceptions. Rig state is never leaked between tests.

**P7 — Faults are descriptors, not coroutines**
`rig.fault.*()` methods return `FaultDescriptor` objects — plain dataclasses. They do not execute anything. `rig.fault.inject()` schedules and activates them. This is load-bearing: passing a coroutine to a context manager would execute it immediately, bypassing the lifecycle management.

---

## 2. The Rig Object

The `Rig` is the single entry point for all hardware interaction. It is injected by the test runner as a fixture. Test functions never construct a `Rig` directly.

```python
async def test_engine_startup(rig: Rig):
    # rig is fully initialised and connected
    # All namespaces below are available
    ...
```

### 2.1 Namespaces

| Namespace | Responsibility |
|---|---|
| `rig.can` | CAN bus send, receive, expect, record |
| `rig.sim` | Bus Simulation Engine — restbus control |
| `rig.someip` | SOME/IP service interaction |
| `rig.doip` | DoIP transport and UDS requests |
| `rig.ecu` | ECU-level operations — flash, reset, DTC |
| `rig.power` | Power rail control and assertion |
| `rig.gpio` | Digital I/O |
| `rig.fault` | Fault injection across all buses |

### 2.2 Lifecycle — managed by the framework

```python
# These are called by the framework. Tests never call them directly.
await rig.connect()     # establish all bus connections per TOML config
await rig.disconnect()  # clean shutdown — always called after test completes
await rig.reset()       # return hardware to known baseline state
```

The framework guarantees: `disconnect()` is called after every test, even if the test raises an exception.

---

## 3. `rig.can` — CAN Bus Interface

### 3.1 Send

```python
# Send a decoded message by name — requires DBC loaded via rig.sim
await rig.can.send(
    message="EngineControl",
    fields={"throttle": 50, "mode": 1},
    interface="can0"    # optional — defaults to primary CAN interface in TOML
)

# Send a raw frame by arbitration ID
await rig.can.send_raw(
    arb_id=0x100,
    data=bytes([0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]),
    interface="can0"
)
```

**Errors:**
- `CANError` if the interface is not connected
- `ConfigurationError` if `message` is not found in loaded DBC

### 3.2 Receive

```python
# Wait for a specific message — returns on first matching frame
msg = await rig.can.receive(
    message="EngineStatus",
    timeout=1.0           # raises CANTimeoutError if not received
)
# msg.fields["rpm"]  -> float
# msg.timestamp      -> float (seconds since test start)
# msg.arb_id         -> int
# msg.raw            -> bytes
# msg.interface      -> str

# Receive a raw frame by arbitration ID
frame = await rig.can.receive_raw(arb_id=0x200, timeout=1.0)
# frame.data         -> bytes
# frame.timestamp    -> float
# frame.arb_id       -> int
```

**Errors:**
- `CANTimeoutError` if timeout expires before message arrives

### 3.3 Expect — condition-based polling

Polls for a signal value to meet a condition. Returns an `ExpectResult` — never raises on condition failure. The caller asserts on `result.passed`.

```python
result = await rig.can.expect(
    signal="EngineRPM",
    condition=lambda v: v > 800,
    timeout=2.0,
    fail_msg="Engine RPM did not reach idle threshold after startup"
)
# result.passed    -> bool
# result.value     -> float (value when condition met, or last value on timeout)
# result.elapsed   -> float (seconds until condition met)
# result.samples   -> list[tuple[float, float]] — (timestamp, value) pairs observed
# result.condition -> str — string representation of condition for logging
# result.fail_msg  -> str | None

assert result.passed, result.fail_msg
```

**Note on condition serialization:** The `condition` parameter is a callable (lambda or function). The `ExpectResult.condition` field stores a string representation (`inspect.getsource` or `repr`) for logging and cloud result storage. The callable itself is never serialized.

**Errors:**
- `CANTimeoutError` if the signal is never observed within timeout
  (distinct from the condition not being met — the signal must be seen at least once)

### 3.4 Assert stable

Asserts a signal holds a condition continuously for a duration. Fails if the condition is violated at any point during the window.

```python
await rig.can.assert_stable(
    signal="BatteryVoltage",
    condition=lambda v: 380 < v < 420,
    duration=5.0,       # condition must hold for this many continuous seconds
    timeout=10.0        # overall time allowed to start and complete
)
```

**Errors:**
- `CANTimeoutError` if the signal is not seen within timeout
- `AssertionError` with `ExpectResult` if condition is violated during the window

### 3.5 Record

```python
async with rig.can.record(interface="can0") as recording:
    await rig.can.send(message="EngineControl", fields={"throttle": 100})
    await asyncio.sleep(3.0)

# After the block (available even if the block raised):
recording.frames    # list[CANFrame]
recording.signals   # dict[str, list[tuple[float, float]]] — signal → [(t, v)]
recording.duration  # float — seconds
await recording.save("test_output/engine_run.asc")   # Vector ASC format
```

The recording context manager always saves its captured data to `recording.frames` and `recording.signals`, even if the enclosed code raises an exception.

### 3.6 Bus load and timing

```python
# Measure bus utilisation over a window
load = await rig.can.measure_load(interface="can0", window=1.0)
# load.utilisation  -> float (0.0 to 1.0)
# load.frame_count  -> int
# load.error_count  -> int

# Measure actual message cycle time across N samples
timing = await rig.can.measure_cycle_time(
    message="EngineData",
    samples=20,
    timeout=5.0
)
# timing.mean_ms    -> float
# timing.min_ms     -> float
# timing.max_ms     -> float
# timing.jitter_ms  -> float — max - min
```

---

## 4. `rig.sim` — Bus Simulation Engine

The BSE simulates the rest of the vehicle network. The ECU under test sees a live bus environment with all peer messages transmitting at their correct cadences. This is the CruciHiL equivalent of dSPACE restbus simulation.

### 4.1 Load definitions

DBC files are parsed using `cantools.database.load_file()` — the canonical cantools API.
Never use `cantools.db.Database().add_dbc_file()`.

```python
# Single file — transport inferred from DBC BA_ attributes
await rig.sim.load("vehicle.dbc")

# Single file with explicit transport config
await rig.sim.load(
    "vehicle_can.dbc",
    transport="can",
    interface="can0"
)

# Multiple files — each with its own config dict
# This is the canonical form. Use this for all new code.
await rig.sim.load([
    ("vehicle_can.dbc", {"transport": "can",      "interface": "can0"}),
    ("vehicle_eth.dbc", {"transport": "ethernet",  "interface": "eth0"}),
])
```

**Transport inference rules (in priority order):**
1. Explicit `transport=` kwarg → use that
2. DBC `BA_ "TRANSPORT"` attribute on message → use declared value
3. Neither → default to `"can"`, emit WARNING for messages with payload > 8 bytes

**Errors:**
- `ConfigurationError` if a DBC file cannot be parsed
- `ConfigurationError` if a declared transport has no corresponding interface in TOML

### 4.2 Start and stop

```python
# Start simulating all messages in loaded definitions
await rig.sim.start()

# Exclude nodes the ECU under test owns — it will transmit these itself
await rig.sim.start(exclude=["EngineControl", "ADAS_BrakeCommand"])

# Stop all simulation
await rig.sim.stop()

# Pause transmission but retain all signal state
await rig.sim.pause()
await rig.sim.resume()
```

### 4.3 Signal control

Signals are identified as `"MessageName.SignalName"`. This works identically for CAN messages and SOME/IP events — the BSE router handles the transport difference transparently.

```python
# Set a single signal value — takes effect on next scheduled transmission
await rig.sim.set_signal("VehicleSpeed.Speed", value=80.0)
await rig.sim.set_signal("SensorFusion.ObjectCount", value=3)

# Set multiple signals atomically — all applied before the next transmission cycle
await rig.sim.set_signals({
    "VehicleSpeed.Speed":    80.0,
    "EngineData.EngineRPM":  3000.0,
    "EngineData.EngineTemp": 90.0,
})

# Read the current simulated value
value = await rig.sim.get_signal("VehicleSpeed.Speed")

# Reset to DBC default
await rig.sim.reset_signal("VehicleSpeed.Speed")
await rig.sim.reset_all()
```

**Errors:**
- `ConfigurationError` if signal name is not found in loaded definitions

### 4.4 Message control

```python
# Stop transmitting a specific message (simulate node failure)
await rig.sim.stop_message("VehicleSpeed")

# Resume transmitting a stopped message
await rig.sim.start_message("VehicleSpeed")

# Change transmission cadence
await rig.sim.set_cadence("EngineData", period_ms=500)

# Reset cadence to DBC-defined value
await rig.sim.reset_cadence("EngineData")

# Inject a single raw frame outside normal scheduling
await rig.sim.inject_raw(
    arb_id=0x100,
    data=bytes([0xFF] * 8),
    interface="can0"
)
```

### 4.5 Scoped overrides

The override context manager saves current values, applies overrides, then **always** restores original values in `__aexit__` — regardless of whether the enclosed code raised an exception.

```python
async with rig.sim.override(signals={
    "VehicleSpeed.Speed":   0.0,
    "EngineData.EngineRPM": 0.0,
}):
    # Inside: Speed and RPM read as 0
    result = await rig.can.expect(
        signal="IdleDetect.Active",
        condition=lambda v: v == 1,
        timeout=0.5
    )
    assert result.passed
# Outside: Speed and RPM are restored to their pre-override values
# This restoration is GUARANTEED even if AssertionError was raised above
```

Implementation contract:
```python
async def __aexit__(self, exc_type, exc_val, exc_tb):
    for signal, original_value in self._saved_values.items():
        await self._store.set_signal(signal, original_value)
    return False  # Never suppress exceptions — always re-raise
```

### 4.6 State inspection

```python
status = await rig.sim.status()
# status.messages -> dict[str, MessageStatus]
# MessageStatus fields: name, active, period_ms, last_tx, tx_count, transport

active = await rig.sim.is_active("VehicleSpeed")
# -> bool
```

---

## 5. `rig.someip` — SOME/IP Interface

Phase 0 covers Events and Fields (publish/subscribe). Methods (request/response RPC) are Phase 1.

### 5.1 Service discovery

```python
# Wait for a service to announce itself via SOME/IP-SD
service = await rig.someip.find_service(
    service_id=0x1111,
    instance_id=0x0001,
    timeout=5.0           # raises SOMEIPTimeoutError if not found
)
# service.service_id   -> int
# service.instance_id  -> int
# service.endpoint     -> tuple[str, int]  (ip, port)
# service.available    -> bool

# Subscribe to an event group
await rig.someip.subscribe(
    service_id=0x1111,
    instance_id=0x0001,
    eventgroup_id=0x0001
)
```

**Errors:**
- `SOMEIPTimeoutError` if service not found within timeout
- `SOMEIPError` if subscription fails

### 5.2 Receive events

```python
# Expect an event meeting a condition
result = await rig.someip.expect(
    service_id=0x1111,
    event_id=0x8001,
    condition=lambda payload: payload["ObjectCount"] > 0,
    timeout=1.0,
    deserializer="SensorFusion.ObjectList"  # signal/type name from definition
)
# result.passed    -> bool
# result.payload   -> dict (deserialized)
# result.raw       -> bytes
# result.elapsed   -> float
# result.condition -> str

# Receive next event unconditionally
event = await rig.someip.receive(
    service_id=0x1111,
    event_id=0x8001,
    timeout=1.0
)
# event.service_id  -> int
# event.event_id    -> int
# event.payload     -> bytes
# event.timestamp   -> float
```

### 5.3 Field interaction

```python
# Read a field value (GET)
value = await rig.someip.get_field(
    service_id=0x1111,
    instance_id=0x0001,
    field_id=0x0001,
    timeout=1.0
)

# Set a field value (SET) — sent to the real service, not via simulation
await rig.someip.set_field(
    service_id=0x1111,
    instance_id=0x0001,
    field_id=0x0001,
    value={"Speed": 80.0}
)
```

### 5.4 SOME/IP simulation via rig.sim

SOME/IP simulated services are controlled through `rig.sim`. The API is identical to CAN — the BSE router determines the transport.

```python
# These work identically whether the signal is CAN or SOME/IP:
await rig.sim.set_signal("SensorFusion.ObjectCount", value=3)
await rig.sim.stop_message("SensorFusion")
await rig.sim.set_cadence("SensorFusion", period_ms=200)
```

---

## 6. `rig.doip` — DoIP Interface

Phase 0: minimal DoIP — routing activation, UDS transport, entity discovery.
Phase 1: DoIP gateway routing, multi-ECU topology.

### 6.1 Session management

DoIP sessions are managed internally by the framework. The `rig.ecu` namespace is the preferred interface for test code — use `rig.doip` directly only for raw UDS access.

```python
# Establish a DoIP session — resolved from rig TOML by ECU name
# Sessions are cached per ECU name within a test run
session = await rig.doip.connect(
    target="ecu_main",    # resolved to logical address via rig TOML
    timeout=5.0
)
# session.logical_address -> int
# session.vin             -> str
# session.connected       -> bool

# Explicit close (framework also closes on rig.disconnect())
await session.close()
```

**Session lifecycle:**
- A new session is created on first `connect()` call per ECU name
- Subsequent `connect()` calls for the same ECU return the cached session
- All sessions are closed in `rig.disconnect()` — tests never need to manage this

### 6.2 UDS over DoIP

```python
# Raw UDS request — use rig.ecu for higher-level operations
response = await rig.doip.uds_request(
    target="ecu_main",
    service_id=0x22,             # ReadDataByIdentifier
    payload=bytes([0xF1, 0x90]), # VIN DID
    timeout=2.0
)
# response.service_id  -> int
# response.payload     -> bytes
# response.positive    -> bool
# response.nrc         -> int | None  (Negative Response Code)

# Read a DID
data = await rig.doip.read_did(target="ecu_main", did=0xF190, timeout=2.0)

# Write a DID
await rig.doip.write_did(
    target="ecu_main",
    did=0x0100,
    data=bytes([0x01]),
    timeout=2.0
)
```

**Errors:**
- `DoIPError` if routing activation fails
- `DoIPNegativeResponseError(nrc=0x22)` if ECU returns negative response
- `CANTimeoutError` if no response within timeout

### 6.3 Entity discovery

```python
entities = await rig.doip.discover(timeout=5.0)
# entities -> list[DoIPEntity]
# DoIPEntity fields: vin, logical_address, eid, gid, ip, port

status = await rig.doip.entity_status(target="ecu_main", timeout=2.0)
# status.node_type                  -> int
# status.max_concurrent_sockets     -> int
# status.currently_open_sockets     -> int
```

---

## 7. `rig.ecu` — ECU Operations

High-level ECU operations built on `rig.doip` and `rig.can`. Test code uses `rig.ecu` — not the underlying transport. Transport is selected from rig TOML.

```python
# Flash firmware — transport (DoIP or CAN isotp) from rig TOML
await rig.ecu.flash(
    target="ecu_main",
    firmware="builds/v2.1.bin",
    timeout=120.0         # flashing is slow — set realistic timeouts
)

# Reset — hard (power cycle via power rail) or soft (UDS 0x11)
await rig.ecu.reset("ecu_main", reset_type="hard")
await rig.ecu.reset("ecu_main", reset_type="soft")

# Read Diagnostic Trouble Codes
dtcs = await rig.ecu.read_dtc("ecu_main")
# dtcs -> list[DTC]
# DTC.code        -> str  (e.g. "U0122")
# DTC.status      -> int
# DTC.description -> str | None

# Clear DTCs
await rig.ecu.clear_dtc("ecu_main")

# Read ECU identification
ident = await rig.ecu.identify("ecu_main")
# ident.vin         -> str
# ident.hw_version  -> str
# ident.sw_version  -> str
# ident.ecu_name    -> str

# Set diagnostic session
await rig.ecu.set_session("ecu_main", session="extended")
# session options: "default" | "extended" | "programming"

# Security access (seed/key exchange)
await rig.ecu.security_access(
    target="ecu_main",
    level=0x01,
    key_fn=my_key_function  # callable(seed: bytes) -> bytes
)
```

**Errors:**
- `FlashError` if firmware flash fails
- `DoIPNegativeResponseError` if ECU rejects a UDS request
- `BlockedError` if ECU cannot be reached (distinct from a failed DTC read)

---

## 8. `rig.power` — Power Rail Control

```python
await rig.power.on("ecu_main")
await rig.power.off("ecu_main")

# Cycle: off for off_duration seconds, then on
await rig.power.cycle("ecu_main", off_duration=1.0)

# Assert voltage within bounds — raises PowerError if out of range
await rig.power.assert_voltage(
    rail="12v_supply",
    min=11.5,
    max=12.5,
    timeout=1.0
)

# Read current voltage
voltage = await rig.power.read_voltage("12v_supply")
# -> float (volts)

# Assert voltage holds within bounds for a continuous duration
await rig.power.assert_stable(
    rail="12v_supply",
    min=11.5,
    max=12.5,
    duration=5.0,
    timeout=10.0
)
```

**Errors:**
- `PowerError` if rail is not in rig TOML config
- `PowerError` if `assert_voltage` or `assert_stable` fails

---

## 9. `rig.gpio` — Digital I/O

```python
await rig.gpio.set("ignition_enable", high=True)
await rig.gpio.set("ignition_enable", high=False)

state = await rig.gpio.read("fault_indicator")
# -> bool

# Wait for pin to reach target state
await rig.gpio.wait_for("fault_indicator", state=True, timeout=2.0)

# Assert pin holds state for a continuous duration
await rig.gpio.assert_stable(
    pin="fault_indicator",
    state=False,
    duration=3.0,
    timeout=5.0
)

# Pulse: set high (or low) for duration, then restore
await rig.gpio.pulse(
    pin="reset_line",
    state=True,
    duration=0.1
)
```

**Errors:**
- `GPIOError` if pin name not in rig TOML config
- `GPIOError` if pin direction mismatch (writing to an input, reading an output)
- `GPIOError` if `wait_for` or `assert_stable` fails

---

## 10. `rig.fault` — Fault Injection

### Critical design note

`rig.fault.*()` methods return `FaultDescriptor` objects — plain dataclasses. They do not execute anything. This is intentional.

```python
# CORRECT: methods return descriptors
descriptor = rig.fault.can_dropout(arb_id=0x100, duration=2.0)
# descriptor is a FaultDescriptor — nothing has happened yet

# CORRECT: inject() activates descriptors
async with rig.fault.inject(descriptor):
    await asyncio.sleep(2.0)
# fault deactivated — always, even on exception

# CORRECT: multiple faults simultaneously
async with rig.fault.inject(
    rig.fault.can_dropout(arb_id=0x100, duration=2.0),
    rig.fault.someip_service_unavailable(service_id=0x1111, duration=2.0)
):
    await asyncio.sleep(2.0)

# CORRECT: immediate one-shot faults use execute()
await rig.fault.execute(rig.fault.can_error_frame(interface="can0"))
```

### CAN fault descriptors

```python
# Stop transmitting for duration seconds
rig.fault.can_dropout(arb_id=0x100, duration=2.0, interface="can0")

# Send corrupted frames for duration seconds
rig.fault.can_corrupt(
    arb_id=0x100,
    duration=1.0,
    strategy="bit_flip"  # "bit_flip" | "random" | "fixed"
)

# Inject a single CAN error frame (use execute(), not inject())
rig.fault.can_error_frame(interface="can0")

# Force bus-off condition for duration seconds
rig.fault.can_bus_off(interface="can0", duration=2.0)
```

### Signal-level fault descriptors (via BSE)

```python
# Freeze a signal at a fixed value for duration seconds
rig.fault.signal_stuck(signal="EngineRPM", value=0.0, duration=3.0)

# Set signal to an out-of-range value for duration seconds
rig.fault.signal_out_of_range(
    signal="BatteryVoltage",
    value=500.0,          # above DBC max
    duration=1.0
)
```

### SOME/IP fault descriptors

```python
# Stop service discovery announcements (service becomes invisible)
rig.fault.someip_service_unavailable(service_id=0x1111, duration=2.0)

# Stop publishing a specific event
rig.fault.someip_event_dropout(
    service_id=0x1111,
    event_id=0x8001,
    duration=1.0
)
```

### Power fault descriptors

```python
rig.fault.voltage_spike(rail="12v_supply", voltage=16.0, duration=0.05)
rig.fault.voltage_drop(rail="12v_supply",  voltage=9.0,  duration=0.1)
```

### inject() context manager — guaranteed cleanup

`inject()` always deactivates all faults in `__aexit__`, regardless of exceptions:

```python
async def __aexit__(self, exc_type, exc_val, exc_tb):
    for descriptor in self._active_faults:
        await self._deactivate(descriptor)
    self._active_faults.clear()
    return False  # Never suppress exceptions
```

---

## 11. Result Model

### ExpectResult

Returned by all `expect()` and `assert_stable()` operations. Never raises on condition failure — the caller asserts.

```python
@dataclass
class ExpectResult:
    passed:     bool
    value:      Any                         # value when condition met, or last seen
    elapsed:    float                       # seconds until condition met
    samples:    list[tuple[float, Any]]     # (timestamp, value) observations
    signal:     str                         # signal name
    condition:  str                         # string repr of condition callable
    fail_msg:   str | None                  # caller-provided failure message
    interface:  str                         # which bus/interface
```

### TestResult

Written to local SQLite and synced to cloud after each test.

```python
@dataclass
class TestResult:
    test_id:      str
    run_id:       str
    suite_name:   str
    status:       Literal["pass", "fail", "blocked", "error", "skip"]
    duration:     float
    started_at:   float
    completed_at: float
    signals:      dict[str, list[tuple[float, float]]]  # recorded signal data
    errors:       list[str]
    logs:         list[str]
    metadata:     dict[str, Any]    # tags, hardware, params from YAML
```

### Status semantics — the blocked/fail distinction is load-bearing

| Status | Meaning | CI/CD behaviour |
|---|---|---|
| `pass` | All assertions passed | ✅ |
| `fail` | An assertion failed — hardware misbehaved | ❌ counts against pass rate |
| `blocked` | Precondition not met — rig or setup issue | ⚠️ does NOT count against pass rate, triggers rig health alert |
| `error` | Framework or infrastructure error | ⚠️ does NOT count against pass rate |
| `skip` | Explicitly skipped — hardware unavailable | — not counted |

**Why this matters:** A flawed rig that causes 10 `blocked` results should not tank a team's pass rate. `blocked` means "the rig is sick". `fail` means "the firmware is sick". These require different responses.

### FaultDescriptor

```python
@dataclass
class FaultDescriptor:
    fault_type:  str
    params:      dict
    started_at:  float | None = None  # set by inject() when activated
    ended_at:    float | None = None  # set by inject() when deactivated
```

---

## 12. Exception Hierarchy

```python
class CruciHiLError(Exception):
    """Base for all CruciHiL exceptions."""

# ── Test execution ─────────────────────────────────────────────
class BlockedError(CruciHiLError):
    """Precondition not met. Rig or setup issue.
    Marks test as 'blocked', not 'fail'. Triggers rig health alert."""

class TestTimeoutError(CruciHiLError):
    """Test exceeded its configured timeout."""

class SetupError(CruciHiLError):
    """Suite or test setup failed. Marks test as blocked."""

class TeardownError(CruciHiLError):
    """Teardown failed. Logged but does not change test status."""

# ── Hardware ───────────────────────────────────────────────────
class HardwareError(CruciHiLError):
    """Base for hardware-related errors."""

class CANError(HardwareError):
    """CAN bus error."""

class CANTimeoutError(CANError):
    """Expected CAN message or signal not received within timeout."""

class SOMEIPError(HardwareError):
    """SOME/IP protocol error."""

class SOMEIPTimeoutError(SOMEIPError):
    """Expected SOME/IP event not received within timeout."""

class DoIPError(HardwareError):
    """DoIP transport error."""

class DoIPNegativeResponseError(DoIPError):
    """ECU returned a UDS negative response."""
    def __init__(self, nrc: int, service_id: int, message: str = ""):
        self.nrc = nrc
        self.service_id = service_id
        super().__init__(
            message or f"NRC 0x{nrc:02X} for service 0x{service_id:02X}"
        )

class PowerError(HardwareError):
    """Power rail error — voltage out of range, rail fault."""

class GPIOError(HardwareError):
    """GPIO error — direction mismatch, unexpected state."""

class FlashError(HardwareError):
    """Firmware flash failed."""

# ── Framework ──────────────────────────────────────────────────
class ConfigurationError(CruciHiLError):
    """Invalid rig TOML, YAML manifest, or missing required config."""

class BackendError(CruciHiLError):
    """Backend not available, failed to connect, or unsupported operation."""
```

---

## 13. Rig Configuration (TOML)

Rigs are declared in TOML. Validated by Pydantic at startup. Tests never read rig config directly — the framework resolves everything.

```toml
# rigs/orin_devkit.toml

[rig]
name        = "Orin_DevKit_01"
platform    = "nvidia_orin"     # informational — never used in test logic
spec_version = "1.0"            # HAL API version this config targets
backend     = "hardware"        # "hardware" | "virtual"

[rig.can.can0]
interface   = "can0"
bitrate     = 500000
fd          = false             # CAN-FD support
backend     = "socketcan"

[rig.can.can1]
interface   = "can1"
bitrate     = 1000000
fd          = true
backend     = "socketcan"

[rig.ethernet.eth0]
interface       = "eth0"
ip              = "192.168.1.10"
someip_backend  = "vsomeip"
doip_backend    = "python-doip"

[rig.power.ecu_main]
backend     = "gpio_relay"
gpio_pin    = 17
default     = "on"

[rig.power.12v_supply]
backend     = "bench_psu"
port        = "/dev/ttyUSB0"
model       = "keysight_e3631a"  # bench_psu backend uses this

[rig.gpio]
ignition_enable = { pin = 22, direction = "out", default = false }
fault_indicator = { pin = 27, direction = "in" }
reset_line      = { pin = 24, direction = "out", default = false }

[rig.ecus.ecu_main]
name            = "ADAS_Main_ECU"
logical_address = 0x0001
transport       = "doip"        # "doip" | "can_isotp"
doip_interface  = "eth0"
power_rail      = "ecu_main"
boot_timeout    = 8.0           # Orin boot is ~8s — in config, not test code

[rig.definitions]
can_dbc  = "defs/vehicle_can.dbc"
eth_dbc  = "defs/vehicle_eth.dbc"
```

**Virtual backend — identical structure, different values:**

```toml
# rigs/virtual.toml

[rig]
name         = "Virtual_Sim"
platform     = "virtual"
spec_version = "1.0"
backend      = "virtual"

[rig.can.can0]
interface = "can0"
bitrate   = 500000
backend   = "virtual"

[rig.ethernet.eth0]
interface      = "eth0"
ip             = "127.0.0.1"
someip_backend = "python-someip"
doip_backend   = "python-doip"

[rig.power.ecu_main]
backend = "virtual_power"
default = "on"

[rig.gpio]
ignition_enable = { pin = 22, direction = "out", default = false, backend = "virtual_gpio" }
fault_indicator = { pin = 27, direction = "in",  backend = "virtual_gpio" }

[rig.ecus.ecu_main]
name            = "Virtual_ECU"
logical_address = 0x0001
transport       = "doip"
doip_interface  = "eth0"
power_rail      = "ecu_main"
boot_timeout    = 0.1           # virtual boots instantly

[rig.definitions]
can_dbc = "defs/vehicle_can.dbc"
eth_dbc = "defs/vehicle_eth.dbc"
```

**CLI selects the rig — tests never know which is active:**

```bash
crucihil run --suite smoke --rig rigs/virtual.toml
crucihil run --suite smoke --rig rigs/orin_devkit.toml
crucihil run --suite smoke --rig rigs/sa8775_testbench.toml
```

---

## 14. Backend Swap Contract

Every backend implements the relevant ABC from `crucihil/hal/backends/base.py`. The full set is defined in `ARCHITECTURE.md`. The Rig HAL never references concrete backend classes — only the ABCs.

```python
# Resolution at startup:
backend_class = resolve_backend(toml_config["rig"]["can"]["can0"]["backend"])
# → SocketCANBackend, VirtualCANBackend, PEAKCANBackend etc.

instance = backend_class()
await instance.connect(interface="can0", bitrate=500000)
# rig.can now wraps this instance — tests never see it
```

Backends are registered in `crucihil/hal/backends/registry.py`. Adding a new hardware adapter requires:
1. Implement the relevant ABC
2. Register in `BACKEND_REGISTRY`
3. Tests require zero changes

---

## 15. Platform Agnosticism

Anything that differs between SoC platforms lives in rig TOML. Nothing platform-specific is in test code.

| Concern | SA8775 | Orin | CruciHiL |
|---|---|---|---|
| CAN interfaces | CAN-FD native / SPI | CAN-FD via Jetson IO | SocketCAN on both — identical |
| Ethernet | 100BASE-T1 | 1000BASE-T1 | Standard socket API — identical |
| Boot time | ~3s | ~8s | `boot_timeout` in TOML, not test |
| Flashing | DoIP or JTAG | DoIP or JTAG | `rig.ecu.flash()` — transport in TOML |
| Diagnostic addressing | Platform-specific | Platform-specific | `logical_address` in TOML |
| Power management | PMIC via I2C | PMIC via I2C | `rig.power` abstraction |

---

## 16. Complete Example Test

A realistic HiL test using CAN, SOME/IP, DoIP, power control, and fault injection. This is what production test code looks like with the full HAL.

```python
import asyncio
import crucihil
from crucihil.hal.rig import Rig
from crucihil.hal.models.exceptions import BlockedError


@crucihil.test(
    tags=["smoke", "regression", "adas"],
    hardware=["ecu_main", "can0", "eth0"],
    timeout=60.0,
    description="ADAS controller detects an object and commands braking. "
                "Verifies fail-safe behaviour during sensor dropout."
)
async def test_adas_emergency_brake(
    rig: Rig,
    expected_brake_pressure: float = 20.0,  # injected from YAML params
    object_distance_m: float = 15.0,
):
    # ── Setup ─────────────────────────────────────────────────────────
    await rig.sim.load([
        ("defs/vehicle_can.dbc", {"transport": "can",      "interface": "can0"}),
        ("defs/vehicle_eth.dbc", {"transport": "ethernet",  "interface": "eth0"}),
    ])

    await rig.power.cycle("ecu_main", off_duration=1.0)
    await rig.sim.start(exclude=["ADAS_BrakeCommand", "ADAS_SteerCommand"])

    # Precondition: ECU must signal ready — if not, this is a rig issue
    ready = await rig.can.expect(
        signal="ADAS_Status.Ready",
        condition=lambda v: v == 1,
        timeout=10.0,
        fail_msg="ADAS ECU did not signal ready within 10s of power-on"
    )
    if not ready.passed:
        raise BlockedError(ready.fail_msg)

    # ── Stimulus ──────────────────────────────────────────────────────
    await rig.sim.set_signals({
        "VehicleSpeed.Speed":     60.0,
        "EngineData.EngineRPM":   2000.0,
        "EngineData.ThrottlePos": 25.0,
    })

    # Simulate sensor fusion detecting an object via SOME/IP event
    await rig.sim.set_signals({
        "SensorFusion.ObjectCount":   1,
        "SensorFusion.ObjectX_0":     object_distance_m,
        "SensorFusion.ObjectY_0":     0.1,
        "SensorFusion.ObjectClass_0": 1,    # vehicle class
    })

    # ── Measurement ───────────────────────────────────────────────────
    brake_result = await rig.can.expect(
        signal="ADAS_BrakeCommand.Pressure",
        condition=lambda v: v > expected_brake_pressure,
        timeout=0.2,
        fail_msg=(
            f"ADAS did not command braking > {expected_brake_pressure} bar "
            f"within 200ms of object detection at {object_distance_m}m"
        )
    )
    assert brake_result.passed, brake_result.fail_msg

    await rig.can.assert_stable(
        signal="ADAS_BrakeCommand.Pressure",
        condition=lambda v: v > expected_brake_pressure,
        duration=1.0,
        timeout=2.0
    )

    # ── Fault injection: sensor dropout during active braking ──────────
    sensor_dropout = rig.fault.someip_event_dropout(
        service_id=0x1111,
        event_id=0x8001
    )

    async with rig.fault.inject(sensor_dropout):
        await asyncio.sleep(0.5)

        # ECU must maintain brake command during sensor dropout (fail-safe)
        safe_result = await rig.can.expect(
            signal="ADAS_BrakeCommand.Pressure",
            condition=lambda v: v > expected_brake_pressure,
            timeout=0.2,
            fail_msg="ADAS released braking during sensor dropout — fail-safe violated"
        )
        assert safe_result.passed, safe_result.fail_msg
    # sensor_dropout deactivated here — always, even if assert above raised

    # ── Verify DTC was logged ─────────────────────────────────────────
    dtcs = await rig.ecu.read_dtc("ecu_main")
    sensor_timeout_dtc_present = any(d.code == "U1234" for d in dtcs)
    assert sensor_timeout_dtc_present, (
        f"Expected sensor timeout DTC U1234 after dropout. "
        f"Got: {[d.code for d in dtcs]}"
    )
```

---

## 17. Phase 1+ Deferred Items

These are not in scope for Phase 0. They are listed here so the architecture is understood to be intentionally incomplete, not accidentally so.

| Item | Target phase |
|---|---|
| SOME/IP Methods (request/response RPC) | Phase 1 |
| DoIP gateway routing | Phase 1 |
| Full YAML manifest parameterization | Phase 1 |
| ARXML / FIDL definition loading | Phase 2/3 |
| LIN bus (LDF-based) | Phase 2/3 |
| FlexRay | Phase 3 |
| Web dashboard API hooks | Phase 2 |
| AI analysis hooks in result model | Phase 3 |
| Local model option (air-gapped) | Phase 3 |
