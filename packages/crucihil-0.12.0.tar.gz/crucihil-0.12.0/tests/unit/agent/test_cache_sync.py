"""Unit tests: ResultCache synced_at column, query_unsynced, mark_synced."""

from __future__ import annotations

import time
import uuid

import pytest
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool

from crucihil.agent.cache.cache import ResultCache, _Base
from crucihil.hal.models.results import TestResult


def _make_result(run_id: str | None = None, test_id: str = "test_foo") -> TestResult:
    now = time.time()
    return TestResult(
        test_id=test_id,
        run_id=run_id or str(uuid.uuid4()),
        suite_name="unit_suite",
        status="pass",
        duration=0.1,
        started_at=now,
        completed_at=now + 0.1,
    )


@pytest.fixture
def cache(tmp_path):
    db = tmp_path / "results.db"
    c = ResultCache.open(db)
    yield c
    c.close()


def test_synced_at_is_null_after_write(cache):
    result = _make_result()
    cache.write(result)

    unsynced = cache.query_unsynced()
    assert len(unsynced) == 1
    row_id, r = unsynced[0]
    assert r.test_id == result.test_id
    assert isinstance(row_id, int)


def test_mark_synced_clears_from_unsynced(cache):
    result = _make_result()
    cache.write(result)

    unsynced = cache.query_unsynced()
    assert len(unsynced) == 1
    row_id, _ = unsynced[0]

    cache.mark_synced([row_id])

    assert cache.query_unsynced() == []


def test_mark_synced_does_not_affect_other_rows(cache):
    r1 = _make_result(test_id="a")
    r2 = _make_result(test_id="b")
    cache.write(r1)
    cache.write(r2)

    unsynced = cache.query_unsynced()
    assert len(unsynced) == 2
    id_a = next(rid for rid, r in unsynced if r.test_id == "a")

    cache.mark_synced([id_a])

    still_unsynced = cache.query_unsynced()
    assert len(still_unsynced) == 1
    assert still_unsynced[0][1].test_id == "b"


def test_mark_synced_empty_list_is_noop(cache):
    cache.write(_make_result())
    cache.mark_synced([])
    assert len(cache.query_unsynced()) == 1


def test_query_unsynced_limit(cache):
    for i in range(5):
        cache.write(_make_result(test_id=f"t{i}"))

    assert len(cache.query_unsynced(limit=3)) == 3
    assert len(cache.query_unsynced(limit=100)) == 5


def test_schema_migration_adds_synced_at_to_existing_db(tmp_path):
    """An existing SQLite DB without synced_at must be migrated transparently."""
    db_path = tmp_path / "old.db"

    # Create DB without synced_at (simulate old schema)
    engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})
    from sqlalchemy import text
    with engine.connect() as conn:
        conn.execute(text(
            "CREATE TABLE test_results ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "test_id TEXT NOT NULL,"
            "run_id TEXT NOT NULL,"
            "suite_name TEXT NOT NULL,"
            "status TEXT NOT NULL,"
            "duration REAL NOT NULL,"
            "started_at REAL NOT NULL,"
            "completed_at REAL NOT NULL,"
            "errors TEXT NOT NULL DEFAULT '[]',"
            "logs TEXT NOT NULL DEFAULT '[]',"
            "signals TEXT NOT NULL DEFAULT '{}',"
            "extra_meta TEXT NOT NULL DEFAULT '{}'"
            ")"
        ))
        conn.commit()
    engine.dispose()

    # Opening via ResultCache must not crash and synced_at must be queryable
    c = ResultCache.open(db_path)
    c.write(_make_result())
    unsynced = c.query_unsynced()
    assert len(unsynced) == 1
    c.close()
