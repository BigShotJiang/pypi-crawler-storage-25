"""Unit tests: flush_unsynced with mocked HTTP."""

from __future__ import annotations

import time
import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from crucihil.agent.cache.sync import flush_unsynced
from crucihil.hal.models.results import TestResult


def _make_result(run_id: str, test_id: str = "test_a") -> TestResult:
    now = time.time()
    return TestResult(
        test_id=test_id,
        run_id=run_id,
        suite_name="suite",
        status="pass",
        duration=0.5,
        started_at=now,
        completed_at=now + 0.5,
    )


def _mock_http(status_code: int = 200, json_body: dict | None = None) -> httpx.AsyncClient:
    """Return an AsyncClient backed by a mock transport that always responds."""
    json_body = json_body or {"inserted": 1, "run_id": "x"}

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, json=json_body)

    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(transport=transport)


@pytest.fixture
def cache(tmp_path):
    from crucihil.agent.cache.cache import ResultCache
    c = ResultCache.open(tmp_path / "results.db")
    yield c
    c.close()


@pytest.mark.asyncio
async def test_flush_empty_cache_returns_zero(cache):
    http = _mock_http()
    result = await flush_unsynced(cache, http, "tok", "http://localhost", "rig-1")
    assert result == 0


@pytest.mark.asyncio
async def test_flush_one_run(cache):
    run_id = str(uuid.uuid4())
    cache.write(_make_result(run_id, "t1"))
    cache.write(_make_result(run_id, "t2"))

    posts: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        posts.append(request)
        return httpx.Response(200, json={"inserted": 2, "run_id": run_id})

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    synced = await flush_unsynced(cache, http, "tok", "http://localhost", "rig-1")

    assert synced == 2
    assert len(posts) == 1  # one POST for one run_id
    assert cache.query_unsynced() == []  # all marked synced


@pytest.mark.asyncio
async def test_flush_groups_by_run_id(cache):
    run_a = str(uuid.uuid4())
    run_b = str(uuid.uuid4())
    cache.write(_make_result(run_a, "a1"))
    cache.write(_make_result(run_b, "b1"))

    posts: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        posts.append(request)
        return httpx.Response(200, json={"inserted": 1, "run_id": "x"})

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    synced = await flush_unsynced(cache, http, "tok", "http://localhost", "rig-1")

    assert synced == 2
    assert len(posts) == 2  # one POST per run_id


@pytest.mark.asyncio
async def test_flush_idempotent_server_do_nothing(cache):
    """Server returns inserted=0 (DO NOTHING) — rows still marked synced."""
    run_id = str(uuid.uuid4())
    cache.write(_make_result(run_id))

    http = _mock_http(200, {"inserted": 0, "run_id": run_id})
    synced = await flush_unsynced(cache, http, "tok", "http://localhost", "rig-1")

    assert synced == 1
    assert cache.query_unsynced() == []


@pytest.mark.asyncio
async def test_flush_skips_failed_run_keeps_others(cache):
    """If one run_id fails to POST, others are still synced."""
    run_ok = str(uuid.uuid4())
    run_fail = str(uuid.uuid4())
    cache.write(_make_result(run_ok, "ok"))
    cache.write(_make_result(run_fail, "fail"))

    call_count = [0]

    def handler(request: httpx.Request) -> httpx.Response:
        import json as _json
        body = _json.loads(request.content)
        call_count[0] += 1
        if body["run_id"] == run_fail:
            return httpx.Response(500, json={"detail": "server error"})
        return httpx.Response(200, json={"inserted": 1, "run_id": run_ok})

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    synced = await flush_unsynced(cache, http, "tok", "http://localhost", "rig-1")

    # Only the successful one is synced
    assert synced == 1
    unsynced = cache.query_unsynced()
    assert len(unsynced) == 1


@pytest.mark.asyncio
async def test_flush_sends_bearer_token(cache):
    run_id = str(uuid.uuid4())
    cache.write(_make_result(run_id))

    seen_headers: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen_headers.append(request.headers.get("Authorization", ""))
        return httpx.Response(200, json={"inserted": 1, "run_id": run_id})

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    await flush_unsynced(cache, http, "my-token-xyz", "http://localhost", "rig-1")

    assert seen_headers == ["Bearer my-token-xyz"]
