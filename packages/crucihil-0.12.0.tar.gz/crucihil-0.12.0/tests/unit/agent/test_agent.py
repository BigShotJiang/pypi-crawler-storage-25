"""Unit tests: LocalAgent — auth, result streaming, local-only mode."""

from __future__ import annotations

import time
import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from crucihil.agent.agent import LocalAgent
from crucihil.agent.cache.cache import ResultCache
from crucihil.hal.config.schema import CloudConfig
from crucihil.hal.models.results import TestResult


def _make_result(run_id: str | None = None) -> TestResult:
    now = time.time()
    return TestResult(
        test_id="test_engine",
        run_id=run_id or str(uuid.uuid4()),
        suite_name="suite",
        status="pass",
        duration=0.1,
        started_at=now,
        completed_at=now + 0.1,
    )


@pytest.fixture
def cache(tmp_path):
    c = ResultCache.open(tmp_path / "results.db")
    yield c
    c.close()


def _make_agent(cache, cloud: CloudConfig | None = None) -> LocalAgent:
    rig = MagicMock()
    rig.config.name = "test-rig"
    rig.config.cloud = cloud
    return LocalAgent(rig=rig, cache=cache, cloud=cloud)


# ── Local-only mode ────────────────────────────────────────────────────────────

def test_local_only_has_no_cloud(cache):
    agent = _make_agent(cache, cloud=None)
    assert agent._cloud is None


def test_local_only_no_token(cache):
    agent = _make_agent(cache, cloud=None)
    assert agent._token is None


# ── on_result: cache write ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_on_result_always_writes_to_cache(cache):
    agent = _make_agent(cache, cloud=None)
    result = _make_result()
    await agent.on_result(result)

    cached = cache.query(limit=10)
    assert len(cached) == 1
    assert cached[0].test_id == result.test_id


@pytest.mark.asyncio
async def test_on_result_skips_ws_when_not_connected(cache):
    agent = _make_agent(cache, cloud=None)
    agent._ws = None  # explicitly no WS
    result = _make_result()
    # Must not raise even though _ws is None
    await agent.on_result(result)
    assert len(cache.query(limit=10)) == 1


@pytest.mark.asyncio
async def test_on_result_sends_via_ws_when_connected(cache):
    cloud = CloudConfig(url="http://localhost:8000", api_key="crucihil-rig-abc")
    agent = _make_agent(cache, cloud=cloud)

    sent: list[str] = []
    mock_ws = AsyncMock()
    mock_ws.send = AsyncMock(side_effect=lambda msg: sent.append(msg))
    agent._ws = mock_ws

    result = _make_result()
    await agent.on_result(result)

    assert len(sent) == 1
    import json
    payload = json.loads(sent[0])
    assert payload["type"] == "result"
    assert payload["run_id"] == result.run_id
    assert payload["result"]["test_id"] == result.test_id


@pytest.mark.asyncio
async def test_on_result_silently_skips_on_ws_error(cache):
    """WS send failure must not propagate — sync flush covers it on reconnect."""
    cloud = CloudConfig(url="http://localhost:8000", api_key="k")
    agent = _make_agent(cache, cloud=cloud)

    mock_ws = AsyncMock()
    mock_ws.send = AsyncMock(side_effect=OSError("connection lost"))
    agent._ws = mock_ws

    result = _make_result()
    await agent.on_result(result)  # must not raise

    # Result is still cached (cache write happens before WS attempt)
    assert len(cache.query_unsynced()) == 1


# ── JWT refresh ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_refresh_token_stores_token_and_expiry(cache):
    cloud = CloudConfig(url="http://localhost:8000", api_key="crucihil-rig-key")
    agent = _make_agent(cache, cloud=cloud)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={
            "access_token": "test.jwt.token",
            "token_type": "bearer",
            "expires_in": 3600,
        })

    agent._http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    before = time.time()
    await agent._refresh_token()

    assert agent._token == "test.jwt.token"
    assert agent._token_expires_at >= before + 3600


@pytest.mark.asyncio
async def test_refresh_token_logs_warning_on_failure(cache):
    cloud = CloudConfig(url="http://localhost:8000", api_key="k")
    agent = _make_agent(cache, cloud=cloud)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "invalid key"})

    agent._http = httpx.AsyncClient(transport=httpx.MockTransport(handler))

    # Must not raise even on 4xx response
    await agent._refresh_token()

    # Token stays None (was not set)
    assert agent._token is None


# ── Heartbeat ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_heartbeat_sends_ping_when_ws_connected(cache):
    cloud = CloudConfig(url="http://localhost:8000", api_key="k")
    agent = _make_agent(cache, cloud=cloud)
    agent._running = True

    sent: list[str] = []
    mock_ws = AsyncMock()
    mock_ws.send = AsyncMock(side_effect=lambda msg: sent.append(msg))
    agent._ws = mock_ws

    # Run one tick of the heartbeat loop without sleeping (patch sleep)
    import asyncio
    import json

    async def _one_tick():
        # Simulate: ws is set, send ping, then stop
        if agent._ws is not None:
            await agent._ws.send(json.dumps({"type": "ping"}))

    await _one_tick()

    assert len(sent) == 1
    assert json.loads(sent[0]) == {"type": "ping"}


@pytest.mark.asyncio
async def test_heartbeat_skips_when_ws_none(cache):
    cloud = CloudConfig(url="http://localhost:8000", api_key="k")
    agent = _make_agent(cache, cloud=cloud)
    agent._ws = None
    agent._running = True

    # Just confirm no exception when ws is None
    if agent._ws is not None:
        await agent._ws.send("{}")  # pragma: no cover
    # No assertion needed — just must not raise
