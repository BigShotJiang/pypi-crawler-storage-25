"""Unit tests: CloudConfig parsing from rig TOML."""

from __future__ import annotations

import pytest

from crucihil.hal.config.schema import CloudConfig, RigConfig


def _base_rig_dict(**extra) -> dict:
    return {
        "name": "test-rig",
        "platform": "virtual",
        "backend": "virtual",
        **extra,
    }


def test_cloud_config_present():
    raw = _base_rig_dict(cloud={"url": "http://localhost:8000", "api_key": "crucihil-rig-abc123"})
    config = RigConfig.model_validate(raw)
    assert config.cloud is not None
    assert config.cloud.url == "http://localhost:8000"
    assert config.cloud.api_key == "crucihil-rig-abc123"


def test_cloud_config_absent_gives_none():
    raw = _base_rig_dict()
    config = RigConfig.model_validate(raw)
    assert config.cloud is None


def test_cloud_config_https_url():
    raw = _base_rig_dict(cloud={"url": "https://cloud.crucihil.io", "api_key": "k"})
    config = RigConfig.model_validate(raw)
    assert config.cloud.url == "https://cloud.crucihil.io"


def test_cloud_config_missing_api_key_allowed():
    # api_key is optional — agent auto-registers via registration_token on first boot
    raw = _base_rig_dict(cloud={"url": "http://localhost:8000"})
    config = RigConfig.model_validate(raw)
    assert config.cloud is not None
    assert config.cloud.api_key == ""


def test_cloud_config_registration_token():
    raw = _base_rig_dict(cloud={"url": "http://localhost:8000", "registration_token": "tok"})
    config = RigConfig.model_validate(raw)
    assert config.cloud.registration_token == "tok"
    assert config.cloud.api_key == ""


def test_cloud_config_missing_url_raises():
    raw = _base_rig_dict(cloud={"api_key": "crucihil-rig-abc"})
    with pytest.raises(Exception):
        RigConfig.model_validate(raw)
