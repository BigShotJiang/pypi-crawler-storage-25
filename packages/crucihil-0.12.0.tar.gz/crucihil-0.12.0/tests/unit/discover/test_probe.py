"""Unit tests for crucihil.discover.probe."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from crucihil.discover.probe import (
    ProbeResult,
    _probe_can,
    _probe_eth,
    _probe_usb,
    probe,
)


# ── ProbeResult helpers ────────────────────────────────────────────────────────

def test_probe_result_is_empty_when_no_hardware():
    r = ProbeResult(platform="Linux x86_64")
    assert r.is_empty()


def test_probe_result_not_empty_with_can():
    r = ProbeResult(platform="Linux x86_64", can_interfaces=["can0"])
    assert not r.is_empty()


def test_probe_result_not_empty_with_usb():
    r = ProbeResult(platform="Linux x86_64", usb_adapters=["PEAK PCAN adapter"])
    assert not r.is_empty()


def test_probe_result_not_empty_with_eth():
    r = ProbeResult(platform="Linux x86_64", eth_interfaces=["eth0"])
    assert not r.is_empty()


def test_probe_result_to_text_no_hardware():
    r = ProbeResult(platform="Linux x86_64")
    text = r.to_text()
    assert "Linux x86_64" in text
    assert "none detected" in text


def test_probe_result_to_text_with_hardware():
    r = ProbeResult(
        platform="Linux aarch64",
        can_interfaces=["can0", "can1"],
        usb_adapters=["PEAK PCAN adapter (use backend=\"peak\")"],
        eth_interfaces=["eth0"],
        python_packages=["python-can"],
    )
    text = r.to_text()
    assert "can0, can1" in text
    assert "PEAK" in text
    assert "eth0" in text
    assert "python-can" in text


# ── _probe_can ─────────────────────────────────────────────────────────────────

def _make_run_result(stdout: str, returncode: int = 0):
    m = MagicMock()
    m.stdout = stdout
    m.returncode = returncode
    return m


@patch("crucihil.discover.probe.subprocess.run")
@patch("crucihil.discover.probe.sys")
def test_probe_can_finds_interfaces(mock_sys, mock_run):
    mock_sys.platform = "linux"
    mock_run.return_value = _make_run_result(
        "3: can0: <NOARP,UP,LOWER_UP> mtu 72 qdisc pfifo_fast state UP mode DEFAULT\n"
        "4: can1@can0: <NOARP,UP,LOWER_UP> mtu 72 qdisc pfifo_fast state UP mode DEFAULT\n"
    )
    result = _probe_can()
    assert result == ["can0", "can1"]


@patch("crucihil.discover.probe.sys")
def test_probe_can_returns_empty_on_non_linux(mock_sys):
    mock_sys.platform = "darwin"
    assert _probe_can() == []


@patch("crucihil.discover.probe.subprocess.run", side_effect=FileNotFoundError)
@patch("crucihil.discover.probe.sys")
def test_probe_can_returns_empty_on_error(mock_sys, mock_run):
    mock_sys.platform = "linux"
    assert _probe_can() == []


# ── _probe_usb ─────────────────────────────────────────────────────────────────

@patch("crucihil.discover.probe.subprocess.run")
def test_probe_usb_detects_peak(mock_run):
    mock_run.return_value = _make_run_result(
        "Bus 001 Device 004: ID 0c72:000d PEAK System PCAN-USB\n"
        "Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub\n"
    )
    result = _probe_usb()
    assert any("PEAK" in a for a in result)


@patch("crucihil.discover.probe.subprocess.run")
def test_probe_usb_no_known_adapters(mock_run):
    mock_run.return_value = _make_run_result(
        "Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub\n"
    )
    assert _probe_usb() == []


@patch("crucihil.discover.probe.subprocess.run", side_effect=FileNotFoundError)
def test_probe_usb_returns_empty_on_error(mock_run):
    assert _probe_usb() == []


# ── _probe_eth ─────────────────────────────────────────────────────────────────

@patch("crucihil.discover.probe.subprocess.run")
@patch("crucihil.discover.probe.sys")
def test_probe_eth_finds_interfaces(mock_sys, mock_run):
    mock_sys.platform = "linux"
    mock_run.return_value = _make_run_result(
        "lo               UNKNOWN        127.0.0.1/8\n"
        "eth0             UP             192.168.1.10/24\n"
        "wlan0            UP             10.0.0.5/24\n"
    )
    result = _probe_eth()
    assert "eth0" in result
    assert "wlan0" in result
    assert "lo" not in result


@patch("crucihil.discover.probe.subprocess.run")
@patch("crucihil.discover.probe.sys")
def test_probe_eth_excludes_veth(mock_sys, mock_run):
    mock_sys.platform = "linux"
    mock_run.return_value = _make_run_result(
        "veth123abc       UP             172.17.0.1\n"
        "eth0             UP             192.168.1.1\n"
    )
    result = _probe_eth()
    assert "eth0" in result
    assert not any(i.startswith("veth") for i in result)


@patch("crucihil.discover.probe.sys")
def test_probe_eth_returns_empty_on_non_linux(mock_sys):
    mock_sys.platform = "darwin"
    assert _probe_eth() == []


# ── probe() integration ────────────────────────────────────────────────────────

@patch("crucihil.discover.probe._probe_can", return_value=["can0"])
@patch("crucihil.discover.probe._probe_usb", return_value=[])
@patch("crucihil.discover.probe._probe_eth", return_value=["eth0"])
@patch("crucihil.discover.probe._probe_packages", return_value=["python-can"])
@patch("crucihil.discover.probe._probe_platform", return_value="Linux x86_64")
def test_probe_assembles_result(mock_plat, mock_pkgs, mock_eth, mock_usb, mock_can):
    result = probe()
    assert result.platform == "Linux x86_64"
    assert result.can_interfaces == ["can0"]
    assert result.eth_interfaces == ["eth0"]
    assert result.python_packages == ["python-can"]
    assert not result.is_empty()
