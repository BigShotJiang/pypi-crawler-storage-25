"""Unit tests for crucihil.discover.ai_client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from crucihil.discover.ai_client import AIClient, detect_provider


# ── detect_provider ────────────────────────────────────────────────────────────

def test_detect_provider_anthropic(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    result = detect_provider()
    assert result == ("anthropic", "sk-ant-test")


def test_detect_provider_openai_fallback(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "sk-oai-test")
    result = detect_provider()
    assert result == ("openai", "sk-oai-test")


def test_detect_provider_none(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    assert detect_provider() is None


def test_detect_provider_anthropic_takes_priority(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-oai-test")
    result = detect_provider()
    assert result is not None
    assert result[0] == "anthropic"


# ── AIClient model defaults ────────────────────────────────────────────────────

def test_ai_client_anthropic_default_model():
    client = AIClient("anthropic", "key")
    assert "claude" in client.model


def test_ai_client_openai_default_model():
    client = AIClient("openai", "key")
    assert "gpt" in client.model


def test_ai_client_custom_model():
    client = AIClient("anthropic", "key", model="claude-haiku-4-5-20251001")
    assert client.model == "claude-haiku-4-5-20251001"


# ── AIClient._call_anthropic ───────────────────────────────────────────────────

def _mock_anthropic_response(text: str) -> MagicMock:
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"content": [{"text": text}]}
    resp.raise_for_status = MagicMock()
    return resp


def _mock_openai_response(text: str) -> MagicMock:
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"choices": [{"message": {"content": text}}]}
    resp.raise_for_status = MagicMock()
    return resp


@patch("crucihil.discover.ai_client.httpx.post")
def test_anthropic_complete_returns_text(mock_post):
    mock_post.return_value = _mock_anthropic_response('[rig]\nname = "bench_01"')
    client = AIClient("anthropic", "sk-ant-key")
    result = client.complete("Generate a rig TOML")
    assert '[rig]' in result
    assert mock_post.called
    call_kwargs = mock_post.call_args
    assert "api.anthropic.com" in call_kwargs[0][0]


@patch("crucihil.discover.ai_client.httpx.post")
def test_anthropic_sends_correct_headers(mock_post):
    mock_post.return_value = _mock_anthropic_response("# toml")
    client = AIClient("anthropic", "my-secret-key")
    client.complete("test")
    headers = mock_post.call_args[1]["headers"]
    assert headers["x-api-key"] == "my-secret-key"
    assert headers["anthropic-version"] == "2023-06-01"


@patch("crucihil.discover.ai_client.httpx.post")
def test_openai_complete_returns_text(mock_post):
    mock_post.return_value = _mock_openai_response('[rig]\nname = "bench_01"')
    client = AIClient("openai", "sk-oai-key")
    result = client.complete("Generate a rig TOML")
    assert '[rig]' in result
    assert "api.openai.com" in mock_post.call_args[0][0]


@patch("crucihil.discover.ai_client.httpx.post")
def test_openai_sends_bearer_auth(mock_post):
    mock_post.return_value = _mock_openai_response("# toml")
    client = AIClient("openai", "my-oai-key")
    client.complete("test")
    headers = mock_post.call_args[1]["headers"]
    assert headers["Authorization"] == "Bearer my-oai-key"


@patch("crucihil.discover.ai_client.httpx.post")
def test_complete_strips_whitespace(mock_post):
    mock_post.return_value = _mock_anthropic_response("  \n[rig]\nname = \"r\"\n  ")
    client = AIClient("anthropic", "key")
    result = client.complete("test")
    assert not result.startswith(" ")
    assert not result.endswith(" ")


@patch("crucihil.discover.ai_client.httpx.post")
def test_http_error_propagates(mock_post):
    import httpx
    mock_post.return_value = MagicMock(
        raise_for_status=MagicMock(side_effect=httpx.HTTPStatusError(
            "401", request=MagicMock(), response=MagicMock(status_code=401)
        ))
    )
    client = AIClient("anthropic", "bad-key")
    with pytest.raises(httpx.HTTPStatusError):
        client.complete("test")


# ── AIClient._call_gemini ──────────────────────────────────────────────────────

def _mock_gemini_response(text: str) -> MagicMock:
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "candidates": [{"content": {"parts": [{"text": text}]}}]
    }
    resp.raise_for_status = MagicMock()
    return resp


@patch("crucihil.discover.ai_client.httpx.post")
def test_gemini_complete_returns_text(mock_post):
    mock_post.return_value = _mock_gemini_response('[rig]\nname = "bench_01"')
    client = AIClient("gemini", "goog-key")
    result = client.complete("Generate a rig TOML")
    assert '[rig]' in result
    assert mock_post.called


@patch("crucihil.discover.ai_client.httpx.post")
def test_gemini_sends_key_as_query_param(mock_post):
    mock_post.return_value = _mock_gemini_response("# toml")
    client = AIClient("gemini", "my-goog-key")
    client.complete("test")
    url = mock_post.call_args[0][0]
    assert "?key=my-goog-key" in url


def test_ai_client_gemini_default_model():
    client = AIClient("gemini", "key")
    assert "gemini" in client.model
