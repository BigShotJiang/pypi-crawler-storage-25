"""Integration-style tests for the 'crucihil discover' CLI command.

Uses typer.testing.CliRunner — no real network calls; AI paths mock httpx.post.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from crucihil.cli.main import app, _strip_fences, _validate_toml

runner = CliRunner()

# Minimal valid TOML that satisfies RigConfig
_VALID_TOML = """\
[rig]
name         = "test_rig"
platform     = "virtual"
spec_version = "1.0"
backend      = "virtual"

[rig.can.can0]
interface = "can0"
bitrate   = 500000
backend   = "virtual"

[rig.definitions]
can_dbc = "defs/vehicle_can.dbc"
"""


# ── --no-ai path ───────────────────────────────────────────────────────────────

def test_no_ai_writes_stub_toml(tmp_path):
    result = runner.invoke(
        app,
        ["discover", "--no-ai", "--describe", "PEAK PCAN USB on can0", "--output-dir", str(tmp_path)],
        input="y\n",
    )
    assert result.exit_code == 0, result.output
    toml_files = list(tmp_path.glob("*.toml"))
    assert toml_files, "Expected a TOML file to be written"
    content = toml_files[0].read_text()
    # Must be parseable TOML
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]
    parsed = tomllib.loads(content)
    assert "rig" in parsed


# ── _validate_toml ─────────────────────────────────────────────────────────────

def test_validate_good_toml_returns_empty():
    errors = _validate_toml(_VALID_TOML)
    assert errors == [], f"Expected no errors, got: {errors}"


def test_validate_missing_rig_section_returns_errors():
    toml_without_rig = "[other_section]\nfoo = 1\n"
    errors = _validate_toml(toml_without_rig)
    assert errors, "Expected validation errors for missing [rig] section"


def test_validate_syntax_error_returns_error():
    bad_toml = "this is not = valid [ toml"
    errors = _validate_toml(bad_toml)
    assert errors, "Expected an error for invalid TOML syntax"
    assert any("syntax" in e.lower() for e in errors), f"Expected 'syntax' in error: {errors}"


# ── _strip_fences ──────────────────────────────────────────────────────────────

def test_strip_fences_removes_backtick_block():
    fenced = "```toml\n[rig]\nname = \"r\"\n```"
    stripped = _strip_fences(fenced)
    assert stripped == '[rig]\nname = "r"'
    assert "```" not in stripped


def test_strip_fences_is_idempotent_on_clean_toml():
    clean = '[rig]\nname = "r"\n'
    stripped = _strip_fences(clean)
    assert stripped == clean.strip()


def test_strip_fences_handles_plain_fence_no_language():
    fenced = "```\n[rig]\nname = \"r\"\n```"
    stripped = _strip_fences(fenced)
    assert "```" not in stripped
    assert "[rig]" in stripped


# ── detect_provider — Gemini ───────────────────────────────────────────────────

def test_gemini_provider_detection(monkeypatch):
    from crucihil.discover.ai_client import detect_provider
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setenv("GOOGLE_API_KEY", "goog-test-key")
    result = detect_provider()
    assert result == ("gemini", "goog-test-key")


def test_anthropic_takes_priority_over_gemini(monkeypatch):
    from crucihil.discover.ai_client import detect_provider
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-key")
    monkeypatch.setenv("GOOGLE_API_KEY", "goog-key")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    result = detect_provider()
    assert result is not None
    assert result[0] == "anthropic"
