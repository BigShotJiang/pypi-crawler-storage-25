"""Unit tests for CruciHiL HAL models.

Tests: results.py, frames.py, exceptions.py, config/schema.py, config/loader.py
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from crucihil.hal.models.exceptions import (
    BackendError,
    BlockedError,
    CANError,
    CANTimeoutError,
    ConfigurationError,
    CruciHiLError,
    DoIPError,
    DoIPNegativeResponseError,
    FlashError,
    GPIOError,
    HardwareError,
    PowerError,
    SOMEIPError,
    SOMEIPTimeoutError,
    SetupError,
    TeardownError,
    TestTimeoutError,
)
from crucihil.hal.models.frames import (
    CANFrame,
    DoIPEntity,
    DoIPEntityStatus,
    DoIPResponse,
    SOMEIPEvent,
    SOMEIPServiceInfo,
)
from crucihil.hal.models.results import (
    BusLoad,
    CycleTiming,
    ExpectResult,
    FaultDescriptor,
    MessageStatus,
    TestResult,
)
from crucihil.hal.config.schema import (
    CANInterfaceConfig,
    ECUConfig,
    EthernetInterfaceConfig,
    GPIOPinConfig,
    PowerRailConfig,
    RigConfig,
)
from crucihil.hal.config.loader import load_rig_config


# ── Exception hierarchy ────────────────────────────────────────────────────────

class TestExceptionHierarchy:
    def test_all_are_crucihil_errors(self):
        for cls in [
            BlockedError, TestTimeoutError, SetupError, TeardownError,
            CANError, CANTimeoutError, SOMEIPError, SOMEIPTimeoutError,
            DoIPError, DoIPNegativeResponseError,
            PowerError, GPIOError, FlashError,
            ConfigurationError, BackendError,
        ]:
            assert issubclass(cls, CruciHiLError), f"{cls} not a CruciHiLError"

    def test_hardware_subtypes(self):
        for cls in [CANError, SOMEIPError, DoIPError, PowerError, GPIOError, FlashError]:
            assert issubclass(cls, HardwareError)

    def test_timeout_subtypes(self):
        assert issubclass(CANTimeoutError, CANError)
        assert issubclass(SOMEIPTimeoutError, SOMEIPError)

    def test_doip_negative_response_attrs(self):
        e = DoIPNegativeResponseError(nrc=0x22, service_id=0x27)
        assert e.nrc == 0x22
        assert e.service_id == 0x27
        assert "0x22" in str(e)
        assert "0x27" in str(e)

    def test_doip_negative_response_custom_message(self):
        e = DoIPNegativeResponseError(nrc=0x31, service_id=0x10, message="custom")
        assert str(e) == "custom"

    def test_blocked_is_not_hardware(self):
        assert not issubclass(BlockedError, HardwareError)

    def test_catchable_as_base(self):
        for cls in [BlockedError, CANTimeoutError, ConfigurationError]:
            with pytest.raises(CruciHiLError):
                raise cls("test msg")


# ── Frame models ───────────────────────────────────────────────────────────────

class TestCANFrame:
    def test_basic_fields(self):
        f = CANFrame(arb_id=0x100, data=b"\x01\x02", timestamp=1.5, interface="can0")
        assert f.arb_id == 0x100
        assert f.data == b"\x01\x02"
        assert f.timestamp == 1.5
        assert f.interface == "can0"
        assert f.frame_idx == 0
        assert f.fields == {}

    def test_raw_alias(self):
        f = CANFrame(arb_id=0x100, data=b"\xff", timestamp=0.0, interface="can0")
        assert f.raw is f.data

    def test_with_decoded_fields(self):
        f = CANFrame(
            arb_id=0x100, data=b"\x00\x01", timestamp=0.0, interface="can0",
            frame_idx=42, fields={"EngineRPM": 800.0}
        )
        assert f.frame_idx == 42
        assert f.fields["EngineRPM"] == 800.0


class TestSOMEIPModels:
    def test_event(self):
        e = SOMEIPEvent(
            service_id=0x1111, event_id=0x8001,
            payload=b"\x00\x03", timestamp=2.0,
        )
        assert e.service_id == 0x1111
        assert e.instance_id == 0       # default
        assert e.eventgroup_id == 0     # default

    def test_service_info(self):
        info = SOMEIPServiceInfo(
            service_id=0x1111, instance_id=0x0001,
            endpoint=("192.168.1.10", 30509), available=True,
        )
        assert info.endpoint[1] == 30509


class TestDoIPModels:
    def test_positive_response(self):
        r = DoIPResponse(service_id=0x62, payload=b"\xF1\x90" + b"VIN123", positive=True)
        assert r.positive
        assert r.nrc is None

    def test_negative_response(self):
        r = DoIPResponse(service_id=0x7F, payload=b"\x22\x22", positive=False, nrc=0x22)
        assert not r.positive
        assert r.nrc == 0x22

    def test_entity(self):
        entity = DoIPEntity(
            vin="1HGBH41JXMN109186",
            logical_address=0x0001,
            eid=b"\x00" * 6,
            gid=b"\xFF" * 6,
            ip="192.168.1.1",
            port=13400,
        )
        assert entity.logical_address == 0x0001

    def test_entity_status(self):
        s = DoIPEntityStatus(node_type=0, max_concurrent_sockets=3, currently_open_sockets=1)
        assert s.max_concurrent_sockets == 3


# ── Result models ──────────────────────────────────────────────────────────────

class TestExpectResult:
    def test_passed(self):
        r = ExpectResult(
            passed=True, value=850.0, elapsed=0.42,
            samples=[(0.1, 800.0), (0.42, 850.0)],
            signal="EngineRPM", condition="lambda v: v > 800",
            fail_msg=None, interface="can0",
        )
        assert r.passed
        assert r.value == 850.0
        assert len(r.samples) == 2

    def test_failed(self):
        r = ExpectResult(
            passed=False, value=700.0, elapsed=2.0,
            samples=[(1.0, 700.0)],
            signal="EngineRPM", condition="lambda v: v > 800",
            fail_msg="Engine did not reach idle RPM", interface="can0",
        )
        assert not r.passed
        assert r.fail_msg == "Engine did not reach idle RPM"


class TestFaultDescriptor:
    def test_is_plain_dataclass(self):
        d = FaultDescriptor(fault_type="can_dropout", params={"arb_id": 0x100, "duration": 2.0})
        assert d.fault_type == "can_dropout"
        assert d.params["arb_id"] == 0x100
        assert d.started_at is None
        assert d.ended_at is None

    def test_not_awaitable(self):
        """FaultDescriptor must never be a coroutine — R4."""
        import inspect
        d = FaultDescriptor(fault_type="can_dropout", params={})
        assert not inspect.isawaitable(d)
        assert not inspect.iscoroutine(d)


class TestTestResult:
    def test_pass_status(self):
        r = TestResult(
            test_id="test_engine_startup",
            run_id="run-001",
            suite_name="smoke",
            status="pass",
            duration=1.23,
            started_at=1700000000.0,
            completed_at=1700000001.23,
        )
        assert r.status == "pass"
        assert r.errors == []
        assert r.logs == []
        assert r.metadata == {}

    def test_blocked_not_fail(self):
        r = TestResult(
            test_id="t", run_id="r", suite_name="s",
            status="blocked", duration=0.0,
            started_at=0.0, completed_at=0.0,
            errors=["ECU did not boot"],
        )
        assert r.status == "blocked"
        assert r.errors == ["ECU did not boot"]

    def test_all_statuses_valid(self):
        for status in ("pass", "fail", "blocked", "error", "skip"):
            r = TestResult(
                test_id="t", run_id="r", suite_name="s",
                status=status, duration=0.0,
                started_at=0.0, completed_at=0.0,
            )
            assert r.status == status


class TestBusLoadAndTiming:
    def test_bus_load(self):
        load = BusLoad(utilisation=0.45, frame_count=900, error_count=0,
                       interface="can0", window=1.0)
        assert load.utilisation == 0.45

    def test_cycle_timing(self):
        t = CycleTiming(message="EngineData", mean_ms=10.1, min_ms=9.8,
                        max_ms=10.4, jitter_ms=0.6, sample_count=20)
        assert t.jitter_ms == pytest.approx(0.6)

    def test_message_status(self):
        s = MessageStatus(name="VehicleSpeed", active=True, period_ms=10.0,
                          last_tx=1700000000.5, tx_count=100, transport="can")
        assert s.active


# ── Config schema ──────────────────────────────────────────────────────────────

class TestConfigSchema:
    def test_can_interface(self):
        c = CANInterfaceConfig(interface="can0", bitrate=500000, backend="virtual")
        assert c.fd is False
        assert c.bitrate == 500000

    def test_can_interface_bad_bitrate(self):
        with pytest.raises(Exception):
            CANInterfaceConfig(interface="can0", bitrate=-1, backend="virtual")

    def test_ethernet_interface(self):
        e = EthernetInterfaceConfig(
            interface="eth0", ip="127.0.0.1",
            someip_backend="python-someip", doip_backend="python-doip",
        )
        assert e.ip == "127.0.0.1"

    def test_power_rail_defaults(self):
        p = PowerRailConfig(backend="virtual_power")
        assert p.default == "off"

    def test_gpio_pin(self):
        g = GPIOPinConfig(pin=22, direction="out", default=True)
        assert g.backend == "virtual_gpio"

    def test_ecu_doip_requires_interface(self):
        with pytest.raises(Exception, match="doip_interface"):
            ECUConfig(
                name="test", logical_address=1,
                transport="doip",
                # missing doip_interface
            )

    def test_rig_config_full(self):
        config = RigConfig(
            name="Virtual_Sim",
            platform="virtual",
            backend="virtual",
            can={"can0": CANInterfaceConfig(interface="can0", bitrate=500000, backend="virtual")},
            ethernet={"eth0": EthernetInterfaceConfig(
                interface="eth0", ip="127.0.0.1",
                someip_backend="python-someip", doip_backend="python-doip",
            )},
            power={"ecu_main": PowerRailConfig(backend="virtual_power", default="on")},
            ecus={"ecu_main": ECUConfig(
                name="Virtual_ECU", logical_address=1,
                transport="doip", doip_interface="eth0",
                power_rail="ecu_main", boot_timeout=0.1,
            )},
        )
        assert config.name == "Virtual_Sim"
        assert "can0" in config.can
        assert config.ecus["ecu_main"].boot_timeout == 0.1

    def test_rig_config_ecu_bad_doip_ref(self):
        """ECU referencing an ethernet interface not in config → ConfigurationError."""
        with pytest.raises(Exception, match="doip_interface"):
            RigConfig(
                name="bad", platform="virtual", backend="virtual",
                ecus={"ecu_main": ECUConfig(
                    name="V", logical_address=1,
                    transport="doip", doip_interface="eth_nonexistent",
                )},
            )


# ── Config loader ──────────────────────────────────────────────────────────────

class TestConfigLoader:
    def test_load_virtual_toml(self):
        """The checked-in rigs/virtual.toml must load and validate cleanly."""
        root = Path(__file__).parent.parent.parent
        config = load_rig_config(root / "rigs" / "virtual.toml")
        assert config.name == "Virtual_Sim"
        assert config.backend == "virtual"
        assert "can0" in config.can
        assert "eth0" in config.ethernet
        assert "ecu_main" in config.ecus
        assert config.ecus["ecu_main"].boot_timeout == pytest.approx(0.1)

    def test_load_missing_file(self):
        with pytest.raises(ConfigurationError, match="not found"):
            load_rig_config("/nonexistent/path/rig.toml")

    def test_load_bad_toml(self, tmp_path):
        bad = tmp_path / "bad.toml"
        bad.write_text("this is not valid [[[toml")
        with pytest.raises(ConfigurationError):
            load_rig_config(bad)

    def test_load_missing_rig_section(self, tmp_path):
        no_rig = tmp_path / "no_rig.toml"
        no_rig.write_text("[other]\nkey = 1\n")
        with pytest.raises(ConfigurationError, match="\\[rig\\]"):
            load_rig_config(no_rig)

    def test_load_invalid_schema(self, tmp_path):
        bad_schema = tmp_path / "bad_schema.toml"
        bad_schema.write_text(textwrap.dedent("""\
            [rig]
            name = "bad"
            platform = "virtual"
            backend = "unknown_backend_value"
        """))
        with pytest.raises(ConfigurationError):
            load_rig_config(bad_schema)
