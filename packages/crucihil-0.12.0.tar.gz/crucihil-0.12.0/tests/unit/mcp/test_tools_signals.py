"""Unit tests for tools/signals.py and tools/suites.py."""

from __future__ import annotations

import pytest

from crucihil.mcp.tools.signals import list_signals
from crucihil.mcp.tools.suites import list_tests

pytestmark = pytest.mark.asyncio


class TestListSignals:
    async def test_real_dbc_file(self):
        result = await list_signals("defs/vehicle_can.dbc")
        assert "error" not in result
        assert result["signal_count"] > 0
        assert result["message_count"] > 0
        assert len(result["signals"]) == result["signal_count"]

        sig = result["signals"][0]
        assert "signal_name" in sig
        assert "message_name" in sig
        assert "message_id" in sig
        assert sig["message_id"].startswith("0x")
        assert "bit_length" in sig
        assert "factor" in sig
        assert "offset" in sig
        assert "unit" in sig
        assert sig["interface"] == "CAN"

    async def test_bad_path(self):
        result = await list_signals("/no/such/file.dbc")
        assert "error" in result
        assert result["dbc_path"] == "/no/such/file.dbc"

    async def test_signal_fields_complete(self):
        result = await list_signals("defs/vehicle_can.dbc")
        required = ["signal_name", "message_name", "message_id", "bit_length",
                    "factor", "offset", "min_val", "max_val", "unit", "interface", "choices"]
        for sig in result["signals"]:
            for field in required:
                assert field in sig, f"Signal missing field: {field}"


class TestListTests:
    async def test_real_suite_file(self):
        result = await list_tests("tests/suites/engine_validation.yaml")
        assert "error" not in result
        assert result["suite_name"] == "engine_validation"
        assert result["test_count"] > 0
        assert result["enabled_count"] <= result["test_count"]

        test = result["tests"][0]
        required = ["id", "name", "enabled", "priority", "tags", "suite_types",
                    "hw_variants", "timeout", "depends_on", "requirements"]
        for field in required:
            assert field in test, f"Test missing field: {field}"

    async def test_bad_path(self):
        result = await list_tests("/no/such/suite.yaml")
        assert "error" in result
        assert "/no/such/suite.yaml" in result["error"] or result.get("suite_path") == "/no/such/suite.yaml"

    async def test_enabled_count_correct(self):
        result = await list_tests("tests/suites/engine_validation.yaml")
        manually_counted = sum(1 for t in result["tests"] if t["enabled"])
        assert result["enabled_count"] == manually_counted
