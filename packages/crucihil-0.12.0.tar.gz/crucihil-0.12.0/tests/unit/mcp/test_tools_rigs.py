"""Unit tests for tools/rigs.py."""

from __future__ import annotations

import time

import httpx
import pytest

from crucihil.mcp.tools.rigs import get_rig_config, list_rigs, register_rig

pytestmark = pytest.mark.asyncio


def _rig_row(name="rig-1", connected=True):
    return {
        "id": "rig-uuid-1",
        "name": name,
        "connected": connected,
        "last_seen_at": time.time(),
        "version": "0.1.0",
        "created_at": time.time() - 3600,
        "extra_meta": {"platform": "virtual"},
    }


class TestListRigs:
    async def test_happy_path(self, mock_client):
        mock_client.list_rigs.return_value = [_rig_row()]
        result = await list_rigs()
        assert len(result) == 1
        assert result[0]["name"] == "rig-1"
        assert result[0]["connected"] is True
        assert "id" in result[0]
        assert "extra_meta" in result[0]

    async def test_empty(self, mock_client):
        mock_client.list_rigs.return_value = []
        result = await list_rigs()
        assert result == []

    async def test_auth_error_returns_error_dict(self, mock_client):
        mock_client.list_rigs.side_effect = httpx.HTTPStatusError(
            "Unauthorized",
            request=httpx.Request("GET", "http://localhost/api/v1/rigs"),
            response=httpx.Response(401, text="Unauthorized"),
        )
        result = await list_rigs()
        assert len(result) == 1
        assert "error" in result[0]
        assert "401" in result[0]["error"]


class TestGetRigConfig:
    async def test_happy_path(self, mock_client):
        mock_client.get_rig.return_value = _rig_row("my-rig")
        result = await get_rig_config("my-rig")
        assert result["rig_name"] == "my-rig"
        assert result["connected"] is True
        assert "rig_id" in result
        assert "hardware_summary" in result

    async def test_not_found(self, mock_client):
        mock_client.get_rig.return_value = None
        result = await get_rig_config("no-such-rig")
        assert result["error"] == "rig not found"
        assert result["rig_name"] == "no-such-rig"

    async def test_api_error(self, mock_client):
        mock_client.get_rig.side_effect = httpx.HTTPStatusError(
            "Server error",
            request=httpx.Request("GET", "http://localhost/api/v1/rigs/x"),
            response=httpx.Response(500, text="Internal Server Error"),
        )
        result = await get_rig_config("x")
        assert "error" in result
        assert "500" in result["error"]


class TestRegisterRig:
    def _registration_response(self, name="bench-01"):
        return {
            "rig": {
                "id": "new-uuid",
                "name": name,
                "role": "admin",
                "created_at": 1234567890.0,
            },
            "api_key": "crucihil-abc123xyz",
        }

    async def test_happy_path_returns_key(self, mock_client):
        mock_client.register_rig.return_value = self._registration_response()
        result = await register_rig("bench-01")
        assert result["rig_name"] == "bench-01"
        assert result["api_key"] == "crucihil-abc123xyz"
        assert result["role"] == "admin"
        assert "rig_id" in result
        assert "next_steps" in result
        assert isinstance(result["next_steps"], list)

    async def test_next_steps_include_key(self, mock_client):
        mock_client.register_rig.return_value = self._registration_response("orin-01")
        result = await register_rig("orin-01")
        steps_text = " ".join(result["next_steps"])
        assert "crucihil-abc123xyz" in steps_text
        assert "crucihil discover" in steps_text or "crucihil init" in steps_text

    async def test_conflict_returns_error(self, mock_client):
        mock_client.register_rig.side_effect = httpx.HTTPStatusError(
            "Conflict",
            request=httpx.Request("POST", "http://localhost/api/v1/rigs"),
            response=httpx.Response(409, json={"detail": "Rig already exists"}),
        )
        result = await register_rig("bench-01")
        assert "error" in result
        assert "409" in result["error"]

    async def test_forbidden_returns_error(self, mock_client):
        mock_client.register_rig.side_effect = httpx.HTTPStatusError(
            "Forbidden",
            request=httpx.Request("POST", "http://localhost/api/v1/rigs"),
            response=httpx.Response(403, text="Admin role required"),
        )
        result = await register_rig("bench-01")
        assert "error" in result
        assert "403" in result["error"]
