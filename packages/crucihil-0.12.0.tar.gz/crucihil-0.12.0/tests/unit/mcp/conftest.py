"""Shared fixtures for MCP unit tests.

Tools are tested by patching the module-level _client in crucihil.mcp.client.
Each test gets an AsyncMock client with configurable return values.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

import crucihil.mcp.client as _client_module


@pytest.fixture
def mock_client(monkeypatch):
    """Replace the global CruciHilClient with an AsyncMock for the duration of the test."""
    client = MagicMock()
    # Make all async methods return coroutines
    client.list_rigs = AsyncMock(return_value=[])
    client.get_rig = AsyncMock(return_value=None)
    client.register_rig = AsyncMock(return_value={})
    client.list_runs = AsyncMock(return_value=[])
    client.get_run = AsyncMock(return_value=None)
    client.create_run = AsyncMock(return_value={})
    client.cancel_run = AsyncMock(return_value={"detail": "cancellation requested"})
    client.list_results = AsyncMock(return_value=[])
    client.get_result_detail = AsyncMock(return_value=None)
    monkeypatch.setattr(_client_module, "_client", client)
    return client
