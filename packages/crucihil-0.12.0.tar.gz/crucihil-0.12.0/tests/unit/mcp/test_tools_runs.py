"""Unit tests for tools/runs.py."""

from __future__ import annotations

import time

import httpx
import pytest

from crucihil.mcp.tools.runs import cancel_run, get_run_summary, list_runs, run_test_suite

pytestmark = pytest.mark.asyncio


def _run_row(run_id="run-1", status="pass", total=4, passed=3, failed=1):
    return {
        "id": run_id,
        "rig_id": "rig-uuid-1",
        "suite_name": "engine_validation.yaml",
        "started_at": time.time() - 60,
        "completed_at": time.time(),
        "status": status,
        "total": total,
        "passed": passed,
        "failed": failed,
        "blocked": 0,
        "errored": 0,
        "skipped": 0,
        "triggered_by": "mcp",
    }


class TestListRuns:
    async def test_happy_path(self, mock_client):
        mock_client.list_runs.return_value = [_run_row()]
        result = await list_runs()
        assert len(result) == 1
        assert result[0]["run_id"] == "run-1"
        assert result[0]["status"] == "pass"
        mock_client.list_runs.assert_called_once_with(rig_name=None, limit=20)

    async def test_rig_name_forwarded(self, mock_client):
        mock_client.list_runs.return_value = []
        await list_runs(rig_name="my-rig", limit=5)
        mock_client.list_runs.assert_called_once_with(rig_name="my-rig", limit=5)

    async def test_api_error(self, mock_client):
        mock_client.list_runs.side_effect = httpx.HTTPStatusError(
            "error",
            request=httpx.Request("GET", "http://localhost/api/v1/runs"),
            response=httpx.Response(401, text="Unauthorized"),
        )
        result = await list_runs()
        assert len(result) == 1
        assert "error" in result[0]


class TestGetRunSummary:
    async def test_happy_path(self, mock_client):
        mock_client.get_run.return_value = _run_row(total=4, passed=3)
        result = await get_run_summary("run-1")
        assert result["run_id"] == "run-1"
        assert result["pass_rate"] == pytest.approx(0.75)
        assert result["duration_s"] is not None
        assert result["duration_s"] > 0

    async def test_zero_total_no_divide_by_zero(self, mock_client):
        mock_client.get_run.return_value = _run_row(total=0, passed=0, failed=0)
        result = await get_run_summary("run-1")
        assert result["pass_rate"] == 0.0

    async def test_not_found(self, mock_client):
        mock_client.get_run.return_value = None
        result = await get_run_summary("no-such-run")
        assert result["error"] == "run not found"
        assert result["run_id"] == "no-such-run"


class TestRunTestSuite:
    async def test_happy_path(self, mock_client):
        mock_client.create_run.return_value = {
            "run_id": "new-run-1",
            "rig_name": "rig-1",
            "suite_name": "tests/suites/engine_validation.yaml",
            "status": "queued",
            "agent_notified": True,
        }
        result = await run_test_suite("rig-1", "tests/suites/engine_validation.yaml")
        assert result["run_id"] == "new-run-1"
        assert result["status"] == "queued"
        mock_client.create_run.assert_called_once_with(
            rig_name="rig-1",
            suite_path="tests/suites/engine_validation.yaml",
            tags=None,
            suite_type=None,
        )

    async def test_tags_and_suite_type_forwarded(self, mock_client):
        mock_client.create_run.return_value = {"run_id": "x", "status": "queued"}
        await run_test_suite("rig-1", "suite.yaml", tags=["smoke"], suite_type="regression")
        mock_client.create_run.assert_called_once_with(
            rig_name="rig-1",
            suite_path="suite.yaml",
            tags=["smoke"],
            suite_type="regression",
        )

    async def test_rig_not_found(self, mock_client):
        mock_client.create_run.side_effect = httpx.HTTPStatusError(
            "Not Found",
            request=httpx.Request("POST", "http://localhost/api/v1/runs"),
            response=httpx.Response(404, json={"detail": "Rig not found"}),
        )
        result = await run_test_suite("no-rig", "suite.yaml")
        assert "error" in result
        assert "404" in result["error"]


class TestCancelRun:
    async def test_happy_path(self, mock_client):
        mock_client.cancel_run.return_value = {"detail": "cancellation requested"}
        result = await cancel_run("run-1")
        assert result["detail"] == "cancellation requested"
        assert result["run_id"] == "run-1"

    async def test_not_found(self, mock_client):
        mock_client.cancel_run.side_effect = httpx.HTTPStatusError(
            "Not Found",
            request=httpx.Request("POST", "http://localhost/api/v1/runs/x/cancel"),
            response=httpx.Response(404, json={"detail": "Run not found"}),
        )
        result = await cancel_run("no-run")
        assert result["error"] == "run not found"
        assert result["run_id"] == "no-run"

    async def test_already_terminal(self, mock_client):
        mock_client.cancel_run.side_effect = httpx.HTTPStatusError(
            "Conflict",
            request=httpx.Request("POST", "http://localhost/api/v1/runs/x/cancel"),
            response=httpx.Response(409, json={"detail": "Run is already in terminal state: pass"}),
        )
        result = await cancel_run("run-done")
        assert "terminal" in result["error"]
        assert result["run_id"] == "run-done"
