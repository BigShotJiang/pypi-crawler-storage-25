"""Unit tests for tools/suites.py — list_tests and generate_test_suite."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from crucihil.mcp.tools.suites import generate_test_suite, list_tests

pytestmark = pytest.mark.asyncio


# ── list_tests ─────────────────────────────────────────────────────────────────

class TestListTests:
    async def test_parses_real_suite(self):
        result = await list_tests("tests/suites/engine_validation.yaml")
        assert result["suite_name"] == "engine_validation"
        assert result["test_count"] > 0
        assert "tests" in result
        assert all("id" in t for t in result["tests"])

    async def test_missing_file_returns_error(self):
        result = await list_tests("does/not/exist.yaml")
        assert "error" in result

    async def test_enabled_count_field(self):
        result = await list_tests("tests/suites/engine_validation.yaml")
        assert "enabled_count" in result
        assert result["enabled_count"] <= result["test_count"]


# ── generate_test_suite ────────────────────────────────────────────────────────

class TestGenerateTestSuite:
    async def test_writes_yaml_and_py(self, tmp_path):
        result = await generate_test_suite(
            suite_name="brake_validation",
            description="Validate brake pressure response",
            output_dir=str(tmp_path),
        )
        assert "error" not in result
        assert Path(result["yaml_path"]).exists()
        assert Path(result["py_path"]).exists()

    async def test_yaml_contains_suite_name(self, tmp_path):
        result = await generate_test_suite(
            suite_name="my_suite",
            description="Test description",
            output_dir=str(tmp_path),
        )
        yaml_text = Path(result["yaml_path"]).read_text()
        assert "my_suite" in yaml_text
        assert "Test description" in yaml_text

    async def test_py_contains_async_function(self, tmp_path):
        result = await generate_test_suite(
            suite_name="signal_check",
            description="Check signal ranges",
            output_dir=str(tmp_path),
        )
        py_text = Path(result["py_path"]).read_text()
        assert "async def test_" in py_text
        assert "rig: Rig" in py_text

    async def test_yaml_module_matches_py_file(self, tmp_path):
        result = await generate_test_suite(
            suite_name="ecu_boot",
            description="ECU boot time",
            output_dir=str(tmp_path),
        )
        yaml_text = Path(result["yaml_path"]).read_text()
        module_path = result["module_path"]
        assert module_path in yaml_text

    async def test_sanitises_suite_name(self, tmp_path):
        result = await generate_test_suite(
            suite_name="My Suite! With Spaces",
            description="Test",
            output_dir=str(tmp_path),
        )
        assert "error" not in result
        assert " " not in result["suite_name"]
        assert "!" not in result["suite_name"]

    async def test_rig_name_appears_in_yaml(self, tmp_path):
        result = await generate_test_suite(
            suite_name="orin_smoke",
            description="Orin smoke tests",
            rig_name="Orin_NX_Bench",
            output_dir=str(tmp_path),
        )
        yaml_text = Path(result["yaml_path"]).read_text()
        assert "Orin_NX_Bench" in yaml_text

    async def test_next_steps_returned(self, tmp_path):
        result = await generate_test_suite(
            suite_name="foo",
            description="bar",
            output_dir=str(tmp_path),
        )
        assert "next_steps" in result
        assert len(result["next_steps"]) > 0

    async def test_content_returned_in_result(self, tmp_path):
        result = await generate_test_suite(
            suite_name="content_check",
            description="Check content returned",
            output_dir=str(tmp_path),
        )
        assert "yaml_content" in result
        assert "py_content" in result
        assert len(result["yaml_content"]) > 0
        assert len(result["py_content"]) > 0

    async def test_unwritable_dir_returns_error(self):
        result = await generate_test_suite(
            suite_name="fail_test",
            description="Should fail",
            output_dir="/proc/crucihil_no_permission",
        )
        assert "error" in result


# ── AI-assisted generation ─────────────────────────────────────────────────────

class TestGenerateTestSuiteAI:
    async def test_generate_context_items_no_key_falls_back(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        result = await generate_test_suite(
            suite_name="sensor_check",
            description="Check sensor health",
            output_dir=str(tmp_path),
            context_items=["camera_front.fps", "gps.latitude"],
        )
        assert "error" not in result
        py_text = Path(result["py_path"]).read_text()
        assert "pass  # TODO: implement" in py_text

    async def test_generate_context_items_with_ai_key_calls_ai(self, tmp_path, monkeypatch):
        from unittest.mock import patch, MagicMock
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

        ai_output = (
            "async def test_engine_rpm(rig: Rig) -> None:\n"
            "    result = await rig.can.expect(signal='EngineData.RPM', condition=lambda v: v > 0, timeout=2.0)\n"
            "    assert result.passed, result.fail_msg\n\n"
            "async def test_brake_pressure(rig: Rig) -> None:\n"
            "    result = await rig.can.expect(signal='BrakePressure.Value', condition=lambda v: v >= 0, timeout=2.0)\n"
            "    assert result.passed, result.fail_msg\n"
        )

        with patch("crucihil.discover.ai_client.httpx.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.raise_for_status = MagicMock()
            mock_resp.json.return_value = {"content": [{"text": ai_output}]}
            mock_post.return_value = mock_resp

            result = await generate_test_suite(
                suite_name="can_check",
                description="Verify CAN signals",
                output_dir=str(tmp_path),
                context_items=["EngineData.RPM", "BrakePressure.Value"],
            )

        assert "error" not in result
        py_text = Path(result["py_path"]).read_text()
        assert "test_engine_rpm" in py_text
        assert "test_brake_pressure" in py_text

    async def test_generate_ai_failure_falls_back_gracefully(self, tmp_path, monkeypatch):
        from unittest.mock import patch
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

        with patch("crucihil.discover.ai_client.httpx.post", side_effect=Exception("network error")):
            result = await generate_test_suite(
                suite_name="fault_check",
                description="Check fault injection",
                output_dir=str(tmp_path),
                context_items=["can_dropout on EngineData"],
            )

        assert "error" not in result
        assert Path(result["py_path"]).exists()
        py_text = Path(result["py_path"]).read_text()
        assert "pass  # TODO: implement" in py_text

    async def test_generate_yaml_entries_match_ai_functions(self, tmp_path, monkeypatch):
        from unittest.mock import patch, MagicMock
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

        ai_output = (
            "async def test_rpm_range(rig: Rig) -> None:\n"
            "    pass\n\n"
            "async def test_speed_range(rig: Rig) -> None:\n"
            "    pass\n"
        )

        with patch("crucihil.discover.ai_client.httpx.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.raise_for_status = MagicMock()
            mock_resp.json.return_value = {"content": [{"text": ai_output}]}
            mock_post.return_value = mock_resp

            result = await generate_test_suite(
                suite_name="signal_range_check",
                description="Signal range validation",
                output_dir=str(tmp_path),
                context_items=["EngineData.RPM", "VehicleSpeed"],
            )

        yaml_text = Path(result["yaml_path"]).read_text()
        assert "test_rpm_range" in yaml_text
        assert "test_speed_range" in yaml_text
        # Both functions should appear as separate YAML test entries
        assert yaml_text.count("function: test_") == 2

    async def test_generate_broad_context_items_accepted(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        result = await generate_test_suite(
            suite_name="multi_sensor_check",
            description="Multi-sensor health check",
            output_dir=str(tmp_path),
            context_items=[
                "camera_front.fps",
                "gps.latitude",
                "power_mode: sleep/active/standby",
                "ECU startup sequence",
            ],
        )
        assert "error" not in result
