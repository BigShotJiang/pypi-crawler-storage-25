"""Unit tests for tools/results.py."""

from __future__ import annotations

import time

import httpx
import pytest

from crucihil.mcp.tools.results import describe_failure, get_results, get_signal_trace

pytestmark = pytest.mark.asyncio


def _result_summary(result_id=1, test_id="engine_startup", status="fail"):
    return {
        "id": result_id,
        "test_id": test_id,
        "run_id": "run-1",
        "suite_name": "engine_validation",
        "status": status,
        "duration": 2.3,
        "started_at": time.time() - 5,
        "completed_at": time.time() - 2,
    }


def _result_detail(result_id=1, test_id="engine_startup", status="fail"):
    base = _result_summary(result_id, test_id, status)
    base.update({
        "errors": [{"type": "AssertionError", "message": "RPM below 800"}],
        "logs": ["Starting engine", "RPM=500 after 2s"],
        "signals": {
            "EngineData.RPM": [{"t": 0.1, "v": 500.0}, {"t": 0.2, "v": 510.0}],
        },
        "extra_meta": {},
    })
    return base


def _run_row(run_id="run-1", status="fail", total=3, passed=2, failed=1):
    return {
        "id": run_id,
        "rig_id": "rig-uuid-1",
        "suite_name": "engine_validation",
        "started_at": time.time() - 30,
        "completed_at": time.time(),
        "status": status,
        "total": total,
        "passed": passed,
        "failed": failed,
        "blocked": 0,
        "errored": 0,
        "skipped": 0,
        "triggered_by": "mcp",
    }


class TestGetResults:
    async def test_happy_path(self, mock_client):
        mock_client.list_results.return_value = [
            _result_summary(1, "test_a", "pass"),
            _result_summary(2, "test_b", "fail"),
        ]
        result = await get_results("run-1")
        assert len(result) == 2
        assert result[0]["test_id"] == "test_a"
        assert result[1]["status"] == "fail"

    async def test_status_filter_forwarded(self, mock_client):
        mock_client.list_results.return_value = []
        await get_results("run-1", status="fail")
        mock_client.list_results.assert_called_once_with(run_id="run-1", status="fail", limit=200)

    async def test_api_error(self, mock_client):
        mock_client.list_results.side_effect = httpx.HTTPStatusError(
            "error",
            request=httpx.Request("GET", "http://localhost/api/v1/results"),
            response=httpx.Response(500, text="error"),
        )
        result = await get_results("run-1")
        assert len(result) == 1
        assert "error" in result[0]


class TestGetSignalTrace:
    async def test_signal_found(self, mock_client):
        mock_client.list_results.return_value = [_result_summary()]
        mock_client.get_result_detail.return_value = _result_detail()
        result = await get_signal_trace("run-1", "EngineData.RPM")
        assert result["found"] is True
        assert len(result["tests"]) == 1
        assert result["tests"][0]["test_id"] == "engine_startup"
        assert len(result["tests"][0]["samples"]) == 2

    async def test_signal_not_found(self, mock_client):
        mock_client.list_results.return_value = [_result_summary()]
        mock_client.get_result_detail.return_value = _result_detail()
        result = await get_signal_trace("run-1", "NoSuchSignal.Value")
        assert result["found"] is False
        assert result["tests"] == []

    async def test_truncation_at_100_samples(self, mock_client):
        big_samples = [{"t": i * 0.01, "v": float(i)} for i in range(150)]
        detail = _result_detail()
        detail["signals"] = {"EngineData.RPM": big_samples}
        mock_client.list_results.return_value = [_result_summary()]
        mock_client.get_result_detail.return_value = detail
        result = await get_signal_trace("run-1", "EngineData.RPM")
        assert result["found"] is True
        assert result["tests"][0]["truncated"] is True
        assert result["tests"][0]["total_samples"] == 150
        assert len(result["tests"][0]["samples"]) == 100
        assert result["note"] is not None

    async def test_api_error_on_list(self, mock_client):
        mock_client.list_results.side_effect = httpx.HTTPStatusError(
            "error",
            request=httpx.Request("GET", "http://localhost/api/v1/results"),
            response=httpx.Response(500, text="error"),
        )
        result = await get_signal_trace("run-1", "EngineData.RPM")
        assert "error" in result


class TestDescribeFailure:
    async def test_happy_path_all_keys_present(self, mock_client):
        mock_client.get_run.return_value = _run_row()
        mock_client.list_results.return_value = [_result_summary()]
        mock_client.get_result_detail.return_value = _result_detail()

        result = await describe_failure("run-1", "engine_startup")

        required_keys = [
            "run_id", "test_id", "suite_name", "rig_id",
            "started_at", "completed_at", "duration_s", "run_started_at",
            "status", "errors", "error_count", "logs", "log_count",
            "captured_signals", "signal_traces", "signal_note",
            "pass_rate_in_run", "run_status", "total_failures_in_run",
        ]
        for key in required_keys:
            assert key in result, f"Missing key: {key}"

        assert result["run_id"] == "run-1"
        assert result["test_id"] == "engine_startup"
        assert result["status"] == "fail"
        assert result["error_count"] == 1
        assert result["log_count"] == 2
        assert "EngineData.RPM" in result["captured_signals"]
        assert result["pass_rate_in_run"] == pytest.approx(2 / 3, abs=0.001)
        assert result["total_failures_in_run"] == 1

    async def test_run_not_found(self, mock_client):
        mock_client.get_run.return_value = None
        result = await describe_failure("no-run", "test_1")
        assert result["error"] == "run not found"

    async def test_test_id_not_in_run(self, mock_client):
        mock_client.get_run.return_value = _run_row()
        mock_client.list_results.return_value = [_result_summary(test_id="other_test")]
        result = await describe_failure("run-1", "missing_test")
        assert result["error"] == "test not found in run"
        assert result["test_id"] == "missing_test"

    async def test_signal_truncation_in_describe(self, mock_client):
        big = [{"t": i * 0.01, "v": float(i)} for i in range(150)]
        detail = _result_detail()
        detail["signals"] = {f"Signal{i}": big for i in range(8)}
        mock_client.get_run.return_value = _run_row()
        mock_client.list_results.return_value = [_result_summary()]
        mock_client.get_result_detail.return_value = detail

        result = await describe_failure("run-1", "engine_startup")
        # Only 5 signals returned
        assert len(result["signal_traces"]) == 5
        # Each truncated to 100 samples
        for trace in result["signal_traces"].values():
            assert len(trace) == 100
        assert result["signal_note"] is not None
        assert "8" in result["signal_note"]  # mentions total signal count

    async def test_duration_computed(self, mock_client):
        mock_client.get_run.return_value = _run_row()
        mock_client.list_results.return_value = [_result_summary()]
        detail = _result_detail()
        detail["started_at"] = 1000.0
        detail["completed_at"] = 1002.5
        mock_client.get_result_detail.return_value = detail

        result = await describe_failure("run-1", "engine_startup")
        assert result["duration_s"] == pytest.approx(2.5)
