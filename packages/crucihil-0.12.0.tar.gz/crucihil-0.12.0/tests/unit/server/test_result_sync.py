"""Unit tests for result_sync service using an in-memory SQLite DB."""

import time
import uuid

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from crucihil.server.models.base import Base
import crucihil.server.models.rig      # noqa: F401 — register ORM models
import crucihil.server.models.run      # noqa: F401
import crucihil.server.models.result   # noqa: F401
from crucihil.server.models.rig import RigRow
from crucihil.server.models.run import TestRunRow
from crucihil.server.models.result import TestResultRow
from crucihil.server.services.result_sync import (
    batch_upsert_results,
    finalize_run,
    recompute_run_counts,
    upsert_run,
)


@pytest.fixture
def db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False)
    with factory() as session:
        # Seed a rig
        rig = RigRow(name="test-rig", api_key_hash="abc", created_at=time.time())
        session.add(rig)
        session.commit()
        session.refresh(rig)
        yield session, rig.id
    engine.dispose()


def _make_result(test_id: str, status: str = "pass") -> dict:
    now = time.time()
    return {
        "test_id": test_id,
        "run_id": "",  # will be overridden by batch_upsert_results
        "suite_name": "test_suite",
        "status": status,
        "duration": 1.0,
        "started_at": now,
        "completed_at": now + 1.0,
        "errors": [],
        "logs": [],
        "signals": {},
        "metadata": {},
    }


def test_upsert_run_creates_row(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    row = upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    session.commit()
    assert row.id == run_id
    assert row.status == "running"


def test_upsert_run_idempotent(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    r1 = upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    r2 = upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    session.commit()
    assert r1.id == r2.id
    count = session.query(TestRunRow).filter_by(id=run_id).count()
    assert count == 1


def test_batch_upsert_inserts(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    results = [_make_result("test_foo"), _make_result("test_bar", "fail")]
    inserted = batch_upsert_results(session, run_id=run_id, results=results)
    session.commit()
    assert inserted == 2


def test_batch_upsert_idempotent(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    results = [_make_result("test_foo")]

    inserted_first = batch_upsert_results(session, run_id=run_id, results=results)
    session.commit()
    inserted_second = batch_upsert_results(session, run_id=run_id, results=results)
    session.commit()

    assert inserted_first == 1
    assert inserted_second == 0  # ON CONFLICT DO NOTHING
    assert session.query(TestResultRow).filter_by(run_id=run_id).count() == 1


def test_recompute_run_counts(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    results = [
        _make_result("t1", "pass"),
        _make_result("t2", "pass"),
        _make_result("t3", "fail"),
        _make_result("t4", "blocked"),
    ]
    batch_upsert_results(session, run_id=run_id, results=results)
    recompute_run_counts(session, run_id)
    session.commit()

    run = session.get(TestRunRow, run_id)
    assert run.total == 4
    assert run.passed == 2
    assert run.failed == 1
    assert run.blocked == 1


def test_finalize_run_pass(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    batch_upsert_results(session, run_id=run_id, results=[_make_result("t1", "pass")])
    finalize_run(session, run_id)
    session.commit()
    run = session.get(TestRunRow, run_id)
    assert run.status == "pass"
    assert run.completed_at is not None


def test_finalize_run_fail(db):
    session, rig_id = db
    run_id = str(uuid.uuid4())
    upsert_run(session, run_id=run_id, rig_id=rig_id, suite_name="s", started_at=time.time())
    batch_upsert_results(session, run_id=run_id, results=[
        _make_result("t1", "pass"),
        _make_result("t2", "fail"),
    ])
    finalize_run(session, run_id)
    session.commit()
    run = session.get(TestRunRow, run_id)
    assert run.status == "fail"
