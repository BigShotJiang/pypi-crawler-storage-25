"""Unit tests for the auth service (key hashing, JWT issue/verify)."""

import time

import pytest
from jose import JWTError

from crucihil.server.services.auth import (
    decode_jwt,
    generate_api_key,
    hash_api_key,
    issue_jwt,
    verify_api_key,
)


def test_api_key_prefix():
    key = generate_api_key()
    assert key.startswith("crucihil-rig-")


def test_api_key_unique():
    assert generate_api_key() != generate_api_key()


def test_hash_is_deterministic():
    key = generate_api_key()
    assert hash_api_key(key) == hash_api_key(key)


def test_verify_correct_key():
    key = generate_api_key()
    stored = hash_api_key(key)
    assert verify_api_key(key, stored) is True


def test_verify_wrong_key():
    key = generate_api_key()
    stored = hash_api_key(key)
    assert verify_api_key("crucihil-rig-wrongkey", stored) is False


def test_jwt_roundtrip():
    data = issue_jwt(rig_name="test-rig", rig_id="abc-123")
    assert data["token_type"] == "bearer"
    assert data["expires_in"] > 0
    payload = decode_jwt(data["access_token"])
    assert payload["sub"] == "test-rig"
    assert payload["rig_id"] == "abc-123"


def test_jwt_expired(monkeypatch):
    import crucihil.server.services.auth as auth_mod
    # Issue a token with exp in the past
    import jose.jwt as _jose_jwt
    import crucihil.server.config as cfg_mod

    settings = cfg_mod.get_settings()
    past = int(time.time()) - 7200
    payload = {"sub": "rig", "rig_id": "x", "iat": past, "exp": past + 1}
    expired_token = _jose_jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)

    with pytest.raises(JWTError):
        decode_jwt(expired_token)


def test_jwt_bad_signature():
    data = issue_jwt(rig_name="rig", rig_id="id")
    tampered = data["access_token"][:-4] + "XXXX"
    with pytest.raises(JWTError):
        decode_jwt(tampered)
