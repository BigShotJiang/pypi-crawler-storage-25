"""Unit tests for the YAML suite manifest loader and schema."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest
import yaml

from crucihil.agent.manifest.loader import load_suite
from crucihil.agent.manifest.schema import (
    FaultSpec,
    SetupStep,
    TestSuite,
)
from crucihil.hal.models.exceptions import ConfigurationError


# ── Helpers ────────────────────────────────────────────────────────────────────

def _write_yaml(tmp_path: Path, content: str) -> Path:
    p = tmp_path / "suite.yaml"
    p.write_text(textwrap.dedent(content))
    return p


# ── Happy path ─────────────────────────────────────────────────────────────────

def test_load_minimal_suite(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: minimal
        tests: []
    """)
    suite = load_suite(p)
    assert suite.suite.name == "minimal"
    assert suite.suite.version == "1.0.0"
    assert suite.tests == []


def test_load_suite_metadata(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: my_suite
          version: "2.3.1"
          description: "Full stack test"
        tests: []
    """)
    suite = load_suite(p)
    assert suite.suite.version == "2.3.1"
    assert suite.suite.description == "Full stack test"


def test_hardware_requirements(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: hw_test
        hardware:
          required: [can0, ecu_main]
          optional: [can1]
        tests: []
    """)
    suite = load_suite(p)
    assert "can0" in suite.hardware.required
    assert "ecu_main" in suite.hardware.required
    assert "can1" in suite.hardware.optional


def test_defaults_inherited(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: defaults_test
        defaults:
          hw_variants: [virtual]
          suite_types: [smoke]
          timeout: 10.0
        tests:
          - id: t1
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    t1 = suite.tests[0]
    assert t1.hw_variants == ["virtual"]
    assert t1.suite_types == ["smoke"]
    assert t1.timeout == 10.0


def test_test_overrides_defaults(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: override_test
        defaults:
          timeout: 30.0
          hw_variants: [virtual]
        tests:
          - id: t1
            timeout: 5.0
            hw_variants: [real_rig]
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    t1 = suite.tests[0]
    assert t1.timeout == 5.0
    assert t1.hw_variants == ["real_rig"]


def test_setup_step_dict_args(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: steps_test
        tests:
          - id: t1
            setup:
              - sim.set: { signal: "EngineData.RPM", value: 1500.0 }
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    step = suite.tests[0].setup[0]
    assert isinstance(step, SetupStep)
    assert step.action == "sim.set"
    assert step.params["signal"] == "EngineData.RPM"
    assert step.params["value"] == 1500.0


def test_setup_step_string_arg(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: steps_test
        tests:
          - id: t1
            setup:
              - sim.start: EngineData
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    step = suite.tests[0].setup[0]
    assert step.action == "sim.start"
    assert step.params == {"target": "EngineData"}


def test_teardown_steps_parsed(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: teardown_test
        tests:
          - id: t1
            setup:
              - sim.start: EngineData
            teardown:
              - sim.stop: EngineData
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    assert len(suite.tests[0].teardown) == 1
    assert suite.tests[0].teardown[0].action == "sim.stop"


def test_fault_spec_parsed(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: fault_test
        tests:
          - id: t1
            faults:
              - can_dropout: { arb_id: 0x200, duration: 1.0 }
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    fault = suite.tests[0].faults[0]
    assert isinstance(fault, FaultSpec)
    assert fault.fault_type == "can_dropout"
    assert fault.params["duration"] == 1.0


def test_record_signals(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: record_test
        tests:
          - id: t1
            record:
              signals: [EngineData.RPM, VehicleSpeed.Speed]
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    assert suite.tests[0].record.signals == ["EngineData.RPM", "VehicleSpeed.Speed"]


def test_params_dict(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: params_test
        tests:
          - id: t1
            module: foo
            function: bar
            params:
              expected_rpm: 800.0
              startup_timeout: 10.0
    """)
    suite = load_suite(p)
    assert suite.tests[0].params["expected_rpm"] == 800.0
    assert suite.tests[0].params["startup_timeout"] == 10.0


def test_depends_on_valid(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: dep_test
        tests:
          - id: t1
            module: foo
            function: bar
          - id: t2
            depends_on: [t1]
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    assert suite.tests[1].depends_on == ["t1"]


def test_disabled_test(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: disabled_test
        tests:
          - id: t1
            enabled: false
            skip_reason: "Blocked on issue-123"
            module: foo
            function: bar
    """)
    suite = load_suite(p)
    assert not suite.tests[0].enabled
    assert suite.tests[0].skip_reason == "Blocked on issue-123"


def test_load_real_suite_yaml() -> None:
    """Smoke test: load the checked-in engine_validation.yaml."""
    suite_path = Path(__file__).parent.parent / "suites" / "engine_validation.yaml"
    suite = load_suite(suite_path)
    assert suite.suite.name == "engine_validation"
    assert len(suite.tests) > 0
    assert any(t.id == "engine_startup" for t in suite.tests)


# ── Error cases ────────────────────────────────────────────────────────────────

def test_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="not found"):
        load_suite(tmp_path / "nonexistent.yaml")


def test_missing_suite_key_raises(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, "tests: []")
    with pytest.raises(ConfigurationError, match="Missing required 'suite' key"):
        load_suite(p)


def test_missing_suite_name_raises(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, "suite:\n  version: '1.0'\ntests: []")
    with pytest.raises(ConfigurationError, match="suite.name"):
        load_suite(p)


def test_missing_test_id_raises(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: bad
        tests:
          - name: "no id here"
            module: foo
            function: bar
    """)
    with pytest.raises(ConfigurationError, match="'id'"):
        load_suite(p)


def test_bad_depends_on_raises(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: bad_dep
        tests:
          - id: t1
            depends_on: [nonexistent]
            module: foo
            function: bar
    """)
    with pytest.raises(ConfigurationError, match="nonexistent"):
        load_suite(p)


def test_invalid_step_format_raises(tmp_path: Path) -> None:
    p = _write_yaml(tmp_path, """
        suite:
          name: bad_step
        tests:
          - id: t1
            setup:
              - this_is_not_a_single_key: foo
                and_this_is_a_second_key: bar
            module: foo
            function: bar
    """)
    with pytest.raises(ConfigurationError, match="single-key"):
        load_suite(p)


def test_bad_yaml_raises(tmp_path: Path) -> None:
    p = tmp_path / "bad.yaml"
    p.write_text("suite:\n  name: bad\n  - invalid: yaml: structure")
    with pytest.raises(ConfigurationError, match="YAML parse error"):
        load_suite(p)
