"""Plain async test functions invoked by the CruciHiL runner.

These are NOT pytest tests — no fixtures, no decorators.
The runner imports them dynamically and calls them as:
    await fn(rig, **params)

They raise AssertionError on failure, BlockedError on precondition failure.
"""

from __future__ import annotations

import asyncio

from crucihil.hal.models.exceptions import BlockedError
from crucihil.hal.rig import Rig


async def test_engine_startup(
    rig: Rig,
    expected_rpm: float = 800.0,
    startup_timeout: float = 2.0,
) -> None:
    """Verify the ECU reaches idle RPM after ignition is enabled."""
    result = await rig.can.expect(
        signal="EngineData.RPM",
        condition=lambda v: v > expected_rpm,
        timeout=startup_timeout,
    )
    assert result.passed, (
        f"ECU did not reach {expected_rpm} RPM within {startup_timeout}s "
        f"(last observed: {result.value})"
    )


async def test_can_heartbeat(rig: Rig, timeout: float = 1.0) -> None:
    """Verify EngineData frames arrive on the bus."""
    result = await rig.can.expect(
        signal="EngineData.RPM",
        condition=lambda v: v >= 0,
        timeout=timeout,
    )
    assert result.passed, f"No EngineData frames received within {timeout}s"


async def test_vehicle_speed_range(
    rig: Rig,
    max_speed: float = 327.0,
    timeout: float = 1.0,
) -> None:
    """Verify vehicle speed signal stays within spec (0–max_speed km/h)."""
    result = await rig.can.expect(
        signal="VehicleSpeed.Speed",
        condition=lambda v: 0.0 <= v <= max_speed,
        timeout=timeout,
    )
    assert result.passed, (
        f"VehicleSpeed.Speed out of range [0, {max_speed}] — got {result.value}"
    )


async def test_always_pass(rig: Rig) -> None:
    """Trivial test that always passes — used for runner lifecycle testing."""
    pass


async def test_always_fail(rig: Rig) -> None:
    """Test that always fails — used to verify runner marks status=fail."""
    assert False, "intentional failure"


async def test_always_blocked(rig: Rig) -> None:
    """Test that always raises BlockedError — used to verify status=blocked."""
    raise BlockedError("intentional blocked — rig precondition not met")


async def test_params_forwarded(rig: Rig, expected_value: float = 1234.0) -> None:
    """Verify that params from YAML are forwarded as kwargs."""
    assert expected_value == 42.0, f"expected_value should be 42.0, got {expected_value}"
