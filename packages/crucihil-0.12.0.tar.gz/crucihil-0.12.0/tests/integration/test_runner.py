"""Integration tests for the CruciHiL runner — full stack.

These tests:
  1. Load tests/suites/engine_validation.yaml
  2. Connect a virtual Rig (no hardware required)
  3. Run the suite via run_suite()
  4. Assert result statuses, errors, and metadata

No hardware required.  This is the Phase 0 end-to-end milestone.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest
import pytest_asyncio

from crucihil.agent.manifest.loader import load_suite
from crucihil.agent.manifest.schema import TestSuite
from crucihil.agent.runner.runner import run_suite
from crucihil.hal.rig import Rig

RIG_TOML = Path(__file__).parent.parent.parent / "rigs" / "virtual.toml"
SUITE_YAML = Path(__file__).parent.parent / "suites" / "engine_validation.yaml"


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def rig():
    r = Rig.from_toml(RIG_TOML)
    await r.connect()
    yield r
    await r.disconnect()


@pytest.fixture
def suite() -> TestSuite:
    return load_suite(SUITE_YAML)


# ── Suite loading ──────────────────────────────────────────────────────────────

def test_suite_loads() -> None:
    s = load_suite(SUITE_YAML)
    assert s.suite.name == "engine_validation"
    assert len(s.tests) >= 1


# ── Full suite run ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_suite_returns_one_result_per_test(suite, rig):
    results = await run_suite(suite, rig)
    assert len(results) == len(suite.tests)


@pytest.mark.asyncio
async def test_engine_startup_passes(suite, rig):
    results = await run_suite(suite, rig)
    by_id = {r.test_id: r for r in results}
    r = by_id["engine_startup"]
    assert r.status == "pass", f"engine_startup failed: {r.errors}"


@pytest.mark.asyncio
async def test_can_heartbeat_passes(suite, rig):
    results = await run_suite(suite, rig)
    by_id = {r.test_id: r for r in results}
    assert by_id["can_heartbeat"].status == "pass"


@pytest.mark.asyncio
async def test_always_pass_passes(suite, rig):
    results = await run_suite(suite, rig)
    by_id = {r.test_id: r for r in results}
    assert by_id["always_pass"].status == "pass"


@pytest.mark.asyncio
async def test_params_forwarded_to_function(suite, rig):
    results = await run_suite(suite, rig)
    by_id = {r.test_id: r for r in results}
    assert by_id["params_forwarded"].status == "pass"


@pytest.mark.asyncio
async def test_disabled_test_is_skipped(suite, rig):
    results = await run_suite(suite, rig)
    by_id = {r.test_id: r for r in results}
    assert by_id["vehicle_speed_disabled"].status == "skip"


@pytest.mark.asyncio
async def test_depends_on_respected_when_dependency_passes(suite, rig):
    """depends_on_startup should run because engine_startup passes."""
    results = await run_suite(suite, rig)
    by_id = {r.test_id: r for r in results}
    assert by_id["depends_on_startup"].status == "pass"


@pytest.mark.asyncio
async def test_depends_on_skips_when_dependency_fails(rig):
    """If engine_startup fails, depends_on_startup should be skipped."""
    raw = textwrap.dedent("""
        suite:
          name: dep_test
        tests:
          - id: failing_parent
            module: tests.suites.engine_functions
            function: test_always_fail
          - id: dependent_child
            depends_on: [failing_parent]
            module: tests.suites.engine_functions
            function: test_always_pass
    """)
    from pathlib import Path
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        by_id = {r.test_id: r for r in results}
        assert by_id["failing_parent"].status == "fail"
        assert by_id["dependent_child"].status == "skip"
    finally:
        tmp.unlink()


# ── Filtering ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_suite_type_filter(suite, rig):
    """Only smoke-tagged tests run when --suite-type smoke."""
    results = await run_suite(suite, rig, filter_suite_types={"smoke"})
    by_id = {r.test_id: r for r in results}
    # regression-only tests should be skipped
    r = by_id.get("params_forwarded")
    assert r is not None and r.status == "skip", (
        "params_forwarded (regression-only) should be skipped when filtering to smoke"
    )
    # smoke tests should run
    assert by_id["can_heartbeat"].status == "pass"


@pytest.mark.asyncio
async def test_tag_filter(suite, rig):
    """Only tests with matching tags run when --tags is set."""
    results = await run_suite(suite, rig, filter_tags={"smoke"})
    by_id = {r.test_id: r for r in results}
    # always_pass has tag 'smoke'
    assert by_id["always_pass"].status == "pass"
    # engine_startup has tags [engine, startup] — not smoke → skipped
    assert by_id["engine_startup"].status == "skip"


@pytest.mark.asyncio
async def test_hw_variant_filter(rig):
    """Tests with non-matching hw_variants are skipped."""
    raw = textwrap.dedent("""
        suite:
          name: variant_test
        tests:
          - id: right_variant
            hw_variants: [Virtual_Sim]
            module: tests.suites.engine_functions
            function: test_always_pass
          - id: wrong_variant
            hw_variants: [orin_real_hw]
            module: tests.suites.engine_functions
            function: test_always_pass
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        by_id = {r.test_id: r for r in results}
        assert by_id["right_variant"].status == "pass"
        assert by_id["wrong_variant"].status == "skip"
    finally:
        tmp.unlink()


# ── Status semantics ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_assertion_error_becomes_fail(rig):
    raw = textwrap.dedent("""
        suite:
          name: fail_test
        tests:
          - id: t1
            module: tests.suites.engine_functions
            function: test_always_fail
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        assert results[0].status == "fail"
        assert results[0].errors  # error message present
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_blocked_error_becomes_blocked(rig):
    raw = textwrap.dedent("""
        suite:
          name: blocked_test
        tests:
          - id: t1
            module: tests.suites.engine_functions
            function: test_always_blocked
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        assert results[0].status == "blocked"
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_timeout_becomes_fail(rig):
    raw = textwrap.dedent("""
        suite:
          name: timeout_test
        tests:
          - id: t1
            timeout: 0.05
            module: tests.suites.engine_functions
            function: test_engine_startup
            params:
              expected_rpm: 99999.0
              startup_timeout: 10.0
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        assert results[0].status == "fail"
        assert "Timed out" in results[0].errors[0]
    finally:
        tmp.unlink()


# ── Setup / teardown declarative steps ────────────────────────────────────────

@pytest.mark.asyncio
async def test_setup_steps_executed(rig):
    """Setup sets RPM=1500; test asserts RPM > 800 — should pass."""
    raw = textwrap.dedent("""
        suite:
          name: setup_test
        definitions:
          can_dbc: "defs/vehicle_can.dbc"
        tests:
          - id: t1
            setup:
              - sim.set:   { signal: "EngineData.RPM", value: 1500.0 }
              - sim.start: EngineData
            teardown:
              - sim.stop: EngineData
            module: tests.suites.engine_functions
            function: test_engine_startup
            params:
              expected_rpm: 800.0
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        assert results[0].status == "pass", results[0].errors
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_teardown_runs_even_after_fail(rig):
    """Teardown must run even if the test function raises (R8)."""
    from crucihil.hal.bse.engine import BusSimEngine

    raw = textwrap.dedent("""
        suite:
          name: teardown_test
        definitions:
          can_dbc: "defs/vehicle_can.dbc"
        tests:
          - id: t1
            setup:
              - sim.start: EngineData
            teardown:
              - sim.stop: EngineData
            module: tests.suites.engine_functions
            function: test_always_fail
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp = Path(f.name)
    try:
        suite = load_suite(tmp)
        results = await run_suite(suite, rig)
        assert results[0].status == "fail"
        # If teardown ran, no scheduler should still be running EngineData
        active = [
            msg
            for sched in rig._bse._schedulers.values()
            for msg in sched.active_messages()
        ]
        assert "EngineData" not in active, (
            "teardown should have stopped EngineData — R8 violated"
        )
    finally:
        tmp.unlink()


# ── JUnit XML reporter ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_junit_xml_written(suite, rig, tmp_path):
    from crucihil.agent.reporter.junit import write_junit_xml
    results = await run_suite(suite, rig)
    out = tmp_path / "results.xml"
    write_junit_xml(results, suite, out)
    assert out.exists()
    content = out.read_text()
    assert "<testsuite" in content
    assert "engine_validation" in content
    assert "<testcase" in content


@pytest.mark.asyncio
async def test_junit_xml_failure_element(rig, tmp_path):
    from crucihil.agent.reporter.junit import write_junit_xml
    raw = textwrap.dedent("""
        suite:
          name: fail_suite
        tests:
          - id: t1
            module: tests.suites.engine_functions
            function: test_always_fail
    """)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
        f.write(raw)
        tmp_yaml = Path(f.name)
    try:
        suite = load_suite(tmp_yaml)
        results = await run_suite(suite, rig)
        out = tmp_path / "fail.xml"
        write_junit_xml(results, suite, out)
        content = out.read_text()
        assert "<failure" in content
    finally:
        tmp_yaml.unlink()
