"""Integration tests — virtual rig end-to-end.

These tests exercise the full stack:
  virtual TOML → Rig → backends → BSE → namespaces → test assertions

No hardware required.  This is the Phase 0 "one test running end-to-end"
milestone.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
import pytest_asyncio

from crucihil.hal.rig import Rig
from crucihil.hal.models.exceptions import BlockedError, CANTimeoutError

# Path to the shared virtual rig config
RIG_TOML = Path(__file__).parent.parent.parent / "rigs" / "virtual.toml"


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def rig():
    """Connected virtual Rig, torn down after each test."""
    r = Rig.from_toml(RIG_TOML)
    await r.connect()
    yield r
    await r.disconnect()


# ── Rig lifecycle ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rig_connects_and_disconnects():
    """Rig connects without error and disconnects cleanly."""
    async with Rig.from_toml(RIG_TOML) as r:
        assert r._connected
    assert not r._connected


@pytest.mark.asyncio
async def test_rig_exposes_namespaces(rig: Rig):
    """After connect(), rig.can, rig.sim and rig.fault are available."""
    assert hasattr(rig, "can")
    assert hasattr(rig, "sim")
    assert hasattr(rig, "fault")


# ── Config load ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_config_loaded(rig: Rig):
    """RigConfig is populated from virtual.toml."""
    assert rig.config.name == "Virtual_Sim"
    assert "can0" in rig.config.can
    assert "eth0" in rig.config.ethernet
    assert "ecu_main" in rig.config.power
    assert "ecu_main" in rig.config.ecus


# ── DBC / Signal Store ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_dbc_loaded(rig: Rig):
    """BSE loads vehicle_can.dbc and populates the signal store."""
    store = rig._bse.signal_store
    # All four DBC messages should have signals registered
    for signal in [
        "EngineData.RPM",
        "EngineData.CoolantTemp",
        "VehicleSpeed.Speed",
        "BrakeStatus.BrakePressure",
    ]:
        val = store.get(signal)   # raises KeyError if not registered
        assert val == 0.0 or val == pytest.approx(val)  # initial value is numeric


@pytest.mark.asyncio
async def test_signal_store_set_get(rig: Rig):
    """rig.sim.set() updates the signal store, readable back."""
    await rig.sim.set("VehicleSpeed.Speed", 100.0)
    val = rig._bse.signal_store.get("VehicleSpeed.Speed")
    assert val == pytest.approx(100.0)


# ── sim.override context manager ──────────────────────────────────────────────

@pytest.mark.asyncio
async def test_sim_override_restores(rig: Rig):
    """sim.override() restores the original value on exit — even on exception."""
    await rig.sim.set("EngineData.RPM", 800.0)

    with pytest.raises(RuntimeError):
        async with rig.sim.override("EngineData.RPM", 0.0):
            assert rig._bse.signal_store.get("EngineData.RPM") == pytest.approx(0.0)
            raise RuntimeError("simulated failure")

    # Must be restored even though the body raised
    assert rig._bse.signal_store.get("EngineData.RPM") == pytest.approx(800.0)


# ── CAN send / receive loopback ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_can_send_raw_loopback(rig: Rig):
    """Raw frames sent via VirtualCANBackend are delivered to listeners."""
    received = []

    async def listener(frame):
        received.append(frame)

    backend = rig._can_backends["can0"]
    backend.add_listener(listener)

    await rig.can.send_raw(arb_id=0x100, data=b"\x01\x02\x03")
    await asyncio.sleep(0)      # give create_task() a chance to run
    await asyncio.sleep(0)

    backend.remove_listener(listener)
    assert len(received) >= 1
    assert received[0].arb_id == 0x100
    assert received[0].data == b"\x01\x02\x03"


@pytest.mark.asyncio
async def test_can_send_by_name(rig: Rig):
    """rig.can.send() encodes a DBC message and delivers it."""
    received = []

    async def listener(frame):
        received.append(frame)

    backend = rig._can_backends["can0"]
    backend.add_listener(listener)

    await rig.can.send(
        message="EngineControl",
        fields={"Throttle": 50.0, "Mode": 2.0},
    )
    await asyncio.sleep(0)
    await asyncio.sleep(0)

    backend.remove_listener(listener)
    assert any(f.arb_id == 256 for f in received)


@pytest.mark.asyncio
async def test_can_receive(rig: Rig):
    """rig.can.receive() waits for a specific frame and returns it."""
    async def sender():
        await asyncio.sleep(0.02)
        await rig.can.send_raw(arb_id=0x200, data=b"\xFF\x00")

    asyncio.create_task(sender())
    frame = await rig.can.receive(arb_id=0x200, timeout=1.0)
    assert frame.arb_id == 0x200
    assert frame.data == b"\xFF\x00"


@pytest.mark.asyncio
async def test_can_receive_timeout(rig: Rig):
    """rig.can.receive() raises CANTimeoutError when no frame arrives."""
    with pytest.raises(CANTimeoutError):
        await rig.can.receive(arb_id=0xDEAD, timeout=0.05)


# ── rig.can.expect via BSE scheduler ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_bse_scheduler_and_expect():
    """BSE scheduler transmits a message periodically; expect() detects it."""
    async with Rig.from_toml(RIG_TOML) as rig:
        # Set RPM to a known value and start the scheduler
        await rig.sim.set("EngineData.RPM", 1500.0)
        rig.sim.start("EngineData")

        # expect() polls the signal store — the scheduler updates it via loopback
        result = await rig.can.expect(
            signal="EngineData.RPM",
            condition=lambda v: v > 1000.0,
            timeout=1.0,
        )
        assert result.passed, result.fail_msg


@pytest.mark.asyncio
async def test_bse_expect_fails_on_wrong_value(rig: Rig):
    """expect() returns passed=False when condition is never satisfied."""
    await rig.sim.set("VehicleSpeed.Speed", 50.0)

    result = await rig.can.expect(
        signal="VehicleSpeed.Speed",
        condition=lambda v: v > 200.0,
        timeout=0.05,
        fail_msg="Speed should exceed 200 km/h",
    )
    assert not result.passed
    assert result.fail_msg == "Speed should exceed 200 km/h"


# ── Fault injection ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_fault_descriptor_not_coroutine():
    """FaultDescriptor is a plain dataclass — never a coroutine (R4)."""
    import inspect
    async with Rig.from_toml(RIG_TOML) as rig:
        d = rig.fault.can_dropout(arb_id=0x100, duration=2.0)
        assert not inspect.isawaitable(d)
        assert d.fault_type == "can_dropout"
        assert d.started_at is None


@pytest.mark.asyncio
async def test_fault_inject_sets_timestamps(rig: Rig):
    """inject() sets started_at and ended_at on the descriptor."""
    d = rig.fault.power_cycle(rail="ecu_main", off_duration=0.01)
    async with rig.fault.inject(d):
        assert d.started_at is not None
        assert d.ended_at is None
    assert d.ended_at is not None
    assert d.ended_at >= d.started_at


@pytest.mark.asyncio
async def test_fault_inject_restores_on_exception(rig: Rig):
    """inject()'s __aexit__ runs even when the body raises (R8)."""
    d = rig.fault.power_cycle(rail="ecu_main", off_duration=0.01)
    with pytest.raises(RuntimeError):
        async with rig.fault.inject(d):
            raise RuntimeError("test error")
    # ended_at must be set even though the body raised
    assert d.ended_at is not None


# ── Power backend ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_power_default_on(rig: Rig):
    """ecu_main power rail starts ON per virtual.toml config."""
    backend = rig._power_backends["ecu_main"]
    assert backend.is_on
    voltage = await backend.read_voltage()
    assert voltage == pytest.approx(12.0)


@pytest.mark.asyncio
async def test_power_off_on(rig: Rig):
    """Power rail can be turned off and on."""
    backend = rig._power_backends["ecu_main"]
    await backend.off()
    assert not backend.is_on
    assert await backend.read_voltage() == pytest.approx(0.0)
    await backend.on()
    assert backend.is_on
    assert await backend.read_voltage() == pytest.approx(12.0)


# ── GPIO backend ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_gpio_output_set(rig: Rig):
    """ignition_enable (direction=out) can be driven high/low."""
    gpio = list(rig._gpio_backends.values())[0]
    await gpio.set("ignition_enable", True)
    assert await gpio.read("ignition_enable") is True
    await gpio.set("ignition_enable", False)
    assert await gpio.read("ignition_enable") is False


@pytest.mark.asyncio
async def test_gpio_input_read(rig: Rig):
    """fault_indicator (direction=in) can be driven externally."""
    gpio = list(rig._gpio_backends.values())[0]
    gpio.drive_input("fault_indicator", True)
    assert await gpio.read("fault_indicator") is True
