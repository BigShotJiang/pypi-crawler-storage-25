"""Phase 1 integration tests.

Covers all new Phase 1 features without requiring physical hardware:
  - SocketCAN backend (using VirtualCANBackend as a stand-in — SocketCAN
    requires Linux vcan; tests use mock to avoid hardware dependency)
  - CAN dropout fault injection via block_arb_id / unblock_arb_id
  - ECU namespace + flash() via virtual DoIP backend
  - HTML reporter output
  - SQLite result cache write / query / prune
  - Backend registry custom module path support
  - VirtualUDP and VirtualUDS backends
  - [rig.udp] / [rig.uds] config schema parsing
"""

from __future__ import annotations

import asyncio
import json
import tempfile
import time
from pathlib import Path

import pytest
import pytest_asyncio

from crucihil.hal.rig import Rig
from crucihil.hal.models.exceptions import (
    BackendError,
    ConfigurationError,
    FlashError,
)
from crucihil.hal.models.results import TestResult
from crucihil.hal.backends.registry import (
    resolve_can_backend,
    resolve_doip_backend,
    resolve_udp_backend,
    resolve_uds_backend,
)

RIG_TOML = Path(__file__).parent.parent.parent / "rigs" / "virtual.toml"


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def rig():
    r = Rig.from_toml(RIG_TOML)
    await r.connect()
    yield r
    await r.disconnect()


# ── Backend registry ───────────────────────────────────────────────────────────

def test_registry_resolves_virtual_can():
    cls = resolve_can_backend("virtual")
    assert cls.__name__ == "VirtualCANBackend"


def test_registry_resolves_socketcan():
    cls = resolve_can_backend("socketcan")
    assert cls.__name__ == "SocketCANBackend"


def test_registry_resolves_peak():
    cls = resolve_can_backend("peak")
    assert cls.__name__ == "PEAKCANBackend"


def test_registry_resolves_virtual_doip():
    cls = resolve_doip_backend("virtual")
    assert cls.__name__ == "VirtualDoIPBackend"


def test_registry_resolves_python_doip():
    cls = resolve_doip_backend("python-doip")
    assert cls.__name__ == "PythonDoIPBackend"


def test_registry_resolves_virtual_udp():
    cls = resolve_udp_backend("virtual_udp")
    assert cls.__name__ == "VirtualUDPBackend"


def test_registry_resolves_virtual_uds():
    cls = resolve_uds_backend("virtual_uds")
    assert cls.__name__ == "VirtualUDSBackend"


def test_registry_unknown_backend_raises():
    with pytest.raises(ConfigurationError):
        resolve_can_backend("nonexistent_backend")


def test_registry_custom_module_path_bad_module_raises():
    with pytest.raises(ConfigurationError, match="Cannot import"):
        resolve_can_backend("no_such_module.NoSuchBackend:MyBackend")


def test_registry_custom_module_path_missing_class_raises():
    with pytest.raises(ConfigurationError, match="has no class"):
        resolve_can_backend("crucihil.hal.backends.virtual.can:NonExistentClass")


def test_registry_custom_module_path_valid():
    cls = resolve_can_backend("crucihil.hal.backends.virtual.can:VirtualCANBackend")
    from crucihil.hal.backends.virtual.can import VirtualCANBackend
    assert cls is VirtualCANBackend


# ── CAN fault injection (dropout) ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_can_dropout_blocks_send(rig: Rig):
    """block_arb_id() suppresses TX; unblock restores it."""
    received = []

    async def listener(frame):
        received.append(frame)

    backend = rig._can_backends["can0"]
    backend.add_listener(listener)

    # Normal send — should be delivered
    await rig.can.send_raw(arb_id=0x123, data=b"\x01\x02")
    await asyncio.sleep(0)
    await asyncio.sleep(0)
    assert any(f.arb_id == 0x123 for f in received), "Frame should be delivered before dropout"

    received.clear()

    # Activate dropout via FaultNamespace
    d = rig.fault.can_dropout(arb_id=0x123, duration=0.0)
    async with rig.fault.inject(d):
        await rig.can.send_raw(arb_id=0x123, data=b"\x01\x02")
        await asyncio.sleep(0)
        await asyncio.sleep(0)
        assert not any(f.arb_id == 0x123 for f in received), "Frame must be suppressed during dropout"

    # After dropout ends — should be delivered again
    received.clear()
    await rig.can.send_raw(arb_id=0x123, data=b"\x01\x02")
    await asyncio.sleep(0)
    await asyncio.sleep(0)
    assert any(f.arb_id == 0x123 for f in received), "Frame should be delivered after dropout removed"

    backend.remove_listener(listener)


@pytest.mark.asyncio
async def test_can_dropout_interface_filter(rig: Rig):
    """can_dropout with interface=None affects all interfaces."""
    d = rig.fault.can_dropout(arb_id=0x999, duration=0.0, interface=None)
    backend = rig._can_backends["can0"]
    async with rig.fault.inject(d):
        assert 0x999 in backend._blocked_arb_ids
    assert 0x999 not in backend._blocked_arb_ids


# ── ECU namespace ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_ecu_namespace_exists(rig: Rig):
    """rig.ecu is an ECUNamespace with ecu_main proxy after connect()."""
    assert hasattr(rig, "ecu")
    assert hasattr(rig.ecu, "ecu_main")


@pytest.mark.asyncio
async def test_ecu_flash_virtual(rig: Rig):
    """flash() on virtual DoIP returns success with valid firmware file."""
    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as tmp:
        # Write a tiny firmware image
        firmware = bytes(range(256)) * 4  # 1 KB
        tmp.write(firmware)
        tmp_path = Path(tmp.name)

    try:
        result = await rig.ecu.ecu_main.flash(tmp_path, timeout=5.0)
        assert result.success, f"Flash failed: {result.error}"
        assert result.bytes_transferred == len(firmware)
        assert result.block_count >= 1
        assert result.duration >= 0
    finally:
        tmp_path.unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_ecu_flash_missing_file(rig: Rig):
    """flash() raises FlashError for a missing firmware file."""
    with pytest.raises(FlashError, match="not found"):
        await rig.ecu.ecu_main.flash("/tmp/__no_such_firmware__.bin")


@pytest.mark.asyncio
async def test_ecu_reset_virtual(rig: Rig):
    """reset() completes without error on virtual backend."""
    await rig.ecu.ecu_main.reset(reset_type=0x01, timeout=1.0)


# ── HTML reporter ──────────────────────────────────────────────────────────────

def test_html_reporter_produces_file():
    from crucihil.agent.reporter.html import write_html_report
    from crucihil.agent.manifest.schema import TestSuite, SuiteMetadata

    suite = TestSuite(suite=SuiteMetadata(name="Phase1Test", version="0.1.0"))
    results = [
        _make_result("test_a", "pass", 0.12),
        _make_result("test_b", "fail", 0.55, errors=["assertion failed"]),
        _make_result("test_c", "blocked", 0.01),
        _make_result("test_d", "skip", 0.0),
    ]

    with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as tmp:
        out = Path(tmp.name)

    try:
        write_html_report(results, suite, out)
        content = out.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content
        assert "Phase1Test" in content
        assert "PASS" in content.upper()
        assert "FAIL" in content.upper()
        assert "assertion failed" in content
        assert "crucihil.io" in content
        assert "<script>" in content
        assert "external" not in content.lower() or "cdn" not in content.lower()
    finally:
        out.unlink(missing_ok=True)


def test_html_reporter_empty_suite():
    from crucihil.agent.reporter.html import write_html_report
    from crucihil.agent.manifest.schema import TestSuite, SuiteMetadata

    suite = TestSuite(suite=SuiteMetadata(name="EmptySuite"))
    with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as tmp:
        out = Path(tmp.name)
    try:
        write_html_report([], suite, out)
        content = out.read_text()
        assert "0%" in content or "0 tests" in content
    finally:
        out.unlink(missing_ok=True)


# ── SQLite result cache ────────────────────────────────────────────────────────

def test_cache_write_and_query():
    from crucihil.agent.cache.cache import ResultCache

    with tempfile.TemporaryDirectory() as tmpdir:
        cache = ResultCache.open(Path(tmpdir) / "test.db")
        try:
            r = _make_result("cache_test_1", "pass", 0.5)
            cache.write(r)

            results = cache.query(limit=10)
            assert len(results) == 1
            assert results[0].test_id == "cache_test_1"
            assert results[0].status == "pass"
            assert results[0].duration == pytest.approx(0.5)
        finally:
            cache.close()


def test_cache_query_filters_by_status():
    from crucihil.agent.cache.cache import ResultCache

    with tempfile.TemporaryDirectory() as tmpdir:
        cache = ResultCache.open(Path(tmpdir) / "test.db")
        try:
            cache.write(_make_result("t1", "pass", 0.1))
            cache.write(_make_result("t2", "fail", 0.2))
            cache.write(_make_result("t3", "fail", 0.3))

            failures = cache.query(status="fail")
            assert len(failures) == 2
            assert all(r.status == "fail" for r in failures)

            passes = cache.query(status="pass")
            assert len(passes) == 1
        finally:
            cache.close()


def test_cache_prune_old_results():
    from crucihil.agent.cache.cache import ResultCache
    from sqlalchemy import text

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "prune_test.db"
        cache = ResultCache.open(db_path)
        try:
            # Write an old result (40 days ago)
            old = _make_result("old_test", "pass", 1.0)
            old.started_at = time.time() - 40 * 86400
            old.completed_at = old.started_at + 1.0
            cache.write(old)

            # Write a recent result
            cache.write(_make_result("new_test", "pass", 0.5))

            # Prune — should remove the old result
            cache._prune()

            results = cache.query()
            ids = [r.test_id for r in results]
            assert "old_test" not in ids
            assert "new_test" in ids
        finally:
            cache.close()


def test_cache_write_errors_and_logs():
    from crucihil.agent.cache.cache import ResultCache

    with tempfile.TemporaryDirectory() as tmpdir:
        cache = ResultCache.open(Path(tmpdir) / "test.db")
        try:
            r = _make_result("err_test", "error", 0.1,
                             errors=["something blew up", "traceback here"],
                             logs=["step 1 done"])
            cache.write(r)
            results = cache.query()
            assert results[0].errors == ["something blew up", "traceback here"]
            assert results[0].logs == ["step 1 done"]
        finally:
            cache.close()


# ── Virtual UDP + UDS backends ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_virtual_udp_connect_disconnect():
    from crucihil.hal.backends.virtual.udp import VirtualUDPBackend
    b = VirtualUDPBackend()
    await b.connect("eth0", "127.0.0.1", 9000)
    assert b._connected
    await b.disconnect()
    assert not b._connected


@pytest.mark.asyncio
async def test_virtual_udp_inject_receive():
    from crucihil.hal.backends.virtual.udp import VirtualUDPBackend
    from crucihil.hal.models.exceptions import CANTimeoutError
    b = VirtualUDPBackend()
    await b.connect("eth0", "127.0.0.1", 9000)

    b.inject(b"hello", "10.0.0.1", 1234)
    data, ip, port = await b.receive(timeout=0.1)
    assert data == b"hello"
    assert ip == "10.0.0.1"
    assert port == 1234

    with pytest.raises(CANTimeoutError):
        await b.receive(timeout=0.02)

    await b.disconnect()


@pytest.mark.asyncio
async def test_virtual_uds_default_positive_response():
    from crucihil.hal.backends.virtual.uds import VirtualUDSBackend
    b = VirtualUDSBackend()
    await b.connect()
    resp = await b.request(0x22, b"\xF1\x90", timeout=1.0)
    assert isinstance(resp, bytes)
    await b.disconnect()


@pytest.mark.asyncio
async def test_virtual_uds_custom_handler():
    from crucihil.hal.backends.virtual.uds import VirtualUDSBackend
    b = VirtualUDSBackend()
    await b.connect()
    b.register_handler(0x22, lambda payload: b"VIN12345678901234")
    resp = await b.request(0x22, b"\xF1\x90", timeout=1.0)
    assert resp == b"VIN12345678901234"
    await b.disconnect()


# ── Config schema — udp/uds sections ──────────────────────────────────────────

def test_rig_config_udp_section_parses():
    from crucihil.hal.config.schema import RigConfig
    raw = {
        "name": "test_udp_rig",
        "platform": "virtual",
        "backend": "virtual",
        "udp": {
            "udp0": {
                "interface": "eth0",
                "ip": "127.0.0.1",
                "port": 9000,
                "backend": "virtual_udp",
            }
        },
    }
    cfg = RigConfig(**raw)
    assert "udp0" in cfg.udp
    assert cfg.udp["udp0"].ip == "127.0.0.1"


def test_rig_config_uds_section_parses():
    from crucihil.hal.config.schema import RigConfig
    raw = {
        "name": "test_uds_rig",
        "platform": "virtual",
        "backend": "virtual",
        "uds": {"backend": "virtual_uds", "timeout": 3.0},
    }
    cfg = RigConfig(**raw)
    assert cfg.uds is not None
    assert cfg.uds.backend == "virtual_uds"
    assert cfg.uds.timeout == pytest.approx(3.0)


# ── JSON Schema files exist and are valid JSON ─────────────────────────────────

def test_rig_config_schema_file_valid():
    schema_path = Path(__file__).parent.parent.parent / "schemas" / "rig_config.schema.json"
    assert schema_path.exists(), "schemas/rig_config.schema.json not found"
    data = json.loads(schema_path.read_text())
    assert "properties" in data or "$defs" in data


def test_suite_manifest_schema_file_valid():
    schema_path = Path(__file__).parent.parent.parent / "schemas" / "suite_manifest.schema.json"
    assert schema_path.exists(), "schemas/suite_manifest.schema.json not found"
    data = json.loads(schema_path.read_text())
    assert "properties" in data


# ── Helpers ────────────────────────────────────────────────────────────────────

def _make_result(
    test_id: str,
    status: str,
    duration: float,
    errors: list[str] | None = None,
    logs: list[str] | None = None,
) -> TestResult:
    now = time.time()
    return TestResult(
        test_id=test_id,
        run_id="test_run_001",
        suite_name="Phase1TestSuite",
        status=status,     # type: ignore[arg-type]
        duration=duration,
        started_at=now,
        completed_at=now + duration,
        errors=errors or [],
        logs=logs or [],
    )
