"""Integration tests: agent ↔ cloud protocol via FastAPI ASGI transport.

Tests the agent's HTTP-level interactions with the cloud control plane:
- JWT auth (POST /api/v1/auth/token)
- Sync flush (POST /api/v1/results/sync)
- Heartbeat ping (WS ping → server updates last_seen_at)
- Result streaming via WS
"""

from __future__ import annotations

import json
import time
import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest

from crucihil.agent.agent import LocalAgent
from crucihil.agent.cache.cache import ResultCache
from crucihil.agent.cache.sync import flush_unsynced
from crucihil.hal.config.schema import CloudConfig
from crucihil.hal.models.results import TestResult


def _make_result(run_id: str, test_id: str = "t1") -> TestResult:
    now = time.time()
    return TestResult(
        test_id=test_id,
        run_id=run_id,
        suite_name="engine_suite",
        status="pass",
        duration=0.5,
        started_at=now,
        completed_at=now + 0.5,
    )


def _make_agent(cache: ResultCache, async_client, rig_name: str = "agent-test-rig") -> LocalAgent:
    rig_mock = MagicMock()
    rig_mock.config.name = rig_name
    cloud = CloudConfig(url="http://testserver", api_key="dummy")
    agent = LocalAgent(rig=rig_mock, cache=cache, cloud=cloud)
    agent._http = async_client
    return agent


# ── JWT auth ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_agent_obtains_jwt_on_startup(async_client, registered_rig, tmp_path):
    """Agent POSTs api_key to /auth/token and stores the JWT."""
    rig, raw_key = registered_rig
    cache = ResultCache.open(tmp_path / "results.db")
    cloud = CloudConfig(url="http://testserver", api_key=raw_key)

    rig_mock = MagicMock()
    rig_mock.config.name = rig.name
    agent = LocalAgent(rig=rig_mock, cache=cache, cloud=cloud)
    agent._http = async_client

    await agent._refresh_token()

    assert agent._token is not None
    assert agent._token_expires_at > time.time()
    cache.close()


@pytest.mark.asyncio
async def test_agent_jwt_with_bad_key_leaves_token_none(async_client, registered_rig, tmp_path):
    """Bad API key → 401 → token stays None, no exception raised."""
    cache = ResultCache.open(tmp_path / "results.db")
    cloud = CloudConfig(url="http://testserver", api_key="crucihil-rig-badkey")

    rig_mock = MagicMock()
    rig_mock.config.name = "agent-test-rig"
    agent = LocalAgent(rig=rig_mock, cache=cache, cloud=cloud)
    agent._http = async_client

    await agent._refresh_token()

    assert agent._token is None
    cache.close()


# ── Sync flush ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_sync_flush_posts_results_to_server(
    async_client, registered_rig, auth_headers, tmp_path
):
    """flush_unsynced POSTs SQLite cache to /api/v1/results/sync."""
    rig, raw_key = registered_rig
    cache = ResultCache.open(tmp_path / "results.db")

    run_id = str(uuid.uuid4())
    cache.write(_make_result(run_id, "t1"))
    cache.write(_make_result(run_id, "t2"))

    # Obtain a real JWT for auth
    token_resp = await async_client.post(
        "/api/v1/auth/token", json={"api_key": raw_key}
    )
    assert token_resp.status_code == 200
    token = token_resp.json()["access_token"]

    synced = await flush_unsynced(
        cache, async_client, token, "http://testserver", rig.name
    )

    assert synced == 2
    assert cache.query_unsynced() == []

    # Verify results exist on server
    resp = await async_client.get(
        f"/api/v1/results?run_id={run_id}", headers={"Authorization": f"Bearer {token}"}
    )
    assert resp.status_code == 200
    assert len(resp.json()) == 2
    cache.close()


@pytest.mark.asyncio
async def test_sync_flush_idempotent(async_client, registered_rig, tmp_path):
    """Replaying the same results twice never creates duplicate server rows."""
    rig, raw_key = registered_rig
    cache = ResultCache.open(tmp_path / "results.db")

    run_id = str(uuid.uuid4())
    cache.write(_make_result(run_id))

    token_resp = await async_client.post(
        "/api/v1/auth/token", json={"api_key": raw_key}
    )
    token = token_resp.json()["access_token"]

    # First sync
    s1 = await flush_unsynced(cache, async_client, token, "http://testserver", rig.name)
    assert s1 == 1

    # Write row again simulating a re-flush (reset synced_at manually for test)
    from sqlalchemy import create_engine, text
    with cache._Session() as session:
        session.execute(text("UPDATE test_results SET synced_at = NULL"))
        session.commit()

    # Second sync — server DO NOTHING, but we still mark synced
    s2 = await flush_unsynced(cache, async_client, token, "http://testserver", rig.name)
    assert s2 == 1

    # Server should still have exactly 1 result (not 2)
    resp = await async_client.get(
        f"/api/v1/results?run_id={run_id}", headers={"Authorization": f"Bearer {token}"}
    )
    assert len(resp.json()) == 1
    cache.close()


# ── Heartbeat / ping ───────────────────────────────────────────────────────────

def test_ws_ping_updates_last_seen_at(sync_client, registered_rig, auth_headers, db_session):
    """Ping message from agent causes server to update rig.last_seen_at."""
    from crucihil.server.models.rig import RigRow

    rig, raw_key = registered_rig

    token_resp = sync_client.post("/api/v1/auth/token", json={"api_key": raw_key})
    token = token_resp.json()["access_token"]

    before = time.time()

    with sync_client.websocket_connect(f"/ws/agent?token={token}") as ws:
        ws.send_text(json.dumps({"type": "ping"}))
        ack = json.loads(ws.receive_text())
        assert ack["type"] == "ack"
        assert ack["msg_type"] == "ping"

    db_session.expire_all()
    updated_rig = db_session.get(RigRow, rig.id)
    assert updated_rig.last_seen_at >= before


# ── Local-only fallback ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_on_result_writes_to_cache_in_local_only_mode(tmp_path):
    """No cloud config → on_result still writes to cache, no WS send."""
    cache = ResultCache.open(tmp_path / "results.db")
    rig_mock = MagicMock()
    rig_mock.config.name = "local-rig"

    agent = LocalAgent(rig=rig_mock, cache=cache, cloud=None)
    agent._ws = None

    result = _make_result(str(uuid.uuid4()))
    await agent.on_result(result)

    cached = cache.query(limit=10)
    assert len(cached) == 1
    assert cached[0].test_id == result.test_id
    cache.close()


# ── Runner callback integration ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_runner_on_result_callback_invoked():
    """run_suite on_result callback is called once per test in the suite."""
    from pathlib import Path

    from crucihil.agent.manifest.loader import load_suite
    from crucihil.agent.runner.runner import run_suite
    from crucihil.hal.rig import Rig

    rig = Rig.from_toml(Path("rigs/virtual.toml"))
    suite = load_suite(Path("tests/suites/engine_validation.yaml"))

    async with rig:
        collected: list[TestResult] = []

        async def collect(result: TestResult) -> None:
            collected.append(result)

        results = await run_suite(suite, rig, on_result=collect)

    # Callback must fire exactly once per test
    assert len(results) == len(collected)
    assert [r.test_id for r in results] == [c.test_id for c in collected]


# ── Env var cloud config override ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_agent_create_cloud_from_env_vars(monkeypatch, tmp_path):
    """CRUCIHIL_BASE_URL + CRUCIHIL_API_KEY env vars override [rig.cloud] in TOML."""
    from pathlib import Path

    from crucihil.agent.agent import LocalAgent

    monkeypatch.setenv("CRUCIHIL_BASE_URL", "http://env-server:8000")
    monkeypatch.setenv("CRUCIHIL_API_KEY", "crucihil-rig-from-env")

    agent = await LocalAgent.create(
        rig_path=Path("rigs/virtual.toml"),
        cache_path=tmp_path / "results.db",
    )
    try:
        assert agent._cloud is not None
        assert agent._cloud.url == "http://env-server:8000"
        assert agent._cloud.api_key == "crucihil-rig-from-env"
    finally:
        await agent._rig.disconnect()
        agent._cache.close()


@pytest.mark.asyncio
async def test_agent_create_no_cloud_without_env_or_toml(monkeypatch, tmp_path):
    """No env vars + no [rig.cloud] in TOML → agent runs in local-only mode."""
    from pathlib import Path

    from crucihil.agent.agent import LocalAgent

    monkeypatch.delenv("CRUCIHIL_BASE_URL", raising=False)
    monkeypatch.delenv("CRUCIHIL_API_KEY", raising=False)

    agent = await LocalAgent.create(
        rig_path=Path("rigs/virtual.toml"),
        cache_path=tmp_path / "results.db",
    )
    try:
        # virtual.toml has no [rig.cloud] section and no env vars → local-only
        assert agent._cloud is None
    finally:
        await agent._rig.disconnect()
        agent._cache.close()


# ── run_suite dispatch ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_dispatch_run_executes_suite(tmp_path):
    """_dispatch_run spawns a task that loads and runs a suite."""
    from pathlib import Path
    from unittest.mock import AsyncMock, MagicMock

    from crucihil.hal.rig import Rig

    rig = Rig.from_toml(Path("rigs/virtual.toml"))
    await rig.connect()

    cache = ResultCache.open(tmp_path / "results.db")
    cloud = CloudConfig(url="http://testserver", api_key="dummy")
    agent = LocalAgent(rig=rig, cache=cache, cloud=cloud)

    collected: list[TestResult] = []
    original_on_result = agent.on_result

    async def capturing_on_result(result: TestResult) -> None:
        collected.append(result)
        await original_on_result(result)

    agent.on_result = capturing_on_result

    msg = {
        "type": "run_suite",
        "run_id": str(uuid.uuid4()),
        "suite_path": "tests/suites/engine_validation.yaml",
        "tags": [],
        "suite_type": None,
    }

    await agent._dispatch_run(msg)

    # Wait for the background task to complete
    task = list(agent._active_runs.values())[0] if agent._active_runs else None
    if task:
        await task

    assert len(collected) > 0, "Expected at least one result from the suite"

    await rig.disconnect()
    cache.close()


@pytest.mark.asyncio
async def test_dispatch_run_bad_path_does_not_crash(tmp_path):
    """_dispatch_run with a non-existent suite path sends run_complete without crashing."""
    from unittest.mock import AsyncMock, MagicMock

    cache = ResultCache.open(tmp_path / "results.db")
    rig_mock = MagicMock()
    rig_mock.config.name = "test-rig"
    cloud = CloudConfig(url="http://testserver", api_key="dummy")
    agent = LocalAgent(rig=rig_mock, cache=cache, cloud=cloud)

    sent_messages = []
    ws_mock = MagicMock()
    ws_mock.send = AsyncMock(side_effect=lambda m: sent_messages.append(json.loads(m)))
    agent._ws = ws_mock

    msg = {
        "type": "run_suite",
        "run_id": str(uuid.uuid4()),
        "suite_path": "does/not/exist.yaml",
        "tags": [],
        "suite_type": None,
    }

    await agent._dispatch_run(msg)

    # Wait for background task
    for task in list(agent._active_runs.values()):
        try:
            await task
        except Exception:
            pass

    # Should have sent run_complete (possibly with error) — not hung or raised
    types = [m.get("type") for m in sent_messages]
    assert "run_complete" in types

    cache.close()


# ── Server: run_start / run_complete handlers ──────────────────────────────────

def test_ws_run_start_marks_run_running(sync_client, registered_rig, db_session):
    """run_start message transitions a queued run to running."""
    rig, raw_key = registered_rig

    token_resp = sync_client.post("/api/v1/auth/token", json={"api_key": raw_key})
    token = token_resp.json()["access_token"]

    # Create a queued run
    run_resp = sync_client.post(
        "/api/v1/runs",
        json={"rig_name": rig.name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert run_resp.status_code == 201
    run_id = run_resp.json()["run_id"]

    # Send run_start via WS
    with sync_client.websocket_connect(f"/ws/agent?token={token}") as ws:
        ws.send_text(json.dumps({
            "type": "run_start",
            "run_id": run_id,
            "suite_name": "engine_suite",
            "started_at": time.time(),
        }))
        ack = json.loads(ws.receive_text())
        assert ack["type"] == "ack"
        assert ack["msg_type"] == "run_start"

    db_session.expire_all()
    from crucihil.server.models.run import TestRunRow
    run = db_session.get(TestRunRow, run_id)
    assert run.status == "running"


def test_ws_run_complete_finalizes_run(sync_client, registered_rig, db_session):
    """run_complete message calls finalize_run and sets a terminal status."""
    rig, raw_key = registered_rig

    token_resp = sync_client.post("/api/v1/auth/token", json={"api_key": raw_key})
    token = token_resp.json()["access_token"]

    run_resp = sync_client.post(
        "/api/v1/runs",
        json={"rig_name": rig.name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers={"Authorization": f"Bearer {token}"},
    )
    run_id = run_resp.json()["run_id"]

    completed_at = time.time()

    with sync_client.websocket_connect(f"/ws/agent?token={token}") as ws:
        # First mark it running
        ws.send_text(json.dumps({
            "type": "run_start",
            "run_id": run_id,
            "suite_name": "engine_suite",
            "started_at": completed_at - 1.0,
        }))
        json.loads(ws.receive_text())  # consume ack

        # Stream one passing result
        ws.send_text(json.dumps({
            "type": "result",
            "run_id": run_id,
            "result": {
                "test_id": "test_engine_rpm",
                "run_id": run_id,
                "suite_name": "engine_suite",
                "status": "pass",
                "duration": 0.3,
                "started_at": completed_at - 0.5,
                "completed_at": completed_at,
                "errors": [],
                "logs": [],
                "signals": {},
                "metadata": {},
            },
        }))
        json.loads(ws.receive_text())  # consume ack

        # Now send run_complete
        ws.send_text(json.dumps({
            "type": "run_complete",
            "run_id": run_id,
            "completed_at": completed_at,
        }))
        ack = json.loads(ws.receive_text())
        assert ack["type"] == "ack"
        assert ack["msg_type"] == "run_complete"

    db_session.expire_all()
    from crucihil.server.models.run import TestRunRow
    run = db_session.get(TestRunRow, run_id)
    assert run.status == "pass"
    assert run.completed_at is not None
    assert run.passed == 1
