"""Shared fixtures for agent integration tests.

Uses the same SQLite-backed FastAPI setup as integration/server/conftest.py,
but also provides an httpx.AsyncClient wired to the ASGI app for agent HTTP calls.
"""

from __future__ import annotations

import time

import pytest
import pytest_asyncio
import httpx
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from crucihil.server.api.deps import get_db
from crucihil.server.db.session import reset_engine, set_engine
from crucihil.server.main import create_app
from crucihil.server.models.base import Base
import crucihil.server.models.rig         # noqa: F401
import crucihil.server.models.run         # noqa: F401
import crucihil.server.models.result      # noqa: F401
import crucihil.server.models.viewer_key  # noqa: F401
from crucihil.server.models.rig import RigRow
from crucihil.server.services.auth import generate_api_key, hash_api_key, issue_jwt


@pytest.fixture
def db_engine():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture
def db_session(db_engine):
    factory = sessionmaker(bind=db_engine, autocommit=False, autoflush=False, expire_on_commit=False)
    with factory() as session:
        yield session


@pytest.fixture
def sync_client(db_engine):
    """Synchronous TestClient for WebSocket tests."""
    from fastapi.testclient import TestClient
    set_engine(db_engine)
    factory = sessionmaker(bind=db_engine, autocommit=False, autoflush=False, expire_on_commit=False)

    def override_get_db():
        with factory() as session:
            yield session

    app = create_app()
    app.dependency_overrides[get_db] = override_get_db
    try:
        with TestClient(app, raise_server_exceptions=True) as c:
            yield c
    finally:
        reset_engine()


@pytest_asyncio.fixture
async def async_client(db_engine):
    """Async httpx.AsyncClient backed by the FastAPI ASGI app (for agent HTTP calls)."""
    set_engine(db_engine)
    factory = sessionmaker(bind=db_engine, autocommit=False, autoflush=False, expire_on_commit=False)

    def override_get_db():
        with factory() as session:
            yield session

    app = create_app()
    app.dependency_overrides[get_db] = override_get_db

    transport = httpx.AsyncHTTPTransport()
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        yield client

    reset_engine()


@pytest.fixture
def registered_rig(db_session):
    raw_key = generate_api_key()
    rig = RigRow(
        name="agent-test-rig",
        api_key_hash=hash_api_key(raw_key),
        created_at=time.time(),
    )
    db_session.add(rig)
    db_session.commit()
    db_session.refresh(rig)
    return rig, raw_key


@pytest.fixture
def auth_headers(registered_rig):
    rig, _ = registered_rig
    token_data = issue_jwt(rig_name=rig.name, rig_id=rig.id)
    return {"Authorization": f"Bearer {token_data['access_token']}"}
