"""Shared fixtures for server integration tests.

Uses SQLite in-memory database so no PostgreSQL is needed in CI.
Each test gets a fresh DB and a fresh TestClient with the in-memory DB wired in.
"""

from __future__ import annotations

import time
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from crucihil.server.api.deps import get_db
from crucihil.server.db.session import reset_engine, set_engine
from crucihil.server.main import create_app
from crucihil.server.models.base import Base
import crucihil.server.models.org         # noqa: F401
import crucihil.server.models.user        # noqa: F401
import crucihil.server.models.rig         # noqa: F401
import crucihil.server.models.run         # noqa: F401
import crucihil.server.models.result      # noqa: F401
import crucihil.server.models.viewer_key  # noqa: F401
import crucihil.server.config as _config_module
from crucihil.server.models.org import OrgRow
from crucihil.server.models.rig import RigRow
from crucihil.server.models.user import UserRow
from crucihil.server.models.viewer_key import ViewerKeyRow
from crucihil.server.services.auth import (
    generate_api_key,
    generate_viewer_key,
    hash_api_key,
    hash_password,
    issue_jwt,
    issue_user_jwt,
)

_TEST_REGISTRATION_TOKEN = "test-registration-token-abc123"


@pytest.fixture
def db_engine():
    # StaticPool forces all connections to share one in-memory database.
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture
def db_session(db_engine):
    factory = sessionmaker(bind=db_engine, autocommit=False, autoflush=False, expire_on_commit=False)
    with factory() as session:
        yield session


@pytest.fixture
def registration_headers(monkeypatch):
    """Headers carrying the REGISTRATION_TOKEN for POST /api/v1/rigs."""
    _config_module._settings = None  # clear cache so patched env is picked up
    monkeypatch.setenv("REGISTRATION_TOKEN", _TEST_REGISTRATION_TOKEN)
    yield {"Authorization": f"Bearer {_TEST_REGISTRATION_TOKEN}"}
    _config_module._settings = None  # restore for next test


@pytest.fixture
def client(db_engine):
    """TestClient wired to in-memory SQLite DB.

    Injects the SQLite engine at the module level so the app lifespan's
    create_all() uses SQLite instead of trying to connect to PostgreSQL.
    """
    set_engine(db_engine)  # wire lifespan to use SQLite
    factory = sessionmaker(bind=db_engine, autocommit=False, autoflush=False, expire_on_commit=False)

    def override_get_db():
        with factory() as session:
            yield session

    app = create_app()
    app.dependency_overrides[get_db] = override_get_db
    try:
        with TestClient(app, raise_server_exceptions=True) as c:
            yield c
    finally:
        reset_engine()  # clear global so next test gets a fresh engine


@pytest.fixture
def registered_rig(db_session):
    """A rig row in the DB plus its raw API key."""
    raw_key = generate_api_key()
    rig = RigRow(
        name="test-rig",
        api_key_hash=hash_api_key(raw_key),
        created_at=time.time(),
    )
    db_session.add(rig)
    db_session.commit()
    db_session.refresh(rig)
    return rig, raw_key


@pytest.fixture
def auth_headers(registered_rig):
    """Bearer token headers for the test rig (admin role)."""
    rig, _ = registered_rig
    token_data = issue_jwt(rig_name=rig.name, rig_id=rig.id, role="admin")
    return {"Authorization": f"Bearer {token_data['access_token']}"}


@pytest.fixture
def viewer_rig_and_key(db_session, registered_rig):
    """A viewer key for the test rig. Returns (ViewerKeyRow, raw_key)."""
    rig, _ = registered_rig
    raw_key = generate_viewer_key()
    vk = ViewerKeyRow(
        rig_id=rig.id,
        name="ci-readonly",
        api_key_hash=hash_api_key(raw_key),
        created_at=time.time(),
    )
    db_session.add(vk)
    db_session.commit()
    db_session.refresh(vk)
    return vk, raw_key


@pytest.fixture
def viewer_auth_headers(registered_rig, viewer_rig_and_key):
    """Bearer token headers with viewer role JWT."""
    rig, _ = registered_rig
    token_data = issue_jwt(rig_name=rig.name, rig_id=rig.id, role="viewer")
    return {"Authorization": f"Bearer {token_data['access_token']}"}


# ── User / org fixtures ───────────────────────────────────────────────────────


@pytest.fixture
def org(db_session):
    """An OrgRow in the DB."""
    row = OrgRow(name="Test Org", slug="test-org", created_at=time.time())
    db_session.add(row)
    db_session.commit()
    db_session.refresh(row)
    return row


@pytest.fixture
def admin_user(db_session, org):
    """An admin UserRow with a known password."""
    row = UserRow(
        org_id=org.id,
        email="admin@test.example",
        password_hash=hash_password("password123"),
        role="admin",
        joined_at=time.time(),
        created_at=time.time(),
    )
    db_session.add(row)
    db_session.commit()
    db_session.refresh(row)
    return row


@pytest.fixture
def member_user(db_session, org):
    """A member UserRow with a known password."""
    row = UserRow(
        org_id=org.id,
        email="member@test.example",
        password_hash=hash_password("password123"),
        role="member",
        joined_at=time.time(),
        created_at=time.time(),
    )
    db_session.add(row)
    db_session.commit()
    db_session.refresh(row)
    return row


@pytest.fixture
def admin_user_headers(admin_user, org):
    """Bearer token headers for an admin user JWT."""
    token_data = issue_user_jwt(user_id=admin_user.id, org_id=admin_user.org_id, org_slug=org.slug, role="admin")
    return {"Authorization": f"Bearer {token_data['access_token']}"}


@pytest.fixture
def member_user_headers(member_user, org):
    """Bearer token headers for a member user JWT."""
    token_data = issue_user_jwt(user_id=member_user.id, org_id=member_user.org_id, org_slug=org.slug, role="member")
    return {"Authorization": f"Bearer {token_data['access_token']}"}


