"""Integration tests: /api/v1/results endpoints including sync idempotency."""

import time
import uuid

import pytest

from crucihil.server.models.run import TestRunRow


def _make_result(test_id: str, status: str = "pass") -> dict:
    now = time.time()
    return {
        "test_id": test_id,
        "run_id": "",
        "suite_name": "engine_suite",
        "status": status,
        "duration": 1.2,
        "started_at": now,
        "completed_at": now + 1.2,
        "errors": [],
        "logs": ["Started ok"],
        "signals": {},
        "metadata": {},
    }


def _sync_payload(rig_name: str, run_id: str, results: list) -> dict:
    return {
        "run_id": run_id,
        "rig_name": rig_name,
        "suite_name": "engine_suite",
        "started_at": time.time(),
        "results": results,
    }


def test_sync_creates_results(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    run_id = str(uuid.uuid4())
    payload = _sync_payload(rig.name, run_id, [
        _make_result("test_a"),
        _make_result("test_b", "fail"),
    ])
    resp = client.post("/api/v1/results/sync", json=payload, headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["inserted"] == 2
    assert resp.json()["run_id"] == run_id


def test_sync_idempotent(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    run_id = str(uuid.uuid4())
    payload = _sync_payload(rig.name, run_id, [_make_result("test_a")])

    r1 = client.post("/api/v1/results/sync", json=payload, headers=auth_headers)
    r2 = client.post("/api/v1/results/sync", json=payload, headers=auth_headers)

    assert r1.json()["inserted"] == 1
    assert r2.json()["inserted"] == 0  # duplicate — ON CONFLICT DO NOTHING


def test_sync_creates_test_run_row(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    run_id = str(uuid.uuid4())
    payload = _sync_payload(rig.name, run_id, [_make_result("test_x")])
    client.post("/api/v1/results/sync", json=payload, headers=auth_headers)

    resp = client.get(f"/api/v1/runs/{run_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["suite_name"] == "engine_suite"


def test_list_results(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    run_id = str(uuid.uuid4())
    payload = _sync_payload(rig.name, run_id, [_make_result("test_a"), _make_result("test_b")])
    client.post("/api/v1/results/sync", json=payload, headers=auth_headers)

    resp = client.get(f"/api/v1/results?run_id={run_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 2


def test_get_result_detail(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    run_id = str(uuid.uuid4())
    payload = _sync_payload(rig.name, run_id, [_make_result("test_detail")])
    client.post("/api/v1/results/sync", json=payload, headers=auth_headers)

    results = client.get(f"/api/v1/results?run_id={run_id}", headers=auth_headers).json()
    result_id = results[0]["id"]
    resp = client.get(f"/api/v1/results/{result_id}", headers=auth_headers)
    assert resp.status_code == 200
    detail = resp.json()
    assert detail["test_id"] == "test_detail"
    assert isinstance(detail["logs"], list)
    assert isinstance(detail["signals"], dict)


def test_get_result_not_found(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/results/999999", headers=auth_headers)
    assert resp.status_code == 404


def test_filter_results_by_status(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    run_id = str(uuid.uuid4())
    payload = _sync_payload(rig.name, run_id, [
        _make_result("t_pass", "pass"),
        _make_result("t_fail", "fail"),
    ])
    client.post("/api/v1/results/sync", json=payload, headers=auth_headers)

    resp = client.get(f"/api/v1/results?run_id={run_id}&status=fail", headers=auth_headers)
    results = resp.json()
    assert len(results) == 1
    assert results[0]["status"] == "fail"
