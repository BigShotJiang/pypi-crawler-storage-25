"""Integration tests: /api/v1/rigs endpoints."""

import time

import pytest


def test_list_rigs_returns_registered(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/rigs", headers=auth_headers)
    assert resp.status_code == 200
    names = [r["name"] for r in resp.json()]
    assert "test-rig" in names


def test_list_rigs_requires_auth(client):
    resp = client.get("/api/v1/rigs")
    assert resp.status_code in (401, 403)  # HTTPBearer raises 401 or 403 depending on FastAPI version


def test_get_rig_ok(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/rigs/test-rig", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["name"] == "test-rig"


def test_get_rig_not_found(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/rigs/does-not-exist", headers=auth_headers)
    assert resp.status_code == 404


def test_register_rig_returns_api_key(client, registered_rig, registration_headers):
    resp = client.post(
        "/api/v1/rigs",
        json={"name": "new-rig"},
        headers=registration_headers,
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["rig"]["name"] == "new-rig"
    assert data["api_key"].startswith("crucihil-rig-")


def test_register_rig_duplicate_name(client, registered_rig, registration_headers):
    resp = client.post(
        "/api/v1/rigs",
        json={"name": "test-rig"},
        headers=registration_headers,
    )
    assert resp.status_code == 409


def test_delete_rig(client, registered_rig, auth_headers, registration_headers):
    # Register a new rig then delete it
    client.post("/api/v1/rigs", json={"name": "rig-to-delete"}, headers=registration_headers)
    resp = client.delete("/api/v1/rigs/rig-to-delete", headers=auth_headers)
    assert resp.status_code == 204
    assert client.get("/api/v1/rigs/rig-to-delete", headers=auth_headers).status_code == 404


def test_delete_rig_not_found(client, registered_rig, auth_headers):
    resp = client.delete("/api/v1/rigs/ghost-rig", headers=auth_headers)
    assert resp.status_code == 404
