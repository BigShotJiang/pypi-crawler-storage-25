"""Integration tests: WebSocket /ws/agent endpoint."""

import json
import time
import uuid

import pytest
from fastapi.testclient import TestClient

from crucihil.server.models.run import TestRunRow
from crucihil.server.services.auth import issue_jwt


def _ws_url(rig, raw_key, client):
    token_resp = client.post("/api/v1/auth/token", json={"api_key": raw_key})
    token = token_resp.json()["access_token"]
    return f"/ws/agent?token={token}"


def test_ws_hello(client, registered_rig, auth_headers):
    rig, raw_key = registered_rig
    url = _ws_url(rig, raw_key, client)
    with client.websocket_connect(url) as ws:
        ws.send_text(json.dumps({
            "type": "agent_hello",
            "rig": rig.name,
            "version": "0.1.0",
        }))
        ack = json.loads(ws.receive_text())
        assert ack["type"] == "ack"
        assert ack["msg_type"] == "agent_hello"


def test_ws_result_ingest(client, registered_rig, auth_headers):
    rig, raw_key = registered_rig
    url = _ws_url(rig, raw_key, client)
    run_id = str(uuid.uuid4())
    now = time.time()

    with client.websocket_connect(url) as ws:
        ws.send_text(json.dumps({
            "type": "result",
            "run_id": run_id,
            "result": {
                "test_id": "test_engine_startup",
                "run_id": run_id,
                "suite_name": "engine_suite",
                "status": "pass",
                "duration": 1.5,
                "started_at": now,
                "completed_at": now + 1.5,
                "errors": [],
                "logs": [],
                "signals": {},
                "metadata": {},
            },
        }))
        ack = json.loads(ws.receive_text())
        assert ack["msg_type"] == "result"

    # Verify the run was created
    resp = client.get(f"/api/v1/runs/{run_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["total"] == 1


def test_ws_no_token_rejected(client):
    with pytest.raises(Exception):
        with client.websocket_connect("/ws/agent") as ws:
            pass


def test_ws_bad_token_rejected(client):
    with pytest.raises(Exception):
        with client.websocket_connect("/ws/agent?token=bad.token.here") as ws:
            pass


def test_ws_hello_redelivers_queued_runs(client, registered_rig, db_session, auth_headers):
    """On agent_hello the server must push any queued runs for this rig."""
    rig, raw_key = registered_rig

    # Seed two queued runs for this rig
    run_ids = [str(uuid.uuid4()), str(uuid.uuid4())]
    for rid in run_ids:
        db_session.add(TestRunRow(
            id=rid,
            rig_id=rig.id,
            suite_name="tests/suites/engine_validation.yaml",
            started_at=time.time(),
            status="queued",
        ))
    db_session.commit()

    url = _ws_url(rig, raw_key, client)
    received_run_suite = []

    with client.websocket_connect(url) as ws:
        ws.send_text(json.dumps({
            "type": "agent_hello",
            "rig": rig.name,
            "version": "0.1.0",
        }))
        # Expect: ack for hello + one run_suite per queued run
        # Messages arrive in order: ack first, then run_suite messages
        messages = []
        for _ in range(1 + len(run_ids)):
            messages.append(json.loads(ws.receive_text()))

    ack = messages[0]
    assert ack["type"] == "ack"
    assert ack["msg_type"] == "agent_hello"

    run_suite_msgs = messages[1:]
    assert len(run_suite_msgs) == len(run_ids)
    assert all(m["type"] == "run_suite" for m in run_suite_msgs)
    delivered_ids = {m["run_id"] for m in run_suite_msgs}
    assert delivered_ids == set(run_ids)


def test_ws_hello_no_queued_runs_no_extra_messages(client, registered_rig):
    """When no runs are queued, hello produces only the ack."""
    rig, raw_key = registered_rig
    url = _ws_url(rig, raw_key, client)

    with client.websocket_connect(url) as ws:
        ws.send_text(json.dumps({
            "type": "agent_hello",
            "rig": rig.name,
            "version": "0.1.0",
        }))
        ack = json.loads(ws.receive_text())
        assert ack["type"] == "ack"
        # No further messages should arrive — close cleanly
        ws.close()


def test_ws_hello_does_not_redeliver_running_or_completed_runs(
    client, registered_rig, db_session
):
    """Only 'queued' runs are re-delivered; running/passed runs are not."""
    rig, raw_key = registered_rig

    for status in ("running", "passed", "failed"):
        db_session.add(TestRunRow(
            id=str(uuid.uuid4()),
            rig_id=rig.id,
            suite_name="tests/suites/engine_validation.yaml",
            started_at=time.time(),
            status=status,
        ))
    db_session.commit()

    url = _ws_url(rig, raw_key, client)
    with client.websocket_connect(url) as ws:
        ws.send_text(json.dumps({
            "type": "agent_hello",
            "rig": rig.name,
            "version": "0.1.0",
        }))
        ack = json.loads(ws.receive_text())
        assert ack["type"] == "ack"
        ws.close()  # no run_suite messages expected
