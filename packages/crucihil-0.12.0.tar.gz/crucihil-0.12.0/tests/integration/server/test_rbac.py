"""RBAC integration tests — admin vs. viewer role enforcement.

Admin JWT: full access (GET + POST + DELETE).
Viewer JWT: GET only; all writes return 403.
REGISTRATION_TOKEN: can always POST /api/v1/rigs (bootstrap path).
"""

from __future__ import annotations

import time
import uuid

import pytest

from crucihil.server.models.run import TestRunRow


# ── Helpers ────────────────────────────────────────────────────────────────────

def _create_run(client, auth_headers, rig_name: str) -> str:
    """Create a queued run and return its run_id."""
    resp = client.post(
        "/api/v1/runs",
        json={"rig_name": rig_name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers=auth_headers,
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["run_id"]


def _mark_run_running(db_session, run_id: str) -> None:
    run = db_session.get(TestRunRow, run_id)
    if run:
        run.status = "running"
        db_session.commit()


# ── Admin: read endpoints ──────────────────────────────────────────────────────

def test_admin_can_get_rigs(client, auth_headers):
    resp = client.get("/api/v1/rigs", headers=auth_headers)
    assert resp.status_code == 200


def test_admin_can_get_runs(client, auth_headers):
    resp = client.get("/api/v1/runs", headers=auth_headers)
    assert resp.status_code == 200


def test_admin_can_get_results(client, auth_headers):
    resp = client.get("/api/v1/results", headers=auth_headers)
    assert resp.status_code == 200


# ── Admin: write endpoints ─────────────────────────────────────────────────────

def test_admin_can_post_runs(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    resp = client.post(
        "/api/v1/runs",
        json={"rig_name": rig.name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers=auth_headers,
    )
    assert resp.status_code == 201


def test_admin_can_cancel_running_run(client, registered_rig, auth_headers, db_session):
    rig, _ = registered_rig
    run_id = _create_run(client, auth_headers, rig.name)
    _mark_run_running(db_session, run_id)

    resp = client.post(f"/api/v1/runs/{run_id}/cancel", headers=auth_headers)
    assert resp.status_code == 202


def test_admin_can_delete_rig(client, auth_headers, db_session):
    from crucihil.server.services.auth import generate_api_key, hash_api_key
    from crucihil.server.models.rig import RigRow

    # Create a secondary rig to delete
    raw = generate_api_key()
    extra = RigRow(name="deletable-rig", api_key_hash=hash_api_key(raw), created_at=time.time())
    db_session.add(extra)
    db_session.commit()

    resp = client.delete("/api/v1/rigs/deletable-rig", headers=auth_headers)
    assert resp.status_code == 204


def test_admin_can_register_rig_with_jwt(client, auth_headers):
    resp = client.post(
        "/api/v1/rigs",
        json={"name": f"new-rig-{uuid.uuid4().hex[:6]}"},
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = resp.json()
    assert "api_key" in data
    assert data["rig"]["role"] == "admin"


def test_new_rig_has_admin_role_by_default(client, registration_headers):
    resp = client.post(
        "/api/v1/rigs",
        json={"name": f"bootstrap-rig-{uuid.uuid4().hex[:6]}"},
        headers=registration_headers,
    )
    assert resp.status_code == 201
    assert resp.json()["rig"]["role"] == "admin"


# ── Admin: viewer key management ──────────────────────────────────────────────

def test_admin_can_create_viewer_key(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    resp = client.post(
        f"/api/v1/rigs/{rig.name}/viewers",
        json={"name": "ci-bot"},
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["role"] == "viewer"
    assert data["viewer_key"].startswith("crucihil-viewer-")


def test_admin_can_revoke_viewer_key(client, registered_rig, auth_headers):
    rig, _ = registered_rig
    create_resp = client.post(
        f"/api/v1/rigs/{rig.name}/viewers",
        json={"name": "ci-bot"},
        headers=auth_headers,
    )
    viewer_id = create_resp.json()["viewer_id"]

    resp = client.delete(f"/api/v1/rigs/{rig.name}/viewers/{viewer_id}", headers=auth_headers)
    assert resp.status_code == 204


# ── Viewer: read endpoints (all allowed) ──────────────────────────────────────

def test_viewer_can_get_rigs(client, viewer_auth_headers):
    resp = client.get("/api/v1/rigs", headers=viewer_auth_headers)
    assert resp.status_code == 200


def test_viewer_can_get_runs(client, viewer_auth_headers):
    resp = client.get("/api/v1/runs", headers=viewer_auth_headers)
    assert resp.status_code == 200


def test_viewer_can_get_results(client, viewer_auth_headers):
    resp = client.get("/api/v1/results", headers=viewer_auth_headers)
    assert resp.status_code == 200


# ── Viewer: write endpoints (all blocked) ─────────────────────────────────────

def test_viewer_cannot_post_runs(client, registered_rig, viewer_auth_headers):
    rig, _ = registered_rig
    resp = client.post(
        "/api/v1/runs",
        json={"rig_name": rig.name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers=viewer_auth_headers,
    )
    assert resp.status_code == 403


def test_viewer_cannot_cancel_run(client, registered_rig, auth_headers, viewer_auth_headers, db_session):
    rig, _ = registered_rig
    run_id = _create_run(client, auth_headers, rig.name)
    _mark_run_running(db_session, run_id)

    resp = client.post(f"/api/v1/runs/{run_id}/cancel", headers=viewer_auth_headers)
    assert resp.status_code == 403


def test_viewer_cannot_register_rig(client, viewer_auth_headers):
    resp = client.post(
        "/api/v1/rigs",
        json={"name": "viewer-should-fail"},
        headers=viewer_auth_headers,
    )
    assert resp.status_code == 403


def test_viewer_cannot_delete_rig(client, registered_rig, viewer_auth_headers):
    rig, _ = registered_rig
    resp = client.delete(f"/api/v1/rigs/{rig.name}", headers=viewer_auth_headers)
    assert resp.status_code == 403


def test_viewer_cannot_create_viewer_key(client, registered_rig, viewer_auth_headers):
    rig, _ = registered_rig
    resp = client.post(
        f"/api/v1/rigs/{rig.name}/viewers",
        json={"name": "should-fail"},
        headers=viewer_auth_headers,
    )
    assert resp.status_code == 403


# ── Bootstrap path ─────────────────────────────────────────────────────────────

def test_registration_token_can_create_rig(client, registration_headers):
    resp = client.post(
        "/api/v1/rigs",
        json={"name": f"bootstrap-{uuid.uuid4().hex[:6]}"},
        headers=registration_headers,
    )
    assert resp.status_code == 201


def test_registration_token_rejected_on_run_create(client, registered_rig, registration_headers):
    """REGISTRATION_TOKEN is not a JWT — cannot create runs."""
    rig, _ = registered_rig
    resp = client.post(
        "/api/v1/runs",
        json={"rig_name": rig.name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers=registration_headers,
    )
    # Must be rejected: 401 (not a valid JWT) or 403
    assert resp.status_code in (401, 403)


# ── Viewer key auth flow ───────────────────────────────────────────────────────

def test_viewer_key_issues_viewer_jwt(client, registered_rig, auth_headers):
    """A viewer key exchanges for a JWT with role=viewer."""
    rig, _ = registered_rig

    # Create viewer key
    create_resp = client.post(
        f"/api/v1/rigs/{rig.name}/viewers",
        json={"name": "ci"},
        headers=auth_headers,
    )
    viewer_key = create_resp.json()["viewer_key"]

    # Exchange for token
    token_resp = client.post("/api/v1/auth/token", json={"api_key": viewer_key})
    assert token_resp.status_code == 200

    # Use viewer token — should pass on GET
    viewer_token = token_resp.json()["access_token"]
    viewer_hdrs = {"Authorization": f"Bearer {viewer_token}"}
    assert client.get("/api/v1/rigs", headers=viewer_hdrs).status_code == 200

    # And fail on POST
    resp = client.post(
        "/api/v1/runs",
        json={"rig_name": rig.name, "suite_path": "tests/suites/engine_validation.yaml"},
        headers=viewer_hdrs,
    )
    assert resp.status_code == 403


def test_revoked_viewer_key_returns_401(client, registered_rig, auth_headers):
    """Revoking a viewer key causes /auth/token to return 401."""
    rig, _ = registered_rig

    create_resp = client.post(
        f"/api/v1/rigs/{rig.name}/viewers",
        json={"name": "temp"},
        headers=auth_headers,
    )
    viewer_id = create_resp.json()["viewer_id"]
    viewer_key = create_resp.json()["viewer_key"]

    # Revoke
    client.delete(f"/api/v1/rigs/{rig.name}/viewers/{viewer_id}", headers=auth_headers)

    # Token exchange should now fail
    token_resp = client.post("/api/v1/auth/token", json={"api_key": viewer_key})
    assert token_resp.status_code == 401


# ── Rig detail includes role field ────────────────────────────────────────────

def test_rig_detail_includes_role(client, auth_headers):
    resp = client.get("/api/v1/rigs", headers=auth_headers)
    assert resp.status_code == 200
    rigs = resp.json()
    assert len(rigs) > 0
    assert "role" in rigs[0]
    assert rigs[0]["role"] == "admin"
