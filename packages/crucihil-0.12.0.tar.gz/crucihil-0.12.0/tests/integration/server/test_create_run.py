"""Integration tests: POST /api/v1/runs (create queued run)."""

from __future__ import annotations

import pytest

from crucihil.server.models.run import TestRunRow


class TestCreateRun:
    def test_create_run_ok(self, client, registered_rig, auth_headers):
        rig, _ = registered_rig
        payload = {
            "rig_name": rig.name,
            "suite_path": "tests/suites/engine_validation.yaml",
        }
        resp = client.post("/api/v1/runs", json=payload, headers=auth_headers)
        assert resp.status_code == 201
        body = resp.json()
        assert body["rig_name"] == rig.name
        assert body["suite_name"] == "tests/suites/engine_validation.yaml"
        assert body["status"] == "queued"
        assert "run_id" in body
        assert isinstance(body["agent_notified"], bool)

    def test_create_run_rig_not_found(self, client, registered_rig, auth_headers):
        payload = {
            "rig_name": "no-such-rig",
            "suite_path": "tests/suites/engine_validation.yaml",
        }
        resp = client.post("/api/v1/runs", json=payload, headers=auth_headers)
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()

    def test_create_run_persisted_in_db(self, client, registered_rig, db_session, auth_headers):
        rig, _ = registered_rig
        payload = {"rig_name": rig.name, "suite_path": "my_suite.yaml"}
        resp = client.post("/api/v1/runs", json=payload, headers=auth_headers)
        assert resp.status_code == 201
        run_id = resp.json()["run_id"]

        row = db_session.get(TestRunRow, run_id)
        assert row is not None
        assert row.status == "queued"
        assert row.triggered_by == "mcp"
        assert row.suite_name == "my_suite.yaml"
        assert row.rig_id == rig.id

    def test_create_run_with_tags_and_suite_type(self, client, registered_rig, auth_headers):
        rig, _ = registered_rig
        payload = {
            "rig_name": rig.name,
            "suite_path": "suite.yaml",
            "tags": ["smoke", "engine"],
            "suite_type": "regression",
        }
        resp = client.post("/api/v1/runs", json=payload, headers=auth_headers)
        assert resp.status_code == 201

    def test_create_run_requires_auth(self, client, registered_rig):
        rig, _ = registered_rig
        payload = {"rig_name": rig.name, "suite_path": "suite.yaml"}
        resp = client.post("/api/v1/runs", json=payload)
        assert resp.status_code in (401, 403)  # HTTPBearer raises 403; JWT validation raises 401

    def test_run_appears_in_list(self, client, registered_rig, auth_headers):
        rig, _ = registered_rig
        payload = {"rig_name": rig.name, "suite_path": "smoke_suite.yaml"}
        create_resp = client.post("/api/v1/runs", json=payload, headers=auth_headers)
        assert create_resp.status_code == 201
        run_id = create_resp.json()["run_id"]

        list_resp = client.get("/api/v1/runs", headers=auth_headers)
        assert list_resp.status_code == 200
        run_ids = [r["id"] for r in list_resp.json()]
        assert run_id in run_ids
